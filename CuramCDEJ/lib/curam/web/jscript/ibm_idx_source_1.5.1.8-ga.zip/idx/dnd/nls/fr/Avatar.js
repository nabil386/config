define({     
//begin v1.x content
	copyText: "Copier ${num} éléments",
	moveText: "Déplacer ${num} éléments",
	copyOneText: "Copier 1 élément",
	moveOneText: "Déplacer 1 élément"
//end v1.x content
});

