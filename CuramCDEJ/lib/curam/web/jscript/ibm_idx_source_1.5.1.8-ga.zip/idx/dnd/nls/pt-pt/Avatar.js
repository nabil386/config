define({     
//begin v1.x content
	copyText: "Copiar ${num} itens",
	moveText: "Mover ${num} itens",
	copyOneText: "Copiar 1 item",
	moveOneText: "Mover 1 item"
//end v1.x content
});

