define({     
//begin v1.x content
	copyText: "Kopiera ${num} objekt",
	moveText: "Flytta ${num} objekt",
	copyOneText: "Kopiera 1 objekt",
	moveOneText: "Flytta 1 objekt"
//end v1.x content
});

