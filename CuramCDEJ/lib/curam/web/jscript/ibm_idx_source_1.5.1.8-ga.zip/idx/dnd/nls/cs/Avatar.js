define({     
//begin v1.x content
	copyText: "Kopírovat položky (počet: ${num})",
	moveText: "Přesunout položky (počet: ${num})",
	copyOneText: "Kopírovat 1 položku",
	moveOneText: "Přesunout 1 položku"
//end v1.x content
});

