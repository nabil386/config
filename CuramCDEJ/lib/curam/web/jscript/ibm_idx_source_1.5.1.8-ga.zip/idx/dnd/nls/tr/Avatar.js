define({     
//begin v1.x content
	copyText: "${num} öğe kopyala",
	moveText: "${num} öğe taşı",
	copyOneText: "1 öğe kopyala",
	moveOneText: "1 öğe taşı"
//end v1.x content
});

