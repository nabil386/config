define({     
//begin v1.x content
	copyText: "Copiar ${num} elements",
	moveText: "Moure ${num} elements",
	copyOneText: "Copiar 1 element",
	moveOneText: "Moure 1 element"
//end v1.x content
});

