define({     
//begin v1.x content
	copyText: "Kopírovať ${num} položiek",
	moveText: "Presunúť ${num} položiek",
	copyOneText: "Kopírovať 1 položku",
	moveOneText: "Presunúť 1 položku"
//end v1.x content
});

