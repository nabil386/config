define({     
//begin v1.x content
	copyText: "Копировать ${num} элемента/ов",
	moveText: "Переместить ${num} элемента/ов",
	copyOneText: "Копировать 1 элемент",
	moveOneText: "Переместить 1 элемент"
//end v1.x content
});

