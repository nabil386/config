define({     
//begin v1.x content
	copyText: "Копиране на ${num} елемента",
	moveText: "Преместване на ${num} елемента",
	copyOneText: "Копиране на 1 елемент",
	moveOneText: "Преместване на 1 елемент"
//end v1.x content
});

