define({     
//begin v1.x content
	copyText: "${num}개 항목 복사",
	moveText: "${num}개 항목 이동",
	copyOneText: "1개 항목 복사",
	moveOneText: "1개 항목 이동"
//end v1.x content
});

