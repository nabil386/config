define({     
//begin v1.x content
	copyText: "Copia ${num} elementi",
	moveText: "Sposta ${num} elementi",
	copyOneText: "Copia 1 elemento",
	moveOneText: "Sposta 1 elemento"
//end v1.x content
});

