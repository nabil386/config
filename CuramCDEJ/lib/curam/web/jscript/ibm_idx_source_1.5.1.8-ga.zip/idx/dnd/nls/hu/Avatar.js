define({     
//begin v1.x content
	copyText: "${num} elem másolása",
	moveText: "${num} elem áthelyezése",
	copyOneText: "1 elem másolása",
	moveOneText: "1 elem áthelyezése"
//end v1.x content
});

