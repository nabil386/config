define({     
//begin v1.x content
	copyText: "复制 ${num} 个项目",
	moveText: "移动 ${num} 个项目",
	copyOneText: "复制 1 个项目",
	moveOneText: "移动 1 个项目"
//end v1.x content
});

