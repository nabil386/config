define({     
//begin v1.x content
	copyText: "Kopiraj ${num} stavki",
	moveText: "Premjesti ${num} stavki",
	copyOneText: "Kopiraj 1 stavku",
	moveOneText: "Premjesti 1 stavku"
//end v1.x content
});

