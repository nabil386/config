define({     
//begin v1.x content
	copyText: "Copiere ${num} articole",
	moveText: "Mutare ${num} articole",
	copyOneText: "Copiere 1 articol",
	moveOneText: "Mutare 1 articol"
//end v1.x content
});

