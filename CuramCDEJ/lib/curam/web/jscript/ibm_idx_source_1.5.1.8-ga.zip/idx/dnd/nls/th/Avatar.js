define({     
//begin v1.x content
	copyText: "คัดลอก ${num} ไอเท็ม",
	moveText: "ย้าย ${num} ไอเท็ม",
	copyOneText: "คัดลอก 1 ไอเท็ม",
	moveOneText: "ย้าย 1 ไอเท็ม"
//end v1.x content
});

