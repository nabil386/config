define({     
//begin v1.x content
	copyText: "העתקת ${num} פריטים",
	moveText: "העברת ${num} פריטים",
	copyOneText: "העתקת 1 פריט",
	moveOneText: "העברת 1 פריט"
//end v1.x content
});

