define({     
//begin v1.x content
   	altTitle: "Arbejdsområde-skilleblad for ${title}"
//end v1.x content
});

