define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus SHIFT plus ${accessKey} în Windows şi Linux sau CONTROL plus ${accessKey} în Mac",
	keySequence_Safari: "CONTROL plus OPT plus ${accessKey} în Mac sau ALT plus ${accessKey} în Windows",
	keySequence_Chrome: "ALT plus ${accessKey} în Windows şi Linux sau CONTROL plus OPT plus ${accessKey} în Mac",
	shortcutListMessage: "Scurtăturile pentru această pagină sunt:",
	a11yPrologueLabel: "Prolog accesibilitate",
    a11yStatementLabel: "Declaraţia de accesibilitate",
    skipToLocationMessage: "Săriţi la ${description}",
	shortcutKeyMessage_internal: "Pentru a sări la ${description}, utilizaţi ${keySequence}.",
	shortcutKeyMessage_external: "Pentru a vă lega la ${description}, utilizaţi ${keySequence}.",
	shortcutMessage_internal: "Săriţi la ${description}.",
	shortcutMessage_external: "Legaţi-vă la ${description}.",

	a11yMainContentAreaName: "conţinutul principal",

	a11yNavigationAreaName: "navigare",

	a11yBannerAreaName: "banner"
//end v1.x content
});

