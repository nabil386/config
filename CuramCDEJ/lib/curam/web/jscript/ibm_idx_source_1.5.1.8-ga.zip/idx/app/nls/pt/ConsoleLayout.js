define({     
//begin v1.x content
	about:				"Sobre",
	help:			      "Ajuda",
	logout:				"Efetuar Logout",
	login:				"Efetuar Login",
	userNameMessage:  "Bem vindo, ${username}"
//end v1.x content
});

