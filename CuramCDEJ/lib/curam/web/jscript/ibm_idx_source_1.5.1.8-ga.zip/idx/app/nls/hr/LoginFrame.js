define({     
//begin v1.x content
	loginTitle: "Prijava",
	labelUserName: "Ime korisnika",
	labelPassword: "Lozinka",
	invalidMessageTitle: "Nevažeći pokušaj prijave",
	invalidMessage: "Nije navedena važeća vrijednost u oba obavezna polja."
//end v1.x content
});

