define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Kan ikke åpne mer enn ${maxOpen} \"${workspaceTypeName}\"\u200e arbeidsområder. Lukk \"${workspaceTypeName}\"\u200e-arbeidsområder som allerede er åpne."
//end v1.x content
});

