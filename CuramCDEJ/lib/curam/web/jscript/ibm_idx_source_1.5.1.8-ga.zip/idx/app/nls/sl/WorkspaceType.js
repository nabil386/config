define({     
//begin v1.x content
    loadingMessage: "Nalaganje ${workspaceTitle}. Počakajte ...",
    failedLoadMessage: "Nalaganje ${workspaceTitle} ni uspelo."
//end v1.x content
});

