define({     
//begin v1.x content
	about:				"Ürün Bilgisi",
	help:			      "Yardım",
	logout:				"Oturumu kapat",
	login:				"Oturum aç",
	userNameMessage:  "Hoş Geldiniz ${username}"
//end v1.x content
});

