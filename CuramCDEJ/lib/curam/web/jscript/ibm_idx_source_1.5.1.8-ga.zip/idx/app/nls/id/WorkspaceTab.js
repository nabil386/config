define({     
//begin v1.x content
   	altTitle: "Tab Ruang Kerja untuk ${title}"
//end v1.x content
});

