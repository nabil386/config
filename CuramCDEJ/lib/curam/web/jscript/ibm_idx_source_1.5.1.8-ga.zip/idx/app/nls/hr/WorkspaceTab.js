define({     
//begin v1.x content
   	altTitle: "Kartica Radni prostor za ${title}"
//end v1.x content
});

