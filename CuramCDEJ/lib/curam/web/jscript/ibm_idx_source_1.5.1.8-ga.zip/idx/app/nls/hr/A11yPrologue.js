define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus SHIFT plus ${accessKey} na Windows i Linuxu ili CONTROL plus ${accessKey} na Macu",
	keySequence_Safari: "CONTROL plus OPT plus ${accessKey} na Macu ili ALT plus ${accessKey} na Windows",
	keySequence_Chrome: "ALT plus ${accessKey} na Windowsu i Linuxu ili CONTROL plus OPT plus ${accessKey} na Macu",
	shortcutListMessage: "Prečice tipkovnice za ovu stranicu su:",
	a11yPrologueLabel: "Predgovor o dostupnosti",
    a11yStatementLabel: "Izjava o dostupnosti",
    skipToLocationMessage: "Preskoči na ${description}",
	shortcutKeyMessage_internal: "Za preskakanje na ${description} upotrijebite ${keySequence}.",
	shortcutKeyMessage_external: "Za povezivanje s ${description} upotrijebite ${keySequence}.",
	shortcutMessage_internal: "Preskoči na ${description}.",
	shortcutMessage_external: "Poveži se s ${description}.",

	a11yMainContentAreaName: "glavni sadržaj",

	a11yNavigationAreaName: "navigacija",

	a11yBannerAreaName: "uvodnik"
//end v1.x content
});

