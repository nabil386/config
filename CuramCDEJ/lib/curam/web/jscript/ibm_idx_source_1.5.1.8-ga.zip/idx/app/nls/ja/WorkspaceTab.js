define({     
//begin v1.x content
   	altTitle: "${title} のワークスペース・タブ"
//end v1.x content
});

