define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Impossibile aprire più di ${maxOpen} \"${workspaceTypeName}\"\u200e aree di lavoro. Se possibile, chiudere le aree di lavoro \"${workspaceTypeName}\"\u200e che sono già aperte."
//end v1.x content
});

