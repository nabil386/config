define({     
//begin v1.x content
    loadingMessage: "Učitavanje ${workspaceTitle}.  Molim, čekajte....",
    failedLoadMessage: "Neuspješno učitavanje ${workspaceTitle}."
//end v1.x content
});

