define({     
//begin v1.x content
	about:				"關於",
	help:			      "說明",
	logout:				"登出",
	login:				"登入",
	userNameMessage:  "歡迎，${username}"
//end v1.x content
});

