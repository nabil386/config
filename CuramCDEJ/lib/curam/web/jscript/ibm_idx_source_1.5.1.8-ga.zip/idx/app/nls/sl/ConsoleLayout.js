define({     
//begin v1.x content
	about:				"O programu",
	help:			      "Pomoč",
	logout:				"Odjava",
	login:				"Prijava",
	userNameMessage:  "Dobrodošli, ${username}"
//end v1.x content
});

