/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "共有",
	actionSettings: "設定",
	actionHelp: "ヘルプ",
	searchEntry: "検索",
	searchSubmit: "検索",
	primarySearchLabelSuffix: "1 次検索",
	secondarySearchLabelSuffix: "2 次検索",
	homeButton: "ホーム"
//end v1.x content
});

