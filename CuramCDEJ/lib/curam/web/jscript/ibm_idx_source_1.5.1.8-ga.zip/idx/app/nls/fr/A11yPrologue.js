define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT + ${accessKey}",
	keySequence_Firefox: "ALT + MAJ + ${accessKey} sous Windows et Linux ou CONTROL + ${accessKey} sous Mac",
	keySequence_Safari: "CONTROL + OPT + ${accessKey} sous Mac ou ALT + ${accessKey} sous Windows",
	keySequence_Chrome: "ALT + ${accessKey} sous Windows et Linux ou CONTROL + OPT + ${accessKey} sous Mac",
	shortcutListMessage: "Les raccourcis de cette page sont les suivants :",
	a11yPrologueLabel: "Prologue d'accessibilité",
    a11yStatementLabel: "Instruction d'accessibilité",
    skipToLocationMessage: "Passer à ${description}",
	shortcutKeyMessage_internal: "Pour passer à ${description}, utilisez ${keySequence}.",
	shortcutKeyMessage_external: "Pour se connecter à ${description}, utilisez ${keySequence}.",
	shortcutMessage_internal: "Passer à ${description}.",
	shortcutMessage_external: "Se connecter à ${description}.",

	a11yMainContentAreaName: "contenu principal",

	a11yNavigationAreaName: "navigation",

	a11yBannerAreaName: "bannière"
//end v1.x content
});

