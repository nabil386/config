define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Impossible d'ouvrir plus de ${maxOpen} espaces de travail \"${workspaceTypeName}\"\u200e.  Si possible, fermez les espaces de travail \"${workspaceTypeName}\"\u200e déjà ouverts."
//end v1.x content
});

