define({     
//begin v1.x content
	loginTitle: "Вход в систему",
	labelUserName: "Имя пользователя",
	labelPassword: "Пароль",
	invalidMessageTitle: "Неудачная попытка входа в систему",
	invalidMessage: "В оба обязательных поля должны быть введены правильные значения."
//end v1.x content
});

