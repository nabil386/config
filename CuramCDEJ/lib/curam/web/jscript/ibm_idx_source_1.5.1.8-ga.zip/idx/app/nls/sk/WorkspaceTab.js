define({     
//begin v1.x content
   	altTitle: "Karta Pracovný priestor pre ${title}"
//end v1.x content
});

