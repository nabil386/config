define({     
//begin v1.x content
    loadingMessage: "Зареждане ${workspaceTitle}.  Моля, изчакайте....",
    failedLoadMessage: "Неуспешно зареждане на ${workspaceTitle}."
//end v1.x content
});

