define({     
//begin v1.x content
	about:				"Относно",
	help:			      "Помощ",
	logout:				"Излизане",
	login:				"Влизане",
	userNameMessage:  "Добре дошли ${username}"
//end v1.x content
});

