define({     
//begin v1.x content
	loginTitle: "Вхід до системи",
	labelUserName: "Ім'я користувача",
	labelPassword: "Пароль",
	invalidMessageTitle: "Неприпустима спроба входу до системи",
	invalidMessage: "В обох полях має бути вказано дійсне значення."
//end v1.x content
});

