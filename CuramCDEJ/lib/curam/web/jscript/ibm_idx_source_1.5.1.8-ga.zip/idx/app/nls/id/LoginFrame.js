define({     
//begin v1.x content
	loginTitle: "Login",
	labelUserName: "Nama Pengguna",
	labelPassword: "Kata Sandi",
	invalidMessageTitle: "Percobaan Login Tidak Valid",
	invalidMessage: "Nilai yang valid belum dimasukkan pada kedua bidang yang diperlukan."
//end v1.x content
});

