define({     
//begin v1.x content
   	altTitle: "${title} 的工作空间选项卡"
//end v1.x content
});

