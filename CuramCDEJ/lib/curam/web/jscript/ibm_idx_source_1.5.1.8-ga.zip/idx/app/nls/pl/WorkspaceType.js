define({     
//begin v1.x content
    loadingMessage: "Ładowanie ${workspaceTitle}.  Proszę czekać...",
    failedLoadMessage: "Ładowanie ${workspaceTitle} nie powiodło się."
//end v1.x content
});

