define({     
//begin v1.x content
   	altTitle: "แท็บเวิร์กสเปซสำหรับ ${title}"
//end v1.x content
});

