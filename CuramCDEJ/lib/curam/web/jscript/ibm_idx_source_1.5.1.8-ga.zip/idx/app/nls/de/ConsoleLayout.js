define({     
//begin v1.x content
	about:				"Informationen zu",
	help:			      "Hilfe",
	logout:				"Abmelden",
	login:				"Anmelden",
	userNameMessage:  "Willkommen ${username}"
//end v1.x content
});

