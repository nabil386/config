define({     
//begin v1.x content
    tooManyOpenWorkspaces: "${maxOpen} \"${workspaceTypeName}\"\u200e артық жұмыс кеңістігі ашылмайды.  Егер мүмкін болса, \"${workspaceTypeName}\"\u200e жұмыс кңістіктері бұрыннан ашық болса жабыңыз."
//end v1.x content
});

