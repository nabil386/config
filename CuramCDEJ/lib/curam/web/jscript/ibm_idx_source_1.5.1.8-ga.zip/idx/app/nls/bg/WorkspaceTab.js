define({     
//begin v1.x content
   	altTitle: "Раздел работно пространство за ${title}"
//end v1.x content
});

