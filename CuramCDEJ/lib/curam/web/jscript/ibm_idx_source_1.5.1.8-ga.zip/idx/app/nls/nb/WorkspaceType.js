define({     
//begin v1.x content
    loadingMessage: "Laster inn ${workspaceTitle}. Vent litt....",
    failedLoadMessage: "Kunne ikke laste inn ${workspaceTitle}."
//end v1.x content
});

