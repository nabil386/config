define({     
//begin v1.x content
   	altTitle: "${title} параметріне арналған Tab жұмыс кеңістігі"
//end v1.x content
});

