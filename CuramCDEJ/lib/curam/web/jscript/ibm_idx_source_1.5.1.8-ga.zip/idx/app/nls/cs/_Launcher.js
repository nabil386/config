define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Nelze otevřít více než ${maxOpen} pracovních prostorů \"${workspaceTypeName}\"\u200e. Je-li to možné, zavřete pracovní prostory \"${workspaceTypeName}\"\u200e, které jsou již otevřeny."
//end v1.x content
});

