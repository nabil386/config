define({     
//begin v1.x content
    tooManyOpenWorkspaces: "ไม่สามารถเปิดมากกว่า ${maxOpen} \"${workspaceTypeName}\"\u200e เวิร์กสเปซ  หากเป็นไปได้ ให้ปิด \"${workspaceTypeName}\"\u200e เวิร์กสเปซที่เปิดอยู่"
//end v1.x content
});

