define({     
//begin v1.x content
	loginTitle: "Logg på",
	labelUserName: "Brukernavn",
	labelPassword: "Passord",
	invalidMessageTitle: "Ugyldig påloggingsforsøk",
	invalidMessage: "Det er ikke oppgitt en gyldig verdi i begge obligatoriske felt."
//end v1.x content
});

