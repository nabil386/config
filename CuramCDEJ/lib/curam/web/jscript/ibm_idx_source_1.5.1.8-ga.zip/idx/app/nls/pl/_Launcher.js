define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Nie można otworzyć więcej niż ${maxOpen} obszarów roboczych \"${workspaceTypeName}\"\u200e.  Jeśli to możliwe, zamknij obszary robocze \"${workspaceTypeName}\"\u200e, które są już otwarte."
//end v1.x content
});

