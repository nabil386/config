define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Ni mogoče odpreti več kot ${maxOpen} \"${workspaceTypeName}\"\u200e delovnih prostorov.  Če je možno, zaprite \"${workspaceTypeName}\"\u200e delovnih prostorov, ki so že odprti."
//end v1.x content
});

