define({     
//begin v1.x content
	loginTitle: "Logare",
	labelUserName: "Nume utilizator",
	labelPassword: "Parola",
	invalidMessageTitle: "Încercare de logare invalidă",
	invalidMessage: "O valoare introdusă în cele două câmpuri necesare nu este validă."
//end v1.x content
});

