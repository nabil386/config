define({     
//begin v1.x content
	loginTitle: "Início de sessão",
	labelUserName: "Nome de utilizador",
	labelPassword: "Palavra-passe",
	invalidMessageTitle: "Tentativa de início de sessão inválida",
	invalidMessage: "Não foi inserido um valor válido em ambos os campos necessários."
//end v1.x content
});

