define({     
//begin v1.x content
	loginTitle: "Přihlásit",
	labelUserName: "Jméno uživatele",
	labelPassword: "Heslo",
	invalidMessageTitle: "Neplatný pokus o přihlášení",
	invalidMessage: "V povinných polích nebyly zadány platné hodnoty."
//end v1.x content
});

