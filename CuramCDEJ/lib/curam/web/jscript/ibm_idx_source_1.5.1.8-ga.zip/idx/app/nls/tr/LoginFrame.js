define({     
//begin v1.x content
	loginTitle: "Oturum Aç",
	labelUserName: "Kullanıcı adı",
	labelPassword: "Parola",
	invalidMessageTitle: "Geçersiz Oturum Açma Girişimi",
	invalidMessage: "Her iki zorunlu alana geçerli bir değer girilmedi."
//end v1.x content
});

