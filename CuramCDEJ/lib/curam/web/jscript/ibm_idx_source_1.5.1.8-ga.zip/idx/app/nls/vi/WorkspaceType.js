define({     
//begin v1.x content
    loadingMessage: "Ðang tải ${workspaceTitle}.  Vui lòng chờ....",
    failedLoadMessage: "Không thể tải ${workspaceTitle}."
//end v1.x content
});

