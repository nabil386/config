define({     
//begin v1.x content
	about:				"Despre",
	help:			      "Ajutor",
	logout:				"Delogare",
	login:				"Logare",
	userNameMessage:  "Bine aţi venit ${username}"
//end v1.x content
});

