define({     
//begin v1.x content
	about:				"Відомості",
	help:			      "Довідка",
	logout:				"Вийти з системи",
	login:				"Вхід до системи",
	userNameMessage:  "Вітаємо, ${username}"
//end v1.x content
});

