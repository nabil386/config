define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT + ${accessKey}",
	keySequence_Firefox: "ALT + SHIFT + ${accessKey} trên Windows và Linux hoặc CONTROL + ${accessKey} trên Mac",
	keySequence_Safari: "CONTROL + OPT + ${accessKey} trên Mac hoặc ALT + ${accessKey} trên Windows",
	keySequence_Chrome: "ALT + ${accessKey} trên Windows và Linux hoặc CONTROL + OPT + ${accessKey} trên Mac",
	shortcutListMessage: "Lối tắt cho trang này là:",
	a11yPrologueLabel: "Phần dẫn nhập trợ năng",
    a11yStatementLabel: "Tuyên bố về trợ năng",
    skipToLocationMessage: "Bỏ qua đến ${description}",
	shortcutKeyMessage_internal: "Ðể bỏ quađến ${description} dùng ${keySequence}.",
	shortcutKeyMessage_external: "Ðể liên kết tới ${description} dùng ${keySequence}.",
	shortcutMessage_internal: "Bỏ qua đến ${description}.",
	shortcutMessage_external: "Liên kết tới ${description}.",

	a11yMainContentAreaName: "nội dung chính",

	a11yNavigationAreaName: "điều hướng",

	a11yBannerAreaName: "biểu ngữ"
//end v1.x content
});

