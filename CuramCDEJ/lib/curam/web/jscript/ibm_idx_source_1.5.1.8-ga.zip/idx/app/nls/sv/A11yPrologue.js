define({     
//begin v1.x content
	keySequence_InternetExplorer: "Alt + ${accessKey}",
	keySequence_Firefox: "Alt + skift + ${accessKey} för Windows och Linux eller CONTROL + ${accessKey} för Mac",
	keySequence_Safari: "CONTROL + OPT + ${accessKey} för Mac eller ALT + ${accessKey} för Windows",
	keySequence_Chrome: "Alt + ${accessKey} för Windows och Linux eller CONTROL + OPT + ${accessKey} för Mac",
	shortcutListMessage: "Kortkommandon för sidan:",
	a11yPrologueLabel: "Hjälpmedelsfunktioner",
    a11yStatementLabel: "Om hjälpmedelsfunktioner",
    skipToLocationMessage: "Gå till ${description}",
	shortcutKeyMessage_internal: "Gå till ${description} med ${keySequence}.",
	shortcutKeyMessage_external: "Länka till ${description} med ${keySequence}.",
	shortcutMessage_internal: "Gå till ${description}.",
	shortcutMessage_external: "Länka till ${description}.",

	a11yMainContentAreaName: "huvudinnehåll",

	a11yNavigationAreaName: "navigering",

	a11yBannerAreaName: "banderoll"
//end v1.x content
});

