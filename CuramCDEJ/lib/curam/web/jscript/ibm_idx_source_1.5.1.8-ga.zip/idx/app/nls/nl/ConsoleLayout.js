define({     
//begin v1.x content
	about:				"Info",
	help:			      "Help",
	logout:				"Afmelden",
	login:				"Aanmelden",
	userNameMessage:  "Welkom ${username}!"
//end v1.x content
});

