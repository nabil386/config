define({     
//begin v1.x content
    loadingMessage: "يتم تحميل ${workspaceTitle}.  برجاء الانتظار....",
    failedLoadMessage: "فشل في تحميل ${workspaceTitle}."
//end v1.x content
});

