define({     
//begin v1.x content
	loginTitle: "Login",
	labelUserName: "Nome de usuário",
	labelPassword: "Senha",
	invalidMessageTitle: "Tentativa de login inválida",
	invalidMessage: "Não foi inserido um valor válido em ambos os campos obrigatórios."
//end v1.x content
});

