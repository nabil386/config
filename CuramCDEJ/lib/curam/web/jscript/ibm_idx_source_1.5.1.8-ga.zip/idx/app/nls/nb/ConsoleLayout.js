define({     
//begin v1.x content
	about:				"Om",
	help:			      "Hjelp",
	logout:				"Logg av",
	login:				"Logg på",
	userNameMessage:  "Velkommen ${username}"
//end v1.x content
});

