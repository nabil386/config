define({     
//begin v1.x content
	about:				"Туралы",
	help:			      "Анықтама",
	logout:				"Шығу",
	login:				"Кіру",
	userNameMessage:  "Қош келдіңіз ${username}"
//end v1.x content
});

