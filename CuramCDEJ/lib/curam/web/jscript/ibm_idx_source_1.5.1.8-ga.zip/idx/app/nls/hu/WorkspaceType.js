define({     
//begin v1.x content
    loadingMessage: "${workspaceTitle} betöltése.  Kérem, várjon...",
    failedLoadMessage: "${workspaceTitle} betöltése nem sikerült."
//end v1.x content
});

