define({     
//begin v1.x content
	about:				"O aplikácii",
	help:			      "Pomoc",
	logout:				"Odhlásiť",
	login:				"Prihlásiť",
	userNameMessage:  "Vitajte ${username}"
//end v1.x content
});

