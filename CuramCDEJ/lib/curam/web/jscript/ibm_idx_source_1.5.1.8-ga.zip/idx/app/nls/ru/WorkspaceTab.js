define({     
//begin v1.x content
   	altTitle: "Вкладка Рабочее пространство для ${title}"
//end v1.x content
});

