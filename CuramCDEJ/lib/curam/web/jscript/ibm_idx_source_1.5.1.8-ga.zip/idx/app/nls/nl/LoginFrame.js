define({     
//begin v1.x content
	loginTitle: "Aanmelden",
	labelUserName: "Gebruikersnaam",
	labelPassword: "Wachtwoord",
	invalidMessageTitle: "Ongeldige aanmeldpoging",
	invalidMessage: "Er is geen geldige waarde ingevoerd in beide vereiste velden."
//end v1.x content
});

