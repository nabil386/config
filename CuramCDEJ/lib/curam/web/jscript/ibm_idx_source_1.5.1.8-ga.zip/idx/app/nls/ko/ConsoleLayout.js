define({     
//begin v1.x content
	about:				"정보",
	help:			      "도움말",
	logout:				"로그아웃",
	login:				"로그인",
	userNameMessage:  "${username} 님을 환영합니다."
//end v1.x content
});

