define({     
//begin v1.x content
    loadingMessage: "Загружается ${workspaceTitle}.  Подождите, пожалуйста....",
    failedLoadMessage: "Не удалось загрузить ${workspaceTitle}."
//end v1.x content
});

