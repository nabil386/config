define({     
//begin v1.x content
	loginTitle: "Anmeldung",
	labelUserName: "Benutzername",
	labelPassword: "Kennwort",
	invalidMessageTitle: "Ungültiger Anmeldeversuch",
	invalidMessage: "Es wurde nicht in beiden erforderlichen Feldern ein gültiger Wert eingegeben."
//end v1.x content
});

