define({     
//begin v1.x content
   	altTitle: "Registerkarte 'Arbeitsbereich' für ${title}"
//end v1.x content
});

