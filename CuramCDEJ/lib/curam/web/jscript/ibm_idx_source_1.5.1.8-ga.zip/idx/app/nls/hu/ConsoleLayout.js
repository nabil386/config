define({     
//begin v1.x content
	about:				"Névjegy",
	help:			      "Súgó",
	logout:				"Kijelentkezés",
	login:				"Bejelentkezés",
	userNameMessage:  "Üdvözöljük, ${username}"
//end v1.x content
});

