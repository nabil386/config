define({     
//begin v1.x content
   	altTitle: "Вкладка Робоча область для ${title}"
//end v1.x content
});

