define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT più ${accessKey}",
	keySequence_Firefox: "ALT più MAIUSC più ${accessKey} su Windows e Linux o CONTROL più ${accessKey} su Mac",
	keySequence_Safari: "CONTROL più OPT più ${accessKey} su Mac o ALT più ${accessKey} su Windows",
	keySequence_Chrome: "ALT più ${accessKey} su Windows e Linux o CONTROL più OPT più ${accessKey} su Mac",
	shortcutListMessage: "Le scelte rapide per questa pagina sono:",
	a11yPrologueLabel: "Prologo di accesso facilitato",
    a11yStatementLabel: "Istruzione di accesso facilitato",
    skipToLocationMessage: "Passa a ${description}",
	shortcutKeyMessage_internal: "Per passare a ${description}, utilizzare ${keySequence}.",
	shortcutKeyMessage_external: "Per collegarsi a ${description}, utilizzare ${keySequence}.",
	shortcutMessage_internal: "Passare a ${description}.",
	shortcutMessage_external: "Collegarsi a ${description}.",

	a11yMainContentAreaName: "contenuto principale",

	a11yNavigationAreaName: "navigazione",

	a11yBannerAreaName: "banner"
//end v1.x content
});

