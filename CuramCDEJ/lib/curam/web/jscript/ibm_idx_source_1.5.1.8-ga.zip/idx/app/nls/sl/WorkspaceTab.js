define({     
//begin v1.x content
   	altTitle: "Zavihek delovnega prostora za ${title}"
//end v1.x content
});

