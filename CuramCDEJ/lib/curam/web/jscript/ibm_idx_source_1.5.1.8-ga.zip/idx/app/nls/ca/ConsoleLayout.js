define({     
//begin v1.x content
	about:				"Quant a",
	help:			      "Ajuda",
	logout:				"Finalitza sessió",
	login:				"Inicia sessió",
	userNameMessage:  "Benvingut ${username}"
//end v1.x content
});

