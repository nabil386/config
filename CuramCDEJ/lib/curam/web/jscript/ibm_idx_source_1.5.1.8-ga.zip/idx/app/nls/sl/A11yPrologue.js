define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus SHIFT plus ${accessKey} v sistemu Windows in Linux ali CONTROL plus ${accessKey} v sistemu Mac",
	keySequence_Safari: "CONTROL plus OPT plus ${accessKey} v sistemu Mac ali ALT plus ${accessKey} v sistemu Windows",
	keySequence_Chrome: "ALT plus ${accessKey} v sistemu Windows in Linux ali CONTROL plus OPT plus ${accessKey} v sistemu Mac",
	shortcutListMessage: "Bližnjice za to stran so:",
	a11yPrologueLabel: "Uvod v pripomočke za osebe s posebnimi potrebami",
    a11yStatementLabel: "Izjava o pripomočkih za osebe s posebnimi potrebami",
    skipToLocationMessage: "Preskoči na ${description}",
	shortcutKeyMessage_internal: "Za preskok na ${description} uporabite ${keySequence}.",
	shortcutKeyMessage_external: "Za povezavo na ${description} uporabite ${keySequence}.",
	shortcutMessage_internal: "Preskoči na ${description}.",
	shortcutMessage_external: "Povezava na ${description}.",

	a11yMainContentAreaName: "glavna vsebina",

	a11yNavigationAreaName: "krmarjenje",

	a11yBannerAreaName: "pasica"
//end v1.x content
});

