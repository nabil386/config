define({     
//begin v1.x content
    loadingMessage: "Laden van ${workspaceTitle}.  Even geduld a.u.b.",
    failedLoadMessage: "${workspaceTitle} kan niet worden geladen."
//end v1.x content
});

