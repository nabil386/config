define({     
//begin v1.x content
    tooManyOpenWorkspaces: "En fazla ${maxOpen} \"${workspaceTypeName}\"\u200e çalışma alanı açık olabilir.  Mümkünse açık olan  \"${workspaceTypeName}\"\u200e çalışma alanını kapatın."
//end v1.x content
});

