define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT + ${accessKey}",
	keySequence_Firefox: "ALT + VAIHTO + ${accessKey} Windows- ja Linux-käyttöjärjestelmissä tai CONTROL + ${accessKey} Mac-käyttöjärjestelmissä",
	keySequence_Safari: "CONTROL + optionäppäin + ${accessKey} Mac-käyttöjärjestelmissä tai ALT + ${accessKey} Windows-käyttöjärjestelmissä",
	keySequence_Chrome: "ALT + ${accessKey} Windows- ja Linux-käyttöjärjestelmissä tai CONTROL + optionäppäin + ${accessKey} n Mac-käyttöjärjestelmissä",
	shortcutListMessage: "Tämän sivun pikanäppäinyhdistelmät ovat seuraavat:",
	a11yPrologueLabel: "Helppokäyttöisyystoimintojen esitoimet",
    a11yStatementLabel: "Helppokäyttöisyyslausunto",
    skipToLocationMessage: "Siirry kohtaan ${description}",
	shortcutKeyMessage_internal: "Voit siirtyä kohtaan ${description} näppäinyhdistelmällä ${keySequence}.",
	shortcutKeyMessage_external: "Voit luoda linkin kohteeseen ${description} näppäinyhdistelmällä ${keySequence}.",
	shortcutMessage_internal: "Siirry kohtaan ${description}.",
	shortcutMessage_external: "Luo linkki kohteeseen ${description}.",

	a11yMainContentAreaName: "pääsisältö",

	a11yNavigationAreaName: "siirtyminen",

	a11yBannerAreaName: "mainospalkki"
//end v1.x content
});

