define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT مع ${accessKey}",
	keySequence_Firefox: "ALT مع SHIFT مع ${accessKey} على نظام Windows و Linux أو CONTROL مع ${accessKey} على نظام Mac",
	keySequence_Safari: "CONTROL مع OPT مع ${accessKey} على نظام Mac أو ALT مع ${accessKey} على نظام Windows",
	keySequence_Chrome: "ALT + ${accessKey} على نظام Windows و Linux أو CONTROL + OPT + ${accessKey} على نظام Mac",
	shortcutListMessage: "المسارات المختصرة لهذه الصفحة هي:",
	a11yPrologueLabel: "مقدمة امكانية التوصل",
    a11yStatementLabel: "عبارة امكانية التوصل",
    skipToLocationMessage: "تخطي الى ${description}",
	shortcutKeyMessage_internal: "للتخطي الى ${description} قم باستخدام ${keySequence}.",
	shortcutKeyMessage_external: "للتوصل الى ${description} قم باستخدام ${keySequence}.",
	shortcutMessage_internal: "تخطي الى ${description}.",
	shortcutMessage_external: "ربط مع ${description}.",

	a11yMainContentAreaName: "محتويات رئيسية",

	a11yNavigationAreaName: "تجول",

	a11yBannerAreaName: "شريط العنوان"
//end v1.x content
});

