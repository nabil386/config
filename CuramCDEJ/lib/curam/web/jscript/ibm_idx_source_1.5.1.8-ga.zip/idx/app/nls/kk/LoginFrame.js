define({     
//begin v1.x content
	loginTitle: "Логин",
	labelUserName: "Пайдаланушының аты",
	labelPassword: "Құпия сөз",
	invalidMessageTitle: "Жарамсыз енгізу әрекеті",
	invalidMessage: "Жарамды мән сұралған екеуінеде енгізілмеген."
//end v1.x content
});

