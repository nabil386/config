define({     
//begin v1.x content
	about:				"אודות",
	help:			      "עזרה",
	logout:				"התנתקות",
	login:				"התחברות",
	userNameMessage:  "שלום ${username}"
//end v1.x content
});

