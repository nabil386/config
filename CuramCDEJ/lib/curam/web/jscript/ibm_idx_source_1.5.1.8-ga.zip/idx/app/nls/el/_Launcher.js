define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Δεν είναι δυνατό το άνοιγμα περισσότερων από ${maxOpen} χώρων εργασίας \"${workspaceTypeName}\"\u200e.  Αν είναι εφικτό, κλείστε τους ήδη ανοιχτούς χώρους εργασίας \"${workspaceTypeName}\"\u200e."
//end v1.x content
});

