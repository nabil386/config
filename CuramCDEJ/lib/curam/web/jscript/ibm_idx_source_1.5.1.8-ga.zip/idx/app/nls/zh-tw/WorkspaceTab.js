define({     
//begin v1.x content
   	altTitle: "${title} 的工作區標籤"
//end v1.x content
});

