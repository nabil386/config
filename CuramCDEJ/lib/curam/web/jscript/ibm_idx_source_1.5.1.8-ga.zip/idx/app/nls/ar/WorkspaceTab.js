define({     
//begin v1.x content
   	altTitle: "علامة تبويب مساحة العمل الى ${title}"
//end v1.x content
});

