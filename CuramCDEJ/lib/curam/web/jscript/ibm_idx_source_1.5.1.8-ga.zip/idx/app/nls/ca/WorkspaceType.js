define({     
//begin v1.x content
    loadingMessage: "S'està carregant ${workspaceTitle}. Espereu...",
    failedLoadMessage: "No s'ha pogut carregar ${workspaceTitle}."
//end v1.x content
});

