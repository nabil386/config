define({     
//begin v1.x content
    loadingMessage: "Caricamento di ${workspaceTitle}.  Attendere....",
    failedLoadMessage: "Impossibile caricare ${workspaceTitle}."
//end v1.x content
});

