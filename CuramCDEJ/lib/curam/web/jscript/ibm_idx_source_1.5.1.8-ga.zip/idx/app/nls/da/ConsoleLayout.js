define({     
//begin v1.x content
	about:				"Om",
	help:			      "Hjælp",
	logout:				"Log af",
	login:				"Log på",
	userNameMessage:  "Velkommen ${username}"
//end v1.x content
});

