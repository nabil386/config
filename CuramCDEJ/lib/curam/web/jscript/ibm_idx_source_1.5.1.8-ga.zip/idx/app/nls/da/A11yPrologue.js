define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus SHIFT plus ${accessKey} i Windows og Linux eller CONTROL plus ${accessKey} på Mac",
	keySequence_Safari: "CONTROL plus OPT plus ${accessKey} på Mac eller ALT plus ${accessKey} i Windows",
	keySequence_Chrome: "ALT plus ${accessKey} i Windows og Linux eller CONTROL plus OPT plus ${accessKey} på Mac",
	shortcutListMessage: "Genvejene for denne side er:",
	a11yPrologueLabel: "Handicapvenlighed - prolog",
    a11yStatementLabel: "Erklæring vedrørende handicapvenlighed",
    skipToLocationMessage: "Spring til ${description}",
	shortcutKeyMessage_internal: "Du kan springe til ${description} med ${keySequence}.",
	shortcutKeyMessage_external: "Du kan linke til ${description} med ${keySequence}.",
	shortcutMessage_internal: "Spring til ${description}.",
	shortcutMessage_external: "Link til ${description}.",

	a11yMainContentAreaName: "hovedindhold",

	a11yNavigationAreaName: "navigering",

	a11yBannerAreaName: "banner"
//end v1.x content
});

