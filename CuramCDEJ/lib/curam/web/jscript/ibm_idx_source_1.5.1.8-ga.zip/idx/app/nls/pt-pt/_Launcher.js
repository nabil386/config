define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Não é possível abrir mais de ${maxOpen} \"${workspaceTypeName}\"\u200e espaços de trabalho.  Se possível, feche os \"${workspaceTypeName}\"\u200e espaços de trabalho que já estão abertos."
//end v1.x content
});

