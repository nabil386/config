define({     
//begin v1.x content
	loginTitle: "Влизане",
	labelUserName: "Потребителско име",
	labelPassword: "Парола",
	invalidMessageTitle: "Невалиден опит за влизане",
	invalidMessage: "Не е въведена валидна стойност в двете задължителни полета."
//end v1.x content
});

