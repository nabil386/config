define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT плюс ${accessKey}",
	keySequence_Firefox: "ALT плюс SHIFT плюс ${accessKey} в Windows и Linux или CONTROL плюс ${accessKey} на Mac",
	keySequence_Safari: "CONTROL плюс OPT плюс ${accessKey} на Mac или ALT плюс ${accessKey} в Windows",
	keySequence_Chrome: "ALT плюс ${accessKey} в Windows и Linux или CONTROL плюс OPT плюс ${accessKey} на Mac",
	shortcutListMessage: "Ярлыки для этой страницы:",
	a11yPrologueLabel: "Вводная информация о доступности",
    a11yStatementLabel: "Заявление о доступности",
    skipToLocationMessage: "Пропустить до раздела ${description}",
	shortcutKeyMessage_internal: "Чтобы пропустить до раздела ${description}, используйте ${keySequence}.",
	shortcutKeyMessage_external: "Чтобы задать ссылку на ${description}, используйте ${keySequence}.",
	shortcutMessage_internal: "Пропустить до раздела ${description}.",
	shortcutMessage_external: "Задать ссылку на ${description}.",

	a11yMainContentAreaName: "Основное содержимое",

	a11yNavigationAreaName: "Навигация",

	a11yBannerAreaName: "Баннер"
//end v1.x content
});

