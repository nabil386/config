define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT més ${accessKey}",
	keySequence_Firefox: "ALT més MAJÚSCULES més ${accessKey} a Windows i Linux o CONTROL més ${accessKey} a Mac",
	keySequence_Safari: "CONTROL més OPCIÓ més ${accessKey} a Mac o ALT més ${accessKey} a Windows",
	keySequence_Chrome: "ALT més ${accessKey} a Windows i Linux o CONTROL més OPT més ${accessKey} a Mac",
	shortcutListMessage: "Les dreceres d'aquesta pàgina són:",
	a11yPrologueLabel: "Pròleg d'accessibilitat",
    a11yStatementLabel: "Sentència d'accessibilitat",
    skipToLocationMessage: "Salta a ${description}",
	shortcutKeyMessage_internal: "Per saltar a ${description} utilitzeu ${keySequence}.",
	shortcutKeyMessage_external: "Per enllaçar amb ${description} utilitzeu ${keySequence}.",
	shortcutMessage_internal: "Saltar a ${description}.",
	shortcutMessage_external: "Enllaçar amb ${description}.",

	a11yMainContentAreaName: "contingut principal",

	a11yNavigationAreaName: "navegació",

	a11yBannerAreaName: "bàner"
//end v1.x content
});

