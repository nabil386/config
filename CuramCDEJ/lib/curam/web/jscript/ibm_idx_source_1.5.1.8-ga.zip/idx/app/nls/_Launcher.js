define({root:
//begin v1.x content
({		
    tooManyOpenWorkspaces: "Cannot open more than ${maxOpen} \"${workspaceTypeName}\"\u200e workspaces.  If possible, close \"${workspaceTypeName}\"\u200e workspaces that are already open."
})
//end v1.x content
,
"zh": true,
"zh-tw": true,
"tr": true,
"th": true,
"sv": true,
"sl": true,
"sk": true,
"ru": true,
"ro": true,
"pt": true,
"pt-pt": true,
"pl": true,
"nl": true,
"nb": true,
"ko": true,
"kk": true,
"ja": true, "id": true,
"it": true,
"hu": true,
"fr": true,
"fi": true,
"es": true,
"el": true,
"de": true,
"da": true,
"cs": true,
"ca": true,
"ar": true,
"bg": true,
"he": true,
"hr": true,
"uk": true,"vi":true
});
