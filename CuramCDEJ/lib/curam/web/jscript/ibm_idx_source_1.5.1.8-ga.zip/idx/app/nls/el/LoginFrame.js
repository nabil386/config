define({     
//begin v1.x content
	loginTitle: "Σύνδεση",
	labelUserName: "Όνομα χρήστη",
	labelPassword: "Κωδικός πρόσβασης",
	invalidMessageTitle: "Μη έγκυρη προσπάθεια σύνδεσης",
	invalidMessage: "Δεν καταχωρήθηκε έγκυρη τιμή και στα δύο απαραίτητα πεδία."
//end v1.x content
});

