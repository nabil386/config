define({     
//begin v1.x content
   	altTitle: "Munkaterület lap - ${title}"
//end v1.x content
});

