define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT + ${accessKey}",
	keySequence_Firefox: "ALT + SHIFT + ${accessKey} บน Windows และ Linux หรือ CONTROL + ${accessKey} บน Mac",
	keySequence_Safari: "CONTROL + OPT + ${accessKey} บน Mac หรือ ALT + ${accessKey} บน Windows",
	keySequence_Chrome: "ALT บวก ${accessKey} บน Windows และ Linux หรือ CONTROL บวก OPT บวก ${accessKey} บน Mac",
	shortcutListMessage: "ทางลัดสำหรับหน้านี้คือ:",
	a11yPrologueLabel: "ส่วนนำที่สามารถเข้าถึงได้",
    a11yStatementLabel: "คำสั่งที่สามารถเข้าถึงได้",
    skipToLocationMessage: "ข้ามไปยัง ${description}",
	shortcutKeyMessage_internal: "เมื่อต้องการข้ามไปยัง ${description} ใช้ ${keySequence}",
	shortcutKeyMessage_external: "เมื่อต้องการลิงก์ไปยัง ${description} ใช้ ${keySequence}",
	shortcutMessage_internal: "ข้ามไปยัง ${description}",
	shortcutMessage_external: "ลิงก์ไปยัง${description}",

	a11yMainContentAreaName: "เนื้อหาหลัก",

	a11yNavigationAreaName: "การนำทาง",

	a11yBannerAreaName: "แบนเนอร์"
//end v1.x content
});

