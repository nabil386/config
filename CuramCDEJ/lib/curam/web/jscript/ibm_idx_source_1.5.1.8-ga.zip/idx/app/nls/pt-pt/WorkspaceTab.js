define({     
//begin v1.x content
   	altTitle: "Separador Espaço de Trabalho para ${title}"
//end v1.x content
});

