define({     
//begin v1.x content
    loadingMessage: "正在装入 ${workspaceTitle}。请稍候...",
    failedLoadMessage: "未能装入 ${workspaceTitle}。"
//end v1.x content
});

