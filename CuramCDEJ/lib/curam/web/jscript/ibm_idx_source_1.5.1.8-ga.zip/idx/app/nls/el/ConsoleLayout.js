define({     
//begin v1.x content
	about:				"Πληροφορίες για το προϊόν",
	help:			      "Βοήθεια",
	logout:				"Αποσύνδεση",
	login:				"Σύνδεση",
	userNameMessage:  "Καλωσορίσατε, ${username}"
//end v1.x content
});

