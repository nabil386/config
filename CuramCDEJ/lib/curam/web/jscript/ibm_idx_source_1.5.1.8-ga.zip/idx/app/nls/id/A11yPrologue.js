define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT dan ${accessKey}",
	keySequence_Firefox: "ALT dan SHIFT dan ${accessKey} pada Windows dan Linux atau CONTROL dan ${accessKey} pada Mac",
	keySequence_Safari: "CONTROL dan OPT dan ${accessKey} pada Mac atau ALT dan ${accessKey} pada Windows",
	keySequence_Chrome: "ALT dan ${accessKey} pada Windows dan Linux atau CONTROL dan OPT dan ${accessKey} pada Mac",
	shortcutListMessage: "Pintasan untuk halaman ini adalah:",
	a11yPrologueLabel: "Prolog Aksesibilitas",
    a11yStatementLabel: "Pernyataan Aksesibilitas",
    skipToLocationMessage: "Lompati ke ${description}",
	shortcutKeyMessage_internal: "Untuk melompati ke ${description} gunakan ${keySequence}.",
	shortcutKeyMessage_external: "Untuk menghubungkan ${description} gunakan ${keySequence}.",
	shortcutMessage_internal: "Lompati ke ${description}.",
	shortcutMessage_external: "Hubungkan ke ${description}.",

	a11yMainContentAreaName: "konten utama",

	a11yNavigationAreaName: "navigasi",

	a11yBannerAreaName: "banner"
//end v1.x content
});

