define({     
//begin v1.x content
	about:				"Informacje",
	help:			      "Pomoc",
	logout:				"Wyloguj",
	login:				"Zaloguj się",
	userNameMessage:  "Witaj ${username}"
//end v1.x content
});

