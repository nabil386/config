define({     
//begin v1.x content
	about:				"关于",
	help:			      "帮助",
	logout:				"注销",
	login:				"登录",
	userNameMessage:  "欢迎您，${username}"
//end v1.x content
});

