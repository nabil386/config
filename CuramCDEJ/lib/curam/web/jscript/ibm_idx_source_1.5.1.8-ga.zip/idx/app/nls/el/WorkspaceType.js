define({     
//begin v1.x content
    loadingMessage: "Φόρτωση του χώρου εργασίας ${workspaceTitle}.  Περιμένετε...",
    failedLoadMessage: "Αποτυχία φόρτωσης του χώρου εργασίας ${workspaceTitle}."
//end v1.x content
});

