define({     
//begin v1.x content
	loginTitle: "بدء الاتصال",
	labelUserName: "اسم المستخدم",
	labelPassword: "كلمة السرية",
	invalidMessageTitle: "محاولة بدء اتصال غير صحيحة",
	invalidMessage: "تم ادخال قيمة غير صحيحة بكلا المجالات المطلوبة."
//end v1.x content
});

