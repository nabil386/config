define({     
//begin v1.x content
	about:				"О программе",
	help:			      "Справка",
	logout:				"Выход",
	login:				"Вход в систему",
	userNameMessage:  "Добро пожаловать, ${username}"
//end v1.x content
});

