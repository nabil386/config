define({     
//begin v1.x content
    loadingMessage: "Chargement de ${workspaceTitle}.  Veuillez patienter....",
    failedLoadMessage: "Echec du chargement de l'espace de travail ${workspaceTitle}."
//end v1.x content
});

