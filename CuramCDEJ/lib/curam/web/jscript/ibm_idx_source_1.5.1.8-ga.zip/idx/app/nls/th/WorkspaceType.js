define({     
//begin v1.x content
    loadingMessage: "กำลังโหลด ${workspaceTitle}  โปรดรอสักครู่....",
    failedLoadMessage: "ไม่สามารถโหลด ${workspaceTitle}."
//end v1.x content
});

