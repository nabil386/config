define({     
//begin v1.x content
	loginTitle: "Inici de sessió",
	labelUserName: "Nom d'usuari",
	labelPassword: "Contrasenya",
	invalidMessageTitle: "Intent d'inici de sessió no vàlid",
	invalidMessage: "No s'ha indicat un valor vàlid en cap dels camps necessaris."
//end v1.x content
});

