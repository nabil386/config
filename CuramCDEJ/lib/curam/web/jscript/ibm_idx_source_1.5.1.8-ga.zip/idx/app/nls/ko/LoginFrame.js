define({     
//begin v1.x content
	loginTitle: "로그인",
	labelUserName: "사용자 이름",
	labelPassword: "비밀번호",
	invalidMessageTitle: "올바르지 않은 시도",
	invalidMessage: "두 필수 필드 모두에 올바른 값이 입력되지 않았습니다."
//end v1.x content
});

