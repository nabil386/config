define({     
//begin v1.x content
    loadingMessage: "${workspaceTitle} נטען.  נא להמתין...‏",
    failedLoadMessage: "כשל בטעינת ${workspaceTitle}."
//end v1.x content
});

