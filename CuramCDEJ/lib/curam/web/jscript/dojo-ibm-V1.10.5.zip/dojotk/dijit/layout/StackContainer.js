//>>built
define("dijit/layout/StackContainer",["dojo/_base/array","dojo/cookie","dojo/_base/declare","dojo/dom-class","dojo/dom-construct","dojo/has","dojo/_base/lang","dojo/on","dojo/ready","dojo/topic","dojo/when","../registry","../_WidgetBase","./_LayoutWidget"],function(_1,_2,_3,_4,_5,_6,_7,on,_8,_9,_a,_b,_c,_d){
if(1){
_8(0,function(){
var _e=["dijit/layout/StackController"];
require(_e);
});
}
var _f=_3("dijit.layout.StackContainer",_d,{doLayout:true,persist:false,baseClass:"dijitStackContainer",buildRendering:function(){
this.inherited(arguments);
_4.add(this.domNode,"dijitLayoutContainer");
},postCreate:function(){
this.inherited(arguments);
this.own(on(this.domNode,"keydown",_7.hitch(this,"_onKeyDown")));
},startup:function(){
if(this._started){
return;
}
var _10=this.getChildren();
_1.forEach(_10,this._setupChild,this);
if(this.persist){
this.selectedChildWidget=_b.byId(_2(this.id+"_selectedChild"));
}else{
_1.some(_10,function(_11){
if(_11.selected){
this.selectedChildWidget=_11;
}
return _11.selected;
},this);
}
var _12=this.selectedChildWidget;
if(!_12&&_10[0]){
_12=this.selectedChildWidget=_10[0];
_12.selected=true;
}
_9.publish(this.id+"-startup",{children:_10,selected:_12,textDir:this.textDir});
this.inherited(arguments);
},resize:function(){
if(!this._hasBeenShown){
this._hasBeenShown=true;
var _13=this.selectedChildWidget;
if(_13){
this._showChild(_13);
}
}
this.inherited(arguments);
},_setupChild:function(_14){
var _15=_14.domNode,_16=_5.place("<div role='tabpanel' class='"+this.baseClass+"ChildWrapper dijitHidden'>",_14.domNode,"replace"),_17=_14["aria-label"]||_14.title||_14.label;
var _18=_16.parentElement;
if(_18&&_18.parentElement){
var _19=_18.parentElement.id+"_tablist";
var _1a=dojo.byId(_19);
if(_1a&&_1a.style.height.trim()=="0px"){
_16.removeAttribute("role");
}
}
if(_17){
_16.setAttribute("aria-label",_17);
}
_5.place(_15,_16);
_14._wrapper=_16;
this.inherited(arguments);
if(_15.style.display=="none"){
_15.style.display="block";
}
_14.domNode.removeAttribute("title");
},addChild:function(_1b,_1c){
this.inherited(arguments);
if(this._started){
_9.publish(this.id+"-addChild",_1b,_1c);
this.layout();
if(!this.selectedChildWidget){
this.selectChild(_1b);
}
}
},removeChild:function(_1d){
var idx=_1.indexOf(this.getChildren(),_1d);
this.inherited(arguments);
_5.destroy(_1d._wrapper);
delete _1d._wrapper;
if(this._started){
_9.publish(this.id+"-removeChild",_1d);
}
if(this._descendantsBeingDestroyed){
return;
}
if(this.selectedChildWidget===_1d){
this.selectedChildWidget=undefined;
if(this._started){
var _1e=this.getChildren();
if(_1e.length){
this.selectChild(_1e[Math.max(idx-1,0)]);
}
}
}
if(this._started){
this.layout();
}
},selectChild:function(_1f,_20){
var d;
_1f=_b.byId(_1f);
if(this.selectedChildWidget!=_1f){
d=this._transition(_1f,this.selectedChildWidget,_20);
this._set("selectedChildWidget",_1f);
_9.publish(this.id+"-selectChild",_1f,this._focused);
if(this.persist){
_2(this.id+"_selectedChild",this.selectedChildWidget.id);
}
}else{
if(this._focused&&true==_1f.closable){
_9.publish(this.id+"-selectChild",_1f,this._focused);
}
}
return _a(d||true);
},_transition:function(_21,_22){
if(_22){
this._hideChild(_22);
}
var d=this._showChild(_21);
if(_21.resize){
if(this.doLayout){
_21.resize(this._containerContentBox||this._contentBox);
}else{
_21.resize();
}
}
return d;
},_adjacent:function(_23){
var _24=this.getChildren();
var _25=_1.indexOf(_24,this.selectedChildWidget);
_25+=_23?1:_24.length-1;
return _24[_25%_24.length];
},forward:function(){
return this.selectChild(this._adjacent(true),true);
},back:function(){
return this.selectChild(this._adjacent(false),true);
},_onKeyDown:function(e){
_9.publish(this.id+"-containerKeyDown",{e:e,page:this});
},layout:function(){
var _26=this.selectedChildWidget;
if(_26&&_26.resize){
if(this.doLayout){
_26.resize(this._containerContentBox||this._contentBox);
}else{
_26.resize();
}
}
},_showChild:function(_27){
var _28=this.getChildren();
_27.isFirstChild=(_27==_28[0]);
_27.isLastChild=(_27==_28[_28.length-1]);
_27._set("selected",true);
if(_27._wrapper){
_4.replace(_27._wrapper,"dijitVisible","dijitHidden");
}
return (_27._onShow&&_27._onShow())||true;
},_hideChild:function(_29){
_29._set("selected",false);
if(_29._wrapper){
_4.replace(_29._wrapper,"dijitHidden","dijitVisible");
}
_29.onHide&&_29.onHide();
},closeChild:function(_2a){
var _2b=_2a.onClose&&_2a.onClose(this,_2a);
if(_2b){
this.removeChild(_2a);
_2a.destroyRecursive();
}
},destroyDescendants:function(_2c){
this._descendantsBeingDestroyed=true;
this.selectedChildWidget=undefined;
_1.forEach(this.getChildren(),function(_2d){
if(!_2c){
this.removeChild(_2d);
}
_2d.destroyRecursive(_2c);
},this);
this._descendantsBeingDestroyed=false;
}});
_f.ChildWidgetProperties={selected:false,disabled:false,closable:false,iconClass:"dijitNoIcon",showTitle:true};
_7.extend(_c,_f.ChildWidgetProperties);
return _f;
});
