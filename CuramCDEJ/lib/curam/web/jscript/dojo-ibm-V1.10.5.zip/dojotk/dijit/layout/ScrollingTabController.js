//>>built
require({cache:{"url:dijit/layout/templates/ScrollingTabController.html":"<div class=\"dijitTabListContainer-${tabPosition} tabStrip-disabled dijitLayoutContainer\"><!-- CURAM-FIX: removed style=\"visibility:hidden, dd the tabStrip-disabled class by default.\" -->\n\t<div data-dojo-type=\"dijit.layout._ScrollingTabControllerMenuButton\"\n\t\t class=\"tabStripButton-${tabPosition}\"\n\t\t id=\"${id}_menuBtn\"\n\t\t data-dojo-props=\"containerId: '${containerId}', iconClass: 'dijitTabStripMenuIcon',\n\t\t\t\t\tdropDownPosition: ['below-alt', 'above-alt']\"\n\t\t data-dojo-attach-point=\"_menuBtn\" showLabel=\"false\" title=\"Navigation menu\">&#9660;</div>\n\t<div data-dojo-type=\"dijit.layout._ScrollingTabControllerButton\"\n\t\t class=\"tabStripButton-${tabPosition}\"\n\t\t id=\"${id}_leftBtn\"\n\t\t data-dojo-props=\"iconClass:'dijitTabStripSlideLeftIcon', showLabel:false, title:'Navigation left'\"\n\t\t data-dojo-attach-point=\"_leftBtn\" data-dojo-attach-event=\"onClick: doSlideLeft\">&#9664;</div>\n\t<div data-dojo-type=\"dijit.layout._ScrollingTabControllerButton\"\n\t\t class=\"tabStripButton-${tabPosition}\"\n\t\t id=\"${id}_rightBtn\"\n\t\t data-dojo-props=\"iconClass:'dijitTabStripSlideRightIcon', showLabel:false, title:'Navigation right'\"\n\t\t data-dojo-attach-point=\"_rightBtn\" data-dojo-attach-event=\"onClick: doSlideRight\">&#9654;</div>\n\t<div class='dijitTabListWrapper dijitTabContainerTopNone dijitAlignClient' data-dojo-attach-point='tablistWrapper'>\n\t\t<div role='tablist' data-dojo-attach-event='onkeydown:onkeydown'\n\t\t\t\tdata-dojo-attach-point='containerNode' class='nowrapTabStrip dijitTabContainerTop-tabs'></div>\n\t</div>\n</div>","url:dijit/layout/templates/_ScrollingTabControllerButton.html":"<div data-dojo-attach-event=\"ondijitclick:_onClick\" data-dojo-attach-point=\"focusNode\" role=\"button\">\n  <div role=\"presentation\" class=\"dijitTabInnerDiv\">\n    <div role=\"presentation\" class=\"dijitTabContent dijitButtonContents\">\n\t<span role=\"presentation\" class=\"dijitInline dijitTabStripIcon\" data-dojo-attach-point=\"iconNode\"></span>\n\t<span data-dojo-attach-point=\"containerNode,titleNode\" class=\"dijitButtonText\"></span>\n</div>  </div>\n</div>"}});
define("dijit/layout/ScrollingTabController",["dojo/_base/array","dojo/_base/declare","dojo/dom-class","dojo/dom-geometry","dojo/dom-style","dojo/_base/fx","dojo/_base/lang","dojo/on","dojo/query","dojo/dom-attr","curam/debug","dojo/sniff","../registry","dojo/text!./templates/ScrollingTabController.html","dojo/text!./templates/_ScrollingTabControllerButton.html","./TabController","./utils","../_WidgetsInTemplateMixin","../Menu","../MenuItem","../form/Button","../_HasDropDown","dojo/NodeList-dom","../a11yclick"],function(_1,_2,_3,_4,_5,fx,_6,on,_7,_8,_9,_a,_b,_c,_d,_e,_f,_10,_11,_12,_13,_14){
var _15=_2("dijit.layout.ScrollingTabController",[_e,_10],{baseClass:"dijitTabController dijitScrollingTabController",templateString:_c,useMenu:true,useSlider:true,tabStripClass:"",_minScroll:5,_setClassAttr:{node:"containerNode",type:"class"},_tabsWidth:-1,_tablistMenuItemIdSuffix:"_stcMi",buildRendering:function(){
this.inherited(arguments);
var n=this.domNode;
this.scrollNode=this.tablistWrapper;
this._initButtons();
if(!this.tabStripClass){
this.tabStripClass="dijitTabContainer"+this.tabPosition.charAt(0).toUpperCase()+this.tabPosition.substr(1).replace(/-.*/,"")+"None";
_3.add(n,"tabStrip-disabled");
}
_3.add(this.tablistWrapper,this.tabStripClass);
},onStartup:function(){
this.inherited(arguments);
this._postStartup=true;
this.own(on(this.containerNode,"attrmodified-label, attrmodified-iconclass",_6.hitch(this,function(evt){
if(this._dim){
this.resize(this._dim);
}
this.bustSizeCache=true;
this._tabsWidth=-1;
evt.detail.widget.domNode._width=0;
})));
},onAddChild:function(_16,_17){
this.inherited(arguments);
var _18=_16.id;
this.bustSizeCache=true;
this._tabsWidth=-1;
var _19=function(pid,_1a){
var _1b=null;
if(_1a._menuBtn.dropDown){
var _1c=dojo.query(pid+_1a._tablistMenuItemIdSuffix,_1a._menuBtn.dropDown.domNode)[0];
if(_1c){
_1b=dijit.byNode(_1c);
}
}
return _1b;
};
this.pane2button(_18).connect(this.pane2button(_18),"_setCuramVisibleAttr",_6.hitch(this,function(){
var _1d=_19(_18,this);
if(_1d){
this._setCuramVisibility(_1d,_18);
}
}));
this.pane2button(_18).connect(this.pane2button(_18),"_setCuramDisabledAttr",_6.hitch(this,function(){
var _1e=_19(_18,this);
if(_1e){
this._setCuramAvailability(_1e,_18);
}
}));
_5.set(this.containerNode,"width",(_5.get(this.containerNode,"width")+200)+"px");
this.containerNode._width=0;
},_setCuramVisibility:function(_1f,_20){
var _21=this.pane2button(_20).curamVisible;
if(_21){
dojo.replaceClass(_1f.domNode,"visible","hidden");
}else{
dojo.replaceClass(_1f.domNode,"hidden","visible");
}
},_setCuramAvailability:function(_22,_23){
var _24=!this.pane2button(_23).curamDisabled;
_22.disabled=!_24;
if(_24){
dojo.replaceClass(_22.domNode,"enabled","disabled");
}else{
dojo.replaceClass(_22.domNode,"disabled","enabled");
}
},_getNodeWidth:function(_25){
if(!_25._width){
_25._width=_5.get(_25,"width");
}
return _25._width;
},destroyRendering:function(_26){
_1.forEach(this._attachPoints,function(_27){
delete this[_27];
},this);
this._attachPoints=[];
_1.forEach(this._attachEvents,this.disconnect,this);
this.attachEvents=[];
},destroy:function(){
if(this._menuBtn){
this._menuBtn._curamOwnerController=null;
}
this.inherited(arguments);
},onRemoveChild:function(_28,_29){
var _2a=this.pane2button(_28.id);
if(this._selectedTab===_2a.domNode){
this._selectedTab=null;
}
this.inherited(arguments);
this.bustSizeCache=true;
this._tabsWidth=-1;
},_initButtons:function(){
this.subscribe("tab.title.name.finished",this._measureBtns);
this._btnWidth=0;
this._buttons=_7("> .tabStripButton",this.domNode).filter(function(btn){
if((this.useMenu&&btn==this._menuBtn.domNode)||(this.useSlider&&(btn==this._rightBtn.domNode||btn==this._leftBtn.domNode))){
this._btnWidth+=_4.getMarginBoxSimple(btn).w;
_8.set(this._menuBtn,"title",_9.getProperty("dijit.layout.ScrollingTabController.navMenu.title"));
_8.set(this._menuBtn,"role","presentation");
_8.set(this._menuBtn,"tabindex",0);
return true;
}else{
_5.set(btn,"display","none");
return false;
}
},this);
this._menuBtn._curamOwnerController=this;
},_getTabsWidth:function(){
if(this._tabsWidth>-1){
return this._tabsWidth;
}
var _2b=this.getChildren();
if(_2b.length){
var _2c=_2b[this.isLeftToRight()?_2b.length-1:0].domNode;
var _2d=this._getNodeWidth(_2c);
if(this.isLeftToRight()){
this._tabsWidth=_2c.offsetLeft+_2d;
}else{
var _2e=_2b[_2b.length-1].domNode;
this._tabsWidth=_2c.offsetLeft+_2d-_2e.offsetLeft;
}
return this._tabsWidth;
}else{
return 0;
}
},_enableBtn:function(_2f){
var _30=this._getTabsWidth();
_2f=_2f||_5.get(this.scrollNode,"width");
return _30>0&&_2f<_30;
},_measureBtns:function(){
if(this._enableBtn()&&this._rightBtn.domNode.style.display=="none"){
this.resize(this._dim);
if(this.isLeftToRight()){
this._rightBtn.set("disabled",true);
}else{
this._leftBtn.set("disabled",true);
}
}
},resize:function(dim){
if(dojo.query("> *",this.containerNode).length<1){
if(this.domNode.style.height!="1px"){
_5.set(this.domNode,"height","1px");
}
return;
}
if(!this.bustSizeCache&&this._dim&&dim&&this._dim.w==dim.w){
return;
}
this.bustSizeCache=false;
this.scrollNodeHeight=this.scrollNodeHeight||this.scrollNode.offsetHeight;
this._dim=dim;
this.scrollNode.style.height="auto";
var cb=this._contentBox=_f.marginBox2contentBox(this.domNode,{h:0,w:dim.w});
cb.h=this.scrollNodeHeight;
_4.setContentSize(this.domNode,cb);
var _31=this._enableBtn(this._contentBox.w);
this._buttons.style("display",_31?"":"none");
this._leftBtn.region="left";
this._rightBtn.region="right";
this._menuBtn.region=this.isLeftToRight()?"right":"left";
_8.set(this._leftBtn,"title",_9.getProperty("dijit.layout.ScrollingTabController.navLeft.title"));
_8.set(this._rightBtn,"title",_9.getProperty("dijit.layout.ScrollingTabController.navRight.title"));
_8.set(this._rightBtn,"role","presentation");
_8.set(this._leftBtn,"role","presentation");
var _32;
if(_31){
_32=dijit.layout.utils.layoutChildren(this.domNode,this._contentBox,[this._menuBtn,this._leftBtn,this._rightBtn,{domNode:this.scrollNode,layoutAlign:"client",fakeWidget:true}]);
}else{
_32=dijit.layout.utils.layoutChildren(this.domNode,this._contentBox,[{domNode:this.scrollNode,layoutAlign:"client",fakeWidget:true}]);
}
this.scrollNode._width=_32.client.w;
if(this._selectedTab){
if(this._anim&&this._anim.status()=="playing"){
this._anim.stop();
}
this.scrollNode.scrollLeft=this._convertToScrollLeft(this._getScrollForSelectedTab());
}
this._setButtonClass(this._getScroll());
this._postResize=true;
return {h:this._contentBox.h,w:dim.w};
},_getScroll:function(){
return (this.isLeftToRight()||_a("ie")<8||(_a("trident")&&_a("quirks"))||_a("webkit"))?this.scrollNode.scrollLeft:_5.get(this.containerNode,"width")-_5.get(this.scrollNode,"width")+(_a("trident")||_a("edge")?-1:1)*this.scrollNode.scrollLeft;
},_convertToScrollLeft:function(val){
if(this.isLeftToRight()||_a("ie")<8||(_a("trident")&&_a("quirks"))||_a("webkit")){
return val;
}else{
var _33=_5.get(this.containerNode,"width")-_5.get(this.scrollNode,"width");
return (_a("trident")||_a("edge")?-1:1)*(val-_33);
}
},onSelectChild:function(_34,_35){
var tab=this.pane2button(_34.id);
if(!tab){
return;
}
var _36=tab.domNode;
if(_36!=this._selectedTab){
this._selectedTab=_36;
if(this._postResize){
var _37=this._getNodeWidth(this.scrollNode);
if(this._getTabsWidth()<_37){
tab.onClick(null);
tab.focus();
}else{
var sl=this._getScroll();
if(sl>_36.offsetLeft||sl+_37<_36.offsetLeft+this._getNodeWidth(_36)){
var _38=this.createSmoothScroll();
if(_35){
_38.onEnd=function(){
tab.focus();
};
}
_38.play();
}else{
if(_35){
tab.focus();
}
}
}
}
}
this.inherited(arguments);
var _39=document.activeElement;
if(typeof _39!=="undefined"&&_39!=null){
if(_39.className=="tabLabel"&&(_7(_39).closest(".nav-panel")).length>0){
curam.util.setTabButtonClicked(_39);
}
}
},_getScrollBounds:function(){
var _3a=this.getChildren(),_3b=this._getNodeWidth(this.scrollNode),_3c=this._getNodeWidth(this.containerNode),_3d=_3c-_3b,_3e=this._getTabsWidth();
if(_3a.length&&_3e>_3b){
return {min:this.isLeftToRight()?0:_3a[_3a.length-1].domNode.offsetLeft,max:this.isLeftToRight()?_3e-_3b:_3d};
}else{
var _3f=this.isLeftToRight()?0:_3d;
return {min:_3f,max:_3f};
}
},_getScrollForSelectedTab:function(){
var w=this.scrollNode,n=this._selectedTab,_40=_5.get(this.scrollNode,"width"),_41=this._getScrollBounds();
var pos=(n.offsetLeft+_5.get(n,"width")/2)-_40/2;
pos=Math.min(Math.max(pos,_41.min),_41.max);
return pos;
},createSmoothScroll:function(x){
if(arguments.length>0){
var _42=this._getScrollBounds();
x=Math.min(Math.max(x,_42.min),_42.max);
}else{
x=this._getScrollForSelectedTab();
}
if(this._anim&&this._anim.status()=="playing"){
this._anim.stop();
}
var _43=this,w=this.scrollNode,_44=new fx.Animation({beforeBegin:function(){
if(this.curve){
delete this.curve;
}
var _45=w.scrollLeft,_46=_43._convertToScrollLeft(x);
_44.curve=new fx._Line(_45,_46);
},onAnimate:function(val){
w.scrollLeft=val;
}});
this._anim=_44;
this._setButtonClass(x);
return _44;
},_getBtnNode:function(e){
var n=e.target;
while(n&&!_3.contains(n,"tabStripButton")){
n=n.parentNode;
}
return n;
},doSlideRight:function(e){
this.doSlide(1,this._getBtnNode(e));
},doSlideLeft:function(e){
this.doSlide(-1,this._getBtnNode(e));
},doSlide:function(_47,_48){
if(_48&&_3.contains(_48,"dijitTabDisabled")){
return;
}
var _49=_5.get(this.scrollNode,"width");
var d=(_49*0.75)*_47;
var to=this._getScroll()+d;
this._setButtonClass(to);
this.createSmoothScroll(to).play();
},_setButtonClass:function(_4a){
var _4b=this._getScrollBounds();
this._leftBtn.set("disabled",_4a<=_4b.min);
this._rightBtn.set("disabled",_4a>=_4b.max);
}});
var _4c=_2("dijit.layout._ScrollingTabControllerButtonMixin",null,{baseClass:"dijitTab tabStripButton",templateString:_d,tabIndex:"",isFocusable:function(){
return false;
}});
_2("dijit.layout._ScrollingTabControllerButton",[_13,_4c]);
_2("dijit.layout._ScrollingTabControllerMenuButton",[_13,_14,_4c],{containerId:"",tabIndex:"-1",isLoaded:function(){
return false;
},loadDropDown:function(_4d){
this.dropDown=new _11({id:this.containerId+"_menu",ownerDocument:this.ownerDocument,dir:this.dir,lang:this.lang,textDir:this.textDir});
var _4e=_b.byId(this.containerId);
_1.forEach(_4e.getChildren(),function(_4f){
var _50=new _12({id:_4f.id+"_stcMi",label:_4f.title,iconClass:_4f.iconClass,disabled:_4f.disabled,ownerDocument:this.ownerDocument,dir:_4f.dir,lang:_4f.lang,textDir:_4f.textDir||_4e.textDir,onClick:function(){
_4e.selectChild(_4f);
}});
this.dropDown.addChild(_50);
},this);
dojo.forEach(this.dropDown.getChildren(),_6.hitch(this,function(_51){
var _52=_51.id.split(this._curamOwnerController._tablistMenuItemIdSuffix)[0];
this._curamOwnerController._setCuramAvailability(_51,_52);
this._curamOwnerController._setCuramVisibility(_51,_52);
dojo.connect(_51,"destroy",function(){
setDynState=null;
});
}));
_4d();
},closeDropDown:function(_53){
this.inherited(arguments);
if(this.dropDown){
this._popupStateNode.removeAttribute("aria-owns");
this.dropDown.destroyRecursive();
delete this.dropDown;
}
}});
return _15;
});
