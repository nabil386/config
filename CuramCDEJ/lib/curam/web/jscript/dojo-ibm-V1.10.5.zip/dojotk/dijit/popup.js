//>>built
define("dijit/popup",["dojo/_base/array","dojo/aspect","dojo/_base/declare","dojo/dom","dojo/dom-attr","dojo/dom-class","dojo/dom-construct","dojo/dom-geometry","dojo/dom-style","dojo/has","dojo/keys","dojo/_base/lang","dojo/on","./place","./BackgroundIframe","./Viewport","./main","dojo/touch"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,_c,on,_d,_e,_f,_10){
function _11(){
if(this._popupWrapper){
_7.destroy(this._popupWrapper);
delete this._popupWrapper;
}
};
var _12=_3(null,{_stack:[],_beginZIndex:1000,_idGen:1,_repositionAll:function(){
if(this._firstAroundNode){
var _13=this._firstAroundPosition,_14=_8.position(this._firstAroundNode,true),dx=_14.x-_13.x,dy=_14.y-_13.y;
if(dx||dy){
this._firstAroundPosition=_14;
for(var i=0;i<this._stack.length;i++){
var _15=this._stack[i].wrapper.style;
_15.top=(parseFloat(_15.top)+dy)+"px";
if(_15.right=="auto"){
_15.left=(parseFloat(_15.left)+dx)+"px";
}else{
_15.right=(parseFloat(_15.right)-dx)+"px";
}
}
}
this._aroundMoveListener=setTimeout(_c.hitch(this,"_repositionAll"),dx||dy?10:50);
}
},_createWrapper:function(_16){
var _17=_16._popupWrapper,_18=_16.domNode;
if(!_17){
_17=_7.create("div",{"class":"dijitPopup",style:{display:"none"},role:"region","aria-label":_16["aria-label"]||_16.label||_16.name||_16.id},_16.ownerDocumentBody);
_17.appendChild(_18);
var s=_18.style;
s.display="";
s.visibility="";
s.position="";
s.top="0px";
_16._popupWrapper=_17;
_2.after(_16,"destroy",_11,true);
if("ontouchend" in document){
on(_17,"touchend",function(evt){
if(!/^(input|button|textarea)$/i.test(evt.target.tagName)){
evt.preventDefault();
}
});
}
_17.dojoClick=true;
}
return _17;
},moveOffScreen:function(_19){
var _1a=this._createWrapper(_19);
var ltr=_8.isBodyLtr(_19.ownerDocument),_1b={visibility:"hidden",top:"-9999px",display:""};
_1b[ltr?"left":"right"]="-9999px";
_1b[ltr?"right":"left"]="auto";
_9.set(_1a,_1b);
return _1a;
},hide:function(_1c){
var _1d=this._createWrapper(_1c);
if(dojo.hasClass(_1d,"dijitMenuPopup")&&(_a("trident")||_a("edge")||_a("ie"))){
_5.set(_1d,"aria-hidden","true");
_9.set(_1d,{position:"absolute",overflow:"hidden",clip:"rect(0 0 0 0)",height:"1px",width:"1px",margin:"-1px",padding:"0",border:"0"});
setTimeout(function(){
if(_5.get(_1d,"aria-hidden","true")){
_9.set(_1d,{display:"none",height:"auto",overflowY:"visible",border:"",position:"",overflow:"",clip:"",width:"",margin:"",padding:""});
}
},200,_1d);
}else{
_9.set(_1d,{display:"none",height:"auto",overflowY:"visible",border:""});
}
var _1e=_1c.domNode;
if("_originalStyle" in _1e){
_1e.style.cssText=_1e._originalStyle;
}
},getTopPopup:function(){
var _1f=this._stack;
for(var pi=_1f.length-1;pi>0&&_1f[pi].parent===_1f[pi-1].widget;pi--){
}
return _1f[pi];
},open:function(_20){
var _21=this._stack,_22=_20.popup,_23=_22.domNode,_24=_20.orient||["below","below-alt","above","above-alt"],ltr=_20.parent?_20.parent.isLeftToRight():_8.isBodyLtr(_22.ownerDocument),_25=_20.around,id=(_20.around&&_20.around.id)?(_20.around.id+"_dropdown"):("popup_"+this._idGen++);
while(_21.length&&(!_20.parent||!_4.isDescendant(_20.parent.domNode,_21[_21.length-1].widget.domNode))){
this.close(_21[_21.length-1].widget);
}
var _26=this.moveOffScreen(_22);
if(_22.startup&&!_22._started){
_22.startup();
}
var _27,_28=_8.position(_23);
if("maxHeight" in _20&&_20.maxHeight!=-1){
_27=_20.maxHeight||Infinity;
}else{
var _29=_f.getEffectiveBox(this.ownerDocument),_2a=_25?_8.position(_25,false):{y:_20.y-(_20.padding||0),h:(_20.padding||0)*2};
_27=Math.floor(Math.max(_2a.y,_29.h-(_2a.y+_2a.h)));
}
if(_28.h>_27){
var cs=_9.getComputedStyle(_23),_2b=cs.borderLeftWidth+" "+cs.borderLeftStyle+" "+cs.borderLeftColor;
_9.set(_26,{overflowY:"scroll",height:(_27-2)+"px",border:_2b});
_23._originalStyle=_23.style.cssText;
_23.style.border="none";
}
_5.set(_26,{id:id,style:{zIndex:this._beginZIndex+_21.length},"class":"dijitPopup "+(_22.baseClass||_22["class"]||"").split(" ")[0]+"Popup",dijitPopupParent:_20.parent?_20.parent.id:""});
if(dojo.hasClass(_26,"dijitMenuPopup")&&(_a("trident")||_a("edge")||_a("ie"))){
if(_5.get(_26,"aria-hidden")==="true"){
_9.set(_26,{position:"",clip:"",width:"",margin:"",padding:"",border:""});
}
_5.set(_26,"aria-hidden","false");
}
if(_21.length==0&&_25){
this._firstAroundNode=_25;
this._firstAroundPosition=_8.position(_25,true);
this._aroundMoveListener=setTimeout(_c.hitch(this,"_repositionAll"),50);
}
if(_a("config-bgIframe")&&!_22.bgIframe){
_22.bgIframe=new _e(_26);
}
var _2c=_22.orient?_c.hitch(_22,"orient"):null,_2d=_25?_d.around(_26,_25,_24,ltr,_2c):_d.at(_26,_20,_24=="R"?["TR","BR","TL","BL"]:["TL","BL","TR","BR"],_20.padding,_2c);
_26.style.visibility="visible";
_23.style.visibility="visible";
var _2e=[];
_2e.push(on(_26,"keydown",_c.hitch(this,function(evt){
if(evt.keyCode==_b.ESCAPE&&_20.onCancel){
evt.stopPropagation();
evt.preventDefault();
_20.onCancel(evt);
}else{
if(evt.keyCode==_b.TAB){
evt.stopPropagation();
evt.preventDefault();
var _2f=this.getTopPopup();
if(_2f&&_2f.onCancel){
_2f.onCancel(evt);
}
}
}
})));
if(_22.onCancel&&_20.onCancel){
_2e.push(_22.on("cancel",_20.onCancel));
}
_2e.push(_22.on(_22.onExecute?"execute":"change",_c.hitch(this,function(){
var _30=this.getTopPopup();
if(_30&&_30.onExecute){
_30.onExecute();
}
})));
_21.push({widget:_22,wrapper:_26,parent:_20.parent,onExecute:_20.onExecute,onCancel:_20.onCancel,onClose:_20.onClose,handlers:_2e});
if(_22.onOpen){
_22.onOpen(_2d);
}
return _2d;
},close:function(_31){
var _32=this._stack;
while((_31&&_1.some(_32,function(_33){
return _33.widget==_31;
}))||(!_31&&_32.length)){
var top=_32.pop(),_34=top.widget,_35=top.onClose;
if(_34.bgIframe){
_34.bgIframe.destroy();
delete _34.bgIframe;
}
if(_34.onClose){
_34.onClose();
}
var h;
while(h=top.handlers.pop()){
h.remove();
}
if(_34&&_34.domNode){
this.hide(_34);
}
if(_35){
_35();
}
}
if(_32.length==0&&this._aroundMoveListener){
clearTimeout(this._aroundMoveListener);
this._firstAroundNode=this._firstAroundPosition=this._aroundMoveListener=null;
}
}});
return (_10.popup=new _12());
});
