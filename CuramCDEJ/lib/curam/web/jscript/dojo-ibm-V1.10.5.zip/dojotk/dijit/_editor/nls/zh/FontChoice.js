//>>built
define("dijit/_editor/nls/zh/FontChoice",({fontSize:"大小",fontName:"字体",formatBlock:"格式",serif:"有衬线","sans-serif":"无衬线",monospace:"等宽字体",cursive:"草书",fantasy:"虚线",noFormat:"无",p:"段落",h1:"标题",h2:"副标题",h3:"二级子标题",pre:"预设有格式的",1:"XX 小号",2:"X 小号",3:"小号",4:"中号",5:"大号",6:"X 大号",7:"XX 大号"}));
