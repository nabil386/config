//>>built
require({cache:{"url:dijit/layout/templates/_TabButton.html":"<div role=\"presentation\" data-dojo-attach-point=\"titleNode,innerDiv,tabContent\" class=\"dijitTabInner dijitTabContent\">\n\t<span role=\"presentation\" class=\"dijitInline dijitIcon dijitTabButtonIcon\" data-dojo-attach-point=\"iconNode\"></span>\n\t<span data-dojo-attach-point='containerNode,focusNode' class='tabLabel'></span>\n\t<span class=\"dijitInline dijitTabCloseButton dijitTabCloseIcon\" data-dojo-attach-point='closeNode'\n\t\t  role=\"presentation\">\n\t\t<span data-dojo-attach-point='closeText' class='dijitTabCloseText'>[x]</span\n\t\t\t\t></span>\n</div>\n"}});
define("dijit/layout/TabController",["dojo/_base/declare","dojo/dom","dojo/dom-attr","dojo/dom-class","dojo/has","dojo/i18n","dojo/_base/lang","./StackController","../registry","../Menu","../MenuItem","curam/inspection/Layer","dojo/text!./templates/_TabButton.html","curam/widget/_TabButton","curam/widget/MenuItem","dojo/i18n!../nls/common"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,lm,_c,_d,_e){
var _f=_d;
if(_5("dojo-bidi")){
_f=_1("dijit.layout._TabButton",_f,{_setLabelAttr:function(_10){
this.inherited(arguments);
this.applyTextDir(this.iconNode,this.iconNode.alt);
}});
}
var _11=_1("dijit.layout.TabController",_8,{baseClass:"dijitTabController",templateString:"<div role='tablist' data-dojo-attach-event='onkeydown:onkeydown'></div>",tabPosition:"top",buttonWidget:_f,startup:function(){
this.inherited(arguments);
this.connect(this,"onAddChild",function(_12,_13){
var _14=this;
_12.controlButton._curamPageId=_12.id;
_12.controlButton.connect(_12.controlButton,"_setCuramVisibleAttr",function(){
if(_12.controlButton.curamVisible){
var _15=dojo.map(_14.getChildren(),function(btn){
return btn._curamPageId;
});
var _16=curam.tab.getTabWidgetId(curam.tab.getContainerTab(_12.domNode));
var _17=curam.util.TabNavigation.getInsertIndex(_16,_15,_12.id);
var _18=false;
if(curam.util.getTopmostWindow().curam.util.tabButtonClicked&&(document.activeElement===curam.util.getTopmostWindow().curam.util.tabButtonClicked)){
_18=true;
}
_14.addChild(_12.controlButton,_17);
if(_18&&(document.activeElement!==curam.util.getTopmostWindow().curam.util.tabButtonClicked)){
curam.util.getTopmostWindow().curam.util.tabButtonClicked.focus();
}
}else{
var _19=_12.controlButton;
if(dojo.indexOf(_14.getChildren(),_19)!=-1){
_14.removeChild(_19);
}
}
});
});
},buttonWidgetCloseClass:"dijitTabCloseButton",postCreate:function(){
this.inherited(arguments);
lm.register("dijit/layout/TabController",this);
var _1a=new _a({id:this.id+"_Menu",ownerDocument:this.ownerDocument,dir:this.dir,lang:this.lang,textDir:this.textDir,targetNodeIds:[this.domNode],selector:function(_1b){
return _4.contains(_1b,"dijitClosable")&&!_4.contains(_1b,"dijitTabDisabled");
}});
this.own(_1a);
var _1c=_6.getLocalization("dijit","common"),_1d=this;
_1a.addChild(new _b({label:_1c.itemClose,ownerDocument:this.ownerDocument,dir:this.dir,lang:this.lang,textDir:this.textDir,onClick:function(evt){
var _1e=_9.byNode(this.getParent().currentTarget);
_1d.onCloseButtonClick(_1e.page);
}}));
var _1f=_6.getLocalization("curam.application","TabMenu"),_20=new _e({onClickValue:"_onClickAll",label:_1f["close.all.tabs.text"],dir:this.dir,lang:this.lang,textDir:this.textDir,onClick:function(evt){
this._onClickAll();
}});
_1a.addChild(_20);
},onButtonClick:function(_21){
if(!_21.controlButton.get("curamDisabled")){
var _22=dijit.byId(this.containerId);
_22.selectChild(_21);
}
}});
_11.TabButton=_f;
return _11;
});
