//>>built
define("dijit/form/nls/sr/validate",{invalidMessage:"Uneta vrednost nije važeća.",missingMessage:"Ova vrednost je potrebna.",rangeMessage:"Ova vrednost je van opsega."});
