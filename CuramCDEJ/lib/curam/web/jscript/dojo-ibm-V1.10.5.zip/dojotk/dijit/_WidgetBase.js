//>>built
define("dijit/_WidgetBase",["require","dojo/_base/array","dojo/aspect","dojo/_base/config","dojo/_base/connect","dojo/_base/declare","dojo/dom","dojo/dom-attr","dojo/dom-class","dojo/dom-construct","dojo/dom-geometry","dojo/dom-style","dojo/has","dojo/_base/kernel","dojo/_base/lang","dojo/on","dojo/ready","dojo/Stateful","dojo/topic","dojo/_base/window","./Destroyable","dojo/has!dojo-bidi?./_BidiMixin","./registry"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,_c,_d,_e,_f,on,_10,_11,_12,win,_13,_14,_15){
var _16=typeof (dojo.global.perf)!="undefined";
1||_d.add("dijit-legacy-requires",!_e.isAsync);
_d.add("dojo-bidi",false);
if(1){
_10(0,function(){
var _17=["dijit/_base/manager"];
_1(_17);
});
}
var _18={};
function _19(obj){
var ret={};
for(var _1a in obj){
ret[_1a.toLowerCase()]=true;
}
return ret;
};
function _1b(_1c){
return function(val){
_8[val?"set":"remove"](this.domNode,_1c,val);
this._set(_1c,val);
};
};
function _1d(a,b){
return a===b||(a!==a&&b!==b);
};
var _1e=_6("dijit._WidgetBase",[_11,_13],{id:"",_setIdAttr:"domNode",lang:"",_setLangAttr:_1b("lang"),dir:"",_setDirAttr:_1b("dir"),"class":"",_setClassAttr:{node:"domNode",type:"class"},_setTypeAttr:null,style:"",title:"",tooltip:"",baseClass:"",srcNodeRef:null,domNode:null,containerNode:null,ownerDocument:null,_setOwnerDocumentAttr:function(val){
this._set("ownerDocument",val);
},attributeMap:{},_blankGif:_4.blankGif||_1.toUrl("dojo/resources/blank.gif"),_introspect:function(){
var _1f=this.constructor;
if(!_1f._setterAttrs){
var _20=_1f.prototype,_21=_1f._setterAttrs=[],_22=(_1f._onMap={});
for(var _23 in _20.attributeMap){
_21.push(_23);
}
for(_23 in _20){
if(/^on/.test(_23)){
_22[_23.substring(2).toLowerCase()]=_23;
}
if(/^_set[A-Z](.*)Attr$/.test(_23)){
_23=_23.charAt(4).toLowerCase()+_23.substr(5,_23.length-9);
if(!_20.attributeMap||!(_23 in _20.attributeMap)){
_21.push(_23);
}
}
}
}
},postscript:function(_24,_25){
this.create(_24,_25);
},create:function(_26,_27){
if(_16){
perf.widgetStartedLoadingCallback();
}
this._introspect();
this.srcNodeRef=_7.byId(_27);
this._connects=[];
this._supportingWidgets=[];
if(this.srcNodeRef&&(typeof this.srcNodeRef.id=="string")){
this.id=this.srcNodeRef.id;
}
if(_26){
this.params=_26;
_f.mixin(this,_26);
}
this.postMixInProperties();
if(!this.id){
this.id=_15.getUniqueId(this.declaredClass.replace(/\./g,"_"));
if(this.params){
delete this.params.id;
}
}
this.ownerDocument=this.ownerDocument||(this.srcNodeRef?this.srcNodeRef.ownerDocument:document);
this.ownerDocumentBody=win.body(this.ownerDocument);
_15.add(this);
this.buildRendering();
var _28;
if(this.domNode){
this._applyAttributes();
var _29=this.srcNodeRef;
if(_29&&_29.parentNode&&this.domNode!==_29){
_29.parentNode.replaceChild(this.domNode,_29);
_28=true;
}
this.domNode.setAttribute("widgetId",this.id);
}
this.postCreate();
if(_28){
delete this.srcNodeRef;
}
this._created=true;
if(_16){
perf.widgetLoadedCallback(this);
}
},_applyAttributes:function(){
var _2a={};
for(var key in this.params||{}){
_2a[key]=this._get(key);
}
_2.forEach(this.constructor._setterAttrs,function(key){
if(!(key in _2a)){
var val=this._get(key);
if(val){
this.set(key,val);
}
}
},this);
for(key in _2a){
this.set(key,_2a[key]);
}
},postMixInProperties:function(){
},buildRendering:function(){
if(!this.domNode){
this.domNode=this.srcNodeRef||this.ownerDocument.createElement("div");
}
if(this.baseClass){
var _2b=this.baseClass.split(" ");
if(!this.isLeftToRight()){
_2b=_2b.concat(_2.map(_2b,function(_2c){
return _2c+"Rtl";
}));
}
_9.add(this.domNode,_2b);
}
},postCreate:function(){
},startup:function(){
if(this._started){
return;
}
this._started=true;
_2.forEach(this.getChildren(),function(obj){
if(!obj._started&&!obj._destroyed&&_f.isFunction(obj.startup)){
obj.startup();
obj._started=true;
}
});
},destroyRecursive:function(_2d){
this._beingDestroyed=true;
this.destroyDescendants(_2d);
this.destroy(_2d);
},destroy:function(_2e){
this._beingDestroyed=true;
this.uninitialize();
function _2f(w){
if(w.destroyRecursive){
w.destroyRecursive(_2e);
}else{
if(w.destroy){
w.destroy(_2e);
}
}
};
_2.forEach(this._connects,_f.hitch(this,"disconnect"));
_2.forEach(this._supportingWidgets,_2f);
if(this.domNode){
_2.forEach(_15.findWidgets(this.domNode,this.containerNode),_2f);
}
this.destroyRendering(_2e);
_15.remove(this.id);
this._destroyed=true;
},destroyRendering:function(_30){
if(this.bgIframe){
this.bgIframe.destroy(_30);
delete this.bgIframe;
}
if(this.domNode){
if(_30){
_8.remove(this.domNode,"widgetId");
}else{
_a.destroy(this.domNode);
}
delete this.domNode;
}
if(this.srcNodeRef){
if(!_30){
_a.destroy(this.srcNodeRef);
}
delete this.srcNodeRef;
}
},destroyDescendants:function(_31){
_2.forEach(this.getChildren(),function(_32){
if(_32.destroyRecursive){
_32.destroyRecursive(_31);
}
});
},uninitialize:function(){
return false;
},_setStyleAttr:function(_33){
var _34=this.domNode;
if(_f.isObject(_33)){
_c.set(_34,_33);
}else{
if(_34.style.cssText){
_34.style.cssText+="; "+_33;
}else{
_34.style.cssText=_33;
}
}
this._set("style",_33);
},_attrToDom:function(_35,_36,_37){
_37=arguments.length>=3?_37:this.attributeMap[_35];
_2.forEach(_f.isArray(_37)?_37:[_37],function(_38){
var _39=this[_38.node||_38||"domNode"];
var _3a=_38.type||"attribute";
switch(_3a){
case "attribute":
if(_f.isFunction(_36)){
_36=_f.hitch(this,_36);
}
var _3b=_38.attribute?_38.attribute:(/^on[A-Z][a-zA-Z]*$/.test(_35)?_35.toLowerCase():_35);
if(_39.tagName){
_8.set(_39,_3b,_36);
}else{
_39.set(_3b,_36);
}
break;
case "innerText":
_39.innerHTML="";
_39.appendChild(this.ownerDocument.createTextNode(_36));
break;
case "innerHTML":
_39.innerHTML=_36;
break;
case "class":
_9.replace(_39,_36,this[_35]);
break;
}
},this);
},get:function(_3c){
var _3d=this._getAttrNames(_3c);
return this[_3d.g]?this[_3d.g]():this._get(_3c);
},set:function(_3e,_3f){
if(typeof _3e==="object"){
for(var x in _3e){
this.set(x,_3e[x]);
}
return this;
}
var _40=this._getAttrNames(_3e),_41=this[_40.s];
if(_f.isFunction(_41)){
var _42=_41.apply(this,Array.prototype.slice.call(arguments,1));
}else{
var _43=this.focusNode&&!_f.isFunction(this.focusNode)?"focusNode":"domNode",tag=this[_43]&&this[_43].tagName,_44=tag&&(_18[tag]||(_18[tag]=_19(this[_43]))),map=_3e in this.attributeMap?this.attributeMap[_3e]:_40.s in this?this[_40.s]:((_44&&_40.l in _44&&typeof _3f!="function")||/^aria-|^data-|^role$/.test(_3e))?_43:null;
if(map!=null){
this._attrToDom(_3e,_3f,map);
}
this._set(_3e,_3f);
}
return _42||this;
},_attrPairNames:{},_getAttrNames:function(_45){
var apn=this._attrPairNames;
if(apn[_45]){
return apn[_45];
}
var uc=_45.replace(/^[a-z]|-[a-zA-Z]/g,function(c){
return c.charAt(c.length-1).toUpperCase();
});
return (apn[_45]={n:_45+"Node",s:"_set"+uc+"Attr",g:"_get"+uc+"Attr",l:uc.toLowerCase()});
},_set:function(_46,_47){
var _48=this[_46];
this[_46]=_47;
if(this._created&&!_1d(_48,_47)){
if(this._watchCallbacks){
this._watchCallbacks(_46,_48,_47);
}
this.emit("attrmodified-"+_46,{detail:{prevValue:_48,newValue:_47}});
}
},_get:function(_49){
return this[_49];
},emit:function(_4a,_4b,_4c){
_4b=_4b||{};
if(_4b.bubbles===undefined){
_4b.bubbles=true;
}
if(_4b.cancelable===undefined){
_4b.cancelable=true;
}
if(!_4b.detail){
_4b.detail={};
}
_4b.detail.widget=this;
var ret,_4d=this["on"+_4a];
if(_4d){
ret=_4d.apply(this,_4c?_4c:[_4b]);
}
if(this._started&&!this._beingDestroyed){
on.emit(this.domNode,_4a.toLowerCase(),_4b);
}
return ret;
},on:function(_4e,_4f){
var _50=this._onMap(_4e);
if(_50){
return _3.after(this,_50,_4f,true);
}
return this.own(on(this.domNode,_4e,_4f))[0];
},_onMap:function(_51){
var _52=this.constructor,map=_52._onMap;
if(!map){
map=(_52._onMap={});
for(var _53 in _52.prototype){
if(/^on/.test(_53)){
map[_53.replace(/^on/,"").toLowerCase()]=_53;
}
}
}
return map[typeof _51=="string"&&_51.toLowerCase()];
},toString:function(){
return "[Widget "+this.declaredClass+", "+(this.id||"NO ID")+"]";
},getChildren:function(){
return this.containerNode?_15.findWidgets(this.containerNode):[];
},getParent:function(){
return _15.getEnclosingWidget(this.domNode.parentNode);
},connect:function(obj,_54,_55){
return this.own(_5.connect(obj,_54,this,_55))[0];
},disconnect:function(_56){
_56.remove();
},subscribe:function(t,_57){
return this.own(_12.subscribe(t,_f.hitch(this,_57)))[0];
},unsubscribe:function(_58){
_58.remove();
},isLeftToRight:function(){
return this.dir?(this.dir.toLowerCase()=="ltr"):_b.isBodyLtr(this.ownerDocument);
},isFocusable:function(){
return this.focus&&(_c.get(this.domNode,"display")!="none");
},placeAt:function(_59,_5a){
var _5b=!_59.tagName&&_15.byId(_59);
if(_5b&&_5b.addChild&&(!_5a||typeof _5a==="number")){
_5b.addChild(this,_5a);
}else{
var ref=_5b&&("domNode" in _5b)?(_5b.containerNode&&!/after|before|replace/.test(_5a||"")?_5b.containerNode:_5b.domNode):_7.byId(_59,this.ownerDocument);
_a.place(this.domNode,ref,_5a);
if(!this._started&&(this.getParent()||{})._started){
this.startup();
}
}
return this;
},defer:function(fcn,_5c){
var _5d=setTimeout(_f.hitch(this,function(){
if(!_5d){
return;
}
_5d=null;
if(!this._destroyed){
_f.hitch(this,fcn)();
}
}),_5c||0);
return {remove:function(){
if(_5d){
clearTimeout(_5d);
_5d=null;
}
return null;
}};
}});
if(_d("dojo-bidi")){
_1e.extend(_14);
}
return _1e;
});
