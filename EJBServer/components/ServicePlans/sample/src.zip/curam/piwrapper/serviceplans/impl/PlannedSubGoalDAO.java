/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.ReaderDAO;
import java.util.List;


/**
 * Read only data access for the
 * {@link curam.serviceplans.sl.entity.intf.PlannedSubGoal} entity.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(PlannedSubGoalDAOImpl.class)
public interface PlannedSubGoalDAO extends ReaderDAO<Long, PlannedSubGoal> {

  // END, CR00309529

  /**
   * Retrieves an immutable list of active planned sub goals for a given planned
   * goal.
   *
   * @param plannedGoal
   * The planned goal to list the planned sub goals for.
   * @return An immutable list of active planned sub goals, or an empty list if
   * none are found.
   */
  List<PlannedSubGoal> listActiveByPlannedGoal(PlannedGoal plannedGoal);
}
