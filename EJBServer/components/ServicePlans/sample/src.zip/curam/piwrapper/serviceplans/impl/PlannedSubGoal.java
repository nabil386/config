/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.OUTCOMEACHIEVEDEntry;
import curam.codetable.impl.PLANNEDSUBGOALSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.piwrapper.user.impl.User;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;


/**
 * Read only wrapper interface to the
 * {@link curam.serviceplans.sl.entity.intf.PlannedSubGoal} entity.
 */
@ImplementedBy(PlannedSubGoalImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface PlannedSubGoal extends StandardEntity {

  /**
   * Retrieves the record status value for the record.
   *
   * @return The record status code table entry value.
   */
  RECORDSTATUSEntry getRecordStatus();

  /**
   * Retrieves the {@link SubGoal} admin configuration details that this planned
   * sub goal is related to.
   *
   * @return The sub goal details.
   */
  SubGoal getSubGoal();

  /**
   * Retrieves the {@link PlannedGoal} details that this planned sub goal hangs
   * off.
   *
   * @return The planned goal that the planned sub goal is related to.
   */
  PlannedGoal getPlannedGoal();

  /**
   * Retrieves the outcome achieved code table entry value for this record.
   *
   * @return The outcome achieved code table entry value.
   */
  OUTCOMEACHIEVEDEntry getOutcomeAchieved();

  /**
   * Retrieves the owner of the planned sub-goal.
   *
   * @return The planned sub goal owner.
   */
  User getOwner();

  /**
   * Retrieves the current {@link PLANNEDSUBGOALSTATUSEntry status} value for
   * the record.
   *
   * @return The current status value of the record.
   */
  PLANNEDSUBGOALSTATUSEntry getStatus();

  /**
   * Retrieves the {@link SENSITIVITYEntry sensitivity} value for the record.
   *
   * @return The sensitivity entry value for the record.
   */
  SENSITIVITYEntry getSensitivity();

  /**
   * Retrieves any user comments recorded for the record.
   *
   * @return The user comments.
   */
  String getComments();

  /**
   * Retrieves the expected date range for the record.
   *
   * @return The expected date range.
   */
  DateRange getExpectedDateRange();

  /**
   * Retrieves the actual date range for the record.
   *
   * @return The actual date range.
   */
  DateRange getActualDateRange();

  /**
   * Retrieves the {@link ServicePlanDelivery} record that the planed sub goal
   * is related to.
   *
   * @return The service plan delivery for the planned sub goal.
   */
  ServicePlanDelivery getPlanDelivery();
}
