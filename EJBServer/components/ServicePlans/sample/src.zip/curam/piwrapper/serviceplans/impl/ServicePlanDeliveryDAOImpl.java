/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.Inject;
import com.google.inject.Singleton;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.participant.impl.ConcernRole;
import curam.serviceplans.sl.entity.impl.ServicePlanDeliveryAdapter;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanForConcernDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Default implementation of {@linkplain ServicePlanDeliveryDAO} interface.
 */
@Singleton
// BEGIN, CR00183334, PS
public class ServicePlanDeliveryDAOImpl extends StandardDAOImpl<ServicePlanDelivery, ServicePlanDeliveryDtls> implements
  ServicePlanDeliveryDAO {

  // END, CR00183334
  private static final ServicePlanDeliveryAdapter adapter = new ServicePlanDeliveryAdapter();

  @Inject
  private ServicePlanDeliveryDAO servicePlanDeliveryDAO;

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected ServicePlanDeliveryDAOImpl() {

    // No-arg constructor for use only by Guice
    // END, CR00183334
    super(adapter, ServicePlanDelivery.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<ServicePlanDelivery> searchActiveServicePlanDeliveriesForConcernRole(
    final ConcernRole concernRole) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final RelationshipConcernRoleIDKey key = new RelationshipConcernRoleIDKey();

    key.concernRoleID = concernRole.getID();

    // Retrieve the service plan delivery cases for this concern role
    final curam.serviceplans.sl.entity.struct.ServicePlanForConcernDetailsList servicePlanForConcernDetailsList = servicePlanDeliveryObj.searchByConcernRoleID(
      key);

    ServicePlanDelivery servicePlanDelivery;

    final List<ServicePlanDelivery> servicePlanDeliveries = new ArrayList<ServicePlanDelivery>();

    for (final ServicePlanForConcernDetails servicePlanForConcernDetails : servicePlanForConcernDetailsList.dtls.items()) {
      servicePlanDelivery = servicePlanDeliveryDAO.get(
        servicePlanForConcernDetails.caseID);
      servicePlanDeliveries.add(servicePlanDelivery);
    }
    return Collections.unmodifiableList(servicePlanDeliveries);
  }
}
