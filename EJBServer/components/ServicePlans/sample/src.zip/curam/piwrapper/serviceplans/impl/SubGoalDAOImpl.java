/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.Inject;
import com.google.inject.Singleton;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.fact.GoalFactory;
import curam.serviceplans.sl.entity.impl.SubGoalAdapter;
import curam.serviceplans.sl.entity.struct.GoalKey;
import curam.serviceplans.sl.entity.struct.SubGoalDtls;
import curam.serviceplans.sl.entity.struct.SubGoalSummaryDetails;
import curam.serviceplans.sl.entity.struct.SubGoalSummaryDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Data access for {@linkplain curam.sl.entity.intf.SubGoal}.
 */
@Singleton
// BEGIN, CR00183334, PS
public class SubGoalDAOImpl extends StandardDAOImpl<SubGoal, SubGoalDtls>
  implements SubGoalDAO {

  // END, CR00183334
  /**
   * SubGoal generated adapter class.
   */
  private static final SubGoalAdapter adapter = new SubGoalAdapter();

  /**
   * Interface for the goal entity.
   */
  private static final curam.serviceplans.sl.entity.intf.Goal goalEntity = GoalFactory.newInstance();

  @Inject
  private SubGoalDAO subGoalDAO;

  @Inject
  private GoalDAO goalDAO;

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected SubGoalDAOImpl() {

    // no-arg constructor for use only by Guice
    // END, CR00183334
    super(adapter, SubGoal.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<SubGoal> listActiveForServicePlan(final ServicePlan servicePlan) {

    // Create an instance of the return list
    final List<SubGoal> returnSubGoalsList = new ArrayList<SubGoal>();

    // List all the active gaols for a service plan
    final List<Goal> goalList = goalDAO.listActiveByServicePlan(servicePlan);

    // Loop through the list of active goals
    for (final Goal goal : goalList) {

      // List all the active sub goals linked to the goal
      final List<SubGoal> subGoalList = goal.listActiveSubGoals();

      // Add each of the active sub goals to the return list
      for (final SubGoal subGoal : subGoalList) {
        returnSubGoalsList.add(subGoal);
      }
    }

    // Return an immutable list of the sub goals
    return Collections.unmodifiableList(returnSubGoalsList);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<SubGoal> listActiveByGoal(final Goal goal) {

    // Create and instance of the return list
    final List<SubGoal> subGoalList = new ArrayList<SubGoal>();

    // Set the key for the read
    final GoalKey goalKey = new GoalKey();

    goalKey.goalID = goal.getID();

    try {
      // Read the list of sub goals
      final SubGoalSummaryDetailsList subGoalSummaryDetailsList = goalEntity.searchSubGoal(
        goalKey);

      // Loop through the list of
      for (final SubGoalSummaryDetails subGoalSummaryDetails : subGoalSummaryDetailsList.dtls.items()) {
        final SubGoal subGoal = subGoalDAO.get(subGoalSummaryDetails.subGoalID);

        if (subGoal.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {
          subGoalList.add(subGoal);
        }
      }

      return subGoalList;

      /*
       * Catch an exceptions and thrown them as runtime exceptions as there is
       * nothing the application can do to cater for exceptions thrown here.
       */
    } catch (final AppException e) {
      throw new AppRuntimeException(e);
    } catch (final InformationalException e) {
      throw new AppRuntimeException(e);
    }
  }
}
