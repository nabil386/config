/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import curam.codetable.impl.PLANITEMNAMEEntry;
import curam.codetable.impl.PLANITEMTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.piwrapper.impl.ClientURI;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.util.persistence.helper.ReadOnlyEntityImpl;
import curam.util.type.Money;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * A wrapper object for {@linkplain curam.serviceplans.sl.entity.intf.PlanItem}.
 */
// BEGIN, CR00183334, PS
public class PlanItemImpl extends ReadOnlyEntityImpl<Long, PlanItemDtls>
  implements PlanItem {

  /*
   * no-arg constructor for use only by Guice
   */
  protected PlanItemImpl() {// no-arg constructor for use only by Guice.
  }

  // END, CR00183334
  /**
   * {@inheritDoc}
   */
  @Override
  public PLANITEMNAMEEntry getName() {

    return PLANITEMNAMEEntry.get(getDtls().name);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RECORDSTATUSEntry getLifecycleState() {

    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Money getCost() {

    return getDtls().cost;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ClientURI getCreateURI() {

    final String pageName = getDtls().createPageName;

    // Append the parameters to the URI
    final Map<String, String> params = new LinkedHashMap<String, String>();

    params.put(getDtls().createPagePlanItemIDParamName, getID().toString());

    return new ClientURI(pageName, params);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getDescription() {

    return getDtls().description;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getReference() {

    return getDtls().planItemReference;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public PLANITEMTYPEEntry getType() {

    return PLANITEMTYPEEntry.get(getDtls().typeCode);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Boolean isApprovalRequired() {

    return getDtls().requiresApproval;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getCreatePlannedSubGoalPageParamName() {

    return getDtls().createPageSubGoalIDParamName;
  }

}
