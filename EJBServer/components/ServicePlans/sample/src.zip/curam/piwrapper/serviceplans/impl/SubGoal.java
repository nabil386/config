/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SUBGOALNAMEEntry;
import curam.codetable.impl.SUBGOALTYPEEntry;
import curam.util.persistence.OptimisticLockable;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import java.util.List;


/**
 * A wrapper object for {@linkplain curam.serviceplans.sl.entity.intf.SubGoal}.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(SubGoalImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface SubGoal extends StandardEntity,
    Lifecycle<RECORDSTATUSEntry>, OptimisticLockable {

  // END, CR00309529

  /**
   * Returns the sub goal reference.
   *
   * @return The sub goal reference
   */
  String getSubGoalReference();

  /**
   * Getter for the sub goal name.
   *
   * @return the name code for the sub goal.
   */
  SUBGOALNAMEEntry getName();

  /**
   * Returns the typeCode, a value from the SubGoalType code table.
   *
   * @return The type of the subGoal
   */
  SUBGOALTYPEEntry getTypeCode();

  /**
   * Returns the date this sub goal was created.
   *
   * @return The date the sub goal was created.
   */
  Date getDateCreated();

  /**
   * Returns the description of this sub goal.
   *
   * @return The description.
   */
  String getDescription();

  /**
   * Retrieves an immutable list of active plan items that are linked to the sub
   * goal.
   *
   * @return An immutable list of active plan items, or an empty list if none
   * are found.
   */
  List<PlanItem> listActivePlanItems();

}
