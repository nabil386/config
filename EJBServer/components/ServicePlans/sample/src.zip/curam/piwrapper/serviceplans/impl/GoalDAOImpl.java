/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.Singleton;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.fact.ServicePlanFactory;
import curam.serviceplans.sl.entity.impl.GoalAdapter;
import curam.serviceplans.sl.entity.struct.GoalDtls;
import curam.serviceplans.sl.entity.struct.GoalSummaryDetails;
import curam.serviceplans.sl.entity.struct.GoalSummaryDetailsList;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Standard implementation of the {@link GoalDAO} interface.
 */
@Singleton
// BEGIN, CR00183334, PS
public class GoalDAOImpl extends StandardDAOImpl<Goal, GoalDtls> implements
  GoalDAO {

  // END, CR00183334
  /**
   * Instance of the goal generated adapter class.
   */
  private static final GoalAdapter goalAdapter = new GoalAdapter();

  /**
   * Instance of the service plan entity.
   */
  private static final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanEntity = ServicePlanFactory.newInstance();

  /**
   * Default constructor.
   */
  protected GoalDAOImpl() {

    super(goalAdapter, Goal.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<Goal> listActiveByServicePlan(final ServicePlan servicePlan) {

    // Create an instance of the return list
    final List<Goal> goalList = new ArrayList<Goal>();

    // Populate the key for the
    final ServicePlanKey servicePlanKey = new ServicePlanKey();

    servicePlanKey.servicePlanID = servicePlan.getID();

    try {
      final GoalSummaryDetailsList goalSummaryDetailsList = servicePlanEntity.searchGoals(
        servicePlanKey);

      // Loop through the list of goals found
      for (final GoalSummaryDetails goalSummaryDetails : goalSummaryDetailsList.dtls.items()) {
        final Goal goal = get(goalSummaryDetails.goalID);

        // If the goal is active, add it to the return list
        if (goal.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {
          goalList.add(goal);
        }
      }

      // Return the immutable list
      return Collections.unmodifiableList(goalList);

      /*
       * Catch an exceptions and thrown them as runtime exceptions as there is
       * nothing the application can do to cater for exceptions thrown here.
       */
    } catch (final AppException e) {
      throw new AppRuntimeException(e);
    } catch (final InformationalException e) {
      throw new AppRuntimeException(e);
    }
  }

}
