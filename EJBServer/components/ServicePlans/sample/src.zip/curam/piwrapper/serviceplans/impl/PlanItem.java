/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.PLANITEMNAMEEntry;
import curam.codetable.impl.PLANITEMTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.piwrapper.impl.ClientURI;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Money;


/**
 * A wrapper object for {@linkplain curam.serviceplans.sl.entity.intf.PlanItem}.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(PlanItemImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface PlanItem extends StandardEntity,
    Lifecycle<RECORDSTATUSEntry> {

  // END, CR00309529

  /**
   * Getter for the plan item name.
   *
   * @return code for the plan item name.
   */
  PLANITEMNAMEEntry getName();

  /**
   * Retrieves the type of plan item.
   *
   * @return The plan item type entry value.
   */
  PLANITEMTYPEEntry getType();

  /**
   * Retrieves the description text for the plan item.
   *
   * @return The description text.
   */
  String getDescription();

  /**
   * Retrieves the reference for the plan item. the reference field is used to
   * reference this type of plan item from other areas of the system, e.g. the
   * rules engine.
   *
   * @return The plan item reference field value.
   */
  String getReference();

  /**
   * Indicates if approval is required for this plan item.
   *
   * @return <code>true</code> if the plan item requires approval,
   * <code>false</code> otherwise.
   */
  Boolean isApprovalRequired();

  /**
   * Retrieves the value of the cost field.
   *
   * @return The cost value for the plan item.
   */
  Money getCost();

  /**
   * Retrieves the URI for the create planned item page. The URI for the create
   * screen contains the page name, plus the populated plan item id param, any
   * additional parameters can be added in the client UIM page link, or appended
   * to the URI returned.
   * <p>
   * E.g. CreatePlannedItemPage.do?planItemID=10001
   * </p>
   * The operation doesn't add the {@link PlannedSubGoal} param to the URI, this
   * is usually required for creating planned items as plan items are linked to
   * planned sub goals.
   *
   * @return The uri of the create planned item page.
   */
  ClientURI getCreateURI();

  /**
   * Retrieves the value of the createPageSubGoalIDParamName field. This field
   * is used to hold the name of the planned sub goal parameter to be used when
   * constructing the URL of the create planned item page.
   *
   * @return The createPageSubGoalIDParamName field value.
   */
  String getCreatePlannedSubGoalPageParamName();

}
