/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.ReaderDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import java.util.List;


/**
 * Data access for {@linkplain curam.sl.entity.intf.PlanItem}.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(PlanItemDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface PlanItemDAO extends ReaderDAO<Long, PlanItem> {

  // END, CR00309529
  /**
   * Retrieves an immutable list of active {@link PlanItem} records linked to
   * the specified SubGoal.
   *
   * @param subGoal
   * subGoal object instance we are searching for plan items for.
   * @return An immutable list of all active PlanItem records linked to the
   * specified SubGoal, or an empty list if none are found.
   */
  public List<PlanItem> listActiveBySubGoal(SubGoal subGoal);
}
