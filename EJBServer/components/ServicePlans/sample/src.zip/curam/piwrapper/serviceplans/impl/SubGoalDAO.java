/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.ReaderDAO;
import java.util.List;


/**
 * Read only data access for the {@link curam.sl.entity.intf.SubGoal} entity.
 */
@ImplementedBy(SubGoalDAOImpl.class)
public interface SubGoalDAO extends ReaderDAO<Long, SubGoal> {

  /**
   * Lists active {@link SubGoal} records linked to the specified ServicePlan.
   * This is done by listing all the active goals linked to the service plan and
   * then listing all the active sub goals for each of the goals.
   *
   * @param servicePlan
   * service plan object instance we are searching for sub goals for.
   * @return a list of all active SubGoal records linked to the specified
   * ServicePlan.
   */
  List<SubGoal> listActiveForServicePlan(ServicePlan servicePlan);

  /**
   * Retrieves an immutable list of all active sub goals linked to a goal.
   *
   * @param goal
   * The goal to use in the search.
   * @return An immutable list of sub goals, or an empty list if none are found.
   */
  List<SubGoal> listActiveByGoal(Goal goal);

}
