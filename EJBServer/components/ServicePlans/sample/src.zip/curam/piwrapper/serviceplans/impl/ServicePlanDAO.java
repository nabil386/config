/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;
import curam.piwrapper.caseconfiguration.impl.CaseConfigurationReaderDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import java.util.List;


/**
 * Data access for abstract
 * {@linkplain curam.serviceplans.sl.entity.intf.ServicePlan}.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(ServicePlanDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ServicePlanDAO extends
    CaseConfigurationReaderDAO<ServicePlan> {

  // END, CR00309529

  @Override

  /**
   * Retrieves an immutable list of active {@linkplain ServicePlan} records.
   *
   * @return An immutable list of active {@linkplain ServicePlan} records
   */
  List<ServicePlan> listActive();

  /**
   * Retrieves an immutable list of all the {@linkplain ServicePlan} records.
   *
   * @return An immutable list of all the {@linkplain ServicePlan} records
   */
  List<ServicePlan> listAll();

}
