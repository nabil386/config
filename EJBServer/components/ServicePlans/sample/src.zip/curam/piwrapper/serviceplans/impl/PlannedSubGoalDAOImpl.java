/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.Singleton;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.impl.PlannedSubGoalAdapter;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Standard implementation of the {@link PlannedSubGoalDAO} interface.
 */
@Singleton
// BEGIN, CR00183334, PS
public class PlannedSubGoalDAOImpl extends StandardDAOImpl<PlannedSubGoal, PlannedSubGoalDtls> implements
  PlannedSubGoalDAO {

  // END, CR00183334
  private static final PlannedSubGoalAdapter entityAdapter = new PlannedSubGoalAdapter();

  /**
   * Default constructor used by Guice.
   */
  // BEGIN, CR00183334, PS
  protected PlannedSubGoalDAOImpl() {

    // END, CR00183334
    super(entityAdapter, PlannedSubGoal.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<PlannedSubGoal> listActiveByPlannedGoal(
    final PlannedGoal plannedGoal) {

    // Read the list of all planned sub goals for a planned goal, includes the
    // cancelled records
    final List<PlannedSubGoal> fullList = newList(
      entityAdapter.searchByPlannedGoalIDAndNoPlannedGroup(plannedGoal.getID()));

    // Filter the cancelled records out of the list
    final List<PlannedSubGoal> activeList = new ArrayList<PlannedSubGoal>();

    for (final PlannedSubGoal plannedSubGoal : fullList) {
      if (plannedSubGoal.getRecordStatus().equals(RECORDSTATUSEntry.NORMAL)) {
        activeList.add(plannedSubGoal);
      }
    }

    // return an immutable list of the active record
    return Collections.unmodifiableList(activeList);
  }

}
