/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.Singleton;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.impl.ServicePlanAdapter;
import curam.serviceplans.sl.entity.struct.ServicePlanDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Default implementation of {@linkplain ServicePlanDAO} interface.
 */
@Singleton
// BEGIN, CR00183334, PS
public class ServicePlanDAOImpl extends StandardDAOImpl<ServicePlan, ServicePlanDtls> implements ServicePlanDAO {

  // END, CR00183334
  private static final ServicePlanAdapter adapter = new ServicePlanAdapter();

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected ServicePlanDAOImpl() {

    // No-arg constructor for use only by Guice
    // END, CR00183334
    super(adapter, ServicePlan.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<ServicePlan> listActive() {

    // Create the return list
    final List<ServicePlan> servicePlanList = newList(adapter.list());

    // TODO (PM) - a new operation searchByStatus that takes in the status code
    // is
    // required

    final List<ServicePlan> filteredServicePlanList = new ArrayList<ServicePlan>();

    // Remove the cancelled records from the list
    for (final ServicePlan servicePlan : servicePlanList) {
      if (servicePlan.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {
        filteredServicePlanList.add(servicePlan);
      }
    }

    return Collections.unmodifiableList(filteredServicePlanList);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<ServicePlan> listAll() {

    return Collections.unmodifiableList(newList(adapter.list()));
  }

}
