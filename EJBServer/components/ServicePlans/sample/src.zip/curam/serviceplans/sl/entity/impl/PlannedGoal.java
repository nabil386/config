/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.GOALNAME;
import curam.codetable.LANGUAGE;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.Count;
import curam.core.struct.CountCaseKey;
import curam.message.BPOMAINTAINSERVICEPLANDELIVERY;
import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.struct.CaseIDAndLanguageCodeKey;
import curam.serviceplans.sl.entity.struct.GoalKey;
import curam.serviceplans.sl.entity.struct.GoalNameDetails;
import curam.serviceplans.sl.entity.struct.ModifyOutcomeAchievedDetails;
import curam.serviceplans.sl.entity.struct.PlannedGoalActualAndExpectedDates;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedGoalIDAndContractText;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalCountDetails;
import curam.serviceplans.sl.entity.struct.ReadPlannedGoalIDAndGoalTextByCaseIDKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.DateTime;


/**
 * Planned Goal entity implementation
 *
 */
public abstract class PlannedGoal extends curam.serviceplans.sl.entity.base.PlannedGoal {

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for a modify operation.
   *
   * @param key Contains case ID of the service plan delivery.
   *
   * @param details Outcome and comments details.
   */
  @Override
  protected void premodifyOutcomeAchieved(CaseHeaderKey key,
    ModifyOutcomeAchievedDetails details) throws AppException,
      InformationalException {

    // call the validate
    validateModifyOutcomeAchieved(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the modification of service plan delivery details.
   *
   * @param key Case ID of the service plan delivery.
   *
   * @param details Outcome and comments details.
   */
  @Override
  public void validateModifyOutcomeAchieved(CaseHeaderKey key,
    ModifyOutcomeAchievedDetails details) throws AppException,
      InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    // PlannedSubGoal manipulation variables
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    final CountCaseKey countCaseKey = new CountCaseKey();
    Count count = null;

    // Set the key
    countCaseKey.caseID = key.caseID;

    // Read case header details
    caseStatusCode = caseHeaderObj.readCaseStatus(key);

    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_CASESTATUS_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check that for each planned sub goal, an outcomeAchieved has been set.
    count = plannedSubGoalObj.countOutcomeAchievedNotSetByCaseID(countCaseKey);

    // if records exist, an outcomeAchieved has not been set for one of the
    // PlannedSubGoals
    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_SET_OUTCOME_WHEN_SET_FOR_SUB_GOALS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the planned goal details
   *
   * @param details Planned goal details.
   */
  @Override
  protected void preinsert(PlannedGoalDtls details) throws AppException,
      InformationalException {

    final CaseID caseID = new CaseID();

    caseID.caseID = details.caseID;

    // Validate the details
    validateCaseStatus(caseID);

    // BEGIN, CR00281989, AKr
    details.createdOn = DateTime.getCurrentDateTime();

    // END, CR00281989

  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the details to modify the service plan goal.
   *
   * @param key Case ID of the service plan delivery.
   *
   * @param dtls Planned goal details.
   */
  @Override
  protected void premodifyGoalType(CaseID key, GoalKey dtls)
    throws AppException, InformationalException {

    // Perform the validation
    validateModifyGoalType(key);

  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the service plan status.
   *
   * @param key Case ID of the service plan delivery.
   */
  @Override
  public void validateCaseStatus(CaseID key) throws AppException,
      InformationalException {

    // Validation - if case is closed, unable to create or modify type
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    // set the key
    caseHeaderKey.caseID = key.caseID;
    // Read case header details
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_CASESTATUS_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the details to modify the service plan goal.
   *
   * @param key Case ID of the service plan delivery.
   */
  @Override
  public void validateModifyGoalType(CaseID key) throws AppException,
      InformationalException {

    // validation when sub goals have already been added to the service plan
    // delivery
    // PlannedSubGoal manipulation variables
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    final PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey = new PlannedSubGoalCaseIDKey();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalCountDetails count = new PlannedSubGoalCountDetails();

    // Check to ensure the case is not closed.
    validateCaseStatus(key);

    // Set the key
    plannedSubGoalCaseIDKey.caseID = key.caseID;

    // Check if any planned sub goals have been created for this service plan
    count = plannedSubGoalObj.countPlannedSubGoalByCaseID(
      plannedSubGoalCaseIDKey);

    // if records exist, sub goals exist so type cannot be modified
    if (count.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_SUBGOALS_ALREADY_ADDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Checks to see if sub goal dates have to be changed and if so,
   * sets them to new dates.
   *
   * @param key Planned Sub-Goal identifier
   */
  @Override
  public void reCalculateDates(PlannedGoalKey key) throws AppException,
      InformationalException {

    final PlannedGoalActualAndExpectedDates plannedGoalActualAndExpectedDates = new PlannedGoalActualAndExpectedDates();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // read all planned items for planned goal,
    // if no planned items then set dates to blank as all dates derive from the
    // plan item dates.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = read(key).caseID;
    if (plannedItemObj.countByCaseID(servicePlanDeliveryKey).recordCount == 0) {
      modifyDateRange(key, plannedGoalActualAndExpectedDates);
    } else {
      // Read the Min and Max Sub Goal dates for this gaol
      final PlannedGoalActualAndExpectedDates plannedSubGoalActualAndExpectedDates = readSubGoalMinAndMaxDates(
        key);

      // Read the Min and Max Planned Group dates for this gaol
      final PlannedGoalActualAndExpectedDates plannedGroupActualAndExpectedDates = readPlanGroupMinAndMaxDates(
        key);

      // When Checking the earliest dates you have to check first - Are the
      // dates set
      // The reason: A date not set still takes the date of 0001-01-01 so will
      // be
      // earlier than a date of today which is incorrect.

      // Check which dates are the earliest and set to new planned goal
      // actualStartDate
      if (plannedSubGoalActualAndExpectedDates.actualStartDate.isZero()) {
        plannedGoalActualAndExpectedDates.actualStartDate = plannedGroupActualAndExpectedDates.actualStartDate;
      } else if (plannedGroupActualAndExpectedDates.actualStartDate.isZero()) {
        plannedGoalActualAndExpectedDates.actualStartDate = plannedSubGoalActualAndExpectedDates.actualStartDate;
      } else {
        if (plannedGroupActualAndExpectedDates.actualStartDate.before(
          plannedSubGoalActualAndExpectedDates.actualStartDate)) {
          plannedGoalActualAndExpectedDates.actualStartDate = plannedGroupActualAndExpectedDates.actualStartDate;
        } else {
          plannedGoalActualAndExpectedDates.actualStartDate = plannedSubGoalActualAndExpectedDates.actualStartDate;
        }
      }
      // Check which dates are the earliest and set to new planned goal
      // expectedStartDate
      if (plannedSubGoalActualAndExpectedDates.expectedStartDate.isZero()) {
        plannedGoalActualAndExpectedDates.expectedStartDate = plannedGroupActualAndExpectedDates.expectedStartDate;
      } else if (plannedGroupActualAndExpectedDates.expectedStartDate.isZero()) {
        plannedGoalActualAndExpectedDates.expectedStartDate = plannedSubGoalActualAndExpectedDates.expectedStartDate;
      } else {
        if (plannedGroupActualAndExpectedDates.expectedStartDate.before(
          plannedSubGoalActualAndExpectedDates.expectedStartDate)) {
          plannedGoalActualAndExpectedDates.expectedStartDate = plannedGroupActualAndExpectedDates.expectedStartDate;
        } else {
          plannedGoalActualAndExpectedDates.expectedStartDate = plannedSubGoalActualAndExpectedDates.expectedStartDate;
        }
      }
      // Check which dates are the latest and set to new planned goal
      // actualEndDate
      if (plannedSubGoalActualAndExpectedDates.actualEndDate.isZero()) {
        plannedGoalActualAndExpectedDates.actualEndDate = plannedGroupActualAndExpectedDates.actualEndDate;
      } else if (plannedSubGoalActualAndExpectedDates.actualEndDate.isZero()) {
        plannedGoalActualAndExpectedDates.actualEndDate = plannedSubGoalActualAndExpectedDates.actualEndDate;
      } else {
        if (plannedGroupActualAndExpectedDates.actualEndDate.after(
          plannedSubGoalActualAndExpectedDates.actualEndDate)) {
          plannedGoalActualAndExpectedDates.actualEndDate = plannedGroupActualAndExpectedDates.actualEndDate;
        } else {
          plannedGoalActualAndExpectedDates.actualEndDate = plannedSubGoalActualAndExpectedDates.actualEndDate;
        }
      }

      // Check to see which dates are the latest and set to new planned goal
      // expectedEndDate
      if (plannedSubGoalActualAndExpectedDates.expectedEndDate.isZero()) {
        plannedGoalActualAndExpectedDates.expectedEndDate = plannedGroupActualAndExpectedDates.expectedEndDate;
      } else if (plannedSubGoalActualAndExpectedDates.expectedEndDate.isZero()) {
        plannedGoalActualAndExpectedDates.expectedEndDate = plannedSubGoalActualAndExpectedDates.expectedEndDate;
      } else {
        if (plannedGroupActualAndExpectedDates.expectedEndDate.after(
          plannedSubGoalActualAndExpectedDates.expectedEndDate)) {
          plannedGoalActualAndExpectedDates.expectedEndDate = plannedGroupActualAndExpectedDates.expectedEndDate;
        } else {
          plannedGoalActualAndExpectedDates.expectedEndDate = plannedSubGoalActualAndExpectedDates.expectedEndDate;
        }
      }

      final PlannedGoalDtls plannedGoalDtls = read(key);

      if (!plannedGoalActualAndExpectedDates.actualEndDate.equals(
        plannedGoalDtls.actualEndDate)
          || !plannedGoalActualAndExpectedDates.actualStartDate.equals(
            plannedGoalDtls.actualStartDate)
            || !plannedGoalActualAndExpectedDates.expectedStartDate.equals(
              plannedGoalDtls.expectedStartDate)
              || !plannedGoalActualAndExpectedDates.expectedEndDate.equals(
                plannedGoalDtls.expectedEndDate)) {

        // modify the dates to the changed dates
        modifyDateRange(key, plannedGoalActualAndExpectedDates);

      }
    }
  }

  // BEGIN, CR00277773, ELG
  // ___________________________________________________________________________
  /**
   * Reads the active planned goal id and goal contract text for a service
   * plan id.
   *
   * @param key Contains case ID and Participant ID.
   * @return Structure containing contract text and planned goal ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlannedGoalIDAndContractText readIDAndGoalContractTextByCaseID1(
    final ReadPlannedGoalIDAndGoalTextByCaseIDKey key) throws AppException,
      InformationalException {

    // Return structure
    PlannedGoalIDAndContractText plannedGoalIDAndContractText = new PlannedGoalIDAndContractText();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    final CaseIDAndLanguageCodeKey caseIDAndLanguageCodeKey = new CaseIDAndLanguageCodeKey();

    caseIDAndLanguageCodeKey.caseID = key.caseID;

    if (concernRoleDtls.preferredLanguage.equals("")) {

      caseIDAndLanguageCodeKey.languageCode = LANGUAGE.DEFAULTCODE;
      plannedGoalIDAndContractText = readIDAndGoalContractTextByCaseAndLanguage(
        caseIDAndLanguageCodeKey);

    } else {

      caseIDAndLanguageCodeKey.languageCode = concernRoleDtls.preferredLanguage;
      plannedGoalIDAndContractText = readIDAndGoalContractTextByCaseAndLanguage(
        caseIDAndLanguageCodeKey);

      if (plannedGoalIDAndContractText.goalContractText.equals("")) {

        caseIDAndLanguageCodeKey.languageCode = LANGUAGE.DEFAULTCODE;
        plannedGoalIDAndContractText = readIDAndGoalContractTextByCaseAndLanguage(
          caseIDAndLanguageCodeKey);

      }

    }

    if (plannedGoalIDAndContractText.goalContractText.equals("")) {
      final AppException ae = new AppException(
        BPOMAINTAINSERVICEPLANDELIVERY.INF_GOAL_CONTRACT_TEXT_MISSING);
      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      // BEGIN, CR00287219, ELG
      final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();
      final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

      servicePlanDeliveryKey.caseID = key.caseID;
      final GoalNameDetails goalNameDetails = plannedGoalObj.readGoalNameByCaseID(
        servicePlanDeliveryKey);

      final String nameDesription = CodeTable.getOneItemForUserLocale(
        GOALNAME.TABLENAME, goalNameDetails.name);

      ae.arg(nameDesription);
      // END, CR00287219

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, "", InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    return plannedGoalIDAndContractText;

  }
  // END, CR00277773

}
