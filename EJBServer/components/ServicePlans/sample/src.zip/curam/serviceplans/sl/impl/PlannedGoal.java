/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.MILESTONESTATUSCODE;
import curam.codetable.OUTCOMEACHIEVED;
import curam.core.sl.entity.fact.MilestoneConfigurationFactory;
import curam.core.sl.entity.intf.MilestoneConfiguration;
import curam.core.sl.entity.struct.MilestoneConfigurationDtls;
import curam.core.sl.entity.struct.MilestoneConfigurationKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.struct.CurrentCaseStatusKey;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtls;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtlsList;
import curam.serviceplans.sl.fact.MilestoneFactory;
import curam.serviceplans.sl.struct.CaseIDSensitivityAndPlannedGroupKey;
import curam.serviceplans.sl.struct.ComparisonLevelDetailsList;
import curam.serviceplans.sl.struct.PlannedGroupKey;
import curam.serviceplans.sl.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Planned Goal
 * service layer.
 */
public abstract class PlannedGoal extends curam.serviceplans.sl.base.PlannedGoal {

  // ___________________________________________________________________________
  /**
   * Clones planned goal.
   *
   * @param originalPlanKey Contains unique ID of the service plan delivery
   * being cloned
   * @param newCreatedPlanKey Contains unique ID of the service plan delivery
   * created as a result of cloning
   */
  @Override
  public void clone(ServicePlanDeliveryKey originalPlanKey,
    ServicePlanDeliveryKey newCreatedPlanKey) throws AppException,
      InformationalException {

    // PlannedGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();
    curam.serviceplans.sl.entity.struct.PlannedGoalDetails plannedGoalDetails;
    final curam.serviceplans.sl.entity.struct.ModifyOutcomeAchievedDetails modifyOutcomeAchievedDetails = new curam.serviceplans.sl.entity.struct.ModifyOutcomeAchievedDetails();
    curam.serviceplans.sl.entity.struct.PlannedGoalKey plannedGoalKey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();
    final curam.serviceplans.sl.struct.PlannedGoalKey newPlannedGoalKey = new curam.serviceplans.sl.struct.PlannedGoalKey();
    final curam.serviceplans.sl.entity.struct.PlannedGoalDtls plannedGoalDtls = new curam.serviceplans.sl.entity.struct.PlannedGoalDtls();

    // Planned Sub Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // CaseHeaderKey
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // Planned Sub Goal entity object
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal entityPlannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalDtlsList plannedSubGoalDtlsList;
    final curam.serviceplans.sl.struct.PlannedSubGoalDtls plannedSubGoalDtls = new curam.serviceplans.sl.struct.PlannedSubGoalDtls();

    // Planned Group entity object
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();
    final curam.serviceplans.sl.struct.PlannedGroupKey plannedGroupKey = new curam.serviceplans.sl.struct.PlannedGroupKey();
    curam.serviceplans.sl.entity.struct.PlannedGroupDtlsList plannedGroupDtlsList;

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup boPlannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();
    curam.serviceplans.sl.struct.PlannedGroupDtls plannedGroupDtls;

    // set up the key
    servicePlanDeliveryKey.caseID = originalPlanKey.key.caseID;

    // BEGIN, CR00117949, MC

    // BEGIN, CR00108566, MC
    final boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);

    final boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
      closePreviousPlan_default);

    // BEGIN, CR00117416, MC

    // CaseStatus manipulation variables
    // read current status

    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

    final CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = servicePlanDeliveryKey.caseID;
    // BEGIN, CR00224271, ZV
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    // END, CR00117949

    //
    // Clone planned goal
    //
    try {
      // read planned goal ID
      plannedGoalKey = plannedGoalObj.readIDByCaseID(servicePlanDeliveryKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      // goal might not be set for the service plan delivery
      plannedGoalKey = null;
    }

    if (plannedGoalKey != null) {
      // read goal ID of the original plan
      final curam.serviceplans.sl.entity.struct.GoalKey goalKey = plannedGoalObj.readGoalID(
        plannedGoalKey);

      // create new planned goal
      plannedGoalDtls.caseID = newCreatedPlanKey.key.caseID;
      plannedGoalDtls.goalID = goalKey.goalID;

      // insert planned goal record
      plannedGoalObj.insert(plannedGoalDtls);

      // set new planned goal ID
      newPlannedGoalKey.key.plannedGoalID = plannedGoalDtls.plannedGoalID;
    }

    // BEGIN, CR00057087, PMD
    // Search for all milestones at service plan level and clone them
    caseHeaderKey.caseID = originalPlanKey.key.caseID;
    final SPMilestoneAndLinkDtlsList spMilestoneAndLinkDtlsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesAndLinksByCaseID(
      caseHeaderKey);

    // BEGIN, CR00117949, MC
    final MilestoneConfiguration milestoneConfig = MilestoneConfigurationFactory.newInstance();

    final MilestoneConfigurationKey milestoneConfigKey = new MilestoneConfigurationKey();

    for (int k = 0; k < spMilestoneAndLinkDtlsList.dtls.size(); k++) {

      final SPMilestoneAndLinkDtls spMilestoneAndLinkDtls = new SPMilestoneAndLinkDtls();

      if (closePreviousPlan
        && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
        spMilestoneAndLinkDtls.assign(spMilestoneAndLinkDtlsList.dtls.item(k));

      } else {

        milestoneConfigKey.milestoneConfigurationID = spMilestoneAndLinkDtlsList.dtls.item(k).milestoneConfigurationID;

        final MilestoneConfigurationDtls milestoneConfigurationDtls = milestoneConfig.read(
          milestoneConfigKey);

        // BEGIN, CR00148492, SAI
        spMilestoneAndLinkDtls.assign(spMilestoneAndLinkDtlsList.dtls.item(k));
        // END, CR00148492
        spMilestoneAndLinkDtls.comments = milestoneConfigurationDtls.comments;
        spMilestoneAndLinkDtls.milestoneConfigurationID = milestoneConfigurationDtls.milestoneConfigurationID;

        spMilestoneAndLinkDtls.status = MILESTONESTATUSCODE.NOTSTARTED;

        spMilestoneAndLinkDtls.ownerUserName = TransactionInfo.getProgramUser();

      }

      spMilestoneAndLinkDtls.caseID = newCreatedPlanKey.key.caseID;
      // Clone the milestone
      MilestoneFactory.newInstance().clone(spMilestoneAndLinkDtls,
        new PlannedGroupKey(), new PlannedSubGoalKey());
    }

    // END, CR00057087
    // END, CR00117949

    //
    // search for all planned sub goals assigned directly to planned goal
    // and clone them
    //

    // search for planned sub goals
    plannedSubGoalDtlsList = entityPlannedSubGoalObj.searchByPlannedGoalIDAndNoPlannedGroup(
      plannedGoalKey);

    for (int i = 0; i < plannedSubGoalDtlsList.dtls.size(); i++) {
      // set the details
      plannedGroupKey.key.plannedGroupID = 0;
      plannedSubGoalDtls.dtls.assign(plannedSubGoalDtlsList.dtls.item(i));

      // clone sub goal
      plannedSubGoalObj.clone(plannedSubGoalDtls, newPlannedGoalKey,
        plannedGroupKey);
    }

    //
    // search for all planned groups assigned directly to planned goal
    // and clone them
    //

    // search for planned groups
    plannedGroupDtlsList = plannedGroupObj.searchByPlannedGoalIDAndNoParentGroup(
      plannedGoalKey);

    for (int j = 0; j < plannedGroupDtlsList.dtls.size(); j++) {

      plannedGroupDtls = new curam.serviceplans.sl.struct.PlannedGroupDtls();
      plannedGroupDtls.dtls.assign(plannedGroupDtlsList.dtls.item(j));

      // clone planned group
      boPlannedGroupObj.clone(plannedGroupDtls, newPlannedGoalKey,
        plannedGroupKey);

    }

    //
    // Update old planned goal
    //

    // set the key
    servicePlanDeliveryKey.caseID = originalPlanKey.key.caseID;

    // read planned goal details
    plannedGoalDetails = plannedGoalObj.readDetailsByCaseID(
      servicePlanDeliveryKey);

    if (closePreviousPlan
      && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
      // modify old planned goal outcome
      modifyOutcomeAchievedDetails.outcomeAchieved = OUTCOMEACHIEVED.NOTATTAINED;
      modifyOutcomeAchievedDetails.versionNo = plannedGoalDetails.versionNo;
      plannedGoalObj.modifyOutcomeAchieved(caseHeaderKey,
        modifyOutcomeAchievedDetails);
    }
    // END, CR00117416
    // END, CR00108566

  }

  // ___________________________________________________________________________
  /**
   * Returns baseline details to be compared with another baseline or with
   * current service plan details
   *
   * @param key Contains service plan delivery unique ID
   *
   * @return Goal, sub goal and plan item details for comparison.
   */
  @Override
  public ComparisonLevelDetailsList readComparisonDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return details
    curam.serviceplans.sl.struct.ComparisonLevelDetailsList comparisonLevelDetailsList = new curam.serviceplans.sl.struct.ComparisonLevelDetailsList();

    // an element of the returned list
    curam.serviceplans.sl.entity.struct.ComparisonLevelDetails comparisonLevelDetails;

    // Planned Goal entity
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // Planned sub goal entity variables
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList;
    final curam.serviceplans.sl.entity.struct.CaseIDAndSensitivityKey caseIDAndSensitivityKey = new curam.serviceplans.sl.entity.struct.CaseIDAndSensitivityKey();
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndSensitivityKey plannedSubGoalIDAndSensitivityKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndSensitivityKey();

    // Planned item entity variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetailsList baselineComparisonPlanItemDetailsList;

    // Planned Group entity variables
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList;
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();
    final curam.serviceplans.sl.struct.CaseIDSensitivityAndPlannedGroupKey caseIDSensitivityAndPlannedGroupKey = new curam.serviceplans.sl.struct.CaseIDSensitivityAndPlannedGroupKey();

    // baseline comparison sub goal details
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails baselineComparisonSubGoalAndAssociatedPlannedItemsDetails;

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode sensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      usersKey);

    // END, CR00098617

    // read baseline comparison details
    comparisonLevelDetailsList.baselineGoalDetails = plannedGoalObj.readGoalDetailsByCaseID(
      key.key);
    comparisonLevelDetails = new curam.serviceplans.sl.entity.struct.ComparisonLevelDetails();

    // set case ID and sensitivity key
    caseIDAndSensitivityKey.caseID = key.key.caseID;
    caseIDAndSensitivityKey.sensitivityCode = sensitivityCode.sensitivity;

    // list planned sub goal comparison details for the first level (planned
    // group is null)
    baselineComparisonSubGoalDetailsList = plannedSubGoalObj.searchDetailsByCaseIDAndSensitivityNoGroup(
      caseIDAndSensitivityKey);

    // search for planned items associated with sub goal
    for (int i = 0; i < baselineComparisonSubGoalDetailsList.dtls.size(); i++) {

      // create returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails = new curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails();

      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.subGoalDetails.assign(
        baselineComparisonSubGoalDetailsList.dtls.item(i));

      plannedSubGoalIDAndSensitivityKey.plannedSubGoalID = baselineComparisonSubGoalDetailsList.dtls.item(i).plannedSubGoalID;
      plannedSubGoalIDAndSensitivityKey.sensitivityCode = sensitivityCode.sensitivity;

      // read planned item comparison details
      baselineComparisonPlanItemDetailsList = plannedItemObj.searchDetailsByPlannedSubGoalIDAndSensitivity(
        plannedSubGoalIDAndSensitivityKey);

      // add baseline plan item details list to the returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.plannedItemList.assign(
        baselineComparisonPlanItemDetailsList);

      comparisonLevelDetails.subGoalList.addRef(
        baselineComparisonSubGoalAndAssociatedPlannedItemsDetails);
    }

    // list all planned groups directly assigned to planned goal
    baselineComparisonPlannedGroupDetailsList = plannedGroupObj.searchByCaseIDNoGroup(
      key.key);

    // add the list to the returned struct
    comparisonLevelDetails.plannedGroupList.assign(
      baselineComparisonPlannedGroupDetailsList);

    // add the details to the list
    comparisonLevelDetailsList.comparisonLevelDetails.addRef(
      comparisonLevelDetails);

    // add the rest to the list
    for (int j = 0; j < baselineComparisonPlannedGroupDetailsList.dtls.size(); j++) {

      // set the key
      caseIDSensitivityAndPlannedGroupKey.key.caseID = key.key.caseID;
      caseIDSensitivityAndPlannedGroupKey.key.plannedGroupID = baselineComparisonPlannedGroupDetailsList.dtls.item(j).plannedGroupID;
      caseIDSensitivityAndPlannedGroupKey.key.sensitivityCode = sensitivityCode.sensitivity;

      // list comparison details for planned group
      comparisonLevelDetailsList = listComparisonDetailsForPlannedGroup(
        caseIDSensitivityAndPlannedGroupKey, comparisonLevelDetailsList);

    }

    // return details
    return comparisonLevelDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads all sub element details (planned groups and sub goals) associated
   * with the given planned group.
   *
   * @param caseIDSensitivityAndPlannedGroupKey id of the planned group
   *
   * @param comparisonLevelDetailsList List that contains details about all
   * existing elements
   * @return lists of sub goals and planned groups associated with the planned
   * group
   */
  @Override
  public ComparisonLevelDetailsList listComparisonDetailsForPlannedGroup(
    CaseIDSensitivityAndPlannedGroupKey caseIDSensitivityAndPlannedGroupKey,
    ComparisonLevelDetailsList comparisonLevelDetailsList)
    throws AppException, InformationalException {

    // an element of the returned list
    final curam.serviceplans.sl.entity.struct.ComparisonLevelDetails comparisonLevelDetails = new curam.serviceplans.sl.entity.struct.ComparisonLevelDetails();

    // Sub Goal and associated Planned Items
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails baselineComparisonSubGoalAndAssociatedPlannedItemsDetails;

    // new key
    final curam.serviceplans.sl.struct.CaseIDSensitivityAndPlannedGroupKey newCaseIDSensitivityAndPlannedGroupKey = new curam.serviceplans.sl.struct.CaseIDSensitivityAndPlannedGroupKey();

    // Planned Group entity variables
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList;
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.CaseIDAndParentGroupIDKey caseIDAndParentGroupIDKey = new curam.serviceplans.sl.entity.struct.CaseIDAndParentGroupIDKey();

    // Planned Sub Goal entity
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetailsList baselineComparisonPlanItemDetailsList;

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndSensitivityKey plannedSubGoalIDAndSensitivityKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndSensitivityKey();

    // baseline comparison sub goal details
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList;

    // set planned group ID
    comparisonLevelDetails.plannedGroupID = caseIDSensitivityAndPlannedGroupKey.key.plannedGroupID;

    // list all sub goals assigned to the planned group
    baselineComparisonSubGoalDetailsList = plannedSubGoalObj.searchDetailsByCaseIDSensitivityAndGroup(
      caseIDSensitivityAndPlannedGroupKey.key);

    // search for planned items associated with sub goal
    for (int i = 0; i < baselineComparisonSubGoalDetailsList.dtls.size(); i++) {

      // create returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails = new curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails();

      // add sub goal details
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.subGoalDetails.assign(
        baselineComparisonSubGoalDetailsList.dtls.item(i));

      // read baseline plan item comparison details
      plannedSubGoalIDAndSensitivityKey.plannedSubGoalID = baselineComparisonSubGoalDetailsList.dtls.item(i).plannedSubGoalID;
      plannedSubGoalIDAndSensitivityKey.sensitivityCode = caseIDSensitivityAndPlannedGroupKey.key.sensitivityCode;

      baselineComparisonPlanItemDetailsList = plannedItemObj.searchDetailsByPlannedSubGoalIDAndSensitivity(
        plannedSubGoalIDAndSensitivityKey);

      // add baseline plan item details list to the returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.plannedItemList.assign(
        baselineComparisonPlanItemDetailsList);

      comparisonLevelDetails.subGoalList.addRef(
        baselineComparisonSubGoalAndAssociatedPlannedItemsDetails);
    }

    caseIDAndParentGroupIDKey.caseID = caseIDSensitivityAndPlannedGroupKey.key.caseID;
    caseIDAndParentGroupIDKey.parentGroupID = caseIDSensitivityAndPlannedGroupKey.key.plannedGroupID;

    // list all planned groups assigned to the planned group
    baselineComparisonPlannedGroupDetailsList = plannedGroupObj.searchByCaseIDAndGroup(
      caseIDAndParentGroupIDKey);

    // add the list to the returned struct
    comparisonLevelDetails.plannedGroupList.assign(
      baselineComparisonPlannedGroupDetailsList);

    // add the details to the list
    comparisonLevelDetailsList.comparisonLevelDetails.addRef(
      comparisonLevelDetails);

    // add the rest to the list
    for (int j = 0; j < baselineComparisonPlannedGroupDetailsList.dtls.size(); j++) {

      // set the key
      newCaseIDSensitivityAndPlannedGroupKey.key.caseID = caseIDSensitivityAndPlannedGroupKey.key.caseID;
      newCaseIDSensitivityAndPlannedGroupKey.key.plannedGroupID = baselineComparisonPlannedGroupDetailsList.dtls.item(j).plannedGroupID;
      newCaseIDSensitivityAndPlannedGroupKey.key.sensitivityCode = caseIDSensitivityAndPlannedGroupKey.key.sensitivityCode;

      // list comparison details for planned group
      comparisonLevelDetailsList = listComparisonDetailsForPlannedGroup(
        newCaseIDSensitivityAndPlannedGroupKey, comparisonLevelDetailsList);

    }

    // return details
    return comparisonLevelDetailsList;
  }

}
