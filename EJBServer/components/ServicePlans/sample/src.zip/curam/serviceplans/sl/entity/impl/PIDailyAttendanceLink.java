/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008,2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.DailyAttendanceDtlsList;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.core.sl.entity.struct.RosterLineItemKey;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndVersionNo;
import curam.serviceplans.sl.entity.fact.PIDailyAttendanceLinkFactory;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtls;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the PIDailyAttendanceLink
 * entity layer.
 *
 */
public abstract class PIDailyAttendanceLink extends curam.serviceplans.sl.entity.base.PIDailyAttendanceLink {

  // ___________________________________________________________________________
  /**
   * Validates the data constraints before modification of the status.
   *
   * @param key The unique identifier of the planned item daily attendance
   * link record.
   * @param recordStatusAndVersionNo The record status and version number
   * details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void premodifyStatus(PIDailyAttendanceLinkKey key,
    RecordStatusAndVersionNo recordStatusAndVersionNo) throws AppException,
      InformationalException {

    // Read the version number from the database
    recordStatusAndVersionNo.versionNo = PIDailyAttendanceLinkFactory.newInstance().readVersionNo(key).versionNo;

  }

  // ___________________________________________________________________________
  /**
   * Remove the attendance roster line items.
   *
   * @param key The roster line item identifier
   */
  @Override
  public void removeAttendanceRosterLnItem(RosterLineItemKey key)
    throws AppException, InformationalException {

    // Get the daily attendance records for the roster line item
    final DailyAttendanceDtlsList dailyAttendanceDtlsList = DailyAttendanceFactory.newInstance().searchByRosterLineItemID(
      key);
    final PIDailyAttendanceLinkKey piDailyAttendanceLinkKey = new PIDailyAttendanceLinkKey();
    final DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    for (final DailyAttendanceDtls o : dailyAttendanceDtlsList.dtls) {
      // Get the link records and remove each one
      dailyAttendanceKey.dailyAttendanceID = o.dailyAttendanceID;
      final PIDailyAttendanceLinkDtlsList piDailyAttendanceLinkDtlsList = searchByDailyAttendanceID(
        dailyAttendanceKey);

      for (final PIDailyAttendanceLinkDtls o2 : piDailyAttendanceLinkDtlsList.dtls) {
        piDailyAttendanceLinkKey.piDailyAttendanceLinkID = o2.piDailyAttendanceLinkID;
        remove(piDailyAttendanceLinkKey);
      }
    }

  }

}
