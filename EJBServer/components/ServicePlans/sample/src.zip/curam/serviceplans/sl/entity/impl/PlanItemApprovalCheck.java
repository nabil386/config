/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.PLANITEMAPPROVALCHECK;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.BPOPLANITEMAPPROVALCHECK;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.struct.CancelPlanItemApprovalCheckDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckCount;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckDtls;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckKey;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckStatusDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckUNModifyKey;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Implements the methods from the Plan Item Approval Check entity.
 */
public class PlanItemApprovalCheck extends curam.serviceplans.sl.entity.base.PlanItemApprovalCheck {

  // __________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion.
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void preinsert(PlanItemApprovalCheckDtls details)
    throws AppException, InformationalException {

    // setting type code if all service plan types is selected
    if (details.appliesToAllInd) {
      if (details.userName.length() > 0) {
        details.typeCode = PLANITEMAPPROVALCHECK.USER;
      }
      if (details.organisationUnitID != 0) {
        details.typeCode = PLANITEMAPPROVALCHECK.ORG_UNIT;
      }
    } else {
      // setting the typceCode when a specific service plan is selected
      if (details.userName.length() > 0) {
        details.typeCode = PLANITEMAPPROVALCHECK.USER;
      }
      if (details.organisationUnitID != 0) {
        details.typeCode = PLANITEMAPPROVALCHECK.ORG_UNIT;
      }
      if (details.userName.length() == 0 && details.organisationUnitID == 0) {
        details.typeCode = PLANITEMAPPROVALCHECK.PLAN_ITEM;
      }
    }

    // set record status to normal
    details.statusCode = RECORDSTATUS.NORMAL;

    // Validate the details
    validateDetails(details);

    // Validate the insert
    validateInsert(details);
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification.
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  @Override
  public void validateInsert(PlanItemApprovalCheckDtls details)
    throws AppException, InformationalException {

    // struct for duplicate approval checks
    PlanItemApprovalCheckCount approvalCheckCount = new PlanItemApprovalCheckCount();

    // validate user type plan item approval checks
    if (details.typeCode.equals(PLANITEMAPPROVALCHECK.USER)) {
      // set key details
      final curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckUNKey unameKey = new curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckUNKey();

      unameKey.estimatedCost = details.estimatedCost;
      unameKey.planItemID = details.planItemID;
      unameKey.userName = details.userName;
      unameKey.statusCode = details.statusCode;
      // if all types selected
      if (details.planItemID == 0) {
        approvalCheckCount = this.countByUsernameAllTypes(unameKey);
      } else { // if a particular service plan is selected
        approvalCheckCount = this.countByUsername(unameKey);
      }
      // must select either service plan or applies to all
      if (details.appliesToAllInd == false && details.planItemID == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_PLANITEM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      // if service plan is selected, selecting all types is not permitted
      if (details.appliesToAllInd && details.planItemID != 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_APPLIESTOALLIND),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // checking for duplicate approval checks
    if (approvalCheckCount.recordCount != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_FV_TYPE_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are done before data modification.
   *
   * @param key approval check key
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateCancel(PlanItemApprovalCheckKey key)
    throws AppException, InformationalException {

    // Read record status
    PlanItemApprovalCheckStatusDetails approvalCheckStatusDetails = new PlanItemApprovalCheckStatusDetails();

    approvalCheckStatusDetails = this.readStatus(key);

    if (approvalCheckStatusDetails.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_FV_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are done before data modification.
   *
   * @param details approval check dtls
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateModify(PlanItemApprovalCheckKey key,
    PlanItemApprovalCheckDtls details) throws AppException,
      InformationalException {

    // Read record status
    PlanItemApprovalCheckStatusDetails approvalCheckStatusDetails = new PlanItemApprovalCheckStatusDetails();

    approvalCheckStatusDetails = this.readStatus(key);

    if (approvalCheckStatusDetails.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // struct to check for duplicate approval checks
    PlanItemApprovalCheckCount approvalCheckCount = new PlanItemApprovalCheckCount();

    // validate user type service plan approval checks
    if (details.typeCode.equals(PLANITEMAPPROVALCHECK.USER)) {
      // set key details
      final PlanItemApprovalCheckUNModifyKey unameModifyKey = new PlanItemApprovalCheckUNModifyKey();

      unameModifyKey.estimatedCost = details.estimatedCost;
      unameModifyKey.planItemID = details.planItemID;
      unameModifyKey.userName = details.userName;
      unameModifyKey.statusCode = details.statusCode;
      unameModifyKey.planItemApprovalCheckID = details.planItemApprovalCheckID;
      if (details.planItemID == 0) {
        approvalCheckCount = this.countByUsernameAllTypesForModify(
          unameModifyKey);
      } else {
        approvalCheckCount = this.countByUsernameForModify(unameModifyKey);
      }
      // select service plan or applies to all
      if (details.appliesToAllInd == false && details.planItemID == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_PLANITEM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }
    // checking for duplicate approval checks
    if (approvalCheckCount.recordCount != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_FV_TYPE_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are done before data modification.
   *
   * @param key approval check key
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void premodify(PlanItemApprovalCheckKey key,
    PlanItemApprovalCheckDtls details) throws AppException,
      InformationalException {

    // Check the details
    validateDetails(details);

    // Check the modify
    validateModify(key, details);
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are done before data modification.
   *
   * @param key approval check key
   * @param dtls approval check details
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void precancel(PlanItemApprovalCheckKey key,
    CancelPlanItemApprovalCheckDetails dtls) throws AppException,
      InformationalException {

    validateCancel(key);
  }

  // __________________________________________________________________________
  /**
   * Ensures common validations are done before inserting and modifying data.
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateDetails(PlanItemApprovalCheckDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00238338, PF
    // Percentage must be greater than zero & must not be
    // greater than one hundred.
    if (details.percentage < 0
      || details.percentage > CuramConst.gkOneHundredPercent) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_FV_PERCENTAGE_NOT_IN_RANGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Estimated cost cannot be negative.
    if (details.estimatedCost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_FV_ESTIMATED_COST_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.appliesToAllInd == false && details.planItemID != 0) {
      final PlanItem planItemObj = PlanItemFactory.newInstance();
      final PlanItemKey piKey = new PlanItemKey();

      piKey.planItemID = details.planItemID;
      final PlanItemDtls piDtls = planItemObj.read(piKey);

      if (piDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANITEMAPPROVALCHECK.ERR_APPROVALCHECK_XRV_PLANITEM_CANCELED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }
}
