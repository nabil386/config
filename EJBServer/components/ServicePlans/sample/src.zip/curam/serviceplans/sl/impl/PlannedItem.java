/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.APPROVALPROCESSINGSTATUS;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.PIAPPROVALCRITERIASTATUS;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESPONSIBILITYTYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.LOCALEEntry;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainProductDeliveryFurtherDetailsFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainProductDeliveryFurtherDetails;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.ProductDeliveryPlanItemLink;
import curam.core.sl.entity.struct.AbsencePeriodDtlsList;
import curam.core.sl.entity.struct.CaseIDAndVersionNoDetailsList;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.PlannedItemCaseLinkCountDetails;
import curam.core.sl.entity.struct.PlannedItemCaseLinkPlannedItemIDKey;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.MaintainProductDeliveryHeaderDtls;
import curam.core.struct.ProductDeliveryFurtherDetailsKey;
import curam.core.struct.ReadCaseParticipantDetails;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserFullname;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.events.SERVICEPLANAPPROVAL;
import curam.events.SERVICEPLANS;
import curam.message.BPOPAAPPROVALREQUEST;
import curam.message.BPOPLANNEDITEM;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.BPOSERVICEUNITDELIVERY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.AuthorizedUnitHistoryFactory;
import curam.serviceplans.sl.entity.fact.GoodCauseFactory;
import curam.serviceplans.sl.entity.fact.OutcomeFactory;
import curam.serviceplans.sl.entity.fact.PIDailyAttendanceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemApprCritFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemAbsenceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemApprovalCriteriaFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemAttachmentLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemTaskConfigurationFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanContractFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanFactory;
import curam.serviceplans.sl.entity.fact.SubGoalPlanItemLinkFactory;
import curam.serviceplans.sl.entity.fact.TaskConfigurationFactory;
import curam.serviceplans.sl.entity.intf.AuthorizedUnitHistory;
import curam.serviceplans.sl.entity.intf.GoodCause;
import curam.serviceplans.sl.entity.intf.Outcome;
import curam.serviceplans.sl.entity.intf.PIDailyAttendanceLink;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItemApprCrit;
import curam.serviceplans.sl.entity.intf.PlannedItemAbsenceLink;
import curam.serviceplans.sl.entity.intf.PlannedItemApprovalCriteria;
import curam.serviceplans.sl.entity.intf.PlannedItemAttachmentLink;
import curam.serviceplans.sl.entity.intf.PlannedItemTaskConfiguration;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.intf.ServicePlan;
import curam.serviceplans.sl.entity.intf.ServicePlanContract;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.intf.SubGoalPlanItemLink;
import curam.serviceplans.sl.entity.intf.TaskConfiguration;
import curam.serviceplans.sl.entity.struct.AuthorizedUnitHistoryDtls;
import curam.serviceplans.sl.entity.struct.CountPlanItemsBySubGoalIDKey;
import curam.serviceplans.sl.entity.struct.DailyAttendanceAndLinkDtlsList;
import curam.serviceplans.sl.entity.struct.GoodCauseKey;
import curam.serviceplans.sl.entity.struct.IsMandatoryIndResult;
import curam.serviceplans.sl.entity.struct.MultipleContractsAllowedIndStruct;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.OutcomeKey;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtls;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkDetails;
import curam.serviceplans.sl.entity.struct.PlanItemCountDetails;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.PlanItemIDKey;
import curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemAssociatedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemAuthorizedUnits;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemEstimatedCost;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDStatus;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemOwnerDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlannedItemParticipantDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemStatusStruct;
import curam.serviceplans.sl.entity.struct.PlannedItemTaskConfigurationDtls;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalSensitivityCodeDetails;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedSubGoalIDDetails;
import curam.serviceplans.sl.entity.struct.ReadMultipleContractsAllowedByCaseIDKey;
import curam.serviceplans.sl.entity.struct.ReadOwnerDetails;
import curam.serviceplans.sl.entity.struct.ReadSubGoalIDByPlannedSubGoal;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryIssuedAndAcceptStatus;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryCount;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemDetailsList;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemDetailsStruct;
import curam.serviceplans.sl.intf.PlanItem;
import curam.serviceplans.sl.struct.CreatePageDetailsStruct;
import curam.serviceplans.sl.struct.CreatePlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.ModifyAuthorizedUnitsDetails;
import curam.serviceplans.sl.struct.ModifyPageDetailsStruct;
import curam.serviceplans.sl.struct.ModifyPlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaDetailsList;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaLinkKey;
import curam.serviceplans.sl.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.PlanItemParticipantAndReferenceDetails;
import curam.serviceplans.sl.struct.PlanItemSummaryDetailsList;
import curam.serviceplans.sl.struct.PlanItemTypeCodeDetails;
import curam.serviceplans.sl.struct.PlannedItemAndConcernRoleIDDetails;
import curam.serviceplans.sl.struct.PlannedItemAndServiceUnitDetails;
import curam.serviceplans.sl.struct.PlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.PlannedItemIndicator;
import curam.serviceplans.sl.struct.PlannedItemParticipantDetailsList;
import curam.serviceplans.sl.struct.PlannedItemProductDeliveryCreationDetails;
import curam.serviceplans.sl.struct.PlannedSubGoalIDStruct;
import curam.serviceplans.sl.struct.ReadAuthorizedUnitDetailsForModify;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanPlanItemSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSubGoalSecurityKey;
import curam.serviceplans.sl.struct.ServiceUnitDeliveryDetails;
import curam.serviceplans.sl.struct.SubGoalIDDetailsStruct;
import curam.serviceplans.sl.struct.SubGoalKey;
import curam.serviceplans.sl.struct.ValidateResponsibilityDetailsStruct;
import curam.serviceplans.sl.struct.ValidateResponsibilityKey;
import curam.serviceplans.sl.struct.ViewPageDetailsStruct;
import curam.serviceplans.sl.struct.ViewPlannedItemDetails;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


public abstract class PlannedItem extends curam.serviceplans.sl.base.PlannedItem {

  // BEGIN, CR00146458, VR
  @Inject
  protected curam.attachment.impl.Attachment attachment;

  // BEGIN, CR00247170, GP
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  // END, CR00247170

  // BEGIN, CR00417588, RD
  /**
   * Reference to create plan item.
   */
  @Inject(optional = true)
  protected CreatePlannedItemHook createPlannedItemHook;

  // END, CR00417588

  // Add injection for using the new CaseTransactionLog API
  public PlannedItem() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00146458

  /**
   * This method is used to remove a service plan planned item.
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_RV_CLIENT_PARTICIPATION_RECORDED_NO_DELETE}
   * - if the plan item is being deleted.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void removeServicePlanPlanItem(PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // Check service plan security.
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();
    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // BEGIN CR00124860, GBA
    // Client Participation manipulation variables
    final PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();
    PIDailyAttendanceLinkDtlsList piDailyAttendanceLinkDtlsList = new PIDailyAttendanceLinkDtlsList();

    // END CR00124860

    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // get the service plan id based on the case id
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PlannedItemKey
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // Set the ID
    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // We have to do the re calculate here as opposed to the postRemove on
    // entity
    // because the plannedItemID will not exists in the database as it
    // is a physical remove. So the planned sub goal id would not have
    // been able to be read at that stage.
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = plannedItemObj.readPlannedSubGoalIDByPlannedItemID(plannedItemKey).plannedSubGoalID;

    // Check that no client participations are recorded for this plan item.
    // If client participations exist, the plan item cannot be deleted.
    // BEGIN CR00124860, GBA
    piDailyAttendanceLinkDtlsList = piDailyAttendanceLinkObj.searchByPlannedItemID(
      plannedItemKey);

    if (!piDailyAttendanceLinkDtlsList.dtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_CLIENT_PARTICIPATION_RECORDED_NO_DELETE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END CR00124860

    // BEGIN, CR00091347, CM
    // Validations Remove
    validateRemove(plannedItemIDKey.plannedItemIDKey);
    // END, CR00091347

    // BEGIN, CR00161962, KY
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDEntityKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDEntityKey.plannedItemID = plannedItemKey.plannedItemID;

    try {
      // Planned Item Task Configuration manipulation
      final PlannedItemTaskConfiguration plannedItemTaskConfigurationObj = PlannedItemTaskConfigurationFactory.newInstance();

      plannedItemTaskConfigurationObj.removePlannedItemTaskConfiguration(
        plannedItemIDEntityKey);

    } catch (final RecordNotFoundException e) {// No Planned Item Task
      // configuration
      // exists for the planned item
    }

    try {
      // Planned Item Approval Criteria Manipulation
      final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

      plannedItemApprovalCriteriaObj.removePlannedItemApprovalCriteriaByPlannedItemID(
        plannedItemIDEntityKey);

    } catch (final RecordNotFoundException e) {// No Planned Item Approval
      // Criteria
      // details exists for the planned
      // item
    }
    // END, CR00161962
    // Remove the planned item
    plannedItemObj.remove(plannedItemKey);

    // Service plans workflow raise event integration
    final Event event = new Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = SERVICEPLANS.DELETEPLANITEM;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemKey.plannedItemID;
    EventService.raiseEvent(event);

    // call method to check dates
    plannedSubGoalObj.reCalculateDatesAndStatus(plannedSubGoalKey);
    // END, HARO 48857.
  }

  /**
   * This method is used to validate the details of a planned item.
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   */
  @Override
  public void validatePlannedItemDetails(PlannedItemIDKey plannedItemIDKey,
    String status) throws AppException, InformationalException {

    // The PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // The CaseHeader Object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    // Get the caseID
    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);

    // Set the caseHeaderKey
    caseHeaderKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    // Read the Case Status
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // If the case is closed closed then throw validation
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDITEM.ERR_SERVICEPLAN_XRV_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    PlannedItemDtls plannedItemDtls = new PlannedItemDtls();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    plannedItemDtls = plannedItemObj.read(plannedItemKey);

    // Read the Case Reference
    CaseReference caseReference = new CaseReference();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = caseHeaderKey.caseID;
    caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    // read OwnerUserName
    PlannedItemOwnerDetailsStruct plannedItemOwnerDetailsStruct = new PlannedItemOwnerDetailsStruct();

    plannedItemOwnerDetailsStruct = plannedItemObj.readOwner(
      plannedItemIDKey.plannedItemIDKey);

    // read Current User
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // User maintenance business process object
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // Read the user details
    final UsersKey usersKey = new UsersKey();
    UserFullname userFullName;

    usersKey.userName = systemUserDtls.userName;
    userFullName = usersObj.getFullName(usersKey);

    // variables used to create a notification
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

    // BEGIN, CR00333044, GYH
    standardManualDtls.dtls.concerningDtls.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    // END, CR00333044

    String planItemStatus = new String();

    boolean sendNotification = false;

    if (status.equals(PLANNEDITEMSTATUS.SUBMITTED)) {

      // retrieve environment variable
      String genPlanItemSubmitted = Configuration.getProperty(
        EnvVars.ENV_GENPLANITEMSUBMITTEDTICKET);

      // check that the variable has been populated, if not, use default
      // variable
      if (genPlanItemSubmitted == null) {

        genPlanItemSubmitted = EnvVars.ENV_GENPLANITEMSUBMITTEDTICKET_DEFAULT;
      }

      // check the notification environment variable when submitting
      // a plan item for approval
      if (genPlanItemSubmitted.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

        sendNotification = true;

        planItemStatus = BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_SUBMITTED_FOR_APPROVAL.getMessageText();
      }
    } else if (status.equals(PLANNEDITEMSTATUS.REJECTED)) {

      // retrieve environment variable
      String genPlanItemRejected = Configuration.getProperty(
        EnvVars.ENV_GENPLANITEMREJECTEDTICKET);

      // check that the variable has been populated, if not, use default
      // variable
      if (genPlanItemRejected == null) {

        genPlanItemRejected = EnvVars.ENV_GENPLANITEMREJECTEDTICKET_DEFAULT;
      }

      // check the notification environment variable when submitting
      // a plan item for approval
      if (genPlanItemRejected.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

        sendNotification = true;

        planItemStatus = BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_REJECT.getMessageText();
      }
    } else if (status.equals(PLANNEDITEMSTATUS.APPROVED)) {

      // retrieve environment variable
      String genPlanItemApproved = Configuration.getProperty(
        EnvVars.ENV_GENPLANITEMAPPROVEDTICKET);

      // check that the variable has been populated, if not, use default
      // variable
      if (genPlanItemApproved == null) {

        genPlanItemApproved = EnvVars.ENV_GENPLANITEMAPPROVEDTICKET_DEFAULT;
      }

      // check the notification environment variable when submitting
      // a plan item for approval
      if (genPlanItemApproved.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

        sendNotification = true;

        planItemStatus = BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_APPROVED.getMessageText();
      }
    }

    // only send notifications if we get past environment variable setting
    if (sendNotification) {

      // set subject and comments
      final AppException subjectText = new AppException(

        curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_CHANGE_SUBJECT);

      subjectText.arg(plannedItemDtls.name);
      subjectText.arg(planItemStatus);

      final AppException commentsText = new AppException(

        curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_CHANGE_COMMENTS);

      // Set up the text
      commentsText.arg(plannedItemDtls.name);
      commentsText.arg(caseReference.caseReference);
      commentsText.arg(planItemStatus);

      commentsText.arg(userFullName.fullname);

      // BEGIN, CR00163659, CL
      // Set the notification for the two possible types of messages
      standardManualDtls.dtls.taskDtls.subject = subjectText.getMessage(
        TransactionInfo.getProgramLocale());
      standardManualDtls.dtls.taskDtls.comments = commentsText.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163659
      // BEGIN, CR00053248, GM
      standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;

      // END, CR00053248

      // If the current user is not the plan item owner send a
      // notification to the plan item owner
      if (!systemUserDtls.userName.equals(
        plannedItemOwnerDetailsStruct.ownerUserName)) {

        // Send Notification to the plan item owner
        standardManualDtls.dtls.assignDtls.assignmentID = plannedItemOwnerDetailsStruct.ownerUserName;

        notificationObj.createWorkAllocationNotification(standardManualDtls);
      }

      // BEGIN, CR00060051, PMD
      //
      // Check if the user is the owner of the case or part of any
      // organization object that owns the case. If not then send
      // notification to all the owner(s)
      //
      // Set the user name key to be the current user
      final UserNameKey userNameKey = new UserNameKey();

      userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

      if (!caseUserRoleObj.isUserCaseOwner(userNameKey, caseHeaderKey).ownerInd) {

        // Send Notification to the plan owner(s)
        standardManualDtls.dtls.concerningDtls.caseID = caseHeaderKey.caseID;
        notificationObj.sendCaseOwnerNotification(standardManualDtls);
      }
      // END, CR00060051
    }
  }

  // BEGIN, CR00235251, TV
  /**
   * This method is used to create a Service Plan Basic Plan Item.
   *
   * @param createPlannedItemDetailsStruct
   * Contains the details of the planned item to be created.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_PARTICIPANT_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to add a plan
   * item to this sub goal.
   * @deprecated Since Curam v6, replaced with
   * {@link createBasicPlanItemDetails}.
   * Reason:- As per code line issue, the
   * attribute 'planTemplatePlanItemID' removed from
   * 'CreatePlannedItemDetailsStruct' struct and added into
   * 'PlannedItemDetailsStruct' struct along with existing attribute
   * of 'CreatePlannedItemDetailsStruct' struct.
   * See release note <CR00235251>
   */
  @Override
  @Deprecated
  public void createBasicPlanItem(
    curam.serviceplans.sl.struct.CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // Manipulation Objects
    final curam.serviceplans.sl.struct.PlannedItemDetailsStruct plannedItemDetailsStruct = new curam.serviceplans.sl.struct.PlannedItemDetailsStruct();

    // Assign objects
    plannedItemDetailsStruct.assign(createPlannedItemDetailsStruct);
    // Call Create method
    createBasicPlanItemDetails(plannedItemDetailsStruct);
  }

  // END, CR00235251

  /**
   * This method is used to create a planned item.
   *
   * @param createPlannedItemDetailsStruct
   * details of the planned item to be created.
   */
  @Override
  public void createServicePlanPlanItem(
    CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // insert the planned item details
    plannedItemObj.insert(createPlannedItemDetailsStruct.plannedItemDtls);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATEPLANITEM;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = createPlannedItemDetailsStruct.plannedItemDtls.planItemID;
    curam.util.events.impl.EventService.raiseEvent(event);

    // BEGIN, CR00161962, KY
    // Raise an event for the approve plan item workflow to be enacted
    // This is for 'not started' status planned items, i.e. auto approved
    // This ensures complete processing of those planned items
    if (createPlannedItemDetailsStruct.plannedItemDtls.status.equals(
      PLANNEDITEMSTATUS.NOTSTARTED)) {

      // Service plans workflow raise event integration

      event.eventKey = curam.events.SERVICEPLANAPPROVAL.AUTOAPPROVEDPLANITEM;

      event.primaryEventData = createPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

      curam.util.events.impl.EventService.raiseEvent(event);

    }
  }

  /**
   * This method is used to modify a Service Plan Basic Plan Item.
   *
   * @param modifyPlannedItemDetailsStruct
   * details of the planned item to be modified.
   *
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_ACTUAL_DATES_CANNOT_BE_MODIFIED}
   * - if actual start and end date is being modified.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_MODIFY_PARTICIPANT_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to modify this
   * plan item.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_FV_CONCERNING_PARTICIPANT_MANDATORY}
   * - if the Concerning Participant is not entered.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_FV_ASSOCIATED_WITH_PRODUCT_DELIVERY_NO_MODIFY}
   * - if the plan item is being modified.
   */
  @Override
  public void modifyBasicPlanItem(
    ModifyPlannedItemDetailsStruct modifyPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // Check service plan security.
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    // Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Planned SubGoal Object
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    // Service Plan Delivery Object
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // need to read the service plan id for security check
    // Read Case ID
    plannedSubGoalKey.plannedSubGoalID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_MODIFY_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    final ValidateResponsibilityKey validateResponsibilityKey = new ValidateResponsibilityKey();
    ValidateResponsibilityDetailsStruct validateResponsibilityDetailsStruct = new ValidateResponsibilityDetailsStruct();

    // BEGIN CR00108989, GBA
    validateResponsibilityKey.responsibilitySetToParticipant = modifyPlannedItemDetailsStruct.responsibilitySetToParticipant;
    validateResponsibilityKey.responsibilitySetToUser = modifyPlannedItemDetailsStruct.responsibilitySetToUser;
    validateResponsibilityKey.plannedSubGoalID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Validate the responsibility
    validateResponsibilityDetailsStruct = validateResponsibility(
      validateResponsibilityKey);

    // BEGIN, CR00079666, MC

    if (modifyPlannedItemDetailsStruct.responsibilitySetToParticipant != 0) {

      modifyPlannedItemDetailsStruct.plannedItemDtls.responsibilityID = validateResponsibilityKey.responsibilitySetToParticipant;

      // Set responsibility type to participant
      modifyPlannedItemDetailsStruct.plannedItemDtls.responsibilityType = RESPONSIBILITYTYPE.PARTICIPANT;

    } else {

      modifyPlannedItemDetailsStruct.plannedItemDtls.respUserName = validateResponsibilityDetailsStruct.userName;

      // Set responsibility type to user
      modifyPlannedItemDetailsStruct.plannedItemDtls.responsibilityType = RESPONSIBILITYTYPE.USER;
    }
    // END CR00108989

    // PlannedItemKey
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // Set the ID of the plannedItem to be modified
    plannedItemKey.plannedItemID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    // if the start date has entered at this stage change status to IN
    // PROGESS
    if (modifyPlannedItemDetailsStruct.plannedItemDtls.actualEndDate.isZero()
      == true
        && modifyPlannedItemDetailsStruct.plannedItemDtls.actualStartDate.isZero()
          == false
          && !modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
            PLANNEDITEMSTATUS.UNAPPROVED)
            // BEGIN, CR00021343, TV
            // BEGIN, HARP 64102,NP
            && !modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
              PLANNEDITEMSTATUS.SUBMITTED)) { // END, HARP
      // 50564 // END

      // HARP 64102
      // END, CR00021343

      modifyPlannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.INPROGRESS;

      // Service plans workflow raise event integration
      final Event event = new Event();

      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK

      event.eventKey = SERVICEPLANS.ACTIVATEPLANITEM;
      // END, HARP 65061
      // END, CR00021588

      event.primaryEventData = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

      EventService.raiseEvent(event);

    }

    // if an actual start and end date have been entered and status is not
    // unapproved, then set status to completed
    if (modifyPlannedItemDetailsStruct.plannedItemDtls.actualStartDate.isZero()
      == false
        && modifyPlannedItemDetailsStruct.plannedItemDtls.actualEndDate.isZero()
          == false
          && !modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
            PLANNEDITEMSTATUS.UNAPPROVED)
            && // BEGIN
            // CR00051981
            // , NRV
            // BEGIN HARP,69936,PN
            !modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
              PLANNEDITEMSTATUS.SUBMITTED)) { // END, HARP
      // 50564
      // END HARP,69936
      // END CR00051981
      modifyPlannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.COMPLETED;

      // Service plans workflow raise event integration
      final Event event = new Event();

      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK

      event.eventKey = SERVICEPLANS.CLOSEPLANITEM;
      // END, HARP 65061
      // END, CR00021588

      event.primaryEventData = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

      EventService.raiseEvent(event);

    }

    // cannot edit a plan item of status unapproved
    if (modifyPlannedItemDetailsStruct.plannedItemDtls.actualStartDate.isZero()
      == true
        && modifyPlannedItemDetailsStruct.plannedItemDtls.actualEndDate.isZero()
          == true
          && !modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
            PLANNEDITEMSTATUS.UNAPPROVED) // BEGIN
            // CR00051981,
            // NRV
            // BEGIN,HARP 69936,PN
            && !modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
              PLANNEDITEMSTATUS.SUBMITTED)) { // END, HARP
      // 50564

      modifyPlannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.NOTSTARTED;
      // END HARP,69936
      // END CR00051981
    }

    // If the planned Item has a status of "Unapproved". Then a change in
    // dates
    // should
    // not affect the status of the planned Item. The only way an unapproved
    // item should
    // change to "NOT STARTED" is when the user submits it for approval.
    if (modifyPlannedItemDetailsStruct.plannedItemDtls.status.equals(
      PLANNEDITEMSTATUS.UNAPPROVED)) {

      modifyPlannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.UNAPPROVED;
    }

    // Product Delivery Planned Item link entity object
    final ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = ProductDeliveryPlanItemLinkFactory.newInstance();
    final PlannedItemCaseLinkPlannedItemIDKey plannedItemCaseLinkPlannedItemIDKey = new PlannedItemCaseLinkPlannedItemIDKey();

    // set planned item ID key
    plannedItemCaseLinkPlannedItemIDKey.plannedItemID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    // count product deliveries associated
    final PlannedItemCaseLinkCountDetails plannedItemCaseLinkCountDetails = productDeliveryPlanItemLinkObj.countByPlannedItemID(
      plannedItemCaseLinkPlannedItemIDKey);

    // BEGIN, CR00021588, TV

    // BEGIN, HARP 66537, PAD
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();
    final ProductDeliveryPlanItemLink productDeliveryPlanItemLink = ProductDeliveryPlanItemLinkFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    plannedItemIDKey.plannedItemID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    // if there is a closed product delivery associated with the planned
    // item
    // then it must not be modified.
    if (plannedItemCaseLinkCountDetails.recordCount > 0) {
      // Get the caseID
      readCaseIDByPlannedItemDetailsStruct = productDeliveryPlanItemLink.readCaseIDByPlannedItemID(
        plannedItemIDKey);

      // Set the caseHeaderKey
      caseHeaderKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
      // Read the Case Status
      caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

      if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_ASSOCIATED_WITH_PRODUCT_DELIVERY_NO_MODIFY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, HARP 66537
    // END, CR00021588

    // BEGIN, CR00047614, JM
    // If the plan item is associated with a product delivery the actual
    // start
    // and end
    // dates of the plan item cannot be updates manually
    if (plannedItemCaseLinkCountDetails.recordCount > 0
      && (modifyPlannedItemDetailsStruct.plannedItemDtls.actualStartDate.isZero()
        == false
          || modifyPlannedItemDetailsStruct.plannedItemDtls.actualEndDate.isZero()
            == false)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_ACTUAL_DATES_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00047614

    // BEGIN CR00108989, GBA
    // If concerningID from UI is zero, read from database if exists
    if (modifyPlannedItemDetailsStruct.plannedItemDtls.concerningID == 0) {

      final PlannedItemDtls plannedItemDtls = plannedItemObj.read(
        plannedItemKey);

      if (plannedItemDtls.concerningID != 0) {
        modifyPlannedItemDetailsStruct.plannedItemDtls.concerningID = plannedItemDtls.concerningID;
        modifyPlannedItemDetailsStruct.plannedItemDtls.versionNo = plannedItemDtls.versionNo;

      } else { // throw exception to enter concerning participant
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_CONCERNING_PARTICIPANT_MANDATORY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    // END CR00108989

    // modify the basic plan item details
    plannedItemObj.modify(plannedItemKey,
      modifyPlannedItemDetailsStruct.plannedItemDtls);

    // Service plans workflow raise event integration
    final Event event = new Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = SERVICEPLANS.MODIFYPLANITEM;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemKey.plannedItemID;
    EventService.raiseEvent(event);

    // case id and version no details list
    CaseIDAndVersionNoDetailsList caseIDAndVersionNoDetailsList;

    // CaseHeader manipulation variables
    final MaintainProductDeliveryFurtherDetails maintainProductDeliveryFurtherDetailsObj = MaintainProductDeliveryFurtherDetailsFactory.newInstance();
    final ProductDeliveryFurtherDetailsKey productDeliveryFurtherDetailsKey = new ProductDeliveryFurtherDetailsKey();

    MaintainProductDeliveryHeaderDtls maintainProductDeliveryHeaderDtls;

    // list associated product deliveries
    caseIDAndVersionNoDetailsList = productDeliveryPlanItemLinkObj.searchCaseIDAndVersionNoByPlannedItemID(
      plannedItemCaseLinkPlannedItemIDKey);

    for (int i = 0; i < caseIDAndVersionNoDetailsList.dtls.size(); i++) {

      // set the key
      productDeliveryFurtherDetailsKey.caseID = caseIDAndVersionNoDetailsList.dtls.item(i).caseID;

      // read case header details
      maintainProductDeliveryHeaderDtls = maintainProductDeliveryFurtherDetailsObj.readCaseHeader1(productDeliveryFurtherDetailsKey).details;

      // set modification details
      maintainProductDeliveryHeaderDtls.expectedEndDate = modifyPlannedItemDetailsStruct.plannedItemDtls.expectedEndDate;
      maintainProductDeliveryHeaderDtls.startDate = modifyPlannedItemDetailsStruct.plannedItemDtls.expectedStartDate;
      maintainProductDeliveryHeaderDtls.expectedOutcome = modifyPlannedItemDetailsStruct.plannedItemDtls.expectedOutcomeID;
      maintainProductDeliveryHeaderDtls.actualOutcome = modifyPlannedItemDetailsStruct.plannedItemDtls.outcomeAchieved;

      // modify case header
      maintainProductDeliveryFurtherDetailsObj.modifyCaseHeaderInSyncWithAssociatedPlanItem(
        maintainProductDeliveryHeaderDtls);
    }
  }

  /**
   * This method is used to modify a planned item.
   *
   * @param modifyPlannedItemDetailsStruct
   * details of the planned item to be modified.
   */
  @Override
  public void modifyServicePlanPlanItem(
    ModifyPlannedItemDetailsStruct modifyPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // PlannedItemKey
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // Set the ID of the plannedItem to be modified
    plannedItemKey.plannedItemID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    // modify the planned item details
    plannedItemObj.modify(plannedItemKey,
      modifyPlannedItemDetailsStruct.plannedItemDtls);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.MODIFYPLANITEM;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemKey.plannedItemID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  /**
   * This method is used to validate the create details.
   *
   * @param createPlannedItemDetailsStruct
   * details of the planned item to be created.
   */
  @Override
  public CreatePlannedItemDetailsStruct validateCreateDetails(
    CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // PlannedSubGoal Object
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    ReadOwnerDetails readOwnerDetails = new ReadOwnerDetails();
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    PlannedSubGoalSensitivityCodeDetails plannedSubGoalSensitivityCodeDetails = new PlannedSubGoalSensitivityCodeDetails();

    // Is planned sub goal id specified
    if (createPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_PLANNED_SUBGOAL_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Set the planned sub goal id
    plannedSubGoalKey.plannedSubGoalID = createPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Read the SubGoalOwners sensitivity
    plannedSubGoalSensitivityCodeDetails = plannedSubGoalObj.readSensitivityCode(
      plannedSubGoalKey);

    // Is the sensitivity level lower than the selected sub goal?
    if (Integer.parseInt(
      createPlannedItemDetailsStruct.plannedItemDtls.sensitivityCode)
        < Integer.parseInt(plannedSubGoalSensitivityCodeDetails.sensitivityCode)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XRV_SUBGOAL_SENSITIVITY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Have multiple owners been selected?
    if (createPlannedItemDetailsStruct.ownerSetToSubGoalOwnerInd == true
      && createPlannedItemDetailsStruct.ownerSetToUser.length() != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_MULTIPLE_OWNER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    } else {

      // Is the owner set to the sub goal owner?
      if (createPlannedItemDetailsStruct.ownerSetToSubGoalOwnerInd == true
        && createPlannedItemDetailsStruct.ownerSetToUser.length() == 0) {

        // Read the SubGoal Owner
        readOwnerDetails = plannedSubGoalObj.readOwner(plannedSubGoalKey);

        // Set them as the owner
        createPlannedItemDetailsStruct.plannedItemDtls.ownerUserName = readOwnerDetails.ownerID;

      } else {

        // Is the owner set to a user?
        if (createPlannedItemDetailsStruct.ownerSetToSubGoalOwnerInd == false
          && createPlannedItemDetailsStruct.ownerSetToUser.length() != 0) {

          createPlannedItemDetailsStruct.plannedItemDtls.ownerUserName = createPlannedItemDetailsStruct.ownerSetToUser;

        } else {

          // Has the owner option not been selected?
          if (createPlannedItemDetailsStruct.ownerSetToSubGoalOwnerInd == false

            && createPlannedItemDetailsStruct.ownerSetToUser.length() == 0) {

            // This is the default
            // Set the current user as the owner
            createPlannedItemDetailsStruct.plannedItemDtls.ownerUserName = systemUserDtls.userName;

          }
        }
      }
    }

    // BEGIN, CR00161962, KY
    // Set the approvalProcessingStatus attribute
    createPlannedItemDetailsStruct.plannedItemDtls.approvalProcessingStatus = APPROVALPROCESSINGSTATUS.NOT_STARTED;
    // END, CR00161962
    // Return the input struct having updated and set the responsibility and
    // owner
    // fields based on the indicators set from the input
    return createPlannedItemDetailsStruct;

  }

  // BEGIN, CR00428820, RD
  /**
   * Populates the Responsibility details to the planned Item.
   *
   * @param plannedItemDetailsStruct Planned Item details
   * @return PLanned Item details with responsibility details updated.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected PlannedItemDetailsStruct populateResponsibilityDetails(
    PlannedItemDetailsStruct plannedItemDetailsStruct) throws AppException,
      InformationalException {

    final PlannedItemDetailsStruct returnPlannedItemDetailsStruct = new PlannedItemDetailsStruct();

    returnPlannedItemDetailsStruct.assign(plannedItemDetailsStruct);

    if (plannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_PLANNED_SUBGOAL_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    final ValidateResponsibilityKey validateResponsibilityKey = new ValidateResponsibilityKey();

    ValidateResponsibilityDetailsStruct validateResponsibilityDetailsStruct = new ValidateResponsibilityDetailsStruct();

    validateResponsibilityKey.responsibilitySetToMeInd = plannedItemDetailsStruct.responsibilitySetToMeInd;

    validateResponsibilityKey.responsibilitySetToUser = plannedItemDetailsStruct.responsibilitySetToUser;

    validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd = plannedItemDetailsStruct.responsibilitySetToSubGoalOwnerInd;

    // BEGIN CR00108989, GBA
    validateResponsibilityKey.responsibilitySetToParticipant = plannedItemDetailsStruct.responsibilitySetToParticipant;
    // END CR00108989

    validateResponsibilityKey.plannedSubGoalID = plannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Validate the responsibility
    validateResponsibilityDetailsStruct = validateResponsibility(
      validateResponsibilityKey);

    // Only one of the fields will be set either username or
    // responsibilityID
    if (validateResponsibilityDetailsStruct.userName.length() != 0) {

      returnPlannedItemDetailsStruct.plannedItemDtls.respUserName = validateResponsibilityDetailsStruct.userName;

      if (plannedItemDetailsStruct.responsibilitySetToMeInd) {
        returnPlannedItemDetailsStruct.plannedItemDtls.responsibilityType = curam.codetable.RESPONSIBILITYTYPE.USER;

      } else {

        // Set responsibility type to user
        returnPlannedItemDetailsStruct.plannedItemDtls.responsibilityType = curam.codetable.RESPONSIBILITYTYPE.USER;
      }
    } else {

      // BEGIN CR00108989, GBA
      if (plannedItemDetailsStruct.responsibilitySetToParticipant != 0) {

        returnPlannedItemDetailsStruct.plannedItemDtls.responsibilityID = validateResponsibilityDetailsStruct.responsibilityID;

        // Set responsibility type to participant
        returnPlannedItemDetailsStruct.plannedItemDtls.responsibilityType = curam.codetable.RESPONSIBILITYTYPE.PARTICIPANT;
      } else {

        returnPlannedItemDetailsStruct.plannedItemDtls.responsibilityID = validateResponsibilityDetailsStruct.responsibilityID;

        // Set responsibility type to client
        returnPlannedItemDetailsStruct.plannedItemDtls.responsibilityType = curam.codetable.RESPONSIBILITYTYPE.CLIENT;

      }
      // END CR00108989

    }
    return returnPlannedItemDetailsStruct;
  }

  // END, CR00428820

  /**
   * This method is used to validate the modify details.
   *
   * @param modifyPlannedItemDetailsStruct
   * details of the planned item to be modified.
   */
  @Override
  public void validateModifyDetails(
    ModifyPlannedItemDetailsStruct modifyPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    final ValidateResponsibilityKey validateResponsibilityKey = new ValidateResponsibilityKey();

    validateResponsibilityKey.responsibilitySetToUser = modifyPlannedItemDetailsStruct.responsibilitySetToUser;

    validateResponsibilityKey.plannedSubGoalID = modifyPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    validateResponsibility(validateResponsibilityKey);

  }

  /**
   * This method is used to validate the responsibility details.
   *
   * @param validateResponsibilityKey
   * responsibility details
   *
   * @return details about the user who is deemed to be responsible
   */
  @Override
  public ValidateResponsibilityDetailsStruct validateResponsibility(
    ValidateResponsibilityKey validateResponsibilityKey) throws AppException,
      InformationalException {

    final ValidateResponsibilityDetailsStruct validateResponsibilityDetailsStruct = new ValidateResponsibilityDetailsStruct();

    // System User Details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // PlannedSubGoal Object
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    ReadOwnerDetails readOwnerDetails = new ReadOwnerDetails();
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // BEGIN CR00108989, GBA
    // Has more than one Responsibility option been set?
    if (validateResponsibilityKey.responsibilitySetToMeInd == true
      && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd == true
        || validateResponsibilityKey.responsibilitySetToUser.length() != 0
          && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
            == true
            || validateResponsibilityKey.responsibilitySetToUser.length() != 0
              && validateResponsibilityKey.responsibilitySetToMeInd == true
              || validateResponsibilityKey.responsibilitySetToUser.length()
                != 0
                  && validateResponsibilityKey.responsibilitySetToParticipant
                    != 0
                    || validateResponsibilityKey.responsibilitySetToMeInd
                      == true
                        && validateResponsibilityKey.responsibilitySetToParticipant
                          != 0
                          || validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
                            == true
                              && validateResponsibilityKey.responsibilitySetToParticipant
                                != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_MULTIPLE_RESPONSIBILITY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Has more than one Responsibility option been set?
    if (validateResponsibilityKey.responsibilitySetToMeInd == true
      && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd == true
      && validateResponsibilityKey.responsibilitySetToUser.length() != 0
      && validateResponsibilityKey.responsibilitySetToParticipant != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_MULTIPLE_RESPONSIBILITY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    } else {

      // Is the responsibility set to the current user?
      if (validateResponsibilityKey.responsibilitySetToMeInd == true
        && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
          == false

          && validateResponsibilityKey.responsibilitySetToUser.length() == 0
          && validateResponsibilityKey.responsibilitySetToParticipant == 0) {

        // Set responsibility equal to the current user
        validateResponsibilityDetailsStruct.userName = systemUserDtls.userName;

      } else {

        // Is the responsibility set to the sub goal owner?
        if (validateResponsibilityKey.responsibilitySetToMeInd == false
          && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
            == true

            && validateResponsibilityKey.responsibilitySetToUser.length() == 0
            && validateResponsibilityKey.responsibilitySetToParticipant == 0) {

          // Read the sub goal owner
          plannedSubGoalKey.plannedSubGoalID = validateResponsibilityKey.plannedSubGoalID;

          readOwnerDetails = plannedSubGoalObj.readOwner(plannedSubGoalKey);

          // Set responsibility equal to the sub goal owner
          validateResponsibilityDetailsStruct.userName = readOwnerDetails.ownerID;

        } else {

          // Is the responsibility set to a user?
          if (validateResponsibilityKey.responsibilitySetToMeInd == false
            && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
              == false
              && validateResponsibilityKey.responsibilitySetToUser.length()
                != 0
                && validateResponsibilityKey.responsibilitySetToParticipant
                  == 0) {

            // Set responsibility equal to the user entered
            validateResponsibilityDetailsStruct.userName = validateResponsibilityKey.responsibilitySetToUser;

          } else // Is the responsibility set to service plan participant?
          if (validateResponsibilityKey.responsibilitySetToMeInd == false
            && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
              == false
              && validateResponsibilityKey.responsibilitySetToUser.length()
                == 0
                && validateResponsibilityKey.responsibilitySetToParticipant
                  != 0) {

            // Set participant ID to the output
            validateResponsibilityDetailsStruct.responsibilityID = validateResponsibilityKey.responsibilitySetToParticipant;
            // END CR00108989

          } else {

            // Has no responsibility option been set?
            if (validateResponsibilityKey.responsibilitySetToMeInd == false
              && validateResponsibilityKey.responsibilitySetToSubGoalOwnerInd
                == false
                && validateResponsibilityKey.responsibilitySetToUser.length()
                  == 0) {

              // This is the default where the client is deemed
              // responsible
              // Read the current client and set responsibility
              // equal to the
              // concern role of case participant

              // The CaseHeader Object
              final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

              ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = new ReadCaseIDByPlannedSubGoalIDDetails();

              ReadCaseParticipantDetails readCaseParticipantDetails = new ReadCaseParticipantDetails();

              final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

              // Set the subgoalID
              plannedSubGoalKey.plannedSubGoalID = validateResponsibilityKey.plannedSubGoalID;

              // Get the caseID
              readCaseIDByPlannedSubGoalIDDetails = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(
                plannedSubGoalKey);

              // Set the caseHeaderKey
              caseHeaderKey.caseID = readCaseIDByPlannedSubGoalIDDetails.caseID;

              // Read the case participant details
              readCaseParticipantDetails = caseHeaderObj.readCaseParticipantDetails(
                caseHeaderKey);

              // Set Client ID to the output
              validateResponsibilityDetailsStruct.responsibilityID = readCaseParticipantDetails.concernRoleID;

            }
          }
        }
      }
    }

    return validateResponsibilityDetailsStruct;
  }

  /**
   * This method is used to read the create page associated with a Planned Item.
   * The create page details and parameters are stored on the plan item entity.
   *
   * @param planItemIDDetailsStruct
   * details of the plan item that holds the create page details.
   */
  @Override
  public CreatePageDetailsStruct readCreatePageDetails(
    PlanItemIDDetailsStruct planItemIDDetailsStruct) throws AppException,
      InformationalException {

    // Return Struct
    CreatePageDetailsStruct createPageDetailsStruct = new CreatePageDetailsStruct();

    // Validate the Read Page Details
    createPageDetailsStruct = validateReadCreatePageDetails(
      planItemIDDetailsStruct);

    // Return the details of the create Page
    return createPageDetailsStruct;

  }

  /**
   * This method is used to read the modify page associated with a Planned Item.
   * The modify page details and parameters are stored on the plan item entity.
   *
   * @param plannedItemIDKey
   * details of the planned item that relates to the modify page
   * details.
   */
  @Override
  public ModifyPageDetailsStruct readModifyPage(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return Struct
    ModifyPageDetailsStruct modifyPageDetailsStruct = new ModifyPageDetailsStruct();

    // Validate the Modify Page Details
    modifyPageDetailsStruct = validateReadModifyPage(plannedItemIDKey);

    // Return the details of the modify Page
    return modifyPageDetailsStruct;

  }

  /**
   * This method is used to read the view page associated with a Planned Item.
   * The view page details and parameters are stored on the plan item entity.
   *
   * @param plannedItemIDKey
   * details of the planned item that relates to the view page details.
   */
  @Override
  public ViewPageDetailsStruct readViewPage(PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return Struct
    ViewPageDetailsStruct viewPageDetailsStruct = new ViewPageDetailsStruct();

    // Validate the View Page Details
    viewPageDetailsStruct = validateReadViewPage(plannedItemIDKey);

    // Return the details of the view Page
    return viewPageDetailsStruct;
  }

  /**
   * This method is used to validate the create page details associated with a
   * Planned Item.
   *
   * @param planItemIDDetailsStruct
   * details of the planned item that relates to the create page
   * details.
   */
  @Override
  public CreatePageDetailsStruct validateReadCreatePageDetails(
    PlanItemIDDetailsStruct planItemIDDetailsStruct) throws AppException,
      InformationalException {

    // Return Struct that holds the URL details
    final CreatePageDetailsStruct createPageDetailsStruct = new CreatePageDetailsStruct();

    // PlanItem Object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // PlanItem ID Key
    final PlanItemIDAndStatusKey planItemIDAndStatusKey = new PlanItemIDAndStatusKey();

    // Set the Key from the input
    planItemIDAndStatusKey.planItemID = planItemIDDetailsStruct.planItemIDDetailsStruct.planItemID;

    // Set the Key from the input
    planItemIDAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;

    // read the create page name
    createPageDetailsStruct.createPageName.createPageName = planItemObj.readCreatePageNameByPlanItemID(planItemIDAndStatusKey).createPageName;

    // read the plan item parameter name
    createPageDetailsStruct.planItemParameterName.createPagePlanItemIDParamName = planItemObj.readCreatePlanItemParameterByPlanItemID(planItemIDAndStatusKey).createPagePlanItemIDParamName;

    // read the URL details
    createPageDetailsStruct.subGoalParameterName.createPageSubGoalIDParamName = planItemObj.readCreateSubGoalParameterByPlanItemID(planItemIDAndStatusKey).createPageSubGoalIDParamName;

    // Check if a create page has been defined
    if (createPageDetailsStruct.createPageName.createPageName.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_CREATE_PAGE_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Check if a create plan item parameter name has been defined
    if (createPageDetailsStruct.planItemParameterName.createPagePlanItemIDParamName.length()
      == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_CREATE_SUBGOAL_PARAMETER_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Check if a create sub goal parameter names has been defined
    if (createPageDetailsStruct.subGoalParameterName.createPageSubGoalIDParamName.length()
      == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_CREATE_PLAN_ITEM_PARAMETER_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return createPageDetailsStruct;
  }

  /**
   * This method is used to validate the view page details associated with a
   * Planned Item.
   *
   * @param plannedItemIDKey
   * details of the planned item that relates to the view page details.
   */
  @Override
  public ViewPageDetailsStruct validateReadViewPage(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return Struct that holds the URL details
    final ViewPageDetailsStruct viewPageDetailsStruct = new ViewPageDetailsStruct();

    // PlanItem Object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // If a user attempts to view a planned item for a baseline plan item
    // where
    // the
    // planned item has been deleted - then an error should be thrown to
    // inform
    // them that the planned item has been deleted.
    // This should be the only case where a planned item id been passed in
    // is
    // invalid.
    boolean plannedItemNotExist = false;

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    try {
      plannedItemObj.read(plannedItemKey);
    } catch (final RecordNotFoundException e) {
      plannedItemNotExist = true;
    }

    if (plannedItemIDKey.plannedItemIDKey.plannedItemID != 0
      && plannedItemNotExist == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOBASELINE.BASELINE_PLAN_ITEM_RV_PLANNED_ITEM_DELETED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // PlanItem ID Key
    final PlanItemIDKey planItemIDKey = new PlanItemIDKey();
    final PlanItemIDDetailsStruct planItemIDDetailsStruct = new PlanItemIDDetailsStruct();

    planItemIDDetailsStruct.planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
      plannedItemIDKey.plannedItemIDKey);

    planItemIDKey.planItemID = planItemIDDetailsStruct.planItemIDDetailsStruct.planItemID;

    // read the URL details
    viewPageDetailsStruct.viewPageDetailsStruct = planItemObj.readViewPageDetailsByPlanItemID(
      planItemIDKey);

    // Check if a view page has been defined
    if (viewPageDetailsStruct.viewPageDetailsStruct.viewPageName.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_VIEW_PAGE_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    return viewPageDetailsStruct;

  }

  /**
   * This method is used to validate the modify page details associated with a
   * Planned Item.
   *
   * @param plannedItemIDKey
   * details of the planned item that relates to the modify page
   * details.
   */
  @Override
  public ModifyPageDetailsStruct validateReadModifyPage(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return Struct that holds the URL details
    final ModifyPageDetailsStruct modifyPageDetailsStruct = new ModifyPageDetailsStruct();

    // PlanItem Object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // PlanItem ID Key
    final PlanItemIDKey planItemIDKey = new PlanItemIDKey();
    final PlanItemIDDetailsStruct planItemIDDetailsStruct = new PlanItemIDDetailsStruct();

    planItemIDDetailsStruct.planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
      plannedItemIDKey.plannedItemIDKey);

    planItemIDKey.planItemID = planItemIDDetailsStruct.planItemIDDetailsStruct.planItemID;

    // read the URL details
    modifyPageDetailsStruct.modifyPageDetailsStruct = planItemObj.readModifyPageDetailsByPlanItemID(
      planItemIDKey);

    // Check if a modify page has been defined
    if (modifyPageDetailsStruct.modifyPageDetailsStruct.modifyPageName.length()
      == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_MODIFY_PAGE_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    return modifyPageDetailsStruct;
  }

  /**
   * This method is used to list all the planItems for a planned subGoal
   *
   * @param plannedSubGoalIDStruct
   * details of the planned subGoal and related case.
   *
   * @return list of planItems defined for a particular subGoal
   */
  @Override
  public curam.serviceplans.sl.struct.PlanItemSummaryDetailsList listPlannedSubGoalPlanItems(PlannedSubGoalIDStruct plannedSubGoalIDStruct)
    throws AppException, InformationalException {

    // SubGoal Object
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // List of PlanItems
    final PlanItemSummaryDetailsList planItemSummaryDetailsList = new PlanItemSummaryDetailsList();

    final SubGoalKey subGoalKey = new SubGoalKey();

    SubGoalIDDetailsStruct subGoalIDDetailsStruct = new SubGoalIDDetailsStruct();

    // Validate the details
    subGoalIDDetailsStruct = validateListPlannedSubGoalPlanItems(
      plannedSubGoalIDStruct);

    // Set the subGoalID
    subGoalKey.subGoalKey.subGoalID = subGoalIDDetailsStruct.subGoalIDDetailsStruct.subGoalID;

    // BEGIN, CR00247170, GP
    SubGoalPlanItemDetailsStruct subGoalPlanItemDetailsStruct;
    final SubGoalPlanItemDetailsList subGoalPlanItemDetailsList = subGoalObj.searchPlanItemsForSubGoal1(
      subGoalKey.subGoalKey);

    for (final curam.serviceplans.sl.entity.struct.SubGoalPlanItemDetails subGoalPlanItemDetails : subGoalPlanItemDetailsList.dtls.items()) {

      subGoalPlanItemDetailsStruct = new SubGoalPlanItemDetailsStruct();
      subGoalPlanItemDetailsStruct.assign(subGoalPlanItemDetails);
      // Read the localized description.
      if (0 != subGoalPlanItemDetails.descriptionTextID) {

        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          subGoalPlanItemDetails.descriptionTextID);

        subGoalPlanItemDetailsStruct.description = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      planItemSummaryDetailsList.subGoalPlanItemDetailsStructList.dtls.addRef(
        subGoalPlanItemDetailsStruct);
    }
    // END, CR00247170

    // Return List
    return planItemSummaryDetailsList;

  }

  /**
   * This method is used to validate the list of PlanItems associated with a
   * subgoal.
   *
   * @param plannedSubGoalIDStruct
   * details of the planned item that relates to the create page
   * details.
   *
   * @return The sub goal ID.
   *
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_RV_CONTRACT_ISSUED_OR_ACCEPTED_NO_INSERT}
   * - if a new plan item is being added to this service plan as a
   * contract has already been issued or accepted by the client.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_PLANITEMS_DEFINED} -
   * if the Plan Items have not been configured for this sub-goal.
   * Please contact your system administrator.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_PARTICIPANT_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to add a plan
   * item to this sub goal.
   */
  @Override
  public SubGoalIDDetailsStruct validateListPlannedSubGoalPlanItems(
    PlannedSubGoalIDStruct plannedSubGoalIDStruct) throws AppException,
      InformationalException {

    // PlannedSubGoal Object
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    // ServicePlan Object
    final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();

    // SubGoal Object
    final ServicePlanContract servicePlanContractObj = ServicePlanContractFactory.newInstance();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // SubGoalPlanItemLink Object
    final SubGoalPlanItemLink subGoalPlanItemLinkObj = SubGoalPlanItemLinkFactory.newInstance();

    final SubGoalIDDetailsStruct subGoalIDDetailsStruct = new SubGoalIDDetailsStruct();
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    ReadSubGoalIDByPlannedSubGoal readSubGoalIDByByPlannedSubGoal = new ReadSubGoalIDByPlannedSubGoal();

    // read the subGoalID related to the planned SubGoal
    plannedSubGoalKey.plannedSubGoalID = plannedSubGoalIDStruct.plannedSubGoalIDStruct.plannedSubGoalID;

    readSubGoalIDByByPlannedSubGoal = plannedSubGoalObj.readSubGoalIDByPlannedSubGoalID(
      plannedSubGoalKey);

    final CountPlanItemsBySubGoalIDKey countPlanItemsBySubGoalIDKey = new CountPlanItemsBySubGoalIDKey();

    PlanItemCountDetails planItemCountDetails = new PlanItemCountDetails();

    countPlanItemsBySubGoalIDKey.subGoalID = readSubGoalIDByByPlannedSubGoal.subGoalID;

    // count the number of planItems defined for this subGoal
    planItemCountDetails = subGoalPlanItemLinkObj.countPlanItemsBySubGoalID(
      countPlanItemsBySubGoalIDKey);

    // Check to see if planItems have been defined for this subGoal
    if (planItemCountDetails.numPlanItems == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_NO_PLANITEMS_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = new ReadCaseIDByPlannedSubGoalIDDetails();

    plannedSubGoalKey.plannedSubGoalID = plannedSubGoalIDStruct.plannedSubGoalIDStruct.plannedSubGoalID;

    // Read the CaseID
    readCaseIDByPlannedSubGoalIDDetails = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(
      plannedSubGoalKey);

    MultipleContractsAllowedIndStruct multipleContractsAllowedIndStruct = new MultipleContractsAllowedIndStruct();

    final ReadMultipleContractsAllowedByCaseIDKey readMultipleContractsAllowedByCaseIDKey = new ReadMultipleContractsAllowedByCaseIDKey();

    // Set the input struct
    readMultipleContractsAllowedByCaseIDKey.caseID = readCaseIDByPlannedSubGoalIDDetails.caseID;

    // read the multipleContractsAllowed indicator value
    multipleContractsAllowedIndStruct = servicePlanObj.readMultipleContractsAllowedInd(
      readMultipleContractsAllowedByCaseIDKey);

    RecordCount recordCount = new RecordCount();

    final ServicePlanDeliveryIssuedAndAcceptStatus servicePlanDeliveryIssuedAndAcceptStatus = new ServicePlanDeliveryIssuedAndAcceptStatus();

    // Set the input struct
    servicePlanDeliveryIssuedAndAcceptStatus.caseID = readCaseIDByPlannedSubGoalIDDetails.caseID;

    // Check to see if multiple contracts are allowed
    if (multipleContractsAllowedIndStruct.multipleContractsAllowedInd == false) {

      try {

        // check to ensure no contract that are issued OR Accepted
        recordCount = servicePlanContractObj.countIssuAndAccContractsByCaseID(
          servicePlanDeliveryIssuedAndAcceptStatus);

      } catch (final RecordNotFoundException e) {// No
        // contract
        // has been
        // issued
      }

      // Check to see if a contract has been issued OR accepted. If it has
      // then
      // throw an error

      if (recordCount.count > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_CONTRACT_ISSUED_OR_ACCEPTED_NO_INSERT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Check service plan security.
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanSubGoalSecurityKey servicePlanSubGoalSecurityKey = new ServicePlanSubGoalSecurityKey();

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    servicePlanSubGoalSecurityKey.plannedSubGoalKey.key.plannedSubGoalID = plannedSubGoalIDStruct.plannedSubGoalIDStruct.plannedSubGoalID;

    // need to read the service plan id for security check
    // Read Case ID
    plannedSubGoalKey.plannedSubGoalID = plannedSubGoalIDStruct.plannedSubGoalIDStruct.plannedSubGoalID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.subGoalOperationSecurityCheck(
        servicePlanSubGoalSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_PARTICIPANT_CHECK_FAILED);

      } else {
        throw e;
      }
    }

    // Set the return struct that contains the subGoalID
    subGoalIDDetailsStruct.subGoalIDDetailsStruct.subGoalID = readSubGoalIDByByPlannedSubGoal.subGoalID;

    return subGoalIDDetailsStruct;
  }

  /**
   * This method is used to view the planned item details.
   *
   * @param plannedItemIDKey
   * unique id of the planned item
   *
   * @return The planned item details
   *
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view
   * this service plan.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_VIEW_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view this plan
   * item.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewPlannedItemDetails readPlannedItemDetails(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    final ViewPlannedItemDetails viewPlannedItemDetails = new ViewPlannedItemDetails();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Outcome Object
    final Outcome outcomeObj = OutcomeFactory.newInstance();

    final OutcomeKey outcomeKey = new OutcomeKey();

    // Outcome Object
    final GoodCause goodCauseObj = GoodCauseFactory.newInstance();
    final GoodCauseKey goodCauseKey = new GoodCauseKey();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // call entity layer
    viewPlannedItemDetails.plannedItemDtls = plannedItemObj.read(plannedItemKey);

    // BEGIN, CR00236077, NS
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = viewPlannedItemDetails.plannedItemDtls.planItemID;
    final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
      planItemKey);

    if (nameNotEditableIndDetails.nameNotEditableInd) {
      viewPlannedItemDetails.plannedItemDtls.name = CodeTable.getOneItem(
        PLANITEMNAME.TABLENAME, nameNotEditableIndDetails.name,
        TransactionInfo.getProgramLocale());
    }
    // END, CR00236077

    // PlannedSubGoal entity object
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // Read the subgoal name by sub goal id
    plannedSubGoalKey.plannedSubGoalID = viewPlannedItemDetails.plannedItemDtls.plannedSubGoalID;

    viewPlannedItemDetails.subGoalName = plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKey).subGoalName;

    // Read the case id by planendPlanItem id
    viewPlannedItemDetails.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    // Read the outcome name by outcome id
    outcomeKey.outcomeID = viewPlannedItemDetails.plannedItemDtls.expectedOutcomeID;

    viewPlannedItemDetails.outcomeName = outcomeObj.readName(outcomeKey).name;

    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = viewPlannedItemDetails.plannedItemDtls.ownerUserName;
    viewPlannedItemDetails.userFullName = usersObj.getFullName(usersKey).fullname;

    // concernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // viewPlannedItemDetails.
    // if the responsibility set and respUserName not set then set the
    // userName
    // to the name of the concern role
    if (viewPlannedItemDetails.plannedItemDtls.responsibilityID != 0
      && viewPlannedItemDetails.plannedItemDtls.respUserName.length() == 0) {

      // BEGIN CR00108989, GBA
      if (viewPlannedItemDetails.plannedItemDtls.responsibilityType.equals(
        RESPONSIBILITYTYPE.CLIENT)) {

        viewPlannedItemDetails.respSetToClientInd = true;

        // The CaseHeader Object
        final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = viewPlannedItemDetails.caseID;
        viewPlannedItemDetails.planItemRespUserFullName = caseHeaderObj.readCaseConcernRoleName(caseKey).concernRoleName;
      } else {

        viewPlannedItemDetails.respSetToParticipant = viewPlannedItemDetails.plannedItemDtls.responsibilityID;

        // Get Responsible participant name
        concernRoleKey.concernRoleID = viewPlannedItemDetails.respSetToParticipant;

        viewPlannedItemDetails.planItemRespUserFullName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      }
    } else {
      usersKey.userName = viewPlannedItemDetails.plannedItemDtls.respUserName;
      viewPlannedItemDetails.planItemRespUserFullName = usersObj.getFullName(usersKey).fullname;
      viewPlannedItemDetails.planItemResponsibilityName = viewPlannedItemDetails.planItemRespUserFullName;
    }

    // BEGIN CR00109001, GBA
    if (viewPlannedItemDetails.plannedItemDtls.concerningID != 0) {

      // Read Concerning Name and CaseParticipantRoleID by concerningID

      // CaseParticipantRole manipulation variables
      final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
      final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();

      // Set the keys
      concernRoleKey.concernRoleID = viewPlannedItemDetails.plannedItemDtls.concerningID;

      caseIDParticipantRoleKey.caseID = viewPlannedItemDetails.caseID;
      caseIDParticipantRoleKey.participantRoleID = viewPlannedItemDetails.plannedItemDtls.concerningID;

      viewPlannedItemDetails.concerningName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      viewPlannedItemDetails.caseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleID(caseIDParticipantRoleKey).caseParticipantRoleID;

      // Check plan item status - once approved, concerning cannot be
      // modified
      if (viewPlannedItemDetails.plannedItemDtls.status.equals(
        PLANNEDITEMSTATUS.APPROVED)
          || viewPlannedItemDetails.plannedItemDtls.status.equals(
            PLANNEDITEMSTATUS.NOTSTARTED)
            || viewPlannedItemDetails.plannedItemDtls.status.equals(
              PLANNEDITEMSTATUS.INPROGRESS)
              || viewPlannedItemDetails.plannedItemDtls.status.equals(
                PLANNEDITEMSTATUS.COMPLETED)) {
        viewPlannedItemDetails.concerningModifiableInd = false;

      } else {
        viewPlannedItemDetails.concerningModifiableInd = true;
      }

    } else {
      viewPlannedItemDetails.concerningModifiableInd = true;
    }
    // END CR00108989
    // END CR00109001

    // Read the good cause name by good cause id.
    if (viewPlannedItemDetails.plannedItemDtls.goodCauseID != 0) {

      goodCauseKey.goodCauseID = viewPlannedItemDetails.plannedItemDtls.goodCauseID;

      viewPlannedItemDetails.goodCauseName = goodCauseObj.readName(goodCauseKey).name;
    }

    // Check service plan security.
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    // PlannedItem Object
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = viewPlannedItemDetails.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);

    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {

        throw new AppException(BPOPLANNEDITEM.ERR_VIEW_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN, CR00161962, KY
    // Determine if we need to show an information on the screen regarding
    // the
    // planned item's approval processing status. If the planned item status
    // is
    // 'Submitted' and approval processing status isn't 'Not Started'
    // then planned item is in the approval process - i.e. it's being
    // processed
    // so there is no need to try and approve it again. So inform user of
    // this
    if (viewPlannedItemDetails.plannedItemDtls.status.equals(
      PLANNEDITEMSTATUS.SUBMITTED)
        && !viewPlannedItemDetails.plannedItemDtls.approvalProcessingStatus.equals(
          APPROVALPROCESSINGSTATUS.NOT_STARTED)) {

      // Create the informational message
      final AppException appException = new AppException(
        BPOPAAPPROVALREQUEST.INF_PLANNED_ITEM_ALREADY_IN_APPROVAL_PROCESS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }
    // END, CR00161962
    return viewPlannedItemDetails;

  }

  // BEGIN CR00109001, GBA
  /**
   * Method used for getting list of Planned participants for selected planned
   * item (Basic, Custom Basic, Service and Custom Service)
   *
   * @param key
   * - Planned SubGoal ID
   *
   *
   *
   * @return list - List of Planned Participants for selected planned item
   */
  @Override
  public PlannedItemParticipantDetailsList getPlannedParticipantsForPlannedItem(
    curam.serviceplans.sl.struct.PlannedSubGoalKey key)
    throws AppException, InformationalException {

    // Return object having list of planned participants for selected
    // planned item
    final PlannedItemParticipantDetailsList plannedItemParticipantDetailsList = new PlannedItemParticipantDetailsList();
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    plannedItemParticipantDetailsList.list = plannedItemObj.searchPlannedParticipantsForPlannedItem(
      key.key);

    return plannedItemParticipantDetailsList;
  }

  // BEGIN, CR00146503, GBA
  /**
   * Method used for getting list of participants to select Concerning
   *
   * @param key
   * - Planned SubGoal ID
   *
   * @return list - List of Participants
   * @throws AppException
   * , InformationalException
   */
  @Override
  public PlannedItemParticipantDetailsList getParticipantsForConcerning(
    curam.serviceplans.sl.struct.PlannedSubGoalKey key) throws AppException,
      InformationalException {

    // Return object having list of planned participants for selected
    // planned item
    final PlannedItemParticipantDetailsList plannedItemParticipantDetailsList = new PlannedItemParticipantDetailsList();

    final PlannedItemParticipantDetailsList allPlannedItemParticipantDetailsList = getPlannedParticipantsForPlannedItem(
      key);

    PlannedItemParticipantDetails plannedItemParticipantDetails = new PlannedItemParticipantDetails();

    // filter the list : Concerning Participant field for a plan item should
    // display only primary plan participant and plan participants
    for (int i = 0; i < allPlannedItemParticipantDetailsList.list.dtls.size(); i++) {

      plannedItemParticipantDetails = allPlannedItemParticipantDetailsList.list.dtls.item(
        i);

      if (RECORDSTATUS.NORMAL.equals(plannedItemParticipantDetails.recordStatus)) {
        if (CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT.equals(
          plannedItemParticipantDetails.typeCode)
            || CASEPARTICIPANTROLETYPE.PLANPARTICIPANT.equals(
              plannedItemParticipantDetails.typeCode)) {

          plannedItemParticipantDetailsList.list.dtls.add(
            plannedItemParticipantDetails);
        }
      }

    }

    // return planned participants list
    return plannedItemParticipantDetailsList;
  }

  /**
   * Method used for getting list of participants to select Responsibility
   * Participant
   *
   * @param key
   * - Planned SubGoal ID
   *
   * @return list - List of Participants
   * @throws AppException
   * , InformationalException
   */
  @Override
  public PlannedItemParticipantDetailsList getParticipantsForResponsibility(
    curam.serviceplans.sl.struct.PlannedSubGoalKey key) throws AppException,
      InformationalException {

    // Return object having list of planned participants for selected
    // planned item
    final PlannedItemParticipantDetailsList plannedItemParticipantDetailsList = new PlannedItemParticipantDetailsList();

    final PlannedItemParticipantDetailsList allPlannedItemParticipantDetailsList = getPlannedParticipantsForPlannedItem(
      key);

    PlannedItemParticipantDetails plannedItemParticipantDetails = new PlannedItemParticipantDetails();

    // filter the list : Responsibility Participant should only display
    // primary
    // plan participant, plan participants and nominated representatives
    for (int i = 0; i < allPlannedItemParticipantDetailsList.list.dtls.size(); i++) {

      plannedItemParticipantDetails = allPlannedItemParticipantDetailsList.list.dtls.item(
        i);

      if (RECORDSTATUS.NORMAL.equals(plannedItemParticipantDetails.recordStatus)) {
        if (CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT.equals(
          plannedItemParticipantDetails.typeCode)
            || CASEPARTICIPANTROLETYPE.PLANPARTICIPANT.equals(
              plannedItemParticipantDetails.typeCode)
              || CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE.equals(
                plannedItemParticipantDetails.typeCode)) {

          plannedItemParticipantDetailsList.list.dtls.add(
            plannedItemParticipantDetails);
        }
      }

    }

    return plannedItemParticipantDetailsList;
  }

  /**
   * Method used for getting list of Participants to be responsible for selected
   * planned item
   *
   * @param key
   * - Planned Item ID
   *
   * @return list - List of Responsibility Participants for selected planned
   * item
   */
  @Override
  public PlannedItemParticipantDetailsList getResponsibleParticipantsForPlannedItem(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // Return object having list of planned participants for selected
    // planned item
    final PlannedItemParticipantDetailsList plannedItemParticipantDetailsList = new PlannedItemParticipantDetailsList();
    final PlannedItemParticipantDetailsList allPlannedItemParticipantDetailsList = new PlannedItemParticipantDetailsList();

    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    allPlannedItemParticipantDetailsList.list = plannedItemObj.searchResponsibilityParticipantListForPlannedItem(
      key.plannedItemIDKey);
    PlannedItemParticipantDetails plannedItemParticipantDetails = new PlannedItemParticipantDetails();

    // filter the list : Responsibility Participant should only display
    // primary
    // plan participant, plan participants and nominated representatives
    for (int i = 0; i < allPlannedItemParticipantDetailsList.list.dtls.size(); i++) {

      plannedItemParticipantDetails = allPlannedItemParticipantDetailsList.list.dtls.item(
        i);

      if (RECORDSTATUS.NORMAL.equals(plannedItemParticipantDetails.recordStatus)) {
        if (CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT.equals(
          plannedItemParticipantDetails.typeCode)
            || CASEPARTICIPANTROLETYPE.PLANPARTICIPANT.equals(
              plannedItemParticipantDetails.typeCode)
              || CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE.equals(
                plannedItemParticipantDetails.typeCode)) {

          plannedItemParticipantDetailsList.list.dtls.add(
            plannedItemParticipantDetails);
        }
      }

    }
    // END, CR00146503
    return plannedItemParticipantDetailsList;
  }

  // END CR00109001

  /**
   * This method is used to validate that an expected outcome has been specified
   * for the plan item before this planned item can be created or modified.
   *
   * @param planItemKey
   * key containing details of the planned item
   * @param key
   * key containing details of the planned sub goal
   *
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_PARTICIPANT_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to add a plan
   * item to this sub goal.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateOutComeExistsForPlanItem(PlanItemKey planItemKey,
    curam.serviceplans.sl.struct.PlannedSubGoalKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final PlanItemIDKey planItemIDKey = new PlanItemIDKey();

    planItemIDKey.planItemID = planItemKey.key.planItemID;

    // ensure that an outcome exists for planItem
    plannedItemObj.validateExpectedOutcome(planItemIDKey);

    // Check service plan security.
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanSubGoalSecurityKey servicePlanSubGoalSecurityKey = new ServicePlanSubGoalSecurityKey();

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanSubGoalSecurityKey.plannedSubGoalKey.key.plannedSubGoalID = key.key.plannedSubGoalID;

    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // need to read the service plan id for security check
    // Read Case ID
    plannedSubGoalKey.plannedSubGoalID = key.key.plannedSubGoalID;

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;
    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.subGoalOperationSecurityCheck(
        servicePlanSubGoalSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_PARTICIPANT_CHECK_FAILED);

      } else {
        throw e;
      }
    }
  }

  /**
   * Clones planned items.
   *
   * @param clonedPlannedSubGoal
   * Contains unique ID of the planned sub goal being cloned
   * @param newPlannedSubGoal
   * Contains unique ID of the planned sub goal created as a result of
   * cloning
   */
  @Override
  public void clonePlanItemsForServicePlan(
    curam.serviceplans.sl.struct.PlannedSubGoalKey clonedPlannedSubGoal,
    curam.serviceplans.sl.struct.PlannedSubGoalKey newPlannedSubGoal)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    curam.serviceplans.sl.entity.struct.PlannedItemDtlsList plannedItemDtlsList;
    curam.serviceplans.sl.entity.struct.PlannedItemDtls plannedItemDtls;

    final curam.serviceplans.sl.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();
    final curam.core.sl.entity.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    final curam.core.sl.entity.struct.PlannedItemCaseLinkPlannedItemIDKey plannedItemCaseLinkPlannedItemIDKey = new curam.core.sl.entity.struct.PlannedItemCaseLinkPlannedItemIDKey();

    curam.core.sl.entity.struct.ProductDeliveryPlanItemLinkDtlsList productDeliveryPlanItemLinkDtlsList;
    final curam.core.sl.entity.struct.ModifyPlannedItemIDDetails modifyPlannedItemIDDetails = new curam.core.sl.entity.struct.ModifyPlannedItemIDDetails();
    final curam.core.sl.entity.struct.ProductDeliveryPlanItemLinkKey productDeliveryPlanItemLinkKey = new curam.core.sl.entity.struct.ProductDeliveryPlanItemLinkKey();

    // BEGIN, CR00117949 ,MC

    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    final PlanItemKey planItemKey = new PlanItemKey();

    final boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);
    final boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
      closePreviousPlan_default);

    // CaseStatus manipulation variables

    // read current status

    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

    plannedSubGoalKey.plannedSubGoalID = clonedPlannedSubGoal.key.plannedSubGoalID;

    final CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    // BEGIN, CR00224271, ZV
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    // END, CR00117949

    // search for all planItems assigned to the "old" (cloned) planned sub
    // goal
    plannedSubGoalKey.plannedSubGoalID = clonedPlannedSubGoal.key.plannedSubGoalID;

    // BEGIN, CR00117669, MC
    // UniqueID business object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    plannedItemDtlsList = plannedItemObj.searchByPlannedSubGoalID(
      plannedSubGoalKey);

    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();

    AttachmentDtls attachmentDtls;
    final AttachmentKey attachmentKey = new AttachmentKey();
    long attachmentID = 0;

    final PlannedItemAttachmentLinkDtls plannedItemAttachmentLinkDtls = new PlannedItemAttachmentLinkDtls();

    // END, CR00117669

    // BEGIN,CR00124499 ,MC

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = curam.events.SERVICEPLANS.CLONEPLAN;

    // END, CR00124499

    // BEGIN, CR00117949 ,MC

    // iterate the planned items list and clone each of them
    for (int j = 0; j < plannedItemDtlsList.dtls.size(); j++) {
      plannedItemDtls = new curam.serviceplans.sl.entity.struct.PlannedItemDtls();

      if (closePreviousPlan
        && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {

        plannedItemDtls.assign(plannedItemDtlsList.dtls.item(j));

      } else {

        planItemKey.key.planItemID = plannedItemDtlsList.dtls.item(j).planItemID;
        final PlanItemDtls planItemDtls = planItemObj.read(planItemKey.key);

        plannedItemDtls.authorizedUnits = planItemDtls.authorizedUnits;
        plannedItemDtls.maximumUnits = planItemDtls.maximumUnits;
        plannedItemDtls.name = plannedItemDtlsList.dtls.item(j).name;

        plannedItemDtls.planItemID = plannedItemDtlsList.dtls.item(j).planItemID;

        plannedItemDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

        plannedItemDtls.expectedStartDate = plannedItemDtlsList.dtls.item(j).expectedStartDate;
        plannedItemDtls.expectedEndDate = plannedItemDtlsList.dtls.item(j).expectedEndDate;
        plannedItemDtls.expectedOutcomeID = plannedItemDtlsList.dtls.item(j).expectedOutcomeID;
        plannedItemDtls.responsibilityID = plannedItemDtlsList.dtls.item(j).responsibilityID;
        plannedItemDtls.ownerUserName = TransactionInfo.getProgramUser();

        // BEGIN, CR00301226, ZV
        plannedItemDtls.concerningID = plannedItemDtlsList.dtls.item(j).concerningID;
        // END, CR00301226

        if (planItemDtls.requiresApproval) {
          plannedItemDtls.status = curam.codetable.PLANNEDITEMSTATUS.UNAPPROVED;
        } else {
          plannedItemDtls.status = curam.codetable.PLANNEDITEMSTATUS.NOTSTARTED;
        }

      }
      plannedItemDtls.plannedSubGoalID = newPlannedSubGoal.key.plannedSubGoalID;
      plannedItemDtls.plannedItemID = uniqueIDObj.getNextID();

      if (closePreviousPlan
        && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {

        // insert new planned item record
        plannedItemObj.insert(plannedItemDtls);
      } else {
        // BEGIN, CR00235251, TV
        final PlannedItemDetailsStruct createPlannedItemDetailsStruct = new PlannedItemDetailsStruct();

        createPlannedItemDetailsStruct.plannedItemDtls.assign(plannedItemDtls);
        createBasicPlanItemDetails(createPlannedItemDetailsStruct);
        // END, CR00235251
      }

      // BEGIN, CR00000048, PMD
      // Set the original Planned Item Key
      final PlannedItemIDKey clonedPlannedItemIDKey = new PlannedItemIDKey();

      clonedPlannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemDtlsList.dtls.item(j).plannedItemID;

      // Set the new Planned Item Key
      final PlannedItemIDKey newPlannedItemIDKey = new PlannedItemIDKey();

      newPlannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

      // Clone Service Unit Deliveries
      serviceUnitDeliveryObj.clone(clonedPlannedItemIDKey, newPlannedItemIDKey);
      // END, CR00000048

      // BEGIN, CR00120471, PMD
      final PlannedItemIDAndStatusKey plannedItemIDAndStatusKey = new PlannedItemIDAndStatusKey();

      plannedItemIDAndStatusKey.plannedItemID = plannedItemDtlsList.dtls.item(j).plannedItemID;

      plannedItemIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      // Search for daily attendance records
      final DailyAttendanceAndLinkDtlsList dailyAttendanceAndLinkDtlsList = PIDailyAttendanceLinkFactory.newInstance().searchByPlannedItemIDAndStatus(
        plannedItemIDAndStatusKey);

      for (int k = 0; k < dailyAttendanceAndLinkDtlsList.dtls.size(); k++) {

        final DailyAttendanceDtls dailyAttendanceDtls = new DailyAttendanceDtls();

        dailyAttendanceDtls.assign(dailyAttendanceAndLinkDtlsList.dtls.item(k));

        plannedSubGoalKey.plannedSubGoalID = newPlannedSubGoal.key.plannedSubGoalID;

        // Set the caseID to be that of the newly created case
        dailyAttendanceDtls.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

        // Insert the daily attendance record
        DailyAttendanceFactory.newInstance().insert(dailyAttendanceDtls);

        final PIDailyAttendanceLinkDtls piDailyAttendanceLinkDtls = new PIDailyAttendanceLinkDtls();

        piDailyAttendanceLinkDtls.dailyAttendanceID = dailyAttendanceDtls.dailyAttendanceID;
        piDailyAttendanceLinkDtls.plannedItemID = plannedItemDtls.plannedItemID;

        piDailyAttendanceLinkDtls.recordStatus = RECORDSTATUS.NORMAL;

        // Insert the link record
        PIDailyAttendanceLinkFactory.newInstance().insert(
          piDailyAttendanceLinkDtls);
      }

      // END, CR00120471

      // set the key
      plannedItemCaseLinkPlannedItemIDKey.plannedItemID = plannedItemDtlsList.dtls.item(j).plannedItemID;

      // search for product delivery plan item links
      // and update to reflect new planned item
      productDeliveryPlanItemLinkDtlsList = productDeliveryPlanItemLinkObj.searchByPlannedItemID(
        plannedItemCaseLinkPlannedItemIDKey);

      for (int k = 0; k < productDeliveryPlanItemLinkDtlsList.dtls.size(); k++) {

        // set modification details - new planned item ID
        modifyPlannedItemIDDetails.plannedItemID = plannedItemDtls.plannedItemID;
        modifyPlannedItemIDDetails.versionNo = productDeliveryPlanItemLinkDtlsList.dtls.item(k).versionNo;

        // set the key
        productDeliveryPlanItemLinkKey.productDeliveryPlanItemLinkID = productDeliveryPlanItemLinkDtlsList.dtls.item(k).productDeliveryPlanItemLinkID;

        // modify link record
        productDeliveryPlanItemLinkObj.modifyPlannedItemID(
          productDeliveryPlanItemLinkKey, modifyPlannedItemIDDetails);

      }

      if (closePreviousPlan
        && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
        // BEGIN, CR00117669, MC
        // Clone Attachments associated with the service plan

        final PlannedItemKey plannedItemKey = new PlannedItemKey();

        plannedItemKey.plannedItemID = plannedItemDtlsList.dtls.item(j).plannedItemID;

        final PlannedItemAttachmentDetailsList plannedItemAttachmentDetailsList = plannedItemAttachmentLinkObj.searchAttachmentsForPlannedItem(
          plannedItemKey);

        final int noOfAttachments = plannedItemAttachmentDetailsList.dtls.size();

        for (int i = 0; i < noOfAttachments; i++) {

          attachmentKey.attachmentID = plannedItemAttachmentDetailsList.dtls.item(i).attachmentID;
          // BEGIN, CR00146458, VR
          attachmentDtls = attachment.read(attachmentKey);
          final String description = plannedItemAttachmentDetailsList.dtls.item(i).description;

          // BEGIN, CR00170321, NS
          // Set attachment ID to 0, since it is a clone and the new ID must be
          // generated
          attachmentDtls.attachmentID = 0;
          // END, CR00170321
          attachment.insert(attachmentDtls);
          // END, CR00146458
          attachmentID = attachmentDtls.attachmentID;
          // set the attachment id to the new attachment id
          plannedItemAttachmentLinkDtls.plannedItemAttachmentLinkID = uniqueIDObj.getNextID();
          plannedItemAttachmentLinkDtls.attachmentID = attachmentID;
          plannedItemAttachmentLinkDtls.plannedItemID = plannedItemDtls.plannedItemID;
          plannedItemAttachmentLinkDtls.description = description;
          plannedItemAttachmentLinkObj.insert(plannedItemAttachmentLinkDtls);

        }

        // Cloning attachments ends here
        // END, CR00117669
      }

      // BEGIN, CR00124499, MC

      // raise events to be used by enterprise modules for further
      // processing

      event.primaryEventData = plannedItemDtlsList.dtls.item(j).plannedItemID;
      event.secondaryEventData = plannedItemDtls.plannedItemID;
      curam.util.events.impl.EventService.raiseEvent(event);

      // END, CR00124499

    }
    // END, CR00117949

  }

  /**
   * Reads service plan delivery case ID based on planned item ID.
   *
   * @param key
   * Planned Item unique identifier
   *
   * @return Service Plan Delivery unique identifier
   */
  @Override
  public curam.serviceplans.sl.struct.ServicePlanDeliveryKey readCaseID(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // return struct
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // PlannedItem entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    final ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      key.plannedItemIDKey);

    servicePlanDeliveryKey.key.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    return servicePlanDeliveryKey;
  }

  /**
   * Performs service plan operation security check for view planned action
   * details.
   *
   * @param details
   * Planned Item and Concern Role unique identifiers.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateViewPlannedItemSecurity(
    PlannedItemAndConcernRoleIDDetails details) throws AppException,
      InformationalException {

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // set planned action key
    plannedItemKey.plannedItemID = details.plannedItemID;

    // read service plan ID
    final ServicePlanKey servicePlanKey = plannedItemObj.readServicePlanID(
      plannedItemKey);

    // populate security key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = details.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // check security
    servicePlanSecurity.servicePlanOperationSecurityCheck(
      servicePlanOperationSecurityKey);
  }

  /**
   * Checks security for planned action modification.
   *
   * @param details
   * Planned Item and Concern Role unique identifiers
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateModifyPlannedItemSecurity(
    PlannedItemAndConcernRoleIDDetails details) throws AppException,
      InformationalException {

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // set planned action key
    plannedItemKey.plannedItemID = details.plannedItemID;

    // read service plan ID
    final ServicePlanKey servicePlanKey = plannedItemObj.readServicePlanID(
      plannedItemKey);

    // populate security key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = details.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // check security
    servicePlanSecurity.servicePlanOperationSecurityCheck(
      servicePlanOperationSecurityKey);
  }

  /**
   * Checks whether or not an associated product delivery could be created for a
   * planned action.
   *
   * @param details
   * Planned Item and Concern Role unique identifiers
   *
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_SERVICEPLAN_PLAN_ITEM_STATUS_NOTSTARTED} - if the
   * Product Delivery is being created for a plan item that
   * is Not Started.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateProductDeliveryCreation(
    PlannedItemAndConcernRoleIDDetails details) throws AppException,
      InformationalException {

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // set the key
    plannedItemIDKey.plannedItemID = details.plannedItemID;

    // read planned item status
    final PlannedItemStatusStruct plannedItemStatusStruct = plannedItemObj.readStatus(
      plannedItemIDKey);

    if (!plannedItemStatusStruct.status.equals(PLANNEDITEMSTATUS.NOTSTARTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_STATUS_NOTSTARTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // set the key
    plannedItemKey.plannedItemID = details.plannedItemID;

    // read service plan ID
    final ServicePlanKey servicePlanKey = plannedItemObj.readServicePlanID(
      plannedItemKey);

    // populate security key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = details.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

    // check security
    servicePlanSecurity.servicePlanOperationSecurityCheck(
      servicePlanOperationSecurityKey);
  }

  /**
   * Reads details needed for associated case creation
   *
   * @param key
   * Planned Item unique identifier
   *
   * @return planned item product delivery creation details
   */
  @Override
  public PlannedItemProductDeliveryCreationDetails readDetailsForProductDeliveryCreation(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // return value
    final PlannedItemProductDeliveryCreationDetails plannedItemProductDeliveryCreationDetails = new PlannedItemProductDeliveryCreationDetails();

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.entity.struct.PlannedItemKey();

    curam.serviceplans.sl.entity.struct.PlannedItemDtls plannedItemDtls;

    // Plan Item business object
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();
    final curam.serviceplans.sl.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.struct.PlanItemKey();

    curam.serviceplans.sl.struct.AssociatedTypeAndApprovalRequiredDetails associatedTypeAndApprovalRequiredDetails;

    // read case id of the service plan delivery
    plannedItemProductDeliveryCreationDetails.caseID = plannedItemObj.readCaseIDByPlannedItemID(key.plannedItemIDKey).caseID;

    // set planned item key
    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // read planned item details
    plannedItemDtls = plannedItemObj.read(plannedItemKey);

    // set plan item key
    planItemKey.key.planItemID = plannedItemDtls.planItemID;

    // read associated type and approval required identifier
    associatedTypeAndApprovalRequiredDetails = planItemObj.readAssociatedTypeAndApprovalRequestDetails(
      planItemKey);

    // set planned item details
    plannedItemProductDeliveryCreationDetails.expectedStartDate = plannedItemDtls.expectedStartDate;
    plannedItemProductDeliveryCreationDetails.expectedEndDate = plannedItemDtls.expectedEndDate;
    plannedItemProductDeliveryCreationDetails.expectedOutcomeID = plannedItemDtls.expectedOutcomeID;
    plannedItemProductDeliveryCreationDetails.planItemID = plannedItemDtls.planItemID;
    plannedItemProductDeliveryCreationDetails.associatedType = associatedTypeAndApprovalRequiredDetails.dtls.associatedType;
    plannedItemProductDeliveryCreationDetails.requiresApproval = associatedTypeAndApprovalRequiredDetails.dtls.requiresApproval;

    // return the details
    return plannedItemProductDeliveryCreationDetails;
  }

  /**
   * Reads plan item type code for a planned item
   *
   * @param key
   * Planned Item unique identifier
   *
   * @return plan item type code
   */
  @Override
  public PlanItemTypeCodeDetails readPlanItemTypeCode(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // return value
    final PlanItemTypeCodeDetails planItemTypeCodeDetails = new PlanItemTypeCodeDetails();

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.entity.struct.PlannedItemKey();

    // set the key
    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // read plan item type code
    planItemTypeCodeDetails.details = plannedItemObj.readPlanItemTypeCodeByPlannedItemID(
      plannedItemKey);

    // return details
    return planItemTypeCodeDetails;
  }

  // BEGIN, CR00000082, PMD
  /**
   * Reads the service unit delivery planned item details
   *
   * @param key
   * the unique identifier for the planned item.
   * @return The service unit delivery planned item details
   */
  @Override
  public PlannedItemAndServiceUnitDetails readServiceUnitPlannedItemDetails(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Return Object
    final PlannedItemAndServiceUnitDetails plannedItemAndServiceUnitDetails = new PlannedItemAndServiceUnitDetails();

    // Plan Item Object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Service Unit Delivery Object
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // Service Unit Delivery Count
    ServiceUnitDeliveryCount serviceUnitDeliveryCount = new ServiceUnitDeliveryCount();

    PlanItemServiceUnitDeliveryDetails planItemServiceUnitDeliveryDetails = new PlanItemServiceUnitDeliveryDetails();

    // Read the basic planned item details
    plannedItemAndServiceUnitDetails.serviceUnitPlannedItemDetails.viewPlannedItemDetails = readPlannedItemDetails(
      key);

    // Get the units received to date for this planned item
    final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID = key.plannedItemIDKey.plannedItemID;

    serviceUnitDeliveryCount = serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(
      plannedItemIDStatus);

    plannedItemAndServiceUnitDetails.serviceUnitPlannedItemDetails.unitsReceivedToDate = serviceUnitDeliveryCount.count;

    // Get the PlanItemKey
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = plannedItemObj.readPlanItemID(key.plannedItemIDKey).planItemID;

    // Read the service unit delivery specific details
    planItemServiceUnitDeliveryDetails = planItemObj.readPlanItemServiceUnitDeliveryDetails(
      planItemKey);

    plannedItemAndServiceUnitDetails.serviceUnitPlannedItemDetails.unitType = planItemServiceUnitDeliveryDetails.unitType;

    // Get the list of service unit deliveries for this planned item
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // BEGIN, CR00001649, CM
    ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList = new ServiceUnitDeliveryDtlsList();

    serviceUnitDeliveryDtlsList = serviceUnitDeliveryObj.searchByPlannedItemID(
      plannedItemKey);

    // Adding the entity details to the service layer
    for (int i = 0; i < serviceUnitDeliveryDtlsList.dtls.size(); i++) {

      final ServiceUnitDeliveryDetails serviceUnitDeliveryDetails = new ServiceUnitDeliveryDetails();

      serviceUnitDeliveryDetails.dtls = serviceUnitDeliveryDtlsList.dtls.item(i);
      plannedItemAndServiceUnitDetails.serviceUnitDeliveryList.dtlsList.addRef(
        serviceUnitDeliveryDetails);

    }

    // Check if the list is empty
    if (!plannedItemAndServiceUnitDetails.serviceUnitDeliveryList.dtlsList.isEmpty()) {

      // Users manipulation variables
      final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

      final UsersKey usersKey = new UsersKey();

      // Iterate through the list of service unit details
      for (int i = 0; i
        < plannedItemAndServiceUnitDetails.serviceUnitDeliveryList.dtlsList.size(); i++) {

        final ServiceUnitDeliveryDetails serviceUnitDeliveryDetails = new ServiceUnitDeliveryDetails();

        // Need to read administrator's full name
        usersKey.userName = plannedItemAndServiceUnitDetails.serviceUnitDeliveryList.dtlsList.item(i).dtls.recordedBy;

        // Read full name
        serviceUnitDeliveryDetails.recordedByFullName = usersObj.getFullName(usersKey).fullname;

        plannedItemAndServiceUnitDetails.serviceUnitDeliveryList.dtlsList.item(i).recordedByFullName = serviceUnitDeliveryDetails.recordedByFullName;

      }

    }// END, CR00001649

    // BEGIN, CR00161962, KY
    // Determine if we need to show an information on the screen regarding
    // the
    // planned item's approval processing status. If the planned item status
    // is
    // 'Submitted' and approval processing status isn't 'Not Started' then
    // planned item is in the approval process - i.e. it's being processed
    // so
    // there is no need to try and approve it again. So, inform user of this
    if (plannedItemAndServiceUnitDetails.serviceUnitPlannedItemDetails.viewPlannedItemDetails.plannedItemDtls.status.equals(
      PLANNEDITEMSTATUS.SUBMITTED)
        && !plannedItemAndServiceUnitDetails.serviceUnitPlannedItemDetails.viewPlannedItemDetails.plannedItemDtls.approvalProcessingStatus.equals(
          APPROVALPROCESSINGSTATUS.NOT_STARTED)) {

      // Create the informational message
      final AppException appException = new AppException(
        BPOPAAPPROVALREQUEST.INF_PLANNED_ITEM_ALREADY_IN_APPROVAL_PROCESS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
    // END, CR00161962
    return plannedItemAndServiceUnitDetails;
  }

  // END, CR00000082

  // BEGIN, CR00000086, CSH
  /**
   * Reads the authorization unit details for the modify page.
   *
   * @param key
   * The unique identifier for the planned item.
   * @return The authorization unit details for modify.
   */
  @Override
  public ReadAuthorizedUnitDetailsForModify readAuthorizedUnitDetailsForModify(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // Return Object
    final ReadAuthorizedUnitDetailsForModify readAuthorizedUnitDetailsForModify = new ReadAuthorizedUnitDetailsForModify();

    // Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Set the Planned Item Key
    final curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.entity.struct.PlannedItemKey();

    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // Get the PlanItemKey
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = plannedItemObj.readPlanItemID(key.plannedItemIDKey).planItemID;

    // Service Unit Delivery Object
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDelivery = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // Get the units received to date for this planned item
    final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // Populate the return struct
    readAuthorizedUnitDetailsForModify.authorizedUnits = plannedItemObj.read(plannedItemKey).authorizedUnits;

    readAuthorizedUnitDetailsForModify.maximumUnits = plannedItemObj.read(plannedItemKey).maximumUnits;

    readAuthorizedUnitDetailsForModify.unitsReceivedToDate = serviceUnitDelivery.countActiveServiceUnitDeliveryByPlannedItemID(plannedItemIDStatus).count;

    // Return the details to be modified
    return readAuthorizedUnitDetailsForModify;
  }

  /**
   * Modifies the authorization units for the service unit delivery planned item
   * and creates an entry in the authorization history table.
   *
   * @param key
   * the unique identifier for the planned item.
   * @param details
   * the details to be modified.
   *
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * user does not have the appropriate privileges to maintain
   * this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyAuthorizedUnits(PlannedItemIDKey key,
    ModifyAuthorizedUnitsDetails details) throws AppException,
      InformationalException {

    // Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Authorized Unit History Object
    final AuthorizedUnitHistory authorizedUnitHistoryObj = AuthorizedUnitHistoryFactory.newInstance();

    // Authorized Unit History details struct
    final AuthorizedUnitHistoryDtls authorizedUnitHistoryDtls = new AuthorizedUnitHistoryDtls();

    // Authorized Units details struct
    final PlannedItemAuthorizedUnits plannedItemAuthorizedUnits = new PlannedItemAuthorizedUnits();

    // ServicePlanDelivery Object
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // Set the Planned Item Key
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Read Service Plan ID
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // Check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);

    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEUNITDELIVERY.ERR_MODIFY_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Check if the user has the appropriate privileges to modify the
    // authorized
    // units

    servicePlanSecurity.modifyAuthorizedUnitsSecurityCheck(plannedItemIDKey);

    // Populate the modify details struct
    plannedItemAuthorizedUnits.assign(details.authorizedUnitDetails);

    // Modify the authorized units details
    plannedItemObj.modifyAuthorizedUnits(plannedItemIDKey.plannedItemIDKey,
      plannedItemAuthorizedUnits);

    // Service plans workflow raise event integration
    final Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = SERVICEPLANS.MODIFYAUTHORIZEDUNITS;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    EventService.raiseEvent(event);

    // Populate the authorized unit history details struct
    authorizedUnitHistoryDtls.plannedItemID = key.plannedItemIDKey.plannedItemID;

    authorizedUnitHistoryDtls.authorizedDate = Date.getCurrentDate();
    authorizedUnitHistoryDtls.comments = details.comments;
    authorizedUnitHistoryDtls.recordStatus = RECORDSTATUS.NORMAL;
    authorizedUnitHistoryDtls.authorizedUnit = details.authorizedUnitDetails.authorizedUnits;

    authorizedUnitHistoryDtls.authorizedByUser = TransactionInfo.getProgramUser();

    // Create the new authorized unit history record
    authorizedUnitHistoryObj.insert(authorizedUnitHistoryDtls);
  }

  // END, CR00000086

  // BEGIN, CR00001429, CM
  /**
   * Reads service plan delivery participant, type and reference.
   *
   * @param key
   * Contains service plan delivery case ID.
   *
   * @return Service plan delivery participant, type and reference details.
   */
  @Override
  public PlanItemParticipantAndReferenceDetails readParticipantTypeAndReferenceDetails(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // return value
    final PlanItemParticipantAndReferenceDetails piParticipantAndReferenceDetails = new PlanItemParticipantAndReferenceDetails();

    // CaseHeader entity manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // PlannedItem entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    // Read the Case ID
    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      key.plannedItemIDKey);

    // Set the caseID
    caseKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    // read the details from CaseHeader
    piParticipantAndReferenceDetails.caseReferenceCRNameAltNameIDDetails = caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(
      caseKey);

    return piParticipantAndReferenceDetails;
  } // END, CR00001429

  // BEGIN, CR00091347, CM
  /**
   * This method is used to validate the details for removing a planned item.
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   */
  @Override
  public void validateRemove(
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // PlannedItemIndicator struct
    PlannedItemIndicator plannedItemIndicator = new PlannedItemIndicator();

    // BEGIN, CR00092965, CM
    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // ReadCaseIDByPlannedItemDetailsStruct
    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    // CaseHeader entity object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // CaseHeaderKey struct
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // CaseStatusCode struct
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    // END, CR00092965

    // BEGIN, CR00120145, CSH
    AbsencePeriodDtlsList absencePeriodDtlsList = new AbsencePeriodDtlsList();

    final PlannedItemAbsenceLink piAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();

    // END, CR00120145

    // Check if Planned Item is associated with a case
    plannedItemIndicator = isPlannedItemAssociatedWithCase(plannedItemIDKey);

    if (plannedItemIndicator.plannedItemIndicator) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XFV_ASSOCIATED_WITH_CASE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check if Planned Item is associated with planned action associated
    // items
    // BEGIN, CR00093557, CM
    plannedItemIndicator = isPlannedItemAssociated(plannedItemIDKey);
    // END, CR00093557

    if (plannedItemIndicator.plannedItemIndicator) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_ASSOCIATED_ITEM_NO_DELETE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Check if the Planned Items status is 'In Progress' or 'Completed'
    // BEGIN, CR00093557, CM
    plannedItemIndicator = isStatusInProgressOrCompleted(plannedItemIDKey);
    // END, CR00093557

    if (plannedItemIndicator.plannedItemIndicator) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_INPROGRESS_COMPLETED_NO_DELETE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00092965, CM
    // Read the caseID
    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey);

    // Set the Key
    caseHeaderKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    // Read the status of the case
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // If the case is closed then throw an error message
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDITEM.ERR_SERVICEPLAN_XRV_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }
    // END, CR00092965

    // BEGIN, CR00120145, CSH
    // Check that no absences are recorded for this plan item
    absencePeriodDtlsList = piAbsenceLinkObj.searchAbsenceByPlannedItemID(
      plannedItemIDKey);

    // If absence details exist, the plan item cannot be deleted
    if (!absencePeriodDtlsList.dtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_RV_ABSENCE_RECORDED_NO_DELETE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00120145

    // BEGIN, CR00161962, KY
    // validation to check if 'isMandatory' attribute is set as true for the
    // plan item. If this value is set as true, then this planned item
    // cannot
    // be deleted.

    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDEntityKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDEntityKey.plannedItemID = plannedItemIDKey.plannedItemID;

    final curam.serviceplans.sl.entity.struct.IsMandatoryIndResult isMandatoryIndResult = new IsMandatoryIndResult();

    isMandatoryIndResult.assign(isMandatoryIndSet(plannedItemIDEntityKey));

    if (isMandatoryIndResult.isMandatoryInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_MANDATORY_IND_TRUE_NO_DELETE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * This method checks to see if the planned item is associated with a case.
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   */
  @Override
  public PlannedItemIndicator isPlannedItemAssociatedWithCase(
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // Return struct
    final PlannedItemIndicator plannedItemIndicator = new PlannedItemIndicator();

    // Product Delivery Planned Item link entity object and key
    final ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = ProductDeliveryPlanItemLinkFactory.newInstance();
    final PlannedItemCaseLinkPlannedItemIDKey picLinkPlannedItemIDKey = new PlannedItemCaseLinkPlannedItemIDKey();

    // PlannedItemCaseLinkCountDetails struct
    final PlannedItemCaseLinkCountDetails countDetails = new PlannedItemCaseLinkCountDetails();

    // set the key
    picLinkPlannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemID;

    // count planned items associated with a case
    countDetails.recordCount = productDeliveryPlanItemLinkObj.countByPlannedItemID(picLinkPlannedItemIDKey).recordCount;

    // If the planned item is associate with a case the count will be
    // greater the zero, then set the indicator to be true
    if (countDetails.recordCount != 0) {

      plannedItemIndicator.plannedItemIndicator = true;
    }

    return plannedItemIndicator;
  }

  /**
   * This method checks to see if the planned item is linked with an associated
   * items i.e. Product Delivery.
   *
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   */
  // BEGIN, CR00093557, CM
  @Override
  public PlannedItemIndicator isPlannedItemAssociated(
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // END, CR00093557

    // Return struct
    final PlannedItemIndicator plannedItemIndicator = new PlannedItemIndicator();

    // Planned Item entity Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // PlannedItemAssociatedItemDetailsStruct
    PlannedItemAssociatedItemDetailsStruct plannedItemAssociatedItemDetailsStruct = new PlannedItemAssociatedItemDetailsStruct();

    // Read all the planned item associated items
    plannedItemAssociatedItemDetailsStruct = plannedItemObj.readAssociatedItems(
      plannedItemIDKey);

    // If the planned item is linked to any associated items then

    // set the indicator to be true
    if (plannedItemAssociatedItemDetailsStruct.associatedItemIDNumber != 0
      || plannedItemAssociatedItemDetailsStruct.associatedItemIDString != 0) {

      plannedItemIndicator.plannedItemIndicator = true;
    }

    return plannedItemIndicator;

  }

  /**
   * This method checks to see if the planned item status equals 'In Progress'
   * or 'Completed'.
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   */
  // BEGIN, CR00093557, CM
  @Override
  public PlannedItemIndicator isStatusInProgressOrCompleted(
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // END, CR00093557

    // Return struct
    final PlannedItemIndicator plannedItemIndicator = new PlannedItemIndicator();

    // PlannedItemStatusStruct struct
    PlannedItemStatusStruct plannedItemStatusStruct = new PlannedItemStatusStruct();

    // PlannedItem entity object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Read the plannedItem status
    plannedItemStatusStruct = plannedItemObj.readStatus(plannedItemIDKey);

    // If the Planned Item status is 'In Progress' or 'Completed'
    // set the indicator to be true

    // BEGIN, CR00161962, KY
    // Added additional condition for setting the indicator as 'true' if the
    // status of the planned item is 'Submitted'. This is to stop the delete
    // of the planned item in submitted status to avoid the Master Approval
    // workflow from failing over if a planned item is deleted mid way
    // through the approval process
    if (plannedItemStatusStruct.status.equals(

      curam.codetable.PLANNEDITEMSTATUS.INPROGRESS)
        || plannedItemStatusStruct.status.equals(
          curam.codetable.PLANNEDITEMSTATUS.COMPLETED)
          || plannedItemStatusStruct.status.equals(
            curam.codetable.PLANNEDITEMSTATUS.SUBMITTED)) {

      plannedItemIndicator.plannedItemIndicator = true;
    }
    // END, CR00161962
    return plannedItemIndicator;
  }

  // END, CR00091347

  // BEGIN, CR00161962, KY
  /**
   * This method creates the planned item approval criteria details
   *
   * @param planItemApprovalCriteriaDetailsList
   * PlannedItemApprovalCriteriaLinkDetailsList containing list of
   * details of the planned item approval criteria
   * @param plannedItemKey
   * Planned item value
   *
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard application exception
   */

  @Override
  public void createPlannedItemApprovalCriteria(
    final PlanItemApprovalCriteriaDetailsList planItemApprovalCriteriaDetailsList,
    final PlannedItemKey plannedItemKey) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final PlanItemApprovalCriteriaDetails planItemApprovalCriteriaDetails = new PlanItemApprovalCriteriaDetails();

    final PlanItemApprovalCriteriaLinkKey planItemApprovalCriteriaLinkKey = new PlanItemApprovalCriteriaLinkKey();

    final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

    final PlannedItemApprovalCriteriaDtls plannedItemApprovalCriteriaDtls = new PlannedItemApprovalCriteriaDtls();

    for (final PlanItemApprovalCriteriaLinkDetails planItemApprovalCriteriaLinkDetails : planItemApprovalCriteriaDetailsList.dtlsList.dtls.items()) {

      // set the planned item id
      plannedItemApprovalCriteriaDtls.plannedItemID = plannedItemKey.plannedItemID;

      plannedItemApprovalCriteriaDtls.priority = planItemApprovalCriteriaLinkDetails.priority;

      plannedItemApprovalCriteriaDtls.occursWhen = planItemApprovalCriteriaLinkDetails.occursWhen;

      plannedItemApprovalCriteriaDtls.approvalStatus = PIAPPROVALCRITERIASTATUS.NOT_STARTED;

      // set the approval criteria link key to read the
      // approval criteria details to fetch - criteria name and
      // workflow event name
      planItemApprovalCriteriaLinkKey.key.planItemApprovalCriteriaLinkID = planItemApprovalCriteriaLinkDetails.planItemApprovalCriteriaLinkID;

      // get the planItemApprovalCriteriaDetails
      planItemApprovalCriteriaDetails.assign(
        planItemObj.readApprovalCriteria(planItemApprovalCriteriaLinkKey));

      // populate the event name and criteria name from
      // planItemApprovalCriteriaDetails obtained in the above step
      plannedItemApprovalCriteriaDtls.eventName = planItemApprovalCriteriaDetails.workflowEventName;

      plannedItemApprovalCriteriaDtls.criteriaName = planItemApprovalCriteriaDetails.criteriaName;

      // invoke the insert method
      plannedItemApprovalCriteriaObj.insert(plannedItemApprovalCriteriaDtls);
    }
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  /**
   * This method reads the planned item mandatory indicator value. This value
   * will be used to perform validation when the planned item is deleted.
   *
   * @param PlannedItemIDKey
   * - key of planned item.
   * @return IsMandatoryIndResult - value to determine mandatory is set.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public IsMandatoryIndResult isMandatoryIndSet(
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // instance for planned item service object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // 'isMandatoryIndResult' struct to hold the result
    final IsMandatoryIndResult isMandatoryIndResult = new IsMandatoryIndResult();

    // invoke the method 'readPlannedItemMandatoryInd'
    // of PlannedItem entity object to get the value
    isMandatoryIndResult.assign(
      plannedItemObj.readPlannedItemMandatoryInd(plannedItemIDKey));

    // return the result
    return isMandatoryIndResult;
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  /**
   * Sends a notification out to a user(s).
   *
   * Notification details and user(s) depends upon the details passed in
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   * @param status
   * details the potential status of the planned item
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public void sendNotification(PlannedItemIDKey plannedItemIDKey,
    curam.serviceplans.sl.struct.PlannedItemStatusStruct status)
    throws AppException, InformationalException {

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();
    // The PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Get the caseID
    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Set the caseHeaderKey
    caseHeaderKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    PlannedItemDtls plannedItemDtls = new PlannedItemDtls();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    plannedItemDtls = plannedItemObj.read(plannedItemKey);

    // Read the Case Reference
    CaseReference caseReference = new CaseReference();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = caseHeaderKey.caseID;
    // The CaseHeader Object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    // read OwnerUserName
    PlannedItemOwnerDetailsStruct plannedItemOwnerDetailsStruct = new PlannedItemOwnerDetailsStruct();

    plannedItemOwnerDetailsStruct = plannedItemObj.readOwner(
      plannedItemIDKey.plannedItemIDKey);

    // read Current User
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // User maintenance business process object
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    // Read the user details
    final UsersKey usersKey = new UsersKey();
    UserFullname userFullName;

    usersKey.userName = systemUserDtls.userName;
    userFullName = usersObj.getFullName(usersKey);

    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

    final StringBuffer planItemStatus = new StringBuffer();
    boolean sendNotification = false;

    sendNotification = resolveSendNotification(status, planItemStatus);

    // only send notifications if we get past environment variable setting
    if (sendNotification) {
      // variables used to create a notification
      final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
      // set subject and comments
      final AppException subjectText = new AppException(
        curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_CHANGE_SUBJECT);

      subjectText.arg(plannedItemDtls.name);
      subjectText.arg(planItemStatus.toString());

      final AppException commentsText = new AppException(
        curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_CHANGE_COMMENTS);

      // Set up the text
      commentsText.arg(plannedItemDtls.name);
      commentsText.arg(caseReference.caseReference);
      commentsText.arg(planItemStatus.toString());
      commentsText.arg(userFullName.fullname);

      // Set the notification for the two possible types of messages
      // BEGIN, CR00333044, GYH
      standardManualDtls.dtls.concerningDtls.caseID = caseHeaderKey.caseID;
      // END, CR00333044

      standardManualDtls.dtls.taskDtls.subject = subjectText.getMessage();
      standardManualDtls.dtls.taskDtls.comments = commentsText.getMessage();
      standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;

      // If the current user is not the plan item owner send a
      // notification to the plan item owner
      if (!systemUserDtls.userName.equals(
        plannedItemOwnerDetailsStruct.ownerUserName)) {

        // Send Notification to the plan item owner
        standardManualDtls.dtls.assignDtls.assignmentID = plannedItemOwnerDetailsStruct.ownerUserName;
        notificationObj.createWorkAllocationNotification(standardManualDtls);
      }

      // Check if the user is the owner of the case or part of any
      // organization object that owns the case. If not then send
      // notification to all the owner(s)
      // Set the user name key to be the current user
      final UserNameKey userNameKey = new UserNameKey();

      // We only want to send one notification out to any one user
      userNameKey.userName = plannedItemOwnerDetailsStruct.ownerUserName;

      boolean caseOwnerIsPlannedItemOwner = false;

      // CaseUserRole manipulation variables
      final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      // Is case owner same as planned item owner?
      if (caseUserRoleObj.isUserCaseOwner(userNameKey, caseHeaderKey).ownerInd) {
        // Case owner is also planned item owner
        caseOwnerIsPlannedItemOwner = true;
      }
      userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

      // Only send a notification out if:
      // 1. case owner is not the planned item owner AND
      // 2. current session user is not case owner
      if (!caseOwnerIsPlannedItemOwner
        && !caseUserRoleObj.isUserCaseOwner(userNameKey, caseHeaderKey).ownerInd) {
        // Send Notification to the plan owner(s)
        notificationObj.sendCaseOwnerNotification(standardManualDtls);
      }
    }
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  /**
   * This method is used to determine the need of send notification.
   *
   * @param status
   * status of planned item.
   * @param planItemStatus
   * status of plan item.
   * @return boolean to determine the need for sending notification.
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  protected boolean resolveSendNotification(
    curam.serviceplans.sl.struct.PlannedItemStatusStruct status,
    StringBuffer planItemStatus) {

    boolean sendNotification = false;

    if (status.plannedItemStatusStruct.status.equals(
      PLANNEDITEMSTATUS.SUBMITTED)) {

      // retrieve environment variable
      String genPlanItemSubmitted = Configuration.getProperty(
        EnvVars.ENV_GENPLANITEMSUBMITTEDTICKET);

      // check that the variable has been populated, if not, use default
      // variable
      if (genPlanItemSubmitted == null) {

        genPlanItemSubmitted = EnvVars.ENV_GENPLANITEMSUBMITTEDTICKET_DEFAULT;
      }

      // check the notification environment variable when submitting
      // a plan item for approval
      if (genPlanItemSubmitted.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

        sendNotification = true;

        planItemStatus.append(
          BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_SUBMITTED_FOR_APPROVAL.getMessageText());
      }
    } else if (status.plannedItemStatusStruct.status.equals(
      PLANNEDITEMSTATUS.REJECTED)) {

      // retrieve environment variable
      String genPlanItemRejected = Configuration.getProperty(
        EnvVars.ENV_GENPLANITEMREJECTEDTICKET);

      // check that the variable has been populated, if not, use default
      // variable
      if (genPlanItemRejected == null) {

        genPlanItemRejected = EnvVars.ENV_GENPLANITEMREJECTEDTICKET_DEFAULT;
      }

      // check the notification environment variable when submitting
      // a plan item for approval
      if (genPlanItemRejected.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

        sendNotification = true;

        planItemStatus.append(
          BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_REJECT.getMessageText());
      }
    } else if (status.plannedItemStatusStruct.status.equals(
      PLANNEDITEMSTATUS.APPROVED)) {

      // retrieve environment variable
      String genPlanItemApproved = Configuration.getProperty(
        EnvVars.ENV_GENPLANITEMAPPROVEDTICKET);

      // check that the variable has been populated, if not, use default
      // variable
      if (genPlanItemApproved == null) {

        genPlanItemApproved = EnvVars.ENV_GENPLANITEMAPPROVEDTICKET_DEFAULT;
      }

      // check the notification environment variable when submitting
      // a plan item for approval
      if (genPlanItemApproved.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

        sendNotification = true;

        planItemStatus.append(
          BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_STATUS_APPROVED.getMessageText());
      }
    }
    return sendNotification;
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  /**
   * Validates the case status that the planned item belongs to
   *
   * @param PlannedItemIDKey
   * - key containing details of the planned item
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public void validateCaseStatus(PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // The PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // The CaseHeader Object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    // Get the caseID
    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);

    // Set the caseHeaderKey
    caseHeaderKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    // Read the Case Status
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // If the case is closed closed then throw validation
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDITEM.ERR_SERVICEPLAN_XRV_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  /**
   * Method which obtains the estimated cost of the planned item.
   *
   * @param PlannedItemIDKey
   * - ID of the planned item
   * @return PlannedItemEstimatedCost - estimated cost of the planned item
   */
  @Override
  public PlannedItemEstimatedCost readPlannedItemEstimatedCost(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Create return struct
    PlannedItemEstimatedCost plannedItemEstimatedCost = new PlannedItemEstimatedCost();

    // Create object instance
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Obtain estimated cost
    plannedItemEstimatedCost = plannedItemObj.readEstimatedCost(
      key.plannedItemIDKey);

    // Return the result
    return plannedItemEstimatedCost;
  }

  // END, CR00161962

  // BEGIN, CR00235251, TV
  /**
   * This method is used to create a Service Plan Basic Plan Item. A hook is
   * called to allow the developer to override the planned item details.
   * curam
   * .serviceplans.sl.impl.CreatePlannedItemHook.populatePlannedItemDetails
   * (PlannedItemDetailsStruct) is the first method called in
   * curam.serviceplans.sl.intf.PlannedItem.createBasicPlanItemDetails
   * (PlannedItemDetailsStruct) method. The input is the planned
   * Item details struct with original values which may be overridden as per
   * the hook implementation.
   *
   * @param createPlannedItemDetailsStruct
   * Contains the details of the planned item to be created.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_CREATE_PARTICIPANT_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to add a plan
   * item to this sub goal.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void createBasicPlanItemDetails(
    PlannedItemDetailsStruct plannedItemDetailsStruct) throws AppException,
      InformationalException {

    // Manipulation Objects
    final CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct = new CreatePlannedItemDetailsStruct();

    // BEGIN, CR00428820, RD
    // BEGIN, CR00417588, RD
    if (null != createPlannedItemHook) {

      createPlannedItemDetailsStruct.assign(
        createPlannedItemHook.populatePlannedItemDetails(
          populateResponsibilityDetails(plannedItemDetailsStruct)));
    } else {
      createPlannedItemDetailsStruct.assign(
        populateResponsibilityDetails(plannedItemDetailsStruct));
    }
    // END, CR00417588
    // END, CR00428820

    // Validate information
    plannedItemDetailsStruct.assign(
      validateCreateDetails(createPlannedItemDetailsStruct));

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // PlannedItem Object
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    // PlannedItem Object
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // PlanItemIDKey
    final PlanItemIDKey planItemIDKey = new PlanItemIDKey();

    // Set the PlanItemID from the input
    planItemIDKey.planItemID = plannedItemDetailsStruct.plannedItemDtls.planItemID;

    // validate the expected outcome
    plannedItemObj.validateExpectedOutcome(planItemIDKey);

    // Check service plan security.

    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();

    final ServicePlanSubGoalSecurityKey servicePlanSubGoalSecurityKey = new ServicePlanSubGoalSecurityKey();

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanSubGoalSecurityKey.plannedSubGoalKey.key.plannedSubGoalID = plannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // need to read the service plan id for security check
    // Read Case ID
    plannedSubGoalKey.plannedSubGoalID = plannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.subGoalOperationSecurityCheck(
        servicePlanSubGoalSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_CREATE_PARTICIPANT_CHECK_FAILED);

      } else {
        throw e;
      }
    }

    // insert the basic plan item details
    plannedItemObj.insert(plannedItemDetailsStruct.plannedItemDtls);

    // Service plans workflow raise event integration
    final Event event = new Event();

    event.eventKey = SERVICEPLANS.CREATEPLANITEM;

    event.primaryEventData = plannedItemDetailsStruct.plannedItemDtls.planItemID;

    // Planned Item Approval criteria manipulation

    // if the planned item comes does not comes from template, then
    // get the approval details from plan item repository else
    // if it is from template, then get the details from the
    // template approval entity.
    if (plannedItemDetailsStruct.planTemplatePlanItemID == CuramConst.gkZero) {
      // Plan item key
      final PlanItemKey planItemKeyObj = new PlanItemKey();

      // Planned item key
      final PlannedItemKey plannedItemKeyObj = new PlannedItemKey();

      // set planItem Key
      planItemKeyObj.key.planItemID = plannedItemDetailsStruct.plannedItemDtls.planItemID;

      // set planned item key
      plannedItemKeyObj.plannedItemID = plannedItemDetailsStruct.plannedItemDtls.plannedItemID;

      // Plan Item entity obj
      final PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

      // Plan Item Approval Criteria Details list object
      final PlanItemApprovalCriteriaDetailsList approvalCriteriaDetailsListObj = new PlanItemApprovalCriteriaDetailsList();

      // invoke the method listApprovalCriteria by passing the
      // planitemKey and get the list of approval criteria
      // and assign it to the approvalCriteriaDetailsList
      approvalCriteriaDetailsListObj.assign(
        planItemObj.listApprovalCriteria(planItemKeyObj));

      // pass the approvalCriteriaDetailsList and the planned item id
      // to the method createPlannedItemApprovalCriteria which will
      // insert values into PlannedItemApprovalCriteria table
      createPlannedItemApprovalCriteria(approvalCriteriaDetailsListObj,
        plannedItemKeyObj);
    } // If the planned item is created from template, then the
    // approval details should be got from the template
    // approval tables and not from the plan item repository
    else {
      // PlantemplatePlanItemKey
      final PlanTemplatePlanItemKey planTemplatePlanItemKeyObj = new PlanTemplatePlanItemKey();

      // plannedItemApprovalCriteriaDtlsList that will be returned from
      // the search method
      final PlannedItemApprovalCriteriaDtlsList plannedItemApprovalCriteriaDtlsList = new PlannedItemApprovalCriteriaDtlsList();

      // set the planTemplatePlanItemKey
      planTemplatePlanItemKeyObj.planTemplatePlanItemID = plannedItemDetailsStruct.planTemplatePlanItemID;

      // Instance for the entity PlanTemplatePlanItemApprCrit which
      // we use to read the approval criteria for this plan item
      // in template
      final PlanTemplatePlanItemApprCrit planTemplatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

      // get the list of approval criteria details for this plan item
      plannedItemApprovalCriteriaDtlsList.assign(
        planTemplatePlanItemApprCritObj.searchByPlanTemplatePlanItemIDForPlannedItem(
          planTemplatePlanItemKeyObj));

      // instance for planneditemApprovalCriteria
      final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

      // loop through the list and get the PlannedItemApprovalCriteriaDtls
      // and invoke the method 'insert' of plannedItemApprovalCriteria for
      // creating the approval details for the planned item.
      for (final PlannedItemApprovalCriteriaDtls plannedItemApprovalCriteriaDtlsObj : plannedItemApprovalCriteriaDtlsList.dtls.items()) {

        // set the planned item id
        plannedItemApprovalCriteriaDtlsObj.plannedItemID = plannedItemDetailsStruct.plannedItemDtls.plannedItemID;

        // default approval status to 'not started
        plannedItemApprovalCriteriaDtlsObj.approvalStatus = PIAPPROVALCRITERIASTATUS.NOT_STARTED;

        // invoke the method 'insert' of planned item approval criteria
        // to insert the approval criteria details for this planned item
        // that we have read from the template link
        plannedItemApprovalCriteriaObj.insert(
          plannedItemApprovalCriteriaDtlsObj);
      }
    }

    // Planned Item task Configuration manipulation.
    // PlanItemTaskConfiguration entity object
    final TaskConfiguration taskConfigurationObj = TaskConfigurationFactory.newInstance();

    // PlannedItemTaskConfiguration entity object
    final PlannedItemTaskConfiguration plannedItemTaskConfigurationObj = PlannedItemTaskConfigurationFactory.newInstance();

    // PlannedItem Task Configuration details struct
    final PlannedItemTaskConfigurationDtls plannedItemTaskConfigurationDtlsObj = new PlannedItemTaskConfigurationDtls();

    final PlanItemIDKey planItemIDEntityKey = new PlanItemIDKey();

    // populate the plan item id to get the plan item task configuration
    // details
    planItemIDEntityKey.planItemID = plannedItemDetailsStruct.plannedItemDtls.planItemID;

    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKeyEL = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKeyEL.planItemID = plannedItemDetailsStruct.plannedItemDtls.planItemID;
    final PlanItemDtls planItemDtls = planItemObj.read(planItemKeyEL);

    // if the plan item task configuration count >0 then we need to get
    // those
    // details and populate for planned item task configuration table
    if (planItemDtls.taskConfigID != CuramConst.gkZero) {
      plannedItemTaskConfigurationDtlsObj.assign(
        taskConfigurationObj.readDetailsForPlannedItem(planItemIDEntityKey));

      // populate the planned item id
      plannedItemTaskConfigurationDtlsObj.plannedItemID = plannedItemDetailsStruct.plannedItemDtls.plannedItemID;

      // invoke the method 'insert' to populate the planned item task
      // configuration entity.
      plannedItemTaskConfigurationObj.insert(
        plannedItemTaskConfigurationDtlsObj);
    }

    // Raise an event for the approve plan item workflow to be enacted
    // This is for 'not started' status planned items, i.e. auto approved
    // This ensures complete processing of those planned items
    if (plannedItemDetailsStruct.plannedItemDtls.status.equals(
      PLANNEDITEMSTATUS.NOTSTARTED)) {

      // Service plans workflow raise event integration

      event.eventKey = SERVICEPLANAPPROVAL.AUTOAPPROVEDPLANITEM;

      event.primaryEventData = plannedItemDetailsStruct.plannedItemDtls.plannedItemID;

      EventService.raiseEvent(event);

    }
  }
  // END, CR00235251

}
