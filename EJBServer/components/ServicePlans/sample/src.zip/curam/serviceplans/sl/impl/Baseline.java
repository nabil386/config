/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.BASELINEPLANCONTENTTYPE;
import curam.codetable.BASELINETYPE;
import curam.codetable.PLANCONTENTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESPONSIBILITYTYPE;
import curam.codetable.impl.LOCALEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.Users;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetailsList;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ServicePlanGanttConst;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.UsersKey;
import curam.message.BPOBASELINE;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.BaselineFactory;
import curam.serviceplans.sl.entity.fact.BaselineMilestoneFactory;
import curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory;
import curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory;
import curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.BaselinePlanGroup;
import curam.serviceplans.sl.entity.intf.BaselinePlanItem;
import curam.serviceplans.sl.entity.intf.BaselineSubGoal;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetails;
import curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetails;
import curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetails;
import curam.serviceplans.sl.entity.struct.BaselineCountDetails;
import curam.serviceplans.sl.entity.struct.BaselineForServicePlanDetails;
import curam.serviceplans.sl.entity.struct.BaselineGoalNameDetails;
import curam.serviceplans.sl.entity.struct.BaselineIDAndPlannedGroupID;
import curam.serviceplans.sl.entity.struct.BaselineMilestoneDtls;
import curam.serviceplans.sl.entity.struct.BaselineMilestoneDtlsList;
import curam.serviceplans.sl.entity.struct.BaselineMilestoneListDetails;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemComparisonKey;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemDtls;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemKey;
import curam.serviceplans.sl.entity.struct.BaselinePlannedGroupDetails;
import curam.serviceplans.sl.entity.struct.BaselinePlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.BaselineSensitivityCode;
import curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtls;
import curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalComparisonKey;
import curam.serviceplans.sl.entity.struct.BaselineViewPlannedGroupKey;
import curam.serviceplans.sl.entity.struct.CountBaselineByPlannedGoalIDAndTypeKey;
import curam.serviceplans.sl.entity.struct.GoalNameDetails;
import curam.serviceplans.sl.entity.struct.MilestoneAndPlannedGroupDetails;
import curam.serviceplans.sl.entity.struct.MilestoneAndPlannedGroupDetailsList;
import curam.serviceplans.sl.entity.struct.MilestoneAndPlannedSubGoalDetails;
import curam.serviceplans.sl.entity.struct.MilestoneAndPlannedSubGoalDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemIDStatus;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.BaselineAndPlannedGroupComparisonKey;
import curam.serviceplans.sl.struct.BaselineCaseIDKey;
import curam.serviceplans.sl.struct.BaselineCompareKey;
import curam.serviceplans.sl.struct.BaselineComparisonGanttDetails;
import curam.serviceplans.sl.struct.BaselineComparisonPlanItemDetailsList;
import curam.serviceplans.sl.struct.BaselineComparisonPlannedGroupDetailsList;
import curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetailsList;
import curam.serviceplans.sl.struct.BaselineGanttElement;
import curam.serviceplans.sl.struct.BaselineGanttElementList;
import curam.serviceplans.sl.struct.BaselineGanttXmlDetails;
import curam.serviceplans.sl.struct.BaselineIDAndCaseIDKey;
import curam.serviceplans.sl.struct.BaselineIDDetails;
import curam.serviceplans.sl.struct.BaselineKey;
import curam.serviceplans.sl.struct.BaselineListDetails;
import curam.serviceplans.sl.struct.BaselineMilestoneDetailsList;
import curam.serviceplans.sl.struct.BaselineMilestoneListDetailsList;
import curam.serviceplans.sl.struct.BaselineNameDetails;
import curam.serviceplans.sl.struct.BaselinePlanContentDetails;
import curam.serviceplans.sl.struct.BaselinePlanGroupDetails;
import curam.serviceplans.sl.struct.BaselinePlanGroupReadDetailsKey;
import curam.serviceplans.sl.struct.BaselinePlanGrpListPlanContentDetailsKey;
import curam.serviceplans.sl.struct.BaselinePlanItemGanttElementList;
import curam.serviceplans.sl.struct.BaselinePlannedGroupChildContentListDetails;
import curam.serviceplans.sl.struct.BaselinePlannedItemDetails;
import curam.serviceplans.sl.struct.BaselineSubGoalGanttElementList;
import curam.serviceplans.sl.struct.BaselineSubGoalKey;
import curam.serviceplans.sl.struct.BaselineSubGoalListDetails;
import curam.serviceplans.sl.struct.BaselineSubGoalWithPlanItemsDetails;
import curam.serviceplans.sl.struct.ComparisonLevelDetailsList;
import curam.serviceplans.sl.struct.CreateBaselineComponentsDetails;
import curam.serviceplans.sl.struct.CreateBaselineDetails;
import curam.serviceplans.sl.struct.ExistingBaselinesDetails;
import curam.serviceplans.sl.struct.ModifyBaselineDetails;
import curam.serviceplans.sl.struct.PlannedGroupGanttElementList;
import curam.serviceplans.sl.struct.ReadBaselineDetails;
import curam.serviceplans.sl.struct.ReadBaselineGanttDetails;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.ViewPlannedItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * Business layer functionality for managing service plan baselines.
 */
public abstract class Baseline extends curam.serviceplans.sl.base.Baseline {

  // BEGIN, CR00236665, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public Baseline() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00236665

  // BEGIN, CR00069996, SK
  protected static final String kGantt = ServicePlanGanttConst.kGantt;

  protected static final String kGoal = ServicePlanGanttConst.kPlannedGoal;

  protected static final String kView = ServicePlanGanttConst.kView;

  protected static final String kOpen = ServicePlanGanttConst.kOpen;

  protected static final String kClosed = ServicePlanGanttConst.kClosed;

  protected static final String kSubGoal = ServicePlanGanttConst.kPlannedSubGoal;

  protected static final String kPlanItem = ServicePlanGanttConst.kPlanItem;

  protected static final String kServiceUnitDelivery = ServicePlanGanttConst.kServiceUnitDelivery;

  protected static final String kMilestone = ServicePlanGanttConst.kMilestone;

  protected static final String kType = ServicePlanGanttConst.kType;

  protected static final String kID = ServicePlanGanttConst.kID;

  protected static final String kName = ServicePlanGanttConst.kName;

  protected static final String kTopStart = ServicePlanGanttConst.kTopStart;

  protected static final String kTopEnd = ServicePlanGanttConst.kTopEnd;

  protected static final String kBottomStart = ServicePlanGanttConst.kBottomStart;

  protected static final String kBottomEnd = ServicePlanGanttConst.kBottomEnd;

  protected static final String kReceivedUnits = ServicePlanGanttConst.kReceivedUnits;

  protected static final String kAuthorizedUnits = ServicePlanGanttConst.kAuthorizedUnits;

  protected static final String kDate = ServicePlanGanttConst.kDate;

  protected static final String kUnits = ServicePlanGanttConst.kUnits;

  protected static final String kUnitType = ServicePlanGanttConst.kUnitType;

  protected static final String kEmptyDate = CuramConst.gkEmpty;

  protected static final String kPlannedGroup = ServicePlanGanttConst.kPlannedGroup;

  protected static final String kPlanGroupType = ServicePlanGanttConst.kPlanGroupType;

  protected static final String kContentType = ServicePlanGanttConst.kContentType;

  protected static final String kPlanGroupContentType = ServicePlanGanttConst.kPlanGroupContentType;

  protected static final String kCaseID = ServicePlanGanttConst.kCaseID;

  protected static final String kBaselineApprovalConstant = ServicePlanGanttConst.kBaselineApprovalConstant;

  protected static final String kBaselineSubmissionApprovalConstant = ServicePlanGanttConst.kBaselineSubmissionApprovalConstant;

  protected static final String kBaselineClone = ServicePlanGanttConst.kBaselineClone;

  // END, CR00069996

  // BEGIN

  protected static final String kFrequency = ServicePlanGanttConst.kfrequency;

  protected static final String kParticipantName = ServicePlanGanttConst.kParticipantName;

  // BEGIN, CR00219204, SW
  // Date format required when converting to string
  // Currently yyyy-MM-dd

  private static final String kGanttDateFormat = curam.util.resources.Locale.Date_ymd_ext;

  // END, CR00219204

  // END HERE
  /**
   * Returns a list of all Baseline Sub Goals, Baseline Milestones
   * and child Baseline Planned Groups
   * for a specified Baseline Plan Group.
   *
   * @param key - Baseline ID and Planned Group ID.
   *
   * @return List of all Baseline Sub Goals, Baseline Milestones
   * and child Baseline Plan Groups.
   */
  @Override
  public BaselinePlannedGroupChildContentListDetails listBaselinePlanGroupContentList(
    final BaselinePlanGrpListPlanContentDetailsKey key)
    throws AppException, InformationalException {

    // set return value
    final BaselinePlannedGroupChildContentListDetails baselinePlannedGroupChildContentListDetails = new BaselinePlannedGroupChildContentListDetails();

    // Baseline Plan Group manipulation variables
    final PlannedGroupKey plannedGroupKey = new PlannedGroupKey();
    final curam.serviceplans.sl.entity.intf.Baseline baselineEntObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();
    final curam.serviceplans.sl.struct.BPGChildBPGContentListDetailsList bPGChildBPGContentListDetailsList = new curam.serviceplans.sl.struct.BPGChildBPGContentListDetailsList();
    final curam.serviceplans.sl.struct.BPGBaselineSubGoalContentListDetailsList bPGBaselineSubGoalContentListDetailsList = new curam.serviceplans.sl.struct.BPGBaselineSubGoalContentListDetailsList();

    // Baseline Plan Group Object
    final curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroupObj = BaselinePlanGroupFactory.newInstance();

    // set key
    plannedGroupKey.plannedGroupID = key.baselinePlanGrpListPlanContentDetailsKey.plannedGroupID;

    // read child Baseline Planned Groups
    bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList = baselinePlanGroupObj.searchChildPlannedGroupsByBaselineIDAndPlannedGroupID(
      key.baselinePlanGrpListPlanContentDetailsKey);

    // set plan content type for each baseline plan group
    for (int i = 0; i
      < bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.size(); i++) {

      final curam.serviceplans.sl.struct.ListBPGChildBaselinePlannedGroupDetails listBPGChildBaselinePlannedGroupDetails = new curam.serviceplans.sl.struct.ListBPGChildBaselinePlannedGroupDetails();

      // assign details
      listBPGChildBaselinePlannedGroupDetails.plannedGroupName = bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.item(i).plannedGroupName;
      listBPGChildBaselinePlannedGroupDetails.plannedGroupID = bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.item(i).plannedGroupID;
      listBPGChildBaselinePlannedGroupDetails.actualEndDate = bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.item(i).actualEndDate;
      listBPGChildBaselinePlannedGroupDetails.actualStartDate = bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.item(i).actualStartDate;
      listBPGChildBaselinePlannedGroupDetails.expectedEndDate = bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.item(i).expectedEndDate;
      listBPGChildBaselinePlannedGroupDetails.expectedStartDate = bPGChildBPGContentListDetailsList.bPGChildBPGContentListDetailsList.dtls.item(i).expectedStartDate;

      // set the case id for the baseline planned group for each record found
      baselineKey.baseLineID = key.baselinePlanGrpListPlanContentDetailsKey.baselineID;
      listBPGChildBaselinePlannedGroupDetails.caseID = baselineEntObj.readCaseIDByBaselineID(baselineKey).caseID;

      // set the indicator
      listBPGChildBaselinePlannedGroupDetails.planGroupIndicator = true;

      // set the type code to baseline planned group for each record found
      listBPGChildBaselinePlannedGroupDetails.planContentType = PLANCONTENTTYPE.PLANNEDGROUP;

      // assign each structure to struct list to be returned
      baselinePlannedGroupChildContentListDetails.listBPGChildBaselinePlannedGroupDetails.addRef(
        listBPGChildBaselinePlannedGroupDetails);
    }

    // read Baseline sub goals
    bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList = baselinePlanGroupObj.searchBaselineSubGoalsDates(
      key.baselinePlanGrpListPlanContentDetailsKey);

    // set plan content type for each baseline sub goal
    for (int i = 0; i
      < bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.size(); i++) {

      final curam.serviceplans.sl.struct.ListBPGSubGoalContentListDetails listBPGSubGoalContentListDetails = new curam.serviceplans.sl.struct.ListBPGSubGoalContentListDetails();

      // assign details
      listBPGSubGoalContentListDetails.plannedSubGoalID = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).plannedSubGoalID;
      listBPGSubGoalContentListDetails.baselineSubGoalID = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).baselineSubGoalID;
      listBPGSubGoalContentListDetails.subGoalName = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).name;
      listBPGSubGoalContentListDetails.actualEndDate = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).actualEndDate;
      listBPGSubGoalContentListDetails.actualStartDate = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).actualStartDate;
      listBPGSubGoalContentListDetails.expectedEndDate = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).expectedEndDate;
      listBPGSubGoalContentListDetails.expectedStartDate = bPGBaselineSubGoalContentListDetailsList.bPGBaselineSubGoalContentListDetailsList.dtls.item(i).expectedStartDate;

      // set the type code to baseline planned group for each record found
      listBPGSubGoalContentListDetails.planContentType = PLANCONTENTTYPE.PLANNEDSUBGOAL;

      // set the indicator
      listBPGSubGoalContentListDetails.subGoalIndicator = false;

      // set the case id for the baseline planned group for each record found
      baselineKey.baseLineID = key.baselinePlanGrpListPlanContentDetailsKey.baselineID;
      listBPGSubGoalContentListDetails.caseID = baselineEntObj.readCaseIDByBaselineID(baselineKey).caseID;

      // assign each structure to struct list to be returned
      baselinePlannedGroupChildContentListDetails.listBPGSubGoalContentListDetails.addRef(
        listBPGSubGoalContentListDetails);
    }

    // BEGIN, CR00057481, PMD
    final BaselineIDAndPlannedGroupID baselineIDAndPlannedGroupID = new BaselineIDAndPlannedGroupID();

    // Set key to search for baseline milestones
    baselineIDAndPlannedGroupID.baselineID = key.baselinePlanGrpListPlanContentDetailsKey.baselineID;
    baselineIDAndPlannedGroupID.plannedGroupID = key.baselinePlanGrpListPlanContentDetailsKey.plannedGroupID;

    final BaselineMilestoneListDetailsList baselineMilestoneListDetailsList = new BaselineMilestoneListDetailsList();

    // Get the list of Baseline Milestones
    baselineMilestoneListDetailsList.listDetails = BaselineMilestoneFactory.newInstance().searchByBaselineIDAndPlannedGroupID(
      baselineIDAndPlannedGroupID);

    // Assign the list of baseline milestones to the return struct
    baselinePlannedGroupChildContentListDetails.milestoneList.assign(
      baselineMilestoneListDetailsList);
    // END, CR00057481

    // return details
    return baselinePlannedGroupChildContentListDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all Baseline plan groups and baseline sub-goals that
   * are part the baseline.
   *
   * @param key
   * Baseline ID.
   *
   * @return List of all Baseline Sub Goals and Baseline Plan Groups.
   */
  @Override
  public BaselinePlanContentDetails listBaselinePlanContent(
    final BaselineKey key) throws AppException, InformationalException {

    // return structure
    final BaselinePlanContentDetails baselinePlanContentDetails = new BaselinePlanContentDetails();

    // Baseline Plan Group manipulation variables
    final curam.serviceplans.sl.struct.BaselinePlannedGroupListDetails baselinePlannedGroupListDetails = new curam.serviceplans.sl.struct.BaselinePlannedGroupListDetails();
    curam.serviceplans.sl.struct.BaselineSubGoalListDetails baselineSubGoalListDetails = new curam.serviceplans.sl.struct.BaselineSubGoalListDetails();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();
    final curam.serviceplans.sl.entity.intf.Baseline baselineEntObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();

    // Baseline Plan Group Object
    final BaselinePlanGroup baselinePlanGroupObj = BaselinePlanGroupFactory.newInstance();

    // read Baseline Plan Group content list details
    baselinePlannedGroupListDetails.baselinePlannedGroupPlanContentDtlsList = baselinePlanGroupObj.searchContentListDetailsByBaselineID(
      key.baselineKey);

    // set plan content type for each baseline plan group
    for (int i = 0; i
      < baselinePlannedGroupListDetails.baselinePlannedGroupPlanContentDtlsList.dtls.size(); i++) {

      final curam.serviceplans.sl.struct.ListBaselinePlannedGroupDetails listBaselinePlannedGroupDetails = new curam.serviceplans.sl.struct.ListBaselinePlannedGroupDetails();

      // assign details
      listBaselinePlannedGroupDetails.baselinePlannedGroupID = baselinePlannedGroupListDetails.baselinePlannedGroupPlanContentDtlsList.dtls.item(i).baselinePlannedGroupID;
      listBaselinePlannedGroupDetails.plannedGroupID = baselinePlannedGroupListDetails.baselinePlannedGroupPlanContentDtlsList.dtls.item(i).plannedGroupID;
      listBaselinePlannedGroupDetails.plannedGroupName = baselinePlannedGroupListDetails.baselinePlannedGroupPlanContentDtlsList.dtls.item(i).plannedGroupName;

      // set the type codes to baseline planned group and planned group for
      // each record found
      listBaselinePlannedGroupDetails.planContentType = PLANCONTENTTYPE.PLANNEDGROUP;
      listBaselinePlannedGroupDetails.baselinePlanContentType = BASELINEPLANCONTENTTYPE.PLANNEDGROUP;

      // set the indicator
      listBaselinePlannedGroupDetails.planGroupIndicator = true;

      // set the case id for the baseline planned group for each record found
      baselineKey.baseLineID = key.baselineKey.baseLineID;
      listBaselinePlannedGroupDetails.caseID = baselineEntObj.readCaseIDByBaselineID(key.baselineKey).caseID;

      // assign each structure to struct list to be returned
      baselinePlanContentDetails.listBaselinePlannedGroupDetails.addRef(
        listBaselinePlannedGroupDetails);
    }
    // read Baseline Sub Goal content list details
    baselineSubGoalListDetails = listSubgoalsBaseline(key);

    // set plan content type for each baseline sub goal
    for (int i = 0; i
      < baselineSubGoalListDetails.baselineSubGoalByBaselineIDDetailsList.dtls.size(); i++) {

      final curam.serviceplans.sl.struct.ListBaselineSubGoalDetails listBaselineSubGoalDetails = new curam.serviceplans.sl.struct.ListBaselineSubGoalDetails();

      // assign details
      listBaselineSubGoalDetails.baselineSubGoalID = baselineSubGoalListDetails.baselineSubGoalByBaselineIDDetailsList.dtls.item(i).baselineSubGoalID;
      listBaselineSubGoalDetails.subGoalName = baselineSubGoalListDetails.baselineSubGoalByBaselineIDDetailsList.dtls.item(i).name;
      listBaselineSubGoalDetails.typeCode = baselineSubGoalListDetails.baselineSubGoalByBaselineIDDetailsList.dtls.item(i).typeCode;
      listBaselineSubGoalDetails.plannedSubGoalID = baselineSubGoalListDetails.baselineSubGoalByBaselineIDDetailsList.dtls.item(i).plannedSubGoalID;

      // set the type code to baseline planned group for each record found
      listBaselineSubGoalDetails.planContentType = PLANCONTENTTYPE.PLANNEDSUBGOAL;
      listBaselineSubGoalDetails.baselinePlanContentType = BASELINEPLANCONTENTTYPE.PLANNEDSUBGOAL;

      // set the case id for the baseline planned group for each record found
      baselineKey.baseLineID = key.baselineKey.baseLineID;
      listBaselineSubGoalDetails.caseID = baselineEntObj.readCaseIDByBaselineID(key.baselineKey).caseID;

      // set the indicator
      listBaselineSubGoalDetails.subGoalIndicator = false;

      // assign each structure to struct list to be returned
      baselinePlanContentDetails.listBaselineSubGoalDetails.addRef(
        listBaselineSubGoalDetails);
    }

    return baselinePlanContentDetails;
  }

  /**
   * Reads the details for a specified Baseline Plan Group.
   *
   * @param key
   * Contains the BaselineID and PlannedGroupID as Key.
   *
   * @return Details of the requested Baseline Plan Group.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE#ERR_VIEW_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view
   * this page.
   */
  @Override
  public BaselinePlanGroupDetails readBaselinePlanGroupDetails(
    final BaselinePlanGroupReadDetailsKey key) throws AppException,
      InformationalException {

    final BaselinePlanGroupDetails baselinePlanGroupDetailsSL = new BaselinePlanGroupDetails();

    // Baseline Plan Group manipulation variables
    BaselinePlannedGroupDetails baselinePlannedGroupDetailsEN = new BaselinePlannedGroupDetails();
    BaselinePlannedGroupChildContentListDetails baselinePlannedGroupChildContentListDetails = new BaselinePlannedGroupChildContentListDetails();
    final BaselineViewPlannedGroupKey baselineViewPlannedGroupKey = new BaselineViewPlannedGroupKey();
    final BaselinePlanGrpListPlanContentDetailsKey baselinePlanGrpListPlanContentDetailsKey = new BaselinePlanGrpListPlanContentDetailsKey();

    // Baseline Plan Group Object
    final BaselinePlanGroup baselinePlanGroupObj = BaselinePlanGroupFactory.newInstance();

    baselineViewPlannedGroupKey.baselineID = key.baselineID;
    baselineViewPlannedGroupKey.baselinePlannedGroupID = key.baselinePlanGroupID;

    baselinePlanGrpListPlanContentDetailsKey.baselinePlanGrpListPlanContentDetailsKey.baselineID = key.baselineID;
    baselinePlanGrpListPlanContentDetailsKey.baselinePlanGrpListPlanContentDetailsKey.plannedGroupID = key.plannedGroupID;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // Service Plan Delivery manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryobj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // Baseline manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // set service plan security key
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // set baseline ID
    baselineKey.baseLineID = key.baselineID;

    // set concern role ID
    caseHeaderKey.caseID = baselineObj.readCaseIDByBaselineID(baselineKey).caseID;
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // set service plan ID
    servicePlanDeliveryKey.caseID = caseHeaderKey.caseID;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryobj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)
        || e.equals(
          BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_VIEW_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // set baseline Planned Group main details
    baselinePlannedGroupDetailsEN = baselinePlanGroupObj.readPlannedGroupIDNameAndBaselineName(
      baselineViewPlannedGroupKey);

    // set baseline planned group child content list
    baselinePlannedGroupChildContentListDetails = listBaselinePlanGroupContentList(
      baselinePlanGrpListPlanContentDetailsKey);

    // set return value
    baselinePlanGroupDetailsSL.baselinePlannedGroupDetails = baselinePlannedGroupDetailsEN;
    baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails = baselinePlannedGroupChildContentListDetails;

    return baselinePlanGroupDetailsSL;

  }

  // BEGIN CR00130620, GBA
  /**
   * Returns the details for a specified baseline plan item.
   *
   * @param key Contains baseline plan item id
   *
   * @return details of the created baseline plan item
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BaselinePlannedItemDetails viewBaselinePlannedItemDetails(
    final BaselinePlanItemKey key) throws AppException,
      InformationalException {

    final BaselinePlannedItemDetails baselinePlannedItemDetails = new BaselinePlannedItemDetails();

    final BaselinePlanItem baselinePlanItemObj = BaselinePlanItemFactory.newInstance();

    // Read Baseline planned item entity details
    baselinePlannedItemDetails.baselinePlannedItem = baselinePlanItemObj.read(
      key);

    // BEGIN, CR00233700, SS
    if (RESPONSIBILITYTYPE.CLIENT.equals(
      baselinePlannedItemDetails.baselinePlannedItem.responsibilityType)
        || RESPONSIBILITYTYPE.PARTICIPANT.equals(
          baselinePlannedItemDetails.baselinePlannedItem.responsibilityType)) {
      // END, CR00233700
      baselinePlannedItemDetails.respSetToClientInd = true;
    }

    return baselinePlannedItemDetails;
  }

  // END CR00130620

  /**
   * Creates the new baseline.
   *
   * @param details
   * Contains the baseline details.
   *
   * @return Key of the created baseline.
   *
   * @throws AppException
   * {@link BPOBASELINE#ERR_CREATE_BASELINE_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to create
   * a baseline for this service plan.
   * @throws AppException
   * {@link BPOBASELINE#ERR_CREATE_BASELINE_FV_NAME_MATCHES_SYSTEM_CREATED_BASELINE_NAME}
   * - if name uses any of the following predefined names for a
   * system-created baseline, 'Plan Approval', 'Approval Submission'
   * or 'Plan Cloned'.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE# ERR_CREATE_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to create
   * a baseline for this service plan.
   * @throws AppException
   * {@link BPOBASELINE#ERR_BASELINE_RV_CREATE_PLANNED_GOAL_MUST_EXIST} - if a
   * planned goal does not exist for the service plan delivery
   * before a baseline can be created.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   */
  @Override
  public BaselineIDDetails create(final CreateBaselineDetails details)
    throws AppException, InformationalException {

    // Baseline manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineDtls baselineDtls = new curam.serviceplans.sl.entity.struct.BaselineDtls();
    final CountBaselineByPlannedGoalIDAndTypeKey countBaselineByPlannedGoalIDAndTypeKey = new CountBaselineByPlannedGoalIDAndTypeKey();

    // BaselinePlannedGroup manipulation variables
    final curam.serviceplans.sl.struct.CreateBaselineComponentsDetails createBaselineComponentsDetails = new curam.serviceplans.sl.struct.CreateBaselineComponentsDetails();

    // BaselineSubGoal manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineSubGoalDtls baselineSubGoalDtls = new curam.serviceplans.sl.entity.struct.BaselineSubGoalDtls();

    // BaselinePlanItem manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselinePlanItemDtls baselinePlanItemDtls = new curam.serviceplans.sl.entity.struct.BaselinePlanItemDtls();

    // BEGIN, CR00000224, PMD
    // BaselineServiceUnitDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselineServiceUnitDelivery baselineServiceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.BaselineServiceUnitDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtls baselineServiceUnitDeliveryDtls = new curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtls();

    // ServiceUnitDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();
    curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList = new curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList();
    // END, CR00000224

    // PlannedGoal manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    // PlannedGroup manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    // PlannedSubGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
    PlannedItemDtlsList plannedItemDtlsList = new PlannedItemDtlsList();

    curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForBaselineList plannedSubGoalDetailsForBaselineList;

    // PlannedItem manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // baseline name
    final StringBuffer baselineName = new StringBuffer();

    // service plan delivery key
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = details.caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOBASELINE.ERR_CREATE_BASELINE_PARTICIPANT_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // return value
    final BaselineIDDetails baselineIDDetails = new BaselineIDDetails();

    // BEGIN, CR00234999, TV
    curam.serviceplans.sl.entity.struct.TrackingGanttGoalDetails trackingGanttGoalDetails;

    // read planned goal ID
    // If planned Goal does not exist - throw an error.
    try {
      trackingGanttGoalDetails = plannedGoalObj.readGoalGroupDetailsForTrackingGanttByCaseID(
        servicePlanDeliveryKey);
      // END, CR00234999
    } catch (final RecordNotFoundException e) {
      throw new AppException(
        BPOBASELINE.ERR_BASELINE_RV_CREATE_PLANNED_GOAL_MUST_EXIST);
    }

    plannedGoalKey.plannedGoalID = trackingGanttGoalDetails.plannedGoalID;

    // create baseline
    baselineDtls.createdBy = TransactionInfo.getProgramUser();
    baselineDtls.creationDateTime = DateTime.getCurrentDateTime();
    baselineDtls.typeCode = BASELINETYPE.APPROVAL;
    baselineDtls.plannedGoalID = plannedGoalKey.plannedGoalID;
    baselineDtls.goalName = trackingGanttGoalDetails.goalName;
    baselineDtls.typeCode = details.typeCode;
    baselineDtls.expectedStartDate = trackingGanttGoalDetails.expectedStartDate;
    baselineDtls.expectedEndDate = trackingGanttGoalDetails.expectedEndDate;
    baselineDtls.actualStartDate = trackingGanttGoalDetails.actualStartDate;
    baselineDtls.actualEndDate = trackingGanttGoalDetails.actualEndDate;

    if (details.typeCode.equals(BASELINETYPE.APPROVAL)) {

      // count existing approval baselines
      countBaselineByPlannedGoalIDAndTypeKey.plannedGoalID = plannedGoalKey.plannedGoalID;
      countBaselineByPlannedGoalIDAndTypeKey.typeCode = BASELINETYPE.APPROVAL;
      final BaselineCountDetails baselineCountDetails = baselineObj.countByPlannedGoalIDAndType(
        countBaselineByPlannedGoalIDAndTypeKey);

      // add approval number to the baseline name
      // BEGIN, CR00274279, PS
      baselineName.append(new AppException(BPOBASELINE.INF_BASELINE_NAME_APPROVAL).getMessage(TransactionInfo.getProgramLocale())).append(
        baselineCountDetails.recordCount + 1);
      // END, CR00274279

      baselineDtls.name = baselineName.toString();

    } else if (details.typeCode.equals(BASELINETYPE.APPROVALSUBMISSION)) {

      // count existing submission baselines
      countBaselineByPlannedGoalIDAndTypeKey.plannedGoalID = plannedGoalKey.plannedGoalID;
      countBaselineByPlannedGoalIDAndTypeKey.typeCode = BASELINETYPE.APPROVALSUBMISSION;
      final BaselineCountDetails baselineCountDetails = baselineObj.countByPlannedGoalIDAndType(
        countBaselineByPlannedGoalIDAndTypeKey);

      // BEGIN, CR00274279, PS
      baselineName.append(new AppException(BPOBASELINE.INF_BASELINE_NAME_APPROVAL_SUBMISSION).getMessage(TransactionInfo.getProgramLocale())).append(
        baselineCountDetails.recordCount + 1);
      // END, CR00274279
      baselineDtls.name = baselineName.toString();

    } else if (details.typeCode.equals(BASELINETYPE.CLONING)) {

      // BEGIN CR00109848, MC
      final LocalisableString baseLineName = new LocalisableString(
        BPOBASELINE.INF_BASELINE_NAME_CLONE_TIMESTAMP);

      baseLineName.arg(DateTime.getCurrentDateTime());
      // BEGIN, CR00274279, PS
      baselineDtls.name = baseLineName.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00274279
      // END CR00109848
    } else {
      baselineDtls.name = details.name;
      baselineDtls.comments = details.comments;
      baselineDtls.typeCode = BASELINETYPE.MANUAL;

      // strip whitespace from both sides of name string
      details.name = details.name.trim();

      final StringBuffer name = new StringBuffer(details.name);

      // if there is a space between the words longer than one reduce it to
      // exactly one space. This algorithm to remove space between words
      // originally appeared in the validate details operation on the entity
      // layer
      for (int i = 0; i < name.length(); i++) {
        if (name.charAt(i) == CuramConst.gkSpaceChar
          && name.charAt(i + 1) == CuramConst.gkSpaceChar) {
          name.deleteCharAt(i + 1);
          i--;
        }
      }

      details.name = name.toString();

      // Newly created manual baseline name must not match any name predefined
      // for automatic baseline creation
      if (details.name.startsWith(kBaselineApprovalConstant)
        || details.name.startsWith(kBaselineSubmissionApprovalConstant)
        || details.name.startsWith(kBaselineClone)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOBASELINE.ERR_CREATE_BASELINE_FV_NAME_MATCHES_SYSTEM_CREATED_BASELINE_NAME),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // insert baseline
    baselineObj.insert(baselineDtls);

    // return baseline unique identifier
    baselineIDDetails.baselineIDDetails.baseLineID = baselineDtls.baseLineID;

    // BEGIN, CR00057481, PMD
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    // Get the list of milestones at service plan level

    // BEGIN, CR00236665, GP
    BaselineMilestoneDtlsList baselineMilestoneDtlsList = new BaselineMilestoneDtlsList();
    final MilestoneDeliveryAndConfigDetailsList milestoneDeliveryAndConfigDetailsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesForBaselineByCaseID1(
      caseHeaderKey);
    BaselineMilestoneDtls baselineMilestoneDtls;

    for (final MilestoneDeliveryAndConfigDetails milestoneDeliveryAndConfigDetails : milestoneDeliveryAndConfigDetailsList.dtls.items()) {

      baselineMilestoneDtls = new BaselineMilestoneDtls();
      baselineMilestoneDtls.actualEndDate = milestoneDeliveryAndConfigDetails.actualEndDate;
      baselineMilestoneDtls.actualStartDate = milestoneDeliveryAndConfigDetails.actualStartDate;
      baselineMilestoneDtls.expectedEndDate = milestoneDeliveryAndConfigDetails.expectedEndDate;
      baselineMilestoneDtls.expectedStartDate = milestoneDeliveryAndConfigDetails.expectedStartDate;
      baselineMilestoneDtls.milestoneDeliveryID = milestoneDeliveryAndConfigDetails.milestoneDeliveryID;

      // Read the localized name.
      if (0 != milestoneDeliveryAndConfigDetails.nameTextID) {

        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.nameTextID);

        baselineMilestoneDtls.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      // Read the localized type.
      if (0 != milestoneDeliveryAndConfigDetails.typeTextID) {

        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.typeTextID);

        baselineMilestoneDtls.type = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      baselineMilestoneDtlsList.dtls.addRef(baselineMilestoneDtls);

    }

    // END, CR00236665
    BaselineMilestoneDetailsList baselineMilestoneDetailsList = new BaselineMilestoneDetailsList();

    baselineMilestoneDetailsList.dtlsList.assign(baselineMilestoneDtlsList);

    final BaselineKey baselineKey = new BaselineKey();

    baselineKey.baselineKey.baseLineID = baselineDtls.baseLineID;

    // Create the baseline milestone.
    createMilestoneBaseline(baselineKey, baselineMilestoneDetailsList);
    // END, CR00057481

    // create BaselinePlanGroup records
    createBaselineComponentsDetails.baselineIDDetails = baselineIDDetails;
    createBaselineComponentsDetails.list = plannedGroupObj.searchDetailsByPlannedGoalID(
      plannedGoalKey);

    // call recursive method
    createBaselineComponents(createBaselineComponentsDetails);

    // search details about sub goals
    plannedSubGoalDetailsForBaselineList = plannedSubGoalObj.searchDetailsByPlannedGoalID(
      plannedGoalKey);

    baselineSubGoalDtls.baseLineID = baselineDtls.baseLineID;

    for (int i = 0; i < plannedSubGoalDetailsForBaselineList.dtls.size(); i++) {

      baselineSubGoalDtls.name = plannedSubGoalDetailsForBaselineList.dtls.item(i).name;
      baselineSubGoalDtls.plannedSubGoalID = plannedSubGoalDetailsForBaselineList.dtls.item(i).plannedSubGoalID;
      baselineSubGoalDtls.sensitivityCode = plannedSubGoalDetailsForBaselineList.dtls.item(i).sensitivityCode;
      baselineSubGoalDtls.typeCode = plannedSubGoalDetailsForBaselineList.dtls.item(i).typeCode;
      baselineSubGoalDtls.expectedStartDate = plannedSubGoalDetailsForBaselineList.dtls.item(i).expectedStartDate;
      baselineSubGoalDtls.expectedEndDate = plannedSubGoalDetailsForBaselineList.dtls.item(i).expectedEndDate;
      baselineSubGoalDtls.actualStartDate = plannedSubGoalDetailsForBaselineList.dtls.item(i).actualStartDate;
      baselineSubGoalDtls.actualEndDate = plannedSubGoalDetailsForBaselineList.dtls.item(i).actualEndDate;

      // create baseline sub goal record
      baselineSubGoalObj.insert(baselineSubGoalDtls);

      // search details about planItems for sub goal
      plannedSubGoalKey.plannedSubGoalID = baselineSubGoalDtls.plannedSubGoalID;

      // BEGIN, CR00057481, PMD
      // Get the list of milestones at subgoal level

      // BEGIN, CR00236665, GP

      // BEGIN, CR00237630, MR
      baselineMilestoneDtlsList = new BaselineMilestoneDtlsList();
      // END, CR00237630
      final MilestoneAndPlannedSubGoalDetailsList milestoneAndPlannedSubGoalDetailsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesForBaselineByPlannedSubGoalID1(
        plannedSubGoalKey);

      for (final MilestoneAndPlannedSubGoalDetails milestoneAndPlannedSubGoalDetails : milestoneAndPlannedSubGoalDetailsList.dtls.items()) {

        baselineMilestoneDtls = new BaselineMilestoneDtls();
        baselineMilestoneDtls.actualEndDate = milestoneAndPlannedSubGoalDetails.actualEndDate;
        baselineMilestoneDtls.actualStartDate = milestoneAndPlannedSubGoalDetails.actualStartDate;
        baselineMilestoneDtls.expectedEndDate = milestoneAndPlannedSubGoalDetails.expectedEndDate;
        baselineMilestoneDtls.expectedStartDate = milestoneAndPlannedSubGoalDetails.expectedStartDate;
        baselineMilestoneDtls.milestoneDeliveryID = milestoneAndPlannedSubGoalDetails.milestoneDeliveryID;
        baselineMilestoneDtls.plannedSubGoalID = milestoneAndPlannedSubGoalDetails.plannedSubGoalID;

        // Read the localized name.
        if (0 != milestoneAndPlannedSubGoalDetails.nameTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            milestoneAndPlannedSubGoalDetails.nameTextID);

          baselineMilestoneDtls.name = localizableText.getValue(
            LOCALEEntry.get(
              ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        }
        // Read the localized type.
        if (0 != milestoneAndPlannedSubGoalDetails.typeTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            milestoneAndPlannedSubGoalDetails.typeTextID);

          baselineMilestoneDtls.type = localizableText.getValue(
            LOCALEEntry.get(
              ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        }
        baselineMilestoneDtlsList.dtls.addRef(baselineMilestoneDtls);
      }
      // END, CR00236665

      baselineMilestoneDetailsList = new BaselineMilestoneDetailsList();
      baselineMilestoneDetailsList.dtlsList.assign(baselineMilestoneDtlsList);

      // Create the baseline milestone.
      createMilestoneBaseline(baselineKey, baselineMilestoneDetailsList);
      // END, CR00057481
      // BEGIN, CR00117766, ANK
      plannedItemDtlsList = plannedItemObj.searchByPlannedSubGoalID(
        plannedSubGoalKey);

      ViewPlannedItemDetails viewPlannedItemDetails = new ViewPlannedItemDetails();

      // PlannedItem business object
      final curam.serviceplans.sl.intf.PlannedItem plannedItem = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

      final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

      for (int j = 0; j < plannedItemDtlsList.dtls.size(); j++) {

        baselinePlanItemDtls.assign(plannedItemDtlsList.dtls.item(j));
        plannedItemIDKey.plannedItemIDKey.plannedItemID = baselinePlanItemDtls.plannedItemID;
        viewPlannedItemDetails = plannedItem.readPlannedItemDetails(
          plannedItemIDKey);

        // Read the planned item details snap shot to baseline
        baselinePlanItemDtls.caseID = viewPlannedItemDetails.caseID;
        baselinePlanItemDtls.subGoalName = viewPlannedItemDetails.subGoalName;
        baselinePlanItemDtls.outcomeName = viewPlannedItemDetails.outcomeName;
        baselinePlanItemDtls.userFullName = viewPlannedItemDetails.userFullName;
        baselinePlanItemDtls.planItemRespUserFullName = viewPlannedItemDetails.planItemRespUserFullName;
        baselinePlanItemDtls.planItemRespUserFullName = viewPlannedItemDetails.planItemRespUserFullName;
        baselinePlanItemDtls.planItemResponsibilityName = viewPlannedItemDetails.planItemResponsibilityName;
        baselinePlanItemDtls.concerningName = viewPlannedItemDetails.concerningName;
        baselinePlanItemDtls.caseParticipantRoleID = viewPlannedItemDetails.caseParticipantRoleID;
        baselinePlanItemDtls.goodCauseName = viewPlannedItemDetails.goodCauseName;
        // END, CR00117766

        baselinePlanItemDtls.baselineSubGoalID = baselineSubGoalDtls.baselineSubGoalID;

        // insert baseline planItem
        baselinePlanItemObj.insert(baselinePlanItemDtls);

        // BEGIN, CR00000224, PMD
        // Search for Service Unit Details for Planned Item
        final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

        plannedItemIDStatus.plannedItemID = baselinePlanItemDtls.plannedItemID;
        plannedItemIDStatus.recordStatus = RECORDSTATUS.NORMAL;

        serviceUnitDeliveryDtlsList = serviceUnitDeliveryObj.searchByPlannedItemIDAndStatus(
          plannedItemIDStatus);

        for (int k = 0; k < serviceUnitDeliveryDtlsList.dtls.size(); k++) {

          baselineServiceUnitDeliveryDtls.baselinePlanItemID = baselinePlanItemDtls.baselinePlanItemID;
          baselineServiceUnitDeliveryDtls.comments = serviceUnitDeliveryDtlsList.dtls.item(k).comments;
          baselineServiceUnitDeliveryDtls.deliveryDate = serviceUnitDeliveryDtlsList.dtls.item(k).deliveryDate;
          baselineServiceUnitDeliveryDtls.numberOfUnits = serviceUnitDeliveryDtlsList.dtls.item(k).numberofUnits;
          baselineServiceUnitDeliveryDtls.recordedBy = serviceUnitDeliveryDtlsList.dtls.item(k).recordedBy;
          baselineServiceUnitDeliveryDtls.recordedDate = serviceUnitDeliveryDtlsList.dtls.item(k).recordedDate;
          baselineServiceUnitDeliveryDtls.relatedID = serviceUnitDeliveryDtlsList.dtls.item(k).relatedID;
          baselineServiceUnitDeliveryDtls.relatedType = serviceUnitDeliveryDtlsList.dtls.item(k).relatedType;
          baselineServiceUnitDeliveryDtls.serviceUnitDeliveryID = serviceUnitDeliveryDtlsList.dtls.item(k).serviceUnitDeliveryID;

          // Insert baseline service unit delivery
          baselineServiceUnitDeliveryObj.insert(baselineServiceUnitDeliveryDtls);
        }
        // END, CR00000224
      }
    }

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // Read service plan id.
    servicePlanDeliveryKey.caseID = details.caseID;
    final ServicePlanDelivery servicePlanDeliveryobj = ServicePlanDeliveryFactory.newInstance();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // set security check key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    servicePlanDeliveryKey.caseID = details.caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryobj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_CREATE_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_CREATE_BASELINE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    return baselineIDDetails;
  }

  /**
   * Returns a list of all baselines for a particular service plan.
   *
   * @param baselineCaseIDKey
   * Contains the caseID key for the specific service plan.
   *
   * @return List of baselines for the service plan.
   *
   * @throws AppException
   * {@link BPOBASELINE#ERR_LIST_BASELINE_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to
   * view this page.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE#ERR_LIST_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to
   * view this list page. a baseline for this service plan.
   */
  @Override
  public BaselineListDetails list(final BaselineCaseIDKey baselineCaseIDKey)
    throws AppException, InformationalException {

    // Create return object
    final BaselineListDetails baselineListDetails = new BaselineListDetails();

    // Baseline manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // Call entity operation to retrieve list of contract records
    baselineListDetails.baselineForServicePlanDetailsList = baselineObj.searchByCaseID(
      baselineCaseIDKey.baselineCaseIDKey);

    // User manipulation variables
    final Users usersObj = UsersFactory.newInstance();

    for (int i = 0; i
      < baselineListDetails.baselineForServicePlanDetailsList.dtls.size(); i++) {

      BaselineForServicePlanDetails baselineForServicePlanDetails = new BaselineForServicePlanDetails();

      final UsersKey createdByUsersKey = new UsersKey();

      baselineForServicePlanDetails = baselineListDetails.baselineForServicePlanDetailsList.dtls.item(
        i);

      if (baselineForServicePlanDetails.createdBy != null
        && baselineForServicePlanDetails.createdBy.length() != 0) {
        createdByUsersKey.userName = baselineForServicePlanDetails.createdBy;

        baselineListDetails.baselineForServicePlanDetailsList.dtls.item(i).createdByFullName = usersObj.getFullName(createdByUsersKey).fullname;
      }
    }

    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = baselineCaseIDKey.baselineCaseIDKey.caseID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;
    caseHeaderKey.caseID = baselineCaseIDKey.baselineCaseIDKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_LIST_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_LIST_BASELINE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    // return list
    return baselineListDetails;
  }

  /**
   * Modifies a baseline.
   *
   * @param modifyBaselineDetails
   * Contains the baseline details to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE#ERR_MODIFY_BASELINE_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to
   * modify this baseline.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if
   * the user does not have the required privileges to access this
   * data.
   * @throws AppException
   * {@link BPOBASELINE# ERR_MODIFY_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to
   * modify this baseline.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} -
   * if the user does not have the required privileges to maintain
   * this data.
   */
  @Override
  public void modify(ModifyBaselineDetails modifyBaselineDetails)
    throws AppException, InformationalException {

    // Baseline manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();

    // Set key to modify baseline record
    baselineKey.baseLineID = modifyBaselineDetails.baselineDtls.baseLineID;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = baselineObj.readCaseIDByBaselineID(baselineKey).caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOBASELINE.ERR_MODIFY_BASELINE_PARTICIPANT_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_MODIFY_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_MODIFY_BASELINE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Call entity operation to modify baseline record
    baselineObj.modify(baselineKey, modifyBaselineDetails.baselineDtls);
  }

  /**
   * Reads the details of a specific baseline.
   *
   * @param baselineKey
   * Contains the baseline key.
   *
   * @return Details of the requested baseline.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE#ERR_MODIFY_BASELINE_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to modify
   * this baseline.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link BPOBASELINE# ERR_MODIFY_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify
   * this baseline.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   */
  @Override
  public ReadBaselineDetails read(BaselineKey baselineKey)
    throws AppException, InformationalException {

    // create return struct
    final ReadBaselineDetails readBaselineDetails = new ReadBaselineDetails();

    // Contract manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();

    // User manipulation variables
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey createdByUsersKey = new UsersKey();

    // Call entity operation to read baseline record
    readBaselineDetails.baselineDtls = baselineObj.read(baselineKey.baselineKey);

    // Set the full name of the created by user
    if (readBaselineDetails.baselineDtls.createdBy != null
      && readBaselineDetails.baselineDtls.createdBy.length() != 0) {

      createdByUsersKey.userName = readBaselineDetails.baselineDtls.createdBy;
      readBaselineDetails.createdByFullName = usersObj.getFullName(createdByUsersKey).fullname;
    }

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = baselineObj.readCaseIDByBaselineID(baselineKey.baselineKey).caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
    readBaselineDetails.caseID = caseHeaderKey.caseID;
    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_VIEW_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_VIEW_BASELINE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // return details
    return readBaselineDetails;
  }

  /**
   * Physically removes a baseline from the database.
   *
   * @param baselineKey
   * Contains the baseline key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE# ERR_DELETE_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to delete
   * this baseline.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link BPOBASELINE#ERR_DELETE_BASELINE_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to delete
   * this baseline.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   */
  @Override
  public void remove(BaselineKey baselineKey) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = baselineObj.readCaseIDByBaselineID(baselineKey.baselineKey).caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOBASELINE.ERR_DELETE_BASELINE_PARTICIPANT_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_DELETE_SERVICEPLAN_BASELINE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_DELETE_BASELINE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Call for a physical removed based
    baselineObj.remove(baselineKey.baselineKey);

  }

  /**
   * Returns all planned sub-goals of a specific baseline.
   *
   * @param baselineKey
   * Contains baseline key.
   *
   * @return List of all planned sub-goals of the requested baseline.
   *
   * @throws AppException
   * {@link BPOBASELINE# ERR_LIST_BASELINE_SUBGOAL_PARTICIPANT_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE# ERR_LIST_SERVICEPLAN_BASELINE__SUBGOAL_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this list page.
   */
  @Override
  public BaselineSubGoalListDetails listSubgoalsBaseline(
    BaselineKey baselineKey) throws AppException, InformationalException {

    final BaselineSubGoalListDetails baselineSubGoalListDetails = new BaselineSubGoalListDetails();

    final BaselineSubGoal baselineSubGoalObj = BaselineSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = baselineObj.readCaseIDByBaselineID(baselineKey.baselineKey).caseID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;
    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_LIST_SERVICEPLAN_BASELINE__SUBGOAL_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_LIST_BASELINE_SUBGOAL_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    baselineSubGoalListDetails.baselineSubGoalByBaselineIDDetailsList = baselineSubGoalObj.searchByBaselineID(
      baselineKey.baselineKey);

    return baselineSubGoalListDetails;
  }

  /**
   * Returns a planned sub-goal details with it's planned items and milestone
   * details based on a baseline identifier and planned sub-goal identifier.
   *
   * @param key
   * Contains baseline planned subgoal key.
   *
   * @return Details of a planned sub-goal details and planned items details of
   * the requested baseline and sub-goal identifier.
   *
   * @throws AppException
   * {@link BPOBASELINE# ERR_VIEW_BASELINE_SUBGOAL_PARTICIPANT_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view
   * this baseline subgoal.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE# ERR_VIEW_SERVICEPLAN_BASELINE__SUBGOAL_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this list page.
   */
  @Override
  public BaselineSubGoalWithPlanItemsDetails readSubgoalBaseline(
    BaselineSubGoalKey key) throws AppException, InformationalException {

    // return structure
    final BaselineSubGoalWithPlanItemsDetails baselineSubGoalWithPlanItemsDetails = new BaselineSubGoalWithPlanItemsDetails();

    final BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();
    final curam.serviceplans.sl.entity.struct.BaselineSubGoalDtls baselineSubGoalDtls = baselineSubGoalObj.read(
      key.key);

    baselineKey.baseLineID = baselineSubGoalDtls.baseLineID;

    baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.baseLineID = baselineKey.baseLineID;
    baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.baselineName = baselineObj.readName(baselineKey).name;
    baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.plannedSubGoalID = baselineSubGoalDtls.plannedSubGoalID;
    baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.subgoalName = baselineSubGoalDtls.name;
    baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.sensitivityCode = baselineSubGoalDtls.sensitivityCode;
    baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.typeCode = baselineSubGoalDtls.typeCode;

    final BaselinePlanItem baselinePlanItemObj = BaselinePlanItemFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // CaseHeader variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = TransactionInfo.getProgramUser();

    // Get baseline sensitivity
    final BaselineSensitivityCode baselineSensitivityCode = baselineSubGoalObj.readSensitivityCode(
      key.key);

    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    servicePlanDeliveryKey.caseID = baselineSubGoalObj.readCaseIDByBaselineSubGoalID(key.key).caseID;

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;
    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    baselineSubGoalWithPlanItemsDetails.baselinePlanItemByBaselineSubGoalIDDetailsList = baselinePlanItemObj.searchByBaselineSubGoalID(
      key.key);

    // BEGIN, CR00057481, PMD
    final BaselinePlannedSubGoalKey baselinePlannedSubGoalKey = new BaselinePlannedSubGoalKey();

    // Set the key to search for the sub-goal milestones
    baselinePlannedSubGoalKey.baseLineID = baselineSubGoalDtls.baseLineID;
    baselinePlannedSubGoalKey.plannedSubGoalID = baselineSubGoalDtls.plannedSubGoalID;

    final BaselineMilestoneListDetailsList baselineMilestoneListDetailsList = new BaselineMilestoneListDetailsList();

    // Get the list of milestones for the subgoal
    baselineMilestoneListDetailsList.listDetails = BaselineMilestoneFactory.newInstance().searchByBaselineIDAndPlannedSubGoalID(
      baselinePlannedSubGoalKey);

    // Assign the sub-goal milestone list to the return struct
    baselineSubGoalWithPlanItemsDetails.milestoneList.assign(
      baselineMilestoneListDetailsList);
    // END, CR00057481

    // Read the sub goal name and assign to return struct
    baselineSubGoalWithPlanItemsDetails.subGoalName = // BEGIN, HARP 47921, BF
      baselineSubGoalWithPlanItemsDetails.baselineSubGoalDetails.subgoalName;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.ERR_VIEW_SERVICEPLAN_BASELINE__SUBGOAL_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Also do a sensitivity check for user
    // if sub goal baseline sensitivity higher than user sensitivity then throw
    // error.
    if (Integer.parseInt(baselineSensitivityCode.sensitivityCode)
      > Integer.parseInt(userSecurityDetails.sensitivity)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOBASELINE.ERR_VIEW_BASELINE_SUBGOAL_PARTICIPANT_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    return baselineSubGoalWithPlanItemsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns an XML document containing comparison information required for the
   * baseline comparison Gantt chart control.
   *
   * @param key Contains baseline keys to be compared.
   *
   * @return Document containing the XML required for the baseline comparison
   * Gantt chart control.
   */
  @Override
  public curam.serviceplans.sl.struct.BaselineCompareDetails compare(
    final BaselineCompareKey key) throws AppException, InformationalException {

    // return value
    final curam.serviceplans.sl.struct.BaselineCompareDetails baselineCompareDetails = new curam.serviceplans.sl.struct.BaselineCompareDetails();

    // Planned Goal manipulation variables
    final curam.serviceplans.sl.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // baseline manipulation variables
    final curam.serviceplans.sl.struct.BaselineKey baselineKey = new curam.serviceplans.sl.struct.BaselineKey();
    ComparisonLevelDetailsList comparedItemDetails;

    // validate comparison details
    validateCompare(key);

    // set the key to read original baseline details
    baselineKey.baselineKey.baseLineID = key.originalBaselineID;

    // read original baseline details
    final ComparisonLevelDetailsList originalBaselineDetails = readComparisonDetails(
      baselineKey);

    // map baseline name to returned struct
    baselineCompareDetails.baselineName = originalBaselineDetails.name;

    // read compared item details (another baseline or service plan delivery)
    if (key.currentPlanInd == true) {
      // compared item is current service plan delivery
      servicePlanDeliveryKey.key.caseID = key.caseID;
      comparedItemDetails = plannedGoalObj.readComparisonDetails(
        servicePlanDeliveryKey);
      baselineCompareDetails.comparedItemName = BPOBASELINE.INF_COMPARED_WITH_CURRENT_PLAN.toString();
    } else {
      // compared item is another baseline
      baselineKey.baselineKey.baseLineID = key.selectedBaselineID;
      comparedItemDetails = readComparisonDetails(baselineKey);
      baselineCompareDetails.comparedItemName = comparedItemDetails.name;

    }

    // create XML details to be returned
    baselineCompareDetails.baselineComparisonGanttDetails = createComparisonGanttDetails(
      originalBaselineDetails, comparedItemDetails);

    // return XML details
    return baselineCompareDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates an XML string to be shown as Gantt diagram.
   *
   * @param originalBaselineDetails Contains baseline details for comparison
   * @param comparedItemDetails Contains details about another baseline or
   * current service plan delivery
   *
   * @return Comparison details in form of an XML string
   */
  @Override
  public BaselineComparisonGanttDetails createComparisonGanttDetails(
    final ComparisonLevelDetailsList originalBaselineDetails,
    final ComparisonLevelDetailsList comparedItemDetails)
    throws AppException, InformationalException {

    // return value
    final BaselineComparisonGanttDetails baselineComparisonGanttDetails = new BaselineComparisonGanttDetails();

    // create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    // create child node GOAL
    final Element goalElement = new Element(kGoal);

    goalElement.setAttribute(kName,
      originalBaselineDetails.baselineGoalDetails.name);

    // original baseline start and end dates
    if (originalBaselineDetails.baselineGoalDetails.actualStartDate.isZero()) {
      goalElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      goalElement.setAttribute(kTopStart,
        String.valueOf(
        originalBaselineDetails.baselineGoalDetails.actualStartDate));
    }

    if (originalBaselineDetails.baselineGoalDetails.actualEndDate.isZero()) {
      goalElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      goalElement.setAttribute(kTopEnd,
        String.valueOf(
        originalBaselineDetails.baselineGoalDetails.actualEndDate));
    }

    // compared item start and end dates
    if (comparedItemDetails.baselineGoalDetails.actualStartDate.isZero()) {
      goalElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      goalElement.setAttribute(kBottomStart,
        String.valueOf(comparedItemDetails.baselineGoalDetails.actualStartDate));
    }

    if (comparedItemDetails.baselineGoalDetails.actualEndDate.isZero()) {
      goalElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      goalElement.setAttribute(kBottomEnd,
        String.valueOf(comparedItemDetails.baselineGoalDetails.actualEndDate));
    }

    goalElement.setAttribute(kID,
      String.valueOf(originalBaselineDetails.baselineGoalDetails.goalID));
    goalElement.setAttribute(kType, kGoal);

    // form XML details for Gantt
    final BaselineGanttElementList baselineGanttElementList = createBaselineTags(
      originalBaselineDetails, comparedItemDetails);

    final curam.serviceplans.sl.struct.PlannedGroupKey plannedGroupKey = new curam.serviceplans.sl.struct.PlannedGroupKey();

    // set the key for the first level elements
    plannedGroupKey.key.plannedGroupID = 0;

    // add elements to the Goal (initially, parent groupID is 0)
    addElementContent(goalElement, plannedGroupKey, baselineGanttElementList);

    // add goal to gantt
    ganttElement.addContent(goalElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    baselineComparisonGanttDetails.baselineXMLString = outputter.outputString(
      ganttElement);

    // return details
    return baselineComparisonGanttDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads current baseline name and the list of all existing baselines for the
   * service plan.
   *
   * @param key Contains service plan delivery ID and current baseline ID
   *
   * @return Current baseline name and the list of all existing baselines for
   * the service plan delivery
   */
  @Override
  public ExistingBaselinesDetails readBaselinesForComparison(
    final BaselineIDAndCaseIDKey key) throws AppException,
      InformationalException {

    // return value
    final ExistingBaselinesDetails existingBaselinesDetails = new ExistingBaselinesDetails();

    // Baseline entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();

    // set current baseline key
    baselineKey.baseLineID = key.baselineIDAndCaseIDKey.baseLineID;

    // read current baseline name
    existingBaselinesDetails.baselineNameDetails = baselineObj.readName(
      baselineKey);

    // list existing baselines for the service plan delivery
    // (excluding current baseline from the list)
    existingBaselinesDetails.baselineNameAndIDDetailsList = baselineObj.searchNameAndIDByCaseID(
      key.baselineIDAndCaseIDKey);

    // return details
    return existingBaselinesDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns baseline details to be compared with another baseline or with
   * current service plan details
   *
   * @param key Contains baseline unique ID
   *
   * @return Goal, planned group, sub goal and plan item details for comparison.
   */
  @Override
  public ComparisonLevelDetailsList readComparisonDetails(
    final BaselineKey key) throws AppException, InformationalException {

    // return details
    curam.serviceplans.sl.struct.ComparisonLevelDetailsList comparisonLevelDetailsList = new curam.serviceplans.sl.struct.ComparisonLevelDetailsList();
    // an element of the returned list
    curam.serviceplans.sl.entity.struct.ComparisonLevelDetails comparisonLevelDetails;

    // Sub Goal and associated Planned Items
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails baselineComparisonSubGoalAndAssociatedPlannedItemsDetails;

    // Baseline entity
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();

    // PlannedGroupKey
    final curam.serviceplans.sl.struct.BaselineAndPlannedGroupComparisonKey baselineAndPlannedGroupComparisonKey = new curam.serviceplans.sl.struct.BaselineAndPlannedGroupComparisonKey();

    // Baseline plan group entity variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroupObj = curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList;

    // Baseline sub goal entity variables
    final curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineSubGoalComparisonKey baselineSubGoalComparisonKey = new curam.serviceplans.sl.entity.struct.BaselineSubGoalComparisonKey();

    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList;

    // Baseline plan item entity variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselinePlanItemComparisonKey baselinePlanItemComparisonKey = new curam.serviceplans.sl.entity.struct.BaselinePlanItemComparisonKey();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetailsList baselineComparisonPlanItemDetailsList;

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode sensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      usersKey);
    // END, CR00098617

    // read baseline name
    final curam.serviceplans.sl.entity.struct.BaselineNameDetails baselineNameDetails = baselineObj.readName(
      key.baselineKey);

    comparisonLevelDetailsList.name = baselineNameDetails.name;

    // read baseline goal details
    comparisonLevelDetailsList.baselineGoalDetails = baselineObj.readBaselineGoalDetails(
      key.baselineKey);

    comparisonLevelDetails = new curam.serviceplans.sl.entity.struct.ComparisonLevelDetails();

    // list all sub goals directly assigned to planned goal
    baselineSubGoalComparisonKey.baseLineID = key.baselineKey.baseLineID;
    baselineSubGoalComparisonKey.sensitivityCode = sensitivityCode.sensitivity;
    baselineComparisonSubGoalDetailsList = baselineSubGoalObj.searchDetailsByBaselineIDAndSensitivityNoGroup(
      baselineSubGoalComparisonKey);

    // search for planned items associated with sub goal
    for (int i = 0; i < baselineComparisonSubGoalDetailsList.dtls.size(); i++) {

      // create returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails = new curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails();

      // add sub goal details
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.subGoalDetails.assign(
        baselineComparisonSubGoalDetailsList.dtls.item(i));

      // read baseline plan item comparison details
      baselinePlanItemComparisonKey.baselineSubGoalID = baselineComparisonSubGoalDetailsList.dtls.item(i).baselineSubGoalID;
      baselinePlanItemComparisonKey.sensitivityCode = sensitivityCode.sensitivity;
      baselineComparisonPlanItemDetailsList = baselinePlanItemObj.searchPlanItemDetailsByBaselineSubGoalIDAndSensitivity(
        baselinePlanItemComparisonKey);

      // add baseline plan item details list to the returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.plannedItemList.assign(
        baselineComparisonPlanItemDetailsList);

      comparisonLevelDetails.subGoalList.addRef(
        baselineComparisonSubGoalAndAssociatedPlannedItemsDetails);
    }

    // list all planned groups directly assigned to planned goal
    baselineComparisonPlannedGroupDetailsList = baselinePlanGroupObj.searchDetailsByBaselineIDNoGroup(
      baselineSubGoalComparisonKey);

    // add the list to the returned struct
    comparisonLevelDetails.plannedGroupList.assign(
      baselineComparisonPlannedGroupDetailsList);
    comparisonLevelDetails.plannedGroupID = baselineAndPlannedGroupComparisonKey.key.plannedGroupID;

    // add the details to the list
    comparisonLevelDetailsList.comparisonLevelDetails.addRef(
      comparisonLevelDetails);

    // add the rest to the list
    for (int j = 0; j < baselineComparisonPlannedGroupDetailsList.dtls.size(); j++) {

      // set the key
      baselineAndPlannedGroupComparisonKey.key.plannedGroupID = baselineComparisonPlannedGroupDetailsList.dtls.item(j).plannedGroupID;
      baselineAndPlannedGroupComparisonKey.key.baseLineID = key.baselineKey.baseLineID;
      baselineAndPlannedGroupComparisonKey.key.sensitivityCode = sensitivityCode.sensitivity;

      // list comparison details for planned group
      comparisonLevelDetailsList = listComparisonDetailsForPlannedGroup(
        baselineAndPlannedGroupComparisonKey, comparisonLevelDetailsList);

    }

    // return details
    return comparisonLevelDetailsList;
  }

  /**
   * Validates comparison details.
   *
   * @param key
   * Contains baseline keys to be compared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE#ERR_COMPARE_BASELINE_SECURITY_FAILED} - if the
   * user does not have the appropriate privileges to compare
   * baselines.
   * @throws AppException
   * {@link BPOBASELINE#ERR_XFV_COMPARE_BASELINE_GOALS_DIFFERENT} - if
   * the item that you have selected to compare against this baseline
   * does not have the same goal. You may only compare items with the
   * same goal.
   * @throws AppException
   * {@link BPOBASELINE#ERR_XFV_SELECTED_BOTH_COMPARE_VALUES} - if the
   * user have not selected either a baseline or the current plan.
   * @throws AppException
   * {@link BPOBASELINE#ERR_XFV_COMPARE_VALUE_NOT_SELECTED} - if the
   * user have not selected a baseline or the current version of the
   * plan to compare against this baseline.
   */
  @Override
  public void validateCompare(BaselineCompareKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery entity variables
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // Planned goal entity variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // Baseline entity variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();

    // CaseHeader entity variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    servicePlanDeliveryKey.caseID = key.caseID;

    // set service plan security key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)
        || e.equals(
          BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(BPOBASELINE.ERR_COMPARE_BASELINE_SECURITY_FAILED);
      } else {
        throw e;
      }
    }

    // either baseline or current plan must be selected, not both
    if (key.currentPlanInd == true && key.selectedBaselineID != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOBASELINE.ERR_XFV_SELECTED_BOTH_COMPARE_VALUES),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // one of baseline or current plan must be selected
    if (key.currentPlanInd == false && key.selectedBaselineID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOBASELINE.ERR_XFV_COMPARE_VALUE_NOT_SELECTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // read current baseline's goal
    baselineKey.baseLineID = key.originalBaselineID;
    final BaselineGoalNameDetails originalGoalName = baselineObj.readGoalName(
      baselineKey);

    // read goal name of the selected item
    BaselineGoalNameDetails goalNameDetails = new BaselineGoalNameDetails();

    if (key.currentPlanInd == true) {
      servicePlanDeliveryKey.caseID = key.caseID;

      final GoalNameDetails name = plannedGoalObj.readGoalNameByCaseID(
        servicePlanDeliveryKey);

      goalNameDetails.goalName = name.name;

    } else {
      baselineKey.baseLineID = key.selectedBaselineID;
      goalNameDetails = baselineObj.readGoalName(baselineKey);
    }

    // Goal names for the two compared items must be the same.
    if (originalGoalName.goalName.compareTo(goalNameDetails.goalName) != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOBASELINE.ERR_XFV_COMPARE_BASELINE_GOALS_DIFFERENT),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Takes in lists of baseline planItems assigned to two baseline sub goals
   * that are to be compared. Returns a list of baseline plan item details
   * formated for appearance in the GANTT diagram.
   *
   * @param list1
   * Contains baseline planItems assigned to the original baseline
   * sub goal
   * @param list2
   * Contains baseline planItems assigned to the baseline sub goal
   * which is to be compared
   *
   * @return list of baseline sub goal plan item details formated for in order
   * they should appear on the Gantt diagram
   */
  @Override
  public BaselinePlanItemGanttElementList createBaselinePlanItemTags(
    final BaselineComparisonPlanItemDetailsList list1,
    final BaselineComparisonPlanItemDetailsList list2) throws AppException,
      InformationalException {

    // return value
    final BaselinePlanItemGanttElementList baselinePlanItemGanttElementList = new BaselinePlanItemGanttElementList();

    // an element of the returned list
    curam.serviceplans.sl.struct.BaselinePlanItemGanttElement baselinePlanItemGanttElement;

    // iterate through first list of planItems
    for (int i = 0; i < list1.baselineComparisonPlanItemDetailsList.dtls.size(); i++) {

      // create new plan item element
      baselinePlanItemGanttElement = new curam.serviceplans.sl.struct.BaselinePlanItemGanttElement();

      // set the details
      baselinePlanItemGanttElement.baselinePlanItemID = list1.baselineComparisonPlanItemDetailsList.dtls.item(i).plannedItemID;
      baselinePlanItemGanttElement.name = list1.baselineComparisonPlanItemDetailsList.dtls.item(i).name;
      baselinePlanItemGanttElement.topExpectedStartDate = list1.baselineComparisonPlanItemDetailsList.dtls.item(i).expectedStartDate;
      baselinePlanItemGanttElement.topExpectedEndDate = list1.baselineComparisonPlanItemDetailsList.dtls.item(i).expectedEndDate;
      baselinePlanItemGanttElement.topActualStartDate = list1.baselineComparisonPlanItemDetailsList.dtls.item(i).actualStartDate;
      baselinePlanItemGanttElement.topActualEndDate = list1.baselineComparisonPlanItemDetailsList.dtls.item(i).actualEndDate;

      boolean foundInTheSecondList = false;

      // iterate through second list of plan items
      for (int j = 0; j
        < list2.baselineComparisonPlanItemDetailsList.dtls.size(); j++) {

        // find the plan item with the same name
        if (list1.baselineComparisonPlanItemDetailsList.dtls.item(i).plannedItemID
          == list2.baselineComparisonPlanItemDetailsList.dtls.item(j).plannedItemID) {

          foundInTheSecondList = true;

          // set bottom date values
          baselinePlanItemGanttElement.bottomExpectedStartDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).expectedStartDate;
          baselinePlanItemGanttElement.bottomExpectedEndDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).expectedEndDate;
          baselinePlanItemGanttElement.bottomActualStartDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).actualStartDate;
          baselinePlanItemGanttElement.bottomActualEndDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).actualEndDate;

        }

        if (foundInTheSecondList) {
          // remove it from the second list
          list2.baselineComparisonPlanItemDetailsList.dtls.remove(j);
          j--;
          break;

        }
      }

      if (!foundInTheSecondList) {
        // set bottom values to zero date
        baselinePlanItemGanttElement.bottomExpectedStartDate = curam.util.type.Date.kZeroDate;
        baselinePlanItemGanttElement.bottomExpectedEndDate = curam.util.type.Date.kZeroDate;
        baselinePlanItemGanttElement.bottomActualStartDate = curam.util.type.Date.kZeroDate;
        baselinePlanItemGanttElement.bottomActualEndDate = curam.util.type.Date.kZeroDate;
      }

      // add the plan item element to the return list
      baselinePlanItemGanttElementList.baselinePlanItemGanttElement.addRef(
        baselinePlanItemGanttElement);

    }

    // iterate through the rest of the second list
    for (int j = 0; j < list2.baselineComparisonPlanItemDetailsList.dtls.size(); j++) {

      // create new plan item element
      baselinePlanItemGanttElement = new curam.serviceplans.sl.struct.BaselinePlanItemGanttElement();

      // set the details
      baselinePlanItemGanttElement.baselinePlanItemID = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).plannedItemID;
      baselinePlanItemGanttElement.name = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).name;
      baselinePlanItemGanttElement.topExpectedStartDate = curam.util.type.Date.kZeroDate;
      baselinePlanItemGanttElement.topExpectedEndDate = curam.util.type.Date.kZeroDate;
      baselinePlanItemGanttElement.topActualStartDate = curam.util.type.Date.kZeroDate;
      baselinePlanItemGanttElement.topActualEndDate = curam.util.type.Date.kZeroDate;
      baselinePlanItemGanttElement.bottomExpectedStartDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).expectedStartDate;
      baselinePlanItemGanttElement.bottomExpectedEndDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).expectedEndDate;
      baselinePlanItemGanttElement.bottomActualStartDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).actualStartDate;
      baselinePlanItemGanttElement.bottomActualEndDate = list2.baselineComparisonPlanItemDetailsList.dtls.item(j).actualEndDate;

      // add the plan item element to the return list
      baselinePlanItemGanttElementList.baselinePlanItemGanttElement.addRef(
        baselinePlanItemGanttElement);
    }

    // return baseline plan item gantt element list
    return baselinePlanItemGanttElementList;
  }

  // ___________________________________________________________________________
  /**
   * Takes in lists of baseline subgoals assigned to two baselines that are to
   * be compared. Returns a list of baseline subgoal details formated for
   * appearance in the GANTT diagram.
   *
   * @param list1 Contains baseline sub goals assigned to the original baseline
   * @param list2 Contains baseline sub goals assigned to the baseline which is
   * to be compared
   *
   * @return list of baseline sub goal details formated for in order they should
   * appear on the Gantt diagram
   */
  @Override
  public BaselineSubGoalGanttElementList createBaselineSubGoalTags(
    final BaselineComparisonSubGoalDetailsList list1,
    final BaselineComparisonSubGoalDetailsList list2) throws AppException,
      InformationalException {

    // return value
    final BaselineSubGoalGanttElementList baselineSubGoalGanttElementList = new BaselineSubGoalGanttElementList();

    // an element of the returned list
    curam.serviceplans.sl.struct.BaselineSubGoalGanttElement baselineSubGoalGanttElement;

    // iterate through first list of sub goals
    for (int i = 0; i < list1.list.size(); i++) {

      // create a new sub goal element
      baselineSubGoalGanttElement = new curam.serviceplans.sl.struct.BaselineSubGoalGanttElement();

      // set the details
      baselineSubGoalGanttElement.baselineSubGoalID = list1.list.item(i).baselineSubGoalID;
      baselineSubGoalGanttElement.plannedSubGoalID = list1.list.item(i).plannedSubGoalID;
      baselineSubGoalGanttElement.name = list1.list.item(i).name;
      baselineSubGoalGanttElement.topExpectedStartDate = list1.list.item(i).expectedStartDate;
      baselineSubGoalGanttElement.topExpectedEndDate = list1.list.item(i).expectedEndDate;
      baselineSubGoalGanttElement.topActualStartDate = list1.list.item(i).actualStartDate;
      baselineSubGoalGanttElement.topActualEndDate = list1.list.item(i).actualEndDate;

      boolean foundInTheSecondList = false;

      // iterate through second list of sub goals
      for (int j = 0; j < list2.list.size(); j++) {

        // find the sub goal with the same planned sub goal
        if (list1.list.item(i).plannedSubGoalID
          == list2.list.item(j).plannedSubGoalID) {

          foundInTheSecondList = true;

          // set bottom date values
          baselineSubGoalGanttElement.bottomExpectedStartDate = list2.list.item(j).expectedStartDate;
          baselineSubGoalGanttElement.bottomExpectedEndDate = list2.list.item(j).expectedEndDate;
          baselineSubGoalGanttElement.bottomActualStartDate = list2.list.item(j).actualStartDate;
          baselineSubGoalGanttElement.bottomActualEndDate = list2.list.item(j).actualEndDate;

        }

        if (foundInTheSecondList) {

          // create original baseline sub goal planItems list
          final BaselineComparisonPlanItemDetailsList originalBaselinePlanItemList = new BaselineComparisonPlanItemDetailsList();

          originalBaselinePlanItemList.baselineComparisonPlanItemDetailsList.assign(
            list1.list.item(i).baselineComparisonPlanItemDetailsList);

          // create compared baseline sub goal planItems list
          final BaselineComparisonPlanItemDetailsList comparedBaselinePlanItemList = new BaselineComparisonPlanItemDetailsList();

          comparedBaselinePlanItemList.baselineComparisonPlanItemDetailsList.assign(
            list2.list.item(j).baselineComparisonPlanItemDetailsList);

          final BaselinePlanItemGanttElementList baselinePlanItemGanttElementList = createBaselinePlanItemTags(
            originalBaselinePlanItemList, comparedBaselinePlanItemList);

          // add list of baseline planItems to the returned struct
          baselineSubGoalGanttElement.assign(baselinePlanItemGanttElementList);

          // remove baseline sub goal details from the second list
          list2.list.remove(j);
          j--;
          break;
        }
      }

      if (!foundInTheSecondList) {
        // set bottom values to zero date
        baselineSubGoalGanttElement.bottomExpectedStartDate = curam.util.type.Date.kZeroDate;
        baselineSubGoalGanttElement.bottomExpectedEndDate = curam.util.type.Date.kZeroDate;
        baselineSubGoalGanttElement.bottomActualStartDate = curam.util.type.Date.kZeroDate;
        baselineSubGoalGanttElement.bottomActualEndDate = curam.util.type.Date.kZeroDate;

        // create original baseline sub goal planItems list
        final BaselineComparisonPlanItemDetailsList originalBaselinePlanItemList = new BaselineComparisonPlanItemDetailsList();

        originalBaselinePlanItemList.baselineComparisonPlanItemDetailsList.assign(
          list1.list.item(i).baselineComparisonPlanItemDetailsList);

        // create compared baseline sub goal planItems list (leave it empty)
        final BaselineComparisonPlanItemDetailsList comparedBaselinePlanItemList = new BaselineComparisonPlanItemDetailsList();

        final BaselinePlanItemGanttElementList baselinePlanItemGanttElementList = createBaselinePlanItemTags(
          originalBaselinePlanItemList, comparedBaselinePlanItemList);

        // add list of baseline planItems to the returned struct
        baselineSubGoalGanttElement.assign(baselinePlanItemGanttElementList);

      }

      // add the sub goal element to the return list
      baselineSubGoalGanttElementList.baselineSubGoalGanttElement.addRef(
        baselineSubGoalGanttElement);
    }

    // iterate through the rest of the second list
    for (int j = 0; j < list2.list.size(); j++) {

      // create a new sub goal element
      baselineSubGoalGanttElement = new curam.serviceplans.sl.struct.BaselineSubGoalGanttElement();

      // set the details
      baselineSubGoalGanttElement.baselineSubGoalID = list2.list.item(j).baselineSubGoalID;
      baselineSubGoalGanttElement.plannedSubGoalID = list2.list.item(j).plannedSubGoalID;
      baselineSubGoalGanttElement.name = list2.list.item(j).name;
      baselineSubGoalGanttElement.topExpectedStartDate = curam.util.type.Date.kZeroDate;
      baselineSubGoalGanttElement.topExpectedEndDate = curam.util.type.Date.kZeroDate;
      baselineSubGoalGanttElement.topActualStartDate = curam.util.type.Date.kZeroDate;
      baselineSubGoalGanttElement.topActualEndDate = curam.util.type.Date.kZeroDate;
      baselineSubGoalGanttElement.bottomExpectedStartDate = list2.list.item(j).expectedStartDate;
      baselineSubGoalGanttElement.bottomExpectedEndDate = list2.list.item(j).expectedEndDate;
      baselineSubGoalGanttElement.bottomActualStartDate = list2.list.item(j).actualStartDate;
      baselineSubGoalGanttElement.bottomActualEndDate = list2.list.item(j).actualEndDate;

      // create original baseline sub goal planItems list (leave it empty)
      final BaselineComparisonPlanItemDetailsList originalBaselinePlanItemList = new BaselineComparisonPlanItemDetailsList();

      // create compared baseline sub goal planItems list
      final BaselineComparisonPlanItemDetailsList comparedBaselinePlanItemList = new BaselineComparisonPlanItemDetailsList();

      comparedBaselinePlanItemList.baselineComparisonPlanItemDetailsList.assign(
        list2.list.item(j).baselineComparisonPlanItemDetailsList);

      final BaselinePlanItemGanttElementList baselinePlanItemGanttElementList = createBaselinePlanItemTags(
        originalBaselinePlanItemList, comparedBaselinePlanItemList);

      // add list of baseline planItems to the returned struct
      baselineSubGoalGanttElement.assign(baselinePlanItemGanttElementList);

      // add the sub goal element to the return list
      baselineSubGoalGanttElementList.baselineSubGoalGanttElement.addRef(
        baselineSubGoalGanttElement);

    }

    // return baseline sub goal gantt element list
    return baselineSubGoalGanttElementList;

  }

  // ___________________________________________________________________________
  /**
   * Takes in lists of plannedGroups and adds each planned group to the
   * baseline along with any subgoals and child planned groups that may be
   * contained within each planned group.
   *
   * @param createBaselineComponentsDetails
   * Contains the baselineID of the baseline that the planned
   * groups are to be added to, and the list of the details for all
   * the planned groups
   */
  @Override
  public void createBaselineComponents(
    final CreateBaselineComponentsDetails createBaselineComponentsDetails)
    throws AppException, InformationalException {

    // BaselinePlannedGroup manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroupObj = curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory.newInstance();
    final curam.serviceplans.sl.struct.CreateBaselineComponentsDetails createChildBaselineComponentsDetails = new curam.serviceplans.sl.struct.CreateBaselineComponentsDetails();
    final curam.serviceplans.sl.entity.struct.BaselinePlanGroupDtls baselinePlanGroupDtls = new curam.serviceplans.sl.entity.struct.BaselinePlanGroupDtls();

    // BaselineSubGoal manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineSubGoalDtls baselineSubGoalDtls = new curam.serviceplans.sl.entity.struct.BaselineSubGoalDtls();

    // BaselinePlanItem manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselinePlanItemDtls baselinePlanItemDtls = new curam.serviceplans.sl.entity.struct.BaselinePlanItemDtls();

    // BEGIN, CR00000224, PMD
    // BaselineServiceUnitDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.BaselineServiceUnitDelivery baselineServiceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.BaselineServiceUnitDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtls baselineServiceUnitDeliveryDtls = new curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtls();

    // ServiceUnitDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();
    curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList = new curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList();
    // END, CR00000224

    // PlannedGroup manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedGroupKey plannedGroupKey = new curam.serviceplans.sl.entity.struct.PlannedGroupKey();

    // PlannedSubGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForBaselineList plannedSubGoalDetailsForBaselineList;

    // PlannedItem manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedItemDetailsForBaselineList plannedItemDetailsForBaselineList;

    // set baselinePlanGroupDetails
    baselinePlanGroupDtls.baselineID = createBaselineComponentsDetails.baselineIDDetails.baselineIDDetails.baseLineID;

    for (int i = 0; i < createBaselineComponentsDetails.list.dtls.size(); i++) {

      baselinePlanGroupDtls.plannedGroupID = createBaselineComponentsDetails.list.dtls.item(i).plannedGroupID;
      baselinePlanGroupDtls.parentGroupID = createBaselineComponentsDetails.list.dtls.item(i).parentGroupID;
      baselinePlanGroupDtls.plannedGroupName = createBaselineComponentsDetails.list.dtls.item(i).plannedGroupName;
      baselinePlanGroupDtls.actualEndDate = createBaselineComponentsDetails.list.dtls.item(i).actualEndDate;
      baselinePlanGroupDtls.actualStartDate = createBaselineComponentsDetails.list.dtls.item(i).actualStartDate;
      baselinePlanGroupDtls.expectedEndDate = createBaselineComponentsDetails.list.dtls.item(i).expectedEndDate;
      baselinePlanGroupDtls.expectedStartDate = createBaselineComponentsDetails.list.dtls.item(i).expectedStartDate;

      baselinePlanGroupObj.insert(baselinePlanGroupDtls);

      // set plannedGroupKey
      plannedGroupKey.plannedGroupID = baselinePlanGroupDtls.plannedGroupID;

      // set baseline id
      createChildBaselineComponentsDetails.baselineIDDetails.baselineIDDetails.baseLineID = baselinePlanGroupDtls.baselineID;

      // BEGIN, CR00057481, PMD
      // Get the list of milestones at plan group level
      // BEGIN, CR00236665, GP
      BaselineMilestoneDtlsList baselineMilestoneDtlsList = new BaselineMilestoneDtlsList();
      final MilestoneAndPlannedGroupDetailsList milestoneAndPlannedGroupDetailsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesForBaselineByPlannedGroupID1(
        plannedGroupKey);
      BaselineMilestoneDtls baselineMilestoneDtls;

      for (final MilestoneAndPlannedGroupDetails milestoneAndPlannedGroupDetails : milestoneAndPlannedGroupDetailsList.dtls.items()) {

        baselineMilestoneDtls = new BaselineMilestoneDtls();
        baselineMilestoneDtls.actualEndDate = milestoneAndPlannedGroupDetails.actualEndDate;
        baselineMilestoneDtls.actualStartDate = milestoneAndPlannedGroupDetails.actualStartDate;
        baselineMilestoneDtls.expectedEndDate = milestoneAndPlannedGroupDetails.expectedEndDate;
        baselineMilestoneDtls.expectedStartDate = milestoneAndPlannedGroupDetails.expectedStartDate;
        baselineMilestoneDtls.milestoneDeliveryID = milestoneAndPlannedGroupDetails.milestoneDeliveryID;
        baselineMilestoneDtls.plannedSubGoalID = milestoneAndPlannedGroupDetails.plannedGroupID;

        // BEGIN, CR00293824, SK
        baselineMilestoneDtls.plannedGroupID = milestoneAndPlannedGroupDetails.plannedGroupID;
        // END, CR00293824

        // Read the localized name.
        if (0 != milestoneAndPlannedGroupDetails.nameTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            milestoneAndPlannedGroupDetails.nameTextID);

          baselineMilestoneDtls.name = localizableText.getValue(
            LOCALEEntry.get(
              ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        }
        // Read the localized type.
        if (0 != milestoneAndPlannedGroupDetails.typeTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            milestoneAndPlannedGroupDetails.typeTextID);

          baselineMilestoneDtls.type = localizableText.getValue(
            LOCALEEntry.get(
              ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        }
        baselineMilestoneDtlsList.dtls.addRef(baselineMilestoneDtls);
      }
      // END, CR00236665

      BaselineMilestoneDetailsList baselineMilestoneDetailsList = new BaselineMilestoneDetailsList();

      baselineMilestoneDetailsList.dtlsList.assign(baselineMilestoneDtlsList);

      final BaselineKey baselineKey = new BaselineKey();

      baselineKey.baselineKey.baseLineID = baselinePlanGroupDtls.baselineID;

      // Create the baseline milestone.
      createMilestoneBaseline(baselineKey, baselineMilestoneDetailsList);
      // END, CR00057481

      // read child planned Groups
      createChildBaselineComponentsDetails.list = plannedGroupObj.searchChildGroupsForBaseline(
        plannedGroupKey);

      // call recursive method
      createBaselineComponents(createChildBaselineComponentsDetails);

      // search details about sub goals
      plannedSubGoalDetailsForBaselineList = plannedSubGoalObj.searchDetailsByPlannedGroupID(
        plannedGroupKey);

      baselineSubGoalDtls.baseLineID = createBaselineComponentsDetails.baselineIDDetails.baselineIDDetails.baseLineID;
      baselineSubGoalDtls.plannedGroupID = plannedGroupKey.plannedGroupID;

      for (int j = 0; j < plannedSubGoalDetailsForBaselineList.dtls.size(); j++) {

        baselineSubGoalDtls.name = plannedSubGoalDetailsForBaselineList.dtls.item(j).name;
        baselineSubGoalDtls.plannedSubGoalID = plannedSubGoalDetailsForBaselineList.dtls.item(j).plannedSubGoalID;
        baselineSubGoalDtls.sensitivityCode = plannedSubGoalDetailsForBaselineList.dtls.item(j).sensitivityCode;
        baselineSubGoalDtls.typeCode = plannedSubGoalDetailsForBaselineList.dtls.item(j).typeCode;
        baselineSubGoalDtls.actualStartDate = plannedSubGoalDetailsForBaselineList.dtls.item(j).actualStartDate;
        baselineSubGoalDtls.actualEndDate = plannedSubGoalDetailsForBaselineList.dtls.item(j).actualEndDate;
        baselineSubGoalDtls.expectedStartDate = plannedSubGoalDetailsForBaselineList.dtls.item(j).expectedStartDate;
        baselineSubGoalDtls.expectedEndDate = plannedSubGoalDetailsForBaselineList.dtls.item(j).expectedEndDate;

        // create baseline sub goal record
        baselineSubGoalObj.insert(baselineSubGoalDtls);
        // search details about planItems for sub goal
        plannedSubGoalKey.plannedSubGoalID = baselineSubGoalDtls.plannedSubGoalID;

        // BEGIN, CR00057481, PMD
        // Get the list of milestones at sub goal level

        // BEGIN, CR00236665, GP
        // BEGIN, CR00293824, SK
        baselineMilestoneDtlsList = new BaselineMilestoneDtlsList();
        // END, CR00293824

        final MilestoneAndPlannedSubGoalDetailsList milestoneAndPlannedSubGoalDetailsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesForBaselineByPlannedSubGoalID1(
          plannedSubGoalKey);

        for (final MilestoneAndPlannedSubGoalDetails milestoneAndPlannedSubGoalDetails : milestoneAndPlannedSubGoalDetailsList.dtls.items()) {

          baselineMilestoneDtls = new BaselineMilestoneDtls();
          baselineMilestoneDtls.actualEndDate = milestoneAndPlannedSubGoalDetails.actualEndDate;
          baselineMilestoneDtls.actualStartDate = milestoneAndPlannedSubGoalDetails.actualStartDate;
          baselineMilestoneDtls.expectedEndDate = milestoneAndPlannedSubGoalDetails.expectedEndDate;
          baselineMilestoneDtls.expectedStartDate = milestoneAndPlannedSubGoalDetails.expectedStartDate;
          baselineMilestoneDtls.milestoneDeliveryID = milestoneAndPlannedSubGoalDetails.milestoneDeliveryID;
          baselineMilestoneDtls.plannedSubGoalID = milestoneAndPlannedSubGoalDetails.plannedSubGoalID;

          // Read the localized name.
          if (0 != milestoneAndPlannedSubGoalDetails.nameTextID) {

            final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
              milestoneAndPlannedSubGoalDetails.nameTextID);

            baselineMilestoneDtls.name = localizableText.getValue(
              LOCALEEntry.get(
                ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
          }
          // Read the localized type.
          if (0 != milestoneAndPlannedSubGoalDetails.typeTextID) {

            final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
              milestoneAndPlannedSubGoalDetails.typeTextID);

            baselineMilestoneDtls.type = localizableText.getValue(
              LOCALEEntry.get(
                ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
          }
          baselineMilestoneDtlsList.dtls.addRef(baselineMilestoneDtls);
        }
        // END, CR00236665

        baselineMilestoneDetailsList = new BaselineMilestoneDetailsList();
        baselineMilestoneDetailsList.dtlsList.assign(baselineMilestoneDtlsList);

        // Create the baseline milestone.
        createMilestoneBaseline(baselineKey, baselineMilestoneDetailsList);
        // END, CR00057481

        plannedItemDetailsForBaselineList = plannedItemObj.searchDetailsByPlannedSubGoal(
          plannedSubGoalKey);

        for (int k = 0; k < plannedItemDetailsForBaselineList.dtls.size(); k++) {

          baselinePlanItemDtls.actualEndDate = plannedItemDetailsForBaselineList.dtls.item(k).actualEndDate;
          baselinePlanItemDtls.actualStartDate = plannedItemDetailsForBaselineList.dtls.item(k).actualStartDate;
          baselinePlanItemDtls.expectedEndDate = plannedItemDetailsForBaselineList.dtls.item(k).expectedEndDate;
          baselinePlanItemDtls.expectedStartDate = plannedItemDetailsForBaselineList.dtls.item(k).expectedStartDate;
          baselinePlanItemDtls.plannedItemID = plannedItemDetailsForBaselineList.dtls.item(k).plannedItemID;
          baselinePlanItemDtls.name = plannedItemDetailsForBaselineList.dtls.item(k).name;
          baselinePlanItemDtls.sensitivityCode = plannedItemDetailsForBaselineList.dtls.item(k).sensitivityCode;
          baselinePlanItemDtls.typeCode = plannedItemDetailsForBaselineList.dtls.item(k).typeCode;

          // BEGIN, CR00000224, PMD
          baselinePlanItemDtls.authorizedUnits = plannedItemDetailsForBaselineList.dtls.item(k).authorizedUnits;
          // END, CR00000224

          baselinePlanItemDtls.baselineSubGoalID = baselineSubGoalDtls.baselineSubGoalID;

          // insert baseline planItem
          baselinePlanItemObj.insert(baselinePlanItemDtls);

          // BEGIN, CR00000224, PMD
          // Search for Service Unit Details for Planned Item
          final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

          plannedItemIDStatus.plannedItemID = baselinePlanItemDtls.plannedItemID;
          plannedItemIDStatus.recordStatus = RECORDSTATUS.NORMAL;

          serviceUnitDeliveryDtlsList = serviceUnitDeliveryObj.searchByPlannedItemIDAndStatus(
            plannedItemIDStatus);

          for (int l = 0; l < serviceUnitDeliveryDtlsList.dtls.size(); l++) {

            baselineServiceUnitDeliveryDtls.baselinePlanItemID = baselinePlanItemDtls.baselinePlanItemID;
            baselineServiceUnitDeliveryDtls.comments = serviceUnitDeliveryDtlsList.dtls.item(l).comments;
            baselineServiceUnitDeliveryDtls.deliveryDate = serviceUnitDeliveryDtlsList.dtls.item(l).deliveryDate;
            baselineServiceUnitDeliveryDtls.numberOfUnits = serviceUnitDeliveryDtlsList.dtls.item(l).numberofUnits;
            baselineServiceUnitDeliveryDtls.recordedBy = serviceUnitDeliveryDtlsList.dtls.item(l).recordedBy;
            baselineServiceUnitDeliveryDtls.recordedDate = serviceUnitDeliveryDtlsList.dtls.item(l).recordedDate;
            baselineServiceUnitDeliveryDtls.relatedID = serviceUnitDeliveryDtlsList.dtls.item(l).relatedID;
            baselineServiceUnitDeliveryDtls.relatedType = serviceUnitDeliveryDtlsList.dtls.item(l).relatedType;
            baselineServiceUnitDeliveryDtls.serviceUnitDeliveryID = serviceUnitDeliveryDtlsList.dtls.item(l).serviceUnitDeliveryID;

            // Insert baseline service unit delivery
            baselineServiceUnitDeliveryObj.insert(
              baselineServiceUnitDeliveryDtls);
          }

          // END, CR00000224
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates Baseline Gantt XML String from the readGantt details.
   *
   * @param details Contains unique id of the baseline.
   *
   * @return XML Gantt Details.
   */
  @Override
  public BaselineGanttXmlDetails createBaselineGanttXmlString(
    final ReadBaselineGanttDetails details) throws AppException,
      InformationalException {

    // Create return struct
    final BaselineGanttXmlDetails baselineGanttXmlDetails = new BaselineGanttXmlDetails();

    // Baseline plan group entity variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroupObj = curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList;
    final curam.serviceplans.sl.entity.struct.BaselineSubGoalComparisonKey baselineSubGoalComparisonKey = new curam.serviceplans.sl.entity.struct.BaselineSubGoalComparisonKey();

    // create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    // create child node GOAL
    Element goalElement = new Element(kGoal);

    goalElement.setAttribute(kName, details.baselineGanttGoalDetails.name);

    // For each date we have to check if dates not set and if so replace
    // with empty string. As widget does not like dates not set for planned
    // Goal.

    // BEGIN, CR00219204, SW
    // Goal Expected Start date
    if (details.baselineGanttGoalDetails.expectedStartDate.isZero()) {
      goalElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      goalElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        details.baselineGanttGoalDetails.expectedStartDate, kGanttDateFormat));
    }
    // Goal Expected End date
    if (details.baselineGanttGoalDetails.expectedEndDate.isZero()) {
      goalElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      goalElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        details.baselineGanttGoalDetails.expectedEndDate, kGanttDateFormat));
    }

    // Goal Actual Start and End dates
    if (details.baselineGanttGoalDetails.actualStartDate.isZero()) {
      goalElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      goalElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        details.baselineGanttGoalDetails.actualStartDate, kGanttDateFormat));
    }

    if (details.baselineGanttGoalDetails.actualEndDate.isZero()) {
      goalElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      goalElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        details.baselineGanttGoalDetails.actualEndDate, kGanttDateFormat));
    }
    // END, CR00219204

    // Planned Goal entity
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    plannedGoalKey.plannedGoalID = details.baselineGanttGoalDetails.plannedGoalID;
    goalElement.setAttribute(kID,
      String.valueOf(plannedGoalObj.readGoalID(plannedGoalKey).goalID));
    goalElement.setAttribute(kType, kGoal);

    // BEGIN, CR00058141, PMD
    // Create xml for service plan level milestones
    for (int i = 0; i < details.baselineGanttMilestoneDetails.dtls.size(); i++) {

      Element milestoneElement = new Element(kMilestone);

      milestoneElement = createMilestoneXML(
        details.baselineGanttMilestoneDetails.dtls.item(i));

      // Update the goal element with all the milestone elements found.
      goalElement.addContent(milestoneElement);
    }
    // END, CR00058141

    baselineSubGoalComparisonKey.baseLineID = details.baseLineID;

    baselineComparisonPlannedGroupDetailsList = baselinePlanGroupObj.searchDetailsByBaselineIDNoGroup(
      baselineSubGoalComparisonKey);

    for (int i = 0; i < baselineComparisonPlannedGroupDetailsList.dtls.size(); i++) {
      Element plannedGroupElement = new Element(kPlannedGroup);

      plannedGroupElement = createPlannedGroupXML(
        baselineComparisonPlannedGroupDetailsList.dtls.item(i));

      // Update the goal element with all the plan group elements found.
      goalElement.addContent(plannedGroupElement);
    }

    // Updates the goal element with all the sub goal/plan items element details
    goalElement = createPlannedSubGoalXMLStringForListPassedIn(details,
      goalElement);
    // add goal to gantt
    ganttElement.addContent(goalElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    baselineGanttXmlDetails.baselineGanttXmlString = outputter.outputString(
      ganttElement);

    // return details
    return baselineGanttXmlDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads Baseline details required to create the Gantt XML String.
   *
   * @param key Contains unique id of the baseline.
   *
   * @return Baseline Gantt Details.
   */
  @Override
  public ReadBaselineGanttDetails readGanttDetailsForBaseline(
    final BaselineKey key) throws AppException, InformationalException {

    // return details
    final curam.serviceplans.sl.struct.ReadBaselineGanttDetails readBaselineGanttDetails = new curam.serviceplans.sl.struct.ReadBaselineGanttDetails();

    // Planned sub goal entity variables
    final curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.BaselinePlanItemComparisonKey baselinePlanItemComparisonKey = new curam.serviceplans.sl.entity.struct.BaselinePlanItemComparisonKey();

    final BaselineSubGoalComparisonKey baselineSubGoalComparisonKey = new curam.serviceplans.sl.entity.struct.BaselineSubGoalComparisonKey();

    // Planned item entity variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();

    // Baseline service unit delivery entity variables
    final curam.serviceplans.sl.entity.intf.BaselineServiceUnitDelivery baselineServiceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.BaselineServiceUnitDeliveryFactory.newInstance();

    // Baseline entity variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();

    // read current user sensitivity
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode sensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      usersKey);
    // END, CR00098617

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = baselineObj.readCaseIDByBaselineID(key.baselineKey).caseID;

    // read goal details
    readBaselineGanttDetails.baselineGanttGoalDetails.assign(
      baselineObj.readBaselineGoalDetails(key.baselineKey));

    // BEGIN, CR00058141, PMD
    // List baseline milestones at service plan level
    curam.serviceplans.sl.entity.struct.BaselineMilestoneListDetailsList baselineMilestoneListDetailsList = BaselineMilestoneFactory.newInstance().searchBaselineMilestonesByBaselineID(
      key.baselineKey);

    // add milestone list to the returned struct
    readBaselineGanttDetails.baselineGanttMilestoneDetails.assign(
      baselineMilestoneListDetailsList);
    // END, CR00058141

    // set case ID and sensitivity key
    baselineSubGoalComparisonKey.baseLineID = key.baselineKey.baseLineID;
    baselineSubGoalComparisonKey.sensitivityCode = sensitivityCode.sensitivity;

    // read baseline sub goal details for baseline gantt
    final curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList = baselineSubGoalObj.searchDetailsByBaselineIDAndSensitivityNoGroup(
      baselineSubGoalComparisonKey);

    // BEGIN, CR00291735, SK
    for (final BaselineComparisonSubGoalDetails baselineComparisonSubGoalListDetails : baselineComparisonSubGoalDetailsList.dtls.items()) {

      final curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails baselineComparisonSubGoalDetails = new curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails();

      baselineComparisonSubGoalDetails.assign(
        baselineComparisonSubGoalListDetails);

      baselinePlanItemComparisonKey.baselineSubGoalID = baselineComparisonSubGoalDetails.baselineSubGoalID;

      baselinePlanItemComparisonKey.sensitivityCode = sensitivityCode.sensitivity;

      final curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetailsList baselineComparisonPlanItemDetailsList = baselinePlanItemObj.searchPlanItemDetailsByBaselineSubGoalIDAndSensitivity(
        baselinePlanItemComparisonKey);

      for (final BaselineComparisonPlanItemDetails baselineComparisonPlanItemDetails : baselineComparisonPlanItemDetailsList.dtls.items()) {

        final BaselinePlanItemKey baselinePlanItemKey = new BaselinePlanItemKey();

        baselinePlanItemKey.baselinePlanItemID = baselineComparisonPlanItemDetails.baselinePlanItemID;

        baselineComparisonPlanItemDetails.unitsReceivedToDate = baselineServiceUnitDeliveryObj.countBaselineServiceUnitDeliveriesByBaselinePlanItemID(baselinePlanItemKey).count;

        BaselineServiceUnitDeliveryDtlsList baselineServiceUnitDeliveryDtlsList = new BaselineServiceUnitDeliveryDtlsList();

        baselineServiceUnitDeliveryDtlsList = baselineServiceUnitDeliveryObj.searchByBaselinePlanItemID(
          baselinePlanItemKey);

        baselineComparisonPlanItemDetails.suList.assign(
          baselineServiceUnitDeliveryDtlsList);

        baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.dtls.addRef(
          baselineComparisonPlanItemDetails);
      }

      // BEGIN, CR00058141, PMD
      final BaselinePlannedSubGoalKey baselinePlannedSubGoalKey = new BaselinePlannedSubGoalKey();

      baselinePlannedSubGoalKey.baseLineID = key.baselineKey.baseLineID;
      baselinePlannedSubGoalKey.plannedSubGoalID = baselineComparisonSubGoalDetails.plannedSubGoalID;

      baselineMilestoneListDetailsList = BaselineMilestoneFactory.newInstance().searchByBaselineIDAndPlannedSubGoalID(
        baselinePlannedSubGoalKey);

      baselineComparisonSubGoalDetails.baselineGanttMilestoneDetails.assign(
        baselineMilestoneListDetailsList);
      // END, CR00058141

      readBaselineGanttDetails.baselineGanttSubGoalDetails.addRef(
        baselineComparisonSubGoalDetails);
      // END, CR00291735

    }
    // return details
    return readBaselineGanttDetails;
  }

  /**
   * Creates Baseline Gantt XML String from the readGantt details.
   *
   * @param key
   * Contains unique id of the baseline.
   *
   * @return XML Gantt Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOBASELINE#BASELINE_VIEW_GANTT_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * page.
   */
  @Override
  public BaselineGanttXmlDetails viewGantt(final BaselineKey key)
    throws AppException, InformationalException {

    BaselineGanttXmlDetails baselineGanttXmlDetails = new BaselineGanttXmlDetails();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery entity variables
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // Baseline entity variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = BaselineFactory.newInstance();

    // CaseHeader entity variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = baselineObj.readCaseIDByBaselineID(key.baselineKey).caseID;
    servicePlanDeliveryKey.caseID = caseHeaderKey.caseID;

    // set service plan security key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = // BEGIN,
      // HARP
      // 49527,
      // JM
      ServicePlanSecurity.kReadSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)
        || e.equals(
          BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOBASELINE.BASELINE_VIEW_GANTT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    ReadBaselineGanttDetails readBaselineGanttDetails;

    // Read baseline gantt details
    readBaselineGanttDetails = readGanttDetailsForBaseline(key);
    readBaselineGanttDetails.baseLineID = key.baselineKey.baseLineID;

    // create XML details to be returned
    baselineGanttXmlDetails = createBaselineGanttXmlString(
      readBaselineGanttDetails);

    // return XML details
    return baselineGanttXmlDetails;
  }

  // ___________________________________________________________________________
  /**
   * Takes in lists of baseline subgoals and planned groups assigned to two
   * baselines that are to be compared. Returns a list of baseline subgoal
   * details and baseline planned group details formated for appearance in the
   * GANTT diagram.
   *
   * @param list1 Contains baseline sub goals and planned groups of the original
   * baseline sub goal
   * @param list2 Contains baseline sub goals and planned groups of the baseline
   * which is to be compared
   *
   * @return list of baseline details formated for in order they should appear
   * on the Gantt diagram
   */
  @Override
  public BaselineGanttElementList createBaselineTags(
    final ComparisonLevelDetailsList list1,
    final ComparisonLevelDetailsList list2) throws AppException,
      InformationalException {

    // return value
    final BaselineGanttElementList baselineGanttElementList = new BaselineGanttElementList();

    // an element of the returned list
    curam.serviceplans.sl.struct.BaselineGanttElement baselineGanttElement;

    // Baseline sub goal Gantt element list
    BaselineSubGoalGanttElementList baselineSubGoalGanttElementList;

    // Lists of baseline sub goal details for comparison
    BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList1 = new BaselineComparisonSubGoalDetailsList();
    BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList2 = new BaselineComparisonSubGoalDetailsList();
    curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails baselineComparisonSubGoalDetails;

    // Lists of baseline planned groups for comparison
    BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList1;
    BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList2;

    // Planned Group Gantt element list
    PlannedGroupGanttElementList plannedGroupGanttElementList;

    // iterate through first list of details
    for (int i = 0; i < list1.comparisonLevelDetails.size(); i++) {

      // create returned element
      baselineGanttElement = new curam.serviceplans.sl.struct.BaselineGanttElement();
      baselineGanttElement.plannedGroupID = list1.comparisonLevelDetails.item(i).plannedGroupID;

      boolean foundInTheSecondList = false;

      // iterate through second list of details
      for (int j = 0; j < list2.comparisonLevelDetails.size(); j++) {

        if (list1.comparisonLevelDetails.item(i).plannedGroupID
          == list2.comparisonLevelDetails.item(j).plannedGroupID) {

          foundInTheSecondList = true;

          //
          // process sub goals
          //

          // create first list of sub goal details
          baselineComparisonSubGoalDetailsList1 = new BaselineComparisonSubGoalDetailsList();
          for (int ii = 0; ii
            < list1.comparisonLevelDetails.item(i).subGoalList.size(); ii++) {
            baselineComparisonSubGoalDetails = new curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails();

            // assign sub goal details
            baselineComparisonSubGoalDetails.assign(
              list1.comparisonLevelDetails.item(i).subGoalList.item(ii).subGoalDetails);

            // assign planned item list
            baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.assign(
              list1.comparisonLevelDetails.item(i).subGoalList.item(ii).plannedItemList);

            baselineComparisonSubGoalDetailsList1.list.addRef(
              baselineComparisonSubGoalDetails);
          }

          // create second list of sub goal details
          baselineComparisonSubGoalDetailsList2 = new BaselineComparisonSubGoalDetailsList();
          for (int jj = 0; jj
            < list2.comparisonLevelDetails.item(j).subGoalList.size(); jj++) {
            baselineComparisonSubGoalDetails = new curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails();

            // assign sub goal details
            baselineComparisonSubGoalDetails.assign(
              list2.comparisonLevelDetails.item(j).subGoalList.item(jj).subGoalDetails);

            // assign planned item list
            baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.assign(
              list2.comparisonLevelDetails.item(j).subGoalList.item(jj).plannedItemList);

            baselineComparisonSubGoalDetailsList2.list.addRef(
              baselineComparisonSubGoalDetails);
          }

          // create sub goal tags
          baselineSubGoalGanttElementList = createBaselineSubGoalTags(
            baselineComparisonSubGoalDetailsList1,
            baselineComparisonSubGoalDetailsList2);

          // add sub goal tags to the returned element
          baselineGanttElement.baselineSubGoalGanttElementList.assign(
            baselineSubGoalGanttElementList);

          //
          // process list of planned groups
          //
          baselineComparisonPlannedGroupDetailsList1 = new BaselineComparisonPlannedGroupDetailsList();
          baselineComparisonPlannedGroupDetailsList2 = new BaselineComparisonPlannedGroupDetailsList();

          BaselineComparisonPlannedGroupDetails listElement;

          for (int listIterator = 0; listIterator
            < list1.comparisonLevelDetails.item(i).plannedGroupList.dtls.size(); listIterator++) {

            listElement = new BaselineComparisonPlannedGroupDetails();
            listElement.assign(
              list1.comparisonLevelDetails.item(i).plannedGroupList.dtls.item(
                listIterator));
            baselineComparisonPlannedGroupDetailsList1.list.dtls.addRef(
              listElement);
          }

          for (int listIterator = 0; listIterator
            < list2.comparisonLevelDetails.item(j).plannedGroupList.dtls.size(); listIterator++) {

            listElement = new BaselineComparisonPlannedGroupDetails();
            listElement.assign(
              list2.comparisonLevelDetails.item(j).plannedGroupList.dtls.item(
                listIterator));
            baselineComparisonPlannedGroupDetailsList2.list.dtls.addRef(
              listElement);
          }

          // create baseline planned group tags
          plannedGroupGanttElementList = createBaselinePlannedGroupTags(
            baselineComparisonPlannedGroupDetailsList1,
            baselineComparisonPlannedGroupDetailsList2);

          // add planned group tags to the returned element
          baselineGanttElement.plannedGroupGanttElementList.assign(
            plannedGroupGanttElementList);

          // remove details from the second list
          list2.comparisonLevelDetails.remove(j);
          j--;
          break;
        }
      }
      if (!foundInTheSecondList) {
        //
        // process list of sub goals - leave second list empty
        //
        // create first list of sub goal details
        baselineComparisonSubGoalDetailsList1 = new BaselineComparisonSubGoalDetailsList();
        for (int ii = 0; ii
          < list1.comparisonLevelDetails.item(i).subGoalList.size(); ii++) {
          baselineComparisonSubGoalDetails = new curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails();

          // assign sub goal details
          baselineComparisonSubGoalDetails.assign(
            list1.comparisonLevelDetails.item(i).subGoalList.item(ii).subGoalDetails);

          // assign planned item list
          baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.assign(
            list1.comparisonLevelDetails.item(i).subGoalList.item(ii).plannedItemList);

          baselineComparisonSubGoalDetailsList1.list.addRef(
            baselineComparisonSubGoalDetails);
        }

        // create second list of sub goal details - leave it empty
        baselineComparisonSubGoalDetailsList2 = new BaselineComparisonSubGoalDetailsList();

        // create sub goal tags
        baselineSubGoalGanttElementList = createBaselineSubGoalTags(
          baselineComparisonSubGoalDetailsList1,
          baselineComparisonSubGoalDetailsList2);

        // add sub goal tags to the returned element
        baselineGanttElement.baselineSubGoalGanttElementList.assign(
          baselineSubGoalGanttElementList);

        //
        // process list of planned groups - leave the second list empty
        //
        baselineComparisonPlannedGroupDetailsList1 = new BaselineComparisonPlannedGroupDetailsList();
        baselineComparisonPlannedGroupDetailsList2 = new BaselineComparisonPlannedGroupDetailsList();

        baselineComparisonPlannedGroupDetailsList1.list.assign(
          list1.comparisonLevelDetails.item(i).plannedGroupList);

        // create baseline planned group tags
        plannedGroupGanttElementList = createBaselinePlannedGroupTags(
          baselineComparisonPlannedGroupDetailsList1,
          baselineComparisonPlannedGroupDetailsList2);

        // add planned group tags to the returned element
        baselineGanttElement.plannedGroupGanttElementList.assign(
          plannedGroupGanttElementList);

      }

      // add the details to the returned struct
      baselineGanttElementList.baselineGanttElement.addRef(baselineGanttElement);

    }// End iterate first list

    // iterate through the rest of the second list
    for (int j = 0; j < list2.comparisonLevelDetails.size(); j++) {

      // create returned element
      baselineGanttElement = new curam.serviceplans.sl.struct.BaselineGanttElement();
      baselineGanttElement.plannedGroupID = list2.comparisonLevelDetails.item(j).plannedGroupID;

      //
      // process sub goals - leave the first list empty
      //
      baselineComparisonSubGoalDetailsList1 = new BaselineComparisonSubGoalDetailsList();

      // create second list of sub goal details
      baselineComparisonSubGoalDetailsList2 = new BaselineComparisonSubGoalDetailsList();
      for (int jj = 0; jj
        < list2.comparisonLevelDetails.item(j).subGoalList.size(); jj++) {
        baselineComparisonSubGoalDetails = new curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails();

        // assign sub goal details
        baselineComparisonSubGoalDetails.assign(
          list2.comparisonLevelDetails.item(j).subGoalList.item(jj).subGoalDetails);

        // assign planned item list
        baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.assign(
          list2.comparisonLevelDetails.item(j).subGoalList.item(jj).plannedItemList);

        baselineComparisonSubGoalDetailsList2.list.addRef(
          baselineComparisonSubGoalDetails);
      }

      // create sub goal tags
      baselineSubGoalGanttElementList = createBaselineSubGoalTags(
        baselineComparisonSubGoalDetailsList1,
        baselineComparisonSubGoalDetailsList2);

      // add sub goal tags to the returned element
      baselineGanttElement.baselineSubGoalGanttElementList.assign(
        baselineSubGoalGanttElementList);

      //
      // process planned groups - leave the first list empty
      //
      baselineComparisonPlannedGroupDetailsList1 = new BaselineComparisonPlannedGroupDetailsList();
      baselineComparisonPlannedGroupDetailsList2 = new BaselineComparisonPlannedGroupDetailsList();

      baselineComparisonPlannedGroupDetailsList1.list.assign(
        list2.comparisonLevelDetails.item(j).plannedGroupList);

      // create baseline planned group tags
      plannedGroupGanttElementList = createBaselinePlannedGroupTags(
        baselineComparisonPlannedGroupDetailsList1,
        baselineComparisonPlannedGroupDetailsList2);

      // add planned group tags to the returned element
      baselineGanttElement.plannedGroupGanttElementList.assign(
        plannedGroupGanttElementList);

      // add the details to the returned struct
      baselineGanttElementList.baselineGanttElement.addRef(baselineGanttElement);
    }

    return baselineGanttElementList;

  }

  // ___________________________________________________________________________
  /**
   * Adds content to the element passed in as a parameter. Appropriate content
   * is found in the list.
   *
   * @param parentGroupID ID of the group which content needs to be added
   * to the Element
   * @param parentElement An XML element that needs to be updated
   * @param baselineGanttElementList List that contains details about all
   * existing Gantt elements
   *
   * @return Newly created XML element
   */
  Element addElementContent(final Element parentElement,
    final curam.serviceplans.sl.struct.PlannedGroupKey plannedGroupKey,
    final BaselineGanttElementList baselineGanttElementList)
    throws AppException, InformationalException {

    // search for a list of all elements that belong to the given group
    final BaselineGanttElement baselineGanttElement = listBaselineGanttElementsByPlannedGroupID(
      baselineGanttElementList, plannedGroupKey);

    // local variable for name manipulation
    // BEGIN, CR00053248, GM
    String name = CuramConst.gkEmpty;
    // END, CR00053248

    // Planned Group ID for the next iteration
    final curam.serviceplans.sl.struct.PlannedGroupKey nextPlannedGroupKey = new curam.serviceplans.sl.struct.PlannedGroupKey();

    // add sub goals
    for (int i = 0; i
      < baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.size(); i++) {

      // create SUBGOAL element
      final Element subGoalElement = new Element(kSubGoal);

      subGoalElement.setAttribute(kName,
        baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).name);

      // original baseline subgoal start and end dates
      if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).topActualStartDate.isZero()) {
        subGoalElement.setAttribute(kTopStart, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kTopStart,
          String.valueOf(
          baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).topActualStartDate));
      }

      if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).topActualEndDate.isZero()) {
        subGoalElement.setAttribute(kTopEnd, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kTopEnd,
          String.valueOf(
          baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).topActualEndDate));
      }

      // compared item subgoal start and end dates
      if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).bottomActualStartDate.isZero()) {
        subGoalElement.setAttribute(kBottomStart, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kBottomStart,
          String.valueOf(
          baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).bottomActualStartDate));
      }

      if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).bottomActualEndDate.isZero()) {
        subGoalElement.setAttribute(kBottomEnd, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kBottomEnd,
          String.valueOf(
          baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).bottomActualEndDate));
      }

      subGoalElement.setAttribute(kID,
        String.valueOf(
        baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).plannedSubGoalID));
      subGoalElement.setAttribute(kType, kSubGoal);

      // iterate baseline plan items list for the sub goal
      for (int j = 0; j
        < baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.size(); j++) {

        // create PLANITEM element
        final Element planItemElement = new Element(kPlanItem);

        name = baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).name;

        planItemElement.setAttribute(kName, name);

        // original baseline subgoal planItem start and end dates
        if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).topActualStartDate.isZero()) {
          planItemElement.setAttribute(kTopStart, kEmptyDate);
        } else {
          planItemElement.setAttribute(kTopStart,
            String.valueOf(
            baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).topActualStartDate));
        }

        if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).topActualEndDate.isZero()) {
          planItemElement.setAttribute(kTopEnd, kEmptyDate);
        } else {
          planItemElement.setAttribute(kTopEnd,
            String.valueOf(
            baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).topActualEndDate));
        }

        // compared item subgoal plan item start and end dates
        if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).bottomActualStartDate.isZero()) {
          planItemElement.setAttribute(kBottomStart, kEmptyDate);
        } else {
          planItemElement.setAttribute(kBottomStart,
            String.valueOf(
            baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).bottomActualStartDate));
        }

        if (baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).bottomActualEndDate.isZero()) {
          planItemElement.setAttribute(kBottomEnd, kEmptyDate);
        } else {
          planItemElement.setAttribute(kBottomEnd,
            String.valueOf(
            baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).bottomActualEndDate));
        }

        planItemElement.setAttribute(kID,
          String.valueOf(
          baselineGanttElement.baselineSubGoalGanttElementList.baselineSubGoalGanttElement.item(i).baselinePlanItemGanttElement.item(j).baselinePlanItemID));
        planItemElement.setAttribute(kType, kPlanItem);

        // add PLANITEM element to the SUBGOAL element
        subGoalElement.addContent(planItemElement);
      }

      // add SUBGOAL element to the parent element
      parentElement.addContent(subGoalElement);
    }

    // add planned groups
    for (int j = 0; j
      < baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.size(); j++) {

      // create PLANNED GROUP element
      final Element plannedGroupElement = new Element(kPlannedGroup);

      plannedGroupElement.setAttribute(kName,
        baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).plannedGroupName);

      // original baseline subgoal start and end dates
      if (baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).topActualStartDate.isZero()) {
        plannedGroupElement.setAttribute(kTopStart, kEmptyDate);
      } else {
        plannedGroupElement.setAttribute(kTopStart,
          String.valueOf(
          baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).topActualStartDate));
      }

      if (baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).topActualEndDate.isZero()) {
        plannedGroupElement.setAttribute(kTopEnd, kEmptyDate);
      } else {
        plannedGroupElement.setAttribute(kTopEnd,
          String.valueOf(
          baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).topActualEndDate));
      }

      // compared item subgoal start and end dates
      if (baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).bottomActualStartDate.isZero()) {
        plannedGroupElement.setAttribute(kBottomStart, kEmptyDate);
      } else {
        plannedGroupElement.setAttribute(kBottomStart,
          String.valueOf(
          baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).bottomActualStartDate));
      }

      if (baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).bottomActualEndDate.isZero()) {
        plannedGroupElement.setAttribute(kBottomEnd, kEmptyDate);
      } else {
        plannedGroupElement.setAttribute(kBottomEnd,
          String.valueOf(
          baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).bottomActualEndDate));
      }

      plannedGroupElement.setAttribute(kID,
        String.valueOf(
        baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).plannedGroupID));

      plannedGroupElement.setAttribute(kType, kPlannedGroup);

      final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

      final curam.serviceplans.sl.entity.struct.PlannedGroupKey planGroupKey = new curam.serviceplans.sl.entity.struct.PlannedGroupKey();

      planGroupKey.plannedGroupID = baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).plannedGroupID;
      // Set caseID and contentType to read home page.
      plannedGroupElement.setAttribute(kContentType, kPlanGroupContentType);
      plannedGroupElement.setAttribute(kCaseID,
        String.valueOf(
        plannedGroupObj.readCaseIDByPlannedGroupID(planGroupKey).caseID));

      // set the key for the next iteration
      nextPlannedGroupKey.key.plannedGroupID = baselineGanttElement.plannedGroupGanttElementList.plannedGroupGanttElement.item(j).plannedGroupID;

      // add sub elements
      final Element completePlannedGroupElement = addElementContent(
        plannedGroupElement, nextPlannedGroupKey, baselineGanttElementList);

      // add PLANNED GROUP element to the parent element
      parentElement.addContent(completePlannedGroupElement);

    }

    return parentElement;
  }

  // ___________________________________________________________________________
  /**
   * Returns baseline gantt element that belongs to the specified planned group.
   *
   * @param baselineGanttElementList List that contains details about all
   * existing Gantt elements
   * @param plannedGroupKey id of the planned group
   *
   * @return planned group Gantt details
   */
  @Override
  public BaselineGanttElement listBaselineGanttElementsByPlannedGroupID(
    final BaselineGanttElementList baselineGanttElementList,
    final curam.serviceplans.sl.struct.PlannedGroupKey plannedGroupKey)
    throws AppException, InformationalException {

    for (int i = 0; i < baselineGanttElementList.baselineGanttElement.size(); i++) {
      if (baselineGanttElementList.baselineGanttElement.item(i).plannedGroupID
        == plannedGroupKey.key.plannedGroupID) {
        return baselineGanttElementList.baselineGanttElement.item(i);
      }
    }
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Reads all sub element details (planned groups and sub goals) associated
   * with the given planned group.
   *
   * @param baselineAndPlannedGroupComparisonKey id of the planned group
   *
   * @param comparisonLevelDetailsList List that contains details about all
   * existing elements
   * @return lists of sub goals and planned groups associated with the planned
   * group
   */
  @Override
  public ComparisonLevelDetailsList listComparisonDetailsForPlannedGroup(
    final BaselineAndPlannedGroupComparisonKey baselineAndPlannedGroupComparisonKey,
    ComparisonLevelDetailsList comparisonLevelDetailsList)
    throws AppException, InformationalException {

    // an element of the returned list
    final curam.serviceplans.sl.entity.struct.ComparisonLevelDetails comparisonLevelDetails = new curam.serviceplans.sl.entity.struct.ComparisonLevelDetails();

    // Sub Goal and associated Planned Items
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails baselineComparisonSubGoalAndAssociatedPlannedItemsDetails;

    final BaselineAndPlannedGroupComparisonKey newBaselineAndPlannedGroupComparisonKey = new BaselineAndPlannedGroupComparisonKey();

    // Baseline plan group entity variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroupObj = curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList;

    // Baseline sub goal entity variables
    final curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList;

    // Baseline plan item entity variables
    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();
    final BaselinePlanItemComparisonKey baselinePlanItemComparisonKey = new curam.serviceplans.sl.entity.struct.BaselinePlanItemComparisonKey();
    curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetailsList baselineComparisonPlanItemDetailsList;

    // set planned group ID
    comparisonLevelDetails.plannedGroupID = baselineAndPlannedGroupComparisonKey.key.plannedGroupID;

    // list all sub goals assigned to the planned group
    baselineComparisonSubGoalDetailsList = baselineSubGoalObj.searchDetailsByBaselineIDSensitivityAndGroup(
      baselineAndPlannedGroupComparisonKey.key);

    // search for planned items associated with sub goal
    for (int i = 0; i < baselineComparisonSubGoalDetailsList.dtls.size(); i++) {

      // create returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails = new curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalAndAssociatedPlannedItemsDetails();

      // add sub goal details
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.subGoalDetails.assign(
        baselineComparisonSubGoalDetailsList.dtls.item(i));

      // read baseline plan item comparison details
      baselinePlanItemComparisonKey.baselineSubGoalID = baselineComparisonSubGoalDetailsList.dtls.item(i).baselineSubGoalID;
      baselinePlanItemComparisonKey.sensitivityCode = baselineAndPlannedGroupComparisonKey.key.sensitivityCode;
      baselineComparisonPlanItemDetailsList = baselinePlanItemObj.searchPlanItemDetailsByBaselineSubGoalIDAndSensitivity(
        baselinePlanItemComparisonKey);

      // add baseline plan item details list to the returned struct
      baselineComparisonSubGoalAndAssociatedPlannedItemsDetails.plannedItemList.assign(
        baselineComparisonPlanItemDetailsList);

      comparisonLevelDetails.subGoalList.addRef(
        baselineComparisonSubGoalAndAssociatedPlannedItemsDetails);
    }

    // list all planned groups assigned to the planned group
    baselineComparisonPlannedGroupDetailsList = baselinePlanGroupObj.searchDetailsByBaselineIDAndGroupID(
      baselineAndPlannedGroupComparisonKey.key);

    // add the list to the returned struct
    comparisonLevelDetails.plannedGroupList.assign(
      baselineComparisonPlannedGroupDetailsList);

    // add the details to the list
    comparisonLevelDetailsList.comparisonLevelDetails.addRef(
      comparisonLevelDetails);

    // add the rest to the list
    for (int j = 0; j < baselineComparisonPlannedGroupDetailsList.dtls.size(); j++) {

      // set the key
      newBaselineAndPlannedGroupComparisonKey.key.plannedGroupID = baselineComparisonPlannedGroupDetailsList.dtls.item(j).plannedGroupID;
      newBaselineAndPlannedGroupComparisonKey.key.baseLineID = baselineAndPlannedGroupComparisonKey.key.baseLineID;
      newBaselineAndPlannedGroupComparisonKey.key.sensitivityCode = baselineAndPlannedGroupComparisonKey.key.sensitivityCode;

      // list comparison details for planned group
      comparisonLevelDetailsList = listComparisonDetailsForPlannedGroup(
        newBaselineAndPlannedGroupComparisonKey, comparisonLevelDetailsList);

    }

    // return details
    return comparisonLevelDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Takes in two lists of planned group details and forms a list to be
   * translated to an XML string.
   *
   * @param list1 List of planned group details
   * @param list2 List of planned group details
   *
   * @return lists of planned group details to be translated to an XML string
   */
  @Override
  public PlannedGroupGanttElementList createBaselinePlannedGroupTags(
    final BaselineComparisonPlannedGroupDetailsList list1,
    final BaselineComparisonPlannedGroupDetailsList list2)
    throws AppException, InformationalException {

    // return value
    final PlannedGroupGanttElementList plannedGroupGanttElementList = new PlannedGroupGanttElementList();

    // an element of the returned list
    curam.serviceplans.sl.struct.PlannedGroupGanttElement plannedGroupGanttElement;

    // iterate through first list of planned groups
    for (int i = 0; i < list1.list.dtls.size(); i++) {

      // create new planned group element
      plannedGroupGanttElement = new curam.serviceplans.sl.struct.PlannedGroupGanttElement();

      // set the details
      plannedGroupGanttElement.parentGroupID = list1.list.dtls.item(i).parentGroupID;
      plannedGroupGanttElement.plannedGroupID = list1.list.dtls.item(i).plannedGroupID;
      plannedGroupGanttElement.plannedGroupName = list1.list.dtls.item(i).plannedGroupName;
      plannedGroupGanttElement.topExpectedStartDate = list1.list.dtls.item(i).expectedStartDate;
      plannedGroupGanttElement.topExpectedEndDate = list1.list.dtls.item(i).expectedEndDate;
      plannedGroupGanttElement.topActualStartDate = list1.list.dtls.item(i).actualStartDate;
      plannedGroupGanttElement.topActualEndDate = list1.list.dtls.item(i).actualEndDate;

      boolean foundInTheSecondList = false;

      // iterate through second list of planned groups
      for (int j = 0; j < list2.list.dtls.size(); j++) {

        // find the planned group with the same ID
        if (list1.list.dtls.item(i).plannedGroupID
          == list2.list.dtls.item(j).plannedGroupID) {

          foundInTheSecondList = true;

          // set bottom date values
          plannedGroupGanttElement.bottomExpectedStartDate = list2.list.dtls.item(j).expectedStartDate;
          plannedGroupGanttElement.bottomExpectedEndDate = list2.list.dtls.item(j).expectedEndDate;
          plannedGroupGanttElement.bottomActualStartDate = list2.list.dtls.item(j).actualStartDate;
          plannedGroupGanttElement.bottomActualEndDate = list2.list.dtls.item(j).actualEndDate;

        }

        if (foundInTheSecondList) {
          // remove it from the second list
          list2.list.dtls.remove(j);
          j--;
          break;
        }
      }
      if (!foundInTheSecondList) {

        // set bottom values to zero date
        plannedGroupGanttElement.bottomExpectedStartDate = curam.util.type.Date.kZeroDate;
        plannedGroupGanttElement.bottomExpectedEndDate = curam.util.type.Date.kZeroDate;
        plannedGroupGanttElement.bottomActualStartDate = curam.util.type.Date.kZeroDate;
        plannedGroupGanttElement.bottomActualEndDate = curam.util.type.Date.kZeroDate;
      }

      // add the plan group element to the return list
      plannedGroupGanttElementList.plannedGroupGanttElement.addRef(
        plannedGroupGanttElement);

    }

    // iterate through the rest of the second list
    for (int j = 0; j < list2.list.dtls.size(); j++) {

      // create new planned group element
      plannedGroupGanttElement = new curam.serviceplans.sl.struct.PlannedGroupGanttElement();

      // set the details
      plannedGroupGanttElement.plannedGroupID = list2.list.dtls.item(j).plannedGroupID;
      plannedGroupGanttElement.parentGroupID = list2.list.dtls.item(j).parentGroupID;
      plannedGroupGanttElement.plannedGroupName = list2.list.dtls.item(j).plannedGroupName;
      plannedGroupGanttElement.topExpectedStartDate = curam.util.type.Date.kZeroDate;
      plannedGroupGanttElement.topExpectedEndDate = curam.util.type.Date.kZeroDate;
      plannedGroupGanttElement.topActualStartDate = curam.util.type.Date.kZeroDate;
      plannedGroupGanttElement.topActualEndDate = curam.util.type.Date.kZeroDate;
      plannedGroupGanttElement.bottomExpectedStartDate = list2.list.dtls.item(j).expectedStartDate;
      plannedGroupGanttElement.bottomExpectedEndDate = list2.list.dtls.item(j).expectedEndDate;
      plannedGroupGanttElement.bottomActualStartDate = list2.list.dtls.item(j).actualStartDate;
      plannedGroupGanttElement.bottomActualEndDate = list2.list.dtls.item(j).actualEndDate;

      // add the plan group element to the return list
      plannedGroupGanttElementList.plannedGroupGanttElement.addRef(
        plannedGroupGanttElement);
    }

    return plannedGroupGanttElementList;
  }

  /**
   * Takes in a list of Planned Sub Goals and their associated planned items.
   * Creates the XML String for each sub goal and each planned item within
   * the planned subGoal. The returns all the sub goal information into
   * a parent Element (which will be either a planned group or a planned Goal).
   *
   * @param details
   * Contains the list of subgoals.
   * @param parentElement
   * Contains the created XML String for all the subGoals passed in.
   *
   * @return The parent Element to hold all the XML for planned subGoals and
   * their planned items.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected Element createPlannedSubGoalXMLStringForListPassedIn(
    final ReadBaselineGanttDetails details, final Element parentElement)
    throws AppException, InformationalException {

    // END, CR00198672

    // BEGIN, CR00291735, SK
    for (final curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails baselineComparisonSubGoalDetails : details.baselineGanttSubGoalDetails.items()) {

      // create SUBGOAL element
      final Element subGoalElement = new Element(kSubGoal);

      subGoalElement.setAttribute(kName, baselineComparisonSubGoalDetails.name);

      // For each date we have to check if dates not set and if so replace
      // with empty string. As widget does not like dates not set for planned
      // Goal.

      // BEGIN, CR00219204, SW
      // SubGoal Expected Start
      if (baselineComparisonSubGoalDetails.expectedStartDate.isZero()) {
        subGoalElement.setAttribute(kTopStart, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kTopStart,
          curam.util.resources.Locale.getFormattedDate(
          baselineComparisonSubGoalDetails.expectedStartDate, kGanttDateFormat));
      }

      // SubGoal Expected End date
      if (baselineComparisonSubGoalDetails.expectedEndDate.isZero()) {
        subGoalElement.setAttribute(kTopEnd, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kTopEnd,
          curam.util.resources.Locale.getFormattedDate(
          baselineComparisonSubGoalDetails.expectedEndDate, kGanttDateFormat));
      }

      // SubGoal Actual start date
      if (baselineComparisonSubGoalDetails.actualStartDate.isZero()) {
        subGoalElement.setAttribute(kBottomStart, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kBottomStart,
          curam.util.resources.Locale.getFormattedDate(
          baselineComparisonSubGoalDetails.actualStartDate, kGanttDateFormat));
      }

      // SubGoal Actual end date
      if (baselineComparisonSubGoalDetails.actualEndDate.isZero()) {
        subGoalElement.setAttribute(kBottomEnd, kEmptyDate);
      } else {
        subGoalElement.setAttribute(kBottomEnd,
          curam.util.resources.Locale.getFormattedDate(
          baselineComparisonSubGoalDetails.actualEndDate, kGanttDateFormat));
      }
      // END, CR00219204

      subGoalElement.setAttribute(kID,
        String.valueOf(baselineComparisonSubGoalDetails.plannedSubGoalID));

      subGoalElement.setAttribute(kType, kSubGoal);

      // iterate plan items list for the sub goal
      for (final BaselineComparisonPlanItemDetails baselineComparisonPlanItemDetails : baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.dtls.items()) {

        // create PLANITEM element
        final Element planItemElement = new Element(kPlanItem);

        planItemElement.setAttribute(kType, kPlanItem);
        planItemElement.setAttribute(kID,
          String.valueOf(baselineComparisonPlanItemDetails.baselinePlanItemID));
        planItemElement.setAttribute(kName,
          baselineComparisonPlanItemDetails.name);

        final BaselinePlanItem baseLinePlanItemObj = BaselinePlanItemFactory.newInstance();
        final BaselinePlanItemKey baselinePlanItemKey = new BaselinePlanItemKey();

        baselinePlanItemKey.baselinePlanItemID = baselineComparisonPlanItemDetails.baselinePlanItemID;
        final BaselinePlanItemDtls baselinePlanItemDtls = baseLinePlanItemObj.read(
          baselinePlanItemKey);

        // For each date we have to check if dates not set and if so replace
        // with empty string. As widget does not like dates not set for
        // PlanItem.

        // BEGIN, CR00219204, SW
        // PlanItem Expected Start
        if (baselineComparisonPlanItemDetails.expectedStartDate.isZero()) {
          planItemElement.setAttribute(kTopStart, kEmptyDate);
        } else {
          planItemElement.setAttribute(kTopStart,
            curam.util.resources.Locale.getFormattedDate(
            baselineComparisonPlanItemDetails.expectedStartDate,
            kGanttDateFormat));
        }

        // PlanItem Expected End date
        if (baselineComparisonPlanItemDetails.expectedEndDate.isZero()) {
          planItemElement.setAttribute(kTopEnd, kEmptyDate);
        } else {
          planItemElement.setAttribute(kTopEnd,
            curam.util.resources.Locale.getFormattedDate(
            baselineComparisonPlanItemDetails.expectedEndDate, kGanttDateFormat));
        }

        // PlanItem Actual Start Date
        if (baselineComparisonPlanItemDetails.actualStartDate.isZero()) {
          planItemElement.setAttribute(kBottomStart, kEmptyDate);
        } else {
          planItemElement.setAttribute(kBottomStart,
            curam.util.resources.Locale.getFormattedDate(
            baselineComparisonPlanItemDetails.actualStartDate, kGanttDateFormat));
        }

        // PlanItem Actual End date
        if (baselineComparisonPlanItemDetails.actualEndDate.isZero()) {
          planItemElement.setAttribute(kBottomEnd, kEmptyDate);
        } else {
          planItemElement.setAttribute(kBottomEnd,
            curam.util.resources.Locale.getFormattedDate(
            baselineComparisonPlanItemDetails.actualEndDate, kGanttDateFormat));
        }
        // END, CR00219204

        // BEGIN, CR00000224, PMD

        // Plan Item Unit Type
        final String unitType = baselineComparisonPlanItemDetails.unitType;

        if (!StringUtil.isNullOrEmpty(unitType)) {
          planItemElement.setAttribute(kUnitType, unitType);
        }

        // Plan Item Units Received To Date
        planItemElement.setAttribute(kReceivedUnits,
          String.valueOf(baselineComparisonPlanItemDetails.unitsReceivedToDate));

        // Plan Item AuthorizedUnits
        final int authorizedUnits = baselineComparisonPlanItemDetails.authorizedUnits;

        if (authorizedUnits > 0) {
          planItemElement.setAttribute(kAuthorizedUnits,
            String.valueOf(authorizedUnits));
        }

        // BEGIN, CR00118825, MC
        final String respOrConcerning = Configuration.getProperty(
          EnvVars.ENV_SERVICEPLANS_SHOW_RESPONSIBILTY_OR_CONCERNING);

        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

        // if it of type concerning set concerning details
        if (ServicePlanGanttConst.kConcerning.equalsIgnoreCase(respOrConcerning)) {

          if (0 != baselinePlanItemDtls.concerningID) {
            final ConcernRoleKey key = new ConcernRoleKey();

            key.concernRoleID = baselinePlanItemDtls.concerningID;
            final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
              key);

            planItemElement.setAttribute(kParticipantName,
              concernRoleNameDetails.concernRoleName);

          } else {

            planItemElement.setAttribute(kParticipantName,
              curam.util.resources.GeneralConstants.kEmpty);

          }

          // if it is type responsibility set responsibility details
        } else if (ServicePlanGanttConst.kResponsibility.equalsIgnoreCase(
          respOrConcerning)) {

          // if both do not have any value then set it to blank
          if (0 == baselinePlanItemDtls.responsibilityID
            && null == baselinePlanItemDtls.respUserName) {

            planItemElement.setAttribute(kParticipantName,
              curam.util.resources.GeneralConstants.kEmpty);

          } else {

            // if responsibility id is set then use it else use responsibility
            // user name

            if (0 != baselinePlanItemDtls.responsibilityID) {
              final ConcernRoleKey key = new ConcernRoleKey();

              key.concernRoleID = baselinePlanItemDtls.responsibilityID;
              final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
                key);

              planItemElement.setAttribute(kParticipantName,
                concernRoleNameDetails.concernRoleName);
            } else {
              planItemElement.setAttribute(kParticipantName,
                baselinePlanItemDtls.respUserName);
            }

          }

        } else {

          planItemElement.setAttribute(kParticipantName,
            curam.util.resources.GeneralConstants.kEmpty);

        }

        // iterate service units list for the planned item
        for (final BaselineServiceUnitDeliveryDtls baselineServiceUnitDeliveryDtls : baselineComparisonPlanItemDetails.suList.dtls.items()) {

          // Create DELIVERY element
          final Element deliveryElement = new Element(kServiceUnitDelivery);

          // BEGIN, CR00219204, SW
          // Delivery Date
          if (baselineServiceUnitDeliveryDtls.deliveryDate.isZero()) {
            deliveryElement.setAttribute(kDate, kEmptyDate);
          } else {
            deliveryElement.setAttribute(kDate,
              curam.util.resources.Locale.getFormattedDate(
              baselineServiceUnitDeliveryDtls.deliveryDate, kGanttDateFormat));
          }
          // END, CR00219204

          // Units Received
          deliveryElement.setAttribute(kUnits,
            String.valueOf(baselineServiceUnitDeliveryDtls.numberOfUnits));

          planItemElement.addContent(deliveryElement);
        }
        // END, CR00000224

        // add PLANITEM element to the SUBGOAL element
        subGoalElement.addContent(planItemElement);
      }

      // BEGIN, CR00058141, PMD
      // Create xml for sub-goal level milestones
      for (final BaselineMilestoneListDetails baselineMilestoneListDetails : baselineComparisonSubGoalDetails.baselineGanttMilestoneDetails.dtls.items()) {

        Element milestoneElement = new Element(kMilestone);

        milestoneElement = createMilestoneXML(baselineMilestoneListDetails);

        // Update the sub-goal element with all the milestone elements found.
        subGoalElement.addContent(milestoneElement);
      }
      // END, CR00058141

      // add SUBGOAL element to the GOAL element
      parentElement.addContent(subGoalElement);
    }
    // END, CR00291735
    return parentElement;
  }

  // ___________________________________________________________________________
  /**
   * Searches for all planned groups, subgoals and planned items for a
   * planned group and adds all the element information to the
   * planned group element for the required XML String.
   *
   * @param plannedGroupDetailsForGantt planned group record.
   *
   * @return Element Planned Group element to be displayed on the Gantt chart.
   */
  // BEGIN, CR00198672, VK
  protected Element createPlannedGroupXML(
    final BaselineComparisonPlannedGroupDetails baselineComparisonPlannedGroupDetails)
    throws AppException, InformationalException {

    // END, CR00198672
    // Planned Group & SubGoal entity
    final curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroupObj = curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();

    // Planned Group entity
    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();

    // Baseline Service Unit Delivery entity
    final curam.serviceplans.sl.entity.intf.BaselineServiceUnitDelivery baselineServiceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.BaselineServiceUnitDeliveryFactory.newInstance();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode sensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      usersKey);
    // END, CR00098617

    // create planGroup Element
    Element planGroupElement = new Element(kPlannedGroup);
    final ReadBaselineGanttDetails readBaselineGanttDetails = new ReadBaselineGanttDetails();

    planGroupElement.setAttribute(kName,
      baselineComparisonPlannedGroupDetails.plannedGroupName);

    // BEGIN, CR00219204, SW
    // SET ACTUAL AND EXPECTED DATES
    // childGroupElement Expected Start
    if (baselineComparisonPlannedGroupDetails.expectedStartDate.isZero()) {
      planGroupElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        baselineComparisonPlannedGroupDetails.expectedStartDate,
        kGanttDateFormat));
    }

    // childGroupElement Expected End date
    if (baselineComparisonPlannedGroupDetails.expectedEndDate.isZero()) {
      planGroupElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        baselineComparisonPlannedGroupDetails.expectedEndDate, kGanttDateFormat));
    }

    // childGroupElement Actual start date
    if (baselineComparisonPlannedGroupDetails.actualStartDate.isZero()) {
      planGroupElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        baselineComparisonPlannedGroupDetails.actualStartDate, kGanttDateFormat));
    }

    // childGroupElement Actual end date
    if (baselineComparisonPlannedGroupDetails.actualEndDate.isZero()) {
      planGroupElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        baselineComparisonPlannedGroupDetails.actualEndDate, kGanttDateFormat));
    }
    // END, CR00219204

    // Set child group id
    planGroupElement.setAttribute(kID,
      String.valueOf(baselineComparisonPlannedGroupDetails.plannedGroupID));

    // Set parent group TYPE
    planGroupElement.setAttribute(kType, kPlanGroupType);

    // BEGIN, CR00058141, PMD
    final BaselineIDAndPlannedGroupID baselineIDAndPlannedGroupID = new BaselineIDAndPlannedGroupID();

    baselineIDAndPlannedGroupID.baselineID = baselineComparisonPlannedGroupDetails.baselineID;
    baselineIDAndPlannedGroupID.plannedGroupID = baselineComparisonPlannedGroupDetails.plannedGroupID;

    // List milestones at plan group level
    curam.serviceplans.sl.entity.struct.BaselineMilestoneListDetailsList baselineMilestoneListDetailsList = BaselineMilestoneFactory.newInstance().searchByBaselineIDAndPlannedGroupID(
      baselineIDAndPlannedGroupID);

    for (int i = 0; i < baselineMilestoneListDetailsList.dtls.size(); i++) {

      // Create Milestone XML
      Element milestoneElement = new Element(kMilestone);

      milestoneElement = createMilestoneXML(
        baselineMilestoneListDetailsList.dtls.item(i));

      // Update the plan group element with all the milestone elements found.
      planGroupElement.addContent(milestoneElement);
    }
    // END, CR00058141

    // read plannedGoal by baseline id
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();

    baselineKey.baseLineID = baselineComparisonPlannedGroupDetails.baselineID;

    // Set caseID and contentType to read home page.
    planGroupElement.setAttribute(kContentType, kPlanGroupContentType);
    planGroupElement.setAttribute(kCaseID,
      String.valueOf(baselineObj.readCaseIDByBaselineID(baselineKey).caseID));

    final curam.serviceplans.sl.entity.struct.BaselineAndPlannedGroupComparisonKey baselineAndPlannedGroupComparisonKey = new curam.serviceplans.sl.entity.struct.BaselineAndPlannedGroupComparisonKey();

    baselineAndPlannedGroupComparisonKey.plannedGroupID = baselineComparisonPlannedGroupDetails.plannedGroupID;
    baselineAndPlannedGroupComparisonKey.baseLineID = baselineComparisonPlannedGroupDetails.baselineID;
    baselineAndPlannedGroupComparisonKey.plannedGroupID = baselineComparisonPlannedGroupDetails.plannedGroupID;
    baselineAndPlannedGroupComparisonKey.sensitivityCode = sensitivityCode.sensitivity;

    // Read Child Sub goals for planned group
    final curam.serviceplans.sl.entity.struct.BaselineComparisonSubGoalDetailsList baselineComparisonSubGoalDetailsList = baselineSubGoalObj.searchDetailsByBaselineIDSensitivityAndGroup(
      baselineAndPlannedGroupComparisonKey);

    // For each sub goal found for the planned group
    // Search for all plan item for each Sub Goal found and assign details to
    // the over all return struct.
    for (int i = 0; i < baselineComparisonSubGoalDetailsList.dtls.size(); i++) {

      // create an element of the returned struct
      final curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails baselineComparisonSubGoalDetails = new curam.serviceplans.sl.struct.BaselineComparisonSubGoalDetails();

      baselineComparisonSubGoalDetails.assign(
        baselineComparisonSubGoalDetailsList.dtls.item(i));

      // BEGIN, CR00058141, PMD
      // List milestones at sub-goal level
      final BaselinePlannedSubGoalKey baselinePlannedSubGoalKey = new BaselinePlannedSubGoalKey();

      baselinePlannedSubGoalKey.baseLineID = baselineComparisonPlannedGroupDetails.baselineID;
      baselinePlannedSubGoalKey.plannedSubGoalID = baselineComparisonSubGoalDetails.plannedSubGoalID;

      baselineMilestoneListDetailsList = BaselineMilestoneFactory.newInstance().searchByBaselineIDAndPlannedSubGoalID(
        baselinePlannedSubGoalKey);

      // add milestone list to the returned struct
      baselineComparisonSubGoalDetails.baselineGanttMilestoneDetails.assign(
        baselineMilestoneListDetailsList);
      // END, CR00058141

      final BaselinePlanItemComparisonKey baselinePlanItemComparisonKey = new BaselinePlanItemComparisonKey();

      baselinePlanItemComparisonKey.baselineSubGoalID = baselineComparisonSubGoalDetailsList.dtls.item(i).baselineSubGoalID;
      baselinePlanItemComparisonKey.sensitivityCode = sensitivityCode.sensitivity;

      // read planned item sub goal details
      final curam.serviceplans.sl.entity.struct.BaselineComparisonPlanItemDetailsList baselineComparisonPlanItemDetailsList = baselinePlanItemj.searchPlanItemDetailsByBaselineSubGoalIDAndSensitivity(
        baselinePlanItemComparisonKey);

      for (int j = 0; j < baselineComparisonPlanItemDetailsList.dtls.size(); j++) {

        final BaselinePlanItemKey baselinePlanItemKey = new BaselinePlanItemKey();

        baselinePlanItemKey.baselinePlanItemID = baselineComparisonPlanItemDetailsList.dtls.item(j).baselinePlanItemID;

        baselineComparisonPlanItemDetailsList.dtls.item(j).unitsReceivedToDate = baselineServiceUnitDeliveryObj.countBaselineServiceUnitDeliveriesByBaselinePlanItemID(baselinePlanItemKey).count;

        // Read baseline service unit delivery details
        BaselineServiceUnitDeliveryDtlsList baselineServiceUnitDeliveryDtlsList = new BaselineServiceUnitDeliveryDtlsList();

        baselineServiceUnitDeliveryDtlsList = baselineServiceUnitDeliveryObj.searchByBaselinePlanItemID(
          baselinePlanItemKey);

        // add baseline service unit delivery details to the returned struct
        baselineComparisonPlanItemDetailsList.dtls.item(j).suList.assign(
          baselineServiceUnitDeliveryDtlsList);

        // add baseline plan item details to the returned struct
        baselineComparisonSubGoalDetails.baselineComparisonPlanItemDetailsList.dtls.addRef(
          baselineComparisonPlanItemDetailsList.dtls.item(j));
      }

      // add sub goal details to the returned struct
      readBaselineGanttDetails.baselineGanttSubGoalDetails.addRef(
        baselineComparisonSubGoalDetails);
    }

    // Updates the plan group element with all the sub goal/plan items element
    // details
    planGroupElement = createPlannedSubGoalXMLStringForListPassedIn(
      readBaselineGanttDetails, planGroupElement);

    baselineAndPlannedGroupComparisonKey.baseLineID = baselineComparisonPlannedGroupDetails.baselineID;
    baselineAndPlannedGroupComparisonKey.plannedGroupID = baselineComparisonPlannedGroupDetails.plannedGroupID;

    // Read Child groups for planned group
    final curam.serviceplans.sl.entity.struct.BaselineComparisonPlannedGroupDetailsList baselineComparisonPlannedGroupDetailsList = baselinePlanGroupObj.searchDetailsByBaselineIDAndGroupID(
      baselineAndPlannedGroupComparisonKey);

    // If a Sub planned Group exists for this planned group, then call this
    // method again to list all the subgoals/groups for for each child planned
    // groups found
    // This will be done until there are no planned groups found.
    boolean plannedGroupsExist = false;

    if (baselineComparisonPlannedGroupDetailsList.dtls.size() > 0) {
      plannedGroupsExist = true;
    }
    while (plannedGroupsExist) {
      // Search until no more child planned groups found.
      plannedGroupsExist = false;
      for (int j = 0; j < baselineComparisonPlannedGroupDetailsList.dtls.size(); j++) {
        Element subPlanGroupElement = new Element(kPlannedGroup);

        subPlanGroupElement = createPlannedGroupXML(
          baselineComparisonPlannedGroupDetailsList.dtls.item(j));
        planGroupElement.addContent(subPlanGroupElement);
      }
    }
    return planGroupElement;
  }

  @Override
  public BaselineNameDetails readBaselineName(final BaselineKey key)
    throws AppException, InformationalException {

    // create return struct
    final BaselineNameDetails baselineNameDetails = new BaselineNameDetails();

    // entity variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObj = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();

    // Call entity operation to read baseline name
    baselineNameDetails.baselineNameDtls = baselineObj.readName(key.baselineKey);

    return baselineNameDetails;
  }

  // BEGIN, CR00057481, PMD
  // ___________________________________________________________________________
  /**
   * Method to create a milestone baseline
   *
   * @param baselineKey the unique identifier of the baseline
   * to add the milestones to
   * @param detailsList the list of milestones to create baselines for
   */
  @Override
  public void createMilestoneBaseline(final BaselineKey baselineKey,
    final BaselineMilestoneDetailsList detailsList) throws AppException,
      InformationalException {

    for (int i = 0; i < detailsList.dtlsList.dtls.size(); i++) {

      final BaselineMilestoneDtls baselineMilestoneDtls = new BaselineMilestoneDtls();

      baselineMilestoneDtls.assign(detailsList.dtlsList.dtls.item(i));
      baselineMilestoneDtls.baselineID = baselineKey.baselineKey.baseLineID;

      // Create baseline milestone record
      BaselineMilestoneFactory.newInstance().insert(baselineMilestoneDtls);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to list all service plan level baseline milestones.
   *
   * @param key the unique id of the baseline
   *
   * @return the list of baseline milestones
   */
  @Override
  public BaselineMilestoneListDetailsList listServicePlanLevelBaselineMilestones(final BaselineKey key)
    throws AppException, InformationalException {

    // Return struct
    final BaselineMilestoneListDetailsList baselineMilestoneListDetailsList = new BaselineMilestoneListDetailsList();

    // Milestone objects
    final curam.core.sl.intf.MilestoneDelivery milestoneDeliveryObj = curam.core.sl.fact.MilestoneDeliveryFactory.newInstance();

    final MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

    // List the baseline milestones
    baselineMilestoneListDetailsList.listDetails = BaselineMilestoneFactory.newInstance().searchBaselineMilestonesByBaselineID(
      key.baselineKey);

    // BEGIN, CR00059103, POB
    // check all milestones exist and update id value to zero if not
    for (int i = 0; i
      < baselineMilestoneListDetailsList.listDetails.dtls.size(); i++) {

      milestoneDeliveryKey.milestoneDeliveryID = baselineMilestoneListDetailsList.listDetails.dtls.item(i).milestoneDeliveryID;

      try {
        milestoneDeliveryObj.read(milestoneDeliveryKey);
      } catch (final Exception e) {
        // if exception then the milestone no longer exists
        // so update the id to zero
        baselineMilestoneListDetailsList.listDetails.dtls.item(i).milestoneDeliveryID = 0;
      }
    }
    // END, CR00059103

    return baselineMilestoneListDetailsList;
  }

  // END, CR00057481

  // BEGIN, CR00058141, PMD
  // ___________________________________________________________________________
  /**
   * Creates a milestone element to add to the xml string
   *
   * @param baselineMilestoneListDetails the baseline milestone record.
   *
   * @return Element Milestone element to be displayed on the baseline gantt.
   */
  // BEGIN, CR00198672, VK
  protected Element createMilestoneXML(
    final BaselineMilestoneListDetails baselineMilestoneListDetails)
    throws AppException, InformationalException {

    // END, CR00198672
    // Create Milestone Element
    final Element milestoneElement = new Element(kMilestone);

    milestoneElement.setAttribute(kName, baselineMilestoneListDetails.name);

    // Set the id
    milestoneElement.setAttribute(kID,
      String.valueOf(baselineMilestoneListDetails.milestoneDeliveryID));

    // Set the type
    milestoneElement.setAttribute(kType, kMilestone);

    // BEGIN, CR00219204, SW
    // Set expected start date
    if (baselineMilestoneListDetails.expectedStartDate.isZero()) {
      milestoneElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        baselineMilestoneListDetails.expectedStartDate, kGanttDateFormat));
    }

    // Set expected end date
    if (baselineMilestoneListDetails.expectedEndDate.isZero()) {
      milestoneElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        baselineMilestoneListDetails.expectedEndDate, kGanttDateFormat));
    }

    // Set actual start date
    if (baselineMilestoneListDetails.actualStartDate.isZero()) {
      milestoneElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        baselineMilestoneListDetails.actualStartDate, kGanttDateFormat));
    }

    // Set actual end date
    if (baselineMilestoneListDetails.actualEndDate.isZero()) {
      milestoneElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        baselineMilestoneListDetails.actualEndDate, kGanttDateFormat));
    }
    // END, CR00219204

    return milestoneElement;
  }
  // END, CR00058141

}
