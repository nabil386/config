/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 *
 * This class is for other modules to link with core planned item entity
 */
package curam.serviceplans.sl.entity.impl;


import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemLinkKey;
import curam.serviceplans.sl.entity.struct.PlannedItemLinkReadmultiKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class PlannedItemLink extends curam.serviceplans.sl.entity.base.PlannedItemLink {

  // ___________________________________________________________________________
  /**
   * Carries out an operation after insertion of a planned item link record.
   *
   * @param details Planned Item link details that have been inserted.
   */
  @Override
  protected void postinsert(PlannedItemLinkDtls details) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Carries out an operation after modification of a planned item link record.
   *
   * @param key Planned Item link key that have been modified.
   * @param details Planned Item link details that have been modified.
   */
  @Override
  protected void postmodify(PlannedItemLinkKey key,
    PlannedItemLinkDtls details) throws AppException, InformationalException {}

  // ___________________________________________________________________________
  /**
   * Carries out an operation after reading the planned item link record.
   *
   * @param key Planned Item link key that have been read.
   * @param result Planned Item link details that have been read.
   */
  @Override
  protected void postread(PlannedItemLinkKey key, PlannedItemLinkDtls result)
    throws AppException, InformationalException {}

  // ___________________________________________________________________________
  /**
   * Carries out an operation after removing the planned item link record.
   *
   * @param key Planned Item link key that have been removed.
   */
  @Override
  protected void postremove(PlannedItemLinkKey key) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Carries out an operation after searching the planned item link records.
   *
   * @param relatedIDAndRelatedTypeKey Planned Item link key that have been
   * removed.
   * @param result Planned Item link details that have been read.
   */
  @Override
  protected void postsearchByRelatedIDAndType(
    PlannedItemLinkReadmultiKey relatedIDAndRelatedTypeKey,
    PlannedItemLinkDtlsList result) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for an insert operation.
   *
   * @param details The planned item link details to be inserted.
   */
  @Override
  protected void preinsert(PlannedItemLinkDtls details) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for a modify operation.
   *
   * @param key The planned item link key to be modified.
   * @param details The planned item link details to be modified.
   */
  @Override
  protected void premodify(PlannedItemLinkKey key, PlannedItemLinkDtls details)
    throws AppException, InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for a read operation.
   *
   * @param key The planned item link key to be read.
   */
  @Override
  protected void preread(PlannedItemLinkKey key) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for a remove operation.
   *
   * @param key The planned item link key to be removed.
   */
  @Override
  protected void preremove(PlannedItemLinkKey key) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for the search operation.
   *
   * @param relatedIDAndRelatedTypeKey The planned item link readmulti key to be
   * searched.
   */
  @Override
  protected void presearchByRelatedIDAndType(
    PlannedItemLinkReadmultiKey relatedIDAndRelatedTypeKey)
    throws AppException, InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for the search operation.
   *
   * @param plannedItemKey The planned item key to be searched.
   * @param result - List of planned item link records searched.
   */
  @Override
  protected void postsearchByPlannedItem(PlannedItemKey plannedItemKey,
    PlannedItemLinkDtlsList result) throws AppException,
      InformationalException {}

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for the search operation.
   *
   * @param plannedItemKey The planned item key to be searched.
   */
  @Override
  protected void presearchByPlannedItem(PlannedItemKey plannedItemKey)
    throws AppException, InformationalException {}

}
