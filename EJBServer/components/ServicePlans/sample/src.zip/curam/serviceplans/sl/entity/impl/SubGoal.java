/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOSUBGOAL;
import curam.serviceplans.sl.entity.struct.SubGoalCancelKey;
import curam.serviceplans.sl.entity.struct.SubGoalCountDetails;
import curam.serviceplans.sl.entity.struct.SubGoalDtls;
import curam.serviceplans.sl.entity.struct.SubGoalIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.SubGoalKey;
import curam.serviceplans.sl.entity.struct.SubGoalNameAndReferenceDetails;
import curam.serviceplans.sl.entity.struct.SubGoalNameAndStatusDetails;
import curam.serviceplans.sl.entity.struct.SubGoalReferenceDetails;
import curam.serviceplans.sl.entity.struct.SubGoalStatusDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class provides methods used to validate the insertion, modification
 * and canceling of sub goals.
 */
public abstract class SubGoal extends curam.serviceplans.sl.entity.base.SubGoal {

  // ___________________________________________________________________________
  /**
   * Pre-cancel processing: calling validate methods.
   *
   * @param key Identifies the sub goal to cancel.
   * @param details The new status for the canceled sub goal.
   */
  @Override
  protected void precancel(SubGoalCancelKey key, SubGoalStatusDetails details)
    throws AppException, InformationalException {

    // validate that the sub goal can be canceled.
    final SubGoalKey subGoalKey = new SubGoalKey();

    subGoalKey.subGoalID = key.subGoalID;
    validateCancel(subGoalKey);

  }

  // ___________________________________________________________________________
  /**
   * Pre-cancel processing: calling validate methods.
   *
   * @param details The details of the new sub goal to be created.
   */
  @Override
  protected void preinsert(SubGoalDtls details) throws AppException,
      InformationalException {

    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Pre-cancel processing: calling validate methods.
   *
   * @param key The ID of the sub goal to modify.
   * @param details The new sub goal details.
   */
  @Override
  protected void premodify(SubGoalKey key, SubGoalDtls details)
    throws AppException, InformationalException {

    validateModify(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates that an sub goal can be canceled.
   *
   * @param key Identifies the sub goal being canceled.
   */
  @Override
  public void validateCancel(SubGoalKey key) throws AppException,
      InformationalException {

    //
    // check that the record isn't canceled already
    //

    // read in the record status
    final SubGoalStatusDetails subGoalStatusDetails = readRecordStatus(key);

    // is the sub goal already canceled?
    if (subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_ALREADY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // create and set the key for sub goal links counting
    final SubGoalIDAndStatusKey subGoalIDAndStatusKey = new SubGoalIDAndStatusKey();

    subGoalIDAndStatusKey.subGoalID = key.subGoalID;
    subGoalIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // sub goal must not be assigned to any goal
    if (countGoalsBySubGoalAndStatus(subGoalIDAndStatusKey).numSubGoals > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_XRV_ASSIGNED_TO_GOAL),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Plan Template Sub Goal entity
    final curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // there must not be any active template based on the sub goal
    if (planTemplateSubGoalObj.countBySubGoalAndStatus(subGoalIDAndStatusKey).count
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_XRV_TEMPLATES_EXIST),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that the details of an sub goal are correct, that all
   * mandatory fields have been specified.
   *
   * @param dtls The sub goal details.
   */
  @Override
  public void validateDetails(SubGoalDtls dtls) throws AppException,
      InformationalException {

    // is name unspecified?
    if (dtls.name.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of a new sub goal, checks that all fields that
   * are required to be unique are unique.
   *
   * @param dtls The sub goal details.
   */
  @Override
  public void validateInsert(SubGoalDtls dtls) throws AppException,
      InformationalException {

    // check that all mandatory fields have been specified
    validateDetails(dtls);

    //
    // check unique fields
    //

    // search if any active records already have the specified name
    final SubGoalNameAndStatusDetails subGoalNameAndStatusDetails = new SubGoalNameAndStatusDetails();

    subGoalNameAndStatusDetails.name = dtls.name;
    subGoalNameAndStatusDetails.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    SubGoalCountDetails subGoalCount = countByNameAndStatus(
      subGoalNameAndStatusDetails);

    // do any active records already have that name?
    if (subGoalCount.numSubGoals > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // has a reference been specified?
    if (dtls.subGoalReference.length() > 0) {

      // yes, reference has been specified so check that it's unique
      final SubGoalReferenceDetails subGoalReferenceDetails = new SubGoalReferenceDetails();

      subGoalReferenceDetails.subGoalReference = dtls.subGoalReference;
      subGoalCount = countByReference(subGoalReferenceDetails);

      // does reference already exist?
      if (subGoalCount.numSubGoals > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      }

    }

    // sub goal type must be specified
    if (dtls.typeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_TYPE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of a new sub goal, checks that all fields that
   * are required to be unique are unique.
   *
   * @param dtls The sub goal details.
   */
  @Override
  public void validateModify(SubGoalDtls dtls) throws AppException,
      InformationalException {

    //
    // check mandatory fields have been entered
    //
    validateDetails(dtls);

    //
    // check that the record isn't canceled
    //

    // read in the record status
    final SubGoalKey subGoalKey = new SubGoalKey();

    subGoalKey.subGoalID = dtls.subGoalID;

    //
    // check that unique fields are still unique
    //

    // read the old name and reference
    final SubGoalNameAndReferenceDetails nameAndReferenceDetails = readNameAndReference(
      subGoalKey);

    // has the name been changed?
    if (!dtls.name.equals(nameAndReferenceDetails.name)) {

      // count the number of active records with the new name
      final SubGoalNameAndStatusDetails nameAndStatusDetails = new SubGoalNameAndStatusDetails();

      nameAndStatusDetails.name = dtls.name;
      nameAndStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
      final SubGoalCountDetails subGoalCount = countByNameAndStatus(
        nameAndStatusDetails);

      // is the name already in active use?
      if (subGoalCount.numSubGoals > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      }

    }

    // has the reference been changed?
    if (!dtls.subGoalReference.equals(nameAndReferenceDetails.subGoalReference)) {

      // count the number of records with the new reference
      final SubGoalReferenceDetails subGoalReferenceDetails = new SubGoalReferenceDetails();

      subGoalReferenceDetails.subGoalReference = dtls.subGoalReference;
      final SubGoalCountDetails subGoalCount = countByReference(
        subGoalReferenceDetails);

      // is the reference already in use?
      if (subGoalCount.numSubGoals > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }

    }

    // sub goal type must be specified
    if (dtls.typeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_FV_TYPE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

  }

}
