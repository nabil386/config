/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;

import curam.core.impl.CuramConst;
import curam.message.CASENOTE;

/**
 * This class assigns values to the Service Plans constants.
 */

public abstract class ServicePlanConst {

  // SID for ServicePlanDelivery.printContract facade method
  public static final String kPrintContractSID = "ServicePlanDelivery.printContract";

  // BEGIN CR00116105, GBA
  // CPM Class which raises event that daily attendance records
  // and absence records have been created
  public static final String kEventClassRoster = "ROSTER";

  public static final String kEventTypeRosterSubmitted = "ROSTER_SUBMITTED";

  // END CR00116105

  // BEGIN, CR00120342, CSH
  public static final String kColon = ":";

  // END, CR00120342
  // BEGIN, CR00161962, LJ
  // constant for Service Plan group.
  public static final String kServicePlanGroup = "SPG";

  // constant for service plan.
  public static final String kServicePlan = "SP";

  // Constant for Planned Item. */
  public static final String kPlannedItem = "PI";

  // Constant for Integrated Service Plan. */
  public static final String kIntegratedServicePlan = "ISP";

  // Constant for active indicator false. */
  public static final String kActiveIndFalse = "false";

  // Constant for Active Indicator. */
  public static final String kActiveInd = "activeInd";

  // Constant for SPG Delivery Key Set. */
  public static final String kSpgdeliveryIdKeysetName = "SPGDELIV";

  // Constant for non empty String. */
  public static final String kNonEmptyString = "-";

  // Constant for Main Approval Workflow process. */
  public static final String kServicePlanAndPlannedItemApprovalWorkflow = "ServicePlanAndPlannedItemApprovalWorkflow";

  // Constant for Approve Planned Item Workflow process. */
  public static final String kApprovePlannedItemWorkflow = "APPROVEPLANNEDITEM";

  // Constant for Approve Planned Item Workflow process. */
  public static final String kReferralWorkQueue = "ReferralWorkQueue";

  // Constant for Main Approval Workflow process for default event
  // of NoEvent.
  public static final String kNoEvent = "NoEvent";

  // Constant for comma.
  public static final String kComma = ", ";

  // Constant for Organization Page.
  public static final String kOrganisationPage = "Organization_viewJobPage.do?jobID=";

  // Constant for Work Queue Page.
  public static final String kWorkQueuePage = "WorkAllocation_viewWorkQueuePage.do?workQueueID=";

  // Constant for Organization Home Page.
  public static final String kOrganizationHomePage = "Organization_orgUnitHomePage.do?organisationUnitID=";

  // Constant for Organization Position Page.
  public static final String kOrganizationPositionPage = "Organization_viewPositionPage.do?positionID=";

  // Constant for Organization User Page.
  public static final String kOrganizationUserPage = "Organization_userHomePage.do?userName=";

  // Constant for External User Page.
  public static final String kExternalUserPage = "ExternalUser_userHomePage.do?userName=";

  // Constant for Organization Structure ID.
  public static final String kOrganizationParam = "&organisationStructureID=";

  // Constant for Organization Unit ID.
  public static final String kOrganizationUnitParam = "&organisationUnitID=";

  // Constant for Plan Item Owner.
  public static final String kPlanItemOwnerParam = "Plan Item Owner";

  // END, CR00161962

  // BEGIN, CR00234759, MR
  /**
   * String constant for plan item identifier.
   */
  public static final String kPlannedItemID = "plannedItemID";

  /**
   * String constant for a submit action for the plan item for approval.
   */
  public static final String kSubmit = "SubmitForApproval";

  /**
   * String constant for a new approval request action for the plan item.
   */
  public static final String kApprove = "Approve";

  /**
   * String constant for a reject action for the plan item.
   */
  public static final String kReject = "Reject";

  // END, CR00234759

  // BEGIN, CR00350312, SS
  /**
   * String constant for provider planned item link.
   */
  public static final String kProviderPlannedItemLink = "PROVIDERPLANNEDITEMLINK";
  // END, CR00350312

  /**
   * A string containing some system details and gets pre-pended to the note
   * text when a note is being created.
   */
  public static String kNoteCreationSystemDetails = CASENOTE.INF_NOTE_CREATED_AS_A_RESULT_OF
      .getMessageText() + CuramConst.gkSpace + CASENOTE.INF_NOTE_TYPE_USER_NOTE
      + CuramConst.gkNewLine;

  /**
   * A string containing some system details and gets pre-pended to the note
   * text when a note is being appended to.
   */
  public static String kNoteModificationSystemDetails = CASENOTE.INF_NOTE_MODIFIED_AS_A_RESULT_OF
      .getMessageText() + CuramConst.gkSpace + CASENOTE.INF_NOTE_TYPE_USER_NOTE
      + CuramConst.gkNewLine;

}
