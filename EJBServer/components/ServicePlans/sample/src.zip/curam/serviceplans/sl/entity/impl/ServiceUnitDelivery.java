/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.BPOSERVICEUNITDELIVERY;
import curam.serviceplans.sl.entity.struct.NumAuthorizedUnits;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDStatus;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryCancelKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryCount;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryStatusDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;


public abstract class ServiceUnitDelivery extends curam.serviceplans.sl.entity.base.ServiceUnitDelivery {

  // BEGIN, CR00000080, CM
  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data deletion
   *
   * @param key Service Unit Delivery identifier
   */
  @Override
  protected void precancel(ServiceUnitDeliveryCancelKey key,
    ServiceUnitDeliveryStatusDetails details) throws AppException,
      InformationalException {

    final ServiceUnitDeliveryKey serviceUnitDeliveryKey = new ServiceUnitDeliveryKey();

    serviceUnitDeliveryKey.serviceUnitDeliveryID = key.serviceUnitDeliveryID;

    // Validate if remove is allowed based on the key
    validateCancel(serviceUnitDeliveryKey);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Service Unit Delivery details
   */
  @Override
  protected void preinsert(ServiceUnitDeliveryDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Service Unit Delivery identifier
   * @param details Service Unit Delivery details
   */
  @Override
  protected void premodify(ServiceUnitDeliveryKey key,
    ServiceUnitDeliveryDtls details) throws AppException,
      InformationalException {

    // Validate the details
    validateModify(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates the Service Unit Delivery details
   *
   * @param details The details of the service unit delivery
   */
  @Override
  public void validateInsert(ServiceUnitDeliveryDtls details)
    throws AppException, InformationalException {

    // Plan Item entity object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // Planned Item entity object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Plan Item key
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    // Service Unit Delivery Entity
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // Service Unit Delivery details struct
    curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails planItemServiceUnitDeliveryDetails = new curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails();

    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = details.plannedItemID;

    PlanItemIDDetailsStruct planItemIDDetailsStruct = new PlanItemIDDetailsStruct();

    planItemIDDetailsStruct = plannedItemObj.readPlanItemID(plannedItemIDKey);

    // Set the value for the plan item key
    planItemKey.planItemID = planItemIDDetailsStruct.planItemID;

    // Read the service unit details back from the plan item
    planItemServiceUnitDeliveryDetails = planItemObj.readPlanItemServiceUnitDeliveryDetails(
      planItemKey);

    // Service Units cannot be recorded as this plan item
    // has not been associated with a type of unit

    // BEGIN, CR00052924, GM
    // BEGIN, CR00091205, CM
    if (planItemServiceUnitDeliveryDetails.unitType.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_CANNOT_RECORD_NO_UNIT_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Get the authorizedUnits
    final NumAuthorizedUnits numAuthorizedUnits = new NumAuthorizedUnits();

    numAuthorizedUnits.authorizedUnits = plannedItemObj.readNumAuthorizedUnits(plannedItemIDKey).authorizedUnits;

    // Get units received to date
    final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID = details.plannedItemID;

    // Get the units received to date
    final ServiceUnitDeliveryCount serviceUnitDeliveryCount = serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(
      plannedItemIDStatus);

    // Total number of units must not exceed the number of authorized units
    if (serviceUnitDeliveryCount.count + details.numberofUnits
      > numAuthorizedUnits.authorizedUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_FV_TOTAL_NO_UNITS_GREATER_THAN_AUTHORIZED_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Check that all mandatory fields have been specified
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Determines that the details provided for the service unit delivery are
   * valid.
   *
   * @param details the service unit delivery details
   */
  @Override
  public void validateDetails(ServiceUnitDeliveryDtls details)
    throws AppException, InformationalException {

    // Check that all mandatory fields have been specified

    // The number of units must be greater than Zero
    if (details.numberofUnits <= 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_FV_NO_OF_UNITS_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The Delivery Date must not be greater than today's date
    if (details.deliveryDate.after(Date.getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_FV_DERLIVERY_DATE_GREATER_THAN_TODAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates Service Unit Delivery modify details
   *
   * @param details Service Unit Delivery details
   */
  @Override
  public void validateModify(ServiceUnitDeliveryDtls details)
    throws AppException, InformationalException {

    // Service Unit Delivery Entity
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // Planned Item entity object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    //
    // check that the record isn't canceled
    //

    final ServiceUnitDeliveryKey serviceUnitDeliveryKey = new ServiceUnitDeliveryKey();

    serviceUnitDeliveryKey.serviceUnitDeliveryID = details.serviceUnitDeliveryID;

    // read in the record status
    final ServiceUnitDeliveryStatusDetails serviceUnitDeliveryStatusDetails = readRecordStatus(
      serviceUnitDeliveryKey);

    // is the service unit delivery already canceled?
    if (serviceUnitDeliveryStatusDetails.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Get units received to date
    final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID = details.plannedItemID;
    plannedItemIDStatus.serviceUnitDeliveryID = details.serviceUnitDeliveryID;
    plannedItemIDStatus.recordStatus = serviceUnitDeliveryStatusDetails.recordStatus;

    // Get the authorizedUnits
    final NumAuthorizedUnits numAuthorizedUnits = new NumAuthorizedUnits();

    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = details.plannedItemID;

    numAuthorizedUnits.authorizedUnits = plannedItemObj.readNumAuthorizedUnits(plannedItemIDKey).authorizedUnits;

    // Get the units received to date except the number of units from the
    // service unit delivery which is been modified
    final ServiceUnitDeliveryCount serviceUnitDeliveryCount = serviceUnitDeliveryObj.countServiceUnitDeliveryForModify(
      plannedItemIDStatus);

    // Total number of units must not exceed the number of authorized units
    if (serviceUnitDeliveryCount.count + details.numberofUnits
      > numAuthorizedUnits.authorizedUnits) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_FV_TOTAL_NO_UNITS_GREATER_THAN_AUTHORIZED_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    //
    // check mandatory fields have been entered
    //
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates Service Unit Delivery cancel
   *
   * @param key ServiceUnitDelivery identifier
   */
  @Override
  public void validateCancel(ServiceUnitDeliveryKey key) throws AppException,
      InformationalException {

    //
    // check that the record isn't canceled already
    //

    // read in the record status
    final ServiceUnitDeliveryStatusDetails serviceUnitDeliveryStatusDetails = readRecordStatus(
      key);

    // is the plan item already canceled?
    if (serviceUnitDeliveryStatusDetails.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEUNITDELIVERY.ERR_SERVICE_UNIT_DELIVERY_ALREADY_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
  }

  // ___________________________________________________________________________
  /**
   * Sets the status to active before reading the service unit delivery.
   *
   * @param key The key for the search, contains plannedItemID, recordStatus
   */
  @Override
  protected void precountActiveServiceUnitDeliveryByPlannedItemID(
    PlannedItemIDStatus key) throws AppException, InformationalException {

    key.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;

  }

} // END, CR00000080
