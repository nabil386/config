/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.event.impl;


import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.impl.SearchController;
import curam.core.intf.CaseHeader;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.event.impl.CaseHeaderSearchHandler;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.events.SERVICEPLANDELIVERY;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This event handler listens for events that occur to the issue delivery
 * entity and informs the search service of changes which may affect it.
 */
public final class ServicePlanDeliverySearchHandler implements EventFilter,
  EventHandler {

  // ___________________________________________________________________________
  /**
   * Returns true if the event is one of the service plan delivery events
   *
   * @param event The details of the event.
   *
   * @return boolean if an only if the event is interesting to the search
   * service
   */
  @Override
  public boolean accept(final Event event) throws AppException,
      InformationalException {

    if (event.eventKey.eventClass.equals(SERVICEPLANDELIVERY.INSERT.eventClass)) {

      if (event.eventKey.eventType.equals(SERVICEPLANDELIVERY.INSERT.eventType)
        || event.eventKey.eventType.equals(SERVICEPLANDELIVERY.MODIFY.eventType)) {
        return true;
      }
    }
    return false;
  }

  // ___________________________________________________________________________
  /**
   * Informs the search service of the change to the service plan delivery.
   *
   * @param event The details of the event.
   */
  @Override
  public void eventRaised(final Event event) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    if (synchronizeEventsObj.isOnlineSynchronizationEnabled()) {

      final SearchController searchControllerObj = new SearchController();
      final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
      final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      ServicePlanDeliveryDtls servicePlanDeliveryDtls;
      CaseHeaderDtls caseHeaderDtls;
      CaseHeaderDtls integratedCaseHeaderDtls = null;

      servicePlanDeliveryKey.caseID = event.primaryEventData;
      servicePlanDeliveryDtls = servicePlanDeliveryObj.read(
        servicePlanDeliveryKey);

      caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // If this is an insert then call the search controller insert
      // otherwise call the update
      if (event.eventKey.eventType.equals(SERVICEPLANDELIVERY.INSERT.eventType)) {

        searchControllerObj.insert(servicePlanDeliveryDtls,
          ServicePlanDelivery.class.getSimpleName());

      } else if (event.eventKey.eventType.equals(
        SERVICEPLANDELIVERY.MODIFY.eventType)) {

        searchControllerObj.modify(servicePlanDeliveryDtls,
          ServicePlanDelivery.class.getSimpleName());

      }

      // BEGIN, CR00221505, ZV
      if (caseHeaderDtls.integratedCaseID != 0L) {

        // read back the related integrated case if it exists
        caseHeaderKey.caseID = caseHeaderDtls.integratedCaseID;
        integratedCaseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

        // propagate the fact that a related service plan has
        // been created back to the related case
        searchControllerObj.modify(integratedCaseHeaderDtls,
          CaseHeader.class.getSimpleName());

        final CaseHeaderSearchHandler caseHeaderSearchHandler = new CaseHeaderSearchHandler();

        // Update all related case indexes
        caseHeaderSearchHandler.updateCaseParticipantNameIndex(caseHeaderKey);
      }
      // END, CR00221505

    }

  }

}
