/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.event.impl;


import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.impl.ServicePlanConst;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.workflow.impl.EnactmentService;
import java.util.ArrayList;
import java.util.List;


/**
 * This event handler listens for events that occur when a planned item requires
 * approval
 * and enacts the appropriate workflow.
 */
public final class ServicePlanDeliveryApprovalEventHandler implements
  EventHandler {

  // __________________________________________________________________________
  /**
   * Enacts the Approve Planned Item workflow as part of when
   * a planned item requires approval.
   *
   * @param event The details of the event.
   * @throws AppException, InformationalException
   */
  @Override
  public void eventRaised(final Event event) throws AppException,
      InformationalException {

    // Create struct manipulation variable
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    // Create enactment data list
    final List enactmentDataList = new ArrayList();

    // Add enactment data to list
    plannedItemIDKey.plannedItemID = event.primaryEventData;

    enactmentDataList.add(plannedItemIDKey);

    // enact the workflow
    EnactmentService.startProcess(ServicePlanConst.kApprovePlannedItemWorkflow,
      enactmentDataList);

  }

}
