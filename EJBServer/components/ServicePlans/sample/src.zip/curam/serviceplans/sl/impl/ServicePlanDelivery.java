/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachment.impl.Attachment;
import curam.codetable.BASELINETYPE;
import curam.codetable.CASECLOSEREASON;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASERELATIONSHIPREASONCODE;
import curam.codetable.CASERELATIONSHIPTYPECODE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.MILESTONESTATUSCODE;
import curam.codetable.NOTEPRIORITY;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.SERVICEPLANCONTRACTSTATUS;
import curam.codetable.SERVICEPLANTYPE;
import curam.core.facade.struct.ReadProspectPersonKey;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.CaseAttachmentLinkFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.AddressData;
import curam.core.intf.CaseAttachmentLink;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainCase;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.MilestoneDeliveryFactory;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.MilestoneDeliveryDtls;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.UpdateCaseParticipantRoleTypeCodeDetails;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.SpecialCautionFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.SpecialCaution;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CountCaseBookmarkKey;
import curam.core.sl.struct.OwnershipStrategyDetails;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.RecordCount;
import curam.core.sl.struct.SpecialCautionConcernKey;
import curam.core.sl.struct.UserNameAndFullName;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseAttachmentLinkDtlsList;
import curam.core.struct.CaseAttachmentLinkReadmultiKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.Count;
import curam.core.struct.CuramInd;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UpdateCaseStatusReasonEndKey1;
import curam.core.struct.UserNameKey;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOCLIENTMERGE;
import curam.message.BPOMAINTAINSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANGROUPDELIVERY;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateMilestoneFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedGroupFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemApprovalCriteriaFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanContractFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem;
import curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal;
import curam.serviceplans.sl.entity.intf.PlannedItemApprovalCriteria;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.struct.GoalIDDetails;
import curam.serviceplans.sl.entity.struct.MilestoneTemplateDetails;
import curam.serviceplans.sl.entity.struct.MilestoneTemplateDetailsList;
import curam.serviceplans.sl.entity.struct.ParticipantCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlanItemAndTemplatePlanItemDetailsList;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateAndSubGoalReadDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupDetailsList;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaLinkReadMultiKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndNameDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForServicePlan;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForServicePlanList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPMilestoneDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanIntegratedCaseIDAndRecordStatusKey;
import curam.serviceplans.sl.entity.struct.TemplateSubGoalDetailsList;
import curam.serviceplans.sl.fact.PlannedItemFactory;
import curam.serviceplans.sl.struct.CancelServicePlanParticipantDetails;
import curam.serviceplans.sl.struct.CaseMemberDetails;
import curam.serviceplans.sl.struct.CaseParticipantRoleKey;
import curam.serviceplans.sl.struct.CaseReferenceAndICTypeDetails;
import curam.serviceplans.sl.struct.CreateNominatedRepresentativeDetails;
import curam.serviceplans.sl.struct.CreateServicePlanDeliveryDetails;
import curam.serviceplans.sl.struct.CreateServicePlanGoalDetails;
import curam.serviceplans.sl.struct.CreateServicePlanGoalKey;
import curam.serviceplans.sl.struct.ICDetails;
import curam.serviceplans.sl.struct.ICMemberDetails;
import curam.serviceplans.sl.struct.ICMemberDetailsList;
import curam.serviceplans.sl.struct.ICMembersAndSPTypesDetails;
import curam.serviceplans.sl.struct.IntegratedCaseMemberKey;
import curam.serviceplans.sl.struct.ListServicePlanForIC;
import curam.serviceplans.sl.struct.ModifySPOutcomeAndCommentsDetails;
import curam.serviceplans.sl.struct.ModifySPOutcomeAndCommentsKey;
import curam.serviceplans.sl.struct.ModifyServicePlanClosureDetails;
import curam.serviceplans.sl.struct.ModifyServicePlanGoalDetails;
import curam.serviceplans.sl.struct.ModifyServicePlanGoalKey;
import curam.serviceplans.sl.struct.ModifyServicePlanParticipantDetails;
import curam.serviceplans.sl.struct.ModifyServicePlanTypeDetails;
import curam.serviceplans.sl.struct.ModifyServicePlanTypeKey;
import curam.serviceplans.sl.struct.PlanGroupNameDetails;
import curam.serviceplans.sl.struct.PlanTemplateKey;
import curam.serviceplans.sl.struct.PlanTemplateNameAndIDDetailsList;
import curam.serviceplans.sl.struct.PlannedItemApprovalCriteriaLinkDetailsList;
import curam.serviceplans.sl.struct.PlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.ReadOutcomeAchievedAndCommentsDetails;
import curam.serviceplans.sl.struct.ReadOutcomeAchievedAndCommentsKey;
import curam.serviceplans.sl.struct.ReadServicePlanDetails;
import curam.serviceplans.sl.struct.ReadServicePlanGoalsDetails;
import curam.serviceplans.sl.struct.ReadServicePlanGoalsKey;
import curam.serviceplans.sl.struct.ReadServicePlanTypesAndCommentsDetails;
import curam.serviceplans.sl.struct.ReadServicePlanTypesAndCommentsKey;
import curam.serviceplans.sl.struct.ServicePlanAndParticipantDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndStatusDtls;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndStatusDtlsList;
import curam.serviceplans.sl.struct.ServicePlanDeliveryClosureDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryCostDtls;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryReadDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryVersions;
import curam.serviceplans.sl.struct.ServicePlanForConcernDetails;
import curam.serviceplans.sl.struct.ServicePlanForConcernDetailsList;
import curam.serviceplans.sl.struct.ServicePlanForICList;
import curam.serviceplans.sl.struct.ServicePlanForICMemberList;
import curam.serviceplans.sl.struct.ServicePlanForOwnerDetailsList;
import curam.serviceplans.sl.struct.ServicePlanICMenuData;
import curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.ServicePlanMenuData;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanOwnerKey;
import curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails;
import curam.serviceplans.sl.struct.ServicePlanParticipantDetails;
import curam.serviceplans.sl.struct.ServicePlanParticipantDetailsList;
import curam.serviceplans.sl.struct.ServicePlanParticipantSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityResult;
import curam.serviceplans.sl.struct.ServicePlanTypesList;
import curam.serviceplans.sl.struct.UpdatePlanParticipantsDetails;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;


/**
 * This process class provides the functionality for the ServicePlanDelivery
 * service layer.
 */
public abstract class ServicePlanDelivery extends curam.serviceplans.sl.base.ServicePlanDelivery {

  // BEGIN, CR00071077, GM
  protected static final String kServicePlanStandardTask = TaskDefinitionIDConst.standardCaseTaskDefinitionID;

  // END, CR00071077

  // BEGIN, CR00146458, VR
  @Inject
  protected Attachment attachment;

  // END, CR00146458

  // BEGIN CR00108818, GBA
  // Add injection for using the new CaseTransactionLog API
  public ServicePlanDelivery() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108818

  /**
   * Creates service plan delivery.
   *
   * @param details
   * Contains service plan type and participant role ID.
   * @param key
   * Contains integrated case ID.
   *
   * @return CaseID of the service plan delivery created.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_FV_SERVICEPLAN_PRIMARY_HAS_TO_BE_PLANNED_PARTICIPANT}
   * - if the primary plan participant is not selected as a plan
   * participant.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_CREATE_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to create
   * a service plan for this client.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_CREATE_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to create a
   * service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_FV_SERVICEPLAN_PRIMARY_IS_NOT_PLANNED_PARTICIPANT}
   * - if the primary plan participant is not selected as a plan
   * participant.
   */
  @Override
  public ServicePlanDeliveryKey create(CreateServicePlanDeliveryDetails details,
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderDtls caseHeaderDtls = new curam.core.struct.CaseHeaderDtls();

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CaseStatusDtls caseStatusDtls = new curam.core.struct.CaseStatusDtls();

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final curam.core.struct.CaseEventDtls caseEventDtls = new curam.core.struct.CaseEventDtls();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.struct.CaseParticipantRoleDetails caseParticipantRoleDetails = new curam.core.sl.struct.CaseParticipantRoleDetails();
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls servicePlanDeliveryDtls = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // validate case member details
    final CaseMemberDetails caseMemberDetails = new CaseMemberDetails();

    caseMemberDetails.concernRoleID = details.concernRoleID;

    // case member must be supplied
    validateCaseMember(caseMemberDetails);

    // check that service plan ID is specified
    // (this validation is part of service plan pre insert validations, but
    // must
    // be done here in order to ensure that security check does not throw
    // NoRecordFound exception if servicePlanID is zero)
    servicePlanDeliveryDtls.servicePlanID = details.servicePlanID;
    servicePlanDeliveryObj.validateDetails(servicePlanDeliveryDtls);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = details.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = details.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CREATE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CREATE_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(key.servicePlanIntegratedCaseKey.caseID);
    // END, CR00227859

    // UniqueID business object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // fill CaseHeader details struct
    caseHeaderDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    caseHeaderDtls.caseTypeCode = curam.codetable.CASETYPECODE.SERVICEPLAN;
    caseHeaderDtls.concernRoleID = details.concernRoleID;
    // set the case reference
    caseHeaderDtls.caseReference = curam.core.sl.fact.CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;
    // set new Case ID to unique number
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();
    caseHeaderDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.registrationDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.receivedDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.priorityCode = curam.codetable.CASEPRIORITY.DEFAULTCODE;
    caseHeaderDtls.classificationCode = curam.codetable.CASECLASSIFICATION.DEFAULTCODE;
    caseHeaderDtls.appealIndicator = false;
    caseHeaderDtls.integratedCaseID = key.servicePlanIntegratedCaseKey.caseID;
    caseHeaderDtls.comments = details.comments;
    // BEGIN, CR00060051, PMD
    caseHeaderDtls.ownerOrgObjectLinkID = 0;
    // END, CR00060051

    // insert new record to CaseHeader
    caseHeaderObj.insert(caseHeaderDtls);

    // fill CaseStatus details
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseStatusDtls.statusCode = curam.codetable.CASESTATUS.OPEN;

    // insert new record to CaseStatus
    caseStatusObj.insert(caseStatusDtls);

    // fill CaseEvent details
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.ACTIVE;
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.startDate = caseHeaderDtls.startDate;
    caseEventDtls.endDate = caseHeaderDtls.startDate;
    caseEventDtls.caseID = caseHeaderDtls.caseID;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = curam.codetable.CASEEVENTTYPE.PLANOPENED;

    // insert caseEvent record
    caseEventObj.insert(caseEventDtls);

    // BEGIN CR00109001, GBA

    // //////////////////////////////////////////////////////////////
    // fill ServicePlanDelivery record
    servicePlanDeliveryDtls.caseID = caseHeaderDtls.caseID;
    servicePlanDeliveryDtls.servicePlanID = details.servicePlanID;
    servicePlanDeliveryDtls.createdBy = curam.util.transaction.TransactionInfo.getProgramUser();

    // insert new ServicePlanDelivery record
    servicePlanDeliveryObj.insert(servicePlanDeliveryDtls);

    // set the key returned
    servicePlanDeliveryKey.key.caseID = caseHeaderDtls.caseID;

    // fill CaseParticipantRole record for Primary Plan Participant
    caseParticipantRoleDetails.dtls.participantRoleID = details.concernRoleID;
    caseParticipantRoleDetails.dtls.caseID = caseHeaderDtls.caseID;
    caseParticipantRoleDetails.dtls.fromDate = curam.util.type.Date.getCurrentDate();
    caseParticipantRoleDetails.dtls.typeCode = CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT;

    // insert Primary Plan Participant record
    caseParticipantRoleObj.insertCaseParticipantRole(caseParticipantRoleDetails);

    // =====================================================================
    // fill CaseParticipantRole record with all planned participants.
    StringList stringList = new StringList();

    stringList = StringUtil.tabText2StringListWithTrim(details.planParticipants);

    final int size = stringList.size();
    boolean flagHasPrimary = false;

    // Validations Starts here
    // Check if primary client is selected as planned participant, if not
    // throw
    // an exception
    if (size == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_FV_SERVICEPLAN_PRIMARY_HAS_TO_BE_PLANNED_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Check if primary has been selected as one of the planned
    // participants.
    for (int i = 0; i < size; i++) {
      // BEGIN CR00130173, ZV
      if (stringList.item(i).trim().length() > 0) {
        caseParticipantRoleDetails.dtls.participantRoleID = Long.parseLong(
          stringList.item(i));
        // Check if the primary is selected from the list
        if (caseParticipantRoleDetails.dtls.participantRoleID
          == details.concernRoleID) {
          flagHasPrimary = true;
          break;
        }
      }
      // END CR00130173
    }

    if (!flagHasPrimary) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_FV_SERVICEPLAN_PRIMARY_IS_NOT_PLANNED_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // Validations Ends Here

    // Insert Plan Participant records into database.
    caseParticipantRoleDetails.dtls.typeCode = CASEPARTICIPANTROLETYPE.PLANPARTICIPANT;
    for (int i = 0; i < size; i++) {
      caseParticipantRoleDetails.dtls.participantRoleID = Long.parseLong(
        stringList.item(i));

      // If the selected planned participant is primary, do not insert him
      // twice as the primary id is already inserted while creating the
      // service plan delivery case in OOTB method. insert all other
      // selected
      // planned participants.
      if (caseParticipantRoleDetails.dtls.participantRoleID
        != details.concernRoleID) {
        // insert new CaseParticipantRole record
        caseParticipantRoleObj.insertCaseParticipantRole(
          caseParticipantRoleDetails);
      }
    }
    // END CR00109001

    // BEGIN, CR00060051, PMD
    // Create a case owner
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Set the caseHeaderKey to be the service plan case id
    caseHeaderKey.caseID = caseHeaderDtls.caseID;

    // Create the case owner
    // BEGIN, CR00205190, SS
    // Check if a workflow is configured for this particular case type.
    final curam.serviceplans.sl.intf.ServicePlan serviceplanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();
    final ServicePlanKey serviceplankey = new ServicePlanKey();

    serviceplankey.key.servicePlanID = details.servicePlanID;

    if (CuramConst.gkZero != serviceplankey.key.servicePlanID) {

      // Retrieve the ownershipStrategyName configured for this case type.
      final ReadServicePlanDetails readServicePlanDetails = serviceplanObj.read(
        serviceplankey);

      if (!StringUtil.isNullOrEmpty(
        readServicePlanDetails.plan.ownershipStrategyName)) {
        final CaseKey caseID = new CaseKey();

        caseID.caseID = caseHeaderKey.caseID;
        final OwnershipStrategyDetails ownershipStrategyDetails = new OwnershipStrategyDetails();

        ownershipStrategyDetails.ownershipStrategyName = readServicePlanDetails.plan.ownershipStrategyName;
        caseUserRoleObj.createOwnerBasedOnOwnershipStrategy(caseID,
          ownershipStrategyDetails);
      } else {

        caseUserRoleObj.createOwner(caseHeaderKey, new OrgObjectLinkDtls());
      }
    } else {

      caseUserRoleObj.createOwner(caseHeaderKey, new OrgObjectLinkDtls());
    }
    // END, CR00060051
    // END, CR00205190
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATEPLAN;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = servicePlanDeliveryKey.key.caseID;

    curam.util.events.impl.EventService.raiseEvent(event);

    // BEGIN CR00108818, GBA
    // Log Transaction Details
    if (servicePlanDeliveryDtls != null && servicePlanDeliveryDtls.caseID != 0) {

      // Service Plan Case Type manipulation variables
      final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servPlanDelKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

      servPlanDelKey.caseID = servicePlanDeliveryDtls.caseID;
      final CodeTableItemIdentifier SPTypeCodeIdentifier = new CodeTableItemIdentifier(
        SERVICEPLANTYPE.TABLENAME,
        servicePlanDeliveryObj.readServicePlanType(servPlanDelKey).servicePlanType);
      // ConcernRole manipulation variables to get Case Member name
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final curam.core.struct.ConcernRoleKey concernRoleKeyObj = new curam.core.struct.ConcernRoleKey();

      concernRoleKeyObj.concernRoleID = details.concernRoleID;

      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.SERVICEPLAN_OPENED).arg(SPTypeCodeIdentifier).arg(
        concernRoleObj.read(concernRoleKeyObj).concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.SERVICEPLAN_OPENED, description,
        caseHeaderDtls.integratedCaseID, servicePlanDeliveryDtls.caseID);
    }
    // END CR00108818

    return servicePlanDeliveryKey;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all active integrated case members and service plan types
   * available for creation on this integrated case.
   *
   * @param key
   * Contains case ID of the integrated case.
   *
   * @return List of integrated case members and service plan types .
   */
  @Override
  public ICMembersAndSPTypesDetails getAvailableICMembersAndSPTypes(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ICMembersAndSPTypesDetails icMembersAndSPTypesDetails = new ICMembersAndSPTypesDetails();

    // service plan integrated case ID and record status key
    final ServicePlanIntegratedCaseIDAndRecordStatusKey servicePlanIntegratedCaseIDAndRecordStatusKey = new ServicePlanIntegratedCaseIDAndRecordStatusKey();

    // set case id
    servicePlanIntegratedCaseIDAndRecordStatusKey.caseID = key.servicePlanIntegratedCaseKey.caseID;

    // set record status to active
    servicePlanIntegratedCaseIDAndRecordStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
    // END HARP 44562

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new curam.core.sl.struct.ViewCaseParticipantRole_boKey();

    // AdminICServicePlanLink entity manipulation variables
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLinkObj = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();

    // set the integrated case key
    viewCaseParticipantRole_boKey.dtls.caseID = key.servicePlanIntegratedCaseKey.caseID;
    // BEGIN CR00118810, GBA
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    // END CR00118810

    // read the list of case participant roles
    icMembersAndSPTypesDetails.caseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseMemberList(
      viewCaseParticipantRole_boKey);

    // read the list of available service plan types
    icMembersAndSPTypesDetails.servicePlanTypeDetailsList = adminICServicePlanLinkObj.searchActiveSPTypesByIntegratedCaseID(
      servicePlanIntegratedCaseIDAndRecordStatusKey);
    // END HARP 44562

    // return the details
    return icMembersAndSPTypesDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all service plan types available for creation on this
   * integrated case.
   *
   * @param key
   * Contains case ID of the integrated case.
   *
   * @return List of service plan types.
   */
  @Override
  public ServicePlanTypesList getAvailableSPTypes(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanTypesList servicePlanTypesList = new ServicePlanTypesList();

    // service plan integrated case ID and record status key
    final ServicePlanIntegratedCaseIDAndRecordStatusKey servicePlanIntegratedCaseIDAndRecordStatusKey = new ServicePlanIntegratedCaseIDAndRecordStatusKey();

    // set case id
    servicePlanIntegratedCaseIDAndRecordStatusKey.caseID = key.servicePlanIntegratedCaseKey.caseID;

    // set record status to active
    servicePlanIntegratedCaseIDAndRecordStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
    // END HARP 44652

    // AdminICServicePlanLink entity manipulation variables
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLinkObj = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();

    // read the list of available service plan types
    servicePlanTypesList.servicePlanTypeDetailsList = adminICServicePlanLinkObj.searchActiveSPTypesByIntegratedCaseID(
      servicePlanIntegratedCaseIDAndRecordStatusKey);
    // END HARP 44652

    return servicePlanTypesList;
  }

  /**
   * Lists all service plans for the specified integrated case member.
   *
   * @param key
   * Contains case participant role ID.
   *
   * @return List of service plan details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_LIST_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to list
   * service plans for the selected client.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanForICMemberList listByICMember(IntegratedCaseMemberKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanForICMemberList servicePlanForICMemberList = new ServicePlanForICMemberList();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.SearchByIntegratedCaseMemberKey searchByIntegratedCaseMemberKey = new curam.serviceplans.sl.entity.struct.SearchByIntegratedCaseMemberKey();

    // PlanndedGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey readGoalNameByCaseIDKey = new curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey();
    curam.serviceplans.sl.entity.struct.GoalNameDetails goalNameDetails;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();
    final curam.core.sl.entity.struct.CaseIDParticipantRoleKey caseIDParticipantRoleKey = new curam.core.sl.entity.struct.CaseIDParticipantRoleKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanParticipantSecurityKey spParticipantSecurityKey = new ServicePlanParticipantSecurityKey();

    // set case participant role key
    caseParticipantRoleKey.caseParticipantRoleID = key.integratedCaseMemberKey.caseParticipantRoleID;

    // read participant role id
    final curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails concernRoleDetails = caseParticipantRoleObj.readParticipantRoleDetails(
      caseParticipantRoleKey);

    // set the service plan participant key
    spParticipantSecurityKey.concernRoleID = concernRoleDetails.concernRoleID;

    try {
      servicePlanSecurity.participantSensitivityCheck(spParticipantSecurityKey);
    } catch (final curam.util.exception.AppException e) {
      throw new AppException(
        BPOSERVICEPLANDELIVERY.ERR_LIST_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
    }

    // an element of the returned list
    curam.serviceplans.sl.struct.ServicePlanDeliverySummaryDetails servicePlanDeliverySummaryDetails;

    // read integrated case ID
    final ServicePlanIntegratedCaseKey integratedCaseKey = getIntegratedCaseID(
      key);

    // find out case participant role for the integrated case
    // set the key to read case participant role ID
    caseIDParticipantRoleKey.caseID = integratedCaseKey.servicePlanIntegratedCaseKey.caseID;
    caseIDParticipantRoleKey.participantRoleID = concernRoleDetails.concernRoleID;

    // read the caseParticipantRoleID
    final curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleIDDetails = caseParticipantRoleObj.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // set the search key
    searchByIntegratedCaseMemberKey.caseParticipantRoleID = caseParticipantRoleIDDetails.caseParticipantRoleID;
    searchByIntegratedCaseMemberKey.recordStatus = RECORDSTATUS.NORMAL;

    // read service plan list
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliverySummaryDetailsList servicePlanDeliveryDetailsList = servicePlanDeliveryObj.searchByIntegratedCaseMember(
      searchByIntegratedCaseMemberKey);

    for (int i = 0; i < servicePlanDeliveryDetailsList.dtls.size(); i++) {

      // create an element of the returned list
      servicePlanDeliverySummaryDetails = new curam.serviceplans.sl.struct.ServicePlanDeliverySummaryDetails();

      // assign service plan delivery details
      servicePlanDeliverySummaryDetails.assign(
        servicePlanDeliveryDetailsList.dtls.item(i));

      // set the key
      readGoalNameByCaseIDKey.caseID = servicePlanDeliveryDetailsList.dtls.item(i).caseID;

      // read goal name, if the goal is set
      try {
        goalNameDetails = plannedGoalObj.readNameByCaseID(
          readGoalNameByCaseIDKey);
      } catch (final RecordNotFoundException e) {
        goalNameDetails = null;
      }

      // assign service plan name details
      if (goalNameDetails != null) {
        servicePlanDeliverySummaryDetails.assign(goalNameDetails);
      }

      // add details to the returned list
      servicePlanForICMemberList.servicePlanDeliverySummaryDetailsList.addRef(
        servicePlanDeliverySummaryDetails);
    }

    // return the list
    return servicePlanForICMemberList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all service plans for the specified integrated case.
   *
   * @param key
   * Contains integrated case ID.
   *
   * @return List of service plan details.
   */
  @Override
  public ServicePlanForICList listByIntegratedCase(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanForICList servicePlanForICList = new ServicePlanForICList();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.SearchByIntegratedCaseAndParticipantTypeKey searchByIntegratedCaseAndParticipantTypeKey = new curam.serviceplans.sl.entity.struct.SearchByIntegratedCaseAndParticipantTypeKey();

    // PlanndedGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey readGoalNameByCaseIDKey = new curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey();
    curam.serviceplans.sl.entity.struct.GoalNameDetails goalNameDetails;

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.servicePlanIntegratedCaseKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    // if the result is false, throw an exception
    if (!dataBasedSecurityResult.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_CASE_SECURITY_CHECK_FAILED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00227042

    // an element of the returned list
    curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDeliveryAndParticipantSummaryDetails;

    // set the key
    searchByIntegratedCaseAndParticipantTypeKey.integratedCaseID = key.servicePlanIntegratedCaseKey.caseID;
    // BEGIN CR00109001, GBA
    searchByIntegratedCaseAndParticipantTypeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT;
    // END CR00109001
    searchByIntegratedCaseAndParticipantTypeKey.recordStatus = RECORDSTATUS.NORMAL;

    // read service plan details list
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryAndParticipantSummaryDetailsList servicePlanDeliveryAndParticipantDetailsList = servicePlanDeliveryObj.searchByIntegratedCaseID(
      searchByIntegratedCaseAndParticipantTypeKey);

    for (int i = 0; i
      < servicePlanDeliveryAndParticipantDetailsList.dtls.size(); i++) {

      // create an element of the returned list
      servicePlanDeliveryAndParticipantSummaryDetails = new curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails();

      // assign service plan delivery and participant details
      servicePlanDeliveryAndParticipantSummaryDetails.assign(
        servicePlanDeliveryAndParticipantDetailsList.dtls.item(i));

      // set the key
      readGoalNameByCaseIDKey.caseID = servicePlanDeliveryAndParticipantDetailsList.dtls.item(i).caseID;

      // read goal name, if the goal is set for the service plan
      try {
        goalNameDetails = plannedGoalObj.readNameByCaseID(
          readGoalNameByCaseIDKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        goalNameDetails = null;
      }

      // assign service plan name details
      if (goalNameDetails != null) {
        servicePlanDeliveryAndParticipantSummaryDetails.assign(goalNameDetails);
      }

      // add details to the returned list
      servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.addRef(
        servicePlanDeliveryAndParticipantSummaryDetails);

    }
    return servicePlanForICList;
  }

  /**
   * Reads service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanDeliveryReadDetails read(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryReadDetails servicePlanDeliveryReadDetails = new ServicePlanDeliveryReadDetails();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ReadGoalAndOutcomeKey readGoalAndOutcomeKey = new curam.serviceplans.sl.entity.struct.ReadGoalAndOutcomeKey();
    curam.serviceplans.sl.entity.struct.SPGoalAndOutcomeDetails spGoalAndOutcomeDetails;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.ParticipantCaseAndUserKey participantCaseAndUserKey = new curam.core.struct.ParticipantCaseAndUserKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // ServicePlan entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // BEGIN, CR00000993, PMD
    // Tracking Gantt manipulation variables
    final curam.serviceplans.sl.intf.TrackingGantt trackingGanttObj = curam.serviceplans.sl.fact.TrackingGanttFactory.newInstance();
    // BEGIN, CR00000993, PMD

    // BEGIN, CR00066677, CM
    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // CaseHeaderKey
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // END, CR00066677

    // BEGIN, CR00092078, SPD
    // Bookmark manipulation variables
    final curam.core.sl.intf.Bookmark bookmarkObj = curam.core.sl.fact.BookmarkFactory.newInstance();
    final CountCaseBookmarkKey countCaseBookmarkKey = new CountCaseBookmarkKey();

    // END, CR00092078

    // set the key for reading case header details
    participantCaseAndUserKey.caseID = key.key.caseID;
    // BEGIN CR00109001, GBA
    participantCaseAndUserKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT;
    // END CR00109001

    // read case header details
    servicePlanDeliveryReadDetails.participantCaseAndUserDetails = caseHeaderObj.readParticipanCaseAndUserDetails(
      participantCaseAndUserKey);

    // read service plan type
    servicePlanDeliveryReadDetails.servicePlanTypeStruct = servicePlanDeliveryObj.readServicePlanType(
      key.key);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanIDDetails servicePlanIDDetails = servicePlanObj.readByServicePlanDeliveryID(
      key.key);

    // END HARP 45406

    // set case participant role key
    caseParticipantRoleKey.caseParticipantRoleID = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.caseParticipantRoleID;

    // read participant role id
    final curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails concernRoleDetails = caseParticipantRoleObj.readParticipantRoleDetails(
      caseParticipantRoleKey);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = concernRoleDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanIDDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN, CR00227859, PM
    checkReadSecurity(key.key.caseID);
    // END, CR00227859

    // set the key for reading goal and outcome details
    readGoalAndOutcomeKey.caseID = key.key.caseID;

    // read service plan goal and outcome details
    try {
      spGoalAndOutcomeDetails = servicePlanDeliveryObj.readGoalAndOutcome(
        readGoalAndOutcomeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      spGoalAndOutcomeDetails = null;
    }

    if (spGoalAndOutcomeDetails != null) {
      servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.assign(
        spGoalAndOutcomeDetails);
    }

    // read service plan type
    servicePlanDeliveryReadDetails.servicePlanTypeStruct = servicePlanDeliveryObj.readServicePlanType(
      key.key);

    // BEGIN, CR00096264, SK
    servicePlanDeliveryReadDetails.servicePlanTypeStruct.servicePlanID = servicePlanIDDetails.servicePlanID;
    // END, CR00096264

    // BEGIN, CR00000993, PMD
    if (spGoalAndOutcomeDetails != null) {
      servicePlanDeliveryReadDetails.trackingGanttDetails = trackingGanttObj.viewTrackingGantt(
        key);
    }
    // END, CR00000993

    // BEGIN, CR00066677, CM
    // Set the caseHeaderKey
    caseHeaderKey.caseID = key.key.caseID;

    // Read the case owner
    final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
      caseHeaderKey);

    // if the type is a user
    if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

      // Set orgObjectReferenceName
      caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.userFullName;
    }

    // Set the case owner details
    servicePlanDeliveryReadDetails.ownerDetails.assign(caseOwnerDetails);
    // END, CR00066677

    // BEGIN, CR00092078, SPD
    // populate key
    // BEGIN, CR00093024, SPD
    countCaseBookmarkKey.dtls.userName = TransactionInfo.getProgramUser();
    // END, CR00093024
    countCaseBookmarkKey.dtls.caseID = key.key.caseID;

    // return number of case bookmarks for the current user
    final Count count = bookmarkObj.countCaseBookmark(countCaseBookmarkKey);

    // check if a case bookmark record exists, the default is false
    if (count.numberOfRecords > 0) {

      servicePlanDeliveryReadDetails.caseIsUserBookmarkInd = true;
    }
    // END, CR00092078

    // BEGIN, CR00129996, ZV
    final SpecialCaution specialCautionObj = SpecialCautionFactory.newInstance();
    final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

    servicePlanDeliveryReadDetails.participantRoleID = concernRoleDetails.concernRoleID;

    // assigning concern role id to SpecialCautionConcernKey struct
    specialCautionConcernKey.concernRoleID = concernRoleDetails.concernRoleID;
    // invoking displayActiveSpecialCautionIndicator() method on special
    // caution
    // object
    servicePlanDeliveryReadDetails.specialCautionInd = specialCautionObj.displayActiveSpecialCautionIndicator(specialCautionConcernKey).displayIndicator;
    // END, CR00129996

    return servicePlanDeliveryReadDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads IC type and reference of the integrated case and case member concern
   * role name.
   *
   * @param key
   * Contains case participant role ID.
   *
   * @return Integrated case details.
   */
  @Override
  public ICDetails readIntegratedCaseDetails(IntegratedCaseMemberKey key)
    throws AppException, InformationalException {

    // return value
    final ICDetails icDetails = new ICDetails();

    // CaseHeader entity manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();
    curam.core.sl.entity.struct.CaseParticipantRole_eoFullNameDetails participantName;

    // read integrated case ID
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = getIntegratedCaseID(
      key);

    // set the case participant role key
    caseParticipantRoleKey.caseParticipantRoleID = key.integratedCaseMemberKey.caseParticipantRoleID;

    // read participant name
    participantName = caseParticipantRoleObj.readFullName(
      caseParticipantRoleKey);

    // set the integrated case key
    caseKey.caseID = servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID;

    // read integrated case reference and case type code
    final curam.core.struct.CaseReferenceAndICTypeDetails details = caseHeaderObj.readCaseReferenceAndICType(
      caseKey);

    // assign details to the return struct
    icDetails.caseReferenceConcernRoleNameCaseType.caseReference = details.caseReference;
    icDetails.caseReferenceConcernRoleNameCaseType.caseTypeCode = details.integratedCaseType;
    icDetails.caseReferenceConcernRoleNameCaseType.concernRoleName = participantName.fullName;

    // return integrated case details
    return icDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery participant, type and reference.
   *
   * @param key
   * Contains service plan delivery case ID.
   *
   * @return Service plan delivery participant, type and reference details.
   */
  @Override
  public ServicePlanParticipantAndReferenceDetails readParticipantTypeAndReferenceDetails(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = new ServicePlanParticipantAndReferenceDetails();

    // CaseHeader entity manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // set the key
    caseKey.caseID = key.key.caseID;

    // read the details from CaseHeader
    spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails = caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(
      caseKey);

    // read service plan delivery type
    spParticipantAndReferenceDetails.servicePlanTypeStruct = servicePlanDeliveryObj.readServicePlanType(
      key.key);

    return spParticipantAndReferenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads menu data.
   *
   * @param key
   * Contains service plan delivery case ID.
   *
   * @return Service plan delivery menu data.
   */
  @Override
  public ServicePlanMenuData readServicePlanMenuData(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanMenuData servicePlanMenuData = new ServicePlanMenuData();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    final curam.core.struct.CaseSearchKey caseSearchKey = new curam.core.struct.CaseSearchKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseIDParticipantRoleKey caseIDParticipantRoleKey = new curam.core.sl.entity.struct.CaseIDParticipantRoleKey();

    // set the key for service plan menu data reading
    // set case key
    caseKey.caseID = key.key.caseID;

    // set case header key
    caseHeaderKey.caseID = key.key.caseID;

    // read participant role for the service plan delivery case
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // read integrated case ID
    final curam.core.struct.IntegratedCaseKey integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(
      caseKey);

    // BEGIN, CR00161962, KY
    // assign integrated case id to the returned struct
    if (integratedCaseKey.integratedCaseID != 0) {
      servicePlanMenuData.integratedCaseID = integratedCaseKey.integratedCaseID;

      // set case key to the integrated case key
      caseKey.caseID = integratedCaseKey.integratedCaseID;
    } else {
      servicePlanMenuData.integratedCaseID = key.key.caseID;
      caseKey.caseID = key.key.caseID;
    }
    // read integrated case menu details
    servicePlanMenuData.ICPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    // set the key to read case participant role ID
    caseIDParticipantRoleKey.caseID = integratedCaseKey.integratedCaseID;
    caseIDParticipantRoleKey.participantRoleID = readParticipantRoleIDDetails.concernRoleID;

    // Read the caseParticipantRoleID
    final curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleIDDetails = caseParticipantRole.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // assign caseParticipantRoleID to the returned struct
    servicePlanMenuData.caseParticipantRoleID = caseParticipantRoleIDDetails.caseParticipantRoleID;

    // set the key to read case reference
    caseSearchKey.caseID = caseKey.caseID;

    // read case reference
    final curam.core.struct.CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
      caseSearchKey);

    // assign caseReference to the returned struct
    servicePlanMenuData.caseReference = caseReference.caseReference;

    // return service plan menu data
    return servicePlanMenuData;

  }

  // ___________________________________________________________________________
  /**
   * Validates service plan types available for service plan delivery creation.
   *
   * @param list
   * List of available service plan types
   */
  @Override
  public void validateAvailableSPTypesForCreation(ServicePlanTypesList list)
    throws AppException, InformationalException {

    // there must be one or more service plan types associated with the
    // integrated case type
    if (list.servicePlanTypeDetailsList.dtls.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_FV_SP_TYPES_LIST_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates case member for which the service plan delivery is to be created.
   *
   * @param details
   * Case member concern role ID.
   */
  @Override
  public void validateCaseMember(CaseMemberDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00099541, PMD
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // END, CR00099541

    // case member must be specified
    if (details.concernRoleID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_FV_CASE_MEMBER_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00099541, PMD
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set the key to be that of the primary client
    concernRoleKey.concernRoleID = details.concernRoleID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd = clientMergeObj.isConcernRoleDuplicate(
      concernRoleKey);

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTMERGE.ERR_CREATE_SERVICE_PLAN_DUPLICATE_CLIENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN CR00096012, PN
    ConcernRoleDtls concernRoleDtls;
    String concernRoleType = null;
    // Concern role variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    concernRoleKey.concernRoleID = details.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    if (concernRoleDtls != null) {
      concernRoleType = concernRoleDtls.concernRoleType;
    }

    final curam.core.sl.intf.ProspectPersonMaintenance prospectPersonMaintenanceObj = curam.core.sl.fact.ProspectPersonMaintenanceFactory.newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();
    final ReadProspectPersonKey readProspectPersonKey = new ReadProspectPersonKey();

    if (concernRoleType != null
      && concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {
      maintainConcernRoleKey.concernRoleID = details.concernRoleID;
      readProspectPersonKey.maintainConcernRoleKey.concernRoleID = details.concernRoleID;
      final curam.core.sl.struct.ReadProspectPersonDtls readProspectPersonSLDtls = prospectPersonMaintenanceObj.readProspectPerson(
        readProspectPersonKey.maintainConcernRoleKey);

      if (readProspectPersonSLDtls.dtls.personConcernRoleID == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANDELIVERY.ERR_SP_DELIVERY_PROSPECT_PERSON),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END CR00096012

    // END, CR00099541

  }

  // ___________________________________________________________________________
  /**
   * Validates integrated case on which the service plan delivery is to be
   * created.
   *
   * @param key
   * Integrated case key
   */
  @Override
  public void validateICStatus(ServicePlanIntegratedCaseKey key)
    throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // set the key
    caseHeaderKey.caseID = key.servicePlanIntegratedCaseKey.caseID;

    // read case status
    final curam.core.struct.CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(
      caseHeaderKey);

    // a service plan delivery cannot be created for an integrated case
    // that is closed
    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)
      || caseStatusCode.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_FV_CASESTATUS_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Reads integrated case ID for the case member
   *
   * @param key
   * Case participant role ID of the case member
   *
   * @return Integrated case identification.
   */
  @Override
  public ServicePlanIntegratedCaseKey getIntegratedCaseID(
    IntegratedCaseMemberKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanIntegratedCaseKey servicePlanICKey = new ServicePlanIntegratedCaseKey();

    // CaseParticipantRole entity manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // set the key
    caseParticipantRoleKey.caseParticipantRoleID = key.integratedCaseMemberKey.caseParticipantRoleID;

    // the case participant role passed in could be for the integrated case
    // participant or for the service plan participant

    // read case ID for the participant
    final curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDDetails caseIDDetails = caseParticipantRoleObj.readCaseID(
      caseParticipantRoleKey);

    // if the case is not an integrated case, we must find out
    // integrated case ID
    caseKey.caseID = caseIDDetails.caseID;

    // read integrated case by service plan case id
    final curam.core.struct.IntegratedCaseKey integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(
      caseKey);

    if (integratedCaseKey.integratedCaseID != 0) {
      servicePlanICKey.servicePlanIntegratedCaseKey.caseID = integratedCaseKey.integratedCaseID;
    } else {
      servicePlanICKey.servicePlanIntegratedCaseKey.caseID = caseIDDetails.caseID;
    }

    return servicePlanICKey;

  }

  // ___________________________________________________________________________
  /**
   * Reads integrated case type and reference for the service plan delivery.
   *
   * @param key
   * Service plan delivery case ID.
   *
   * @return Integrated case type and reference.
   */
  @Override
  public CaseReferenceAndICTypeDetails readIntegratedCaseTypeAndReference(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final CaseReferenceAndICTypeDetails caseReferenceAndICTypeDetails = new CaseReferenceAndICTypeDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // set integrated case key
    caseKey.caseID = key.servicePlanIntegratedCaseKey.caseID;

    // read integrated case details
    caseReferenceAndICTypeDetails.caseReferenceAndICTypeDetails = caseHeaderObj.readCaseReferenceAndICType(
      caseKey);

    return caseReferenceAndICTypeDetails;
  }

  // BEGIN, CR00000082, PMD
  // ___________________________________________________________________________
  /**
   * Adds a plan template to a service plan delivery. Creates planned goal, plan
   * groups, milestones, sub-goals and planItems defined by the template.
   *
   * @param servicePlanKey
   * Service plan delivery case ID.
   * @param planTemplateKey
   * Plan template ID
   */
  @Override
  public void addTemplate(ServicePlanDeliveryKey servicePlanKey,
    PlanTemplateKey planTemplateKey) throws AppException,
      InformationalException {

    // PlanTemplate entity
    final curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    // PlanTemplatePlanGroup entity
    final PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    // PlanTemplateSubGoal entity
    final PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    // PlanTemplatePlanItem entity
    final PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    // PlannedGoal entity
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();

    final PlannedGoalDtls plannedGoalDtls = new PlannedGoalDtls();

    // PlannedSubGoal entity
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem entity and service layer
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    // Read Goal ID
    GoalIDDetails goalIDDetails = new GoalIDDetails();

    goalIDDetails = planTemplateObj.readGoalID(planTemplateKey.planTemplateKey);

    // create planned goal details
    plannedGoalDtls.caseID = servicePlanKey.key.caseID;
    plannedGoalDtls.goalID = goalIDDetails.goalID;

    // insert planned goal
    plannedGoalObj.insert(plannedGoalDtls);

    // Get back the newly created planned goal key
    final PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    plannedGoalKey.plannedGoalID = plannedGoalDtls.plannedGoalID;

    // BEGIN, CR00057255, PMD
    // Create service plan level milestones
    MilestoneTemplateDetailsList milestoneTemplateDetailsList = new MilestoneTemplateDetailsList();

    // Get the list of milestones configured at service plan level
    // for the selected template
    milestoneTemplateDetailsList = PlanTemplateMilestoneFactory.newInstance().searchServicePlanLevelMilestones(
      planTemplateKey.planTemplateKey);

    for (int k = 0; k < milestoneTemplateDetailsList.dtls.size(); k++) {

      // Add the service plan template milestone to the service plan
      addTemplateMilestone(servicePlanKey,
        milestoneTemplateDetailsList.dtls.item(k));
    }
    // END, CR00057255

    // Create PlanGroups
    final PlanTemplatePlanGroupDetailsList planTemplatePlanGroupDetailsList = new PlanTemplatePlanGroupDetailsList();

    planTemplatePlanGroupDetailsList.detailsList = planTemplatePlanGroupObj.getParentPlanGroupDetails(
      planTemplateKey.planTemplateKey);

    // Call recursive method
    addTemplatePlanGroup(planTemplatePlanGroupDetailsList, plannedGoalKey);

    // Read Template Sub-Goal details
    TemplateSubGoalDetailsList templateSubGoalDetailsList = new TemplateSubGoalDetailsList();

    templateSubGoalDetailsList = planTemplateSubGoalObj.searchParentSubGoalsByPlanTemplateID(
      planTemplateKey.planTemplateKey);

    for (int i = 0; i < templateSubGoalDetailsList.dtls.size(); i++) {

      // BEGIN, CR00292366, AKr
      final PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      planTemplateSubGoalKey.planTemplateSubGoalID = templateSubGoalDetailsList.dtls.item(i).planTemplateSubGoalID;

      // create planned sub goal details
      final PlannedSubGoalDtls plannedSubGoalDtls = new PlannedSubGoalDtls();

      plannedSubGoalDtls.plannedGoalID = plannedGoalDtls.plannedGoalID;
      plannedSubGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
      plannedSubGoalDtls.ownerID = curam.util.transaction.TransactionInfo.getProgramUser();
      plannedSubGoalDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;
      plannedSubGoalDtls.subGoalID = templateSubGoalDetailsList.dtls.item(i).subGoalID;
      plannedSubGoalDtls.createdOn = planTemplateSubGoalObj.readLastWritten(planTemplateSubGoalKey).lastWritten;
      // END, CR00292366
      plannedSubGoalObj.insert(plannedSubGoalDtls);

      // Read template plan items that are assigned to this template
      // sub-goal
      // BEGIN, CR00226899 MN
      PlanItemAndTemplatePlanItemDetailsList planItemAndPlanTemplatePlanItemDetailsList = new PlanItemAndTemplatePlanItemDetailsList();

      // END, CR00226899

      // BEGIN, CR00226899 MN
      planItemAndPlanTemplatePlanItemDetailsList = planTemplatePlanItemObj.searchPlanItemByPlanTemplateSubGoalID(
        planTemplateSubGoalKey);
      // END, CR00226899

      for (int j = 0; j
        < planItemAndPlanTemplatePlanItemDetailsList.dtls.size(); j++) {
        // BEGIN, CR00021303, SP
        // BEGIN, HARP 64097, NK
        // BEGIN, CR00235251, TV
        final PlannedItemDetailsStruct createPlannedItemDetailsStruct = new PlannedItemDetailsStruct();
        // END, CR00235251
        // END, HARP 64097
        // END, CR00021303

        // Read the plan item name and assign
        final PlanItemKey planItemKey = new PlanItemKey();

        planItemKey.planItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).planItemID;

        createPlannedItemDetailsStruct.plannedItemDtls.name = CodeTable// BEGIN, CR00163098, JC
          .getOneItem(PLANITEMNAME.TABLENAME,
          planItemObj.readName(planItemKey).name,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        // create planned item details
        createPlannedItemDetailsStruct.plannedItemDtls.expectedOutcomeID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).expectedOutcomeID;

        createPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

        createPlannedItemDetailsStruct.plannedItemDtls.planItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).planItemID;

        createPlannedItemDetailsStruct.plannedItemDtls.expectedStartDate = curam.util.type.Date.getCurrentDate().addDays(
          planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).startDay);

        // BEGIN, CR00000048, PMD
        createPlannedItemDetailsStruct.plannedItemDtls.authorizedUnits = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).authorizedUnits;
        // END, CR00000048

        // BEGIN, CR00000637, PMD
        createPlannedItemDetailsStruct.plannedItemDtls.maximumUnits = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).maximumUnits;
        // END, CR00000637

        // BEGIN, CR00161962, KY
        // Check to see if we only have one plan participants for this
        // service
        // plan. If so then default the concerningID
        final ServicePlanParticipantDetailsList servicePlanParticipantDetailsList = listPlanParticipants(
          servicePlanKey);

        if (servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.size()
          == 1) {
          // get the primary participant concernRoleID's so we can
          // default all
          // PlannedItem concerningID's to this value
          final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
            servicePlanKey);

          createPlannedItemDetailsStruct.plannedItemDtls.concerningID = servicePlanAndParticipantDetails.concernRoleID;
        }
        // END, CR00161962
        int duration = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).duration;

        if (duration > 0) {
          duration = duration - 1;
        }

        createPlannedItemDetailsStruct.plannedItemDtls.expectedEndDate = createPlannedItemDetailsStruct.plannedItemDtls.expectedStartDate.addDays(
          duration);

        createPlannedItemDetailsStruct.plannedItemDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

        // BEGIN, CR00161962, KY
        // set the 'plan template plan item id' in the
        // create planned item details struct
        createPlannedItemDetailsStruct.planTemplatePlanItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).planTemplatePlanItemID;
        // END, CR00161962

        // BEGIN, CR00246725, MR
        final PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

        planTemplatePlanItemKey.planTemplatePlanItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).planTemplatePlanItemID;
        final PlanTemplatePlanItemDtls planTemplatePlanItemDtls = planTemplatePlanItemObj.read(
          planTemplatePlanItemKey);

        // Setting the status of the planned item based on the
        // approval required indicator value set in the template.
        if (planTemplatePlanItemDtls.approvalReqInd) {
          createPlannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.UNAPPROVED;
        } else {
          createPlannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.NOTSTARTED;
        }

        // Setting the mandatory indicator of the planned item based on the
        // mandatory indicator value set in the template.
        if (planTemplatePlanItemDtls.isMandatoryInd) {
          createPlannedItemDetailsStruct.plannedItemDtls.isMandatoryInd = true;
        }

        // Setting the guidance URL of the planned item based on the
        // guidance URL value set in the plan item.
        final PlanItemDtls planItemDtls = planItemObj.read(planItemKey);

        if (!StringUtil.isNullOrEmpty(planItemDtls.guidanceURL)) {
          createPlannedItemDetailsStruct.plannedItemDtls.guidanceURL = planItemDtls.guidanceURL;
        }
        // END, CR00246725

        // BEGIN, CR00292366, AKr
        createPlannedItemDetailsStruct.plannedItemDtls.createdOn = planTemplatePlanItemObj.readLastWritten(planTemplatePlanItemKey).lastWritten;
        // END, CR00292366
        // insert planned item
        // call the service layer method
        // BEGIN, CR00235251, TV
        plannedItemObj.createBasicPlanItemDetails(
          createPlannedItemDetailsStruct);
        // END, CR00235251
      }

      // BEGIN, CR00057255, PMD
      // Create sub-goal level milestones
      milestoneTemplateDetailsList = new MilestoneTemplateDetailsList();

      // Get the list of milestones configured at sub-goal level
      milestoneTemplateDetailsList = PlanTemplateMilestoneFactory.newInstance().searchSubGoalLevelMilestones(
        planTemplateSubGoalKey);

      for (int l = 0; l < milestoneTemplateDetailsList.dtls.size(); l++) {

        MilestoneTemplateDetails milestoneTemplateDetails = new MilestoneTemplateDetails();

        milestoneTemplateDetails = milestoneTemplateDetailsList.dtls.item(l);
        milestoneTemplateDetails.linkDtls.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

        // Add the sub-goal template milestone to the service plan
        addTemplateMilestone(servicePlanKey, milestoneTemplateDetails);
      }
      // END, CR00057255
    }
  }

  // ___________________________________________________________________________
  /**
   * Takes in lists of TemplatePlanGroups and adds each TemplatePlanGroup along
   * with any subgoals, child plan groups and milestones that may be contained
   * within each TemplatePlanGroup.
   *
   * @param planGroupDetailsList
   * the list of details for all the plan groups
   */
  @Override
  public void addTemplatePlanGroup(
    PlanTemplatePlanGroupDetailsList planGroupDetailsList,
    PlannedGoalKey plannedGoalKey) throws AppException,
      InformationalException {

    // PlannedGroup entity
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();

    // PlannedSubGoal entity
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // PlanTemplatePlanGroup entity
    final curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    // PlanTemplateSubGoal entity
    final PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    // PlanTemplatePlanItem entity
    final PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    // PlanItem entity
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    // Add plan groups
    for (int i = 0; i < planGroupDetailsList.detailsList.dtls.size(); i++) {

      final PlannedGroupDtls plannedGroupDtls = new PlannedGroupDtls();

      // BEGIN, CR00265531, CSH
      // if name field is not populated check if there is a
      // version stored in text translation
      if (plannedGroupDtls.name.length() == 0) {
        final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();
        final curam.serviceplans.sl.struct.PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new curam.serviceplans.sl.struct.PlanTemplatePlanGroupKey();
        PlanGroupNameDetails planGroupNameDetails = new PlanGroupNameDetails();

        planTemplatePlanGroupKey.key.planTemplatePlanGroupID = planGroupDetailsList.detailsList.dtls.item(i).planTemplatePlanGroupID;
        planGroupNameDetails = planTemplateObj.readPlanGroupName(
          planTemplatePlanGroupKey);
        plannedGroupDtls.name = planGroupNameDetails.planGroupNameDetails.name;

      } else {

        plannedGroupDtls.name = planGroupDetailsList.detailsList.dtls.item(i).name;
      }
      // END, CR00265531

      // BEGIN, CR00292366, AKr
      final PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

      planTemplatePlanGroupKey.planTemplatePlanGroupID = planGroupDetailsList.detailsList.dtls.item(i).planTemplatePlanGroupID;
      plannedGroupDtls.createdOn = planTemplatePlanGroupObj.readLastWritten(planTemplatePlanGroupKey).lastWritten;
      // END, CR00292366
      plannedGroupDtls.comments = planGroupDetailsList.detailsList.dtls.item(i).comments;
      plannedGroupDtls.parentGroupID = planGroupDetailsList.detailsList.dtls.item(i).parentGroupID;
      plannedGroupDtls.plannedGoalID = plannedGoalKey.plannedGoalID;
      plannedGroupObj.insert(plannedGroupDtls);

      // BEGIN, CR00057255, PMD
      // Create plan group level milestones
      MilestoneTemplateDetailsList milestoneTemplateDetailsList = new MilestoneTemplateDetailsList();

      // Get the list of milestones configured at plan group level
      milestoneTemplateDetailsList = PlanTemplateMilestoneFactory.newInstance().searchPlanGroupLevelMilestones(
        planTemplatePlanGroupKey);

      // Read the planned goal details to get the caseID
      final PlannedGoalDtls plannedGoalDtls = PlannedGoalFactory.newInstance().read(
        plannedGoalKey);

      // Set the caseID
      final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

      servicePlanDeliveryKey.key.caseID = plannedGoalDtls.caseID;

      for (int k = 0; k < milestoneTemplateDetailsList.dtls.size(); k++) {

        MilestoneTemplateDetails milestoneTemplateDetails = new MilestoneTemplateDetails();

        milestoneTemplateDetails = milestoneTemplateDetailsList.dtls.item(k);
        milestoneTemplateDetails.linkDtls.plannedGroupID = plannedGroupDtls.plannedGroupID;

        // Create the milestone
        addTemplateMilestone(servicePlanDeliveryKey, milestoneTemplateDetails);
      }
      // END, CR00057255

      // Search for any child plan groups
      final PlanTemplatePlanGroupDetailsList childPlanGroupList = new PlanTemplatePlanGroupDetailsList();

      childPlanGroupList.detailsList = planTemplatePlanGroupObj.getChildPlanGroupDetails(
        planTemplatePlanGroupKey);

      // Need to set parent plan group ID's to that of
      // the parent plan group created above
      for (int m = 0; m < childPlanGroupList.detailsList.dtls.size(); m++) {
        childPlanGroupList.detailsList.dtls.item(m).parentGroupID = plannedGroupDtls.plannedGroupID;
      }

      // Add the child plan groups
      addTemplatePlanGroup(childPlanGroupList, plannedGoalKey);

      // Search for any child sub-goals
      TemplateSubGoalDetailsList templateSubGoalDetailsList = new TemplateSubGoalDetailsList();

      templateSubGoalDetailsList = planTemplateSubGoalObj.searchByPlanTemplatePlanGroupID(
        planTemplatePlanGroupKey);

      // Add each sub-goal
      for (int j = 0; j < templateSubGoalDetailsList.dtls.size(); j++) {

        // create planned sub goal details
        final PlannedSubGoalDtls plannedSubGoalDtls = new PlannedSubGoalDtls();

        plannedSubGoalDtls.plannedGoalID = plannedGoalKey.plannedGoalID;
        plannedSubGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
        plannedSubGoalDtls.ownerID = curam.util.transaction.TransactionInfo.getProgramUser();
        plannedSubGoalDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;
        plannedSubGoalDtls.plannedGroupID = plannedGroupDtls.plannedGroupID;

        // Need to retrieve the subgoal id
        // BEGIN, CR00233815, GP
        PlanTemplateAndSubGoalReadDetails planTemplateSubGoalReadDetails = new PlanTemplateAndSubGoalReadDetails();
        // END, CR00233815
        final PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

        planTemplateSubGoalKey.planTemplateSubGoalID = templateSubGoalDetailsList.dtls.item(j).planTemplateSubGoalID;

        // BEGIN, CR00233815, GP
        planTemplateSubGoalReadDetails = planTemplateSubGoalObj.readTemplateSubGoalDetails(
          planTemplateSubGoalKey);
        // END, CR00233815

        plannedSubGoalDtls.subGoalID = planTemplateSubGoalReadDetails.subGoalID;

        // BEGIN, CR00292665, AKr
        plannedSubGoalDtls.createdOn = planTemplateSubGoalObj.readLastWritten(planTemplateSubGoalKey).lastWritten;
        // END, CR00292665

        // insert planned sub goal
        plannedSubGoalObj.insert(plannedSubGoalDtls);

        // BEGIN, CR00228422 MN
        // Search for any child plan items
        PlanItemAndTemplatePlanItemDetailsList planItemAndPlanTemplatePlanItemDetailsList = new PlanItemAndTemplatePlanItemDetailsList();

        planItemAndPlanTemplatePlanItemDetailsList = planTemplatePlanItemObj.searchPlanItemByPlanTemplateSubGoalID(
          planTemplateSubGoalKey);
        // END, CR00228422

        // Add the plan items
        for (int k = 0; k
          < planItemAndPlanTemplatePlanItemDetailsList.dtls.size(); k++) {

          // Read the plan item name and assign
          final PlanItemKey planItemKey = new PlanItemKey();

          planItemKey.planItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).planItemID;
          // BEGIN, CR00235251, TV
          final PlannedItemDetailsStruct createPlannedItemDetailsStruct = new PlannedItemDetailsStruct();

          // END, CR00235251
          createPlannedItemDetailsStruct.plannedItemDtls.name = CodeTable// BEGIN, CR00163098, JC
            .getOneItem(PLANITEMNAME.TABLENAME,
            planItemObj.readName(planItemKey).name,
            TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

          // create planned item details
          createPlannedItemDetailsStruct.plannedItemDtls.expectedOutcomeID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).expectedOutcomeID;

          createPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

          createPlannedItemDetailsStruct.plannedItemDtls.planItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).planItemID;

          createPlannedItemDetailsStruct.plannedItemDtls.expectedStartDate = curam.util.type.Date.getCurrentDate().addDays(
            planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).startDay);

          // BEGIN, CR00000048, PMD
          createPlannedItemDetailsStruct.plannedItemDtls.authorizedUnits = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).authorizedUnits;
          // END, CR00000048

          // BEGIN, CR00000637, PMD
          createPlannedItemDetailsStruct.plannedItemDtls.maximumUnits = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).maximumUnits;
          // END, CR00000637

          int duration = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).duration;

          if (duration > 0) {
            duration = duration - 1;
          }

          createPlannedItemDetailsStruct.plannedItemDtls.expectedEndDate = createPlannedItemDetailsStruct.plannedItemDtls.expectedStartDate.addDays(
            duration);

          createPlannedItemDetailsStruct.plannedItemDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;
          // BEGIN, CR00292665, AKr
          final PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

          planTemplatePlanItemKey.planTemplatePlanItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(k).planTemplatePlanItemID;
          createPlannedItemDetailsStruct.plannedItemDtls.createdOn = planTemplatePlanItemObj.readLastWritten(planTemplatePlanItemKey).lastWritten;
          // END, CR00292665
          // insert planned item
          // call the service layer method
          // BEGIN, CR00235251, TV
          plannedItemObj.createBasicPlanItemDetails(
            createPlannedItemDetailsStruct);
          // END, CR00235251

        }

        // BEGIN, CR00057255, PMD
        // Create sub-goal level milestones
        milestoneTemplateDetailsList = new MilestoneTemplateDetailsList();

        // Get the list of milestones configured at sub-goal level
        milestoneTemplateDetailsList = PlanTemplateMilestoneFactory.newInstance().searchSubGoalLevelMilestones(
          planTemplateSubGoalKey);

        for (int l = 0; l < milestoneTemplateDetailsList.dtls.size(); l++) {

          MilestoneTemplateDetails milestoneTemplateDetails = new MilestoneTemplateDetails();

          milestoneTemplateDetails = milestoneTemplateDetailsList.dtls.item(l);
          milestoneTemplateDetails.linkDtls.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

          // Create the milestone
          addTemplateMilestone(servicePlanDeliveryKey, milestoneTemplateDetails);
        }
        // END, CR00057255
      }
    }
  }

  // END, CR00000082

  // ___________________________________________________________________________
  /**
   * Ensures that plan template key is set.
   *
   * @param key
   * Plan template key
   */
  @Override
  public void validateAddTemplateToServicePlanDetails(PlanTemplateKey key)
    throws AppException, InformationalException {

    // plan template ID must be defined
    if (key.planTemplateKey.planTemplateID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_FV_PLAN_TEMPLATE_ID_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Ensures that the list is not empty.
   *
   * @param list
   * Plan template key list
   */
  @Override
  public void validateTemplateList(PlanTemplateNameAndIDDetailsList list)
    throws AppException, InformationalException {

    // the list of plan templates must not be empty
    if (list.list.dtls.size() == 0) {

      final curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        BPOSERVICEPLANDELIVERY.ERR_FV_TEMPLATE_LIST_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e, curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan ID for the service plan delivery.
   *
   * @param key
   * Service plan delivery key
   *
   * @return Service plan unique ID
   */
  @Override
  public ServicePlanKey readServicePlanID(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanKey servicePlanKey = new ServicePlanKey();

    // ServicePlanDelivery entity
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // read service plan ID
    servicePlanKey.key.servicePlanID = servicePlanDeliveryObj.read(key.key).servicePlanID;

    // return service plan ID
    return servicePlanKey;

  }

  // ___________________________________________________________________________
  /**
   * Reads integrated case menu data.
   *
   * @param key
   * Contains integrated case ID.
   *
   * @return Integrated case menu data for the service plan.
   */
  @Override
  public ServicePlanICMenuData readServicePlanICMenuData(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanICMenuData servicePlanICMenuData = new ServicePlanICMenuData();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // set the key
    caseKey.caseID = key.servicePlanIntegratedCaseKey.caseID;

    // read IC home page name, case reference and type
    servicePlanICMenuData.ICHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(
      caseKey);

    // return menu data
    return servicePlanICMenuData;

  }

  // ___________________________________________________________________________
  /**
   * Checks whether service plan delivery is closed.
   *
   * @param key
   * Contains service plan delivery unique ID.
   */
  @Override
  public void checkIfClosed(ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // read current service plan delivery status
    currentCaseStatusKey.caseID = key.key.caseID;
    // BEGIN, CR00224271, ZV
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    if (!caseStatusDtls.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_NO_CLOSURE_DETAILS_FOUND),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Closes service plan delivery.
   *
   * @param details
   * Contains service plan delivery unique ID, closing reason code and
   * comments.
   */
  @Override
  public void close(ServicePlanDeliveryKey key,
    ServicePlanDeliveryClosureDetails details, boolean isSingleSPContext)
    throws AppException, InformationalException {

    // END, CR00161962
    // CaseHeader manipulation variables
    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    // BEGIN, CR00103023, CW
    // CloseCase manipulation variables
    final curam.core.intf.CloseCase closeCaseObj = curam.core.fact.CloseCaseFactory.newInstance();
    // BEGIN, CR00220971, ZV
    final UpdateCaseStatusReasonEndKey1 updateCaseStatusReasonEndKey = new UpdateCaseStatusReasonEndKey1();
    // END, CR00220971
    // END, CR00103023

    // Case Note manipulation variables
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();
    final curam.core.sl.struct.CaseNoteDetails caseNoteDetails = new curam.core.sl.struct.CaseNoteDetails();

    // UniqueID business object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // Close case manipulation variables
    final curam.core.intf.CaseClosure caseClosureObj = curam.core.fact.CaseClosureFactory.newInstance();
    final curam.core.struct.CaseClosureDtls caseClosureDtls = new curam.core.struct.CaseClosureDtls();

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final curam.core.struct.CaseEventDtls caseEventDtls = new curam.core.struct.CaseEventDtls();

    // Maintain Case business object
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    // User variables
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    curam.core.struct.SystemUserDtls currentSystemUserDtls;

    // BEGIN, CR00161962, KY
    // validate closing details
    // BEGIN, CR00234272, TV
    validateCloseInfo(key, details, isSingleSPContext);
    // END, CR00234272
    // END, CR00161962
    // BEGIN, CR00103023, CW

    // Update the Case Status and Case Header details to closed
    updateCaseStatusReasonEndKey.statusCode = curam.codetable.CASESTATUS.CLOSED;
    updateCaseStatusReasonEndKey.caseID = key.key.caseID;
    updateCaseStatusReasonEndKey.reasonCode = details.spClosureNoteReasonDateDetails.reasonCode;
    updateCaseStatusReasonEndKey.endDate = curam.util.type.Date.getCurrentDate();

    // Call CloseCase to update status and end date on case header record,
    // and insert case status record
    // BEGIN, CR00220971, ZV
    closeCaseObj.updateCaseStatus1(updateCaseStatusReasonEndKey);
    // END, CR00220971
    // END, CR00103023

    // fill in case note details
    caseNoteDetails.caseNoteDetails.noteDetails.sensitivityCode = SENSITIVITY.DEFAULTCODE;
    caseNoteDetails.caseNoteDetails.noteDetails.priorityCode = NOTEPRIORITY.DEFAULTCODE;

    // Set the user
    currentSystemUserDtls = systemUserObj.getUserDetails();

    if (details.spClosureNoteReasonDateDetails.notesText != null
      && details.spClosureNoteReasonDateDetails.notesText.length() > 0) {

      caseNoteDetails.caseNoteDetails.noteDetails.notesText = details.spClosureNoteReasonDateDetails.notesText;

    } else {
      // as note text must not be empty it must be created from predefined
      // text

      // read case details
      caseIDKey.caseID = key.key.caseID;
      final curam.core.struct.CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);

      // create note text
      final AppException e = new AppException(
        curam.message.BPOCLOSECASE.INF_CLOSECASE_CLOSED_SUBJECT);

      e.arg(caseReferenceProductNameConcernRoleName.caseReference);

      // read service plan type
      final curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = readParticipantTypeAndReferenceDetails(
        key);

      // add service plan type
      e.arg(
        curam.util.type.CodeTable.getOneItemForUserLocale(
          SERVICEPLANTYPE.TABLENAME,
          spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType));
      e.arg(caseReferenceProductNameConcernRoleName.concernRoleName);
      e.arg(currentSystemUserDtls.userName);

      // BEGIN, CR00163659, CL
      // assign note text to note details
      caseNoteDetails.caseNoteDetails.noteDetails.notesText = e.getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00163659
    }

    caseNoteDetails.caseNoteDetails.caseNoteDetails.caseID = key.key.caseID;

    // insert case note
    caseNoteObj.insert(caseNoteDetails);

    // assign values to closure record (case closure)
    caseClosureDtls.caseID = key.key.caseID;
    caseClosureDtls.closureDate = curam.util.type.Date.getCurrentDate();
    caseClosureDtls.reasonCode = details.spClosureNoteReasonDateDetails.reasonCode;
    caseClosureDtls.caseClosureID = uniqueIDObj.getNextID();
    caseClosureDtls.notesID = caseNoteDetails.caseNoteDetails.caseNoteDetails.caseNoteID;
    caseClosureDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // save CaseClosure to database
    caseClosureObj.insert(caseClosureDtls);

    // assign values to closure record (case event)
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = key.key.caseID;
    caseEventDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.endDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.relatedID = caseClosureDtls.caseClosureID;
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.DEFAULTCODE;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = curam.codetable.CASEEVENTTYPE.PLANCLOSED;

    // save CaseEvent to database
    caseEventObj.insert(caseEventDtls);

    // notify owner
    notifyOwnerOfClosure(key);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CLOSEPLAN;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = key.key.caseID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan ID and concern role ID of the service plan delivery
   * primary client.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return List of service plan versions.
   */
  @Override
  public ServicePlanAndParticipantDetails readServicePlanIDAndConcernRoleID(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = new ServicePlanAndParticipantDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // set case header key
    caseHeaderKey.caseID = key.key.caseID;

    // read participant role for the service plan delivery case
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // assign it to return struct
    servicePlanAndParticipantDetails.concernRoleID = readParticipantRoleIDDetails.concernRoleID;

    // set service plan delivery key
    servicePlanDeliveryKey.caseID = key.key.caseID;

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    // assign service plan ID to return struct
    servicePlanAndParticipantDetails.servicePlanID = servicePlanKey.servicePlanID;

    return servicePlanAndParticipantDetails;
  }

  // BEGIN, CR00234272, TV
  /**
   * Validates service plan delivery closing.
   *
   * @param key
   * Contains service plan delivery unique ID
   * @param details
   * Contains closing reason code.
   *
   * @deprecated Since Curam v6, replaced with {@link validateCloseInfo}.
   * Reason:- As per the codeLine policy, we should not change the
   * the parameter of the method. So the new input boolean
   * parameter 'isSingleSPContext' is added in validateCloseInfo()
   * method along with 'ServicePlanDeliveryKey' and
   * 'ServicePlanDeliveryClosureDetails' of validateCloseDetails()
   * See release note <CR00234272>
   */
  @Override
  @Deprecated
  public void validateCloseDetails(ServicePlanDeliveryKey key,
    ServicePlanDeliveryClosureDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // PlannedGoal manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey plannedGoalCaseIDKey = new curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey();
    curam.serviceplans.sl.entity.struct.ReadOutcomeAchievedDetails readOutcomeAchievedDetails;

    // reason code must be specified
    if (details.spClosureNoteReasonDateDetails.reasonCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_CLOSURE_REASON_CODE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CLOSE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read current status
    currentCaseStatusKey.caseID = key.key.caseID;
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID(
      currentCaseStatusKey);

    // service plan delivery must not be closed
    if (caseStatusDtls.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_SERVICE_PLAN_ALREADY_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // if service plan delivery is active then an outcome must be
    // specified for the service plan goal
    if (caseStatusDtls.statusCode.equals(CASESTATUS.ACTIVE)) {

      plannedGoalCaseIDKey.caseID = key.key.caseID;

      // read outcome achieved details
      readOutcomeAchievedDetails = plannedGoalObj.readOutcomeAchievedByCaseID(
        plannedGoalCaseIDKey);

      if (readOutcomeAchievedDetails != null
        && readOutcomeAchievedDetails.outcomeAchieved.length() == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSERVICEPLANDELIVERY.ERR_GOAL_OUTCOME_NOT_SET),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }

    }
  }

  // END, CR00234272

  /**
   * Reads service plan delivery closure details for view.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return Service plan delivery closure details
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_VIEW_CLOSURE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to view
   * service plan closure details.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanDeliveryClosureDetails viewClosureDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // to be returned
    final ServicePlanDeliveryClosureDetails servicePlanDeliveryClosureDetails = new ServicePlanDeliveryClosureDetails();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = // BEGIN,
      // HARP
      // 49583,
      // POH
      ServicePlanSecurity.kReadSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_CLOSURE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read closure details
    servicePlanDeliveryClosureDetails.spClosureNoteReasonDateDetails = servicePlanDeliveryObj.readClosureReasonDateAndComments(
      key.key);

    return servicePlanDeliveryClosureDetails;

  }

  /**
   * Lists service plan delivery versions.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return List of service plan versions.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_LIST_VERSIONS_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanDeliveryVersions listVersions(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // to be returned
    final ServicePlanDeliveryVersions servicePlanDeliveryVersions = new ServicePlanDeliveryVersions();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // Case Relationship manipulation variables
    final curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();
    final curam.core.struct.CaseIDAndReasonCodeKey caseIDAndReasonCodeKey = new curam.core.struct.CaseIDAndReasonCodeKey();
    curam.core.struct.RelCaseIDReferenceAndDateCreatedDetails relCaseIDReferenceAndDateCreatedDetails = null;

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;

    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_LIST_VERSIONS_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    caseIDAndReasonCodeKey.caseID = key.key.caseID;
    caseIDAndReasonCodeKey.reasonCode = CASERELATIONSHIPREASONCODE.CLONEDPLAN;

    boolean relatedCaseFound = true;

    // search for all related cases
    while (relatedCaseFound) {

      try {
        relCaseIDReferenceAndDateCreatedDetails = caseRelationshipObj.readRelCaseIDReferenceAndDateCreatedByCaseIDAndReasonCode(
          caseIDAndReasonCodeKey);
      } catch (final RecordNotFoundException e) {
        relatedCaseFound = false;
      }

      if (relatedCaseFound) {
        // add the related case to the list
        servicePlanDeliveryVersions.relCaseIDReferenceAndDateCreatedDetails.addRef(
          relCaseIDReferenceAndDateCreatedDetails);

        // set key for the next search
        caseIDAndReasonCodeKey.caseID = relCaseIDReferenceAndDateCreatedDetails.relatedCaseID;
      }

    }

    int i;
    boolean relatedCaseAlreadyInList;

    caseIDAndReasonCodeKey.caseID = key.key.caseID;
    relatedCaseFound = true;

    // search for all relationships where the case is related case
    while (relatedCaseFound) {

      try {
        relCaseIDReferenceAndDateCreatedDetails = caseRelationshipObj.readCaseIDReferenceAndDateCreatedByRelCaseIDAndReasonCode(
          caseIDAndReasonCodeKey);
      } catch (final RecordNotFoundException e) {
        relatedCaseFound = false;
      }

      if (relatedCaseFound) {

        if (relCaseIDReferenceAndDateCreatedDetails.relatedCaseID
          != key.key.caseID) {

          // check that the record is not already in the list
          relatedCaseAlreadyInList = false;

          for (i = 0; i
            < servicePlanDeliveryVersions.relCaseIDReferenceAndDateCreatedDetails.size(); i++) {

            // BEGIN, CR00091205, CM
            if (servicePlanDeliveryVersions.relCaseIDReferenceAndDateCreatedDetails.item(i).caseReference.equals(
              relCaseIDReferenceAndDateCreatedDetails.caseReference)) {
              // END, CR00091205
              relatedCaseAlreadyInList = true;
              break;
            }
          }

          // if the record is not already in the list, add it
          if (!relatedCaseAlreadyInList) {
            // add the related case to the list
            servicePlanDeliveryVersions.relCaseIDReferenceAndDateCreatedDetails.addRef(
              relCaseIDReferenceAndDateCreatedDetails);
          }
        }

        // set key for the next search
        caseIDAndReasonCodeKey.caseID = relCaseIDReferenceAndDateCreatedDetails.relatedCaseID;
      }

    }

    // return list of plan versions
    return servicePlanDeliveryVersions;
  }

  // ___________________________________________________________________________
  /**
   * Clones service plan delivery.
   *
   * @param key
   * Contains unique ID of the service plan delivery to be cloned
   *
   * @return Unique ID of the new created service plan delivery
   */
  @Override
  public ServicePlanDeliveryKey clone(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Planned Goal business object
    final curam.serviceplans.sl.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.fact.PlannedGoalFactory.newInstance();

    // validate service plan delivery to be cloned
    validateClone(key);

    // Baseline manipulation variables
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();
    final curam.serviceplans.sl.struct.CreateBaselineDetails createBaselineDetails = new curam.serviceplans.sl.struct.CreateBaselineDetails();

    // create a Plan Cloned baseline
    createBaselineDetails.caseID = key.key.caseID;
    createBaselineDetails.typeCode = BASELINETYPE.CLONING;
    baselineObj.create(createBaselineDetails);

    // clone service plan delivery details
    final ServicePlanDeliveryKey servicePlanDeliveryKey = cloneServicePlanDeliveryDetails(
      key);

    // clone planned goal
    plannedGoalObj.clone(key, servicePlanDeliveryKey);

    // create closure details for original plan
    final ServicePlanDeliveryClosureDetails servicePlanDeliveryClosureDetails = new ServicePlanDeliveryClosureDetails();

    servicePlanDeliveryClosureDetails.spClosureNoteReasonDateDetails.closureDate = curam.util.type.Date.getCurrentDate();
    servicePlanDeliveryClosureDetails.spClosureNoteReasonDateDetails.reasonCode = CASECLOSEREASON.PLANCLONED;

    // BEGIN, CR00108566, MC

    final boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);
    final boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
      closePreviousPlan_default);

    // CaseStatus manipulation variables
    // read current status

    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

    final CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = key.key.caseID;
    // BEGIN, CR00224271, ZV
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    if (closePreviousPlan
      && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
      // close original service plan delivery
      // BEGIN, CR00161962, KY
      close(key, servicePlanDeliveryClosureDetails, true);
      // END, CR00161962
    }

    // END, CR00108566

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATEPLAN;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = key.key.caseID;
    curam.util.events.impl.EventService.raiseEvent(event);

    // BEGIN CR00108818, GBA
    // Log Transaction Details
    if (key.key != null && key.key.caseID != 0) {

      // CaseHeader manipulation variable to get IntegratedCaseID
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      // Set the case header key
      caseKey.caseID = key.key.caseID;

      // ServicePlanDelivery manipulation variables
      final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
      final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servPlanDelKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

      servPlanDelKey.caseID = key.key.caseID;
      final CodeTableItemIdentifier SPTypeCodeIdentifier = new CodeTableItemIdentifier(
        SERVICEPLANTYPE.TABLENAME,
        servicePlanDeliveryObj.readServicePlanType(servPlanDelKey).servicePlanType);

      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.SERVICEPLAN_CLONED).arg(
        SPTypeCodeIdentifier);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.SERVICEPLAN_CLONED, description,
        caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID,
        CuramConst.kDefaultRelatedID);
    }
    // END CR00108818

    // BEGIN, CR00161962, KY
    // Add the new cloned plan into the service plan delivery group (if
    // exists)
    final SPGDeliveryLink spgDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.key.caseID;

    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();

    final SPGDeliveryKey spgDeliveryKey = spgDeliveryLinkObj.readServicePlanGroupDeliveryIdByCaseId(
      notFoundIndicator, caseHeaderKey);

    if (notFoundIndicator.isNotFound() == false) {
      final SPGDeliveryLinkDtls spgDeliveryLinkDtls = new SPGDeliveryLinkDtls();

      spgDeliveryLinkDtls.servicePlanGroupDeliveryLinkId = UniqueIDFactory.newInstance().getNextID();
      spgDeliveryLinkDtls.servicePlanGroupDeliveryId = spgDeliveryKey.servicePlanGroupDeliveryId;
      spgDeliveryLinkDtls.caseID = servicePlanDeliveryKey.key.caseID;

      spgDeliveryLinkObj.insert(spgDeliveryLinkDtls);
    }
    // END, CR00161962
    // return unique ID of the new created service plan delivery
    return servicePlanDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * Clones service plan delivery participants.
   *
   * @param originalPlanKey
   * Contains unique ID of the service plan delivery being cloned
   * @param newCreatedPlanKey
   * Contains unique ID of the service plan delivery created as a
   * result of cloning
   */
  @Override
  public void cloneParticipants(ServicePlanDeliveryKey originalPlanKey,
    ServicePlanDeliveryKey newCreatedPlanKey) throws AppException,
      InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDStatusKey caseParticipantRole_eoCaseIDStatusKey = new curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDStatusKey();
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    curam.core.sl.entity.struct.CaseParticipantRoleDtlsList caseParticipantRoleDtlsList;
    final curam.core.sl.entity.struct.CaseParticipantRoleDtls caseParticipantRoleDtls = new curam.core.sl.entity.struct.CaseParticipantRoleDtls();

    // populate search key
    caseParticipantRole_eoCaseIDStatusKey.caseID = originalPlanKey.key.caseID;
    caseParticipantRole_eoCaseIDStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // search case participants
    caseParticipantRoleDtlsList = caseParticipantRoleObj.searchByCaseIDStatus(
      caseParticipantRole_eoCaseIDStatusKey);

    caseParticipantRoleDtls.caseID = newCreatedPlanKey.key.caseID;
    caseParticipantRoleDtls.fromDate = curam.util.type.Date.getCurrentDate();
    caseParticipantRoleDtls.recordStatus = RECORDSTATUS.NORMAL;

    for (int i = 0; i < caseParticipantRoleDtlsList.dtls.size(); i++) {

      caseParticipantRoleDtls.participantRoleID = caseParticipantRoleDtlsList.dtls.item(i).participantRoleID;
      caseParticipantRoleDtls.typeCode = caseParticipantRoleDtlsList.dtls.item(i).typeCode;

      // insert case participant role
      caseParticipantRoleObj.insert(caseParticipantRoleDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Clones service plan delivery details.
   *
   * @param key
   * Contains unique ID of the service plan delivery to be cloned
   *
   * @return Unique ID of the new created service plan delivery
   */
  @Override
  public ServicePlanDeliveryKey cloneServicePlanDeliveryDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    curam.core.struct.CaseHeaderDtls caseHeaderDtls;
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // Case Relationship manipulation variables
    final curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();
    final curam.core.struct.CaseRelationshipDtls caseRelationshipDtls = new curam.core.struct.CaseRelationshipDtls();

    // UniqueID business object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls servicePlanDeliveryDtls = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CaseStatusDtls caseStatusDtls = new curam.core.struct.CaseStatusDtls();

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final curam.core.struct.CaseEventDtls caseEventDtls = new curam.core.struct.CaseEventDtls();

    // BEGIN, CR00060051, PMD
    // CaseOrgObjectLink manipulation variables
    final OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();

    // END, CR00060051

    // read case header details
    caseHeaderKey.caseID = key.key.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // BEGIN, CR00050587, CSH
    // update case header details
    caseHeaderDtls.statusCode = CASESTATUS.OPEN;
    // END, CR00050587
    caseHeaderDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.caseReference = curam.core.sl.fact.CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();

    // insert case header details
    caseHeaderObj.insert(caseHeaderDtls);

    // to be returned - caseID of the new created case
    servicePlanDeliveryKey.key.caseID = caseHeaderDtls.caseID;

    // create case relationship details
    caseRelationshipDtls.caseID = servicePlanDeliveryKey.key.caseID;
    caseRelationshipDtls.relatedCaseID = key.key.caseID;
    caseRelationshipDtls.reasonCode = CASERELATIONSHIPREASONCODE.CLONEDPLAN;
    caseRelationshipDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseRelationshipDtls.statusCode = RECORDSTATUS.NORMAL;
    caseRelationshipDtls.typeCode = CASERELATIONSHIPTYPECODE.PLANPLAN;
    caseRelationshipDtls.caseRelationshipID = uniqueIDObj.getNextID();

    // insert case relationship
    caseRelationshipObj.insert(caseRelationshipDtls);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      key.key);

    // create ServicePlanDelivery details
    servicePlanDeliveryDtls.caseID = caseHeaderDtls.caseID;
    servicePlanDeliveryDtls.servicePlanID = servicePlanKey.servicePlanID;
    servicePlanDeliveryDtls.createdBy = curam.util.transaction.TransactionInfo.getProgramUser();

    // insert new ServicePlanDelivery record
    servicePlanDeliveryObj.insert(servicePlanDeliveryDtls);

    final ServicePlanDeliveryKey newCaseIDKey = new ServicePlanDeliveryKey();

    newCaseIDKey.key.caseID = servicePlanDeliveryDtls.caseID;

    // notify owner
    notifyOwnerOfCloning(key, newCaseIDKey);

    // notify supervisor
    notifySupervisorOfCloning(key, newCaseIDKey);

    // BEGIN, CR00060051, PMD
    // Read the current case owner
    final CaseOwnerDetails currentCaseOwnerDetails = caseUserRoleObj.readOwner(
      caseHeaderKey);

    // Clone the case owner details
    orgObjectLinkDtls.orgObjectReference = currentCaseOwnerDetails.orgObjectReference;
    orgObjectLinkDtls.orgObjectType = currentCaseOwnerDetails.orgObjectType;
    orgObjectLinkDtls.userName = currentCaseOwnerDetails.userName;

    // Set the case header id to be the newly cloned case
    final CaseHeaderKey newCaseHeaderKey = new CaseHeaderKey();

    newCaseHeaderKey.caseID = servicePlanDeliveryDtls.caseID;

    // Create the case owner
    // BEGIN, CR00205190, SS
    // Check if a workflow is configured for this particular case type.
    final curam.serviceplans.sl.intf.ServicePlan serviceplanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();
    final ServicePlanKey serviceplankey = new ServicePlanKey();

    // BEGIN, CR00234425, SS
    serviceplankey.key.servicePlanID = servicePlanKey.servicePlanID;
    // END, CR00234425
    if (CuramConst.gkZero != serviceplankey.key.servicePlanID) {
      // Retrieve the ownershipStrategyName configured for this case type.
      final ReadServicePlanDetails readServicePlanDetails = serviceplanObj.read(
        serviceplankey);

      if (!StringUtil.isNullOrEmpty(
        readServicePlanDetails.plan.ownershipStrategyName)) {
        final CaseKey caseID = new CaseKey();

        caseID.caseID = caseHeaderKey.caseID;
        final OwnershipStrategyDetails ownershipStrategyDetails = new OwnershipStrategyDetails();

        ownershipStrategyDetails.ownershipStrategyName = readServicePlanDetails.plan.ownershipStrategyName;
        caseUserRoleObj.createOwnerBasedOnOwnershipStrategy(caseID,
          ownershipStrategyDetails);
      } else {

        caseUserRoleObj.createOwner(newCaseHeaderKey, orgObjectLinkDtls);
      }
    } else {

      caseUserRoleObj.createOwner(newCaseHeaderKey, orgObjectLinkDtls);
    }
    // END, CR00205190
    // Read current case supervisor
    final UserNameAndFullName currentSupervisorDetails = caseUserRoleObj.readSupervisor(
      caseHeaderKey);

    // BEGIN, CR00081197, CSH
    // If a supervisor is set for the current case
    if (currentSupervisorDetails.userName.length() > 0) {

      // Clone the case supervisor details
      final UserNameKey supervisorUserName = new UserNameKey();

      supervisorUserName.userName = currentSupervisorDetails.userName;

      // Create the case supervisor
      caseUserRoleObj.createSupervisor(newCaseHeaderKey, supervisorUserName);
    }
    // END, CR00081197
    // END, CR00060051

    // clone participants
    cloneParticipants(key, servicePlanDeliveryKey);

    // fill CaseStatus details for new created plan
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.startDate = curam.util.type.Date.getCurrentDate();
    // BEGIN, CR00050587, CSH
    caseStatusDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    // END, CR00050587

    // insert new record to CaseStatus
    caseStatusObj.insert(caseStatusDtls);

    // fill CaseEvent details for new created plan
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = caseHeaderDtls.caseID;
    caseEventDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.endDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.ACTIVE;
    caseEventDtls.eventTypeCode = curam.codetable.CASEEVENTTYPE.PLANOPENED;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // insert new CaseEvent record
    caseEventObj.insert(caseEventDtls);

    // fill CaseEvent details for original plan
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = key.key.caseID;
    caseEventDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.endDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.ACTIVE;
    caseEventDtls.eventTypeCode = curam.codetable.CASEEVENTTYPE.PLANCLONED;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // insert new CaseEvent record
    caseEventObj.insert(caseEventDtls);

    // BEGIN, CR00117949, MC
    final boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);
    final boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
      closePreviousPlan_default);

    if (closePreviousPlan
      && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {

      // BEGIN, CR00117669, MC
      // Clone Attachments associated with the service plan

      final CaseAttachmentLink caseAttachmentLinkObj = CaseAttachmentLinkFactory.newInstance();
      final CaseAttachmentLinkReadmultiKey rmKey = new CaseAttachmentLinkReadmultiKey();

      rmKey.caseID = key.key.caseID;

      final CaseAttachmentLinkDtlsList caseAttachmentLinkDtlsList = caseAttachmentLinkObj.searchByCaseID(
        rmKey);
      final int noOfAttachments = caseAttachmentLinkDtlsList.dtls.size();

      AttachmentDtls attachmentDtls;
      final AttachmentKey attachmentKey = new AttachmentKey();
      long attachmentID = 0;

      for (int i = 0; i < noOfAttachments; i++) {

        attachmentKey.attachmentID = caseAttachmentLinkDtlsList.dtls.item(i).attachmentID;
        attachmentDtls = attachment.read(attachmentKey);

        // BEGIN, CR00155031, MC
        // Set to zero as we need to create a new attachment
        attachmentDtls.attachmentID = CuramConst.gkZero;
        // END, CR00155031

        attachment.insert(attachmentDtls);

        attachmentID = attachmentDtls.attachmentID;

        // set the attachment id to the new attachment id
        caseAttachmentLinkDtlsList.dtls.item(i).caseAttachmentLinkID = uniqueIDObj.getNextID();

        caseAttachmentLinkDtlsList.dtls.item(i).attachmentID = attachmentID;
        caseAttachmentLinkDtlsList.dtls.item(i).caseID = caseHeaderDtls.caseID;
        caseAttachmentLinkObj.insert(caseAttachmentLinkDtlsList.dtls.item(i));

      }

      // Cloning attachments ends here
      // END, CR00117669
    }
    // END, CR00117949

    // return new created service plan delivery identifier
    return servicePlanDeliveryKey;

  }

  /**
   * Modifies service plan delivery closure details.
   *
   * @param key
   * Contains service plan delivery unique ID.
   * @param details
   * Contains service plan delivery details for modify.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_CLOSURE_SECURITY_CHECK_FAILED} -
   * if the user does not have appropriate privileges to modify this
   * service plan details.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_CLOSURE_REASON_CODE_EMPTY} - if
   * the close reason code is not specified.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyClosureDetails(ServicePlanDeliveryKey key,
    ModifyServicePlanClosureDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // Close case manipulation variables
    final curam.core.intf.CaseClosure caseClosureObj = curam.core.fact.CaseClosureFactory.newInstance();
    final curam.core.struct.CaseClosureKey caseClosureKey = new curam.core.struct.CaseClosureKey();
    final curam.core.struct.ModifyReasonCodeDetails modifyReasonCodeDetails = new curam.core.struct.ModifyReasonCodeDetails();

    // Case Note manipulation variables
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();
    final curam.core.sl.struct.ModifyCaseNoteDetails1 modifyCaseNoteDetails = new curam.core.sl.struct.ModifyCaseNoteDetails1();
    curam.core.sl.struct.ReadCaseNoteDetails1 readCaseNoteDetails;
    final curam.core.sl.struct.CaseNoteKey caseNoteKey = new curam.core.sl.struct.CaseNoteKey();

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_CLOSURE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // reason code must be specified
    if (details.servicePlanClosureDetails.reasonCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_CLOSURE_REASON_CODE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // set details for case closure modifying
    caseClosureKey.caseClosureID = details.servicePlanClosureDetails.caseClosureID;
    modifyReasonCodeDetails.reasonCode = details.servicePlanClosureDetails.reasonCode;
    modifyReasonCodeDetails.versionNo = details.servicePlanClosureDetails.caseClosureVersionNo;

    // modify closure reason code
    caseClosureObj.modifyReasonCode(caseClosureKey, modifyReasonCodeDetails);

    // read CaseNotes from database
    caseNoteKey.key.caseNoteID = details.servicePlanClosureDetails.caseNoteID;
    readCaseNoteDetails = caseNoteObj.read1(caseNoteKey);

    // create note details for modify
    modifyCaseNoteDetails.key.caseNoteID = details.servicePlanClosureDetails.caseNoteID;
    modifyCaseNoteDetails.caseNoteDetails.caseNoteDetails.assign(
      readCaseNoteDetails.noteDetails);
    modifyCaseNoteDetails.caseNoteDetails.modifyNoteDetails.assign(
      readCaseNoteDetails.noteDetails);

    // BEGIN, CR00279583, IBM
    modifyCaseNoteDetails.caseNoteDetails.modifyNoteDetails.notesText = details.servicePlanClosureDetails.notesText;

    if (StringUtil.isNullOrEmpty(details.servicePlanClosureDetails.notesText)) {
      final CaseIDKey caseIDKey = new CaseIDKey();
      final MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
      final SystemUser systemUserObj = SystemUserFactory.newInstance();
      final SystemUserDtls currentSystemUserDtls = systemUserObj.getUserDetails();

      caseIDKey.caseID = key.key.caseID;
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);

      final AppException e = new AppException(
        BPOSERVICEPLANDELIVERY.INF_SERVICEPLAN_UPDATE_CLOSURE_DETAILS);

      e.arg(caseReferenceProductNameConcernRoleName.caseReference);

      final ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = readParticipantTypeAndReferenceDetails(
        key);

      e.arg(
        curam.util.type.CodeTable.getOneItemForUserLocale(
          SERVICEPLANTYPE.TABLENAME,
          spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType));
      e.arg(caseReferenceProductNameConcernRoleName.concernRoleName);
      e.arg(currentSystemUserDtls.userName);

      modifyCaseNoteDetails.caseNoteDetails.modifyNoteDetails.notesText = e.getMessage(
        ProgramLocale.getDefaultServerLocale());
    }
    // END, CR00279583

    // save changed case notes to the database
    caseNoteObj.modify1(modifyCaseNoteDetails);

  }

  // ___________________________________________________________________________
  /**
   * Sends a notification about service plan delivery cloning to the owner.
   *
   * @param clonedCaseIDKey
   * Contains unique ID of the cloned service plan delivery.
   * @param newCaseIDKey
   * Contains unique ID of new created service plan delivery.
   */
  @Override
  public void notifyOwnerOfCloning(ServicePlanDeliveryKey clonedCaseIDKey,
    ServicePlanDeliveryKey newCaseIDKey) throws AppException,
      InformationalException {

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Notification variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseSearchKey caseSearchKey = new curam.core.struct.CaseSearchKey();
    curam.core.struct.CaseReference caseReference;

    // BEGIN, CR00074750, CM
    // check the environment variable
    String genSPDCloneTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENSPDCLONETICKET);

    if (genSPDCloneTicket == null) {

      genSPDCloneTicket = EnvVars.ENV_GENSPDCLONETICKET_DEFAULT;
    }

    if (genSPDCloneTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {

      return;
    }
    // END, CR00074750

    // BEGIN, CR00060051, PMD
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Set the case header key to be
    // that of the cloned case
    caseHeaderKey.caseID = clonedCaseIDKey.key.caseID;

    // Set the user name key to be the current user
    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Check if the user is the owner of the case or part of
    // any organization object that owns the case

    // only create notification if current user is not a service plan
    // delivery owner
    if (!caseUserRoleObj.isUserCaseOwner(userNameKey, caseHeaderKey).ownerInd) {

      final curam.core.facade.struct.StandardManualTaskDtls standardManualTaskDtls = new curam.core.facade.struct.StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = clonedCaseIDKey.key.caseID;

      final AppException reasonText = new AppException(
        BPOSERVICEPLANDELIVERY.INF_CLONE_REASON);

      reasonText.arg(curam.util.type.Date.getCurrentDate());

      // read new service plan reference
      caseSearchKey.caseID = newCaseIDKey.key.caseID;
      caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);
      reasonText.arg(caseReference.caseReference);

      // read original service plan reference
      caseSearchKey.caseID = clonedCaseIDKey.key.caseID;
      caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);
      reasonText.arg(caseReference.caseReference);

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.comments = reasonText.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163659
      standardManualTaskDtls.dtls.taskDtls.subject = BPOSERVICEPLANDELIVERY.INF_CLONE_SUBJECT// BEGIN, CR00163471, JC
        .getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = kServicePlanStandardTask;

      // BEGIN, CR00069238, MG
      standardManualTaskDtls.dtls.concerningDtls.caseID = clonedCaseIDKey.key.caseID;

      // create notification
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00069238
    }
    // END, CR00060051
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification about service plan delivery closing to the owner.
   *
   * @param key
   * Contains service plan delivery unique ID.
   */
  @Override
  public void notifyOwnerOfClosure(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Case details manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final curam.core.struct.ConcernRoleKey concernRoleKeyObj = new curam.core.struct.ConcernRoleKey();

    // Notification variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // BEGIN, CR00074750, CM
    // check the environment variable
    String genSPDCloseTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENSPDCLOSETICKET);

    if (genSPDCloseTicket == null) {

      genSPDCloseTicket = EnvVars.ENV_GENSPDCLOSETICKET_DEFAULT;
    }

    if (genSPDCloseTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {

      return;
    }
    // END, CR00074750
    // BEGIN, CR00060051, PMD
    // Set the case header key
    caseHeaderKey.caseID = key.key.caseID;

    // Set the user name key to be the current user
    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Check if the user is the owner of the case or part of
    // any organization object that owns the case

    // only create notification if current user is not a service plan
    // delivery owner
    if (!caseUserRoleObj.isUserCaseOwner(userNameKey, caseHeaderKey).ownerInd) {

      final curam.core.facade.struct.StandardManualTaskDtls standardManualTaskDtls = new curam.core.facade.struct.StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.key.caseID;

      final AppException reasonText = new AppException(
        BPOSERVICEPLANDELIVERY.INF_CLOSE_REASON);

      final AppException subjectText = new AppException(
        BPOSERVICEPLANDELIVERY.INF_CLOSE_SUBJECT);

      // set caseID & concerRoleID
      caseHeaderKey.caseID = key.key.caseID;
      concernRoleKeyObj.concernRoleID = caseHeaderObj.read(caseHeaderKey).concernRoleID;

      // assign values to message placeholders
      reasonText.arg(curam.util.type.Date.getCurrentDate());

      // BEGIN, CR00021533, CMB
      // BEGIN, HARP 65191, KN
      reasonText.arg(curam.util.transaction.TransactionInfo.getProgramUser());
      // END, HARP 65191
      // END, CR00021533

      reasonText.arg(caseHeaderObj.read(caseHeaderKey).caseReference);
      reasonText.arg(concernRoleObj.read(concernRoleKeyObj).concernRoleName);

      subjectText.arg(caseHeaderObj.read(caseHeaderKey).caseReference);

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.comments = reasonText.getMessage(
        TransactionInfo.getProgramLocale());
      standardManualTaskDtls.dtls.taskDtls.subject = subjectText.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163659
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = kServicePlanStandardTask;

      standardManualTaskDtls.dtls.concerningDtls.caseID = key.key.caseID;

      // Create notification
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
    }
    // END, CR00060051
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification about service plan delivery cloning to the supervisor.
   *
   * @param clonedCaseIDKey
   * Contains unique ID of the cloned service plan delivery.
   * @param newCaseIDKey
   * Contains unique ID of new created service plan delivery.
   */
  @Override
  public void notifySupervisorOfCloning(
    ServicePlanDeliveryKey clonedCaseIDKey,
    ServicePlanDeliveryKey newCaseIDKey) throws AppException,
      InformationalException {

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Notification variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseSearchKey caseSearchKey = new curam.core.struct.CaseSearchKey();
    curam.core.struct.CaseReference caseReference;

    // BEGIN, CR00060051, PMD
    // Set the case header key to be that of the
    // cloned service plan
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = clonedCaseIDKey.key.caseID;

    // Read the case supervisor
    final UserNameAndFullName supervisorUserNameAndFullName = caseUserRoleObj.readSupervisor(
      caseHeaderKey);

    // only create notification if current user is not
    // a service plan delivery supervisor
    if (!supervisorUserNameAndFullName.userName.equals(
      curam.util.transaction.TransactionInfo.getProgramUser())) {

      final curam.core.facade.struct.StandardManualTaskDtls standardManualTaskDtls = new curam.core.facade.struct.StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = clonedCaseIDKey.key.caseID;

      final AppException reasonText = new AppException(
        BPOSERVICEPLANDELIVERY.INF_CLONE_REASON);

      reasonText.arg(curam.util.type.Date.getCurrentDate());

      // read new service plan reference
      caseSearchKey.caseID = newCaseIDKey.key.caseID;
      caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);
      reasonText.arg(caseReference.caseReference);

      // read original service plan reference
      caseSearchKey.caseID = clonedCaseIDKey.key.caseID;
      caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);
      reasonText.arg(caseReference.caseReference);

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.comments = reasonText.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163659
      standardManualTaskDtls.dtls.taskDtls.subject = BPOSERVICEPLANDELIVERY.INF_CLONE_SUBJECT// BEGIN, CR00163471, JC
        .getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = kServicePlanStandardTask;
      standardManualTaskDtls.dtls.assignDtls.assignmentID = supervisorUserNameAndFullName.userName;
      standardManualTaskDtls.dtls.concerningDtls.caseID = clonedCaseIDKey.key.caseID;

      // Create notification
      notificationObj.createWorkAllocationNotification(standardManualTaskDtls);

    }
    // END, CR00060051
  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery closure details for modify.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return Service plan delivery details
   */
  @Override
  public ModifyServicePlanClosureDetails readClosureDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return details
    final ModifyServicePlanClosureDetails modifyServicePlanClosureDetails = new ModifyServicePlanClosureDetails();

    // ServicePlanDelivery entity
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // service plan delivery must be closed
    checkIfClosed(key);

    // read closure details
    modifyServicePlanClosureDetails.servicePlanClosureDetails = servicePlanDeliveryObj.readClosureDetails(
      key.key);

    return modifyServicePlanClosureDetails;

  }

  /**
   * Checks that service plan delivery can be cloned.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_CLONE_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to clone
   * this service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_CLONE_STATUS_FAILED} - if a
   * service plan must be Active or Closed before it can be cloned.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_CLONE_CONTRACT_UNACCEPTED_FAILED} - if a
   * service plan cannot be cloned until a contract has been
   * accepted by the client in respect of the plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateClone(ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // Service Plan Contract manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = ServicePlanContractFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryAndContractStatusKey servicePlanDeliveryAndContractStatusKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryAndContractStatusKey();

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;

    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCloneSecurityCheck;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CLONE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN CR00117416 ,MC

    // a service plan must be active or closed
    // read current case status
    currentCaseStatusKey.caseID = key.key.caseID;
    // BEGIN, CR00224271, ZV
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    if (!(caseStatusDtls.statusCode.equals(CASESTATUS.ACTIVE)
      || caseStatusDtls.statusCode.equals(CASESTATUS.CLOSED))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_CLONE_STATUS_FAILED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
    // END CR00117416

    // count accepted contracts
    servicePlanDeliveryAndContractStatusKey.caseID = key.key.caseID;
    servicePlanDeliveryAndContractStatusKey.contractStatus = SERVICEPLANCONTRACTSTATUS.ACCEPTED;

    final RecordCount recordCount = servicePlanContractObj.countByCaseIDAndStatus(
      servicePlanDeliveryAndContractStatusKey);

    if (recordCount.count == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CLONE_CONTRACT_UNACCEPTED_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Lists all integrated case participants, except for service plan delivery
   * primary client.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of integrated case participants.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MAINTAIN_NOMREP_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to add a
   * nominated representative.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ICMemberDetailsList getAvailableICMembers(ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    // return structure and details
    final ICMemberDetailsList icMemberDetailsList = new ICMemberDetailsList();
    ICMemberDetails icMemberDetails;

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new curam.core.sl.struct.ViewCaseParticipantRole_boKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // read concern role ID of the plan participant
    caseHeaderKey.caseID = key.key.caseID;
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      key.key);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      throw new AppException(
        BPOSERVICEPLANDELIVERY.ERR_MAINTAIN_NOMREP_SECURITY_CHECK_FAILED);
    }

    // set the key
    caseKey.caseID = key.key.caseID;

    // find out integrated case ID
    viewCaseParticipantRole_boKey.dtls.caseID = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;

    // read the list of case participant roles
    final curam.core.sl.struct.ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.listCaseParticipantsForIC(
      viewCaseParticipantRole_boKey);

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {
      // do not add plan participant to the list
      if (viewCaseParticipantRoleDetailsList.dtls.item(i).participantRoleID
        != readParticipantRoleIDDetails.concernRoleID) {

        icMemberDetails = new ICMemberDetails();
        icMemberDetails.assign(viewCaseParticipantRoleDetailsList.dtls.item(i));
        icMemberDetailsList.icMemberDetails.addRef(icMemberDetails);
      }
    }

    // return integrated case member list
    return icMemberDetailsList;
  }

  // BEGIN CR00109001, GBA
  /**
   * Lists all integrated case members.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of integrated case participants.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MAINTAIN_NOMREP_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to add a
   * nominated representative.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ICMemberDetailsList getIntegratedCaseMembers(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return structure and details
    final ICMemberDetailsList icMemberDetailsList = new ICMemberDetailsList();
    ICMemberDetails icMemberDetails;

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new curam.core.sl.struct.ViewCaseParticipantRole_boKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // read concern role ID of the plan participant
    caseHeaderKey.caseID = key.key.caseID;
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      key.key);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      throw new AppException(
        BPOSERVICEPLANDELIVERY.ERR_MAINTAIN_NOMREP_SECURITY_CHECK_FAILED);
    }

    // set the key
    caseKey.caseID = key.key.caseID;

    // find out integrated case ID
    viewCaseParticipantRole_boKey.dtls.caseID = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;

    // read the list of active case members
    // BEGIN CR00108989, GBA
    viewCaseParticipantRole_boKey.showOnlyActive = true;

    final curam.core.sl.struct.ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseMemberList(
      viewCaseParticipantRole_boKey);

    // END CR00108989

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {
      icMemberDetails = new ICMemberDetails();
      icMemberDetails.assign(viewCaseParticipantRoleDetailsList.dtls.item(i));
      icMemberDetailsList.icMemberDetails.addRef(icMemberDetails);
    }

    // return integrated case member list
    return icMemberDetailsList;
  }

  // END CR00109001

  /**
   * Lists all the nominated representative records for a service plan delivery.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of nominated representative records for a service plan.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_LIST_PLAN_PARTICIPANTS_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanParticipantDetailsList listNominatedRepresentative(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // ServicePlanDelivery entity and key
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanParticipantTypeKey servicePlanParticipantTypeKey = new curam.serviceplans.sl.entity.struct.ServicePlanParticipantTypeKey();

    // return structure
    final ServicePlanParticipantDetailsList servicePlanParticipantDetailsList = new ServicePlanParticipantDetailsList();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // read concern role ID of the plan participant
    caseHeaderKey.caseID = key.key.caseID;
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      key.key);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_LIST_PLAN_PARTICIPANTS_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // set the key
    servicePlanParticipantTypeKey.caseID = key.key.caseID;
    servicePlanParticipantTypeKey.typeCode = CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE;

    // search for nominated representatives
    servicePlanParticipantDetailsList.servicePlanParticipantDetailsList = servicePlanDeliveryObj.searchParticipantsByType(
      servicePlanParticipantTypeKey);

    // return the list
    return servicePlanParticipantDetailsList;

  }

  /**
   * Returns a list of all plan participants for a particular service plan.
   *
   * @param key
   * Contains the caseID key for the specific service plan.
   *
   * @return List of plan participants for the service plan.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_LIST_PLAN_PARTICIPANTS_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanParticipantDetailsList listPlanParticipants(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // ServicePlanDelivery entity and key
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // return structure
    final ServicePlanParticipantDetailsList servicePlanParticipantDetailsList = new ServicePlanParticipantDetailsList();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // read concern role ID of the plan participant
    caseHeaderKey.caseID = key.key.caseID;
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      key.key);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_LIST_PLAN_PARTICIPANTS_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read the list of case participant roles
    servicePlanParticipantDetailsList.servicePlanParticipantDetailsList = servicePlanDeliveryObj.searchParticipants(
      key.key);

    // BEGIN, CR00129996, ZV
    final SpecialCaution specialCautionObj = SpecialCautionFactory.newInstance();
    final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

    for (int i = 0; i
      < servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.size(); i++) {

      // assigning concern role id to SpecialCautionConcernKey struct
      specialCautionConcernKey.concernRoleID = servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.item(i).participantRoleID;
      // invoking displayActiveSpecialCautionIndicator() method on special
      // caution
      // object
      servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.item(i).specialCautionInd = specialCautionObj.displayActiveSpecialCautionIndicator(specialCautionConcernKey).displayIndicator;
    }
    // END, CR00129996

    // return the list
    return servicePlanParticipantDetailsList;

  }

  // BEGIN CR00109001, GBA
  // ___________________________________________________________________________
  // BEGIN CR00273405, KRK
  /**
   * Add and/or remove plan participants for a service plan.
   *
   * @param details
   * Contains plan participants details to create the nominated
   * representative.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_XRV_SERVICEPLAN_PLANPARTICIPANT_NOT_MODIFIABLE}
   * - Plan
   * participants cannot be added or removed from a service plan
   * once the status of service plan becomes active or closed.
   */
  // END, CR00273405
  @Override
  public void updatePlanParticipants(UpdatePlanParticipantsDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole entity object, key and details
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // populate caseIDParticipantRole key with service plan caseID
    caseIDParticipantRoleKey.caseID = details.caseID;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.struct.CaseParticipantRoleDetails caseParticipantRoleDetails = new curam.core.sl.struct.CaseParticipantRoleDetails();
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // Manipulation variables to add/remove plan participants
    StringList initialStringList = new StringList();
    StringList updatedStringList = new StringList();

    // CaseHeader entity manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    // Read CaseHeader for the service plan
    // BEGIN, CR00279909, SG
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // END, CR00279909

    initialStringList = StringUtil.tabText2StringListWithTrim(
      details.initialPlanParticipants);
    updatedStringList = StringUtil.tabText2StringListWithTrim(
      details.updatedPlanParticipants);

    final int updatedSize = updatedStringList.size();

    // Validations Starts here
    // BEGIN, CR00273405, KRK
    // Plan participants cannot be added or removed from a service plan once the
    // status becomes active or closed.
    // Check if service plan is active, if yes throw an exception
    if (CASESTATUS.ACTIVE.equals(caseHeaderDtls.statusCode)
      || CASESTATUS.CLOSED.equals(caseHeaderDtls.statusCode)) {
      final AppException e = new AppException(
        BPOSERVICEPLANDELIVERY.ERR_XRV_SERVICEPLAN_PLANPARTICIPANT_NOT_MODIFIABLE);

      e.arg(
        CodeTable.getOneItemForUserLocale(CASESTATUS.TABLENAME,
        caseHeaderDtls.statusCode));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00273405
    // Check if primary client is selected as planned participant, if not
    // throw
    // an exception
    if (updatedSize == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_FV_SERVICEPLAN_PRIMARY_HAS_TO_BE_PLANNED_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    boolean flagHasPrimary = false;

    // Check if primary has been selected as one of the planned
    // participants.
    for (int i = 0; i < updatedSize; i++) {
      if (updatedStringList.item(i).trim().length() > 0) {
        caseParticipantRoleDetails.dtls.participantRoleID = Long.parseLong(
          updatedStringList.item(i));
        // Check if the primary is selected from the list
        if (caseParticipantRoleDetails.dtls.participantRoleID
          == details.primaryConcernRoleID) {
          flagHasPrimary = true;
          break;
        }
      }
    }

    if (!flagHasPrimary) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_FV_SERVICEPLAN_PRIMARY_IS_NOT_PLANNED_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // Validations Ends Here

    // Check if primary plan participant has been changed
    boolean flagPrimaryChanged = false;

    if (caseHeaderDtls.concernRoleID != details.primaryConcernRoleID) {
      flagPrimaryChanged = true;
    }

    if (flagPrimaryChanged) {

      // Manipulation variable for case participant role type update
      final UpdateCaseParticipantRoleTypeCodeDetails updateCaseParticipantRoleType = new UpdateCaseParticipantRoleTypeCodeDetails();

      // Check if previous primary plan participant is selected as
      // participant
      if (updatedStringList.contains(
        String.valueOf(caseHeaderDtls.concernRoleID))) {
        // If yes, modify CaseParticipantRole with plan participant type

        // Get caseParticipantRoleID
        caseIDParticipantRoleKey.participantRoleID = caseHeaderDtls.concernRoleID;
        caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleID(caseIDParticipantRoleKey).caseParticipantRoleID;
        // Read details
        final CaseParticipantRoleDtls caseParticipantRoleDtls = caseParticipantRoleObj.read(
          caseParticipantRoleKey);

        // Set type code and version number for modify details
        updateCaseParticipantRoleType.typeCode = CASEPARTICIPANTROLETYPE.PLANPARTICIPANT;
        updateCaseParticipantRoleType.versionNo = caseParticipantRoleDtls.versionNo;

        // modify CaseParticipantRole record
        caseParticipantRoleObj.modifyTypeCode(caseParticipantRoleKey,
          updateCaseParticipantRoleType);

      }

      // Update CaseHeader with new primary plan participant
      caseHeaderDtls.concernRoleID = details.primaryConcernRoleID;
      caseHeaderObj.modify(caseHeaderKey, caseHeaderDtls);

      // Check if new primary plan participant was selected as participant
      if (initialStringList.contains(
        String.valueOf(details.primaryConcernRoleID))) {
        // If Yes, modify CaseParticipantRole with plan participant type

        // Get caseParticipantRoleID
        caseIDParticipantRoleKey.participantRoleID = details.primaryConcernRoleID;
        caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleID(caseIDParticipantRoleKey).caseParticipantRoleID;
        // Read details
        final CaseParticipantRoleDtls caseParticipantRoleDtls = caseParticipantRoleObj.read(
          caseParticipantRoleKey);

        // Set type code and version number for modify details
        updateCaseParticipantRoleType.typeCode = CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT;
        updateCaseParticipantRoleType.versionNo = caseParticipantRoleDtls.versionNo;

        // modify CaseParticipantRole record
        caseParticipantRoleObj.modifyTypeCode(caseParticipantRoleKey,
          updateCaseParticipantRoleType);

      } else {
        // Insert new primary plan participant into CaseParticipantRole
        caseParticipantRoleDetails.dtls.participantRoleID = details.primaryConcernRoleID;
        caseParticipantRoleDetails.dtls.caseID = details.caseID;
        caseParticipantRoleDetails.dtls.fromDate = curam.util.type.Date.getCurrentDate();
        caseParticipantRoleDetails.dtls.typeCode = CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT;
        caseParticipantRole.insertCaseParticipantRole(
          caseParticipantRoleDetails);
      }
    }

    // fill CaseParticipantRole record for plan participants to insert
    caseParticipantRoleDetails.dtls.caseID = details.caseID;
    caseParticipantRoleDetails.dtls.fromDate = curam.util.type.Date.getCurrentDate();
    caseParticipantRoleDetails.dtls.typeCode = CASEPARTICIPANTROLETYPE.PLANPARTICIPANT;

    // Insert new Plan Participant records into database.
    for (int i = 0; i < updatedSize; i++) {
      caseParticipantRoleDetails.dtls.participantRoleID = Long.parseLong(
        updatedStringList.item(i));

      // If the selected planned participant is not existing plan
      // participant,
      // insert the record into database.
      if (!initialStringList.contains(
        String.valueOf(caseParticipantRoleDetails.dtls.participantRoleID))) {
        // Check if the selected plan participant is already added as
        // primary
        if (caseParticipantRoleDetails.dtls.participantRoleID
          != details.primaryConcernRoleID) {

          caseParticipantRole.insertCaseParticipantRole(
            caseParticipantRoleDetails);
        }
      }
    }

    final int originalSize = initialStringList.size();

    // Remove Plan Participant record in the database.
    for (int i = 0; i < originalSize; i++) {
      caseIDParticipantRoleKey.participantRoleID = Long.parseLong(
        initialStringList.item(i));

      // If the original plan participant is not in the updated plan
      // participant list, delete the record
      if (!updatedStringList.contains(
        String.valueOf(caseIDParticipantRoleKey.participantRoleID))) {

        // Validate plan participant is not associated with any planned
        // item

        // Entity declarations
        final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
        final ParticipantCaseIDKey participantCaseIDKey = new ParticipantCaseIDKey();

        participantCaseIDKey.caseID = details.caseID;
        participantCaseIDKey.concernRoleID = caseIDParticipantRoleKey.participantRoleID;

        // Call the entity operation to get planned items for
        // participant
        final PlannedItemIDAndNameDetailsList plannedItemList = plannedItemObj.searchPlannedItemsForPlanParticipant(
          participantCaseIDKey);

        // If PlannedItem exists for the participant, throw an exception
        if (plannedItemList.dtls.size() != 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOSERVICEPLANDELIVERY.ERR_FV_SERVICEPLAN_PLANPARTICIPANT_NOT_REMOVABLE),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }

        try {
          caseParticipantRoleObj.removeCaseParticipantRole(
            caseIDParticipantRoleKey);
        } catch (final Exception e) {
          Trace.exceptionStackTraceAsString(e);
        }
      }
    }

  }

  // END CR00109001

  /**
   * Creates a nominated representative record for a service plan delivery.
   *
   * @param details
   * Details to create the nominated representative.
   *
   * @return Returns created nominated representative's unique identifier.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MAINTAIN_NOMREP_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to add a
   * nominated representative.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public CaseParticipantRoleKey insertNominatedRepresentative(
    CreateNominatedRepresentativeDetails details) throws AppException,
      InformationalException {

    // Create return object
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleDtls caseParticipantRoleDtls = new curam.core.sl.entity.struct.CaseParticipantRoleDtls();

    // ServicePlanDelivery entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // Representative maintenance object
    final curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();
    // Struct passed to Representative::registerRepresentative
    final curam.core.sl.struct.RepresentativeRegistrationDetails representativeRegistrationDetails = new curam.core.sl.struct.RepresentativeRegistrationDetails();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // call validations
    validateInsertNominatedRepresentative(details);

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = details.caseID;

    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    if (details.name.length() > 0) {

      representativeRegistrationDetails.representativeDtls.representativeName = details.name;

      // BEGIN, CR00190258, CL
      final AddressData addressDataObj = AddressDataFactory.newInstance();

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = addressDataObj.getAddressDataForLocale().addressData;
      // END, CR00190258

      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = curam.util.type.Date.getCurrentDate();
      representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = curam.codetable.SENSITIVITY.DEFAULTCODE;

      // Call registerRepresentative
      representativeObj.registerRepresentative(
        representativeRegistrationDetails);
    }

    // set the key
    if (details.planParticipantConcernRoleID != 0) {
      servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = details.planParticipantConcernRoleID;
    } else if (details.registeredPersonConcernRoleID != 0) {
      servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = details.registeredPersonConcernRoleID;
    } else {
      servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    }

    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {

      throw new AppException(
        BPOSERVICEPLANDELIVERY.ERR_MAINTAIN_NOMREP_SECURITY_CHECK_FAILED);

    }

    // set details for the other attributes
    if (details.planParticipantConcernRoleID != 0) {
      caseParticipantRoleDtls.participantRoleID = details.planParticipantConcernRoleID;
    } else if (details.registeredPersonConcernRoleID != 0) {
      caseParticipantRoleDtls.participantRoleID = details.registeredPersonConcernRoleID;
    } else {
      caseParticipantRoleDtls.participantRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    }

    caseParticipantRoleDtls.caseID = details.caseID;
    caseParticipantRoleDtls.comments = details.comments;
    caseParticipantRoleDtls.fromDate = details.startDate;
    caseParticipantRoleDtls.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
    caseParticipantRoleDtls.typeCode = CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE;

    // insert CaseParticipantRole
    caseParticipantRoleObj.insert(caseParticipantRoleDtls);

    // set return value
    caseParticipantRoleKey.caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleDtls.caseParticipantRoleID;

    // return case participant role ID
    return caseParticipantRoleKey;

  }

  // ___________________________________________________________________________
  /**
   * Validates Nominated Representative details for insert.
   *
   * @param details
   * New nominated representative details.
   */
  @Override
  public void validateInsertNominatedRepresentative(
    CreateNominatedRepresentativeDetails details) throws AppException,
      InformationalException {

    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();
    curam.core.struct.CaseStatusCode caseStatusCode;

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.SearchForDupClientsKey searchForDupClientsKey = new curam.core.sl.entity.struct.SearchForDupClientsKey();

    // /////////////////////////////////////////////////////////////////////////
    // One and only one of the participant, registered person or
    // representative name
    // fields must be specified
    if (
      // first check if none of the 3 options are selected
      details.planParticipantConcernRoleID == 0
      && details.registeredPersonConcernRoleID == 0
      && details.name.length() == 0
        // check if any 2 of the options are populated
        || details.planParticipantConcernRoleID != 0
          && details.registeredPersonConcernRoleID != 0
          || details.planParticipantConcernRoleID != 0
            && details.name.length() != 0
            || details.registeredPersonConcernRoleID != 0
              && details.name.length() != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CREATE_NOMREP_SELECT_ONLY_ONE_REPRESENTATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // ////////////////////////////////////////////////////////////////////
    // Start Date must be defined
    if (details.startDate.equals(curam.util.type.Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_NOMREP_START_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // /////////////////////////////////////////////////////////////////////////
    // The service plan status must not be Closed

    // manipulation variables
    caseHeaderKey.caseID = details.caseID;

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(details.caseID);
    // END, CR00227859

    // Read case header details
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CREATE_NOMREP_WHEN_CASE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // /////////////////////////////////////////////////////////////////////////
    // start date must not be earlier than current date
    if (details.startDate.equals(curam.util.type.Date.kZeroDate)
      || details.startDate.before(curam.util.type.Date.getCurrentDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CREATE_NOMREP_START_AFTER_CURRENT_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // /////////////////////////////////////////////////////////////////////////
    // The plan participant cannot be a nominated representative
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    if (readParticipantRoleIDDetails.concernRoleID
      == details.planParticipantConcernRoleID
        || readParticipantRoleIDDetails.concernRoleID
          == details.registeredPersonConcernRoleID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_CREATE_NOMREP_NOT_PLAN_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // /////////////////////////////////////////////////////////////////////////
    // The person must not be defined as nominated representative for the
    // same
    // period of time
    if (details.planParticipantConcernRoleID != 0) {
      searchForDupClientsKey.participantRoleID = details.planParticipantConcernRoleID;
    } else if (details.registeredPersonConcernRoleID != 0) {
      searchForDupClientsKey.participantRoleID = details.registeredPersonConcernRoleID;
    }
    searchForDupClientsKey.caseID = details.caseID;
    searchForDupClientsKey.fromDate = details.startDate;
    searchForDupClientsKey.recordStatus = RECORDSTATUS.NORMAL;
    searchForDupClientsKey.typeCode = CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE;

    // find out if case participant role already exist
    final curam.core.sl.entity.struct.CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = caseParticipantRoleObj.searchForDuplicateParticipants(
      searchForDupClientsKey);

    if (caseParticipantRoleDtlsList.dtls.size() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MAINTAIN_NOMREP_DUPLICATE_PERSON),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Logically deletes (cancels) a nominated representative record on a service
   * plan delivery.
   *
   * @param details
   * Details to cancel the nominated representative.
   */
  @Override
  public void deleteNominatedRepresentative(
    CancelServicePlanParticipantDetails details) throws AppException,
      InformationalException {

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    // validate cancel details
    validateDeleteNominatedRepresentative(details);

    // cancel nominated representative
    details.cancelCaseParticipantRoleDetails.recordStatus = RECORDSTATUS.CANCELLED;
    caseParticipantRoleObj.modifyRecordStatus(details.caseParticipantRoleKey,
      details.cancelCaseParticipantRoleDetails);
  }

  // ___________________________________________________________________________
  /**
   * Allows a participant record of type Nominated Representative to be updated.
   *
   * @param details
   * Nominated Representative details
   */
  @Override
  public void modifyNominatedRepresentative(
    ModifyServicePlanParticipantDetails details) throws AppException,
      InformationalException {

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // call validations
    validateModifyNominatedRepresentative(details);

    // set CaseParticipantRole key
    caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRole_eoModifyDetails.caseParticipantRoleID;

    // modify CaseParticipantRole
    caseParticipantRoleObj.modifyCaseParticipantRole(caseParticipantRoleKey,
      details.caseParticipantRole_eoModifyDetails);

  }

  /**
   * Reads nominated representative's details.
   *
   * @param key
   * Case participant role ID of the nominated representative.
   *
   * @return Returns nominated representative details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_VIEW_NOMINATED_REPRESENTATIVE_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanParticipantDetails readNominatedRepresentativeDetails(
    CaseParticipantRoleKey key) throws AppException, InformationalException {

    // return struct
    final ServicePlanParticipantDetails servicePlanParticipantDetails = new ServicePlanParticipantDetails();

    // ServicePlanDelivery entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // read service plan delivery ID
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = readServicePlanDeliveryID(key).key.caseID;

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    // read concern role ID of the plan participant
    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;
    final curam.core.struct.ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_NOMINATED_REPRESENTATIVE_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read nominated representative details
    servicePlanParticipantDetails.servicePlanParticipantDetails = servicePlanDeliveryObj.readNominatedRepresentativeDetails(
      key.caseParticipantRoleKey);

    // return details
    return servicePlanParticipantDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validates Nominated Representative details to be modified.
   *
   * @param details
   * Modified nominated representative details.
   */
  @Override
  public void validateModifyNominatedRepresentative(
    ModifyServicePlanParticipantDetails details) throws AppException,
      InformationalException {

    // ServicePlanDelivery entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // ServicePlanContract entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    curam.serviceplans.sl.entity.struct.DateAcceptedStruct dateAcceptedStruct;
    curam.serviceplans.sl.entity.struct.DateRejectedStruct dateRejectedStruct;
    curam.core.sl.struct.RecordCount recordCount;

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();
    final curam.core.sl.entity.struct.SearchForDupClientsKey searchForDupClientsKey = new curam.core.sl.entity.struct.SearchForDupClientsKey();
    curam.core.sl.entity.struct.CaseParticipantRole_eoStatusAndTypeDetails caseParticipantRole_eoStatusAndTypeDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoStatusAndTypeDetails();

    // set case participant role key
    caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRole_eoModifyDetails.caseParticipantRoleID;

    // /////////////////////////////////////////////////////////////////////////
    // case participant must be active

    // read nominated representative status
    caseParticipantRole_eoStatusAndTypeDetails = caseParticipantRoleObj.readStatusAndTypeDetails(
      caseParticipantRoleKey);
    if (!caseParticipantRole_eoStatusAndTypeDetails.recordStatus.equals(
      RECORDSTATUS.NORMAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_MODIFY_NOMREP_WHEN_DELETED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // ////////////////////////////////////////////////////////////////////
    // Start Date must be defined
    if (details.caseParticipantRole_eoModifyDetails.fromDate.equals(
      curam.util.type.Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_NOMREP_START_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // ////////////////////////////////////////////////////////////////////
    // Start Date must not be earlier than the date already specified

    // read existing data
    final curam.serviceplans.sl.entity.struct.ServicePlanParticipantDetails servicePlanParticipantDetails = servicePlanDeliveryObj.readNominatedRepresentativeDetails(
      caseParticipantRoleKey);

    // compare dates
    if (details.caseParticipantRole_eoModifyDetails.fromDate.before(
      servicePlanParticipantDetails.fromDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_NOMREP_START_NOT_EARLIER_THAN_ORIGINAL_START),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // /////////////////////////////////////////////////////////////////////////
    // The end date must be after start date

    if (!details.caseParticipantRole_eoModifyDetails.toDate.after(
      details.caseParticipantRole_eoModifyDetails.fromDate)
        && !details.caseParticipantRole_eoModifyDetails.toDate.equals(
          curam.util.type.Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_NOMREP_START_EARLIER_THAN_END),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // /////////////////////////////////////////////////////////////////////////
    // The person must not be defined as nominated representative for the
    // same
    // period of time

    // read concern role id
    caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRole_eoModifyDetails.caseParticipantRoleID;
    final curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails caseParticipantConcernRoleDetails = caseParticipantRoleObj.readParticipantRoleDetails(
      caseParticipantRoleKey);

    searchForDupClientsKey.participantRoleID = caseParticipantConcernRoleDetails.concernRoleID;
    searchForDupClientsKey.caseID = caseParticipantRoleObj.readCaseID(caseParticipantRoleKey).caseID;
    searchForDupClientsKey.fromDate = details.caseParticipantRole_eoModifyDetails.fromDate;
    searchForDupClientsKey.toDate = details.caseParticipantRole_eoModifyDetails.toDate;
    searchForDupClientsKey.recordStatus = RECORDSTATUS.NORMAL;
    searchForDupClientsKey.typeCode = CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE;

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(searchForDupClientsKey.caseID);
    // END, CR00227859

    // find out if case participant role already exist
    final curam.core.sl.entity.struct.CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = caseParticipantRoleObj.searchForDuplicateParticipants(
      searchForDupClientsKey);

    int listSize = caseParticipantRoleDtlsList.dtls.size();

    for (int i = 0; i < listSize; i++) {
      if (caseParticipantRoleDtlsList.dtls.item(i).caseParticipantRoleID
        == details.caseParticipantRole_eoModifyDetails.caseParticipantRoleID) {
        // it is the record I am modifying and should be skipped
        listSize--;
      }
    }

    if (listSize > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MAINTAIN_NOMREP_DUPLICATE_PERSON),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // ///////////////////////////////////////////////////////////////////////
    // An end date may not be entered if a contract issued to the nominated
    // representative has a status of Issued

    // count contracts issued for participant
    caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRole_eoModifyDetails.caseParticipantRoleID;
    recordCount = servicePlanContractObj.countContractsIssuedForPlanParticipant(
      caseParticipantRoleKey);

    if (recordCount.count > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_NOMREP_WHEN_CONTRACT_ISSUED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // ////////////////////////////////////////////////////////////////////////
    // The end date must be later than the latest date on which any contract
    // issued to the nominated representative were either accepted or
    // rejected

    // search last date a contract was accepted
    dateAcceptedStruct = servicePlanContractObj.searchLastAcceptedDateForPlanParticipant(
      caseParticipantRoleKey);

    // search last date a contract was rejected
    dateRejectedStruct = servicePlanContractObj.searchLatestRejectedDateForPlanParticipant(
      caseParticipantRoleKey);

    if (!dateAcceptedStruct.dateAccepted.equals(curam.util.type.Date.kZeroDate)
      || !dateRejectedStruct.dateRejected.equals(curam.util.type.Date.kZeroDate)) {
      final AppException e = new AppException(
        BPOSERVICEPLANDELIVERY.ERR_MODIFY_NOMREP_END_LATER_THAN_CONTRACT_DATE);

      if (!dateAcceptedStruct.dateAccepted.equals(
        curam.util.type.Date.kZeroDate)
          && !dateRejectedStruct.dateRejected.equals(
            curam.util.type.Date.kZeroDate)) {
        // end date must be later than the latest of this two
        if (dateAcceptedStruct.dateAccepted.after(
          dateRejectedStruct.dateRejected)) {
          if (details.caseParticipantRole_eoModifyDetails.toDate.before(
            dateAcceptedStruct.dateAccepted)) {
            e.arg(dateAcceptedStruct.dateAccepted);
          }
        } else if (dateRejectedStruct.dateRejected.after(
          dateAcceptedStruct.dateAccepted)) {
          if (details.caseParticipantRole_eoModifyDetails.toDate.before(
            dateRejectedStruct.dateRejected)) {
            e.arg(dateRejectedStruct.dateRejected);
          } else {
            e.arg(dateRejectedStruct.dateRejected);
          }
        }
      } else if (!dateAcceptedStruct.dateAccepted.equals(
        curam.util.type.Date.kZeroDate)) {
        // end date must be later than date accepted
        if (details.caseParticipantRole_eoModifyDetails.toDate.before(
          dateAcceptedStruct.dateAccepted)) {
          e.arg(dateAcceptedStruct.dateAccepted);
        }
      } else if (!dateRejectedStruct.dateRejected.equals(
        curam.util.type.Date.kZeroDate)) {
        // end date must be later than date rejected
        if (details.caseParticipantRole_eoModifyDetails.toDate.before(
          dateRejectedStruct.dateRejected)) {
          e.arg(dateRejectedStruct.dateRejected);
        }
      }
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery unique identifier for a service plan
   * participant.
   *
   * @param key
   * Case participant role key
   *
   * @return Service plan delivery unique identifier
   */
  @Override
  public ServicePlanDeliveryKey readServicePlanDeliveryID(
    CaseParticipantRoleKey key) throws AppException, InformationalException {

    // return struct
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // read case ID
    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleKey.caseParticipantRoleID;
    servicePlanDeliveryKey.key.caseID = caseParticipantRoleObj.readCaseID(caseParticipantRoleKey).caseID;

    // return service plan delivery identifier
    return servicePlanDeliveryKey;

  }

  /**
   * Reads nominated representative's details to be modified.
   *
   * @param key
   * Case participant role ID of the nominated representative.
   *
   * @return Returns nominated representative details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_NOMREP_SECURITY_CHECK_FAILED} -
   * if the user does not have appropriate privileges to modify this
   * service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_VIEW_NOMINATED_REPRESENTATIVE_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanParticipantDetails readNominatedRepresentativeDetailsForModify(CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    // return struct
    final ServicePlanParticipantDetails servicePlanParticipantDetails = new ServicePlanParticipantDetails();

    // ServicePlanDelivery entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();
    final curam.serviceplans.sl.struct.CaseParticipantRoleKey slCaseParticipantRoleKey = new curam.serviceplans.sl.struct.CaseParticipantRoleKey();

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // read service plan delivery ID
    slCaseParticipantRoleKey.caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleKey.caseParticipantRoleID;
    servicePlanDeliveryKey.caseID = readServicePlanDeliveryID(slCaseParticipantRoleKey).key.caseID;

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    // set case participant role key
    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleKey.caseParticipantRoleID;

    // read participant role id
    final curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails concernRoleDetails = caseParticipantRoleObj.readParticipantRoleDetails(
      caseParticipantRoleKey);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = concernRoleDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_NOMREP_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_NOMINATED_REPRESENTATIVE_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read nominated representative details
    servicePlanParticipantDetails.servicePlanParticipantDetails = servicePlanDeliveryObj.readNominatedRepresentativeDetails(
      key.caseParticipantRoleKey);

    // return details
    return servicePlanParticipantDetails;

  }

  /**
   * Validates Nominated Representative details to be deleted.
   *
   * @param details
   * Nominated representative details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_DELETE_NOMREP_WHEN_CASE_CLOSED} - if
   * this nominated representative may not be deleted as the
   * service plan has already been closed.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_DELETE_NOMREP_WHEN_ALREADY_DELETED} - if
   * this nominated representative has already been deleted.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_DELETE_NOMREP_SECURITY_CHECK_FAILED} -
   * if the user does not have appropriate privileges to delete this
   * nominated representative.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_DELETE_NOMREP_WHEN_CONTRACT_ISSUED} - if
   * this nominated representative may not be deleted as a
   * contract has already been issued to this person.
   */
  @Override
  public void validateDeleteNominatedRepresentative(
    CancelServicePlanParticipantDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    curam.core.sl.entity.struct.CaseParticipantRole_eoStatusAndTypeDetails caseParticipantRole_eoStatusAndTypeDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRole_eoKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // ServicePlanContract entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    curam.core.sl.struct.RecordCount recordCount;

    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();
    curam.core.struct.CaseStatusCode caseStatusCode;

    // ServicePlanDelivery entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // read service plan delivery ID
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    caseParticipantRoleKey.caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRoleKey.caseParticipantRoleID;
    servicePlanDeliveryKey.caseID = readServicePlanDeliveryID(caseParticipantRoleKey).key.caseID;

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(servicePlanDeliveryKey.caseID);
    // END, CR00227859

    // read service plan ID
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    // set case participant role key
    caseParticipantRole_eoKey.caseParticipantRoleID = details.caseParticipantRoleKey.caseParticipantRoleID;

    // read participant role id
    final curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails concernRoleDetails = caseParticipantRoleObj.readParticipantRoleDetails(
      caseParticipantRole_eoKey);

    // set the key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = concernRoleDetails.concernRoleID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.servicePlanID;

    // ////////////////////////////////////////////////////////////////////////
    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      throw new AppException(
        BPOSERVICEPLANDELIVERY.ERR_DELETE_NOMREP_SECURITY_CHECK_FAILED);
    }

    // ////////////////////////////////////////////////////////////////////////
    // case participant must be active

    // read nominated representative status
    caseParticipantRole_eoStatusAndTypeDetails = caseParticipantRoleObj.readStatusAndTypeDetails(
      details.caseParticipantRoleKey);
    if (!caseParticipantRole_eoStatusAndTypeDetails.recordStatus.equals(
      RECORDSTATUS.NORMAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_DELETE_NOMREP_WHEN_ALREADY_DELETED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // ////////////////////////////////////////////////////////////////////////
    // The service plan status must not be Closed

    // set case header key
    caseHeaderKey.caseID = caseParticipantRoleObj.readCaseID(caseParticipantRole_eoKey).caseID;

    // Read case status code
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_DELETE_NOMREP_WHEN_CASE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // ////////////////////////////////////////////////////////////////////////
    // The nominated representative may not be deleted if a contract was
    // issued

    // count contracts issued for participant
    recordCount = servicePlanContractObj.countContractsIssuedForPlanParticipant(
      caseParticipantRole_eoKey);

    if (recordCount.count > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANDELIVERY.ERR_DELETE_NOMREP_WHEN_CONTRACT_ISSUED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Modifies service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @param dtls
   * Service plan delivery details.
   */
  @Override
  public void modifyServicePlanOutcomeAndComments(ModifySPOutcomeAndCommentsKey key,
    ModifySPOutcomeAndCommentsDetails dtls) throws AppException,
      InformationalException {

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(key.caseHeaderKey.caseID);
    // END, CR00227859

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // PlannedGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // Plan outcome manipulation variables
    final ReadOutcomeAchievedAndCommentsDetails readOutcomeAchievedAndCommentsDetails = new ReadOutcomeAchievedAndCommentsDetails();
    final PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();

    // Assign case ID value
    plannedGoalCaseIDKey.caseID = key.caseHeaderKey.caseID;

    // Read outcome details
    readOutcomeAchievedAndCommentsDetails.outcomeAchievedDetails = PlannedGoalFactory.newInstance().readOutcomeAchievedByCaseID(
      plannedGoalCaseIDKey);

    // If outcome is unchanged, just update the comments
    if (readOutcomeAchievedAndCommentsDetails.outcomeAchievedDetails.outcomeAchieved.equals(
      dtls.plannedGoalDetails.outcomeAchieved)) {
      // Modify case header comments
      caseHeaderObj.modifyCaseHeaderComments(key.caseHeaderKey,
        dtls.caseHeaderDetails);
    } else {

      // Modify case header comments
      caseHeaderObj.modifyCaseHeaderComments(key.caseHeaderKey,
        dtls.caseHeaderDetails);

      // Modify planned goal outcome achieved
      plannedGoalObj.modifyOutcomeAchieved(key.caseHeaderKey,
        dtls.plannedGoalDetails);

      // Service plans workflow raise event integration
      final Event event = new Event();

      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK
      event.eventKey = curam.events.SERVICEPLANS.MODIFYPLAN;
      // END, HARP 65061
      // END, CR00021588

      event.primaryEventData = key.caseHeaderKey.caseID;
      curam.util.events.impl.EventService.raiseEvent(event);
    }
  }

  /**
   * Reads service plan delivery details to be modified.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details containing the outcome and comments.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_MODIFY_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to modify
   * the service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify
   * the service plan for this client.
   * @throws AppException
   * {@link BPOMAINTAINSERVICEPLANDELIVERY# ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS}
   * - if this service plan cannot be modified as a goal has not been
   * set.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadOutcomeAchievedAndCommentsDetails readOutcomeAchievedAndComments(ReadOutcomeAchievedAndCommentsKey key)
    throws AppException, InformationalException {

    // create return struct
    final ReadOutcomeAchievedAndCommentsDetails readOutcomeAchievedAndCommentsDetails = new ReadOutcomeAchievedAndCommentsDetails();

    // planned goal entity manipulation variables
    final PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // need to read the service plan case id and plan participant role id.
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // ServicePlanDelivery variables to read servicePlanID
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // read the ServicePlanID
    servicePlanDeliveryKey.caseID = key.caseHeaderKey.caseID;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // CaseHeader entity variables to read participant role id
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // set the key
    caseHeaderKey.caseID = key.caseHeaderKey.caseID;

    // read the Concern Role ID
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // set the key
    plannedGoalCaseIDKey.caseID = key.caseHeaderKey.caseID;

    // read service plan details
    try {

      readOutcomeAchievedAndCommentsDetails.outcomeAchievedDetails = PlannedGoalFactory.newInstance().readOutcomeAchievedByCaseID(
        plannedGoalCaseIDKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {

      throw new AppException(
        BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS);
    }

    readOutcomeAchievedAndCommentsDetails.caseHeaderDetails = CaseHeaderFactory.newInstance().readCaseHeaderComments(
      key.caseHeaderKey);

    return readOutcomeAchievedAndCommentsDetails;
  }

  /**
   * Modifies service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   * @param dtls
   * Service plan delivery details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_TYPE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to modify
   * the service plan type.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_TYPE_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify
   * the service plan type for this client.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyServicePlanTypeAndComments(ModifyServicePlanTypeKey key,
    ModifyServicePlanTypeDetails dtls) throws AppException,
      InformationalException {

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(key.key.caseID);
    // END, CR00227859

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // read the ServicePlanID
    servicePlanDeliveryKey.caseID = key.key.caseID;

    // If the type is to be changed, ensure this is allowed with respect to
    // the current
    // plan status e.g not allowed if sub goals already defined
    if (servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID
      != dtls.typeDtls.servicePlanID) {

      // BEGIN, CR00179387, NS
      final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
      // END, CR00179387

      final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

      // need to read the service plan case id and concern role id.
      spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

      spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

      // set the key to read concern role id
      caseHeaderKey.caseID = key.key.caseID;

      // read the Concern Role ID
      spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

      // check service plan security
      try {
        servicePlanSecurity.servicePlanOperationSecurityCheck(
          spOperationSecurityKey);
      } catch (final AppException e) {
        if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
          throw new AppException(
            BPOSERVICEPLANDELIVERY.ERR_MODIFY_TYPE_SECURITY_CHECK_FAILED);
        } else if (e.equals(
          BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
          throw new AppException(
            BPOSERVICEPLANDELIVERY.ERR_MODIFY_TYPE_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
        } else {
          throw e;
        }
      }

      // set the key
      caseHeaderKey.caseID = key.key.caseID;

      // Modify case header comments
      caseHeaderObj.modifyCaseHeaderComments(caseHeaderKey,
        dtls.caseHeaderDetails);

      // Modify service plan delivery type
      servicePlanDeliveryObj.modifyServicePlanType(key.key, dtls.typeDtls);

      // Service plans workflow integration to raise an event
      final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK
      event.eventKey = curam.events.SERVICEPLANS.MODIFYPLAN;
      // END, HARP 65061
      // END, CR00021588

      event.primaryEventData = caseHeaderKey.caseID;
      curam.util.events.impl.EventService.raiseEvent(event);
    } // BEGIN, HARP 50482, CH
    // Else only change the comments this is allowed regardless of plan
    // status
    // but subject to normal security checks
    else {

      // BEGIN, CR00179387, NS
      final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
      // END, CR00179387

      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // need to read the service plan case id and plan maintenance role
      // id.
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // Read case id into manipulation variable
      servicePlanDeliveryKey.caseID = key.key.caseID;

      // Read service plan id into manipulation variable
      servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

      // check service plan security
      try {
        servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
      } catch (final AppException e) {
        if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
          throw new AppException(
            BPOSERVICEPLANDELIVERY.ERR_MODIFY_TYPE_SECURITY_CHECK_FAILED);
        } else {
          throw e;
        }
      }

      // set the key
      caseHeaderKey.caseID = key.key.caseID;

      // Modify case header comments
      caseHeaderObj.modifyCaseHeaderComments(caseHeaderKey,
        dtls.caseHeaderDetails);
    }
  }

  /**
   * Reads service plan delivery type and comments to be modified.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details containing the type and comments.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_TYPE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to modify
   * the service plan type.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_TYPE_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify
   * the service plan type for this client.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadServicePlanTypesAndCommentsDetails readServicePlanTypesAndComments(ReadServicePlanTypesAndCommentsKey key)
    throws AppException, InformationalException {

    // create return struct
    final ReadServicePlanTypesAndCommentsDetails readServicePlanTypesAndCommentsDetails = new ReadServicePlanTypesAndCommentsDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // need to read the service plan case id and concern role id.
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // read the ServicePlanID
    servicePlanDeliveryKey.caseID = key.key.caseID;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // set the key to read concern role id
    caseHeaderKey.caseID = key.key.caseID;

    // read the Concern Role ID
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_TYPE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_TYPE_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // set the key
    caseKey.caseID = key.key.caseID;

    // return variable
    curam.core.struct.IntegratedCaseKey integratedCaseKey = new curam.core.struct.IntegratedCaseKey();

    // read Integrated Case ID by CaseID
    integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);

    // Read SP types specified for an integrated case
    // AdminICServicePlanLink entity manipulation variable
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLinkObj = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();
    final ServicePlanIntegratedCaseIDAndRecordStatusKey servicePlanIntegratedCaseIDAndRecordStatusKey = new ServicePlanIntegratedCaseIDAndRecordStatusKey();

    // populate the key
    servicePlanIntegratedCaseIDAndRecordStatusKey.caseID = integratedCaseKey.integratedCaseID;

    // set record status to active
    servicePlanIntegratedCaseIDAndRecordStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;

    readServicePlanTypesAndCommentsDetails.planTypeDtlsList = adminICServicePlanLinkObj.searchActiveSPTypesByIntegratedCaseID(
      servicePlanIntegratedCaseIDAndRecordStatusKey);

    // populate the key
    caseHeaderKey.caseID = key.key.caseID;

    // read case header for comments and version no
    readServicePlanTypesAndCommentsDetails.caseHeaderDetails = caseHeaderObj.readCaseHeaderComments(
      caseHeaderKey);

    servicePlanDeliveryKey.caseID = key.key.caseID;
    // read SP entity for versionNo
    readServicePlanTypesAndCommentsDetails.servicePlanDeliveryVersionDetails = servicePlanDeliveryObj.readVersionNo(
      servicePlanDeliveryKey);

    return readServicePlanTypesAndCommentsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the service plan goal.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @param details
   * Details containing the goal.
   */
  @Override
  public void modifyServicePlanGoal(ModifyServicePlanGoalKey key,
    ModifyServicePlanGoalDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00227859, PM
    checkMaintainSecurity(key.key.caseID);
    // END, CR00227859

    // Entity layer object variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // Entity layer structs
    final curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey plannedGoalCaseIDKey = new curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey();

    plannedGoalCaseIDKey.caseID = key.key.caseID;

    // Count the planned goal by CaseID
    final curam.serviceplans.sl.entity.struct.PlannedGoalCountDetails plannedGoalCountDetails = plannedGoalObj.countPlannedGoalByCaseID(
      plannedGoalCaseIDKey);

    // If there is no planned goal for the case id we need to insert a new
    // one.
    if (plannedGoalCountDetails.recordCount == 0) {

      // Create Planned Goal Service layer structs
      final curam.serviceplans.sl.struct.CreateServicePlanGoalDetails createServicePlanGoalDetails = new curam.serviceplans.sl.struct.CreateServicePlanGoalDetails();
      final CaseID caseID = new CaseID();

      // set the key
      caseID.caseID = key.key.caseID;
      // assign goalID of goal to the planned goal
      createServicePlanGoalDetails.dtls.goalID = details.dtls.goalID;

      // create a planned goal
      this.createServicePlanGoal(caseID, createServicePlanGoalDetails);
    } else {
      // otherwise update the current planned goal.
      plannedGoalObj.modifyGoalType(key.key, details.dtls);
    }

  }

  /**
   * Reads the goal for the service plan delivery.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_GOAL_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to modify
   * the service plan goal.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY# ERR_MODIFY_GOAL_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify
   * the service plan goal for this client.
   * @throws AppException
   * {@link BPOMAINTAINSERVICEPLANDELIVERY# ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_DEFINED}
   * - if the goals have not been defined for this type of service
   * plan. Please contact your system administrator.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadServicePlanGoalsDetails readServicePlanGoals(
    ReadServicePlanGoalsKey key) throws AppException, InformationalException {

    // Entity layer object variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // Entity layer object variables
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // Struct variables
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();
    curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.entity.struct.ServicePlanKey();
    final curam.core.struct.CaseID caseID = new curam.core.struct.CaseID();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // need to read the service plan case id and concern role id.
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // read the ServicePlanID
    servicePlanDeliveryKey.caseID = key.caseID;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // set the key to read concern role id
    caseHeaderKey.caseID = key.caseID;

    // read the Concern Role ID
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_GOAL_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_MODIFY_GOAL_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Set the caseID
    caseID.caseID = key.caseID;

    // Get the service plan ID to read the available goals for this service
    // plan
    servicePlanKey = servicePlanDeliveryObj.readServicePlanIDByCaseID(caseID);

    // Return struct
    final curam.serviceplans.sl.struct.ReadServicePlanGoalsDetails readServicePlanGoalsDetails = new curam.serviceplans.sl.struct.ReadServicePlanGoalsDetails();

    // Read available goals for the service plan.
    readServicePlanGoalsDetails.goalsList = servicePlanObj.searchAvailableGoalsForServicePlan(
      servicePlanKey);

    // Throw error when Goals have not been configured for service plans
    // type
    if (readServicePlanGoalsDetails.goalsList.dtls.size() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Return the list to the client.
    return readServicePlanGoalsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates the service plan goal.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @param details
   * Details of the service plan goal.
   *
   * @return Key containing the ID.
   */
  @Override
  public CreateServicePlanGoalKey createServicePlanGoal(
    curam.core.struct.CaseID key, CreateServicePlanGoalDetails details)
    throws AppException, InformationalException {

    // Entity layer object variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    final CreateServicePlanGoalKey createServicePlanGoalKey = new CreateServicePlanGoalKey();

    // set the CaseID
    details.dtls.caseID = key.caseID;
    // insert the record
    plannedGoalObj.insert(details.dtls);

    createServicePlanGoalKey.key.plannedGoalID = details.dtls.plannedGoalID;

    return createServicePlanGoalKey;
  }

  // BEGIN, CR00047428, CSH
  /**
   * This method is used to retrieve all service plan deliveries for a specified
   * concern role.
   *
   * @param key
   * The unique id for the concern role.
   *
   * @return The list of service plan delivery details for the concern.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanForConcernDetailsList listServicePlanDeliveryForConcernRole(RelationshipConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00301053, ZV
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = key.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00301053

    // Entity Object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // Return struct
    final curam.serviceplans.sl.struct.ServicePlanForConcernDetailsList servicePlanForConcernDetailsListSL = new curam.serviceplans.sl.struct.ServicePlanForConcernDetailsList();

    // BEGIN, CR00049123, CSH
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();
    ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();
    // END, CR00049123

    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Retrieve the service plan delivery cases for this concern role
    final curam.serviceplans.sl.entity.struct.ServicePlanForConcernDetailsList servicePlanForConcernDetailsList = servicePlanDeliveryObj.searchByConcernRoleID(
      key);

    // BEGIN, CR00049123, CSH
    // Iterate through the list of records to check security
    // and set the case case owner
    for (int i = 0; i < servicePlanForConcernDetailsList.dtls.size(); i++) {

      final ServicePlanForConcernDetails servicePlanForConcernDetails = new ServicePlanForConcernDetails();

      servicePlanForConcernDetails.dtls.assign(
        servicePlanForConcernDetailsList.dtls.item(i));

      // Set the case header key to be the current case id
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = servicePlanForConcernDetails.dtls.caseID;

      // Read the case owner
      final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
        caseHeaderKey);

      // BEGIN, CR00098462, CSH
      // If the type is a user
      if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

        // Set orgObjectReferenceName
        caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.userFullName;
      }
      // END, CR00098462

      // Set the case owner details
      servicePlanForConcernDetails.ownerDetails.assign(caseOwnerDetails);

      // Read the ServicePlanID
      servicePlanDeliveryKey.caseID = servicePlanForConcernDetailsList.dtls.item(i).caseID;

      // Set the security key
      spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = key.concernRoleID;
      spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;
      spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // Check service plan security
      servicePlanSecurityResult = servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);

      // If the result is false, it means the user does not have access to
      // read the service plan delivery details
      if (!servicePlanSecurityResult.result) {

        // Set the details to restricted
        servicePlanForConcernDetails.dtls.caseID = 0;
        servicePlanForConcernDetails.dtls.caseReference = CuramConst.gkRestricted;
        servicePlanForConcernDetails.dtls.caseStatus = CASESTATUS.RESTRICTEDACCESS;
        servicePlanForConcernDetails.dtls.servicePlanType = SERVICEPLANTYPE.RESTRICTEDACCESS;
        servicePlanForConcernDetails.dtls.startDate = curam.util.type.Date.kZeroDate;
        servicePlanForConcernDetails.ownerDetails.orgObjectReferenceName = CuramConst.gkRestricted;
        servicePlanForConcernDetails.ownerDetails.userFullName = CuramConst.gkRestricted;
      }

      servicePlanForConcernDetailsListSL.list.addRef(
        servicePlanForConcernDetails);
    }
    // END, CR00049123
    return servicePlanForConcernDetailsListSL;
    // END, CR00060051
  }

  // END, CR00047428

  // BEGIN, CR00051799, GBA
  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all service plans for which the current
   * user is the owner.
   *
   * @param key
   * The unique id for the current user.
   *
   * @return The list of service plans details for the current user.
   */
  @Override
  public ServicePlanForOwnerDetailsList listServicePlanDeliveryForOwner(
    ServicePlanOwnerKey key) throws AppException, InformationalException {

    // Entity Object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    // Return struct
    final ServicePlanForOwnerDetailsList servicePlanForOwnerDetailsList = new ServicePlanForOwnerDetailsList();

    // Retrieve the service plan delivery cases for this current user
    servicePlanForOwnerDetailsList.servPlanList = servicePlanDeliveryObj.searchByOwnerID(
      key.servicePlanOwnerKey);

    return servicePlanForOwnerDetailsList;
  }

  // END, CR00051799

  // BEGIN, CR00057255, PMD
  // ___________________________________________________________________________
  /**
   * Adds a template milestone to a service plan
   *
   * @param servicePlanDeliveryKey
   * service plan delivery case ID.
   * @param details
   * the plan template milestone details
   */
  @Override
  public void addTemplateMilestone(
    ServicePlanDeliveryKey servicePlanDeliveryKey,
    MilestoneTemplateDetails details) throws AppException,
      InformationalException {

    final MilestoneDeliveryDtls milestoneDeliveryDtls = new MilestoneDeliveryDtls();

    // Read the case start date
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;
    final CaseStartDate caseStartDate = CaseHeaderFactory.newInstance().readStartDate(
      caseHeaderKey);

    // Setup the milestone delivery details
    milestoneDeliveryDtls.milestoneConfigurationID = details.milestoneConfigurationID;
    milestoneDeliveryDtls.caseID = servicePlanDeliveryKey.key.caseID;
    milestoneDeliveryDtls.ownerUserName = TransactionInfo.getProgramUser();
    milestoneDeliveryDtls.status = MILESTONESTATUSCODE.NOTSTARTED;
    milestoneDeliveryDtls.expectedStartDate = caseStartDate.startDate.addDays(
      details.startAfter);

    // Need to include the current day in the calculation
    if (details.duration > 0) {

      details.duration = details.duration - 1;
    }

    milestoneDeliveryDtls.expectedEndDate = milestoneDeliveryDtls.expectedStartDate.addDays(
      details.duration);

    // Insert the milestone delivery
    MilestoneDeliveryFactory.newInstance().insert(milestoneDeliveryDtls);

    // Create the SPMilestoneDeliveryLink Details
    final SPMilestoneDeliveryLinkDtls spMilestoneDeliveryLinkDtls = new SPMilestoneDeliveryLinkDtls();

    spMilestoneDeliveryLinkDtls.milestoneDeliveryID = milestoneDeliveryDtls.milestoneDeliveryID;
    spMilestoneDeliveryLinkDtls.plannedGroupID = details.linkDtls.plannedGroupID;
    spMilestoneDeliveryLinkDtls.plannedSubGoalID = details.linkDtls.plannedSubGoalID;

    // Insert the SPMilestoneDeliveryLink
    SPMilestoneDeliveryLinkFactory.newInstance().insert(
      spMilestoneDeliveryLinkDtls);
  }

  // END, CR00057255

  // BEGIN, CR00161962, KY
  /**
   * Method to get the list of approval criteria for the planned item
   *
   * @param PlannedItemIDKey
   * planned item key
   * @return PlannedItemApprovalCriteriaLinkDetailsList list of approval
   * criteria
   */
  @Override
  public PlannedItemApprovalCriteriaLinkDetailsList getListOfApprovalCriteriaForPlannedItem(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // Entity object to read the list of approval criteria
    final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

    // return struct
    final PlannedItemApprovalCriteriaLinkDetailsList plannedItemApprovalCriteriaLinkDetailsList = new PlannedItemApprovalCriteriaLinkDetailsList();

    // key to read the list of approval criteria for planned item
    final PlannedItemApprovalCriteriaLinkReadMultiKey criteriaLinkReadMultiKey = new PlannedItemApprovalCriteriaLinkReadMultiKey();

    // populate the key
    criteriaLinkReadMultiKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // invoke the method to read the list of approval criteria details
    plannedItemApprovalCriteriaLinkDetailsList.assign(
      plannedItemApprovalCriteriaObj.searchAllApprovalCriteriaForPlannedItemID(
        criteriaLinkReadMultiKey));

    // return the list retrieved
    return plannedItemApprovalCriteriaLinkDetailsList;

  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  // __________________________________________________________________________
  /**
   * Gets all the Active Service Plan Deliveries for the given Service Plan Id
   *
   * @param ServicePlanKey
   * the id of the Service Plan
   * @return ServicePlanDeliveryAndStatusDtlsList the list of active Service
   * Plan Deliveries
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ServicePlanDeliveryAndStatusDtlsList getActiveServicePlanDeliveriesByServicePlanID(
    ServicePlanKey servicePlanKey) throws AppException,
      InformationalException {

    final ServicePlanDeliveryAndStatusDtlsList dtls = new ServicePlanDeliveryAndStatusDtlsList();
    // get all the SPDs by SP id first
    final ServicePlanDeliveryDtlsList spdList = ServicePlanDeliveryFactory.newInstance().searchByServicePlanID(
      servicePlanKey.key);
    // loop through the records, get the status via the Case API
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseKey = new CaseHeaderKey();
    final int size = spdList.dtls.size();

    for (int i = 0; i < size; i++) {
      final ServicePlanDeliveryDtls spdDtls = spdList.dtls.item(i);

      caseKey.caseID = spdDtls.caseID;
      final CaseHeaderDtls caseDtls = caseHeaderObj.read(caseKey);

      // only proceed if the status is ...
      if (caseDtls.statusCode.equals(CASESTATUS.ACTIVE)) {
        final ServicePlanDeliveryAndStatusDtls spdAndStatusDtls = new ServicePlanDeliveryAndStatusDtls();

        spdAndStatusDtls.spdDtls = spdDtls;
        spdAndStatusDtls.caseStatus = caseDtls.statusCode;
        dtls.listDtls.addRef(spdAndStatusDtls);
      }
    }
    return dtls;
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  // __________________________________________________________________________
  /**
   * gets the actual and estimated costs for the Service Plan Delivery based
   * on the lower level costs from the planned items
   *
   * @param ServicePlanDeliveryKey
   * the id of the Service Plan Delivery
   * @return ServicePlanDeliveryCostDtls the total cost figures for the
   * Service Plan Delivery
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ServicePlanDeliveryCostDtls getServicePlanDeliveryCosts(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    final ServicePlanDeliveryCostDtls spdCosts = new ServicePlanDeliveryCostDtls();
    // get all the planned items using method readPlannedItems
    // iterate through them and record the actual costs and estimated costs
    final PlannedItemDtlsList plannedItems = readPlannedItems(key);
    final int plannedItemsDtlsSize = plannedItems.dtls.size();

    for (int i = 0; i < plannedItemsDtlsSize; i++) {
      final PlannedItemDtls plannedItem = plannedItems.dtls.item(i);
      final Money actualCost = new Money(
        plannedItem.actualCost.getValue() + spdCosts.actualCost.getValue());

      spdCosts.actualCost = actualCost;
      final Money estimatedCost = new Money(
        plannedItem.estimatedCost.getValue()
          + spdCosts.estimatedCost.getValue());

      spdCosts.estimatedCost = estimatedCost;
    }
    return spdCosts;
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  // __________________________________________________________________________
  /**
   * finds all the Planned Items contained in this Service Plan Delivery
   *
   * @param ServicePlanDeliveryKey
   * the id of the Service Plan Delivery
   * @return PlannedItemDtlsList the list of Planned Items
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public PlannedItemDtlsList readPlannedItems(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    final PlannedItemDtlsList returnList = new PlannedItemDtlsList();
    // loop through the Planned Goals, PlannedSubgoals to get to the Planned
    // Items
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoal = PlannedSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItem = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    final PlannedSubGoalCaseIDKey plannedSubGoalCaseKey = new PlannedSubGoalCaseIDKey();

    plannedSubGoalCaseKey.caseID = key.key.caseID;
    final PlannedSubGoalDetailsForServicePlanList plannedSubgoals = plannedSubGoal.searchByCaseID(
      plannedSubGoalCaseKey);

    final PlannedSubGoalKey plannedSubKey = new PlannedSubGoalKey();

    for (int i = 0; i < plannedSubgoals.dtls.size(); i++) {
      final PlannedSubGoalDetailsForServicePlan plannedSubGoalDtls = plannedSubgoals.dtls.item(
        i);

      plannedSubKey.plannedSubGoalID = plannedSubGoalDtls.id;
      final PlannedItemDtlsList plannedItems = plannedItem.searchByPlannedSubGoalID(
        plannedSubKey);
      final int plannedItemsDtlsSize = plannedItems.dtls.size();

      for (int j = 0; j < plannedItemsDtlsSize; j++) {
        final PlannedItemDtls p = plannedItems.dtls.item(j);

        returnList.dtls.addRef(p);
      }
    }

    return returnList;
  }

  // BEGIN, CR00145825 , SK
  // ___________________________________________________________________________
  /**
   * Return service plan status for a specific service plan.
   *
   * @param caseHeaderKey service plan case ID.
   * @return caseStatusCode Status of service plan.
   * @throws AppException, InformationalException
   */
  @Override
  public CaseStatusCode getServicePlanStatus(CaseHeaderKey caseHeaderKey)
    throws AppException, InformationalException {

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(
      caseHeaderKey);

    return caseStatusCode;
  }

  // END, CR00145825

  // BEGIN, CR00146960 ,DJ
  // ___________________________________________________________________________

  /**
   * Lists all service plans for the specified integrated case.
   *
   * @param key Contains integrated case ID.
   * @return List of service plan details.
   *
   * @throws AppException, InformationalException
   */
  @Override
  public ListServicePlanForIC listByICCase(ServicePlanIntegratedCaseKey key)
    throws AppException, InformationalException {

    final ListServicePlanForIC listServicePlanForIC = new ListServicePlanForIC();

    // ServicePlanDelivery entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.SearchByIntegratedCaseAndParticipantTypeKey searchByIntegratedCaseAndParticipantTypeKey = new curam.serviceplans.sl.entity.struct.SearchByIntegratedCaseAndParticipantTypeKey();

    // PlanndedGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey readGoalNameByCaseIDKey = new curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey();
    curam.serviceplans.sl.entity.struct.GoalNameDetails goalNameDetails;

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.servicePlanIntegratedCaseKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    // if the result is false, throw an exception
    if (!dataBasedSecurityResult.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_CASE_SECURITY_CHECK_FAILED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00227042

    // an element of the returned list
    curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDeliveryAndParticipantSummaryDetails;
    curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantDetails servicePlanDeliveryAndParticipantDetails;

    // set the key
    searchByIntegratedCaseAndParticipantTypeKey.integratedCaseID = key.servicePlanIntegratedCaseKey.caseID;
    searchByIntegratedCaseAndParticipantTypeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT;
    searchByIntegratedCaseAndParticipantTypeKey.recordStatus = RECORDSTATUS.NORMAL;

    // read service plan details list
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryAndParticipantSummaryDetailsList servicePlanDeliveryAndParticipantDetailsList = servicePlanDeliveryObj.searchByIntegratedCaseID(
      searchByIntegratedCaseAndParticipantTypeKey);

    for (int i = 0; i
      < servicePlanDeliveryAndParticipantDetailsList.dtls.size(); i++) {

      // create an element of the returned list
      servicePlanDeliveryAndParticipantDetails = new curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantDetails();
      servicePlanDeliveryAndParticipantSummaryDetails = new curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails();

      // assign service plan delivery and participant details
      servicePlanDeliveryAndParticipantSummaryDetails.assign(
        servicePlanDeliveryAndParticipantDetailsList.dtls.item(i));
      servicePlanDeliveryAndParticipantDetails.assign(
        servicePlanDeliveryAndParticipantSummaryDetails);

      // set the key
      readGoalNameByCaseIDKey.caseID = servicePlanDeliveryAndParticipantDetailsList.dtls.item(i).caseID;

      // read goal name, if the goal is set for the service plan
      try {
        goalNameDetails = plannedGoalObj.readNameByCaseID(
          readGoalNameByCaseIDKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        goalNameDetails = null;
        servicePlanDeliveryAndParticipantDetails.goalInd = true;
      }

      // assign service plan name details
      if (goalNameDetails != null) {
        servicePlanDeliveryAndParticipantSummaryDetails.assign(goalNameDetails);
        // BEGIN, CR00227988, PB
        servicePlanDeliveryAndParticipantDetails.name = servicePlanDeliveryAndParticipantSummaryDetails.name;
        // END, CR00227988

      }

      // add details to the returned list
      listServicePlanForIC.dtls.addRef(servicePlanDeliveryAndParticipantDetails);
    }
    return listServicePlanForIC;
  }

  // END, CR00146960

  // BEGIN, CR00227859, PM
  /**
   * Checks Maintain security rights of a user for a particular case.
   *
   * @param CaseID
   * To check if the user has access to the case.
   *
   * @throws AppException
   * , InformationalException
   */
  protected void checkMaintainSecurity(long caseID) throws AppException,
      InformationalException {

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
  }

  /**
   * Checks Read security rights of a user for a particular case.
   *
   * @param CaseID
   * To check if the user has access to the case.
   *
   * @throws AppException
   * , InformationalException
   */
  protected void checkReadSecurity(long caseID) throws AppException,
      InformationalException {

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
  }

  // END, CR00227859

  // BEGIN, CR00234272, TV
  // ___________________________________________________________________________
  /**
   * Validates service plan delivery closing.
   *
   * @param key
   * Contains service plan delivery unique ID
   * @param details
   * Contains closing reason code.
   */
  @Override
  public void validateCloseInfo(ServicePlanDeliveryKey key,
    ServicePlanDeliveryClosureDetails details, boolean isSingleSPContext)
    throws AppException, InformationalException {

    // need the case ref for potential Service Plan Group exceptions
    final CaseSearchKey csKey = new CaseSearchKey();

    csKey.caseID = key.key.caseID;
    final CaseReference caseRef = CaseHeaderFactory.newInstance().readCaseReferenceByCaseID(
      csKey);

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // PlannedGoal manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey plannedGoalCaseIDKey = new curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey();
    curam.serviceplans.sl.entity.struct.ReadOutcomeAchievedDetails readOutcomeAchievedDetails;

    // reason code must be specified
    if (details.spClosureNoteReasonDateDetails.reasonCode.length() == 0) {
      if (isSingleSPContext) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSERVICEPLANDELIVERY.ERR_CLOSURE_REASON_CODE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      } else {
        final AppException ae = new AppException(
          BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_SERVICEPLAN_CLOSE_REASON_MISSING);

        ae.arg(caseRef.caseReference);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }
    }

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        if (isSingleSPContext) {
          throw new AppException(
            BPOSERVICEPLANDELIVERY.ERR_CLOSE_SECURITY_CHECK_FAILED);
        } else {
          final AppException ae = new AppException(
            BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_SERVICEPLAN_CLOSE_PRIVILEGES_FAILURE);

          ae.arg(caseRef.caseReference);
          throw ae;
        }
      } else {
        throw e;
      }
    }

    // read current status
    currentCaseStatusKey.caseID = key.key.caseID;

    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // service plan delivery must not be closed
    if (caseStatusDtls.statusCode.equals(CASESTATUS.CLOSED)) {

      if (isSingleSPContext) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANDELIVERY.ERR_SERVICE_PLAN_ALREADY_CLOSED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        final AppException ae = new AppException(
          BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_SERVICEPLAN_CLOSE_CLOSED);

        ae.arg(caseRef.caseReference);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }
    }

    // if service plan delivery is active then an outcome must be
    // specified for the service plan goal
    if (caseStatusDtls.statusCode.equals(CASESTATUS.ACTIVE)) {

      plannedGoalCaseIDKey.caseID = key.key.caseID;

      // read outcome achieved details
      readOutcomeAchievedDetails = plannedGoalObj.readOutcomeAchievedByCaseID(
        plannedGoalCaseIDKey);

      if (readOutcomeAchievedDetails != null
        && readOutcomeAchievedDetails.outcomeAchieved.length() == 0) {

        if (isSingleSPContext) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOSERVICEPLANDELIVERY.ERR_GOAL_OUTCOME_NOT_SET),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        } else {
          final AppException ae = new AppException(
            BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_SERVICEPLAN_CLOSE_OUTCOME_NOTDEFINED);

          ae.arg(caseRef.caseReference);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            ae,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        }

      }

    }
  }
  // END, CR00234272

}
