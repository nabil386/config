/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.serviceplans.sl.entity.struct.CancelServicePlanDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.entity.struct.ServicePlanStatus;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeAndStatusKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeCountDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * A Service Plan is used to describe a plan by which a client will change his
 * situation. The plan will contain goals which the client will strive to
 * achieve, each goal consists of a number of sub goals and the sub goal
 * contain planItems that the client must perform in order to complete their
 * sub goal.
 *
 * For example, a service plan might exist to get the client back to work.
 * The goal is to return to work, one sub goal is to improve his interviewing
 * skills. An appropriate plan item might be to buy a suit.
 */
public abstract class ServicePlan extends curam.serviceplans.sl.entity.base.ServicePlan {

  // ___________________________________________________________________________
  /**
   * Performs validation of the data being inserted.
   *
   * @param dtls the data
   */
  @Override
  protected void preinsert(ServicePlanDtls dtls) throws AppException,
      InformationalException {

    // validate service plan type
    final ServicePlanTypeStruct servicePlanTypeStruct = new ServicePlanTypeStruct();

    servicePlanTypeStruct.servicePlanType = dtls.servicePlanType;

    validateDetails(servicePlanTypeStruct);
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the cancel operation. This involves ensuring that
   * the service plan has not been previously canceled.
   *
   * @param cancelKey the key of the service plan
   * @param details the new status being applied to the service plan
   */
  @Override
  protected void precancel(CancelServicePlanDetails cancelKey,
    ServicePlanStatus details) throws AppException, InformationalException {

    // create structures to read service plan details
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    ServicePlanStatus servicePlanStatus;

    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.entity.struct.ServicePlanKey();

    // read service plan details from database
    servicePlanKey.servicePlanID = cancelKey.servicePlanID;

    servicePlanStatus = servicePlanObj.readStatus(servicePlanKey);

    // service plan should not be already canceled
    if (servicePlanStatus.recordStatus.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_ALREADY_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Checks that the data being inserted/modified contains valid fields.
   *
   * @param type the data being inserted/modified
   */
  @Override
  public void validateDetails(ServicePlanTypeStruct type)
    throws AppException, InformationalException {

    // service plan type should be selected
    if (type.servicePlanType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_BLANK_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // check if service plan type is unique
    final ServicePlanTypeAndStatusKey servicePlanTypeAndStatusKey = new ServicePlanTypeAndStatusKey();

    servicePlanTypeAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    servicePlanTypeAndStatusKey.servicePlanType = type.servicePlanType;

    ServicePlanTypeCountDetails servicePlanTypeCountDetails;

    servicePlanTypeCountDetails = countByTypeAndStatus(
      servicePlanTypeAndStatusKey);

    if (servicePlanTypeCountDetails.servicePlanTypeCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLAN.ERR_SERVICEPLAN_XRV_SERVICE_PLAN_TYPE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Called before the modification operation.
   *
   * @param key The key of service plan being modified
   * @param dtls The new details for the service plan
   */
  @Override
  protected void premodify(ServicePlanKey key, ServicePlanDtls dtls)
    throws AppException, InformationalException {

    // Service Plan type must be unique
    ServicePlanTypeStruct servicePlanTypeStruct;

    servicePlanTypeStruct = readType(key);

    // validate service plan type if it was changed
    if (!servicePlanTypeStruct.servicePlanType.equals(dtls.servicePlanType)) {
      validateDetails(servicePlanTypeStruct);
    }

    validateServicePlanStatus(key);

  }

  // ___________________________________________________________________________
  /**
   * validates service plan status before making any modifications to it.
   *
   * @param key service plan key
   */
  @Override
  public void validateServicePlanStatus(ServicePlanKey key)
    throws AppException, InformationalException {

    // create structures to read service plan details

    // read service plan status
    final ServicePlanStatus servicePlanStatus = readStatus(key);

    // service plan should not be already canceled
    if (servicePlanStatus.recordStatus.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_MODIFY_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

}
