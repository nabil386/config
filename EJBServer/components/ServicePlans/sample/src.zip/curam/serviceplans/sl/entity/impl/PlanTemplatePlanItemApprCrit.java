/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.APPROVALCRITERIAWHEN;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.BPOAPPROVALCRITERIA;
import curam.message.BPOPLANTEMPLATEPLANITEMAPPPROVALCRITERIA;
import curam.serviceplans.sl.entity.fact.PlanTemplateFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplate;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTable;
import curam.util.type.StringList;


/**
 * Implementation for the PlanTemplatePlanItemApprCrit entity.
 */
public abstract class PlanTemplatePlanItemApprCrit extends curam.serviceplans.sl.entity.base.PlanTemplatePlanItemApprCrit {

  /**
   * Validate before inserting record.
   *
   * @param details
   * Generated details struct to validate.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  protected void preinsert(final PlanTemplatePlanItemApprCritDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  /**
   * Validate before modifying record.
   *
   * @param details
   * Generated details struct to validate.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  protected void premodify(PlanTemplatePlanItemApprCritKey key,
    PlanTemplatePlanItemApprCritDtls details) throws AppException,
      InformationalException {

    validateModify(key, details);

  }

  /**
   * Validate data before modifying into the database.
   *
   * @param details - details of the entity to be validated
   * @param key - key of the entity that needs to be validated.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public void validateModify(PlanTemplatePlanItemApprCritKey key,
    PlanTemplatePlanItemApprCritDtls dtls) throws AppException,
      InformationalException {

    final PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

    planTemplatePlanItemKey.planTemplatePlanItemID = dtls.planTemplatePlanItemID;

    // Plan Template entity
    final PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // check if plan template is canceled
    final PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplatePlanItemID(
      planTemplatePlanItemKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEMAPPPROVALCRITERIA.ERR_PT_PI_APPROVAL_CRITERIA_MODIFY_TO_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Service Plan Template Plan Item Approval Criteria ID must be entered
    if (key.planTemplatePlanItemApprCritID == CuramConst.gkZero) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_MODIFY_APPROVAL_CRITERIA_RECORD_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
    // Check all details
    validateDetails(dtls);

  }

  /**
   * Validate before deleting record.
   *
   * @param key
   * struct to validate.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  protected void preremove(PlanTemplatePlanItemApprCritKey key)
    throws AppException, InformationalException {

    validateRemove(key);

  }

  /**
   * Validate data before deleting from the database.
   *
   * @param key - key of the entity that needs to be validated.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public void validateRemove(PlanTemplatePlanItemApprCritKey key)
    throws AppException, InformationalException {

    // Plan Template entity
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    // check if plan template is canceled
    final PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplatePlanItemApprCritID(
      key);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEMAPPPROVALCRITERIA.ERR_PT_PI_APPROVAL_CRITERIA_DELETE_FROM_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Validate details for both insert and modify.
   *
   * @param dtls
   * Generated details struct to validate
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public void validateDetails(PlanTemplatePlanItemApprCritDtls details)
    throws AppException, InformationalException {

    final StringList whenCodes = CodeTable.getDistinctCodesForAllLanguages(
      APPROVALCRITERIAWHEN.TABLENAME);

    if (whenCodes.contains(details.occursWhen) == false) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_OCCURS_WHEN_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    if (details.priority <= CuramConst.gkZero) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_PRIORITY_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }

  /**
   * Validate date before inserting into the database.
   *
   * @param details - details of the entity to be validated
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  @Override
  public void validateInsert(PlanTemplatePlanItemApprCritDtls details)
    throws AppException, InformationalException {

    final PlanTemplatePlanItemKey key = new PlanTemplatePlanItemKey();

    key.planTemplatePlanItemID = details.planTemplatePlanItemID;

    // Plan Template entity
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    // check if plan template is canceled
    final PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplatePlanItemID(
      key);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEMAPPPROVALCRITERIA.ERR_PT_PI_APPROVAL_CRITERIA_ADD_TO_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.planItemApprovalCriteriaLinkID == CuramConst.gkZero) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_NAME_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
  }

}
