/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.APPROVALCRITERIAWHEN;
import curam.codetable.RECORDSTATUS;
import curam.message.BPOAPPROVALCRITERIA;
import curam.serviceplans.sl.entity.fact.PlanItemApprovalCriteriaLinkFactory;
import curam.serviceplans.sl.entity.intf.PlanItemApprovalCriteriaLink;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaCountDetails;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaDtls;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaKey;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaNameAndStatusDetails;
import curam.serviceplans.sl.entity.struct.CancelApprovalCriteriaDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkSearchByApprovalCriteriaID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTable;
import curam.util.type.StringList;


/**
 * Implementation for the ApprovalCriteria entity.
 */
public class ApprovalCriteria extends curam.serviceplans.sl.entity.base.ApprovalCriteria {

  /**
   * Validate the soft delete of an entry.
   *
   * @param key
   * Contains the unique ID of the entry to cancel.
   * @param details
   * Contains the versionNo for the record to cancel
   * @throws AppException, InformationalException
   */
  @Override
  protected void precancel(final ApprovalCriteriaKey key,
    final CancelApprovalCriteriaDetails details) throws AppException,
      InformationalException {

    validateCancel(key);
  }

  /**
   * Validate before inserting record.
   *
   * @param details
   * Generated details struct to validate.
   * @throws AppException, InformationalException
   */
  @Override
  protected void preinsert(final ApprovalCriteriaDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
  }

  /**
   * Validate before a modify.
   *
   * @param key
   * Contains the unique ID of the record to modify
   * @param details
   * Generated details struct to validate.
   * @throws AppException, InformationalException
   */
  @Override
  protected void premodify(final ApprovalCriteriaKey key,
    final ApprovalCriteriaDtls details) throws AppException,
      InformationalException {

    validateModify(key, details);
  }

  /**
   * Validate details for both insert and modify.
   *
   * @param details
   * Contains the approval criteria details to validate
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateDetails(final ApprovalCriteriaDtls details)
    throws AppException, InformationalException {

    if (details.criteriaName.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_NAME_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    if (details.workflowEvent.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_WORKFLOW_EVENT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    final StringList whenCodes = CodeTable.getDistinctCodesForAllLanguages(
      APPROVALCRITERIAWHEN.TABLENAME);

    if (!whenCodes.contains(details.occursWhen)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_OCCURS_WHEN_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.priority <= 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_PRIORITY_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    final StringList recordCodes = CodeTable.getDistinctCodesForAllLanguages(
      RECORDSTATUS.TABLENAME);

    if (recordCodes.contains(details.recordStatus) == false) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_RECORD_STATUS_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Method ensures that no existing approval criteria records already exist
   * with the same criteriaName.
   *
   * @param details
   * ApprovalCriteriaDtls - details of the approval criteria being
   * added
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateDuplicates(ApprovalCriteriaDtls details)
    throws AppException, InformationalException {

    // If there is an ID set then this is a modify and we may not need to check
    // for duplicates
    if (details.approvalCriteriaID != 0) {
      ApprovalCriteriaDtls readDtls = new ApprovalCriteriaDtls();
      final ApprovalCriteriaKey readKey = new ApprovalCriteriaKey();

      readKey.approvalCriteriaID = details.approvalCriteriaID;

      readDtls = read(readKey);

      // No need to check for duplicates when there has been no change of name.
      if (readDtls.criteriaName.equals(details.criteriaName)) {
        return;
      }
    }

    // Create count details and return structs
    final ApprovalCriteriaNameAndStatusDetails acNameAndStatusDtls = new ApprovalCriteriaNameAndStatusDetails();
    ApprovalCriteriaCountDetails acCountDetails = new ApprovalCriteriaCountDetails();

    // Set attributes
    acNameAndStatusDtls.criteriaName = details.criteriaName;
    acNameAndStatusDtls.recordStatus = RECORDSTATUS.NORMAL;

    // Obtain a count
    acCountDetails = countByCriteriaNameAndStatus(acNameAndStatusDtls);

    // Do any active records already have that name?
    if (acCountDetails.numApprovalCriteria > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_APPROVAL_CRITERIA_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  /**
   * Validate the data passed into the cancel method.
   *
   * @param key
   * Contains the unique ID of the record to cancel
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateCancel(ApprovalCriteriaKey key) throws AppException,
      InformationalException {

    // Approval Criteria ID must be entered
    if (key.approvalCriteriaID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_MODIFY_APPROVAL_CRITERIA_RECORD_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    ApprovalCriteriaDtls readDtls = new ApprovalCriteriaDtls();

    readDtls = read(key);

    if (readDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_ALREADY_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    final PlanItemApprovalCriteriaLinkSearchByApprovalCriteriaID searchKey = new PlanItemApprovalCriteriaLinkSearchByApprovalCriteriaID();

    // Assign key values.
    searchKey.approvalCriteriaID = key.approvalCriteriaID;

    final PlanItemApprovalCriteriaLink piAppLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    final PlanItemApprovalCriteriaLinkDtlsList piLinkList = piAppLinkObj.searchByApprovalCriteriaID(
      searchKey);

    // Check for any active links
    final int size = piLinkList.dtls.size();

    for (int i = 0; i < size; i++) {
      if (piLinkList.dtls.item(i).recordStatus.equals(RECORDSTATUS.NORMAL)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOAPPROVALCRITERIA.ERR_APPROVAL_CRITERIA_FV_ACTIVE_PLAN_ITEMS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

  }

  /**
   * Validate date before inserting into the database.
   *
   * @param details
   * Approval Criteria details
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateInsert(ApprovalCriteriaDtls details)
    throws AppException, InformationalException {

    // Check all details
    validateDetails(details);

    // Check for duplicates
    validateDuplicates(details);
  }

  /**
   * Validate details before performing a modify operation.
   *
   * @param key
   * Approval Criteria ID
   * @param details
   * Approval Criteria details
   * @throws AppException, InformationalException
   */
  @Override
  protected void validateModify(ApprovalCriteriaKey key,
    ApprovalCriteriaDtls details) throws AppException, InformationalException {

    // Read the current details
    final ApprovalCriteriaDtls readDetails = this.read(key);

    if (readDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_MODIFY_CANCELLED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Approval Criteria ID must be entered
    if (key.approvalCriteriaID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_MODIFY_APPROVAL_CRITERIA_RECORD_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    validateDetails(details);

    // Ensure no approval criteria records exist with the same name
    validateDuplicates(details);
  }
}
