/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.SERVICEPLANGROUPNAME;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.struct.MilestoneDeliveryDetails;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceAndICTypeDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOINTEGRATEDSERVICEPLAN;
import curam.message.BPOSERVICEPLANGROUP;
import curam.message.BPOSERVICEPLANGROUPDELIVERY;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.intf.ServicePlanGroup;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.SPGDeliveryGroupAndCaseKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.fact.MaintainSPGDeliveryLinkFactory;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupDeliveryFactory;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupFactory;
import curam.serviceplans.sl.fact.MilestoneFactory;
import curam.serviceplans.sl.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.fact.ServicePlanStatementFactory;
import curam.serviceplans.sl.intf.MaintainServicePlanGroup;
import curam.serviceplans.sl.intf.Milestone;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.serviceplans.sl.intf.ServicePlanStatement;
import curam.serviceplans.sl.struct.IntegratedServicePlanKey;
import curam.serviceplans.sl.struct.MilestoneDeliveryDetailsList;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndGroupKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryClosureDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryIDDtls;
import curam.serviceplans.sl.struct.ServicePlanDeliveryIDDtlsList;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryReadDetails;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryAndActiveIndKey;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryHomeDtls;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryServicePlanDeliveryDtls;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryServicePlanDeliveryDtlsList;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryTabDetails;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryDetails1;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.message.CatEntry;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Money;
import curam.util.type.UniqueID;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


/**
 * SL API to maintain the service plan group functionality.
 */
public class MaintainServicePlanGroupDelivery extends curam.serviceplans.sl.base.MaintainServicePlanGroupDelivery {

  /**
   * Add injection for using the new CaseTransactionLog API.
   */
  public MaintainServicePlanGroupDelivery() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ____________________________________________________________________________
  @Inject

  /**
   * caseTransactionLogProvider.
   */
  private Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // ____________________________________________________________________________
  /**
   * This method is used to get all the milestones for the service plan group
   * delivery.
   *
   * @param caseIDKey
   * CaseIDKey
   * @return list of milestone deliveries
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public MilestoneDeliveryDetailsList getAllMilestones(
    final CaseIDKey caseIDKey) throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final SPGDeliveryLink spgDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();
    final Milestone mileStoneObj = MilestoneFactory.newInstance();
    final CaseHeaderKey servicePlanCaseIDKey = new CaseHeaderKey();
    final SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

    // Get the list of service plan deliveries for the service plan group
    // delivery
    spgDeliveryKey.servicePlanGroupDeliveryId = caseIDKey.caseID;
    final SPGDeliveryLinkDtlsList spgDeliveryLinkDtlsList = spgDeliveryLinkObj.searchServicePlanDeliveriesByServicePlanGroupDeliveryId(
      spgDeliveryKey);

    // Iterate over all the service plan deliveries and fetch the list of all
    // the milestones
    final MilestoneDeliveryDetailsList returnStruct = new MilestoneDeliveryDetailsList();
    final int size = spgDeliveryLinkDtlsList.dtls.size();

    for (int spdListIter = 0; spdListIter < size; spdListIter++) {
      servicePlanCaseIDKey.caseID = spgDeliveryLinkDtlsList.dtls.item(spdListIter).caseID;
      final MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = mileStoneObj.listAllMilestoneDeliveriesForServicePlan(
        servicePlanCaseIDKey);

      // Add the case reference details for the service plan delivery
      setCaseIDAndCaseReference(milestoneDeliveryDetailsList,
        servicePlanCaseIDKey.caseID);

      consolidateMilestoneList(returnStruct, milestoneDeliveryDetailsList);
    }

    return returnStruct;
  }

  // ____________________________________________________________________________
  /**
   * This method is used to consolidate the list of the milestones into the
   * final return struct.
   *
   * @param returnStruct list of milestone deliveries after consolidation
   *
   * @param milestoneList list of milestone deliveries to consolidate
   */
  protected void consolidateMilestoneList(
    MilestoneDeliveryDetailsList returnStruct,
    MilestoneDeliveryDetailsList milestoneList) {

    returnStruct.spMilestoneDetailsList.dtlsList.dtls.addAll(
      milestoneList.spMilestoneDetailsList.dtlsList.dtls);
  }

  // ____________________________________________________________________________
  /**
   * This method is used to get all the incomplete list of milestone for the
   * service plan group delivery.
   *
   * @param caseIDKey identifies the case ID
   *
   * @return List of incomplete milestones for the ServicePlan Group Delivery
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public MilestoneDeliveryDetailsList getIncompleteMilestones(
    CaseIDKey caseIDKey) throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final SPGDeliveryLink spgDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();
    final Milestone mileStoneObj = MilestoneFactory.newInstance();
    final CaseHeaderKey servicePlanCaseIDKey = new CaseHeaderKey();
    final SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

    // Get the list of service plan deliveries for the service plan group
    // delivery
    spgDeliveryKey.servicePlanGroupDeliveryId = caseIDKey.caseID;
    final SPGDeliveryLinkDtlsList spgDeliveryLinkDtlsList = spgDeliveryLinkObj.searchServicePlanDeliveriesByServicePlanGroupDeliveryId(
      spgDeliveryKey);

    // Iterate over all the service plan deliveries and fetch the list of all
    // the milestones
    final MilestoneDeliveryDetailsList returnStruct = new MilestoneDeliveryDetailsList();
    final int spgDeliveryLinkDtlsListSize = spgDeliveryLinkDtlsList.dtls.size();

    for (int spdListIter = 0; spdListIter < spgDeliveryLinkDtlsListSize; spdListIter++) {

      servicePlanCaseIDKey.caseID = spgDeliveryLinkDtlsList.dtls.item(spdListIter).caseID;
      final MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = mileStoneObj.listUncompletedMilestonesForServicePlan(
        servicePlanCaseIDKey);

      // Add the case reference details for the service plan delivery
      setCaseIDAndCaseReference(milestoneDeliveryDetailsList,
        servicePlanCaseIDKey.caseID);
      consolidateMilestoneList(returnStruct, milestoneDeliveryDetailsList);

    }
    return returnStruct;
  }

  // ____________________________________________________________________________
  /**
   * This method is used to set the case id and case reference to the milestone
   * list.
   *
   * @param milestoneDeliveryDetailsList list of milestone deliveries to set the
   * case ID and case reference
   *
   * @param caseID holds case ID to set to the milestone deliveries details
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  protected void setCaseIDAndCaseReference(
    MilestoneDeliveryDetailsList milestoneDeliveryDetailsList, long caseID)
    throws AppException, InformationalException {

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseID;
    final CaseReferenceAndICTypeDetails caseReferenceAndICTypeDetails = caseHeaderObj.readCaseReferenceAndICType(
      caseKey);

    final IntegratedCaseReferenceKey caseReferenceKey = new IntegratedCaseReferenceKey();

    caseReferenceKey.caseReference = caseReferenceAndICTypeDetails.caseReference;
    caseReferenceKey.integratedCaseID = caseKey.caseID;
    MilestoneDeliveryDetails milestoneDeliveryDetails = new MilestoneDeliveryDetails();

    final int size = milestoneDeliveryDetailsList.spMilestoneDetailsList.dtlsList.dtls.size();

    for (int milestoneListIter = 0; milestoneListIter < size; milestoneListIter++) {
      milestoneDeliveryDetails = milestoneDeliveryDetailsList.spMilestoneDetailsList.dtlsList.dtls.item(
        milestoneListIter);
      milestoneDeliveryDetails.caseDtls.assign(caseReferenceKey);
    }

  }

  // ____________________________________________________________________________
  /**
   * Closes the Service Plan Deliveries within the Service Plan Group Delivery
   *
   * @param SPGDeliveryKey
   * ID of the Service Plan Group Delivery
   * @param ServicePlanDeliveryClosureDetails
   * details of the ServicePlan delivery closure
   *
   * @return Any informational messages resulting
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public InformationalMsgDtlsList close(SPGDeliveryKey key,
    ServicePlanDeliveryClosureDetails closureDetails,
    boolean isSingleSPContext) throws AppException, InformationalException {

    final InformationalMsgDtlsList msgsList = new InformationalMsgDtlsList();

    // hold onto any exceptions being thrown each time the
    // underlying close method is invoked, so that they are all
    // presented to the client in one hit
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // get a handle on the current Transaction, for access to any exceptions
    final InformationalManager im = TransactionInfo.getInformationalManager();

    // first get all the related Service Plan Delivery Ids
    final ServicePlanDeliveryIDDtlsList spdIdsList = getServicePlanDeliveryIDs(
      key);

    // list of the Service Plan Deliveries that we will eventually go close
    final List<ServicePlanDeliveryKey> closeableServicePlans = new ArrayList<ServicePlanDeliveryKey>();

    ServicePlanDeliveryIDDtls spdId;
    final int spdIdsListSize = spdIdsList.dtls.size();

    for (int i = 0; i < spdIdsListSize; i++) {
      spdId = spdIdsList.dtls.item(i);
      final ServicePlanDeliveryKey spdKey = new ServicePlanDeliveryKey();

      spdKey.key.caseID = spdId.servicePlanDeliveryID;

      // try validating the close request
      try {
        // BEGIN, CR00234272, TV
        servicePlanDeliveryObj.validateCloseInfo(spdKey, closureDetails, false);
        // END, CR00234272
        // no issues? Add to the list to be closed
        closeableServicePlans.add(spdKey);
      } catch (final AppException ae) {
        im.addInformationalMsg(ae, CuramConst.gkEmpty, InformationalType.kError);
      }
    }
    // create ServicePlanDeliveryKey struct
    ServicePlanDeliveryKey spdKey = new ServicePlanDeliveryKey();

    final int size = closeableServicePlans.size();

    // now run through the closure list
    for (int i = 0; i < size; i++) {
      spdKey = closeableServicePlans.get(i);
      servicePlanDeliveryObj.close(spdKey, closureDetails, false);
    }

    // now loop through the potential info error messages
    final String infoMessages[] = im.obtainInformationalAsString();

    for (int i = 0; i < infoMessages.length; i++) {
      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = infoMessages[i];
      msgsList.dtls.addRef(msgDtls);
    }
    return msgsList;
  }

  // ____________________________________________________________________________
  /**
   * creates a new Service Plan Group Delivery
   *
   * @param SPGDeliveryDtls
   * the details of the new Service Plan Group Delivery
   * @return SPGDeliveryKey the id of the new Service Plan Group Delivery
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public SPGDeliveryKey create(SPGDeliveryDtls dtls) throws AppException,
      InformationalException {

    // validate the create request
    validateCreate(dtls);
    // use the entity to create a new record
    final SPGDelivery spgd = SPGDeliveryFactory.newInstance();
    final SPGDeliveryKey spgdKey = new SPGDeliveryKey();

    spgdKey.servicePlanGroupDeliveryId = UniqueID.nextUniqueID();
    dtls.spgdReference = ""
      + UniqueID.nextUniqueID(ServicePlanConst.kSpgdeliveryIdKeysetName);
    dtls.servicePlanGroupDeliveryId = spgdKey.servicePlanGroupDeliveryId;
    spgd.insert(dtls);

    // Part to populate the case transaction log with
    // relevant details for making a entry for
    // insertion of the service plan group delivery
    final CaseReference caseReference = new CaseReference();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // set the case id
    caseSearchKey.caseID = dtls.integratedCaseID;

    // get the case header details for case reference
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();

    caseReference.assign(caseHeader.readCaseReferenceByCaseID(caseSearchKey));

    // get the service plan group dtls for retrieving the
    // service plan group name
    final ServicePlanGroupDtls servicePlanGroupDtls = new ServicePlanGroupDtls();

    // set the service plan group key
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = dtls.servicePlanGroupId;

    // invoke the method of service plan group to get the
    // service plan group dtls
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    servicePlanGroupDtls.assign(servicePlanGroupObj.read(servicePlanGroupKey));

    // build the description for logging by passing the required parameters
    final LocalisableString description = new LocalisableString(
      BPOCASEEVENTS.SERVICEPLAN_GROUP_CREATED);

    description.arg(
      CodeTable.getOneItemForUserLocale(SERVICEPLANGROUPNAME.TABLENAME,
      servicePlanGroupDtls.servicePlanGroupName));

    description.arg(caseReference.caseReference);
    // record the transaction
    caseTransactionLogProvider.get().recordCaseTransaction(
      CASETRANSACTIONEVENTS.SERVICEPLAN_GROUP_CREATED, description,
      dtls.integratedCaseID, CuramConst.kDefaultRelatedID);
    return spgdKey;
  }

  // ____________________________________________________________________________
  /**
   * gets the ids of the Service Plan Deliveries within this Service Plan Group
   * Delivery.
   *
   * @param SPGDeliveryKey
   * the id of the Service Plan Group Delivery
   * @return ServicePlanDeliveryIDDtlsList list of Service Plan Delivery ids
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public ServicePlanDeliveryIDDtlsList getServicePlanDeliveryIDs(
    SPGDeliveryKey key) throws AppException, InformationalException {

    final ServicePlanDeliveryIDDtlsList deliveryIds = new ServicePlanDeliveryIDDtlsList();
    final SPGDeliveryLink spgdLink = SPGDeliveryLinkFactory.newInstance();
    final SPGDeliveryLinkDtlsList linkedServicePlanIds = spgdLink.searchServicePlanDeliveriesByServicePlanGroupDeliveryId(
      key);

    final int linkedServicePlanIdsSize = linkedServicePlanIds.dtls.size();

    for (int i = 0; i < linkedServicePlanIdsSize; i++) {
      final ServicePlanDeliveryIDDtls dtls = new ServicePlanDeliveryIDDtls();

      dtls.servicePlanDeliveryID = linkedServicePlanIds.dtls.item(i).caseID;
      deliveryIds.dtls.addRef(dtls);
    }

    return deliveryIds;
  }

  // ____________________________________________________________________________
  /**
   * Gets all Service Plan Group Delivery records by Integrated Case ID and
   * Service Plan Group ID
   *
   * @param ServicePlanGroupKey ID of the Service Plan Group
   * @param CaseHeaderKey
   * The Integrated Case ID
   *
   * @return SPGDeliveryDtlsList list of the Service Plan Group Deliveries
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public SPGDeliveryDtlsList readByServicePlanGroupIdAndIntegratedCaseId(
    ServicePlanGroupKey spgKey, CaseHeaderKey icCaseKey) throws AppException,
      InformationalException {

    final SPGDelivery spgd = SPGDeliveryFactory.newInstance();
    final SPGDeliveryGroupAndCaseKey groupAndCaseKey = new SPGDeliveryGroupAndCaseKey();

    groupAndCaseKey.integratedCaseID = icCaseKey.caseID;
    groupAndCaseKey.servicePlanGroupId = spgKey.servicePlanGroupId;

    return spgd.searchByServicePlanGroupIdAndCaseId(groupAndCaseKey);
  }

  // ____________________________________________________________________________
  /**
   * Gets all Service Plan Delivery details for the homepage
   *
   * @param ServicePlanGroupDeliveryAndActiveIndKey
   * the Service Plan Group Delivery and the flag indicating whether to
   * retrieve just Active Service Plan Deliveries or not
   * @return list of ServicePlan Delivery details
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryServicePlanDeliveryDtlsList readGroupHomeAllPlans(
    ServicePlanGroupDeliveryAndActiveIndKey spgdActiveKey)
    throws AppException, InformationalException {

    final ServicePlanGroupDeliveryServicePlanDeliveryDtlsList spgdspdList = new ServicePlanGroupDeliveryServicePlanDeliveryDtlsList();

    final SPGDeliveryKey key = new SPGDeliveryKey();

    key.servicePlanGroupDeliveryId = spgdActiveKey.servicePlanGroupDeliveryId;
    final ServicePlanDeliveryIDDtlsList deliveryIdsList = getServicePlanDeliveryIDs(
      key);
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final ServicePlanDeliveryKey spdKey = new ServicePlanDeliveryKey();
    final ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey = new ServicePlanStatementDeliveryKey();

    final ServicePlanStatement servicePlanStatementObj = ServicePlanStatementFactory.newInstance();

    final int deliveryIdsListSize = deliveryIdsList.dtls.size();

    for (int i = 0; i < deliveryIdsListSize; i++) {
      spdKey.key.caseID = deliveryIdsList.dtls.item(i).servicePlanDeliveryID;

      final ServicePlanDeliveryReadDetails spdDtls = servicePlanDeliveryObj.read(
        spdKey);
      final ServicePlanGroupDeliveryServicePlanDeliveryDtls spgdspdDtls = new ServicePlanGroupDeliveryServicePlanDeliveryDtls();

      spgdspdDtls.goal = spdDtls.spGoalAndOutcomeDetails.goalName;
      spgdspdDtls.outcome = spdDtls.spGoalAndOutcomeDetails.outcomeAchieved;
      spgdspdDtls.status = spdDtls.participantCaseAndUserDetails.statusCode;
      spgdspdDtls.caseReference = spdDtls.participantCaseAndUserDetails.caseReference;
      spgdspdDtls.servicePlanType = spdDtls.servicePlanTypeStruct.servicePlanType;
      spgdspdDtls.servicePlanDeliveryId = deliveryIdsList.dtls.item(i).servicePlanDeliveryID;

      // get the actual and estimated cost too
      // use the ServicePlanStatement like ISP does
      servicePlanStatementDeliveryKey.caseID = deliveryIdsList.dtls.item(i).servicePlanDeliveryID;

      // BEGIN, CR00246182, TV
      // BEGIN, CR00208728, LP
      final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = servicePlanStatementObj.readStatementDeliveryDetailsWithExceptionOptional(
        servicePlanStatementDeliveryKey, false);

      // END, CR00208728
      // END, CR00246182

      spgdspdDtls.actualCost = servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.actualCost;
      spgdspdDtls.estimatedCost = servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.estimatedCost;
      spgdspdList.dtls.addRef(spgdspdDtls);
    }

    return spgdspdList;
  }

  // ____________________________________________________________________________
  /**
   * gets just the Active Service Plan Delivery details for the homepage
   *
   * @param ServicePlanGroupDeliveryAndActiveIndKey
   * the Service Plan Group Delivery and the flag indicating whether to
   * retrieve just Active Service Plan Deliveries or not
   *
   * @return list of ServicePlan Delivery details
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryServicePlanDeliveryDtlsList readGroupHomeOnlyActivePlans(
    ServicePlanGroupDeliveryAndActiveIndKey spgdAndActiveKey)
    throws AppException, InformationalException {

    final ServicePlanGroupDeliveryServicePlanDeliveryDtlsList filteredList = new ServicePlanGroupDeliveryServicePlanDeliveryDtlsList();
    // use the AllPlans method, then filter out the non-active ones
    final ServicePlanGroupDeliveryServicePlanDeliveryDtlsList spdList = readGroupHomeAllPlans(
      spgdAndActiveKey);

    final int spdListSize = spdList.dtls.size();

    for (int i = 0; i < spdListSize; i++) {
      final ServicePlanGroupDeliveryServicePlanDeliveryDtls dtls = spdList.dtls.item(
        i);

      if (!(dtls.status.equals(CASESTATUS.CANCELED)
        || dtls.status.equals(CASESTATUS.CANCELLEDPLANNED)
        || dtls.status.equals(CASESTATUS.CLOSED)
        || dtls.status.equals(CASESTATUS.COMPLETED)
        || dtls.status.equals(CASESTATUS.REJECTED)
        || dtls.status.equals(CASESTATUS.SUSPENDED))) {
        filteredList.dtls.addRef(dtls);
      }
    }
    return filteredList;
  }

  // ____________________________________________________________________________
  /**
   * check that no similar such SPGD already exists and that the SPG value isn't
   * blank because there are no SPGs defined
   *
   * @param SPGDeliveryDtls
   * the Service Plan Group Delivery details to create
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public void validateCreate(SPGDeliveryDtls dtls) throws AppException,
      InformationalException {

    final ServicePlanGroupKey spgKey = new ServicePlanGroupKey();

    spgKey.servicePlanGroupId = dtls.servicePlanGroupId;
    // first check for existence of the Service Plan Group
    try {
      MaintainServicePlanGroupFactory.newInstance().read(spgKey);
    } catch (final RecordNotFoundException rnfe) {
      throw new AppException(
        BPOSERVICEPLANGROUP.INF_SPG_NO_ACTIVE_SERVICEPLANGROUPS);
    }

    // now check the existing SPGDs
    final CaseHeaderKey icCaseKey = new CaseHeaderKey();

    icCaseKey.caseID = dtls.integratedCaseID;
    final SPGDeliveryDtlsList spgds = readByServicePlanGroupIdAndIntegratedCaseId(
      spgKey, icCaseKey);
    final int spgdsSize = spgds.dtls.size();

    for (int i = 0; i < spgdsSize; i++) {
      // can't have more than one of the same type
      if (spgds.dtls.item(i).servicePlanGroupId == dtls.servicePlanGroupId) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_CANNOT_CREATE_SAME_TYPE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // ____________________________________________________________________________
  /**
   * create a new Service Plan Group Delivery (if required) and create the link
   * between the Service Plan Delivery and the Service Plan Group Delivery
   *
   * @param ServicePlanDeliveryAndGroupKey
   * the Service Plan Delivery ID and the ID of the Service Plan Group
   *
   * @return ID of the Service Plan Group Delivery
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public SPGDeliveryKey createAndLinkWithServicePlanDelivery(
    ServicePlanDeliveryAndGroupKey key) throws AppException,
      InformationalException {

    // create a new SPGD based on the SPG
    // look up the IC case id first
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.planDeliveryKey.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeader.read(caseHeaderKey);

    final CaseHeaderKey icCaseKey = new CaseHeaderKey();

    icCaseKey.caseID = caseHeaderDtls.integratedCaseID;

    // check if there is already a SPGD running for this SPG type and IC Id
    final SPGDeliveryDtlsList existingSpgds = MaintainServicePlanGroupDeliveryFactory.newInstance().readByServicePlanGroupIdAndIntegratedCaseId(
      key.planGroupKey, icCaseKey);
    // any count > 1 means a problem, there SHOULDN'T be anything except 1 or 0
    // however if there is, just take the first one we find
    SPGDeliveryKey spgdKey = new SPGDeliveryKey();

    if (existingSpgds.dtls.size() > 0) {
      // use the first one regardless
      spgdKey.servicePlanGroupDeliveryId = existingSpgds.dtls.item(0).servicePlanGroupDeliveryId;
    } else {
      // otherwise create a brand spanking new one
      final SPGDeliveryDtls spgdDtls = new SPGDeliveryDtls();

      spgdDtls.integratedCaseID = caseHeaderDtls.integratedCaseID;
      spgdDtls.servicePlanGroupId = key.planGroupKey.servicePlanGroupId;
      spgdKey = MaintainServicePlanGroupDeliveryFactory.newInstance().create(
        spgdDtls);
    }
    // link to SPGD
    final SPGDeliveryLinkDtls deliveryLinkDtls = new SPGDeliveryLinkDtls();

    deliveryLinkDtls.servicePlanGroupDeliveryLinkId = UniqueID.nextUniqueID();
    deliveryLinkDtls.servicePlanGroupDeliveryId = spgdKey.servicePlanGroupDeliveryId;
    deliveryLinkDtls.caseID = key.planDeliveryKey.caseID;
    MaintainSPGDeliveryLinkFactory.newInstance().createLink(deliveryLinkDtls);

    return spgdKey;
  }

  // ____________________________________________________________________________
  /**
   * Reads details required to display the Service Plan Group Delivery homepage
   *
   * @param key
   * id of the Service Plan Group Delivery and flag to say whether to
   * show all active child Service Plan Deliveries or not
   *
   * @return the details for the home page display
   *
   * @throws InformationalException standard application exception
   * @throws AppException standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryHomeDtls readHomePageDtls(
    ServicePlanGroupDeliveryAndActiveIndKey key) throws AppException,
      InformationalException {

    final ServicePlanGroupDeliveryHomeDtls homeDtls = new ServicePlanGroupDeliveryHomeDtls();
    ServicePlanGroupDeliveryServicePlanDeliveryDtlsList spdList;

    if (key.activeInd) {
      spdList = readGroupHomeOnlyActivePlans(key);
    } else {
      spdList = readGroupHomeAllPlans(key);
    }
    homeDtls.servicePlanDeliveries.addAll(spdList.dtls);

    final int servicePlanDeliveryDtlsSize = homeDtls.servicePlanDeliveries.size();

    // now figure out high level costs
    for (int i = 0; i < servicePlanDeliveryDtlsSize; i++) {
      final ServicePlanGroupDeliveryServicePlanDeliveryDtls spdDtls = homeDtls.servicePlanDeliveries.item(
        i);
      final Money actualMoney = new Money(
        homeDtls.highLevelCosts.actualCost.getValue()
          + spdDtls.actualCost.getValue());

      homeDtls.highLevelCosts.actualCost = actualMoney;
      final Money estimatedMoney = new Money(
        homeDtls.highLevelCosts.estimatedCost.getValue()
          + spdDtls.estimatedCost.getValue());

      homeDtls.highLevelCosts.estimatedCost = estimatedMoney;
    }
    return homeDtls;
  }

  // BEGIN, CR00211672, CSH
  // _________________________________________________________________________
  /**
   * Reads the details for display on the Service Plan Group Delivery tab.
   *
   * @param key
   * The unique identifier of the assistance case.
   * @return ServicePlanGroupDeliveryTabDetails
   *
   * @throws InformationalException Standard information exception
   * @throws AppException Standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryTabDetails readServicePlanGroupDeliveryTabDetails(
    ServicePlanGroupDeliveryAndActiveIndKey key) throws AppException,
      InformationalException {

    final ServicePlanGroupDeliveryTabDetails tabDetails = new ServicePlanGroupDeliveryTabDetails();
    // BEGIN, CR00386333, VT
    final Locale locale = ProgramLocale.parseLocale(
      TransactionInfo.getProgramLocale());
    // END, CR00386333
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseReferenceAndICTypeDetails details = new CaseReferenceAndICTypeDetails();
    final CaseKey caseKey = new CaseKey();

    final SPGDelivery spgd = SPGDeliveryFactory.newInstance();
    final SPGDeliveryKey spgdKey = new SPGDeliveryKey();

    spgdKey.servicePlanGroupDeliveryId = key.servicePlanGroupDeliveryId;

    // Read associated case details for display on client screen
    caseKey.caseID = spgd.read(spgdKey).integratedCaseID;
    details = caseHeaderObj.readCaseReferenceAndICType(caseKey);

    tabDetails.integratedCaseType = details.integratedCaseType;

    final CatEntry catEntry = BPOINTEGRATEDSERVICEPLAN.INF_RELATED_CASE_DESCRIPTION;
    final LocalisableString info = new LocalisableString(catEntry);

    info.arg(
      CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
      tabDetails.integratedCaseType, locale.toString()));
    info.arg(details.caseReference);

    tabDetails.relatedCaseDescription = info.toClientFormattedText();
    tabDetails.integratedCaseID = caseKey.caseID;

    final IntegratedServicePlanKey integratedServicePlanKey = new IntegratedServicePlanKey();

    integratedServicePlanKey.integratedCaseID = key.servicePlanGroupDeliveryId;

    ServicePlanGroupDeliveryHomeDtls homePageDtls = new ServicePlanGroupDeliveryHomeDtls();

    // For the context panel display information relating to all plans
    // so the boolean parameter is set to false
    key.activeInd = false;
    homePageDtls = readHomePageDtls(key);

    tabDetails.actualCost = homePageDtls.highLevelCosts.actualCost;
    tabDetails.estimatedCost = homePageDtls.highLevelCosts.estimatedCost;

    // Get the case reference of the service plan group delivery case.
    final SPGDeliveryKey sPGDeliveryKey = new SPGDeliveryKey();

    sPGDeliveryKey.servicePlanGroupDeliveryId = key.servicePlanGroupDeliveryId;
    final SPGDelivery sPGDeliveryObj = SPGDeliveryFactory.newInstance();
    final SPGDeliveryDtls sPGDeliveryDtls = sPGDeliveryObj.read(sPGDeliveryKey);

    tabDetails.caseReference = sPGDeliveryDtls.spgdReference;

    // Get the name of the service plan group.
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = sPGDeliveryDtls.servicePlanGroupId;
    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();

    tabDetails.servicePlanGroupName = maintainServicePlanGroupObj.readNameDtls(servicePlanGroupKey).servicePlanGroupName;

    return tabDetails;
  }
  // END, CR00211672
}
