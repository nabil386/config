/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.message.BPOSERVICEPLANGROUP;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.ServicePlanFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanGroup;
import curam.serviceplans.sl.entity.struct.ServicePlanDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDescriptionTextID;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupStatusDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.entity.struct.ServicePlanStatus;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeDetail;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeDetailList;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupLinkFactory;
import curam.serviceplans.sl.struct.MaintainServicePlanGroupAllActiveDtlsList;
import curam.serviceplans.sl.struct.ServicePlanGroupInformationalMessage;
import curam.serviceplans.sl.struct.ServicePlanGroupNameDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * this class provides service layer functionality for the Service Plan Group.
 *
 */
public abstract class MaintainServicePlanGroup extends curam.serviceplans.sl.base.MaintainServicePlanGroup {

  // BEGIN, CR00235328, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Constructor for the class.
   */
  public MaintainServicePlanGroup() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00235328

  /**
   * Creates the Service Plan Group from the details passed in.
   *
   * @param servicePlanGroupDtls
   * The details of the Service Plan Group to create.
   * @return ServicePlanGroupKey The id of the new Service Plan Group.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanGroupKey create(ServicePlanGroupDtls servicePlanGroupDtls) throws AppException,
      InformationalException {

    validateCreate(servicePlanGroupDtls);
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    // populate the other 'blank' details
    servicePlanGroupDtls.servicePlanGroupStatus = RECORDSTATUS.NORMAL;
    servicePlanGroupDtls.servicePlanGroupCreationDate = Date.getCurrentDate();

    // BEGIN, CR00235328, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!servicePlanGroupDtls.servicePlanGroupDesc.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(servicePlanGroupDtls.servicePlanGroupDesc,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      servicePlanGroupDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      servicePlanGroupDtls.descriptionTextID = localizableTextHandler.store();
    }

    servicePlanGroupDtls.servicePlanGroupDesc = null;
    // END, CR00235328

    servicePlanGroupObj.insert(servicePlanGroupDtls);

    // BEGIN, CR00260989, MR
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = servicePlanGroupDtls.servicePlanGroupId;
    // END, CR00260989
    return servicePlanGroupKey;
  }

  /**
   * Processes the list of Service Plans and returns just those with ids that
   * match the Service Plan Group links passed in.
   *
   * @param spDtlsList
   * the list of Service Plans
   * @param linkDtlsList
   * the list of Service Plan Group link records
   * @return ServicePlanDtlsList the filtered list of Service Plans
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanDtlsList filterActiveServicePlanList(ServicePlanDtlsList spDtlsList,
    ServicePlanGroupLinkDtlsList linkDtlsList) throws AppException,
      InformationalException {

    final ServicePlanDtlsList servicePlanDtlsList = new ServicePlanDtlsList();
    boolean addToList = true;
    ServicePlanDtls spDtls = null;
    ServicePlanGroupLinkDtls servicePlanGroupLinkDtls = null;
    final int servicePlanLstSize = spDtlsList.dtls.size();

    for (int i = 0; i < servicePlanLstSize; i++) {
      spDtls = spDtlsList.dtls.item(i);
      final int servicePlanGroupLinkLstSize = linkDtlsList.dtls.size();

      for (int j = 0; j < servicePlanGroupLinkLstSize; j++) {
        servicePlanGroupLinkDtls = linkDtlsList.dtls.item(j);
        if (servicePlanGroupLinkDtls.servicePlanID == spDtls.servicePlanID) {
          addToList = false;
        }
      }
      if (addToList) {
        servicePlanDtlsList.dtls.addRef(spDtls);
      }
      addToList = true;
    }
    return servicePlanDtlsList;
  }

  /**
   * Retrieves all Service Plans Types and returns the Service Plan Details for
   * each type, providing that the Service Plan is active.
   *
   * @return ServicePlanDtlsList list of Service Plans
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanDtlsList getServicePlansByType() throws AppException,
      InformationalException {

    final ServicePlanDtlsList ServicePlanDtlsList = new ServicePlanDtlsList();
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
    final ServicePlanStatus servicePlanStatus = new ServicePlanStatus();

    servicePlanStatus.recordStatus = RECORDSTATUS.NORMAL;
    final ServicePlanTypeDetailList servicePlanTypeDetailList = servicePlanObj.searchActiveSPTypes(
      servicePlanStatus);
    final ServicePlanKey servicePlanKey = new ServicePlanKey();
    // now get the ServicePlan details
    final int size = servicePlanTypeDetailList.dtls.size();
    ServicePlanTypeDetail servicePlanTypeDetail = null;

    for (int i = 0; i < size; i++) {
      servicePlanTypeDetail = servicePlanTypeDetailList.dtls.item(i);

      servicePlanKey.servicePlanID = servicePlanTypeDetail.servicePlanID;
      ServicePlanDtlsList.dtls.addRef(servicePlanObj.read(servicePlanKey));
    }
    return ServicePlanDtlsList;
  }

  /**
   * Reads the Service Plan Group using its unique id.
   *
   * @param spgKey
   * the unique id of the Service Plan Group
   * @return ServicePlanGroupDtls the Service Plan Group record
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupDtls read(ServicePlanGroupKey spgKey)
    throws AppException, InformationalException {

    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    // BEGIN, CR00235328, GP
    ServicePlanGroupDtls servicePlanGroupDtls = new ServicePlanGroupDtls();

    servicePlanGroupDtls = servicePlanGroupObj.read(spgKey);

    // Read the localized description.
    if (0 != servicePlanGroupDtls.descriptionTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        servicePlanGroupDtls.descriptionTextID);

      servicePlanGroupDtls.servicePlanGroupDesc = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }

    return servicePlanGroupDtls;
    // END, CR00235328
  }

  /**
   * gets all the Service Plan Groups
   *
   * @return ServicePlanGroupDtlsList the list of Service Plan Groups
   */
  @Override
  public ServicePlanGroupDtlsList readAll() throws AppException,
      InformationalException {

    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    // BEGIN, CR00235328, GP
    ServicePlanGroupDtlsList servicePlanGroupDtlsList = new ServicePlanGroupDtlsList();
    final ServicePlanGroupDtlsList servicePlanGroupRetDtlsList = new ServicePlanGroupDtlsList();

    servicePlanGroupDtlsList = servicePlanGroupObj.readAll();

    for (final ServicePlanGroupDtls servicePlanGroupDtls : servicePlanGroupDtlsList.dtls.items()) {

      if (0 != servicePlanGroupDtls.descriptionTextID) {

        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          servicePlanGroupDtls.descriptionTextID);

        servicePlanGroupDtls.servicePlanGroupDesc = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      servicePlanGroupRetDtlsList.dtls.addRef(servicePlanGroupDtls);
    }
    return servicePlanGroupRetDtlsList;
    // END, CR00235328
  }

  /**
   * Changes the Service Plan Group status to Cancelled.
   *
   * @param spgKey
   * the unique id of the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public void remove(ServicePlanGroupKey spgKey) throws AppException,
      InformationalException {

    validateRemove(spgKey);

    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupStatusDtls servicePlanGroupStatusDtls = new ServicePlanGroupStatusDtls();

    servicePlanGroupStatusDtls.servicePlanGroupStatus = RECORDSTATUS.CANCELLED;
    servicePlanGroupObj.modifyStatus(spgKey, servicePlanGroupStatusDtls);

    // also delete any SPG links
    MaintainServicePlanGroupLinkFactory.newInstance().removeLinkByGroupId(
      spgKey);
  }

  /**
   * Modifies the Service Plan Group.
   *
   * @param spgDtls
   * the details for the update
   * @throws AppException, InformationalException
   */
  @Override
  public void update(ServicePlanGroupDtls spgDtls) throws AppException,
      InformationalException {

    validateUpdate(spgDtls);
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = spgDtls.servicePlanGroupId;

    // BEGIN, CR00235328, GP
    // Modify Localized description.
    long descriptionTextID;

    if (0 == spgDtls.descriptionTextID) {

      if (!spgDtls.servicePlanGroupDesc.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(spgDtls.servicePlanGroupDesc,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      spgDtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        spgDtls.descriptionTextID);

      localizableTextHandler.addValue(spgDtls.servicePlanGroupDesc,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }
    spgDtls.servicePlanGroupDesc = null;
    // END, CR00235328

    servicePlanGroupObj.modify(servicePlanGroupKey, spgDtls);
  }

  /**
   * Checks the details before allowing the Service Plan Group to be created.
   *
   * @param spgDtls
   * the Service Plan Group details
   * @throws AppException, InformationalException
   */
  @Override
  public void validateCreate(ServicePlanGroupDtls spgDtls)
    throws AppException, InformationalException {

    // does one already exist with the same name and active status? = error
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupDtlsList servicePlanGroupDtlsList = servicePlanGroupObj.readAll();
    final int size = servicePlanGroupDtlsList.dtls.size();
    ServicePlanGroupDtls servicePlanGroupDtls = null;

    for (int i = 0; i < size; i++) {
      servicePlanGroupDtls = servicePlanGroupDtlsList.dtls.item(i);
      if (servicePlanGroupDtls.servicePlanGroupName.equals(
        spgDtls.servicePlanGroupName)
          && servicePlanGroupDtls.servicePlanGroupStatus.equals(
            RECORDSTATUS.NORMAL)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSERVICEPLANGROUP.ERR_SPG_NAME_ALREADY_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }
  }

  /**
   * Checks if it is ok to perform the remove operation.
   *
   * @param spgKey
   * the unique id of the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public void validateRemove(ServicePlanGroupKey spgKey) throws AppException,
      InformationalException {

    // don't let the user remove an already cancelled SPG
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupDtls servicePlanGroupDtls = servicePlanGroupObj.read(
      spgKey);

    if (servicePlanGroupDtls.servicePlanGroupStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      throw new AppException(
        BPOSERVICEPLANGROUP.ERR_SPG_REMOVE_ALREADY_CANCELLED);
    }
  }

  /**
   * Checks that its ok to update the service plan group details.
   *
   * @param dtls
   * the Service Plan Group details
   * @throws AppException, InformationalException
   */
  @Override
  public void validateUpdate(ServicePlanGroupDtls dtls) throws AppException,
      InformationalException {

    final ServicePlanGroupKey spgKey = new ServicePlanGroupKey();

    spgKey.servicePlanGroupId = dtls.servicePlanGroupId;

    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupDtls servicePlanGroupDtls = servicePlanGroupObj.read(
      spgKey);

    // do not allow updates if the SPG is in the Cancelled state
    if (servicePlanGroupDtls.servicePlanGroupStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANGROUP.ERR_SPG_MODIFY_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }
  }

  /**
   * Looks up active Service Plan Groups based on their entry in the Service
   * Plan Group Link table and connection with the Service Plan passed in.
   *
   * @param servicePlanKey
   * the id of the Service Plan
   * @return ServicePlanGroupDtlsList the list of Active Service Plan Groups
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupDtlsList searchActiveServicePlanGroupsByServicePlanId(ServicePlanKey servicePlanKey)
    throws AppException, InformationalException {

    final ServicePlanGroupDtlsList spgList = new ServicePlanGroupDtlsList();

    final ServicePlanGroupLinkDtlsList spgLinks = MaintainServicePlanGroupLinkFactory.newInstance().getAllForServicePlan(
      servicePlanKey);
    // iterate through the list, looking up the SPG each time and checking its
    // status
    final ServicePlanGroupKey spgKey = new ServicePlanGroupKey();
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final int size = spgLinks.dtls.size();
    ServicePlanGroupDtls servicePlanGroupDtls = null;

    for (int i = 0; i < size; i++) {
      spgKey.servicePlanGroupId = spgLinks.dtls.item(i).servicePlanGroupId;
      servicePlanGroupDtls = servicePlanGroupObj.read(spgKey);
      if (servicePlanGroupDtls.servicePlanGroupStatus.equals(
        RECORDSTATUS.NORMAL)) {
        // ok to add to returned list
        spgList.dtls.addRef(servicePlanGroupDtls);
      }
    }
    return spgList;
  }

  /**
   * Reads just the active Service Plan Groups.
   *
   * @return ServicePlanGroupDtlsList the list of active Service Plan Groups
   * @throws AppException, InformationalException
   */
  @Override
  public MaintainServicePlanGroupAllActiveDtlsList readAllActive()
    throws AppException, InformationalException {

    final MaintainServicePlanGroupAllActiveDtlsList maintainServicePlanGroupAllActiveDtlsList = new MaintainServicePlanGroupAllActiveDtlsList();
    final ServicePlanGroupDtlsList servicePlanGroupDtlsList = new ServicePlanGroupDtlsList();

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupDtlsList servicePlanGroupDtlsEntityList = servicePlanGroupObj.readAll();
    ServicePlanGroupDtls servicePlanGroupDtls = null;
    final int size = servicePlanGroupDtlsEntityList.dtls.size();

    for (int i = 0; i < size; i++) {
      servicePlanGroupDtls = servicePlanGroupDtlsEntityList.dtls.item(i);
      if (servicePlanGroupDtls.servicePlanGroupStatus.equals(
        RECORDSTATUS.NORMAL)) {
        // ok to add to the return list
        servicePlanGroupDtlsList.dtls.addRef(servicePlanGroupDtls);
      }
    }

    maintainServicePlanGroupAllActiveDtlsList.dtls = servicePlanGroupDtlsList;
    // if the list is empty, through an InformationalMessage to let the user
    // know
    if (servicePlanGroupDtlsList.dtls.size() < 1) {
      final AppException ae = new AppException(
        BPOSERVICEPLANGROUP.INF_SPG_NO_ACTIVE_SERVICEPLANGROUPS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    final String[] infoMessages = informationalManager.obtainInformationalAsString();
    ServicePlanGroupInformationalMessage message = null;

    for (int i = 0; i < infoMessages.length; i++) {
      message = new ServicePlanGroupInformationalMessage();
      message.message = infoMessages[i];
      maintainServicePlanGroupAllActiveDtlsList.messages.addRef(message);
    }
    return maintainServicePlanGroupAllActiveDtlsList;
  }

  /**
   * Gets the name and id of the Service Plan Group.
   *
   * @param ServicePlanGroupKey
   * the unique id of the Service Plan Group
   * @return ServicePlanGroupNameDtls a struct of the name and id
   * of the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupNameDtls readNameDtls(ServicePlanGroupKey key)
    throws AppException, InformationalException {

    final ServicePlanGroupNameDtls servicePlanGroupNameDtls = new ServicePlanGroupNameDtls();
    final ServicePlanGroupDtls servicePlanGroupDtls = ServicePlanGroupFactory.newInstance().read(
      key);

    servicePlanGroupNameDtls.servicePlanGroupId = servicePlanGroupDtls.servicePlanGroupId;
    servicePlanGroupNameDtls.servicePlanGroupName = servicePlanGroupDtls.servicePlanGroupName;
    return servicePlanGroupNameDtls;
  }

  // BEGIN, CR00235328, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          24);
      }
    }
  }

  /**
   * Creates a text translation for the ServicePlanGroup attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for ServicePlanGroup
   * attribute, description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   *
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   *
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   *
   * {@link BPOSERVICEPLANGROUP#ERR_SPG_MODIFY_ALREADY_CANCELLED
   * ERR_SPG_MODIFY_ALREADY_CANCELLED}- if the ServicePlanGroup to be
   * modified is already canceled.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    final ServicePlanGroupDescriptionTextID servicePlanGroupDescriptionTextID = new ServicePlanGroupDescriptionTextID();
    ServicePlanGroupDtls servicePlanGroupDtls = new ServicePlanGroupDtls();

    servicePlanGroupKey.servicePlanGroupId = localizableTextTranslationDetails.localizableTextParentID;
    servicePlanGroupDtls = servicePlanGroupObj.read(servicePlanGroupKey);

    // Record must not be already canceled.
    if (servicePlanGroupDtls.servicePlanGroupStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANGROUP.ERR_SPG_MODIFY_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 34);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 15);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == servicePlanGroupDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !servicePlanGroupDtls.servicePlanGroupDesc.equals(
            CuramConst.gkEmpty)) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          23);

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = servicePlanGroupDtls.servicePlanGroupDesc;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      servicePlanGroupDescriptionTextID.descriptionTextID = textID;
      servicePlanGroupDescriptionTextID.versionNo = servicePlanGroupDtls.versionNo;
      servicePlanGroupObj.modifyDescriptionTextID(servicePlanGroupKey,
        servicePlanGroupDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != servicePlanGroupDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        servicePlanGroupDtls.descriptionTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the GoodCause attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of GoodCause attribute,
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   *
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   *
   * {@link BPOGOODCAUSE#ERR_FV_RECORD_CANCELED_NO_MODIFY
   * ERR_FV_RECORD_CANCELED_NO_MODIFY}- if the GoodCause to be modified
   * is already canceled.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    final ServicePlanGroupDescriptionTextID servicePlanGroupDescriptionTextID = new ServicePlanGroupDescriptionTextID();
    ServicePlanGroupDtls servicePlanGroupDtls = new ServicePlanGroupDtls();

    servicePlanGroupKey.servicePlanGroupId = localizableTextTranslationDetails.localizableTextParentID;
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 33);
    }

    servicePlanGroupDtls = servicePlanGroupObj.read(servicePlanGroupKey);

    // Record must not be already canceled.
    if (servicePlanGroupDtls.servicePlanGroupStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANGROUP.ERR_SPG_MODIFY_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == servicePlanGroupDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      servicePlanGroupDescriptionTextID.descriptionTextID = textID;
      servicePlanGroupDescriptionTextID.versionNo = servicePlanGroupDtls.versionNo;
      servicePlanGroupObj.modifyDescriptionTextID(servicePlanGroupKey,
        servicePlanGroupDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != servicePlanGroupDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        servicePlanGroupDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00235328

}
