/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.message.BPOCONTRACTTEXT;
import curam.message.BPOSUBGOAL;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.SubGoalOutcomeLinkFactory;
import curam.serviceplans.sl.entity.fact.SubGoalPlanItemLinkFactory;
import curam.serviceplans.sl.entity.intf.SubGoalOutcomeLink;
import curam.serviceplans.sl.entity.intf.SubGoalPlanItemLink;
import curam.serviceplans.sl.entity.struct.OutcomeCountDetails;
import curam.serviceplans.sl.entity.struct.OutcomeDtls;
import curam.serviceplans.sl.entity.struct.PlanItemCountDetails;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedOutcomesForSubGoalKey;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedPlanItemsForSubGoalKey;
import curam.serviceplans.sl.entity.struct.SubGoalContractTextCountKey;
import curam.serviceplans.sl.entity.struct.SubGoalContractTextDtls;
import curam.serviceplans.sl.entity.struct.SubGoalContractTextRemoveKey;
import curam.serviceplans.sl.entity.struct.SubGoalDescriptionTextID;
import curam.serviceplans.sl.entity.struct.SubGoalDtls;
import curam.serviceplans.sl.entity.struct.SubGoalOutcomeKey;
import curam.serviceplans.sl.entity.struct.SubGoalOutcomeLinkDtls;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemCountKey;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemLinkDtls;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemRemoveKey;
import curam.serviceplans.sl.entity.struct.SubGoalStatusDetails;
import curam.serviceplans.sl.struct.ContractTextDetails;
import curam.serviceplans.sl.struct.ContractTextKey;
import curam.serviceplans.sl.struct.CreateContractTextDetails;
import curam.serviceplans.sl.struct.CreateOutcomeDetails;
import curam.serviceplans.sl.struct.CreatePlanItemDetails;
import curam.serviceplans.sl.struct.CreateSubGoalDetails;
import curam.serviceplans.sl.struct.ModifyContractTextDetails;
import curam.serviceplans.sl.struct.ModifySubGoalDetails;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.OutcomeKeyList;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.PlanItemKeyList;
import curam.serviceplans.sl.struct.ReadSubGoalDetails;
import curam.serviceplans.sl.struct.RemoveSubGoalContractTextKey;
import curam.serviceplans.sl.struct.SubGoalCancelKey;
import curam.serviceplans.sl.struct.SubGoalContractTextDetailsList;
import curam.serviceplans.sl.struct.SubGoalDetailsList;
import curam.serviceplans.sl.struct.SubGoalKey;
import curam.serviceplans.sl.struct.SubGoalNameDetails;
import curam.serviceplans.sl.struct.SubGoalOutcomeDetailsList;
import curam.serviceplans.sl.struct.SubGoalPlanItemDetailsList;
import curam.serviceplans.sl.struct.SubGoalUnassociatedOutcomeDetailsList;
import curam.serviceplans.sl.struct.SubGoalUnassociatedPlanItemDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * Business layer functionality for managing service plan sub goals.
 */
public abstract class SubGoal extends curam.serviceplans.sl.base.SubGoal {

  // BEGIN, CR00228110, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public SubGoal() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00228110
  // ___________________________________________________________________________
  /**
   * Adds existing planItems to a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param planItemKeyList The list of planItems to be added to the sub goal.
   */
  @Override
  public void addExistingPlanItems(SubGoalKey subGoalKey,
    PlanItemKeyList planItemKeyList) throws AppException,
      InformationalException {

    // loop variables
    final SubGoalPlanItemLink subGoalPlanItemLinkObj = SubGoalPlanItemLinkFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();
    final int numOutcomes = planItemKeyList.planItemKey.size();

    // loop through all the planItems
    for (int i = 0; i < numOutcomes; i++) {

      // validate that the plan item can be added to the sub goal
      planItemKey.key.planItemID = planItemKeyList.planItemKey.item(i).key.planItemID;
      validateAddPlanItem(subGoalKey, planItemKey);

      // add the plan item to the sub goal
      final SubGoalPlanItemLinkDtls subGoalPlanItemLinkDtls = new SubGoalPlanItemLinkDtls();

      subGoalPlanItemLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
      subGoalPlanItemLinkDtls.planItemID = planItemKey.key.planItemID;
      subGoalPlanItemLinkObj.insert(subGoalPlanItemLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Adds existing outcomes to a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param outcomeKeyList The list of outcomes to be added to the sub goal.
   */
  @Override
  public void addExistingOutcomes(SubGoalKey subGoalKey,
    OutcomeKeyList outcomeKeyList) throws AppException,
      InformationalException {

    // loop variables
    final SubGoalOutcomeLink subGoalOutcomeLinkObj = SubGoalOutcomeLinkFactory.newInstance();
    final OutcomeKey outcomeKey = new OutcomeKey();
    final int numOutcomes = outcomeKeyList.outcomeKey.size();

    // loop through all the outcomes
    for (int i = 0; i < numOutcomes; i++) {

      // validate that the outcome can be added to the sub goal
      outcomeKey.key.outcomeID = outcomeKeyList.outcomeKey.item(i).key.outcomeID;
      validateAddOutcome(subGoalKey, outcomeKey);

      // add the outcome to the sub goal
      final SubGoalOutcomeLinkDtls subGoalOutcomeLinkDtls = new SubGoalOutcomeLinkDtls();

      subGoalOutcomeLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
      subGoalOutcomeLinkDtls.outcomeID = outcomeKey.key.outcomeID;
      subGoalOutcomeLinkObj.insert(subGoalOutcomeLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Cancels a sub goal.
   *
   * @param key Identifies the sub goal.
   */
  @Override
  public void cancel(SubGoalCancelKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.SubGoalStatusDetails subGoalStatusDetails = new curam.serviceplans.sl.entity.struct.SubGoalStatusDetails();

    subGoalStatusDetails.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;
    // BEGIN, CR00228110, GP
    final SubGoalKey subGoalKey = new SubGoalKey();

    subGoalKey.subGoalKey.subGoalID = key.key.subGoalID;
    key.key.versionNo = read(subGoalKey).dtls.versionNo;
    // END, CR00228110
    subGoalObj.cancel(key.key, subGoalStatusDetails);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.DELETESUBGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = key.key.subGoalID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Creates a sub goal.
   *
   * @param details The details for the new sub goal.
   *
   * @return The ID of the new sub goal.
   */
  @Override
  public SubGoalKey create(CreateSubGoalDetails details) throws AppException,
      InformationalException {

    // populate the sub goal details
    final curam.serviceplans.sl.entity.struct.SubGoalDtls subGoalDtls = new curam.serviceplans.sl.entity.struct.SubGoalDtls();

    // assign the creation details
    subGoalDtls.assign(details.createSubGoalDetails);

    // default the record status and creation date
    subGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
    subGoalDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // insert the sub goal details
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // BEGIN, CR00228110, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!subGoalDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(subGoalDtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      subGoalDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      subGoalDtls.descriptionTextID = localizableTextHandler.store();
    }

    subGoalDtls.description = null;
    // END, CR00228110

    subGoalObj.insert(subGoalDtls);

    // return sub goal identifier
    final SubGoalKey subGoalKey = new SubGoalKey();

    subGoalKey.subGoalKey.subGoalID = subGoalDtls.subGoalID;

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATESUBGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = subGoalDtls.subGoalID;
    curam.util.events.impl.EventService.raiseEvent(event);

    return subGoalKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates an plan item associated with a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param createPlanItemDetails The details for the new planItem.
   *
   * @return The ID of the new planItem.
   */
  @Override
  public PlanItemKey createPlanItem(SubGoalKey subGoalKey,
    CreatePlanItemDetails createPlanItemDetails) throws AppException,
      InformationalException {

    //
    // validate sub goal
    //

    // SubGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // read sub goal record status
    final curam.serviceplans.sl.entity.struct.SubGoalStatusDetails subGoalStatusDetails = subGoalObj.readRecordStatus(
      subGoalKey.subGoalKey);

    // sub goal cannot be created for a cancelled goal
    if (!subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {
      throw new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED);
    }

    //
    // create the planItem
    //

    // populate the details
    final PlanItemDtls planItemDtls = new PlanItemDtls();

    planItemDtls.assign(createPlanItemDetails);

    // default the record status and creation date
    planItemDtls.recordStatus = RECORDSTATUS.NORMAL;
    planItemDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // create the plan item record
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    planItemObj.insert(planItemDtls);

    //
    // link the plan item to the sub goal
    //

    // populate the link details
    final SubGoalPlanItemLinkDtls subGoalPlanItemLinkDtls = new SubGoalPlanItemLinkDtls();

    subGoalPlanItemLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalPlanItemLinkDtls.planItemID = planItemDtls.planItemID;

    // insert the link
    final curam.serviceplans.sl.entity.intf.SubGoalPlanItemLink subGoalPlanItemLinkObj = curam.serviceplans.sl.entity.fact.SubGoalPlanItemLinkFactory.newInstance();

    subGoalPlanItemLinkObj.insert(subGoalPlanItemLinkDtls);

    //
    // return the new plan item id
    //

    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.planItemID = planItemDtls.planItemID;
    return planItemKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates a contract text associated with a sub goal.
   *
   * @param subGoalKey Identifies the sub goal
   * @param createContractTextDetails The details of the new contract text.
   *
   * @return The ID of the new contract text.
   */
  @Override
  public ContractTextKey createContractText(SubGoalKey subGoalKey,
    CreateContractTextDetails createContractTextDetails) throws AppException,
      InformationalException {

    //
    // add the contract text and link it to the sub goal
    //

    // contract text variables
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    final ContractTextDtls contractTextDtls = new ContractTextDtls();

    validateAddContractText(subGoalKey, createContractTextDetails);

    // ensure that contract text does not exist already for the chosen language
    validateAddContractText(subGoalKey, createContractTextDetails);

    // insert the contract text record
    contractTextDtls.contractText = createContractTextDetails.contractText;
    contractTextDtls.languageCode = createContractTextDetails.languageCode;
    contractTextDtls.recordStatus = RECORDSTATUS.NORMAL;
    // set the contract text type to Service plans
    contractTextDtls.typeCode = curam.codetable.CONTRACTTEXTTYPE.SERVICEPLANS;

    // create contract text
    contractTextObj.insert(contractTextDtls);

    // add the sub goal contract text link
    final SubGoalContractTextDtls subGoalContractTextDtls = new SubGoalContractTextDtls();

    subGoalContractTextDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalContractTextDtls.contractTextID = contractTextDtls.contractTextID;
    final curam.serviceplans.sl.entity.intf.SubGoalContractText subGoalContractTextObj = curam.serviceplans.sl.entity.fact.SubGoalContractTextFactory.newInstance();

    subGoalContractTextObj.insert(subGoalContractTextDtls);

    // return the contract text id
    final ContractTextKey contractTextKey = new ContractTextKey();

    contractTextKey.contractTextKey.contractTextID = contractTextDtls.contractTextID;
    return contractTextKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates an outcome associated with a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param createOutcomeDetails The details of the new outcome.
   *
   * @return The ID of the new outcome.
   */
  @Override
  public OutcomeKey createOutcome(SubGoalKey subGoalKey,
    CreateOutcomeDetails createOutcomeDetails) throws AppException,
      InformationalException {

    //
    // create the outcome
    //

    // populate the details
    final OutcomeDtls outcomeDtls = new OutcomeDtls();

    outcomeDtls.assign(createOutcomeDetails.createOutcomeDetails);

    // default the record status and creation date
    outcomeDtls.recordStatus = RECORDSTATUS.NORMAL;
    outcomeDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // create the outcome record
    final curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    outcomeObj.insert(outcomeDtls);

    //
    // link the outcome to the planItem
    //

    // populate the link details
    final SubGoalOutcomeLinkDtls subGoalOutcomeLinkDtls = new SubGoalOutcomeLinkDtls();

    subGoalOutcomeLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalOutcomeLinkDtls.outcomeID = outcomeDtls.outcomeID;

    // insert the link
    final curam.serviceplans.sl.entity.intf.SubGoalOutcomeLink subGoalOutcomeLinkObj = curam.serviceplans.sl.entity.fact.SubGoalOutcomeLinkFactory.newInstance();

    subGoalOutcomeLinkObj.insert(subGoalOutcomeLinkDtls);

    //
    // return the new outcome id
    //

    final OutcomeKey outcomeKey = new OutcomeKey();

    outcomeKey.key.outcomeID = outcomeDtls.outcomeID;
    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals.
   *
   * @return A list of all sub goals.
   */
  @Override
  public SubGoalDetailsList list() throws AppException,
      InformationalException {

    // return object
    final SubGoalDetailsList subGoalDetailsList = new SubGoalDetailsList();

    // call the entity list method to populate the return object
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    subGoalDetailsList.dtls = subGoalObj.readAll();

    return subGoalDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of all planItems associated with the sub goal.
   */
  @Override
  public SubGoalPlanItemDetailsList listPlanItems(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalPlanItemDetailsList planItemList = new SubGoalPlanItemDetailsList();

    // read the plan item list and populate the return object
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    planItemList.dtls = subGoalObj.searchPlanItems(key.subGoalKey);

    return planItemList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all contract texts associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of contract texts associated with the sub goal.
   */
  @Override
  public SubGoalContractTextDetailsList listContractTexts(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalContractTextDetailsList contractTextList = new SubGoalContractTextDetailsList();

    // read the list of contracts and populate the return object
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    contractTextList.dtls = subGoalObj.searchContractTexts(key.subGoalKey);

    return contractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of outcomes associated with the sub goal.
   */
  @Override
  public SubGoalOutcomeDetailsList listOutcomes(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalOutcomeDetailsList outcomeList = new SubGoalOutcomeDetailsList();

    // read the outcome list and populate the return object
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    outcomeList.dtls = subGoalObj.searchOutcomes(key.subGoalKey);

    return outcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems not associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of planItems not associated with the sub goal.
   */
  @Override
  public SubGoalUnassociatedPlanItemDetailsList listUnassociatedPlanItems(
    SubGoalKey key) throws AppException, InformationalException {

    // return object
    final SubGoalUnassociatedPlanItemDetailsList unassociatedPlanItemList = new SubGoalUnassociatedPlanItemDetailsList();

    // populate the search key
    final SearchUnassociatedPlanItemsForSubGoalKey searchKey = new SearchUnassociatedPlanItemsForSubGoalKey();

    searchKey.subGoalID = key.subGoalKey.subGoalID;
    searchKey.planItemRecordStatus = RECORDSTATUS.NORMAL;

    // read the list of unassociated planItems
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    unassociatedPlanItemList.dtls = subGoalObj.searchUnassociatedPlanItemsByStatus(
      searchKey);

    return unassociatedPlanItemList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes not associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of outcomes not associated with the sub goal.
   */
  @Override
  public SubGoalUnassociatedOutcomeDetailsList listUnassociatedOutcomes(
    SubGoalKey key) throws AppException, InformationalException {

    // return object
    final SubGoalUnassociatedOutcomeDetailsList unassociatedOutcomeList = new SubGoalUnassociatedOutcomeDetailsList();

    // populate the search key
    final SearchUnassociatedOutcomesForSubGoalKey searchKey = new SearchUnassociatedOutcomesForSubGoalKey();

    searchKey.subGoalID = key.subGoalKey.subGoalID;
    searchKey.outcomeRecordStatus = RECORDSTATUS.NORMAL;

    // read the list of unassociated outcomes
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    unassociatedOutcomeList.dtls = subGoalObj.searchUnassociatedOutcomesByStatus(
      searchKey);

    return unassociatedOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a sub goal.
   *
   * @param details The modified sub goal details.
   * @throws AppException
   * {@link BPOSUBGOAL#ERR_SUBGOAL_CANCELED ERR_SUBGOAL_CANCELED} - if
   * the subgoal to be modified is already canceled.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modify(ModifySubGoalDetails details) throws AppException,
      InformationalException {

    // populate the modify key
    final curam.serviceplans.sl.entity.struct.SubGoalKey subGoalKey = new curam.serviceplans.sl.entity.struct.SubGoalKey();

    subGoalKey.subGoalID = details.dtls.subGoalID;

    // populate the modify details
    final curam.serviceplans.sl.entity.struct.SubGoalDtls subGoalDtls = new curam.serviceplans.sl.entity.struct.SubGoalDtls();

    subGoalDtls.assign(details.dtls);

    // modify the sub goal
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // BEGIN, CR00228110, GP

    final SubGoalStatusDetails subGoalStatusDetails = subGoalObj.readRecordStatus(
      subGoalKey);

    // check if the sub goal already canceled.
    if (subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);

    }
    // Modify localized description.
    long descriptionTextID;

    // Modify Localized description.
    if (0 == subGoalDtls.descriptionTextID) {

      if (!subGoalDtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(subGoalDtls.description,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }

      // Update the entity struct.
      subGoalDtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        subGoalDtls.descriptionTextID);

      localizableTextHandler.addValue(subGoalDtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }

    subGoalDtls.description = null;
    // END, CR00228110

    subGoalObj.modify(subGoalKey, subGoalDtls);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.MODIFYSUBGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = details.dtls.subGoalID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Modifies a contract text associated with a sub goal.
   *
   * @param modifyDetails The modifies contract text details.
   */
  @Override
  public void modifyContractText(ModifyContractTextDetails modifyDetails)
    throws AppException, InformationalException {

    // populate the key
    final curam.core.sl.entity.struct.ContractTextKey key = new curam.core.sl.entity.struct.ContractTextKey();

    key.contractTextID = modifyDetails.dtls.contractTextID;

    // populate the details
    final curam.core.sl.entity.struct.ModifyContractTextDetails details = new curam.core.sl.entity.struct.ModifyContractTextDetails();

    details.contractText = modifyDetails.dtls.contractText;
    details.versionNo = modifyDetails.dtls.versionNo;

    // modify the details
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    contractTextObj.modify(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return The sub goal details.
   */
  @Override
  public ReadSubGoalDetails read(SubGoalKey key) throws AppException,
      InformationalException {

    // set up the read key
    final curam.serviceplans.sl.entity.struct.SubGoalKey subGoalKey = new curam.serviceplans.sl.entity.struct.SubGoalKey();

    subGoalKey.subGoalID = key.subGoalKey.subGoalID;

    // read the details into the output struct
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    final ReadSubGoalDetails readSubGoalDetails = new ReadSubGoalDetails();

    readSubGoalDetails.dtls = subGoalObj.read(subGoalKey, false);

    // BEGIN, CR00228110, GP
    // Read the localized description.
    if (0 != readSubGoalDetails.dtls.descriptionTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readSubGoalDetails.dtls.descriptionTextID);

      readSubGoalDetails.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00228110

    return readSubGoalDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a contract text associated with a sub goal.
   *
   * @param contractTextKey Identifies the contract text.
   *
   * @return The contract text details.
   */
  @Override
  public ContractTextDetails readContractText(ContractTextKey contractTextKey) throws AppException,
      InformationalException {

    // return object
    final ContractTextDetails contractTextDetails = new ContractTextDetails();

    // read the contract text entity(now moved to core)
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    // populate the output details
    contractTextDetails.assign(
      contractTextObj.read(contractTextKey.contractTextKey, false));

    return contractTextDetails;

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an plan item and a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param planItemKey Identifies the planItem.
   */
  @Override
  public void removePlanItem(SubGoalKey subGoalKey, PlanItemKey planItemKey)
    throws AppException, InformationalException {

    // populate the remove key
    final SubGoalPlanItemRemoveKey subGoalPlanItemRemoveKey = new SubGoalPlanItemRemoveKey();

    subGoalPlanItemRemoveKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalPlanItemRemoveKey.planItemID = planItemKey.key.planItemID;

    // Plan Template entity
    final curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.SubGoalPlanItemAndStatusKey subGoalPlanItemAndStatusKey = new curam.serviceplans.sl.entity.struct.SubGoalPlanItemAndStatusKey();

    subGoalPlanItemAndStatusKey.planItemID = planItemKey.key.planItemID;
    subGoalPlanItemAndStatusKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalPlanItemAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // there must not be a plan template plan item based on this plan item that
    // is assigned to the plan template sub goal created for this sub goal
    if (planTemplateObj.countBySubGoalAndPlanItem(subGoalPlanItemAndStatusKey).count
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUBGOAL.ERR_SUBGOAL_XRV_PLANTEMPLATEPLAN_ITEM_ASSIGNED_TO_PLANTEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // remove the link between the sub goal and planItem
    final SubGoalPlanItemLink subGoalPlanItemLink = SubGoalPlanItemLinkFactory.newInstance();

    subGoalPlanItemLink.removeBySubGoalIDAndPlanItemID(subGoalPlanItemRemoveKey);

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between a contract text and a sub goal. The
   * contract text is also deleted.
   *
   * @param key Identifies the sub goal and contract text details.
   */
  @Override
  public void removeContractText(RemoveSubGoalContractTextKey key)
    throws AppException, InformationalException {

    //
    // remove the sub goal-contract text link
    //

    // populate the sub goal contract text key
    final SubGoalContractTextRemoveKey linkKey = new SubGoalContractTextRemoveKey();

    linkKey.subGoalID = key.subGoalID;
    linkKey.contractTextID = key.contractTextID;

    // remove the link between the sub goal and the contract text
    final curam.serviceplans.sl.entity.intf.SubGoalContractText subGoalContractTextObj = curam.serviceplans.sl.entity.fact.SubGoalContractTextFactory.newInstance();

    subGoalContractTextObj.removeBySubGoalIDAndContractTextID(linkKey);

    //
    // cancel the contract text record
    //

    // cancel struct
    final curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();
    final curam.core.sl.entity.struct.CancelContractTextDetails cancelContractTextDetails = new curam.core.sl.entity.struct.CancelContractTextDetails();

    // populate the cancel details
    contractTextKey.contractTextID = key.contractTextID;
    cancelContractTextDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelContractTextDetails.versionNo = key.contractTextVersionNo;

    // cancel the contract text
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    contractTextObj.cancel(contractTextKey, cancelContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an outcome and a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param outcomeKey Identifies the outcome.
   */
  @Override
  public void removeOutcome(SubGoalKey subGoalKey, OutcomeKey outcomeKey)
    throws AppException, InformationalException {

    // populate the remove key
    final SubGoalOutcomeKey subGoalOutcomeKey = new SubGoalOutcomeKey();

    subGoalOutcomeKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalOutcomeKey.outcomeID = outcomeKey.key.outcomeID;

    // remove the link between the plan item and outcome
    final SubGoalOutcomeLink subGoalOutcomeLink = SubGoalOutcomeLinkFactory.newInstance();

    subGoalOutcomeLink.removeBySubGoalIDAndOutcomeID(subGoalOutcomeKey);

  }

  // ___________________________________________________________________________
  /**
   * Validates that a contract text can be associated with a sub goal.
   * SubGoals can only have one contract text per language.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param createContractTextDetails The new contract text details.
   */
  @Override
  public void validateAddContractText(SubGoalKey subGoalKey,
    CreateContractTextDetails createContractTextDetails) throws AppException,
      InformationalException {

    //
    // check that the sub goal doesn't already have a contract in the same
    // language as the new contract
    //

    // check that the language code has been specified
    if (createContractTextDetails.languageCode.length() < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCONTRACTTEXT.ERR_LANGUAGECODE_FV_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    // set up the count key
    final SubGoalContractTextCountKey subGoalContractTextCountKey = new SubGoalContractTextCountKey();

    subGoalContractTextCountKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalContractTextCountKey.languageCode = createContractTextDetails.languageCode;
    subGoalContractTextCountKey.recordStatus = RECORDSTATUS.NORMAL;

    // count the number of active contracts for this sub goal in the same
    // language
    final curam.serviceplans.sl.entity.intf.SubGoalContractText subGoalContractTextObj = curam.serviceplans.sl.entity.fact.SubGoalContractTextFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ContractTextCountDetails contractTextCountDetails = subGoalContractTextObj.countBySubGoalIDContractLanguageAndStatus(
      subGoalContractTextCountKey);

    // is there already a contract in the same language as the new contract?
    if (contractTextCountDetails.numContractTexts > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUBGOAL.ERR_SUBGOAL_XFV_CONTRACTTEXT_EXISTS_FOR_LANGUAGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that an plan item can be added to a sub goal. An plan item cannot
   * be
   * associated with the same sub goal more than once.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param planItemKey Identifies the planItem.
   */
  @Override
  public void validateAddPlanItem(SubGoalKey subGoalKey,
    PlanItemKey planItemKey) throws AppException, InformationalException {

    // SubGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // read sub goal record status
    final curam.serviceplans.sl.entity.struct.SubGoalStatusDetails subGoalStatusDetails = subGoalObj.readRecordStatus(
      subGoalKey.subGoalKey);

    // sub goal cannot be created for a cancelled goal
    if (!subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // populate the count key
    final SubGoalPlanItemCountKey countKey = new SubGoalPlanItemCountKey();

    countKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    countKey.planItemID = planItemKey.key.planItemID;

    // count the number of existing links between the sub goal and planItem
    final SubGoalPlanItemLink subGoalPlanItemLinkObj = SubGoalPlanItemLinkFactory.newInstance();
    final PlanItemCountDetails countDetails = subGoalPlanItemLinkObj.countBySubGoalIDAndPlanItemID(
      countKey);

    // is the plan item already linked to the sub goal?
    if (countDetails.numPlanItems > 0) {

      // get the plan item name
      final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
      final curam.serviceplans.sl.entity.struct.PlanItemNameDetails planItemNameDetails = planItemObj.readName(
        planItemKey.key);

      // throw an exception indicating the name of the plan item which
      // caused the problem
      final AppException e = new AppException(
        BPOSUBGOAL.ERR_SUBGOAL_XFV_PLAN_ITEM_EXISTS);

      e.arg(planItemNameDetails.name);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates than an outcome can be added to a sub goal. An outcome cannot
   * be associated with the same sub goal more than once.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param outcomeKey Identifies the outcome.
   */
  @Override
  public void validateAddOutcome(SubGoalKey subGoalKey, OutcomeKey outcomeKey)
    throws AppException, InformationalException {

    // populate the count key
    final SubGoalOutcomeKey countKey = new SubGoalOutcomeKey();

    countKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    countKey.outcomeID = outcomeKey.key.outcomeID;

    // count the number of existing associations between the sub goal and
    // outcome
    final SubGoalOutcomeLink subGoalOutcomeLinkObj = SubGoalOutcomeLinkFactory.newInstance();
    final OutcomeCountDetails countDetails = subGoalOutcomeLinkObj.countBySubGoalIDAndOutcomeID(
      countKey);

    // is the outcome already linked to the sub goal?
    if (countDetails.recordCount > 0) {

      // get the outcome name
      final curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
      final curam.serviceplans.sl.entity.struct.OutcomeNameDetails outcomeNameDetails = outcomeObj.readName(
        outcomeKey.key);

      // throw an exception indicating the name of the outcome which
      // caused the problem
      final AppException e = new AppException(
        BPOSUBGOAL.ERR_SUBGOAL_XFV_OUTCOME_EXISTS);

      e.arg(outcomeNameDetails.name);
      throw e;

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads sub goal name.
   *
   * @param key SubGoal unique identifier
   * @return SubGoal name
   */
  @Override
  public SubGoalNameDetails readName(SubGoalKey key) throws AppException,
      InformationalException {

    // sub goal entity object
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // return value
    final SubGoalNameDetails subGoalNameDetails = new SubGoalNameDetails();

    // read sub goal name
    subGoalNameDetails.subGoalNameDetails = subGoalObj.readName(key.subGoalKey);

    // return sub goal name
    return subGoalNameDetails;
  }

  // BEGIN, CR00228110, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE } - If multiple text
   * translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          17);
      }
    }
  }

  /**
   * Creates a text translation for the SubGoal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for SubGoal
   * attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty. {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if
   * locale is
   * empty. {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if translation for that
   * locale exists already. {@link BPOSUBGOAL#ERR_SUBGOAL_CANCELED
   * ERR_SUBGOAL_CANCELED - if the
   * SubGoal to be modified is already canceled.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    final SubGoalKey subGoalKey = new SubGoalKey();

    final SubGoalDescriptionTextID subGoalDescriptionTextID = new SubGoalDescriptionTextID();
    SubGoalDtls subGoalDtls = new SubGoalDtls();

    subGoalKey.subGoalKey.subGoalID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 26);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 12);
    }

    subGoalDtls = subGoalObj.read(subGoalKey.subGoalKey);

    // Record must not be already canceled.
    if (subGoalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == subGoalDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !subGoalDtls.description.equals(CuramConst.gkEmpty)) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          18);

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = subGoalDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      subGoalDescriptionTextID.descriptionTextID = textID;
      subGoalDescriptionTextID.versionNo = subGoalDtls.versionNo;
      subGoalObj.modifyDescriptionTextID(subGoalKey.subGoalKey,
        subGoalDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != subGoalDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        subGoalDtls.descriptionTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the SubGoal attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of SubGoal attribute,
   * description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty. {@link BPOSUBGOAL#ERR_SUBGOAL_CANCELED
   * ERR_SUBGOAL_CANCELED }- if the
   * plan template to be modified is already deleted.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    final SubGoalKey subGoalKey = new SubGoalKey();

    final SubGoalDescriptionTextID subGoalDescriptionTextID = new SubGoalDescriptionTextID();
    SubGoalDtls subGoalDtls = new SubGoalDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 27);
    }

    subGoalKey.subGoalKey.subGoalID = localizableTextTranslationDetails.localizableTextParentID;

    subGoalDtls = subGoalObj.read(subGoalKey.subGoalKey);

    // Record must not be already canceled.
    if (subGoalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == subGoalDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      subGoalDescriptionTextID.descriptionTextID = textID;
      subGoalDescriptionTextID.versionNo = subGoalDtls.versionNo;
      subGoalObj.modifyDescriptionTextID(subGoalKey.subGoalKey,
        subGoalDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != subGoalDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        subGoalDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00228110

}
