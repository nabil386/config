/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007,2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.core.struct.UserSecurityDetails;
import curam.core.struct.UsersKey;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalSensitivityCodeDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanContractSensitivityCodeDetails;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.struct.ServicePlanContractSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanParticipantSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanPlanItemApprovalSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanPlanItemSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityResult;
import curam.serviceplans.sl.struct.ServicePlanSubGoalSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class defines the security checks for Service Plans.
 */

public class ServicePlanSecurity extends curam.serviceplans.sl.base.ServicePlanSecurity {

  /**
   * Identifies an Approval Security Check for a Security Plan
   */
  public static final byte kApproveSecurityCheck = 5;

  /**
   * Identifies a Maintenance Security Check for a Security Plan
   */
  public static final byte kMaintainSecurityCheck = 4;

  /**
   * Identifies a Create Security Check for a Security Plan
   */
  public static final byte kCreateSecurityCheck = 3;

  /**
   * Identifies a Clone Security Check for a Security Plan
   */
  public static final byte kCloneSecurityCheck = 2;

  /**
   * Identifies a Read Security Check for a Security Plan
   */
  public static final byte kReadSecurityCheck = 1;

  // ___________________________________________________________________________
  /**
   * Checks security for a particular service plan operation. Includes service
   * plan security check and participant security check.
   *
   * @param key Contains servicePlanID, securityCheckType and concernRoleID
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult servicePlanOperationSecurityCheck(
    ServicePlanOperationSecurityKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // perform participant sensitivity check
    final ServicePlanSecurityResult participantSensitivity = participantSensitivityCheck(
      key.servicePlanParticipantSecurityKey);

    // perform service plan security check
    final ServicePlanSecurityResult servicePlanSecurity = servicePlanSecurityCheck(
      key.servicePlanSecurityKey);

    // both security checks must pass
    servicePlanSecurityResult.result = participantSensitivity.result
      && servicePlanSecurity.result;

    // return the result
    return servicePlanSecurityResult;
  }

  // ___________________________________________________________________________
  /**
   * Checks security for a particular service plan operation.
   *
   * @param key Contains servicePlanID and securityCheckType.
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult servicePlanSecurityCheck(
    ServicePlanSecurityKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // ServicePlan entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.entity.struct.ServicePlanKey();

    // set the key for reading security indicators
    servicePlanKey.servicePlanID = key.servicePlanID;

    // read service plan security indicators
    final curam.serviceplans.sl.entity.struct.ServicePlanSecurityIndicatorsDetails servicePlanSecurityIndicatorDetails = servicePlanObj.readSecurityIndicators(
      servicePlanKey);

    // Security manipulation variables
    final curam.core.intf.SecurityLink securityLinkObj = curam.core.fact.SecurityLinkFactory.newInstance();
    final curam.core.struct.SecurityCheckKey securityCheckKey = new curam.core.struct.SecurityCheckKey();

    // set user security check key to the current user
    securityCheckKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // If approval SID is specified check if the user has it in the security
    // profile. If has, there is no need to check anything else as the user with
    // approval rights has all other rights.
    if (servicePlanSecurityIndicatorDetails.approveRights.length() != 0) {

      // user must have Approve SID
      securityCheckKey.sidName = servicePlanSecurityIndicatorDetails.approveRights;

      // check user security
      securityLinkObj.checkUserSecurity(securityCheckKey);

      // assign the result to the returned struct
      servicePlanSecurityResult.result = securityCheckKey.result;

      if (servicePlanSecurityResult.result) {
        // security check passes, user has right to perform the operation
        return servicePlanSecurityResult;
      } else {
        if (key.securityCheckType == kApproveSecurityCheck) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        }
      }
    }

    //
    // check maintain rights for the user
    //

    // at this point either approval SID is specified and the user
    // does not have it in the profile, but he does not want to perform
    // approval anyway, or approval SID is not specified.

    if (servicePlanSecurityIndicatorDetails.maintainRights.length() != 0) {

      // user must have Maintain SID
      securityCheckKey.sidName = servicePlanSecurityIndicatorDetails.maintainRights;

      // check user security
      securityLinkObj.checkUserSecurity(securityCheckKey);

      // assign the result to the returned struct
      servicePlanSecurityResult.result = securityCheckKey.result;

      if (servicePlanSecurityResult.result) {
        // security check passes, user has right to perform the operation
        return servicePlanSecurityResult;
      } else {
        if (key.securityCheckType == kApproveSecurityCheck
          || key.securityCheckType == kMaintainSecurityCheck) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
        }

      }
    }

    //
    // check create rights for the user
    //
    if (key.securityCheckType == kCreateSecurityCheck
      && servicePlanSecurityIndicatorDetails.createRights.length() != 0) {
      // set the appropriate SID
      securityCheckKey.sidName = servicePlanSecurityIndicatorDetails.createRights;

      // check user security
      securityLinkObj.checkUserSecurity(securityCheckKey);

      // assign the result to the returned struct
      servicePlanSecurityResult.result = securityCheckKey.result;

      if (servicePlanSecurityResult.result) {
        // security check passes, user has right to perform the operation
        return servicePlanSecurityResult;
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
      }
    }

    //
    // check clone rights for the user
    //
    if (key.securityCheckType == kCloneSecurityCheck) {

      if (servicePlanSecurityIndicatorDetails.cloneRights.length() != 0) {

        // user must have Clone SID defined
        securityCheckKey.sidName = servicePlanSecurityIndicatorDetails.cloneRights;

        // check user security
        securityLinkObj.checkUserSecurity(securityCheckKey);

        // assign the result to the returned struct
        servicePlanSecurityResult.result = securityCheckKey.result;

        if (servicePlanSecurityResult.result) {
          // security check passes, user has right to perform the operation
          return servicePlanSecurityResult;
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        }
      } else {
        if (servicePlanSecurityIndicatorDetails.maintainRights.length() != 0) {
          // user must have Clone SID defined
          securityCheckKey.sidName = servicePlanSecurityIndicatorDetails.maintainRights;

          // check user security
          securityLinkObj.checkUserSecurity(securityCheckKey);

          // assign the result to the returned struct
          servicePlanSecurityResult.result = securityCheckKey.result;

          if (servicePlanSecurityResult.result) {
            // security check passes, user has right to perform the operation
            return servicePlanSecurityResult;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              4);
          }
        }
      }
    }

    //
    // check view rights for the user
    //
    if (key.securityCheckType == kReadSecurityCheck) {

      if (servicePlanSecurityIndicatorDetails.viewRights.length() != 0) {
        // user must have View SID defined
        securityCheckKey.sidName = servicePlanSecurityIndicatorDetails.viewRights;

        // check user security
        securityLinkObj.checkUserSecurity(securityCheckKey);

        // assign the result to the returned struct
        servicePlanSecurityResult.result = securityCheckKey.result;

        if (servicePlanSecurityResult.result) {
          // security check passes, user has right to perform the operation
          return servicePlanSecurityResult;
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
        }
      }
    }

    // If we get to this point it means that neither of the security
    // SIDs are set for the service plan, so there is no security restriction.
    servicePlanSecurityResult.result = true;

    return servicePlanSecurityResult;
  }

  // ___________________________________________________________________________
  /**
   * Checks security for a particular operation on a planned item.
   *
   * @param key Contains servicePlanID, securityCheckType and plannedItemID.
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult planItemOperationSecurityCheck(
    ServicePlanPlanItemSecurityKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // perform plan item sensitivity check
    final ServicePlanSecurityResult securityResult1 = planItemSensitivityCheck(
      key.plannedItemIDKey);

    // perform service plan security check
    final ServicePlanSecurityResult securityResult2 = servicePlanSecurityCheck(
      key.servicePlanSecurityKey);

    // both security checks must pass
    servicePlanSecurityResult.result = securityResult1.result
      && securityResult2.result;

    // return security result
    return servicePlanSecurityResult;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the current user has sensitivity higher or equal to planned
   * plan item sensitivity.
   *
   * @param key Contains plannedItemID.
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult planItemSensitivityCheck(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // PlannedItem entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.entity.struct.PlannedItemKey();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // set the key for reading planned item sensitivity code
    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // read planned item sensitivity code
    final curam.serviceplans.sl.entity.struct.PlannedItemSensitivityDetails plannedItemSensitivityDetails = plannedItemObj.readSensitivityCode(
      plannedItemKey);

    // get the user id of the working user
    // BEGIN CR00052856, GSP
    // BEGIN HARP 69095,PN
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    usersKey.userName = systemUserObj.getUserDetails().userName;

    // END HARP, 69095
    // END CR00052856
    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    if (Integer.parseInt(plannedItemSensitivityDetails.sensitivityCode)
      > Integer.parseInt(userSecurityDetails.sensitivity)) {

      servicePlanSecurityResult.result = false;

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // return security result
    return servicePlanSecurityResult;

  }

  // ___________________________________________________________________________
  /**
   * Performs service plan contract security check. The check includes contract
   * sensitivity check and service plan security check.
   *
   * @param key Contains servicePlanID and servicePlanContractID
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult contractOperationSecurityCheck(
    ServicePlanContractSecurityKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();
    final ServicePlanContractSensitivityCodeDetails servicePlanContractSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();

    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanContractKey servicePlanContractKeyEntity = new curam.serviceplans.sl.entity.struct.ServicePlanContractKey();

    // Service plan security key
    final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // set the service plan contract key
    servicePlanContractKeyEntity.servicePlanContractID = key.servicePlanContractID;

    servicePlanContractSensitivityCodeDetails.sensitivityCode = servicePlanContractObj.readSensitivityCode(servicePlanContractKeyEntity).sensitivityCode;

    // perform contract sensitivity check
    final ServicePlanSecurityResult securityResult1 = contractSensitivityCheck(
      servicePlanContractSensitivityCodeDetails);

    // set the service plan security key
    servicePlanSecurityKey.securityCheckType = kMaintainSecurityCheck;
    servicePlanSecurityKey.servicePlanID = key.servicePlanID;

    // perform service plan security check
    final ServicePlanSecurityResult securityResult2 = servicePlanSecurityCheck(
      servicePlanSecurityKey);

    // both security checks must pass
    servicePlanSecurityResult.result = securityResult1.result
      && securityResult2.result;

    // return security result
    return servicePlanSecurityResult;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the current user has sensitivity higher or equal to contract
   * sensitivity.
   *
   * @param details Contains ServicePlanContract ID.
   *
   * @return Boolean indicates whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult contractSensitivityCheck(
    ServicePlanContractSensitivityCodeDetails details) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    final UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    if (Integer.parseInt(details.sensitivityCode)
      > Integer.parseInt(userSecurityDetails.sensitivity)) {

      servicePlanSecurityResult.result = false;

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITY.ERR_CONTRACT_SENSITIVITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    return servicePlanSecurityResult;

  }

  // ___________________________________________________________________________
  /**
   * Performs sensitivity check for the service plan participant.
   *
   * @param key Contains concernRoleID
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult participantSensitivityCheck(
    ServicePlanParticipantSecurityKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult result = new ServicePlanSecurityResult();

    // Participant security check manipulation variables
    final curam.core.sl.struct.ParticipantKeyStruct participantKeyStruct = new curam.core.sl.struct.ParticipantKeyStruct();
    final curam.core.intf.ParticipantSecurityCheck participantSecurityCheckObj = curam.core.fact.ParticipantSecurityCheckFactory.newInstance();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();

    // set participant key
    participantKeyStruct.participantID = key.concernRoleID;

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // check participant sensitivity
    result.result = participantSecurityCheckObj.authorize(participantKeyStruct, usersKey).result;

    if (!result.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Checks security for a particular operation on a service plan sub goal.
   *
   * @param key Contains servicePlanID, securityCheckType and plannedSubGoalID
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult subGoalOperationSecurityCheck(
    ServicePlanSubGoalSecurityKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // perform service plan security check
    final ServicePlanSecurityResult securityResult2 = servicePlanSecurityCheck(
      key.servicePlanSecurityKey);

    // perform sub goal sensitivity check
    final ServicePlanSecurityResult securityResult1 = subGoalSensitivityCheck(
      key.plannedSubGoalKey);

    // both security checks must pass
    servicePlanSecurityResult.result = securityResult1.result
      && securityResult2.result;

    // return security result
    return servicePlanSecurityResult;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the current user has sensitivity higher or equal to planned
   * subgoal sensitivity.
   *
   * @param key Contains plannedSubGoalID.
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult subGoalSensitivityCheck(
    PlannedSubGoalKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    final PlannedSubGoalSensitivityCodeDetails plannedSubGoalSensitivityCodeDetails = plannedSubGoalObj.readSensitivityCode(
      key.key);

    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    final UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    if (Integer.parseInt(plannedSubGoalSensitivityCodeDetails.sensitivityCode)
      > Integer.parseInt(userSecurityDetails.sensitivity)) {

      servicePlanSecurityResult.result = false;

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    return servicePlanSecurityResult;

  }

  /*
   * ___________________________________________________________________________
   * /**
   * Checks security for a particular planned item approval operation.
   *
   * @param key Contains planItemID.
   *
   * @return Boolean indicated whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult approvePlanItemSecurityCheck(
    ServicePlanPlanItemApprovalSecurityKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // ServicePlan entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    // set the key for reading security indicators
    planItemKey.planItemID = key.planItemID;

    // Security manipulation variables
    final curam.core.intf.SecurityLink securityLinkObj = curam.core.fact.SecurityLinkFactory.newInstance();
    final curam.core.struct.SecurityCheckKey securityCheckKey = new curam.core.struct.SecurityCheckKey();

    // set user security check key to the current user
    securityCheckKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // set the appropriate SID
    securityCheckKey.sidName = planItemObj.read(planItemKey).approvalSID;

    // check user security
    securityLinkObj.checkUserSecurity(securityCheckKey);

    // assign the result to the returned struct
    servicePlanSecurityResult.result = securityCheckKey.result;

    if (servicePlanSecurityResult.result) {

      // security check passes, user has right to perform the operation
      return servicePlanSecurityResult;

    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITY.ERR_PLANITEMAPPROVAL_SENSITIVITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      // Should not reach this point without throwing a validation
      return null;
    }

  }

  // BEGIN, CR00000086, CSH
  // ___________________________________________________________________________
  /**
   * Ensures that the current user has the required SID to modify authorization
   * units.
   *
   * @param key Contains plannedItemID.
   *
   * @return Boolean indicating whether the check passed or not
   */
  @Override
  public ServicePlanSecurityResult modifyAuthorizedUnitsSecurityCheck(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Return value
    final ServicePlanSecurityResult servicePlanSecurityResult = new ServicePlanSecurityResult();

    // Plan item object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // Planned item object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Set the plan item key
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = plannedItemObj.readPlanItemID(key.plannedItemIDKey).planItemID;

    // Security manipulation variables
    final curam.core.intf.SecurityLink securityLinkObj = curam.core.fact.SecurityLinkFactory.newInstance();

    final curam.core.struct.SecurityCheckKey securityCheckKey = new curam.core.struct.SecurityCheckKey();

    // set user security check key to the current user
    securityCheckKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // set the appropriate SID
    securityCheckKey.sidName = planItemObj.readPlanItemServiceUnitDeliveryDetails(planItemKey).modifyAuthorizedSID;

    // check user security
    securityLinkObj.checkUserSecurity(securityCheckKey);

    // assign the result to the returned struct
    servicePlanSecurityResult.result = securityCheckKey.result;

    if (servicePlanSecurityResult.result) {

      // security check passes, user has right to perform the operation
      return servicePlanSecurityResult;

    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITY.ERR_PLANNED_ITEM_MODIFY_AUTHORIZED_UNITS_SECURITY_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      // Should not reach this point without throwing a validation
      return null;
    }
  }
  // END, CR00000086

}
