/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004, 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.goodcause.impl.GoodCauseLink;
import curam.goodcause.impl.GoodCauseLinkDAO;
import curam.message.BPOGOODCAUSE;
import curam.message.GENERAL;
import curam.message.impl.BPOGOODCAUSEExceptionCreator;
import curam.serviceplans.sl.entity.struct.GoodCauseDescriptionTextID;
import curam.serviceplans.sl.entity.struct.GoodCauseDtls;
import curam.serviceplans.sl.struct.GoodCauseCancelDetails;
import curam.serviceplans.sl.struct.GoodCauseCreateDetails;
import curam.serviceplans.sl.struct.GoodCauseDetails;
import curam.serviceplans.sl.struct.GoodCauseDetailsList;
import curam.serviceplans.sl.struct.GoodCauseDetailsListAndVersionNo;
import curam.serviceplans.sl.struct.GoodCauseKey;
import curam.serviceplans.sl.struct.GoodCauseNameDetails;
import curam.serviceplans.sl.struct.ModifyGoodCauseDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * This process class provides the functionality for the Good Cause service
 * layer.
 */
public abstract class GoodCause extends curam.serviceplans.sl.base.GoodCause {

  // BEGIN, CR00158757, SG
  /**
   * Reference to GoodCauseLink DAO.
   */
  @Inject
  private GoodCauseLinkDAO goodCauseLinkDAO;

  // BEGIN, CR00234442, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  // END, CR00234442

  /**
   * Constructor for the class.
   */
  public GoodCause() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00158757

  /**
   * Cancels a good cause.
   *
   * @param details
   * Contains the good cause details to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link BPOGOODCAUSE#ERR_GOODCAUSE_XRV_ASSIGNED_TO_REFERENCE} -
   * Good Cause cannot be canceled if it is associated with a related
   * reference.
   */
  @Override
  public void cancel(GoodCauseCancelDetails details) throws AppException,
      InformationalException {

    // GoodCause entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoodCauseCancelDetails goodCauseCancelDetails = new curam.serviceplans.sl.entity.struct.GoodCauseCancelDetails();

    // Set good cause cancel details
    goodCauseCancelDetails.recordStatus = RECORDSTATUS.CANCELLED;
    goodCauseCancelDetails.versionNo = details.versionNo;

    // BEGIN, CR00158757, SG
    // Search the related references for this good cause. If at least one
    // reference exists, throw the exception.
    for (final GoodCauseLink goodCauseLink : goodCauseLinkDAO.searchByGoodCause(
      details.goodCauseKey)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOGOODCAUSEExceptionCreator.ERR_GOODCAUSE_XRV_ASSIGNED_TO_REFERENCE(
          goodCauseLink.getRelatedType().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00158757

    // Cancel the good cause
    goodCauseObj.cancel(details.goodCauseKey, goodCauseCancelDetails);

  }

  /**
   * Creates a good cause.
   *
   * @param details
   * The good cause details.
   *
   * @return The ID of the new good cause.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GoodCauseKey create(GoodCauseCreateDetails details)
    throws AppException, InformationalException {

    // Good cause entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoodCauseDtls goodCauseDtls = new curam.serviceplans.sl.entity.struct.GoodCauseDtls();

    // to be returned
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    // assign creation details
    goodCauseDtls.assign(details);

    // set creation date
    goodCauseDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // set record status
    goodCauseDtls.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00234442, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!goodCauseDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      goodCauseDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      goodCauseDtls.descriptionTextID = localizableTextHandler.store();
    }

    goodCauseDtls.description = null;
    // END, CR00234442

    // create good cause
    goodCauseObj.insert(goodCauseDtls);

    // set good cause identifier to be returned
    goodCauseKey.goodCauseKey.goodCauseID = goodCauseDtls.goodCauseID;

    return goodCauseKey;

  }

  /**
   * Lists all good causes.
   *
   * @return The list of good causes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GoodCauseDetailsList list() throws AppException,
      InformationalException {

    // return object
    final GoodCauseDetailsList goodCauseDetailsList = new GoodCauseDetailsList();

    // Good cause entity object
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

    // read the list
    goodCauseDetailsList.goodCauseDetailsList = goodCauseObj.list();

    // return the list
    return goodCauseDetailsList;
  }

  // BEGIN, CR00234442, GP
  /**
   * Modifies a good cause.
   *
   * @param details
   * The modified details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since curam 6.0 replace by {@link GoodCause#modifyGoodCause()}
   * as part of localizing GoodCause description. See release note: CR00234442
   */
  @Override
  @Deprecated
  public void modify(
    curam.serviceplans.sl.struct.GoodCauseModifyDetails details)
    throws AppException, InformationalException {

    // END, CR00234442

    // GoodCause entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

    // modify good cause
    goodCauseObj.modify(details.goodCauseKey, details.goodCauseModifyDetails);
  }

  // BEGIN, CR00234442, GP
  /**
   * Modifies a good cause.
   *
   * @param details contains the details to be modified.
   *
   * @throws AppException
   * {@link BPOGOODCAUSE#ERR_FV_RECORD_CANCELED_NO_MODIFY
   * ERR_FV_RECORD_CANCELED_NO_MODIFY}- if the GoodCause to be modified
   * is already canceled.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyGoodCause(ModifyGoodCauseDetails details)
    throws AppException, InformationalException {

    long descriptionTextID;
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.GoodCauseKey key = new curam.serviceplans.sl.entity.struct.GoodCauseKey();

    key.goodCauseID = details.dtls.goodCauseID;
    // Check if Good Cause is already canceled.
    final GoodCauseDtls goodCauseDtls = goodCauseObj.read(key);

    if (goodCauseDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      // Record must not be already canceled
      throw new AppException(BPOGOODCAUSE.ERR_FV_RECORD_CANCELED_NO_MODIFY);
    }

    details.dtls.dateCreated = goodCauseDtls.dateCreated;

    // Modify Localized description.
    if (0 == details.dtls.descriptionTextID) {

      if (!details.dtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.dtls.description,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      details.dtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.descriptionTextID);

      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }
    details.dtls.description = null;
    goodCauseObj.modifyDetails(key, details.dtls);

  }

  // END, CR00234442

  /**
   * Reads a good cause's details.
   *
   * @param key
   * Identifies the good cause.
   *
   * @return The good cause details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GoodCauseDetails read(GoodCauseKey key) throws AppException,
      InformationalException {

    // GoodCause entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

    // Return value
    final GoodCauseDetails goodCauseDetails = new GoodCauseDetails();

    // Read good cause details
    goodCauseDetails.goodCauseDetails = goodCauseObj.read(key.goodCauseKey);

    // BEGIN, CR00234442, GP
    // Read the localized description.
    if (0 != goodCauseDetails.goodCauseDetails.descriptionTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        goodCauseDetails.goodCauseDetails.descriptionTextID);

      goodCauseDetails.goodCauseDetails.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00234442

    // Return good cause details
    return goodCauseDetails;
  }

  /**
   * Reads good cause's name.
   *
   * @param key
   * Identifies the good cause.
   *
   * @return The good cause name
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GoodCauseNameDetails readName(GoodCauseKey key) throws AppException,
      InformationalException {

    // return value
    final GoodCauseNameDetails goodCauseNameDetails = new GoodCauseNameDetails();

    // GoodCause entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

    // read good cause name
    goodCauseNameDetails.goodCauseNameDetails = goodCauseObj.readName(
      key.goodCauseKey);

    // return goal name
    return goodCauseNameDetails;
  }

  /**
   * Lists all good causes.includes versionNo for delete to work.
   *
   * @return The list of good causes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GoodCauseDetailsListAndVersionNo listAndVersionNo()
    throws AppException, InformationalException {

    // return object
    final GoodCauseDetailsListAndVersionNo goodCauseDetailsList = new GoodCauseDetailsListAndVersionNo();

    // Good cause entity object
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

    // read the list
    goodCauseDetailsList.dtls = goodCauseObj.searchListAndVersionNo();

    // return the list
    return goodCauseDetailsList;
  }

  // BEGIN, CR00234442, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          10);
      }
    }
  }

  /**
   * Creates a text translation for the GoodCause attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for GoodCause
   * attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   *
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   *
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   *
   * {@link BPOGOODCAUSE#ERR_FV_RECORD_CANCELED_NO_MODIFY
   * ERR_FV_RECORD_CANCELED_NO_MODIFY}- if the GoodCause to be modified
   * is already canceled.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    final GoodCauseDescriptionTextID goodCauseDescriptionTextID = new GoodCauseDescriptionTextID();
    GoodCauseDtls goodCauseDtls = new GoodCauseDtls();

    goodCauseKey.goodCauseKey.goodCauseID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 13);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 6);
    }

    goodCauseDtls = goodCauseObj.read(goodCauseKey.goodCauseKey);

    // Record must not be already canceled.
    if (goodCauseDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_RECORD_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == goodCauseDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !goodCauseDtls.description.equals(CuramConst.gkEmpty)) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          9);

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = goodCauseDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      goodCauseDescriptionTextID.descriptionTextID = textID;
      goodCauseDescriptionTextID.versionNo = goodCauseDtls.versionNo;
      goodCauseObj.modifyDescriptionTextID(goodCauseKey.goodCauseKey,
        goodCauseDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != goodCauseDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        goodCauseDtls.descriptionTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();

    }
  }

  /**
   * Modifies the text translation details for the GoodCause attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of GoodCause attribute,
   * description.
   *
   * @throws AppException
   *
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   *
   * {@link BPOGOODCAUSE#ERR_FV_RECORD_CANCELED_NO_MODIFY
   * ERR_FV_RECORD_CANCELED_NO_MODIFY}- if the GoodCause to be modified
   * is already canceled.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    final GoodCauseDescriptionTextID goodCauseDescriptionTextID = new GoodCauseDescriptionTextID();
    GoodCauseDtls goodCauseDtls = new GoodCauseDtls();

    goodCauseKey.goodCauseKey.goodCauseID = localizableTextTranslationDetails.localizableTextParentID;

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 12);
    }

    goodCauseDtls = goodCauseObj.read(goodCauseKey.goodCauseKey);

    // Record must not be already canceled.
    if (goodCauseDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_RECORD_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == goodCauseDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      goodCauseDescriptionTextID.descriptionTextID = textID;
      goodCauseDescriptionTextID.versionNo = goodCauseDtls.versionNo;
      goodCauseObj.modifyDescriptionTextID(goodCauseKey.goodCauseKey,
        goodCauseDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != goodCauseDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        goodCauseDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00234442

}
