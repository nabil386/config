/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.core.impl.CuramConst;
import curam.core.sl.infrastructure.impl.PlanTemplateConst;


// BEGIN, CR00142673, MR
/**
 * This class handles the last accessed node for the service plan template
 * tree.
 *
 */
public class TreeXMLNodeUtil {

  // BEGIN, CR00069996, SK
  /**
   * For the Plan Template.
   */
  public static final String kPlanTemplate = PlanTemplateConst.kPlanTemplate;

  /**
   * For the Plan Template Plan Group.
   */
  public static final String kPlanTemplatePlanGroup = PlanTemplateConst.kPlanTemplatePlanGroup;

  /**
   * For the Plan Template Sub Goal.
   */
  public static final String kPlanTemplateSubGoal = PlanTemplateConst.kPlanTemplateSubGoal;

  /**
   * For the Plan Template Plan Item.
   */
  public static final String kPlanTemplatePlanItem = PlanTemplateConst.kPlanTemplatePlanItem;

  /**
   * For the Plan Template Milestone.
   */
  public static final String kPlanTemplateMilestone = PlanTemplateConst.kPlanTemplateMilestone;

  // END, CR00069996

  // BEGIN, CR00161962, LJ
  // for approval criteria
  public static final String kPlanTemplatePlanItemApprovalCriteria = PlanTemplateConst.kPlanTemplatePlanItemApprovalCriteria;

  // END, CR00161962
  // BEGIN, CR00052924, GM
  /**
   * The Id of the last accessed node.
   */
  protected String stLastAccessedNodeId = CuramConst.gkStringZero;

  /**
   * The type of the last accessed node.
   */
  protected String stLastAccessedNodeType = CuramConst.gkStringZero;

  // END, CR00052924

  /**
   * Returns the stLastAccessedNodeId.
   *
   * @return the stLastAccessedNodeId.
   */
  public static String getStLastAccessedNodeId() {

    final String stLastAccessedNodeId = new TreeXMLNodeUtil().stLastAccessedNodeId;

    return stLastAccessedNodeId;
  }

  /**
   * Sets the last accessed node Id in the Tree XML widget.
   *
   * @param lastAccessedNodeId The stLastAccessedNodeId to set.
   */
  public static void setStLastAccessedNodeId(String lastAccessedNodeId) {

    new TreeXMLNodeUtil().stLastAccessedNodeId = lastAccessedNodeId;
  }

  /**
   * Returns the stLastAccessedNodeType.
   *
   * @return the stLastAccessedNodeType.
   */
  public static String getStLastAccessedNodeType() {

    final String stLastAccessedNodeType = new TreeXMLNodeUtil().stLastAccessedNodeType;

    return stLastAccessedNodeType;
  }

  /**
   * Sets the last accessed node type in the Tree XML widget.
   *
   * @param lastAccessedNodeType The lastAccessedNodeType to set.
   */
  public static void setStLastAccessedNodeType(String lastAccessedNodeType) {

    new TreeXMLNodeUtil().stLastAccessedNodeType = lastAccessedNodeType;
  }

  /**
   * Returns a boolean value.
   *
   * @param theNodeId nodeId to be compared.
   * @param theNodeType nodeType to be compared.
   *
   * @return boolean value.
   */
  public boolean equals(String theNodeId, String theNodeType) {

    return stLastAccessedNodeId.equals(theNodeId)
      && stLastAccessedNodeType.equals(theNodeType);
  }

  /**
   * Sets the last accessed node with node Id and node Type.
   *
   * @param lastAccessedNodeID The stLastAccessedNodeId to set.
   * @param lastAccessedNodeType The lastAccessedNodeType to set.
   */
  public void setLastAccessedNode(String lastAccessedNodeID,
    String lastAccessedNodeType) {

    setStLastAccessedNodeId(lastAccessedNodeID);
    setStLastAccessedNodeType(lastAccessedNodeType);
  }

  /**
   * Returns the TreeXMLNodeUtil object.
   *
   * @return the TreeXMLNodeUtil object.
   */
  public TreeXMLNodeUtil getLastAccessedNode() {

    return this;
  }
  // END, CR00142673
}
