/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANTYPENAME;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.message.BPOSERVICEPLANAPPROVALCHECK;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.struct.ApprovalCheckCommentsTextID;
import curam.serviceplans.sl.entity.struct.ApprovalChecksAndSPTypeDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckDtls;
import curam.serviceplans.sl.struct.ApprovalChecksDetails;
import curam.serviceplans.sl.struct.ApprovalChecksList;
import curam.serviceplans.sl.struct.CancelApprovalCheckDetails;
import curam.serviceplans.sl.struct.ModifyApprovalCheckDetail;
import curam.serviceplans.sl.struct.SPKey;
import curam.serviceplans.sl.struct.ServicePlanApprovalCheckDetails;
import curam.serviceplans.sl.struct.ServicePlanApprovalCheckKey;
import curam.serviceplans.sl.struct.ServicePlanApprovalCheckList;
import curam.serviceplans.sl.struct.ServicePlanApprovalCheckListAndVersionNo;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.UserApprovalCheckSearchKey;
import curam.serviceplans.sl.struct.UserNameDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


public abstract class ServicePlanApprovalCheck extends curam.serviceplans.sl.base.ServicePlanApprovalCheck {

  // BEGIN, CR00228110, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public ServicePlanApprovalCheck() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00228110
  // _________________________________________________________________________
  /**
   * Creates an approval check for a specific service plan
   *
   * @param details The details of the service plan approval check
   * @return Unique identifier of the created goal
   */
  @Override
  public ServicePlanApprovalCheckKey createSPApprovalCheck(
    ServicePlanApprovalCheckDetails details) throws AppException,
      InformationalException {

    // ServicePlanApprovalCheck entity class
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final curam.serviceplans.sl.struct.ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new curam.serviceplans.sl.struct.ServicePlanApprovalCheckKey();

    // BEGIN, CR00228110, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!details.details.comments.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.details.comments,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      details.details.commentsTextID = localizableTextHandler.store();
    } else {
      // If comments is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      details.details.commentsTextID = localizableTextHandler.store();
    }

    details.details.comments = null;
    // END, CR00228110

    // create approval check
    servicePlanApprovalCheckObj.insert(details.details);
    // set return key
    servicePlanApprovalCheckKey.key.servicePlanApprovalCheckID = details.details.servicePlanApprovalCheckID;

    return servicePlanApprovalCheckKey;

  }

  // _________________________________________________________________________
  /**
   * Reads an approval check for a specific service plan
   *
   * @param key The key for the service plan approval check
   * @return Service Plan Approval Check Details
   */
  @Override
  public ServicePlanApprovalCheckDetails readSPApprovalCheck(
    ServicePlanApprovalCheckKey key) throws AppException,
      InformationalException {

    // set up the read key
    final curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckKey();

    // set key
    servicePlanApprovalCheckKey.servicePlanApprovalCheckID = key.key.servicePlanApprovalCheckID;

    // read the details into the output struct
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final curam.serviceplans.sl.struct.ServicePlanApprovalCheckDetails servicePlanApprovalCheckDetails = new curam.serviceplans.sl.struct.ServicePlanApprovalCheckDetails();

    // reading the details into the return struct
    servicePlanApprovalCheckDetails.details = servicePlanApprovalCheckObj.read(
      key.key);

    // BEGIN, CR00228110, GP
    // Read the localized comments.
    if (0 != servicePlanApprovalCheckDetails.details.commentsTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        servicePlanApprovalCheckDetails.details.commentsTextID);

      servicePlanApprovalCheckDetails.details.comments = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00228110

    return servicePlanApprovalCheckDetails;

  }

  // _________________________________________________________________________
  /**
   * Lists the approval checks for a specific service plan
   *
   * @param key The key for the service plan approval check
   * @return Service Plan Approval Check List
   */
  @Override
  public ServicePlanApprovalCheckList listSPApprovalChecks(SPKey key)
    throws AppException, InformationalException {

    // creating the ServicePlanApprovalCheck obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final curam.serviceplans.sl.struct.ServicePlanApprovalCheckList servicePlanApprovalCheckList = new curam.serviceplans.sl.struct.ServicePlanApprovalCheckList();

    // setting the list in the return struct
    servicePlanApprovalCheckList.detailsList = servicePlanApprovalCheckObj.searchByServicePlan(
      key.spKey);

    return servicePlanApprovalCheckList;
  }

  // _________________________________________________________________________
  /**
   * Cancels the approval checks
   *
   * @param dtls The details for the service plan approval check
   */
  @Override
  public void cancelSPApprovalCheck(CancelApprovalCheckDetails dtls)
    throws AppException, InformationalException {

    // ServicePlanApprovalCheck entity manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();

    curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckKey();

    final curam.serviceplans.sl.entity.struct.CancelApprovalCheckDetails cancelApprovalCheckDetails = new curam.serviceplans.sl.entity.struct.CancelApprovalCheckDetails();

    // Set ServicePlanApprovalCheck key & version
    servicePlanApprovalCheckKey = dtls.cancelKey;
    cancelApprovalCheckDetails.versionNo = dtls.cancelDetails.versionNo;

    // Set record status to cancelled
    cancelApprovalCheckDetails.statusCode = RECORDSTATUS.CANCELLED;

    // Cancel the ServicePlanApprovalCheck
    servicePlanApprovalCheckObj.cancel(servicePlanApprovalCheckKey,
      cancelApprovalCheckDetails);

  }

  // _________________________________________________________________________
  /**
   * Reads the service plan key for the specified approval check key
   *
   * @param key The key for the service plan approval check
   * @return Service Plan Key
   */
  @Override
  public ServicePlanKey readServicePlanName(ServicePlanApprovalCheckKey key)
    throws AppException, InformationalException {

    // creating the approval check obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.struct.ServicePlanKey();

    // assign the key to the return struct
    servicePlanKey.key = servicePlanApprovalCheckObj.readServicePlanID(key.key);

    return servicePlanKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists the approval checks for a user.
   *
   * @param key Identifies the user.
   * @return the Service Plan Approval Check List.
   */
  @Override
  public ApprovalChecksList listUserApprovalChecks(
    UserApprovalCheckSearchKey key) throws AppException,
      InformationalException {

    // creating the approval check obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final ApprovalChecksList approvalChecksList = new curam.serviceplans.sl.struct.ApprovalChecksList();

    approvalChecksList.approvalChecks = servicePlanApprovalCheckObj.searchUserApprovalChecks(
      key.searchKey);
    for (int i = 0; i < approvalChecksList.approvalChecks.dtls.size(); i++) {
      // Set service plan type to all products if approval check has no
      // related service plan id
      if (approvalChecksList.approvalChecks.dtls.item(i).servicePlanID == 0) {
        approvalChecksList.approvalChecks.dtls.item(i).servicePlanType = curam.codetable.SERVICEPLANTYPENAME.ALLTYPES;
      }
    }
    return approvalChecksList;
  }

  // ___________________________________________________________________________
  /**
   * Reads the service plan approval check for user
   *
   * @param key Identifies the service plan approval check.
   * @return the ServicePlan Approval Checks Details
   */
  @Override
  public ApprovalChecksDetails readUserApprovalCheck(
    ServicePlanApprovalCheckKey key) throws AppException,
      InformationalException {

    // creating the approval check obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    final ApprovalChecksDetails approvalChecksDetails = new ApprovalChecksDetails();

    // BEGIN, CR00228110, GP
    ApprovalChecksAndSPTypeDetails approvalChecksAndSPTypeDetails = new ApprovalChecksAndSPTypeDetails();

    approvalChecksAndSPTypeDetails = servicePlanApprovalCheckObj.readApprovalCheckDetailsAndSPType(
      key.key);

    approvalChecksDetails.approvalChecksDetails.assign(
      approvalChecksAndSPTypeDetails);
    if (0 != approvalChecksAndSPTypeDetails.commentsTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        approvalChecksAndSPTypeDetails.commentsTextID);

      approvalChecksDetails.approvalChecksDetails.comments = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00228110

    if (approvalChecksDetails.approvalChecksDetails.appliesToAllInd) {
      // Set service plan type to all products if approval check has no
      // related service plan id
      approvalChecksDetails.approvalChecksDetails.servicePlanType = SERVICEPLANTYPENAME.ALLTYPES;
    }
    return approvalChecksDetails;

  }

  // _________________________________________________________________________
  /**
   * Reads the username for the service plan approval check.
   *
   * @param key Identifies the service plan approval check.
   * @return the username Details
   */
  @Override
  public UserNameDetails readUserName(ServicePlanApprovalCheckKey key)
    throws AppException, InformationalException {

    // creating the approval check obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final UserNameDetails userNameDetails = new UserNameDetails();

    userNameDetails.userNamedtl = servicePlanApprovalCheckObj.readUserName(
      key.key);

    return userNameDetails;
  }

  // _________________________________________________________________________
  /**
   * Modifies the the service plan approval check.
   *
   * @param key Identifies the service plan approval check.
   * @param details The approval check details.
   * {@link BPOSERVICEPLANAPPROVALCHECK#ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY
   * ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY} - if
   * the ApprovalCheck to be modified is already canceled.
   */
  @Override
  public void modifySPApprovalCheck(ServicePlanApprovalCheckKey key,
    ModifyApprovalCheckDetail details) throws AppException,
      InformationalException {

    // creating the ServicePlanApprovalCheck obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();

    // BEGIN, CR00228110, GP
    // Check if ServicePlan is already canceled.
    if (details.detail.statusCode.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Modify localized comments.
    long commentsTextID;

    // Modify Localized description.
    if (0 == details.detail.commentsTextID) {

      if (!details.detail.comments.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.detail.comments,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        commentsTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        commentsTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().

      details.detail.commentsTextID = commentsTextID;

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.detail.commentsTextID);

      localizableTextHandler.addValue(details.detail.comments,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }

    details.detail.comments = null;
    // END, CR00228110

    if (details.detail.servicePlanID == 0) {
      details.detail.appliesToAllInd = true;
    }
    // modify the approval check
    servicePlanApprovalCheckObj.modify(key.key, details.detail);
  }

  /**
   * Lists the approval checks for a specific service plan with versionNo
   *
   * @param key The key for the service plan approval check
   * @return Service Plan Approval Check List
   */
  @Override
  public ServicePlanApprovalCheckListAndVersionNo listSPApprovalChecksAndVersionNo(SPKey readmultiKey) throws AppException,
      InformationalException {

    // creating the ServicePlanApprovalCheck obj
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final ServicePlanApprovalCheckListAndVersionNo servicePlanApprovalCheckList = new ServicePlanApprovalCheckListAndVersionNo();

    // setting the list in the return struct
    servicePlanApprovalCheckList.dtls = servicePlanApprovalCheckObj.searchByServicePlanVNo(
      readmultiKey.spKey);

    return servicePlanApprovalCheckList;
  }

  // BEGIN, CR00228110, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        throw e;
      }
    }
  }

  /**
   * Creates a text translation for the Service Plan approval check attribute,
   * comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Service Plan
   * approval check attribute,comments.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty. {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if
   * locale
   * is empty. {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * {@link BPOSERVICEPLANAPPROVALCHECK# ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY}
   * - if the
   * ServicePlan ApprovalCheck to be modified is already deleted.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addCommentsTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    final ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new ServicePlanApprovalCheckKey();

    final ApprovalCheckCommentsTextID approvalCheckCommentsTextID = new ApprovalCheckCommentsTextID();
    ServicePlanApprovalCheckDtls servicePlanApprovalCheckDtls = new ServicePlanApprovalCheckDtls();

    servicePlanApprovalCheckKey.key.servicePlanApprovalCheckID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_LOCALE_EMPTY);
    }

    servicePlanApprovalCheckDtls = servicePlanApprovalCheckObj.read(
      servicePlanApprovalCheckKey.key);

    // ServicePlan ApprovalCheck must not be already canceled.
    if (servicePlanApprovalCheckDtls.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(
        BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == servicePlanApprovalCheckDtls.commentsTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !servicePlanApprovalCheckDtls.comments.equals(CuramConst.gkEmpty)) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        throw e;

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = servicePlanApprovalCheckDtls.comments;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      approvalCheckCommentsTextID.commentsTextID = textID;
      approvalCheckCommentsTextID.versionNo = servicePlanApprovalCheckDtls.versionNo;
      servicePlanApprovalCheckObj.modifyCommentsTextID(
        servicePlanApprovalCheckKey.key, approvalCheckCommentsTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != servicePlanApprovalCheckDtls.commentsTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        servicePlanApprovalCheckDtls.commentsTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the ServicePlan ApprovalCheck
   * attribute, comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Goal attribute,
   * description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link BPOSERVICEPLANAPPROVALCHECK# ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY
   * ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY} - if the
   * ServicePlan ApprovalCheck to be modified is already deleted
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public void modifyCommentsTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.entity.fact.ServicePlanApprovalCheckFactory.newInstance();
    final ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new ServicePlanApprovalCheckKey();

    final ApprovalCheckCommentsTextID approvalCheckCommentsTextID = new ApprovalCheckCommentsTextID();
    ServicePlanApprovalCheckDtls servicePlanApprovalCheckDtls = new ServicePlanApprovalCheckDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 35);
    }

    servicePlanApprovalCheckKey.key.servicePlanApprovalCheckID = localizableTextTranslationDetails.localizableTextParentID;

    servicePlanApprovalCheckDtls = servicePlanApprovalCheckObj.read(
      servicePlanApprovalCheckKey.key);

    // Record must not be already canceled.
    if (servicePlanApprovalCheckDtls.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == servicePlanApprovalCheckDtls.commentsTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      approvalCheckCommentsTextID.commentsTextID = textID;
      approvalCheckCommentsTextID.versionNo = servicePlanApprovalCheckDtls.versionNo;
      servicePlanApprovalCheckObj.modifyCommentsTextID(
        servicePlanApprovalCheckKey.key, approvalCheckCommentsTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != servicePlanApprovalCheckDtls.commentsTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        servicePlanApprovalCheckDtls.commentsTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00228110
}
