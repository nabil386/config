/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CASESTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.BookmarkFactory;
import curam.core.sl.struct.CountCaseBookmarkKey;
import curam.core.sl.tab.impl.TabLoaderConst;
import curam.core.struct.Count;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.serviceplans.facade.struct.ServicePlanDeliveryHomePageDetails1;
import curam.serviceplans.facade.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Trace;
import curam.util.tab.impl.DynamicMenuStateLoader;
import curam.util.tab.impl.MenuState;
import curam.util.transaction.TransactionInfo;
import java.util.Map;


public class ServicePlanHomeMenuLoader implements DynamicMenuStateLoader {

  @Inject
  private CaseHeaderDAO caseHeaderDAO;

  /**
   * Constructor.
   */
  public ServicePlanHomeMenuLoader() {

    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Returns the state of the given list of menu items.
   *
   * @param menuState
   * The menu instance to load states into.
   * @param pageParameters
   * The context information, in our current case it is the page
   * parameters.
   * @param idsToUpdate
   * The IDs requested by the client to be updated.
   *
   * @return The same menu instance with the updated states.
   */
  @Override
  public MenuState loadMenuState(MenuState menuState,
    Map<String, String> pageParameters, String[] idsToUpdate) {

    // configure menuState
    final MenuState returnState = menuState;

    final String caseIdParam = pageParameters.get(TabLoaderConst.kCaseID);

    final CaseHeader caseHeader = caseHeaderDAO.get(Long.parseLong(caseIdParam));
    final String statusCode = caseHeader.getStatus().getCode();

    // BEGIN, CR00241963 JF
    Boolean caseIsBookmarkedInd = false;
    final curam.core.sl.intf.Bookmark bookmarkObj = BookmarkFactory.newInstance();
    final CountCaseBookmarkKey countCaseBookmarkKey = new CountCaseBookmarkKey();

    countCaseBookmarkKey.dtls.userName = TransactionInfo.getProgramUser();
    countCaseBookmarkKey.dtls.caseID = Long.parseLong(caseIdParam);

    // return number of case bookmarks for the current user
    Count count = null;

    try {
      count = bookmarkObj.countCaseBookmark(countCaseBookmarkKey);
    } catch (final Exception e) {
      // In the case of an exception being thrown, display both of the actions
      returnState.setVisible(true, TabLoaderConst.kBookmark);
      returnState.setEnabled(true, TabLoaderConst.kBookmark);

      returnState.setVisible(true, TabLoaderConst.kRemoveBookmark);
      returnState.setEnabled(true, TabLoaderConst.kRemoveBookmark);
    }

    // check if a case bookmark record exists, the default is false
    if (count.numberOfRecords > 0) {
      caseIsBookmarkedInd = true;
    }

    if (caseIsBookmarkedInd == true) {
      returnState.setVisible(false, TabLoaderConst.kBookmark);
      returnState.setEnabled(false, TabLoaderConst.kBookmark);

      returnState.setVisible(true, TabLoaderConst.kRemoveBookmark);
      returnState.setEnabled(true, TabLoaderConst.kRemoveBookmark);

    } else {
      returnState.setVisible(true, TabLoaderConst.kBookmark);
      returnState.setEnabled(true, TabLoaderConst.kBookmark);

      returnState.setVisible(false, TabLoaderConst.kRemoveBookmark);
      returnState.setEnabled(false, TabLoaderConst.kRemoveBookmark);
    }
    // END, CR00241963 JF

    final ServicePlanDeliveryHomePageDetails1 servicePlanDeliveryHomePageDetails1 = new ServicePlanDeliveryHomePageDetails1();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = Long.parseLong(
      caseIdParam);

    try {

      // Register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      servicePlanDeliveryHomePageDetails1.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
        servicePlanDeliveryKey.servicePlanDeliveryKey);
    } catch (final AppException e) {
      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {
        Trace.kTopLevelLogger.info(Trace.exceptionStackTraceAsString(e));
      }
    } catch (final InformationalException e) {
      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {
        Trace.kTopLevelLogger.info(Trace.exceptionStackTraceAsString(e));
      }
    }

    if (CuramConst.gkEmpty.equals(
      servicePlanDeliveryHomePageDetails1.servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName)) {
      returnState.setVisible(true, TabLoaderConst.kEditServicePlan);
      returnState.setEnabled(false, TabLoaderConst.kEditServicePlan);
    } else {
      returnState.setVisible(true, TabLoaderConst.kEditServicePlan);
      returnState.setEnabled(true, TabLoaderConst.kEditServicePlan);
    }

    if (statusCode.equals(CASESTATUSEntry.OPEN.getCode())) {

      returnState.setVisible(true, TabLoaderConst.kSubmitPlan);
      returnState.setEnabled(true, TabLoaderConst.kSubmitPlan);

      returnState.setVisible(true, TabLoaderConst.kApprovePlan);
      returnState.setEnabled(false, TabLoaderConst.kApprovePlan);

      returnState.setVisible(true, TabLoaderConst.kRejectPlan);
      returnState.setEnabled(false, TabLoaderConst.kRejectPlan);

      returnState.setVisible(true, TabLoaderConst.kClosePlan);
      returnState.setEnabled(true, TabLoaderConst.kClosePlan);

      returnState.setVisible(true, TabLoaderConst.kChangePlanClosure);
      returnState.setEnabled(false, TabLoaderConst.kChangePlanClosure);

    } else if (statusCode.equals(CASESTATUSEntry.PLANSUBMITTED.getCode())) {

      returnState.setVisible(false, TabLoaderConst.kSubmitPlan);
      returnState.setEnabled(false, TabLoaderConst.kSubmitPlan);

      returnState.setVisible(true, TabLoaderConst.kApprovePlan);
      returnState.setEnabled(true, TabLoaderConst.kApprovePlan);

      returnState.setVisible(true, TabLoaderConst.kRejectPlan);
      returnState.setEnabled(true, TabLoaderConst.kRejectPlan);

      returnState.setVisible(true, TabLoaderConst.kClosePlan);
      returnState.setEnabled(true, TabLoaderConst.kClosePlan);

      returnState.setVisible(true, TabLoaderConst.kChangePlanClosure);
      returnState.setEnabled(false, TabLoaderConst.kChangePlanClosure);

    } else if (statusCode.equals(CASESTATUSEntry.APPROVED.getCode())) {

      returnState.setVisible(false, TabLoaderConst.kSubmitPlan);
      returnState.setEnabled(false, TabLoaderConst.kSubmitPlan);

      returnState.setVisible(false, TabLoaderConst.kApprovePlan);
      returnState.setEnabled(false, TabLoaderConst.kApprovePlan);

      returnState.setVisible(false, TabLoaderConst.kRejectPlan);
      returnState.setEnabled(false, TabLoaderConst.kRejectPlan);

      returnState.setVisible(true, TabLoaderConst.kClosePlan);
      returnState.setEnabled(true, TabLoaderConst.kClosePlan);

      returnState.setVisible(true, TabLoaderConst.kChangePlanClosure);
      returnState.setEnabled(false, TabLoaderConst.kChangePlanClosure);

    } else if (statusCode.equals(CASESTATUSEntry.CLOSED.getCode())) {

      returnState.setVisible(true, TabLoaderConst.kSubmitPlan);
      returnState.setEnabled(false, TabLoaderConst.kSubmitPlan);

      returnState.setVisible(true, TabLoaderConst.kApprovePlan);
      returnState.setEnabled(false, TabLoaderConst.kApprovePlan);

      returnState.setVisible(true, TabLoaderConst.kRejectPlan);
      returnState.setEnabled(false, TabLoaderConst.kRejectPlan);

      returnState.setVisible(true, TabLoaderConst.kClosePlan);
      returnState.setEnabled(false, TabLoaderConst.kClosePlan);

      returnState.setVisible(true, TabLoaderConst.kChangePlanClosure);
      returnState.setEnabled(true, TabLoaderConst.kChangePlanClosure);

    }

    return returnState;
  }
}
