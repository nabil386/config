/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.AbsencePeriodKey;
import curam.core.sl.entity.struct.CountDetails;
import curam.core.sl.fact.AbsencePeriodFactory;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndVersionNo;
import curam.core.sl.struct.AbsencePeriodDtls;
import curam.core.struct.CaseHeaderKey;
import curam.message.BPOCLIENTPARTICIPATION;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.serviceplans.sl.entity.fact.PlannedItemAbsenceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemAbsenceLink;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkKey;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsencePeriodDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.PlannedItemAbsenceDetails;
import curam.serviceplans.sl.struct.PlannedItemAbsenceDetailsList;
import curam.serviceplans.sl.struct.PlannedItemAbsenceIDKey;
import curam.serviceplans.sl.struct.PlannedItemIDAndNameDetailsList;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.ServicePlanAbsenceDetailsList;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


public abstract class Absence extends curam.serviceplans.sl.base.Absence {

  // ___________________________________________________________________________
  /**
   * This method cancels the specified absence record.
   *
   * @param key - The planned item and absence identifiers.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelPlanItemAbsence(PlannedItemAbsenceIDKey key)
    throws AppException, InformationalException {

    // Service Plan manipulation entity
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    // Absence manipulation variables
    final curam.core.sl.intf.AbsencePeriod absencePeriodObj = AbsencePeriodFactory.newInstance();
    final PlannedItemAbsenceLink piAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();
    final AbsencePeriodKey absencePeriodKey = new AbsencePeriodKey();
    final PlannedItemAbsenceLinkKey plannedItemAbsenceLinkKey = new PlannedItemAbsenceLinkKey();
    PlannedItemAbsenceDetails plannedItemAbsenceDetails = new PlannedItemAbsenceDetails();
    final RecordStatusAndVersionNo recordStatusAndVersionNo = new RecordStatusAndVersionNo();

    // Modify record status to 'Canceled'
    recordStatusAndVersionNo.recordStatus = RECORDSTATUS.CANCELLED;

    // Set the service plan security check key
    plannedItemIDKey.plannedItemIDKey.plannedItemID = key.plannedItemID;

    // Check service plan security
    securityCheckMaintain(plannedItemIDKey);

    // Read the absence details
    plannedItemAbsenceDetails = readPlanItemAbsence(key);

    // Validate the absence details
    validateCancel(plannedItemAbsenceDetails);

    // Set the absence key
    absencePeriodKey.absencePeriodID = key.absencePeriodID;

    // Cancel the absence record
    absencePeriodObj.cancelAbsencePeriod(absencePeriodKey);

    // Cancel the link record
    // Get link records for planned item absence (there should only be one)
    final PlannedItemAbsenceLinkDtlsList plannedItemAbsenceLinkDtlsList = piAbsenceLinkObj.searchByAbsencePeriodID(
      absencePeriodKey);

    for (int i = 0; i < plannedItemAbsenceLinkDtlsList.dtls.size(); i++) {

      PlannedItemAbsenceLinkDtls plannedItemAbsenceLinkDtls = new PlannedItemAbsenceLinkDtls();

      plannedItemAbsenceLinkDtls = plannedItemAbsenceLinkDtlsList.dtls.item(i);

      plannedItemAbsenceLinkKey.plannedItemAbsenceLinkID = plannedItemAbsenceLinkDtls.plannedItemAbsenceLinkID;

      // Cancel the link record
      piAbsenceLinkObj.modifyStatus(plannedItemAbsenceLinkKey,
        recordStatusAndVersionNo);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method creates an absence record and a link record that contains
   * the association between the absence and the planned item.
   *
   * @param details - The absence and planned item details to be inserted.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createPlanItemAbsence(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.core.sl.intf.AbsencePeriod absencePeriodObj = AbsencePeriodFactory.newInstance();
    final AbsencePeriodKey absencePeriodKey = new AbsencePeriodKey();

    // Service Plan manipulation variables
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();
    final PlannedItemAbsenceLink piAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();
    final PlannedItemAbsenceLinkDtls plannedItemAbsenceLinkDtls = new PlannedItemAbsenceLinkDtls();

    // Validate the absence details
    validateInsert(details);

    // Set the service plan security check key
    plannedItemIDKey.plannedItemIDKey.plannedItemID = details.plannedItemID;

    // Check service plan security
    securityCheckMaintain(plannedItemIDKey);

    // Create the absence record
    absencePeriodKey.absencePeriodID = absencePeriodObj.createAbsencePeriod(details.dtls).absencePeriodID;

    // Set the Planned Item Absence Link details
    plannedItemAbsenceLinkDtls.plannedItemID = details.plannedItemID;
    plannedItemAbsenceLinkDtls.absencePeriodID = absencePeriodKey.absencePeriodID;
    plannedItemAbsenceLinkDtls.recordStatus = RECORDSTATUS.NORMAL;

    // Create the Planned Item Absence Link entity
    piAbsenceLinkObj.insert(plannedItemAbsenceLinkDtls);
  }

  // ___________________________________________________________________________
  /**
   * This method modifies the specified absence record.
   *
   * @param details - The absence modification details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyPlanItemAbsence(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.core.sl.intf.AbsencePeriod absencePeriodObj = AbsencePeriodFactory.newInstance();

    // Validate the absence details
    validateModify(details);

    // Set the service plan security check key
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = details.plannedItemID;

    // Check service plan security
    securityCheckMaintain(plannedItemIDKey);

    // Modify the absence record
    absencePeriodObj.modifyAbsencePeriod(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * This method reads the specified absence record details.
   *
   * @param key - The planned item and absence identifiers.
   *
   * @return the absence record details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PlannedItemAbsenceDetails readPlanItemAbsence(
    PlannedItemAbsenceIDKey key) throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.core.sl.intf.AbsencePeriod absencePeriodObj = AbsencePeriodFactory.newInstance();
    AbsencePeriodDtls absencePeriodDtls = new AbsencePeriodDtls();
    final AbsencePeriodKey absencePeriodKey = new AbsencePeriodKey();
    final PlannedItemAbsenceDetails plannedItemAbsenceDetails = new PlannedItemAbsenceDetails();
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Set the planned item id key
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = key.plannedItemID;

    // Set the service plan security check key
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    // Check service plan security
    securityCheckRead(servicePlanDeliveryKey);

    // Set the planned item key
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = key.plannedItemID;

    // Set the absence key
    absencePeriodKey.absencePeriodID = key.absencePeriodID;

    // Read the absence details
    absencePeriodDtls = absencePeriodObj.readAbsencePeriod(absencePeriodKey);

    // Set the return details
    plannedItemAbsenceDetails.dtls = absencePeriodDtls;
    plannedItemAbsenceDetails.plannedItemID = key.plannedItemID;
    plannedItemAbsenceDetails.planItemName = plannedItemObj.readName(plannedItemIDKey.plannedItemIDKey).name;

    return plannedItemAbsenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method lists the absence records associated with the specified
   * planned item.
   *
   * @param key - The planned item identifier.
   *
   * @return the list of absences for the planned item.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PlannedItemAbsenceDetailsList listPlanItemAbsence(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Absence manipulation variables
    final PlannedItemAbsenceLink plannedItemAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();
    final PlannedItemAbsenceDetailsList plannedItemAbsenceDetailsList = new PlannedItemAbsenceDetailsList();
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Set the service plan security check key
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(key.plannedItemIDKey).caseID;

    // Check service plan security
    securityCheckRead(servicePlanDeliveryKey);

    // Set the planned item key
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // Read the absence list
    plannedItemAbsenceDetailsList.list = plannedItemAbsenceLinkObj.searchAbsenceByPlannedItemID(
      key.plannedItemIDKey);

    // Read the planned item name
    plannedItemAbsenceDetailsList.planItemName = plannedItemObj.read(plannedItemKey).name;

    return plannedItemAbsenceDetailsList;
  }

  // BEGIN, CR00127318, CSH
  // ___________________________________________________________________________
  /**
   * This method lists the absence records associated with the specified
   * service plan delivery.
   *
   * @param key - The service plan delivery identifier.
   *
   * @return the list of absences for the service plan.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ServicePlanAbsenceDetailsList listServicePlanAbsence(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // Planned Item Absence manipulation variables
    final ServicePlanAbsenceDetailsList servicePlanAbsenceDetailsList = new ServicePlanAbsenceDetailsList();
    final PlannedItemAbsenceLink plannedItemAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();

    // Check service plan security
    securityCheckRead(key);

    // Read the list of planned item absences for the service plan delivery
    servicePlanAbsenceDetailsList.list = plannedItemAbsenceLinkObj.searchAbsenceByServicePlanDeliveryID(
      key);

    // Return the list of absences for the service plan delivery
    return servicePlanAbsenceDetailsList;
  }

  // END, CR00127318

  // ___________________________________________________________________________
  /**
   * This method lists the plan items associated with the specified
   * service plan delivery.
   *
   * @param key - The service plan delivery identifier.
   *
   * @return the list of planned items for the service plan.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PlannedItemIDAndNameDetailsList listServicePlanPlanItems(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // Planned Item manipulation variables
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlannedItemIDAndNameDetailsList plannedItemIDAndNameDetailsList = new PlannedItemIDAndNameDetailsList();

    // Check service plan security
    securityCheckRead(key);

    // Retrieve the list of plan items associated with the service plan delivery
    plannedItemIDAndNameDetailsList.list = plannedItemObj.searchPlanItemsForServicePlan(
      key);

    // Return the list of plan items for the service plan delivery
    return plannedItemIDAndNameDetailsList;
  }

  /**
   * Checks that the user is allowed to maintain the service plan.
   *
   * @param key
   * ID of the service plan that is being checked.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANSECURITY#ERR_MAINTAIN_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void securityCheckMaintain(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Get the case ID
    caseHeaderKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(key.plannedItemIDKey).caseID;

    // Set the service plan security check key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID;

    // Set the service plan security check type
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Get the service plan id
    servicePlanDeliveryKey.caseID = caseHeaderKey.caseID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = ServicePlanDeliveryFactory.newInstance().read(servicePlanDeliveryKey).servicePlanID;

    // Check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // Operation SID security check failed
        throw new AppException(
          BPOSERVICEPLANSECURITY.ERR_MAINTAIN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // User-participant item sensitivity check failed
        throw new AppException(
          BPOSERVICEPLANSECURITY.ERR_MAINTAIN_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
  }

  /**
   * Checks that the user is allowed to view the service plan.
   *
   * @param key
   * ID of the service plan that is being viewed.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * service plan.
   */
  @Override
  protected void securityCheckRead(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Get the case ID
    caseHeaderKey.caseID = key.caseID;
    // plannedItemObj.readCaseIDByPlannedItemID(key.plannedItemIDKey).caseID;

    // Set the service plan security check key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID;

    // Set the service plan security check type
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Get the service plan id
    servicePlanDeliveryKey.caseID = caseHeaderKey.caseID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = ServicePlanDeliveryFactory.newInstance().read(servicePlanDeliveryKey).servicePlanID;

    // Check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // Operation SID security check failed
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
  }

  /**
   * Validates the absence details for the cancel operation.
   *
   * @param details
   * Contains the absence details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_RV_CANNOT_DELETE_SYSTEM_CREATED_RECORDS}
   * -
   * absence date can not be later than service to date of the roster
   * line item.
   */
  @Override
  protected void validateCancel(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // Verify that the record has been manually created
    if (details.dtls.dtls.createdBySystem == true) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_RV_CANNOT_DELETE_SYSTEM_CREATED_RECORDS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    TransactionInfo.getInformationalManager().failOperation();
  }

  /**
   * Validates the absence details for the cancel operation.
   *
   * @param details
   * Contains the absence details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_XRV_ABSENCE_PERIOD_OVERLAPS} -
   * manually created absence records with the same absence reason cannot
   * overlap.
   */
  @Override
  protected void validateInsert(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.core.sl.entity.intf.AbsencePeriod absencePeriodObj = curam.core.sl.entity.fact.AbsencePeriodFactory.newInstance();

    // Set the planned item key
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = details.plannedItemID;

    // Validate the mandatory absence period details
    validateDetails(details);

    if (details.dtls.dtls.createdBySystem == false) {

      // Declare the count details struct
      CountDetails countDetails = new CountDetails();

      // BEGIN, CR00127318, CSH
      final PlannedItemAbsencePeriodDetails plannedItemAbsencePeriodDetails = new PlannedItemAbsencePeriodDetails();

      // Set the details to check against existing records
      plannedItemAbsencePeriodDetails.absenceDate = details.dtls.dtls.absenceDate;
      plannedItemAbsencePeriodDetails.absencePeriodID = details.dtls.dtls.absencePeriodID;
      plannedItemAbsencePeriodDetails.absenceReason = details.dtls.dtls.absenceReason;
      plannedItemAbsencePeriodDetails.createdBySystem = details.dtls.dtls.createdBySystem;
      plannedItemAbsencePeriodDetails.creationDate = details.dtls.dtls.creationDate;
      plannedItemAbsencePeriodDetails.name = details.planItemName;
      plannedItemAbsencePeriodDetails.periodEndDate = details.dtls.dtls.periodEndDate;
      plannedItemAbsencePeriodDetails.periodStartDate = details.dtls.dtls.periodStartDate;
      plannedItemAbsencePeriodDetails.plannedItemID = details.plannedItemID;
      plannedItemAbsencePeriodDetails.recordStatus = details.dtls.dtls.recordStatus;
      plannedItemAbsencePeriodDetails.unitsUnattended = details.dtls.dtls.unitsUnattended;
      plannedItemAbsencePeriodDetails.versionNo = details.dtls.dtls.versionNo;

      // Check for duplicate periods
      countDetails = absencePeriodObj.countDuplicatePeriods(
        plannedItemAbsencePeriodDetails);
      // END, CR00127318

      // The period of the absence must not overlap with an existing absence
      // which has the same reason
      if (countDetails.numberOfRecords != 0) {

        final AppException appException = new AppException(
          BPOCLIENTPARTICIPATION.ERR_ABSENCE_XRV_ABSENCE_PERIOD_OVERLAPS);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }
    }

    TransactionInfo.getInformationalManager().failOperation();
  }

  /**
   * Validates the absence details for the cancel operation.
   *
   * @param details
   * Contains the absence details.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_RV_CANNOT_MODIFY_SYSTEM_CREATED_RECORDS}
   * -
   * system created absence period records cannot be modified by a user.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_XRV_ABSENCE_PERIOD_OVERLAPS} -
   * absence period must not overlap with an existing absence period
   * has the same absence reason.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void validateModify(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.core.sl.entity.intf.AbsencePeriod absencePeriodObj = curam.core.sl.entity.fact.AbsencePeriodFactory.newInstance();

    // Validate the mandatory absence period details
    validateDetails(details);

    // Verify that the record has been manually created and
    // has a valid plan item type
    if (details.dtls.dtls.createdBySystem == true) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_RV_CANNOT_MODIFY_SYSTEM_CREATED_RECORDS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (details.dtls.dtls.createdBySystem == false) {

      // Declare the count details struct
      CountDetails countDetails = new CountDetails();

      // BEGIN, CR00127318, CSH
      final PlannedItemAbsencePeriodDetails plannedItemAbsencePeriodDetails = new PlannedItemAbsencePeriodDetails();

      // Set the details to check against existing records
      plannedItemAbsencePeriodDetails.absenceDate = details.dtls.dtls.absenceDate;
      plannedItemAbsencePeriodDetails.absencePeriodID = details.dtls.dtls.absencePeriodID;
      plannedItemAbsencePeriodDetails.absenceReason = details.dtls.dtls.absenceReason;
      plannedItemAbsencePeriodDetails.createdBySystem = details.dtls.dtls.createdBySystem;
      plannedItemAbsencePeriodDetails.creationDate = details.dtls.dtls.creationDate;
      plannedItemAbsencePeriodDetails.name = details.planItemName;
      plannedItemAbsencePeriodDetails.periodEndDate = details.dtls.dtls.periodEndDate;
      plannedItemAbsencePeriodDetails.periodStartDate = details.dtls.dtls.periodStartDate;
      plannedItemAbsencePeriodDetails.plannedItemID = details.plannedItemID;
      plannedItemAbsencePeriodDetails.recordStatus = details.dtls.dtls.recordStatus;
      plannedItemAbsencePeriodDetails.unitsUnattended = details.dtls.dtls.unitsUnattended;
      plannedItemAbsencePeriodDetails.versionNo = details.dtls.dtls.versionNo;

      // Check for duplicate periods
      countDetails = absencePeriodObj.countDuplicatePeriodsForModify(
        plannedItemAbsencePeriodDetails);
      // END, CR00127318
      // The period of the absence must not overlap with an existing absence
      // which has the same reason
      if (countDetails.numberOfRecords != 0) {

        final AppException appException = new AppException(
          BPOCLIENTPARTICIPATION.ERR_ABSENCE_XRV_ABSENCE_PERIOD_OVERLAPS);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

    TransactionInfo.getInformationalManager().failOperation();
  }

  // ___________________________________________________________________________
  /**
   * This method verifies the mandatory details required for recording
   * an absence period for a plan item.
   *
   * @param details - The planned item absence details.
   *
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_FV_PERIOD_START_DATE_NOT_PROVIDED}
   * -
   * period start date must be provided.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_FV_ABSENCE_REASON_NOT_PROVIDED} -
   * absence reason must be provided.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_CLIENTPARTICIPATION_FV_PLAN_ITEM_NOT_PROVIDED}
   * -
   * plan item must be provided.
   * @throws AppException Generic Exception Signature.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_FV_PERIOD_END_DATE_NOT_PROVIDED}
   * -
   * period end date must be provided.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_ABSENCE_FV_UNITS_UNATTENDED_NOT_PROVIDED}
   * -
   * number of units not attended must be provided.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void validateDetails(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // Plan item must be entered
    if (details.plannedItemID == 0) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PLAN_ITEM_NOT_PROVIDED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Period Start Date must be entered
    if (details.dtls.dtls.periodStartDate.isZero()) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_FV_PERIOD_START_DATE_NOT_PROVIDED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Period Start End must be entered
    if (details.dtls.dtls.periodEndDate.isZero()) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_FV_PERIOD_END_DATE_NOT_PROVIDED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Number of Units Not attended must be entered
    if (details.dtls.dtls.unitsUnattended == 0) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_FV_UNITS_UNATTENDED_NOT_PROVIDED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Absence Reason must be entered
    if (details.dtls.dtls.absenceReason.length() == 0) {

      final AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_FV_ABSENCE_REASON_NOT_PROVIDED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    TransactionInfo.getInformationalManager().failOperation();
  }
}
