/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.APPROVALCRITERIAWHEN;
import curam.codetable.APPROVALENACTEDFROM;
import curam.codetable.APPROVALPROCESSINGSTATUS;
import curam.codetable.APPROVALREQUESTSTATUS;
import curam.codetable.PIAPPROVALCRITERIASTATUS;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.REJECTIONREASON;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.ApprovalRequestIDAndVersionNoDetails;
import curam.core.sl.entity.struct.ApprovalRequestStatusDetails;
import curam.core.sl.entity.struct.ModifyStatusRejectReasonAndCommentsDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersKey;
import curam.events.SERVICEPLANS;
import curam.message.BPOAPPROVALCRITERIA;
import curam.message.BPOPAAPPROVALREQUEST;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.PAApprovalRequestFactory;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemApprovalCriteriaFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.PAApprovalRequest;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemApprovalCriteria;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.PIApprovalCriteriaApprovalStatusUpdateDetails;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaSummaryDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalProcessingStatusDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndApprovalRequestStatusKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.SetPlannedItemStatusKey;
import curam.serviceplans.sl.struct.ApprovalRequestPlannedItemIDKey;
import curam.serviceplans.sl.struct.OutstandingApprovalsResult;
import curam.serviceplans.sl.struct.PAApprovalRequestDetailsList;
import curam.serviceplans.sl.struct.PAApprovalRequestKey;
import curam.serviceplans.sl.struct.PIApprovalCriteriaStatusUpdateDtls;
import curam.serviceplans.sl.struct.PlannedItemApprovalRequestDetails;
import curam.serviceplans.sl.struct.PlannedItemIDAndApprovalCriteriaKey;
import curam.serviceplans.sl.struct.PlannedItemIDAndApprovalOccursWhenKey;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.PlannedItemIDList;
import curam.serviceplans.sl.struct.PlannedItemNameDetailsStruct;
import curam.serviceplans.sl.struct.PlannedItemStatusStruct;
import curam.serviceplans.sl.struct.ProcessPIApprovalCriteriaResults;
import curam.serviceplans.sl.struct.RejectionReasonAndRejectionComments;
import curam.serviceplans.sl.struct.ServicePlanAndParticipantDetails;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanPlanItemApprovalSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanPlanItemSecurityKey;
import curam.serviceplans.sl.struct.StatusChangeDetails;
import curam.serviceplans.workflow.wfl.struct.CaseIDAndEnactedFromDetails;
import curam.serviceplans.workflow.wfl.struct.PlannedItemIDKeyList;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.events.struct.EventKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.StringList;
import curam.util.workflow.impl.EnactmentService;
import java.util.ArrayList;
import java.util.List;


/**
 * This process class provides the functionality for servicePlans
 * Planned Item Approval Request service layer.
 */
public abstract class PlannedItemApprovalRequest extends curam.serviceplans.sl.base.PlannedItemApprovalRequest {

  /**
   * Lists all approval requests associated with a specific planned item.
   *
   * @param approvalRequestPlannedItemIDKey
   * Contains the planned item ID.
   *
   * @return A list of all approval requests associated with the planned item.
   *
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_VIEW_SERVICEPLAN_CHECK_FAILED} -
   * if the user does not have appropriate privileges to view this
   * approval request.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public PAApprovalRequestDetailsList list(
    ApprovalRequestPlannedItemIDKey approvalRequestPlannedItemIDKey)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // create Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // create planned item key
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey.plannedItemID;

    plannedItemIDKey.plannedItemIDKey.plannedItemID = approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey.plannedItemID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security if maintain rights are defined
    // Also check sensitivity check for user
    // Below check will do both:
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        curam.message.BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // create return value
    final PAApprovalRequestDetailsList paApprovalRequestDetailsList = new PAApprovalRequestDetailsList();

    // PlannedItemApprovalRequest entity object
    final PAApprovalRequest plannedItemApprovalRequestObj = PAApprovalRequestFactory.newInstance();

    // create planned item manipulation variable
    final PlannedItemNameDetailsStruct plannedItemNameDetailsStruct = new PlannedItemNameDetailsStruct();

    // set planned item key
    plannedItemIDKey.plannedItemIDKey.plannedItemID = approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey.plannedItemID;

    // set planned item key
    final curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.entity.struct.PlannedItemKey();

    plannedItemKey.plannedItemID = approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey.plannedItemID;

    // BEGIN, CR00236077, NS
    final PlanItemIDDetailsStruct planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
      plannedItemIDKey.plannedItemIDKey);
    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = planItemIDDetailsStruct.planItemID;
    final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
      planItemKey);

    if (nameNotEditableIndDetails.nameNotEditableInd) {
      plannedItemNameDetailsStruct.plannedItemNameDetailsStruct.name = CodeTable.getOneItem(
        PLANITEMNAME.TABLENAME, nameNotEditableIndDetails.name,
        TransactionInfo.getProgramLocale());
    } else {
      plannedItemNameDetailsStruct.plannedItemNameDetailsStruct = plannedItemObj.readName(
        plannedItemIDKey.plannedItemIDKey);
    }
    // END, CR00236077

    // search for all approval requests based on the planned item id
    paApprovalRequestDetailsList.list = plannedItemApprovalRequestObj.searchApprovalRequestByPlannedItemID(
      plannedItemKey);

    // set planed plan item name
    paApprovalRequestDetailsList.plannedItemNameDetailsStruct = plannedItemNameDetailsStruct;

    // return approval request list
    return paApprovalRequestDetailsList;
  }

  /**
   * Reads an approval request associated with a specific planned item.
   *
   * @param paApprovalRequestKey
   * Contains the Unique reference number assigned by the system to the
   * planned item approval request record.
   *
   * @return Details on an approval request associated with the planned item.
   *
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_VIEW_SERVICEPLAN_CHECK_FAILED} -
   * if the user does not have appropriate privileges to view this
   * approval request.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public PlannedItemApprovalRequestDetails readByPlannedItemID(
    PAApprovalRequestKey paApprovalRequestKey) throws AppException,
      InformationalException {

    // create return value
    final PlannedItemApprovalRequestDetails plannedItemApprovalRequestDetails = new PlannedItemApprovalRequestDetails();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // create Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // create Planned Item Approval Request Object
    final PAApprovalRequest plannedItemApprovalRequestObj = PAApprovalRequestFactory.newInstance();

    // create entity key
    curam.serviceplans.sl.entity.struct.PAApprovalRequestKey paApprovalRequestKeyEN = new curam.serviceplans.sl.entity.struct.PAApprovalRequestKey();

    paApprovalRequestKeyEN = paApprovalRequestKey.paApprovalRequestKey;
    // Read the planned item approval request record

    plannedItemApprovalRequestDetails.paApprovalRequestDtls = plannedItemApprovalRequestObj.read(
      paApprovalRequestKeyEN);

    // create planned item key
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemApprovalRequestDetails.paApprovalRequestDtls.plannedItemID;

    plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemApprovalRequestDetails.paApprovalRequestDtls.plannedItemID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security if maintain rights are defined
    // Also check sensitivity check for user
    // Below check will do both:
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Create approval request key
    final curam.core.sl.entity.struct.ApprovalRequestKey approvalRequestKey = new curam.core.sl.entity.struct.ApprovalRequestKey();

    // ApprovalRequest entity manipulation variables
    final curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();

    // Set approvalRequestKey
    approvalRequestKey.approvalRequestID = plannedItemApprovalRequestDetails.paApprovalRequestDtls.approvalRequestID;

    // Read the approval request record
    plannedItemApprovalRequestDetails.approvalRequestDtls = approvalRequestObj.read(
      approvalRequestKey);

    // User manipulation variables
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey requestedByUsersKey = new UsersKey();
    final UsersKey approvalDecisionUsersKey = new UsersKey();

    // Set the full name of the requested by user
    if (plannedItemApprovalRequestDetails.approvalRequestDtls.requestedByUser
      != null
        && plannedItemApprovalRequestDetails.approvalRequestDtls.requestedByUser.length()
          != 0) {

      requestedByUsersKey.userName = plannedItemApprovalRequestDetails.approvalRequestDtls.requestedByUser;
      plannedItemApprovalRequestDetails.requestedByUserFullName = usersObj.getFullName(requestedByUsersKey).fullname;
    }
    // Set the full name of user that made the approval decision
    if (plannedItemApprovalRequestDetails.approvalRequestDtls.approvalDecisionByUser
      != null
        && plannedItemApprovalRequestDetails.approvalRequestDtls.approvalDecisionByUser.length()
          != 0) {

      approvalDecisionUsersKey.userName = plannedItemApprovalRequestDetails.approvalRequestDtls.approvalDecisionByUser;
      plannedItemApprovalRequestDetails.decisionMadeByUserFullName = usersObj.getFullName(approvalDecisionUsersKey).fullname;
    }

    plannedItemApprovalRequestDetails.caseID = servicePlanDeliveryKey.caseID;

    // Return the planned item approval request record and the related approval
    // request record.
    return plannedItemApprovalRequestDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads approval request ID and version number
   *
   * @param key Planned item approval request unique identifier
   *
   * @return approval request ID and version number
   */
  @Override
  public curam.serviceplans.sl.struct.RejectionDetailsForModify readDetailsForModify(PAApprovalRequestKey key) throws AppException,
      InformationalException {

    // return value
    final curam.serviceplans.sl.struct.RejectionDetailsForModify rejectionDetailsForModify = new curam.serviceplans.sl.struct.RejectionDetailsForModify();

    // PAApprovalRequest entity object
    final curam.serviceplans.sl.entity.intf.PAApprovalRequest paApprovalRequestObj = curam.serviceplans.sl.entity.fact.PAApprovalRequestFactory.newInstance();

    // call validations
    validateReadDetailsForModify(key);

    // read approval request details
    rejectionDetailsForModify.dtls = paApprovalRequestObj.readRejectionDetailsForModify(
      key.paApprovalRequestKey);

    return rejectionDetailsForModify;
  }

  /**
   * On display validation for modify.
   *
   * @param key
   * Planned item approval request unique identifier.
   *
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_APPROVAL_NOT_REJECTED} - if this
   * approval request is being modified. Only rejected approval
   * requests may be modified.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_UPDATE_SERVICEPLAN_CHECK_FAILED} - if the
   * user does not have appropriate privileges to update this
   * approval request.
   */
  @Override
  public void validateReadDetailsForModify(PAApprovalRequestKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // PAApprovalRequest entity object
    final curam.serviceplans.sl.entity.intf.PAApprovalRequest paApprovalRequestObj = curam.serviceplans.sl.entity.fact.PAApprovalRequestFactory.newInstance();

    // PlannedItem manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // set planned item key
    plannedItemIDKey.plannedItemID = paApprovalRequestObj.read(key.paApprovalRequestKey).plannedItemID;

    // set service plan delivery key
    servicePlanDeliveryKey.key.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey).caseID;

    // read service plan ID and concern role ID
    final ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = servicePlanDeliveryObj.readServicePlanIDAndConcernRoleID(
      servicePlanDeliveryKey);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_UPDATE_SERVICEPLAN_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read approval check status
    final ApprovalRequestStatusDetails approvalRequestStatusDetails = paApprovalRequestObj.readApprovalRequestStatus(
      key.paApprovalRequestKey);

    // approval must be rejected
    if (!approvalRequestStatusDetails.status.equals(
      APPROVALREQUESTSTATUS.REJECTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPAAPPROVALREQUEST.ERR_APPROVAL_NOT_REJECTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * This method is used to submit a service plan planned item.
   *
   * @param plannedItemIDKey key containing details of the planned item
   */
  @Override
  public void submit(
    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // BEGIN, CR00161962, LJ
    // Perform common submit processing
    processSubmitDetails(plannedItemIDKey);

    // Call the common approval process for the planned item
    // User must pass further security checks for approval, hence the use of a
    // try catch
    try {

      processApproveDetails(plannedItemIDKey);

      // Perform approval processing
      approve(plannedItemIDKey);

    } catch (final AppException e) {

      if (e.equals(
        curam.message.BPOPAAPPROVALREQUEST.ERR_APPROVE_PARTICIPANT_CHECK_FAILED)) {
        // User does not have security rights to approve the planned item
        // Rather than throw an exception, raise a task for users supervisor
        // to approve the planned item

        // PlannedItem Object
        final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

        // Manipulation variables
        ReadCaseIDByPlannedItemDetailsStruct servicePlanCaseID = new ReadCaseIDByPlannedItemDetailsStruct();
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        // Obtain service plan delivery caseID
        servicePlanCaseID = plannedItemObj.readCaseIDByPlannedItemID(
          plannedItemIDKey.plannedItemIDKey);
        caseHeaderKey.caseID = servicePlanCaseID.caseID;

        // Initialize an event
        final Event manuallyApprovePI = new Event();

        // Set event to be of type ApproveServicePlan
        manuallyApprovePI.eventKey = SERVICEPLANS.MANUALAPPROVEPLANNEDITEM;

        // Populate data needed for workflow
        manuallyApprovePI.primaryEventData = caseHeaderKey.caseID;

        manuallyApprovePI.secondaryEventData = plannedItemIDKey.plannedItemIDKey.plannedItemID;

        // Trigger event to call workflow
        EventService.raiseEvent(manuallyApprovePI);

      } else {
        // Some other error occurred
        throw e;
      }
    }
    // END, CR00161962
  }

  // ___________________________________________________________________________
  /**
   * This method is used to approve a service plan planned item.
   *
   * @param plannedItemIDKey key containing details of the planned item
   */
  @Override
  public void approve(
    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    final PlannedItemIDKey itemIDKey = new PlannedItemIDKey();

    itemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(itemIDKey.plannedItemIDKey).caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(
          curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // BEGIN, CR00161962, LJ
    // Perform security and other validations
    processApproveDetails(plannedItemIDKey);

    // Approval processing status manipulation variables
    PlannedItemApprovalProcessingStatusDetails approvalProcessingStatus = new PlannedItemApprovalProcessingStatusDetails();

    // Obtain the approval processing status as we only
    // want to approve planned items
    // that are not already being processed.
    approvalProcessingStatus = plannedItemObj.readApprovalProcessingStatusByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);

    // Planned item should have a 'not started' approval processing status
    // If not, throw an exception
    if (!approvalProcessingStatus.approvalProcessingStatus.equals(
      APPROVALPROCESSINGSTATUS.NOT_STARTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_PLANNED_ITEM_ALREADY_IN_APPROVAL_PROCESS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    } else {
      // Set approval processing status to 'in progress' and modify record
      // This will prevent the planned item being actioned multiple times if
      // sent for approval again
      approvalProcessingStatus.approvalProcessingStatus = APPROVALPROCESSINGSTATUS.IN_PROGRESS;

      plannedItemObj.modifyPlannedItemApprovalProcessingStatus(
        plannedItemIDKey.plannedItemIDKey, approvalProcessingStatus);
    }

    // Obtain the caseID (i.e. service plan delivery)
    // that this planned item belongs to

    // Manipulation variable
    ReadCaseIDByPlannedItemDetailsStruct servicePlanCaseID = new ReadCaseIDByPlannedItemDetailsStruct();

    // Obtain service plan delivery caseID
    servicePlanCaseID = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);

    // Create workflow data enactment structs
    final PlannedItemIDKeyList plannedItemIDKeyList = new PlannedItemIDKeyList();
    final curam.serviceplans.sl.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.struct.PlannedItemKey();
    final CaseIDAndEnactedFromDetails caseIDAndEnactedFromDtls = new CaseIDAndEnactedFromDetails();

    // Set planned item ID
    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Populate structs with data
    plannedItemIDKeyList.key.addRef(plannedItemKey);
    caseIDAndEnactedFromDtls.caseID = servicePlanCaseID.caseID;

    // Set enacted from variable
    caseIDAndEnactedFromDtls.enactedFrom = APPROVALENACTEDFROM.PLANNEDITEM;
    // as long as we have at least 1 planned item to approve
    // then call the approval workflow
    if (plannedItemIDKeyList.key.size() > 0) {
      // Create enactment data list
      final List enactmentDataList = new ArrayList();

      // Add enactment data to list
      enactmentDataList.add(caseIDAndEnactedFromDtls);
      enactmentDataList.add(plannedItemIDKeyList);

      // Set the status of any pre approval criteria planned item records
      final StatusChangeDetails statusChangeDetails = new StatusChangeDetails();

      statusChangeDetails.changeToStatus = PIAPPROVALCRITERIASTATUS.READY_TO_PROCESS;

      setPIApprovalCriteriaStatusForPlannedItemList(plannedItemIDKeyList,
        statusChangeDetails);

      // Enact main approval workflow process
      EnactmentService.startProcess(
        ServicePlanConst.kServicePlanAndPlannedItemApprovalWorkflow,
        enactmentDataList);
    }
    // END, CR00161962
  }

  /**
   * This method is used to reject a service plan planned item.
   *
   * @param plannedItemIDKey
   * key containing details of the planned item
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_SERVICEPLAN_PLAN_ITEM_FV_REJEC_REASON_EMPTY}
   * - if the Rejection Reason is not entered.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_REJECT_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to reject
   * this plan item.
   */
  @Override
  public void reject(PlannedItemIDKey plannedItemIDKey,
    RejectionReasonAndRejectionComments details) throws AppException,
      InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemApprovalSecurityKey servicePlanPlanItemApprovalSecurityKey = new ServicePlanPlanItemApprovalSecurityKey();

    // Ensure that reason was set
    if (details.rejectionReason.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_SERVICEPLAN_PLAN_ITEM_FV_REJEC_REASON_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    // ServicePlanSecurity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    servicePlanPlanItemApprovalSecurityKey.planItemID = plannedItemObj.readPlanItemID(plannedItemIDKey.plannedItemIDKey).planItemID;

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    final PlannedItemIDKey itemIDKey = new PlannedItemIDKey();

    itemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(itemIDKey.plannedItemIDKey).caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // check plan item sensitivity
    try {
      servicePlanSecurity.planItemSensitivityCheck(plannedItemIDKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_REJECT_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Check plan item approval security if approval security identifier was set
    // on planItem.
    try {
      servicePlanSecurity.approvePlanItemSecurityCheck(
        servicePlanPlanItemApprovalSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLANITEMAPPROVAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_REJECT_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Validate the details
    validateRejectDetails(plannedItemIDKey);

    final SetPlannedItemStatusKey setPlannedItemStatusKey = new SetPlannedItemStatusKey();

    // Set the planeedPlanItem status equal to Submitted
    setPlannedItemStatusKey.plannedItemStatus = curam.codetable.PLANNEDITEMSTATUS.UNAPPROVED;

    setPlannedItemStatusKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // set the status
    plannedItemObj.setStatusCode(setPlannedItemStatusKey);

    // System user maintenance object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // plannedItemApprovalRequest object
    final curam.serviceplans.sl.entity.intf.PAApprovalRequest paApprovalRequestObj = curam.serviceplans.sl.entity.fact.PAApprovalRequestFactory.newInstance();
    final PlannedItemIDAndApprovalRequestStatusKey plannedItemIDAndApprovalRequestStatusKey = new PlannedItemIDAndApprovalRequestStatusKey();

    // approvalRequest object and manipulation variables
    final curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();
    final ModifyStatusRejectReasonAndCommentsDetails modifyStatusRejectReasonAndCommentsDetails = new ModifyStatusRejectReasonAndCommentsDetails();
    final curam.core.sl.entity.struct.ApprovalRequestKey approvalRequestKey = new curam.core.sl.entity.struct.ApprovalRequestKey();

    // set the key for reading approval request details
    plannedItemIDAndApprovalRequestStatusKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    plannedItemIDAndApprovalRequestStatusKey.status = APPROVALREQUESTSTATUS.SUBMITTED;

    // read approval request details
    final ApprovalRequestIDAndVersionNoDetails approvalRequestIDAndVersionNoDetails = paApprovalRequestObj.readApprovalRequestIDAndVersionNoByPlannedItemIDAndApprovalRequestStatus(
      plannedItemIDAndApprovalRequestStatusKey);

    // modify approval request - set status to 'rejected'.
    approvalRequestKey.approvalRequestID = approvalRequestIDAndVersionNoDetails.approvalRequestID;
    modifyStatusRejectReasonAndCommentsDetails.status = APPROVALREQUESTSTATUS.REJECTED;
    modifyStatusRejectReasonAndCommentsDetails.approvalDecisionDate = Date.getCurrentDate();
    modifyStatusRejectReasonAndCommentsDetails.approvalDecisionByUser = systemUserDtls.userName;
    modifyStatusRejectReasonAndCommentsDetails.versionNo = approvalRequestIDAndVersionNoDetails.versionNo;
    modifyStatusRejectReasonAndCommentsDetails.rejectionComments = details.rejectionComments;
    modifyStatusRejectReasonAndCommentsDetails.rejectionReason = details.rejectionReason;

    // reject approval request
    approvalRequestObj.modifyStatusRejectionReasonAndComments(
      approvalRequestKey, modifyStatusRejectReasonAndCommentsDetails);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.REJECTPLANITEM;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * This method is used to validate the details of the planned item to be
   * submitted.
   *
   * @param plannedItemIDKey key containing details of the planned item
   */
  @Override
  public void validateSubmitDetails(
    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // PlannedItem entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntityObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final PlannedItemStatusStruct plannedItemStatusStruct = new PlannedItemStatusStruct();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Read the status
    plannedItemStatusStruct.plannedItemStatusStruct = plannedItemEntityObj.readStatus(
      plannedItemIDKey.plannedItemIDKey);

    // If the PlannedItem status is not equal to Unapproved then throw
    // validation
    if (!plannedItemStatusStruct.plannedItemStatusStruct.status.equals(
      PLANNEDITEMSTATUS.UNAPPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_SERVICEPLAN_PLAN_ITEM_XRV_NOT_UNAPPROVED_NO_SUBMIT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // validate the details
    plannedItemObj.validatePlannedItemDetails(plannedItemIDKey,
      curam.codetable.PLANNEDITEMSTATUS.SUBMITTED);

  }

  // ___________________________________________________________________________
  /**
   * This method is used to validate the details of the planned item to be
   * approved.
   *
   * @param plannedItemIDKey key containing details of the planned item
   */
  @Override
  public void validateApproveDetails(
    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // BEGIN CR00108989, GBA
    // PlannedItem entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntityObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Read the planned item record
    final PlannedItemDtls plannedItemDtls = plannedItemEntityObj.read(
      plannedItemKey);

    // BEGIN, CR00161962, LJ
    // If the PlannedItem status is equal to 'Not Started' then throw validation
    if (plannedItemDtls.status.equals(
      curam.codetable.PLANNEDITEMSTATUS.NOTSTARTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_SERVICEPLAN_PLAN_ITEM_APPROVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

      // Next, if the PlannedItem status is not equal to 'Submitted' then throw
      // validation
    } else if (!plannedItemDtls.status.equals(
      curam.codetable.PLANNEDITEMSTATUS.SUBMITTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_SERVICEPLAN_PLAN_ITEM_XRV_NOT_SUBMITTED_NO_APPROVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00161962
    // If concerning participant is not there, throw validation
    if (plannedItemDtls.concerningID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_PLANNED_ITEM_CONCERNING_NOT_PRESENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END CR00108989
    // BEGIN, CR00161962, LJ
    // validate the details
    plannedItemObj.validateCaseStatus(plannedItemIDKey);
    // END, CR00161962

  }

  // ___________________________________________________________________________
  /**
   * This method is used to validate the details of the planned item to be
   * rejected.
   *
   * @param plannedItemIDKey key containing details of the planned item
   */
  @Override
  public void validateRejectDetails(
    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // PlannedItem entity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntityObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final PlannedItemStatusStruct plannedItemStatusStruct = new PlannedItemStatusStruct();
    // BEGIN, CR00161962, LJ
    PlannedItemApprovalProcessingStatusDetails plannedItemApprovalProcessingStatusStruct = new PlannedItemApprovalProcessingStatusDetails();
    // END, CR00161962

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Read the status
    plannedItemStatusStruct.plannedItemStatusStruct = plannedItemEntityObj.readStatus(
      plannedItemIDKey.plannedItemIDKey);
    // BEGIN, CR00161962, LJ
    plannedItemApprovalProcessingStatusStruct = plannedItemEntityObj.readApprovalProcessingStatusByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);
    // END, CR00161962
    // If the PlannedItem status is not equal to 'Submitted' then throw
    // validation
    if (!plannedItemStatusStruct.plannedItemStatusStruct.status.equals(
      curam.codetable.PLANNEDITEMSTATUS.SUBMITTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_SERVICEPLAN_PLAN_ITEM_XRV_NOT_SUBMITTED_NO_REJECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    } else if (!plannedItemApprovalProcessingStatusStruct.approvalProcessingStatus.equals(
      curam.codetable.APPROVALPROCESSINGSTATUS.NOT_STARTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPAAPPROVALREQUEST.ERR_SERVICEPLAN_PLAN_ITEM_XRV_IN_APPROVAL_PROCESS_NO_REJECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00161962
    // Validate the details
    plannedItemObj.validatePlannedItemDetails(plannedItemIDKey,
      curam.codetable.PLANNEDITEMSTATUS.REJECTED);

  }

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * This method is used to approve a list of service plan planned items.
   *
   * @param keyList keyList containing details of the planned items
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void approvePlannedItemList(final PlannedItemIDList keyList)
    throws AppException, InformationalException {

    // PlannedItem Object and struct manipulation variable
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Approval processing status manipulation variables
    PlannedItemApprovalProcessingStatusDetails approvalProcessingStatus = new PlannedItemApprovalProcessingStatusDetails();

    // CaseID Manipulation variable
    ReadCaseIDByPlannedItemDetailsStruct servicePlanCaseID = new ReadCaseIDByPlannedItemDetailsStruct();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Obtain service plan delivery caseID
    // Use any of the planned item id's in the list - just use the first

    // Create entity struct
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    // Set plannedItemID
    plannedItemIDKey.plannedItemIDKey.plannedItemID = keyList.key.item(0).plannedItemID;

    // Read caseID
    servicePlanCaseID = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey);
    caseHeaderKey.caseID = servicePlanCaseID.caseID;

    // Process each planned item in the list
    for (int i = 0; i < keyList.key.size(); i++) {

      // Call the common approval process for the planned item
      // User must pass further security checks for approval,
      // hence the use of a try catch
      try {
        // Set plannedItemID
        plannedItemIDKey.plannedItemIDKey.plannedItemID = keyList.key.item(i).plannedItemID;

        processApproveDetails(plannedItemIDKey);

      } catch (final AppException ae) {

        if (ae.equals(
          curam.message.BPOPAAPPROVALREQUEST.ERR_APPROVE_PARTICIPANT_CHECK_FAILED)) {
          // User does not have security rights to approve the planned item
          // Rather than throw an exception, raise a task for users supervisor
          // to approve the planned item

          // Initialize an event
          final Event manuallyApprovePI = new Event();

          // Set event to be of type ApproveServicePlan
          manuallyApprovePI.eventKey = SERVICEPLANS.MANUALAPPROVEPLANNEDITEM;

          // Populate data needed for workflow
          manuallyApprovePI.primaryEventData = caseHeaderKey.caseID;

          manuallyApprovePI.secondaryEventData = keyList.key.item(i).plannedItemID;

          // Trigger event to call workflow
          EventService.raiseEvent(manuallyApprovePI);

          // Now, remove that planned item from the list
          // And jump to the start of the loop to process next planned item
          keyList.key.remove(i);
          continue;

        } else {
          // Some other error occurred
          throw ae;
        }
      }

      // Obtain the approval processing status as we only want to approve
      // planned items that are not already being processed.

      // Set plannedItemID
      plannedItemIDKey.plannedItemIDKey.plannedItemID = keyList.key.item(i).plannedItemID;

      approvalProcessingStatus = plannedItemObj.readApprovalProcessingStatusByPlannedItemID(
        plannedItemIDKey.plannedItemIDKey);

      // Planned item should have a 'not started' approval processing status
      if (!approvalProcessingStatus.approvalProcessingStatus.equals(
        APPROVALPROCESSINGSTATUS.NOT_STARTED)) {
        // Means the planned item has been submitted for approval previously
        // Remove it from keyList and jump to the start of the loop to
        // process next planned item
        keyList.key.remove(i);
        continue;
      } else {
        // Set approval processing status to 'in progress' and modify record
        // This will prevent the planned item being actioned multiple times if
        // sent for approval again
        approvalProcessingStatus.approvalProcessingStatus = APPROVALPROCESSINGSTATUS.IN_PROGRESS;

        plannedItemObj.modifyPlannedItemApprovalProcessingStatus(
          plannedItemIDKey.plannedItemIDKey, approvalProcessingStatus);
      }
    } // End of for loop

    // At this time we have a keyList of valid planned item IDs that can be
    // passed to the main approval workflow to perform any approval criteria

    // Obtain the caseID (i.e. service plan delivery) that the planned items
    // belong to

    // Create workflow data enactment structs
    final PlannedItemIDKeyList plannedItemIDKeyList = new PlannedItemIDKeyList();
    final CaseIDAndEnactedFromDetails caseIDAndEnactedFromDtls = new CaseIDAndEnactedFromDetails();

    // Populate structs with data
    for (int j = 0; j < keyList.key.size(); j++) {
      final curam.serviceplans.sl.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.struct.PlannedItemKey();

      plannedItemKey.plannedItemID = keyList.key.item(j).plannedItemID;

      plannedItemIDKeyList.key.addRef(plannedItemKey);

    }

    // Set enactment variables
    caseIDAndEnactedFromDtls.caseID = servicePlanCaseID.caseID;
    caseIDAndEnactedFromDtls.enactedFrom = APPROVALENACTEDFROM.SERVICEPLANDELIVERY;
    // as long as we have at least 1 planned item to approve then
    // call the ServicePlanAndPlannedItemApprovalWorkflow workflow
    if (plannedItemIDKeyList.key.size() > 0) {
      // Create enactment data list
      final List enactmentDataList = new ArrayList();

      // Add enactment data to list
      enactmentDataList.add(caseIDAndEnactedFromDtls);
      enactmentDataList.add(plannedItemIDKeyList);

      // Set the status of any pre approval criteria planned item records
      final StatusChangeDetails statusChangeDetails = new StatusChangeDetails();

      statusChangeDetails.changeToStatus = PIAPPROVALCRITERIASTATUS.READY_TO_PROCESS;

      setPIApprovalCriteriaStatusForPlannedItemList(plannedItemIDKeyList,
        statusChangeDetails);

      // Enact main approval workflow process
      EnactmentService.startProcess(
        ServicePlanConst.kServicePlanAndPlannedItemApprovalWorkflow,
        enactmentDataList);
    }

  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * Method for determining if all planned items have completed all their
   * pre approval criteria and if they failed any.
   *
   * If any planned item has failed it's approval check, it will be removed
   * from the list before sending back.
   *
   * @param dtlsList - containing a list of all planned items requiring approval
   * @return PlannedItemIDList -
   * containing a list of all non failed approval criteria planned items
   * and an indicator highlighting if there are any outstanding approvals
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public PlannedItemIDList checkAllPreApprovalCriteriaComplete(
    PlannedItemIDList dtlsList) throws AppException, InformationalException {

    // Create manipulation objects

    // Create entity instances
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Create struct objects
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();
    PlannedItemApprovalProcessingStatusDetails approvalProcessingStatusDtls = new PlannedItemApprovalProcessingStatusDetails();

    final PlannedItemIDList processKeyList = new PlannedItemIDList();

    processKeyList.assign(dtlsList);

    final int processDtlsListSize = processKeyList.key.size();

    // For each item in the input list call planned item's
    // read approval processing status
    for (int i = 0; i < processDtlsListSize; i++) {

      plannedItemIDKey.plannedItemID = processKeyList.key.item(i).plannedItemID;

      approvalProcessingStatusDtls = plannedItemObj.readApprovalProcessingStatusByPlannedItemID(
        plannedItemIDKey);

      // If the approvalProcessingStatus=NOT_STARTED then the planned item
      // failed one of it's pre-approval criteria.
      // So, we shouldn't include this in the returned list
      if (approvalProcessingStatusDtls.approvalProcessingStatus.equals(
        APPROVALPROCESSINGSTATUS.NOT_STARTED)) {

        // Removed key from list
        dtlsList.key.remove(i);

      } else if (!approvalProcessingStatusDtls.approvalProcessingStatus.equals(
        APPROVALPROCESSINGSTATUS.READY_FOR_APPROVAL)) {
        // Set outstanding approval indicator then break out the loop
        // as there is no need to carry on
        dtlsList.outstandingApprovals.outstandingApprovals = true;
        break;

      }

    }

    // Return back the result
    return dtlsList;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for checking if a planned item has any outstanding approvals.
   *
   * @param key - planned item ID and occurs when setting (i.e. pre or post).
   * @return OutstandingApprovalsResult -
   * boolean indicating if there are any
   * outstanding approvals for the planned item
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public OutstandingApprovalsResult isOutstandingApprovals(
    PlannedItemIDAndApprovalOccursWhenKey key) throws AppException,
      InformationalException {

    // Create return struct
    final OutstandingApprovalsResult outstandingApprovalsResult = new OutstandingApprovalsResult();

    // Create manipulation objects
    final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

    // Read the planned item approval criteria table to
    // see if there are any approval criteria
    try {

      plannedItemApprovalCriteriaObj.readHighestPriorityByPlannedItemID(
        key.dtls);

      // There are details so set return struct accordingly
      outstandingApprovalsResult.outstandingApprovals = true;

    } catch (final RecordNotFoundException rNFE) {

      // Nothing actually wrong - just means the planned item has no approval
      // criteria
      // Set return struct accordingly
      outstandingApprovalsResult.outstandingApprovals = false;

    }

    // Return the result
    return outstandingApprovalsResult;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for completing the processing of planned items
   * that have come through the approval workflow.
   *
   * @param plannedItemIDKey - id of the planned item to process
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void processPlannedItem(final PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemServiceLayerObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    final PlannedItemStatusStruct status = new PlannedItemStatusStruct();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Validate the details
    validateApproveDetails(plannedItemIDKey);

    // current date
    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // System user maintenance object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // plannedItemApprovalRequest entity object
    final curam.serviceplans.sl.entity.intf.PAApprovalRequest paApprovalRequestObj = curam.serviceplans.sl.entity.fact.PAApprovalRequestFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDAndApprovalRequestStatusKey plannedItemIDAndApprovalRequestStatusKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDAndApprovalRequestStatusKey();

    // approvalRequest object
    final curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();

    // create approvalRequestKey and details
    final curam.core.sl.entity.struct.ApprovalRequestKey approvalRequestKey = new curam.core.sl.entity.struct.ApprovalRequestKey();
    final curam.core.sl.entity.struct.ApprovalDetails approvalDetails = new curam.core.sl.entity.struct.ApprovalDetails();

    // set the key for reading approval request details
    plannedItemIDAndApprovalRequestStatusKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    plannedItemIDAndApprovalRequestStatusKey.status = APPROVALREQUESTSTATUS.SUBMITTED;

    // read approval request details
    final curam.core.sl.entity.struct.ApprovalRequestIDAndVersionNoDetails approvalRequestIDAndVersionNoDetails = paApprovalRequestObj.readApprovalRequestIDAndVersionNoByPlannedItemIDAndApprovalRequestStatus(
      plannedItemIDAndApprovalRequestStatusKey);

    // set approval key and details
    approvalRequestKey.approvalRequestID = approvalRequestIDAndVersionNoDetails.approvalRequestID;
    approvalDetails.approvalDecisionByUser = systemUserDtls.userName;
    approvalDetails.approvalDecisionDate = currentDate;
    approvalDetails.automaticallyApprovedInd = false;
    approvalDetails.status = APPROVALREQUESTSTATUS.APPROVED;
    approvalDetails.versionNo = approvalRequestIDAndVersionNoDetails.versionNo;

    // approve planItem
    approvalRequestObj.approve(approvalRequestKey, approvalDetails);

    final SetPlannedItemStatusKey setPlannedItemStatusKey = new SetPlannedItemStatusKey();

    setPlannedItemStatusKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Set the planeedPlanItem status equal to Not Started
    setPlannedItemStatusKey.plannedItemStatus = curam.codetable.PLANNEDITEMSTATUS.NOTSTARTED;

    // Set the status
    plannedItemObj.setStatusCode(setPlannedItemStatusKey);

    // Send notification to user(s) if applicable
    // Set status
    status.plannedItemStatusStruct.status = curam.codetable.PLANNEDITEMSTATUS.APPROVED;

    // Call notification code
    plannedItemServiceLayerObj.sendNotification(plannedItemIDKey, status);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = curam.events.SERVICEPLANAPPROVAL.APPROVEPLANITEM;

    event.primaryEventData = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method which will process approval criteria for a planned item.
   *
   * It will determine if the planned item has any approval criteria and if so,
   * enact the associated workflow.
   *
   * @param key containing the plannedItemID and approvalType (pre or post)
   * @return OutstandingApprovalsResult containing a boolean stating
   * if the plannedItemID has any outstanding approval criteria left to process
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public ProcessPIApprovalCriteriaResults processPlannedItemApprovalCritieria(
    final PlannedItemIDAndApprovalOccursWhenKey key) throws AppException,
      InformationalException {

    // Create return struct
    final ProcessPIApprovalCriteriaResults processPIApprovalCriteriaResults = new ProcessPIApprovalCriteriaResults();

    // Create necessary manipulation objects and structs

    // Entity instances
    final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

    // Struct objects
    PlannedItemApprovalCriteriaDtls plannedItemApprovalCriteriaDtls = new PlannedItemApprovalCriteriaDtls();
    final curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaKey piApprCriteriaKey = new curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaKey();
    final PIApprovalCriteriaApprovalStatusUpdateDetails approvalStatusUpdateDtls = new PIApprovalCriteriaApprovalStatusUpdateDetails();

    // Read the planned item approval criteria table to
    // see if there are any approval criteria
    // and if so, return the highest one which requires processing
    plannedItemApprovalCriteriaDtls = plannedItemApprovalCriteriaObj.readHighestPriorityByPlannedItemID(
      key.dtls);

    // Have approval criteria so perform required processing

    // Set the approvalStatus on the planned item approval criteria record
    // This lets the system know that this approval criteria is being actioned

    // Set attributes accordingly
    piApprCriteriaKey.plannedItemApprovalCriteriaID = plannedItemApprovalCriteriaDtls.plannedItemApprovalCriteriaID;
    approvalStatusUpdateDtls.approvalStatus = PIAPPROVALCRITERIASTATUS.IN_PROGRESS;
    approvalStatusUpdateDtls.versionNo = plannedItemApprovalCriteriaDtls.versionNo;

    // Set approvalStatus
    plannedItemApprovalCriteriaObj.modifyApprovalStatus(piApprCriteriaKey,
      approvalStatusUpdateDtls);

    // Set plannedItemApprovalCriteriaID for return struct
    processPIApprovalCriteriaResults.plannedItemApprovalCriteriaID = plannedItemApprovalCriteriaDtls.plannedItemApprovalCriteriaID;

    // We have an approval criteria and hence, we should have an event to raise
    // So, enact the associated workflow

    // Create required event structs
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();
    final curam.util.events.struct.EventKey eventKey = new EventKey();

    // Obtain the event class and type from the
    // planned item approval criteria details
    final StringList stringList = StringUtil.delimitedText2StringListWithTrim(
      plannedItemApprovalCriteriaDtls.eventName, CuramConst.gkDotChar);

    // Set event key attributes
    eventKey.eventClass = stringList.item(0);
    eventKey.eventType = stringList.item(1);

    // Set eventKey on event
    event.eventKey = eventKey;

    // Set primary event data
    event.primaryEventData = key.caseID;

    // Set secondary event data
    event.secondaryEventData = key.dtls.plannedItemID;

    // Raise the event
    curam.util.events.impl.EventService.raiseEvent(event);

    // Return the result
    return processPIApprovalCriteriaResults;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * This method is used to submit a list of service plan planned items.
   *
   * @param keyList keyList containing a list of planned items to submit/approve
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void submitPlannedItemList(
    final curam.serviceplans.sl.struct.PlannedItemIDList keyList)
    throws AppException, InformationalException {

    // Create manipulation variables
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    // Loop round key list and process
    for (int i = 0; i < keyList.key.size(); i++) {

      // Set planned item ID
      plannedItemIDKey.plannedItemIDKey.plannedItemID = keyList.key.item(i).plannedItemID;

      // Perform common submit processing
      processSubmitDetails(plannedItemIDKey);

    }

    // Call the approval process for the planned item list
    approvePlannedItemList(keyList);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method that handles processing if a planned item
   * fails one of its approval criteria.
   *
   * Statuses need to be reset on the planned item and planned item approval
   * criteria entities.
   *
   * @param key containing planned item id
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void processFailedApprovalCriteria(
    final PlannedItemIDAndApprovalCriteriaKey key) throws AppException,
      InformationalException {

    // Create required entity instances
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Create required struct objects
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();
    PlannedItemApprovalProcessingStatusDetails approvalProcessingStatusDtls = new PlannedItemApprovalProcessingStatusDetails();

    // Set struct and read planned item details for the specific planned item
    plannedItemIDKey.plannedItemID = key.plannedItemID;

    approvalProcessingStatusDtls = plannedItemObj.readApprovalProcessingStatusByPlannedItemID(
      plannedItemIDKey);

    // Set modification attributes
    approvalProcessingStatusDtls.approvalProcessingStatus = APPROVALPROCESSINGSTATUS.NOT_STARTED;

    // Now, set attribute on plannedItem entity
    plannedItemObj.modifyPlannedItemApprovalProcessingStatus(plannedItemIDKey,
      approvalProcessingStatusDtls);

    // Finally, need to reject the planned item so other records and
    // actual planned item status are updated appropriately

    // Manipulation variables
    final PlannedItemIDKey rejectPlannedItemIDKey = new PlannedItemIDKey();
    final RejectionReasonAndRejectionComments rejectDetails = new RejectionReasonAndRejectionComments();

    // Set attributes
    rejectPlannedItemIDKey.plannedItemIDKey.plannedItemID = key.plannedItemID;
    rejectDetails.rejectionReason = REJECTIONREASON.FAILEDAPPROVALCRITERIA;

    reject(rejectPlannedItemIDKey, rejectDetails);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for setting all planned items approval processing status to
   * ready for approval as they have passed all pre-approval criteria
   * and any user defined ones.
   *
   * @param plannedItemIDKeyList - contains list of planned item id's to process
   * @param status - status to change to
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void setApprovalProcessingStatusForPlannedItemList(
    final PlannedItemIDList keyList, final StatusChangeDetails status)
    throws AppException, InformationalException {

    // Create required entity instances and struct object
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // Create struct object
    PlannedItemApprovalProcessingStatusDetails approvalProcessingStatusDtls = new PlannedItemApprovalProcessingStatusDetails();

    // For every id in the list, read their approvalProcessingStatus,
    // set the status and then modify
    for (int i = 0; i < keyList.key.size(); i++) {

      plannedItemIDKey.plannedItemID = keyList.key.item(i).plannedItemID;

      // Have to read as optimistic locking is set
      // and need the version no for modification
      approvalProcessingStatusDtls = plannedItemObj.readApprovalProcessingStatusByPlannedItemID(
        plannedItemIDKey);

      // Set status accordingly
      approvalProcessingStatusDtls.approvalProcessingStatus = status.changeToStatus;

      // Modify status for plannedItemID
      plannedItemObj.modifyPlannedItemApprovalProcessingStatus(plannedItemIDKey,
        approvalProcessingStatusDtls);
    }

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  /**
   * This is a common method for processing planned items when submitted for
   * approval. This Method is called when both a single planned item is
   * submitted for approval as well as a service plan delivery.
   *
   * @param plannedItemIDKey
   * Contains the key of the planned item to process.
   *
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_SUBMIT_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to submit
   * this plan item for approval.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_SUBMIT_SERVICEPLAN_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to submit
   * this plan item for approval.
   */
  @Override
  public void processSubmitDetails(final PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security if maintain rights are defined
    // Also check sensitivity check for user
    // Below check will do both:
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        curam.message.BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_SUBMIT_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        curam.message.BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_SUBMIT_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Validate the details
    validateSubmitDetails(plannedItemIDKey);

    final SetPlannedItemStatusKey setPlannedItemStatusKey = new SetPlannedItemStatusKey();

    setPlannedItemStatusKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Set the plannedItem status equal to Submitted
    setPlannedItemStatusKey.plannedItemStatus = curam.codetable.PLANNEDITEMSTATUS.SUBMITTED;

    // set the status
    plannedItemObj.setStatusCode(setPlannedItemStatusKey);

    // System user maintenance object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // PlannedItemApprovalRequest entity and details
    final curam.serviceplans.sl.entity.intf.PAApprovalRequest paApprovalRequestObj = curam.serviceplans.sl.entity.fact.PAApprovalRequestFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PAApprovalRequestDtls paApprovalRequestDtls = new curam.serviceplans.sl.entity.struct.PAApprovalRequestDtls();

    // ApprovalRequest entity and details
    final curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();
    final curam.core.sl.entity.struct.ApprovalRequestDtls approvalRequestDtls = new curam.core.sl.entity.struct.ApprovalRequestDtls();

    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // Set ApprovalRequest details
    approvalRequestDtls.requestedDate = currentDate;
    approvalRequestDtls.requestedByUser = systemUserDtls.userName;
    approvalRequestDtls.status = curam.codetable.APPROVALREQUESTSTATUS.SUBMITTED;

    // insert approval request
    approvalRequestObj.insert(approvalRequestDtls);

    // create PAApprovalRequestDetails
    paApprovalRequestDtls.approvalRequestID = approvalRequestDtls.approvalRequestID;
    paApprovalRequestDtls.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // insert planned item approval request
    paApprovalRequestObj.insert(paApprovalRequestDtls);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.SUBMITPLANITEM;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  /**
   * This is a common method for processing planned items for approval. This
   * method is called when both a single planned item is submitted for approval
   * as well as a service plan delivery.
   *
   * @param plannedItemIDKey
   * Contains the key of the planned item to process.
   *
   * @throws AppException
   * {@link BPOPAAPPROVALREQUEST#ERR_APPROVE_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to approve
   * this plan item.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void processApproveDetails(final PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // Service Plan Security Checks.

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemApprovalSecurityKey servicePlanPlanItemApprovalSecurityKey = new ServicePlanPlanItemApprovalSecurityKey();

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    servicePlanPlanItemApprovalSecurityKey.planItemID = plannedItemObj.readPlanItemID(plannedItemIDKey.plannedItemIDKey).planItemID;

    // check plan item sensitivity
    try {
      servicePlanSecurity.planItemSensitivityCheck(plannedItemIDKey);
    } catch (final AppException e) {
      if (e.equals(
        curam.message.BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_APPROVE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // check plan item approval security if approval
    // security identifier was set on planItem
    try {
      servicePlanSecurity.approvePlanItemSecurityCheck(
        servicePlanPlanItemApprovalSecurityKey);
    } catch (final AppException e) {
      if (e.equals(
        curam.message.BPOSERVICEPLANSECURITY.ERR_PLANITEMAPPROVAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPAAPPROVALREQUEST.ERR_APPROVE_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Validate the details
    validateApproveDetails(plannedItemIDKey);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Sets the approvalStatus of the planned item approval
   * criteria according to the details passed in.
   *
   * Check the approvalType and eventType and process accordingly
   * If approvalType is pre approval and eventType is a 'fail' then
   * we need to set the approvalStatus to not started
   *
   * if eventType is a 'pass' then we need to
   * set the approvalStatus to completed
   *
   * If approvalType is post approval then regardless,
   * we set the approvalStatus to completed
   *
   * @param dtls - dtls of plannedItem and status
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public OutstandingApprovalsResult setPIApprovalCriteriaStatus(
    final PIApprovalCriteriaStatusUpdateDtls dtls) throws AppException,
      InformationalException {

    // Create return struct
    final OutstandingApprovalsResult outstandingApprovalsResult = new OutstandingApprovalsResult();

    // Create necessary manipulation variables

    // Entity instances
    final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

    // Struct objects
    PlannedItemApprovalCriteriaSummaryDetailsList piApprovalCriteriaSummaryDtlsList = new PlannedItemApprovalCriteriaSummaryDetailsList();
    final PIApprovalCriteriaApprovalStatusUpdateDetails approvalStatusUpdateDtls = new PIApprovalCriteriaApprovalStatusUpdateDetails();
    final curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaKey piApprCriteriaKey = new curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaKey();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDAndApprovalOccursWhenKey plannedItemIDAndOccursWhenKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDAndApprovalOccursWhenKey();

    final String failedApprovalCriteriaEvent = curam.events.SERVICEPLANS.FAILEDAPPROVALCRITERIA.eventClass
      + CuramConst.gkDotChar
      + curam.events.SERVICEPLANS.FAILEDAPPROVALCRITERIA.eventType;

    // If approvalType is pre approval and eventType is a 'fail'
    // OR 'NoEvent' (meaning deadline has passed) we set the approvalStatus
    // to 'not started' otherwise we set the approvalStatus to 'completed'
    if (dtls.approvalType.equals(APPROVALCRITERIAWHEN.PREAPPROVAL)
      && (dtls.eventType.equals(failedApprovalCriteriaEvent)
        || dtls.eventType.equals(ServicePlanConst.kNoEvent))) {

      // We need to reset the status of all approval criteria records
      // associated to the planned item
      final curam.serviceplans.sl.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.struct.PlannedItemKey();
      final PlannedItemIDKeyList keyList = new PlannedItemIDKeyList();
      final StatusChangeDetails changeToStatus = new StatusChangeDetails();

      // Set attributes
      plannedItemKey.plannedItemID = dtls.plannedItemID;
      keyList.key.addRef(plannedItemKey);
      changeToStatus.changeToStatus = PIAPPROVALCRITERIASTATUS.NOT_STARTED;

      // Reset the statuses
      setPIApprovalCriteriaStatusForPlannedItemList(keyList, changeToStatus);

    } else {

      // Set attributes
      plannedItemIDAndOccursWhenKey.plannedItemID = dtls.plannedItemID;
      plannedItemIDAndOccursWhenKey.occursWhen = dtls.approvalType;
      plannedItemIDAndOccursWhenKey.approvalStatus = PIAPPROVALCRITERIASTATUS.IN_PROGRESS;

      // Obtain the record we need to process
      piApprovalCriteriaSummaryDtlsList = plannedItemApprovalCriteriaObj.searchCriteriaByStatusOccursWhenAndPlannedItemID(
        plannedItemIDAndOccursWhenKey);

      // Should only be one in the list as approval
      // criteria are processed one at a time
      if (piApprovalCriteriaSummaryDtlsList.dtls.size() > 1) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOAPPROVALCRITERIA.ERR_MORE_THAN_ONE_APPROVAL_CRITERIA_BEING_PROCESSED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        // Set planned item approval criteria key struct
        piApprCriteriaKey.plannedItemApprovalCriteriaID = piApprovalCriteriaSummaryDtlsList.dtls.item(0).plannedItemApprovalCriteriaID;

        // Set version number and approvalStatus
        approvalStatusUpdateDtls.versionNo = piApprovalCriteriaSummaryDtlsList.dtls.item(0).versionNo;
        approvalStatusUpdateDtls.approvalStatus = PIAPPROVALCRITERIASTATUS.COMPLETED;

        // Set attribute on entity
        plannedItemApprovalCriteriaObj.modifyApprovalStatus(piApprCriteriaKey,
          approvalStatusUpdateDtls);

      }

      // Finally, see if there are any outstanding approvals
      // Read the planned item approval criteria table
      // to see if there are any approval criteria
      // with an approvalStatus of ready to process
      plannedItemIDAndOccursWhenKey.approvalStatus = PIAPPROVALCRITERIASTATUS.READY_TO_PROCESS;

      try {

        plannedItemApprovalCriteriaObj.readHighestPriorityByPlannedItemID(
          plannedItemIDAndOccursWhenKey);

        outstandingApprovalsResult.outstandingApprovals = true;

      } catch (final RecordNotFoundException rNFE) {
        // Nothing actually wrong - just means the planned
        // item has no further approval criteria
        outstandingApprovalsResult.outstandingApprovals = false;
      }

    }

    // Return the result
    return outstandingApprovalsResult;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Sets the approvalStatus of the planned item approval
   * criteria records associated to a planned item.
   *
   * Sets the status to the passed in variable.
   *
   * @param keyList - plannedItemID list
   * @param changeToStatus - Status to be set
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void setPIApprovalCriteriaStatusForPlannedItemList(
    final PlannedItemIDKeyList keyList,
    final StatusChangeDetails changeToStatus) throws AppException,
      InformationalException {

    // Entity instance
    final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

    // Struct variables
    PlannedItemApprovalCriteriaSummaryDetailsList piApprovalCriteriaSummaryDtlsList = new PlannedItemApprovalCriteriaSummaryDetailsList();
    final PIApprovalCriteriaApprovalStatusUpdateDetails approvalStatusUpdateDtls = new PIApprovalCriteriaApprovalStatusUpdateDetails();
    final curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaKey piApprCriteriaKey = new curam.serviceplans.sl.entity.struct.PlannedItemApprovalCriteriaKey();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // For each item in the list search for approval criteria
    for (int i = 0; i < keyList.key.size(); i++) {

      // Set the planned item ID key
      plannedItemIDKey.plannedItemID = keyList.key.item(i).plannedItemID;

      // Read approval criteria for the planned item
      piApprovalCriteriaSummaryDtlsList = plannedItemApprovalCriteriaObj.searchApprovalStatusDetailsForPlannedItemID(
        plannedItemIDKey);

      // For each planned item approval criteria
      // record set the status accordingly
      for (int j = 0; j < piApprovalCriteriaSummaryDtlsList.dtls.size(); j++) {

        // Set planned item approval criteria key struct
        piApprCriteriaKey.plannedItemApprovalCriteriaID = piApprovalCriteriaSummaryDtlsList.dtls.item(j).plannedItemApprovalCriteriaID;

        // Set version number
        approvalStatusUpdateDtls.versionNo = piApprovalCriteriaSummaryDtlsList.dtls.item(j).versionNo;

        // Set approvalStatus to completed
        approvalStatusUpdateDtls.approvalStatus = changeToStatus.changeToStatus;

        // Set attribute on entity
        plannedItemApprovalCriteriaObj.modifyApprovalStatus(piApprCriteriaKey,
          approvalStatusUpdateDtls);

      }

    }

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for setting a planned items approval processing status to
   * passed in statusChange attribute.
   *
   * @param key - contains planned item id to process
   * @param statusChange - status to change to
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public void setApprovalProcessingStatusForPlannedItem(
    final curam.serviceplans.sl.struct.PlannedItemIDKey key,
    final StatusChangeDetails statusChange) throws AppException,
      InformationalException {

    // Create required entity instances and struct object
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // Create struct object
    PlannedItemApprovalProcessingStatusDetails approvalProcessingStatusDtls = new PlannedItemApprovalProcessingStatusDetails();

    plannedItemIDKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // Have to read as optimistic locking is set and
    // need the version no for modification
    approvalProcessingStatusDtls = plannedItemObj.readApprovalProcessingStatusByPlannedItemID(
      plannedItemIDKey);

    // If the approvalProcessingStatus is 'not started' then do not change
    // Means it failed approval criteria processing
    if (!approvalProcessingStatusDtls.approvalProcessingStatus.equals(
      APPROVALPROCESSINGSTATUS.NOT_STARTED)) {
      // Set status accordingly
      approvalProcessingStatusDtls.approvalProcessingStatus = statusChange.changeToStatus;

      // Modify status for plannedItemID
      plannedItemObj.modifyPlannedItemApprovalProcessingStatus(plannedItemIDKey,
        approvalProcessingStatusDtls);
    }
  }
  // END, CR00161962
}
