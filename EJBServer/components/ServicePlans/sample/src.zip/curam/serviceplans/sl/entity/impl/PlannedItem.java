/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2005, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2009,2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.LANGUAGE;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.message.BPOMAINTAINSERVICEPLANDELIVERY;
import curam.message.BPOPLANNEDITEM;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemApprovalCriteriaFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemAttachmentLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemTaskConfigurationFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItemApprovalCriteria;
import curam.serviceplans.sl.entity.intf.PlannedItemAttachmentLink;
import curam.serviceplans.sl.entity.intf.PlannedItemTaskConfiguration;
import curam.serviceplans.sl.entity.struct.ModifyEstimatedCostDetails;
import curam.serviceplans.sl.entity.struct.ModifyExpectedAndActualOutcomeDetails;
import curam.serviceplans.sl.entity.struct.OutcomeCountDetails;
import curam.serviceplans.sl.entity.struct.PlanItemIDKey;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentLinkKey;
import curam.serviceplans.sl.entity.struct.PlannedItemAuthorizedUnits;
import curam.serviceplans.sl.entity.struct.PlannedItemClosureDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndContractTextDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndContractTextDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndLanguageKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDStatus;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndConcernRoleKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.RequiresApprovalStruct;
import curam.serviceplans.sl.entity.struct.SetPlannedItemStatusKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;
import java.util.Calendar;
import java.util.Date;


public abstract class PlannedItem extends curam.serviceplans.sl.entity.base.PlannedItem {

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the planned item details
   *
   * @param details The planned item details to be inserted.
   */
  @Override
  protected void preinsert(PlannedItemDtls details) throws AppException,
      InformationalException {

    if (details.plannedItemID == 0) {

      final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

      details.plannedItemID = uniqueIDObj.getNextID();

    }

    // BEGIN, CR00110475, MC
    // Validate the Insert Details
    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = details.planItemID;
    validateInsert(details);
    // END, CR00110475

    // Set the planned item status
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // PlanItemKey
    planItemKey = new PlanItemKey();

    final SetPlannedItemStatusKey setPlannedItemStatusKey = new SetPlannedItemStatusKey();

    // Requires Approval Struct
    RequiresApprovalStruct requiresApprovalStruct = new RequiresApprovalStruct();

    // Set the Key
    planItemKey.planItemID = details.planItemID;

    // Check if the requiresApproval attribute has been set
    requiresApprovalStruct = planItemObj.readApprovalRequired(planItemKey);

    // Set the Key
    setPlannedItemStatusKey.plannedItemID = details.plannedItemID;

    // If planned item is getting cloned status should stay as it is.
    // Status is initially empty only for new added Planned Items.
    if (details.status.length() == 0) {

      // If approval is required set the status to 'Unapproved'
      if (requiresApprovalStruct.requiresApproval == true) {

        // Set the StatusCode
        details.status = curam.codetable.PLANNEDITEMSTATUS.UNAPPROVED;

      } else {

        // If approval is not required then set the status to 'Not Started'.
        details.status = curam.codetable.PLANNEDITEMSTATUS.NOTSTARTED;
      }
    }

    // BEGIN, CR00292366, AKr
    if (details.createdOn.isZero()) {
      details.createdOn = DateTime.getCurrentDateTime();
    }
    // END, CR00292366
  }

  // ___________________________________________________________________________
  /**
   * Carries out an operation after insertion of a planned item record.
   *
   * @param details Planned Item details that have been inserted.
   */
  @Override
  protected void postinsert(PlannedItemDtls details) throws AppException,
      InformationalException {

    // BEGIN, CR00110475, MC
    // Validate the details
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = details.planItemID;
    validatePostDetails(details);
    // END, CR00110475

    // If so notify subgoal of possible date change.
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = details.plannedItemID;
    notifySubGoalOfRecordUpdate(plannedItemKey);
    // END, HARO 46404.
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for a modify operation.
   *
   * @param key the planned item key
   * @param details the planned item details
   */
  @Override
  protected void premodify(PlannedItemKey key, PlannedItemDtls details)
    throws AppException, InformationalException {

    // Variables used to check actual start and actual end have been entered
    boolean actualStartDateEntered = false;
    boolean actualEndDateEntered = false;

    // Date difference in days variable
    int actualDateDiffInDays = 0;
    int expDateDiffInDays = 0;
    // BEGIN, CR00351006, AC
    curam.util.type.Date actualEndDateTemp = new curam.util.type.Date();

    // END, CR00351006
    if (details.actualStartDate.isZero() == true) {

      actualStartDateEntered = false;

    } else {

      actualStartDateEntered = true;
    }
    // BEGIN, CR00351006, AC
    if (details.actualEndDate.isZero() == true) {

      actualEndDateTemp = curam.util.type.Date.getCurrentDate();
      actualEndDateEntered = true;
    } else {
      actualEndDateTemp = details.actualEndDate;
      actualEndDateEntered = true;
    }
    // END, CR00351006
    // Check if indicator should be set
    if (actualStartDateEntered && actualEndDateEntered) {

      final Date actualStartDate = details.actualStartDate.getCalendar().getTime();
      final Date expectedStartDate = details.expectedStartDate.getCalendar().getTime();
      // BEGIN, CR00351006, AC
      final Date actualEndDate = actualEndDateTemp.getCalendar().getTime();
      final Date expectedEndDate = details.expectedEndDate.getCalendar().getTime();

      // END, CR00351006
      // calculate actual difference and expected difference
      actualDateDiffInDays = calculateDifference(actualStartDate, actualEndDate);
      expDateDiffInDays = calculateDifference(expectedStartDate,
        expectedEndDate);

      if (actualDateDiffInDays > expDateDiffInDays) {
        // Set the indicator
        details.datePeriodMaxInd = true;
      }

    }

    // BEGIN, CR00110475, MC
    // Validate the details
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = details.planItemID;
    validateModify(details);
    // END, CR00110475

    // if the start date has entered at this stage change status to IN PROGESS
    if (details.actualEndDate.isZero() == true
      && details.actualStartDate.isZero() == false // BEGIN, CR00021343, TV
      // BEGIN, HARP 64102,NP
      && !details.status.equals(PLANNEDITEMSTATUS.SUBMITTED)) {
      details.status = PLANNEDITEMSTATUS.INPROGRESS;
    }
    // END,HARP 64102
    // END, CR00021343

    // if both the actual start date and end dates have been entered at this
    // stage change
    // status to COMPLETED
    if (details.actualStartDate.isZero() == false
      && details.actualEndDate.isZero() == false) {
      details.status = PLANNEDITEMSTATUS.COMPLETED;
    }

  }

  // ___________________________________________________________________________
  /**
   * Performs calculation of the dates difference for the actual start/end and
   * the expected start/end dates.
   *
   * @param a, b Start and end dates for both actual and expected dates
   *
   * @return difference between start and end for actual dates and expected
   * dates
   */
  protected int calculateDifference(Date a, Date b) throws AppException,
      InformationalException {

    int tempDifference = 0;
    int difference = 0;
    final int kDaysInYear = 365;

    final Calendar earlier = Calendar.getInstance();
    final Calendar later = Calendar.getInstance();

    // set the earlier and later structs with given date
    earlier.setTime(a);
    later.setTime(b);

    while (earlier.get(Calendar.YEAR) != later.get(Calendar.YEAR)) {

      tempDifference = kDaysInYear
        * (later.get(Calendar.YEAR) - earlier.get(Calendar.YEAR));
      difference += tempDifference;

      earlier.add(Calendar.DAY_OF_YEAR, tempDifference);
    }

    if (earlier.get(Calendar.DAY_OF_YEAR) != later.get(Calendar.DAY_OF_YEAR)) {

      tempDifference = later.get(Calendar.DAY_OF_YEAR)
        - earlier.get(Calendar.DAY_OF_YEAR);
      difference += tempDifference;
      earlier.add(Calendar.DAY_OF_YEAR, tempDifference);
    }

    return difference;

  }

  // ___________________________________________________________________________
  /**
   * Carries out an operation after the modification of a planned item record.
   *
   * @param details Planned item details that have been modified.
   */
  @Override
  protected void postmodify(PlannedItemKey key, PlannedItemDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00110475, MC
    // Validate the details
    final PlanItem planItem = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = details.planItemID;
    final String code = curam.codetable.impl.PLANITEMTYPEEntry.get(planItem.read(planItemKey).typeCode).getCode();

    ServicePlanHookManager.getPlannedItemHook(code).validatePostDetails(details);
    // END, CR00110475

    notifySubGoalOfRecordUpdate(key);

  }

  // ___________________________________________________________________________
  /**
   * Performs validation on the expected outcome associated with a plan item.
   *
   * @param planItemIDKey the plan item key
   */
  @Override
  public void validateExpectedOutcome(PlanItemIDKey planItemIDKey)
    throws AppException, InformationalException {

    // PlanItemOutcomeLink Object
    final curam.serviceplans.sl.entity.intf.PlanItemOutcomeLink planItemOutcomeLinkObj = curam.serviceplans.sl.entity.fact.PlanItemOutcomeLinkFactory.newInstance();

    OutcomeCountDetails outcomeCountDetails = new OutcomeCountDetails();

    // Check if an expected outcome has been defined for this planItem
    outcomeCountDetails = planItemOutcomeLinkObj.countOutcomeByPlanItemID(
      planItemIDKey);

    // If no outcome has been defined throw the appropriate error message.
    if (outcomeCountDetails.recordCount == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XFV_EXPECTED_OUTCOME_NOT_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for an insert operation.
   *
   * @param plannedItemDtls The planned item details to be inserted.
   */
  @Override
  public void validateInsert(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // Validate the details
    validateDetails(plannedItemDtls);

  }

  // __________________________________________________________________________
  /**
   * Performs validation of the details for a modify operation.
   *
   * @param plannedItemDtls The planned item details to be modified.
   * @throws AppException, InformationalException
   */
  @Override
  public void validateModify(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00138465, MC
    final PlanItem planItem = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;

    final String code = curam.codetable.impl.PLANITEMTYPEEntry.get(planItem.read(planItemKey).typeCode).getCode();

    ServicePlanHookManager.getPlannedItemHook(code).validateModify(
      plannedItemDtls);
    // END, CR00138465

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of a planned item.
   *
   * @param plannedItemDtls details of the planned item to be validated.
   * @throws AppException, InformationalException
   */
  @Override
  public void validateDetails(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00138465, MC
    final PlanItem planItem = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;
    final String code = curam.codetable.impl.PLANITEMTYPEEntry.get(planItem.read(planItemKey).typeCode).getCode();

    ServicePlanHookManager.getPlannedItemHook(code).validateDetails(
      plannedItemDtls);
    // END, CR00138465

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of the post insert and post modify operations.
   *
   * @param plannedItemDtls - details of the planned item to be validated.
   */
  @Override
  public void validatePostDetails(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00138465, MC
    final PlanItem planItem = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;
    final String code = curam.codetable.impl.PLANITEMTYPEEntry.get(planItem.read(planItemKey).typeCode).getCode();

    ServicePlanHookManager.getPlannedItemHook(code).validatePostDetails(
      plannedItemDtls);

    // END, CR00138465

  }

  // ___________________________________________________________________________
  /**
   * Sets the status Code of a Planned Item
   *
   * @param setPlannedItemStatusKey - details of the planned item to be updated.
   */
  @Override
  public void setStatusCode(SetPlannedItemStatusKey setPlannedItemStatusKey)
    throws AppException, InformationalException {

    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    // Set the plannedItemID
    plannedItemKey.plannedItemID = setPlannedItemStatusKey.plannedItemID;

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    PlannedItemDtls plannedItemDtls = new PlannedItemDtls();

    // Read the record to be updated
    plannedItemDtls = plannedItemObj.read(plannedItemKey);

    plannedItemDtls.status = setPlannedItemStatusKey.plannedItemStatus;

    // Set the statusCode
    plannedItemObj.modify(plannedItemKey, plannedItemDtls);
  }

  // ___________________________________________________________________________
  /**
   * Notifies the sub goal that the plan item dates have changed
   *
   * @param key Planned Item identifier
   */
  @Override
  public void notifySubGoalOfRecordUpdate(PlannedItemKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // Read planned sub goal id.
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = readPlannedSubGoalIDByPlannedItemID(key).plannedSubGoalID;

    // call method to check dates
    plannedSubGoalObj.reCalculateDatesAndStatus(plannedSubGoalKey);
  }

  // ___________________________________________________________________________
  /**
   * Validates details for expected and actual outcome modification.
   *
   * @param key Planned Item identifier
   * @param details Modification details
   */
  @Override
  protected void premodifyExpectedAndActualOutcome(PlannedItemKey key,
    ModifyExpectedAndActualOutcomeDetails details) throws AppException,
      InformationalException {

    // validate modification details
    validateModifyExpectedAndActualOutcome(key, details);
  }

  // ___________________________________________________________________________
  /**
   * Validates details for expected and actual outcome modification.
   *
   * @param key Planned Item identifier
   * @param details Modification details
   */
  @Override
  public void validateModifyExpectedAndActualOutcome(PlannedItemKey key,
    ModifyExpectedAndActualOutcomeDetails details) throws AppException,
      InformationalException {

    // PlannedItem Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    // read status, expected outcome and actual dates
    final curam.serviceplans.sl.entity.struct.PlannedItemSummaryDetails plannedItemSummaryDetails = plannedItemObj.readStatusExpectedOutcomeActualStartAndEndDate(
      key);

    // read service plan status
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = key.plannedItemID;

    caseHeaderKey.caseID = readCaseIDByPlannedItemID(plannedItemIDKey).caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // planned item cannot be modified if service plan delivery is closed
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // if action has been started, than the actual outcome cannot be: CANCELLED
    if (details.outcomeAchieved.equals(
      curam.codetable.OUTCOMEACHIEVED.CANCELLED)
        && !plannedItemSummaryDetails.actualStartDate.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_CANNOT_BE_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // if actual end date has not been set, actual outcome cannot be set to
    // ATTAINED or NOTATTAINED
    if ((details.outcomeAchieved.equals(
      curam.codetable.OUTCOMEACHIEVED.ATTAINED)
        || details.outcomeAchieved.equals(
          curam.codetable.OUTCOMEACHIEVED.NOTATTAINED))
            && plannedItemSummaryDetails.actualEndDate.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_ACTUAL_OUTCOME_CANNOT_BE_SET),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // expected outcome cannot be modified after the action is started
    if (!plannedItemSummaryDetails.actualStartDate.isZero()
      && details.expectedOutcomeID
        != plannedItemSummaryDetails.expectedOutcomeID) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_EXPECTED_OUTCOME_CANNOT_BE_SET),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
  }

  // ___________________________________________________________________________
  /**
   * Validates details before planned item is closed
   *
   * @param key Planned Item identifier
   * @param details Closure details
   */
  @Override
  protected void preclose(PlannedItemKey key,
    PlannedItemClosureDetails details) throws AppException,
      InformationalException {

    // validate closure details
    validateClosureDetails(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Validates details before planned item is closed
   *
   * @param key Planned Item identifier
   * @param details Closure details
   */
  @Override
  public void validateClosureDetails(PlannedItemKey key,
    PlannedItemClosureDetails details) throws AppException,
      InformationalException {

    if (details.outcomeAchieved.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XFV_EXPECTED_OUTCOME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // BEGIN, CR00000086, CSH
  // ___________________________________________________________________________
  /**
   * Validates details before planned item authorized units are modified
   *
   * @param plannedItemDtls Planned item details
   */
  @Override
  public void validateModifyAuthorizedUnits(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // Plan Item entity object
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // Plan Item key
    final curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    // Service Unit Delivery details struct
    curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails planItemServiceUnitDeliveryDetails = new curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails();

    // Set the value for the plan item key
    planItemKey.planItemID = plannedItemDtls.planItemID;

    // Read the service unit details back from the plan item
    planItemServiceUnitDeliveryDetails = planItemObj.readPlanItemServiceUnitDeliveryDetails(
      planItemKey);

    // Service Unit Delivery Object
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // Get the units received to date for this planned item
    final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID = plannedItemDtls.plannedItemID;

    // Authorized units cannot be modified if plan item is not of type unit
    // BEGIN, CR00052924, GM
    // BEGIN, CR00091205, CM
    if (planItemServiceUnitDeliveryDetails.unitType.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLANNED_ITEM_AUTHORIZED_UNITS_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // New Authorized Units cannot be greater than the maximum units
    // value for the plan item
    if (plannedItemDtls.authorizedUnits > plannedItemDtls.maximumUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLANNED_ITEM_XRV_NEW_AUTH_UNITS_GREATER_THAN_MAX_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // New Authorized Units cannot be less that the total units received to date
    if (plannedItemDtls.authorizedUnits
      < serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(plannedItemIDStatus).count) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLANNED_ITEM_XRV_NEW_AUTH_UNITS_LESS_THAN_TOTAL_UNITS_RECEIVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates details before planned item authorized units are modified
   *
   * @param key Planned item identifier
   * @param details Planned item details
   */
  @Override
  protected void premodifyAuthorizedUnits(PlannedItemIDKey key,
    PlannedItemAuthorizedUnits details) throws AppException,
      InformationalException {

    // Planned Item details struct
    curam.serviceplans.sl.entity.struct.PlannedItemDtls plannedItemDtls = new curam.serviceplans.sl.entity.struct.PlannedItemDtls();

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = key.plannedItemID;

    // Populate the details struct
    plannedItemDtls = plannedItemObj.read(plannedItemKey);
    plannedItemDtls.authorizedUnits = details.authorizedUnits;

    // validate modification details
    validateModifyAuthorizedUnits(plannedItemDtls);
  }

  // END, CR00000086

  // ___________________________________________________________________________
  /**
   * Removes the planned item attachments before removing the planned item.
   *
   * @param plannedItemKey Planned item identifier
   * @throws AppException, InformationalException
   */
  @Override
  protected void preremove(PlannedItemKey plannedItemKey)
    throws AppException, InformationalException {

    // Manipulation variables
    final PlannedItemAttachmentLinkKey plannedItemAttachmentLinkKey = new PlannedItemAttachmentLinkKey();
    PlannedItemAttachmentDetailsList plannedItemAttachmentDetailsList = new PlannedItemAttachmentDetailsList();

    // Entity Objects
    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();

    // Finding out the list of attachments for the planned item
    plannedItemAttachmentDetailsList = plannedItemAttachmentLinkObj.searchAttachmentsForPlannedItem(
      plannedItemKey);

    // Iterating the Planned Item Attachments List to delete the attachments
    for (int i = 0; i < plannedItemAttachmentDetailsList.dtls.size(); i++) {

      plannedItemAttachmentLinkKey.plannedItemAttachmentLinkID = plannedItemAttachmentDetailsList.dtls.item(i).plannedItemAttachmentLinkID;

      // Removing the planned item attachment link and then the attachment
      plannedItemAttachmentLinkObj.remove(plannedItemAttachmentLinkKey);
    }
    // BEGIN, CR00161962, LJ
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemEntityKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemEntityKey.plannedItemID = plannedItemKey.plannedItemID;

    try {
      // Planned Item Task Configuration manipulation
      final PlannedItemTaskConfiguration plannedItemTaskConfigurationObj = PlannedItemTaskConfigurationFactory.newInstance();

      plannedItemTaskConfigurationObj.removePlannedItemTaskConfiguration(
        plannedItemEntityKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {// No
      // Planned
      // Item
      // Task
      // configuration
      // exists for the
      // planned item
    }

    try {
      // Planned Item Approval Criteria Manipulation
      final PlannedItemApprovalCriteria plannedItemApprovalCriteriaObj = PlannedItemApprovalCriteriaFactory.newInstance();

      plannedItemApprovalCriteriaObj.removePlannedItemApprovalCriteriaByPlannedItemID(
        plannedItemEntityKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {// No
      // Planned
      // Item
      // Approval
      // Criteria
      // details exists
      // for the planned
      // item
    }
    // END, CR00161962
  }

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________
  /**
   * Validates details before planned item estimated cost is modified.
   *
   * @param key Planned item identifier
   * @param details Estimated Cost details
   * @throws AppException, InformationalException
   */
  @Override
  protected void premodifyEstimatedCost(PlannedItemKey key,
    ModifyEstimatedCostDetails details) throws AppException,
      InformationalException {

    validateModifyEstimatedCost(details);
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________
  /**
   * Validates planned item estimated cost details.
   *
   * @param key Planned item identifier
   * @param details Estimated Cost details
   * @throws AppException, InformationalException
   */
  @Override
  public void validateModifyEstimatedCost(ModifyEstimatedCostDetails details)
    throws AppException, InformationalException {

    if (details.estimatedCost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_ESTIMATED_COST_NON_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }

  // END, CR00161962

  // BEGIN, CR00287219, ELG
  // ___________________________________________________________________________
  /**
   * This method is used to get the contract text for a planned item. It reads
   * it by participant and Planned SubGoal.
   *
   * @param key - Contains planned sub-goal ID and concern role id.
   * @return Structure containing a list of contract text details and planned
   * item id's.
   * @throws AppException, InformationalException
   */
  @Override
  public PlannedItemIDAndContractTextDetailsList searchContractTextByPlannedSubGoalAndParticipant(
    final PlannedSubGoalIDAndConcernRoleKey key) throws AppException,
      InformationalException {

    // Return structure
    final PlannedItemIDAndContractTextDetailsList plannedItemIDAndContractTextDetailsList = new PlannedItemIDAndContractTextDetailsList();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = key.plannedSubGoalID;
    final PlannedItemDtlsList plannedItemDtlsList = searchByPlannedSubGoalID(
      plannedSubGoalKey);

    final PlannedItemIDAndLanguageKey plannedItemIDAndLanguageKey = new PlannedItemIDAndLanguageKey();

    for (final PlannedItemDtls plannedItemDtls : plannedItemDtlsList.dtls) {

      plannedItemIDAndLanguageKey.plannedItemID = plannedItemDtls.plannedItemID;
      PlannedItemIDAndContractTextDetails plannedItemIDAndContractTextDetails = new PlannedItemIDAndContractTextDetails();

      if (concernRoleDtls.preferredLanguage.equals("")) {

        plannedItemIDAndLanguageKey.languageCode = LANGUAGE.DEFAULTCODE;
        plannedItemIDAndContractTextDetails = readContractTextByPlannedItemAndLanguage(
          plannedItemIDAndLanguageKey);

      } else {

        plannedItemIDAndLanguageKey.languageCode = concernRoleDtls.preferredLanguage;
        plannedItemIDAndContractTextDetails = readContractTextByPlannedItemAndLanguage(
          plannedItemIDAndLanguageKey);

        if (plannedItemIDAndContractTextDetails.planItemContractText.equals("")) {

          plannedItemIDAndLanguageKey.languageCode = LANGUAGE.DEFAULTCODE;
          plannedItemIDAndContractTextDetails = readContractTextByPlannedItemAndLanguage(
            plannedItemIDAndLanguageKey);

        }

      }

      if (plannedItemIDAndContractTextDetails.planItemContractText.equals("")) {

        final AppException ae = new AppException(
          BPOMAINTAINSERVICEPLANDELIVERY.INF_PLANITEM_CONTRACT_TEXT_MISSING);
        final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

        ae.arg(plannedItemDtls.name);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          ae, "", InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }

      plannedItemIDAndContractTextDetailsList.dtls.addRef(
        plannedItemIDAndContractTextDetails);

    }

    return plannedItemIDAndContractTextDetailsList;

  }
  // END, CR00287219

}
