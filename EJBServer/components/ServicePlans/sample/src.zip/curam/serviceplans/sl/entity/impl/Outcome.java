/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOOUTCOME;
import curam.serviceplans.sl.entity.struct.OutcomeCancelDetails;
import curam.serviceplans.sl.entity.struct.OutcomeCountDetails;
import curam.serviceplans.sl.entity.struct.OutcomeDtls;
import curam.serviceplans.sl.entity.struct.OutcomeIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.OutcomeKey;
import curam.serviceplans.sl.entity.struct.OutcomeNameAndReferenceDetails;
import curam.serviceplans.sl.entity.struct.OutcomeNameStatusKey;
import curam.serviceplans.sl.entity.struct.OutcomeReferenceKey;
import curam.serviceplans.sl.entity.struct.OutcomeStatusDetails;
import curam.serviceplans.sl.entity.struct.OutcomeValidationDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This Outcome entity contains all of the possible outcomes for goals,
 * sub goals and planItems within the organization.
 */
public abstract class Outcome extends curam.serviceplans.sl.entity.base.Outcome {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Outcome details
   */
  @Override
  protected void preinsert(OutcomeDtls details) throws AppException,
      InformationalException {

    // validate insert details
    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Outcome identifier
   * @param details Outcome details
   */
  @Override
  protected void premodify(OutcomeKey key, OutcomeDtls details)
    throws AppException, InformationalException {

    // validate modify details
    validateModify(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the outcome cancellation
   *
   * @param key Outcome identifier
   * @param details Outcome details
   */
  @Override
  protected void precancel(OutcomeKey key, OutcomeCancelDetails details)
    throws AppException, InformationalException {

    // validate cancel
    validateCancel(key);

  }

  // ___________________________________________________________________________
  /**
   * Validates the outcome details
   *
   * @param details The details of the outcome
   */
  @Override
  public void validateDetails(OutcomeValidationDetails details)
    throws AppException, InformationalException {

    // outcome name must be specified
    if (details.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the outcome to be canceled
   *
   * @param key Outcome unique identifier
   */
  @Override
  public void validateCancel(OutcomeKey key) throws AppException,
      InformationalException {

    // read outcome status
    final OutcomeStatusDetails outcomeStatusDetails = readStatus(key);

    // record must not be already canceled
    if (outcomeStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_ALREADY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final OutcomeIDAndStatusKey outcomeIDAndStatusKey = new OutcomeIDAndStatusKey();

    // set the key
    outcomeIDAndStatusKey.outcomeID = key.outcomeID;
    outcomeIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // outcome must not be assigned to any goal
    if (countGoalsByOutcomeAndStatus(outcomeIDAndStatusKey).recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_XRV_ASSIGNED_TO_GOAL),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // outcome must not be assigned to any planItem
    if (countPlanItemsByOutcomeAndStatus(outcomeIDAndStatusKey).recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_XRV_ASSIGNED_TO_PLANITEM),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // outcome must not be assigned to any sub goal
    if (countSubGoalsByOutcomeAndStatus(outcomeIDAndStatusKey).recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_XRV_ASSIGNED_TO_SUBGOAL),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates outcome insert details
   *
   * @param details The details of the outcome
   */
  @Override
  protected void validateInsert(OutcomeDtls details) throws AppException,
      InformationalException {

    // Outcome manipulation variables
    final OutcomeValidationDetails outcomeValidationDetails = new OutcomeValidationDetails();
    final OutcomeReferenceKey outcomeReferenceKey = new OutcomeReferenceKey();
    OutcomeCountDetails outcomeCountDetails;
    final OutcomeNameStatusKey outcomeNameStatusKey = new OutcomeNameStatusKey();

    // assign validation details
    outcomeValidationDetails.assign(details);

    // validate details
    validateDetails(outcomeValidationDetails);

    if (details.outcomeReference.length() != 0) {

      // set outcome reference key
      outcomeReferenceKey.outcomeReference = details.outcomeReference;

      // count outcomes by outcome reference
      outcomeCountDetails = countByReference(outcomeReferenceKey);

      // outcome reference must be unique
      if (outcomeCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOOUTCOME.ERR_OUTCOME_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }
    }

    // set outcome name and status key
    outcomeNameStatusKey.name = details.name;
    outcomeNameStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // count outcomes by name and record status
    outcomeCountDetails = countByNameAndStatus(outcomeNameStatusKey);

    // outcome name must be unique for all active records
    if (outcomeCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates outcome modify details
   *
   * @param details The details of the outcome
   */
  @Override
  protected void validateModify(OutcomeDtls details) throws AppException,
      InformationalException {

    // Outcome manipulation variables
    final curam.serviceplans.sl.entity.struct.OutcomeKey outcomeKey = new curam.serviceplans.sl.entity.struct.OutcomeKey();
    final OutcomeValidationDetails outcomeValidationDetails = new OutcomeValidationDetails();
    final OutcomeReferenceKey outcomeReferenceKey = new OutcomeReferenceKey();
    OutcomeCountDetails outcomeCountDetails;
    final OutcomeNameStatusKey outcomeNameStatusKey = new OutcomeNameStatusKey();

    // assign validation details
    outcomeValidationDetails.assign(details);

    // validate details
    validateDetails(outcomeValidationDetails);

    // set outcome key
    outcomeKey.outcomeID = details.outcomeID;

    // read outcome status
    final OutcomeStatusDetails outcomeStatusDetails = readStatus(outcomeKey);

    // record must not be canceled
    if (outcomeStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // read name and reference
    final OutcomeNameAndReferenceDetails outcomeNameAndReferenceDetails = readNameAndReference(
      outcomeKey);

    // if name is modified, the new name must be unique
    if (!outcomeNameAndReferenceDetails.name.equals(details.name)) {

      // set outcome name and status key
      outcomeNameStatusKey.name = details.name;
      outcomeNameStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      // count outcomes by name and record status
      outcomeCountDetails = countByNameAndStatus(outcomeNameStatusKey);

      // outcome name must be unique for all active records
      if (outcomeCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOOUTCOME.ERR_OUTCOME_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }

    }

    // if reference is modified, the new reference must be unique
    if (!outcomeNameAndReferenceDetails.outcomeReference.equals(
      details.outcomeReference)) {

      // set outcome reference key
      outcomeReferenceKey.outcomeReference = details.outcomeReference;

      // count outcomes by outcome reference
      outcomeCountDetails = countByReference(outcomeReferenceKey);

      // outcome reference must be unique
      if (outcomeCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOOUTCOME.ERR_OUTCOME_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

    }

  }

}
