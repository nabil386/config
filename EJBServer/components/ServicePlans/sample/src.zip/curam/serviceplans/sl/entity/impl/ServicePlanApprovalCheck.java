/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANAPPROVALCHECK;
import curam.core.impl.CuramConst;
import curam.message.BPOSERVICEPLANAPPROVALCHECK;
import curam.serviceplans.sl.entity.fact.ServicePlanFactory;
import curam.serviceplans.sl.entity.intf.ServicePlan;
import curam.serviceplans.sl.entity.struct.ApprovalCheckSPModifyKey;
import curam.serviceplans.sl.entity.struct.CancelApprovalCheckDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanApprovalCheckKey;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.entity.struct.ServicePlanStatus;
import curam.serviceplans.sl.entity.struct.UnameModifyKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class ServicePlanApprovalCheck extends curam.serviceplans.sl.entity.base.ServicePlanApprovalCheck {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details approval check details
   */
  @Override
  protected void preinsert(ServicePlanApprovalCheckDtls details)
    throws AppException, InformationalException {

    // setting type code if all service plan types is selected
    if (details.appliesToAllInd) {
      if (details.userName.length() > 0) {
        details.typeCode = SERVICEPLANAPPROVALCHECK.USER;
      }
      if (details.organisationUnitID != 0) {
        details.typeCode = curam.codetable.SERVICEPLANAPPROVALCHECK.ORG_UNIT;
      }
    } else {
      // setting the typceCode when a specific service plan is selected
      if (details.userName.length() > 0) {
        details.typeCode = curam.codetable.SERVICEPLANAPPROVALCHECK.USER;
      }
      if (details.organisationUnitID != 0) {
        details.typeCode = curam.codetable.SERVICEPLANAPPROVALCHECK.ORG_UNIT;
      }
      if (details.userName.length() == 0 && details.organisationUnitID == 0) {
        details.typeCode = curam.codetable.SERVICEPLANAPPROVALCHECK.SERVICE_PLAN;
      }
    }
    // set record status to normal
    details.statusCode = RECORDSTATUS.NORMAL;
    validateInsert(details);
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification.
   *
   * @param details approval check details
   * @throws AppException, InformationalException
   */
  @Override
  public void validateInsert(ServicePlanApprovalCheckDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00161962, LJ
    // Validate details first
    validateDetails(details);

    // struct for duplicate approval checks
    curam.serviceplans.sl.entity.struct.ApprovalCheckCount approvalCheckCount = new curam.serviceplans.sl.entity.struct.ApprovalCheckCount();

    if (details.typeCode.equals(SERVICEPLANAPPROVALCHECK.SERVICE_PLAN)) {

      // check for duplicate service plan approval checks
      final curam.serviceplans.sl.entity.struct.ApprovalCheckSPKey approvalCheckSPKey = new curam.serviceplans.sl.entity.struct.ApprovalCheckSPKey();

      approvalCheckSPKey.estimatedCost = details.estimatedCost;
      approvalCheckSPKey.servicePlanID = details.servicePlanID;
      approvalCheckSPKey.statusCode = details.statusCode;
      approvalCheckSPKey.typeCode = details.typeCode;
      approvalCheckCount = this.countByServicePlanID(approvalCheckSPKey);
    }
    // END, CR00161962
    // validate user type service plan approval checks
    if (details.typeCode.equals(SERVICEPLANAPPROVALCHECK.USER)) {
      // set key details
      final curam.serviceplans.sl.entity.struct.UnameKey unameKey = new curam.serviceplans.sl.entity.struct.UnameKey();

      unameKey.estimatedCost = details.estimatedCost;
      unameKey.servicePlanID = details.servicePlanID;
      unameKey.userName = details.userName;
      unameKey.statusCode = details.statusCode;

      // if all types selected
      if (details.servicePlanID == 0) {
        approvalCheckCount = this.countByUnameAndAllTypes(unameKey);
      } else { // if a particular service plan is selected
        approvalCheckCount = this.countByUname(unameKey);
      }

      // must select either service plan or applies to all
      if (details.appliesToAllInd == false && details.servicePlanID == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_SERVICEPLAN),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // if service plan is selected, selecting all types is not permitted
      if (details.appliesToAllInd && details.servicePlanID != 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_APPLIESTOALLIND),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // checking for duplicate approval checks
    if (approvalCheckCount.recordCount != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_FV_TYPE_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are done before data modification
   *
   * @param key approval check key
   */

  @Override
  public void validateCancel(ServicePlanApprovalCheckKey key)
    throws AppException, InformationalException {

    // Read record status
    curam.serviceplans.sl.entity.struct.ApprovalCheckStatusDetails approvalCheckStatusDetails = new curam.serviceplans.sl.entity.struct.ApprovalCheckStatusDetails();

    approvalCheckStatusDetails = readStatus(key);
    if (approvalCheckStatusDetails.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_FV_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // __________________________________________________________________________
  /**
   * Ensures validations are done before data modification.
   *
   * @param details approval check dtls
   * @throws AppException, InformationalException
   */

  @Override
  public void validateModify(ServicePlanApprovalCheckDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00161962, LJ
    // Validate details first
    validateDetails(details);

    // struct to check for duplicate approval checks
    curam.serviceplans.sl.entity.struct.ApprovalCheckCount approvalCheckCount = new curam.serviceplans.sl.entity.struct.ApprovalCheckCount();

    if (details.typeCode.equals(SERVICEPLANAPPROVALCHECK.SERVICE_PLAN)) {
      // check for duplicate service plan approval checks
      final ApprovalCheckSPModifyKey approvalCheckSPModifyKey = new curam.serviceplans.sl.entity.struct.ApprovalCheckSPModifyKey();

      approvalCheckSPModifyKey.estimatedCost = details.estimatedCost;
      approvalCheckSPModifyKey.servicePlanID = details.servicePlanID;
      approvalCheckSPModifyKey.statusCode = details.statusCode;
      approvalCheckSPModifyKey.typeCode = details.typeCode;
      approvalCheckSPModifyKey.servicePlanapprovalCheckID = details.servicePlanApprovalCheckID;
      approvalCheckCount = this.countBySPandApprovalCheck(
        approvalCheckSPModifyKey);
    }
    // END, CR00161962
    // validate user type service plan approval checks
    if (details.typeCode.equals(SERVICEPLANAPPROVALCHECK.USER)) {
      // set key details
      final UnameModifyKey unameModifyKey = new curam.serviceplans.sl.entity.struct.UnameModifyKey();

      unameModifyKey.estimatedCost = details.estimatedCost;
      unameModifyKey.servicePlanID = details.servicePlanID;
      unameModifyKey.userName = details.userName;
      unameModifyKey.statusCode = details.statusCode;
      unameModifyKey.servicePlanapprovalCheckID = details.servicePlanApprovalCheckID;
      if (details.servicePlanID == 0) {
        approvalCheckCount = this.countbyUnameApprChkAllSPTypes(unameModifyKey);
      } else {
        approvalCheckCount = this.countByUnameandApprovalcheck(unameModifyKey);
      }
      // select service plan or applies to all
      if (details.appliesToAllInd == false && details.servicePlanID == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_SERVICEPLAN),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }
    // checking for duplicate approval checks
    if (approvalCheckCount.recordCount != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_FV_TYPE_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are done before data modification
   *
   * @param key approval check key
   * @param details approval check details
   */

  @Override
  protected void premodify(ServicePlanApprovalCheckKey key,
    ServicePlanApprovalCheckDtls details) throws AppException,
      InformationalException {

    validateModify(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are done before data modification
   *
   * @param key approval check key
   * @param dtls approval check details
   */

  @Override
  protected void precancel(ServicePlanApprovalCheckKey key,
    CancelApprovalCheckDetails dtls) throws AppException,
      InformationalException {

    validateCancel(key);
  }

  // __________________________________________________________________________
  /**
   * Ensures common validations are done before inserting and modifying data.
   *
   * @param details approval check details
   * @throws AppException, InformationalException
   */
  @Override
  public void validateDetails(ServicePlanApprovalCheckDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00161962, LJ
    // BEGIN, CR00238338, PF
    // Percentage must be greater than zero & must not be greater
    // than one hundred.
    if (details.percentage < 0
      || details.percentage > CuramConst.gkOneHundredPercent) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_FV_PERCENTAGE_NOT_IN_RANGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00238338

    // Estimated cost cannot be negative.
    if (details.estimatedCost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANAPPROVALCHECK.ERR_APPROVALCHECK_FV_ESTIMATED_COST_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // If a service plan ID is provided the service plan can not be cancelled
    if (!details.appliesToAllInd && details.servicePlanID != 0) {
      // make sure service plan is active
      final ServicePlanKey servicePlanKey = new ServicePlanKey();
      ServicePlanStatus servicePlanStatus = new ServicePlanStatus();

      // ServicePlanApprovalCheck process class
      final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();

      servicePlanKey.servicePlanID = details.servicePlanID;
      // get record status if service plan is selected
      servicePlanStatus = servicePlanObj.readStatus(servicePlanKey);

      if (servicePlanStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANAPPROVALCHECK.ERR_SERVICEPLAN_RV_CANCELLED_NO_MODIFY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00161962
  }

}
