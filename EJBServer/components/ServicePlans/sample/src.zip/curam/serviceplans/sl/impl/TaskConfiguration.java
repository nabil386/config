/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.impl;


import curam.codetable.PLANITEMTASKNAME;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TARGETITEMTYPE;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.JobName;
import curam.core.sl.entity.struct.OrgUnitAndStatusKey;
import curam.core.sl.entity.struct.OrganisationStructureIDDtls;
import curam.core.sl.entity.struct.OrganisationUnitIDDtls;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.PositionName;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.ReadWorkQueueDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.message.BPOPLANITEM;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.TaskConfigurationFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.struct.PlanItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlanItemTaskConfigSearchKey;
import curam.serviceplans.sl.entity.struct.TaskConfigurationDtls;
import curam.serviceplans.sl.entity.struct.TaskConfigurationDtlsList;
import curam.serviceplans.sl.entity.struct.TaskConfigurationIDKey;
import curam.serviceplans.sl.entity.struct.TaskConfigurationKey;
import curam.serviceplans.sl.entity.struct.TaskNameStruct;
import curam.serviceplans.sl.struct.TaskConfigurationDetails;
import curam.serviceplans.sl.struct.TaskConfigurationDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.UniqueID;


/**
 * This process class provides the functionality for Task Configurations in
 * service layer.
 */
public abstract class TaskConfiguration extends curam.serviceplans.sl.base.TaskConfiguration {

  /**
   * Cancels the task configuration record.
   *
   * @param taskConfigKey
   * Contains unique ID of the task configuration being canceled.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void cancel(final TaskConfigurationKey taskConfigKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();
    final TaskConfigurationDtls taskConfigurationDtls = taskConfigObj.read(
      taskConfigKey);

    // If the task configuration is already cancelled then throw an exception
    // : This task configuration cannot be cancelled as it is already cancelled.
    if (taskConfigurationDtls.status.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(
        BPOPLANITEM.ERR_TASK_CONFIGURATION_CANNOT_BE_CANCELED);
    }
    validateTaskConfigurationDeletion(taskConfigKey);
    taskConfigurationDtls.status = RECORDSTATUS.CANCELLED;
    taskConfigObj.modify(taskConfigKey, taskConfigurationDtls);
  }

  /**
   * This method is used to search the task configuration record based on the
   * search criteria entered by the user.
   *
   * @param taskConfigKey
   * Task config Key
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void validateTaskConfigurationDeletion(
    TaskConfigurationKey taskConfigKey) throws AppException,
      InformationalException {

    // Entity layer Object
    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final TaskConfigurationIDKey taskConfigKeyEL = new TaskConfigurationIDKey();

    taskConfigKeyEL.taskConfigID = taskConfigKey.taskConfigurationID;
    taskConfigKeyEL.recordStatus = RECORDSTATUS.NORMAL;
    // Check if plan item is associated with the task configuration id
    final PlanItemDtlsList planItemDtlsList = planItemObj.searchByTaskConfigID(
      taskConfigKeyEL);

    if (planItemDtlsList.dtls.size() > 0) {
      throw new AppException(
        BPOPLANITEM.ERR_TASK_CONFIGURATION_ASSOCIATED_WITH_PLAN_ITEM);
    }

  }

  /**
   * This method is used to search the task configuration record based on the
   * search criteria entered by the user.
   *
   * @param searchKey
   * Contains search criteria
   *
   * @return TaskConfigurationDtlsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public TaskConfigurationDetailsList searchByTaskNamePriorityAssignee(
    PlanItemTaskConfigSearchKey searchKey) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();
    TaskConfigurationDtlsList taskConfigurationDtlsList;
    final TaskConfigurationDetailsList taskConfigurationDetailsList = new TaskConfigurationDetailsList();

    if (searchKey.taskName.equals(CuramConst.gkEmpty)) {
      return taskConfigurationDetailsList;
    }
    final TaskNameStruct taskNameStruct = new TaskNameStruct();

    taskNameStruct.taskName = searchKey.taskName;
    taskNameStruct.status = RECORDSTATUS.NORMAL;
    taskConfigurationDtlsList = taskConfigObj.searchByTaskName(taskNameStruct);
    TaskConfigurationDetails taskConfigDetails;

    final int taskConfigurationListSize = taskConfigurationDtlsList.dtls.size();

    for (int taskConfigurationIter = 0; taskConfigurationIter
      < taskConfigurationListSize; taskConfigurationIter++) {
      taskConfigDetails = new TaskConfigurationDetails();
      taskConfigDetails.dtls.assign(
        taskConfigurationDtlsList.dtls.item(taskConfigurationIter));
      if (!taskConfigurationDtlsList.dtls.item(taskConfigurationIter).assignToID.equals(
        CuramConst.gkEmpty)) {
        taskConfigDetails.dtls.assignToID = taskConfigurationDtlsList.dtls.item(taskConfigurationIter).assignToID;
        taskConfigDetails.dtls.assignToType = taskConfigurationDtlsList.dtls.item(taskConfigurationIter).assignToType;

        getTaskAssigneeName(taskConfigDetails);
      } else {
        taskConfigDetails.assigneeName = ServicePlanConst.kPlanItemOwnerParam;
      }
      taskConfigurationDetailsList.taskConfigDetails.addRef(taskConfigDetails);
    }
    return taskConfigurationDetailsList;
  }

  /**
   * This method is used to create the task configuration record.
   *
   * @param taskConfigDtls
   * TaskConfigurationDtls
   *
   * @return TaskConfigurationKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public TaskConfigurationKey insert(TaskConfigurationDtls taskConfigDtls)
    throws AppException, InformationalException {

    // Validate the task configuration record.
    validateTaskConfiguration(taskConfigDtls);

    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();

    taskConfigDtls.taskConfigurationID = UniqueID.nextUniqueID();
    taskConfigDtls.status = RECORDSTATUS.NORMAL;
    taskConfigDtls.dateCreated = Date.getCurrentDate();
    taskConfigObj.insert(taskConfigDtls);

    final TaskConfigurationKey piTaskConfigKey = new TaskConfigurationKey();

    piTaskConfigKey.taskConfigurationID = taskConfigDtls.taskConfigurationID;

    return piTaskConfigKey;
  }

  /**
   * This method is used to list all the active records in task configuration
   * details.
   *
   * @return TaskConfigurationDtlsList
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public TaskConfigurationDtlsList list() throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();
    final TaskConfigurationDtlsList taskConfigDtlsList = taskConfigObj.readAll();

    return taskConfigDtlsList;
  }

  /**
   * This method is used to modify the task configuration record.
   *
   * @param taskConfigDtls
   * TaskConfigurationDtls
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void modify(TaskConfigurationDtls taskConfigDtls)
    throws AppException, InformationalException {

    if (taskConfigDtls.status.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_TASK_CONFIGURATION_ALREADY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();

    // Check if the task can be modified
    validateTaskConfiguration(taskConfigDtls);

    final TaskConfigurationKey taskConfigKey = new TaskConfigurationKey();

    taskConfigKey.taskConfigurationID = taskConfigDtls.taskConfigurationID;
    taskConfigObj.modify(taskConfigKey, taskConfigDtls);
  }

  /**
   * This method is used to validate the creation of the task configuration.
   *
   * @param taskConfigDtls
   * TaskConfigurationDtls
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void validateTaskConfiguration(
    TaskConfigurationDtls taskConfigDtls) throws InformationalException,
      AppException {

    // Both 'reserve to owner' and 'assign to' cannot be specified
    // together.
    if (taskConfigDtls.reserveToOwnerInd
      && !CuramConst.gkEmpty.equals(taskConfigDtls.assignToID)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_TASK_CONFIG_PI_OWNER_AND_ASSIGNTO_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    if (!taskConfigDtls.reserveToOwnerInd
      && CuramConst.gkEmpty.equals(taskConfigDtls.assignToID)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_TASK_CONFIG_PI_OWNER_OR_ASSIGNTO_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Entity layer object
    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();
    // Fetch all the task configurations
    final TaskConfigurationDtlsList taskConfigurationDtlsList = taskConfigObj.readAll();
    TaskConfigurationDtls taskConfigurationDtls = null;

    // Check if a task configuration exists with this name
    for (int i = 0; i < taskConfigurationDtlsList.dtls.size(); i++) {
      taskConfigurationDtls = taskConfigurationDtlsList.dtls.item(i);
      if (taskConfigDtls.taskName.equals(taskConfigurationDtls.taskName)
        && taskConfigurationDtls.status.equals(RECORDSTATUS.NORMAL)
        && taskConfigDtls.taskConfigurationID
          != taskConfigurationDtls.taskConfigurationID) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPLANITEM.ERR_MULTIPLE_TASK_WITH_SAME_NAME),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }
    }

  }

  /**
   * This method is used to read the task configuration record.
   *
   * @param taskConfigKey
   * TaskConfigurationKey
   *
   * @return TaskConfigurationDtls
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public TaskConfigurationDetails read(TaskConfigurationKey taskConfigKey)
    throws AppException, InformationalException {

    // Entity layer object
    final curam.serviceplans.sl.entity.intf.TaskConfiguration taskConfigObj = TaskConfigurationFactory.newInstance();
    final TaskConfigurationDtls taskConfigDtls = taskConfigObj.read(
      taskConfigKey);

    final TaskConfigurationDetails taskConfigurationDetails = new TaskConfigurationDetails();

    // Get the description from the code table.
    taskConfigurationDetails.taskNameDescription = CodeTable.getOneItem(
      PLANITEMTASKNAME.TABLENAME, taskConfigDtls.taskName);
    taskConfigurationDetails.dtls.assign(taskConfigDtls);

    if (!taskConfigurationDetails.dtls.assignToID.equals(CuramConst.gkEmpty)) {
      getTaskAssigneeName(taskConfigurationDetails);
    }

    return taskConfigurationDetails;
  }

  /**
   * This method is used to populate the task assignee name based on target item
   * type.
   *
   * @param taskConfigurationDetails
   * - task allocation type
   * @throws AppException
   * @throws InformationalException
   */
  protected void getTaskAssigneeName(
    TaskConfigurationDetails taskConfigurationDetails) throws AppException,
      InformationalException {

    // check if the assignToType if equal to WorkQueue
    if (taskConfigurationDetails.dtls.assignToType.equals(
      TARGETITEMTYPE.WORKQUEUE)) {

      // WorkQueue object
      final curam.core.sl.intf.WorkQueue workQueueObj = curam.core.sl.fact.WorkQueueFactory.newInstance();

      final curam.core.sl.struct.ReadWorkQueueKey readWorkQueueKey = new curam.core.sl.struct.ReadWorkQueueKey();

      // Set the Work Queue ID as the key
      readWorkQueueKey.key.workQueueID = Long.parseLong(
        taskConfigurationDetails.dtls.assignToID);

      // Read the WorkQueue details
      final ReadWorkQueueDetails readWorkQueueDetails = workQueueObj.read(
        readWorkQueueKey);

      // set the WorkQueue name in the details
      taskConfigurationDetails.assigneeName = readWorkQueueDetails.dtls.name;

      taskConfigurationDetails.homePageURL = ServicePlanConst.kWorkQueuePage
        + taskConfigurationDetails.dtls.assignToID;
    }
    if (taskConfigurationDetails.dtls.assignToType.equals(
      curam.codetable.TARGETITEMTYPE.JOB)) {

      // Users manipulation variables
      final curam.core.sl.entity.intf.Job jobObj = curam.core.sl.entity.fact.JobFactory.newInstance();

      final curam.core.sl.entity.struct.JobKey jobKey = new curam.core.sl.entity.struct.JobKey();

      // Set key for read
      jobKey.jobID = Long.parseLong(taskConfigurationDetails.dtls.assignToID);

      // Read Job name
      final JobName jobName = jobObj.readJobName(jobKey);

      // Set full name in object
      taskConfigurationDetails.assigneeName = jobName.name;

      taskConfigurationDetails.homePageURL = ServicePlanConst.kOrganisationPage
        + taskConfigurationDetails.dtls.assignToID;

    }

    if (taskConfigurationDetails.dtls.assignToType.equals(
      curam.codetable.TARGETITEMTYPE.ORGUNIT)) {

      // Users manipulation variables
      final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();

      final curam.core.sl.entity.intf.OrgUnitParentLink orgUnitParentLinkObj = curam.core.sl.entity.fact.OrgUnitParentLinkFactory.newInstance();

      final curam.core.sl.entity.struct.OrganisationUnitKey organisationUnitKey = new curam.core.sl.entity.struct.OrganisationUnitKey();

      // Set key for read
      organisationUnitKey.organisationUnitID = Long.parseLong(
        taskConfigurationDetails.dtls.assignToID);

      // Read Organization Unit Name name
      final OrganisationUnitName organisationUnitName = organisationUnitObj.readOrgUnitName(
        organisationUnitKey);

      final curam.core.sl.entity.struct.OrgUnitAndStatusKey orgUnitAndStatusKey = new OrgUnitAndStatusKey();

      final curam.core.sl.entity.struct.OrganisationStructureIDDtls organisationStructureIDDtls = new OrganisationStructureIDDtls();

      orgUnitAndStatusKey.organisationUnitID = organisationUnitKey.organisationUnitID;
      orgUnitAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      organisationStructureIDDtls.assign(
        orgUnitParentLinkObj.readOrgStructureID(orgUnitAndStatusKey));

      // Set full name in object
      taskConfigurationDetails.assigneeName = organisationUnitName.name;

      taskConfigurationDetails.homePageURL = ServicePlanConst.kOrganizationHomePage
        + taskConfigurationDetails.dtls.assignToID
        + ServicePlanConst.kOrganizationParam
        + organisationStructureIDDtls.organisationStructureID;
    }

    if (taskConfigurationDetails.dtls.assignToType.equals(
      curam.codetable.TARGETITEMTYPE.POSITION)) {

      // Users manipulation variables
      final curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
      final curam.core.sl.entity.struct.PositionKey positionKey = new curam.core.sl.entity.struct.PositionKey();

      final curam.core.sl.entity.intf.OrgUnitParentLink orgUnitParentLinkObj = curam.core.sl.entity.fact.OrgUnitParentLinkFactory.newInstance();

      // Set key for read
      positionKey.positionID = Long.parseLong(
        taskConfigurationDetails.dtls.assignToID);
      // Read Position name
      final PositionName positionName = positionObj.readPositionName(
        positionKey);

      final curam.core.sl.entity.struct.OrganisationUnitIDDtls organisationUnitIDDtls = new OrganisationUnitIDDtls();

      organisationUnitIDDtls.assign(
        positionObj.readOrganisationUnitID(positionKey));

      // Set full name in object
      taskConfigurationDetails.assigneeName = positionName.name;

      final curam.core.sl.entity.struct.OrgUnitAndStatusKey orgUnitAndStatusKey = new OrgUnitAndStatusKey();

      final curam.core.sl.entity.struct.OrganisationStructureIDDtls organisationStructureIDDtls = new OrganisationStructureIDDtls();

      orgUnitAndStatusKey.organisationUnitID = organisationUnitIDDtls.organisationUnitID;
      orgUnitAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      organisationStructureIDDtls.assign(
        orgUnitParentLinkObj.readOrgStructureID(orgUnitAndStatusKey));

      taskConfigurationDetails.homePageURL = ServicePlanConst.kOrganizationPositionPage
        + taskConfigurationDetails.dtls.assignToID
        + ServicePlanConst.kOrganizationParam
        + organisationStructureIDDtls.organisationStructureID
        + ServicePlanConst.kOrganizationUnitParam
        + organisationUnitIDDtls.organisationUnitID;
    }

    if (taskConfigurationDetails.dtls.assignToType.equals(
      curam.codetable.TARGETITEMTYPE.USER)) {

      // Users manipulation variables
      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      // Set key to read user name
      usersKey.userName = taskConfigurationDetails.dtls.assignToID;

      // Read the user's full details
      final UserFullname userFullname = userAccessObj.getFullName(usersKey);

      // Set full name in object
      taskConfigurationDetails.assigneeName = userFullname.fullname;

      taskConfigurationDetails.homePageURL = ServicePlanConst.kOrganizationUserPage
        + taskConfigurationDetails.dtls.assignToID;
    }
    if (taskConfigurationDetails.dtls.assignToType.equals(
      curam.codetable.TARGETITEMTYPE.EXTERNALUSER)) {

      // Users manipulation variables
      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      // Set key to read user name
      usersKey.userName = taskConfigurationDetails.dtls.assignToID;

      // Read the user's full details
      final UserFullname userFullname = userAccessObj.getFullName(usersKey);

      // Set full name in object
      taskConfigurationDetails.assigneeName = userFullname.fullname;

      taskConfigurationDetails.homePageURL = ServicePlanConst.kExternalUserPage
        + taskConfigurationDetails.dtls.assignToID;
    }
  }
}
