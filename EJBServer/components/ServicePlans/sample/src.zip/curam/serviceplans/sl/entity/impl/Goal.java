/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOGOAL;
import curam.serviceplans.sl.entity.struct.GoalCancelDetails;
import curam.serviceplans.sl.entity.struct.GoalCountDetails;
import curam.serviceplans.sl.entity.struct.GoalDtls;
import curam.serviceplans.sl.entity.struct.GoalIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.GoalKey;
import curam.serviceplans.sl.entity.struct.GoalNameKey;
import curam.serviceplans.sl.entity.struct.GoalNameReferenceDetails;
import curam.serviceplans.sl.entity.struct.GoalReferenceKey;
import curam.serviceplans.sl.entity.struct.GoalStatusDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Contains details about a specific Goal. Goal is assigned to a Service Plan
 * and can have assigned multiple Sub Goals.
 */
public abstract class Goal extends curam.serviceplans.sl.entity.base.Goal {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Goal details
   */
  @Override
  protected void preinsert(GoalDtls details) throws AppException,
      InformationalException {

    // Validate the details
    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Goal identifier
   * @param details Goal details
   */
  @Override
  protected void premodify(GoalKey key, GoalDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateModify(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the goal cancellation
   *
   * @param key Goal identifier
   * @param details Goal details
   */
  @Override
  protected void precancel(GoalKey key, GoalCancelDetails details)
    throws AppException, InformationalException {

    // validate cancel
    validateCancel(key);
  }

  // ___________________________________________________________________________
  /**
   * Validates the goal details
   *
   * @param details The details of the goal
   */
  @Override
  public void validateInsert(GoalDtls details) throws AppException,
      InformationalException {

    // goal reference key
    final GoalReferenceKey goalReferenceKey = new GoalReferenceKey();

    // goal name key
    final GoalNameKey goalNameKey = new GoalNameKey();

    // count details
    GoalCountDetails goalCountDetails;

    // If goalReference is not blank, it must be unique
    if (details.goalReference.length() != 0) {

      // set reference number key
      goalReferenceKey.goalReference = details.goalReference;

      // count goals by reference number
      goalCountDetails = countByReference(goalReferenceKey);

      if (goalCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGOAL.ERR_GOAL_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }
    }

    if (details.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // set name key details
    goalNameKey.name = details.name;
    goalNameKey.recordStatus = RECORDSTATUS.NORMAL;

    // count goals by name
    goalCountDetails = countByNameAndStatus(goalNameKey);

    if (goalCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates the goal to be canceled
   *
   * @param key Goal unique identifier
   */
  @Override
  public void validateCancel(GoalKey key) throws AppException,
      InformationalException {

    // Key struct for counting templates
    final GoalIDAndStatusKey goalIDAndStatusKey = new GoalIDAndStatusKey();

    // Read record status
    final GoalStatusDetails goalStatusDetails = readStatus(key);

    if (goalStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // set the key
    goalIDAndStatusKey.goalID = key.goalID;
    goalIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // count active templates assigned to the goal
    final GoalCountDetails goalCountDetails = countTemplatesByGoalAndStatus(
      goalIDAndStatusKey);

    if (goalCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_XRV_TEMPLATES_EXIST),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // there must not be any service plan based on the goal
    if (countServicePlansByGoalAndStatus(goalIDAndStatusKey).recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_XRV_ASSIGNED_TO_SERVICEPLAN),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the goal to be modified
   *
   * @param dtls modification details
   */
  @Override
  public void validateModify(GoalDtls dtls) throws AppException,
      InformationalException {

    // GoalKey manipulation variable
    final GoalKey goalKey = new GoalKey();

    // GoalNameKey manipulation variable
    final GoalNameKey goalNameKey = new GoalNameKey();

    // GoalReferenceKey manipulation variable
    final GoalReferenceKey goalReferenceKey = new GoalReferenceKey();

    // Goal count details
    GoalCountDetails goalCountDetails;

    if (dtls.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Set goal key
    goalKey.goalID = dtls.goalID;

    // Read goal name and reference number
    final GoalNameReferenceDetails goalNameReferenceDetails = readNameAndReference(
      goalKey);

    // if reference is modified, it must be unique
    if (!goalNameReferenceDetails.goalReference.equals(dtls.goalReference)
      && dtls.goalReference.length() != 0) {

      // set goal reference key details
      goalReferenceKey.goalReference = dtls.goalReference;

      // count goals by reference
      goalCountDetails = countByReference(goalReferenceKey);

      if (goalCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGOAL.ERR_GOAL_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

    }

    // if name is modified, the new name must be unique
    if (!goalNameReferenceDetails.name.equals(dtls.name)) {

      // set goal name key details
      goalNameKey.name = dtls.name;
      goalNameKey.recordStatus = RECORDSTATUS.NORMAL;

      // count goals by name
      goalCountDetails = countByNameAndStatus(goalNameKey);

      if (goalCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGOAL.ERR_GOAL_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

    }

  }

}
