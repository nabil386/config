/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004, 2010Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOGOODCAUSE;
import curam.serviceplans.sl.entity.struct.GoodCauseCancelDetails;
import curam.serviceplans.sl.entity.struct.GoodCauseCountDetails;
import curam.serviceplans.sl.entity.struct.GoodCauseDtls;
import curam.serviceplans.sl.entity.struct.GoodCauseIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.GoodCauseKey;
import curam.serviceplans.sl.entity.struct.GoodCauseModifyDetails;
import curam.serviceplans.sl.entity.struct.GoodCauseNameAndReferenceDetails;
import curam.serviceplans.sl.entity.struct.GoodCauseNameAndStatusKey;
import curam.serviceplans.sl.entity.struct.GoodCauseRecordStatusDetails;
import curam.serviceplans.sl.entity.struct.GoodCauseReferenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Stores all possible acceptable reasons why an plan item on the users plan was
 * not
 * completed satisfactorily.
 */
public abstract class GoodCause extends curam.serviceplans.sl.entity.base.GoodCause {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the good cause cancellation
   *
   * @param key Good cause identifier
   * @param details Good cause details
   */
  @Override
  protected void precancel(GoodCauseKey key, GoodCauseCancelDetails details)
    throws AppException, InformationalException {

    // validate cancellation
    validateCancel(key);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the good cause insertion
   *
   * @param details Good cause details
   */
  @Override
  protected void preinsert(GoodCauseDtls details) throws AppException,
      InformationalException {

    // validate details for insert
    validateInsert(details);
  }

  // BEGIN, CR00234442, GP
  /**
   * Ensures validations are performed before the good cause modification
   *
   * @param key Good cause identifier
   * @param details Good cause details
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link GoodCause# premodifyDetails()} as part of implementing localization
   * of Good Cause
   * description. See release note: CR00234442.
   */
  @Override
  @Deprecated
  protected void premodify(GoodCauseKey key, GoodCauseModifyDetails details)
    throws AppException, InformationalException {

    // END, CR00234442

    // validate details for modify
    validateModify(key, details);
  }

  // BEGIN, CR00234442, GP
  /**
   * Ensures validations are performed before the good cause modification
   *
   * @param key contains the Good cause identifier.
   * @param details contains the Good cause details to be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void premodifyDetails(GoodCauseKey key, GoodCauseDtls details)
    throws AppException, InformationalException {

    final GoodCauseModifyDetails goodCauseModifyDetails = new GoodCauseModifyDetails();

    goodCauseModifyDetails.goodCauseReference = details.goodCauseReference;
    goodCauseModifyDetails.name = details.name;
    validateModify(key, goodCauseModifyDetails);
  }

  // END, CR00234442

  /**
   * Ensure that it is valid to cancel the good cause identified by the key.
   *
   * @param key Good cause identifier
   */
  @Override
  protected void validateCancel(GoodCauseKey key) throws AppException,
      InformationalException {

    // Read record status
    final GoodCauseRecordStatusDetails goodCauseRecordStatusDetails = readRecordStatus(
      key);

    if (goodCauseRecordStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_RECORD_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final GoodCauseIDAndStatusKey goodCauseIDAndStatusKey = new GoodCauseIDAndStatusKey();

    // set the key
    goodCauseIDAndStatusKey.goodCauseID = key.goodCauseID;
    goodCauseIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // count active planItems linked to the GoodCause
    if (countPlanItemsByGoodCauseAndStatus(goodCauseIDAndStatusKey).recordCount
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_XRV_ASSIGNED_TO_PLANITEM),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Determines that the details provided for the insert are valid.
   *
   * @param dtls Good cause details
   */
  @Override
  protected void validateInsert(GoodCauseDtls dtls) throws AppException,
      InformationalException {

    // Good cause reference key
    final GoodCauseReferenceKey goodCauseReferenceKey = new GoodCauseReferenceKey();

    // Good cause name and status key
    final GoodCauseNameAndStatusKey goodCauseNameAndStatusKey = new GoodCauseNameAndStatusKey();

    // count details
    GoodCauseCountDetails goodCauseCountDetails;

    // If Reference is not blank, it must be unique
    if (dtls.goodCauseReference.length() != 0) {

      // set the reference key
      goodCauseReferenceKey.goodCauseReference = dtls.goodCauseReference;

      // count by reference
      goodCauseCountDetails = countByReference(goodCauseReferenceKey);

      if (goodCauseCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGOODCAUSE.ERR_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }
    }

    if (dtls.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // set name key details
    goodCauseNameAndStatusKey.name = dtls.name;
    goodCauseNameAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // count active good causes by name
    goodCauseCountDetails = countByNameAndStatus(goodCauseNameAndStatusKey);

    if (goodCauseCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Determines that the details provided for the modify are valid.
   *
   * @param key Good cause identifier
   * @param details Good cause details
   */
  @Override
  protected void validateModify(GoodCauseKey key,
    GoodCauseModifyDetails details) throws AppException,
      InformationalException {

    // GoodCauseNameAndStatusKey manipulation variable
    final GoodCauseNameAndStatusKey goodCauseNameAndStatusKey = new GoodCauseNameAndStatusKey();

    // GoodCauseReferenceKey manipulation variable
    final GoodCauseReferenceKey goodCauseReferenceKey = new GoodCauseReferenceKey();

    // Good cause count details
    GoodCauseCountDetails goodCauseCountDetails;

    if (details.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Read record status
    final GoodCauseRecordStatusDetails goodCauseRecordStatusDetails = readRecordStatus(
      key);

    if (goodCauseRecordStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOODCAUSE.ERR_FV_RECORD_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Read good cause name and reference number
    final GoodCauseNameAndReferenceDetails goodCauseNameAndReferenceDetails = readNameAndReference(
      key);

    // if reference is modified, it must be unique
    if (!goodCauseNameAndReferenceDetails.goodCauseReference.equals(
      details.goodCauseReference)
        && details.goodCauseReference.length() != 0) {

      // set good cause reference key details
      goodCauseReferenceKey.goodCauseReference = details.goodCauseReference;

      // count good causes by reference
      goodCauseCountDetails = countByReference(goodCauseReferenceKey);

      if (goodCauseCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGOODCAUSE.ERR_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

    }

    // if name is modified, the new name must be unique
    if (!goodCauseNameAndReferenceDetails.name.equals(details.name)) {

      // set good cause name key details
      goodCauseNameAndStatusKey.name = details.name;
      goodCauseNameAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      // count active good causes by name
      goodCauseCountDetails = countByNameAndStatus(goodCauseNameAndStatusKey);

      if (goodCauseCountDetails.recordCount > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGOODCAUSE.ERR_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }

    }

  }

}
