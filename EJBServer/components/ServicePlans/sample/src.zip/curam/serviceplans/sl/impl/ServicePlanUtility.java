/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004,2008, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.serviceplans.sl.struct.ApprovalCriteriaID;
import curam.serviceplans.sl.struct.ApprovalCriteriaKeyList;
import curam.serviceplans.sl.struct.ApprovalCriteriaTabList;
import curam.serviceplans.sl.struct.GoalKeyList;
import curam.serviceplans.sl.struct.GoalTabList;
import curam.serviceplans.sl.struct.GoodCauseKeyList;
import curam.serviceplans.sl.struct.GoodCauseTabList;
import curam.serviceplans.sl.struct.IntegratedCaseIDList;
import curam.serviceplans.sl.struct.IntegratedCasesTabList;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.OutcomeKeyList;
import curam.serviceplans.sl.struct.OutcomeTabList;
import curam.serviceplans.sl.struct.PlanItemKeyList;
import curam.serviceplans.sl.struct.PlanItemTabList;
import curam.serviceplans.sl.struct.PlanTemplateKeyList;
import curam.serviceplans.sl.struct.PlanTemplateTabList;
import curam.serviceplans.sl.struct.SubGoalKey;
import curam.serviceplans.sl.struct.SubGoalKeyList;
import curam.serviceplans.sl.struct.SubGoalTabList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.StringList;


/**
 * Utility class which contains functionalities to parse tab delimited string
 * details.
 *
 */
public abstract class ServicePlanUtility extends curam.serviceplans.sl.base.ServicePlanUtility {

  // BEGIN, CR00021588, TV
  public static final int gkOne = 1;

  // END, CR00021588

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of outcome
   * information into an object list.
   *
   * @param details Outcome details delimited string
   * @return list of outcome information
   */
  @Override
  public OutcomeKeyList parseOutcomes(OutcomeTabList details)
    throws AppException, InformationalException {

    // Return value
    final OutcomeKeyList outcomeKeyList = new OutcomeKeyList();

    // Outcome key
    OutcomeKey outcomeKey;

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.outcomeIDTabList);

    for (int i = 0; i < stringList.size(); i++) {
      outcomeKey = new OutcomeKey();

      // set outcome key from the list
      outcomeKey.key.outcomeID = Long.parseLong(stringList.item(i));

      // add to the list
      outcomeKeyList.outcomeKey.addRef(outcomeKey);
    }

    return outcomeKeyList;

  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of sub goal
   * information into an object list.
   *
   * @param details Sub Goal details delimited string
   * @return list of sub goal information
   */
  @Override
  public SubGoalKeyList parseSubGoals(SubGoalTabList details)
    throws AppException, InformationalException {

    // Return value
    final SubGoalKeyList subGoalKeyList = new SubGoalKeyList();

    // Sub Goal key
    SubGoalKey subGoalKey;

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.subGoalIDTabList);

    for (int i = 0; i < stringList.size(); i++) {
      subGoalKey = new SubGoalKey();

      // set sub goal key from the list
      subGoalKey.subGoalKey.subGoalID = Long.parseLong(stringList.item(i));

      // add to the list
      subGoalKeyList.subGoalKey.addRef(subGoalKey);
    }

    return subGoalKeyList;

  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of goal
   * information into an object list.
   *
   * @param details Goal details delimited string
   * @return list of goal information
   */
  @Override
  public GoalKeyList parseGoals(GoalTabList details) throws AppException,
      InformationalException {

    // Return value
    final GoalKeyList goalKeyList = new GoalKeyList();

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.goalIDTabList);

    curam.serviceplans.sl.struct.GoalKey goalKey;

    for (int i = 0; i < stringList.size(); i++) {

      goalKey = new curam.serviceplans.sl.struct.GoalKey();

      // set goal key from the list
      goalKey.goalKey.goalID = Long.parseLong(stringList.item(i));

      // add to the list
      goalKeyList.goalKey.addRef(goalKey);

    }

    return goalKeyList;

  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of planItem
   * information into an object list.
   *
   * @param details PlanItem details delimited string
   * @return list of plan item information
   */
  @Override
  public PlanItemKeyList parsePlanItems(PlanItemTabList details)
    throws AppException, InformationalException {

    // Return value
    final PlanItemKeyList planItemKeyList = new PlanItemKeyList();

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.planItemIDTabList);

    curam.serviceplans.sl.struct.PlanItemKey planItemKey;

    for (int i = 0; i < stringList.size(); i++) {

      planItemKey = new curam.serviceplans.sl.struct.PlanItemKey();

      // set plan item key from the list
      planItemKey.key.planItemID = Long.parseLong(stringList.item(i));

      // add to the list
      planItemKeyList.planItemKey.addRef(planItemKey);

    }

    return planItemKeyList;

  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of plan template
   * information into an object list.
   *
   * @param details Plan template details delimited string
   * @return list of plan template information
   */
  @Override
  public PlanTemplateKeyList parsePlanTemplates(PlanTemplateTabList details)
    throws AppException, InformationalException {

    // Return value
    final PlanTemplateKeyList planTemplateKeyList = new PlanTemplateKeyList();

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.planTemplateIDTabList);

    curam.serviceplans.sl.struct.PlanTemplateKey planTemplateKey;

    for (int i = 0; i < stringList.size(); i++) {

      planTemplateKey = new curam.serviceplans.sl.struct.PlanTemplateKey();

      // set plan template key from the list
      planTemplateKey.planTemplateKey.planTemplateID = Long.parseLong(
        stringList.item(i));

      // add plan template key to the list
      planTemplateKeyList.planTemplateKey.addRef(planTemplateKey);

    }

    return planTemplateKeyList;

  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of integrated case
   * information into an object list.
   *
   * @param icTabList string of Integrated Case IDs delimited by tab symbol
   * @return list of integrated case IDs
   */
  @Override
  public IntegratedCaseIDList parseIntegratedCases(
    IntegratedCasesTabList icTabList) throws AppException,
      InformationalException {

    // Return value
    final IntegratedCaseIDList integratedCaseIDList = new IntegratedCaseIDList();

    curam.serviceplans.sl.entity.struct.AdminICCaseKey adminICCaseKey;

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      icTabList.integratedCaseIDTabList);

    for (int i = 0; i < stringList.size(); i++) {

      adminICCaseKey = new curam.serviceplans.sl.entity.struct.AdminICCaseKey();

      // set outcome key from the list
      adminICCaseKey.caseID = Long.parseLong(stringList.item(i));

      // add to the list
      integratedCaseIDList.adminICCaseKey.addRef(adminICCaseKey);

    }

    return integratedCaseIDList;
  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of good cause
   * information into an object list.
   *
   * @param details string of GoodCause IDs delimited by tab symbol
   * @return list of good cause IDs
   */
  @Override
  public GoodCauseKeyList parseGoodCauses(GoodCauseTabList details)
    throws AppException, InformationalException {

    // Return value
    final GoodCauseKeyList goodCauseKeyList = new GoodCauseKeyList();

    // convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.goodCauseIDTabList);

    curam.serviceplans.sl.struct.GoodCauseKey goodCauseKey;

    for (int i = 0; i < stringList.size(); i++) {

      goodCauseKey = new curam.serviceplans.sl.struct.GoodCauseKey();

      // set plan item key from the list
      goodCauseKey.goodCauseKey.goodCauseID = Long.parseLong(stringList.item(i));

      // add to the list
      goodCauseKeyList.goodCauseKey.addRef(goodCauseKey);

    }

    return goodCauseKeyList;

  }

  // BEGIN, CR00161962, LJ
  /**
   * Parses a delimited string containing multiple instances of approval
   * criteria information into an object list.
   *
   * @param details -
   * details string of approval criteria IDs delimited by tab symbol
   * @return ApprovalCriteriaKeyList - list of approval criteria IDs
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ApprovalCriteriaKeyList parseApprovalCriteria(
    ApprovalCriteriaTabList details) throws AppException,
      InformationalException {

    // Return value
    final ApprovalCriteriaKeyList approvalCriteriaKeyList = new ApprovalCriteriaKeyList();

    // Convert tab delimited string to list of strings
    final StringList stringList = curam.util.resources.StringUtil.tabText2StringList(
      details.approvalCriteriaIDTabList);

    ApprovalCriteriaID approvalCriteriaKey;

    // Loop through string list adding the key to the return struct
    for (final String approvalCriteriaID : stringList.items()) {

      approvalCriteriaKey = new curam.serviceplans.sl.struct.ApprovalCriteriaID();

      // Set approval criteria key from the list
      approvalCriteriaKey.approvalCriteriaID = Long.parseLong(
        approvalCriteriaID);

      // Add to the list
      approvalCriteriaKeyList.approvalCriteriaKey.addRef(approvalCriteriaKey);

    }

    // Return the key list
    return approvalCriteriaKeyList;
  }
  // END, CR00161962
}
