/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;

import curam.codetable.RECORDSTATUS;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.NoteStatus;
import curam.core.impl.NoteType;
import curam.core.impl.NoteUtil;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.fact.NoteFactory;
import curam.core.sl.entity.intf.Note;
import curam.core.sl.entity.struct.LastNoteDetails;
import curam.core.sl.entity.struct.ModifyNoteDetails1;
import curam.core.sl.entity.struct.NoteDtls;
import curam.core.sl.entity.struct.NoteDtlsList;
import curam.core.sl.entity.struct.NoteKey;
import curam.core.sl.entity.struct.NoteText;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.NoteEditDetails;
import curam.core.struct.SecurityResult;
import curam.core.struct.UsersKey;
import curam.message.BPOSPGNOTES;
import curam.message.CASENOTE;
import curam.message.GENERAL;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetails;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetails1;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList1;
import curam.serviceplans.sl.entity.fact.SPGDeliveryNoteLinkFactory;
import curam.serviceplans.sl.entity.intf.SPGDeliveryNoteLink;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkStatusDtls;
import curam.serviceplans.sl.struct.NoteIdKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.StringUtil;
import curam.util.type.DateTime;

/**
 * This API is used to maintain the notes for service plan group delivery.
 */
public abstract class MaintainSPGDeliveryNote
    extends curam.serviceplans.sl.base.MaintainSPGDeliveryNote {

  // ____________________________________________________________________________
  /**
   * This method is used to create note for service plan group delivery.
   *
   * @param details
   *          SPGDeliveryNoteDetails - Details populated from the UIM which
   *          needs to be added
   * @return SPGDeliveryNoteLinkKey - contains the ID of the link which was
   *         created
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public SPGDeliveryNoteLinkKey createNote(final SPGDeliveryNoteDetails details)
      throws AppException, InformationalException {

    // Create an entry in CEF note
    final Note noteObj = NoteFactory.newInstance();

    details.noteDtls.noteID = UniqueIDFactory.newInstance().getNextID();

    if (details.noteDtls.notesText.toString().trim().length() > 0) {

      // insert information line, created as a result of
      final StringBuffer noteText = new StringBuffer();

      final int position = details.noteDtls.notesText
          .indexOf(CASENOTE.INF_NOTE_CREATED_AS_A_RESULT_OF.getMessageText());

      if (position == -1) {

        noteText.append(ServicePlanConst.kNoteCreationSystemDetails);
      }

      noteText.append(details.noteDtls.notesText);
      details.noteDtls.notesText = noteText.toString();
    }

    noteObj.insert(details.noteDtls);

    // Create an entry in service plan group
    final SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory
        .newInstance();

    details.spgDeliveryNoteLink.noteId = details.noteDtls.noteID;
    details.spgDeliveryNoteLink.status = RECORDSTATUS.NORMAL;

    spgDeliveryNoteLinkObj.insert(details.spgDeliveryNoteLink);

    final SPGDeliveryNoteLinkKey returnKey = new SPGDeliveryNoteLinkKey();

    returnKey.spgDeliveryNoteLinkId = details.spgDeliveryNoteLink.spgDeliveryNoteLinkId;

    return returnKey;
  }

  // BEGIN, CR00240923 PDN
  // ____________________________________________________________________________
  /**
   * This method is used to list all the notes for service plan group delivery.
   *
   * @param key
   *          SPGDeliveryKey - contains the ID of the service plan group
   *          delivery.
   * @return SPGDeliveryNoteDetailsList - List of the service plan group
   *         delivery note details.
   * @throws AppException,
   *           InformationalException
   * @deprecated - replaced by {@link #listNotesByGroupDeliveryID()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  @Override
  public SPGDeliveryNoteDetailsList listNotesByGroupDeliveryID(
      final SPGDeliveryKey key) throws AppException, InformationalException {

    // Return struct
    final SPGDeliveryNoteDetailsList spgDeliveryNoteDetailsList = new SPGDeliveryNoteDetailsList();

    final SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList1 = listNotesByGroupDeliveryID1(
        key);

    spgDeliveryNoteDetailsList.assign(spgDeliveryNoteDetailsList1);

    return spgDeliveryNoteDetailsList;
  }

  // ____________________________________________________________________________
  /**
   * This method is used to list all the notes for service plan group delivery.
   *
   * @param key
   *          SPGDeliveryKey - contains the ID of the service plan group
   *          delivery.
   * @return SPGDeliveryNoteDetailsList - List of the service plan group
   *         delivery note details.
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public SPGDeliveryNoteDetailsList1 listNotesByGroupDeliveryID1(
      final SPGDeliveryKey key) throws AppException, InformationalException {

    // Entity instance
    final SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory
        .newInstance();

    // Return struct
    final SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList = new SPGDeliveryNoteDetailsList1();

    SPGDeliveryNoteDetails1 spgDeliveryNoteDetails;

    // Fetch the list of notes from service plan group delivery id
    final NoteDtlsList noteDtlsList = spgDeliveryNoteLinkObj
        .searchNotesBySPGDeliveryID1(key);

    NoteDtls noteDtls;

    final NoteIdKey noteIdKey = new NoteIdKey();

    SPGDeliveryNoteLinkDtls spgDeliveryNoteLinkDtls;

    final int sizeOfNoteList = noteDtlsList.dtls.size();

    // Iterate through each note fetch the link details
    // and add to the return struct
    for (int noteListIter = 0; noteListIter < sizeOfNoteList; noteListIter++) {

      noteDtls = noteDtlsList.dtls.item(noteListIter);
      spgDeliveryNoteDetails = new SPGDeliveryNoteDetails1();
      spgDeliveryNoteDetails.noteDtls.assign(noteDtls);
      noteIdKey.noteId = noteDtls.noteID;
      spgDeliveryNoteLinkDtls = spgDeliveryNoteLinkObj.readByNoteId(noteIdKey);
      spgDeliveryNoteDetails.spgDeliveryNoteLink
          .assign(spgDeliveryNoteLinkDtls);
      spgDeliveryNoteDetails.noteDtls.assign(noteDtls);

      // Users variables
      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      // set the user name from the spgDeliveryNoteDetails details.
      usersKey.userName = spgDeliveryNoteDetails.noteDtls.userName;

      // invoke the method getFullName to get the user full name
      // and set that to spgDeliveryNoteDetails details.
      spgDeliveryNoteDetails.fullname = userAccessObj
          .getFullName(usersKey).fullname;

      spgDeliveryNoteDetailsList.dtls.addRef(spgDeliveryNoteDetails);
    }

    final NoteKey noteKey = new NoteKey();
    NoteText noteText = new NoteText();

    // Note Object
    final Note noteObj = NoteFactory.newInstance();

    // Security Variables
    SecurityResult securityResult;

    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
        .get();

    final int sizeOfList = spgDeliveryNoteDetailsList.dtls.size();

    for (int i = 0; i < sizeOfList; i++) {

      spgDeliveryNoteDetails = spgDeliveryNoteDetailsList.dtls.item(i);

      // Check the note sensitivity
      noteKey.noteID = spgDeliveryNoteDetails.noteDtls.noteID;

      securityResult = dataBasedSecurity.checkNoteSecurity(noteKey);

      if (securityResult.result) {

        // Assign the details.
        noteText.notesText = spgDeliveryNoteDetails.noteDtls.notesText;

        // BEGIN, CR00142625
        final LastNoteDetails lastNoteDetails = noteObj
            .getLastNoteText1(noteText);

        // END, CR00142625

        noteText.notesText = lastNoteDetails.content;

        spgDeliveryNoteDetails.modifiedDateTime = lastNoteDetails.dateTime;

        // Truncate the note
        noteText = noteObj.truncate(noteText);

        spgDeliveryNoteDetails.truncatedNoteText = noteText.notesText;

        spgDeliveryNoteDetails.noteDtls.notesText = noteText.notesText;

        // get details about whether a note can be edited
        final NoteUtil noteUtil = new NoteUtil();
        final NoteStatus noteEditStatus = noteUtil.determineNoteEditStatus(
            spgDeliveryNoteDetails.noteDtls.userName,
            spgDeliveryNoteDetails.noteDtls.latestNoteCreationDateTime,
            NoteType.NOTE);
        spgDeliveryNoteDetails.latestNoteTextEditStatusOpt = noteEditStatus
            .toString();

      } else {

        // Return no details to client if User does not have access
        spgDeliveryNoteDetails.noteDtls.priorityCode = CuramConst.gkEmpty;
        spgDeliveryNoteDetails.noteDtls.sensitivityCode = CuramConst.gkEmpty;
        spgDeliveryNoteDetails.noteDtls.creationDateTime = DateTime.kZeroDateTime;
        spgDeliveryNoteDetails.noteDtls.notesText = CuramConst.gkRestricted;

        /*
         * If the user does not have access due to sensitivity, setting the edit
         * status to the default 'appendable' - because they should not see
         * details about if a note is editable or locked by another user. Having
         * the default value ultimately means no info, messages or icons will be
         * displayed, as this is also the default behaviour.
         */
        spgDeliveryNoteDetails.latestNoteTextEditStatusOpt = NoteStatus.APPENDABLE
            .toString();
      }
    }

    return spgDeliveryNoteDetailsList;
  }

  // END, CR00240923

  // ____________________________________________________________________________
  /**
   * This method is used to modify the notes for service plan group delivery.
   *
   * @param noteDetails
   *          SPGDeliveryNoteDetails - Service plan group delivery note which
   *          needs to be modified
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public void modifyNote(final SPGDeliveryNoteDetails noteDetails)
      throws AppException, InformationalException {

    // validation to check if the record is already canceled and in this case,
    // the record cannot be modified and so error is thrown
    if (noteDetails.spgDeliveryNoteLink.status.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(
                  GENERAL.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              81);
    }

    final NoteKey noteKey = new NoteKey();

    noteKey.noteID = noteDetails.noteDtls.noteID;

    final ModifyNoteDetails1 modifyNoteDetails = new ModifyNoteDetails1();

    modifyNoteDetails.assign(noteDetails.noteDtls);

    if (modifyNoteDetails.notesText.trim().length() > 0) {

      final StringBuffer noteText = new StringBuffer();

      /*
       * There are 2 scenarios for modifying a note - one scenario is editing
       * the latest note text only, the other scenario is appending a new entry
       * onto the existing note txt.
       *
       * If only editing the latest note text, we want to keep the pre-pended
       * string that was originally added when the note or addendum was added.
       * So we need to read the record to see what this was, before modifying
       * anything.
       */
      if (noteDetails.editLatestNoteTextIndOpt) {

        final Note noteObj = NoteFactory.newInstance();
        final NoteText originalNoteText = noteObj.readNotesText(noteKey);

        final String originalNoteDetails = noteObj
            .getLastNoteText1(originalNoteText).content;

        if (!StringUtil.isNullOrEmpty(originalNoteDetails)
            && originalNoteDetails
                .startsWith(ServicePlanConst.kNoteCreationSystemDetails)) {
          noteText.append(ServicePlanConst.kNoteCreationSystemDetails);
        } else {
          noteText.append(ServicePlanConst.kNoteModificationSystemDetails);
        }

      } else {
        noteText.append(ServicePlanConst.kNoteModificationSystemDetails);
      }

      noteText.append(modifyNoteDetails.notesText);
      modifyNoteDetails.notesText = noteText.toString();
    }

    final NoteUtil noteUtil = new NoteUtil();
    noteUtil.modifyNote(noteKey, modifyNoteDetails, NoteType.NOTE,
        noteDetails.editLatestNoteTextIndOpt);

  }

  // ____________________________________________________________________________
  /**
   * This method is used to remove the notes for service plan group delivery.
   *
   * @param noteDetails
   *          SPGDeliveryNoteDetails - The record which is to be removed.
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public void removeNote(final SPGDeliveryNoteDetails noteDetails)
      throws AppException, InformationalException {

    // Entity layer link object
    final SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory
        .newInstance();

    final SPGDeliveryNoteLinkKey spgDeliveryNoteLinkKey = new SPGDeliveryNoteLinkKey();

    spgDeliveryNoteLinkKey.spgDeliveryNoteLinkId = noteDetails.spgDeliveryNoteLink.spgDeliveryNoteLinkId;

    final SPGDeliveryNoteLinkDtls deliveryNoteLinkDtls = new SPGDeliveryNoteLinkDtls();

    final NoteIdKey noteIdKey = new NoteIdKey();

    noteIdKey.noteId = noteDetails.noteDtls.noteID;

    deliveryNoteLinkDtls
        .assign(spgDeliveryNoteLinkObj.read(spgDeliveryNoteLinkKey));

    if (deliveryNoteLinkDtls.status.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(GENERAL.ERR_GENERAL_FV_RECORD_ALREADY_CANCELLED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              74);
    }

    final SPGDeliveryNoteLinkStatusDtls spgDeliveryNoteLinkStatusDtls = new SPGDeliveryNoteLinkStatusDtls();

    spgDeliveryNoteLinkStatusDtls.status = RECORDSTATUS.CANCELLED;

    // Cancel the record.
    spgDeliveryNoteLinkObj.cancelLink(spgDeliveryNoteLinkKey,
        spgDeliveryNoteLinkStatusDtls);
  }

  // ____________________________________________________________________________
  /**
   * This method is used to view the notes for service plan group delivery.
   *
   * @param key
   *          SPGDeliveryNoteLinkKey - The key for the record which is to be
   *          read.
   * @return SPGDeliveryNoteDetails - The returned record details for viewing.
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public SPGDeliveryNoteDetails viewNote(final SPGDeliveryNoteLinkKey linkKey)
      throws AppException, InformationalException {

    // Return struct
    final SPGDeliveryNoteDetails spgDeliveryNoteDetails = new SPGDeliveryNoteDetails();

    final SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory
        .newInstance();

    final SPGDeliveryNoteLinkDtls spgDeliveryNoteLinkDtls = spgDeliveryNoteLinkObj
        .read(linkKey);

    final NoteIdKey nodeIDKey = new NoteIdKey();

    nodeIDKey.noteId = spgDeliveryNoteLinkDtls.noteId;

    final NoteDtls noteDtls = spgDeliveryNoteLinkObj
        .readNoteDetailsByLinkID1(nodeIDKey);

    // Set the return struct
    spgDeliveryNoteDetails.noteDtls.assign(noteDtls);
    spgDeliveryNoteDetails.spgDeliveryNoteLink.assign(spgDeliveryNoteLinkDtls);

    // Check security on retrieved details.
    checkSecurityForRead(spgDeliveryNoteDetails);

    // Users variables
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // set the user name from the opinion details.
    usersKey.userName = spgDeliveryNoteDetails.noteDtls.userName;

    // invoke the method getFullName to get the user full name
    // and set that to spgDeliveryNoteDetails
    spgDeliveryNoteDetails.fullname = userAccessObj
        .getFullName(usersKey).fullname;

    // get details about whether or not a note can be edited
    final NoteUtil noteUtil = new NoteUtil();
    final NoteEditDetails noteEditDetails = noteUtil.getNoteEditDetails(
        spgDeliveryNoteDetails.noteDtls.userName,
        spgDeliveryNoteDetails.noteDtls.latestNoteCreationDateTime,
        spgDeliveryNoteDetails.noteDtls.notesText);

    spgDeliveryNoteDetails.noteEditDetails.assign(noteEditDetails);

    /*
     * Functionality specific to SPGDeliveryNote has pre-pended a string onto
     * the latest note content, with some system-added details. This string
     * differs depending on if it is the original entry or an appended entry.
     *
     * This additional string needs to be removed, so the user will only be
     * presented with the actual note text, if they are going to edit it.
     */
    final String latestNoteText = spgDeliveryNoteDetails.noteEditDetails.latestNoteTextForEdit;
    if (!StringUtil.isNullOrEmpty(latestNoteText)) {

      String updateNoteTextWithoutSystemDtls = "";

      if (latestNoteText
          .startsWith(ServicePlanConst.kNoteCreationSystemDetails)) {
        updateNoteTextWithoutSystemDtls = latestNoteText.replaceAll(
            ServicePlanConst.kNoteCreationSystemDetails, CuramConst.gkEmpty);
      }

      if (latestNoteText
          .startsWith(ServicePlanConst.kNoteModificationSystemDetails)) {
        updateNoteTextWithoutSystemDtls = latestNoteText.replaceAll(
            ServicePlanConst.kNoteModificationSystemDetails,
            CuramConst.gkEmpty);
      }

      spgDeliveryNoteDetails.noteEditDetails.latestNoteTextForEdit = updateNoteTextWithoutSystemDtls;

    }

    return spgDeliveryNoteDetails;
  }

  // ____________________________________________________________________________
  /**
   * This method is used to check the read security on notes for a service plan
   * group delivery.
   *
   * @param key
   *          SPGDeliveryNoteDetails - The record which is to be checked.
   * @throws AppException,
   *           InformationalException
   */
  protected void checkSecurityForRead(final SPGDeliveryNoteDetails details)
      throws AppException, InformationalException {

    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
        .get();

    final NoteKey noteKey = new NoteKey();

    noteKey.noteID = details.noteDtls.noteID;

    // Check the note sensitivity
    final SecurityResult securityResult = dataBasedSecurity
        .checkNoteSecurity(noteKey);

    if (securityResult.result == false) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(BPOSPGNOTES.ERR_SPGNOTE_SL_FV_SENSITIVITY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }
  }
}
