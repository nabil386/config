/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.struct.Priority;
import curam.core.sl.struct.PriorityDetails;
import curam.core.sl.struct.PriorityPosition;
import curam.message.BPOAPPROVALCRITERIA;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.ApprovalCriteriaFactory;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaDescriptionTextID;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaDtls;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaKey;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaPriorityDetails;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaPriorityDetailsList;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaPrioritySearchDetails;
import curam.serviceplans.sl.fact.PriorityHelperFactory;
import curam.serviceplans.sl.intf.PriorityHelper;
import curam.serviceplans.sl.struct.ApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.ApprovalCriteriaDetailsList;
import curam.serviceplans.sl.struct.ApprovalCriteriaID;
import curam.serviceplans.sl.struct.CancelApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.OrderPriorityDetails;
import curam.serviceplans.sl.struct.PriorityDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * Implementation for ApprovalCriteria service layer.
 */
public class ApprovalCriteria extends curam.serviceplans.sl.base.ApprovalCriteria {

  // BEGIN, CR00227878, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public ApprovalCriteria() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00227878

  /**
   * Cancel the ApprovalCriteria entry
   *
   * @param details Details used to cancel an approval criteria,
   * contains ID andversionNo.
   * @throws AppException, InformationalException
   */
  @Override
  public void cancelApprovalCriteria(CancelApprovalCriteriaDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria appCriteriaObj = curam.serviceplans.sl.entity.fact.ApprovalCriteriaFactory.newInstance();

    final ApprovalCriteriaKey key = new ApprovalCriteriaKey();
    final curam.serviceplans.sl.entity.struct.CancelApprovalCriteriaDetails cancelDtls = new curam.serviceplans.sl.entity.struct.CancelApprovalCriteriaDetails();

    key.approvalCriteriaID = details.approvalCriteriaID;
    cancelDtls.versionNo = details.versionNo;
    cancelDtls.recordStatus = RECORDSTATUS.CANCELLED;
    appCriteriaObj.cancel(key, cancelDtls);
  }

  /**
   * Create a new ApprovalCriteria entry
   *
   * @param details ApprovalCriteria details
   * @throws AppException, InformationalException
   */
  @Override
  public void createApprovalCriteria(ApprovalCriteriaDetails details)
    throws AppException, InformationalException {

    // Carry out validation and re-ordering of existing entries
    callPriorityHelper(details);

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalObj = ApprovalCriteriaFactory.newInstance();

    // Must set this so that records turn up in the list page.
    details.dtls.recordStatus = RECORDSTATUS.NORMAL;
    details.dtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // BEGIN, CR00227878, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!details.dtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      details.dtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      details.dtls.descriptionTextID = localizableTextHandler.store();
    }

    details.dtls.description = null;
    // END, CR00227878
    approvalObj.insert(details.dtls);
  }

  /**
   * List all approval criteria, both active and
   * cancelled entries are returned.
   *
   * @returns List of approval criteria details
   * @throws AppException, InformationalException
   */
  @Override
  public ApprovalCriteriaDetailsList listApprovalCriteria()
    throws AppException, InformationalException {

    final ApprovalCriteriaDetailsList dtlsList = new ApprovalCriteriaDetailsList();

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalObj = ApprovalCriteriaFactory.newInstance();

    dtlsList.approvalCriteriaList.assign(approvalObj.readAll());

    return dtlsList;
  }

  /**
   * Modify ApprovalCriteria entry.
   *
   * @param details Contains the details of the record to modify
   * @throws AppException, InformationalException
   */
  @Override
  public void modifyApprovalCriteria(ApprovalCriteriaDetails details)
    throws AppException, InformationalException {

    // Carry out validation and re-ordering of existing entries
    callPriorityHelper(details);

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalObj = ApprovalCriteriaFactory.newInstance();

    final ApprovalCriteriaKey key = new ApprovalCriteriaKey();

    key.approvalCriteriaID = details.dtls.approvalCriteriaID;
    // BEGIN, CR00227878, GP
    long descriptionTextID;

    // Modify Localized description.
    if (0 == details.dtls.descriptionTextID) {

      if (!details.dtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.dtls.description,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }

      // BEGIN, CR00229116, GP
      // Update the struct passed to modify().
      details.dtls.descriptionTextID = descriptionTextID;
      // END, CR00229116

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.descriptionTextID);

      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }

    details.dtls.description = null;
    // END, CR00227878

    approvalObj.modify(key, details.dtls);
  }

  /**
   * Read ApprovalCriteria entry
   *
   * @returns Details for ApprovalCriteria record
   * @param id Contains the unique ID of the approval criteria record to read
   * @throws AppException, InformationalException
   */
  @Override
  public ApprovalCriteriaDetails readApprovalCriteria(ApprovalCriteriaID id)
    throws AppException, InformationalException {

    final ApprovalCriteriaDetails details = new ApprovalCriteriaDetails();

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalObj = ApprovalCriteriaFactory.newInstance();

    final ApprovalCriteriaKey key = new ApprovalCriteriaKey();

    key.assign(id);

    // Read the details
    details.dtls = approvalObj.read(key);

    // BEGIN, CR00227878, GP
    // Read the localized description.
    if (0 != details.dtls.descriptionTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        details.dtls.descriptionTextID);

      details.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00227878

    if (details.dtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      // Display only priority
      details.priorityPosition.priorityPosition = Integer.toString(
        details.dtls.priority);
    } else {
      // Display the priority as x(y of z)
      details.priorityPosition = getPriorityPosition(details.dtls);
    }

    return details;
  }

  /**
   * Helper method to carry out the validation and reordering of the priority
   * values if need be.
   *
   * @param details
   * @throws AppException, InformationalException
   */
  protected void callPriorityHelper(ApprovalCriteriaDetails details)
    throws AppException, InformationalException {

    final PriorityHelper priorityHelper = PriorityHelperFactory.newInstance();

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalObj = ApprovalCriteriaFactory.newInstance();

    final PriorityDetails priorityDetails = new PriorityDetails();

    priorityDetails.applyNextPriorityInd = details.assignNextPriority;
    priorityDetails.priority = details.dtls.priority;

    // Validate the options provided
    priorityHelper.validatePriority(priorityDetails);

    final ApprovalCriteriaPrioritySearchDetails searchDetails = new ApprovalCriteriaPrioritySearchDetails();

    ApprovalCriteriaPriorityDetailsList appCritPriDtlsList = null;

    final ApprovalCriteriaPriorityDetails appCritPriDtls = new ApprovalCriteriaPriorityDetails();

    final ApprovalCriteriaKey appCritKey = new ApprovalCriteriaKey();

    final PriorityDetailsList existingPriorities = new PriorityDetailsList();
    PriorityDetailsList reorderedPriorities = null;

    // Get the list of existing priorities
    searchDetails.recordStatus = RECORDSTATUS.NORMAL;
    searchDetails.occursWhen = details.dtls.occursWhen;

    appCritPriDtlsList = approvalObj.searchPriorityDetailsByOccursWhen(
      searchDetails);

    existingPriorities.assign(appCritPriDtlsList);

    // If we need to assign the next priority then update the details struct
    if (details.assignNextPriority) {

      // Create details for the existing entry
      final OrderPriorityDetails currentDetails = new OrderPriorityDetails();

      currentDetails.priority = details.dtls.priority;
      currentDetails.recordKeyID = details.dtls.approvalCriteriaID;
      currentDetails.versionNo = details.dtls.versionNo;

      // Given the current list of priority details, get the next one
      final Priority priority = priorityHelper.getNextPriority(
        existingPriorities, currentDetails);

      // Update the details struct so that when we return the new value will be
      // written to the database
      details.dtls.priority = priority.dtls.priority;

    } else {
      final OrderPriorityDetails orderDetails = new OrderPriorityDetails();

      orderDetails.priority = details.dtls.priority;
      orderDetails.recordKeyID = details.dtls.approvalCriteriaID;
      orderDetails.versionNo = details.dtls.versionNo;

      reorderedPriorities = priorityHelper.reorderPriority(orderDetails,
        existingPriorities);

      for (int i = 0; i < reorderedPriorities.dtls.size(); i++) {
        appCritPriDtls.assign(reorderedPriorities.dtls.item(i));
        appCritPriDtls.versionNo = reorderedPriorities.dtls.item(i).versionNo;

        appCritKey.approvalCriteriaID = appCritPriDtls.approvalCriteriaID;

        // Update this entry to modify the priority
        approvalObj.modifyPriority(appCritKey, appCritPriDtls);
      }

    }
  }

  /**
   * Helper method to generate the priority position details.
   *
   * @param dtls ApprovalCriteria details
   * @throws AppException, InformationalException
   */
  protected PriorityPosition getPriorityPosition(ApprovalCriteriaDtls dtls)
    throws AppException, InformationalException {

    PriorityPosition result = new PriorityPosition();

    final PriorityHelper priorityHelper = PriorityHelperFactory.newInstance();

    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalObj = ApprovalCriteriaFactory.newInstance();

    final ApprovalCriteriaPrioritySearchDetails searchDetails = new ApprovalCriteriaPrioritySearchDetails();
    ApprovalCriteriaPriorityDetailsList appCritPriDtlsList = null;

    final PriorityDetailsList existingPriorities = new PriorityDetailsList();

    // Get the list of existing priorities
    searchDetails.recordStatus = RECORDSTATUS.NORMAL;
    searchDetails.occursWhen = dtls.occursWhen;

    appCritPriDtlsList = approvalObj.searchPriorityDetailsByOccursWhen(
      searchDetails);

    existingPriorities.assign(appCritPriDtlsList);

    final OrderPriorityDetails currentDetails = new OrderPriorityDetails();

    currentDetails.priority = dtls.priority;
    currentDetails.recordKeyID = dtls.approvalCriteriaID;
    currentDetails.versionNo = dtls.versionNo;

    result = priorityHelper.getPriorityPosition(existingPriorities,
      currentDetails);

    return result;
  }

  // BEGIN, CR00227878, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          21);
      }
    }
  }

  /**
   * Creates a text translation for the Approval criteria attribute,
   * description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Approval
   * criteria attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be translated is
   * empty. {@link GENERAL#ERR_LOCALE_EMPTY} - if locale is empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalCriteriaObj = curam.serviceplans.sl.entity.fact.ApprovalCriteriaFactory.newInstance();
    final ApprovalCriteriaKey approvalCriteriaKey = new ApprovalCriteriaKey();

    final ApprovalCriteriaDescriptionTextID appprovalCriteriaDescriptionTextID = new ApprovalCriteriaDescriptionTextID();
    ApprovalCriteriaDtls approvalCriteriaDtls = new ApprovalCriteriaDtls();

    approvalCriteriaKey.approvalCriteriaID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 31);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 14);
    }

    approvalCriteriaDtls = approvalCriteriaObj.read(approvalCriteriaKey);

    if (!approvalCriteriaDtls.recordStatus.equals(RECORDSTATUS.NORMAL)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_MODIFY_CANCELLED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // Handling legacy Data.

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == approvalCriteriaDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          22);

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = approvalCriteriaDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      appprovalCriteriaDescriptionTextID.descriptionTextID = textID;
      appprovalCriteriaDescriptionTextID.versionNo = approvalCriteriaDtls.versionNo;
      approvalCriteriaObj.modifyDescriptionTextID(approvalCriteriaKey,
        appprovalCriteriaDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != approvalCriteriaDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        approvalCriteriaDtls.descriptionTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();

    }
  }

  /**
   * Modifies the text translation details for the ApprovalCriteria attribute,
   * description.
   *
   * @param localizableTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of ApprovalCriteria
   * attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link BPOAPPROVALCRITERIA#ERR_DETAILS_MODIFY_CANCELLED_RECORD
   * - if the Approval Criteria to be modified is already deleted.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.ApprovalCriteria approvalCriteriaObj = curam.serviceplans.sl.entity.fact.ApprovalCriteriaFactory.newInstance();
    final ApprovalCriteriaKey approvalCriteriaKey = new ApprovalCriteriaKey();

    final ApprovalCriteriaDescriptionTextID approvalCriteriaDescriptionTextID = new ApprovalCriteriaDescriptionTextID();
    ApprovalCriteriaDtls approvalCriteriaDtls = new ApprovalCriteriaDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 30);
    }

    approvalCriteriaKey.approvalCriteriaID = localizableTextTranslationDetails.localizableTextParentID;

    approvalCriteriaDtls = approvalCriteriaObj.read(approvalCriteriaKey);

    // Record must not be already canceled.
    if (!approvalCriteriaDtls.recordStatus.equals(RECORDSTATUS.NORMAL)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_MODIFY_CANCELLED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == approvalCriteriaDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      approvalCriteriaDescriptionTextID.descriptionTextID = textID;
      approvalCriteriaDescriptionTextID.versionNo = approvalCriteriaDtls.versionNo;
      approvalCriteriaObj.modifyDescriptionTextID(approvalCriteriaKey,
        approvalCriteriaDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != approvalCriteriaDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        approvalCriteriaDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00227878
}
