/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004, 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.CancelContractTextDetails;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.message.BPOGOAL;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.struct.GoalContractTextDtls;
import curam.serviceplans.sl.entity.struct.GoalCountDetails;
import curam.serviceplans.sl.entity.struct.GoalDescriptionTextID;
import curam.serviceplans.sl.entity.struct.GoalDtls;
import curam.serviceplans.sl.entity.struct.GoalIDContractTextIDKey;
import curam.serviceplans.sl.entity.struct.GoalStatusDetails;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedOutcomesForGoalKey;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedSubGoalsForGoalKey;
import curam.serviceplans.sl.struct.CancelGoalDetails;
import curam.serviceplans.sl.struct.ContractTextDetails;
import curam.serviceplans.sl.struct.ContractTextKey;
import curam.serviceplans.sl.struct.CreateGoalContractTextDetails;
import curam.serviceplans.sl.struct.CreateGoalDetails;
import curam.serviceplans.sl.struct.CreateGoalOutcomeDetails;
import curam.serviceplans.sl.struct.CreateGoalSubGoalDetails;
import curam.serviceplans.sl.struct.ExistingOutcomesDetails;
import curam.serviceplans.sl.struct.ExistingSubGoalsDetails;
import curam.serviceplans.sl.struct.GoalContractTextList;
import curam.serviceplans.sl.struct.GoalKey;
import curam.serviceplans.sl.struct.GoalList;
import curam.serviceplans.sl.struct.GoalNameAndIDDetailsList;
import curam.serviceplans.sl.struct.GoalNameDetails;
import curam.serviceplans.sl.struct.GoalOutcomeKey;
import curam.serviceplans.sl.struct.GoalOutcomeList;
import curam.serviceplans.sl.struct.GoalSubGoalKey;
import curam.serviceplans.sl.struct.GoalSubGoalList;
import curam.serviceplans.sl.struct.ModifyGoalContractTextDetails;
import curam.serviceplans.sl.struct.ModifyGoalDetails;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.ReadGoalDetails;
import curam.serviceplans.sl.struct.RemoveGoalContractTextDetails;
import curam.serviceplans.sl.struct.SubGoalKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * This process class provides the functionality for the Goal
 * service layer.
 */
public abstract class Goal extends curam.serviceplans.sl.base.Goal {

  // BEGIN, CR00228110, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public Goal() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00228110
  // ___________________________________________________________________________
  /**
   * Creates a goal.
   *
   * @param details The details of the Goal to be created
   * @return Unique identifier of the created goal
   */
  @Override
  public GoalKey create(CreateGoalDetails details) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final GoalDtls goalDtls = new GoalDtls();

    // to be returned
    final GoalKey goalKey = new GoalKey();

    // assign creation details
    goalDtls.assign(details);

    // set creation date
    goalDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // set record status
    goalDtls.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00228110, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!goalDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(goalDtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      goalDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      goalDtls.descriptionTextID = localizableTextHandler.store();
    }

    goalDtls.description = null;
    // END, CR00228110

    // create goal
    goalObj.insert(goalDtls);

    // set goal identifier to be returned
    goalKey.goalKey.goalID = goalDtls.goalID;

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATEGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = goalDtls.goalID;
    curam.util.events.impl.EventService.raiseEvent(event);

    return goalKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies goal details.
   *
   * @param details The details of the Goal to be modified.
   * @throws AppException
   * {@link BPOGOAL#ERR_GOAL_FV_CANCELED_NO_MODIFY
   * ERR_GOAL_FV_CANCELED_NO_MODIFY} - if the goal to be modified is
   * already canceled.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modify(ModifyGoalDetails details) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalKey goalKey = new curam.serviceplans.sl.entity.struct.GoalKey();

    // Set goal key
    goalKey.goalID = details.goalDtls.goalID;

    // BEGIN, CR00228110, GP

    // Check if Goal is already canceled.
    // Read record status
    final GoalStatusDetails goalStatusDetails = goalObj.readStatus(goalKey);

    if (goalStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Modify localized description.
    long descriptionTextID;

    // Modify Localized description.
    if (0 == details.goalDtls.descriptionTextID) {

      if (!details.goalDtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.goalDtls.description,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      details.goalDtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.goalDtls.descriptionTextID);

      localizableTextHandler.addValue(details.goalDtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }

    details.goalDtls.description = null;
    // END, CR00228110

    // modify goal
    goalObj.modify(goalKey, details.goalDtls);

    // Service plans workflow raise event integration
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.MODIFYGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = details.goalDtls.goalID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Cancels goal details.
   *
   * @param details The details of the Goal to be canceled
   */
  @Override
  public void cancel(CancelGoalDetails details) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalKey goalKey = new curam.serviceplans.sl.entity.struct.GoalKey();
    final curam.serviceplans.sl.entity.struct.GoalCancelDetails goalCancelDetails = new curam.serviceplans.sl.entity.struct.GoalCancelDetails();

    // Set goal key and version number
    goalKey.goalID = details.goalID;
    goalCancelDetails.versionNo = details.versionNo;

    // Set record status to CANCELLED
    goalCancelDetails.recordStatus = RECORDSTATUS.CANCELLED;

    // Cancel the goal
    goalObj.cancel(goalKey, goalCancelDetails);

  }

  // ___________________________________________________________________________
  /**
   * Reads goal details.
   *
   * @param key The Goal unique identifier
   * @return Goal details
   */
  @Override
  public ReadGoalDetails read(GoalKey key) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    // Return value
    final ReadGoalDetails readGoalDetails = new ReadGoalDetails();

    // Read goal details
    readGoalDetails.goalDtls = goalObj.read(key.goalKey);

    // BEGIN, CR00228110, GP
    // Read the localized description.
    if (0 != readGoalDetails.goalDtls.descriptionTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readGoalDetails.goalDtls.descriptionTextID);

      readGoalDetails.goalDtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00228110

    // Return goal details
    return readGoalDetails;

  }

  // ___________________________________________________________________________
  /**
   * Lists all existing goals.
   *
   * @return Goal details
   */
  @Override
  public GoalList list() throws AppException, InformationalException {

    // return object
    final GoalList goalList = new GoalList();

    // read the list of goals
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    goalList.dtls = goalObj.readAll();

    // return the list
    return goalList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals assigned to a goal.
   *
   * @param key The Goal unique identifier
   * @return List of goal sub goals
   */
  @Override
  public GoalSubGoalList listSubGoal(GoalKey key) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    // Return value
    final GoalSubGoalList goalSubGoalList = new GoalSubGoalList();

    // Search for goal's sub goals
    goalSubGoalList.goalSubGoalDetailsList = goalObj.searchSubGoal(key.goalKey);

    // Return a list of sub goals for the goal
    return goalSubGoalList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all active sub goals that are not associated to a goal.
   *
   * @param key The Goal unique identifier
   * @return List of sub goals not associated with the goal
   */
  @Override
  public GoalSubGoalList listUnassociatedSubGoals(GoalKey key)
    throws AppException, InformationalException {

    // return object
    final curam.serviceplans.sl.struct.GoalSubGoalList goalSubGoalList = new curam.serviceplans.sl.struct.GoalSubGoalList();

    // populate the read key to search for active sub goals not associated
    // with the goal
    final SearchUnassociatedSubGoalsForGoalKey searchUnassociatedSubGoalsForGoalKey = new SearchUnassociatedSubGoalsForGoalKey();

    searchUnassociatedSubGoalsForGoalKey.goalID = key.goalKey.goalID;
    searchUnassociatedSubGoalsForGoalKey.subGoalRecordStatus = RECORDSTATUS.NORMAL;

    // read list of unassociated sub goals
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    goalSubGoalList.goalSubGoalDetailsList = goalObj.searchUnassociatedSubGoalsByStatus(
      searchUnassociatedSubGoalsForGoalKey);

    // return the list
    return goalSubGoalList;

  }

  // ___________________________________________________________________________
  /**
   * Removes sub goal from a goal.
   *
   * @param key The Goal and Sub Goal unique identifiers
   */
  @Override
  public void removeSubGoal(GoalSubGoalKey key) throws AppException,
      InformationalException {

    // GoalSubGoalLink entity
    final curam.serviceplans.sl.entity.intf.GoalSubGoalLink goalSubGoalLinkObj = curam.serviceplans.sl.entity.fact.GoalSubGoalLinkFactory.newInstance();

    // Key for templates counting
    final curam.serviceplans.sl.entity.struct.GoalSubGoalAndStatusKey goalSubGoalAndStatusKey = new curam.serviceplans.sl.entity.struct.GoalSubGoalAndStatusKey();

    // Plan Template entity
    final curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    goalSubGoalAndStatusKey.assign(key.goalSubGoalKey);
    goalSubGoalAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // there must not be a plan template sub goal based on this sub goal that
    // is assigned to the plan template created for this goal
    if (planTemplateObj.countByGoalAndSubGoal(goalSubGoalAndStatusKey).count
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOGOAL.ERR_GOAL_XRV_PLANTEMPLATESUBGOAL_ASSIGNED_TO_PLANTEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // remove goal sub goal link
    goalSubGoalLinkObj.removeByGoalIDAndSubGoalID(key.goalSubGoalKey);

  }

  // ___________________________________________________________________________
  /**
   * Assigns to goal existing sub goals from the list.
   *
   * @param details List of the existing sub goals to be added to the goal
   */
  @Override
  public void addExistingSubGoals(ExistingSubGoalsDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.struct.GoalSubGoalKey goalSubGoalKey = new curam.serviceplans.sl.struct.GoalSubGoalKey();

    // GoalSubGoalLink manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalSubGoalLink goalSubGoalLinkObj = curam.serviceplans.sl.entity.fact.GoalSubGoalLinkFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalSubGoalLinkDtls goalSubGoalLinkDtls = new curam.serviceplans.sl.entity.struct.GoalSubGoalLinkDtls();

    // set validation key
    goalSubGoalKey.goalSubGoalKey.goalID = details.goalKey.goalKey.goalID;

    for (int i = 0; i < details.subGoalKeyList.subGoalKey.size(); i++) {

      // set sub goal ID
      goalSubGoalKey.goalSubGoalKey.subGoalID = details.subGoalKeyList.subGoalKey.item(i).subGoalKey.subGoalID;

      // validate sub goal creation
      validateAddSubGoal(goalSubGoalKey);

      // set GoalSubGoalLink details for insert
      goalSubGoalLinkDtls.goalID = details.goalKey.goalKey.goalID;
      goalSubGoalLinkDtls.subGoalID = details.subGoalKeyList.subGoalKey.item(i).subGoalKey.subGoalID;

      // insert goal sub goal link
      goalSubGoalLinkObj.insert(goalSubGoalLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Assigns to goal existing outcomes from the list.
   *
   * @param details List of the existing outcomes to be added to the goal
   */
  @Override
  public void addExistingOutcomes(ExistingOutcomesDetails details)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.struct.GoalOutcomeKey goalOutcomeKey = new curam.serviceplans.sl.struct.GoalOutcomeKey();

    // GoalOutcomeLink manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalOutcomeLink goalOutcomeLinkObj = curam.serviceplans.sl.entity.fact.GoalOutcomeLinkFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalOutcomeLinkDtls goalOutcomeLinkDtls = new curam.serviceplans.sl.entity.struct.GoalOutcomeLinkDtls();

    // set validation key
    goalOutcomeKey.goalOutcomeKey.goalID = details.goalKey.goalKey.goalID;

    for (int i = 0; i < details.outcomeKeyList.outcomeKey.size(); i++) {

      // set sub goal ID
      goalOutcomeKey.goalOutcomeKey.outcomeID = details.outcomeKeyList.outcomeKey.item(i).key.outcomeID;

      // validate outcome creation
      validateAddOutcome(goalOutcomeKey);

      // set GoalOutcomeLink details for insert
      goalOutcomeLinkDtls.goalID = details.goalKey.goalKey.goalID;
      goalOutcomeLinkDtls.outcomeID = details.outcomeKeyList.outcomeKey.item(i).key.outcomeID;

      // insert goal outcome link
      goalOutcomeLinkObj.insert(goalOutcomeLinkDtls);
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a sub goal and assigns it to a goal.
   *
   * @param details Sub Goal details
   * @return Unique identifier of the sub goal created
   */
  @Override
  public SubGoalKey createSubGoal(CreateGoalSubGoalDetails details)
    throws AppException, InformationalException {

    // SubGoal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.SubGoalDtls subGoalDtls = new curam.serviceplans.sl.entity.struct.SubGoalDtls();

    // GoalSubGoalLink manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalSubGoalLink goalSubGoalLinkObj = curam.serviceplans.sl.entity.fact.GoalSubGoalLinkFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalSubGoalLinkDtls goalSubGoalLinkDtls = new curam.serviceplans.sl.entity.struct.GoalSubGoalLinkDtls();

    // Return value
    final SubGoalKey subGoalKey = new SubGoalKey();

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    // read goal record status
    final curam.serviceplans.sl.entity.struct.GoalStatusDetails goalStatusDetails = goalObj.readStatus(
      details.goalKey.goalKey);

    // sub goal cannot be created for a cancelled goal
    if (!goalStatusDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {
      throw new AppException(BPOGOAL.ERR_GOAL_FV_CANCELED_NO_MODIFY);
    }

    // set Sub Goal details for insert
    subGoalDtls.dateCreated = curam.util.type.Date.getCurrentDate();
    subGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
    subGoalDtls.assign(details.createSubGoalDetails);

    // BEGIN, CR00228110, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!subGoalDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(subGoalDtls.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      subGoalDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      subGoalDtls.descriptionTextID = localizableTextHandler.store();
    }

    subGoalDtls.description = null;
    // END, CR00228110

    // Insert sub goal
    subGoalObj.insert(subGoalDtls);

    // set return value
    subGoalKey.subGoalKey.subGoalID = subGoalDtls.subGoalID;

    // set GoalSubGoalLink details for insert
    goalSubGoalLinkDtls.goalID = details.goalKey.goalKey.goalID;
    goalSubGoalLinkDtls.subGoalID = subGoalDtls.subGoalID;

    // insert goal sub goal link
    goalSubGoalLinkObj.insert(goalSubGoalLinkDtls);

    // Return unique identifier of the sub goal created
    return subGoalKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates an outcome and assigns it to a goal.
   *
   * @param details Outcome details
   * @return Unique identifier of the outcome created
   */
  @Override
  public OutcomeKey createOutcome(CreateGoalOutcomeDetails details)
    throws AppException, InformationalException {

    // Outcome entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.OutcomeDtls outcomeDtls = new curam.serviceplans.sl.entity.struct.OutcomeDtls();

    // GoalOutcomeLink manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalOutcomeLink goalOutcomeLinkObj = curam.serviceplans.sl.entity.fact.GoalOutcomeLinkFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalOutcomeLinkDtls goalOutcomeLinkDtls = new curam.serviceplans.sl.entity.struct.GoalOutcomeLinkDtls();

    // Return value
    final OutcomeKey outcomeKey = new OutcomeKey();

    // assign the details
    outcomeDtls.name = details.createOutcomeDetails.name;
    outcomeDtls.outcomeReference = details.createOutcomeDetails.outcomeReference;
    outcomeDtls.description = details.createOutcomeDetails.description;

    // set Outcome details for insert
    outcomeDtls.dateCreated = curam.util.type.Date.getCurrentDate();
    outcomeDtls.recordStatus = RECORDSTATUS.NORMAL;

    // Insert outcome
    outcomeObj.insert(outcomeDtls);

    // set return value
    outcomeKey.key.outcomeID = outcomeDtls.outcomeID;

    // set GoalSubGoalLink details for insert
    goalOutcomeLinkDtls.goalID = details.goalKey.goalKey.goalID;
    goalOutcomeLinkDtls.outcomeID = outcomeDtls.outcomeID;

    // insert goal outcome link
    goalOutcomeLinkObj.insert(goalOutcomeLinkDtls);

    // Return unique identifier of the outcome created
    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists outcomes assigned to a goal.
   *
   * @param key Goal unique identifier
   * @return list of outcomes assigned to goal
   */
  @Override
  public GoalOutcomeList listOutcome(GoalKey key) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    // Return value
    final GoalOutcomeList goalOutcomeList = new GoalOutcomeList();

    // Search for goal's outcomes
    goalOutcomeList.goalOutcomeDetailsList = goalObj.searchOutcome(key.goalKey);

    // Return a list of outcomes for the goal
    return goalOutcomeList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all active outcomes that are not associated to a goal.
   *
   * @param key The Goal unique identifier
   * @return List of outcomes not associated with the goal
   */
  @Override
  public GoalOutcomeList listUnassociatedOutcomes(GoalKey key)
    throws AppException, InformationalException {

    // return object
    final curam.serviceplans.sl.struct.GoalOutcomeList goalOutcomeList = new curam.serviceplans.sl.struct.GoalOutcomeList();

    // populate the search key
    final SearchUnassociatedOutcomesForGoalKey searchUnassociatedOutcomesForGoalKey = new SearchUnassociatedOutcomesForGoalKey();

    searchUnassociatedOutcomesForGoalKey.goalID = key.goalKey.goalID;
    searchUnassociatedOutcomesForGoalKey.outcomeRecordStatus = RECORDSTATUS.NORMAL;

    // read list of unassociated outcomes
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    goalOutcomeList.goalOutcomeDetailsList = goalObj.searchUnassociatedOutcomesByStatus(
      searchUnassociatedOutcomesForGoalKey);

    // return the list
    return goalOutcomeList;
  }

  // ___________________________________________________________________________
  /**
   * Removes outcome from a goal.
   *
   * @param key The Goal and Outcome unique identifiers
   */
  @Override
  public void removeOutcome(GoalOutcomeKey key) throws AppException,
      InformationalException {

    // GoalOutcomeLink manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalOutcomeLink goalOutcomeLinkObj = curam.serviceplans.sl.entity.fact.GoalOutcomeLinkFactory.newInstance();

    // remove goal outcome link
    goalOutcomeLinkObj.removeByGoalIDAndOutcomeID(key.goalOutcomeKey);

  }

  // ___________________________________________________________________________
  /**
   * Validates outcome creation for a goal.
   *
   * @param key The Goal and Outcome unique identifiers
   */
  @Override
  public void validateAddOutcome(GoalOutcomeKey key) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.GoalCountDetails goalCountDetails = new curam.serviceplans.sl.entity.struct.GoalCountDetails();

    // Count outcomes
    goalCountDetails = goalObj.countOutcomeByOutcomeID(key.goalOutcomeKey);

    if (goalCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_XFV_OUTCOME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates contract text for a goal.
   *
   * @param details Contract text details
   * @return Unique identifier of the contract text created
   */
  @Override
  public ContractTextKey createContractText(
    CreateGoalContractTextDetails details) throws AppException,
      InformationalException {

    // Contract text entity manipulation variables
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    final ContractTextDtls contractTextDtls = new ContractTextDtls();

    // Goal contract text entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalContractText goalContractTextObj = curam.serviceplans.sl.entity.fact.GoalContractTextFactory.newInstance();
    final GoalContractTextDtls goalContractTextDtls = new GoalContractTextDtls();

    // return value
    final curam.serviceplans.sl.struct.ContractTextKey contractTextKey = new curam.serviceplans.sl.struct.ContractTextKey();

    // validate contract text
    validateAddContractText(details);

    // populate contract text details
    contractTextDtls.contractText = details.createContractTextDetails.contractText;
    contractTextDtls.languageCode = details.createContractTextDetails.languageCode;
    contractTextDtls.recordStatus = RECORDSTATUS.NORMAL;
    // set contract text type to Service Plans
    contractTextDtls.typeCode = curam.codetable.CONTRACTTEXTTYPE.SERVICEPLANS;

    // create contract text
    contractTextObj.insert(contractTextDtls);

    // set contract text ID to be returned
    contractTextKey.contractTextKey.contractTextID = contractTextDtls.contractTextID;

    // set goal contract text details
    goalContractTextDtls.contractTextID = contractTextDtls.contractTextID;
    goalContractTextDtls.goalID = details.goalKey.goalKey.goalID;

    // insert goal contract text record
    goalContractTextObj.insert(goalContractTextDtls);

    // return unique ID of the contract text created
    return contractTextKey;
  }

  // ___________________________________________________________________________
  /**
   * Lists contract text details for a goal.
   *
   * @param key The Goal unique identifier
   * @return List of contract text details
   */
  @Override
  public GoalContractTextList listContractText(GoalKey key)
    throws AppException, InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    // Return value
    final GoalContractTextList goalContractTextList = new GoalContractTextList();

    // search contract text for the goal
    goalContractTextList.goalContractTextDetailsList = goalObj.searchContractText(
      key.goalKey);

    // return the list
    return goalContractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies contract text for a goal.
   *
   * @param details Contract text details for modify
   */
  @Override
  public void modifyContractText(ModifyGoalContractTextDetails details)
    throws AppException, InformationalException {

    // ContractText entity manipulation variables
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    final curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();
    final curam.core.sl.entity.struct.ModifyContractTextDetails modifyContractTextDetails = new curam.core.sl.entity.struct.ModifyContractTextDetails();

    // set key for modify
    contractTextKey.contractTextID = details.contractTextID;

    // set details for modify
    modifyContractTextDetails.contractText = details.contractText;
    modifyContractTextDetails.versionNo = details.versionNo;

    // modify contract text
    contractTextObj.modify(contractTextKey, modifyContractTextDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads contract text details for a goal.
   *
   * @param key Goal and contract text unique identifiers
   * @return Contract text details
   */
  @Override
  public ContractTextDetails readContractText(ContractTextKey key)
    throws AppException, InformationalException {

    // ContractText entity manipulation variables (moved to core)
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    // Return value
    final ContractTextDetails contractTextDetails = new ContractTextDetails();

    // read contract text details
    final curam.core.sl.entity.struct.ContractTextDtls contractTextDtls = contractTextObj.read(
      key.contractTextKey);

    // assign the details to return value
    contractTextDetails.assign(contractTextDtls);

    // return contract text details
    return contractTextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Removes contract text for a goal.
   *
   * @param details Goal and contract text unique identifiers
   */
  @Override
  public void removeContractText(RemoveGoalContractTextDetails details)
    throws AppException, InformationalException {

    // GoalContractText entity manipulation variables
    final curam.serviceplans.sl.entity.intf.GoalContractText goalContractTextObj = curam.serviceplans.sl.entity.fact.GoalContractTextFactory.newInstance();
    final GoalIDContractTextIDKey goalIDContractTextIDKey = new GoalIDContractTextIDKey();

    // ContractText entity manipulation variables
    final curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    final curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();
    final CancelContractTextDetails cancelContractTextDetails = new CancelContractTextDetails();

    // set the key for goal contract text removal
    goalIDContractTextIDKey.contractTextID = details.contractTextID;
    goalIDContractTextIDKey.goalID = details.goalID;

    // remove goal contract text
    goalContractTextObj.removeByGoalIDAndContractTextID(goalIDContractTextIDKey);

    // set cancel key and details
    contractTextKey.contractTextID = details.contractTextID;
    cancelContractTextDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelContractTextDetails.versionNo = details.versionNo;

    // cancel contract text
    contractTextObj.cancel(contractTextKey, cancelContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Validates contract text details for a goal.
   *
   * @param details Goal and contract text unique identifiers
   */
  @Override
  public void validateAddContractText(CreateGoalContractTextDetails details)
    throws AppException, InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.CountGoalContractTextKey countGoalContractTextKey = new curam.serviceplans.sl.entity.struct.CountGoalContractTextKey();

    // set goal contract text key
    countGoalContractTextKey.goalID = details.goalKey.goalKey.goalID;
    countGoalContractTextKey.languageCode = details.createContractTextDetails.languageCode;
    countGoalContractTextKey.recordStatus = RECORDSTATUS.NORMAL;

    // check if there is already a contract text in the language specified
    final GoalCountDetails goalCountDetails = goalObj.countByLanguageAndStatus(
      countGoalContractTextKey);

    if (goalCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_XFV_CONTRACTTEXT_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates sub goal creation for a goal.
   *
   * @param key The Goal and Sub Goal unique identifiers
   */
  @Override
  protected void validateAddSubGoal(GoalSubGoalKey key) throws AppException,
      InformationalException {

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.GoalCountDetails goalCountDetails = new curam.serviceplans.sl.entity.struct.GoalCountDetails();

    final curam.serviceplans.sl.entity.struct.GoalKey goalKey = new curam.serviceplans.sl.entity.struct.GoalKey();

    goalKey.goalID = key.goalSubGoalKey.goalID;

    // read goal record status
    final curam.serviceplans.sl.entity.struct.GoalStatusDetails goalStatusDetails = goalObj.readStatus(
      goalKey);

    // sub goal cannot be created for a cancelled goal
    if (!goalStatusDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // Count sub goals
    goalCountDetails = goalObj.countSubGoalBySubGoalID(key.goalSubGoalKey);

    if (goalCountDetails.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_XFV_SUBGOAL_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Lists names and IDs of all existing active goals.
   *
   * @return Goal name and ID details list
   */
  @Override
  public GoalNameAndIDDetailsList listActiveGoals() throws AppException,
      InformationalException {

    // return value
    final GoalNameAndIDDetailsList goalNameAndIDDetailsList = new GoalNameAndIDDetailsList();

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalStatusDetails goalStatusDetails = new curam.serviceplans.sl.entity.struct.GoalStatusDetails();

    // look for active goals
    goalStatusDetails.recordStatus = RECORDSTATUS.NORMAL;

    // list goal details
    goalNameAndIDDetailsList.goalNameAndIDDetailsList = goalObj.listGoalDetailsByStatus(
      goalStatusDetails);

    // return the list
    return goalNameAndIDDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads goal name.
   *
   * @param key Goal unique identifier
   * @return Goal name
   */
  @Override
  public GoalNameDetails readName(GoalKey key) throws AppException,
      InformationalException {

    // return value
    final GoalNameDetails goalNameDetails = new GoalNameDetails();

    // Goal entity manipulation variables
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    // read goal name
    goalNameDetails.goalNameDetails = goalObj.readName(key.goalKey);

    // return goal name
    return goalNameDetails;

  }

  // BEGIN, CR00228110, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        throw e;
      }
    }
  }

  /**
   * Creates a text translation for the Goal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Goal
   * attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty. {@link GENERAL#ERR_LOCALE_EMPTY
   * ERR_LOCALE_EMPTY} - if locale is empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * {@link BPOGOAL#ERR_GOAL_FV_CANCELED_NO_MODIFY
   * ERR_GOAL_FV_CANCELED_NO_MODIFY} - if the
   * goal to be modified is already deleted.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final GoalKey goalKey = new GoalKey();

    final GoalDescriptionTextID goalDescriptionTextID = new GoalDescriptionTextID();
    GoalDtls goalDtls = new GoalDtls();

    goalKey.goalKey.goalID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_LOCALE_EMPTY);
    }

    goalDtls = goalObj.read(goalKey.goalKey);

    // Record must not be already canceled.
    if (goalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(BPOGOAL.ERR_GOAL_FV_CANCELED_NO_MODIFY);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == goalDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !goalDtls.description.equals(CuramConst.gkEmpty)) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        throw e;

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = goalDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      goalDescriptionTextID.descriptionTextID = textID;
      goalDescriptionTextID.versionNo = goalDtls.versionNo;
      goalObj.modifyDescriptionTextID(goalKey.goalKey, goalDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != goalDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        goalDtls.descriptionTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the Goal attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Goal attribute,
   * description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty. {@link BPOGOAL#ERR_GOAL_FV_CANCELED_NO_MODIFY
   * ERR_GOAL_FV_CANCELED_NO_MODIFY- if the goal to be modified is
   * already canceled.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final GoalKey goalKey = new GoalKey();

    final GoalDescriptionTextID goalDescriptionTextID = new GoalDescriptionTextID();
    GoalDtls goalDtls = new GoalDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 32);
    }

    goalKey.goalKey.goalID = localizableTextTranslationDetails.localizableTextParentID;

    goalDtls = goalObj.read(goalKey.goalKey);

    // Record must not be already canceled.
    if (goalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGOAL.ERR_GOAL_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == goalDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      goalDescriptionTextID.descriptionTextID = textID;
      goalDescriptionTextID.versionNo = goalDtls.versionNo;
      goalObj.modifyDescriptionTextID(goalKey.goalKey, goalDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != goalDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        goalDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00228110
}
