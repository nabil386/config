/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.PLANITEMNAMECODE;
import curam.codetable.RECORDSTATUS;
import curam.serviceplans.sl.entity.fact.PlanItemApprovalCheckFactory;
import curam.serviceplans.sl.entity.struct.CancelPlanItemApprovalCheckDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckDtls;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckKey;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCheckUsernameKey;
import curam.serviceplans.sl.struct.CancelPlanItemApprovalCheckKey;
import curam.serviceplans.sl.struct.PlanItemApprovalCheckDetails;
import curam.serviceplans.sl.struct.PlanItemApprovalCheckDetailsList;
import curam.serviceplans.sl.struct.PlanItemApprovalCheckID;
import curam.serviceplans.sl.struct.PlanItemApprovalCheckUsernameID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class to implement the plan item approval check facade functionality.
 */
public class PlanItemApprovalCheck extends curam.serviceplans.sl.base.PlanItemApprovalCheck {

  // ___________________________________________________________________________
  /**
   * This method is to cancel plan item approval check for the passed
   * plan approval check key.
   *
   * @param key
   * Unique ID and versionNo of entry to delete
   *
   * @throws InformationalException e2
   *
   * @throws AppException e1
   */
  @Override
  public void cancelPlanItemApprovalCheck(
    final CancelPlanItemApprovalCheckKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckKey id = new PlanItemApprovalCheckKey();
    final CancelPlanItemApprovalCheckDetails details = new CancelPlanItemApprovalCheckDetails();

    id.assign(key);
    details.versionNo = key.versionNo;
    details.statusCode = RECORDSTATUS.CANCELLED;

    piAppCheckObj.cancel(id, details);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to create a new plan item approval check entry.
   *
   *
   * @param details
   * Details used to create the new entry
   *
   * @throws InformationalException e2
   *
   * @throws AppException e1
   */
  @Override
  public void createPlanItemApprovalCheck(
    final PlanItemApprovalCheckDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckDtls dtls = new PlanItemApprovalCheckDtls();

    dtls.assign(details.dtls);

    piAppCheckObj.insert(dtls);

    // This is needed to ensure that the generated unique ID gets passed back
    // the structs above are different to simplify the modeled aggregations but
    // that means that the Java object that gets passed into the
    // insert is different from the one used to call the entity.
    details.dtls.planItemApprovalCheckID = dtls.planItemApprovalCheckID;
  }

  // ___________________________________________________________________________
  /**
   * This method is to get the list all plan item approval check
   * entries for a given username.
   *
   * @param key
   * Username to search against
   *
   * @return List of plan item approval check details that are retrieved for
   * the passed user name
   *
   * @throws InformationalException e2
   * @throws AppException e1
   */
  @Override
  public PlanItemApprovalCheckDetailsList listPlanItemApprovalChecks(
    final PlanItemApprovalCheckUsernameID key) throws AppException,
      InformationalException {

    final PlanItemApprovalCheckDetailsList list = new PlanItemApprovalCheckDetailsList();

    final curam.serviceplans.sl.entity.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckUsernameKey username = new PlanItemApprovalCheckUsernameKey();

    username.assign(key);

    list.planItemApprovalCheckList.assign(
      piAppCheckObj.searchWithPITypeByUsername(username));

    // get the list size
    final int size = list.planItemApprovalCheckList.dtls.size();

    // Change display of PlanItemName if the applied to all option is selected
    for (int i = 0; i < size; i++) {
      if (list.planItemApprovalCheckList.dtls.item(i).appliesToAllInd == true) {
        list.planItemApprovalCheckList.dtls.item(i).planItemName = PLANITEMNAMECODE.ALLTYPES;
      }
    }

    return list;
  }

  // ___________________________________________________________________________
  /**
   * This method is to modify an existing plan item approval check entry.
   *
   *
   * @param details
   * Details used to modify the entry
   *
   * @throws InformationalException e2
   * @throws AppException e1
   */
  @Override
  public void modifyPlanItemApprovalCheck(
    final PlanItemApprovalCheckDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckKey key = new PlanItemApprovalCheckKey();
    final PlanItemApprovalCheckDtls dtls = new PlanItemApprovalCheckDtls();

    key.planItemApprovalCheckID = details.dtls.planItemApprovalCheckID;
    dtls.assign(details.dtls);

    piAppCheckObj.modify(key, dtls);
  }

  // ___________________________________________________________________________
  /**
   * Read a plan item approval check entry. This method is used to read the
   * PlanItemApprovalCheck details for the given plan item approval check id.
   *
   * @param key
   * Unique reference to the entry
   *
   * @return Details of the plan item approval that was read.
   *
   * @throws InformationalException e2
   *
   * @throws AppException e1
   */
  @Override
  public PlanItemApprovalCheckDetails readPlanItemApprovalCheck(
    final PlanItemApprovalCheckID key) throws AppException,
      InformationalException {

    final PlanItemApprovalCheckDetails details = new PlanItemApprovalCheckDetails();

    final curam.serviceplans.sl.entity.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckKey id = new PlanItemApprovalCheckKey();

    id.assign(key);

    details.dtls.assign(piAppCheckObj.readWithPIType(id));

    // Change display of PlanItemName if the applied to all option is selected
    if (details.dtls.appliesToAllInd == true) {
      details.dtls.planItemName = PLANITEMNAMECODE.ALLTYPES;
    }

    return details;
  }

}
