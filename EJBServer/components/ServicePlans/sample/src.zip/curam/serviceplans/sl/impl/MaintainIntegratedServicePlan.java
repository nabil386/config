/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.SERVICEPLANDELIVERYTYPE;
import curam.codetable.SERVICEPLANGROUPNAME;
import curam.codetable.SERVICEPLANTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.struct.MilestoneDeliveryDetails;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndICTypeDetails;
import curam.core.struct.CaseReferenceConcernRoleNameICTypeAltID;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.message.BPOINTEGRATEDSERVICEPLAN;
import curam.serviceplans.sl.entity.fact.GoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.Goal;
import curam.serviceplans.sl.entity.intf.PlannedGoal;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.intf.ServicePlanGroup;
import curam.serviceplans.sl.entity.struct.GoalDtls;
import curam.serviceplans.sl.entity.struct.GoalKey;
import curam.serviceplans.sl.entity.struct.IntegratedCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalDetails;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.fact.MilestoneFactory;
import curam.serviceplans.sl.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.fact.ServicePlanStatementFactory;
import curam.serviceplans.sl.intf.Milestone;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.serviceplans.sl.intf.ServicePlanStatement;
import curam.serviceplans.sl.struct.IntegratedServicePlanGoalSummaryDetails;
import curam.serviceplans.sl.struct.IntegratedServicePlanHomePageDetails;
import curam.serviceplans.sl.struct.IntegratedServicePlanKey;
import curam.serviceplans.sl.struct.IntegratedServicePlanTabDetails;
import curam.serviceplans.sl.struct.MilestoneDeliveryDetailsList;
import curam.serviceplans.sl.struct.ReadServicePlanDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryCostDtls;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanForICList;
import curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryDetails1;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;


/**
 * Service layer class used to maintain the integrated service plan
 * functionality.
 *
 */
public abstract class MaintainIntegratedServicePlan extends curam.serviceplans.sl.base.MaintainIntegratedServicePlan {

  // _________________________________________________________________________
  /**
   * This method is used to fetch all the milestone for the integrated service
   * plan.
   *
   * @param caseidKey
   * CaseIDKey
   * @return MilestoneDeliveryDetailsList
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public MilestoneDeliveryDetailsList getAllMilestones(
    final CaseIDKey caseidKey) throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final MilestoneDeliveryDetailsList returnStruct = new MilestoneDeliveryDetailsList();

    final Milestone mileStoneObj = MilestoneFactory.newInstance();

    final ServicePlanIntegratedCaseKey spIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    final SPGDeliveryLink spgdLinkObj = SPGDeliveryLinkFactory.newInstance();

    // Fetch the list of service plan deliveries for the integrated service plan

    spIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = caseidKey.caseID;

    final ServicePlanForICList servicePlanForICList = servicePlanDeliveryObj.listByIntegratedCase(
      spIntegratedCaseKey);

    final CaseHeaderKey servicePlanCaseIDKey = new CaseHeaderKey();

    SPGDeliveryKey spgdeliveryKey = null;

    final int servicePlanDeliveryAndParticipantSummaryDetailsListSize = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.size();

    for (int spdCaseKeyIter = 0; spdCaseKeyIter
      < servicePlanDeliveryAndParticipantSummaryDetailsListSize; spdCaseKeyIter++) {

      servicePlanCaseIDKey.caseID = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.item(spdCaseKeyIter).caseID;

      try {

        spgdeliveryKey = spgdLinkObj.readServicePlanGroupDeliveryIdByCaseId(
          servicePlanCaseIDKey);

      } catch (final RecordNotFoundException e) {// If the service plan does not
        // belong to any service plan group
        // then
        // ignore the exception
      }

      final MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = mileStoneObj.listAllMilestoneDeliveriesForServicePlan(
        servicePlanCaseIDKey);

      // Add the case reference details for the service plan delivery
      setCaseIDAndCaseReference(milestoneDeliveryDetailsList,
        servicePlanCaseIDKey.caseID, spgdeliveryKey);

      // Add all the details returned from the core method to the return list
      consolidateMilestoneList(returnStruct, milestoneDeliveryDetailsList);
    }

    return returnStruct;
  }

  // _________________________________________________________________________
  /**
   * This method is used to consolidate the list of the milestones into the
   * final return struct.
   *
   * @param returnStruct
   * MilestoneDeliveryDetailsList
   * @param milestoneList
   * MilestoneDeliveryDetailsList
   */
  protected void consolidateMilestoneList(
    MilestoneDeliveryDetailsList returnStruct,
    MilestoneDeliveryDetailsList milestoneList) {

    returnStruct.spMilestoneDetailsList.dtlsList.dtls.addAll(
      milestoneList.spMilestoneDetailsList.dtlsList.dtls);
  }

  // _________________________________________________________________________
  /**
   * This method is used to fetch all the incomplete milestones for the
   * integrated service plan.
   *
   * @param caseidKey
   * CaseIDKey - Identifier of the case.
   * @return MilestoneDeliveryDetailsList
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public MilestoneDeliveryDetailsList getIncompleteMilestones(
    CaseIDKey caseidKey) throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final MilestoneDeliveryDetailsList returnStruct = new MilestoneDeliveryDetailsList();

    final Milestone mileStoneObj = MilestoneFactory.newInstance();

    final ServicePlanIntegratedCaseKey spIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // Fetch the list of service plan deliveries for the integrated service
    // plan.
    spIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = caseidKey.caseID;

    final ServicePlanForICList servicePlanForICList = servicePlanDeliveryObj.listByIntegratedCase(
      spIntegratedCaseKey);

    final CaseHeaderKey servicePlanCaseIDKey = new CaseHeaderKey();

    final SPGDeliveryLink spgdLinkObj = SPGDeliveryLinkFactory.newInstance();

    SPGDeliveryKey spgdeliveryKey = null;

    final int servicePlanDeliveryAndParticipantSummaryDetailsListSize = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.size();

    for (int spdCaseKeyIter = 0; spdCaseKeyIter
      < servicePlanDeliveryAndParticipantSummaryDetailsListSize; spdCaseKeyIter++) {

      servicePlanCaseIDKey.caseID = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.item(spdCaseKeyIter).caseID;

      final MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = mileStoneObj.listUncompletedMilestonesForServicePlan(
        servicePlanCaseIDKey);

      try {
        spgdeliveryKey = spgdLinkObj.readServicePlanGroupDeliveryIdByCaseId(
          servicePlanCaseIDKey);

      } catch (final RecordNotFoundException e) {// If the service plan does not
        // belong to any service plan group
        // then
        // ignore the exception
      }

      // Add the case reference details for the service plan delivery
      setCaseIDAndCaseReference(milestoneDeliveryDetailsList,
        servicePlanCaseIDKey.caseID, spgdeliveryKey);

      // Add all the details returned from the core method to the return list
      consolidateMilestoneList(returnStruct, milestoneDeliveryDetailsList);
    }

    return returnStruct;
  }

  // _________________________________________________________________________
  /**
   * This method is used to set the case id and case reference of the
   * milestone list.
   *
   * @param milestoneDeliveryDetailsList
   * MilestoneDeliveryDetailsList
   * @param caseID
   * CaseID
   * @param spgdeliveryKey
   * SPGDeliveryKey
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  protected void setCaseIDAndCaseReference(
    MilestoneDeliveryDetailsList milestoneDeliveryDetailsList, long caseID,
    SPGDeliveryKey spgdeliveryKey) throws AppException,
      InformationalException {

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseID;

    final CaseReferenceAndICTypeDetails caseReferenceAndICTypeDetails = caseHeaderObj.readCaseReferenceAndICType(
      caseKey);

    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    final IntegratedCaseReferenceKey caseReferenceKey = new IntegratedCaseReferenceKey();

    caseReferenceKey.caseReference = caseReferenceAndICTypeDetails.caseReference;

    caseReferenceKey.integratedCaseID = caseKey.caseID;

    MilestoneDeliveryDetails milestoneDeliveryDetails = new MilestoneDeliveryDetails();

    SPGDeliveryDtls spgDeliveryDtls = null;

    // If the service plan does not belong to a SPG then spgKey will be null

    if (null != spgdeliveryKey) {

      spgDeliveryDtls = spgDeliveryObj.read(spgdeliveryKey);
    }

    final int milestoneDetailsListSize = milestoneDeliveryDetailsList.spMilestoneDetailsList.dtlsList.dtls.size();

    // Iterate through each milestone
    for (int milestoneListIter = 0; milestoneListIter
      < milestoneDetailsListSize; milestoneListIter++) {

      milestoneDeliveryDetails = milestoneDeliveryDetailsList.spMilestoneDetailsList.dtlsList.dtls.item(
        milestoneListIter);

      milestoneDeliveryDetails.caseDtls.assign(caseReferenceKey);

      // If the service plan belong to a service plan group then
      // get the service plan group reference.

      if (spgDeliveryDtls != null) {

        milestoneDeliveryDetails.spgReference.servicePlanGroupDeliveryId = spgDeliveryDtls.servicePlanGroupDeliveryId;

        milestoneDeliveryDetails.spgReference.spgdReference = spgDeliveryDtls.spgdReference;
      }

    }

  }

  // _________________________________________________________________________
  /**
   * Reads the ISP Home Page details.
   *
   * @param active only
   * a boolean value indicating if all records need to be read or only
   * the active records.
   * @param integratedServicePlanKey
   * IntegratedServicePlanKey
   * @return IntegratedServicePlanHomePageDetails
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  @Override
  public IntegratedServicePlanHomePageDetails readIntegratedServicePlanHomePage(
    IntegratedServicePlanKey integratedServicePlanKey, boolean activeOnly)
    throws AppException, InformationalException {

    // Find all associated service plans with 'Integrated Service Plan' a.k.a.
    // 'Integrated Case'
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = integratedServicePlanKey.integratedCaseID;

    final ServicePlanForICList servicePlanForICList = servicePlanDeliveryObj.listByIntegratedCase(
      servicePlanIntegratedCaseKey);

    // Put all found values into map
    final Map<Long, ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanMap = new HashMap<Long, ServicePlanDeliveryAndParticipantSummaryDetails>();

    final int numberOfServicePlans = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      final ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDetails = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.item(
        servicePlanCount);

      servicePlanMap.put(servicePlanDetails.caseID, servicePlanDetails);
    }

    // Create return object
    final IntegratedServicePlanHomePageDetails integratedServicePlanHomePageDetails = new IntegratedServicePlanHomePageDetails();

    integratedServicePlanHomePageDetails.integratedCaseID = integratedServicePlanKey.integratedCaseID;

    integratedServicePlanHomePageDetails.totalEstimatedCost = Money.kZeroMoney;
    integratedServicePlanHomePageDetails.totalActualCost = Money.kZeroMoney;

    // Setup struct object for estimated / actual costs
    final ServicePlanDeliveryCostDtls estimatedAndActual = new ServicePlanDeliveryCostDtls();

    // factored out processing of Groups
    processServicePlanGroupsForISPHome(integratedServicePlanKey,
      integratedServicePlanHomePageDetails, servicePlanMap, estimatedAndActual,
      activeOnly);

    // Add remaining service plans in list to return object.
    final Iterator<ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanIterator = servicePlanMap.values().iterator();

    // factor out processing of the Service Plans details
    processServicePlansForISPHome(servicePlanIterator,
      integratedServicePlanHomePageDetails, estimatedAndActual, activeOnly);

    integratedServicePlanHomePageDetails.totalEstimatedCost = estimatedAndActual.estimatedCost;
    integratedServicePlanHomePageDetails.totalActualCost = estimatedAndActual.actualCost;

    return integratedServicePlanHomePageDetails;
  }

  // _________________________________________________________________________
  /**
   * Helper method used in the generation of the ISP Home page
   *
   * @param integratedServicePlanKey IntegratedServicePlanKey
   * @param integratedServicePlanHomePageDetails
   * IntegratedServicePlanHomePageDetails
   * @param servicePlanMap Map
   * @param estimatedAndActual ServicePlanDeliveryCostDtls
   *
   * @param activeOnly
   * whether or not we need to grab all Service Plan Deliveries'
   * details
   * @throws AppException e1
   * @throws InformationalException e2
   */
  protected void processServicePlanGroupsForISPHome(
    IntegratedServicePlanKey integratedServicePlanKey,
    IntegratedServicePlanHomePageDetails integratedServicePlanHomePageDetails,
    Map<Long, ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanMap,
    ServicePlanDeliveryCostDtls estimatedAndActual, boolean activeOnly)
    throws AppException, InformationalException {

    double estCost = 0.0D;
    double actCost = 0.0D;

    // Find all associated service plan groups
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    final SPGDeliveryLink spgDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();

    final IntegratedCaseIDKey integratedCaseIDKey = new IntegratedCaseIDKey();

    integratedCaseIDKey.integratedCaseID = integratedServicePlanKey.integratedCaseID;

    final SPGDeliveryDtlsList spgDeliveryDtlsList = spgDeliveryObj.searchByIntegratedCaseId(
      integratedCaseIDKey);

    final int numberOfSPGDeliveries = spgDeliveryDtlsList.dtls.size();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    for (int spgDeliveryCount = 0; spgDeliveryCount < numberOfSPGDeliveries; spgDeliveryCount++) {
      // Read the group details and add to return object.
      final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryDtlsList.dtls.item(
        spgDeliveryCount);

      final SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

      spgDeliveryKey.servicePlanGroupDeliveryId = spgDeliveryDtls.servicePlanGroupDeliveryId;

      // Read service plan group details
      final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

      final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

      servicePlanGroupKey.servicePlanGroupId = spgDeliveryDtls.servicePlanGroupId;

      final ServicePlanGroupDtls servicePlanGroupDtls = servicePlanGroupObj.read(
        servicePlanGroupKey);

      // Create the summary object
      final IntegratedServicePlanGoalSummaryDetails groupSummaryDetails = new IntegratedServicePlanGoalSummaryDetails();

      groupSummaryDetails.integratedCaseID = integratedServicePlanKey.integratedCaseID;
      groupSummaryDetails.summaryID = spgDeliveryDtls.servicePlanGroupDeliveryId;
      groupSummaryDetails.summaryReference = spgDeliveryDtls.spgdReference;
      groupSummaryDetails.summaryName = CodeTable.getOneItemForUserLocale(
        SERVICEPLANGROUPNAME.TABLENAME,
        servicePlanGroupDtls.servicePlanGroupName);
      groupSummaryDetails.summaryType = SERVICEPLANDELIVERYTYPE.SPG;
      groupSummaryDetails.summaryGoal = CuramConst.gkEmpty;
      groupSummaryDetails.summaryOutcome = CuramConst.gkEmpty;
      groupSummaryDetails.summaryEstimatedCost = Money.kZeroMoney;
      groupSummaryDetails.summaryActualCost = Money.kZeroMoney;
      groupSummaryDetails.summaryStatus = CuramConst.gkEmpty;

      // Add the summary object to the return object
      integratedServicePlanHomePageDetails.summaryDetails.addRef(
        groupSummaryDetails);

      // Read the Service Plan Deliveries for the group
      final SPGDeliveryLinkDtlsList spgDeliveryLinkDtlsList = spgDeliveryLinkObj.searchServicePlanDeliveriesByServicePlanGroupDeliveryId(
        spgDeliveryKey);

      double estimatedCost = 0;
      double actualCost = 0;

      // Remove any service plans within group from main list.
      final int numberOfServicePlans = spgDeliveryLinkDtlsList.dtls.size();

      for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
        final SPGDeliveryLinkDtls spgDeliveryLinkDtls = spgDeliveryLinkDtlsList.dtls.item(
          servicePlanCount);

        servicePlanDeliveryKey.key.caseID = spgDeliveryLinkDtls.caseID;

        final IntegratedServicePlanGoalSummaryDetails servicePlanSummaryDetails = createSummaryDetails(
          servicePlanDeliveryKey);

        if (activeOnly) {
          final String status = servicePlanSummaryDetails.summaryStatus;

          if (!(status.equals(CASESTATUS.CANCELED)
            || status.equals(CASESTATUS.CANCELLEDPLANNED)
            || status.equals(CASESTATUS.CLOSED)
            || status.equals(CASESTATUS.COMPLETED)
            || status.equals(CASESTATUS.REJECTED)
            || status.equals(CASESTATUS.SUSPENDED))) {
            estimatedCost += servicePlanSummaryDetails.summaryEstimatedCost.getValue();
            actualCost += servicePlanSummaryDetails.summaryActualCost.getValue();
          }
        } else {
          estimatedCost += servicePlanSummaryDetails.summaryEstimatedCost.getValue();
          actualCost += servicePlanSummaryDetails.summaryActualCost.getValue();
        }

        if (servicePlanMap.containsKey(spgDeliveryLinkDtls.caseID)) {
          servicePlanMap.remove(spgDeliveryLinkDtls.caseID);
        }
      }

      groupSummaryDetails.summaryEstimatedCost = new Money(estimatedCost);
      groupSummaryDetails.summaryActualCost = new Money(actualCost);

      estCost += estimatedCost;
      actCost += actualCost;
    }

    estimatedAndActual.estimatedCost = new Money(
      estimatedAndActual.estimatedCost.getValue() + estCost);
    estimatedAndActual.actualCost = new Money(
      estimatedAndActual.actualCost.getValue() + actCost);
  }

  // _________________________________________________________________________
  /**
   * Processes the Service Plans for the Integrated Service Plan Home
   *
   * @param servicePlanIterator Iterator
   * @param integratedServicePlanHomePageDetails
   * IntegratedServicePlanHomePageDetails
   * @param estimatedAndActual
   * Estimated and actual cost of the Service Plan.
   * @param activeOnly
   * whether or not we need to grab all Service Plan Deliveries'
   * details
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  protected void processServicePlansForISPHome(
    Iterator<ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanIterator,
    IntegratedServicePlanHomePageDetails integratedServicePlanHomePageDetails,
    ServicePlanDeliveryCostDtls estimatedAndActual, boolean activeOnly)
    throws AppException, InformationalException {

    double estCost = 0.0D;
    double actCost = 0.0D;

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    while (servicePlanIterator.hasNext()) {
      final ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDetails = servicePlanIterator.next();

      servicePlanDeliveryKey.key.caseID = servicePlanDetails.caseID;

      final IntegratedServicePlanGoalSummaryDetails servicePlanSummaryDetails = createSummaryDetails(
        servicePlanDeliveryKey);

      if (activeOnly) {
        final String status = servicePlanSummaryDetails.summaryStatus;

        if (!(status.equals(CASESTATUS.CANCELED)
          || status.equals(CASESTATUS.CANCELLEDPLANNED)
          || status.equals(CASESTATUS.CLOSED)
          || status.equals(CASESTATUS.COMPLETED)
          || status.equals(CASESTATUS.REJECTED)
          || status.equals(CASESTATUS.SUSPENDED))) {
          estCost += servicePlanSummaryDetails.summaryEstimatedCost.getValue();
          actCost += servicePlanSummaryDetails.summaryActualCost.getValue();
          integratedServicePlanHomePageDetails.summaryDetails.addRef(
            servicePlanSummaryDetails);
        }
      } else {
        estCost += servicePlanSummaryDetails.summaryEstimatedCost.getValue();
        actCost += servicePlanSummaryDetails.summaryActualCost.getValue();
        integratedServicePlanHomePageDetails.summaryDetails.addRef(
          servicePlanSummaryDetails);
      }

    }

    estimatedAndActual.estimatedCost = new Money(
      estimatedAndActual.estimatedCost.getValue() + estCost);
    estimatedAndActual.actualCost = new Money(
      estimatedAndActual.actualCost.getValue() + actCost);

  }

  // _________________________________________________________________________
  /**
   * Creates summary details for a service plan delivery.
   *
   * @param servicePlanDeliveryKey
   * ServicePlanDeliveryKey
   * @return IntegratedServicePlanGoalSummaryDetails
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  protected IntegratedServicePlanGoalSummaryDetails createSummaryDetails(
    ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {

    // Get the case information
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;

    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final ReadServicePlanDetails readServicePlanDetails = servicePlanObj.read(
      servicePlanKey);

    // Get the planned goal information
    final PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryEntityKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryEntityKey.caseID = servicePlanDeliveryKey.key.caseID;

    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();

    final PlannedGoalDetails plannedGoalDetails = plannedGoalObj.readDetailsByCaseID(
      notFoundIndicator, servicePlanDeliveryEntityKey);

    final IntegratedServicePlanGoalSummaryDetails summaryDetails = new IntegratedServicePlanGoalSummaryDetails();

    if (notFoundIndicator.isNotFound() == false) {
      final PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

      plannedGoalKey.plannedGoalID = plannedGoalDetails.plannedGoalID;

      final PlannedGoalDtls plannedGoalDtls = plannedGoalObj.read(
        plannedGoalKey);

      // Get the goal details
      final Goal goalObj = GoalFactory.newInstance();

      final GoalKey goalKey = new GoalKey();

      goalKey.goalID = plannedGoalDetails.goalID;

      final GoalDtls goalDtls = goalObj.read(goalKey);

      // Get the cost details
      final ServicePlanStatement servicePlanStatementObj = ServicePlanStatementFactory.newInstance();

      final ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey = new ServicePlanStatementDeliveryKey();

      servicePlanStatementDeliveryKey.caseID = servicePlanDeliveryKey.key.caseID;

      // BEGIN, CR00246182, TV
      // BEGIN, CR00208728, LP
      final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = servicePlanStatementObj.readServicePlanStatementDetails(
        servicePlanStatementDeliveryKey);

      // END, CR00208728
      // END, CR00246182

      summaryDetails.summaryGoal = goalDtls.name;
      summaryDetails.summaryOutcome = plannedGoalDtls.outcomeAchieved;
      summaryDetails.summaryEstimatedCost = servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.estimatedCost;
      summaryDetails.summaryActualCost = servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.actualCost;
    } else {
      summaryDetails.summaryGoal = CuramConst.gkEmpty;
      summaryDetails.summaryOutcome = CuramConst.gkEmpty;
      summaryDetails.summaryEstimatedCost = Money.kZeroMoney;
      summaryDetails.summaryActualCost = Money.kZeroMoney;
    }

    summaryDetails.summaryID = caseHeaderDtls.caseID;
    summaryDetails.summaryReference = caseHeaderDtls.caseReference;
    summaryDetails.summaryName = CodeTable.getOneItemForUserLocale(
      SERVICEPLANTYPE.TABLENAME, readServicePlanDetails.plan.servicePlanType);
    summaryDetails.summaryType = SERVICEPLANDELIVERYTYPE.SP;
    summaryDetails.summaryStatus = caseHeaderDtls.statusCode;

    return summaryDetails;
  }

  // BEGIN, CR00211672, CSH
  // _________________________________________________________________________
  /**
   * Reads the Integrated Service Plan tab context panel details.
   *
   * @param key Unique identifier for the assistance case.
   *
   * @return IntegratedServicePlanTabDetails
   *
   * @throws AppException Standard application exception
   * @throws InformationalException Standard information exception
   */
  @Override
  public IntegratedServicePlanTabDetails readIntegratedServicePlanTabDetails(
    CaseHeaderKey key) throws AppException, InformationalException {

    final IntegratedServicePlanTabDetails tabDetails = new IntegratedServicePlanTabDetails();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseReferenceConcernRoleNameICTypeAltID details = new CaseReferenceConcernRoleNameICTypeAltID();
    final CaseKey caseKey = new CaseKey();

    // Read associated case details for display on client screen
    caseKey.caseID = key.caseID;
    details = caseHeaderObj.readCaseReferenceICTypeConcernRoleNameAlternateID(
      key);

    tabDetails.caseReference = details.caseReference;
    tabDetails.personName = details.concernRoleName;
    tabDetails.integratedCaseType = details.integratedCaseType;

    // BEGIN, CR00386333, VT
    final Locale locale = ProgramLocale.parseLocale(
      TransactionInfo.getProgramLocale());
    // END, CR00386333

    final curam.util.message.CatEntry catEntry = BPOINTEGRATEDSERVICEPLAN.INF_RELATED_CASE_DESCRIPTION;
    final LocalisableString info = new LocalisableString(catEntry);

    info.arg(
      curam.util.type.CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
      tabDetails.integratedCaseType, locale.toString()));
    info.arg(tabDetails.caseReference);

    tabDetails.relatedCaseDescription = info.toClientFormattedText();

    final IntegratedServicePlanKey integratedServicePlanKey = new IntegratedServicePlanKey();

    integratedServicePlanKey.integratedCaseID = key.caseID;
    IntegratedServicePlanHomePageDetails serviceHomePageDetails = new IntegratedServicePlanHomePageDetails();

    // For the context panel display information relating to all plans
    // so the boolean parameter is set to false
    serviceHomePageDetails = readIntegratedServicePlanHomePage(
      integratedServicePlanKey, false);

    tabDetails.actualCost = serviceHomePageDetails.totalActualCost;
    tabDetails.estimatedCost = serviceHomePageDetails.totalEstimatedCost;

    return tabDetails;
  }
  // END, CR00211672
}
