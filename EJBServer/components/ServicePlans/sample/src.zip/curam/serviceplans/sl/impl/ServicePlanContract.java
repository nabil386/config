/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachment.impl.Attachment;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.DOCUMENTTYPE;
import curam.codetable.GOALNAME;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.SERVICEPLANCONTRACTSTATUS;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.SUBGOALNAME;
import curam.codetable.SUBGOALTYPE;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.ConcernRole;
import curam.core.intf.Users;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.struct.RecordCount;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.AttachmentNameStruct;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusAndEventTypeDetails1;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CreateCaseAttachmentDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadAttachmentIn;
import curam.core.struct.ReadIntegratedCaseIDAndParticipantDetails;
import curam.core.struct.UsersKey;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOMAINTAINATTACHMENT;
import curam.message.BPOSERVICEPLANCONTRACT;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.ContractPrintHistoryFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanContractFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.ContractPrintHistory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.CheckMultipleContractDetails;
import curam.serviceplans.sl.entity.struct.ContractPrintHistoryDtls;
import curam.serviceplans.sl.entity.struct.ContractPrintHistoryDtlsList;
import curam.serviceplans.sl.entity.struct.ContractPrintHistoryReadmultiKey;
import curam.serviceplans.sl.entity.struct.CountAllUnapprovAndSubmittedForServPlanKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalIDAndContractText;
import curam.serviceplans.sl.entity.struct.PlannedGoalIDandRecordStatusKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndContractTextDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedItemSensitivityDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForContractList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndConcernRoleKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalIDandSensitivityDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.ReadGoalNameByCaseIDKey;
import curam.serviceplans.sl.entity.struct.ReadPlannedGoalIDAndGoalTextByCaseIDKey;
import curam.serviceplans.sl.entity.struct.ReadSubGoalIDByPlannedSubGoal;
import curam.serviceplans.sl.entity.struct.ServicePlanContractDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanContractDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanContractKey;
import curam.serviceplans.sl.entity.struct.ServicePlanContractReadmultiKey;
import curam.serviceplans.sl.entity.struct.ServicePlanContractSensitivityCodeDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.SubGoalKey;
import curam.serviceplans.sl.intf.ServicePlanDocGeneration;
import curam.serviceplans.sl.struct.CompleteContractDetails;
import curam.serviceplans.sl.struct.ContractAttachmentDetails;
import curam.serviceplans.sl.struct.ContractPrintHistoryDetails;
import curam.serviceplans.sl.struct.CreateContractAttachmentKey;
import curam.serviceplans.sl.struct.CreateSPContractDetails;
import curam.serviceplans.sl.struct.CreateSPContractReturnKey;
import curam.serviceplans.sl.struct.ModifySPContractDetails;
import curam.serviceplans.sl.struct.PlannedSubGoalDetailsListForContract;
import curam.serviceplans.sl.struct.PrintContractHistoryDetailsList;
import curam.serviceplans.sl.struct.ServicePlanContractFullDetails;
import curam.serviceplans.sl.struct.ServicePlanContractFullDetailsList;
import curam.serviceplans.sl.struct.ServicePlanContractSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanDocumentTemplateCodeKey;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.StringList;
import java.io.File;


/**
 * This process class provides the functionality for the ServicePlanContract
 * service layer.
 */
public abstract class ServicePlanContract extends curam.serviceplans.sl.base.ServicePlanContract {

  // BEGIN, CR00146458, VR
  @Inject
  protected Attachment attachment;

  // END, CR00146458

  // BEGIN CR00108818, GBA
  // Add injection for using the new CaseTransactionLog API
  public ServicePlanContract() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108818

  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00354960

  /**
   * Create a contract for a specific service plan.
   *
   * @param createSPContractDetails
   * Contains the service plan contract creation details.
   *
   * @return The service plan contract ID.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to view
   * this page.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_CREATE_CONTRACT_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to create
   * a contract for this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public CreateSPContractReturnKey create(
    CreateSPContractDetails createSPContractDetails) throws AppException,
      InformationalException {

    // Create return object
    final CreateSPContractReturnKey createSPContractReturnKey = new CreateSPContractReturnKey();

    // SP Contract entity object
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = ServicePlanContractFactory.newInstance();

    // Service Plan Delivery manipulation variables
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // Service Plan Delivery manipulation variables
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey SPDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // Service Plan Security Key manipulation variable
    final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // END HARP 48756

    // Set key to check location security
    servicePlanDeliveryKey.key.caseID = createSPContractDetails.servicePlanContractDtls.caseID;
    final ServicePlanContractSensitivityCodeDetails servicePlanContractSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();

    // BEGIN, CR00227859, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // BEGIN,CR00124499, MC

    final String issueTo = createSPContractDetails.servicePlanContractDtls.issuedToParticipantRole
      + "";

    createSPContractDetails.servicePlanContractDtls.signedBy = createSPContractDetails.servicePlanContractDtls.signedBy.concat(CuramConst.gkTabDelimiter).concat(
      issueTo);

    // END, CR00124499

    // Set the sensitivity of the contract to the highest sensitivity of the
    // service plan
    // subgoal or planItems
    servicePlanContractSensitivityCodeDetails.sensitivityCode = getContractSensitivity(servicePlanDeliveryKey).sensitivityCode;
    // set the sensitivity to store in database
    createSPContractDetails.servicePlanContractDtls.sensitivityCode = servicePlanContractSensitivityCodeDetails.sensitivityCode;
    // Call entity operation to insert dailySchedule record
    servicePlanContractObj.insert(
      createSPContractDetails.servicePlanContractDtls);

    // Return the identifier of the service plan contract record
    createSPContractReturnKey.servicePlanContractID = createSPContractDetails.servicePlanContractDtls.servicePlanContractID;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    SPDeliveryKey.caseID = createSPContractDetails.servicePlanContractDtls.caseID;

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(SPDeliveryKey).servicePlanID;

    // Check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Now need to read the service plan case id and plan view role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Check security if user against that of the contract.
    try {
      servicePlanSecurity.contractSensitivityCheck(
        servicePlanContractSensitivityCodeDetails);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_CONTRACT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_CREATE_CONTRACT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    return createSPContractReturnKey;
  }

  /**
   * Lists contract records for a service plan.
   *
   * @param spContractListKey
   * Contains the service plan identifier.
   *
   * @return List of service plan records.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_LIST_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * page.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_LIST_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to list
   * contracts for this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanContractFullDetailsList list(
    curam.serviceplans.sl.struct.SPContractListKey spContractListKey)
    throws AppException, InformationalException {

    // Create return object
    final ServicePlanContractFullDetailsList servicePlanContractFullDetailsList = new ServicePlanContractFullDetailsList();

    // Contract manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();
    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID = new CaseParticipantRole_eoCaseParticipantRoleID();
    final ServicePlanContractReadmultiKey servicePlanContractReadmultiKey = new ServicePlanContractReadmultiKey();

    // Set key to retrieve list of contract records
    servicePlanContractReadmultiKey.caseID = spContractListKey.caseID;

    // Call entity operation to retrieve list of contract records
    final ServicePlanContractDtlsList servicePlanContractDtlsList = servicePlanContractObj.searchByCaseID(
      servicePlanContractReadmultiKey);

    for (int i = 0; i < servicePlanContractDtlsList.dtls.size(); i++) {

      final ServicePlanContractFullDetails servicePlanContractFullDetails = new ServicePlanContractFullDetails();
      ServicePlanContractDtls servicePlanContractDtls = new ServicePlanContractDtls();

      servicePlanContractDtls = servicePlanContractDtlsList.dtls.item(i);

      caseIDParticipantRoleKey.participantRoleID = servicePlanContractDtls.issuedToParticipantRole;
      caseIDParticipantRoleKey.caseID = servicePlanContractDtls.caseID;

      // Reads caseParticipantRoleID
      caseParticipantRoleCaseParticipantRoleID = caseParticipantRole.readCaseParticipantRoleID(
        caseIDParticipantRoleKey);

      // Assign caseParticipantRoleID to the return object
      servicePlanContractFullDetails.clientNameAndCPRoleID.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

      caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

      // Assign full name of client to display on contract home page
      servicePlanContractFullDetails.clientNameAndCPRoleID.clientName = caseParticipantRole.readFullName(caseParticipantRoleKey).fullName;

      servicePlanContractFullDetails.dtls = servicePlanContractDtls;

      // Add contract full details to list
      servicePlanContractFullDetailsList.details.addRef(
        servicePlanContractFullDetails);

    }

    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = spContractListKey.caseID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;
    caseHeaderKey.caseID = spContractListKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_LIST_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_LIST_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    // return list
    return servicePlanContractFullDetailsList;
  }

  /**
   * Lists all active service plan participants for which the contract can be
   * issued to.
   *
   * @param servicePlanDeliveryKey
   * Contains the service plan delivery key.
   *
   * @return The list of plan participation to issue the contract to.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_ISSUE_CONTRACT_PARTICIPANTS_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_ISSUE_CONTRACT_PARTICIPANTS_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewCaseParticipantRoleDetailsList listParticipantsToIssueContractTo(
    curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey)
    throws AppException, InformationalException {

    // Create return object
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = new ViewCaseParticipantRoleDetailsList();

    // Service Plan Contract manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // validate that the list can be viewed
    validateListParticipantsToIssueContractTo(servicePlanDeliveryKey);

    // List participants for case
    viewCaseParticipantRole_boKey.dtls.caseID = servicePlanDeliveryKey.key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;

    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseParticipantRoleList(
      viewCaseParticipantRole_boKey);

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey.key).servicePlanID;
    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_ISSUE_CONTRACT_PARTICIPANTS_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_ISSUE_CONTRACT_PARTICIPANTS_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    return viewCaseParticipantRoleDetailsList;

  }

  /**
   * Lists print history records for a service plan contract.
   *
   * @param key
   * Contains the service plan contract identifier.
   *
   * @return List of print history records.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_PRINT_CONTRACT_HISTORY_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_PRINT_CONTRACT_HISTORY_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public PrintContractHistoryDetailsList listPrintHistory(
    curam.serviceplans.sl.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    // Create return object
    final PrintContractHistoryDetailsList printContractHistoryDetailsList = new PrintContractHistoryDetailsList();

    // SP Contract Print History manipulation variables
    final ContractPrintHistory contractPrintHistoryObj = ContractPrintHistoryFactory.newInstance();

    // contract manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    final ContractPrintHistoryReadmultiKey contractPrintHistoryReadmultiKey = new ContractPrintHistoryReadmultiKey();

    // Set key to retrieve list of print records
    contractPrintHistoryReadmultiKey.servicePlanContractID = key.servicePlanContractID;

    // Call entity operation to retrieve list of contract records
    final ContractPrintHistoryDtlsList contractPrintHistoryDtlsList = contractPrintHistoryObj.searchByContractID(
      contractPrintHistoryReadmultiKey);

    final Users usersObj = UsersFactory.newInstance();
    ContractPrintHistoryDetails contractPrintHistoryDetails;

    for (int i = 0; i < contractPrintHistoryDtlsList.dtls.size(); i++) {

      contractPrintHistoryDetails = new ContractPrintHistoryDetails();

      contractPrintHistoryDetails.contractPrintHistoryID = contractPrintHistoryDtlsList.dtls.item(i).contractPrintHistoryID;
      contractPrintHistoryDetails.printDate = contractPrintHistoryDtlsList.dtls.item(i).printDate;
      contractPrintHistoryDetails.servicePlanContractID = contractPrintHistoryDtlsList.dtls.item(i).servicePlanContractID;
      contractPrintHistoryDetails.requestedBy = contractPrintHistoryDtlsList.dtls.item(i).requestedBy;

      final UsersKey usersKey = new UsersKey();

      usersKey.userName = contractPrintHistoryDetails.requestedBy;
      contractPrintHistoryDetails.requestedByFullName = usersObj.getFullName(usersKey).fullname;

      printContractHistoryDetailsList.detailsList.dtls.addRef(
        contractPrintHistoryDetails);
    }

    final ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();

    servicePlanContractKey.servicePlanContractID = key.servicePlanContractID;

    printContractHistoryDetailsList.nameDateAndStatusDetails = servicePlanContractObj.readContractStatusClientAndIssueDate(
      servicePlanContractKey);

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey).caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_PRINT_CONTRACT_HISTORY_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_PRINT_CONTRACT_HISTORY_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    return printContractHistoryDetailsList;
  }

  /**
   * Modifies the details of a service plan contract.
   *
   * @param modifySPContractDetails Contains the modified contract details.
   *
   * @throws AppException
   * {@link BPOMAINTAINATTACHMENT#ERR_CASEATTACHMENT_NAME_XRV_FILE_MUST_EXIST_ALREADY}
   * - if attachment name is entered, attachment file must exist already.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOMAINTAINATTACHMENT#ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE}
   * - the user should provide either file location and reference or file
   * attachment but not both.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_MODIFY_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify this
   * contract.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_MODIFY_CONTRACT_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to modify this
   * contract.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   */
  @Override
  public void modify(ModifySPContractDetails modifySPContractDetails)
    throws AppException, InformationalException {

    // contract manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = ServicePlanContractFactory.newInstance();
    final ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();

    // Maintain Case business object
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    // BEGIN, CR00220971, ZV
    final CaseStatusAndEventTypeDetails1 caseStatusAndEventTypeDetails = new CaseStatusAndEventTypeDetails1();

    // END, CR00220971

    // Set key to modify dailySchedule record
    servicePlanContractKey.servicePlanContractID = modifySPContractDetails.servicePlanContractDtls.servicePlanContractID;

    // create Concern Role Communication object

    // BEGIN,CR00124499, MC
    final String issueTo = modifySPContractDetails.servicePlanContractDtls.issuedToParticipantRole
      + "";

    if (modifySPContractDetails.servicePlanContractDtls.signedBy.length() > 0) {

      modifySPContractDetails.servicePlanContractDtls.signedBy = modifySPContractDetails.servicePlanContractDtls.signedBy.concat(CuramConst.gkTabDelimiter).concat(
        issueTo);

    } else {

      modifySPContractDetails.servicePlanContractDtls.signedBy = issueTo;
    }

    // END, CR00124499

    // BEGIN, CR00002547, CSH
    // Set indicators to check if location and reference have been entered
    final boolean locationANDReferenceProvided = modifySPContractDetails.attachmentDetails.fileLocation.length()
      != 0
        && modifySPContractDetails.attachmentDetails.fileReference.length()
          != 0;

    final boolean locationORReferenceProvided = modifySPContractDetails.attachmentDetails.fileLocation.length()
      != 0
        || modifySPContractDetails.attachmentDetails.fileReference.length()
          != 0;
    // END, CR00002547

    // BEGIN, CR00037661, CSH
    final boolean attachmentNameProvided = modifySPContractDetails.attachmentDetails.attachmentName.length()
      != 0;

    // END, CR00037661

    // need to read the service plan case id and plan participant role id.
    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    servicePlanDeliveryKey.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey).caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // BEGIN CR00108818, GBA
    final ReadIntegratedCaseIDAndParticipantDetails readIntegIDAndPartDtls = curam.core.fact.CaseHeaderFactory.newInstance().readIntegratedCaseIDAndParticipantDetails(
      caseHeaderKey);

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = readIntegIDAndPartDtls.concernRoleID;
    // END CR00108818

    if (modifySPContractDetails.attachmentDetails.attachedFileInd == true) {

      final AttachmentKey attachmentKey = new AttachmentKey();
      AttachmentDtls attachmentDtls = new AttachmentDtls();

      attachmentKey.attachmentID = modifySPContractDetails.attachmentDetails.attachmentID;

      attachmentDtls = attachment.read(attachmentKey);

      if (modifySPContractDetails.attachmentDetails.attachmentContents.length()
        != 0) {
        attachmentDtls.attachmentContents = modifySPContractDetails.attachmentDetails.attachmentContents;

        // Parses the file name from path of the file.
        java.io.File attachmentName;

        attachmentName = new java.io.File(
          modifySPContractDetails.attachmentDetails.attachmentName);
        attachmentDtls.attachmentName = attachmentName.getName();
      }

      attachmentDtls.fileLocation = modifySPContractDetails.attachmentDetails.fileLocation;
      attachmentDtls.fileReference = modifySPContractDetails.attachmentDetails.fileReference;
      attachmentDtls.attachedFileInd = modifySPContractDetails.attachmentDetails.attachedFileInd;

      attachmentKey.attachmentID = modifySPContractDetails.attachmentDetails.attachmentID;

      // modify attachment record
      attachment.modify(attachmentKey, attachmentDtls);

      modifySPContractDetails.servicePlanContractDtls.attachmentID = attachmentDtls.attachmentID;

    } else if (modifySPContractDetails.attachmentDetails.attachedFileInd
      == false
        && modifySPContractDetails.attachmentDetails.attachmentContents.length()
          != 0) {

      final CreateCaseAttachmentDetails createCaseAttachmentDetails = new CreateCaseAttachmentDetails();

      // copying over attachment details
      createCaseAttachmentDetails.newCaseAttachmentName = modifySPContractDetails.attachmentDetails.attachmentName;
      createCaseAttachmentDetails.newCaseAttachmentContents = modifySPContractDetails.attachmentDetails.attachmentContents;
      createCaseAttachmentDetails.filelocation = modifySPContractDetails.attachmentDetails.fileLocation;
      createCaseAttachmentDetails.fileReference = modifySPContractDetails.attachmentDetails.fileReference;
      createCaseAttachmentDetails.documentType = DOCUMENTTYPE.DEFAULTCODE;
      createCaseAttachmentDetails.caseParticipantRoleID = modifySPContractDetails.servicePlanContractDtls.issuedToParticipantRole;
      createCaseAttachmentDetails.attachedFileInd = true;

      // BEGIN, CR00354960, CD
      // set up some meta data for the attachment
      final CMSMetadataInterface cmsMetadataInterface = cmsMetadataProvider.get();

      cmsMetadataInterface.add(CMSMetadataConst.kCaseID,
        Long.toString(readIntegIDAndPartDtls.integratedCaseID));
      // END, CR00354960

      modifySPContractDetails.servicePlanContractDtls.attachmentID = insertContractAttachment(createCaseAttachmentDetails).attachmentID;
    } // BEGIN, CR00002547, CSH
    else if (locationANDReferenceProvided) {

      // If location and reference have been provided we need to create
      // an attachment record to store these details
      final CreateCaseAttachmentDetails createCaseAttachmentDetails = new CreateCaseAttachmentDetails();

      // Set location and reference details
      createCaseAttachmentDetails.filelocation = modifySPContractDetails.attachmentDetails.fileLocation;
      createCaseAttachmentDetails.fileReference = modifySPContractDetails.attachmentDetails.fileReference;

      // Insert the attachment record
      modifySPContractDetails.servicePlanContractDtls.attachmentID = insertContractAttachment(createCaseAttachmentDetails).attachmentID;
    } else if (locationORReferenceProvided) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
    } // END, CR00002547
    // BEGIN, CR00037661, CSH
    // Only a file name or location and reference must be supplied, not both
    else if (attachmentNameProvided && locationANDReferenceProvided) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          7);
    } // If a file name is provided, it must be valid
    else if (attachmentNameProvided) {

      File attachmentName;

      // Check that the attachment exists already
      attachmentName = new File(
        modifySPContractDetails.attachmentDetails.attachmentName);

      if (!attachmentName.exists()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_NAME_XRV_FILE_MUST_EXIST_ALREADY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // If a valid file name has been entered, but contents are empty try to
      // create an attachment and run regular attachment validations
      final CreateCaseAttachmentDetails createCaseAttachmentDetails = new CreateCaseAttachmentDetails();

      // copying over attachment details
      createCaseAttachmentDetails.newCaseAttachmentName = modifySPContractDetails.attachmentDetails.attachmentName;
      createCaseAttachmentDetails.newCaseAttachmentContents = modifySPContractDetails.attachmentDetails.attachmentContents;
      createCaseAttachmentDetails.filelocation = modifySPContractDetails.attachmentDetails.fileLocation;
      createCaseAttachmentDetails.fileReference = modifySPContractDetails.attachmentDetails.fileReference;
      createCaseAttachmentDetails.documentType = DOCUMENTTYPE.DEFAULTCODE;
      createCaseAttachmentDetails.caseParticipantRoleID = modifySPContractDetails.servicePlanContractDtls.issuedToParticipantRole;
      createCaseAttachmentDetails.attachedFileInd = true;

      modifySPContractDetails.servicePlanContractDtls.attachmentID = insertContractAttachment(createCaseAttachmentDetails).attachmentID;
    }
    // END, CR00037661

    // Call entity operation to modify contract record
    servicePlanContractObj.modify(servicePlanContractKey,
      modifySPContractDetails.servicePlanContractDtls);

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    // BEGIN, CR00227859, PM
    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANCONTRACT.ERR_MODIFY_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_MODIFY_CONTRACT_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_MODIFY_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // if contract is accepted, plan must be activated
    if (modifySPContractDetails.servicePlanContractDtls.status.equals(
      SERVICEPLANCONTRACTSTATUS.ACCEPTED)) {

      // create case status and event details
      caseStatusAndEventTypeDetails.caseID = servicePlanDeliveryKey.caseID;
      caseStatusAndEventTypeDetails.eventTypeCode = CASEEVENTTYPE.PLANACTIVATED;
      caseStatusAndEventTypeDetails.statusCode = CASESTATUS.ACTIVE;

      // change case status to 'active'.
      // BEGIN, CR00220971, ZV
      maintainCaseObj.changeCaseStatus1(caseStatusAndEventTypeDetails);
      // END, CR00220971

      // BEGIN CR00108818, GBA
      // Log Transaction Details
      if (servicePlanDeliveryKey != null && servicePlanDeliveryKey.caseID != 0) {

        // ConcernRole manipulation variables to get Case Member name
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final curam.core.struct.ConcernRoleKey concernRoleKeyObj = new curam.core.struct.ConcernRoleKey();

        concernRoleKeyObj.concernRoleID = readIntegIDAndPartDtls.concernRoleID;

        final CodeTableItemIdentifier SPTypeCodeIdentifier = new CodeTableItemIdentifier(
          SERVICEPLANTYPE.TABLENAME,
          servicePlanDeliveryObj.readServicePlanType(servicePlanDeliveryKey).servicePlanType);

        final LocalisableString description = new LocalisableString(BPOCASEEVENTS.SERVICEPLAN_ACTIVATED).arg(SPTypeCodeIdentifier).arg(
          concernRoleObj.read(concernRoleKeyObj).concernRoleName);

        caseTransactionLogProvider.get().recordCaseTransaction(
          CASETRANSACTIONEVENTS.SERVICEPLAN_ACTIVATED, description,
          readIntegIDAndPartDtls.integratedCaseID, CuramConst.kDefaultRelatedID);
      }
      // END CR00108818

    }
  }

  /**
   * Prints a service plan contract.
   *
   * @param spContractKey
   * Contains the unique key which identifies the service plan
   * contract.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_PRINT_CONTRACT_VIEW} - if an
   * un-handled server exception has occurred. Please contact your
   * administrator.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_PRINT_CONTRACT_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to print
   * the contract for this service plan.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_PRINT_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to print
   * the contract for this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void print(
    curam.serviceplans.sl.struct.ServicePlanContractKey spContractKey)
    throws AppException, InformationalException {

    // Contract manipulation variables
    final ServicePlanDocGeneration servicePlanDocGenerationObj = curam.serviceplans.sl.fact.ServicePlanDocGenerationFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    final ServicePlanDocumentTemplateCodeKey servicePlanDocumentTemplateCodeKey = new ServicePlanDocumentTemplateCodeKey();
    final ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();

    // Contract Print History manipulation variables
    final ContractPrintHistory contractPrintHistory = ContractPrintHistoryFactory.newInstance();
    final ContractPrintHistoryDtls contractPrintHistoryDtls = new ContractPrintHistoryDtls();
    final Date currentDate = Date.getCurrentDate();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanContractSecurityKey servicePlanContractSecurityKey = new ServicePlanContractSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ServicePlanDelivery variables
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    // BEGIN, CR00220971, ZV
    final CaseStatusAndEventTypeDetails1 caseStatusAndEventTypeDetails = new CaseStatusAndEventTypeDetails1();

    // END, CR00220971

    // populate key
    servicePlanContractKey.servicePlanContractID = spContractKey.servicePlanContractID;
    servicePlanDocumentTemplateCodeKey.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey).caseID;
    servicePlanDocumentTemplateCodeKey.servicePlanContractID = spContractKey.servicePlanContractID;
    servicePlanDocumentTemplateCodeKey.templateTypeCode = curam.codetable.TEMPLATEIDCODE.SERVICEPLANCONTRACT;

    // Call the print method

    // BEGIN, CR00094662 SK
    try {
      servicePlanDocGenerationObj.printDocumentByTemplateIDCode(
        servicePlanDocumentTemplateCodeKey);
    } catch (final AppException e) {
      throw new AppException(BPOSERVICEPLANCONTRACT.ERR_PRINT_CONTRACT_VIEW);
    }
    // END, CR00094662
    // Insert a printHistory record
    contractPrintHistoryDtls.printDate = currentDate;
    contractPrintHistoryDtls.servicePlanContractID = spContractKey.servicePlanContractID;
    contractPrintHistoryDtls.requestedBy = curam.util.transaction.TransactionInfo.getProgramUser();
    contractPrintHistory.insert(contractPrintHistoryDtls);

    // populate input struct to create case status and event
    caseStatusAndEventTypeDetails.caseID = servicePlanDocumentTemplateCodeKey.caseID;
    caseStatusAndEventTypeDetails.eventTypeCode = CASEEVENTTYPE.CONTRACTPRINTED;

    // read current case status

    // Set key to read CaseHeader
    caseHeaderKey.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey).caseID;

    // Read CaseStatus
    caseStatusAndEventTypeDetails.statusCode = caseHeaderObj.readCaseStatus(caseHeaderKey).statusCode;
    caseStatusAndEventTypeDetails.relatedID = contractPrintHistoryDtls.servicePlanContractID;

    // change case status to 'submitted' and create 'Contract Printed' event
    // BEGIN, CR00220971, ZV
    maintainCaseObj.changeCaseStatus1(caseStatusAndEventTypeDetails);
    // END, CR00220971

    // Read service plan id
    servicePlanDeliveryKey.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey).caseID;
    servicePlanContractSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanContractSecurityKey.servicePlanContractID = spContractKey.servicePlanContractID;

    // check service plan security
    try {
      servicePlanSecurity.contractOperationSecurityCheck(
        servicePlanContractSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_PRINT_CONTRACT_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_PRINT_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
  }

  /**
   * Reads the details of the contract record.
   *
   * @param key
   * Identifies the Service Plan Contract record to be read.
   *
   * @return Contract details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to view
   * this page.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_VIEW_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanContractFullDetails read(
    curam.serviceplans.sl.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    // Create return object
    final ServicePlanContractFullDetails servicePlanContractFullDetails = new ServicePlanContractFullDetails();

    // Contract manipulation variables
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    final ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();
    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID = new CaseParticipantRole_eoCaseParticipantRoleID();

    // Set key to read record
    servicePlanContractKey.servicePlanContractID = key.servicePlanContractID;

    // Call entity operation to read contract record

    servicePlanContractFullDetails.dtls = servicePlanContractObj.read(
      servicePlanContractKey);
    caseIDParticipantRoleKey.participantRoleID = servicePlanContractFullDetails.dtls.issuedToParticipantRole;
    caseIDParticipantRoleKey.caseID = servicePlanContractFullDetails.dtls.caseID;

    // BEGIN, CR00123092, MC

    final StringList tabbedParticipantsList = StringUtil.tabText2StringListWithTrim(
      servicePlanContractFullDetails.dtls.signedBy);

    if (tabbedParticipantsList != null && tabbedParticipantsList.size() > 0) {

      // Get a named list of participants
      // Get the Comma separated ConcernRole names for signed by details
      final ConcernRole concernRoleEntObj = ConcernRoleFactory.newInstance();
      ConcernRoleKey concernRoleKey = null;

      final StringBuffer signedParticipantNames = new StringBuffer();

      final int planParticipantsListSize = tabbedParticipantsList.size();

      for (int i = 0; i < planParticipantsListSize; i++) {
        concernRoleKey = new ConcernRoleKey();
        if (tabbedParticipantsList.item(i).trim().length() > 0) {
          concernRoleKey.concernRoleID = Long.parseLong(
            tabbedParticipantsList.item(i));

          // BEGIN, CR00124499, MC
          signedParticipantNames.append(CuramConst.gkSpaceChar).append(
            concernRoleEntObj.readConcernRoleName(concernRoleKey).concernRoleName);
          signedParticipantNames.append(CuramConst.gkComma);
          // END, CR00124499
        }

      }

      servicePlanContractFullDetails.signedByView = // Substring the
        // signedParticipantNames to
        // remove the comma at the
        // end.
        signedParticipantNames.toString().substring(0,
        signedParticipantNames.toString().length() - 1);
    }
    // END, CR00123092

    // Reads caseParticipantRoleID
    caseParticipantRoleCaseParticipantRoleID = caseParticipantRole.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // Assign caseParticipantRoleID to the return object
    servicePlanContractFullDetails.clientNameAndCPRoleID.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    // Assign full name of client to display on contract home page
    servicePlanContractFullDetails.clientNameAndCPRoleID.clientName = caseParticipantRole.readFullName(caseParticipantRoleKey).fullName;

    // Read the attachment details and return
    if (servicePlanContractFullDetails.dtls.attachmentID != 0) {

      final ReadAttachmentIn readAttachmentIn = new ReadAttachmentIn();

      readAttachmentIn.attachmentID = servicePlanContractFullDetails.dtls.attachmentID;
      servicePlanContractFullDetails.attachmentDetails = readContractAttachmentDetails(
        readAttachmentIn);

    }

    // if an address record for service plan contract exists, read its
    // details
    if (servicePlanContractFullDetails.dtls.addressID != 0) {

      // Address manipulation variables
      final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
      final curam.core.struct.AddressKey addressKey = new curam.core.struct.AddressKey();
      curam.core.struct.AddressDtls addressDtls;
      final OtherAddressData otherAddressData = new OtherAddressData();

      addressKey.addressID = servicePlanContractFullDetails.dtls.addressID;
      addressDtls = addressObj.read(addressKey);

      // BEGIN, CR00236131, SS
      // get address line one to use in the modify
      otherAddressData.addressData = addressDtls.addressData;
      servicePlanContractFullDetails.addressLine1 = addressObj.getFirstLine(otherAddressData).addressElementString;

      // Format the address to be displayed in single line.
      servicePlanContractFullDetails.formattedAddressData = ParticipantFactory.newInstance().displaySingleLineAddress(otherAddressData).addressString;
      // END, CR00236131

    }

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = servicePlanContractFullDetails.dtls.caseID;
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    // set security participant key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_VIEW_CONTRACT_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    return servicePlanContractFullDetails;

  }

  /**
   * Reads the complete details of the contract record including goal, sub goal
   * and plan item details.
   *
   * @param spContractKey
   * Identifies the Service Plan Contract record to be read.
   *
   * @return Complete Contract details.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_PREVIEW_CONTRACT_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to preview
   * the contract for this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public CompleteContractDetails readCompleteContract(
    curam.serviceplans.sl.struct.ServicePlanContractKey spContractKey)
    throws AppException, InformationalException {

    // Manipulation Variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = ServicePlanContractFactory.newInstance();
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CompleteContractDetails completeContractDetails = new CompleteContractDetails();
    final PlannedGoalIDandRecordStatusKey plannedGoalIDandRecordStatusKey = new PlannedGoalIDandRecordStatusKey();

    PlannedSubGoalDetailsForContractList plannedSubGoalDetailsForContractList = new PlannedSubGoalDetailsForContractList();

    final ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();

    servicePlanContractKey.servicePlanContractID = spContractKey.servicePlanContractID;

    // read CaseID of contract
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // Set the case id
    servicePlanDeliveryKey.caseID = servicePlanContractObj.readCaseIDDateClientNameAndSSN(servicePlanContractKey).caseID;

    // Set contract date, client name and Client's SSN
    completeContractDetails.clientName = servicePlanContractObj.readCaseIDDateClientNameAndSSN(servicePlanContractKey).fullName;
    completeContractDetails.contractDate = servicePlanContractObj.readCaseIDDateClientNameAndSSN(servicePlanContractKey).contractDate;
    completeContractDetails.ssnNumber = servicePlanContractObj.readCaseIDDateClientNameAndSSN(servicePlanContractKey).ssnNumber;
    final SubGoalKey subGoalKey = new SubGoalKey();
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();
    // Set Planned Goal name (method already exist)
    final ReadGoalNameByCaseIDKey readGoalNameByCaseIDKey = new ReadGoalNameByCaseIDKey();

    readGoalNameByCaseIDKey.caseID = servicePlanDeliveryKey.caseID;

    boolean servicePlanGoalInd = true;

    try {
      completeContractDetails.plannedGoalName = // BEGIN, CR00163098, JC
        CodeTable.getOneItem(GOALNAME.TABLENAME,
        plannedGoalObj.readNameByCaseID(readGoalNameByCaseIDKey).name,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } catch (final curam.util.exception.RecordNotFoundException e) {
      servicePlanGoalInd = false;
    }

    // BEGIN, CR00123092, ANK
    // Read Service Plan Signatories list
    final ServicePlanContractFullDetails servicePlanContractFullDetails = new ServicePlanContractFullDetails();

    servicePlanContractFullDetails.dtls = servicePlanContractObj.read(
      servicePlanContractKey);
    final StringList tabbedParticipantsList = StringUtil.tabText2StringListWithTrim(
      servicePlanContractFullDetails.dtls.signedBy);
    final ConcernRole concernRoleEntObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = null;

    if (tabbedParticipantsList != null && tabbedParticipantsList.size() > 0) {

      // Get a named list of participants
      // Get the Comma separated ConcernRole names for signed by details
      final int size = tabbedParticipantsList.size();

      for (int i = 0; i < size; i++) {
        concernRoleKey = new ConcernRoleKey();
        if (tabbedParticipantsList.item(i).trim().length() > 0) {
          concernRoleKey.concernRoleID = Long.parseLong(
            tabbedParticipantsList.item(i));
          completeContractDetails.servicePlanSignatories.concernRoleList.addRef(
            concernRoleEntObj.readConcernRoleName(concernRoleKey));
        }
      }
    }
    // END, CR00123092

    // only search if planned goal exits
    if (servicePlanGoalInd) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

      // Read Planned GoalID and Goal Contract Text by case id
      PlannedGoalIDAndContractText plannedGoalIDAndContractText;
      final ReadPlannedGoalIDAndGoalTextByCaseIDKey readPlannedGoalIDAndGoalTextByCaseIDKey = new ReadPlannedGoalIDAndGoalTextByCaseIDKey();

      readPlannedGoalIDAndGoalTextByCaseIDKey.caseID = servicePlanDeliveryKey.caseID;

      // set concern role id
      readPlannedGoalIDAndGoalTextByCaseIDKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

      // BEGIN, CR00277773, ELG
      plannedGoalIDAndContractText = plannedGoalObj.readIDAndGoalContractTextByCaseID1(
        readPlannedGoalIDAndGoalTextByCaseIDKey);
      // END, CR00277773

      // Set values
      completeContractDetails.goalContractText = plannedGoalIDAndContractText.goalContractText;

      plannedGoalIDandRecordStatusKey.concernRoleID = readPlannedGoalIDAndGoalTextByCaseIDKey.concernRoleID;
      plannedGoalIDandRecordStatusKey.plannedGoalID = plannedGoalIDAndContractText.plannedGoalID;
      plannedGoalIDandRecordStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      plannedSubGoalDetailsForContractList = plannedSubGoalObj.searchSubGoalDetailsByPlannedGoalID(
        plannedGoalIDandRecordStatusKey);

      // PlannedSubGoalDetailsListForContract-> A struct that contains:
      // - flat struct which will contain sugGoal details, i.e. name, text
      // and gaolID
      // - a list struct which will contains a list of all planItems for
      // this subGoal

      // For each sub goal - get the list of planItems.
      for (int i = 0; i < plannedSubGoalDetailsForContractList.dtls.size(); i++) {

        final PlannedSubGoalDetailsListForContract plannedSubGoalDetailsListForContract = new PlannedSubGoalDetailsListForContract();

        // Read the Sub Goal Name description and not the codetable
        // value
        // to be displayed on the contract been viewed.
        plannedSubGoalKey.plannedSubGoalID = plannedSubGoalDetailsForContractList.dtls.item(i).plannedSubGoalID;
        // subGoalKey.subGoalID
        final ReadSubGoalIDByPlannedSubGoal readSubGoalIDByPlannedSubGoal = plannedSubGoalObj.readSubGoalIDByPlannedSubGoalID(
          plannedSubGoalKey);

        subGoalKey.subGoalID = readSubGoalIDByPlannedSubGoal.subGoalID;

        // Set the description sub goal name
        plannedSubGoalDetailsForContractList.dtls.item(i).subGoalName = // BEGIN,
          // CR00163098,
          // JC
          CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
          subGoalObj.read(subGoalKey).name, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        // Assign subGoal details
        plannedSubGoalDetailsListForContract.plannedSubGoalDetails = plannedSubGoalDetailsForContractList.dtls.item(
          i);

        // BEGIN, CR00052872 MC
        // BEGIN,HARP 67384,SK
        plannedSubGoalDetailsListForContract.plannedSubGoalDetails.subGoalTypeName = // BEGIN, CR00163098, JC
          CodeTable.getOneItem(
          SUBGOALTYPE.TABLENAME,
          plannedSubGoalDetailsListForContract.plannedSubGoalDetails.subGoalType,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
        // END,HARP 67384
        // END, CR00052872

        // Get list of subGoals for goal
        plannedSubGoalDetailsListForContract.planItemDtlsForContract = plannedItemObj.searchDetailsForContractByPlannedSubGoalID(
          plannedSubGoalKey);

        // BEGIN, CR00052872 MC
        // BEGIN,HARP 67384,SK
        PlannedItemIDAndContractTextDetailsList plannedItemIDAndContractTextDetails;

        final PlannedSubGoalIDAndConcernRoleKey plannedSubGoalIDAndConcernRoleKey = new PlannedSubGoalIDAndConcernRoleKey();

        plannedSubGoalIDAndConcernRoleKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
        plannedSubGoalIDAndConcernRoleKey.plannedSubGoalID = plannedSubGoalKey.plannedSubGoalID;

        // BEGIN, CR00287219, ELG
        plannedItemIDAndContractTextDetails = plannedItemObj.searchContractTextByPlannedSubGoalAndParticipant(
          plannedSubGoalIDAndConcernRoleKey);
        // END, CR00287219

        for (int j = 0; j < plannedItemIDAndContractTextDetails.dtls.size(); j++) {

          completeContractDetails.planItemContractText = plannedItemIDAndContractTextDetails.dtls.item(j).planItemContractText;

          plannedSubGoalDetailsListForContract.planItemDtlsForContract.dtls.item(j).planItemContractText = plannedItemIDAndContractTextDetails.dtls.item(j).planItemContractText;
        }
        completeContractDetails.contractTextDtls.subGoalDtlsForContractList.addRef(
          plannedSubGoalDetailsListForContract);
        // END,HARP 67384
        // END, CR00052872
        // Check to see what TYPE the sub is and assign to appropriate
        // list
        if (plannedSubGoalDetailsListForContract.plannedSubGoalDetails.subGoalType.equals(
          SUBGOALTYPE.OBJECTIVE)) {
          // Add SubGoal record to list of subGoals returned for goal
          completeContractDetails.ObjectiveSubGoalDetails.subGoalDtlsForContractList.addRef(
            plannedSubGoalDetailsListForContract);
        } else if (plannedSubGoalDetailsListForContract.plannedSubGoalDetails.subGoalType.equals(
          SUBGOALTYPE.BARRIER)) {
          // Add SubGoal record to list of subGoals returned for goal
          completeContractDetails.BarrierSubGoalDetails.subGoalDtlsForContractList.addRef(
            plannedSubGoalDetailsListForContract);
        } else if (plannedSubGoalDetailsListForContract.plannedSubGoalDetails.subGoalType.equals(
          SUBGOALTYPE.NEED)) {
          // Add SubGoal record to list of subGoals returned for goal
          completeContractDetails.NeedSubGoalDetails.subGoalDtlsForContractList.addRef(
            plannedSubGoalDetailsListForContract);
          // BEGIN, CR00052872 MC
          // BEGIN,HARP 67384,SK
        } else {
          // Add SubGoal record to list of subGoals returned for goal
          completeContractDetails.OtherSubGoalDetails.subGoalDtlsForContractList.addRef(
            plannedSubGoalDetailsListForContract);

        }
        // END,HARP 67384
        // END, CR00052872

      }
    }
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = servicePlanDeliveryKey.caseID;

    // Assign the case reference of the service plan.
    completeContractDetails.caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanContractSensitivityCodeDetails servicePlanContractSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();

    servicePlanContractSensitivityCodeDetails.sensitivityCode = servicePlanContractObj.readSensitivityCode(servicePlanContractKey).sensitivityCode;

    // Check security if user against that of the contract.
    try {
      servicePlanSecurity.contractSensitivityCheck(
        servicePlanContractSensitivityCodeDetails);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_CONTRACT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_PREVIEW_CONTRACT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    return completeContractDetails;

  }

  // ___________________________________________________________________________
  /**
   * Validates that the list of plan participants can be viewed.
   *
   * @param servicePlanDeliveryKey
   * Identifies the Service Plan Contract record to be read.
   */
  @Override
  public void validateListParticipantsToIssueContractTo(
    curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();

    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // case header object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CheckMultipleContractDetails checkMultipleContractDetails = new CheckMultipleContractDetails();

    checkMultipleContractDetails.caseID = servicePlanDeliveryKey.key.caseID;
    checkMultipleContractDetails.contractStatus = SERVICEPLANCONTRACTSTATUS.ISSUED;

    // This check is done when modifying and inserting contracts, so errors
    // will
    // be slightly different. So pass in boolean to tell if on insertion or
    // modification of contract
    checkMultipleContractDetails.insertingContractInd = true;

    // Ensure that multiple contracts are allowed.
    servicePlanContractObj.checkForMultipleContracts(
      checkMultipleContractDetails);

    // Ensure service plan is not closed
    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;
    final CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(
      caseHeaderKey);

    // If closed than return error.
    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CREATE_CONTRACT_RV_SERPLAN_MUST_NOT_BE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // Ensure that the service plan delivery must be of type
    // active or approved

    // If not active or approved than return error.

    if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
      && !caseStatusCode.statusCode.equals(CASESTATUS.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_RV_SERPLAN_MUST_BE_ACTIVE_OR_APPROVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // Ensure that no planItems with status unapproved or submitted exist
    // for the service plan.
    final CountAllUnapprovAndSubmittedForServPlanKey countAllUnapprovAndSubmittedForServPlanKey = new CountAllUnapprovAndSubmittedForServPlanKey();

    countAllUnapprovAndSubmittedForServPlanKey.caseID = servicePlanDeliveryKey.key.caseID;

    countAllUnapprovAndSubmittedForServPlanKey.planItemStatusSubmitted = PLANNEDITEMSTATUS.SUBMITTED;

    countAllUnapprovAndSubmittedForServPlanKey.planItemStatusUnapproved = PLANNEDITEMSTATUS.UNAPPROVED;

    final RecordCount recordCount = new RecordCount();

    recordCount.count = plannedItemObj.countAllUnapprovAndSubmittedForServPlan(countAllUnapprovAndSubmittedForServPlanKey).recordCount;

    if (recordCount.count > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XRV_PLANITEMS_STILL_REQUIRE_APPROVAL),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to insert attachment for a service plan contract
   *
   * @param details
   * Details of the attachment to be created.
   *
   * @return attachment and attachment link identifiers
   */
  @Override
  public CreateContractAttachmentKey insertContractAttachment(
    curam.core.struct.CreateCaseAttachmentDetails details)
    throws AppException, InformationalException {

    // Output structure
    final CreateContractAttachmentKey createContractAttachmentKey = new CreateContractAttachmentKey();

    final curam.core.intf.MaintainAttachmentAssistant maintainAttachmentAssistantObj = curam.core.fact.MaintainAttachmentAssistantFactory.newInstance();

    // attachment entity, dtls structure

    final AttachmentDtls attachmentDtls = new AttachmentDtls();

    // attachmentNameStruct struct
    final AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();

    final boolean atachmentNameProvided = details.newCaseAttachmentName.length()
      != 0;

    if (atachmentNameProvided) {
      attachmentNameStruct.attachmentName = details.newCaseAttachmentName;

      // parse attachmentName from path of attachment, leaving just the
      // base
      // name
      maintainAttachmentAssistantObj.parseAttachmentFileName(
        attachmentNameStruct);

      if (attachmentNameStruct.attachmentName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_NAME_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            3);
      }
    }

    // BEGIN, CR00002547, CSH
    // Set an indicator to check both location and reference have been entered
    final boolean locationANDReferenceProvided = details.filelocation.length()
      != 0
        && details.fileReference.length() != 0;

    // Either a file name or location and reference must be entered
    if (details.newCaseAttachmentContents.length() == 0
      && !locationANDReferenceProvided) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_EMPTY_FILE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00002547

    // insert attachment details

    attachmentDtls.attachmentStatus = curam.codetable.ATTACHMENTSTATUS.ACTIVE;

    attachmentDtls.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    attachmentDtls.attachmentName = attachmentNameStruct.attachmentName;

    if (attachmentDtls.attachmentName.length() > 0) {
      attachmentDtls.attachedFileInd = true;
    }

    attachmentDtls.attachmentContents = details.newCaseAttachmentContents;

    attachmentDtls.fileLocation = details.filelocation;
    attachmentDtls.fileReference = details.fileReference;

    // BEGIN, CR00354960, CD
    // set up some meta data about the attachment
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    // Note: this is really a participant identifier so this is not mixing ids
    cmsMetadata.add(CMSMetadataConst.kParticipantID,
      Long.toString(details.caseParticipantRoleID));
    // END, CR00354960

    attachment.insert(attachmentDtls);

    // BEGIN, CR00155031, MC
    createContractAttachmentKey.attachmentID = attachmentDtls.attachmentID;
    // END, CR00155031

    return createContractAttachmentKey;

  }

  // ___________________________________________________________________________
  /**
   * Method to read attachment for a service plan contract
   *
   * @param key
   * AttachmentID for attachment to be read.
   *
   * @return attachment details.
   */
  @Override
  public ContractAttachmentDetails readContractAttachmentDetails(
    ReadAttachmentIn key) throws AppException, InformationalException {

    final ContractAttachmentDetails contractAttachmentDetails = new ContractAttachmentDetails();

    // attachment entity, dtls, key

    final AttachmentKey AttachmentKey = new AttachmentKey();

    AttachmentKey.attachmentID = key.attachmentID;

    AttachmentDtls attachmentDtls;

    // read attachment details
    attachmentDtls = attachment.read(AttachmentKey);

    // populate attachmentDtls in dtls
    contractAttachmentDetails.attachedFileInd = attachmentDtls.attachedFileInd;
    contractAttachmentDetails.attachmentContents = attachmentDtls.attachmentContents;
    contractAttachmentDetails.attachmentID = attachmentDtls.attachmentID;
    contractAttachmentDetails.fileLocation = attachmentDtls.fileLocation;
    contractAttachmentDetails.fileReference = attachmentDtls.fileReference;
    contractAttachmentDetails.attachmentName = attachmentDtls.attachmentName;

    return contractAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to read attachment for a service plan contract
   *
   * @param details
   * AttachmentID for attachment to be read.
   */
  @Override
  public void modifyContractAttachment(ContractAttachmentDetails details)
    throws AppException, InformationalException {//
  }

  // ___________________________________________________________________________
  /**
   * Method to the highest sensitivity value of a subgoal or planned item
   * associated to a specific service plan delivery
   *
   * @param key servicePlanDeliveryID of a service plan delivery.
   *
   * @return Service Plan Contract Sensitivity Code Details.
   */
  @Override
  public ServicePlanContractSensitivityCodeDetails getContractSensitivity(
    curam.serviceplans.sl.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return structure
    final ServicePlanContractSensitivityCodeDetails servicePlanContractSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();

    // Manipulation Variables
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    final PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();

    plannedGoalCaseIDKey.caseID = key.key.caseID;
    final PlannedGoalKey plannedGoalKey = new PlannedGoalKey();
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // Have to read all subGoal for the service plan delivery
    // First read the goal for service plan delivery and if no goal exists
    // return
    boolean servicePlanGoalInd = true;
    PlannedSubGoalIDandSensitivityDetailsList plannedSubGoalIDandSensitivityDetailsList;
    final ServicePlanContractSensitivityCodeDetails maxSubGoalSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();
    final ServicePlanContractSensitivityCodeDetails maxPlanItemSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();

    try {
      plannedGoalObj.readPlannedGoalIDByCaseID(plannedGoalCaseIDKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      servicePlanGoalInd = false;
    }

    servicePlanContractSensitivityCodeDetails.sensitivityCode = SENSITIVITY.MINIMUM;
    // if no goal exists - return minimum sensitivity
    if (!servicePlanGoalInd) {

      return servicePlanContractSensitivityCodeDetails;
    } else {
      // get list of sub goals for goal and if max sensitivity found
      // return
      plannedGoalKey.plannedGoalID = plannedGoalObj.readPlannedGoalIDByCaseID(plannedGoalCaseIDKey).plannedGoalID;
      plannedSubGoalIDandSensitivityDetailsList = plannedSubGoalObj.searchSubGoalSensitivityDetailsByPlannedGoalID(
        plannedGoalKey);

      if (plannedSubGoalIDandSensitivityDetailsList.dtls.size() > 0) {

        // ordered the list by the highest so if highest is set to max
        // then return it
        // else take note of the highest and then return.
        if (plannedSubGoalIDandSensitivityDetailsList.dtls.item(0).sensitivityCode.equals(
          SENSITIVITY.MAXIMUM)) {
          servicePlanContractSensitivityCodeDetails.sensitivityCode = SENSITIVITY.MAXIMUM;
          return servicePlanContractSensitivityCodeDetails;

          // Have to check all plan item sensitivity to see if they
          // higher than the subgoal one
        } else {

          // Set the highest sensitivity so far - i.e. sub goal
          // sensitivity
          maxSubGoalSensitivityCodeDetails.sensitivityCode = plannedSubGoalIDandSensitivityDetailsList.dtls.item(0).sensitivityCode;

          maxPlanItemSensitivityCodeDetails.sensitivityCode = SENSITIVITY.MINIMUM;

          // List through all planItems for each sub goal and get
          // highest sensitivity
          for (int i = 0; i
            < plannedSubGoalIDandSensitivityDetailsList.dtls.size(); i++) {
            final ServicePlanContractSensitivityCodeDetails tmpPlanItemSensitivityCodeDetails = new ServicePlanContractSensitivityCodeDetails();

            plannedSubGoalKey.plannedSubGoalID = plannedSubGoalIDandSensitivityDetailsList.dtls.item(0).plannedSubGoalID;

            final PlannedItemSensitivityDetailsList plannedItemSensitivityDetailsList = plannedItemObj.searchSensitivityCodeDetailsByPlannedSubGoalID(
              plannedSubGoalKey);

            if (plannedItemSensitivityDetailsList.dtls.size() > 0) {

              // if plan item sensitivity set to max - return it
              if (plannedItemSensitivityDetailsList.dtls.item(0).sensitivityCode.equals(
                SENSITIVITY.MAXIMUM)) {
                servicePlanContractSensitivityCodeDetails.sensitivityCode = plannedItemSensitivityDetailsList.dtls.item(0).sensitivityCode;
                return servicePlanContractSensitivityCodeDetails;

              } else {
                tmpPlanItemSensitivityCodeDetails.sensitivityCode = plannedItemSensitivityDetailsList.dtls.item(0).sensitivityCode;

                // Check to see if temp plan item sensitivity is
                // here than one before and if so set it
                // to new max plan item sensitivity
                if (Integer.parseInt(
                  tmpPlanItemSensitivityCodeDetails.sensitivityCode)
                    > Integer.parseInt(
                      maxPlanItemSensitivityCodeDetails.sensitivityCode)) {
                  maxPlanItemSensitivityCodeDetails.sensitivityCode = tmpPlanItemSensitivityCodeDetails.sensitivityCode;
                }
              } // end else
            } // end if plan item list size > 0
          } // end for loop through planItems

          // Check to see if plan item or sub goal sensitivity is
          // higher and if so return
          if (Integer.parseInt(maxSubGoalSensitivityCodeDetails.sensitivityCode)
            > Integer.parseInt(
              maxPlanItemSensitivityCodeDetails.sensitivityCode)) {

            return maxSubGoalSensitivityCodeDetails;
          } else {
            return maxPlanItemSensitivityCodeDetails;
          }

        } // end else
      }

    }
    return servicePlanContractSensitivityCodeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to the read caseID for contract
   *
   * @param key
   * ServicePlanContractKey of a service plan contract.
   *
   * @return Service Plan Contract case id.
   */
  @Override
  public curam.serviceplans.sl.struct.ServicePlanDeliveryKey readCaseID(
    curam.serviceplans.sl.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();

    // Create return struct
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey returnServicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    final ServicePlanContractKey servicePlanContractKey = new curam.serviceplans.sl.entity.struct.ServicePlanContractKey();

    servicePlanContractKey.servicePlanContractID = key.servicePlanContractID;

    returnServicePlanDeliveryKey.key.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey).caseID;

    return returnServicePlanDeliveryKey;
  }
}
