/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2005,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANITEMTYPE;
import curam.codetable.PLANNEDSUBGOALSTATUS;
import curam.codetable.SUBGOALTYPE;
import curam.codetable.impl.LOCALEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ServicePlanGanttConst;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.BPOTRACKINGGANTT;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedGroupFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedGroup;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.intf.SPMilestoneDeliveryLink;
import curam.serviceplans.sl.entity.intf.ServicePlanGroup;
import curam.serviceplans.sl.entity.struct.IntegratedCaseIDKey;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalAndSensitivityCodeKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupAndSensitivityKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupDetailsForGantt;
import curam.serviceplans.sl.entity.struct.PlannedGroupDetailsForGanttList;
import curam.serviceplans.sl.entity.struct.PlannedGroupKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDetailsForTracknGanttList;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDStatus;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalAndSensitivityCode;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForTrackGantt;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForTrackGanttList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalStatus;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalStatusList;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.TrackingGanttGoalDetails;
import curam.serviceplans.sl.entity.struct.TrackingGanttMilestoneDetails;
import curam.serviceplans.sl.entity.struct.TrackingGanttMilestoneDetails1;
import curam.serviceplans.sl.entity.struct.TrackingGanttMilestoneDetails1List;
import curam.serviceplans.sl.entity.struct.TrackingGanttMilestoneDetailsList;
import curam.serviceplans.sl.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.serviceplans.sl.struct.ReadTrackingGanttDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanForICList;
import curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey;
import curam.serviceplans.sl.struct.ServicePlanParticipantSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanTrackGanttDetails;
import curam.serviceplans.sl.struct.ServicePlanTrackingGanttDetails;
import curam.serviceplans.sl.struct.TrackingGanttGroupDetails;
import curam.serviceplans.sl.struct.TrackingGanttGroupKey;
import curam.serviceplans.sl.struct.TrackingGanttIntegratedDetails;
import curam.serviceplans.sl.struct.TrackingGanttIntegratedKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.Locale;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * This process class provides the functionality for the Tracking Gantt service
 * layer.
 */
public abstract class TrackingGantt extends curam.serviceplans.sl.base.TrackingGantt {

  // BEGIN, CR00236426, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public TrackingGantt() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00236426

  // BEGIN, CR00161962, LJ
  protected static final String kIntegrated = ServicePlanGanttConst.kIntegrated;

  protected static final String kIntegratedType = ServicePlanGanttConst.kIntegratedType;

  protected static final String kIntegratedName = ServicePlanGanttConst.kIntegratedName;

  protected static final String kGroup = ServicePlanGanttConst.kGroup;

  protected static final String kGroupType = ServicePlanGanttConst.kGroupType;

  protected static final String kSPType = ServicePlanGanttConst.kSPType;

  protected static final String kStatus = ServicePlanGanttConst.kStatus;

  // END, CR00161962

  protected static final String kGantt = ServicePlanGanttConst.kGantt;

  protected static final String kPlannedGoal = ServicePlanGanttConst.kPlannedGoal;

  protected static final String kView = ServicePlanGanttConst.kView;

  protected static final String kOpen = ServicePlanGanttConst.kOpen;

  protected static final String kClosed = ServicePlanGanttConst.kClosed;

  protected static final String kSubGoal = ServicePlanGanttConst.kPlannedSubGoal;

  protected static final String kPlanGroup = ServicePlanGanttConst.kPlannedGroup;

  protected static final String kPlanGroupType = ServicePlanGanttConst.kPlanGroupType;

  protected static final String kPlanItem = ServicePlanGanttConst.kPlanItem;

  protected static final String kServiceUnitDelivery = ServicePlanGanttConst.kServiceUnitDelivery;

  protected static final String kMilestone = ServicePlanGanttConst.kMilestone;

  protected static final String kType = ServicePlanGanttConst.kType;

  protected static final String kID = ServicePlanGanttConst.kID;

  protected static final String kName = ServicePlanGanttConst.kName;

  protected static final String kTopStart = ServicePlanGanttConst.kTopStart;

  protected static final String kTopEnd = ServicePlanGanttConst.kTopEnd;

  protected static final String kBottomStart = ServicePlanGanttConst.kBottomStart;

  protected static final String kBottomEnd = ServicePlanGanttConst.kBottomEnd;

  protected static final String kReceivedUnits = ServicePlanGanttConst.kReceivedUnits;

  protected static final String kAuthorizedUnits = ServicePlanGanttConst.kAuthorizedUnits;

  protected static final String kDate = ServicePlanGanttConst.kDate;

  protected static final String kUnits = ServicePlanGanttConst.kUnits;

  protected static final String kUnitType = ServicePlanGanttConst.kUnitType;

  // BEGIN, CR00052924, GM
  protected static final String kEmptyDate = CuramConst.gkEmpty;

  // END, CR00052924
  protected static final String kContentType = ServicePlanGanttConst.kContentType;

  protected static final String kPlanGroupContentType = ServicePlanGanttConst.kPlanGroupContentType;

  protected static final String kCaseID = ServicePlanGanttConst.kCaseID;

  // BEGIN, CR00052681, NRV
  // END, CR00069996
  // START,HARP 69118, SK
  protected static final String kGanttDateFormat = curam.util.resources.Locale.Date_ymd_ext;

  // END,HARP 69118
  // END, CR00052681

  // BEGIN, CR00118825, MC
  protected static final String kFrequency = ServicePlanGanttConst.kfrequency;

  protected static final String kParticipantName = ServicePlanGanttConst.kParticipantName;

  // END, CR00118825

  // ___________________________________________________________________________

  /**
   * Creates the XML string for the Tracking Gantt.
   *
   * @param details
   * Details required to create the tracking Gantt XML String.
   *
   * @return The created XML String to be displayed on the Gantt diagram.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public ServicePlanTrackGanttDetails createTrackingGanttXmlDetails(
    final ReadTrackingGanttDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00161962, LJ
    // Create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    // Create goal element
    final Element goalElement = createGoalXML(details, true);

    ganttElement.addContent(goalElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    final ServicePlanTrackGanttDetails servicePlanTrackGanttDetails = new ServicePlanTrackGanttDetails();

    servicePlanTrackGanttDetails.trackGanttXmlString = outputter.outputString(
      ganttElement);

    return servicePlanTrackGanttDetails;
    // END, CR00161962
  }

  /**
   * Views the Tracking Gantt Details for a Service Plan Delivery.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details in form of XML string to be displayed as Gantt diagram.
   */
  @Override
  public ServicePlanTrackGanttDetails viewTrackingGantt(
    final ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00161962, LJ
    // Read tracking gantt details
    final ReadTrackingGanttDetails readTrackingGanttDetails = readTrackingGanttDetails(
      key);

    // Create XML details to be returned
    final ServicePlanTrackGanttDetails servicePlanTrackGanttDetails = createTrackingGanttXmlDetails(
      readTrackingGanttDetails);

    // Return XML details
    return servicePlanTrackGanttDetails;
    // END, CR00161962
  }

  // ___________________________________________________________________________

  /**
   * Reads the details required to create the XML string for the Tracking
   * Gantt.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details required to create the tracking Gantt XML string.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public ReadTrackingGanttDetails readTrackingGanttDetails(
    final ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00161962, LJ
    // Call the read method and allow exceptions to be thrown
    final ReadTrackingGanttDetails readTrackingGanttDetails = readTrackingGanttDetails(
      key, true);

    // Return details object
    return readTrackingGanttDetails;
    // END, CR00161962
  }

  // BEGIN, CR00161962, LJ
  /**
   * Views the Tracking Gantt Details for a Service Plan Group Delivery.
   *
   * @param trackingGanttGroupKey
   * Contains case ID of the service plan group delivery.
   *
   * @return Details in form of XML string to be displayed as Gantt diagram
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public ServicePlanTrackingGanttDetails viewGroupTrackingGantt(
    final TrackingGanttGroupKey trackingGanttGroupKey) throws AppException,
      InformationalException {

    // Read tracking gantt group details
    final TrackingGanttGroupDetails trackingGanttGroupDetails = readTrackingGanttGroupDetails(
      trackingGanttGroupKey);

    // Create XML details to be returned
    final ServicePlanTrackingGanttDetails servicePlanTrackGanttDetails = createTrackingGanttGroupXmlDetails(
      trackingGanttGroupDetails);

    // Return XML details
    return servicePlanTrackGanttDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Reads the details required to create the XML string for the Group
   * Tracking Gantt.
   *
   * @param trackingGanttGroupKey
   * Contains case ID of the service plan group delivery.
   *
   * @return Details required to create the tracking Gantt XML string.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public TrackingGanttGroupDetails readTrackingGanttGroupDetails(
    final TrackingGanttGroupKey trackingGanttGroupKey) throws AppException,
      InformationalException {

    // Read the Service Plan Group Delivery details based on the passed ID
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

    spgDeliveryKey.servicePlanGroupDeliveryId = trackingGanttGroupKey.groupDeliveryID;

    final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryObj.read(spgDeliveryKey);

    // Read the Service Plan Group Details
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = spgDeliveryDtls.servicePlanGroupId;

    final ServicePlanGroupDtls servicePlanGroupDtls = servicePlanGroupObj.read(
      servicePlanGroupKey);

    // Create the tracking Gantt group details object
    final TrackingGanttGroupDetails trackingGanttGroupDetails = new TrackingGanttGroupDetails();

    trackingGanttGroupDetails.groupDeliveryID = trackingGanttGroupKey.groupDeliveryID;
    trackingGanttGroupDetails.groupName = servicePlanGroupDtls.servicePlanGroupName;

    // Read the details of the associated service plans
    final SPGDeliveryLink spgDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();

    spgDeliveryKey = new SPGDeliveryKey();

    spgDeliveryKey.servicePlanGroupDeliveryId = trackingGanttGroupKey.groupDeliveryID;

    final SPGDeliveryLinkDtlsList spgDeliveryLinkDtlsList = spgDeliveryLinkObj.searchServicePlanDeliveriesByServicePlanGroupDeliveryId(
      spgDeliveryKey);

    // Setup date objects for expected / actual start and end
    Date expectedStartDate = Date.kZeroDate;
    Date expectedEndDate = Date.kZeroDate;
    Date actualStartDate = Date.kZeroDate;
    Date actualEndDate = Date.kZeroDate;

    // Loop around each of the associated service plans
    final int numberOfSPGDeliveries = spgDeliveryLinkDtlsList.dtls.size();

    final ServicePlanDeliveryKey serviceDeliveryKey = new ServicePlanDeliveryKey();

    for (int spgDeliveryCount = 0; spgDeliveryCount < numberOfSPGDeliveries; spgDeliveryCount++) {

      final SPGDeliveryLinkDtls spgDeliveryLinkDtls = spgDeliveryLinkDtlsList.dtls.item(
        spgDeliveryCount);

      serviceDeliveryKey.key.caseID = spgDeliveryLinkDtls.caseID;

      final ReadTrackingGanttDetails readTrackingGanttDetails = readTrackingGanttDetails(
        serviceDeliveryKey, false);

      // BEGIN, CR00234999, TV
      // Check if a record has been returned
      if (readTrackingGanttDetails.readTrackGanttGoalDetails.plannedGoalID != 0) {
        final Date goalExpectedStartDate = readTrackingGanttDetails.readTrackGanttGoalDetails.expectedStartDate;
        final Date goalExpectedEndDate = readTrackingGanttDetails.readTrackGanttGoalDetails.expectedEndDate;
        final Date goalActualStartDate = readTrackingGanttDetails.readTrackGanttGoalDetails.actualStartDate;
        final Date goalActualEndDate = readTrackingGanttDetails.readTrackGanttGoalDetails.actualEndDate;

        // END, CR00234999
        // Assign dates from each underlying service plan
        expectedStartDate = getEarliestDate(expectedStartDate,
          goalExpectedStartDate);
        expectedEndDate = getLatestDate(expectedEndDate, goalExpectedEndDate);

        actualStartDate = getEarliestDate(actualStartDate, goalActualStartDate);
        actualEndDate = getLatestDate(actualEndDate, goalActualEndDate);

        trackingGanttGroupDetails.detailsList.addRef(readTrackingGanttDetails);
      }
    }

    trackingGanttGroupDetails.expectedStartDate = expectedStartDate;
    trackingGanttGroupDetails.expectedEndDate = expectedEndDate;
    trackingGanttGroupDetails.actualStartDate = actualStartDate;
    trackingGanttGroupDetails.actualEndDate = actualEndDate;

    return trackingGanttGroupDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Creates the XML string for the Group Tracking Gantt.
   *
   * @param trackingGanttGroupDetails
   * Details required to create the tracking Gantt XML String.
   *
   * @return The created XML String to be displayed on the Gantt diagram.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public ServicePlanTrackingGanttDetails createTrackingGanttGroupXmlDetails(
    final TrackingGanttGroupDetails trackingGanttGroupDetails)
    throws AppException, InformationalException {

    // Create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    // Create service plan group element
    final Element groupElement = createGroupXML(trackingGanttGroupDetails);

    ganttElement.addContent(groupElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00229255 MN
    final ServicePlanTrackingGanttDetails servicePlanTrackGanttDetails = new ServicePlanTrackingGanttDetails();

    // END, CR00229225

    servicePlanTrackGanttDetails.newTrackGanttXmlString = outputter.outputString(
      ganttElement);

    return servicePlanTrackGanttDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * Views the Tracking Gantt Details for a Integrated Service Plan.
   *
   * @param trackingGanttIntegratedKey
   * Contains case ID of the integrated service plan.
   *
   * @return Details in form of XML string to be displayed as Gantt diagram.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public ServicePlanTrackingGanttDetails viewIntegratedTrackingGantt(
    final TrackingGanttIntegratedKey trackingGanttIntegratedKey)
    throws AppException, InformationalException {

    // Read tracking gantt group details
    final TrackingGanttIntegratedDetails trackingGanttIntegratedDetails = readTrackingGanttIntegratedDetails(
      trackingGanttIntegratedKey);

    // BEGIN, CR00229255 MN
    // Create XML details to be returned
    final ServicePlanTrackingGanttDetails servicePlanTrackGanttDetails = createTrackingGanttIntegratedXmlDetails(
      trackingGanttIntegratedDetails);

    // END, CR00229225
    // Return XML details
    return servicePlanTrackGanttDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Reads the details required to create the XML string for the Integrated
   * Tracking Gantt.
   *
   * @param trackingGanttIntegratedKey
   * Contains case ID of the integrated service plan.
   *
   * @return Details required to create the tracking Gantt XML string.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public TrackingGanttIntegratedDetails readTrackingGanttIntegratedDetails(
    final TrackingGanttIntegratedKey trackingGanttIntegratedKey)
    throws AppException, InformationalException {

    // Find all associated service plans with 'Integrated Service Plan'
    // a.k.a. 'Integrated Case'
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = trackingGanttIntegratedKey.integratedCaseID;

    final ServicePlanForICList servicePlanForICList = servicePlanDeliveryObj.listByIntegratedCase(
      servicePlanIntegratedCaseKey);

    // Put all found values into map
    final Map<Long, ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanMap = new HashMap<Long, ServicePlanDeliveryAndParticipantSummaryDetails>();

    final int numberOfServicePlans = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      final ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDetails = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.item(
        servicePlanCount);

      servicePlanMap.put(servicePlanDetails.caseID, servicePlanDetails);
    }

    final TrackingGanttIntegratedDetails trackingGanttIntegratedDetails = readTrackingGanttIntegratedDetails(
      trackingGanttIntegratedKey, servicePlanMap);

    return trackingGanttIntegratedDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * @param trackingGanttIntegratedKey
   * Contains case ID of the integrated service plan.
   * @param servicePlanMap
   * Service Plan Delivery Participant details.
   * @return Details required to create the tracking Gantt XML string.
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected TrackingGanttIntegratedDetails readTrackingGanttIntegratedDetails(
    final TrackingGanttIntegratedKey trackingGanttIntegratedKey,
    final Map<Long, ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanMap)
    throws AppException, InformationalException {

    // END, CR00198672
    int numberOfServicePlans;
    // Create return object
    final TrackingGanttIntegratedDetails trackingGanttIntegratedDetails = new TrackingGanttIntegratedDetails();

    trackingGanttIntegratedDetails.integratedCaseID = trackingGanttIntegratedKey.integratedCaseID;

    // Setup date objects for expected / actual start and end
    Date expectedStartDate = Date.kZeroDate;
    Date expectedEndDate = Date.kZeroDate;
    Date actualStartDate = Date.kZeroDate;
    Date actualEndDate = Date.kZeroDate;

    // Find all associated service plan groups
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    final IntegratedCaseIDKey caseHeaderKey = new IntegratedCaseIDKey();

    caseHeaderKey.integratedCaseID = trackingGanttIntegratedKey.integratedCaseID;

    final SPGDeliveryDtlsList spgDeliveryDtlsList = spgDeliveryObj.searchByIntegratedCaseId(
      caseHeaderKey);

    final int numberOfSPGDeliveries = spgDeliveryDtlsList.dtls.size();

    for (int spgDeliveryCount = 0; spgDeliveryCount < numberOfSPGDeliveries; spgDeliveryCount++) {
      // Read the group details and add to return object.
      final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryDtlsList.dtls.item(
        spgDeliveryCount);

      final TrackingGanttGroupKey trackingGanttGroupKey = new TrackingGanttGroupKey();

      trackingGanttGroupKey.groupDeliveryID = spgDeliveryDtls.servicePlanGroupDeliveryId;

      final TrackingGanttGroupDetails trackingGanttGroupDetails = readTrackingGanttGroupDetails(
        trackingGanttGroupKey);

      final Date groupExpectedStartDate = trackingGanttGroupDetails.expectedStartDate;
      final Date groupExpectedEndDate = trackingGanttGroupDetails.expectedEndDate;
      final Date groupActualStartDate = trackingGanttGroupDetails.actualStartDate;
      final Date groupActualEndDate = trackingGanttGroupDetails.actualEndDate;

      // Assign dates from each underlying service plan group
      expectedStartDate = getEarliestDate(expectedStartDate,
        groupExpectedStartDate);
      expectedEndDate = getLatestDate(expectedEndDate, groupExpectedEndDate);

      actualStartDate = getEarliestDate(actualStartDate, groupActualStartDate);
      actualEndDate = getLatestDate(actualEndDate, groupActualEndDate);

      trackingGanttIntegratedDetails.groupDetailsList.addRef(
        trackingGanttGroupDetails);

      // Remove any service plans within group from main list.
      numberOfServicePlans = trackingGanttGroupDetails.detailsList.size();

      for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
        final ReadTrackingGanttDetails readTrackingGanttDetails = trackingGanttGroupDetails.detailsList.item(
          servicePlanCount);

        // BEGIN, CR00234999, TV
        if (servicePlanMap.containsKey(
          readTrackingGanttDetails.readTrackGanttGoalDetails.caseID)) {
          servicePlanMap.remove(
            readTrackingGanttDetails.readTrackGanttGoalDetails.caseID);
          // END, CR00234999
        }
      }
    }

    // Add remaining service plans in list to return object.
    final Iterator<ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanIterator = servicePlanMap.values().iterator();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    while (servicePlanIterator.hasNext()) {

      final ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDetails = servicePlanIterator.next();

      servicePlanDeliveryKey.key.caseID = servicePlanDetails.caseID;

      final ReadTrackingGanttDetails readTrackingGanttDetails = readTrackingGanttDetails(
        servicePlanDeliveryKey, false);

      // BEGIN, CR00234999, TV
      // Check if a record has been returned
      if (readTrackingGanttDetails.readTrackGanttGoalDetails.plannedGoalID != 0) {
        final Date deliveryExpectedStartDate = readTrackingGanttDetails.readTrackGanttGoalDetails.expectedStartDate;
        final Date deliveryExpectedEndDate = readTrackingGanttDetails.readTrackGanttGoalDetails.expectedEndDate;
        final Date deliveryActualStartDate = readTrackingGanttDetails.readTrackGanttGoalDetails.actualStartDate;
        final Date deliveryActualEndDate = readTrackingGanttDetails.readTrackGanttGoalDetails.actualEndDate;

        // END, CR00234999
        // Assign dates from each underlying service plan group
        expectedStartDate = getEarliestDate(expectedStartDate,
          deliveryExpectedStartDate);
        expectedEndDate = getLatestDate(expectedEndDate,
          deliveryExpectedEndDate);

        actualStartDate = getEarliestDate(actualStartDate,
          deliveryActualStartDate);
        actualEndDate = getLatestDate(actualEndDate, deliveryActualEndDate);

        trackingGanttIntegratedDetails.detailsList.addRef(
          readTrackingGanttDetails);
      }
    }

    trackingGanttIntegratedDetails.expectedStartDate = expectedStartDate;
    trackingGanttIntegratedDetails.expectedEndDate = expectedEndDate;
    trackingGanttIntegratedDetails.actualStartDate = actualStartDate;
    trackingGanttIntegratedDetails.actualEndDate = actualEndDate;
    return trackingGanttIntegratedDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Creates the XML string for the Integrated Tracking Gantt.
   *
   * @param trackingGanttIntegratedDetails
   * Details required to create the tracking Gantt XML String.
   *
   * @return The created XML String to be displayed on the Gantt diagram.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public ServicePlanTrackingGanttDetails createTrackingGanttIntegratedXmlDetails(
    final TrackingGanttIntegratedDetails trackingGanttIntegratedDetails)
    throws AppException, InformationalException {

    // Create the integrated service plan element
    final Element integratedElement = new Element(kIntegrated);

    integratedElement.setAttribute(kType, kIntegratedType);

    integratedElement.setAttribute(kID,
      String.valueOf(trackingGanttIntegratedDetails.integratedCaseID));

    // BEGIN CR00381184 CC
    integratedElement.setAttribute(kName,
      BPOTRACKINGGANTT.INF_TRACKING_GANTT_STATEMENT_INTEGRATED_SERVICE_PLAN.getMessageText(
      TransactionInfo.getProgramLocale()));
    // END CR00381184
    integratedElement.setAttribute(kTopStart,
      convertDate(trackingGanttIntegratedDetails.expectedStartDate));
    integratedElement.setAttribute(kTopEnd,
      convertDate(trackingGanttIntegratedDetails.expectedEndDate));

    integratedElement.setAttribute(kBottomStart,
      convertDate(trackingGanttIntegratedDetails.actualStartDate));
    integratedElement.setAttribute(kBottomEnd,
      convertDate(trackingGanttIntegratedDetails.actualEndDate));

    // Add the service plan group deliveries
    final int numberOfGroups = trackingGanttIntegratedDetails.groupDetailsList.size();

    for (int groupCount = 0; groupCount < numberOfGroups; groupCount++) {
      final TrackingGanttGroupDetails trackingGanttGroupDetails = trackingGanttIntegratedDetails.groupDetailsList.item(
        groupCount);

      final Element groupElement = createGroupXML(trackingGanttGroupDetails);

      integratedElement.addContent(groupElement);
    }

    // Add the service plan deliveries
    final int numberOfServicePlans = trackingGanttIntegratedDetails.detailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      final ReadTrackingGanttDetails readTrackingGanttDetails = trackingGanttIntegratedDetails.detailsList.item(
        servicePlanCount);

      final Element goalElement = createGoalXML(readTrackingGanttDetails, false);

      integratedElement.addContent(goalElement);
    }

    // Create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    ganttElement.addContent(integratedElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00229255 MN
    final ServicePlanTrackingGanttDetails servicePlanTrackGanttDetails = new ServicePlanTrackingGanttDetails();

    // END, CR00229225

    servicePlanTrackGanttDetails.newTrackGanttXmlString = outputter.outputString(
      ganttElement);

    return servicePlanTrackGanttDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * Creates a goal element to add to the xml string.
   *
   * @param readTrackingGanttDetails
   * the goal record.
   *
   * @param usePlannedSubGoalForGoalStatus
   * Indicator to specify to use planned sub goal.
   *
   * @return Element Goal element to be displayed on the Gantt chart.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected Element createGoalXML(
    final ReadTrackingGanttDetails readTrackingGanttDetails,
    final boolean usePlannedSubGoalForGoalStatus) throws AppException,
      InformationalException {

    // END, CR00198672
    // Create goal element
    Element goalElement = new Element(kPlannedGoal);

    // plannedSubGoal structs
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    PlannedSubGoalStatusList plannedSubGoalStatusList = new PlannedSubGoalStatusList();

    final PlannedSubGoalStatus plannedSubGoalStatus = new PlannedSubGoalStatus();

    if (usePlannedSubGoalForGoalStatus) {
      // BEGIN, CR00234999, TV
      // populate key
      plannedGoalKey.plannedGoalID = readTrackingGanttDetails.readTrackGanttGoalDetails.plannedGoalID;
      // END, CR00234999
      // read back all plannedSubGoal statuses
      plannedSubGoalStatusList = plannedSubGoalObj.searchPlannedSubGoalStatusByPlannedGoalID(
        plannedGoalKey);

      // we do not use the status from the method key as this is of type
      // CASESTATUS we need a status of type PLANNEDSUBGOALSTATUS
      // default status to be 'not started'.
      plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;

      final int sizePlannedSubGoalStatusList = plannedSubGoalStatusList.dtls.size();

      // check all statuses for 'completed'.
      for (int i = 0; i < sizePlannedSubGoalStatusList; i++) {
        if (!plannedSubGoalStatusList.dtls.item(i).status.equals(
          PLANNEDSUBGOALSTATUS.INPROGRESS)
            && plannedSubGoalStatusList.dtls.item(i).status.equals(
              PLANNEDSUBGOALSTATUS.COMPLETED)) {

          plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.COMPLETED;

        }
      }
      final int sizePlannedSubGoalList = plannedSubGoalStatusList.dtls.size();

      // if statuses are not 'completed', check for 'in progress'.
      for (int i = 0; i < sizePlannedSubGoalList; i++) {
        if (plannedSubGoalStatusList.dtls.item(i).status.equals(
          PLANNEDSUBGOALSTATUS.INPROGRESS)) {
          plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.INPROGRESS;

        }
      }

      goalElement.setAttribute(kStatus, plannedSubGoalStatus.status);

    } else {
      // if we are building xml for display on ISP or SPG gantt, the flag
      // usePlannedSubGoalForGoalStatus passed in should be false
      // the status should be the Case Status in this scenario
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseHeaderKey chKey = new CaseHeaderKey();

      // BEGIN, CR00234999, TV
      chKey.caseID = readTrackingGanttDetails.readTrackGanttGoalDetails.caseID;
      // END, CR00234999
      final CaseStatusCode caseStatus = caseHeaderObj.readCaseStatus(chKey);

      goalElement.setAttribute(kStatus, caseStatus.statusCode);
    }

    // Assign the attributes of the goal from the passed object
    // BEGIN, CR00234999, TV
    goalElement.setAttribute(kName,
      readTrackingGanttDetails.readTrackGanttGoalDetails.goalName);

    goalElement.setAttribute(kTopStart,
      convertDate(
      readTrackingGanttDetails.readTrackGanttGoalDetails.expectedStartDate));
    goalElement.setAttribute(kTopEnd,
      convertDate(
      readTrackingGanttDetails.readTrackGanttGoalDetails.expectedEndDate));
    goalElement.setAttribute(kBottomStart,
      convertDate(
      readTrackingGanttDetails.readTrackGanttGoalDetails.actualStartDate));
    goalElement.setAttribute(kBottomEnd,
      convertDate(
      readTrackingGanttDetails.readTrackGanttGoalDetails.actualEndDate));

    // Assign the goal ID
    goalElement.setAttribute(kID,
      String.valueOf(readTrackingGanttDetails.readTrackGanttGoalDetails.caseID));
    // END, CR00234999
    goalElement.setAttribute(kType, kPlannedGoal);

    // Create XML for service plan level milestones
    final int numberOfMilestones = readTrackingGanttDetails.trackGanttMilestoneDetails.dtls.size();

    for (int milestoneCount = 0; milestoneCount < numberOfMilestones; milestoneCount++) {
      Element milestoneElement = new Element(kMilestone);

      milestoneElement = createMilestoneXML(
        readTrackingGanttDetails.trackGanttMilestoneDetails.dtls.item(
          milestoneCount));

      goalElement.addContent(milestoneElement);
    }

    // Read planned group details
    final PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();

    plannedGoalKey = new PlannedGoalKey();
    // BEGIN, CR00234999, TV
    plannedGoalKey.plannedGoalID = readTrackingGanttDetails.readTrackGanttGoalDetails.plannedGoalID;
    // END, CR00234999
    final PlannedGroupDetailsForGanttList plannedGroupDetailsForGanttList = plannedGroupObj.searchPlannedGroupsOnGoalForGantt(
      plannedGoalKey);

    final int numberOfPlannedGroupDetails = plannedGroupDetailsForGanttList.dtls.size();

    for (int plannedGroupDetailsCount = 0; plannedGroupDetailsCount
      < numberOfPlannedGroupDetails; plannedGroupDetailsCount++) {
      Element plannedGroupElement = new Element(kPlanGroup);

      plannedGroupElement = createPlannedGroupXML(
        plannedGroupDetailsForGanttList.dtls.item(plannedGroupDetailsCount));

      goalElement.addContent(plannedGroupElement);
    }

    // Update the goal element with all the sub goal/plan items element
    // details
    goalElement = createPlannedSubGoalXMLStringForListPassedIn(
      readTrackingGanttDetails, goalElement);

    return goalElement;
  }

  // END, CR00161962
  // ___________________________________________________________________________

  /**
   * Takes in a list of Planned Sub Goals and their associated planned items.
   * Creates the XML String for each sub goal and each planned item within the
   * planned subGoal. The returns all the sub goal information into a parent
   * Element (which will be either a planned group or a planned Goal).
   *
   * @param details
   * Structure which contains the list of subgoals.
   * @param parentElement
   * parentElement which will be updates with the created XML
   * String for all the subGoals passed in.
   *
   * @return Element The parent Element to hold all the XML for planned
   * subGoals and their planned items.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected Element createPlannedSubGoalXMLStringForListPassedIn(
    final ReadTrackingGanttDetails details, final Element parentElement)
    throws AppException, InformationalException {

    // END, CR00198672
    // BEGIN, CR00052924, GM

    // BEGIN, CR00161962, LJ
    // BEGIN, CR00118825, MC
    // Planned item entity variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    final String respOrConcerning = Configuration.getProperty(
      EnvVars.ENV_SERVICEPLANS_SHOW_RESPONSIBILTY_OR_CONCERNING);

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    // END, CR00118825

    // END, CR00052924

    // iterate through sub goals list
    for (int i = 0; i < details.trackGanttSubGoalDetails.size(); i++) {

      final Element subGoalElement = createSubgoalElement(details, i);

      // iterate plan items list for the sub goal
      for (int j = 0; j
        < details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.size(); j++) {

        createPlanItemForSubgoal(details, plannedItemObj, respOrConcerning,
          concernRoleObj, i, subGoalElement, j);
      }
      // END, CR00161962
      // BEGIN, CR00058141, PMD
      // Create xml for sub-goal level milestones
      for (int k = 0; k
        < details.trackGanttSubGoalDetails.item(i).trackGanttMilestoneDetails.dtls.size(); k++) {

        Element milestoneElement = new Element(kMilestone);

        milestoneElement = createMilestoneXML(
          details.trackGanttSubGoalDetails.item(i).trackGanttMilestoneDetails.dtls.item(
            k));

        // Update the sub-goal element with all the milestone elements
        // found.
        subGoalElement.addContent(milestoneElement);
      }
      // END, CR00058141

      // add SUBGOAL element to the GOAL element
      parentElement.addContent(subGoalElement);
    }
    return parentElement;
  }

  // BEGIN, CR00161962, LJ
  /**
   * @param details
   * Tracking Gantt Details.
   * @param plannedItemObj
   * Planned Item Instance
   * @param respOrConcerning
   * String
   * @param concernRoleObj
   * Concern Role Instance
   * @param i
   * Iterator
   * @param subGoalElement
   * Sub Goal Element
   * @param j
   * Iterator
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected void createPlanItemForSubgoal(
    final ReadTrackingGanttDetails details, final PlannedItem plannedItemObj,
    final String respOrConcerning, final ConcernRole concernRoleObj,
    final int i, final Element subGoalElement, final int j)
    throws AppException, InformationalException {

    // END, CR00198672
    String name = CuramConst.gkEmpty;
    // create PLANITEM element
    final Element planItemElement = new Element(kPlanItem);

    planItemElement.setAttribute(kType, kPlanItem);
    planItemElement.setAttribute(kID,
      String.valueOf(
      details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).plannedItemID));

    // BEGIN, CR00236077, NS
    final PlannedItemIDKey plannedItemIdKey = new PlannedItemIDKey();

    plannedItemIdKey.plannedItemID = details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).plannedItemID;
    final PlanItemIDDetailsStruct planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
      plannedItemIdKey);

    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = planItemIDDetailsStruct.planItemID;
    final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
      planItemKey);

    if (nameNotEditableIndDetails.nameNotEditableInd) {
      name = CodeTable.getOneItem(PLANITEMNAME.TABLENAME,
        nameNotEditableIndDetails.name, TransactionInfo.getProgramLocale());
    } else {
      name = details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).name;
    }
    // END, CR00236077

    planItemElement.setAttribute(kName, name);

    // Get plan item type code description
    final String planItemType = CodeTable.getOneItemForUserLocale(
      PLANITEMTYPE.TABLENAME,
      details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).typeCode);

    planItemElement.setAttribute(kSPType, planItemType);

    // For each date we have to check if dates not set and if so replace
    // with empty string. As widget does not like dates not set for PlanItem

    // BEGIN, CR00052681, NRV
    // START,HARP 69118, SK
    // PlanItem Expected Start
    if (details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).expectedStartDate.isZero()) {
      planItemElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      planItemElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).expectedStartDate,
        kGanttDateFormat));
    }

    // PlanItem Expected End date
    if (details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).expectedEndDate.isZero()) {
      planItemElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      planItemElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).expectedEndDate,
        kGanttDateFormat));
    }

    // PlanItem Actual Start Date
    if (details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).actualStartDate.isZero()) {
      planItemElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      planItemElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).actualStartDate,
        kGanttDateFormat));
    }

    // PlanItem Actual End date
    if (details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).actualEndDate.isZero()) {
      planItemElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      planItemElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).actualEndDate,
        kGanttDateFormat));
    }
    // END, HARP 69118
    // END CR00052681

    // BEGIN, CR00000224, PMD
    // BEGIN, CR00127576, MC

    // Plan Item Unit Type
    final String unitType = details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).unitType;

    if (unitType != null && unitType.length() > 0) {
      planItemElement.setAttribute(kUnitType,
        String.valueOf(
        details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).unitType));
    }

    // Plan Item Units Received To Date
    planItemElement.setAttribute(kReceivedUnits,
      String.valueOf(
      details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).unitsReceivedToDate));

    // Plan Item AuthorizedUnits
    final int authorizedUnits = details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).authorizedUnits;

    if (authorizedUnits > 0) {
      planItemElement.setAttribute(kAuthorizedUnits,
        String.valueOf(authorizedUnits));
    }

    // END, CR00127576
    // BEGIN, CR00118825, MC

    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).plannedItemID;
    final PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);

    // BEGIN, CR00140973, MC
    String frequencyPattern = null;

    if (!GeneralConstants.kEmpty.equals(plannedItemDtls.frequency)) {
      frequencyPattern = plannedItemDtls.frequency;

    }
    if (frequencyPattern != null) {
      planItemElement.setAttribute(kFrequency, frequencyPattern);
    }
    // END, CR00140973

    // if it of type concerning set concerning details
    if (ServicePlanGanttConst.kConcerning.equalsIgnoreCase(respOrConcerning)) {

      if (plannedItemDtls.concerningID != 0) {
        final ConcernRoleKey key = new ConcernRoleKey();

        key.concernRoleID = plannedItemDtls.concerningID;
        final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
          key);

        planItemElement.setAttribute(kParticipantName,
          concernRoleNameDetails.concernRoleName);

      } else {

        planItemElement.setAttribute(kParticipantName,
          curam.util.resources.GeneralConstants.kEmpty);

      }

      // if it is type responsibility set responsibility details
    } else if (ServicePlanGanttConst.kResponsibility.equalsIgnoreCase(
      respOrConcerning)) {

      // if both do not have any value then set it to blank
      if (plannedItemDtls.responsibilityID == 0
        && plannedItemDtls.respUserName == null) {

        planItemElement.setAttribute(kParticipantName,
          curam.util.resources.GeneralConstants.kEmpty);

      } else {

        // if responsibility id is set then use it else use
        // responsibility
        // user name

        if (plannedItemDtls.responsibilityID != 0) {
          final ConcernRoleKey key = new ConcernRoleKey();

          key.concernRoleID = plannedItemDtls.responsibilityID;
          final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
            key);

          planItemElement.setAttribute(kParticipantName,
            concernRoleNameDetails.concernRoleName);
        } else {
          planItemElement.setAttribute(kParticipantName,
            plannedItemDtls.respUserName);
        }
      }

    } else {

      planItemElement.setAttribute(kParticipantName,
        curam.util.resources.GeneralConstants.kEmpty);
    }

    // END, CR00118825

    // BEGIN, MC, CR00124499
    if (plannedItemDtls.unitsDelivered > 0) {

      // Create DELIVERY element
      final Element deliveryElement = new Element(kServiceUnitDelivery);

      // Units Received
      deliveryElement.setAttribute(kUnits,
        String.valueOf(plannedItemDtls.unitsDelivered));
      deliveryElement.setAttribute(kDate,
        plannedItemDtls.expectedStartDate.toString());

      planItemElement.addContent(deliveryElement);

    }
    // END, CR00124499

    ServiceUnitDeliveryDtls serviceUnitDeliveryDtls = new ServiceUnitDeliveryDtls();

    // iterate service units list for the planned item
    for (int k = 0; k
      < details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).suList.dtls.size(); k++) {

      serviceUnitDeliveryDtls = details.trackGanttSubGoalDetails.item(i).trackingGanttPlanItemDetailsList.dtls.item(j).suList.dtls.item(
        k);

      // Create DELIVERY element
      final Element deliveryElement = new Element(kServiceUnitDelivery);

      // Delivery Date
      if (serviceUnitDeliveryDtls.deliveryDate.isZero()) {
        deliveryElement.setAttribute(kDate, kEmptyDate);
      } else {
        // BEGIN, CR00191032, NP
        deliveryElement.setAttribute(kDate,
          Locale.getFormattedDate(serviceUnitDeliveryDtls.deliveryDate,
          kGanttDateFormat));
        // END, CR00191032
      }

      // Units Received
      deliveryElement.setAttribute(kUnits,
        String.valueOf(serviceUnitDeliveryDtls.numberofUnits));

      planItemElement.addContent(deliveryElement);
    }
    // END, CR00000224

    // add PLANITEM element to the SUBGOAL element
    subGoalElement.addContent(planItemElement);
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * Creates the sub goal element.
   *
   * @param details
   * Tracking Gantt Details
   * @param i
   * iterator variable
   * @return Sub Goal Element
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected Element createSubgoalElement(
    final ReadTrackingGanttDetails details, final int i) throws AppException,
      InformationalException {

    // END, CR00198672
    // create SUBGOAL element
    final Element subGoalElement = new Element(kSubGoal);

    subGoalElement.setAttribute(kName,
      details.trackGanttSubGoalDetails.item(i).name);

    // For each date we have to check if dates not set and if so replace
    // with empty string. As widget does not like dates not set for planned
    // Goal.

    // BEGIN, CR00052681, NRV
    // START,HARP 69118, SK
    // SubGoal Expected Start
    if (details.trackGanttSubGoalDetails.item(i).expectedStartDate.isZero()) {
      subGoalElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      subGoalElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).expectedStartDate,
        kGanttDateFormat));
    }

    // SubGoal Expected End date
    if (details.trackGanttSubGoalDetails.item(i).expectedEndDate.isZero()) {
      subGoalElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      subGoalElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).expectedEndDate,
        kGanttDateFormat));
    }

    // SubGoal Actual start date
    if (details.trackGanttSubGoalDetails.item(i).actualStartDate.isZero()) {
      subGoalElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      subGoalElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).actualStartDate,
        kGanttDateFormat));
    }

    // SubGoal Actual end date
    if (details.trackGanttSubGoalDetails.item(i).actualEndDate.isZero()) {
      subGoalElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      subGoalElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        details.trackGanttSubGoalDetails.item(i).actualEndDate,
        kGanttDateFormat));
    }
    // END,HARP 69118
    // END, CR00052681
    subGoalElement.setAttribute(kID,
      String.valueOf(details.trackGanttSubGoalDetails.item(i).plannedSubGoalID));

    subGoalElement.setAttribute(kType, kSubGoal);

    // also set the Service Plan Delivery Id as an attribute
    // BEGIN, CR00234999, TV
    subGoalElement.setAttribute(kCaseID,
      String.valueOf(details.readTrackGanttGoalDetails.caseID));
    // END, CR00234999
    // Get sub goal type code description
    final String subGoalType = CodeTable.getOneItemForUserLocale(
      SUBGOALTYPE.TABLENAME, details.trackGanttSubGoalDetails.item(i).typeCode);

    subGoalElement.setAttribute(kSPType, subGoalType);
    return subGoalElement;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Searches for all planned groups, subgoals and planned items for a planned
   * group and adds all the element information to the planned group element
   * for the required XML String.
   *
   * @param plannedGroupDetailsForGantt
   * planned group record.
   *
   * @return Element Planned Group element to be displayed on the Gantt chart.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected Element createPlannedGroupXML(
    final PlannedGroupDetailsForGantt plannedGroupDetailsForGantt)
    throws AppException, InformationalException {

    // END, CR00198672
    // Planned Group entity
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    // Planned Item entity
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Service Unit Delivery entity
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // Plan Item entity
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final PlannedGroupKey plannedGroupKey = new PlannedGroupKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode sensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      usersKey);
    // END, CR00098617

    // create planGroup Element
    Element planGroupElement = new Element(kPlanGroup);

    planGroupElement.setAttribute(kName, plannedGroupDetailsForGantt.name);

    // SET ACTUAL AND EXPECTED DATES

    // BEGIN, CR00052681, NRV
    // START, HARP 69118, SK

    // childGroupElement Expected Start
    if (plannedGroupDetailsForGantt.expectedStartDate.isZero()) {
      planGroupElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        plannedGroupDetailsForGantt.expectedStartDate, kGanttDateFormat));
    }

    // childGroupElement Expected End date
    if (plannedGroupDetailsForGantt.expectedEndDate.isZero()) {
      planGroupElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        plannedGroupDetailsForGantt.expectedEndDate, kGanttDateFormat));
    }

    // childGroupElement Actual start date
    if (plannedGroupDetailsForGantt.actualStartDate.isZero()) {
      planGroupElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        plannedGroupDetailsForGantt.actualStartDate, kGanttDateFormat));
    }

    // childGroupElement Actual end date
    if (plannedGroupDetailsForGantt.actualEndDate.isZero()) {
      planGroupElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      planGroupElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        plannedGroupDetailsForGantt.actualEndDate, kGanttDateFormat));
    }
    // END, HARP 69118
    // END, CR00052681

    // Set child group id
    planGroupElement.setAttribute(kID,
      String.valueOf(plannedGroupDetailsForGantt.plannedGroupID));

    // Set parent group TYPE
    planGroupElement.setAttribute(kType, kPlanGroupType);

    // Set caseID and contentType to read home page.
    planGroupElement.setAttribute(kContentType, kPlanGroupContentType);
    planGroupElement.setAttribute(kCaseID,
      String.valueOf(plannedGroupDetailsForGantt.caseID));

    // BEGIN, CR00058141, PMD
    plannedGroupKey.plannedGroupID = plannedGroupDetailsForGantt.plannedGroupID;

    // List milestones at plan group level

    // BEGIN, CR00236665, GP
    final TrackingGanttMilestoneDetailsList trackingGanttMilestoneDetailsList = new TrackingGanttMilestoneDetailsList();
    final TrackingGanttMilestoneDetails1List trackingGanttMilestoneDetails1List = SPMilestoneDeliveryLinkFactory.newInstance().searchTrackingGanttDetailsByPlannedGroupID1(
      plannedGroupKey);

    for (final TrackingGanttMilestoneDetails1 trackingGanttMilestoneDetails : trackingGanttMilestoneDetails1List.dtls.items()) {

      // Read the localized name.
      if (0 != trackingGanttMilestoneDetails.nameTextID) {

        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          trackingGanttMilestoneDetails.nameTextID);

        trackingGanttMilestoneDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
    }
    trackingGanttMilestoneDetailsList.assign(trackingGanttMilestoneDetails1List);
    // END, CR00236665

    // Create Milestone XML
    for (int i = 0; i < trackingGanttMilestoneDetailsList.dtls.size(); i++) {

      Element milestoneElement = new Element(kMilestone);

      milestoneElement = createMilestoneXML(
        trackingGanttMilestoneDetailsList.dtls.item(i));

      // Update the plan group element with all the milestone elements
      // found.
      planGroupElement.addContent(milestoneElement);
    }
    // END, CR00058141

    final PlannedGroupAndSensitivityKey plannedGroupAndSensitivityKey = new PlannedGroupAndSensitivityKey();

    plannedGroupAndSensitivityKey.plannedGroupID = plannedGroupDetailsForGantt.plannedGroupID;
    plannedGroupAndSensitivityKey.sensitivityCode = sensitivityCode.sensitivity;

    // Read Child Sub goals for planned group
    final PlannedSubGoalDetailsForTrackGanttList subGoalDetailsForChildPlannedGrouplist = plannedGroupObj.searchChildSubGoalDetailsForTrackingGantt(
      plannedGroupAndSensitivityKey);

    final ReadTrackingGanttDetails readTrackingGanttDetails = new ReadTrackingGanttDetails();

    final PlannedSubGoalAndSensitivityCode plannedSubGoalAndSensitivityCode = new PlannedSubGoalAndSensitivityCode();

    final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    // For each sub goal found for the planned group
    // Search for all plan item for each Sub Goal found and assign details
    // to
    // the over all return struct.
    for (int i = 0; i < subGoalDetailsForChildPlannedGrouplist.dtls.size(); i++) {

      // create an element of the returned struct
      searchPlanItemsForDetails(plannedItemObj, serviceUnitDeliveryObj,
        planItemObj, sensitivityCode, subGoalDetailsForChildPlannedGrouplist,
        readTrackingGanttDetails, plannedSubGoalAndSensitivityCode,
        plannedItemIDStatus, i);
    }

    // Updates the plan group element with all the sub goal/plan items
    // element
    // details
    planGroupElement = createPlannedSubGoalXMLStringForListPassedIn(
      readTrackingGanttDetails, planGroupElement);

    // Read Child groups for planned group
    final PlannedGroupDetailsForGanttList plannedGroupDetailsForGanttList = plannedGroupObj.searchChildGroupDetailsForGantt(
      plannedGroupKey);

    // If a Sub planned Group exists for this planned group, then call this
    // method again to
    // list all the subgoals/groups for for each child planned groups found
    // This will be done until there are no planned groups found.
    boolean plannedGroupsExist = false;

    if (plannedGroupDetailsForGanttList.dtls.size() > 0) {
      plannedGroupsExist = true;
    }
    while (plannedGroupsExist) {
      // Search until no more child planned groups found.
      plannedGroupsExist = false;
      for (int j = 0; j < plannedGroupDetailsForGanttList.dtls.size(); j++) {
        Element subPlanGroupElement = new Element(kPlanGroup);

        subPlanGroupElement = createPlannedGroupXML(
          plannedGroupDetailsForGanttList.dtls.item(j));
        planGroupElement.addContent(subPlanGroupElement);
      }
    }
    return planGroupElement;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * @param plannedItemObj
   * Planned Item Instance
   * @param serviceUnitDeliveryObj
   * ServicePlanDelivery Instance
   * @param planItemObj
   * PlanItem Instance
   * @param sensitivityCode
   * sensitivity Code for security check
   * @param subGoalDetailsForChildPlannedGrouplist
   * sub goal details
   * @param readTrackingGanttDetails
   * Tracking Gantt Details
   * @param plannedSubGoalAndSensitivityCode
   * sub goal sensitivity code
   * @param plannedItemIDStatus
   * Planned Item Status
   * @param i
   * iterator
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected void searchPlanItemsForDetails(
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj,
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj,
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj,
    final curam.core.struct.SensitivityCode sensitivityCode,
    final PlannedSubGoalDetailsForTrackGanttList subGoalDetailsForChildPlannedGrouplist,
    final ReadTrackingGanttDetails readTrackingGanttDetails,
    final PlannedSubGoalAndSensitivityCode plannedSubGoalAndSensitivityCode,
    final PlannedItemIDStatus plannedItemIDStatus, final int i)
    throws AppException, InformationalException {

    // END, CR00198672

    final PlannedSubGoalDetailsForTrackGantt plannedSubGoalDetailsForTrackGantt = new PlannedSubGoalDetailsForTrackGantt();

    plannedSubGoalDetailsForTrackGantt.assign(
      subGoalDetailsForChildPlannedGrouplist.dtls.item(i));

    // BEGIN, CR00058141, PMD
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = subGoalDetailsForChildPlannedGrouplist.dtls.item(i).plannedSubGoalID;

    // List milestones at sub-goal level
    // BEGIN, CR00236426, GP
    final TrackingGanttMilestoneDetailsList trackingGanttMilestoneDetailsList = new TrackingGanttMilestoneDetailsList();
    final TrackingGanttMilestoneDetails1List trackingGanttMilestoneDetails1List = SPMilestoneDeliveryLinkFactory.newInstance().searchTrackingGanttDetailsByPlannedSubGoalID1(
      plannedSubGoalKey);

    for (final TrackingGanttMilestoneDetails1 trackingGanttMilestoneDetails : trackingGanttMilestoneDetails1List.dtls.items()) {

      // Read the localized name.
      if (0 != trackingGanttMilestoneDetails.nameTextID) {

        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          trackingGanttMilestoneDetails.nameTextID);

        trackingGanttMilestoneDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
    }
    trackingGanttMilestoneDetailsList.assign(trackingGanttMilestoneDetails1List);
    // END, CR00236426

    // add milestone list to the returned struct
    plannedSubGoalDetailsForTrackGantt.trackGanttMilestoneDetails.assign(
      trackingGanttMilestoneDetailsList);
    // END, CR00058141

    plannedSubGoalAndSensitivityCode.plannedSubGoalID = subGoalDetailsForChildPlannedGrouplist.dtls.item(i).plannedSubGoalID;
    plannedSubGoalAndSensitivityCode.sensitivityCode = sensitivityCode.sensitivity;

    // read planned item sub goal details
    final PlannedItemDetailsForTracknGanttList plannedItemDetailsForTracknGanttList = plannedItemObj.searchByPlannedSubGoalAndSensitivityForTrackGantt(
      plannedSubGoalAndSensitivityCode);

    for (int j = 0; j < plannedItemDetailsForTracknGanttList.dtls.size(); j++) {

      // BEGIN, CR00000224, PMD
      // Get the service units received to date

      plannedItemIDStatus.plannedItemID = plannedItemDetailsForTracknGanttList.dtls.item(j).plannedItemID;

      plannedItemDetailsForTracknGanttList.dtls.item(j).unitsReceivedToDate = serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(plannedItemIDStatus).count;

      PlanItemIDDetailsStruct planItemIDDetailsStruct = new PlanItemIDDetailsStruct();
      final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

      plannedItemIDKey.plannedItemID = plannedItemDetailsForTracknGanttList.dtls.item(j).plannedItemID;

      final PlannedItemKey plannedItemKey = new PlannedItemKey();

      plannedItemKey.plannedItemID = plannedItemDetailsForTracknGanttList.dtls.item(j).plannedItemID;

      planItemIDDetailsStruct = plannedItemObj.readPlanItemID(plannedItemIDKey);

      final PlanItemKey planItemKey = new PlanItemKey();

      planItemKey.planItemID = planItemIDDetailsStruct.planItemID;

      plannedItemDetailsForTracknGanttList.dtls.item(j).unitType = planItemObj.readPlanItemServiceUnitDeliveryDetails(planItemKey).unitType;

      // Get the list of service unit deliveries
      ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList = new ServiceUnitDeliveryDtlsList();

      serviceUnitDeliveryDtlsList = serviceUnitDeliveryObj.searchByPlannedItemIDAndStatus(
        plannedItemIDStatus);

      plannedItemDetailsForTracknGanttList.dtls.item(j).suList.assign(
        serviceUnitDeliveryDtlsList);
      // END, CR00000224

      // add baseline plan item details to the returned struct
      plannedSubGoalDetailsForTrackGantt.trackingGanttPlanItemDetailsList.dtls.addRef(
        plannedItemDetailsForTracknGanttList.dtls.item(j));
    }

    // add sub goal details to the returned struct
    readTrackingGanttDetails.trackGanttSubGoalDetails.addRef(
      plannedSubGoalDetailsForTrackGantt);
  }

  // END, CR00161962
  // ___________________________________________________________________________
  /**
   * Creates a milestone element to add to the xml string
   *
   * @param trackingGanttMilestoneDetails
   * the milestone record.
   *
   * @return Element Milestone element to be displayed on the Gantt chart.
   */
  // BEGIN, CR00198672, VK
  protected Element createMilestoneXML(
    TrackingGanttMilestoneDetails trackingGanttMilestoneDetails)
    throws AppException, InformationalException {

    // END, CR00198672
    // Create Milestone Element
    final Element milestoneElement = new Element(kMilestone);

    milestoneElement.setAttribute(kName, trackingGanttMilestoneDetails.name);

    // Set the id
    milestoneElement.setAttribute(kID,
      String.valueOf(trackingGanttMilestoneDetails.milestoneDeliveryID));

    // Set the type
    milestoneElement.setAttribute(kType, kMilestone);
    // BEGIN, CR00147132, RV
    // BEGIN, CR00182896, CL
    // Set expected start date
    if (trackingGanttMilestoneDetails.expectedStartDate.isZero()) {
      milestoneElement.setAttribute(kTopStart, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kTopStart,
        curam.util.resources.Locale.getFormattedDate(
        trackingGanttMilestoneDetails.expectedStartDate, kGanttDateFormat));

    }

    // Set expected end date
    if (trackingGanttMilestoneDetails.expectedEndDate.isZero()) {
      milestoneElement.setAttribute(kTopEnd, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kTopEnd,
        curam.util.resources.Locale.getFormattedDate(
        trackingGanttMilestoneDetails.expectedEndDate, kGanttDateFormat));
    }

    // Set actual start date
    if (trackingGanttMilestoneDetails.actualStartDate.isZero()) {
      milestoneElement.setAttribute(kBottomStart, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kBottomStart,
        curam.util.resources.Locale.getFormattedDate(
        trackingGanttMilestoneDetails.actualStartDate, kGanttDateFormat));
    }

    // Set actual end date
    if (trackingGanttMilestoneDetails.actualEndDate.isZero()) {
      milestoneElement.setAttribute(kBottomEnd, kEmptyDate);
    } else {
      milestoneElement.setAttribute(kBottomEnd,
        curam.util.resources.Locale.getFormattedDate(
        trackingGanttMilestoneDetails.actualEndDate, kGanttDateFormat));
    }
    // END, CR00182896

    return milestoneElement;
  }

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Creates a group element to add to the xml string
   *
   * @param trackingGanttGroupDetails
   * the group record.
   *
   * @return Element Group element to be displayed on the Gantt chart.
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  // BEGIN, CR00198672, VK
  protected Element createGroupXML(
    final TrackingGanttGroupDetails trackingGanttGroupDetails)
    throws AppException, InformationalException {

    // END, CR00198672
    final Element groupElement = new Element(kGroup);

    groupElement.setAttribute(kType, kGroupType);

    groupElement.setAttribute(kID,
      String.valueOf(trackingGanttGroupDetails.groupDeliveryID));
    groupElement.setAttribute(kName, trackingGanttGroupDetails.groupName);

    groupElement.setAttribute(kTopStart,
      convertDate(trackingGanttGroupDetails.expectedStartDate));
    groupElement.setAttribute(kTopEnd,
      convertDate(trackingGanttGroupDetails.expectedEndDate));

    groupElement.setAttribute(kBottomStart,
      convertDate(trackingGanttGroupDetails.actualStartDate));
    groupElement.setAttribute(kBottomEnd,
      convertDate(trackingGanttGroupDetails.actualEndDate));

    // Create service plan elements
    final int numberOfServicePlans = trackingGanttGroupDetails.detailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      final ReadTrackingGanttDetails readTrackingGanttDetails = trackingGanttGroupDetails.detailsList.item(
        servicePlanCount);

      final Element goalElement = createGoalXML(readTrackingGanttDetails, false);

      groupElement.addContent(goalElement);
    }

    return groupElement;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Converts passed date to correctly formatted <code>String</code>
   */
  // BEGIN, CR00198672, VK
  protected String convertDate(Date date) {

    // END, CR00198672
    if (date.isZero()) {
      return kEmptyDate;
    } else {
      return Locale.getFormattedDate(date, kGanttDateFormat);
    }
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Gets the earliest of the two passed <code>Date</code> objects.
   */
  // BEGIN, CR00198672, VK
  protected Date getEarliestDate(Date date, Date dateToCheck) {

    // END, CR00198672
    Date returnDate = Date.kZeroDate;

    if (date.equals(Date.kZeroDate)) {
      if (dateToCheck.equals(Date.kZeroDate) == false) {
        returnDate = dateToCheck;
      }
    } else {
      if (dateToCheck.equals(Date.kZeroDate)) {
        returnDate = date;
      } else {
        if (date.before(dateToCheck)) {
          returnDate = date;
        } else {
          returnDate = dateToCheck;
        }
      }
    }

    return returnDate;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Gets the latest of the two passed <code>Date</code> objects.
   */
  // BEGIN, CR00198672, VK
  protected Date getLatestDate(Date date, Date dateToCheck) {

    // END, CR00198672
    Date returnDate = Date.kZeroDate;

    if (date.equals(Date.kZeroDate)) {
      if (dateToCheck.equals(Date.kZeroDate) == false) {
        returnDate = dateToCheck;
      }
    } else {
      if (dateToCheck.equals(Date.kZeroDate)) {
        returnDate = date;
      } else {
        if (date.after(dateToCheck)) {
          returnDate = date;
        } else {
          returnDate = dateToCheck;
        }
      }
    }

    return returnDate;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  /**
   * Checks the security of the passed case ID.
   *
   * @param caseID
   * Contains the case ID.
   *
   * @throws AppException
   * {@link BPOTRACKINGGANTT#ERR_TRACKING_VIEW_GANTT_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to view
   * this page.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected void checkSecurity(long caseID) throws AppException,
      InformationalException {

    // END, CR00198672

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanParticipantSecurityKey servicePlanParticipantSecurityKey = new ServicePlanParticipantSecurityKey();

    // CaseHeader entity variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseID;

    // set service plan security key
    servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan participant security
    try {
      servicePlanSecurity.participantSensitivityCheck(
        servicePlanParticipantSecurityKey);
    } catch (final AppException ae) {
      if (ae.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOTRACKINGGANTT.ERR_TRACKING_VIEW_GANTT_SECURITY_CHECK_FAILED);
      } else {
        throw ae;
      }
    }

    // ServicePlanSecurity manipulation variables
    final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // need to read the service plan case id.
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = caseID;

    // service plan Delivery manipulation object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryobj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryobj.read(servicePlanDeliveryKey).servicePlanID;

    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // check service plan security
    try {

      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException ae) {
      if (ae.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOTRACKINGGANTT.ERR_TRACKING_VIEW_GANTT_SECURITY_CHECK_FAILED);
      } else {
        throw ae;
      }
    }
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Overloaded method to read the tracking Gantt details.
   */
  // BEGIN, CR00198672, VK
  protected ReadTrackingGanttDetails readTrackingGanttDetails(
    ServicePlanDeliveryKey key, boolean throwException) throws AppException,
      InformationalException {

    // END, CR00198672
    // This method has been added to allow a boolean flag to be passed to
    // determine if an exception should be raised as within the context of a
    // service plan group delivery the exception should not be thrown to
    // prevent
    // the chart being displayed.
    //
    // The method has been written in this manner as the original exception
    // thrown from the read method cannot be moved from it's location as
    // dependencies may exist on that code.

    // Check Security
    checkSecurity(key.key.caseID);

    // return details
    final curam.serviceplans.sl.struct.ReadTrackingGanttDetails readTrackingGanttDetails = new curam.serviceplans.sl.struct.ReadTrackingGanttDetails();

    // Planned Goal entity
    final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // Planned sub goal entity variables
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    final PlannedSubGoalAndSensitivityCode plannedSubGoalAndSensitivityCode = new curam.serviceplans.sl.entity.struct.PlannedSubGoalAndSensitivityCode();

    final PlannedGoalAndSensitivityCodeKey plannedGoalAndSensitivityCodeKey = new curam.serviceplans.sl.entity.struct.PlannedGoalAndSensitivityCodeKey();

    // Planned item entity variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Service Unit Delivery Entity
    final curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // PlanItem Entity
    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode sensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      usersKey);
    // END, CR00098617

    // Set boolean to see if exception could have occurred
    boolean exceptionOccurred = false;

    // read goal details
    // BEGIN, CR00234999, TV
    try {
      final TrackingGanttGoalDetails trackingGanttGoalDetails = plannedGoalObj.readGoalGroupDetailsForTrackingGanttByCaseID(
        key.key);

      readTrackingGanttDetails.readTrackGanttGoalDetails.assign(
        trackingGanttGoalDetails);
      // END, CR00234999
    } catch (final RecordNotFoundException rnfe) {
      if (throwException == true) {
        throw new AppException(
          BPOTRACKINGGANTT.ERR_TRACKING_GANTT_GOAL_MUST_EXIST_FOR_SERVICE_PLAN);
      } else {
        exceptionOccurred = true;
      }
    }

    // Only attempt to read the details if no exception has occurred
    if (exceptionOccurred == false) {
      // BEGIN, CR00058141, PMD
      // List milestones at service plan level
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.key.caseID;

      // BEGIN, CR00236426, GP
      final SPMilestoneDeliveryLink milestoneDeliveryLinkObj = SPMilestoneDeliveryLinkFactory.newInstance();
      final TrackingGanttMilestoneDetailsList trackingGanttMilestoneDetailsList = new TrackingGanttMilestoneDetailsList();
      TrackingGanttMilestoneDetails1List trackingGanttMilestoneDetails1List = milestoneDeliveryLinkObj.searchTrackingGanttDetailsByCaseID1(
        caseHeaderKey);

      for (final TrackingGanttMilestoneDetails1 trackingGanttMilestoneDetails : trackingGanttMilestoneDetails1List.dtls.items()) {

        final TrackingGanttMilestoneDetails trackingGanttMilestoneDtls = new TrackingGanttMilestoneDetails();

        trackingGanttMilestoneDtls.assign(trackingGanttMilestoneDetails);

        // Read the localized name.
        if (0 != trackingGanttMilestoneDetails.nameTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            trackingGanttMilestoneDetails.nameTextID);

          trackingGanttMilestoneDtls.name = localizableText.getValue(
            LOCALEEntry.get(
              ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        }
        trackingGanttMilestoneDetailsList.dtls.addRef(
          trackingGanttMilestoneDtls);
      }

      // Add milestone list to the returned struct.
      readTrackingGanttDetails.trackGanttMilestoneDetails.assign(
        trackingGanttMilestoneDetailsList);
      // END, CR00236426

      // END, CR00058141

      // set planned goal ID and sensitivity key
      // BEGIN, CR00234999, TV
      plannedGoalAndSensitivityCodeKey.plannedGoalID = readTrackingGanttDetails.readTrackGanttGoalDetails.plannedGoalID;
      // END, CR00234999
      plannedGoalAndSensitivityCodeKey.sensitivityCode = sensitivityCode.sensitivity;

      // list planned sub goal details for goal
      final PlannedSubGoalDetailsForTrackGanttList plannedSubGoalDetailsForTrackGanttList = plannedSubGoalObj.searchByPlannedGoalAndSensitivityForTrackingGantt(
        plannedGoalAndSensitivityCodeKey);

      final int sizePlannedSubGoal = plannedSubGoalDetailsForTrackGanttList.dtls.size();

      final PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

      // For each sub goal found for the planned goal
      for (int i = 0; i < sizePlannedSubGoal; i++) {

        // create an element of the returned struct
        final PlannedSubGoalDetailsForTrackGantt plannedSubGoalDetailsForTrackGantt = new PlannedSubGoalDetailsForTrackGantt();

        plannedSubGoalDetailsForTrackGantt.assign(
          plannedSubGoalDetailsForTrackGanttList.dtls.item(i));

        plannedSubGoalAndSensitivityCode.plannedSubGoalID = plannedSubGoalDetailsForTrackGanttList.dtls.item(i).plannedSubGoalID;
        plannedSubGoalAndSensitivityCode.sensitivityCode = sensitivityCode.sensitivity;

        // read planned item sub goal details
        final PlannedItemDetailsForTracknGanttList plannedItemDetailsForTracknGanttList = plannedItemObj.searchByPlannedSubGoalAndSensitivityForTrackGantt(
          plannedSubGoalAndSensitivityCode);

        final int sizePlannedItemDetails = plannedItemDetailsForTracknGanttList.dtls.size();

        for (int j = 0; j < sizePlannedItemDetails; j++) {

          // BEGIN, CR00000224, PMD

          plannedItemIDStatus.plannedItemID = plannedItemDetailsForTracknGanttList.dtls.item(j).plannedItemID;

          // Add the service unit delivery details to the return
          // struct
          plannedItemDetailsForTracknGanttList.dtls.item(j).unitsReceivedToDate = serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(plannedItemIDStatus).count;

          PlanItemIDDetailsStruct planItemIDDetailsStruct = new PlanItemIDDetailsStruct();
          final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

          plannedItemIDKey.plannedItemID = plannedItemDetailsForTracknGanttList.dtls.item(j).plannedItemID;

          planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
            plannedItemIDKey);
          final PlanItemKey planItemKey = new PlanItemKey();

          planItemKey.planItemID = planItemIDDetailsStruct.planItemID;

          plannedItemDetailsForTracknGanttList.dtls.item(j).unitType = planItemObj.readPlanItemServiceUnitDeliveryDetails(planItemKey).unitType;

          // Read the service unit delivery details
          ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList = new ServiceUnitDeliveryDtlsList();

          serviceUnitDeliveryDtlsList = serviceUnitDeliveryObj.searchByPlannedItemIDAndStatus(
            plannedItemIDStatus);
          plannedItemDetailsForTracknGanttList.dtls.item(j).suList.assign(
            serviceUnitDeliveryDtlsList);
          // END, CR00000224

          plannedSubGoalDetailsForTrackGantt.trackingGanttPlanItemDetailsList.dtls.addRef(
            plannedItemDetailsForTracknGanttList.dtls.item(j));

        }

        // BEGIN, CR00058141, PMD
        final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

        plannedSubGoalKey.plannedSubGoalID = plannedSubGoalDetailsForTrackGanttList.dtls.item(i).plannedSubGoalID;

        // List milestones at sub-goal level
        // BEGIN, CR00236426, GP
        trackingGanttMilestoneDetails1List = SPMilestoneDeliveryLinkFactory.newInstance().searchTrackingGanttDetailsByPlannedSubGoalID1(
          plannedSubGoalKey);

        for (final TrackingGanttMilestoneDetails1 trackingGanttMilestoneDetails : trackingGanttMilestoneDetails1List.dtls.items()) {

          // Read the localized name.
          if (0 != trackingGanttMilestoneDetails.nameTextID) {

            final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
              trackingGanttMilestoneDetails.nameTextID);

            trackingGanttMilestoneDetails.name = localizableText.getValue(
              LOCALEEntry.get(
                ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
          }
        }
        trackingGanttMilestoneDetailsList.assign(
          trackingGanttMilestoneDetails1List);
        // END, CR00236426

        // add milestone list to the returned struct
        plannedSubGoalDetailsForTrackGantt.trackGanttMilestoneDetails.assign(
          trackingGanttMilestoneDetailsList);
        // END, CR00058141

        // add sub goal details to the returned struct
        readTrackingGanttDetails.trackGanttSubGoalDetails.addRef(
          plannedSubGoalDetailsForTrackGantt);
      }
    }

    // return details
    return readTrackingGanttDetails;
  }
  // END, CR00161962
}
