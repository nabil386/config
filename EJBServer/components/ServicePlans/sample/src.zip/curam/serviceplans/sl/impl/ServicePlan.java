/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.struct.AdminIntegratedCaseDtls;
import curam.core.struct.AdminIntegratedCaseKey;
import curam.core.struct.SIDTypeKey;
import curam.core.struct.SecurityIDList;
import curam.message.BPOSERVICEPLAN;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.struct.PlanTemplateSummaryDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplateSummaryDetails1;
import curam.serviceplans.sl.entity.struct.PlanTemplateSummaryDetails1List;
import curam.serviceplans.sl.entity.struct.ServicePlanAndStatusKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDescriptionTextID;
import curam.serviceplans.sl.entity.struct.ServicePlanDtls;
import curam.serviceplans.sl.struct.AdminICSummaryStructList;
import curam.serviceplans.sl.struct.CancelServicePlanDetails;
import curam.serviceplans.sl.struct.CreateGoalDetails;
import curam.serviceplans.sl.struct.GoalDetails;
import curam.serviceplans.sl.struct.GoalKey;
import curam.serviceplans.sl.struct.GoalKeyList;
import curam.serviceplans.sl.struct.GoalSummaryStructList;
import curam.serviceplans.sl.struct.IntegratedCaseIDList;
import curam.serviceplans.sl.struct.PlanTemplateDetails;
import curam.serviceplans.sl.struct.PlanTemplateKey;
import curam.serviceplans.sl.struct.PlanTemplateKeyList;
import curam.serviceplans.sl.struct.PlanTemplateSummaryStructList;
import curam.serviceplans.sl.struct.ReadServicePlanDetails;
import curam.serviceplans.sl.struct.RemoveGoalFromServicePlanKey;
import curam.serviceplans.sl.struct.RemoveICFromServicePlanKey;
import curam.serviceplans.sl.struct.SecurityIdentifierList;
import curam.serviceplans.sl.struct.ServicePlanDetailList;
import curam.serviceplans.sl.struct.ServicePlanDetails;
import curam.serviceplans.sl.struct.ServicePlanDetailsList;
import curam.serviceplans.sl.struct.ServicePlanGoalKey;
import curam.serviceplans.sl.struct.ServicePlanICKey;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.ServicePlanStatus;
import curam.serviceplans.sl.struct.ServicePlanTypeDetails;
import curam.serviceplans.sl.struct.ServicePlanTypes;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


public abstract class ServicePlan extends curam.serviceplans.sl.base.ServicePlan {

  // BEGIN, CR00226647, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public ServicePlan() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00226647

  // _________________________________________________________________________
  /**
   * Adds a list of goals to a service plan.
   *
   * @param servicePlanKey The key of the service plan
   * @param goals A list of goal keys to add to the service plan
   */
  @Override
  public void addExistingGoals(ServicePlanKey servicePlanKey,
    GoalKeyList goals) throws AppException, InformationalException {

    //
    // check that service plan is not canceled
    //

    // read the service plan status
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanStatus servicePlanStatus = servicePlanObj.readStatus(
      servicePlanKey.key, false);

    // is the service plan canceled?
    if (servicePlanStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_MODIFY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);

    }

    //
    // add the goals
    //

    // loop variables
    final curam.serviceplans.sl.entity.intf.ServicePlanGoalLink servicePlanGoalLinkObj = curam.serviceplans.sl.entity.fact.ServicePlanGoalLinkFactory.newInstance();
    final ServicePlanGoalKey servicePlanGoalKey = new ServicePlanGoalKey();
    final int numGoals = goals.goalKey.size();

    // loop through all the goals
    for (int i = 0; i < numGoals; i++) {

      // get the next goal in the list
      final GoalKey nextGoal = goals.goalKey.item(i);

      // check that the goal can be added to the service plan
      servicePlanGoalKey.servicePlanKey = servicePlanKey.key;
      servicePlanGoalKey.goalKey = nextGoal.goalKey;
      validateAddGoalToServicePlan(servicePlanGoalKey);

      // add the goal to the service plan
      final curam.serviceplans.sl.entity.struct.ServicePlanGoalLinkDtls servicePlanGoalLinkDtls = new curam.serviceplans.sl.entity.struct.ServicePlanGoalLinkDtls();

      servicePlanGoalLinkDtls.goalID = nextGoal.goalKey.goalID;
      servicePlanGoalLinkDtls.servicePlanID = servicePlanKey.key.servicePlanID;
      servicePlanGoalLinkObj.insert(servicePlanGoalLinkDtls);

    }

  }

  // _________________________________________________________________________
  /**
   * Adds a list of templates to a service plan.
   *
   * @param servicePlanKey The key of the service plan
   * @param templates A list of template keys to add to the service plan
   */
  @Override
  public void addExistingTemplates(ServicePlanKey servicePlanKey,
    PlanTemplateKeyList templates) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.PlanTemplateServicePlanLink planTemplateServicePlanLinkObj = curam.serviceplans.sl.entity.fact.PlanTemplateServicePlanLinkFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.PlanTemplateServicePlanLinkDtls planTemplateServicePlanLinkDtls = new curam.serviceplans.sl.entity.struct.PlanTemplateServicePlanLinkDtls();

    // check if service plan is not cancelled
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    servicePlanObj.validateServicePlanStatus(servicePlanKey.key);

    // if service plan is not cancelled, add templates
    final int numTemplates = templates.planTemplateKey.size();

    // create object to generate unique ID
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    final PlanTemplateDetails planTemplateDetails = new PlanTemplateDetails();

    // loop through all the plan templates
    for (int i = 0; i < numTemplates; i++) {

      final PlanTemplateKey nextTemplate = templates.planTemplateKey.item(i);

      planTemplateDetails.dtls.planTemplateID = nextTemplate.planTemplateKey.planTemplateID;

      // validate template when adding to service plan
      validateAddTemplateToServicePlan(servicePlanKey, planTemplateDetails);

      // if validation passed then add template
      planTemplateServicePlanLinkDtls.planTemplateID = nextTemplate.planTemplateKey.planTemplateID;

      planTemplateServicePlanLinkDtls.servicePlanID = servicePlanKey.key.servicePlanID;

      // generate unique ID
      planTemplateServicePlanLinkDtls.planTemplateServicePlanLinkID = uniqueIDObj.getNextID();

      // add template to service plan
      planTemplateServicePlanLinkObj.insert(planTemplateServicePlanLinkDtls);

    }

  }

  // _________________________________________________________________________
  /**
   * Adds a list of integrated cases to the service plan.
   *
   * @param servicePlanKey The key of the service plan
   * @param integratedCaseIDList The integrated case id's to be added to the
   * service plan.
   */
  @Override
  public void addICToServicePlan(ServicePlanKey servicePlanKey,
    IntegratedCaseIDList integratedCaseIDList) throws AppException,
      InformationalException {

    //
    // check that service plan is not canceled
    //

    // read the service plan status
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanStatus servicePlanStatus = servicePlanObj.readStatus(
      servicePlanKey.key, false);

    // is the service plan canceled?
    if (servicePlanStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_MODIFY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);

    }

    //
    // add the integrated cases
    //

    // loop variables
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLinkObj = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();
    final ServicePlanICKey servicePlanICKey = new ServicePlanICKey();
    final int numCases = integratedCaseIDList.adminICCaseKey.size();

    // loop through all the integrated cases
    for (int i = 0; i < numCases; i++) {

      // get the next case in the list
      final curam.serviceplans.sl.entity.struct.AdminICCaseKey nextCase = integratedCaseIDList.adminICCaseKey.item(
        i);

      // check that the case can be added to the service plan
      servicePlanICKey.servicePlanKey = servicePlanKey;
      servicePlanICKey.caseKey.key.caseID = nextCase.caseID;
      validateAddICToServicePlan(servicePlanICKey);

      // add the case to the service plan
      final curam.serviceplans.sl.entity.struct.AdminICServicePlanLinkDtls adminICServicePlanLinkDtls = new curam.serviceplans.sl.entity.struct.AdminICServicePlanLinkDtls();

      adminICServicePlanLinkDtls.servicePlanID = servicePlanKey.key.servicePlanID;
      adminICServicePlanLinkDtls.adminIntegratedCaseID = nextCase.caseID;
      adminICServicePlanLinkObj.insert(adminICServicePlanLinkDtls);

    }

  }

  // _________________________________________________________________________
  /**
   * Cancels the service plan.
   *
   * @param cancelKey The key of the service plan to cancel.
   */
  @Override
  public void cancel(CancelServicePlanDetails cancelKey) throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.ServicePlanStatus servicePlanStatus = new curam.serviceplans.sl.entity.struct.ServicePlanStatus();

    servicePlanStatus.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    servicePlanObj.cancel(cancelKey.cancelDetails, servicePlanStatus);

  }

  // _________________________________________________________________________
  /**
   * Creates the service plan.
   *
   * @param details The details to create the service plan with.
   * @return Unique identifier of the service plan created
   */
  @Override
  public ServicePlanKey create(ServicePlanDetails details)
    throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    curam.serviceplans.sl.entity.struct.ServicePlanDtls servicePlanDtls = new curam.serviceplans.sl.entity.struct.ServicePlanDtls();

    // create return structure
    final ServicePlanKey servicePlanKey = new ServicePlanKey();

    // create object to generate unique ID
    // curam.core.intf.UniqueID uniqueIDObj =
    // curam.core.fact.UniqueIDFactory.newInstance();

    servicePlanDtls = details.plan;
    servicePlanDtls.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;

    // BEGIN, CR00227878, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!details.plan.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.plan.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      details.plan.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      details.plan.descriptionTextID = localizableTextHandler.store();
    }

    servicePlanDtls.description = null;
    // END, CR00227878

    // insert service plan
    servicePlanObj.insert(servicePlanDtls);

    // get service plan ID
    servicePlanKey.key.servicePlanID = servicePlanDtls.servicePlanID;

    return servicePlanKey;

  }

  // _________________________________________________________________________
  /**
   * Creates a goal and adds it to the service plan.
   *
   * @param details the details of the goal
   * @param key the service plan key
   * @return Unique identifier of the goal created
   */
  @Override
  public GoalKey createGoal(GoalDetails details, ServicePlanKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    GoalKey goalKey;
    final CreateGoalDetails createGoalDetails = new CreateGoalDetails();

    createGoalDetails.assign(details.goal);

    goalKey = goalObj.create(createGoalDetails);

    return goalKey;

  }

  // _________________________________________________________________________
  /**
   * Creates a template and adds it to the service plan.
   *
   * @param details the details of the template
   * @param key the service plan key
   *
   * @return Unique identifier of the plan template created
   */
  @Override
  public PlanTemplateKey createTemplate(PlanTemplateDetails details,
    ServicePlanKey key) throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    final PlanTemplateKey planTemplateKey = planTemplateObj.create(details);

    final PlanTemplateKeyList planTemplateKeyList = new PlanTemplateKeyList();

    planTemplateKeyList.planTemplateKey.addRef(planTemplateKey);

    addExistingTemplates(key, planTemplateKeyList);

    return planTemplateKey;

  }

  // _________________________________________________________________________
  /**
   * Lists the service plan available on the system.
   *
   * @return A list of available service plans.
   */
  @Override
  public ServicePlanDetailsList list() throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // create return structure
    final ServicePlanDetailsList servicePlanDetailsList = new ServicePlanDetailsList();

    // get list service plans
    servicePlanDetailsList.list = servicePlanObj.list();

    return servicePlanDetailsList;

  }

  // _________________________________________________________________________
  /**
   * Lists the goals associated with the service plan.
   *
   * @param key The key of the service plan from which the goals are required
   * @return A list of the goals that are associated with the service plan
   */
  @Override
  public GoalSummaryStructList listGoals(ServicePlanKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    final GoalSummaryStructList goalSummaryStructListReturn = new GoalSummaryStructList();

    goalSummaryStructListReturn.list = servicePlanObj.searchGoals(key.key);

    return goalSummaryStructListReturn;

  }

  // _________________________________________________________________________
  /**
   * Lists integrated cases that are not associated with the service plan.
   *
   * @param key The key of the service plan for which the integrated cases
   * are required.
   * @return A list of integrated cases
   */
  @Override
  public AdminICSummaryStructList listICNotAssociatedWithServicePlan(
    ServicePlanKey key) throws AppException, InformationalException {

    // return object
    final AdminICSummaryStructList adminICSummaryStructListReturn = new AdminICSummaryStructList();

    // populate the search key - only look for active ones
    final ServicePlanAndStatusKey servicePlanAndStatusKey = new ServicePlanAndStatusKey();

    servicePlanAndStatusKey.servicePlanID = key.key.servicePlanID;
    servicePlanAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // search for integrated case types and populate the return object
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    adminICSummaryStructListReturn.list = servicePlanObj.searchUnassociatedIntegratedCasesByStatus(
      servicePlanAndStatusKey);

    return adminICSummaryStructListReturn;

  }

  // _________________________________________________________________________
  /**
   * List integrated cases that are associated with the service plan.
   *
   * @param key The key of the service plan for which the integrated cases
   * are required.
   * @return A list of integrated cases
   */
  @Override
  public AdminICSummaryStructList listServicePlanIC(ServicePlanKey key)
    throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLinkObj = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();

    // create return structure
    final AdminICSummaryStructList adminICSummaryStructListReturn = new AdminICSummaryStructList();

    adminICSummaryStructListReturn.list = adminICServicePlanLinkObj.searchByServicePlanID(
      key.key);

    return adminICSummaryStructListReturn;

  }

  // _________________________________________________________________________
  /**
   * List the plan templates associated with the service plan
   *
   * @param key The key of the service plan
   *
   * @return A list of templates.
   */
  @Override
  public PlanTemplateSummaryStructList listTemplates(ServicePlanKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    final PlanTemplateSummaryStructList planTemplateSummaryStructList = new PlanTemplateSummaryStructList();

    // BEGIN, CR00226647, GP

    PlanTemplateSummaryDetails1List planTemplateSummaryDetailsList = new PlanTemplateSummaryDetails1List();
    PlanTemplateSummaryDetails planTemplateSummaryDetails;
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.entity.struct.ServicePlanKey();

    servicePlanKey.servicePlanID = key.key.servicePlanID;

    // Look for the templates associated with service plan.
    planTemplateSummaryDetailsList = servicePlanObj.searchPlanTemplates(
      servicePlanKey);

    planTemplateSummaryStructList.list.dtls.ensureCapacity(
      planTemplateSummaryDetailsList.dtls.size());

    for (final PlanTemplateSummaryDetails1 planTemplateSummaryDetails1 : planTemplateSummaryDetailsList.dtls.items()) {

      planTemplateSummaryDetails = new PlanTemplateSummaryDetails();

      planTemplateSummaryDetails.planTemplateID = planTemplateSummaryDetails1.planTemplateID;
      planTemplateSummaryDetails.dateCreated = planTemplateSummaryDetails1.dateCreated;

      // Check if localized name is found.
      if (0 != planTemplateSummaryDetails1.nameTextID) {
        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          planTemplateSummaryDetails1.nameTextID);

        planTemplateSummaryDetails.planTemplateName = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      } else {

        planTemplateSummaryDetails.planTemplateName = planTemplateSummaryDetails1.planTemplateName;
      }
      planTemplateSummaryStructList.list.dtls.addRef(planTemplateSummaryDetails);
    }
    // END, CR00226647

    return planTemplateSummaryStructList;

  }

  // _________________________________________________________________________
  /**
   * List the goals that are not associated with the service plane
   *
   * @param key The key of the service plan
   * @return A list of goals
   */
  @Override
  public GoalSummaryStructList listUnassociatedGoals(ServicePlanKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    final GoalSummaryStructList goalSummaryStructList = new GoalSummaryStructList();

    // search for active goals not assigned to this service plans
    final curam.serviceplans.sl.entity.struct.ServicePlanAndStatusKey servicePlanAndStatusKey = new curam.serviceplans.sl.entity.struct.ServicePlanAndStatusKey();

    servicePlanAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
    servicePlanAndStatusKey.servicePlanID = key.key.servicePlanID;

    goalSummaryStructList.list = servicePlanObj.searchUnassociatedGoalsByStatus(
      servicePlanAndStatusKey);

    return goalSummaryStructList;

  }

  // _________________________________________________________________________
  /**
   * List the plan templates that are not associated with the service plan
   *
   * @param key The key of the service plan
   * @return A list of the templates
   */
  @Override
  public PlanTemplateSummaryStructList listUnassociatedTemplates(
    ServicePlanKey key) throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // BEGIN, CR00226647, GP
    final PlanTemplateSummaryStructList planTemplateSummaryStructList = new PlanTemplateSummaryStructList();

    PlanTemplateSummaryDetails1List planTemplateSummaryDetailsList = new PlanTemplateSummaryDetails1List();
    PlanTemplateSummaryDetails planTemplateSummaryDetails;
    final curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.entity.struct.ServicePlanKey();

    servicePlanKey.servicePlanID = key.key.servicePlanID;

    final curam.serviceplans.sl.entity.struct.ServicePlanAndStatusKey servicePlanAndStatusKey = new curam.serviceplans.sl.entity.struct.ServicePlanAndStatusKey();

    servicePlanAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    servicePlanAndStatusKey.servicePlanID = key.key.servicePlanID;

    // Look for the templates not associated with service plan.
    planTemplateSummaryDetailsList = servicePlanObj.searchUnassociatedPlanTemplatesByStatus(
      servicePlanAndStatusKey);

    planTemplateSummaryStructList.list.dtls.ensureCapacity(
      planTemplateSummaryDetailsList.dtls.size());

    for (final PlanTemplateSummaryDetails1 planTemplateSummaryDetails1 : planTemplateSummaryDetailsList.dtls.items()) {

      planTemplateSummaryDetails = new PlanTemplateSummaryDetails();

      planTemplateSummaryDetails.planTemplateID = planTemplateSummaryDetails1.planTemplateID;
      planTemplateSummaryDetails.dateCreated = planTemplateSummaryDetails1.dateCreated;

      // Check if localized name is found.
      if (0 != planTemplateSummaryDetails1.nameTextID) {
        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          planTemplateSummaryDetails1.nameTextID);

        planTemplateSummaryDetails.planTemplateName = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      } else {

        planTemplateSummaryDetails.planTemplateName = planTemplateSummaryDetails1.planTemplateName;
      }
      planTemplateSummaryStructList.list.dtls.addRef(planTemplateSummaryDetails);
    }
    // END, CR00226647

    return planTemplateSummaryStructList;

  }

  // _________________________________________________________________________
  /**
   * Modifies the service plan.
   *
   * @param key The key of the service plan to modify.
   * @param details The new details of the service plan.
   */
  @Override
  public void modify(ServicePlanKey key, ServicePlanDetails details)
    throws AppException, InformationalException {

    // create object at entity level
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // BEGIN, CR00227878, GP
    long descriptionTextID;

    // Check if service plan is already canceled.
    servicePlanObj.validateServicePlanStatus(key.key);

    // Modify Localized description.
    if (0 == details.plan.descriptionTextID) {

      if (!details.plan.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.plan.description,
          LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }

      // BEGIN, CR00229116, GP
      // Update the struct passed to modify().
      details.plan.descriptionTextID = descriptionTextID;
      // END, CR00229116

    } else {

      // Handling New data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.plan.descriptionTextID);

      localizableTextHandler.addValue(details.plan.description,
        LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      localizableTextHandler.store();

    }

    details.plan.description = null;
    // END, CR00227878

    servicePlanObj.modify(key.key, details.plan);

  }

  // _________________________________________________________________________
  /**
   * Reads the service plan
   *
   * @param key The key of the service plan required
   * @return The details of the service plan matching the key
   */
  @Override
  public ReadServicePlanDetails read(ServicePlanKey key) throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // create return structure
    final ReadServicePlanDetails readServicePlanDetails = new ReadServicePlanDetails();

    readServicePlanDetails.plan = servicePlanObj.read(key.key);

    // BEGIN, CR00227878, GP
    // Read the localized description.
    if (0 != readServicePlanDetails.plan.descriptionTextID) {

      final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readServicePlanDetails.plan.descriptionTextID);

      readServicePlanDetails.plan.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00227878

    return readServicePlanDetails;

  }

  // _________________________________________________________________________
  /**
   * Remove a goal from the service plan
   *
   * @param key Goal ID and Service Plan ID
   */
  @Override
  public void removeGoal(RemoveGoalFromServicePlanKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanGoalLink servicePlanGoalLinkObj = curam.serviceplans.sl.entity.fact.ServicePlanGoalLinkFactory.newInstance();

    servicePlanGoalLinkObj.removeByServicePlanIDAndGoalID(key.removeKey);

  }

  // _________________________________________________________________________
  /**
   * Removes an integrated cases association with the service plan
   *
   * @param key The key of the link to remove
   */
  @Override
  public void removeICFromServicePlan(RemoveICFromServicePlanKey key)
    throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLinkObj = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();

    // remove integrated case from service plan
    adminICServicePlanLinkObj.removeByServicePlanAndIC(key.removeKey);

  }

  // _________________________________________________________________________
  /**
   * Removes a template from the service plan
   *
   * @param servicePlanKey The key of the service plan
   * @param templateKey The key of the template to remove
   */
  @Override
  public void removeTemplate(ServicePlanKey servicePlanKey,
    PlanTemplateKey templateKey) throws AppException, InformationalException {

    final curam.serviceplans.sl.entity.intf.PlanTemplateServicePlanLink planTemplateServicePlanLinkObj = curam.serviceplans.sl.entity.fact.PlanTemplateServicePlanLinkFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.PlanTemplateServicePlanKey planTemplateServicePlanKey = new curam.serviceplans.sl.entity.struct.PlanTemplateServicePlanKey();

    // check if service plan is not cancelled
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.ServicePlanStatus servicePlanStatus = servicePlanObj.readStatus(
      servicePlanKey.key);

    // is the service plan cancelled?
    if (servicePlanStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_MODIFY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
    }

    // If validation passed, remove template from service plan
    planTemplateServicePlanKey.planTemplateID = templateKey.planTemplateKey.planTemplateID;
    planTemplateServicePlanKey.servicePlanID = servicePlanKey.key.servicePlanID;

    planTemplateServicePlanLinkObj.removeByPlanTemplateAndServicePlan(
      planTemplateServicePlanKey);

  }

  // ___________________________________________________________________________
  /**
   * Validates that the goal has not yet been associated with the service plan
   *
   * @param key
   * The key of the goal
   */
  @Override
  public void validateCreateGoal(ServicePlanGoalKey key) throws AppException,
      InformationalException {//
  }

  // ___________________________________________________________________________
  /**
   * Validates that the template has not yet been associated with the
   * service plan
   *
   * @param key the service plan key
   * @param details the plan template details
   */
  @Override
  public void validateAddTemplateToServicePlan(ServicePlanKey key,
    PlanTemplateDetails details) throws AppException, InformationalException {

    // validate if template is not already added
    final curam.serviceplans.sl.entity.intf.PlanTemplateServicePlanLink planTemplateServicePlanLinkObj = curam.serviceplans.sl.entity.fact.PlanTemplateServicePlanLinkFactory.newInstance();

    final curam.serviceplans.sl.entity.struct.PlanTemplateServicePlanKey planTemplateServicePlanKey = new curam.serviceplans.sl.entity.struct.PlanTemplateServicePlanKey();

    curam.serviceplans.sl.entity.struct.TemplateServicePlanCount templateServicePlanCount;

    planTemplateServicePlanKey.planTemplateID = details.dtls.planTemplateID;
    planTemplateServicePlanKey.servicePlanID = key.key.servicePlanID;

    templateServicePlanCount = planTemplateServicePlanLinkObj.countByServicePlanAndTemplate(
      planTemplateServicePlanKey);

    if (templateServicePlanCount.count > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLAN.ERR_SERVICEPLAN_XFV_TEMPLATE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // validate if template is not cancelled
    final curam.serviceplans.sl.entity.struct.PlanTemplateKey planTemplateKey = new curam.serviceplans.sl.entity.struct.PlanTemplateKey();

    final curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlanTemplateStatus planTemplateStatus;

    planTemplateKey.planTemplateID = details.dtls.planTemplateID;

    planTemplateStatus = planTemplateObj.readStatus(planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates service plan and goal details before adding goal to service plan
   * service plan
   *
   * @param key contains service plan ID and goal ID
   */
  @Override
  public void validateAddGoalToServicePlan(ServicePlanGoalKey key)
    throws AppException, InformationalException {

    //
    // Check that the goal is not canceled
    //

    // read the goal status
    final curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.GoalDtls goalDtls = goalObj.read(
      key.goalKey, false);

    // is the goal canceled?
    if (goalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_XFV_GOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    //
    // Check that the goal is not already on the service plan
    //

    // populate the count key
    final curam.serviceplans.sl.entity.struct.ServicePlanAndGoalKey servicePlanAndGoalKey = new curam.serviceplans.sl.entity.struct.ServicePlanAndGoalKey();

    servicePlanAndGoalKey.goalID = key.goalKey.goalID;
    servicePlanAndGoalKey.servicePlanID = key.servicePlanKey.servicePlanID;

    // count the number of existing links between the service plan and goal
    final curam.serviceplans.sl.entity.intf.ServicePlanGoalLink servicePlanGoalLink = curam.serviceplans.sl.entity.fact.ServicePlanGoalLinkFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.ServicePlanGoalLinkCount servicePlanGoalLinkCount = servicePlanGoalLink.countByGoalIDAndServicePlanID(
      servicePlanAndGoalKey);

    // is the goal already on the service plan?
    if (servicePlanGoalLinkCount.count > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_XFV_GOAL_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * validates details before adding integrated case to service plan
   *
   * @param key contains service plan and integrated case keys
   */
  @Override
  public void validateAddICToServicePlan(ServicePlanICKey key)
    throws AppException, InformationalException {

    //
    // Check that the case is not canceled
    //

    // read the case status

    // populate the read key
    final AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();

    adminIntegratedCaseKey.adminIntegratedCaseID = key.caseKey.key.caseID;

    // read the case details
    final curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();
    final AdminIntegratedCaseDtls adminIntegratedCaseDtls = adminIntegratedCaseObj.read(
      adminIntegratedCaseKey, false);

    // is the case canceled?
    if (adminIntegratedCaseDtls.statusCode.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_XFV_CASE_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    //
    // Check that the case is not already on the service plan
    //

    // populate the count key
    final curam.serviceplans.sl.entity.struct.AdminICAndServicePlanKey adminICAndServicePlanKey = new curam.serviceplans.sl.entity.struct.AdminICAndServicePlanKey();

    adminICAndServicePlanKey.adminIntegratedCaseID = key.caseKey.key.caseID;
    adminICAndServicePlanKey.servicePlanID = key.servicePlanKey.key.servicePlanID;

    // count the number of existing links between the service plan and the case
    final curam.serviceplans.sl.entity.intf.AdminICServicePlanLink adminICServicePlanLink = curam.serviceplans.sl.entity.fact.AdminICServicePlanLinkFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.AdminICServicePlanLinkCount adminICServicePlanLinkCount = adminICServicePlanLink.countByServicePlanIDAndCaseID(
      adminICAndServicePlanKey);

    // is the case already on the service plan?
    if (adminICServicePlanLinkCount.count > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_XFV_CASE_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan type
   *
   * @param key contains service plan unique identifier
   * @return service plan type
   */
  @Override
  public ServicePlanTypeDetails readType(ServicePlanKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanTypeDetails servicePlanTypeDetails = new ServicePlanTypeDetails();

    // create service plan entity
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // read service plan type
    servicePlanTypeDetails.servicePlanTypeStruct = servicePlanObj.readType(
      key.key);

    // return service plan type
    return servicePlanTypeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists the service plan types which are active.
   *
   * @param key Identifies the status.
   * @return the ServicePlan type Detail List .
   */
  @Override
  public ServicePlanDetailList listActiveSPTypes(ServicePlanStatus key)
    throws AppException, InformationalException {

    // return struct
    final ServicePlanDetailList servicePlanDetailList = new ServicePlanDetailList();

    // create service plan entity
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // look for active service plans
    key.status.recordStatus = RECORDSTATUS.NORMAL;
    servicePlanDetailList.servicePlanDtlList = servicePlanObj.searchActiveSPTypes(
      key.status);
    return servicePlanDetailList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all existing service plan security identifiers
   *
   * @return Security identifiers list
   */
  @Override
  public SecurityIdentifierList listSIDs() throws AppException,
      InformationalException {

    // variable to hold result for return
    final SecurityIdentifierList securityIdentifierList = new SecurityIdentifierList();
    curam.core.struct.SecurityIdentifier securityIdentifier;

    final curam.core.intf.SecurityLink securityLinkObj = curam.core.fact.SecurityLinkFactory.newInstance();
    final SIDTypeKey sIDTypeKey = new SIDTypeKey();

    sIDTypeKey.sidType = curam.codetable.SECURITYIDENTIFIERTYPE.SERVICEPLAN;

    // read SIDs by type
    final SecurityIDList securityIDList = securityLinkObj.getSidsByType(
      sIDTypeKey);

    for (int i = 0; i < securityIDList.dtls.size(); i++) {
      securityIdentifier = new curam.core.struct.SecurityIdentifier();

      securityIdentifier.sidName = securityIDList.dtls.item(i).sidName;
      securityIdentifierList.securityIdentifier.addRef(securityIdentifier);

    }

    return securityIdentifierList;
  }

  // BEGIN, CR00081013, PMD
  // ___________________________________________________________________________
  /**
   * Method to list all service plan types
   *
   * @return a list of all service plan types
   */
  @Override
  public ServicePlanTypes listAllServicePlanTypes() throws AppException,
      InformationalException {

    // BEGIN, CR00087257, PMD
    // The filtered list of issue types
    final ServicePlanTypes servicePlanTypes = new ServicePlanTypes();

    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();

    // List all service plan types
    servicePlanTypes.types = servicePlanObj.searchAllTypes();

    return servicePlanTypes;
    // END, CR00087257
  }

  // END, CR00081013

  // BEGIN, CR00227878, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new TextTranslationDtlsList();
    final TextTranslation textTranslation = TextTranslationFactory.newInstance();
    final SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (final TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        throw e;
      }
    }
  }

  /**
   * Creates a text translation for the Service Plan attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Service Plan
   * attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be translated is
   * empty. {@link GENERAL#ERR_LOCALE_EMPTY} - if locale is empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * {@link BPOSERVICEPLAN#ERR_SERVICEPLAN_FV_ALREADY_CANCELED} - if
   * the service plan to be modified is canceled already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    final ServicePlanKey servicePlanKey = new ServicePlanKey();

    final ServicePlanDescriptionTextID servicePlanDescriptionTextID = new ServicePlanDescriptionTextID();
    ServicePlanDtls servicePlanDtls = new ServicePlanDtls();

    servicePlanKey.key.servicePlanID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_LOCALE_EMPTY);
    }

    servicePlanDtls = servicePlanObj.read(servicePlanKey.key);

    // Record must not be already canceled.
    if (servicePlanDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_MODIFY_CANCELED);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == servicePlanDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !servicePlanDtls.description.equals(CuramConst.gkEmpty)) {

        final AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        throw e;

      }

      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      final String value = servicePlanDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      servicePlanDescriptionTextID.descriptionTextID = textID;
      servicePlanDescriptionTextID.versionNo = servicePlanDtls.versionNo;
      servicePlanObj.modifyDescriptionTextID(servicePlanKey.key,
        servicePlanDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != servicePlanDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        servicePlanDtls.descriptionTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the Service Plan attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Service Plan
   * attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link BPOSERVICEPLAN#ERR_SERVICEPLAN_FV_ALREADY_CANCELED} - if
   * the service plan to be modified is canceled already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    final curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    final ServicePlanKey servicePlanKey = new ServicePlanKey();

    final ServicePlanDescriptionTextID servicePlanDescriptionTextID = new ServicePlanDescriptionTextID();
    ServicePlanDtls servicePlanDtls = new ServicePlanDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 11);
    }

    servicePlanKey.key.servicePlanID = localizableTextTranslationDetails.localizableTextParentID;

    servicePlanDtls = servicePlanObj.read(servicePlanKey.key);

    // Record must not be already canceled.
    if (servicePlanDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLAN.ERR_SERVICEPLAN_FV_MODIFY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == servicePlanDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      textID = localizableTextHandler.store();
      servicePlanDescriptionTextID.descriptionTextID = textID;
      servicePlanDescriptionTextID.versionNo = servicePlanDtls.versionNo;
      servicePlanObj.modifyDescriptionTextID(servicePlanKey.key,
        servicePlanDescriptionTextID);

      // BEGIN, CR00246419, GP
    } else if (0 != servicePlanDtls.descriptionTextID) {

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        servicePlanDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    } else {
      // END, CR00246419

      // Handling new Data.
      final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString()));
      localizableTextHandler.store();
    }
  }
  // END, CR00227878
}
