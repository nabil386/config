/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.message.BPOSERVICEPLANHOOKREGISTRAR;
import curam.serviceplans.sl.entity.fact.PlanItemValidatorFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemValidatorFactory;
import curam.serviceplans.sl.entity.intf.PlanItemValidator;
import curam.serviceplans.sl.entity.intf.PlannedItemValidator;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import java.lang.reflect.Method;


/**
 * Central class to handle the creation of hooks based on a particular
 * plan type.
 */
public final class ServicePlanHookManager {

  /**
   * The map containing a subclass of the PlannedItem class for each plan type.
   */
  // BEGIN, CR00198200, GYH
  protected static ServicePlanHookRegistrar.HookMap plannedItemHookMap = GuiceWrapper.getInjector().getInstance(
    ServicePlanHookRegistrar.HookMap.class);

  // END, CR00198200

  public static ServicePlanHookRegistrar.HookMap getPlannedItemHookMap() {

    return plannedItemHookMap;
  }

  /**
   * The map containing a subclass of the PlanItem class for each plan type.
   */
  // BEGIN, CR00198200, GYH
  protected static ServicePlanHookRegistrar.HookMap planItemHookMap = GuiceWrapper.getInjector().getInstance(
    ServicePlanHookRegistrar.HookMap.class);

  // END, CR00198200

  public static ServicePlanHookRegistrar.HookMap getPlanItemHookMap() {

    return planItemHookMap;
  }

  // Static initialization of Service Plan Hook Entity Map
  static {

    // Get the value of the service hook registrars environment variable
    final String registrarsString = Configuration.getProperty(
      EnvVars.ENV_SERVICEPLAN_HOOK_REGISTRARS_LIST);

    if (null != registrarsString) {

      // Get comma-separated list of registrar factory class names

      final String registrarFactoryNames[] = registrarsString.split(
        CuramConst.gkComma);

      final int numberOfRegistrars = registrarFactoryNames.length;

      for (int i = 0; i < numberOfRegistrars; i++) {

        final String registrarFactoryName = registrarFactoryNames[i];

        try {
          final Class registrarFactoryClass = Class.forName(
            registrarFactoryName);

          final Method newInstance = registrarFactoryClass.getMethod(
            ReflectionConst.kNewInstance, new Class[0]);

          final Object registrar = newInstance.invoke(null, new Object[0]);
          final ServicePlanHookRegistrar servicePlanHookRegistrar = (ServicePlanHookRegistrar) registrar;

          servicePlanHookRegistrar.registerPlannedItemDataHooks();

          // BEGIN, CR00114880
          servicePlanHookRegistrar.registerPlanItemDataHooks();
          // END, CR00114880

        } catch (final Exception e) {

          final AppException ae = new AppException(
            BPOSERVICEPLANHOOKREGISTRAR.ERR_REGISTRAR_ISSUE);

          // BEGIN, CR00155681, GYH
          ae.initCause(e);
          // END, CR00155681

          throw new AppRuntimeException(ae);
        }
      }
    }
  }

  /**
   * Gets the implementation subclass of the PlannedItem class for the specified
   * plan type.
   *
   * @param planItemType
   * The type of the plan
   *
   * @return The implementation subclass of the PlannedItem class for the
   * specified plan type.
   */
  // BEGIN, CR00138465, MC
  public static PlannedItemValidator getPlannedItemHook(
    final String planItemType) throws AppException {

    PlannedItemValidator result = (PlannedItemValidator) plannedItemHookMap.createHookInstance(
      planItemType, PlannedItemValidator.class);

    if (null == result) {
      result = PlannedItemValidatorFactory.newInstance();
    }

    return result;
  }

  /**
   * Gets the implementation subclass of the PlanItem class for the specified
   * plan type.
   *
   * @param planItemType The type of the plan
   *
   * @return The implementation subclass of the PlanItem class for the specified
   * plan type.
   */
  public static PlanItemValidator getPlanItemHook(final String planItemType)
    throws AppException {

    PlanItemValidator result = (PlanItemValidator) planItemHookMap.createHookInstance(
      planItemType, PlanItemValidator.class);

    if (null == result) {
      result = PlanItemValidatorFactory.newInstance();
    }

    return result;
  }
  // END, CR00138465
}
