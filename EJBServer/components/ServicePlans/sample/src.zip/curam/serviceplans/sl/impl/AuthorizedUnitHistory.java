/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.core.struct.UsersKey;
import curam.message.BPOPLANNEDITEM;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.BPOSERVICEUNITDELIVERY;
import curam.serviceplans.sl.entity.fact.AuthorizedUnitHistoryFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.AuthorizedUnitHistoryDtls;
import curam.serviceplans.sl.entity.struct.AuthorizedUnitHistoryDtlsList;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.AuthorizedUnitHistoryKey;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.ReadAuthorizedUnitHistoryDetails;
import curam.serviceplans.sl.struct.ReadAuthorizedUnitHistoryDetailsList;
import curam.serviceplans.sl.struct.ServicePlanPlanItemSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class AuthorizedUnitHistory extends curam.serviceplans.sl.base.AuthorizedUnitHistory {

  /**
   * Reads the Authorized Unit History Details.
   *
   * @param key
   * Contains the unique authorized unit history id.
   *
   * @return The details of the authorized unit history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view
   * this service plan.
   * @throws AppException
   * {@link BPOSERVICEUNITDELIVERY#ERR_VIEW_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view
   * this plan item.
   */
  @Override
  public ReadAuthorizedUnitHistoryDetails read(AuthorizedUnitHistoryKey key)
    throws AppException, InformationalException {

    // Entity object
    final curam.serviceplans.sl.entity.intf.AuthorizedUnitHistory authorizedUnitHistoryObj = AuthorizedUnitHistoryFactory.newInstance();

    // Return value
    final ReadAuthorizedUnitHistoryDetails readAuthorizedUnitHistoryDetails = new ReadAuthorizedUnitHistoryDetails();

    // Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Read authorized unit history details
    readAuthorizedUnitHistoryDetails.dtls = authorizedUnitHistoryObj.read(
      key.key);

    // Get the current user's full name
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = readAuthorizedUnitHistoryDetails.dtls.authorizedByUser;

    readAuthorizedUnitHistoryDetails.userFullName = usersObj.getFullName(usersKey).fullname;

    // Set the Planned Item Key
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = readAuthorizedUnitHistoryDetails.dtls.plannedItemID;

    // ServicePlanDelivery Object
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemID;

    // Read Service Plan ID
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // Check Service Plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEUNITDELIVERY.ERR_VIEW_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Return authorized unit history details
    return readAuthorizedUnitHistoryDetails;
  }

  // BEGIN, CR00000048, PMD
  // ___________________________________________________________________________
  /**
   * Clones Authorized Unit History
   *
   * @param clonedPlannedItemKey Contains the unique ID of the planned item
   * being cloned
   * @param newPlannedItemKey
   * Contains the unique ID of the planned item created as a result of cloning
   */
  @Override
  public void clone(PlannedItemIDKey clonedPlannedItemKey,
    PlannedItemIDKey newPlannedItemKey) throws AppException,
      InformationalException {

    // Authorized Unit History Entity
    final curam.serviceplans.sl.entity.intf.AuthorizedUnitHistory authorizedUnitHistoryObj = curam.serviceplans.sl.entity.fact.AuthorizedUnitHistoryFactory.newInstance();

    AuthorizedUnitHistoryDtlsList authorizedUnitHistoryDtlsList = new AuthorizedUnitHistoryDtlsList();

    // Get the list of authorized unit changes for this planned item.
    authorizedUnitHistoryDtlsList = authorizedUnitHistoryObj.searchByPlannedItemID(
      clonedPlannedItemKey.plannedItemIDKey);

    // Clone Authorized Unit History Details
    for (int i = 0; i < authorizedUnitHistoryDtlsList.dtls.size(); i++) {

      final AuthorizedUnitHistoryDtls authorizedUnitHistoryDtls = new AuthorizedUnitHistoryDtls();

      authorizedUnitHistoryDtls.assign(
        authorizedUnitHistoryDtlsList.dtls.item(i));
      authorizedUnitHistoryDtls.plannedItemID = newPlannedItemKey.plannedItemIDKey.plannedItemID;

      authorizedUnitHistoryObj.insert(authorizedUnitHistoryDtls);
    }
  }

  // END, CR00000048

  // BEGIN, CR00000180, CSH
  /**
   * Reads the Authorized Unit History Details List.
   *
   * @param key
   * Contains the unique authorized unit history id.
   * @return The list of details of the authorized unit history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDITEM#ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view
   * this service plan.
   * @throws AppException
   * {@link BPOSERVICEUNITDELIVERY#ERR_VIEW_PARTICIPANT_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view
   * this plan item.
   */
  @Override
  public ReadAuthorizedUnitHistoryDetailsList viewAuthorizationHistoryList(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Authorized Unit History Object
    final curam.serviceplans.sl.entity.intf.AuthorizedUnitHistory authorizedUnitHistoryObj = curam.serviceplans.sl.entity.fact.AuthorizedUnitHistoryFactory.newInstance();

    // Authorized Unit History entity details list struct
    AuthorizedUnitHistoryDtlsList authorizedUnitHistoryDtlsList = new AuthorizedUnitHistoryDtlsList();

    // Authorized Unit History details list struct
    final ReadAuthorizedUnitHistoryDetailsList readAuthorizedUnitHistoryDetailsList = new ReadAuthorizedUnitHistoryDetailsList();

    // User Object declarations
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    // Planned Item Object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Set the Entity Planned Item Key
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // Set the Entity Planned Item Key
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDSLKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemIDSLKey.plannedItemIDKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // ServicePlanDelivery Object
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey = new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemID;

    // Read Service Plan ID
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // Check Service Plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEUNITDELIVERY.ERR_VIEW_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Read the details list back from authorized unit history
    authorizedUnitHistoryDtlsList = authorizedUnitHistoryObj.searchByPlannedItemID(
      plannedItemIDKey);

    // Populate the readAuthorizedUnitHistoryDetailsList struct
    for (int i = 0; i < authorizedUnitHistoryDtlsList.dtls.size(); i++) {

      final ReadAuthorizedUnitHistoryDetails readAuthorizedUnitHistoryDetails = new ReadAuthorizedUnitHistoryDetails();

      readAuthorizedUnitHistoryDetails.dtls = authorizedUnitHistoryDtlsList.dtls.item(
        i);

      readAuthorizedUnitHistoryDetailsList.dtlsList.addRef(
        readAuthorizedUnitHistoryDetails);
    }

    // Populate the user full name field using the username
    for (int j = 0; j < readAuthorizedUnitHistoryDetailsList.dtlsList.size(); j++) {

      usersKey.userName = readAuthorizedUnitHistoryDetailsList.dtlsList.item(j).dtls.authorizedByUser;

      readAuthorizedUnitHistoryDetailsList.dtlsList.item(j).userFullName = usersObj.getFullName(usersKey).fullname;
    }

    // Return the details
    return readAuthorizedUnitHistoryDetailsList;
  }
  // END, CR00000180
}
