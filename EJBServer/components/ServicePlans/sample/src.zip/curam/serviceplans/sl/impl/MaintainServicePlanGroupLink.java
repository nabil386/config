/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOSERVICEPLANGROUP;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupLinkFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanGroupLink;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkKey;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.fact.ServicePlanFactory;
import curam.serviceplans.sl.intf.ServicePlan;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.UniqueID;


/**
 * provides Service Layer functionality for working with Service Plan Group
 * Links.
 */
public abstract class MaintainServicePlanGroupLink extends curam.serviceplans.sl.base.MaintainServicePlanGroupLink {

  /**
   * This method creates new SPG Link records
   *
   * @param list
   * the details list
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public void createLinks(final ServicePlanGroupLinkDtlsList list)
    throws AppException, InformationalException {

    final ServicePlanGroupLink spgLink = ServicePlanGroupLinkFactory.newInstance();
    ServicePlanGroupLinkDtls linkDtls = null;
    final int size = list.dtls.size();

    for (int i = 0; i < size; i++) {
      linkDtls = list.dtls.item(i);
      validateCreateLink(linkDtls);
      linkDtls.servicePlanGroupLinkId = UniqueID.nextUniqueID();
      spgLink.insert(linkDtls);
    }
  }

  /**
   * This method returns all the SPG Links for the given SP id
   *
   * @param spKey
   * the id of the Service Plan
   * @return ServicePlanGroupLinkDtlsList list of SPG Link records
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public ServicePlanGroupLinkDtlsList getAllForServicePlan(
    ServicePlanKey spKey) throws AppException, InformationalException {

    // use the SPGLink entity to find the details
    final ServicePlanGroupLink spgLink = ServicePlanGroupLinkFactory.newInstance();

    return spgLink.searchByServicePlanId(spKey);
  }

  /**
   * This method returns all the SPG Links for the given SPG id
   *
   * @param servicePlanGroupKey
   * the id of the SPG
   * @return ServicePlanGroupLinkDtlsList list of SPG Link records
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public ServicePlanGroupLinkDtlsList getAllForServicePlanGroup(
    ServicePlanGroupKey servicePlanGroupKey) throws AppException,
      InformationalException {

    final ServicePlanGroupLink spgLink = ServicePlanGroupLinkFactory.newInstance();

    return spgLink.searchByServicePlanGroupId(servicePlanGroupKey);
  }

  /**
   * This method removes the requested Service Plan Group Link
   *
   * @param spgLinkKey
   * the id of the SPGLink
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public void removeLink(ServicePlanGroupLinkKey spgLinkKey)
    throws AppException, InformationalException {

    final ServicePlanGroupLink spgLink = ServicePlanGroupLinkFactory.newInstance();

    spgLink.remove(spgLinkKey);
  }

  /**
   * This method removes all links for the given Service Plan Group id
   *
   * @param spgKey
   * the id of the SPG
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public void removeLinkByGroupId(ServicePlanGroupKey spgKey)
    throws AppException, InformationalException {

    // validate first
    validateRemoveLinkByGroupId(spgKey);
    final ServicePlanGroupLink spgLink = ServicePlanGroupLinkFactory.newInstance();

    try {
      spgLink.removeLinkByGroupId(spgKey);
    } catch (final RecordNotFoundException rnfe) {// ok to ignore this
    }
  }

  /**
   * The Service Plan cannot be linked to the Service Plan Group if the same
   * Service Plan is already linked and is Active. Also it cannot be linked if
   * the Service Plan Group is Cancelled.
   *
   * @param newLink
   * the Service Plan Group link details
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public void validateCreateLink(ServicePlanGroupLinkDtls newLink)
    throws AppException, InformationalException {

    // any existing link records for this Service Plan id?
    final ServicePlanGroupKey spgKey = new ServicePlanGroupKey();

    spgKey.servicePlanGroupId = newLink.servicePlanGroupId;
    // check the SPG status first
    final ServicePlanGroupDtls spgDtls = ServicePlanGroupFactory.newInstance().read(
      spgKey);

    if (spgDtls.servicePlanGroupStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANGROUP.ERR_SPG_MODIFY_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // no need to check the SP status, the selection provided to the user weeded
    // out any cancelled ones

    final ServicePlanGroupLinkDtlsList existingLinks = getAllForServicePlanGroup(
      spgKey);

    final curam.serviceplans.sl.struct.ServicePlanKey spKey = new curam.serviceplans.sl.struct.ServicePlanKey();

    final int size = existingLinks.dtls.size();

    final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
    ServicePlanGroupLinkDtls servicePlanGroupLinkDtls;

    for (int i = 0; i < size; i++) {
      servicePlanGroupLinkDtls = existingLinks.dtls.item(i);
      // look up the Service Plan of this link

      spKey.key.servicePlanID = servicePlanGroupLinkDtls.servicePlanID;
      servicePlanObj.read(spKey);
      if (servicePlanGroupLinkDtls.servicePlanID == newLink.servicePlanID) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOSERVICEPLANGROUP.ERR_SPG_DUPLICATE_SP),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }
  }

  /**
   * The link may be deleted, no logic required to prevent it
   *
   * @param key
   * the id of the SPGLink
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public void validateRemoveLink(ServicePlanGroupLinkKey key)
    throws AppException, InformationalException {// no restrictions at this
    // time.
  }

  /**
   * performs validation of link removal based on looking up links via the SPG
   * id.
   *
   * @param spgKey
   * the id of the SPG
   * @throws AppException
   * Standard application exception
   * @throws InformationalException
   * Standard information exception
   */
  @Override
  public void validateRemoveLinkByGroupId(ServicePlanGroupKey spgKey)
    throws AppException, InformationalException {

    // check that we can remove the various links
    // look up all the entries first
    final ServicePlanGroupLinkDtlsList linkedList = ServicePlanGroupLinkFactory.newInstance().searchByServicePlanGroupId(
      spgKey);
    final ServicePlanGroupLinkKey linkKey = new ServicePlanGroupLinkKey();
    final int size = linkedList.dtls.size();

    for (int i = 0; i < size; i++) {
      linkKey.servicePlanGroupLinkId = linkedList.dtls.item(i).servicePlanGroupLinkId;
      validateRemoveLink(linkKey);
    }
  }

}
