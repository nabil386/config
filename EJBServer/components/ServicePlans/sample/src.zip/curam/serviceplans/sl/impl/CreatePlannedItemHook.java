/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.serviceplans.sl.impl;


import curam.serviceplans.sl.struct.PlannedItemDetailsStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.Implementable;


/**
 * A hook definition to allow a developer to override the planned item details.
 *
 */
@Implementable
@AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
public interface CreatePlannedItemHook {

  /**
   * A hook definition to allow a developer to override the planned item
   * details.
   * curam
   * .serviceplans.sl.impl.CreatePlannedItemHook.populatePlannedItemDetails
   * (PlannedItemDetailsStruct) is the first method called in
   * curam.serviceplans.sl.intf.PlannedItem.createBasicPlanItemDetails
   * (PlannedItemDetailsStruct) method. The input is the planned
   * Item details struct with original values which may be overridden as per
   * the hook implementation. After curam
   * .serviceplans.sl.impl.CreatePlannedItemHook.populatePlannedItemDetails
   * (PlannedItemDetailsStruct) method call, rest of the OOTB business
   * processing is executed as usual.
   *
   * This allows implementers to bind custom implementation to override or
   * populate the plan item details struct which will be used by OOTB business
   * process.
   *
   * @param plannedItemDetailsStruct
   * Original Planned Item details.
   *
   * @return Plan Item Details struct with overridden values.
   */
  @AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  PlannedItemDetailsStruct populatePlannedItemDetails(
    PlannedItemDetailsStruct plannedItemDetailsStruct) throws AppException,
      InformationalException;

}
