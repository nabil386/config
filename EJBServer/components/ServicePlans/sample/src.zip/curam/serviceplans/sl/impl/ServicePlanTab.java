/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.impl;


import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.SERVICEPLANGROUPNAME;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UsersFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndICTypeDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.UsersKey;
import curam.message.BPOINTEGRATEDSERVICEPLAN;
import curam.message.BPOSERVICEPLAN;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemTabDetails;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTabKey;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupFactory;
import curam.serviceplans.sl.intf.MaintainServicePlanGroup;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryReadDetails;
import curam.serviceplans.sl.struct.ServicePlanGroupNameDtls;
import curam.serviceplans.sl.struct.ServicePlanHomeTabDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.message.CatEntry;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.NotFoundIndicator;
import java.util.Locale;


/**
 * This facade class provides the functionality for the Service Plan Tab Details
 * service layer.
 */
public abstract class ServicePlanTab extends curam.serviceplans.sl.base.ServicePlanTab {

  // BEGIN, CR00305200, AKr
  /**
   * Reads the data to be displayed on the details tab of planned item.
   *
   * @param PlannedItemKey Contains the planned item unique identifier.
   *
   * @return PlannedItemTabDtls The details to be displayed on the details tab.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PlannedItemTabDetails readPlanItemTabDetails(
    final PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    final PlannedItemTabDetails plannedItemTabDtls = new PlannedItemTabDetails();
    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemID;
    final PlannedItemDtls plannedItemDtls = PlannedItemFactory.newInstance().read(
      notFoundIndicator, plannedItemKey);

    if (!notFoundIndicator.isNotFound()) {

      plannedItemTabDtls.assign(plannedItemDtls);
      if (0 != plannedItemDtls.concerningID) {

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = plannedItemDtls.concerningID;
        final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
          concernRoleKey);

        plannedItemTabDtls.concernRoleName = concernRoleDtls.concernRoleName;
        plannedItemTabDtls.concernRoleType = concernRoleDtls.concernRoleType;
      }
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = plannedItemDtls.ownerUserName;
      plannedItemTabDtls.ownerName = UsersFactory.newInstance().getFullName(usersKey).fullname;
      plannedItemTabDtls.caseID = PlannedItemFactory.newInstance().readCaseIDByPlannedItemID(plannedItemIDKey.plannedItemIDKey).caseID;

    }
    return plannedItemTabDtls;
  }

  // END, CR00305200

  // __________________________________________________________________________
  /**
   * Reads the details for the details tab for service plan.
   *
   * @param ServicePlanDeliveryKey Contains the service plan delivery case
   * unique identifier.
   *
   * @return ServicePlanTabDetails
   * The details to be displayed on the details tab.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ServicePlanHomeTabDetails readServicePlanTabDetails(
    ServicePlanTabKey key) throws AppException, InformationalException {

    final ServicePlanHomeTabDetails servicePlanHomeTabDetails = new ServicePlanHomeTabDetails();

    // read service plan details
    final ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    ServicePlanDeliveryReadDetails servicePlanDeliveryReadDetails = new ServicePlanDeliveryReadDetails();

    final ServicePlanDeliveryKey sPDKey = new ServicePlanDeliveryKey();

    sPDKey.key.caseID = key.caseID;
    servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(sPDKey);

    servicePlanHomeTabDetails.planReference = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.caseReference;
    servicePlanHomeTabDetails.personName = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.concernRoleName;
    servicePlanHomeTabDetails.integratedCaseID = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.integratedCaseID;
    servicePlanHomeTabDetails.servicePlanType = servicePlanDeliveryReadDetails.servicePlanTypeStruct.servicePlanType;
    servicePlanHomeTabDetails.registrationDate = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.registrationDate;
    servicePlanHomeTabDetails.goalName = servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName;
    servicePlanHomeTabDetails.outcomeAchieved = servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.outcomeAchieved;
    servicePlanHomeTabDetails.statusCode = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.statusCode;

    // Read associated integrated case details for display on client screen
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseReferenceAndICTypeDetails details = new CaseReferenceAndICTypeDetails();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = servicePlanDeliveryReadDetails.participantCaseAndUserDetails.integratedCaseID;
    details = caseHeaderObj.readCaseReferenceAndICType(caseKey);

    // BEGIN, CR00386333, VT
    final Locale locale = ProgramLocale.parseLocale(
      TransactionInfo.getProgramLocale());
    // END, CR00386333

    final CatEntry catEntry = BPOINTEGRATEDSERVICEPLAN.INF_RELATED_CASE_DESCRIPTION;
    final LocalisableString info = new LocalisableString(catEntry);

    info.arg(
      curam.util.type.CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
      details.integratedCaseType, locale.toString()));
    info.arg(details.caseReference);

    servicePlanHomeTabDetails.relatedCaseDescription = info.toClientFormattedText();

    // Read the owner description details
    final CatEntry catEntry2 = BPOSERVICEPLAN.INF_OWNER_DESCRIPTION;
    final LocalisableString info2 = new LocalisableString(catEntry2);

    info2.arg(
      servicePlanDeliveryReadDetails.ownerDetails.orgObjectReferenceName);
    info2.arg(
      curam.util.type.CodeTable.getOneItem(ORGOBJECTTYPE.TABLENAME,
      servicePlanDeliveryReadDetails.ownerDetails.orgObjectType,
      locale.toString()));

    servicePlanHomeTabDetails.ownerDescription = info2.toClientFormattedText();

    // Read the service plan group details.
    // The Service Plan Group field is only supposed to be populated if the
    // Service Plan is added to a Service Plan Group within the
    // Integrated Service Plan of the case.
    final SPGDelivery sPGDeliveryObj = SPGDeliveryFactory.newInstance();
    final SPGDeliveryLink sPGDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();
    final SPGDeliveryKey sPGDeliveryKey = new SPGDeliveryKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();
    final CatEntry catEntry3 = BPOINTEGRATEDSERVICEPLAN.INF_SERVICEPLAN_GROUP_DESCRIPTION;
    final LocalisableString localisableString = new LocalisableString(catEntry3);

    try {
      sPGDeliveryKey.servicePlanGroupDeliveryId = sPGDeliveryLinkObj.readServicePlanGroupDeliveryIdByCaseId(caseHeaderKey).servicePlanGroupDeliveryId;
      servicePlanGroupKey.servicePlanGroupId = sPGDeliveryObj.read(sPGDeliveryKey).servicePlanGroupId;
      final ServicePlanGroupNameDtls servicePlanGroupNameDtls = maintainServicePlanGroupObj.readNameDtls(
        servicePlanGroupKey);

      localisableString.arg(
        CodeTable.getOneItem(SERVICEPLANGROUPNAME.TABLENAME,
        servicePlanGroupNameDtls.servicePlanGroupName, locale.toString()));
      servicePlanHomeTabDetails.servicePlanGroupDescription = localisableString.toClientFormattedText();
      servicePlanHomeTabDetails.servicePlanGroupDeliveryID = sPGDeliveryKey.servicePlanGroupDeliveryId;
    } catch (final RecordNotFoundException e) {// No need to do anything if
      // Service
      // Plan is created outside of the
      // Service Plan Group.
    }

    return servicePlanHomeTabDetails;
  }

}
