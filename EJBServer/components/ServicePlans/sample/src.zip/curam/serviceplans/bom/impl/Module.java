/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.bom.impl;


import com.google.inject.AbstractModule;
import com.google.inject.multibindings.Multibinder;
import curam.util.ctm.bom.DeleteBOM;
import curam.util.ctm.bom.DependentBOM;
import curam.util.ctm.bom.ExistenceBOM;
import curam.util.ctm.bom.InformationalBOM;
import curam.util.ctm.bom.PreCommitActionBOM;
import curam.util.ctm.bom.ReadAndUpsertBOM;
import curam.util.ctm.bom.SecurityBOM;


/**
 * Guice module class to provide binding for the service plan component.
 */
public class Module extends AbstractModule {

  /**
   * {@inheritDoc}
   */
  @Override
  protected void configure() {

    final Multibinder<ReadAndUpsertBOM> readAndUpsertBOMBinder = Multibinder.newSetBinder(
      binder(), ReadAndUpsertBOM.class);

    readAndUpsertBOMBinder.addBinding().to(
      ServicePlanReadAndUpsertBOMImpl.class);

    final Multibinder<ExistenceBOM> existenceBOMBinder = Multibinder.newSetBinder(
      binder(), ExistenceBOM.class);

    existenceBOMBinder.addBinding().to(ServicePlanExistenceBOMImpl.class);

    final Multibinder<InformationalBOM> informationalBOMBinder = Multibinder.newSetBinder(
      binder(), InformationalBOM.class);

    informationalBOMBinder.addBinding().to(
      ServicePlanInformationalBOMImpl.class);

    final Multibinder<DeleteBOM> deleteBOMBinder = Multibinder.newSetBinder(
      binder(), DeleteBOM.class);

    deleteBOMBinder.addBinding().to(ServicePlanDeleteBOMImpl.class);

    final Multibinder<SecurityBOM> securityBOMBinder = Multibinder.newSetBinder(
      binder(), SecurityBOM.class);

    securityBOMBinder.addBinding().to(ServicePlanSecurityBOMImpl.class);

    final Multibinder<DependentBOM> dependentBOMBinder = Multibinder.newSetBinder(
      binder(), DependentBOM.class);

    dependentBOMBinder.addBinding().to(ServicePlanDependentBOMImpl.class);

    final Multibinder<PreCommitActionBOM> preCommitActionBOMBinder = Multibinder.newSetBinder(
      binder(), PreCommitActionBOM.class);

    preCommitActionBOMBinder.addBinding().to(
      ServicePlanPreCommitActionBOMImpl.class);
  }
}
