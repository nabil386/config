/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2005,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.serviceplans.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachment.impl.Attachment;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.ATTACHMENTSTATUS;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CASEDECISIONSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.OUTCOMEACHIEVED;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDSUBGOALSTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANGROUPNAME;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.SUBGOALNAME;
import curam.codetable.SUBGOALTYPE;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.intf.IntegratedCase;
import curam.core.facade.intf.ParticipantContext;
import curam.core.facade.struct.CaseEventAndActivityDetails;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.CheckForWaiverIndicators;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.ICProductDeliveryEventDetails;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.ListMemberDetails;
import curam.core.facade.struct.MemberDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ReadAttachmentDetails;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.WizardProperties;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.MaintainAttachmentAssistantFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.MaintainAttachmentAssistant;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.fact.MilestoneConfigurationFactory;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.intf.MilestoneConfiguration;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.core.sl.entity.struct.MilestoneConfigurationKey;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.entity.struct.ParticipantRoleIDAndNameDetails;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.entity.struct.WaiverIndicatorDetails;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.struct.ActivityElementDetails;
import curam.core.sl.struct.CalendarElementData;
import curam.core.sl.struct.DateRangeKey;
import curam.core.sl.struct.DateTimeRangeDetails;
import curam.core.sl.struct.EventElementDetails;
import curam.core.sl.struct.RecordCount;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.AttachmentNameStruct;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseEventKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceCRNameAltIDDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.core.struct.SecurityIdentifier;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserSecurityDetails;
import curam.core.struct.UsersKey;
import curam.core.struct.ViewActiveCaseEventDetailsList1;
import curam.core.struct.ViewCaseEventDetailsList;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.message.BPOBASELINE;
import curam.message.BPOINTEGRATEDSERVICEPLAN;
import curam.message.BPOMAINTAINATTACHMENT;
import curam.message.BPOMAINTAINSERVICEPLANDELIVERY;
import curam.message.BPOPLANNEDITEM;
import curam.message.BPOSERVICEPLANCONTRACT;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANGROUPDELIVERY;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERAL;
import curam.message.GENERALCASE;
import curam.serviceplans.facade.struct.*;
import curam.serviceplans.impl.ServicePlanHelper;
import curam.serviceplans.sl.entity.fact.BaselineMilestoneFactory;
import curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemAttachmentLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.BaselineSubGoal;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemAttachmentLink;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.struct.BaselineAndMilestoneDeliveryKey;
import curam.serviceplans.sl.entity.struct.BaselineMilestoneDtls;
import curam.serviceplans.sl.entity.struct.BaselineMilestoneKey;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemKey;
import curam.serviceplans.sl.entity.struct.BaselineSensitivityCode;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalKey;
import curam.serviceplans.sl.entity.struct.ParentGroupIDKey;
import curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentLinkKey;
import curam.serviceplans.sl.entity.struct.PlannedItemEstimatedCost;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndNameDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalSensitivityCodeDetails;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedSubGoalIDDetails;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryIssuedAndAcceptStatus;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServicePlanParticipantDetails1;
import curam.serviceplans.sl.entity.struct.SubGoalNameDetails;
import curam.serviceplans.sl.fact.BaselineFactory;
import curam.serviceplans.sl.fact.ClientParticipationFactory;
import curam.serviceplans.sl.fact.MaintainSPGDeliveryLinkFactory;
import curam.serviceplans.sl.fact.MilestoneFactory;
import curam.serviceplans.sl.fact.PlannedGroupFactory;
import curam.serviceplans.sl.fact.ServicePlanContractFactory;
import curam.serviceplans.sl.fact.ServicePlanStatementFactory;
import curam.serviceplans.sl.fact.TrackingGanttFactory;
import curam.serviceplans.sl.impl.ServicePlanConst;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.serviceplans.sl.intf.Baseline;
import curam.serviceplans.sl.intf.ClientParticipation;
import curam.serviceplans.sl.intf.MaintainSPGDeliveryLink;
import curam.serviceplans.sl.intf.PlannedGroup;
import curam.serviceplans.sl.intf.ServicePlanContract;
import curam.serviceplans.sl.intf.ServicePlanDocGeneration;
import curam.serviceplans.sl.intf.ServicePlanStatement;
import curam.serviceplans.sl.intf.ServiceUnitDelivery;
import curam.serviceplans.sl.intf.TrackingGantt;
import curam.serviceplans.sl.struct.BaselineNameDetails;
import curam.serviceplans.sl.struct.BaselinePlanContentDetails;
import curam.serviceplans.sl.struct.ContractAttachmentDetails;
import curam.serviceplans.sl.struct.CreatePageDetailsStruct;
import curam.serviceplans.sl.struct.ICDetails;
import curam.serviceplans.sl.struct.PlannedItemApprovalCriteriaLinkDetailsList;
import curam.serviceplans.sl.struct.SPContractListKey;
import curam.serviceplans.sl.struct.ServicePlanDocumentTemplateCodeKey;
import curam.serviceplans.sl.struct.ServicePlanMenuData;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails;
import curam.serviceplans.sl.struct.ServicePlanParticipantDetailsList;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanStatementGroupKey;
import curam.serviceplans.sl.struct.ServicePlanStatementIntegratedKey;
import curam.serviceplans.sl.struct.TrackingGanttGroupKey;
import curam.serviceplans.sl.struct.TrackingGanttIntegratedKey;
import curam.serviceplans.sl.struct.ViewPlannedItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;
import curam.util.type.UniqueID;
import curam.util.xml.struct.XSLTemplateIDCodeKey;
import java.util.Map;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * This process class provides the functionality for the ServicePlanDelivery
 * facade layer.
 */

public abstract class ServicePlanDelivery extends curam.serviceplans.facade.base.ServicePlanDelivery {

  // BEGIN, CR00069996, SK
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kParamCaseParticipantRoleID = XmlMetaDataConst.kParamCaseParticipantRoleID;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kServicePlanHome = UimConst.kServicePlanHome;

  protected static final String kCodeTableLanguage = EnvVars.ENV_DEFAULT_LOCALE_DEFAULT;

  protected static final int kBufSize = 256;

  public static final String kSubGoalDetailsRestricted = CuramConst.gkSubGoalDetailsRestricted;

  // END, CR00069996
  // BEGIN, CR00052924, GM
  protected static final String kCuramCalendarDataHeader = CuramCalendarHeaderConst.kCuramCalendarDataHeader;

  protected static final String kCuramCalendarDataFooter = CuramCalendarHeaderConst.kCuramCalendarDataFooter;

  protected static final String kCloseBracket = CuramCalendarHeaderConst.kCloseBracket;

  protected static final String kQuote = CuramCalendarHeaderConst.kQuote;

  protected static final String kSpace = CuramConst.gkSpace;

  // END, CR00052924
  protected static final int kBufferSize = 2048;

  // BEGIN, CR00091182, CM
  protected static final String kPageCaseID = GeneralConst.gKPageCaseID;

  protected static final String kTypeCode = GeneralConst.gkTypeCode;

  protected static final String kSubGoalID = GeneralConst.gkSubGoalID;

  protected static final String kSubGoalName = GeneralConst.gkSubGoalName;

  // END, CR00091182

  // BEGIN, CR00093416, CM
  protected static final String kParentGroupID = GeneralConst.kParentGroup;

  // END, CR00093416
  // BEGIN, CR00099881, CSH
  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  // END, CR00099881

  // BEGIN CR00104430, ELG
  protected static final String kPrintContractSIDName = ServicePlanConst.kPrintContractSID;

  // END CR00104430

  // BEGIN, CR00161962, LJ
  /**
   * Integrated Service Plan homepage URL.
   */
  protected static final String kIntegratedServicePlanHome = UimConst.kIntegratedServicePlanHome;

  /**
   * Service Plan Group Delivery homepage URL.
   */
  protected static final String kServicePlanGroupDeliveryHome = UimConst.kServicePlanGroupDeliveryHome;

  /**
   * Service Plan Group Delivery url constant.
   */
  protected static final String kActiveIndFalse = ServicePlanConst.kActiveIndFalse;

  protected static final String kActiveInd = ServicePlanConst.kActiveInd;

  // END, CR00161962

  // BEGIN, CR00146458, VR
  @Inject
  protected Attachment attachment;

  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00354960

  // BEGIN, CR00350312, SS
  @Inject(optional = true)
  protected Map<String, ServicePlanHelper> servicePlanHelperObj;

  // END, CR00350312

  public ServicePlanDelivery() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00146458

  // ___________________________________________________________________________
  /**
   * Creates service plan delivery on the integrated case member level.
   *
   * @param details
   * Contains service plan type and participant role ID.
   * @param key
   * Integrated case ID.
   *
   * @return CaseID of the service plan delivery created
   */
  @Override
  public ServicePlanDeliveryKey create(
    CreateServicePlanDeliveryDetails details, IntegratedCaseMemberKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey();
    final curam.serviceplans.sl.struct.CreateServicePlanDeliveryDetails createServicePlanDeliveryDetails = new curam.serviceplans.sl.struct.CreateServicePlanDeliveryDetails();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // set the case participant role key
    caseParticipantRoleKey.caseParticipantRoleID = key.integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID;

    // read case id and participant role id
    final curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDandParticipantID(
      caseParticipantRoleKey);

    // read integrated case id
    servicePlanIntegratedCaseKey = servicePlanDeliveryObj.getIntegratedCaseID(
      key.integratedCaseMemberKey);

    // assign the details
    createServicePlanDeliveryDetails.assign(details);
    createServicePlanDeliveryDetails.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // create service plan delivery
    servicePlanDeliveryKey.servicePlanDeliveryKey = servicePlanDeliveryObj.create(
      createServicePlanDeliveryDetails, servicePlanIntegratedCaseKey);

    // return service plan delivery key
    return servicePlanDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * Creates service plan delivery on the integrated case level.
   *
   * @param details
   * Contains service plan type and participant role ID.
   * @param key
   * Integrated case ID.
   *
   * @return CaseID of the service plan delivery created
   */
  @Override
  public ServicePlanDeliveryKey ICCreate(
    ICCreateServicePlanDeliveryDetails details,
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // create service plan delivery
    servicePlanDeliveryKey.servicePlanDeliveryKey = servicePlanDeliveryObj.create(
      details.servicePlanDeliveryDetails, key.servicePlanIntegratedCaseKey);

    // return service plan delivery key
    return servicePlanDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all integrated case members and service plan types
   * available for creation on this integrated case.
   *
   * @param key
   * Contains case ID of the integrated case.
   *
   * @return List of integrated case members and service plan types .
   */
  @Override
  public ICMembersAndSPTypesDetails getAvailableICMembersAndSPTypes(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final curam.serviceplans.facade.struct.ICMembersAndSPTypesDetails icMembersAndSPTypesDetails = new curam.serviceplans.facade.struct.ICMembersAndSPTypesDetails();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.struct.ServicePlanTypesList list = new curam.serviceplans.sl.struct.ServicePlanTypesList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // integrated case must not be closed
    servicePlanDeliveryObj.validateICStatus(key.servicePlanIntegratedCaseKey);

    // read integrated case members and service plan types
    icMembersAndSPTypesDetails.icMembersAndSPTypesDetails = servicePlanDeliveryObj.getAvailableICMembersAndSPTypes(
      key.servicePlanIntegratedCaseKey);

    // assign the list of service plan types
    list.servicePlanTypeDetailsList.assign(
      icMembersAndSPTypesDetails.icMembersAndSPTypesDetails.servicePlanTypeDetailsList);

    // validate service plan types
    servicePlanDeliveryObj.validateAvailableSPTypesForCreation(list);

    // return
    return icMembersAndSPTypesDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all service plan types and integrated case members
   * available for service plan creation on the integrated case.
   *
   * @param key
   * Contains case participant role ID of the case member.
   *
   * @return List of service plan types.
   */
  @Override
  public ServicePlanTypesList getAvailableSPTypes(IntegratedCaseMemberKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanTypesList servicePlanTypesList = new ServicePlanTypesList();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // read integrated case ID of the integrated case member
    final curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey icKey = servicePlanDeliveryObj.getIntegratedCaseID(
      key.integratedCaseMemberKey);

    // integrated case must not be closed
    servicePlanDeliveryObj.validateICStatus(icKey);

    // read available service plan types for this type of integrated case
    servicePlanTypesList.servicePlanTypesList = servicePlanDeliveryObj.getAvailableSPTypes(
      icKey);

    // validate service plan types
    servicePlanDeliveryObj.validateAvailableSPTypesForCreation(
      servicePlanTypesList.servicePlanTypesList);

    // BEGIN CR00124178, GBA
    // Integrated case facade object and key
    final curam.core.facade.intf.IntegratedCase integratedCaseObj = curam.core.facade.fact.IntegratedCaseFactory.newInstance();
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID;

    servicePlanTypesList.integratedCaseMembers = integratedCaseObj.listActiveCaseMembersByCaseParticipantRoleID(
      caseParticipantRoleKey);
    // END CR00124178

    // return the list of service plan types
    return servicePlanTypesList;
  }

  // ___________________________________________________________________________
  /**
   * Reads context description for the service plan member.
   *
   * @param key
   * Contains case participant role ID.
   *
   * @return IC Service Plan Context Description details.
   */
  @Override
  protected ICServicePlanContextDescription getICMemberServicePlanContextDescription(IntegratedCaseMemberKey key)
    throws AppException, InformationalException {

    // return value
    final ICServicePlanContextDescription icServicePlanContextDescription = new ICServicePlanContextDescription();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // read integrated case details
    final curam.serviceplans.sl.struct.ICDetails icDetails = servicePlanDeliveryObj.readIntegratedCaseDetails(
      key.integratedCaseMemberKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_CONTEXT_DESCRIPTION);

    // add integrated case type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icDetails.caseReferenceConcernRoleNameCaseType.caseTypeCode));

    // add integrated case reference
    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.caseReference);

    // add plan integrated case participant name
    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.concernRoleName);

    // add plan integrated case participant reference
    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.primaryAlternateID);

    // Assign it to the return object
    icServicePlanContextDescription.description = description.toClientFormattedText();

    // return IC member service plan context description
    return icServicePlanContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Reads menu data.
   *
   * @param key
   * Contains service plan delivery case ID.
   *
   * @return Service plan delivery menu data.
   */
  @Override
  public ICServicePlanDeliveryMenuDataDetails getICServicePlanMenuData(
    ServicePlanIntegratedCaseKey key) throws AppException,
      InformationalException {

    // return value
    final ICServicePlanDeliveryMenuDataDetails icServicePlanDeliveryMenuDataDetails = new ICServicePlanDeliveryMenuDataDetails();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();
    final curam.serviceplans.sl.struct.IntegratedCaseMemberKey integratedCaseMemberKey = new curam.serviceplans.sl.struct.IntegratedCaseMemberKey();

    // Integrated case facade object and key
    final curam.core.facade.intf.IntegratedCase integratedCaseObj = curam.core.facade.fact.IntegratedCaseFactory.newInstance();
    final curam.core.facade.struct.CaseParticipantRoleIDKey caseParticipantRoleIDKey = new curam.core.facade.struct.CaseParticipantRoleIDKey();

    // read service plan menu data
    servicePlanDeliveryKey.key.caseID = key.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID;
    final curam.serviceplans.sl.struct.ServicePlanMenuData servicePlanMenuData = servicePlanDeliveryObj.readServicePlanMenuData(
      servicePlanDeliveryKey);

    // set integrated case member key
    integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID = servicePlanMenuData.caseParticipantRoleID;

    // read integrated case details
    final curam.serviceplans.sl.struct.ICDetails icDetails = servicePlanDeliveryObj.readIntegratedCaseDetails(
      integratedCaseMemberKey);

    // set case participant role key
    caseParticipantRoleIDKey.caseParticipantRoleID = servicePlanMenuData.caseParticipantRoleID;

    // get participant home page
    final curam.core.facade.struct.ParticipantHomePageName participantHomePageName = integratedCaseObj.resolveParticipantHome(
      caseParticipantRoleIDKey);

    // create description
    curam.util.exception.LocalisableString description = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // set IC type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      servicePlanMenuData.ICPageNamesICTypeAndConcernDetails.integratedCaseType));

    // set IC case reference
    description.arg(servicePlanMenuData.caseReference);

    // create root node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // create child node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      servicePlanMenuData.ICPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeCase);
    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanMenuData.integratedCaseID));

    linkElement.addContent(paramElement);

    // create participant parameter
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(servicePlanMenuData.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(
      key.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID));

    linkElement.addContent(paramElement);

    // create service plan parameter
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID, kServicePlanHome);

    description = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_SERVICE_PLAN_DESCRIPTION);

    // read service plan name and reference
    final curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = servicePlanDeliveryObj.readParticipantTypeAndReferenceDetails(
      servicePlanDeliveryKey);

    // add service plan type
    description.arg(
      new CodeTableItemIdentifier(SERVICEPLANTYPE.TABLENAME,
      spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType));

    // add service plan reference
    description.arg(
      spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails.caseReference);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(
      key.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    icServicePlanDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // return menu data
    return icServicePlanDeliveryMenuDataDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan context description.
   *
   * @param key
   * Contains service plan delivery case ID.
   *
   * @return Service Plan Context Description details.
   */
  @Override
  public SPDeliveryContextDescription getServicePlanContextDescription(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final SPDeliveryContextDescription spDeliveryContextDescription = new SPDeliveryContextDescription();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // read service plan participant and reference details
    final curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = servicePlanDeliveryObj.readParticipantTypeAndReferenceDetails(
      key.servicePlanDeliveryKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_CONTEXT_DESCRIPTION);

    // add service plan type
    description.arg(
      new CodeTableItemIdentifier(SERVICEPLANTYPE.TABLENAME,
      spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType));

    // add service plan reference
    description.arg(
      spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails.caseReference);

    // add plan participant name
    description.arg(
      spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails.concernRoleName);

    // add plan participant reference
    description.arg(
      spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails.primaryAlternateID);

    // assign it to the return object
    spDeliveryContextDescription.description = description.toClientFormattedText();

    // return service plan context description
    return spDeliveryContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Lists all service plans for the specified integrated case member.
   *
   * @param key
   * Contains case participant role ID.
   *
   * @return List of service plan details.
   */
  @Override
  public ServicePlanForICMemberList listByICMember(IntegratedCaseMemberKey key) throws AppException,
      InformationalException {

    // return value
    final ServicePlanForICMemberList servicePlanForICMemberList = new ServicePlanForICMemberList();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Integrated case facade object and key
    final curam.core.facade.intf.IntegratedCase integratedCaseObj = curam.core.facade.fact.IntegratedCaseFactory.newInstance();
    final curam.core.facade.struct.CaseParticipantRoleIDKey caseParticipantRoleIDKey = new curam.core.facade.struct.CaseParticipantRoleIDKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read service plan list
    servicePlanForICMemberList.servicePlanForICMemberList = servicePlanDeliveryObj.listByICMember(
      key.integratedCaseMemberKey);

    // read context description
    servicePlanForICMemberList.icServicePlanContextDescription = getICMemberServicePlanContextDescription(
      key);

    // read integrated case ID of the integrated case member
    final curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey icKey = servicePlanDeliveryObj.getIntegratedCaseID(
      key.integratedCaseMemberKey);

    // set the integrated case key
    final curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = icKey.servicePlanIntegratedCaseKey.caseID;

    // read integrated case menu data
    final curam.serviceplans.sl.struct.ServicePlanICMenuData servicePlanICMenuData = servicePlanDeliveryObj.readServicePlanICMenuData(
      servicePlanIntegratedCaseKey);

    // read integrated case details
    final curam.serviceplans.sl.struct.ICDetails icDetails = servicePlanDeliveryObj.readIntegratedCaseDetails(
      key.integratedCaseMemberKey);

    // set case participant role key
    caseParticipantRoleIDKey.caseParticipantRoleID = key.integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID;

    // get participant home page
    final curam.core.facade.struct.ParticipantHomePageName participantHomePageName = integratedCaseObj.resolveParticipantHome(
      caseParticipantRoleIDKey);

    // create description
    curam.util.exception.LocalisableString description = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // set IC type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      servicePlanICMenuData.ICHomePageNameAndType.integratedCaseType));

    // set IC case reference
    description.arg(servicePlanICMenuData.ICHomePageNameAndType.caseReference);

    // create root node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // create child node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      servicePlanICMenuData.ICHomePageNameAndType.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeCase);
    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(icKey.servicePlanIntegratedCaseKey.caseID));

    linkElement.addContent(paramElement);

    // create participant parameter
    linkElement = new Element(kItem);

    // set participant home page name
    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);
    description = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(
      key.integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(icKey.servicePlanIntegratedCaseKey.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    servicePlanForICMemberList.integratedCaseMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // return the list
    return servicePlanForICMemberList;
  }

  // BEGIN, CR00247294, PM
  /**
   * Lists all service plans for the specified integrated case.
   *
   * @param key
   * Contains case ID of the integrated case
   *
   * @return List of service plan details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 5.2 SP4, is replaced with
   * {@link #listByICCase(ServicePlanIntegratedCaseKey)} This method
   * is deprecated as it was not showing any information even if a
   * goal was not there for service plans. This is resolved in the
   * new method by displaying an informational message and user is
   * not allowed to edit a service plan,if goals are not there.See
   * release note: CR00215472.
   */
  @Override
  @Deprecated
  // END, CR00247294
  public ServicePlanForICList listByIntegratedCase(ServicePlanIntegratedCaseKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanForICList servicePlanForICList = new ServicePlanForICList();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register the security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read menu data
    final curam.serviceplans.sl.struct.ServicePlanICMenuData servicePlanICMenuData = servicePlanDeliveryObj.readServicePlanICMenuData(
      key.servicePlanIntegratedCaseKey);

    // read service plan list
    servicePlanForICList.servicePlanForICList = servicePlanDeliveryObj.listByIntegratedCase(
      key.servicePlanIntegratedCaseKey);

    // read context description data
    final curam.serviceplans.sl.struct.CaseReferenceAndICTypeDetails caseReferenceAndICTypeDetails = servicePlanDeliveryObj.readIntegratedCaseTypeAndReference(
      key.servicePlanIntegratedCaseKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_IC_CONTEXT_DESCRIPTION);

    // add integrated case type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      caseReferenceAndICTypeDetails.caseReferenceAndICTypeDetails.integratedCaseType));

    // add integrated case reference
    description.arg(
      caseReferenceAndICTypeDetails.caseReferenceAndICTypeDetails.caseReference);

    // assign it to the return object
    servicePlanForICList.icContextDescriptionDetails.description = description.toClientFormattedText();

    // assign menu data
    final curam.util.exception.LocalisableString icMenuDescription = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // set IC type
    icMenuDescription.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      servicePlanICMenuData.ICHomePageNameAndType.integratedCaseType));

    // set IC case reference
    icMenuDescription.arg(
      servicePlanICMenuData.ICHomePageNameAndType.caseReference);

    // create root node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // create child node
    final Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      servicePlanICMenuData.ICHomePageNameAndType.homePageName);
    linkElement.setAttribute(kDesc, icMenuDescription.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeCase);
    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    final Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(
      key.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    servicePlanForICList.integratedCaseMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // return the list
    return servicePlanForICList;

  }

  // BEGIN, CR00218024, CSH
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @deprecated since v6.0 is replaced with
   * {@link #readHomePageDetails1(ServicePlanDeliveryKey key)} This
   * method has been deprecated to introduce new user interface
   * enhancements. See release note: CR00218024.
   *
   * Reads service plan delivery details.
   */
  @Override
  @Deprecated
  public ServicePlanDeliveryHomePageDetails readHomePageDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryHomePageDetails servicePlanDeliveryHomePageDetails = new ServicePlanDeliveryHomePageDetails();

    // BEGIN, CR00147011, MR
    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read service plan details
    servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);

    // read context description
    servicePlanDeliveryHomePageDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    // assign menu data to the returned struct
    servicePlanDeliveryHomePageDetails.integratedCaseMenuDataDetails.menuData = menuData.menuData;

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.servicePlanDeliveryKey.key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883
    // END, CR00147011

    // return home page details
    return servicePlanDeliveryHomePageDetails;
  }

  // END, CR00218024

  // ___________________________________________________________________________
  /**
   * Creates a contract on a service plan case.
   *
   * @param details
   * Details to create the case contract.
   *
   * @return Returns created contract's unique identifier.
   */
  @Override
  public CreateServicePlanContractKey createContract(
    CreateServicePlanContractDetails details) throws AppException,
      InformationalException {

    // return value
    final CreateServicePlanContractKey createServicePlanContractKey = new CreateServicePlanContractKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // XSLTemplateUtility manipulation variables
    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // Set key to read latest template by name
    xslTemplateIDCodeKey.templateIDCode = TEMPLATEIDCODE.SERVICEPLANCONTRACT;

    // Read template by name
    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);

    // Map templateID to caseContractDetails to create the contract
    details.createSPContractDetails.servicePlanContractDtls.documentID = xslTemplateInstanceKey.templateID;
    details.createSPContractDetails.servicePlanContractDtls.documentVersionNo = xslTemplateInstanceKey.templateVersion;

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // create service plan delivery
    createServicePlanContractKey.createSPContractKey = servicePlanContractObj.create(
      details.createSPContractDetails);

    // return service plan delivery key
    return createServicePlanContractKey;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a contract on a service plan case.
   *
   * @param details
   * Details to create the case contract.
   */
  @Override
  public void modifyContract(ModifyServicePlanContractDetails details)
    throws AppException, InformationalException {

    // Service Plan Contract manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Call MaintainCaseContract BPO to modify the contract details
    servicePlanContractObj.modify(details.modifySPContractDetails);
  }

  // ___________________________________________________________________________
  /**
   * Prints a contract for a service plan case.
   *
   * @param key
   * unique identifier of the service plan contract.
   */
  @Override
  public void printContract(
    curam.serviceplans.facade.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    // ServicePlanContract business object
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // print contract
    servicePlanContractObj.print(key.servPlanContractKey);
  }

  // ___________________________________________________________________________
  /**
   * Views and displays the service plan contract for the user.
   *
   * @param key
   * unique identifier of the service plan contract.
   *
   * @return The details of the complete contract.
   */
  @Override
  public ReadCompleteContractDetails viewCompleteContract(
    curam.serviceplans.facade.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    // return value
    final ReadCompleteContractDetails readCompleteContractDetails = new ReadCompleteContractDetails();

    // ServicePlanContract business object
    final ServicePlanDocGeneration servicePlanDocGenerationObj = curam.serviceplans.sl.fact.ServicePlanDocGenerationFactory.newInstance();

    // Contract manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();
    final ServicePlanDocumentTemplateCodeKey servicePlanDocumentTemplateCodeKey = new ServicePlanDocumentTemplateCodeKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    servicePlanDocumentTemplateCodeKey.caseID = servicePlanContractObj.readCaseID(key.servPlanContractKey).key.caseID;
    servicePlanDocumentTemplateCodeKey.servicePlanContractID = key.servPlanContractKey.servicePlanContractID;
    servicePlanDocumentTemplateCodeKey.templateTypeCode = TEMPLATEIDCODE.SERVICEPLANCONTRACT;

    // readCompleteContractDetails.description
    readCompleteContractDetails.contactDetails = servicePlanDocGenerationObj.previewDocumentByTemplateIDCode(
      servicePlanDocumentTemplateCodeKey);

    // return the list
    return readCompleteContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * View the contract home page details
   *
   * @param key
   * unique identifier of the service plan contract.
   *
   * @return Contract home page details.
   */
  @Override
  public ReadContractHomeDetails viewContractHome(
    curam.serviceplans.facade.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadContractHomeDetails readContractHomeDetails = new ReadContractHomeDetails();

    // Service PlanContract manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Call ServicePlanContract BPO to read contract details
    readContractHomeDetails.contractDetails = servicePlanContractObj.read(
      key.servPlanContractKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = readContractHomeDetails.contractDetails.dtls.caseID;

    readContractHomeDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readContractHomeDetails;

  }

  // ___________________________________________________________________________
  /**
   * List all the contract print records for a service plan contract
   *
   * @param key
   * unique identifier of the service plan contract.
   *
   * @return List of all print history records for a service plan contract.
   */
  @Override
  public PrintContractHistoryDetailsList listContractPrintHistory(
    curam.serviceplans.facade.struct.ServicePlanContractKey key)
    throws AppException, InformationalException {

    // return value
    final PrintContractHistoryDetailsList printContractHistoryDetailsList = new PrintContractHistoryDetailsList();

    // ServicePlanContract business object
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read service plan contract print contract list
    printContractHistoryDetailsList.printContractHistoryList = servicePlanContractObj.listPrintHistory(
      key.servPlanContractKey);

    final curam.serviceplans.sl.entity.struct.ServicePlanContractKey servicePlanContractKey = new curam.serviceplans.sl.entity.struct.ServicePlanContractKey();

    servicePlanContractKey.servicePlanContractID = key.servPlanContractKey.servicePlanContractID;
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = servicePlanContractObj.readCaseID(key.servPlanContractKey).key.caseID;

    // Set SP context description
    printContractHistoryDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // return the list
    return printContractHistoryDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all the contracts for a specific service plan.
   *
   * @param key
   * unique identifier of the service plan case.
   *
   * @return list of service plan contracts.
   */
  @Override
  public ServicePlanContractDetailsList listContracts(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanContractDetailsList servicePlanContractDetailsList = new ServicePlanContractDetailsList();

    // ServicePlanContract business object
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Set caseID
    final SPContractListKey spContractListKey = new SPContractListKey();

    spContractListKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read service plan contract list
    servicePlanContractDetailsList.servPlanContractDetailsList = servicePlanContractObj.list(
      spContractListKey);

    servicePlanContractDetailsList.description = getServicePlanContextDescription(
      key);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanContractDetailsList.menuData.menuData = menuData.menuData;

    // return the list
    return servicePlanContractDetailsList;

  }

  /**
   * List all participants for a service plan delivery without any Duplicates.
   * used for combo boxed where listing all available plan participants to issue
   * a contract to.
   *
   * @param key
   * unique identifier of the service plan case.
   *
   * @return List of participants available to issue a new contract to.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSERVICEPLANCONTRACT#ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to view
   * this page.
   */
  @Override
  public ListMemberDetails listParticipantsToIssueContractTo(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    MemberDetails memberDetails;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    // Service Plan Delivery manipulation object
    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // need to read the service plan case id and plan maintenance role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    final curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // Read case id into manipulation variable
    servicePlanDeliveryKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // Read service plan id into manipulation variable
    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // now need to read the service plan case id and plan view role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEPLANCONTRACT.ERR_VIEW_CONTRACT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list plan participants
    viewCaseParticipantRole_boKey.dtls.caseID = key.servicePlanDeliveryKey.key.caseID;

    // Contract manipulation variables
    final ServicePlanContract servicePlanContractObj = ServicePlanContractFactory.newInstance();

    servicePlanContractObj.validateListParticipantsToIssueContractTo(
      key.servicePlanDeliveryKey);

    // Read the list of participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.listCaseParticipantsForIC(
      viewCaseParticipantRole_boKey);

    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    // Reserve space in memberDetailsList
    listMemberDetails.memberDetailsList.dtls.ensureCapacity(
      viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      // BEGIN, CR00146503, GBA
      caseParticipantRoleFullDetails = viewCaseParticipantRoleDetailsList.dtls.item(
        i);
      // filter the list : Primary plan participant, plan participants and
      // nominated representatives should appear in the Issue To field
      if (!caseParticipantRoleFullDetails.recordStatus.equals(
        RECORDSTATUS.CANCELLED)) {

        if (CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT.equals(
          caseParticipantRoleFullDetails.typeCode)
            || CASEPARTICIPANTROLETYPE.PLANPARTICIPANT.equals(
              caseParticipantRoleFullDetails.typeCode)
              || CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE.equals(
                caseParticipantRoleFullDetails.typeCode)) {

          memberDetails = new MemberDetails();
          memberDetails.assign(caseParticipantRoleFullDetails);

          // Add to return object
          listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
        }

      }
      // END, CR00146503
    }

    return listMemberDetails;
  }

  // ___________________________________________________________________________
  /**
   * Adds a planned item to a planned subgoal.
   *
   * @param createPlannedItemDetailsStruct
   * details of the plan item to be added.
   */
  @Override
  public void addPlanItemToSubGoal(
    CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Create the planned item
    plannedItemObj.createServicePlanPlanItem(
      createPlannedItemDetailsStruct.createPlannedItemDetailsStruct);
  }

  // BEGIN, CR00235251, TV
  // ___________________________________________________________________________
  /**
   * Adds a basic planned item to a planned subgoal.
   *
   * @param createPlannedItemDetailsStruct
   * details of the plan item to be added.
   *
   * @deprecated Since Curam v6, replaced with
   * {@link createBasicPlanItemToSubGoal}.
   * Reason:- As per code line issue, the
   * attribute 'planTemplatePlanItemID' removed from
   * 'CreatePlannedItemDetailsStruct' struct and added into
   * 'PlannedItemDetailsStruct' struct along with existing attribute
   * of 'CreatePlannedItemDetailsStruct' struct.
   * See release note <CR00235251>
   */
  @Override
  // END, CR00235251
  @Deprecated
  public void addBasicPlanItemToSubGoal(
    curam.serviceplans.facade.struct.CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Create the planned item
    plannedItemObj.createBasicPlanItem(
      createPlannedItemDetailsStruct.createPlannedItemDetailsStruct);
  }

  // ___________________________________________________________________________
  /**
   * Approves the planned item.
   *
   * @param plannedItemIDKey
   * unique identifier of the planned item to be approved.
   */

  @Override
  public void approvePlanItem(PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItemApprovalRequest business object
    final curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // Approve the planned item
    plannedItemApprovalRequestObj.approve(plannedItemIDKey.plannedItemIDKey);

  }

  // ___________________________________________________________________________
  /**
   * Submits the planned item.
   *
   * @param plannedItemIDKey
   * unique identifier of the planned item to be submitted.
   */
  @Override
  public void submitPlanItem(PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // Submit the planned item
    plannedItemApprovalRequestObj.submit(plannedItemIDKey.plannedItemIDKey);
  }

  // ___________________________________________________________________________
  /**
   * Deletes the planned item.
   *
   * @param plannedItemIDKey
   * unique identifier of the planned item to be deleted.
   */
  @Override
  public PlannedSubGoalAndCaseIDStruct deletePlanItem(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return struct
    final PlannedSubGoalAndCaseIDStruct plannedSubGoalAndCaseIDStruct = new PlannedSubGoalAndCaseIDStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    final ViewPlannedItemDetails viewPlannedItemDetailsStruct = plannedItemObj.readPlannedItemDetails(
      plannedItemIDKey.plannedItemIDKey);

    plannedSubGoalAndCaseIDStruct.caseID = viewPlannedItemDetailsStruct.caseID;

    plannedSubGoalAndCaseIDStruct.plannedSubGoalID = viewPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Delete the planned item
    plannedItemObj.removeServicePlanPlanItem(plannedItemIDKey.plannedItemIDKey);

    // return details
    return plannedSubGoalAndCaseIDStruct;

  }

  // ___________________________________________________________________________
  /**
   * Rejects the planned item.
   *
   * @param plannedItemIDKey
   * unique identifier of the planned item to be rejected.
   */
  @Override
  public void rejectPlanItem(
    PlannedItemIDKey plannedItemIDKey,
    curam.serviceplans.facade.struct.RejectionReasonAndRejectionComments details)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // Reject the planned item
    plannedItemApprovalRequestObj.reject(plannedItemIDKey.plannedItemIDKey,
      details.rejectionReasonAndCommentsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Lists all the planItems for a specific sub goal.
   *
   * @param plannedSubGoalIDStruct
   * unique identifier of the sub goal.
   *
   * @return List of planItems defined for the sub goal.
   */
  @Override
  public PlanItemSummaryDetailsList listPlanItemsForSubGoal(
    PlannedSubGoalIDStruct plannedSubGoalIDStruct) throws AppException,
      InformationalException {

    // Return Struct
    final PlanItemSummaryDetailsList planItemSummaryDetailsList = new PlanItemSummaryDetailsList();

    // BEGIN, CR00082647, CM
    final curam.serviceplans.facade.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

    // PlannedSubGoal object
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // plannedSubGoalKey struct
    final PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // END, CR00082647

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // List all planItems for the planned sub goal
    planItemSummaryDetailsList.planItemSummaryDetailsList = plannedItemObj.listPlannedSubGoalPlanItems(
      plannedSubGoalIDStruct.plannedSubGoalIDStruct);

    // BEGIN, CR00082647, CM
    // set the key
    plannedSubGoalKey.plannedSubGoalKey.key.plannedSubGoalID = plannedSubGoalIDStruct.plannedSubGoalIDStruct.plannedSubGoalIDStruct.plannedSubGoalID;

    // read the caseID
    ReadCaseIDByPlannedSubGoalIDDetails caseID = new ReadCaseIDByPlannedSubGoalIDDetails();

    caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(
      plannedSubGoalKey.plannedSubGoalKey.key);

    // set the key
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseID.caseID;

    planItemSummaryDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);
    // END, CR00082647

    // Return the list
    return planItemSummaryDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the service plan basic planItem.
   *
   * @param modifyPlannedItemDetailsStruct
   * details to be modified.
   */
  @Override
  public ModifyPlanItemReturnStruct modifyBasicPlanItem(
    ModifyPlannedItemDetailsStruct modifyPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    final ModifyPlanItemReturnStruct modifyPlanItemReturnStruct = new ModifyPlanItemReturnStruct();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // planned sub goal object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Modify the basic planned item
    plannedItemObj.modifyBasicPlanItem(
      modifyPlannedItemDetailsStruct.modifyPlannedItemDetailsStruct);

    modifyPlanItemReturnStruct.plannedSubGoalID = modifyPlannedItemDetailsStruct.modifyPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Read Case ID by planned Subgoal id
    plannedItemIDKey.plannedItemID = modifyPlannedItemDetailsStruct.modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    modifyPlanItemReturnStruct.caseID = plannedItemEntObj.readCaseIDByPlannedItemID(plannedItemIDKey).caseID;

    return modifyPlanItemReturnStruct;

  }

  // ___________________________________________________________________________
  /**
   * Modifies the planned item.
   *
   * @param modifyPlannedItemDetailsStruct
   * details to be modified.
   */
  @Override
  public void modifyServicePlanPlanItem(
    ModifyPlannedItemDetailsStruct modifyPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Modify the planned item
    plannedItemObj.modifyServicePlanPlanItem(
      modifyPlannedItemDetailsStruct.modifyPlannedItemDetailsStruct);

  }

  // ___________________________________________________________________________
  /**
   * Reads the details of the Create Page defined for a planned item.
   *
   * @param planItemIDDetailsStruct
   * unique identifier of the planned item.
   *
   * @return Details of the create plan item page including URL
   */
  @Override
  public CreatePageDetailsStruct resolveCreatePlanItemPage(
    PlanItemIDDetailsStruct planItemIDDetailsStruct) throws AppException,
      InformationalException {

    // Return Struct
    CreatePageDetailsStruct createPageDetailsStruct = new CreatePageDetailsStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Read the Create Page Details defined for the PlanItem
    createPageDetailsStruct = plannedItemObj.readCreatePageDetails(
      planItemIDDetailsStruct.planItemIDDetailsStruct);

    return createPageDetailsStruct;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of the Modify Page defined for a planned item.
   *
   * @param plannedItemIDKey
   * unique identifier of the planned item.
   *
   * @return Details of the modify plan item page including URL
   */
  @Override
  public ModifyPageDetailsStruct resolveModifyPlanItemPage(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return Struct
    final ModifyPageDetailsStruct modifyPageDetailsStruct = new ModifyPageDetailsStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Read the Modify Page Details defined for the PlanItem
    modifyPageDetailsStruct.modifyPageDetailsStruct = plannedItemObj.readModifyPage(
      plannedItemIDKey.plannedItemIDKey);

    return modifyPageDetailsStruct;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of the View Page defined for a planned item.
   *
   * @param plannedItemIDKey
   * unique identifier of the planned item.
   *
   * @return Details of the view plan item page including URL
   */
  @Override
  public ViewPageDetailsStruct resolveViewPlanItemPage(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Return Struct
    final ViewPageDetailsStruct viewPageDetailsStruct = new ViewPageDetailsStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Read the Modify Page Details defined for the PlanItem
    viewPageDetailsStruct.viewPageDetailsStruct = plannedItemObj.readViewPage(
      plannedItemIDKey.plannedItemIDKey);

    return viewPageDetailsStruct;
  }

  // ___________________________________________________________________________
  /**
   * */
  @Override
  public ViewPlannedItemDetailsStruct viewPlanItem(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // Create return struct
    final ViewPlannedItemDetailsStruct viewPlannedItemDetailsStruct = new ViewPlannedItemDetailsStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    try {
      viewPlannedItemDetailsStruct.plannedItemDetails = plannedItemObj.readPlannedItemDetails(
        key.plannedItemIDKey);
    } catch (final RecordNotFoundException e) {
      throw new AppException(
        BPOBASELINE.BASELINE_PLAN_ITEM_RV_PLANNED_ITEM_DELETED);
    }

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = viewPlannedItemDetailsStruct.plannedItemDetails.caseID;

    viewPlannedItemDetailsStruct.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // BEGIN CR00109001, GBA
    viewPlannedItemDetailsStruct.participants.list = plannedItemObj.getResponsibleParticipantsForPlannedItem(key.plannedItemIDKey).list;
    // END CR00109001

    return viewPlannedItemDetailsStruct;
  }

  // BEGIN, CR00226831, LP
  // ___________________________________________________________________________
  /**
   * Reads the the possible outcomes and Goal Name for a plan item
   *
   * @param plannedSubGoalKey
   * Contains the planned sub-goal id.
   * @return The Sub Goal Name
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link ServicePlanDelivery# readPossibleOutcomesAndSubGoalNameDetailsForPlanItem (PlannedSubGoalKey, PlanItemKey)}
   * .
   * In addition to the current functionality, the new method return struct
   * curam.serviceplans.facade.struct.ExpectedOutcomesForPlanItemDtlsList
   * contains all the fields of ExpectedOutcomesForPlanItemList along with
   * field guidanceURL.
   * See release note : <CR00226831>
   */
  @Override
  @Deprecated
  public curam.serviceplans.facade.struct.ExpectedOutcomesForPlanItemList readPossibleOutcomesAndSubGoalNameForPlanItem(
    PlannedSubGoalKey plannedSubGoalKey,
    curam.serviceplans.facade.struct.PlanItemKey planItemKey)
    throws AppException, InformationalException {

    final curam.serviceplans.facade.struct.ExpectedOutcomesForPlanItemList expectedOutcomesForPlanItemList = new curam.serviceplans.facade.struct.ExpectedOutcomesForPlanItemList();

    final ExpectedOutcomesForPlanItemDtlsList expOutcomesPIDtlsList = readPossibleOutcomesAndSubGoalNameDetailsForPlanItem(
      plannedSubGoalKey, planItemKey);

    expectedOutcomesForPlanItemList.subGoalName = expOutcomesPIDtlsList.subGoalName;
    expectedOutcomesForPlanItemList.planItemName = expOutcomesPIDtlsList.planItemName;
    expectedOutcomesForPlanItemList.outcomesForPlanItem = expOutcomesPIDtlsList.outcomesForPlanItem;
    expectedOutcomesForPlanItemList.participantList = expOutcomesPIDtlsList.participantList;
    expectedOutcomesForPlanItemList.respParticipantList = expOutcomesPIDtlsList.respParticipantList;

    return expectedOutcomesForPlanItemList;
  }

  // END, CR00226831
  // ___________________________________________________________________________
  /**
   * Lists all the sub-goals for a specific service plan.
   *
   * @param plannedSubGoalCaseIDKey
   * unique identifier of the service plan case.
   *
   * @return List of sub-goals associated with the service plan case.
   */
  @Override
  public PlannedSubGoalList listPlannedSubGoals(
    PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey) throws AppException,
      InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.struct.ListPlannedSubGoalDetailsList plannedSubGoalListSL = null;
    // return value
    final PlannedSubGoalList plannedSubGoalList = new PlannedSubGoalList();

    ServicePlanSecurityImplementationFactory.register();

    // call service layer for list
    plannedSubGoalListSL = plannedSubGoalObj.list(
      plannedSubGoalCaseIDKey.plannedSubGoalCaseIDKey);

    // set facade list attribute to the service layers list just retrieved
    plannedSubGoalList.plannedSubGoalList = plannedSubGoalListSL;

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedSubGoalCaseIDKey.plannedSubGoalCaseIDKey.key.caseID;

    plannedSubGoalList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return plannedSubGoalList;
  }

  // ___________________________________________________________________________
  /**
   * Checks to see if a goal exists when listing sub-goal types for a specific
   * service plan
   *
   * @param plannedSubGoalCaseIDKey
   * unique identifier of the service plan case.
   *
   * @return The planned sub gaol type list.
   */
  @Override
  public PlannedSubGoalTypeCodeDetailsList validateGoalExistsAndReturnSubGoalTypes(
    PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey) throws AppException,
      InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // BEGIN, CR00082647, CM
    // ServicePlanDeliveryKey
    final curam.serviceplans.facade.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

    // END, CR00082647

    ServicePlanSecurityImplementationFactory.register();

    // call service layer to see if planned goal exists
    plannedSubGoalObj.validateGoalExistsAndReturnSubGoalTypes(
      plannedSubGoalCaseIDKey.plannedSubGoalCaseIDKey);
    // BEGIN,CR00109753,SK
    String kCodeTableDefaultLanguage = curam.util.resources.Configuration.getProperty(
      curam.core.impl.EnvVars.ENV_DEFAULT_LOCALE);

    // If it's not set, use the default
    if (kCodeTableDefaultLanguage == null) {
      kCodeTableDefaultLanguage = kCodeTableLanguage;
    }
    // END CR00109753

    // Get the list of codetable values for sub goal type
    final StringList subGoalType = CodeTable.getAllCodesStringList(
      SUBGOALTYPE.TABLENAME, kCodeTableLanguage);

    final PlannedSubGoalTypeCodeDetailsList plannedSubGoalTypeCodeDetailsList = new PlannedSubGoalTypeCodeDetailsList();

    if (subGoalType != null) {

      // Return a list of subgoal types from the SubGoalType codetable.
      for (int i = 0; i < subGoalType.size(); i++) {
        final PlannedSubGoalTypeCodeDetails plannedSubGoalTypeCodeDetails = new PlannedSubGoalTypeCodeDetails();

        // BEGIN, CR00096677, SK
        if (CodeTable.isEnabled(SUBGOALTYPE.TABLENAME, subGoalType.item(i),
          kCodeTableLanguage)) {
          plannedSubGoalTypeCodeDetails.plannedSubGoalTypeCodeDetails.typeCode = subGoalType.item(
            i);

          plannedSubGoalTypeCodeDetailsList.listSubGoalType.addRef(
            plannedSubGoalTypeCodeDetails);
        }
        // END, CR00096677
      }
    }

    // BEGIN, CR00082647, CM
    // set the key
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedSubGoalCaseIDKey.plannedSubGoalCaseIDKey.key.caseID;

    // set the context description
    plannedSubGoalTypeCodeDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);
    // END, CR00082647

    return plannedSubGoalTypeCodeDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals of a certain type that could be assigned to a goal
   *
   * @param subGoalType
   * sub goal type identifier and unique identifier of the service plan
   * delivery.
   *
   * @return List of sub goals associated with the particular goal and sub goal
   * type.
   */
  @Override
  public PlannedSubGoalListByTypeDetailsList listSubGoalsOfType(
    PlannedSubGoalTypeCodeKey subGoalType) throws AppException,
      InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // return object
    final PlannedSubGoalListByTypeDetailsList plannedSubGoalListByTypeDetailsList = new PlannedSubGoalListByTypeDetailsList();

    ServicePlanSecurityImplementationFactory.register();
    // get sub-goals of requested type
    plannedSubGoalListByTypeDetailsList.plannedSubGoalListByTypeDetailsList = plannedSubGoalObj.select(
      subGoalType.plannedSubGoalTypeCodeKey,
      subGoalType.plannedSubGoalCaseIDKey);

    return plannedSubGoalListByTypeDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Creates a planned sub-goal for a service plan
   *
   * @param createPlannedSubGoalDetails
   * for the creation of the planned sub-goal
   */
  @Override
  public void createPlannedSubGoal(
    CreatePlannedSubGoalDetails createPlannedSubGoalDetails)
    throws AppException, InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    ServicePlanSecurityImplementationFactory.register();

    plannedSubGoalObj.create(
      createPlannedSubGoalDetails.createPlannedSubGoalDetails);

  }

  // ___________________________________________________________________________
  /**
   * Removes physically a planned sub-goal
   *
   * @param plannedSubGoalKey
   * unique identifier of the planned sub-goal.
   */
  @Override
  public void removePlannedSubGoal(PlannedSubGoalKey plannedSubGoalKey)
    throws AppException, InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00350312, SS
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalIDKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    plannedSubGoalIDKey.plannedSubGoalID = plannedSubGoalKey.plannedSubGoalKey.key.plannedSubGoalID;

    if (null != servicePlanHelperObj) {
      // Remove the corresponding provider planned item details
      servicePlanHelperObj.get("PROVIDERPLANNEDITEMLINK").remove(
        plannedSubGoalIDKey);
    }
    // END, CR00350312
    plannedSubGoalObj.remove(plannedSubGoalKey.plannedSubGoalKey);
  }

  // ___________________________________________________________________________
  /**
   * Modifies a planned sub-goal
   *
   * @param modifyPlannedSubGoalDetails
   * of the modified planned sub-goal.
   */
  @Override
  public void modifyPlannedSubGoal(
    ModifyPlannedSubGoalDetails modifyPlannedSubGoalDetails)
    throws AppException, InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    ServicePlanSecurityImplementationFactory.register();
    plannedSubGoalObj.modify(
      modifyPlannedSubGoalDetails.modifyPlannedSubGoalDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a planned sub-goal
   *
   * @param plannedSubGoalKey
   * unique identifier of the planned sub-goal.
   *
   * @return Details of the planned sub-goal.
   */
  @Override
  public ReadPlannedSubGoalDetailsForModification viewPlannedSubGoal(
    PlannedSubGoalKey plannedSubGoalKey) throws AppException,
      InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObjSL = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // return object
    final ReadPlannedSubGoalDetailsForModification readPlannedSubGoalDetailsForModification = new ReadPlannedSubGoalDetailsForModification();

    ServicePlanSecurityImplementationFactory.register();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // read planned sub-goal
    readPlannedSubGoalDetailsForModification.readPlannedSubGoalDetailsForModification = plannedSubGoalObjSL.readForModification(
      plannedSubGoalKey.plannedSubGoalKey);

    // read case id for context description
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey.plannedSubGoalKey.key).caseID;

    readPlannedSubGoalDetailsForModification.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readPlannedSubGoalDetailsForModification;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a planned sub-goal and its corresponding planned items
   *
   * @param plannedSubGoalKey
   * unique identifier of the planned sub-goal.
   *
   * @return Details of the planned sub-goal and its planned items.
   */
  @Override
  public ReadPlannedSubGoalDetailsWithPlannedItemsDetails viewPlannedSubGoalWithPlannedItems(PlannedSubGoalKey plannedSubGoalKey)
    throws AppException, InformationalException {

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // return object
    final ReadPlannedSubGoalDetailsWithPlannedItemsDetails readPlannedSubGoalDetailsWithPlannedItemsDetails = new ReadPlannedSubGoalDetailsWithPlannedItemsDetails();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    ServicePlanSecurityImplementationFactory.register();

    // read planned sub-goal details and planned items of planned sub-goal
    readPlannedSubGoalDetailsWithPlannedItemsDetails.readPlannedSubGoalDetails = plannedSubGoalObj.read(
      plannedSubGoalKey.plannedSubGoalKey);
    readPlannedSubGoalDetailsWithPlannedItemsDetails.plannedItemsForPlannedSubgoal = plannedSubGoalObj.readPlannedItemsForPlannedSubgoal(
      plannedSubGoalKey.plannedSubGoalKey);

    // BEGIN, CR00053508, PMD
    // Read the list of milestones for this planned sub goal
    readPlannedSubGoalDetailsWithPlannedItemsDetails.milestoneList = plannedSubGoalObj.readMilestonesForPlannedSubGoal(
      plannedSubGoalKey.plannedSubGoalKey);
    // END, CR00053508

    // read case id for context description
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = readPlannedSubGoalDetailsWithPlannedItemsDetails.readPlannedSubGoalDetails.servicePlanDeliveryID;

    readPlannedSubGoalDetailsWithPlannedItemsDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readPlannedSubGoalDetailsWithPlannedItemsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the Contract Client Name and Participant Role ID based on the Case
   * Participant Role ID passed in.
   *
   * @param key
   * unique identifier of the planned sub-goal.
   *
   * @return Details of the Client Name and Participant Role ID
   */
  @Override
  public ContractClientNameAndParticipantRoleID readContractIssuerDetails(
    CaseParticipantRoleIDKey key) throws AppException, InformationalException {

    final ContractClientNameAndParticipantRoleID contractClientNameAndParticipantRoleID = new ContractClientNameAndParticipantRoleID();

    // BEGIN, CR00087706, KH
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Set key and read participant details
    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;
    final ParticipantRoleIDAndNameDetails participantRoleIDAndNameDetails = caseParticipantRoleObj.readParticipantRoleIDAndParticpantName(
      caseParticipantRoleKey);

    // Assign data to return struct
    contractClientNameAndParticipantRoleID.name = participantRoleIDAndNameDetails.name;
    contractClientNameAndParticipantRoleID.participantRoleID = participantRoleIDAndNameDetails.participantRoleID;
    // END, CR00087706

    return contractClientNameAndParticipantRoleID;

  }

  // ___________________________________________________________________________
  /**
   * Compare a baseline with another baseline or with a current plan.
   *
   * @param key
   * contains original baseline ID and the ID of the baseline/plan to
   * be compared with original baseline
   *
   * @return Details in form of XML string to be displayed as Gantt diagram
   */
  @Override
  public BaselineComparisonGanttDetails compareBaselines(
    BaselineCompareKey key) throws AppException, InformationalException {

    // return value
    final BaselineComparisonGanttDetails baselineComparisonGanttDetails = new BaselineComparisonGanttDetails();

    // Baseline business object
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // register service plan security
    curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

    // compare baselines
    baselineComparisonGanttDetails.baselineCompareDetails = baselineObj.compare(
      key.baselineCompareKey);

    // read context description
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.baselineCompareKey.caseID;
    baselineComparisonGanttDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    baselineComparisonGanttDetails.menuData.menuData = menuData.menuData;

    return baselineComparisonGanttDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads current baseline name and the list of all existing baselines for the
   * service plan.
   *
   * @param key
   * contains original baseline ID and service plan delivery ID
   *
   * @return Original baseline name and list of all other baselines created for
   * the service plan delivery
   */
  @Override
  public ExistingBaselinesDetails readBaselinesForComparison(
    BaselineIDAndCaseIDKey key) throws AppException, InformationalException {

    // return value
    final ExistingBaselinesDetails existingBaselinesDetails = new ExistingBaselinesDetails();

    // Baseline business object
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // read baselines for comparison
    existingBaselinesDetails.existingBaselinesDetails = baselineObj.readBaselinesForComparison(
      key.baselineIDAndCaseIDKey);

    // read context description
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.baselineIDAndCaseIDKey.baselineIDAndCaseIDKey.caseID;
    existingBaselinesDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return existingBaselinesDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a baseline
   *
   * @param modifyBaselineDetails
   * of the modified baseline.
   */
  @Override
  public void modifyServicePlanBaseline(
    ModifyBaselineDetails modifyBaselineDetails) throws AppException,
      InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    // modify baseline
    baselineObj.modify(modifyBaselineDetails.modifyDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates a service plan baseline
   *
   * @param createBaselineDetails
   * Details to be inserted
   *
   * @return unique identifier of the created baseline.
   */
  @Override
  public BaselineReturnKey createServicePlanBaseline(
    CreateBaselineDetails createBaselineDetails) throws AppException,
      InformationalException {

    final BaselineReturnKey baselineReturnKey = new BaselineReturnKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    // create baseline
    baselineReturnKey.returnKey = baselineObj.create(
      createBaselineDetails.createDetails);

    // return baseline key
    return baselineReturnKey;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a service plan baseline
   *
   * @param baselineKey
   * unique identifier of the baseline.
   *
   * @return Details of the baseline
   */
  @Override
  public ReadBaselineDetails viewBaselineHome(
    curam.serviceplans.facade.struct.BaselineKey baselineKey)
    throws AppException, InformationalException {

    // Baseline manipulation variables
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    // Baseline manipulation variables
    final curam.serviceplans.sl.entity.intf.Baseline baselineObjEntity = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // return struct
    final ReadBaselineDetails readBaselineDetails = new ReadBaselineDetails();

    readBaselineDetails.readDetails = baselineObj.read(baselineKey.key);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = baselineObjEntity.readCaseIDByBaselineID(baselineKey.key.baselineKey).caseID;

    readBaselineDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readBaselineDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a planned sub-goal and it's corresponding planned
   * items
   *
   * @param baselineCaseIDKey
   * unique identifier of the planned sub-goal.
   *
   * @return Details of the planned sub-goal and it's planned items.
   */
  @Override
  public BaselineDetailsList listServicePlanBaselines(
    BaselineCaseIDKey baselineCaseIDKey) throws AppException,
      InformationalException {

    // return value
    final BaselineDetailsList baselineDetailsList = new BaselineDetailsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Baseline manipulation variables
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    // Set caseID
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = baselineCaseIDKey.baselineCaseKey.baselineCaseIDKey.caseID;

    // read service plan contract list
    baselineDetailsList.listDetails = baselineObj.list(
      baselineCaseIDKey.baselineCaseKey);

    baselineDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = baselineCaseIDKey.baselineCaseKey.baselineCaseIDKey.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    baselineDetailsList.menuData.menuData = menuData.menuData;

    // return the list
    return baselineDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Removes a service plan baseline
   *
   * @param baselineKey
   * unique identifier of the baseline.
   */
  @Override
  public void removeServicePlanBaseline(
    curam.serviceplans.facade.struct.BaselineKey baselineKey)
    throws AppException, InformationalException {

    // Baseline manipulation variables
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Remove baseline
    baselineObj.remove(baselineKey.key);
  }

  /**
   * Reads the details of a service plan baseline subgoal.
   *
   * @param baselineSubGoalKey
   * Contains the unique identifier of the baseline.
   *
   * @return Details of the baseline subgoal.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BaselineSubGoalDetails viewServicePlanBaselineSubGoalDetails(
    curam.serviceplans.facade.struct.BaselineSubGoalKey baselineSubGoalKey)
    throws AppException, InformationalException {

    // Baseline manipulation variables
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    final BaselineSubGoalDetails baselineSubGoalDetails = new BaselineSubGoalDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Read baseline
    baselineSubGoalDetails.baselineSubGoalDetails = baselineObj.readSubgoalBaseline(
      baselineSubGoalKey.key);

    final curam.serviceplans.sl.entity.intf.Baseline baselineObjEnt = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();

    baselineKey.baseLineID = baselineSubGoalDetails.baselineSubGoalDetails.baselineSubGoalDetails.baseLineID;

    final curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    // Note
    // This processing has to be done at the presentation layer, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct
    // type, e.g. expectedStartDate -> DATE and not a string.
    final BaselinePlanItemDetailsForBaselineSubGoalList baselinePlanItemDetailsForBaselineSubGoalList = new BaselinePlanItemDetailsForBaselineSubGoalList();

    for (int i = 0; i
      < baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.size(); i++) {

      final BaselinePlanItemDetailsForBaselineSubGoal baselinePlanItemDetailsForBaselineSubGoal = new BaselinePlanItemDetailsForBaselineSubGoal();
      final BaselinePlanItemKey baselinePlanItemKey = new BaselinePlanItemKey();

      // get sensitivity level for each baseline plan item
      baselinePlanItemKey.baselinePlanItemID = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).baselinePlanItemID;
      final BaselineSensitivityCode baselineSensitivityCode = baselinePlanItemObj.readSensitivityCode(
        baselinePlanItemKey);

      baselinePlanItemDetailsForBaselineSubGoal.plannedItemID = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).plannedItemID;
      baselinePlanItemDetailsForBaselineSubGoal.name = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).name;
      baselinePlanItemDetailsForBaselineSubGoal.baselinePlanItemID = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).baselinePlanItemID;

      // if baseline plan item sensitivity high than user sensitivity then
      // replace with ********
      if (Integer.parseInt(baselineSensitivityCode.sensitivityCode)
        > Integer.parseInt(userSecurityDetails.sensitivity)) {

        // BEGIN, CR00002667, PMD
        baselinePlanItemDetailsForBaselineSubGoal.actualEndDate = curam.util.type.Date.kZeroDate;
        baselinePlanItemDetailsForBaselineSubGoal.actualStartDate = curam.util.type.Date.kZeroDate;
        baselinePlanItemDetailsForBaselineSubGoal.expectedStartDate = curam.util.type.Date.kZeroDate;
        baselinePlanItemDetailsForBaselineSubGoal.expectedEndDate = curam.util.type.Date.kZeroDate;
        // END, CR00002667

      } else {

        // BEGIN, CR00002667, PMD
        baselinePlanItemDetailsForBaselineSubGoal.actualStartDate = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).actualStartDate;
        baselinePlanItemDetailsForBaselineSubGoal.actualEndDate = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).actualEndDate;
        baselinePlanItemDetailsForBaselineSubGoal.expectedStartDate = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).expectedStartDate;
        baselinePlanItemDetailsForBaselineSubGoal.expectedEndDate = baselineSubGoalDetails.baselineSubGoalDetails.baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i).expectedEndDate;
        // END, CR00002667
      }

      // Add each filtered record to overall struct.
      baselinePlanItemDetailsForBaselineSubGoalList.list.addRef(
        baselinePlanItemDetailsForBaselineSubGoal);
    }
    // Assign filtered struct
    baselineSubGoalDetails.baselinePlanItemsDetailsList = baselinePlanItemDetailsForBaselineSubGoalList;

    // Set caseID
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = baselineObjEnt.readCaseIDByBaselineID(baselineKey).caseID;

    // return description
    baselineSubGoalDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return baselineSubGoalDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads the list for the plan content.
   *
   * @param baselineKey
   * unique identifier of the baseline.
   *
   * @return List of the baseline plan content.
   */
  @Override
  public BaselinePlanContentList viewBaselinePlanContentList(
    curam.serviceplans.facade.struct.BaselineKey baselineKey)
    throws AppException, InformationalException {

    // Baseline manipulation variables
    final curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    final BaselinePlanContentList baselinePlanContentList = new BaselinePlanContentList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Baseline manipulation variables
    final BaselineSubGoal baselineSubGoalObj = BaselineSubGoalFactory.newInstance();

    BaselinePlanContentDetails baselinePlanContentDetailsSL = new BaselinePlanContentDetails();

    baselinePlanContentDetailsSL = baselineObj.listBaselinePlanContent(
      baselineKey.key);

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    // Note
    // This processing has to be done at the presentation level, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct
    // type - TYPECODE -> SUBGOAL_NAME, typeCode ->BASELINE_TYPE_CODE etc
    for (int i = 0; i
      < baselinePlanContentDetailsSL.listBaselineSubGoalDetails.size(); i++) {

      final BaselinePlanContent baselinePlanContent = new BaselinePlanContent();
      final BaselineSubGoalKey baselineSubGoalKey = new BaselineSubGoalKey();

      // get sensitivity level for each baseline sub goal
      baselineSubGoalKey.baselineSubGoalID = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).baselineSubGoalID;

      final BaselineSensitivityCode baselineSensitivityCode = baselineSubGoalObj.readSensitivityCode(
        baselineSubGoalKey);

      // Assign ids & plan content types as will be passed back no matter always
      // as never displayed on screen
      baselinePlanContent.baselinePlanContentID = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).baselineSubGoalID;
      baselinePlanContent.planContentID = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).plannedSubGoalID;
      baselinePlanContent.planContentType = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).planContentType;
      baselinePlanContent.baselinePlanContentType = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).baselinePlanContentType;
      baselinePlanContent.caseID = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).caseID;

      // set indicator
      baselinePlanContent.planGroupOrSubGoalInd = baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).subGoalIndicator;

      // if sub goal sensitivity higher than user sensitivity then replace with
      // ********
      if (Integer.parseInt(baselineSensitivityCode.sensitivityCode)
        > Integer.parseInt(userSecurityDetails.sensitivity)) {

        baselinePlanContent.name = kSubGoalDetailsRestricted;
        baselinePlanContent.type = kSubGoalDetailsRestricted;

      } else // return baselineSubGoal details
      {
        // Set baseline name
        baselinePlanContent.name = CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
          baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).subGoalName,
          TransactionInfo.getProgramLocale());

        // Set the type
        baselinePlanContent.type = CodeTable.getOneItem(SUBGOALTYPE.TABLENAME,
          baselinePlanContentDetailsSL.listBaselineSubGoalDetails.item(i).typeCode,
          TransactionInfo.getProgramLocale());

      }

      // Add each filtered record to overall struct.
      baselinePlanContentList.list.addRef(baselinePlanContent);
    }

    // Note
    // This processing has to be done at the presentation level
    for (int i = 0; i
      < baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.size(); i++) {

      final BaselinePlanContent baselinePlanContent = new BaselinePlanContent();

      // set the baseline plan group ID
      baselinePlanContent.baselinePlanContentID = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).baselinePlannedGroupID;

      // set the plan group ID
      baselinePlanContent.planContentID = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).plannedGroupID;

      // set the baseline plan group name
      baselinePlanContent.name = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).plannedGroupName;

      // set the plan content type
      baselinePlanContent.planContentType = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).planContentType;

      // set the baseline plan content type
      baselinePlanContent.baselinePlanContentType = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).baselinePlanContentType;

      // set the case ID
      baselinePlanContent.caseID = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).caseID;

      // set indicator
      baselinePlanContent.planGroupOrSubGoalInd = baselinePlanContentDetailsSL.listBaselinePlannedGroupDetails.item(i).planGroupIndicator;

      // add record to overall Struct
      baselinePlanContentList.list.addRef(baselinePlanContent);

    }
    // return for service layer read baseline name
    BaselineNameDetails baselineNameDetails = new BaselineNameDetails();
    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    baselineNameDetails = baselineObj.readBaselineName(baselineKey.key);
    // add baseline name
    description.arg(baselineNameDetails.baselineNameDtls.name);

    // assign it to the return object
    baselinePlanContentList.description.description = description.toClientFormattedText();

    return baselinePlanContentList;
  }

  // ___________________________________________________________________________
  /**
   * Returns select type code (used in UIM planItem) so code can be passed to
   * next page
   *
   * @param key
   * Contains the planned sub-goal type key selected
   *
   * @return Details of sub-goal type
   */
  @Override
  public PlannedSubGoalTypeCodeDetails getPlannedSubGoalTypeCode(
    PlannedSubGoalTypeCodeKey key) throws AppException,
      InformationalException {

    final PlannedSubGoalTypeCodeDetails plannedSubGoalTypeCodeDetails = new PlannedSubGoalTypeCodeDetails();

    plannedSubGoalTypeCodeDetails.plannedSubGoalTypeCodeDetails.typeCode = key.plannedSubGoalTypeCodeKey.typeCode;

    return plannedSubGoalTypeCodeDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns name for a particular planned sub-goal.
   *
   * @param key
   * Contains the planned sub-goal key selected
   *
   * @return Name of sub-goal.
   */
  @Override
  public PlannedSubGoalNameKey readSubGoalName(PlannedSubGoalNameStruct key)
    throws AppException, InformationalException {

    ServicePlanSecurityImplementationFactory.register();

    final PlannedSubGoalNameKey plannedSubGoalNameKey = new PlannedSubGoalNameKey();

    // get sub goal name
    // BEGIN HARP 49368, ST
    plannedSubGoalNameKey.subGoalName = CodeTable.getOneItem(
      SUBGOALNAME.TABLENAME, key.subGoalName,
      TransactionInfo.getProgramLocale());
    // END HARP 49638

    return plannedSubGoalNameKey;

  }

  // ___________________________________________________________________________

  /**
   * Reads all planned item approval requests based on the planned item id.
   *
   * @param approvalRequestPlannedItemIDKey
   * Contains the planned item Approval Request key selected
   *
   * @return Details of Approval request for selected planned item
   */
  @Override
  public PAApprovalRequestDetailsList listPlanItemApprovalRequest(
    ApprovalRequestPlannedItemIDKey approvalRequestPlannedItemIDKey)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // create return value
    final PAApprovalRequestDetailsList paApprovalRequestDetailsList = new PAApprovalRequestDetailsList();

    // Planned Item Approval Request business object
    final curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // Planned Item business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    // read approval request details list
    paApprovalRequestDetailsList.paApprovalRequestDetailsList = plannedItemApprovalRequestObj.list(
      approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey);

    // read service plan delivery case ID
    plannedItemIDKey.plannedItemIDKey.plannedItemID = approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey.approvalRequestPlannedItemIDKey.plannedItemID;
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey = plannedItemObj.readCaseID(
      plannedItemIDKey);

    // read context description
    paApprovalRequestDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    paApprovalRequestDetailsList.menuData.menuData = menuData.menuData;

    // return details
    return paApprovalRequestDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all the approval requests for a service plan.
   *
   * @param key
   * unique identifier of the service plan.
   *
   * @return List of approval request records.
   */
  @Override
  public SPApprovalRequestDtlsList listServicePlanApprovalRequest(
    ApprovalRequestCaseIDKey key) throws AppException, InformationalException {

    // return value
    final SPApprovalRequestDtlsList spApprovalRequestDtlsList = new SPApprovalRequestDtlsList();

    // Service Plan Approval Request business object
    final curam.serviceplans.sl.intf.ServicePlanApprovalRequest servicePlanApprovalRequestObj = curam.serviceplans.sl.fact.ServicePlanApprovalRequestFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read the list
    spApprovalRequestDtlsList.list = servicePlanApprovalRequestObj.list(
      key.approvalRequestCaseIDKey);

    // read context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.approvalRequestCaseIDKey.approvalRequestCaseIDKey.caseID;
    spApprovalRequestDtlsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.approvalRequestCaseIDKey.approvalRequestCaseIDKey.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    spApprovalRequestDtlsList.menuData.menuData = menuData.menuData;

    return spApprovalRequestDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Reads planned item approval request details for modify
   *
   * @param key
   * planned item approval request unique identifier
   *
   * @return Approval request ID and version number
   */
  @Override
  public RejectionDetailsForModify readPAApprovalRequestDetailsForModify(
    PAApprovalRequestKey key) throws AppException, InformationalException {

    // return value
    final RejectionDetailsForModify rejectionDetailsForModify = new RejectionDetailsForModify();

    // Planned Item Approval Request business object
    final curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read rejection details
    rejectionDetailsForModify.dtls = plannedItemApprovalRequestObj.readDetailsForModify(
      key.paApprovalRequestKey);

    // set service plan delivery key
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = rejectionDetailsForModify.dtls.dtls.caseID;

    // read context description
    rejectionDetailsForModify.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return rejectionDetailsForModify;
  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery approval request details for modify
   *
   * @param key
   * service plan delivery approval request unique identifier
   *
   * @return Approval request ID and version number
   */
  @Override
  public RejectionDetailsForModify readSPApprovalRequestDetailsForModify(
    SPApprovalRequestKey key) throws AppException, InformationalException {

    // return value
    final RejectionDetailsForModify rejectionDetailsForModify = new RejectionDetailsForModify();

    // Service Plan Approval Request business object
    final curam.serviceplans.sl.intf.ServicePlanApprovalRequest servicePlanApprovalRequestObj = curam.serviceplans.sl.fact.ServicePlanApprovalRequestFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read details for modify
    rejectionDetailsForModify.dtls = servicePlanApprovalRequestObj.readDetailsForModify(
      key.spApprovalRequestKey);

    // set service plan delivery key
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = rejectionDetailsForModify.dtls.dtls.caseID;

    // read context description
    rejectionDetailsForModify.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return rejectionDetailsForModify;

  }

  // ___________________________________________________________________________
  /**
   * Modifies the planned item approval request.
   *
   * @param details
   * Contains approval request ID, rejection reason and comments.
   */
  @Override
  public void modifyPlanItemApprovalRequest(ModifyRejectionDetails details)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // create service plan Approval Request Object
    final curam.core.sl.intf.ApprovalRequest approvalRequestObj = curam.core.sl.fact.ApprovalRequestFactory.newInstance();

    // modify planned item approval request
    approvalRequestObj.modifyReasonDetails(details.key, details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Modifies the service plan approval request.
   *
   * @param details
   * Contains approval request identifier, rejection reason and
   * comments.
   */
  @Override
  public void modifyServicePlanApprovalRequest(ModifyRejectionDetails details)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // create service plan Approval Request Object
    final curam.core.sl.intf.ApprovalRequest approvalRequestObj = curam.core.sl.fact.ApprovalRequestFactory.newInstance();

    // modify planned item approval request
    approvalRequestObj.modifyReasonDetails(details.key, details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads the planned item approval request.
   *
   * @param paApprovalRequestKey
   * Contains the approval request id.
   *
   * @return Details of the Approval Request.
   */
  @Override
  public PlannedItemApprovalRequestDetails viewPlanItemApprovalRequest(
    curam.serviceplans.facade.struct.PAApprovalRequestKey paApprovalRequestKey)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // approval request business object
    final curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // create return value
    final curam.serviceplans.facade.struct.PlannedItemApprovalRequestDetails plannedItemApprovalRequestDetails = new curam.serviceplans.facade.struct.PlannedItemApprovalRequestDetails();

    // read Approval Request Record using key
    plannedItemApprovalRequestDetails.plannedItemApprovalRequestDetails = plannedItemApprovalRequestObj.readByPlannedItemID(
      paApprovalRequestKey.paApprovalRequestKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedItemApprovalRequestDetails.plannedItemApprovalRequestDetails.caseID;

    // read context description
    plannedItemApprovalRequestDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return plannedItemApprovalRequestDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads the service plan approval request.
   *
   * @param spApprovalRequestKey
   * Contains the service plan approval request id.
   *
   * @return Full Details of the Service Plan Approval Request
   */
  @Override
  public ServicePlanApprovalRequestFullDetails viewServicePlanApprovalRequest(SPApprovalRequestKey spApprovalRequestKey)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00233701, PB
    final CaseEventKey caseEventKey = new CaseEventKey();
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    CaseEventDtls caseEventDtls = new CaseEventDtls();
    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();

    caseEventKey.caseEventID = spApprovalRequestKey.spApprovalRequestKey.spApprovalRequestKey.servicePlanApprovalRequestID;
    caseEventDtls = caseEventObj.read(notFoundIndicator, caseEventKey);

    if (!notFoundIndicator.isNotFound()) {
      spApprovalRequestKey.spApprovalRequestKey.spApprovalRequestKey.servicePlanApprovalRequestID = caseEventDtls.relatedID;
    }
    // END, CR00233701
    // service plan approval request business object
    final curam.serviceplans.sl.intf.ServicePlanApprovalRequest servicePlanApprovalRequestObj = curam.serviceplans.sl.fact.ServicePlanApprovalRequestFactory.newInstance();

    // create return value
    final ServicePlanApprovalRequestFullDetails servicePlanApprovalRequestFullDetails = new ServicePlanApprovalRequestFullDetails();

    // read Approval Request Record using key
    servicePlanApprovalRequestFullDetails.servicePlanApprovalRequestFullDetails = servicePlanApprovalRequestObj.read(
      spApprovalRequestKey.spApprovalRequestKey);

    // set service plan delivery key
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = servicePlanApprovalRequestFullDetails.servicePlanApprovalRequestFullDetails.spApprovalRequestDtls.caseID;

    // read context description
    servicePlanApprovalRequestFullDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return servicePlanApprovalRequestFullDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads details of a case attachment.
   *
   * @param key
   * Key to read the case attachment details.
   *
   * @return Details of the case attachment.
   */
  @Override
  public ReadAttachmentDetails readServicePlanContractAttachment(
    ReadAttachmentKey key) throws AppException, InformationalException {

    // Details to be returned
    final ReadAttachmentDetails readAttachmentDetails = new ReadAttachmentDetails();

    // Appeal objects
    final ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Call service layer to read the attachment details
    final ContractAttachmentDetails contractAttachmentDetails = servicePlanContractObj.readContractAttachmentDetails(
      key.readAttachmentIn);

    readAttachmentDetails.readAttachmentOut.attachmentContents = contractAttachmentDetails.attachmentContents;
    readAttachmentDetails.readAttachmentOut.attachmentName = contractAttachmentDetails.attachmentName;

    return readAttachmentDetails;

  }

  // BEGIN, CR00114509, PMD
  // _________________________________________________________________________
  /**
   * Adds Daily Attendance record for a user selected planItem.
   *
   * @param addClientParticipationDetails
   * Details of daily attendance entered by user
   *
   * @return Identifier of newly created daily attendance record.
   */
  @Override
  public DailyAttendanceKey addClientParticipationSelectPlanItem(
    AddClientParticipationDetails addClientParticipationDetails)
    throws AppException, InformationalException {

    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Add the daily attendance details
    dailyAttendanceKey = ClientParticipationFactory.newInstance().addParticipation(
      addClientParticipationDetails.dailyAttendanceDtls);

    return dailyAttendanceKey;
  }

  // _________________________________________________________________________
  /**
   * Adds Daily Attendance record for default planItem.
   *
   * @param addClientParticipationDetails
   * Details of daily attendance entered by user.
   *
   * @return Identifier of newly created daily attendance record.
   */
  @Override
  public DailyAttendanceKey addClientParticipationDefaultPlanItem(
    AddClientParticipationDetails addClientParticipationDetails)
    throws AppException, InformationalException {

    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    dailyAttendanceKey = ClientParticipationFactory.newInstance().addParticipation(
      addClientParticipationDetails.dailyAttendanceDtls);

    return dailyAttendanceKey;
  }

  // _________________________________________________________________________
  /**
   * Modifies details of daily attendance.
   *
   * @param modifyClientParticipationDetails
   * modified daily attendance details
   */
  @Override
  public void modifyClientParticipation(
    ModifyClientParticipationDetails modifyClientParticipationDetails)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    ClientParticipationFactory.newInstance().modifyDetails(
      modifyClientParticipationDetails.dailyAttendanceDtls);
  }

  // _________________________________________________________________________
  /**
   * Reads details of daily attendance.
   *
   * @param dailyAttendanceKey
   * Contains daily attendance identifier.
   *
   * @return Details of the daily attendance.
   */
  @Override
  public ViewClientParticipationDetails readClientParticipationDetails(
    DailyAttendanceKey dailyAttendanceKey) throws AppException,
      InformationalException {

    final ViewClientParticipationDetails viewClientParticipationDetails = new ViewClientParticipationDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    viewClientParticipationDetails.dailyAttendanceDtls = ClientParticipationFactory.newInstance().viewDetails(
      dailyAttendanceKey);

    // read context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = viewClientParticipationDetails.dailyAttendanceDtls.dtls.dtls.caseID;

    viewClientParticipationDetails.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return viewClientParticipationDetails;

  }

  // END, CR00114509

  // ___________________________________________________________________________
  /**
   * Creates service plan delivery for an integrated case member based on the
   * selected service plan template.
   *
   * @param details
   * Service plan template details
   */
  @Override
  public void addTemplate(AddTemplateDetails details) throws AppException,
      InformationalException {

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // validate details
    servicePlanDeliveryObj.validateAddTemplateToServicePlanDetails(
      details.planTemplateKey);

    // add template
    servicePlanDeliveryObj.addTemplate(
      details.servicePlanDeliveryKey.servicePlanDeliveryKey,
      details.planTemplateKey);

  }

  // ___________________________________________________________________________
  /**
   * Returns list of planTemplateIDs and planTemplateNames for all plan
   * templates assigned to a service plan.
   *
   * @param key
   * Service plan delivery unique ID
   *
   * @return PlanTemplateNameAndIDDetailsList list of plan templates assigned to
   * the current service plan.
   */
  @Override
  public PlanTemplateNameAndIDDetailsList listServicePlanTemplates(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final PlanTemplateNameAndIDDetailsList planTemplateNameAndIDDetailsList = new PlanTemplateNameAndIDDetailsList();

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // PlanTemplate manipulation variables
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // read service plan ID
    final curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      key.servicePlanDeliveryKey);

    // list service plan templates
    planTemplateNameAndIDDetailsList.list = planTemplateObj.listByServicePlan(
      servicePlanKey);

    // validate template list
    servicePlanDeliveryObj.validateTemplateList(
      planTemplateNameAndIDDetailsList.list);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final ServicePlanInformationalMessage servicePlanInformationalMessage = new ServicePlanInformationalMessage();

      servicePlanInformationalMessage.informationMsgTxt = warnings[i];

      planTemplateNameAndIDDetailsList.servicePlanInformationalMessageDetailsList.servicePlanInformationalMessage.addRef(
        servicePlanInformationalMessage);

    }

    // return plan template list
    return planTemplateNameAndIDDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Approves service plan delivery.
   *
   * @param key
   * Contains service plan delivery unique ID.
   */
  @Override
  public void approve(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // ServicePlanApprovalRequest business object
    final curam.serviceplans.sl.intf.ServicePlanApprovalRequest servicePlanApprovalRequestObj = curam.serviceplans.sl.fact.ServicePlanApprovalRequestFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // approve service plan
    servicePlanApprovalRequestObj.approve(key.servicePlanDeliveryKey);
  }

  // ___________________________________________________________________________
  /**
   * Clones service plan delivery.
   *
   * @param key
   * Contains unique ID of the service plan delivery to be cloned
   *
   * @return Unique ID of the new created service plan delivery
   */
  @Override
  public curam.serviceplans.facade.struct.ServicePlanDeliveryKey clone(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final curam.serviceplans.facade.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // clone service plan
    servicePlanDeliveryKey.servicePlanDeliveryKey = servicePlanDeliveryObj.clone(
      key.servicePlanDeliveryKey);

    return servicePlanDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * Closes service plan delivery.
   *
   * @param details
   * Contains service plan delivery unique ID, closing reason code and
   * comments.
   */
  // ___________________________________________________________________________
  /**
   * Closes service plan delivery.
   *
   * @param details
   * Contains service plan delivery unique ID, closing reason code and
   * comments.
   *
   */
  @Override
  public void close(ServicePlanDeliveryClosureDetails details)
    throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    // BEGIN, CR00161962, LJ
    // close service plan
    servicePlanDeliveryObj.close(details.servicePlanDeliveryKey,
      details.servicePlanDeliveryClosureDetails, true);
    // END, CR00161962
  }

  // ___________________________________________________________________________
  /**
   * Modifies service plan delivery closure details.
   *
   * @param key
   * Contains service plan delivery unique ID.
   * @param details
   * Contains service plan delivery closure details.
   */
  @Override
  public void modifyClosureDetails(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key,
    ModifyServicePlanClosureDetails details) throws AppException,
      InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // modify service plan closure details
    servicePlanDeliveryObj.modifyClosureDetails(key.servicePlanDeliveryKey,
      details.modifyServicePlanClosureDetails);

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery closure details for modify.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return Service plan delivery details
   */
  @Override
  public ModifyServicePlanClosureDetails readClosureDetails(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final ModifyServicePlanClosureDetails modifyServicePlanClosureDetails = new ModifyServicePlanClosureDetails();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read service plan closure details
    modifyServicePlanClosureDetails.modifyServicePlanClosureDetails = servicePlanDeliveryObj.readClosureDetails(
      key.servicePlanDeliveryKey);

    // read context description
    modifyServicePlanClosureDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    return modifyServicePlanClosureDetails;
  }

  // ___________________________________________________________________________
  /**
   * Rejects service plan delivery approval.
   *
   * @param details
   * Contains service plan delivery unique ID and rejection reason.
   */
  @Override
  public void reject(ServicePlanDeliveryRejectDetails details)
    throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanApprovalRequest servicePlanApprovalRequestObj = curam.serviceplans.sl.fact.ServicePlanApprovalRequestFactory.newInstance();

    // register service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // reject service plan delivery
    servicePlanApprovalRequestObj.reject(
      details.servicePlanDeliveryRejectDetails);

  }

  // ___________________________________________________________________________
  /**
   * Submits service plan delivery for approval.
   *
   * @param key
   * Contains service plan delivery unique ID.
   */
  @Override
  public void submit(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // ServicePlanApprovalRequest business object
    final curam.serviceplans.sl.intf.ServicePlanApprovalRequest servicePlanApprovalRequestObj = curam.serviceplans.sl.fact.ServicePlanApprovalRequestFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    servicePlanApprovalRequestObj.submit(key.servicePlanDeliveryKey);

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery closure details
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return Service plan delivery closure details
   */
  @Override
  public ServicePlanDeliveryClosureDetails viewClosureDetails(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryClosureDetails servicePlanDeliveryClosureDetails = new ServicePlanDeliveryClosureDetails();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // view closure details
    servicePlanDeliveryClosureDetails.servicePlanDeliveryClosureDetails = servicePlanDeliveryObj.viewClosureDetails(
      key.servicePlanDeliveryKey);

    // read context description
    servicePlanDeliveryClosureDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    return servicePlanDeliveryClosureDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists service plan delivery versions.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @return List of service plan versions.
   */
  @Override
  public ServicePlanDeliveryVersions listVersions(
    curam.serviceplans.facade.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryVersions servicePlanDeliveryVersions = new ServicePlanDeliveryVersions();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // list service plan delivery versions
    servicePlanDeliveryVersions.servicePlanDeliveryVersions = servicePlanDeliveryObj.listVersions(
      key.servicePlanDeliveryKey);

    // read context description
    servicePlanDeliveryVersions.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanDeliveryVersions.integratedCaseMenuDataDetails.menuData = menuData.menuData;

    // return service plan versions
    return servicePlanDeliveryVersions;

  }

  // ___________________________________________________________________________
  /**
   * Lists all integrated case participants, except for service plan delivery
   * primary client.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of integrated case participants.
   */
  @Override
  public ICMembersList getAvailableICMembers(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Details to be returned
    final ICMembersList icMembersList = new ICMembersList();

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // get context description
    icMembersList.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // get integrated case members list
    icMembersList.icMemberDetailsList = servicePlanDeliveryObj.getAvailableICMembers(
      key.servicePlanDeliveryKey);

    return icMembersList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all the nominated representative records for a service plan delivery.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of nominated representative records for a service plan.
   */
  @Override
  public PlanParticipantList listNominatedRepresentative(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // Details to be returned.
    final PlanParticipantList planParticipantList = new PlanParticipantList();

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // list nominated representatives
    planParticipantList.servicePlanParticipantDetailsList = servicePlanDeliveryObj.listNominatedRepresentative(
      key.servicePlanDeliveryKey);

    // get context description
    planParticipantList.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    planParticipantList.integratedCaseMenuDataDetails.menuData = getICServicePlanMenuData(servicePlanIntegratedCaseKey).menuData;

    return planParticipantList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all the plan participant records for a service plan delivery.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of plan participant records for a service plan.
   */
  @Override
  public PlanParticipantList listPlanParticipants(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Details to be returned
    final PlanParticipantList planParticipantList = new PlanParticipantList();

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // list plan participants
    planParticipantList.servicePlanParticipantDetailsList = servicePlanDeliveryObj.listPlanParticipants(
      key.servicePlanDeliveryKey);

    // get context description
    planParticipantList.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    planParticipantList.integratedCaseMenuDataDetails.menuData = getICServicePlanMenuData(servicePlanIntegratedCaseKey).menuData;

    return planParticipantList;

  }

  // BEGIN, CR00234619, SS
  /**
   * Lists all the plan participant records for a service plan delivery.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return List of plan participant records for a service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlanParticipantList1 listPlanParticipants1(ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    final PlanParticipantList1 planParticipantList1 = new PlanParticipantList1();
    final PlanParticipantList planParticipantList = new PlanParticipantList();
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();
    planParticipantList.servicePlanParticipantDetailsList = servicePlanDeliveryObj.listPlanParticipants(
      key.servicePlanDeliveryKey);
    for (final curam.serviceplans.sl.entity.struct.ServicePlanParticipantDetails spParticipantDetails : planParticipantList.servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls) {
      final ServicePlanParticipantDetails1 spParticpantDetails = new ServicePlanParticipantDetails1();

      spParticpantDetails.dtls.assign(spParticipantDetails);
      // delete option is available only for nominated representative.
      if (CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE.equals(
        spParticipantDetails.typeCode)) {
        spParticpantDetails.nominatedRepInd = true;
      }
      // Edit & Delete option need to be disabled for canceled record.
      if (RECORDSTATUS.CANCELLED.equals(spParticipantDetails.recordStatus)) {
        spParticpantDetails.nominatedRepInd = false;
        spParticpantDetails.activeStatusInd = false;
      } else {
        spParticpantDetails.activeStatusInd = true;
      }
      planParticipantList1.dtls.spParticipant.add(spParticpantDetails);
    }
    // get context description
    planParticipantList1.spDeliveryContextDescription = getServicePlanContextDescription(
      key);
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;
    planParticipantList1.icMenuDataDetails.menuData = getICServicePlanMenuData(servicePlanIntegratedCaseKey).menuData;
    return planParticipantList1;
  }

  // END, CR00234619

  // BEGIN CR00109001, GBA
  // ___________________________________________________________________________
  /**
   * Populate integrated case member list and service plan participants list to
   * add and/or remove integrated case members as plan participants.
   *
   * @param key
   * Unique identifier of the Service Plan Delivery.
   *
   * @return Returns available integrated case members and plan participants
   */
  @Override
  public PopulatedPlanParticipants populatePlanParticipants(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // Details to be returned
    final PopulatedPlanParticipants populatedPlanParticipants = new PopulatedPlanParticipants();

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // get primary plan participant
    populatedPlanParticipants.primaryPlanParticipant = servicePlanDeliveryObj.readServicePlanIDAndConcernRoleID(key.servicePlanDeliveryKey).concernRoleID;

    // list service plan participants including primary plan participant
    final ServicePlanParticipantDetailsList sPParticipantDetailsList = servicePlanDeliveryObj.listPlanParticipants(
      key.servicePlanDeliveryKey);

    // construct tab-separated plan participant string like "102\t103\t104"
    if (sPParticipantDetailsList != null) {
      populatedPlanParticipants.selectedPlanParticipants = new String();
      final int participantListSize = sPParticipantDetailsList.servicePlanParticipantDetailsList.dtls.size();
      // BEGIN, CR00146503, GBA
      curam.serviceplans.sl.entity.struct.ServicePlanParticipantDetails servicePlanParticipantDetails;
      int participantIdx = 0;

      for (int k = 0; k < participantListSize; k++) {
        servicePlanParticipantDetails = sPParticipantDetailsList.servicePlanParticipantDetailsList.dtls.item(
          k);

        if (RECORDSTATUS.NORMAL.equals(
          servicePlanParticipantDetails.recordStatus)
            && (CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT.equals(
              servicePlanParticipantDetails.typeCode)
                || CASEPARTICIPANTROLETYPE.PLANPARTICIPANT.equals(
                  servicePlanParticipantDetails.typeCode))) {

          if (participantIdx != 0) {
            populatedPlanParticipants.selectedPlanParticipants += CuramConst.gkTabDelimiter;
          }

          populatedPlanParticipants.selectedPlanParticipants += Long.toString(
            servicePlanParticipantDetails.participantRoleID);
          participantIdx++;
        }
        // END, CR00146503
      }
    }

    // get context description
    populatedPlanParticipants.planParticipantContextDesc = getServicePlanContextDescription(
      key);

    // get integrated case members
    populatedPlanParticipants.integratedCaseMembers = servicePlanDeliveryObj.getIntegratedCaseMembers(
      key.servicePlanDeliveryKey);

    return populatedPlanParticipants;
  }

  // ___________________________________________________________________________
  /**
   * Manage plan participants by adding and/or removing integrated case members
   * as plan participant.
   *
   * @param details
   * to update plan participants of a service plan.
   */
  @Override
  public void updatePlanParticipants(PlanParticipantDetailsForUpdate details)
    throws AppException, InformationalException {

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    servicePlanDeliveryObj.updatePlanParticipants(
      details.updatePlanParticipants);

  }

  // END CR00109001

  // ___________________________________________________________________________
  /**
   * Creates a nominated representative record for a service plan delivery.
   *
   * @param details
   * Details to create the nominated representative.
   *
   * @return Returns created nominated representative's unique identifier.
   */
  @Override
  public curam.serviceplans.facade.struct.CaseParticipantRoleKey insertNominatedRepresentative(CreateNominatedRepresentativeDetails details)
    throws AppException, InformationalException {

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // to be returned
    final curam.serviceplans.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.serviceplans.facade.struct.CaseParticipantRoleKey();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // insert nominated representative
    caseParticipantRoleKey.caseParticipantRoleKey = servicePlanDeliveryObj.insertNominatedRepresentative(
      details.createNominatedRepresentativeDetails);

    // return representative's unique ID
    return caseParticipantRoleKey;
  }

  // ___________________________________________________________________________
  /**
   * Logically deletes (cancels) a nominated representative record on a service
   * plan delivery.
   *
   * @param details
   * Details to cancel the nominated representative.
   */
  @Override
  public void deleteNominatedRepresentative(
    CancelServicePlanParticipantDetails details) throws AppException,
      InformationalException {

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // modify nominated representative record
    servicePlanDeliveryObj.deleteNominatedRepresentative(
      details.cancelServicePlanParticipantDetails);

  }

  // ___________________________________________________________________________
  /**
   * Modifies a nominated representative record for a service plan delivery.
   *
   * @param details
   * Details to modify the nominated representative.
   */
  @Override
  public void modifyNominatedRepresentative(
    ModifyServicePlanParticipantDetails details) throws AppException,
      InformationalException {

    // ServicePlanDelivery manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // modify nominated representative record
    servicePlanDeliveryObj.modifyNominatedRepresentative(
      details.modifyServicePlanParticipantDetails);

  }

  // ___________________________________________________________________________
  /**
   * Reads nominated representative's details.
   *
   * @param key
   * Case participant role ID of the nominated representative.
   *
   * @return Returns nominated representative details.
   */
  @Override
  public ServicePlanParticipantDetails readNominatedRepresentativeDetails(
    curam.serviceplans.facade.struct.CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // to be returned
    final ServicePlanParticipantDetails servicePlanParticipantDetails = new ServicePlanParticipantDetails();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // read nominated representative's details
    servicePlanParticipantDetails.servicePlanparticipantDetails = servicePlanDeliveryObj.readNominatedRepresentativeDetails(
      key.caseParticipantRoleKey);

    // read service plan delivery ID
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = servicePlanDeliveryObj.readServicePlanDeliveryID(
      key.caseParticipantRoleKey);

    // set the key to read context description
    final curam.serviceplans.facade.struct.ServicePlanDeliveryKey facadeServicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

    facadeServicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = servicePlanDeliveryKey.key.caseID;

    // get context description
    servicePlanParticipantDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      facadeServicePlanDeliveryKey);

    return servicePlanParticipantDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads nominated representative's details to be modified.
   *
   * @param key
   * Case participant role ID of the nominated representative.
   *
   * @return Returns nominated representative details.
   */
  @Override
  public ServicePlanParticipantDetails readNominatedRepresentativeDetailsForModify(
    curam.serviceplans.facade.struct.CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    // Service plan delivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // to be returned
    final ServicePlanParticipantDetails servicePlanParticipantDetails = new ServicePlanParticipantDetails();

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    // read nominated representative's details
    servicePlanParticipantDetails.servicePlanparticipantDetails = servicePlanDeliveryObj.readNominatedRepresentativeDetailsForModify(
      key.caseParticipantRoleKey);

    // read service plan delivery ID
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = servicePlanDeliveryObj.readServicePlanDeliveryID(
      key.caseParticipantRoleKey);

    // set the key to read context description
    final curam.serviceplans.facade.struct.ServicePlanDeliveryKey facadeServicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

    facadeServicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = servicePlanDeliveryKey.key.caseID;

    // get context description
    servicePlanParticipantDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      facadeServicePlanDeliveryKey);

    return servicePlanParticipantDetails;

  }

  // BEGIN, CR00114509, PMD
  // _________________________________________________________________________
  /**
   * Sets Daily Attendance record to status "Canceled".
   *
   * @param key
   * The key identifying the record to be cancelled.
   */
  @Override
  public void cancelClienParticipation(DailyAttendanceKey key)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    ClientParticipationFactory.newInstance().cancelParticipation(key);

  }

  // _________________________________________________________________________
  /**
   * @param planItemClientParticipationSearchKey
   * The key identifying the set of records to be returned.
   *
   * @return List of daily attendance records for selected planItem.
   *
   * @deprecated This method is replaced by
   * {@link #listClienParticipationForPlannedItem()} Lists all daily attendance
   * records for selected planItem.
   */
  @Override
  @Deprecated
  public PlanItemClientParticipationList listClienParticipationForPlanItem(
    PlanItemClientParticipationSearchKey planItemClientParticipationSearchKey)
    throws AppException, InformationalException {

    final ClientParticipation clientParticipationObj = ClientParticipationFactory.newInstance();

    final PlanItemClientParticipationList planItemClientParticipationList = new PlanItemClientParticipationList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Get the list of attendances
    planItemClientParticipationList.piDtlsList = clientParticipationObj.listForPlanItem(
      planItemClientParticipationSearchKey.planItemClientParticipationSearchKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = planItemClientParticipationSearchKey.planItemClientParticipationSearchKey.plannedItemIDKey.plannedItemID;

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = plannedItemObj.readCaseID(plannedItemIDKey).key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    planItemClientParticipationList.menuData.menuData = menuData.menuData;

    return planItemClientParticipationList;

  }

  // BEGIN, CR00168425, GBA
  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method
   * {@link #listClienParticipationForPlanItem()} Lists all daily attendance
   * records for selected planItem.
   *
   * @param planItemClientParticipationSearchKey The key identifying the set
   * of records to be returned.
   * @return List of daily attendance records for selected planItem.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlannedItemClientParticipationList listClienParticipationForPlannedItem(
    PlanItemClientParticipationSearchKey planItemClientParticipationSearchKey)
    throws AppException, InformationalException {

    final ClientParticipation clientParticipationObj = ClientParticipationFactory.newInstance();

    final PlannedItemClientParticipationList planItemClientParticipationList = new PlannedItemClientParticipationList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Get the list of attendances
    planItemClientParticipationList.piDtlsList = clientParticipationObj.listForPlannedItem(
      planItemClientParticipationSearchKey.planItemClientParticipationSearchKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = planItemClientParticipationSearchKey.planItemClientParticipationSearchKey.plannedItemIDKey.plannedItemID;

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = plannedItemObj.readCaseID(plannedItemIDKey).key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    planItemClientParticipationList.menuData.menuData = menuData.menuData;

    return planItemClientParticipationList;

  }

  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method
   * {@link #listClienParticipationForCase()} List all daily attendance records
   * for all planItems of integrated case.
   *
   * @param caseClientParticipationKey Contains service plan case ID
   *
   * @return List of daily attendance records for service plan delivery.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanClientParticipationList listClienParticipationForServicePlan(
    CaseClientParticipationKey caseClientParticipationKey)
    throws AppException, InformationalException {

    final ClientParticipation clientParticipationObj = ClientParticipationFactory.newInstance();

    final ServicePlanClientParticipationList servicePlanClientParticipationList = new ServicePlanClientParticipationList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    servicePlanClientParticipationList.dailyAttendanceList = clientParticipationObj.listForServicePlan(
      caseClientParticipationKey.caseClientParticipationSearchKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key = caseClientParticipationKey.caseClientParticipationSearchKey.servicePlanDeliveyKey;

    servicePlanClientParticipationList.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanClientParticipationList.icMenuData.menuData = menuData.menuData;

    return servicePlanClientParticipationList;

  }

  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method
   * {@link #planItemClientParticipationForWeekList()} Lists all daily
   * attendance records with time absent information for
   * particular plan item for a week specified.
   *
   * @param planItemClientParticipationForDateRangeKey Contains plan item
   * and date range
   * @return List of daily attendance records for plan item for week.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PIDailyAttendanceDetailsList plannedItemParticipationForWeekList(
    PlanItemClientParticipationForDateRangeKey planItemClientParticipationForDateRangeKey)
    throws AppException, InformationalException {

    final PIDailyAttendanceDetailsList piDailyAttendanceDetailsList = new PIDailyAttendanceDetailsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    piDailyAttendanceDetailsList.dtlsList = ClientParticipationFactory.newInstance().listForPlannedItemForWeek(
      planItemClientParticipationForDateRangeKey.planItemAndDatesRangeKey);

    return piDailyAttendanceDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method
   * {@link #caseClienParticipationForWeekList()} Lists all client participation
   * records with time absent information for all
   * planItems of service plan for a week specified.
   *
   * @param caseClientParticipationForDateRangeKey
   * Contains service plan case Id and date range
   * @return List of client participation records for case for week.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanClientParticipationList servicePlanParticipationForWeekList(
    CaseClientParticipationForDateRangeKey caseClientParticipationForDateRangeKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    final ServicePlanClientParticipationList servicePlanClientParticipationList = new ServicePlanClientParticipationList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    servicePlanClientParticipationList.dailyAttendanceList = clientParticipationObj.listForServicePlanForWeek(
      caseClientParticipationForDateRangeKey.caseAndDateRangeKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseClientParticipationForDateRangeKey.caseAndDateRangeKey.participationsForCaseAndDateRangeKey.caseID;

    servicePlanClientParticipationList.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return servicePlanClientParticipationList;

  }

  // END, CR00168425

  // _________________________________________________________________________
  /**
   * @param caseClientParticipationKey
   * The key identifying the set of records to be returned.
   *
   * @return List of daily attendance records for case.
   *
   * @deprecated This method is replaced by
   * {@link #listClienParticipationForServicePlan()} List all daily attendance
   * records for all planItems of integrated case.
   */
  @Override
  @Deprecated
  public CaseClientParticipationsList listClienParticipationForCase(
    CaseClientParticipationKey caseClientParticipationKey)
    throws AppException, InformationalException {

    final ClientParticipation clientParticipationObj = ClientParticipationFactory.newInstance();

    final CaseClientParticipationsList caseClientParticipationsList = new CaseClientParticipationsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    caseClientParticipationsList.caseDailyAttendanceDetailsAsStringsList = clientParticipationObj.listForCase(
      caseClientParticipationKey.caseClientParticipationSearchKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key = caseClientParticipationKey.caseClientParticipationSearchKey.servicePlanDeliveyKey;

    caseClientParticipationsList.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    caseClientParticipationsList.icMenuData.menuData = menuData.menuData;

    return caseClientParticipationsList;

  }

  // _________________________________________________________________________
  /**
   * @param planItemClientParticipationForDateRangeKey
   * The key identifying the set of records to be returned.
   *
   * @return List of daily attendance records for plan item for week.
   * @deprecated This method is replaced by
   * {@link #plannedItemParticipationForWeekList()} Lists all daily attendance
   * records for particular plan item for a week
   * specified.
   */
  @Override
  @Deprecated
  public PIDailyAttendanceSummaryDetailsList planItemClientParticipationForWeekList(
    PlanItemClientParticipationForDateRangeKey planItemClientParticipationForDateRangeKey)
    throws AppException, InformationalException {

    final PIDailyAttendanceSummaryDetailsList piDailyAttendanceSummaryDetailsList = new PIDailyAttendanceSummaryDetailsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    piDailyAttendanceSummaryDetailsList.dtlsList = ClientParticipationFactory.newInstance().listForPlanItemForWeek(
      planItemClientParticipationForDateRangeKey.planItemAndDatesRangeKey);

    return piDailyAttendanceSummaryDetailsList;
  }

  // _________________________________________________________________________
  /**
   * @param caseClientParticipationForDateRangeKey
   * The key identifying the set of records to be returned.
   *
   * @return List of client participation records for case for week.
   * @deprecated This method is replaced by
   * {@link #servicePlanParticipationForWeekList()} Lists all client
   * participation records for all planItems of integrated case
   * for a week specified.
   */
  @Override
  @Deprecated
  public CaseClientParticipationsList caseClienParticipationForWeekList(
    CaseClientParticipationForDateRangeKey caseClientParticipationForDateRangeKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    final CaseClientParticipationsList caseClientParticipationsList = new CaseClientParticipationsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    caseClientParticipationsList.caseDailyAttendanceDetailsAsStringsList = clientParticipationObj.listForCaseForWeek(
      caseClientParticipationForDateRangeKey.caseAndDateRangeKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseClientParticipationForDateRangeKey.caseAndDateRangeKey.participationsForCaseAndDateRangeKey.caseID;

    caseClientParticipationsList.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return caseClientParticipationsList;

  }

  // END, CR00114509
  // _________________________________________________________________________
  /**
   * Lists client participation summary for plan item for every week .
   *
   * @param planItemActiveClientParticipationSearchKey
   * The key identifying the set of records to be returned.
   *
   * @return List of details required to make weekly summary of Client
   * Participation for planItem.
   */
  @Override
  public WeeklyPlanItemClientParticipationList planItemClienParticipationWeeklyList(
    PlanItemActiveClientParticipationSearchKey planItemActiveClientParticipationSearchKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    final WeeklyPlanItemClientParticipationList weeklyPlanItemClientParticipationList = new WeeklyPlanItemClientParticipationList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    weeklyPlanItemClientParticipationList.weeklyParticipationSumaryDetailsList = clientParticipationObj.weeklyListForPlanItem(
      planItemActiveClientParticipationSearchKey.planItemActiveClientParticipationSearchKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = planItemActiveClientParticipationSearchKey.planItemActiveClientParticipationSearchKey.activeClientParticipationsForPlanItemKey.plannedItemID;

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = plannedItemObj.readCaseID(plannedItemIDKey).key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    weeklyPlanItemClientParticipationList.menuData.menuData = menuData.menuData;

    return weeklyPlanItemClientParticipationList;

  }

  // _________________________________________________________________________
  /**
   * Lists weekly client participation summary for all planItems of integrated
   * case.
   *
   * @param caseActiveClientParticipationKey
   * The key identifying the set of records to be returned.
   *
   * @return List of details required to make weekly summary of Client
   * Participation for case.
   */
  @Override
  public WeeklyServicePlanClientParticipationList caseClientParticipationWeeklyList(
    CaseActiveClientParticipationKey caseActiveClientParticipationKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    final WeeklyServicePlanClientParticipationList weeklyServicePlanClientParticipationList = new WeeklyServicePlanClientParticipationList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    weeklyServicePlanClientParticipationList.weeklyParticipationSummaryDetailsList = clientParticipationObj.weeklyListForCase(
      caseActiveClientParticipationKey.caseActiveClientParticipationsKey);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseActiveClientParticipationKey.caseActiveClientParticipationsKey.activeClientParticipationForCaseKey.caseID;

    weeklyServicePlanClientParticipationList.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    weeklyServicePlanClientParticipationList.menuData.menuData = menuData.menuData;

    return weeklyServicePlanClientParticipationList;

  }

  // _________________________________________________________________________
  /**
   * Lists client participation summary for all planItems of integrated case for
   * a day specified.
   *
   * @param caseClientParticipationForDayKey
   * The key identifying the set of records to be returned.
   *
   * @return List of client participation details for date specified.
   */
  @Override
  public CaseClientParticipationForDayList caseClienParticipationDailyList(
    CaseClientParticipationForDayKey caseClientParticipationForDayKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    final CaseClientParticipationForDayList caseClientParticipationForDayList = new CaseClientParticipationForDayList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00114509, PMD
    caseClientParticipationForDayList.caseAttendanceForDateStringList = clientParticipationObj.listForCaseForDate(
      caseClientParticipationForDayKey.participationCaseAndDateKey);
    // END, CR00114509

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseClientParticipationForDayKey.participationCaseAndDateKey.participationsForCaseAndDateKey.caseID;

    caseClientParticipationForDayList.spServicePlanContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return caseClientParticipationForDayList;

  }

  // _________________________________________________________________________
  /**
   * Gets weekly summary of active client participations of plan item specified
   * to display chart.
   *
   * @param planItemActiveClientParticipationSearchKey
   * The key identifying the set of records to be returned.
   *
   * @return String containing information required to form the chart of client
   * participation weekly summary for planItem.
   */
  @Override
  public PlanItemChartDetails planItemClientParticipationWeeklyChart(
    PlanItemActiveClientParticipationSearchKey planItemActiveClientParticipationSearchKey)
    throws AppException, InformationalException {

    final PlanItemChartDetails planItemChartDetails = new PlanItemChartDetails();

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    planItemChartDetails.planItemChartDetails = clientParticipationObj.weeklyChartForPlanItem(
      planItemActiveClientParticipationSearchKey.planItemActiveClientParticipationSearchKey);

    return planItemChartDetails;
  }

  // _________________________________________________________________________
  /**
   * Gets weekly summary of active client participations of integrated case to
   * display chart.
   *
   * @param caseActiveClientParticipationKey
   * The key identifying the set of records to be returned.
   *
   * @return String containing information required to form the chart of client
   * participation weekly summary for case.
   */

  @Override
  public CaseChartDetails caseClientParticipationWeeklyChart(
    CaseActiveClientParticipationKey caseActiveClientParticipationKey)
    throws AppException, InformationalException {

    final CaseChartDetails caseChartDetails = new CaseChartDetails();

    final curam.serviceplans.sl.intf.ClientParticipation clientParticipationObj = curam.serviceplans.sl.fact.ClientParticipationFactory.newInstance();

    caseChartDetails.clientParticipationXMLString = clientParticipationObj.weeklyChartForCase(
      caseActiveClientParticipationKey.caseActiveClientParticipationsKey);

    // get service plan delivery context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseActiveClientParticipationKey.caseActiveClientParticipationsKey.activeClientParticipationForCaseKey.caseID;

    caseChartDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return caseChartDetails;

  }

  // _________________________________________________________________________
  /**
   * Gets list of planItems for which client participation can be recorded.
   * Status of these plan item should be 'In Progress' or 'Completed'.
   *
   * @param planItemsForClientParticipationSearchKey
   * Identifies planned items suitable for recording client
   * participation
   * @return List of planned items suitable for recording client participation
   */
  @Override
  public PlannedItemNameAndIDDetailsList listPlanItemsForClientParticipation(
    PlanItemsForClientParticipationSearchKey planItemsForClientParticipationSearchKey)
    throws AppException, InformationalException {

    final PlannedItemNameAndIDDetailsList plannedItemNameAndIDDetailsList = new PlannedItemNameAndIDDetailsList();

    // BEGIN, CR00139526, GBA
    final ClientParticipation clientParticipationObj = ClientParticipationFactory.newInstance();

    try {
      plannedItemNameAndIDDetailsList.plannedItemNameAndIDDetailsList = clientParticipationObj.listPlanItemsForClientParticipation(
        planItemsForClientParticipationSearchKey.planItemsForClientParticipationSearchKey);
      plannedItemNameAndIDDetailsList.createClientPartInd = true;
    } catch (final AppException e) {
      plannedItemNameAndIDDetailsList.infoMsg = addExceptionToInformational(e);
    }
    // END, CR00139526

    return plannedItemNameAndIDDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @param dtls
   * Service plan delivery details.
   */

  @Override
  public void modifyServicePlanDetails(ModifySPOutcomeAndCommentsKey key,
    ModifySPOutcomeAndCommentsDetails dtls) throws AppException,
      InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    servicePlanDeliveryObj.modifyServicePlanOutcomeAndComments(key.key,
      dtls.details);

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery details to be modified.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details of outcome and comments to be modified.
   */
  @Override
  public ReadOutcomeAchievedAndCommentsDetails readOutcomeAchievedAndComments(ReadOutcomeAchievedAndCommentsKey key)
    throws AppException, InformationalException {

    // create return struct
    final curam.serviceplans.facade.struct.ReadOutcomeAchievedAndCommentsDetails readOutcomeAchievedAndCommentsDetails = new curam.serviceplans.facade.struct.ReadOutcomeAchievedAndCommentsDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // read service plan details
    readOutcomeAchievedAndCommentsDetails.details = servicePlanDeliveryObj.readOutcomeAchievedAndComments(
      key.key);

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // set the key to read context description
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.key.caseHeaderKey.caseID;
    // read context description
    readOutcomeAchievedAndCommentsDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readOutcomeAchievedAndCommentsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery details to be modified.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details of service plan delivery type and comments.
   */
  @Override
  public ReadServicePlanTypesAndCommentsDetails readServicePlanTypesAndComments(ReadServicePlanTypesAndCommentsKey key)
    throws AppException, InformationalException {

    // create return struct
    final curam.serviceplans.facade.struct.ReadServicePlanTypesAndCommentsDetails readServicePlanTypesAndCommentsDetails = new curam.serviceplans.facade.struct.ReadServicePlanTypesAndCommentsDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // read service plan details
    readServicePlanTypesAndCommentsDetails.dtls = servicePlanDeliveryObj.readServicePlanTypesAndComments(
      key.key);

    return readServicePlanTypesAndCommentsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the service plan goal.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   * @param details
   * Service plan delivery details.
   */
  @Override
  public void modifyServicePlanGoal(ModifyServicePlanGoalKey key,
    ModifyServicePlanGoalDetails details) throws AppException,
      InformationalException {

    // Service layer object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    servicePlanDeliveryObj.modifyServicePlanGoal(key.key, details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Modifies service plan type and comments.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @param dtls
   * Service plan delivery details.
   */
  @Override
  public InformationalMsgDtlsList modifyServicePlanTypeAndComments(
    ModifyServicePlanTypeKey key, ModifyServicePlanTypeDetails dtls)
    throws AppException, InformationalException {

    // return struct
    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    // Service layer object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // modify the details
    servicePlanDeliveryObj.modifyServicePlanTypeAndComments(key.key, dtls.dtls);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads a list of goals for the service plan.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   */

  @Override
  public ReadServicePlanGoalsDetails readServicePlanGoals(
    ReadServicePlanGoalsKey key) throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // create return struct
    final curam.serviceplans.facade.struct.ReadServicePlanGoalsDetails readServicePlanGoalsDetails = new curam.serviceplans.facade.struct.ReadServicePlanGoalsDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read details
    readServicePlanGoalsDetails.dtls = servicePlanDeliveryObj.readServicePlanGoals(
      key.key);

    return readServicePlanGoalsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads Contract details for creating a contract.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   */

  @Override
  public CaseParticipantRoleIDStruct readContractDetailsForCreateContract(
    curam.serviceplans.facade.struct.CaseIDAndParticipantRoleIDKey key)
    throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // create return struct
    final curam.serviceplans.facade.struct.CaseParticipantRoleIDStruct caseParticipantRoleIDStruct = new curam.serviceplans.facade.struct.CaseParticipantRoleIDStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final curam.core.sl.struct.CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey = new curam.core.sl.struct.CaseIDAndParticipantRoleIDKey();

    caseIDAndParticipantRoleIDKey.caseID = key.caseID;
    caseIDAndParticipantRoleIDKey.participantRoleID = key.participantRoleID;

    // read details
    caseParticipantRoleIDStruct.caseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(caseIDAndParticipantRoleIDKey).caseParticipantRoleID;

    return caseParticipantRoleIDStruct;

  }

  // ___________________________________________________________________________
  /**
   * Creates a planned group for a service plan
   *
   * @param createPlanGroupDetails
   * Details for the creation of the planned group
   */
  @Override
  public void createPlanGroup(CreatePlanGroupDetails createPlanGroupDetails)
    throws AppException, InformationalException {

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    plannedGroupObj.create(createPlanGroupDetails.createPlanGroupDetails);

  }

  // BEGIN, CR00247294, PM
  /**
   * Lists all the plan groups and sub-goals for a specific service plan.
   *
   * @param key
   * unique identifier of the service plan case.
   *
   * @return List of plan groups and sub-goals associated with the service plan
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 5.2 SP4, is replaced with
   * {@link #listPlanContentforServicePlans(ServicePlanDeliveryKey)} This method
   * is deprecated as it was not showing any information
   * even if a goal was not there for service plans. This is
   * resolved in the new method by displaying an informational
   * message and user is not allowed to create a planned group and
   * subgoal,if goals are not there. See release note: CR00215472.
   */
  @Override
  @Deprecated
  // END, CR00247294
  public PlanContentDetailsList listPlanContent(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();
    curam.serviceplans.sl.struct.PlanContentDetailsList planContentDetailsListSL = null;
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();
    // return value
    final curam.serviceplans.facade.struct.PlanContentDetailsList planContentDetailsList = new curam.serviceplans.facade.struct.PlanContentDetailsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // set the key
    servicePlanDeliveryKey.key.caseID = key.servicePlanDeliveryKey.key.caseID;
    // call service layer for list
    planContentDetailsListSL = plannedGroupObj.listPlanContent(
      key.servicePlanDeliveryKey);

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    // filter sub goal details
    // Note
    // This processing has to be done at the presentation level, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct type
    for (int i = 0; i < planContentDetailsListSL.list.size(); i++) {

      final PlanContentDetails planContentDetailsAsStrings = new PlanContentDetails();

      final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
      final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

      PlannedSubGoalSensitivityCodeDetails plannedSubGoalSensitivityCodeDetails = null;

      // only want to check sensitivity for those in list of type sub goal
      if (planContentDetailsListSL.list.item(i).planContentTypeInd == false) {

        plannedSubGoalKey.plannedSubGoalID = planContentDetailsListSL.list.item(i).planContentID;
        plannedSubGoalSensitivityCodeDetails = plannedSubGoalObj.readSensitivityCode(
          plannedSubGoalKey);
      }
      // Assign ID's and content type as will never be displayed on screen
      planContentDetailsAsStrings.planContentID = planContentDetailsListSL.list.item(i).planContentID;
      planContentDetailsAsStrings.planContentType = planContentDetailsListSL.list.item(i).planContentType;

      // set indicator
      planContentDetailsAsStrings.planContentTypeInd = planContentDetailsListSL.list.item(i).planContentTypeInd;

      // if subgoal do the following:
      if (planContentDetailsListSL.list.item(i).planContentTypeInd == false
        && // if sub goal sensitivity higher than user sensitivity then replace
        // with ********
        Integer.parseInt(plannedSubGoalSensitivityCodeDetails.sensitivityCode)
          > Integer.parseInt(userSecurityDetails.sensitivity)) {

        // BEGIN, CR00002667, PMD
        planContentDetailsAsStrings.name = planContentDetailsAsStrings.outcome = planContentDetailsAsStrings.status = kSubGoalDetailsRestricted;

        planContentDetailsAsStrings.startDate = curam.util.type.Date.kZeroDate;
        planContentDetailsAsStrings.endDate = curam.util.type.Date.kZeroDate;
        // END, CR00002667

      } // planned group and planned subgoal will have same info
      else {
        planContentDetailsAsStrings.name = planContentDetailsListSL.list.item(i).name;

        // outcome and status only relate to a planned sub goal
        if (planContentDetailsListSL.list.item(i).planContentTypeInd == false) {
          // set outcome and status
          planContentDetailsAsStrings.outcome = CodeTable.getOneItem(
            OUTCOMEACHIEVED.TABLENAME,
            planContentDetailsListSL.list.item(i).outcome,
            TransactionInfo.getProgramLocale());
          planContentDetailsAsStrings.status = CodeTable.getOneItem(
            PLANNEDSUBGOALSTATUS.TABLENAME,
            planContentDetailsListSL.list.item(i).status,
            TransactionInfo.getProgramLocale());
        }

        // BEGIN, CR00002667, PMD
        planContentDetailsAsStrings.startDate = planContentDetailsListSL.list.item(i).startDate;
        planContentDetailsAsStrings.endDate = planContentDetailsListSL.list.item(i).endDate;
        // END, CR00002667

      }

      // add each filtered record to overall return struct
      planContentDetailsList.list.addRef(planContentDetailsAsStrings);
    }

    planContentDetailsList.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    planContentDetailsList.menuData.menuData = menuData.menuData;

    return planContentDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a planned group
   *
   * @param modifyPlanGroupDetails
   * Details of the modified planned group.
   */
  @Override
  public void modifyPlanGroup(ModifyPlanGroupDetails modifyPlanGroupDetails)
    throws AppException, InformationalException {

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    plannedGroupObj.modify(modifyPlanGroupDetails.modifyPlannedGroupDetails);
  }

  // ___________________________________________________________________________
  /**
   * Removes physically a planned group
   *
   * @param planGroupKey
   * Unique identifier of the planned group.
   */
  @Override
  public void removePlanGroup(PlanGroupKey planGroupKey) throws AppException,
      InformationalException {

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    plannedGroupObj.remove(planGroupKey.key);
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a planned group along with any child plan groups and
   * corresponding planned sub-goals
   *
   * @param key
   * unique identifier of the planned group.
   *
   * @return Details of the planned group and it's planned sub-goals and groups.
   */
  @Override
  public ReadPlannedGroupDetails viewPlanGroupDetails(PlanGroupKey key)
    throws AppException, InformationalException {

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();

    // Planned Group entity object
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupEntityObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    // Planned Sub-Goal entity object
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    // return struct
    final ReadPlannedGroupDetails readPlannedGroupDetails = new ReadPlannedGroupDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read details
    readPlannedGroupDetails.readPlannedGroupDetails = plannedGroupObj.viewDetails(
      key.key);

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    // Note
    // This processing has to be done at the presentation layer, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct
    // type, e.g. expectedStartDate -> DATE and not a string.
    final PlannedSubGoalDetailsForPlannedGroupList plannedSubGoalDetailsForPlannedGroupList = new PlannedSubGoalDetailsForPlannedGroupList();

    for (int i = 0; i
      < readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.size(); i++) {

      final PlannedSubGoalDetailsForPlannedGroup plannedSubGoalDetailsForPlannedGroup = new PlannedSubGoalDetailsForPlannedGroup();
      final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

      PlannedSubGoalSensitivityCodeDetails plannedSubGoalSensitivityCodeDetails = null;

      // only want to check sensitivity for those in list of type sub goal
      if (readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).planContentTypeInd
        == false) {

        plannedSubGoalKey.plannedSubGoalID = readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).planContentID;
        plannedSubGoalSensitivityCodeDetails = plannedSubGoalObj.readSensitivityCode(
          plannedSubGoalKey);
      }

      plannedSubGoalDetailsForPlannedGroup.plannedSubGoalID = readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).planContentID;

      // if subgoal do the following:
      if (readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).planContentTypeInd
        == false
          // if sub goal sensitivity higher than user sensitivity then replace
          // with ********
          && Integer.parseInt(
            plannedSubGoalSensitivityCodeDetails.sensitivityCode)
              > Integer.parseInt(userSecurityDetails.sensitivity)) {

        plannedSubGoalDetailsForPlannedGroup.name = plannedSubGoalDetailsForPlannedGroup.outcome = plannedSubGoalDetailsForPlannedGroup.status = kSubGoalDetailsRestricted;

        // BEGIN, CR00002667, PMD
        plannedSubGoalDetailsForPlannedGroup.startDate = curam.util.type.Date.kZeroDate;
        plannedSubGoalDetailsForPlannedGroup.endDate = curam.util.type.Date.kZeroDate;
        // END, CR00002667

      } // planned group and planned subgoal will have same info
      else {
        plannedSubGoalDetailsForPlannedGroup.name = readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).name;

        // BEGIN, CR00002667, PMD
        plannedSubGoalDetailsForPlannedGroup.startDate = readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).startDate;
        plannedSubGoalDetailsForPlannedGroup.endDate = readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).endDate;
        // END, CR00002667

        // outcome and status only relate to a planned sub goal
        if (readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).planContentTypeInd
          == false) {
          // set outcome and status
          plannedSubGoalDetailsForPlannedGroup.outcome = CodeTable.getOneItem(
            OUTCOMEACHIEVED.TABLENAME,
            readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).outcome,
            TransactionInfo.getProgramLocale());
          plannedSubGoalDetailsForPlannedGroup.status = CodeTable.getOneItem(
            PLANNEDSUBGOALSTATUS.TABLENAME,
            readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).status,
            TransactionInfo.getProgramLocale());
        }
        // set indicator
        plannedSubGoalDetailsForPlannedGroup.planContentTypeInd = readPlannedGroupDetails.readPlannedGroupDetails.planContentDetails.list.item(i).planContentTypeInd;
      }

      // Add each filtered record to overall struct.
      plannedSubGoalDetailsForPlannedGroupList.list.addRef(
        plannedSubGoalDetailsForPlannedGroup);
    }
    // Assign filtered struct
    readPlannedGroupDetails.subGoalDetailsList = plannedSubGoalDetailsForPlannedGroupList;

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // read case id for context description
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedGroupEntityObj.readCaseIDByPlannedGroupID(key.key.key).caseID;

    readPlannedGroupDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readPlannedGroupDetails;
  }

  // BEGIN, CR00228733, MR
  /**
   * Reads the details of a planned group along with any child planned groups
   * and corresponding planned sub-goals. It also returns plan content type
   * along with the sub-goal details for the planned group.
   *
   * @param planGroupKey
   * Contains unique identifier of the planned group.
   *
   * @return Details of the planned group and it's associated planned
   * sub-goals and groups.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadPlannedGroupAndSubGoalDetails viewPlannedGroupAndSubGoalDetails(
    final PlanGroupKey planGroupKey) throws AppException,
      InformationalException {

    final PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();
    final PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    final ReadPlannedGroupAndSubGoalDetails readPlannedGroupAndSubGoalDetails = new ReadPlannedGroupAndSubGoalDetails();

    ServicePlanSecurityImplementationFactory.register();
    readPlannedGroupAndSubGoalDetails.readPlannedGroupDetails = plannedGroupObj.viewDetails(
      planGroupKey.key);

    final UsersKey usersKey = new UsersKey();
    final Users usersObj = UsersFactory.newInstance();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    final UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    final PlannedSubGoalDetailsForPlanGroupList plannedSubGoalDetailsList = new PlannedSubGoalDetailsForPlanGroupList();
    final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
    PlannedSubGoalSensitivityCodeDetails plannedSubGoalSensitivityCodeDetails = null;

    for (final curam.serviceplans.sl.struct.PlanContentDetails planContentDetails : readPlannedGroupAndSubGoalDetails.readPlannedGroupDetails.planContentDetails.list.items()) {
      final PlannedSubGoalDetailsForPlanGroup plannedSubGoalDetails = new PlannedSubGoalDetailsForPlanGroup();

      // Only want to check sensitivity for those in list of type
      // sub goal.
      if (planContentDetails.planContentTypeInd == false) {

        plannedSubGoalKey.plannedSubGoalID = planContentDetails.planContentID;
        plannedSubGoalSensitivityCodeDetails = plannedSubGoalObj.readSensitivityCode(
          plannedSubGoalKey);
      }
      plannedSubGoalDetails.plannedSubGoalID = planContentDetails.planContentID;

      // If subgoal do the following:
      // if sub goal sensitivity higher than user sensitivity then replace
      // with ********
      if (planContentDetails.planContentTypeInd == false
        && Integer.parseInt(
          plannedSubGoalSensitivityCodeDetails.sensitivityCode)
            > Integer.parseInt(userSecurityDetails.sensitivity)) {
        plannedSubGoalDetails.name = plannedSubGoalDetails.outcome = plannedSubGoalDetails.status = kSubGoalDetailsRestricted;
        plannedSubGoalDetails.startDate = Date.kZeroDate;
        plannedSubGoalDetails.endDate = Date.kZeroDate;
      } // Planned group and planned subgoal will have same info.
      else {
        plannedSubGoalDetails.name = planContentDetails.name;
        plannedSubGoalDetails.startDate = planContentDetails.startDate;
        plannedSubGoalDetails.endDate = planContentDetails.endDate;

        // Outcome and status only relate to a planned sub goal.
        if (planContentDetails.planContentTypeInd == false) {
          plannedSubGoalDetails.outcome = CodeTable.getOneItem(
            OUTCOMEACHIEVED.TABLENAME, planContentDetails.outcome,
            TransactionInfo.getProgramLocale());
          plannedSubGoalDetails.status = CodeTable.getOneItem(
            PLANNEDSUBGOALSTATUS.TABLENAME, planContentDetails.status,
            TransactionInfo.getProgramLocale());
        }
        plannedSubGoalDetails.planContentTypeInd = planContentDetails.planContentTypeInd;
        plannedSubGoalDetails.planContentType = planContentDetails.planContentType;
      }
      plannedSubGoalDetailsList.list.addRef(plannedSubGoalDetails);
    }

    readPlannedGroupAndSubGoalDetails.subGoalDetailsList = plannedSubGoalDetailsList;
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupEntityObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedGroupEntityObj.readCaseIDByPlannedGroupID(planGroupKey.key.key).caseID;
    readPlannedGroupAndSubGoalDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);
    return readPlannedGroupAndSubGoalDetails;
  }

  // END, CR00228733

  // BEGIN, CR00222522, ELG
  // ___________________________________________________________________________
  /**
   * Shows service plan statement
   *
   * @param servicePlanDeliveryKey
   * Contains case ID of the service plan delivery.
   *
   * @return XML String containing information of Service Plan Statement
   * @deprecated Since Curam V5.2 SP3, replaced by
   * {@link #displayServicePlanStatement(ServicePlanDeliveryKey)}.
   * See release note: CR00222522.
   */
  @Override
  @Deprecated
  // END, CR00222522
  public ServicePlanStatementXMLString showServicePlanStatement(
    ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlanStatement servicePlanStatementObj = curam.serviceplans.sl.fact.ServicePlanStatementFactory.newInstance();

    final ServicePlanStatementXMLString servicePlanStatementXMLString = new ServicePlanStatementXMLString();

    servicePlanStatementXMLString.servicePlanStatementXMLString = servicePlanStatementObj.showStatement(
      servicePlanDeliveryKey.servicePlanDeliveryKey);

    servicePlanStatementXMLString.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanStatementXMLString.menuData.menuData = menuData.menuData;

    return servicePlanStatementXMLString;

  }

  // BEGIN, CR00222522, ELG
  // ___________________________________________________________________________
  /**
   * Returns service plan statement if it is available, else it returns
   * informational message.
   *
   * @param servicePlanDeliveryKey Contains case ID of the service plan
   * delivery.
   *
   * @return Structure containing XML String containing information of Service
   * Plan Statement, informational message list, context description
   * and menu data.
   */
  @Override
  public ServicePlanStatementDisplayDetails displayServicePlanStatement(
    ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlanStatement servicePlanStatementObj = curam.serviceplans.sl.fact.ServicePlanStatementFactory.newInstance();

    // Return structure
    final ServicePlanStatementDisplayDetails servicePlanStatementDisplayDetails = new ServicePlanStatementDisplayDetails();

    servicePlanStatementDisplayDetails.dtls = servicePlanStatementObj.showStatement1(
      servicePlanDeliveryKey.servicePlanDeliveryKey);

    servicePlanStatementDisplayDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanStatementDisplayDetails.menuData.menuData = menuData.menuData;

    // get informational messages (if available)
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    final String[] informationals = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < informationals.length; i++) {
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = informationals[i];
      servicePlanStatementDisplayDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return servicePlanStatementDisplayDetails;

  }

  // END, CR00222522

  // ___________________________________________________________________________
  /**
   * Reads the details of a Baseline Plan Group.
   *
   * @param key
   * containing the BaselineID and PlannedGroupID.
   *
   * @return Details of the baseline plan group.
   */
  @Override
  public BaselinePlanGroupDetails viewBaselinePlanGroupDetails(
    BaselinePlanGroupReadDetailsKey key) throws AppException,
      InformationalException {

    // return struct
    final curam.serviceplans.facade.struct.BaselinePlanGroupDetails baselinePlanGroupDetails = new curam.serviceplans.facade.struct.BaselinePlanGroupDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Baseline manipulation variables
    final BaselineSubGoal baselineSubGoalObj = BaselineSubGoalFactory.newInstance();
    final Baseline baselineObj = BaselineFactory.newInstance();

    curam.serviceplans.sl.struct.BaselinePlanGroupDetails baselinePlanGroupDetailsSL = new curam.serviceplans.sl.struct.BaselinePlanGroupDetails();

    // read Baseline Plan Group Details
    baselinePlanGroupDetailsSL = baselineObj.readBaselinePlanGroupDetails(
      key.baselinePlanGroupReadDetailsKey);

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    // filter Baseline SubGoal details
    // Note
    // This processing has to be done at the presentation level, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct type
    for (int i = 0; i
      < baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.size(); i++) {
      final curam.serviceplans.facade.struct.BPGChildContentListDetails bPGChildContentListDetails = new curam.serviceplans.facade.struct.BPGChildContentListDetails();
      final BaselineSubGoalKey baselineSubGoalKey = new BaselineSubGoalKey();

      baselineSubGoalKey.baselineSubGoalID = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).baselineSubGoalID;
      final BaselineSensitivityCode baselineSensitivityCode = baselineSubGoalObj.readSensitivityCode(
        baselineSubGoalKey);

      // Assign ID's and content type as will never be displayed on screen
      bPGChildContentListDetails.planContentID = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).plannedSubGoalID;
      bPGChildContentListDetails.caseID = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).caseID;
      bPGChildContentListDetails.planContentType = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).planContentType;

      // set indicator
      bPGChildContentListDetails.planGroupOrSubGoalInd = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).subGoalIndicator;

      // if sub goal sensitivity higher than user sensitivity then replace with
      // ********
      if (Integer.parseInt(baselineSensitivityCode.sensitivityCode)
        > Integer.parseInt(userSecurityDetails.sensitivity)) {

        bPGChildContentListDetails.name = kSubGoalDetailsRestricted;

        // BEGIN, CR00002667, PMD
        bPGChildContentListDetails.actualEndDate = curam.util.type.Date.kZeroDate;
        bPGChildContentListDetails.actualStartDate = curam.util.type.Date.kZeroDate;
        bPGChildContentListDetails.expectedEndDate = curam.util.type.Date.kZeroDate;
        bPGChildContentListDetails.expectedStartDate = curam.util.type.Date.kZeroDate;
        // END, CR00002667

      } else // return baselineSubGoal details
      {
        bPGChildContentListDetails.name = CodeTable.getOneItem(
          SUBGOALNAME.TABLENAME,
          baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).subGoalName,
          TransactionInfo.getProgramLocale());
        // BEGIN, CR00002667, PMD
        bPGChildContentListDetails.actualStartDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).actualStartDate;

        bPGChildContentListDetails.actualEndDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).actualEndDate;

        bPGChildContentListDetails.expectedEndDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).expectedEndDate;

        bPGChildContentListDetails.expectedStartDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGSubGoalContentListDetails.item(i).expectedStartDate;
        // END, CR00002667

      }

      // add each filtered record to overall struct
      baselinePlanGroupDetails.list.addRef(bPGChildContentListDetails);
    }

    // filter Baseline Plan Group details
    // Note
    // This processing has to be done at the presentation level, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct type
    for (int i = 0; i
      < baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.size(); i++) {

      final curam.serviceplans.facade.struct.BPGChildContentListDetails bPGChildContentListDetails = new curam.serviceplans.facade.struct.BPGChildContentListDetails();

      // set the Plan Group ID
      bPGChildContentListDetails.planContentID = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).plannedGroupID;

      // set the Plan Group Name
      bPGChildContentListDetails.name = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).plannedGroupName;

      // set the Plan Content type
      bPGChildContentListDetails.planContentType = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).planContentType;

      // set the case ID
      bPGChildContentListDetails.caseID = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).caseID;

      // set indicator
      bPGChildContentListDetails.planGroupOrSubGoalInd = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).planGroupIndicator;

      // BEGIN, CR00002667, PMD
      bPGChildContentListDetails.actualStartDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).actualStartDate;

      bPGChildContentListDetails.actualEndDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).actualEndDate;

      bPGChildContentListDetails.expectedEndDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).expectedEndDate;

      bPGChildContentListDetails.expectedStartDate = baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.listBPGChildBaselinePlannedGroupDetails.item(i).expectedStartDate;
      // END, CR00002667

      // add each filtered record to overall Struct
      baselinePlanGroupDetails.list.addRef(bPGChildContentListDetails);

    }

    // BEGIN, CR00057481, PMD
    // Add milestone list to return struct
    baselinePlanGroupDetails.milestoneList.listDetails.assign(
      baselinePlanGroupDetailsSL.baselineGroupChildPlannedContentListDetails.milestoneList);
    // END, CR00057481

    // add main Baseline Plan Group Details
    baselinePlanGroupDetails.bPGPlanGroupDetails.baselineName = baselinePlanGroupDetailsSL.baselinePlannedGroupDetails.baselineName;

    baselinePlanGroupDetails.bPGPlanGroupDetails.plannedGroupID = baselinePlanGroupDetailsSL.baselinePlannedGroupDetails.plannedGroupID;

    baselinePlanGroupDetails.bPGPlanGroupDetails.plannedGroupName = baselinePlanGroupDetailsSL.baselinePlannedGroupDetails.plannedGroupName;

    return baselinePlanGroupDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads Baseline Gantt Details to be displayed.
   *
   * @param key
   * Contains unique id of the baseline.
   *
   * @return Gantt Details.
   */
  @Override
  public BaselineGanttDetails viewBaselineGantt(
    curam.serviceplans.facade.struct.BaselineKey key) throws AppException,
      InformationalException {

    // return value
    final BaselineGanttDetails baselineGanttDetails = new BaselineGanttDetails();

    // Baseline business object
    final Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // register service plan security
    curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

    // Baseline Entity business object
    final curam.serviceplans.sl.entity.intf.Baseline baselineObjEntity = curam.serviceplans.sl.entity.fact.BaselineFactory.newInstance();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = baselineObjEntity.readCaseIDByBaselineID(key.key.baselineKey).caseID;

    // compare baselines
    baselineGanttDetails.baselineGantt = baselineObj.viewGantt(key.key);

    // read context description
    baselineGanttDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return baselineGanttDetails;
  }

  // ___________________________________________________________________________
  /**
   * Views the Tracking Gantt Details for a Service Plan Delivery
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details in form of XML string to be displayed as Gantt diagram
   */
  @Override
  public TrackingGanttDetails viewTrackingGantt(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // return value
    final TrackingGanttDetails trackingGanttDetails = new TrackingGanttDetails();

    // TrackingGantt business object
    final TrackingGantt trackingGanttObj = curam.serviceplans.sl.fact.TrackingGanttFactory.newInstance();

    // register service plan security
    curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00139524, GBA
    // compare baselines
    try {
      trackingGanttDetails.trackGanttDetails = trackingGanttObj.viewTrackingGantt(
        key.servicePlanDeliveryKey);
      trackingGanttDetails.displayPlanInd = true;
    } catch (final AppException e) {
      trackingGanttDetails.infoMsg = addExceptionToInformational(e);
    }
    // END, CR00139524

    // read context description
    trackingGanttDetails.description = getServicePlanContextDescription(key);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    trackingGanttDetails.menuData.menuData = menuData.menuData;

    return trackingGanttDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists Tasks for Service Plan
   *
   * @param servicePlanDeliveryKey
   * Contains case ID of the service plan delivery.
   *
   * @return List Of Tasks for Service Plan
   */
  @Override
  public ListServicePlanTaskDetails listTask(
    ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {

    // create return object
    final ListServicePlanTaskDetails listServicePlanTaskDetails = new ListServicePlanTaskDetails();

    // Task manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    curam.core.sl.struct.CaseAndConcernLinkedTaskDtls caseAndConcernLinkedTaskDtls = new curam.core.sl.struct.CaseAndConcernLinkedTaskDtls();

    final curam.core.sl.struct.SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new curam.core.sl.struct.SearchTaskForConcernOrCaseKey();

    // BEGIN, CR00001117, CM
    // register service plan security
    curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

    final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

    // set service plan security key
    servicePlanSecurityKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // check service plan security
    checkSecurity(servicePlanSecurityKey);

    // END, CR00001117

    // set key to read the list of tasks
    searchTaskForConcernOrCaseKey.details.linkedID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // Get list of case tasks
    caseAndConcernLinkedTaskDtls = workAllocationTaskObj.listCaseTasks(
      searchTaskForConcernOrCaseKey);

    // assign list to output structure
    listServicePlanTaskDetails.taskSearchDetailsList.assign(
      caseAndConcernLinkedTaskDtls.dtls);

    // Iterate through the list and set reservedByExistsInd to true
    for (int i = 0; i
      < listServicePlanTaskDetails.taskSearchDetailsList.dtls.size(); i++) {

      if (listServicePlanTaskDetails.taskSearchDetailsList.dtls.item(i).reservedBy.length()
        > 0) {

        listServicePlanTaskDetails.taskSearchDetailsList.dtls.item(i).reservedByExistsInd = true;
      }
    }

    // read context description and assign to return object
    listServicePlanTaskDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;

    // read menu data and assign to return object
    listServicePlanTaskDetails.icServicePlanMenuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    return listServicePlanTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns data representing case events and activities for a Service Plan
   *
   * @param key
   * Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   */
  @Override
  public ICServicePlanEventandActivity searchICServicePlanEventandActivity(
    curam.serviceplans.facade.struct.SearchCaseandEventKey key)
    throws AppException, InformationalException {

    // Create return object
    final curam.serviceplans.facade.struct.ICServicePlanEventandActivity icServicePlanEventandActivity = new curam.serviceplans.facade.struct.ICServicePlanEventandActivity();

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    // BEGIN, CR00001117, CM
    // register the security implementation
    // register service plan security
    curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

    final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

    // set service plan security key
    servicePlanSecurityKey.caseID = key.caseID;
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // check service plan security
    checkSecurity(servicePlanSecurityKey);
    // END, CR00001117

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj.readEventsByType(
      viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * viewCaseEventDetailsList.dtls.size());

    xmlString.append(kCuramCalendarDataHeader).append(kQuote).append(curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASE, TransactionInfo.getProgramLocale())).append(kQuote).append(kCloseBracket).append(
      kSpace);

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode.equals(
        CASEEVENTTYPE.ACTIVITY)) {

        // BEGIN, CR00233701, PB
        if (0 != viewCaseEventDetailsList.dtls.item(i).caseEventID) {
          activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).caseEventID;
        } else {
          activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        }
        // END, CR00233701
        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj.parseActivity(
          activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls.item(i).endDateTime;
        // BEGIN, CR00233701, PB
        if (0 != viewCaseEventDetailsList.dtls.item(i).caseEventID) {
          eventElementDetails.eventID = viewCaseEventDetailsList.dtls.item(i).caseEventID;
        } else {
          activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        }
        // END, CR00233701

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls.item(i).typeCode;

        // if it is a event of type case decision with a status of superseded
        // do not add to the calendar
        final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory.newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to calendar if an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj.parseEvent(
              eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        }
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);
    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();
    icServicePlanEventandActivity.calendarXMLstring.assign(
      caseEventAndActivityDetails);

    // set the context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.caseID;
    icServicePlanEventandActivity.spcontextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // set the menu data
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.caseID;
    icServicePlanEventandActivity.spmenudata = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    return icServicePlanEventandActivity;

  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Key to read the list of Service Plan events.
   *
   * @return List of events on the Service Plan.
   * @deprecated This method is replaced by
   * {@link #listICServicePlanEventDetails1(SearchCaseandEventKey)} The new
   * method returns the same details but also returns
   * indicators that will be used to conditionally display list row
   * action appropriate to the event type.
   * @deprecated - since 6.0
   * Returns a list of events for a Service Plan
   */
  @Override
  @Deprecated
  public ListICServicePlanEventDetails listICServicePlanEventDetails(
    SearchCaseandEventKey key) throws AppException, InformationalException {

    final ListICServicePlanEventDetails listICServicePlanEventDetails = new ListICServicePlanEventDetails();

    final ListICServicePlanEventDetails1 listICServicePlanEventDetails1 = listICServicePlanEventDetails1(
      key);

    listICServicePlanEventDetails.spcontextDescription = listICServicePlanEventDetails1.spcontextDescription;
    listICServicePlanEventDetails.spmenuData = listICServicePlanEventDetails1.spmenuData;

    ICProductDeliveryEventDetails icServicePlanEventDetails;

    for (int i = 0; i < listICServicePlanEventDetails1.eventDetails.dtls.size(); i++) {

      icServicePlanEventDetails = new ICProductDeliveryEventDetails();
      icServicePlanEventDetails.assign(
        listICServicePlanEventDetails1.eventDetails.dtls.item(i));

      listICServicePlanEventDetails.eventDetails.dtls.addRef(
        icServicePlanEventDetails);
    }

    return listICServicePlanEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of events for a Service Plan
   *
   * @param key
   * Key to read the list of Service Plan events.
   *
   * @return List of events on the Service Plan.
   */
  @Override
  public ListICServicePlanEventDetails1 listICServicePlanEventDetails1(
    SearchCaseandEventKey key) throws AppException, InformationalException {

    // Create return object
    final ListICServicePlanEventDetails1 listICServicePlanEventDetails = new ListICServicePlanEventDetails1();

    // ViewCaseEvents manipulation variables
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList;

    // ServicePlanDelivery ContextDescriptionKey object
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.caseID;

    // set menu data
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.caseID;

    // BEGIN, CR00001117, CM
    // register the security implementation
    // register service plan security
    curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

    final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

    // set service plan security key
    servicePlanSecurityKey.caseID = key.caseID;
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // check service plan security
    checkSecurity(servicePlanSecurityKey);
    // END, CR00001117

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.assign(viewCaseEventsByCaseIDAndTypeKey);

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList = viewCaseEventsObj.readActiveEventsByType1(
      viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICServicePlanEventDetails.eventDetails.dtls.ensureCapacity(
        viewActiveCaseEventDetailsList.dtls.size());

      // If the list has case event decisions of type superseded, do not return
      // them
      // on the view list for the case

      // Create new struct to hold all case events except those of type
      // superseded case decisions.
      final ViewActiveCaseEventDetailsList1 viewFileteredCaseEventDetailsList = new ViewActiveCaseEventDetailsList1();

      for (int i = 0; i < viewActiveCaseEventDetailsList.dtls.size(); i++) {
        // Check event to see of type case decision
        final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory.newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewActiveCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to list if an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(CASEDECISIONSTATUS.CURRENT)) {

            viewFileteredCaseEventDetailsList.dtls.addRef(
              viewActiveCaseEventDetailsList.dtls.item(i));
          }
        } else {

          // if not a case decision event - add to list.
          viewFileteredCaseEventDetailsList.dtls.addRef(
            viewActiveCaseEventDetailsList.dtls.item(i));
        }

      }

      // Assign details to the return object
      listICServicePlanEventDetails.eventDetails.assign(
        viewFileteredCaseEventDetailsList);
    }

    // Read context description
    listICServicePlanEventDetails.spcontextDescription = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Read menu data
    listICServicePlanEventDetails.spmenuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    // Determine if CPM is installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      listICServicePlanEventDetails.isCPMInstalledInd = true;
    }

    return listICServicePlanEventDetails;
  }

  // BEGIN, CR00000080, CM
  // _________________________________________________________________________
  /**
   * Sets Service Unit Delivery record to status "Canceled".
   *
   * @param key
   * The key identifying the record to be cancelled.
   */
  @Override
  public void cancelServiceUnitDelivery(CancelServiceUnitDeliveryKey key)
    throws AppException, InformationalException {

    // Service Unit Delivery Business object
    final ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Cancel details
    serviceUnitDeliveryObj.cancelServiceUnitDelivery(key.key);

  }

  // ___________________________________________________________________________
  /**
   * Creates a service unit delivery
   *
   * @param dtls
   * details for the creation of the service unit delivery
   * @return ServiceUnitDeliveryKey the unique id of the newly created service
   * unit delivery
   */
  @Override
  public ServiceUnitDeliveryKey createServiceUnitDelivery(
    ServiceUnitDeliveryDetails dtls) throws AppException,
      InformationalException {

    // service unit delivery business object
    final ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();

    // create return struct
    final ServiceUnitDeliveryKey serviceUnitDeliveryKey = new ServiceUnitDeliveryKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Record details
    serviceUnitDeliveryKey.key = serviceUnitDeliveryObj.recordServiceUnitDelivery(
      dtls.dtls);

    return serviceUnitDeliveryKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists active service unit deliveries for a planned item on a given day.
   *
   * @param serviceUnitDeliveryListKey
   * key containing the planned item id, delivery date and record
   * status
   *
   * @return List of service unit delivery details.
   */
  @Override
  public ServiceUnitDeliveryDetailsList listServiceUnitDeliveries(
    ServiceUnitDeliveryListKey serviceUnitDeliveryListKey)
    throws AppException, InformationalException {

    // Service Unit Delivery business object
    final ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();

    // Planned Item entity object
    final PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // create return struct
    final ServiceUnitDeliveryDetailsList serviceUnitDeliveryDetailsList = new ServiceUnitDeliveryDetailsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // call service layer for list
    serviceUnitDeliveryDetailsList.list = serviceUnitDeliveryObj.listServiceUnitDelivery(
      serviceUnitDeliveryListKey.key);

    // ServicePlanDelivery ContextDescriptionKey object
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = new ReadCaseIDByPlannedItemDetailsStruct();

    final curam.serviceplans.facade.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.facade.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = serviceUnitDeliveryListKey.key.key.plannedItemID;

    // read method to retrieve the case ID
    readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey.plannedItemIDKey);

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    // read context description
    serviceUnitDeliveryDetailsList.pItemContextDescription = getPlannedItemContextDescription(
      plannedItemIDKey);

    return serviceUnitDeliveryDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a service unit delivery
   *
   * @param dtls
   * Details of the modified service unit delivery.
   */
  @Override
  public void modifyServiceUnitDelivery(ServiceUnitDeliveryDetails dtls)
    throws AppException, InformationalException {

    // ServiceUnitDelivery business object
    final curam.serviceplans.sl.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // modify details
    serviceUnitDeliveryObj.modifyServiceUnitDelivery(dtls.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a service unit delivery
   *
   * @param readServiceUnitDeliveryKey
   * a key containing the planned item id and the service unit delivery
   * id
   *
   * @return the service unit details
   */
  @Override
  public ReadServiceUnitDeliveryDetails readServiceUnitDeliveryDetails(
    ReadServiceUnitDeliveryKey readServiceUnitDeliveryKey)
    throws AppException, InformationalException {

    // ServiceUnitDelivery business object
    final ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();

    // create return struct
    final curam.serviceplans.facade.struct.ReadServiceUnitDeliveryDetails readServiceUnitDeliveryDetails = new curam.serviceplans.facade.struct.ReadServiceUnitDeliveryDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read details
    readServiceUnitDeliveryDetails.details = serviceUnitDeliveryObj.viewServiceUnitDelivery(
      readServiceUnitDeliveryKey.key);

    final PlannedItemIDKey plannedItemIDkey = new PlannedItemIDKey();

    plannedItemIDkey.plannedItemIDKey.plannedItemIDKey.plannedItemID = readServiceUnitDeliveryKey.key.plannedItemKey.plannedItemIDKey.plannedItemID;

    // read context description
    readServiceUnitDeliveryDetails.pItemContextDescription = getPlannedItemContextDescription(
      plannedItemIDkey);

    return readServiceUnitDeliveryDetails;
  }

  // END, CR00000080

  // BEGIN, CR00000082, PMD
  // BEGIN, CR00235251, TV
  // ___________________________________________________________________________
  /**
   * Adds a service unit delivery planned item to a planned subgoal.
   *
   * @param details
   * Details of the plan item to be added.
   *
   * @deprecated Since Curam v6, replaced with
   * {@link createServiceUnitDeliveryPlanItemToSubGoal}.
   * Reason:- As per code line issue, the
   * attribute 'planTemplatePlanItemID' removed from
   * 'CreatePlannedItemDetailsStruct' struct and added into
   * 'PlannedItemDetailsStruct' struct along with existing attribute
   * of 'CreatePlannedItemDetailsStruct' struct.
   * See release note <CR00235251>
   */
  @Override
  // END, CR00235251
  @Deprecated
  public void addServiceUnitDeliveryPlanItemToSubGoal(
    curam.serviceplans.facade.struct.CreatePlannedItemDetailsStruct details)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Create the planned item
    plannedItemObj.createBasicPlanItem(details.createPlannedItemDetailsStruct);

  }

  // BEGIN, CR00226831, LP
  // ___________________________________________________________________________
  /**
   * Reads the details required to display the add service unit delivery plan
   * item screen
   *
   * @param plannedSubGoalKey
   * the key of the sub-goal
   * @param planItemKey
   * the key of the plan item
   * @return the service unit plan item details
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link ServicePlanDelivery#readDtlsForAddServiceUnitPlannedItem (PlannedSubGoalKey, PlanItemKey)}
   * .
   * In addition to the current functionality, the new method return struct
   * curam.serviceplans.facade.struct.ReadDtlsForAddServiceUnitPlannedItem
   * contains all the fields of ReadDetailsForAddServiceUnitPlannedItem along
   * with field guidanceURL.
   * See release note : <CR00226831>
   */
  @Override
  @Deprecated
  public curam.serviceplans.facade.struct.ReadDetailsForAddServiceUnitPlannedItem readDetailsForAddServiceUnitPlannedItem(
    PlannedSubGoalKey plannedSubGoalKey, PlanItemKey planItemKey)
    throws AppException, InformationalException {

    // Return Object
    final curam.serviceplans.facade.struct.ReadDetailsForAddServiceUnitPlannedItem readDetailsForAddServiceUnitPlannedItem = new curam.serviceplans.facade.struct.ReadDetailsForAddServiceUnitPlannedItem();
    final ReadDtlsForAddServiceUnitPlannedItem readDtlsAddServiceUnitPI = readDtlsForAddServiceUnitPlannedItem(
      plannedSubGoalKey, planItemKey);

    readDetailsForAddServiceUnitPlannedItem.subGoalName = readDtlsAddServiceUnitPI.subGoalName;
    readDetailsForAddServiceUnitPlannedItem.planItemName = readDtlsAddServiceUnitPI.planItemName;
    readDetailsForAddServiceUnitPlannedItem.unitType = readDtlsAddServiceUnitPI.unitType;
    readDetailsForAddServiceUnitPlannedItem.authorizedUnits = readDtlsAddServiceUnitPI.authorizedUnits;
    readDetailsForAddServiceUnitPlannedItem.maximumUnits = readDtlsAddServiceUnitPI.maximumUnits;
    readDetailsForAddServiceUnitPlannedItem.outcomesForPlanItem = readDtlsAddServiceUnitPI.outcomesForPlanItem;
    readDetailsForAddServiceUnitPlannedItem.participants = readDtlsAddServiceUnitPI.participants;
    readDetailsForAddServiceUnitPlannedItem.respParticipantList = readDtlsAddServiceUnitPI.respParticipantList;

    return readDetailsForAddServiceUnitPlannedItem;
  }

  // END, CR00226831

  // ___________________________________________________________________________
  /**
   * Reads the service unit delivery planned item details and a list of service
   * unit deliveries
   *
   * @param key
   * unique identifier of the planned item.
   * @return Details of the service unit delivery planned item and the list of
   * service unit deliveries
   */
  @Override
  public PlannedItemAndServiceUnitDetails viewServiceUnitPlannedItemDetails(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Return Object
    final PlannedItemAndServiceUnitDetails plannedItemAndServiceUnitDetails = new PlannedItemAndServiceUnitDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    try {

      // Get the service unit planned item details
      plannedItemAndServiceUnitDetails.details = plannedItemObj.readServiceUnitPlannedItemDetails(
        key.plannedItemIDKey);

    } catch (final RecordNotFoundException e) {
      throw new AppException(
        BPOBASELINE.BASELINE_PLAN_ITEM_RV_PLANNED_ITEM_DELETED);
    }

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = plannedItemAndServiceUnitDetails.details.serviceUnitPlannedItemDetails.viewPlannedItemDetails.caseID;

    // BEGIN CR00123917, GBA
    // get available plan participants for responsible party
    plannedItemAndServiceUnitDetails.planParticipants.list = plannedItemObj.getResponsibleParticipantsForPlannedItem(key.plannedItemIDKey).list;
    // END CR00123917

    // Set the context description
    plannedItemAndServiceUnitDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return plannedItemAndServiceUnitDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a service unit delivery planned item.
   *
   * @param details
   * the planned item details to be modified.
   * @return ModifyPlanItemReturnStruct the modified details
   */
  @Override
  public ModifyPlanItemReturnStruct modifyServiceUnitPlannedItemDetails(
    ModifyPlannedItemDetailsStruct details) throws AppException,
      InformationalException {

    // Return Object
    final ModifyPlanItemReturnStruct modifyPlanItemReturnStruct = new ModifyPlanItemReturnStruct();

    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Planned Item entity object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Modify the basic planned item
    plannedItemObj.modifyBasicPlanItem(details.modifyPlannedItemDetailsStruct);

    modifyPlanItemReturnStruct.plannedSubGoalID = details.modifyPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // Read Case ID by planned Subgoal id
    plannedItemIDKey.plannedItemID = details.modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    modifyPlanItemReturnStruct.caseID = plannedItemEntObj.readCaseIDByPlannedItemID(plannedItemIDKey).caseID;

    return modifyPlanItemReturnStruct;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details required to display the add service unit delivery to the
   * plan item screen
   *
   * @param plannedItemIDKey
   * the key of the planned item
   *
   * @return the service unit delivery details
   */
  @Override
  public ReadDetailsForAddServiceUnitDelivery readDetailsForAddServiceUnitDelivery(PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // ServiceUnitDelivery business object
    final curam.serviceplans.sl.intf.ServiceUnitDelivery serviceUnitDeliveryObj = curam.serviceplans.sl.fact.ServiceUnitDeliveryFactory.newInstance();

    // create return struct
    final ReadDetailsForAddServiceUnitDelivery readDetailsForAddServiceUnitDelivery = new ReadDetailsForAddServiceUnitDelivery();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Reads the service unit delivery details
    readDetailsForAddServiceUnitDelivery.sUDetails = serviceUnitDeliveryObj.readDetailsForAddServiceUnitDelivery(
      plannedItemIDKey.plannedItemIDKey);

    // read context description
    readDetailsForAddServiceUnitDelivery.pItemContextDescription = getPlannedItemContextDescription(
      plannedItemIDKey);

    return readDetailsForAddServiceUnitDelivery;
  }

  // END, CR00000082

  // BEGIN, CR00000086, CSH
  // ___________________________________________________________________________
  /**
   * Reads the authorized unit details on a service unit planned item
   *
   * @param key
   * the key of the planned item
   * @return ReadAuthorizedUnitDetailsForModify the details to be modified
   */
  @Override
  public ReadAuthorizedUnitDetailsForModify readAuthorizedUnitDetailsForModify(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // Return Object
    final ReadAuthorizedUnitDetailsForModify readAuthorizedUnitDetailsForModify = new ReadAuthorizedUnitDetailsForModify();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Modify the planned item
    readAuthorizedUnitDetailsForModify.readAuthorizedUnitDetailsForModify = plannedItemObj.readAuthorizedUnitDetailsForModify(
      key.plannedItemIDKey);

    // read context description
    readAuthorizedUnitDetailsForModify.pItemContextDescription = getPlannedItemContextDescription(
      key);

    return readAuthorizedUnitDetailsForModify;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the authorized units on a service unit planned item
   *
   * @param key
   * Key of the planned item
   * @param details
   * Details to be modified
   */
  @Override
  public void modifyAuthorizedUnits(PlannedItemIDKey key,
    ModifyAuthorizedUnitsDetails details) throws AppException,
      InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Modify the planned item
    plannedItemObj.modifyAuthorizedUnits(key.plannedItemIDKey,
      details.modifyAuthorizedUnitsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Returns the authorized unit history details for a service unit planned item
   *
   * @param key
   * the key of the planned item
   * @return AuthorizedUnitHistoryDetails the authorization history details
   */
  @Override
  public AuthorizedUnitHistoryDetails viewAuthorizationHistoryDetails(
    curam.serviceplans.facade.struct.AuthorizedUnitHistoryKey key)
    throws AppException, InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Authorized Unit History business object
    final curam.serviceplans.sl.intf.AuthorizedUnitHistory authorizedUnitHistoryObj = curam.serviceplans.sl.fact.AuthorizedUnitHistoryFactory.newInstance();

    // Return Object
    final AuthorizedUnitHistoryDetails authorizedUnitHistoryDetails = new AuthorizedUnitHistoryDetails();

    // Read the authorized unit history details
    authorizedUnitHistoryDetails.dtls = authorizedUnitHistoryObj.read(key.key);

    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = authorizedUnitHistoryDetails.dtls.dtls.plannedItemID;

    // read context description
    authorizedUnitHistoryDetails.pItemContextDescription = getPlannedItemContextDescription(
      plannedItemIDKey);

    // Return the authorization history details
    return authorizedUnitHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list authorized unit history details for a service unit planned
   * item
   *
   * @param key
   * The key of the planned item
   * @return AuthorizedUnitHistoryDetailsList the list of authorization history
   * details
   */
  @Override
  public AuthorizedUnitHistoryDetailsList viewAuthorizationHistoryList(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.AuthorizedUnitHistory authorizedUnitHistoryObj = curam.serviceplans.sl.fact.AuthorizedUnitHistoryFactory.newInstance();

    // Return Object
    final AuthorizedUnitHistoryDetailsList authorizedUnitHistoryDetailsList = new AuthorizedUnitHistoryDetailsList();

    // Read back the list of authorization history details
    authorizedUnitHistoryDetailsList.dtls = authorizedUnitHistoryObj.viewAuthorizationHistoryList(
      key.plannedItemIDKey);

    // read context description
    authorizedUnitHistoryDetailsList.pItemContextDescription = getPlannedItemContextDescription(
      key);

    // Return the list of authorization history details
    return authorizedUnitHistoryDetailsList;
  }

  // END, CR00000086

  // BEGIN, CR00001117, CM
  /**
   * Checks Service Plan security.
   *
   * @param key
   * Contains the Service Plan Security key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void checkSecurity(
    curam.serviceplans.facade.struct.ServicePlanSecurityKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    final ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // Case Header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Service Plan Delivery manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryobj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // populate operation type
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = key.securityCheckType;

    // set case header key
    caseHeaderKey.caseID = key.caseID;

    // populate concern role ID
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // set service plan delivery key
    servicePlanDeliveryKey.key.caseID = key.caseID;

    // populate service plan ID
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryobj.readServicePlanID(servicePlanDeliveryKey).key.servicePlanID;

    // check service plan security
    servicePlanSecurity.servicePlanOperationSecurityCheck(
      spOperationSecurityKey);
  }

  // END, CR00001117

  // BEGIN, CR00001429, CM
  // ___________________________________________________________________________
  /**
   * Reads plan item context description.
   *
   * @param key
   * Contains planned item id key.
   *
   * @return Plan Item Context Description details.
   */
  @Override
  public PlannedItemContextDescription getPlannedItemContextDescription(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // return value
    final PlannedItemContextDescription plannedItemContextDescription = new PlannedItemContextDescription();

    // Planned Item business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Planned Item entity object
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntityObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // read planned item participant and reference details
    final curam.serviceplans.sl.struct.PlanItemParticipantAndReferenceDetails piParticipantAndReferenceDetails = plannedItemObj.readParticipantTypeAndReferenceDetails(
      key.plannedItemIDKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_CONTEXT_DESCRIPTION);

    final curam.serviceplans.sl.struct.PlannedItemNameDetailsStruct plannedItemNameDetailsStruct = new curam.serviceplans.sl.struct.PlannedItemNameDetailsStruct();

    // Read plan item name
    plannedItemNameDetailsStruct.plannedItemNameDetailsStruct = plannedItemEntityObj.readName(
      key.plannedItemIDKey.plannedItemIDKey);

    piParticipantAndReferenceDetails.pItemNameDetailsStruct.plannedItemNameDetailsStruct.name = plannedItemNameDetailsStruct.plannedItemNameDetailsStruct.name;

    description.arg(
      piParticipantAndReferenceDetails.pItemNameDetailsStruct.plannedItemNameDetailsStruct.name);

    // add service plan reference
    description.arg(
      piParticipantAndReferenceDetails.caseReferenceCRNameAltNameIDDetails.caseReference);

    // add plan participant name
    description.arg(
      piParticipantAndReferenceDetails.caseReferenceCRNameAltNameIDDetails.concernRoleName);

    // add plan participant reference
    description.arg(
      piParticipantAndReferenceDetails.caseReferenceCRNameAltNameIDDetails.primaryAlternateID);

    // assign it to the return object
    plannedItemContextDescription.description = description.toClientFormattedText();

    // return service plan context description
    return plannedItemContextDescription;

  }

  // BEGIN, CR00047428, CSH
  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all service plan deliveries for a specified
   * concern role.
   *
   * @param key
   * The unique id for the concern role.
   *
   * @return The list of service plan delivery details for the concern.
   */
  @Override
  public ServicePlanConcernList listServicePlanDeliveryForConcern(
    RelationshipConcernRoleIDKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return struct
    final ServicePlanConcernList servicePlanConcernList = new ServicePlanConcernList();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00169613, VK
    // Participant business object
    final ParticipantContext participantContextObj = ParticipantContextFactory.newInstance();

    // BEGIN, CR00102618, CSH
    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // END, CR00102618

    // BEGIN, CR00049123, CSH
    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    // END, CR00049123

    // Context Description key
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Set the context key
    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    servicePlanConcernList.participantContextDescriptionDetails.description = participantContextObj.readContextDescription(participantContextDescriptionKey).description;
    // END CR00169613
    // Populate the return struct
    servicePlanConcernList.detailsList.list = servicePlanDeliveryObj.listServicePlanDeliveryForConcernRole(
      key);

    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kServicePlanDelivery_listForDuplicatePerson;
      origPageIdentifier.pageIdentifier = CuramConst.kServicePlanDelivery_listForPerson;

      // Build up the xml data needed for the tab widget
      servicePlanConcernList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      servicePlanConcernList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    return servicePlanConcernList;
    // END, CR00102618
  }

  // END, CR00047428

  // BEGIN, CR00051799, GBA
  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all service plans for which the current
   * user is the owner.
   *
   * @param key
   * The unique id for the current user.
   *
   * @return The list of service plans details for the current user.
   */
  @Override
  public ServicePlansForOwnerList listServicePlanDeliveryForOwner(
    ServicePlansByOwnerKey key) throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Create return struct
    final ServicePlansForOwnerList servicePlanOwnerList = new ServicePlansForOwnerList();

    // SystemUser manipulation variables
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Read the system user details
    systemUserDtls = systemUserObj.getUserDetails();

    // populate ownerID value of key
    key.servicePlanOwnerKey.servicePlanOwnerKey.ownerID = systemUserDtls.userName;

    // Populate the return struct
    servicePlanOwnerList.ServicePlansForOwnerList = servicePlanDeliveryObj.listServicePlanDeliveryForOwner(
      key.servicePlanOwnerKey);

    return servicePlanOwnerList;
  }

  // END, CR00051799

  // BEGIN, CR00053508, PMD
  // ___________________________________________________________________________
  /**
   * This method creates a milestone delivery for a service plan, plan group or
   * sub goal
   *
   * @param details
   * the service plan milestone delivery details
   */
  @Override
  public void addMilestone(SPMilestoneDeliveryDetails details)
    throws AppException, InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Create the milestone
    MilestoneFactory.newInstance().create(details.details);
  }

  // ___________________________________________________________________________
  /**
   * This method lists all milestones at service plan, plan group and sub goal
   * levels with a status of Not Started, In Progress and Completed.
   *
   * @param key
   * the unique identifier of the service plan
   *
   * @return the list of milestone deliveries for the specified service plan
   */
  @Override
  public MilestoneDeliveryDetailsList listAllMilestoneDeliveriesForServicePlan(CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return struct
    final MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = new MilestoneDeliveryDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Get the list of all milestone deliveries
    milestoneDeliveryDetailsList.dtlsList = MilestoneFactory.newInstance().listAllMilestoneDeliveriesForServicePlan(
      key);

    // BEGIN, CR00142331, SAI
    for (int i = 0; i
      < milestoneDeliveryDetailsList.dtlsList.spMilestoneDetailsList.dtlsList.dtls.size(); i++) {

      final MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

      milestoneDeliveryKey.milestoneDeliveryID = milestoneDeliveryDetailsList.dtlsList.spMilestoneDetailsList.dtlsList.dtls.item(i).milestoneDeliveryID;

      final CheckForWaiverIndicators checkForWaiverIndicators = readWaiverIndicatorDetails(
        milestoneDeliveryKey);

      milestoneDeliveryDetailsList.waiverIndList.addRef(
        checkForWaiverIndicators);
    }
    // END, CR00142331

    // Set the context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.caseID;
    milestoneDeliveryDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // BEGIN, CR00100255, MR
    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    milestoneDeliveryDetailsList.menuData.menuData = menuData.menuData;
    // END, CR00100255

    return milestoneDeliveryDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists all milestones that have been configured for the
   * specified service plan type
   *
   * @param key
   * the unique identifier of the service plan
   *
   * @return the list of milestones configured for the specified service plan
   */
  @Override
  public MilestoneConfigIDNameAndTypeList listMilestoneConfigsForServicePlanType(CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return Struct
    final MilestoneConfigIDNameAndTypeList milestoneConfigIDNameAndTypeList = new MilestoneConfigIDNameAndTypeList();

    // Get the list of available milestones
    milestoneConfigIDNameAndTypeList.dtlsList = MilestoneFactory.newInstance().listMilestoneConfigsForServicePlanType(
      key);

    // Obtain the informational(s) to be returned to the client
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      milestoneConfigIDNameAndTypeList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // Set the context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.caseID;
    milestoneConfigIDNameAndTypeList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return milestoneConfigIDNameAndTypeList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists milestones at service plan level with a status of Not
   * Started or In Progress.
   *
   * @param key
   * the unique identifier of the service plan
   *
   * @return the list of milestone deliveries
   */
  @Override
  public MilestoneDeliveryDetailsList listUncompletedMilestoneDeliveriesForServicePlan(CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return struct
    final MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = new MilestoneDeliveryDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Get the list of uncompleted milestone deliveries
    milestoneDeliveryDetailsList.dtlsList = MilestoneFactory.newInstance().listUncompletedMilestonesForServicePlan(
      key);

    // BEGIN, CR00142331, SAI
    for (int i = 0; i
      < milestoneDeliveryDetailsList.dtlsList.spMilestoneDetailsList.dtlsList.dtls.size(); i++) {

      final MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

      milestoneDeliveryKey.milestoneDeliveryID = milestoneDeliveryDetailsList.dtlsList.spMilestoneDetailsList.dtlsList.dtls.item(i).milestoneDeliveryID;

      final CheckForWaiverIndicators checkForWaiverIndicators = readWaiverIndicatorDetails(
        milestoneDeliveryKey);

      milestoneDeliveryDetailsList.waiverIndList.addRef(
        checkForWaiverIndicators);
    }
    // END, CR00142331

    // Set the context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.caseID;
    milestoneDeliveryDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // BEGIN, CR00100255, MR
    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    milestoneDeliveryDetailsList.menuData.menuData = menuData.menuData;
    // END, CR00100255

    return milestoneDeliveryDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to modify the service plan milestone delivery details
   *
   * @param details
   * The modified milestone delivery details.
   */
  @Override
  public void modifyMilestone(SPMilestoneDeliveryDetails details)
    throws AppException, InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Modify the milestone
    MilestoneFactory.newInstance().modify(details.details);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to read the service plan milestone delivery details.
   *
   * @param key
   * The unique identifier of the milestone delivery.
   *
   * @return The milestone delivery details.
   */
  @Override
  public ReadMilestoneDeliveryDetails readMilestone(MilestoneDeliveryKey key)
    throws AppException, InformationalException {

    // Return struct
    final ReadMilestoneDeliveryDetails readMilestoneDeliveryDetails = new ReadMilestoneDeliveryDetails();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final curam.serviceplans.sl.intf.Milestone milestoneObj = MilestoneFactory.newInstance();

    // Read the milestone delivery details
    readMilestoneDeliveryDetails.readDetails = milestoneObj.read(key);

    // BEGIN, CR00146068, SAI
    readMilestoneDeliveryDetails.waiverIndDtls = readWaiverIndicatorDetails(key);
    // END, CR00146068

    // BEGIN, CR00147167, SAI
    final curam.core.sl.entity.struct.MilestoneDeliveryKey milestoneDeliveryKey = new curam.core.sl.entity.struct.MilestoneDeliveryKey();

    milestoneDeliveryKey.milestoneDeliveryID = key.milestoneDeliveryID;

    final curam.core.sl.entity.intf.MilestoneDelivery milestoneDelivery = curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance();
    final curam.core.sl.entity.struct.MilestoneCreatedBySystem milestoneCreatedBySystem = milestoneDelivery.readCreatedBySystemInd(
      key);

    final curam.core.sl.intf.MilestoneLink milestoneLink = curam.core.sl.fact.MilestoneLinkFactory.newInstance();

    if (milestoneCreatedBySystem.createdBySystem) {

      readMilestoneDeliveryDetails.associatedDtls = milestoneLink.readMilestoneComponentDetails(
        readMilestoneDeliveryDetails.readDetails.readDetails);
    }
    // END, CR00147167

    // Set the context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = readMilestoneDeliveryDetails.readDetails.readDetails.readDetails.caseID;
    readMilestoneDeliveryDetails.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    return readMilestoneDeliveryDetails;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00146068, SAI
  /**
   * This method will set a boolean parameter to true only when the Expected
   * Time Frame indicator is set to true and if Waiver Required indicator is set
   * to false in Admin application for a milestone. Based on this boolean value
   * the user will be allowed to change the Expected Start and End Date at the
   * client side.
   *
   * @param This
   * key will provide the milestone configuration ID and this ID the
   * waiver details will fetched for a milestone from the table.
   *
   * @return CheckForExpectedTimeChange returns true when only Expected Time
   * Frame indicator is set to true in Admin for a milestone.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected CheckForWaiverIndicators readWaiverIndicatorDetails(
    MilestoneDeliveryKey key) throws AppException, InformationalException {

    // END, CR00198672
    final CheckForWaiverIndicators checkForWaiverIndicators = new CheckForWaiverIndicators();

    final curam.core.sl.intf.MilestoneDelivery milestoneDeliveryObj = curam.core.sl.fact.MilestoneDeliveryFactory.newInstance();

    final curam.core.facade.struct.ReadMilestoneDeliveryDetails readMilestoneDeliveryDetails = new curam.core.facade.struct.ReadMilestoneDeliveryDetails();

    readMilestoneDeliveryDetails.milestoneDetails = milestoneDeliveryObj.read(
      key);

    final curam.core.sl.entity.intf.MilestoneDelivery milestoneDelivery = curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance();
    final curam.core.sl.entity.struct.MilestoneCreatedBySystem milestoneCreatedBySystem = milestoneDelivery.readCreatedBySystemInd(
      key);

    final MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

    milestoneConfigurationKey.milestoneConfigurationID = readMilestoneDeliveryDetails.milestoneDetails.readDetails.milestoneConfigurationID;

    final MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    final WaiverIndicatorDetails waiverIndicatorDetails = milestoneConfigurationObj.readWaiverIndicatorsDetails(
      milestoneConfigurationKey);

    // BEGIN, CR00145948, SAI
    if (milestoneCreatedBySystem.createdBySystem == true) {
      // END, CR00145948

      if (waiverIndicatorDetails.expectedTimeFrameInd == true
        && waiverIndicatorDetails.waiverRequired == false) {
        checkForWaiverIndicators.expectedTimeFrameInd = true;
      }
      if (waiverIndicatorDetails.expectedTimeFrameInd == true
        && waiverIndicatorDetails.waiverRequired == true) {
        checkForWaiverIndicators.waiverLinkInd = true;
      }
    } else {
      checkForWaiverIndicators.expectedTimeFrameInd = true;
      checkForWaiverIndicators.waiverLinkInd = false;
    }
    return checkForWaiverIndicators;
  }

  // END, CR00146068

  // ___________________________________________________________________________
  /**
   * This method is used to remove a milestone delivery from a service plan.
   *
   * @param key
   * The unique identifier of the milestone delivery.
   */
  @Override
  public void removeMilestone(MilestoneDeliveryKey key) throws AppException,
      InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Remove the milestone delivery
    MilestoneFactory.newInstance().remove(key);
  }

  // BEGIN, CR00057481, PMD
  // ___________________________________________________________________________
  /**
   * Method to list all service plan level baseline milestones.
   *
   * @param key
   * the unique id of the baseline
   *
   * @return the list of baseline milestones
   */
  @Override
  public BaselineMilestoneListDetailsList listServicePlanLevelBaselineMilestones(BaselineKey key)
    throws AppException, InformationalException {

    // Return struct
    final BaselineMilestoneListDetailsList baselineMilestoneListDetailsList = new BaselineMilestoneListDetailsList();

    // List the baseline milestones
    baselineMilestoneListDetailsList.listDetails = BaselineFactory.newInstance().listServicePlanLevelBaselineMilestones(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    final BaselineNameDetails baselineNameDetails = BaselineFactory.newInstance().readBaselineName(
      key.key);

    // add baseline name
    description.arg(baselineNameDetails.baselineNameDtls.name);

    // assign it to the return object
    baselineMilestoneListDetailsList.description.description = description.toClientFormattedText();

    return baselineMilestoneListDetailsList;
  }

  // END, CR00057481
  // END, CR00053508

  // BEGIN, CR00091182, CM
  // ___________________________________________________________________________
  /**
   * Returns a sub-goal page depending on the amount of sub-goals created for
   * the selected type.
   *
   * @param subGoalType
   * The caseID and sub-goal type
   * @param parentGroupkey
   * The parentGroupID
   *
   * @return a planned sub-goal page
   */
  @Override
  public PageIdentifierDetails resolvePlannedSubGoal(
    PlannedSubGoalTypeCodeKey subGoalType, ParentGroupIDKey parentGroupkey)
    throws AppException, InformationalException {

    // Return struct
    final PageIdentifierDetails pageIdentifier = new PageIdentifierDetails();

    // PlannedSubGoalListByTypeDetailsList struct
    curam.serviceplans.sl.struct.PlannedSubGoalListByTypeDetailsList plannedSubGoalListByTypeDetailsList = new curam.serviceplans.sl.struct.PlannedSubGoalListByTypeDetailsList();

    // Planned Sub-Goal service layer object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // SubGoal structs
    final curam.serviceplans.sl.entity.struct.SubGoalKey subGoalKey = new curam.serviceplans.sl.entity.struct.SubGoalKey();
    final SubGoalNameDetails subGoalNameDetails = new SubGoalNameDetails();

    // get sub-goals of requested type
    plannedSubGoalListByTypeDetailsList = plannedSubGoalObj.select(
      subGoalType.plannedSubGoalTypeCodeKey,
      subGoalType.plannedSubGoalCaseIDKey);

    // BEGIN, CR00093416, CM
    // If there is no parentGroup set, this means that there is no
    // Planned Group created for the subGoal
    if (parentGroupkey.parentGroupID == 0) {

      // BEGIN, CR00092996, PMD
      if (plannedSubGoalListByTypeDetailsList.list.dtls.size() == 1) {

        // If there is only one sub-goal configured for this type,
        // there is no need to force the user to select the sub-goal,
        // send the user directly to the add sub-goal page
        // Set the typeCode and name
        subGoalKey.subGoalID = plannedSubGoalListByTypeDetailsList.list.dtls.item(0).subGoalID;
        subGoalNameDetails.name = plannedSubGoalListByTypeDetailsList.list.dtls.item(0).name;

        // Set pageIdentifier
        pageIdentifier.pageIdentifier = CuramConst.gkNewPlannedSubGoalPage
          + kPageCaseID + subGoalType.plannedSubGoalCaseIDKey.key.caseID
          + kSubGoalID + subGoalKey.subGoalID + kTypeCode
          + subGoalType.plannedSubGoalTypeCodeKey.typeCode + kSubGoalName
          + subGoalNameDetails.name;

      } else {

        // Force the user to select a sub-goal
        pageIdentifier.pageIdentifier = CuramConst.gkSelectNewPlannedSubGoalPage
          + kPageCaseID + subGoalType.plannedSubGoalCaseIDKey.key.caseID
          + kTypeCode + subGoalType.plannedSubGoalTypeCodeKey.typeCode;

      }
      // END, CR00092996
    } // There is a Planned Group created for the subGoal.
    else {

      if (plannedSubGoalListByTypeDetailsList.list.dtls.size() == 1) {

        // If there is only one sub-goal configured for this type,
        // there is no need to force the user to select the sub-goal,
        // send the user directly to the add sub-goal page
        // Set the typeCode and name
        subGoalKey.subGoalID = plannedSubGoalListByTypeDetailsList.list.dtls.item(0).subGoalID;
        subGoalNameDetails.name = plannedSubGoalListByTypeDetailsList.list.dtls.item(0).name;

        // Set pageIdentifier
        pageIdentifier.pageIdentifier = CuramConst.gkCreatePlannedSubGoalPage
          + kPageCaseID + subGoalType.plannedSubGoalCaseIDKey.key.caseID
          + kSubGoalID + subGoalKey.subGoalID + kTypeCode
          + subGoalType.plannedSubGoalTypeCodeKey.typeCode + kSubGoalName
          + subGoalNameDetails.name + kParentGroupID
          + parentGroupkey.parentGroupID;

      } else {

        // Force the user to select a sub-goal
        pageIdentifier.pageIdentifier = CuramConst.gkSelectPlannedSubGoalPage
          + kPageCaseID + subGoalType.plannedSubGoalCaseIDKey.key.caseID
          + kTypeCode + subGoalType.plannedSubGoalTypeCodeKey.typeCode
          + kParentGroupID + parentGroupkey.parentGroupID;

      }

    }
    // END, CR00093416

    return pageIdentifier;
  }

  // END, CR00091182

  // BEGIN, CR00099881, CSH
  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all service plan deliveries for a specified
   * duplicate concern role.
   *
   * @param key
   * The unique id for the duplicate concern role.
   *
   * @return The list of service plan delivery details for the duplicate
   * concern.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanConcernListForDuplicate listServicePlanDeliveryForDuplicateConcern(ConcernRoleKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return struct
    final ServicePlanConcernListForDuplicate servicePlanConcernListForDuplicate = new ServicePlanConcernListForDuplicate();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00169613, VK
    // ParticipantContext business object
    final ParticipantContext participantContextObj = ParticipantContextFactory.newInstance();

    // BEGIN, CR00102618, CSH
    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // END, CR00102618

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Set the Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // RelationshipConcernRole identifier
    final RelationshipConcernRoleIDKey relConcernRoleIDKey = new RelationshipConcernRoleIDKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // BEGIN, CR00102618, CSH
    // Get the context description for the original concern role
    servicePlanConcernListForDuplicate.dtlsList.participantContextDescriptionDetails.description = participantContextObj.readContextDescription(participantContextDescriptionKey).description;

    // Set the context description key to be the duplicate concern role ID
    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the original concern role
    servicePlanConcernListForDuplicate.duplicateContextDesc = participantContextObj.readContextDescription(
      participantContextDescriptionKey);
    // END CR00169613

    // Set the key for the service plan search
    relConcernRoleIDKey.concernRoleID = key.concernRoleID;

    // Populate the return struct
    servicePlanConcernListForDuplicate.dtlsList.detailsList.list = servicePlanDeliveryObj.listServicePlanDeliveryForConcernRole(
      relConcernRoleIDKey);

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kServicePlanDelivery_listForDuplicatePerson;
    origPageIdentifier.pageIdentifier = CuramConst.kServicePlanDelivery_listForPerson;

    // Build up the xml data needed for the tab widget
    servicePlanConcernListForDuplicate.dtlsList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    return servicePlanConcernListForDuplicate;
    // END, CR00102618
  }

  // END, CR00099881

  // ___________________________________________________________________________
  /**
   * Returns a Service Plan ID depending on the amount of sub-goals created for
   * the selected Service Plan type.
   *
   * @param Key
   * Contains Service Plan identifier
   *
   * @return a Service Plan ID
   */
  // BEGIN, CR00096264, SK
  @Override
  public servicePlanIDDetails getServicePlanID(ServicePlanKey Key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();
    final servicePlanIDDetails details = new servicePlanIDDetails();

    details.key = Key.servicePlanKey.key.servicePlanID;
    return details;
  }

  // END, CR00096264

  // BEGIN CR00104430, ELG

  // ___________________________________________________________________________
  /**
   * Checks is Service Plan Delivery contract printing SID authorized for
   * currently working user. The method is intended to use from the resolve
   * scripts only.
   *
   * @return Struct containing an indicator. Indicator is set to true if
   * currently working user has access to service plan delivery print
   * contract security identifier.
   */
  @Override
  public IndicatorStruct isPrintContractAuthorised() throws AppException,
      InformationalException {

    final SecurityIdentifier securityIdentifier = new SecurityIdentifier();

    securityIdentifier.sidName = kPrintContractSIDName;

    return isSIDAuthorised(securityIdentifier);

  }

  // ___________________________________________________________________________
  /**
   * Checks is SID authorized for currently working user. SID name is passed in
   * as a parameter.
   *
   * @param key
   * Contains security identifier name.
   * @return Struct containing an indicator. Indicator is set to true if
   * currently working user has access to security identifier specified.
   */
  @Override
  protected IndicatorStruct isSIDAuthorised(SecurityIdentifier key)
    throws AppException, InformationalException {

    // return structure
    final IndicatorStruct indicatorStruct = new IndicatorStruct();

    final String userName = curam.util.transaction.TransactionInfo.getProgramUser();

    indicatorStruct.indicator = curam.util.security.Authorisation.isSIDAuthorised(
      key.sidName, userName, false);

    return indicatorStruct;

  }

  // END, CR00104430

  // ___________________________________________________________________________
  /**
   * Method to remove the planned item attachment details
   *
   * @param plannedItemAttachmentLinkKey
   * Contains the Planned Item Attachment Link key.
   */
  @Override
  public void deleteAttachment(
    PlannedItemAttachmentLinkKey plannedItemAttachmentLinkKey)
    throws AppException, InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Getting the Planned Item Attachment Link Entity object
    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();
    // BEGIN, CR00131703, ANK
    // Deleting planned item attachment link details

    // Structs declaration
    final AttachmentKey attachmentKey = new AttachmentKey();

    final PlannedItemAttachmentLinkDtls plannedItemAttachmentLinkDtls = plannedItemAttachmentLinkObj.read(
      plannedItemAttachmentLinkKey);

    // BEGIN, CR00227859, PM
    // ServicePlanSecurity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey itemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    itemIDKey.plannedItemID = plannedItemAttachmentLinkDtls.plannedItemID;
    DataBasedSecurityResult dataBasedSecurityResult;

    try {
      // perform case security check
      caseSecurityCheckKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(itemIDKey).caseID;
      caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

      dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
        caseSecurityCheckKey);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
        } else {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }
    } catch (final RecordNotFoundException e) {// Do nothing
    }
    // END, CR00227859

    // Get the attachmentID to set the details as cancelled
    attachmentKey.attachmentID = plannedItemAttachmentLinkDtls.attachmentID;

    // Read the attachment Details and modify the same

    // Call the entity operation for modifying the attachment status
    // BEGIN, CR00146458, VR
    attachment.cancel(attachmentKey);
    // END, CR00146458
    // END, CR00131703
  }

  // ___________________________________________________________________________
  /**
   * Creating the Planned Item Attachment and the Planned Item Attachment Link
   * record
   *
   * @param plannedItemAttachmentDetails
   * Contains the Planned Item Attachment details to be created.
   */
  @Override
  public void createAttachment(
    PlannedItemAttachmentDetails plannedItemAttachmentDetails)
    throws AppException, InformationalException {

    // Creating Attachment details
    final AttachmentDtls attachmentDtls = new AttachmentDtls();

    // BEGIN, CR00227859, PM
    // ServicePlanSecurity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey itemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    itemIDKey.plannedItemID = plannedItemAttachmentDetails.plannedItemID;
    DataBasedSecurityResult dataBasedSecurityResult;

    try {
      // perform case security check
      caseSecurityCheckKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(itemIDKey).caseID;
      caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

      dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
        caseSecurityCheckKey);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(
            curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
        } else {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }

      // BEGIN, CR00354960, CD
      // populate meta data for the attachment
      GuiceWrapper.getInjector().injectMembers(this);
      final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      // BEGIN, CR00361162, CD
      cmsMetadata.add(CMSMetadataConst.kCaseID,
        Long.toString(caseSecurityCheckKey.caseID));
      // END, CR00361162
      // END, CR00354960

    } catch (final RecordNotFoundException e) {// Do nothing
    }
    // END, CR00227859

    // Getting the PlannedItem Attachment Link Entity object
    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();

    // Attachment Name Struct to parse and store the attachment name
    final AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();

    // Planned Item Attachment Link object
    final PlannedItemAttachmentLinkDtls plannedItemAttachmentLinkDtls = new PlannedItemAttachmentLinkDtls();

    // Attachment Assistant
    final MaintainAttachmentAssistant maintainAttachmentAssistantObj = MaintainAttachmentAssistantFactory.newInstance();

    // uniqueID entity to get Unique IDs for Planned Item Attachment Link ID
    // and for Attachment ID
    final curam.core.intf.UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // check the attachment name been provided or not
    final boolean attachmentNameProvided = plannedItemAttachmentDetails.attachmentName.length()
      != 0;

    final boolean locationANDReferenceProvided = plannedItemAttachmentDetails.fileLocation.length()
      != 0
        && plannedItemAttachmentDetails.fileReference.length() != 0;

    final boolean locationORReferenceProvided = plannedItemAttachmentDetails.fileLocation.length()
      != 0
        || plannedItemAttachmentDetails.fileReference.length() != 0;

    if (attachmentNameProvided && locationORReferenceProvided) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
    }

    if (!attachmentNameProvided && !locationANDReferenceProvided) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          5);
    }

    // based on domain CURAM_DATE
    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    if (plannedItemAttachmentDetails.receiptDate.after(currentDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_RECEIPTDATE_LATER_THAN_TODAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }
    // Check if the attachmentName is provided, else add other file details
    // to the attachment table
    if (attachmentNameProvided) {
      attachmentNameStruct.attachmentName = plannedItemAttachmentDetails.attachmentName;

      // parse attachmentName from path of attachment, leaving just
      // the base name
      maintainAttachmentAssistantObj.parseAttachmentFileName(
        attachmentNameStruct);

      if (attachmentNameStruct.attachmentName.length() == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_PLANNED_ITEM_ATTACHMENT_NAME_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // Assign the corresponding values with CANCELLED status
    attachmentDtls.assign(plannedItemAttachmentDetails);

    // create attachment details
    // Get the next Unique ID

    // BEGIN, CR00146458, VR
    // Store the parsed attachment name
    attachmentDtls.attachmentName = attachmentNameStruct.attachmentName;
    // inserting the attachment details
    attachment.insert(attachmentDtls);
    // END, CR00146458

    // Creating PlannedItem Attachment Link details
    // Get the next Unique ID
    plannedItemAttachmentLinkDtls.plannedItemAttachmentLinkID = uniqueIDObj.getNextID();
    plannedItemAttachmentLinkDtls.attachmentID = attachmentDtls.attachmentID;
    plannedItemAttachmentLinkDtls.plannedItemID = plannedItemAttachmentDetails.plannedItemID;
    plannedItemAttachmentLinkDtls.description = plannedItemAttachmentDetails.description;

    // Inserting the planned item attachment link entry
    plannedItemAttachmentLinkObj.insert(plannedItemAttachmentLinkDtls);

    // BEGIN, CR00115015, ANK
    // Set the Planned Item Attachment Link ID back to the input struct
    plannedItemAttachmentDetails.plannedItemAttachmentLinkID = plannedItemAttachmentLinkDtls.plannedItemAttachmentLinkID;
    // END, CR00115015
  }

  // ___________________________________________________________________________
  /**
   * Getting the List of Attachments for a given planned item id
   *
   * @param plannedItemKey
   * Contains the Planned Item ID for which the attachments will be
   * retrieved.
   * @return details Contains the List of Planned Item Attachment details
   */

  @Override
  public PlannedItemAttachmentsList listAttachments(
    PlannedItemKey plannedItemKey) throws AppException,
      InformationalException {

    // Facade layer Planned Item Attachments List struct
    final PlannedItemAttachmentsList plannedItemAttachmentsList = new PlannedItemAttachmentsList();

    // Entity layer Planned Item Attachments List struct
    PlannedItemAttachmentDetailsList plannedItemAttachmentDetailsList = new PlannedItemAttachmentDetailsList();

    // Getting the Planned Item Attachment Link Entity object
    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00131703, ANK
    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemKey.plannedItemID;

    try {
      plannedItemObj.readPlannedItemDetails(plannedItemIDKey.plannedItemIDKey);
    } catch (final RecordNotFoundException e) {
      throw new AppException(
        BPOBASELINE.BASELINE_PLAN_ITEM_RV_PLANNED_ITEM_DELETED);
    }
    // END, CR00131703

    // Searching the attachments for the given planned item
    plannedItemAttachmentDetailsList = plannedItemAttachmentLinkObj.searchAttachmentsForPlannedItem(
      plannedItemKey);

    // Assign the result to facade layer struct
    plannedItemAttachmentsList.attachmentsList = plannedItemAttachmentDetailsList;

    // Return the list of Attachments for the given planned item
    return plannedItemAttachmentsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the planned item attachment details
   *
   * @param plannedItemAttachmentDetails
   * Contains the planned item attachment to be modified.
   */
  @Override
  public void modifyAttachment(
    PlannedItemAttachmentDetails plannedItemAttachmentDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00227859, PM
    // ServicePlanSecurity manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey itemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    itemIDKey.plannedItemID = plannedItemAttachmentDetails.plannedItemID;
    DataBasedSecurityResult dataBasedSecurityResult;

    try {
      // perform case security check
      caseSecurityCheckKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(itemIDKey).caseID;
      caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

      dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
        caseSecurityCheckKey);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(
            curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
        } else {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }
    } catch (final RecordNotFoundException e) {// Do nothing
    }
    // END, CR00227859

    // Creating Attachment key and details
    AttachmentDtls attachmentDtls = new AttachmentDtls();

    final AttachmentKey attachmentKey = new AttachmentKey();

    attachmentKey.attachmentID = plannedItemAttachmentDetails.attachmentID;

    // BEGIN, CR00155031, MC
    final String statusCode = attachment.read(attachmentKey).statusCode;
    // END, CR00155031

    // Creating Planned Item Attachment Link key
    final PlannedItemAttachmentLinkKey plannedItemAttachmentLinkKey = new PlannedItemAttachmentLinkKey();

    // Creating the Planned Item Attachment Link details
    final PlannedItemAttachmentLinkDtls plannedItemAttachmentLinkDtls = new PlannedItemAttachmentLinkDtls();

    // Attachment Name Struct to parse and store the attachment name
    final AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();

    // Attachment Assistant class to parse the attachment name
    final MaintainAttachmentAssistant maintainAttachmentAssistantObj = MaintainAttachmentAssistantFactory.newInstance();

    // Getting the Planned Item Attachment Link Entity object
    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // check to see if it has been canceled already
    // BEGIN, CR00155031, MC
    if (statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 79);
    }

    // Modify the attachment details
    if (plannedItemAttachmentDetails.attachmentContents.length() > 0) {

      // check attachmentName
      final boolean attachmentNameProvided = plannedItemAttachmentDetails.attachmentName.length()
        != 0;

      final boolean locationANDReferenceProvided = plannedItemAttachmentDetails.fileLocation.length()
        != 0
          && plannedItemAttachmentDetails.fileReference.length() != 0;

      final boolean locationORReferenceProvided = plannedItemAttachmentDetails.fileLocation.length()
        != 0
          || plannedItemAttachmentDetails.fileReference.length() != 0;

      if (attachmentNameProvided && locationORReferenceProvided) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            5);
      }

      if (!attachmentNameProvided && !locationANDReferenceProvided) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            4);
      }

      // Check if the attachmentName is provided, else add other file
      // details to the attachment table
      if (attachmentNameProvided) {
        attachmentNameStruct.attachmentName = plannedItemAttachmentDetails.attachmentName;

        // parse attachmentName from path of attachment, to get the
        // base file name
        maintainAttachmentAssistantObj.parseAttachmentFileName(
          attachmentNameStruct);

        if (attachmentNameStruct.attachmentName.length() == 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_PLANNED_ITEM_ATTACHMENT_NAME_EMPTY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }
      }
      plannedItemAttachmentDetails.attachmentName = attachmentNameStruct.attachmentName;
    } else {
      // BEGIN, CR00161481, ZV
      attachmentDtls = attachment.read(attachmentKey);
      // END, CR00161481

      plannedItemAttachmentDetails.attachmentName = attachmentDtls.attachmentName;
      plannedItemAttachmentDetails.attachmentContents = attachmentDtls.attachmentContents;
    }

    // Check if the receipt Date is greater than current Date
    if (plannedItemAttachmentDetails.receiptDate.after(Date.getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_RECEIPT_DATE_LATER_THAN_CURRENT_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // populating the attachment details
    plannedItemAttachmentDetails.attachmentStatus = ATTACHMENTSTATUS.ACTIVE;
    attachmentDtls.assign(plannedItemAttachmentDetails);

    // BEGIN, CR00365030, CD
    // populate meta data for the attachment
    GuiceWrapper.getInjector().injectMembers(this);
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID,
      Long.toString(caseSecurityCheckKey.caseID));
    // END, CR00365030

    // Modify the attachment details
    // BEGIN, CR00146458, VR
    attachment.modify(attachmentKey, attachmentDtls);
    // END, CR00146458

    // Modify the Planned Item Attachment Link details
    plannedItemAttachmentLinkKey.plannedItemAttachmentLinkID = plannedItemAttachmentDetails.plannedItemAttachmentLinkID;

    // Details to be modified
    plannedItemAttachmentLinkDtls.attachmentID = plannedItemAttachmentDetails.attachmentID;
    plannedItemAttachmentLinkDtls.plannedItemID = plannedItemAttachmentDetails.plannedItemID;
    plannedItemAttachmentLinkDtls.plannedItemAttachmentLinkID = plannedItemAttachmentDetails.plannedItemAttachmentLinkID;
    plannedItemAttachmentLinkDtls.description = plannedItemAttachmentDetails.description;

    // Modify the Planned Item Attachment Link details
    plannedItemAttachmentLinkObj.modify(plannedItemAttachmentLinkKey,
      plannedItemAttachmentLinkDtls);

  }

  // ___________________________________________________________________________
  /**
   * Reading the Attachment details based on the Planned Item Attachment Link ID
   *
   * @param plannedItemAttachmentLinkKey
   * Contains the Planned Item Attachment Link ID to be read.
   * @return details Contains the Planned Item Attachment details
   */
  @Override
  public PlannedItemAttachmentDetails viewAttachment(
    PlannedItemAttachmentLinkKey plannedItemAttachmentLinkKey)
    throws AppException, InformationalException {

    // Creating Attachment key and details
    final AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls = new AttachmentDtls();

    // Creating Planned Item Attachment Link and details
    PlannedItemAttachmentLinkDtls plannedItemAttachmentLinkDtls = new PlannedItemAttachmentLinkDtls();
    final PlannedItemAttachmentDetails plannedItemAttachmentDetails = new PlannedItemAttachmentDetails();

    // Getting the Planned Item Attachment Link Entity object
    final PlannedItemAttachmentLink plannedItemAttachmentLinkObj = PlannedItemAttachmentLinkFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Read the planned item link details to get the corresponding attachment id
    plannedItemAttachmentLinkDtls = plannedItemAttachmentLinkObj.read(
      plannedItemAttachmentLinkKey);

    attachmentKey.attachmentID = plannedItemAttachmentLinkDtls.attachmentID;
    // BEGIN, CR00146458, VR
    // Reading the Attachment details
    attachmentDtls = attachment.read(attachmentKey);
    // END, CR00146458

    // Assign the result to Facade level struct
    plannedItemAttachmentDetails.assign(attachmentDtls);

    plannedItemAttachmentDetails.description = plannedItemAttachmentLinkDtls.description;
    plannedItemAttachmentDetails.attachmentID = plannedItemAttachmentLinkDtls.attachmentID;
    plannedItemAttachmentDetails.plannedItemID = plannedItemAttachmentLinkDtls.plannedItemID;
    plannedItemAttachmentDetails.plannedItemAttachmentLinkID = plannedItemAttachmentLinkDtls.plannedItemAttachmentLinkID;
    // Return the attachment details
    return plannedItemAttachmentDetails;
  }

  // BEGIN, CR00114509, PMD
  // ___________________________________________________________________________
  /**
   * Method to return the planned item id passed in and its name
   *
   * @param key
   * planned item id
   * @return planned item id and name
   */

  @Override
  public PlannedItemIDAndNameDetails getPlannedItemIDAndName(
    PlannedItemIDKey key) throws AppException, InformationalException {

    final PlannedItemIDAndNameDetails plannedItemIDAndNameDetails = new PlannedItemIDAndNameDetails();

    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    plannedItemIDAndNameDetails.name = plannedItemObj.readName(key.plannedItemIDKey.plannedItemIDKey).name;
    plannedItemIDAndNameDetails.plannedItemID = key.plannedItemIDKey.plannedItemIDKey.plannedItemID;

    return plannedItemIDAndNameDetails;
  }

  // END, CR00114509

  // BEGIN, CR00114740, CSH
  // ___________________________________________________________________________
  /**
   * This method cancels the specified absence record.
   *
   * @param key
   * - The planned item and absence identifiers.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelPlanItemAbsence(PlannedItemAbsenceIDKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Cancel the absence
    absenceObj.cancelPlanItemAbsence(key.key);
  }

  // ___________________________________________________________________________
  /**
   * This method creates an absence record and a link record that contains the
   * association between the absence and the planned item.
   *
   * @param details
   * - The absence and planned item details to be inserted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createAbsenceForPlanItem(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    absenceObj.createPlanItemAbsence(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * This method lists the absence records associated with the specified planned
   * item.
   *
   * @param key
   * - The planned item identifier.
   *
   * @return the list of absences for the planned item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlannedItemAbsenceDetailsList listAbsenceForPlanItem(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();
    final PlannedItemAbsenceDetailsList plannedItemAbsenceDetailsList = new PlannedItemAbsenceDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Retrieve the planned item absence list
    plannedItemAbsenceDetailsList.list = absenceObj.listPlanItemAbsence(
      key.plannedItemIDKey);

    return plannedItemAbsenceDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method modifies the specified absence record.
   *
   * @param details
   * - The absence modification details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyAbsenceForPlanItem(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Modify the absence record
    absenceObj.modifyPlanItemAbsence(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * This method reads the specified absence record details.
   *
   * @param key
   * - The planned item and absence identifiers.
   *
   * @return the absence record details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlannedItemAbsenceDetails readAbsenceForPlanItem(
    PlannedItemAbsenceIDKey key) throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();
    final PlannedItemAbsenceDetails plannedItemAbsenceDetails = new PlannedItemAbsenceDetails();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Retrieve the planned item absence list
    plannedItemAbsenceDetails.dtls = absenceObj.readPlanItemAbsence(key.key);

    return plannedItemAbsenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method lists the absence records associated with the specified service
   * plan delivery.
   *
   * @param key
   * - The service plan delivery identifier.
   *
   * @return the list of absences for the service plan.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanAbsenceDetailsList listAbsenceForServicePlan(
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Absence manipulation variables
    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();
    final ServicePlanAbsenceDetailsList servicePlanAbsenceDetailsList = new ServicePlanAbsenceDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00127318, CSH
    // Retrieve the service plan delivery absence list
    servicePlanAbsenceDetailsList.list = absenceObj.listServicePlanAbsence(key);
    // END, CR00127318

    // Set the context description
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key = key;

    servicePlanAbsenceDetailsList.description = getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // Set the menu data
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.caseID;

    // Read the menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanAbsenceDetailsList.menuData.menuData = menuData.menuData;

    return servicePlanAbsenceDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists the plan items associated with the specified service plan
   * delivery.
   *
   * @param key
   * - The service plan delivery identifier.
   *
   * @return the list of planned items for the service plan.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlannedItemIDAndNameDetailsList listPlanItemsForServicePlan(
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Plan Item Absence manipulation variables
    final curam.serviceplans.sl.intf.Absence absenceObj = curam.serviceplans.sl.fact.AbsenceFactory.newInstance();
    final PlannedItemIDAndNameDetailsList plannedItemIDAndNameDetailsList = new PlannedItemIDAndNameDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Retrieve the service plan delivery plan item list
    plannedItemIDAndNameDetailsList.list = absenceObj.listServicePlanPlanItems(
      key);

    return plannedItemIDAndNameDetailsList;
  }

  // END, CR00114740

  // BEGIN, CR00117766, ANK
  // ___________________________________________________________________________
  /**
   * This method to read the baseline planned item details of the given
   * baseline.
   *
   * @param baselinePlanItemKey
   * - The plan item key of the given base line.
   *
   * @return BaselinePlannedItemDetails - Planned Item details of the given
   * baseline.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ViewBaselinePlannedItemDetails viewServicePlanBaselinePlannedItemDetails(
    BaselinePlanItemKey baselinePlanItemKey) throws AppException,
      InformationalException {

    // Manipulation Variables
    final ViewBaselinePlannedItemDetails viewBaselinePlannedItemDetails = new ViewBaselinePlannedItemDetails();
    // BEGIN CR00130620, GBA
    final Baseline baselineObj = BaselineFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Read Baseline planned item details
    viewBaselinePlannedItemDetails.baselinePlannedItemDetails = baselineObj.viewBaselinePlannedItemDetails(
      baselinePlanItemKey);
    // END CR00130620
    return viewBaselinePlannedItemDetails;
  }

  // END, CR00117766

  /**
   * This method is used to return the list of plan participants for whom the
   * contract is not currently issued to.
   *
   * @param key
   * - ContractParticipantKey containing the current user for whom the
   * contract is issued to and the case id
   *
   * @return PlanParticipantList
   * @throws AppException
   * , InformationalException
   */

  // BEGIN, CR00124499, MC
  @Override
  public PlanParticipantList listPlanParticipantsForContract(
    ContractParticipantKey key) throws AppException, InformationalException {

    // register service plan security
    ServicePlanSecurityImplementationFactory.register();

    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = key.caseID;

    // BEGIN, CR00146503, GBA
    final PlanParticipantList planParticipantList = new PlanParticipantList();

    final curam.serviceplans.sl.struct.ServicePlanParticipantDetailsList servicePlanParticipantDetailsList = listPlanParticipants(servicePlanDeliveryKey).servicePlanParticipantDetailsList;

    curam.serviceplans.sl.entity.struct.ServicePlanParticipantDetails servicePlanParticipantDetails = new curam.serviceplans.sl.entity.struct.ServicePlanParticipantDetails();

    // filter the list : Primary plan participant, plan participants and
    // nominated representatives should appear in the Issue To field when first
    // creating the contract and appear in the signatories cluster
    for (int i = 0; i
      < servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.size(); i++) {

      servicePlanParticipantDetails = servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.item(
        i);

      if (RECORDSTATUS.NORMAL.equals(servicePlanParticipantDetails.recordStatus)) {
        if (CASEPARTICIPANTROLETYPE.PRIMARYPLANPARTICIPANT.equals(
          servicePlanParticipantDetails.typeCode)
            || CASEPARTICIPANTROLETYPE.PLANPARTICIPANT.equals(
              servicePlanParticipantDetails.typeCode)
              || CASEPARTICIPANTROLETYPE.NOMINATEDREPRESENTATIVE.equals(
                servicePlanParticipantDetails.typeCode)) {

          planParticipantList.servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.add(
            servicePlanParticipantDetails);
        }
      }

    }

    final int noOfParticipants = planParticipantList.servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.size();
    int issueToPosition = -1;

    for (int i = 0; i < noOfParticipants; i++) {
      if (planParticipantList.servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.item(i).participantRoleID
        == key.issueToID) {
        issueToPosition = i;
        break;
      }
    }
    // END, CR00146503
    if (issueToPosition > -1) {
      planParticipantList.servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.remove(
        issueToPosition);
    }

    // BEGIN, CR00125260, ANK
    if (noOfParticipants > 1) {
      planParticipantList.havingMultiplePlanParticipants = true;
    }
    // END, CR00125260
    return planParticipantList;
  }

  // END, CR00124499

  // BEGIN, CR00139526, GBA
  // ___________________________________________________________________________

  // BEGIN, CR00246925, MR
  /**
   * Helper method to add an exception to the Informational Manager.
   *
   * @param e Generic Exception Signature.
   *
   * @return List of Informational Messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationMsgDtlsList addExceptionToInformational(
    final AppException e) throws AppException, InformationalException {

    // END, CR00246925
    // Create informational message list
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager.addInformationalMsg(e, CuramConst.gkEmpty,
      InformationalElement.InformationalType.kWarning);

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00139526

  // BEGIN, CR00142331, SAI
  // ___________________________________________________________________________
  /**
   * This method is used to modify the service plan milestone delivery details
   *
   * @param details
   * The modified milestone delivery details.
   */
  @Override
  public void modifyMilestoneForWaiver(SPMilestoneDeliveryDetails details)
    throws AppException, InformationalException {

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Modify the milestone
    MilestoneFactory.newInstance().modify(details.details);

  }

  // END, CR00142331

  // BEGIN, CR00161962, LJ
  /**
   * This method is used to return the list of approval criteria for the planned
   * item
   *
   * @param key
   * PlannedItemIDKey containing the current planned item id for which
   * the list of approval criteria should be retrieved
   *
   * @return List of planned item approval criteria.
   * @throws AppException
   * , InformationalException
   */
  @Override
  public PlannedItemApprovalCriteriaLinkDetailsList getListOfApprovalCriteriaForPlannedItem(
    curam.serviceplans.facade.struct.PlannedItemIDKey key)
    throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    final curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey = key.plannedItemIDKey.plannedItemIDKey;

    return servicePlanDeliveryObj.getListOfApprovalCriteriaForPlannedItem(
      plannedItemIDKey);

  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Views the Tracking Gantt information for a Service Plan Group Delivery.
   *
   * @param servicePlanGroupDeliveryKey
   * Contains the Service Plan Group Delivery ID.
   *
   * @return XML String containing the Service Plan Group Delivery Gantt chart.
   * @throws AppException
   * , InformationalException
   */
  // BEGIN, CR00229255 MN
  @Override
  public ServicePlanTrackingGanttDetails viewGroupTrackingGantt(
    ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey)
    throws AppException, InformationalException {

    // END, CR00229225

    ServicePlanSecurityImplementationFactory.register();

    final TrackingGantt trackingGanttObj = TrackingGanttFactory.newInstance();

    // BEGIN, CR00229255 MN
    final ServicePlanTrackingGanttDetails trackingGanttDetails = new ServicePlanTrackingGanttDetails();
    // END, CR00229225

    final TrackingGanttGroupKey trackingGanttGroupKey = new TrackingGanttGroupKey();

    trackingGanttGroupKey.groupDeliveryID = servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID;

    trackingGanttDetails.trackGanttDetails = trackingGanttObj.viewGroupTrackingGantt(
      trackingGanttGroupKey);

    trackingGanttDetails.description = getServicePlanGroupContextDescription(
      servicePlanGroupDeliveryKey);

    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanGroupMenuData(
      servicePlanGroupDeliveryKey);

    trackingGanttDetails.menuData.menuData = menuData.menuData;

    return trackingGanttDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Views the Tracking Gantt information for the Integrated Service Plan.
   *
   * @param integratedServicePlanKey
   * Contains the Integrated Service Plan ID.
   *
   * @return XML String containing the Integrated Service Plan Gantt chart.
   * @throws AppException
   * , InformationalException
   */
  // BEGIN, CR00229255 MN
  @Override
  public ServicePlanTrackingGanttDetails viewIntegratedTrackingGantt(
    IntegratedServicePlanKey integratedServicePlanKey) throws AppException,
      InformationalException {

    // END, CR00229225
    ServicePlanSecurityImplementationFactory.register();

    final TrackingGantt trackingGanttObj = TrackingGanttFactory.newInstance();

    // BEGIN, CR00229255 MN
    final ServicePlanTrackingGanttDetails trackingGanttDetails = new ServicePlanTrackingGanttDetails();
    // END, CR00229225

    final TrackingGanttIntegratedKey trackingGanttIntegratedKey = new TrackingGanttIntegratedKey();

    trackingGanttIntegratedKey.integratedCaseID = integratedServicePlanKey.integratedCaseID;

    trackingGanttDetails.trackGanttDetails = trackingGanttObj.viewIntegratedTrackingGantt(
      trackingGanttIntegratedKey);

    trackingGanttDetails.description = getIntegratedServicePlanContextDescription(
      integratedServicePlanKey);

    final ICServicePlanDeliveryMenuDataDetails menuData = getICIntegratedServicePlanMenuData(
      integratedServicePlanKey);

    trackingGanttDetails.menuData.menuData = menuData.menuData;

    return trackingGanttDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Shows the Service Plan Group Delivery statement.
   *
   * @param servicePlanGroupDeliveryKey
   * Contains the Service Plan Group Delivery ID.
   *
   * @return XML String containing the Service Plan Group Delivery statement.
   * @throws AppException
   * , InformationalException
   */
  // BEGIN, CR00229255 MN

  @Override
  public SPStatementXMLString showServicePlanGroupStatement(
    ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey)
    throws AppException, InformationalException {

    // END, CR00229225

    final ServicePlanStatementGroupKey servicePlanStatementGroupKey = new ServicePlanStatementGroupKey();

    servicePlanStatementGroupKey.groupDeliveryID = servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID;

    // BEGIN, CR00229255 MN
    final SPStatementXMLString servicePlanStatementXMLString = new SPStatementXMLString();
    // END, CR00229225

    // BEGIN, CR00246725, MR
    final ServicePlanStatement servicePlanStatementObj = ServicePlanStatementFactory.newInstance();

    servicePlanStatementXMLString.servicePlanStatementXMLString = servicePlanStatementObj.showGroupStatement(
      servicePlanStatementGroupKey);
    // END, CR00246725
    servicePlanStatementXMLString.description = getServicePlanGroupContextDescription(
      servicePlanGroupDeliveryKey);

    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanGroupMenuData(
      servicePlanGroupDeliveryKey);

    servicePlanStatementXMLString.menuData.menuData = menuData.menuData;

    return servicePlanStatementXMLString;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Shows the Integrated Service Plan statement.
   *
   * @param integratedServicePlanKey
   * Contains the Integrated Service Plan ID.
   *
   * @return XML String containing the Integrated Service Plan statement.
   * @throws AppException
   * , InformationalException
   */
  // BEGIN, CR00229255 MN
  @Override
  public SPStatementXMLString showIntegratedServicePlanStatement(
    IntegratedServicePlanKey integratedServicePlanKey) throws AppException,
      InformationalException {

    // END, CR00229225

    final ServicePlanStatement servicePlanStatementObj = ServicePlanStatementFactory.newInstance();

    final ServicePlanStatementIntegratedKey servicePlanStatementIntegratedKey = new ServicePlanStatementIntegratedKey();

    servicePlanStatementIntegratedKey.integratedCaseID = integratedServicePlanKey.integratedCaseID;

    // BEGIN, CR00229255 MN
    final SPStatementXMLString servicePlanStatementXMLString = new SPStatementXMLString();

    // END, CR00229225

    servicePlanStatementXMLString.servicePlanStatementXMLString = servicePlanStatementObj.showIntegratedStatement(
      servicePlanStatementIntegratedKey);

    servicePlanStatementXMLString.description = getIntegratedServicePlanContextDescription(
      integratedServicePlanKey);

    final ICServicePlanDeliveryMenuDataDetails menuData = getICIntegratedServicePlanMenuData(
      integratedServicePlanKey);

    servicePlanStatementXMLString.menuData.menuData = menuData.menuData;

    return servicePlanStatementXMLString;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Reads the Integrated Service Plan menu data.
   *
   * @param integratedServicePlanKey
   * Contains the Integrated Service Plan ID.
   *
   * @return Integrated Service Plan menu data.
   * @throws AppException
   * , InformationalException
   */
  @Override
  public ICServicePlanDeliveryMenuDataDetails getICIntegratedServicePlanMenuData(
    IntegratedServicePlanKey integratedServicePlanKey) throws AppException,
      InformationalException {

    // Read integrated case page details
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = integratedServicePlanKey.integratedCaseID;

    final ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    // Read integrated case reference
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = integratedServicePlanKey.integratedCaseID;

    final CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
      caseSearchKey);

    // Read participant role id details
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();

    caseIDParticipantRoleKey.caseID = integratedServicePlanKey.integratedCaseID;
    caseIDParticipantRoleKey.participantRoleID = icPageNamesICTypeAndConcernDetails.concernRoleID;

    final CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // Read participant home page details
    final curam.core.facade.intf.IntegratedCase integratedCaseObj = curam.core.facade.fact.IntegratedCaseFactory.newInstance();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    caseParticipantRoleIDKey.caseParticipantRoleID = caseParticipantRoleID.caseParticipantRoleID;

    final ParticipantHomePageName participantHomePageName = integratedCaseObj.resolveParticipantHome(
      caseParticipantRoleIDKey);

    // Create description
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDSERVICEPLAN.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // Set IC type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    // Set IC case reference
    description.arg(caseReference.caseReference);

    // ROOT ELEMENT

    // Create root element
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // INTEGRATED CASE LINK ELEMENT

    // Create link element
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // Create case id parameter element
    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedServicePlanKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // PARTICIPANT LINK ELEMENT

    // Create participant parameter element
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOINTEGRATEDSERVICEPLAN.INF_MENU_PARTICIPANT_DESCRIPTION);

    description.arg(icPageNamesICTypeAndConcernDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(caseParticipantRoleID.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedServicePlanKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // INTEGRATED SERVICE PLAN LINK ELEMENT

    // Create service plan group delivery link element
    linkElement = new Element(kItem);
    linkElement.setAttribute(kPageID, kIntegratedServicePlanHome);

    description = new LocalisableString(
      BPOINTEGRATEDSERVICEPLAN.INF_MENU_INTEGRATED_SERVICE_PLAN_DESCRIPTION);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedServicePlanKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // XML OUTPUT

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    final ICServicePlanDeliveryMenuDataDetails icServicePlanDeliveryMenuDataDetails = new ICServicePlanDeliveryMenuDataDetails();

    icServicePlanDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // return menu data
    return icServicePlanDeliveryMenuDataDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Reads the Service Plan Group menu data.
   *
   * @param servicePlanGroupDeliveryKey
   * Contains the Service Plan Group Delivery ID.
   *
   * @return Service Plan Group Delivery menu data.
   * @throws AppException
   * , InformationalException
   */
  @Override
  public ICServicePlanDeliveryMenuDataDetails getICServicePlanGroupMenuData(
    ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey)
    throws AppException, InformationalException {

    // Read service plan group delivery details
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    final SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

    spgDeliveryKey.servicePlanGroupDeliveryId = servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID;

    final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryObj.read(spgDeliveryKey);

    // Read integrated case page details
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = spgDeliveryDtls.integratedCaseID;

    final ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    // Read integrated case reference
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = spgDeliveryDtls.integratedCaseID;

    final CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
      caseSearchKey);

    // Read participant role id details
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();

    caseIDParticipantRoleKey.caseID = spgDeliveryDtls.integratedCaseID;
    caseIDParticipantRoleKey.participantRoleID = icPageNamesICTypeAndConcernDetails.concernRoleID;

    final CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // Read participant home page details
    final IntegratedCase integratedCaseObj = IntegratedCaseFactory.newInstance();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    caseParticipantRoleIDKey.caseParticipantRoleID = caseParticipantRoleID.caseParticipantRoleID;

    final ParticipantHomePageName participantHomePageName = integratedCaseObj.resolveParticipantHome(
      caseParticipantRoleIDKey);

    // Create description
    LocalisableString description = new LocalisableString(
      BPOSERVICEPLANGROUPDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // Set IC type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    // Set IC case reference
    description.arg(caseReference.caseReference);

    // ROOT ELEMENT

    // Create root element
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // INTEGRATED SERVICE PLAN LINK ELEMENT

    // Create service plan group delivery link element
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID, kIntegratedServicePlanHome);

    description = new LocalisableString(
      BPOINTEGRATEDSERVICEPLAN.INF_MENU_INTEGRATED_SERVICE_PLAN_DESCRIPTION);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(spgDeliveryDtls.integratedCaseID));

    linkElement.addContent(paramElement);

    // PARTICIPANT LINK ELEMENT

    // Create participant parameter element
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOSERVICEPLANGROUPDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    description.arg(icPageNamesICTypeAndConcernDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(caseParticipantRoleID.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(spgDeliveryDtls.integratedCaseID));

    linkElement.addContent(paramElement);

    // SERVICE PLAN GROUP DELIVERY LINK ELEMENT

    // Create service plan group delivery link element
    linkElement = new Element(kItem);
    linkElement.setAttribute(kPageID, kServicePlanGroupDeliveryHome);

    description = new LocalisableString(
      BPOSERVICEPLANGROUPDELIVERY.INF_MENU_SERVICE_PLAN_GROUP_DESCRIPTION);

    // append the SPGD reference to the description
    description.arg(spgDeliveryDtls.spgdReference);

    // Add activeInd value to linkElement
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kActiveInd);
    paramElement.setAttribute(kValue, kActiveIndFalse);
    linkElement.addContent(paramElement);

    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    paramElement = new Element(kParam);

    paramElement.setAttribute(kName,
      XmlMetaDataConst.kServicePlanGroupDeliveryId);
    paramElement.setAttribute(kValue,
      String.valueOf(spgDeliveryDtls.servicePlanGroupDeliveryId));

    linkElement.addContent(paramElement);

    // XML OUTPUT

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    final ICServicePlanDeliveryMenuDataDetails icServicePlanDeliveryMenuDataDetails = new ICServicePlanDeliveryMenuDataDetails();

    icServicePlanDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // return menu data
    return icServicePlanDeliveryMenuDataDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Reads the Integrated Service Plan context description.
   *
   * @param integratedServicePlanKey
   * Contains the integrated service plan ID.
   *
   * @return Integrated Service Plan Context Description details.
   * @throws AppException
   * , InformationalException
   */
  @Override
  public SPDeliveryContextDescription getIntegratedServicePlanContextDescription(
    IntegratedServicePlanKey integratedServicePlanKey) throws AppException,
      InformationalException {

    // Read the concern details based on the integrated case id
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = integratedServicePlanKey.integratedCaseID;

    final CaseReferenceCRNameAltIDDetails caseReferenceCRNameAltIDDetails = caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(
      caseKey);

    // Create the context description
    final LocalisableString description = new LocalisableString(
      BPOINTEGRATEDSERVICEPLAN.INF_CONTEXT_DESCRIPTION);

    // Add concern name
    description.arg(caseReferenceCRNameAltIDDetails.concernRoleName);

    // Add concern reference
    description.arg(caseReferenceCRNameAltIDDetails.primaryAlternateID);

    // Create return object
    final SPDeliveryContextDescription spDeliveryContextDescription = new SPDeliveryContextDescription();

    spDeliveryContextDescription.description = description.toClientFormattedText();

    return spDeliveryContextDescription;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Reads the Service Plan Group context description.
   *
   * @param servicePlanGroupDeliveryKey
   * Contains the Service Plan Group Delivery ID.
   *
   * @return Service Plan Group Context Description details.
   * @throws AppException
   * , InformationalException
   */
  @Override
  public SPDeliveryContextDescription getServicePlanGroupContextDescription(
    ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey)
    throws AppException, InformationalException {

    // ------------------------------------------------------------------------

    // Read the service plan group delivery details
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    final SPGDeliveryKey spgdeliverykey = new SPGDeliveryKey();

    spgdeliverykey.servicePlanGroupDeliveryId = servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID;

    final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryObj.read(spgdeliverykey);

    // Read the service plan group details
    final curam.serviceplans.sl.entity.intf.ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = spgDeliveryDtls.servicePlanGroupId;

    final ServicePlanGroupDtls servicePlanGroupDtls = servicePlanGroupObj.read(
      servicePlanGroupKey);

    // Read the concern details based on the integrated case id
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = spgDeliveryDtls.integratedCaseID;

    final CaseReferenceCRNameAltIDDetails caseReferenceCRNameAltIDDetails = caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(
      caseKey);

    // ------------------------------------------------------------------------

    // Create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANGROUPDELIVERY.INF_CONTEXT_DESCRIPTION);

    // Add service plan group name
    description.arg(
      new CodeTableItemIdentifier(SERVICEPLANGROUPNAME.TABLENAME,
      servicePlanGroupDtls.servicePlanGroupName));

    // Add Service Plan Group Delivery reference
    description.arg(spgDeliveryDtls.spgdReference);

    // Add concern name
    description.arg(caseReferenceCRNameAltIDDetails.concernRoleName);

    // Add concern reference
    description.arg(caseReferenceCRNameAltIDDetails.primaryAlternateID);

    // Create return object
    final SPDeliveryContextDescription spDeliveryContextDescription = new SPDeliveryContextDescription();

    spDeliveryContextDescription.description = description.toClientFormattedText();

    return spDeliveryContextDescription;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * creates a new Service Plan Delivery record linked to the Service Plan Group
   * Delivery
   *
   * @param spdAndGrpDtls
   * the Service Plan Delivery details and Service Plan Group Delivery
   * details
   * @return The id of the new Service Plan Delivery
   * @throws AppException
   * , InformationalException
   */
  @Override
  public ServicePlanDeliveryKey ICCreateWithGroupDelivery(
    ICCreateServicePlanDeliveryAndGroupDetails spdAndGrpDtls)
    throws AppException, InformationalException {

    // create the Service Plan Delivery using standard method, then create the
    // Service Plan Group Delivery
    final ServicePlanIntegratedCaseKey facadeICKey = new ServicePlanIntegratedCaseKey();

    facadeICKey.servicePlanIntegratedCaseKey = spdAndGrpDtls.icKey;
    final ServicePlanDeliveryKey servicePlanDeliveryKey = ICCreate(
      spdAndGrpDtls.icDetails, facadeICKey);

    final MaintainSPGDeliveryLink maintainSPGDeliveryLinkObj = MaintainSPGDeliveryLinkFactory.newInstance();
    final SPGDeliveryLinkDtls varSPGDeliveryLinkDtls = new SPGDeliveryLinkDtls();

    // populate the link details
    varSPGDeliveryLinkDtls.servicePlanGroupDeliveryLinkId = UniqueID.nextUniqueID();
    varSPGDeliveryLinkDtls.caseID = servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID;
    varSPGDeliveryLinkDtls.servicePlanGroupDeliveryId = spdAndGrpDtls.spgKey.servicePlanGroupDeliveryId;
    maintainSPGDeliveryLinkObj.createLink(varSPGDeliveryLinkDtls);

    return servicePlanDeliveryKey;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Gets Service Plan Menu Data, that is in XML format. Used to generate
   * dynamic menu.
   *
   * @param servicePlanDeliveryMenuKey
   * Menu Key
   * @return Menu Details
   * @throws AppException
   * , InformationalException
   */
  @Override
  public ServicePlanDeliveryMenuDataDetails getServicePlanMenuData(
    ServicePlanDeliveryMenuKey servicePlanDeliveryMenuKey)
    throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    final curam.serviceplans.sl.struct.IntegratedCaseMemberKey integratedCaseMemberKey = new curam.serviceplans.sl.struct.IntegratedCaseMemberKey();

    // Integrated case facade object and key
    final IntegratedCase integratedCaseObj = IntegratedCaseFactory.newInstance();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    // Read service plan menu data
    servicePlanDeliveryKey.key.caseID = servicePlanDeliveryMenuKey.servicePlanDeliveryID;

    final ServicePlanMenuData servicePlanMenuData = servicePlanDeliveryObj.readServicePlanMenuData(
      servicePlanDeliveryKey);

    // Set integrated case member key
    integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID = servicePlanMenuData.caseParticipantRoleID;

    // Read integrated case details
    final ICDetails icDetails = servicePlanDeliveryObj.readIntegratedCaseDetails(
      integratedCaseMemberKey);

    // Set case participant role key
    caseParticipantRoleIDKey.caseParticipantRoleID = servicePlanMenuData.caseParticipantRoleID;

    // Get participant home page
    final ParticipantHomePageName participantHomePageName = integratedCaseObj.resolveParticipantHome(
      caseParticipantRoleIDKey);

    // Create description
    LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // Set IC type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      servicePlanMenuData.ICPageNamesICTypeAndConcernDetails.integratedCaseType));

    // Set IC case reference
    description.arg(servicePlanMenuData.caseReference);

    // Create root navigation element
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create IC link element
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      servicePlanMenuData.ICPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // Create case ID parameter
    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanMenuData.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create participant link element
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(servicePlanMenuData.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanDeliveryMenuKey.servicePlanDeliveryID));

    linkElement.addContent(paramElement);

    // Create service plan parameter
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID, kServicePlanHome);

    description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_SERVICE_PLAN_DESCRIPTION);

    // Read service plan name and reference
    final ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = servicePlanDeliveryObj.readParticipantTypeAndReferenceDetails(
      servicePlanDeliveryKey);

    // Add service plan type
    description.arg(
      new CodeTableItemIdentifier(SERVICEPLANTYPE.TABLENAME,
      spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType));

    // Add service plan reference
    description.arg(
      spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails.caseReference);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    // Create case ID parameter
    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanDeliveryMenuKey.servicePlanDeliveryID));

    linkElement.addContent(paramElement);

    // Create the return object
    final ServicePlanDeliveryMenuDataDetails servicePlanDeliveryMenuDataDetails = new ServicePlanDeliveryMenuDataDetails();

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    servicePlanDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // Return menu data
    return servicePlanDeliveryMenuDataDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Returns/Gets Service Plan Group Delivery Service Plan Menu Data, which is
   * in XML format.
   *
   * @param servicePlanDeliveryMenuKey
   * Service Plan Delivery Key
   *
   * @return Menu Details
   * @throws AppException
   * , InformationalException
   */
  @Override
  public ServicePlanDeliveryMenuDataDetails getSPGDServicePlanMenuData(
    ServicePlanDeliveryMenuKey servicePlanDeliveryMenuKey)
    throws AppException, InformationalException {

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    final curam.serviceplans.sl.struct.IntegratedCaseMemberKey integratedCaseMemberKey = new curam.serviceplans.sl.struct.IntegratedCaseMemberKey();

    // Integrated case facade object and key
    final IntegratedCase integratedCaseObj = IntegratedCaseFactory.newInstance();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    // Read service plan menu data
    servicePlanDeliveryKey.key.caseID = servicePlanDeliveryMenuKey.servicePlanDeliveryID;

    final ServicePlanMenuData servicePlanMenuData = servicePlanDeliveryObj.readServicePlanMenuData(
      servicePlanDeliveryKey);

    // Set integrated case member key
    integratedCaseMemberKey.integratedCaseMemberKey.caseParticipantRoleID = servicePlanMenuData.caseParticipantRoleID;

    // Read integrated case details
    final ICDetails icDetails = servicePlanDeliveryObj.readIntegratedCaseDetails(
      integratedCaseMemberKey);

    // Set case participant role key
    caseParticipantRoleIDKey.caseParticipantRoleID = servicePlanMenuData.caseParticipantRoleID;

    // Get participant home page
    final ParticipantHomePageName participantHomePageName = integratedCaseObj.resolveParticipantHome(
      caseParticipantRoleIDKey);

    // Create description
    LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // Set IC type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      servicePlanMenuData.ICPageNamesICTypeAndConcernDetails.integratedCaseType));

    // Set IC case reference
    description.arg(servicePlanMenuData.caseReference);

    // Create root navigation element
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // SERVICE PLAN GROUP DELIVERY LINK ELEMENT

    // Create service plan group delivery link element
    Element linkElement = new Element(kItem);

    description = new LocalisableString(
      BPOSERVICEPLANGROUPDELIVERY.INF_MENU_SERVICE_PLAN_GROUP_DESCRIPTION);

    // append the SPGD reference to the description
    description.arg(
      servicePlanDeliveryMenuKey.servicePlanGroupDeliveryReference);

    linkElement.setAttribute(kPageID, kServicePlanGroupDeliveryHome);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName,
      XmlMetaDataConst.kServicePlanGroupDeliveryId);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanDeliveryMenuKey.servicePlanGroupDeliveryID));

    linkElement.addContent(paramElement);

    // Add activeInd value to linkElement
    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kActiveInd);
    paramElement.setAttribute(kValue, kActiveIndFalse);
    linkElement.addContent(paramElement);

    // Create participant link element
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_PARTICIPANT_DESCRIPTION);

    description.arg(
      icDetails.caseReferenceConcernRoleNameCaseType.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(servicePlanMenuData.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanDeliveryMenuKey.servicePlanDeliveryID));

    linkElement.addContent(paramElement);

    // Create service plan parameter
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID, kServicePlanHome);

    description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_SERVICE_PLAN_DESCRIPTION);

    // Read service plan name and reference
    final ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = servicePlanDeliveryObj.readParticipantTypeAndReferenceDetails(
      servicePlanDeliveryKey);

    // Add service plan type
    description.arg(
      new CodeTableItemIdentifier(SERVICEPLANTYPE.TABLENAME,
      spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType));

    // Add service plan reference
    description.arg(
      spParticipantAndReferenceDetails.caseReferenceCRNameAltIDDetails.caseReference);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    // Create case ID parameter
    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(servicePlanDeliveryMenuKey.servicePlanDeliveryID));

    linkElement.addContent(paramElement);

    // Create the return object
    final ServicePlanDeliveryMenuDataDetails servicePlanDeliveryMenuDataDetails = new ServicePlanDeliveryMenuDataDetails();

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    servicePlanDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // Return menu data
    return servicePlanDeliveryMenuDataDetails;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Returns true or false based on whether or not the case has a Service Plan
   * Group Delivery.
   *
   * @returns Group result
   * @param servicePlanDeliveryMenuKey
   * Service Plan Delivery Menu Key
   *
   * @throws AppException
   * , InformationalException
   */
  // BEGIN, CR00198672, VK
  protected boolean checkGroup(
    ServicePlanDeliveryMenuKey servicePlanDeliveryMenuKey)
    throws AppException, InformationalException {

    // END, CR00198672
    final SPGDeliveryLink spgDeliveryLink = SPGDeliveryLinkFactory.newInstance();

    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryMenuKey.servicePlanDeliveryID;

    final SPGDeliveryKey spgdDeliveryKey = spgDeliveryLink.readServicePlanGroupDeliveryIdByCaseId(
      notFoundIndicator, caseHeaderKey);

    boolean groupInd = false;

    if (notFoundIndicator.isNotFound() == false) {
      final SPGDelivery spgDelivery = SPGDeliveryFactory.newInstance();

      final SPGDeliveryDtls spgDeliveryDtls = spgDelivery.read(spgdDeliveryKey);

      servicePlanDeliveryMenuKey.servicePlanGroupDeliveryID = spgDeliveryDtls.servicePlanGroupDeliveryId;
      servicePlanDeliveryMenuKey.servicePlanGroupDeliveryReference = spgDeliveryDtls.spgdReference;

      groupInd = true;
    }

    return groupInd;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * Return the case ID (service plan delivery ID) for a given plannedID
   *
   * @param key
   * Planned Item ID Key
   * @throws AppException
   * , InformationalException
   */
  @Override
  public ServicePlanDeliveryKey readCaseID(PlannedItemIDKey key)
    throws AppException, InformationalException {

    ServicePlanDeliveryKey result = new ServicePlanDeliveryKey();

    final curam.serviceplans.sl.intf.PlannedItem piObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    try {
      result.servicePlanDeliveryKey = piObj.readCaseID(key.plannedItemIDKey);
    } catch (final RecordNotFoundException rnfe) {
      result = new ServicePlanDeliveryKey();
    }
    return result;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  /**
   * Method which obtains the estimated cost of the planned item.
   *
   * @param key
   * ID of the planned item
   * @return Estimated cost of the planned item
   * @throws AppException
   * , InformationalException
   */
  @Override
  public PlannedItemEstimatedCost readEstimatedCostOfPlannedItemID(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Create return struct
    PlannedItemEstimatedCost plannedItemEstimatedCost = new PlannedItemEstimatedCost();

    // Create service layer object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Call service layer to obtain estimated cost
    plannedItemEstimatedCost = plannedItemObj.readPlannedItemEstimatedCost(
      key.plannedItemIDKey);

    // Return the result
    return plannedItemEstimatedCost;
  }

  // END, CR00161962
  // BEGIN, CR00145825, SK
  // ___________________________________________________________________________
  /**
   * Lists all the contracts with service plan status for a specific service
   * plan.
   *
   * @param key
   * unique identifier of the service plan case.
   * @return list of service plan contracts with service plan status.
   * @throws AppException
   * , InformationalException
   */

  @Override
  public SPContractDetailsListwithCaseStatus listContractswithCaseStatus(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // TODO Auto-generated method stub

    final SPContractDetailsListwithCaseStatus servicePlanContractDetailsList = new SPContractDetailsListwithCaseStatus();

    // ServicePlanContract business object
    final curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final SPContractListKey spContractListKey = new SPContractListKey();

    spContractListKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read service plan contract list
    servicePlanContractDetailsList.servPlanContractDetailsList = servicePlanContractObj.list(
      spContractListKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    caseHeaderKey.caseID = key.servicePlanDeliveryKey.key.caseID;
    // return the status of the service plan
    final CaseStatusCode caseStatusCode = servicePlanDeliveryObj.getServicePlanStatus(
      caseHeaderKey);
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    if (caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
      || caseStatusCode.statusCode.equals(CASESTATUS.APPROVED)) {
      servicePlanContractDetailsList.caseStatusInd = true;
    } else {
      final LocalisableString infoMessage = new LocalisableString(
        BPOSERVICEPLANCONTRACT.INF_SERPLAN_CONTRACT_XRV_SERPLAN_MUST_BE_ACTIVE_OR_APPROVED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }
      servicePlanContractDetailsList.dtls = informationMsgDtlsList.informationalMsgDtlsList;
      // setting the status indicator false to hide the new link
      // if the service plan status is not active or approved.
      servicePlanContractDetailsList.caseStatusInd = false;
    }

    // BEGIN, CR00236562, SS
    final ServicePlanDeliveryIssuedAndAcceptStatus servicePlanDeliveryIssuedAndAcceptStatus = new ServicePlanDeliveryIssuedAndAcceptStatus();

    servicePlanDeliveryIssuedAndAcceptStatus.caseID = key.servicePlanDeliveryKey.key.caseID;

    final curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractBaseObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    final RecordCount countIssuedAndAccepted = servicePlanContractBaseObj.countIssuAndAccContractsByCaseID(
      servicePlanDeliveryIssuedAndAcceptStatus);

    if (countIssuedAndAccepted.count > 0) {

      final LocalisableString infoMessage = new LocalisableString(
        BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_RV_INSERT_CONTRACT_MULTI_CONRACT_NOT_ALLOWED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }
      servicePlanContractDetailsList.dtls = informationMsgDtlsList.informationalMsgDtlsList;
      // setting the status indicator false to hide the new link
      // if the service plan contract status is issued or accepted.
      servicePlanContractDetailsList.caseStatusInd = false;
    }
    // END, CR00236562

    servicePlanContractDetailsList.description = getServicePlanContextDescription(
      key);

    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanContractDetailsList.menuData.menuData = menuData.menuData;

    // return the contract list service plan status
    return servicePlanContractDetailsList;

  }

  // END, CR00145825
  // BEGIN, CR00146960, DJ
  // ___________________________________________________________________________
  /**
   * Lists all the plan groups and sub-goals for a specific service plan.
   *
   * @param key unique identifier of the service plan case.
   *
   * @return List of plan groups and sub-goals associated with the service plan
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  @Override
  public ServicePlanContentDetailsList listPlanContentforServicePlans(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // Planned Group business object
    final curam.serviceplans.sl.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.fact.PlannedGroupFactory.newInstance();
    curam.serviceplans.sl.struct.PlanContentDetailsList planContentDetailsListSL = null;
    final curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // return value
    final curam.serviceplans.facade.struct.ServicePlanContentDetailsList servicePlanContentDetailsList = new curam.serviceplans.facade.struct.ServicePlanContentDetailsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // set the key
    servicePlanDeliveryKey.key.caseID = key.servicePlanDeliveryKey.key.caseID;

    // call service layer for list
    planContentDetailsListSL = plannedGroupObj.listPlanContent(
      key.servicePlanDeliveryKey);
    final ServicePlanDeliveryHomePageDetails servicePlanDeliveryHomePageDetails = new ServicePlanDeliveryHomePageDetails();
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);
    if (servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName.equals(
      CuramConst.gkEmpty)) {
      servicePlanContentDetailsList.goalInd = true;
      final LocalisableString infoMessage = new LocalisableString(
        BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_ADD_SERVICE_PLAN_GOAL_NOT_EXISTS);
      final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
      final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      servicePlanContentDetailsList.infodtls = informationMsgDtlsList;
    }

    // User manipulation variables
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();

    // get the user id of the working user
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    // read current user sensitivity details
    final curam.core.struct.UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    // filter sub goal details
    // Note
    // This processing has to be done at the presentation level, as can not
    // return
    // the details containing all Strings attributes from the BPO layer,
    // as the customer will be expecting them to be of the correct type
    for (int i = 0; i < planContentDetailsListSL.list.size(); i++) {

      final PlanContentDetails planContentDetailsAsStrings = new PlanContentDetails();

      final curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
      final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

      PlannedSubGoalSensitivityCodeDetails plannedSubGoalSensitivityCodeDetails = null;

      // only want to check sensitivity for those in list of type sub goal
      if (planContentDetailsListSL.list.item(i).planContentTypeInd == false) {

        plannedSubGoalKey.plannedSubGoalID = planContentDetailsListSL.list.item(i).planContentID;
        plannedSubGoalSensitivityCodeDetails = plannedSubGoalObj.readSensitivityCode(
          plannedSubGoalKey);
      }

      // Assign ID's and content type as will never be displayed on screen
      planContentDetailsAsStrings.planContentID = planContentDetailsListSL.list.item(i).planContentID;
      planContentDetailsAsStrings.planContentType = planContentDetailsListSL.list.item(i).planContentType;

      // set indicator
      planContentDetailsAsStrings.planContentTypeInd = planContentDetailsListSL.list.item(i).planContentTypeInd;

      // if subgoal do the following:
      if (planContentDetailsListSL.list.item(i).planContentTypeInd == false
        && // if sub goal sensitivity higher than user sensitivity
        // then replace with
        Integer.parseInt(plannedSubGoalSensitivityCodeDetails.sensitivityCode)
          > Integer.parseInt(userSecurityDetails.sensitivity)) {
        planContentDetailsAsStrings.name = planContentDetailsAsStrings.outcome = planContentDetailsAsStrings.status = kSubGoalDetailsRestricted;
        planContentDetailsAsStrings.startDate = curam.util.type.Date.kZeroDate;
        planContentDetailsAsStrings.endDate = curam.util.type.Date.kZeroDate;
      } // planned group and planned subgoal will have same info
      else {
        planContentDetailsAsStrings.name = planContentDetailsListSL.list.item(i).name;
        // outcome and status only relate to a planned sub goal
        if (planContentDetailsListSL.list.item(i).planContentTypeInd == false) {
          // set outcome and status
          planContentDetailsAsStrings.outcome = CodeTable.getOneItem(
            OUTCOMEACHIEVED.TABLENAME,
            planContentDetailsListSL.list.item(i).outcome,
            TransactionInfo.getProgramLocale());
          planContentDetailsAsStrings.status = CodeTable.getOneItem(
            PLANNEDSUBGOALSTATUS.TABLENAME,
            planContentDetailsListSL.list.item(i).status,
            TransactionInfo.getProgramLocale());
        }

        planContentDetailsAsStrings.startDate = planContentDetailsListSL.list.item(i).startDate;
        planContentDetailsAsStrings.endDate = planContentDetailsListSL.list.item(i).endDate;

      }

      // add each filtered record to overall return struct
      // planContentDetailsList.list.addRef(planContentDetailsAsStrings);
      servicePlanContentDetailsList.dtls3.addRef(planContentDetailsAsStrings);
    }
    servicePlanContentDetailsList.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanContentDetailsList.integratedCaseMenuDataDetails.menuData = menuData.menuData;
    return servicePlanContentDetailsList;
  }

  // BEGIN, CR00248736, MR
  /**
   * Reads service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlanDelivery#readHomePageDetails1(ServicePlanDeliveryKey)}.
   * This method is not returning the indicators to denote which
   * manage actions should be visible to the user. See release
   * note: CR00248736.
   */
  @Override
  @Deprecated
  // END, CR00248736
  public ServicePlanDeliveryHomeDetails readServicePlanDeliveryHomeDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    final ServicePlanDeliveryHomeDetails servicePlanDeliveryHomeDetails = new ServicePlanDeliveryHomeDetails();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    servicePlanDeliveryHomeDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);
    if (servicePlanDeliveryHomeDetails.servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName.equals(
      CuramConst.gkEmpty)) {
      servicePlanDeliveryHomeDetails.goalInd = true;
      final LocalisableString infoMessage = new LocalisableString(
        BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS);
      final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
      final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      servicePlanDeliveryHomeDetails.informationalmsgdtls = informationMsgDtlsList;
    }

    // read service plan details
    servicePlanDeliveryHomeDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);

    // read context description
    servicePlanDeliveryHomeDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    // assign menu data to the returned struct
    servicePlanDeliveryHomeDetails.integratedCaseMenuDataDetails.menuData = menuData.menuData;

    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.servicePlanDeliveryKey.key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);

    // return home page details
    return servicePlanDeliveryHomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists all service plans for the specified integrated case.
   *
   * @param key Contains case ID of the integrated case
   * @return List of service plan details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public ListServicePlanForIC listByICCase(ServicePlanIntegratedCaseKey key)
    throws AppException, InformationalException {

    // return value
    final ListServicePlanForIC listServicePlanForIC = new ListServicePlanForIC();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // register the security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read menu data
    final curam.serviceplans.sl.struct.ServicePlanICMenuData servicePlanICMenuData = servicePlanDeliveryObj.readServicePlanICMenuData(
      key.servicePlanIntegratedCaseKey);

    // read service plan list
    listServicePlanForIC.listServicePlanForIC = servicePlanDeliveryObj.listByICCase(
      key.servicePlanIntegratedCaseKey);

    // read context description data
    final curam.serviceplans.sl.struct.CaseReferenceAndICTypeDetails caseReferenceAndICTypeDetails = servicePlanDeliveryObj.readIntegratedCaseTypeAndReference(
      key.servicePlanIntegratedCaseKey);
    final int length = listServicePlanForIC.listServicePlanForIC.dtls.size();
    int counttrue = 0;
    int countfalse = 0;

    for (int a = 0; a < length; a++) {
      if (listServicePlanForIC.listServicePlanForIC.dtls.item(a).goalInd
        == false) {
        counttrue = counttrue + 1;
      } else {
        countfalse = countfalse + 1;
      }
    }
    if (countfalse > 0) {
      listServicePlanForIC.goalInd = true;
      final LocalisableString infoMessage = new LocalisableString(
        BPOMAINTAINSERVICEPLANDELIVERY.INF_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS);
      final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
      final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      listServicePlanForIC.infodtls = informationMsgDtlsList;
    }

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_IC_CONTEXT_DESCRIPTION);

    // add integrated case type
    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      caseReferenceAndICTypeDetails.caseReferenceAndICTypeDetails.integratedCaseType));

    // add integrated case reference
    description.arg(
      caseReferenceAndICTypeDetails.caseReferenceAndICTypeDetails.caseReference);

    // assign it to the return object
    listServicePlanForIC.icServicePlanContextDescription.description = description.toClientFormattedText();

    // assign menu data
    final curam.util.exception.LocalisableString icMenuDescription = new curam.util.exception.LocalisableString(
      BPOSERVICEPLANDELIVERY.INF_MENU_INTEGRATED_CASE_DESCRIPTION);

    // set IC type
    icMenuDescription.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      servicePlanICMenuData.ICHomePageNameAndType.integratedCaseType));

    // set IC case reference
    icMenuDescription.arg(
      servicePlanICMenuData.ICHomePageNameAndType.caseReference);

    // create root node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // create child node
    final Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      servicePlanICMenuData.ICHomePageNameAndType.homePageName);
    linkElement.setAttribute(kDesc, icMenuDescription.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);
    navigationMenuElement.addContent(linkElement);

    // create case ID parameter
    final Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(
      key.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID));
    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    listServicePlanForIC.integratedCaseMenuDetails.menuData = outputter.outputString(
      navigationMenuElement);

    // return the list
    return listServicePlanForIC;
  }

  // END, CR00146960

  // BEGIN, CR00218024, CSH

  // BEGIN, CR00248736, MR
  /**
   * Replaces the deprecated method
   * {@link ServicePlanDelivery#readServicePlanDeliveryHomeDetails(ServicePlanDeliveryKey)}
   * .
   * <p>
   * Reads service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00248736
  @Override
  public ServicePlanDeliveryHomePageDetails1 readHomePageDetails1(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // Return value
    final ServicePlanDeliveryHomePageDetails1 servicePlanDeliveryHomePageDetails = new ServicePlanDeliveryHomePageDetails1();

    // ServicePlanDelivery business object
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Read service plan details
    servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);

    // BEGIN, CR00147011, MR
    if (CuramConst.gkEmpty.equals(
      servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName)) {
      final LocalisableString infoMessage = new LocalisableString(
        BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS);
      final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      for (final String warnings : informationalManager.obtainInformationalAsString()) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings;
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      servicePlanDeliveryHomePageDetails.informationalMsgDtlsList = informationMsgDtlsList;
    }
    // END, CR00147011

    // Read context description
    servicePlanDeliveryHomePageDetails.spDeliveryContextDescription = getServicePlanContextDescription(
      key);

    // Set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // Read menu data
    final ICServicePlanDeliveryMenuDataDetails menuData = getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    // Assign menu data to the returned struct
    servicePlanDeliveryHomePageDetails.integratedCaseMenuDataDetails.menuData = menuData.menuData;

    // Populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.servicePlanDeliveryKey.key.caseID;

    // Create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);

    // Read current status of the service plan delivery to determine
    // which actions should be available to the user
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = key.servicePlanDeliveryKey.key.caseID;
    // BEGIN, CR00224271, ZV
    final curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    if (caseStatusDtls.statusCode.equals(CASESTATUS.OPEN)) {

      servicePlanDeliveryHomePageDetails.showSubmitInd = true;
    } else {

      servicePlanDeliveryHomePageDetails.showSubmitInd = false;
    }

    if (caseStatusDtls.statusCode.equals(CASESTATUS.PLANSUBMITTED)) {

      servicePlanDeliveryHomePageDetails.showApproveRejectInd = true;
    } else {

      servicePlanDeliveryHomePageDetails.showApproveRejectInd = false;
    }

    if (caseStatusDtls.statusCode.equals(CASESTATUS.CLOSED)) {

      servicePlanDeliveryHomePageDetails.isClosedInd = true;
    }

    // Return home page details
    return servicePlanDeliveryHomePageDetails;
  }

  // END, CR00218024

  // BEGIN, CR00218954, MC
  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the Weekly Client Participation
   * wizard.
   *
   * @return The wizard details for the Weekly Client Participation wizard.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public WizardProperties getWeeklyClientParticipationWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCreateWeeklyClientParticipationWizardProperties;

    return wizardProperties;
  }

  // END, CR00218954

  // BEGIN, CR00226831, LP
  /**
   * Reads the the possible outcomes and Goal Name for a plan item
   *
   * @param plannedSubGoalKey
   * Contains the planned sub-goal id.
   * @return The Sub Goal Name
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ExpectedOutcomesForPlanItemDtlsList readPossibleOutcomesAndSubGoalNameDetailsForPlanItem(
    PlannedSubGoalKey plannedSubGoalKey,
    curam.serviceplans.facade.struct.PlanItemKey planItemKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final ExpectedOutcomesForPlanItemDtlsList expectedOutcomesForPlanItemList = new ExpectedOutcomesForPlanItemDtlsList();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Planned Sub-Goal business object
    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    expectedOutcomesForPlanItemList.outcomesForPlanItem = planItemObj.listOutcomes(
      planItemKey.key);

    // BEGIN HARP 49368, ST
    final PlannedSubGoalNameStruct plannedSubGoalNameStruct = new PlannedSubGoalNameStruct();

    plannedSubGoalNameStruct.subGoalName = plannedSubGoalObj.readForModification(plannedSubGoalKey.plannedSubGoalKey).plannedSubGoalDetailsAndSubGoalName.subGoalName;
    // get sub goal name
    expectedOutcomesForPlanItemList.subGoalName = readSubGoalName(plannedSubGoalNameStruct).subGoalName;
    // END HARP 49368

    // get planItem
    expectedOutcomesForPlanItemList.planItemName = CodeTable.getOneItem(
      PLANITEMNAME.TABLENAME,
      planItemObj.readName(planItemKey.key).planItemNameDetails.name,
      TransactionInfo.getProgramLocale());

    plannedItemObj.validateOutComeExistsForPlanItem(planItemKey.key,
      plannedSubGoalKey.plannedSubGoalKey);

    // BEGIN CR00109001, GBA
    // BEGIN, CR00146503, GBA
    expectedOutcomesForPlanItemList.participantList.list = plannedItemObj.getParticipantsForConcerning(plannedSubGoalKey.plannedSubGoalKey).list;
    // END CR00109001

    expectedOutcomesForPlanItemList.respParticipantList.list = plannedItemObj.getParticipantsForResponsibility(plannedSubGoalKey.plannedSubGoalKey).list;
    // END, CR00146503

    expectedOutcomesForPlanItemList.respParticipantList.list = plannedItemObj.getParticipantsForResponsibility(plannedSubGoalKey.plannedSubGoalKey).list;
    // END, CR00129695

    // BEGIN, CR00246725, MR
    expectedOutcomesForPlanItemList.guidanceURL = planItemObj.read(planItemKey.key).dtls.guidanceURL;
    // END, CR00246725
    return expectedOutcomesForPlanItemList;
  }

  // END, CR00226831

  // BEGIN, CR00226831, LP
  /**
   * Reads the details required to display the add service unit delivery plan
   * item screen
   *
   * @param plannedSubGoalKey
   * the key of the sub-goal
   * @param planItemKey
   * the key of the plan item
   *
   * @return the service unit plan item details
   */
  @Override
  public ReadDtlsForAddServiceUnitPlannedItem readDtlsForAddServiceUnitPlannedItem(PlannedSubGoalKey plannedSubGoalKey,
    PlanItemKey planItemKey) throws AppException, InformationalException {

    // Return Object
    final ReadDtlsForAddServiceUnitPlannedItem readDetailsForAddServiceUnitPlannedItem = new ReadDtlsForAddServiceUnitPlannedItem();

    final curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    final curam.serviceplans.sl.intf.PlanItem planItemSLObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    final PlannedSubGoalNameStruct plannedSubGoalNameStruct = new PlannedSubGoalNameStruct();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    plannedSubGoalNameStruct.subGoalName = plannedSubGoalObj.readForModification(plannedSubGoalKey.plannedSubGoalKey).plannedSubGoalDetailsAndSubGoalName.subGoalName;

    // Get the sub-goal name
    readDetailsForAddServiceUnitPlannedItem.subGoalName = readSubGoalName(plannedSubGoalNameStruct).subGoalName;

    // Get the plan item name
    readDetailsForAddServiceUnitPlannedItem.planItemName = CodeTable.getOneItem(
      PLANITEMNAME.TABLENAME, planItemObj.readName(planItemKey.key.key).name,
      TransactionInfo.getProgramLocale());

    // Get the plan item service unit delivery details
    PlanItemServiceUnitDeliveryDetails planItemServiceUnitDeliveryDetails = new PlanItemServiceUnitDeliveryDetails();

    planItemServiceUnitDeliveryDetails = planItemObj.readPlanItemServiceUnitDeliveryDetails(
      planItemKey.key.key);

    readDetailsForAddServiceUnitPlannedItem.unitType = planItemServiceUnitDeliveryDetails.unitType;

    readDetailsForAddServiceUnitPlannedItem.authorizedUnits = planItemServiceUnitDeliveryDetails.authorizedUnits;

    // BEGIN, CR00000637, PMD
    readDetailsForAddServiceUnitPlannedItem.maximumUnits = planItemServiceUnitDeliveryDetails.maximumUnits;
    // END, CR00000637

    // Get the list of Outcomes available for the plan item
    readDetailsForAddServiceUnitPlannedItem.outcomesForPlanItem = planItemSLObj.listOutcomes(
      planItemKey.key);

    // BEGIN CR00124520, GBA
    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // BEGIN, CR00147210, GBA
    readDetailsForAddServiceUnitPlannedItem.participants.list = plannedItemObj.getParticipantsForConcerning(plannedSubGoalKey.plannedSubGoalKey).list;

    readDetailsForAddServiceUnitPlannedItem.respParticipantList.list = plannedItemObj.getParticipantsForResponsibility(plannedSubGoalKey.plannedSubGoalKey).list;
    // END, CR00147210
    // END CR00124520

    return readDetailsForAddServiceUnitPlannedItem;
  }

  // END, CR00226831

  // BEGIN, CR00235251, TV
  // ___________________________________________________________________________
  /**
   * Adds a service unit delivery planned item to a planned subgoal.
   *
   * @param details
   * Details of the plan item to be added.
   */
  @Override
  public void createServiceUnitDeliveryPlanItemToSubGoal(
    PlannedItemDetailsStruct details) throws AppException,
      InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Create the planned item
    plannedItemObj.createBasicPlanItemDetails(
      details.createPlannedItemDetailsStruct);
  }

  // END, CR00235251

  // BEGIN, CR00235251, TV
  // ___________________________________________________________________________
  /**
   * Adds a basic planned item to a planned subgoal.
   *
   * @param createPlannedItemDetailsStruct
   * details of the plan item to be added.
   */
  @Override
  public void createBasicPlanItemToSubGoal(PlannedItemDetailsStruct details)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    final curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Create the planned item
    plannedItemObj.createBasicPlanItemDetails(
      details.createPlannedItemDetailsStruct);
  }

  // END, CR00235251

  // BEGIN, CR00282078, AKr
  /**
   * Returns the baseline milestone details for the specified
   * baseline milestone ID.
   *
   * @param key Contains the baseline milestone ID.
   * @return Baseline Milestone Details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public BaselineMilestoneDtls viewBaselineMilestoneDetails(
    final BaselineMilestoneKey key) throws AppException,
      InformationalException {

    return BaselineMilestoneFactory.newInstance().read(key);
  }

  /**
   * Reads the baseline milestone ID for the specified baseline version of
   * the milestone delivery.
   *
   * @param key Contains the baseline ID and the milestone delivery ID.
   * @return Baseline Milestone ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public BaselineMilestoneKey readBaselineMilestoneID(
    final BaselineAndMilestoneDeliveryKey key) throws AppException,
      InformationalException {

    final BaselineMilestoneDtls baselineMilestoneDtls = BaselineMilestoneFactory.newInstance().readByBaselineAndMilestoneDeliveryID(
      key);
    final BaselineMilestoneKey baselineMilestoneKey = new BaselineMilestoneKey();

    baselineMilestoneKey.baselineMilestoneID = baselineMilestoneDtls.baselineMilestoneID;
    return baselineMilestoneKey;
  }
  // END, CR00282078
}
