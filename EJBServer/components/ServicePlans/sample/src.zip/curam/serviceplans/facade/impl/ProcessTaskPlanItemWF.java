/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;


import curam.codetable.TASKCONFIGACTIONLINK;
import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseKey;
import curam.core.struct.IntegratedCaseKey;
import curam.serviceplans.facade.struct.PlanItemKey;
import curam.serviceplans.facade.struct.PlannedItemIDKey;
import curam.serviceplans.facade.struct.ReadPlanItemTaskConfigDetails;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemTaskConfigurationFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemTaskConfiguration;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemTaskConfigurationDtls;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.TaskConfigurationDtls;
import curam.serviceplans.sl.fact.PlanItemFactory;
import curam.serviceplans.sl.intf.PlanItem;
import curam.serviceplans.sl.struct.ReadPlanItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.NotFoundIndicator;


/**
 * This API has the functionality related to processing the task plan item.
 */
public abstract class ProcessTaskPlanItemWF extends curam.serviceplans.facade.base.ProcessTaskPlanItemWF {

  /**
   * This method is used to check if the task configuration exists for the
   * plan item. If it exists it fetches the task configuration details.
   *
   * @param piKey
   * PlannedItemIDKey
   * @return ReadPlanItemTaskConfigDetails
   * @throws AppException, InformationalException
   */
  @Override
  public ReadPlanItemTaskConfigDetails readTaskConfigurationDetails(
    final PlannedItemIDKey piKey) throws AppException, InformationalException {

    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = piKey.plannedItemIDKey.plannedItemIDKey.plannedItemID;

    final NotFoundIndicator nfiPI = new NotFoundIndicator();

    final PlannedItemKey plannedItemKeyEL = new PlannedItemKey();

    // before processing anything check if the planned item still exits
    plannedItemKeyEL.plannedItemID = piKey.plannedItemIDKey.plannedItemIDKey.plannedItemID;

    plannedItemObj.read(nfiPI, plannedItemKeyEL);

    // If the planned item does not exist then return blank param.
    if (nfiPI.isNotFound()) {
      return new ReadPlanItemTaskConfigDetails();
    }

    final PlanItemIDDetailsStruct planItemIDDetails = plannedItemObj.readPlanItemID(
      piKey.plannedItemIDKey.plannedItemIDKey);

    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.key.planItemID = planItemIDDetails.planItemID;

    final PlanItem planItemObj = PlanItemFactory.newInstance();

    final ReadPlanItemDetails readPlanItemDetails = planItemObj.read(
      planItemKey.key);

    final PlannedItemTaskConfiguration plannedItemTaskConfigObj = PlannedItemTaskConfigurationFactory.newInstance();

    final TaskConfigurationDtls taskConfigDtls = new TaskConfigurationDtls();

    final NotFoundIndicator nfi = new NotFoundIndicator();

    taskConfigDtls.assign(readPlanItemDetails.taskConfigDtls);

    PlannedItemTaskConfigurationDtls plannedItemTaskConfigurationDtls = plannedItemTaskConfigObj.readPlannedItemTaskByPlannedItemID(
      nfi, piKey.plannedItemIDKey.plannedItemIDKey);

    if (nfi.isNotFound()) {
      plannedItemTaskConfigurationDtls = new PlannedItemTaskConfigurationDtls();
    }

    taskConfigDtls.actionLink = plannedItemTaskConfigurationDtls.actionLink;

    taskConfigDtls.actionText = plannedItemTaskConfigurationDtls.actionText;

    taskConfigDtls.assignToID = plannedItemTaskConfigurationDtls.assignToID;

    taskConfigDtls.subject = plannedItemTaskConfigurationDtls.subject;

    readPlanItemDetails.taskConfigDtls.assign(taskConfigDtls);

    final ReadPlanItemTaskConfigDetails readPlanItemTaskConfigDetails = new ReadPlanItemTaskConfigDetails();

    readPlanItemTaskConfigDetails.taskConfigDtls.assign(
      readPlanItemDetails.taskConfigDtls);

    final ReadCaseIDByPlannedItemDetailsStruct servicePlanCaseIDKey = plannedItemObj.readCaseIDByPlannedItemID(
      piKey.plannedItemIDKey.plannedItemIDKey);

    readPlanItemTaskConfigDetails.caseID = servicePlanCaseIDKey.caseID;

    // Set the action page parameter id
    // If the action link is Claim home then set the page param as
    // integrated case id
    if (readPlanItemTaskConfigDetails.taskConfigDtls.actionLink.equals(
      TASKCONFIGACTIONLINK.ClaimHome)) {

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = servicePlanCaseIDKey.caseID;

      final IntegratedCaseKey integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(
        caseKey);

      readPlanItemTaskConfigDetails.actionPageIDParam = integratedCaseKey.integratedCaseID;
    } else if (readPlanItemTaskConfigDetails.taskConfigDtls.actionLink.equals(
      TASKCONFIGACTIONLINK.ServicePlanHome)) {
      // if the action page is service plan home then set the page param
      // id equal to service plan delivery case id

      readPlanItemTaskConfigDetails.actionPageIDParam = plannedItemObj.readCaseIDByPlannedItemID(piKey.plannedItemIDKey.plannedItemIDKey).caseID;
    } else if (readPlanItemTaskConfigDetails.taskConfigDtls.actionLink.equals(// if the action page is set to plan item home
      // then select plan item home
      TASKCONFIGACTIONLINK.PlanItemHome)) {

      readPlanItemTaskConfigDetails.actionPageIDParam = plannedItemKey.plannedItemID;
    }

    return readPlanItemTaskConfigDetails;
  }
}
