/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.facade.impl;


import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.core.struct.IntegratedCaseKey;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANGROUP;
import curam.message.BPOSERVICEPLANGROUPDELIVERY;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.SearchForServicePlansResultsDtls;
import curam.serviceplans.facade.struct.ServicePlanAndCaseMemberDetails;
import curam.serviceplans.facade.struct.ServicePlanGroupCreateLinksDtls;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryKey;
import curam.serviceplans.facade.struct.ServicePlanGroupDescriptionDtls;
import curam.serviceplans.facade.struct.ServicePlanGroupHomeDtls;
import curam.serviceplans.facade.struct.ServicePlanGroupHomeDtlsForUpdate;
import curam.serviceplans.facade.struct.ServicePlanGroupInfoMessage;
import curam.serviceplans.facade.struct.ServicePlanGroupLinkedServicePlanDtlsList;
import curam.serviceplans.facade.struct.ServicePlanGroupLinkedServicePlansDtls;
import curam.serviceplans.facade.struct.ServicePlanGroupSPDetailsAndSPGKey;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.struct.IntegratedCaseIDKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupLinkKey;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupFactory;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupLinkFactory;
import curam.serviceplans.sl.fact.ServicePlanFactory;
import curam.serviceplans.sl.intf.MaintainServicePlanGroup;
import curam.serviceplans.sl.intf.MaintainServicePlanGroupLink;
import curam.serviceplans.sl.intf.ServicePlan;
import curam.serviceplans.sl.struct.ICMembersAndSPTypesDetails;
import curam.serviceplans.sl.struct.MaintainServicePlanGroupAllActiveDtlsList;
import curam.serviceplans.sl.struct.ReadServicePlanDetails;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringList;
import curam.util.type.UniqueID;
import curam.workspaceservices.facade.struct.LocalizableTextDetails;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.facade.struct.ViewLocalizableTextDetails;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.impl.TextTranslation;
import curam.workspaceservices.localization.impl.TextTranslationDAO;


/**
 * This process class provides the functionality for the ServicePlanGroup facade
 * layer.
 */
public abstract class ServicePlanGroup extends curam.serviceplans.facade.base.ServicePlanGroup {

  // BEGIN, CR00233651, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  @Inject
  private TextTranslationDAO textTranslationDAO;

  // END, CR00233651

  /**
   * Default Constructor.
   */
  public ServicePlanGroup() {

    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a new Service Plan Group.
   *
   * @param dtls
   * the details to create the new record
   * @return ServicePlanGroupKey
   * the id of the new record
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupKey create(final ServicePlanGroupDtls dtls)
    throws AppException, InformationalException {

    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();

    return maintainServicePlanGroupObj.create(dtls);
  }

  /**
   * looks up details required for the Service Plan Group homepage.
   *
   * @param spgKey
   * the id of the Service Plan Group
   * @return ServicePlanGroupHomeDtls
   * the details required for the Service Plan Group home page.
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupHomeDtls read(ServicePlanGroupKey spgKey)
    throws AppException, InformationalException {

    //

    final ServicePlanGroupHomeDtls homeDtls = new ServicePlanGroupHomeDtls();
    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();

    homeDtls.spgDtls = maintainServicePlanGroupObj.read(spgKey);
    final MaintainServicePlanGroupLink linkObj = MaintainServicePlanGroupLinkFactory.newInstance();
    final ServicePlanGroupLinkDtlsList linkDtlsList = linkObj.getAllForServicePlanGroup(
      spgKey);

    final ServicePlanKey spk = new ServicePlanKey();

    ServicePlanGroupLinkDtls servicePlanGroupLinkDtls = null;
    ServicePlanGroupLinkedServicePlansDtls servicePlanGroupLinkedServicePlansDtls = null;
    final ServicePlan slServicePlanObj = ServicePlanFactory.newInstance();
    final int size = linkDtlsList.dtls.size();

    for (int i = 0; i < size; i++) {
      servicePlanGroupLinkDtls = linkDtlsList.dtls.item(i);
      servicePlanGroupLinkedServicePlansDtls = new ServicePlanGroupLinkedServicePlansDtls();
      servicePlanGroupLinkedServicePlansDtls.linkDtls = servicePlanGroupLinkDtls;
      spk.key.servicePlanID = servicePlanGroupLinkDtls.servicePlanID;
      final ReadServicePlanDetails spd = slServicePlanObj.read(spk);

      servicePlanGroupLinkedServicePlansDtls.planDtls = spd.plan;
      homeDtls.linkedServicePlans.addRef(servicePlanGroupLinkedServicePlansDtls);
    }
    return homeDtls;
  }

  /**
   * gets all the Service Plan Groups available.
   *
   * @return ServicePlanGroupDtlsList
   * all of the Service Plan Groups.
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupDtlsList readAll() throws AppException,
      InformationalException {

    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();

    return maintainServicePlanGroupObj.readAll();
  }

  /**
   * sets the Service Plan Group to the Cancelled state.
   *
   * @param spgKey
   * the id of the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public void remove(ServicePlanGroupKey spgKey) throws AppException,
      InformationalException {

    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();

    maintainServicePlanGroupObj.remove(spgKey);
  }

  /**
   * removes the record linking a Service Plan Group to a Service Plan.
   *
   * @param linkKey
   * the id of the Service Plan Group Link record
   * @throws AppException, InformationalException
   */
  @Override
  public void removeLink(ServicePlanGroupLinkKey linkKey)
    throws AppException, InformationalException {

    final MaintainServicePlanGroupLink linkObj = MaintainServicePlanGroupLinkFactory.newInstance();

    linkObj.removeLink(linkKey);
  }

  /**
   * Returns a list of Service Plans that the Service Plan Group can be linked
   * to. Note that the list returned will exclude any that the Service Plan
   * Group is already linked to
   *
   * @param key
   * the id of the Service Plan Group
   * @return SearchForServicePlansResultsDtls
   * the list of Service Plans for the Service Plan Group.
   * @throws AppException, InformationalException
   */
  @Override
  public SearchForServicePlansResultsDtls searchForServicePlans(
    ServicePlanGroupKey key) throws AppException, InformationalException {

    final SearchForServicePlansResultsDtls resultDtls = new SearchForServicePlansResultsDtls();
    final MaintainServicePlanGroupLink linkObj = MaintainServicePlanGroupLinkFactory.newInstance();

    final ServicePlanGroupLinkDtlsList linkDtlsList = linkObj.getAllForServicePlanGroup(
      key);
    // now get all the possible ServicePlans
    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();
    final ServicePlanDtlsList allList = maintainServicePlanGroupObj.getServicePlansByType();

    // check the SPG status to see if need to put up the message about
    // status being cancelled
    MaintainServicePlanGroupFactory.newInstance().read(key);

    resultDtls.spds.addAll(
      maintainServicePlanGroupObj.filterActiveServicePlanList(allList, linkDtlsList).dtls);
    return resultDtls;
  }

  /**
   * performs an update of the Service Plan Group.
   *
   * @param dtls
   * the id of the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public void update(ServicePlanGroupDtls dtls) throws AppException,
      InformationalException {

    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();

    maintainServicePlanGroupObj.update(dtls);
  }

  /**
   * creates one or more link records for the Service Plan Group and the
   * specified Service Plan(s).
   *
   * @param dtls
   * the ids of those Service Plans to be linked to the Service
   * Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public void createLinks(ServicePlanGroupCreateLinksDtls dtls)
    throws AppException, InformationalException {

    // first check if the SPG is active
    final ServicePlanGroupKey spgKey = new ServicePlanGroupKey();

    spgKey.servicePlanGroupId = dtls.servicePlanGroupId;
    final ServicePlanGroupDtls spgDtls = ServicePlanGroupFactory.newInstance().read(
      spgKey);

    if (spgDtls.servicePlanGroupStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(
        BPOSERVICEPLANGROUP.ERR_SPG_MODIFY_ALREADY_CANCELLED);
    }

    // now check if user has selected anything
    final ServicePlanGroupLinkDtlsList inputLinksList = new ServicePlanGroupLinkDtlsList();
    final StringList servicePlanIds = StringUtil.tabText2StringList(
      dtls.servicePlanIds);
    final int numberServicePlanIds = servicePlanIds.size();

    // error if this is < 1
    if (numberServicePlanIds < 1) {
      throw new AppException(
        BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_NO_SP_SELECTED_FOR_LINKING);
    }

    ServicePlanGroupLinkDtls linkDtls = null;
    String servicePlanId = null;

    for (int i = 0; i < numberServicePlanIds; i++) {
      linkDtls = new ServicePlanGroupLinkDtls();
      linkDtls.servicePlanGroupId = dtls.servicePlanGroupId;
      servicePlanId = servicePlanIds.item(i);
      linkDtls.servicePlanID = Long.parseLong(servicePlanId);
      inputLinksList.dtls.addRef(linkDtls);
    }
    final MaintainServicePlanGroupLink linkObj = MaintainServicePlanGroupLinkFactory.newInstance();

    linkObj.createLinks(inputLinksList);
  }

  /**
   * creates a new Service Plan from the details provided and also the link to
   * the Service Plan Group.
   *
   * @param dtls
   * the Service Plan to create and to link to the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public void createServicePlanForServicePlanGroupAndLinkUp(
    ServicePlanGroupSPDetailsAndSPGKey dtls) throws AppException,
      InformationalException {

    // check the SPG status first
    final ServicePlanGroupKey spgKey = dtls.spgKey;
    final ServicePlanGroupDtls spgDtls = ServicePlanGroupFactory.newInstance().read(
      spgKey);

    if (spgDtls.servicePlanGroupStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(
        BPOSERVICEPLANGROUP.ERR_SPG_MODIFY_ALREADY_CANCELLED);
    }
    final curam.serviceplans.sl.intf.ServicePlan servicePlanSLObj = ServicePlanFactory.newInstance();
    final ServicePlanKey spKey = servicePlanSLObj.create(dtls.spDtls);
    final MaintainServicePlanGroupLink linkObj = MaintainServicePlanGroupLinkFactory.newInstance();
    final ServicePlanGroupLinkDtls linkDtls = new ServicePlanGroupLinkDtls();

    linkDtls.servicePlanGroupId = dtls.spgKey.servicePlanGroupId;
    linkDtls.servicePlanID = spKey.key.servicePlanID;
    linkDtls.servicePlanGroupLinkId = UniqueID.nextUniqueID();
    final ServicePlanGroupLinkDtlsList servicePlanGroupLinkDtlsList = new ServicePlanGroupLinkDtlsList();

    servicePlanGroupLinkDtlsList.dtls.addRef(linkDtls);
    linkObj.createLinks(servicePlanGroupLinkDtlsList);
  }

  /**
   * finds all the selectable Service Plans and case member details for the
   * Service Plan Group Delivery record.
   *
   * @param spgDeliveryKey
   * the id of the Service Plan Group Delivery
   * @return ServicePlanAndCaseMemberDetails
   * the details of the Service Plans linked to the Service Plan
   * Group and all members of the Integrated Case
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanAndCaseMemberDetails getLinkedServicePlansAndICMembers(
    SPGDeliveryKey spgDeliveryKey) throws AppException,
      InformationalException {

    final ServicePlanAndCaseMemberDetails planAndCaseMemberDetails = new ServicePlanAndCaseMemberDetails();

    // get the ICMembers
    final ServicePlanDelivery servicePlanDelObj = ServicePlanDeliveryFactory.newInstance();
    // find the IC key
    final SPGDelivery spgDelObj = SPGDeliveryFactory.newInstance();
    final IntegratedCaseIDKey icCaseKey = spgDelObj.readCaseIdByServicePlanGroupDeliveryId(
      spgDeliveryKey);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    // look up the IC participants
    final curam.serviceplans.sl.intf.ServicePlanDelivery slSpd = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey spIcKey = new curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey();

    spIcKey.servicePlanIntegratedCaseKey.caseID = icCaseKey.integratedCaseID;
    final ICMembersAndSPTypesDetails icMembersAndSPTypes = slSpd.getAvailableICMembersAndSPTypes(
      spIcKey);

    // assign the case participants in
    planAndCaseMemberDetails.membersAndTypes.icMembersAndSPTypesDetails.caseParticipantRoleDetailsList = icMembersAndSPTypes.caseParticipantRoleDetailsList;
    final int innerLoopSize = icMembersAndSPTypes.servicePlanTypeDetailsList.dtls.size();

    // if the list is empty, no SPs can be selected, even after filtering
    // against the SPGs
    if (innerLoopSize < 1) {
      final AppException e = new AppException(
        BPOSERVICEPLANDELIVERY.ERR_FV_SP_NO_IC_ASSOCIATION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e, curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else {
      // get the Service Plan types based on those Service Plans linked to
      // this
      // SPG
      final SPGDeliveryDtls spgdDtls = spgDelObj.read(spgDeliveryKey);
      final ServicePlanGroupKey spgKey = new ServicePlanGroupKey();

      spgKey.servicePlanGroupId = spgdDtls.servicePlanGroupId;
      final ServicePlanGroupLinkDtlsList linkedSPs = MaintainServicePlanGroupLinkFactory.newInstance().getAllForServicePlanGroup(
        spgKey);
      final int size = linkedSPs.dtls.size();

      for (int i = 0; i < size; i++) {
        final ServicePlanGroupLinkDtls spgLinkDtl = linkedSPs.dtls.item(i);

        // set up inner loop of Service Plan Types
        innerloop:
        for (int j = 0; j < innerLoopSize; j++) {
          final curam.serviceplans.sl.entity.struct.ServicePlanTypeDetails spTypeDtls = icMembersAndSPTypes.servicePlanTypeDetailsList.dtls.item(
            j);

          // if the sp id matches that of the link record, then
          // capture it
          if (spTypeDtls.servicePlanID == spgLinkDtl.servicePlanID) {
            planAndCaseMemberDetails.membersAndTypes.icMembersAndSPTypesDetails.servicePlanTypeDetailsList.dtls.addRef(
              spTypeDtls);
            break innerloop;
          }
        }
      }

      // set Informational if there are no available Service Plans, the
      // user
      // cannot proceed
      if (planAndCaseMemberDetails.membersAndTypes.icMembersAndSPTypesDetails.servicePlanTypeDetailsList.dtls.size()
        < 1) {

        // create a new Info message
        final AppException e = new AppException(
          BPOSERVICEPLANGROUPDELIVERY.ERR_SPG_NO_SERVICEPLANS_LINKED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          e, curam.core.impl.CuramConst.gkEmpty,
          curam.util.exception.InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

    // grab any messages we need to display to the user
    final String[] infoMessages = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < infoMessages.length; i++) {
      final ServicePlanGroupInfoMessage message = new ServicePlanGroupInfoMessage();

      message.message = infoMessages[i];
      planAndCaseMemberDetails.messages.addRef(message);
    }

    // pass the IC key back to the caller
    final IntegratedCaseKey ick = new IntegratedCaseKey();

    ick.integratedCaseID = icCaseKey.integratedCaseID;
    planAndCaseMemberDetails.icKey = ick;

    // get the context description
    final ServicePlanGroupDeliveryKey facadeSpgdKey = new ServicePlanGroupDeliveryKey();

    facadeSpgdKey.servicePlanGroupDeliveryID = spgDeliveryKey.servicePlanGroupDeliveryId;
    planAndCaseMemberDetails.context = servicePlanDelObj.getServicePlanGroupContextDescription(
      facadeSpgdKey);
    return planAndCaseMemberDetails;
  }

  /**
   * Reads the service plan group details based on service plan group key
   * for update.
   *
   * @param key
   * service plan group identifier
   * @return ServicePlanGroupHomeDtlsForUpdate
   * service plan group home details
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupHomeDtlsForUpdate readForUpdate(
    ServicePlanGroupKey key) throws AppException, InformationalException {

    final ServicePlanGroupHomeDtlsForUpdate dtls = new ServicePlanGroupHomeDtlsForUpdate();

    // do a standard read first
    dtls.homeDtls.spgDtls = MaintainServicePlanGroupFactory.newInstance().read(
      key);

    return dtls;
  }

  /**
   * Gets the Service Plan Group description
   *
   * @param key
   * the id of the Service Plan Group
   * @return ServicePlanGroupDescriptionDtls
   * the description of the Service Plan Group
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupDescriptionDtls getDescription(
    ServicePlanGroupKey key) throws AppException, InformationalException {

    final ServicePlanGroupDescriptionDtls desc = new ServicePlanGroupDescriptionDtls();
    final ServicePlanGroupDtls spgDtls = MaintainServicePlanGroupFactory.newInstance().read(
      key);

    desc.spgName = spgDtls.servicePlanGroupName;
    return desc;
  }

  /**
   * reads just the active Service Plan Groups
   *
   * @return MaintainServicePlanGroupAllActiveDtlsList
   * the list of active Service Plan Groups
   * @throws AppException, InformationalException
   */
  @Override
  public MaintainServicePlanGroupAllActiveDtlsList readAllActive()
    throws AppException, InformationalException {

    return MaintainServicePlanGroupFactory.newInstance().readAllActive();
  }

  /**
   * lists the Service Plans linked to the Service Plan Group
   *
   * @param key
   * the id of the Service Plan Group
   * @return ServicePlanGroupLinkedServicePlanDtlsList
   * the list of linked Service Plans
   * @throws AppException, InformationalException
   */
  @Override
  public ServicePlanGroupLinkedServicePlanDtlsList listServicePlansForServicePlanGroup(ServicePlanGroupKey key)
    throws AppException, InformationalException {

    // struct to return
    final ServicePlanGroupLinkedServicePlanDtlsList linkedServicePlans = new ServicePlanGroupLinkedServicePlanDtlsList();

    // BPOs declared
    final ServicePlan slServicePlanObj = ServicePlanFactory.newInstance();
    final MaintainServicePlanGroupLink linkObj = MaintainServicePlanGroupLinkFactory.newInstance();

    final ServicePlanGroupLinkDtlsList linkDtlsList = linkObj.getAllForServicePlanGroup(
      key);
    final int size = linkDtlsList.dtls.size();

    for (int i = 0; i < size; i++) {
      final ServicePlanGroupLinkDtls servicePlanGroupLinkDtlsObj = linkDtlsList.dtls.item(
        i);
      final ServicePlanGroupLinkedServicePlansDtls servicePlanGroupLinkedServicePlansDtlsObj = new ServicePlanGroupLinkedServicePlansDtls();

      servicePlanGroupLinkedServicePlansDtlsObj.linkDtls = servicePlanGroupLinkDtlsObj;
      final ServicePlanKey spk = new ServicePlanKey();

      spk.key.servicePlanID = servicePlanGroupLinkDtlsObj.servicePlanID;
      final ReadServicePlanDetails spd = slServicePlanObj.read(spk);

      servicePlanGroupLinkedServicePlansDtlsObj.planDtls = spd.plan;
      linkedServicePlans.dtls.addRef(servicePlanGroupLinkedServicePlansDtlsObj);
    }
    return linkedServicePlans;
  }

  // BEGIN, CR00235328, GP
  /**
   * Assigns the text translation details.
   *
   * @param textTranslation
   * The text translation information.
   *
   * @return The text translation details.
   */

  protected TextTranslationDetails assignTextTranslationDtls(
    final TextTranslation textTranslation) {

    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    textTranslationDetails.dtls.localeCode = textTranslation.getLocale().getCode();
    textTranslationDetails.dtls.localizableTextID = textTranslation.getLocalizableTextID();

    final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      textTranslationDetails.dtls.localizableTextID);

    if (localizableTextHandler.isShortTextInd()) {
      textTranslationDetails.dtls.shortText = textTranslation.getShortText();
    } else {
      textTranslationDetails.dtls.text = textTranslation.getText();
    }
    textTranslationDetails.dtls.text = textTranslation.getText();
    textTranslationDetails.dtls.textTranslationID = textTranslation.getID();
    return textTranslationDetails;
  }

  /**
   * Provides text translation for the attribute.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details.
   *
   * @return The view localizable text details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ViewLocalizableTextDetails getTextTranslation(
    final LocalizableTextDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.dtls.localizableTextID);
    final ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();

    viewLocalizableTextDetails.dtls.localizableTextID = localizableTextHandler.getID();

    for (final TextTranslation textTranslation : localizableTextHandler.listTranslations()) {

      final TextTranslationDetails textTranslationDetails = assignTextTranslationDtls(
        textTranslation);

      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);

    }
    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the ServicePlanGroup entity attribute,
   * description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for
   * ServicePlanGroup description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MaintainServicePlanGroupFactory.newInstance().addDescriptionTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the ServicePlanGroup entity
   * attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of ServicePlanGroup
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MaintainServicePlanGroupFactory.newInstance().modifyDescriptionTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the ServicePlanGroup entity attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the ServicePlanGroup description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();
      ServicePlanGroupDtls servicePlanGroupDtls = new ServicePlanGroupDtls();
      final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

      servicePlanGroupKey.servicePlanGroupId = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from ServicePlanGroup entity.
      servicePlanGroupDtls = maintainServicePlanGroupObj.read(
        servicePlanGroupKey);

      textTranslationDetails.dtls.text = servicePlanGroupDtls.servicePlanGroupDesc;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the ServicePlanGroup attribute,
   * description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the ServicePlanGroup description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    final MaintainServicePlanGroup maintainServicePlanGroupObj = MaintainServicePlanGroupFactory.newInstance();
    ServicePlanGroupDtls servicePlanGroupDtls = new ServicePlanGroupDtls();
    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = localizableTextDetails.dtls.localizableTextParentID;

    // As there is no localization yet, read it from ServicePlanGroup entity.
    servicePlanGroupDtls = maintainServicePlanGroupObj.read(servicePlanGroupKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != servicePlanGroupDtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = servicePlanGroupDtls.descriptionTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from SubGoal entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = servicePlanGroupDtls.servicePlanGroupDesc;

      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }
  // END, CR00235328
}
