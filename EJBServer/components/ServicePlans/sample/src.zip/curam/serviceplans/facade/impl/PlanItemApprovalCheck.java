/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;


import curam.core.fact.UsersFactory;
import curam.core.intf.Users;
import curam.core.struct.UsersKey;
import curam.serviceplans.facade.struct.CancelPlanItemApprovalCheckKey;
import curam.serviceplans.facade.struct.PlanItemApprovalCheckDetails;
import curam.serviceplans.facade.struct.PlanItemApprovalCheckDetailsList;
import curam.serviceplans.facade.struct.PlanItemApprovalCheckID;
import curam.serviceplans.facade.struct.PlanItemApprovalCheckUsernameID;
import curam.serviceplans.sl.fact.PlanItemApprovalCheckFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class to implement the plan item approval check facade functionality.
 */
public class PlanItemApprovalCheck extends curam.serviceplans.facade.base.PlanItemApprovalCheck {

  // ___________________________________________________________________________
  /**
   * This method is to cancel plan item approval check for the passed
   * plan approval check key.
   *
   * @param key Unique ID and versionNo of entry to delete
   *
   * @throws AppException,
   * InformationalException
   */
  @Override
  public void cancelPlanItemApprovalCheck(
    final CancelPlanItemApprovalCheckKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    piAppCheckObj.cancelPlanItemApprovalCheck(key.key);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to create a new plan item approval check entry
   *
   *
   * @param details Details used to create the new entry
   *
   * @throws AppException,
   * InformationalException
   */
  @Override
  public void createPlanItemApprovalCheck(PlanItemApprovalCheckDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    piAppCheckObj.createPlanItemApprovalCheck(details.details);
  }

  // ___________________________________________________________________________
  /**
   * This method is to modify an existing plan item approval check entry.
   *
   *
   * @param details Details used to modify the entry
   *
   * @throws AppException,
   * InformationalException
   */
  @Override
  public void modifyPlanItemApprovalCheck(PlanItemApprovalCheckDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    piAppCheckObj.modifyPlanItemApprovalCheck(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Read a plan item approval check entry. This method is used to read the
   * PlanItemApprovalCheck details for the given plan item approval check id.
   *
   * @param key Unique reference to the entry
   *
   * @return PlanItemApprovalCheckDetails - details of the plan item approval
   * that was read
   *
   * @throws AppException,
   * InformationalException
   */
  @Override
  public PlanItemApprovalCheckDetails readPlanItemApprovalCheck(
    PlanItemApprovalCheckID key) throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckDetails details = new PlanItemApprovalCheckDetails();

    details.details.assign(piAppCheckObj.readPlanItemApprovalCheck(key.key));
    details.contextDescription.contextDescription = getPlanItemApprovalCheckContextDescription(
      details.details.dtls.userName);

    return details;
  }

  // ___________________________________________________________________________
  /**
   * This method is to get the list all plan item approval check
   * entries for a given username
   *
   * @param key Username to search against
   *
   * @return PlanItemApprovalCheckDetailsList - list of plan item approval
   * check details that are retrieved for the passed user name
   *
   * @throws AppException,
   * InformationalException
   */
  @Override
  public PlanItemApprovalCheckDetailsList listPlanItemApprovalCheck(
    PlanItemApprovalCheckUsernameID key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItemApprovalCheck piAppCheckObj = PlanItemApprovalCheckFactory.newInstance();

    final PlanItemApprovalCheckDetailsList list = new PlanItemApprovalCheckDetailsList();

    list.detailList.assign(piAppCheckObj.listPlanItemApprovalChecks(key.key));
    list.contextDescription.contextDescription = getPlanItemApprovalCheckContextDescription(
      key.key.userName);
    return list;
  }

  // ___________________________________________________________________________
  /**
   * This method is to read the plan item approval check context description.
   *
   * @param details Details read from database
   *
   * @return String containing the context description
   *
   * @throws AppException,
   * InformationalException
   */
  protected String getPlanItemApprovalCheckContextDescription(
    String strUserName) throws AppException, InformationalException {

    String contextDescription = null;

    // reading the user surname for context description
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = strUserName;

    contextDescription = usersObj.getFullName(usersKey).fullname;

    return contextDescription;
  }

}
