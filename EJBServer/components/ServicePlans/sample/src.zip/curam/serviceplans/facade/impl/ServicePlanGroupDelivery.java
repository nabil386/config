/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.facade.impl;


import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.InformationalMsgDtlsList;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.ISPCaseKeyAndViewActiveKey;
import curam.serviceplans.facade.struct.ServicePlanDeliveryAndServicePlanGroupKey;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryHeaderDtls;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryHomeDtls;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryKey;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryTabDetails;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.fact.MaintainServicePlanGroupDeliveryFactory;
import curam.serviceplans.sl.impl.ServicePlanConst;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.serviceplans.sl.intf.MaintainServicePlanGroupDelivery;
import curam.serviceplans.sl.struct.MilestoneDeliveryDetailsList;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndGroupKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryClosureDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryIDDtls;
import curam.serviceplans.sl.struct.ServicePlanDeliveryIDDtlsList;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryAndActiveIndKey;
import curam.serviceplans.sl.struct.ServicePlanGroupDeliveryInfoMessageDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * Facade layer class to maintain the functionality related to service plan
 * group delivery.
 */
public class ServicePlanGroupDelivery extends curam.serviceplans.facade.base.ServicePlanGroupDelivery {

  /**
   * This method is used to fetch the milestones for the service plan group.
   * Depending upon the value of the indicator which is set in the screen
   * either all the milestone are fetched or only incomplete milestones are
   * fetched. Milestones of all the service plans under the service plan group
   * are fetched.
   *
   * @param ispCaseKey
   * ISPCaseKeyAndViewActiveKey
   * @return MilestoneDeliveryDetailsList
   *
   * @throws InformationalException
   * Standard information exception
   * @throws AppException
   * Standard application exception
   */
  @Override
  public curam.serviceplans.facade.struct.MilestoneDeliveryDetailsList viewMilestone(final ISPCaseKeyAndViewActiveKey ispCaseKey)
    throws AppException, InformationalException {

    final MaintainServicePlanGroupDelivery maintainSPGDeliveryObj = MaintainServicePlanGroupDeliveryFactory.newInstance();

    final CaseIDKey caseIDKey = new CaseIDKey();
    final curam.serviceplans.facade.struct.MilestoneDeliveryDetailsList returnStruct = new curam.serviceplans.facade.struct.MilestoneDeliveryDetailsList();
    // If the indicator is set to true fetch all the milestones else just fetch
    // the milestones in progress and incomplete.
    MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = null;

    caseIDKey.caseID = ispCaseKey.caseID;
    if (ispCaseKey.allMileStones) {
      milestoneDeliveryDetailsList = maintainSPGDeliveryObj.getAllMilestones(
        caseIDKey);
    } else {
      milestoneDeliveryDetailsList = maintainSPGDeliveryObj.getIncompleteMilestones(
        caseIDKey);
    }
    returnStruct.dtlsList.assign(milestoneDeliveryDetailsList);

    return returnStruct;
  }

  /**
   * closes the constituent Service Plan Deliveries
   *
   * @param key
   * the Service Plan Group Delivery Id
   * @param closureDetails
   * the Service Plan Delivery Closure details
   *
   * @return InformationalMsgDtlsList one or more informational messages
   *
   * @throws InformationalException
   * Standard information exception
   * @throws AppException
   * Standard application exception
   */
  @Override
  public InformationalMsgDtlsList close(SPGDeliveryKey key,
    ServicePlanDeliveryClosureDetails closureDetails) throws AppException,
      InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    final MaintainServicePlanGroupDelivery maintainObj = MaintainServicePlanGroupDeliveryFactory.newInstance();

    return maintainObj.close(key, closureDetails, false);
  }

  /**
   * creates the Service Plan Group Delivery
   *
   * @param dtls
   * the Service Plan Group Delivery details
   *
   * @return SPGDeliveryKey the newly created Service Plan Group Delivery's Id
   *
   * @throws InformationalException
   * Standard information exception
   * @throws AppException
   * Standard application exception
   */
  @Override
  public SPGDeliveryKey create(SPGDeliveryDtls dtls) throws AppException,
      InformationalException {

    // set the creation date to today
    dtls.creationDate = Date.getCurrentDate();
    final MaintainServicePlanGroupDelivery maintainServicePlanGroupDeliveryObj = MaintainServicePlanGroupDeliveryFactory.newInstance();

    return maintainServicePlanGroupDeliveryObj.create(dtls);
  }

  /**
   * reads details required to display the Service Plan Group Delivery homepage
   *
   * @param key
   * id of the Service Plan Group Delivery and flag to say whether to
   * show all active child Service Plan Deliveries or not
   *
   * @return ServicePlanGroupDeliveryHomeDtls the details for the home page
   * display
   *
   * @throws InformationalException
   * Standard information exception
   * @throws AppException
   * Standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryHomeDtls readHomePage(
    ServicePlanGroupDeliveryAndActiveIndKey key) throws AppException,
      InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // get the constituent service plan deliveries
    final MaintainServicePlanGroupDelivery maintainSPGD = MaintainServicePlanGroupDeliveryFactory.newInstance();

    final ServicePlanGroupDeliveryHomeDtls homeDtls = new ServicePlanGroupDeliveryHomeDtls();

    final curam.serviceplans.sl.struct.ServicePlanGroupDeliveryHomeDtls slHomeDtls = maintainSPGD.readHomePageDtls(
      key);

    homeDtls.homeDtls = slHomeDtls;

    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    final ServicePlanGroupDeliveryKey spgdKey = new ServicePlanGroupDeliveryKey();

    spgdKey.servicePlanGroupDeliveryID = key.servicePlanGroupDeliveryId;

    homeDtls.menu = servicePlanDeliveryObj.getICServicePlanGroupMenuData(
      spgdKey);

    homeDtls.headerDtls.context = servicePlanDeliveryObj.getServicePlanGroupContextDescription(
      spgdKey);

    // also return the active indicator value
    homeDtls.activeOnly.activeOnly = key.activeInd;
    return homeDtls;
  }

  /**
   * checks if the system will permit the user to close the Service Plan
   * Deliveries related to this Service Plan Group Delivery
   *
   * @param key
   * the Service Plan Group Delivery's Id
   * @param closureDetails
   * the Service Plan Delivery Closure details
   *
   * @return ServicePlanGroupDeliveryHeaderDtls header details for displaying
   * the page
   *
   * @throws InformationalException
   * Standard information exception
   * @throws AppException
   * Standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryHeaderDtls getServicePlansClosureValidation(
    SPGDeliveryKey key, ServicePlanDeliveryClosureDetails closureDetails)
    throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Since the user won't be able to select the closure reason by this stage
    // we just need to set one for them, to avoid a meaningless error
    closureDetails.spClosureNoteReasonDateDetails.reasonCode = ServicePlanConst.kNonEmptyString;
    final curam.serviceplans.sl.intf.ServicePlanDelivery spdObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    final MaintainServicePlanGroupDelivery maintainSPGD = MaintainServicePlanGroupDeliveryFactory.newInstance();

    final InformationalManager im = TransactionInfo.getInformationalManager();
    final ServicePlanDeliveryIDDtlsList spdIdsList = maintainSPGD.getServicePlanDeliveryIDs(
      key);

    final ServicePlanDeliveryKey spdKey = new ServicePlanDeliveryKey();

    final int spdIdsListSize = spdIdsList.dtls.size();

    for (int i = 0; i < spdIdsListSize; i++) {
      final ServicePlanDeliveryIDDtls spdId = spdIdsList.dtls.item(i);

      spdKey.key.caseID = spdId.servicePlanDeliveryID;
      // try and validate the close details for each SPD
      try {
        // BEGIN, CR00234272, TV
        spdObj.validateCloseInfo(spdKey, closureDetails, false);
        // END, CR00234272
      } catch (final AppException ae) {
        im.addInformationalMsg(ae, "", InformationalType.kWarning);
      }
    }

    // now loop through the potential info error messages
    final ServicePlanGroupDeliveryHeaderDtls headerDtls = new ServicePlanGroupDeliveryHeaderDtls();
    final String infoMessages[] = im.obtainInformationalAsString();

    for (int i = 0; i < infoMessages.length; i++) {
      final ServicePlanGroupDeliveryInfoMessageDtls msgDtls = new ServicePlanGroupDeliveryInfoMessageDtls();

      msgDtls.message = infoMessages[i];
      headerDtls.messages.addRef(msgDtls);
    }
    // look up the header details
    final curam.serviceplans.facade.intf.ServicePlanDelivery facadeSPDObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
    final ServicePlanGroupDeliveryKey spgdKey = new ServicePlanGroupDeliveryKey();

    spgdKey.servicePlanGroupDeliveryID = key.servicePlanGroupDeliveryId;
    headerDtls.context = facadeSPDObj.getServicePlanGroupContextDescription(
      spgdKey);
    return headerDtls;
  }

  /**
   * Creates a new service plan group delivery and link it with service plan.
   *
   * @param key
   * Service Plan Delivery And Service Plan GroupKey key
   * @return Service Plan Group Delivery Key
   *
   * @throws InformationalException
   * Standard information exception
   * @throws AppException
   * Standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryKey createAndLinkWithServicePlanDelivery(
    ServicePlanDeliveryAndServicePlanGroupKey key) throws AppException,
      InformationalException {

    // struct to return
    final ServicePlanGroupDeliveryKey returnKey = new ServicePlanGroupDeliveryKey();

    final ServicePlanDeliveryAndGroupKey keys = new ServicePlanDeliveryAndGroupKey();

    // populate the key struct for the SL method
    keys.assign(key);
    final SPGDeliveryKey spgdKey = MaintainServicePlanGroupDeliveryFactory.newInstance().createAndLinkWithServicePlanDelivery(
      keys);

    returnKey.servicePlanGroupDeliveryID = spgdKey.servicePlanGroupDeliveryId;

    return returnKey;
  }

  // BEGIN, CR00211672, CSH
  // _________________________________________________________________________
  /**
   * Reads the details for display on the Service Plan Group Delivery tab.
   *
   * @param key
   * The unique identifier of the assistance case.
   * @return ServicePlanGroupDeliveryTabDetails
   *
   * @throws InformationalException Standard information exception
   * @throws AppException Standard application exception
   */
  @Override
  public ServicePlanGroupDeliveryTabDetails readServicePlanGroupDeliveryTabDetails(
    ServicePlanGroupDeliveryAndActiveIndKey key) throws AppException,
      InformationalException {

    // Register the service plan security implementation.
    ServicePlanSecurityImplementationFactory.register();

    final ServicePlanGroupDeliveryTabDetails tabDetails = new ServicePlanGroupDeliveryTabDetails();

    // Service layer Integrated Service Plan Home Page details
    final MaintainServicePlanGroupDelivery maintainServicePlanGroupDelivery = MaintainServicePlanGroupDeliveryFactory.newInstance();

    tabDetails.tabDtls = maintainServicePlanGroupDelivery.readServicePlanGroupDeliveryTabDetails(
      key);

    return tabDetails;
  }
  // END, CR00211672

}
