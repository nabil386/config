/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;


import curam.codetable.PLANITEMNAME;
import curam.serviceplans.facade.struct.PlannedItemIDKey;
import curam.serviceplans.facade.struct.PlannedItemTabDtls;
import curam.serviceplans.facade.struct.ServicePlanHomeTabDetails;
import curam.serviceplans.facade.struct.ServicePlanTabKey;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.fact.ServicePlanTabFactory;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This facade class provides the functionality for the Service Plan Tab detail
 * facade layer.
 */
public abstract class ServicePlanTab extends curam.serviceplans.facade.base.ServicePlanTab {

  /**
   * Reads the details for the details tab for service plan plan item.
   *
   * @param PlannedItemCaseKey
   * Contains the planned item and the case unique identifiers.
   *
   * @return PlannedItemTabDtls The details to be displayed on the details tab.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PlannedItemTabDtls readPlanItemTabDetails(
    final PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    final PlannedItemTabDtls plannedItemTabDtls = new PlannedItemTabDtls();

    plannedItemTabDtls.dtls = ServicePlanTabFactory.newInstance().readPlanItemTabDetails(
      plannedItemIDKey.plannedItemIDKey);

    // BEGIN, CR00236077, NS
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlanItemIDDetailsStruct planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
      plannedItemIDKey.plannedItemIDKey.plannedItemIDKey);

    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = planItemIDDetailsStruct.planItemID;
    final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
      planItemKey);

    if (nameNotEditableIndDetails.nameNotEditableInd) {
      plannedItemTabDtls.dtls.name = CodeTable.getOneItem(
        PLANITEMNAME.TABLENAME, nameNotEditableIndDetails.name,
        TransactionInfo.getProgramLocale());
    }
    // END, CR00236077

    // If plan item name is "Service Unit Delivery"
    if (plannedItemTabDtls.dtls.name.equals(
      CodeTable.getOneItem(PLANITEMNAME.TABLENAME,
      PLANITEMNAME.SERVICEUNITDELIVERY, TransactionInfo.getProgramLocale()))) {
      plannedItemTabDtls.displayUnitsInd = true;
    } else {
      plannedItemTabDtls.displayUnitsInd = false;
    }

    return plannedItemTabDtls;
  }

  /**
   * Reads the details for the details tab for service plan.
   *
   * @param ServicePlanDeliveryKey
   * Contains the service plan delivery case unique identifier.
   *
   * @return ServicePlanHomeTabDetails The details to be displayed on the
   * details tab.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ServicePlanHomeTabDetails readServicePlanTabDetails(
    ServicePlanTabKey key) throws AppException, InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    final ServicePlanHomeTabDetails servicePlanHomeTabDetails = new ServicePlanHomeTabDetails();

    servicePlanHomeTabDetails.dtls = ServicePlanTabFactory.newInstance().readServicePlanTabDetails(
      key.key);

    return servicePlanHomeTabDetails;
  }

}
