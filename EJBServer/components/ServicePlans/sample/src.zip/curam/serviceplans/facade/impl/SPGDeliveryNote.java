/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;

import curam.core.impl.NoteType;
import curam.core.impl.NoteUtil;
import curam.core.sl.entity.struct.NoteSummaryDetails;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetails;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList1;
import curam.serviceplans.facade.struct.SPGDeliveryNoteKey;
import curam.serviceplans.facade.struct.SPGDeliveryNoteLockedStatusDetails;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryKey;
import curam.serviceplans.sl.entity.fact.SPGDeliveryNoteLinkFactory;
import curam.serviceplans.sl.entity.intf.SPGDeliveryNoteLink;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkKey;
import curam.serviceplans.sl.fact.MaintainSPGDeliveryNoteFactory;
import curam.serviceplans.sl.intf.MaintainSPGDeliveryNote;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;

/**
 * This API is used to maintain the notes for service plan group delivery.
 */
public class SPGDeliveryNote
    extends curam.serviceplans.facade.base.SPGDeliveryNote {

  /**
   * This method is used to create note for service plan group delivery.
   *
   * @param noteDetails
   *          has the details of the note which need to be recorded
   * @return SPGDeliveryAttachmentLinkKey has the id of the attachment link key
   *         which gets created
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public SPGDeliveryNoteLinkKey createNote(
      final SPGDeliveryNoteDetails noteDetails)
      throws AppException, InformationalException {

    final MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj = MaintainSPGDeliveryNoteFactory
        .newInstance();

    final SPGDeliveryNoteLinkKey SPGDeliveryNoteLinkKey = maintainSPGDeliveryNoteObj
        .createNote(noteDetails);

    return SPGDeliveryNoteLinkKey;
  }

  // BEGIN, CR00240923 PDN
  /**
   * This method is used to list all the notes for service plan group delivery.
   *
   * @param key
   *          id of the service plan group delivery key
   * @return SPGDeliveryNoteDetailsList list of service plan group delivery key
   *         details.
   * @throws AppException,
   *           InformationalException
   * @deprecated - replaced by {@link #listNotesByGroupDeliveryID()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  @Override
  public SPGDeliveryNoteDetailsList listNotesByGroupDeliveryID(
      final SPGDeliveryKey key) throws AppException, InformationalException {

    final SPGDeliveryNoteDetailsList spgDeliveryNoteDetailsList = new SPGDeliveryNoteDetailsList();

    final SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList1 = listNotesByGroupDeliveryID1(
        key);

    spgDeliveryNoteDetailsList.assign(spgDeliveryNoteDetailsList1);

    return spgDeliveryNoteDetailsList;
  }

  /**
   * This method is used to list all the notes for service plan group delivery.
   *
   * @param key
   *          id of the service plan group delivery key
   * @return SPGDeliveryNoteDetailsList list of service plan group delivery key
   *         details.
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public SPGDeliveryNoteDetailsList1 listNotesByGroupDeliveryID1(
      final SPGDeliveryKey key) throws AppException, InformationalException {

    final MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj = MaintainSPGDeliveryNoteFactory
        .newInstance();

    final SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList = maintainSPGDeliveryNoteObj
        .listNotesByGroupDeliveryID1(key);

    // Create the objects for menu and context description
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    final ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey = new ServicePlanGroupDeliveryKey();

    servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID = key.servicePlanGroupDeliveryId;

    // Get the menu data
    spgDeliveryNoteDetailsList.menuData = servicePlanDeliveryObj
        .getICServicePlanGroupMenuData(servicePlanGroupDeliveryKey);

    // Get the context description
    spgDeliveryNoteDetailsList.contextDescription = servicePlanDeliveryObj
        .getServicePlanGroupContextDescription(servicePlanGroupDeliveryKey);

    return spgDeliveryNoteDetailsList;
  }

  // END, CR00240923

  /**
   * This method is used to modify the notes for service plan group delivery.
   *
   * @param noteDetails
   *          modified note details
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public void modifyNote(final SPGDeliveryNoteDetails noteDetails)
      throws AppException, InformationalException {

    final MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj = MaintainSPGDeliveryNoteFactory
        .newInstance();

    maintainSPGDeliveryNoteObj.modifyNote(noteDetails);
  }

  /**
   * This method is used to remove the notes for service plan group delivery.
   *
   * @param noteDetails
   *          details of the note to be removed
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public void removeNote(final SPGDeliveryNoteDetails noteDetails)
      throws AppException, InformationalException {

    final MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj = MaintainSPGDeliveryNoteFactory
        .newInstance();

    maintainSPGDeliveryNoteObj.removeNote(noteDetails);
  }

  /**
   * This method is used to view the notes for service plan group delivery.
   *
   * @param key
   *          has the note link id of the record which needs to be returned.
   * @return SPGDeliveryNoteDetails details of the service plan group delivery
   *         note
   * @throws AppException,
   *           InformationalException
   */
  @Override
  public SPGDeliveryNoteDetails viewNote(final SPGDeliveryNoteKey key)
      throws AppException, InformationalException {

    final MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj = MaintainSPGDeliveryNoteFactory
        .newInstance();

    final SPGDeliveryNoteLinkKey spgdDeliveryNoteLinkKey = new SPGDeliveryNoteLinkKey();

    spgdDeliveryNoteLinkKey.spgDeliveryNoteLinkId = key.spgDeliveryNoteLinkId;

    final SPGDeliveryNoteDetails spgDeliveryNoteDetails = maintainSPGDeliveryNoteObj
        .viewNote(spgdDeliveryNoteLinkKey);

    // Create the objects for menu and context description
    final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    final ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey = new ServicePlanGroupDeliveryKey();

    servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID = key.servicePlanGroupDeliveryId;

    // Get the menu data
    spgDeliveryNoteDetails.menuData = servicePlanDeliveryObj
        .getICServicePlanGroupMenuData(servicePlanGroupDeliveryKey);

    // display message relating to a note being editable or locked
    if (spgDeliveryNoteDetails.noteEditDetails.noteEditableInd) {
      // message for editable
      final LocalisableString editableMessage = new LocalisableString(
          curam.message.NOTE.INF_NOTE_EDITABLE_UNTIL);

      editableMessage
          .arg(spgDeliveryNoteDetails.noteEditDetails.editPeriodEndDateTime);

      spgDeliveryNoteDetails.editableNoteMessageOpt = editableMessage
          .toClientFormattedText();
    } else if (spgDeliveryNoteDetails.noteEditDetails.noteLockedInd) {
      // message for locked
      final LocalisableString lockedMessage = new LocalisableString(
          curam.message.NOTE.INF_NOTE_LOCKED_UNTIL);

      lockedMessage.arg(spgDeliveryNoteDetails.fullname);
      lockedMessage
          .arg(spgDeliveryNoteDetails.noteEditDetails.editPeriodEndDateTime);

      spgDeliveryNoteDetails.editableNoteMessageOpt = lockedMessage
          .toClientFormattedText();

    }

    // the note field label is different depending on whether the note text is
    // to be edited or appended.
    if (spgDeliveryNoteDetails.noteEditDetails.noteEditableInd) {
      spgDeliveryNoteDetails.noteTextFieldLabelOpt = curam.message.NOTE.INF_EDIT_NOTE_LABEL
          .getMessageText(TransactionInfo.getProgramLocale());
    } else {
      spgDeliveryNoteDetails.noteTextFieldLabelOpt = curam.message.NOTE.INF_APPEND_NOTE_LABEL
          .getMessageText(TransactionInfo.getProgramLocale());
    }

    /*
     * Different screens that use this facade interface have different
     * requirements for displaying the note history - in some instances the
     * rendered history includes a html link to a User page, in other instances
     * the rendered history should not include a link. Although the string
     * details are the same, 2 different attributes with corresponding domain
     * definitions to the 2 different renderers are required.
     *
     * The note history does not contain the latest note if the status is
     * editable.
     */
    if (spgDeliveryNoteDetails.noteEditDetails.noteEditableInd) {
      final NoteUtil noteUtil = new NoteUtil();
      final String noteHistoryWithoutLatestEntry = noteUtil
          .getNoteHistoryWithoutLatestNote(
              spgDeliveryNoteDetails.noteDtls.notesText);
      spgDeliveryNoteDetails.noteHistoryWithoutUserLinksOpt = noteHistoryWithoutLatestEntry;
    } else {
      spgDeliveryNoteDetails.noteHistoryWithoutUserLinksOpt = spgDeliveryNoteDetails.noteDtls.notesText;
    }

    return spgDeliveryNoteDetails;
  }

  /**
   * Returns details on whether a note has been locked against editing for the
   * current user, because it is still being edited by another user.
   *
   * @param contains
   *          the unique id of the SPG delivery note.
   * @return details containing an indicator which is set to true if the note is
   *         locked against editing.
   */
  @Override
  public SPGDeliveryNoteLockedStatusDetails readNoteLockedStatus(
      final SPGDeliveryNoteKey key)
      throws AppException, InformationalException {

    final SPGDeliveryNoteLockedStatusDetails lockedStatusDetails = new SPGDeliveryNoteLockedStatusDetails();

    final SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory
        .newInstance();

    final SPGDeliveryNoteLinkKey noteLinkKey = new SPGDeliveryNoteLinkKey();
    noteLinkKey.spgDeliveryNoteLinkId = key.spgDeliveryNoteLinkId;
    final NoteSummaryDetails summaryDetails = spgDeliveryNoteLinkObj
        .readNoteSummaryDetails(noteLinkKey);

    final NoteUtil noteUtil = new NoteUtil();
    lockedStatusDetails.noteLockedInd = noteUtil.isNoteLocked(
        summaryDetails.userName, summaryDetails.latestNoteCreationDateTime,
        NoteType.NOTE);

    return lockedStatusDetails;

  }

}
