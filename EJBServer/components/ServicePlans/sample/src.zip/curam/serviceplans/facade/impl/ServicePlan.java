/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.facade.impl;


import com.google.inject.Inject;
import curam.codetable.CASETYPECODE;
import curam.codetable.OUTCOMENAME;
import curam.codetable.SERVICEPLANAPPROVALCHECK;
import curam.core.facade.struct.MilestoneConfigurationDtls;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.MilestoneLinkDtls;
import curam.core.sl.entity.struct.MilestoneLinkKey;
import curam.core.sl.fact.MilestoneConfigurationFactory;
import curam.core.sl.fact.MilestoneLinkFactory;
import curam.core.sl.intf.MilestoneConfiguration;
import curam.core.sl.intf.MilestoneLink;
import curam.core.sl.struct.AddMilestoneKey;
import curam.core.sl.struct.CaseType;
import curam.core.sl.struct.CaseTypeIDAndType;
import curam.core.sl.struct.MilestoneConfigurationLinkDetailsList;
import curam.core.sl.struct.MilestoneConfigurationSummaryDtlsList;
import curam.core.sl.struct.MilestoneLinkConfigDetails;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOPLANTEMPLATE;
import curam.message.BPOSERVICEPLAN;
import curam.serviceplans.facade.fact.ServicePlanFactory;
import curam.serviceplans.facade.struct.*;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.fact.GoalFactory;
import curam.serviceplans.sl.fact.GoodCauseFactory;
import curam.serviceplans.sl.fact.OutcomeFactory;
import curam.serviceplans.sl.fact.PlanItemFactory;
import curam.serviceplans.sl.fact.PlanTemplateFactory;
import curam.serviceplans.sl.fact.PlanTemplateTreeFactory;
import curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory;
import curam.serviceplans.sl.fact.ServicePlanUtilityFactory;
import curam.serviceplans.sl.fact.SubGoalFactory;
import curam.serviceplans.sl.intf.Goal;
import curam.serviceplans.sl.intf.GoodCause;
import curam.serviceplans.sl.intf.Outcome;
import curam.serviceplans.sl.intf.PlanItem;
import curam.serviceplans.sl.intf.PlanTemplate;
import curam.serviceplans.sl.intf.PlanTemplateTree;
import curam.serviceplans.sl.intf.ServicePlanApprovalCheck;
import curam.serviceplans.sl.intf.ServicePlanUtility;
import curam.serviceplans.sl.intf.SubGoal;
import curam.serviceplans.sl.struct.ApprovalCriteriaKeyList;
import curam.serviceplans.sl.struct.PlanItemOutcomeKey;
import curam.serviceplans.sl.struct.PlanTemplateAndPlanItemDetails;
import curam.serviceplans.sl.struct.PlanTemplateAndPlanItemModifyDetails;
import curam.serviceplans.sl.struct.PlanTemplateAndSubGoalReadDetails;
import curam.serviceplans.sl.struct.ReadPlanTemplateDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.workspaceservices.facade.struct.LocalizableTextDetails;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.facade.struct.ViewLocalizableTextDetails;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.impl.TextTranslation;
import curam.workspaceservices.localization.impl.TextTranslationDAO;


/**
 * This process class provides the functionality for the ServicePlan
 * facade layer.
 */

public abstract class ServicePlan extends curam.serviceplans.facade.base.ServicePlan {

  // BEGIN, CR00096677, SK
  protected static final String kCodeTableLanguage = EnvVars.ENV_DEFAULT_LOCALE_DEFAULT;

  // END, CR00096677

  // BEGIN, CR00226647, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  @Inject
  private TextTranslationDAO textTranslationDAO;

  /**
   * Default constructor.
   */
  public ServicePlan() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00226647

  // BEGIN, CR00047848, CM
  // _________________________________________________________________________
  /**
   * Adds a set of existing milestones to the service plan.
   *
   * @param key Identifies the service plan key and the milestoneTabList to
   * be added.
   */
  @Override
  public void addExistingMilestonesToServicePlan(AddMilestoneKey key)
    throws AppException, InformationalException {

    // Milestone Link business process object.
    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    final CaseType caseType = new CaseType();

    caseType.caseType = CASETYPECODE.SERVICEPLAN;

    // add existing milestone configuration to service plan
    milestoneLinkObj.addExistingMilestone(key, caseType);

  }

  // _________________________________________________________________________

  // BEGIN, CR00145972, MC
  /**
   * This method helps to add the existing milestone to a selected service plan
   * from
   * list of milestones which was created earlier for different products.
   *
   * @param key AddMilestoneKey - This key will have the value of case type ID
   * and
   * list of milestone configuration ID selected by the user.
   *
   * @param configDetails MilestoneLinkConfigDetails - The config details
   * contain details
   * such as creation completion event details along with the component category
   * and
   * the component type.
   */

  @Override
  public void addExistingMilestoneWithConfigDetails(AddMilestoneKey key,
    MilestoneLinkConfigDetails configDetails) throws AppException,
      InformationalException {

    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    final CaseType caseType = new CaseType();

    caseType.caseType = CASETYPECODE.SERVICEPLAN;

    milestoneLinkObj.addExistingMilestoneWithConfigDetails(key, caseType,
      configDetails);

  }

  // END, CR00145972

  // _________________________________________________________________________
  /**
   * Creates a new milestone configuration and then creates the link between
   * the milestone and the service plan.
   *
   * @param key Identifies the service plan key.
   * @param details Identifies the milestone configuration details
   */
  @Override
  public void createMilestoneForServicePlan(ServicePlanKey key,
    MilestoneConfigurationDtls details) throws AppException,
      InformationalException {

    // Milestone service layer object.
    final MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // MilestoneLink service layer object
    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // create a milestone configuration
    milestoneObj.create(details.dtls);

    // Set the milestone link details to create the link
    final MilestoneLinkDtls milestoneLinkDtls = new MilestoneLinkDtls();

    milestoneLinkDtls.caseTypeID = key.servicePlanID;
    milestoneLinkDtls.caseType = CASETYPECODE.SERVICEPLAN;
    milestoneLinkDtls.milestoneConfigurationID = details.dtls.dtls.milestoneConfigurationID;

    milestoneLinkDtls.creationEvent = details.creationEvent;
    milestoneLinkDtls.completionEvent = details.completionEvent;

    final String components = details.components;

    if (components != null && components.trim().length() > 0) {
      final String[] comps = components.split(CuramConst.gkComma);

      milestoneLinkDtls.componentCategory = comps[0];
      if (comps.length == 2) {
        milestoneLinkDtls.componentType = comps[1];
      }

    }

    // create milestone link
    milestoneLinkObj.create(milestoneLinkDtls);

  }

  // _________________________________________________________________________
  // BEGIN, CR00233651, GP
  /**
   * Lists all the milestones which are currently associated with a particular
   * service plan.
   *
   * @param key Identifies the service plan key
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# listServicePlanMilestones()} as part of implementing
   * localization of
   * milestone attributes. See release note: CR00233651.
   */
  @Override
  @Deprecated
  // END, CR00233651
  public curam.core.sl.struct.MilestoneConfigurationLinkDtlsList listMilestonesForServicePlan(ServicePlanKey key) throws AppException,
      InformationalException {

    // return struct
    // BEGIN, CR00233651, GP
    curam.core.sl.struct.MilestoneConfigurationLinkDtlsList milestoneConfigurationLinkDtlsList = new curam.core.sl.struct.MilestoneConfigurationLinkDtlsList();
    // END, CR00233651

    // Milestone Link business process object.
    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // Context description key
    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    final CaseTypeIDAndType caseTypeIDAndType = new CaseTypeIDAndType();

    caseTypeIDAndType.caseType = curam.codetable.CASECATEGORY.SERVICEPLAN;
    caseTypeIDAndType.caseTypeID = key.servicePlanID;

    milestoneConfigurationLinkDtlsList = milestoneLinkObj.listMilestonesForCaseTypeAndID(
      caseTypeIDAndType);

    // read service plan context description
    readServicePlanKey.key.key.servicePlanID = key.servicePlanID;

    // gets service plan context description
    milestoneConfigurationLinkDtlsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return milestoneConfigurationLinkDtlsList;
  }

  // BEGIN, CR00233651, GP
  /**
   * Lists all the milestones which are currently associated with a particular
   * service plan.
   *
   * @param key contains the service plan key.
   * @return the milestone configuration link details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public MilestoneConfigurationLinkDetailsList listServicePlanMilestones(
    ServicePlanKey key) throws AppException, InformationalException {

    MilestoneConfigurationLinkDetailsList milestoneConfigurationLinkDetailsList = new MilestoneConfigurationLinkDetailsList();

    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();
    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    final CaseTypeIDAndType caseTypeIDAndType = new CaseTypeIDAndType();

    caseTypeIDAndType.caseType = curam.codetable.CASECATEGORY.SERVICEPLAN;
    caseTypeIDAndType.caseTypeID = key.servicePlanID;

    milestoneConfigurationLinkDetailsList = milestoneLinkObj.listAssociatedMilestonesForCaseTypeAndID(
      caseTypeIDAndType);

    readServicePlanKey.key.key.servicePlanID = key.servicePlanID;

    // Get service plan context description.
    milestoneConfigurationLinkDetailsList.contextDescription.contextDescription = getServicePlanContextDescription(readServicePlanKey).contextDescription;

    return milestoneConfigurationLinkDetailsList;
  }

  // END, CR00233651

  // _________________________________________________________________________
  /**
   * Lists all the active milestones not already associated with a particular
   * service plan.
   *
   * @param key Identifies the service plan key
   */
  @Override
  public MilestoneConfigurationSummaryDtlsList listUnassociatedMilestone(
    ServicePlanKey key) throws AppException, InformationalException {

    // return struct
    MilestoneConfigurationSummaryDtlsList milestoneDtlsList = new MilestoneConfigurationSummaryDtlsList();

    // Context description key
    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    // read service plan context description
    readServicePlanKey.key.key.servicePlanID = key.servicePlanID;

    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();
    final CaseTypeIDAndType caseTypeIDAndType = new CaseTypeIDAndType();

    caseTypeIDAndType.caseType = curam.codetable.CASECATEGORY.SERVICEPLAN;
    caseTypeIDAndType.caseTypeID = key.servicePlanID;
    milestoneDtlsList = milestoneLinkObj.listUnassociatedMilestones(
      caseTypeIDAndType);

    // gets service plan context description
    milestoneDtlsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return milestoneDtlsList;

  }

  // _________________________________________________________________________
  /**
   * Removes the link between a milestone and a service plan.
   *
   * @param key Identifies the milestone link key
   */
  @Override
  public void removeMilestoneFromServicePlan(MilestoneLinkKey key)
    throws AppException, InformationalException {

    // Milestone Link business process object.
    final MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // removes the link between the milestone and the service plan
    milestoneLinkObj.remove(key);

  }

  // END, CR00047848

  // _________________________________________________________________________
  /**
   * Adds a set of existing goals to the service plan.
   *
   * @param key Identifies the service plan and the goals to be added.
   */
  @Override
  public void addExistingGoalsToServicePlan(
    AddExistingGoalsToServicePlanDetails key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create structure and object to parse goal tab list
    curam.serviceplans.sl.struct.GoalKeyList goalKeyList;

    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();

    // parse goal tab list
    goalKeyList = servicePlanUtilityObj.parseGoals(key.goalTabList);

    // add list of goals to service plan
    servicePlanObj.addExistingGoals(key.servicePlanKey, goalKeyList);

  }

  // _________________________________________________________________________
  /**
   * Adds a set of existing templates to the service plan.
   *
   * @param key Identifies the service plan and the templates to be added.
   */
  @Override
  public void addExistingTemplatesToServicePlan(
    AddExistingTemplateToServicePlanDetails key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();

    curam.serviceplans.sl.struct.PlanTemplateKeyList planTemplateKeyList;

    // parse template tab list
    planTemplateKeyList = servicePlanUtilityObj.parsePlanTemplates(
      key.planTemplateTabList);

    servicePlanObj.addExistingTemplates(key.servicePlanKey, planTemplateKeyList);

  }

  // _________________________________________________________________________
  /**
   * Adds an integrated case to the service plan.
   *
   * @param key Identifies the integrated case through a case id and the
   * service plan.
   */
  @Override
  public void addICToServicePlan(AddICToServicePlanKey key)
    throws AppException, InformationalException {

    // create object and structures from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();

    curam.serviceplans.sl.struct.IntegratedCaseIDList integratedCaseIDList = new curam.serviceplans.sl.struct.IntegratedCaseIDList();

    // parse tab delimited string of integrated case IDs to list of
    // integrated cases ID
    integratedCaseIDList = servicePlanUtilityObj.parseIntegratedCases(
      key.tabList);

    // add integrated case to service plan
    servicePlanObj.addICToServicePlan(key.servicePlanKey, integratedCaseIDList);
  }

  // ___________________________________________________________________________
  /**
   * Cancels a service plan.
   *
   * @param key Identifies the service plan to be canceled
   */
  @Override
  public void cancel(CancelServicePlanKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    servicePlanObj.cancel(key.cancelDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates a service plan.
   *
   * @param details The details with which to create the service plan.
   * @return The key of the newly created service plan.
   */
  @Override
  public CreateServicePlanKey create(CreateServicePlanDetails details)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create return structure
    final CreateServicePlanKey createServicePlanKey = new CreateServicePlanKey();

    createServicePlanKey.key = servicePlanObj.create(details.details);

    return createServicePlanKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates a new goal and associates it with the service plan.
   *
   * @param details Contains the details necessary to create the new goal and
   * the key of the service plan to which to attach it.
   *
   * @return A key containing the key of the new goal.
   */
  @Override
  public CreateGoalForServicePlanKey createGoalForServicePlan(
    CreateGoalForServicePlanDetails details) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.struct.ServicePlanKey();

    final curam.serviceplans.sl.struct.GoalKeyList goalKeyList = new curam.serviceplans.sl.struct.GoalKeyList();

    final CreateGoalForServicePlanKey createGoalForServicePlanKey = new CreateGoalForServicePlanKey();

    servicePlanKey = details.servicePlanKey;

    createGoalForServicePlanKey.key = servicePlanObj.createGoal(details.details,
      servicePlanKey);

    goalKeyList.goalKey.add(createGoalForServicePlanKey.key);

    servicePlanObj.addExistingGoals(servicePlanKey, goalKeyList);

    return createGoalForServicePlanKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists the service plans that exist on the systems.
   *
   * @return A list of the service plans.
   */
  @Override
  public ListServicePlanDetailsList list() throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create return structure
    final ListServicePlanDetailsList listServicePlanDetailsList = new ListServicePlanDetailsList();

    // call corresponding method from service layer
    listServicePlanDetailsList.list = servicePlanObj.list();

    return listServicePlanDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists the goals associated with a specific service plan.
   *
   * @param key Contains the key of the service plan for which the goals are
   * required.
   *
   * @return A list of goals that match the service plan key.
   */
  @Override
  public ListGoalsForServicePlanDetailsList listGoalsForServicePlan(
    ListGoalsForServicePlanKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final ListGoalsForServicePlanDetailsList listGoalsForServicePlanDetailsList = new ListGoalsForServicePlanDetailsList();

    listGoalsForServicePlanDetailsList.list = servicePlanObj.listGoals(key.key);

    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    readServicePlanKey.key = key.key;

    // read context description
    listGoalsForServicePlanDetailsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return listGoalsForServicePlanDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the goals not associated with a specific service plan. These will
   * probably then be selected for addition to the service plan.
   *
   * @param key Contains the key of the service plan for which the goals are
   * required.
   *
   * @return A list of goals that do not match the service plan key.
   */
  @Override
  public ListGoalsNotAssociatedWithServicePlanDetailsList listGoalsNotAssociatedWithServicePlan(
    ListGoalsNotAssociatedWithServicePlanKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final ListGoalsNotAssociatedWithServicePlanDetailsList listGoalsNotAssociatedWithServicePlanDetailsList = new ListGoalsNotAssociatedWithServicePlanDetailsList();

    listGoalsNotAssociatedWithServicePlanDetailsList.list = servicePlanObj.listUnassociatedGoals(
      key.key);

    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    readServicePlanKey.key = key.key;

    // read context description
    listGoalsNotAssociatedWithServicePlanDetailsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return listGoalsNotAssociatedWithServicePlanDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the integrated cases that are not associated with a service plan.
   * These will probably then be selected for addition to the service plan.
   *
   * @param key Contains the key of the service plan for which the integrated
   * cases are required.
   * @return A list of integrated cases that have not yet been associated
   * with the service plan.
   */
  @Override
  public ListICNotAssociatedWithServicePlanDetailsList listICNotAssociatedWithServicePlan(
    ListICNotAssociatedWithServicePlanKey key) throws AppException,
      InformationalException {

    // create objects and structure from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create return structure
    final ListICNotAssociatedWithServicePlanDetailsList listICNotAssociatedWithServicePlanDetailsList = new ListICNotAssociatedWithServicePlanDetailsList();

    // list integrated cases still not associated with service plan
    listICNotAssociatedWithServicePlanDetailsList.list = servicePlanObj.listICNotAssociatedWithServicePlan(
      key.key);

    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    readServicePlanKey.key = key.key;

    // read context description
    listICNotAssociatedWithServicePlanDetailsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return listICNotAssociatedWithServicePlanDetailsList;

  }

  // _________________________________________________________________________
  /**
   * Removes Integrated case from the service plan.
   *
   * @param removeKey contains service plan key and integrated case ID
   */
  @Override
  public void removeICFromServicePlan(RemoveICFromServicePlanKey removeKey)
    throws AppException, InformationalException {

    // create objects and structure from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    servicePlanObj.removeICFromServicePlan(removeKey.key);

  }

  // ___________________________________________________________________________
  /**
   * Lists the integrated cases associated with the service plan.
   *
   * @param key A key containing the service plan key for which the cases
   * are required.
   *
   * @return A list of integrated cases that are associated with the service
   * plan.
   */
  @Override
  public ListServicePlanICDetailsList listServicePlanIC(
    ListServicePlanICKey key) throws AppException, InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create return structure
    final ListServicePlanICDetailsList listServicePlanICDetailsList = new ListServicePlanICDetailsList();

    // create structure and object to list integrated cases for service plan
    listServicePlanICDetailsList.list = servicePlanObj.listServicePlanIC(
      key.key);

    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    readServicePlanKey.key = key.key;

    // read context description
    listServicePlanICDetailsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return listServicePlanICDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the templates that are associated with the service plan.
   *
   * @param key A key containing the service plan ID for which the templates
   * are required.
   *
   * @return A list of templates that are associated with the service plan.
   */
  @Override
  public ListTemplatesForServicePlanDetailsList listTemplatesForServicePlan(
    ListTemplatesForServicePlanKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final ReadServicePlanKey readServicePlanKey = new ReadServicePlanKey();

    final ListTemplatesForServicePlanDetailsList listTemplatesForServicePlanDetailsList = new ListTemplatesForServicePlanDetailsList();

    // get list of templates for service plan
    listTemplatesForServicePlanDetailsList.list = servicePlanObj.listTemplates(
      key.key);

    // read service plan context description
    readServicePlanKey.key = key.key;

    listTemplatesForServicePlanDetailsList.contextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    return listTemplatesForServicePlanDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the templates not associated with the service plan.
   *
   * @param key A key containing the service plan key for which the templates
   * are required.
   *
   * @return A list of templates that are not associated with the service
   * plan.
   */
  @Override
  public ListTemplatesNotAssociatedWithServicePlanDetailsList listTemplatesNotAssociatedWithServicePlan(
    ListTemplatesNotAssociatedWithServicePlanKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final ListTemplatesNotAssociatedWithServicePlanDetailsList tempsNotWithSPDtlsList = new ListTemplatesNotAssociatedWithServicePlanDetailsList();

    // get templates not associated with service plan
    tempsNotWithSPDtlsList.list = servicePlanObj.listUnassociatedTemplates(
      key.key);

    return tempsNotWithSPDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies the service plan.
   *
   * @param key Contains the key of the service plan to be modified and the new
   * details of the service plan.
   */
  @Override
  public void modify(ModifyServicePlanDetails key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create structures for modification
    final curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.struct.ServicePlanKey();

    // modify service plan
    servicePlanKey.key.servicePlanID = key.details.plan.servicePlanID;

    servicePlanObj.modify(servicePlanKey, key.details);

  }

  // ___________________________________________________________________________
  /**
   * Reads the service plan.
   *
   * @param key Contains the key of the service plan that is required.
   *
   * @return The details of the service plan matching the key.
   */
  @Override
  public ReadServicePlanDetails read(ReadServicePlanKey key)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // create return structure
    final ReadServicePlanDetails readServicePlanDetails = new ReadServicePlanDetails();

    readServicePlanDetails.details = servicePlanObj.read(key.key);

    // read context description
    readServicePlanDetails.contextDescription = getServicePlanContextDescription(
      key);

    return readServicePlanDetails;

  }

  // ___________________________________________________________________________
  /**
   * Removes a goal from the service plan.
   *
   * @param key Identifies the goal to be removed and the service plan from
   * which to remove it.
   */
  @Override
  public void removeGoalFromServicePlan(RemoveGoalFromServicePlanKey key)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    servicePlanObj.removeGoal(key.key);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the concern role details for the specified case participant
   * role.
   *
   * @return The concern role ID and type
   */
  @Override
  public GoalList listGoals() throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final GoalList goalList = new GoalList();

    // List goals
    goalList.goalList = goalObj.list();

    // Return list of goals
    return goalList;

  }

  // ___________________________________________________________________________
  /**
   * Creates a goal.
   *
   * @param details The details of the Goal to be created
   *
   * @return Unique identifier of the created goal
   */
  @Override
  public GoalKey createGoal(CreateGoalDetails details) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final GoalKey goalKey = new GoalKey();

    // create goal
    goalKey.goalKey = goalObj.create(details.createGoalDetails);

    // return goalID
    return goalKey;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a goal.
   *
   * @param details The details of the Goal to be modified
   */
  @Override
  public void modifyGoal(ModifyGoalDetails details) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Modify Goal
    goalObj.modify(details.modifyGoalDetails);

  }

  // ___________________________________________________________________________
  /**
   * Reads goal details.
   *
   * @param key The Goal unique identifier
   *
   * @return Goal details
   */
  @Override
  public ReadGoalDetails readGoal(GoalKey key) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final ReadGoalDetails readGoalDetails = new ReadGoalDetails();

    // Read goal details
    readGoalDetails.readGoalDetails = goalObj.read(key.goalKey);

    // read context description
    readGoalDetails.contextDescription = getGoalContextDescription(key);

    // Return goal details
    return readGoalDetails;

  }

  // ___________________________________________________________________________
  /**
   * Cancels a goal.
   *
   * @param key Unique identifier of the goal to be canceled
   */
  @Override
  public void cancelGoal(CancelGoalKey key) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Cancel goal
    goalObj.cancel(key.cancelGoalDetails);

  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals for a goal.
   *
   * @param key The Goal unique identifier
   *
   * @return Sub Goal details list
   */
  @Override
  public GoalSubGoalList listSubGoalsForGoal(GoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final GoalSubGoalList goalSubGoalList = new GoalSubGoalList();

    // list goal's sub goals
    goalSubGoalList.goalSubGoalList = goalObj.listSubGoal(key.goalKey);

    // read context description
    goalSubGoalList.contextDescription = getGoalContextDescription(key);

    // Return list of sub goals for the goal
    return goalSubGoalList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals that are not associated to a goal.
   *
   * @param key The Goal unique identifier
   *
   * @return Sub Goal details list
   */
  @Override
  public GoalSubGoalList listSubGoalsNotAssociatedWithGoal(GoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();
    final GoalSubGoalList goalSubGoalList = new GoalSubGoalList();

    // Read sub goals unassociated with the goal
    goalSubGoalList.goalSubGoalList = goalObj.listUnassociatedSubGoals(
      key.goalKey);

    // read context description
    goalSubGoalList.contextDescription = getGoalContextDescription(key);

    // return list of unassociated sub goals
    return goalSubGoalList;
  }

  // ___________________________________________________________________________
  /**
   * Assigns to goal existing sub goals from the list.
   *
   * @param details Tabbed string list of sub goal identifiers
   */
  @Override
  public void addExistingSubGoalsToGoal(
    AddExistingSubGoalsToGoalDetails details) throws AppException,
      InformationalException {

    // ServicePlanUtility manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.struct.ExistingSubGoalsDetails existingSubGoalsDetails = new curam.serviceplans.sl.struct.ExistingSubGoalsDetails();

    // set goal key
    existingSubGoalsDetails.goalKey = details.goalKey;

    // Parse tab delimited string to a list
    existingSubGoalsDetails.subGoalKeyList = servicePlanUtilityObj.parseSubGoals(
      details.subGoalTabList);

    // Add existing sub goals to the goal
    goalObj.addExistingSubGoals(existingSubGoalsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates sub goal for a goal.
   *
   * @param details The details of the Sub Goal to be created
   *
   * @return Unique identifier of the created sub goal
   */
  @Override
  public SubGoalKey createSubGoalForGoal(CreateSubGoalForGoalDetails details)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final SubGoalKey subGoalKey = new SubGoalKey();

    // Create sub goal
    subGoalKey.subGoalKey = goalObj.createSubGoal(details.createSubGoalDetails);

    // Return ID of the sub goal created
    return subGoalKey;

  }

  // ___________________________________________________________________________
  /**
   * Removes sub goal from a goal.
   *
   * @param key Goal and Sub Goal unique identifiers
   */
  @Override
  public void removeSubGoalFromGoal(RemoveSubGoalFromGoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // remove sub goal from the goal
    goalObj.removeSubGoal(key.goalSubGoalKey);
  }

  // ___________________________________________________________________________
  /**
   * Lists contract text details for a goal.
   *
   * @param key The Goal unique identifier
   *
   * @return Contract text details list
   */
  @Override
  public GoalContractTextList listContractTextForGoal(GoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final GoalContractTextList goalContractTextList = new GoalContractTextList();

    // list contract text for goal
    goalContractTextList.goalContractTextList = goalObj.listContractText(
      key.goalKey);

    // read context description
    goalContractTextList.contextDescription = getGoalContextDescription(key);

    // return the list
    return goalContractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Creates contract text for a goal.
   *
   * @param details The details of the Contract Text to be created
   *
   * @return Unique identifier of the created contract text
   */
  @Override
  public ContractTextKey createContractTextForGoal(
    CreateContractTextForGoalDetails details) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // return value
    final ContractTextKey contractTextKey = new ContractTextKey();

    // create contract text
    contractTextKey.contractTextKey = goalObj.createContractText(
      details.createContractTextDetails);

    // return unique ID of the contract text created
    return contractTextKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies contract text for a goal.
   *
   * @param details The details of the Contract Text to be modified
   */
  @Override
  public void modifyContractTextForGoal(
    ModifyContractTextForGoalDetails details) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // modify contract text for goal
    goalObj.modifyContractText(details.modifyGoalContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Removes contract text for a goal.
   *
   * @param key Goal and contract text unique identifiers
   */
  @Override
  public void removeContractTextForGoal(RemoveContractTextForGoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // remove contract text
    goalObj.removeContractText(key.removeGoalContractTextDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads contract text details for a goal.
   *
   * @param key Contract text unique identifier
   *
   * @return Contract text details
   */
  @Override
  public ReadContractTextForGoalDetails readContractTextForGoal(
    ReadContractTextForGoalKey key) throws AppException,
      InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final ReadContractTextForGoalDetails readContractTextForGoalDetails = new ReadContractTextForGoalDetails();

    // read contract text details
    readContractTextForGoalDetails.contractTextDetails = goalObj.readContractText(
      key.contractTextKey);

    final GoalKey goalKey = new GoalKey();

    // assign the plan item key
    goalKey.goalKey.assign(key.goalKey);

    // read context description
    readContractTextForGoalDetails.contextDescription = getGoalContextDescription(
      goalKey);

    // return contract text details
    return readContractTextForGoalDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes for a goal.
   *
   * @param key The Goal unique identifier
   *
   * @return Outcome details list
   */
  @Override
  public GoalOutcomeList listOutcomesForGoal(GoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final GoalOutcomeList goalOutcomeList = new GoalOutcomeList();

    // list goal's outcomes
    goalOutcomeList.goalOutcomeList = goalObj.listOutcome(key.goalKey);

    // read context description
    goalOutcomeList.contextDescription = getGoalContextDescription(key);

    // Return list of outcomes for the goal
    return goalOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes that are not associated to a goal.
   *
   * @param key The Goal unique identifier
   *
   * @return Outcome details list
   */
  @Override
  public GoalOutcomeList listOutcomesNotAssociatedWithGoal(GoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();
    final GoalOutcomeList goalOutcomeList = new GoalOutcomeList();

    // Read outcomes unassociated with the goal
    goalOutcomeList.goalOutcomeList = goalObj.listUnassociatedOutcomes(
      key.goalKey);

    // read context description
    goalOutcomeList.contextDescription = getGoalContextDescription(key);

    // return list of unassociated outcomes
    return goalOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Assigns to goal existing outcomes from the list.
   *
   * @param details Tabbed string list of outcome identifiers
   */
  @Override
  public void addExistingOutcomesToGoal(
    AddExistingOutcomesToGoalDetails details) throws AppException,
      InformationalException {

    // ServicePlanUtility manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();
    final curam.serviceplans.sl.struct.ExistingOutcomesDetails existingOutcomesDetails = new curam.serviceplans.sl.struct.ExistingOutcomesDetails();

    // set goal key
    existingOutcomesDetails.goalKey = details.goalKey;

    // Parse tab delimited string to a list
    existingOutcomesDetails.outcomeKeyList = servicePlanUtilityObj.parseOutcomes(
      details.outcomeTabList);

    // Add existing outcomes to the goal
    goalObj.addExistingOutcomes(existingOutcomesDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates outcome for a goal.
   *
   * @param details The details of the Outcome to be created
   *
   * @return Unique identifier of the created outcome
   */
  @Override
  public OutcomeKey createOutcomeForGoal(CreateOutcomeForGoalDetails details)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // Return value
    final OutcomeKey outcomeKey = new OutcomeKey();

    // Create outcome
    outcomeKey.key = goalObj.createOutcome(details.createOutcomeDetails);

    // Return ID of the outcome created
    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * Removes outcome from a goal.
   *
   * @param key Goal and Outcome unique identifiers
   */
  @Override
  public void removeOutcomeFromGoal(RemoveOutcomeFromGoalKey key)
    throws AppException, InformationalException {

    // Goal BPO manipulation variables
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // remove outcome from the goal
    goalObj.removeOutcome(key.goalOutcomeKey);

  }

  // ___________________________________________________________________________
  /**
   * Adds existing planItems to an sub goal. The planItems and the sub goal are
   * identified in the details. The planItems are listed as a tab list, which
   * is parsed for further processing.
   *
   * @param details Identifies the sub goal and contains the new plan item IDs.
   */
  @Override
  public void addExistingPlanItemsToSubGoal(
    AddExistingPlanItemsToSubGoalDetails details) throws AppException,
      InformationalException {

    // parse the plan item list
    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();
    final curam.serviceplans.sl.struct.PlanItemKeyList planItemKeyList = servicePlanUtilityObj.parsePlanItems(
      details.planItemIDList);

    // add the list of planItems to the sub goal
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.addExistingPlanItems(details.subGoalKey, planItemKeyList);

  }

  // ___________________________________________________________________________
  /**
   * Adds existing outcomes to a plan item. The outcomes and the plan item are
   * identified in the details. The outcomes are listed as a tab list, which
   * is parsed for further processing.
   *
   * @param details Identifies the plan item and contains the new outcome
   * details.
   */
  @Override
  public void addExistingOutcomesToSubGoal(
    AddExistingOutcomesToSubGoalDetails details) throws AppException,
      InformationalException {

    // parse the outcome list
    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();
    final curam.serviceplans.sl.struct.OutcomeKeyList outcomeKeyList = servicePlanUtilityObj.parseOutcomes(
      details.outcomeIDList);

    // add the list of outcomes to the sub goal
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.addExistingOutcomes(details.subGoalKey, outcomeKeyList);

  }

  // ___________________________________________________________________________
  /**
   * Cancels sub goal details.
   *
   * @param key Sub Goal unique identifier
   */
  @Override
  public void cancelSubGoal(CancelSubGoalKey key) throws AppException,
      InformationalException {

    // SubGoal BPO
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    // cancel the sub goal
    subGoalObj.cancel(key.key);

  }

  // ___________________________________________________________________________
  /**
   * Creates an plan item for an sub goal.
   *
   * @param details Identifies the sub goal and contains the new plan item
   * details
   *
   * @return The new plan item ID
   */
  @Override
  public PlanItemKey createPlanItemForSubGoal(
    CreatePlanItemForSubGoalDetails details) throws AppException,
      InformationalException {

    // return object
    final PlanItemKey planItemKey = new PlanItemKey();

    // populate the create details
    final curam.serviceplans.sl.struct.CreatePlanItemDetails createPlanItemDetails = new curam.serviceplans.sl.struct.CreatePlanItemDetails();

    createPlanItemDetails.assign(details.details.planItemDtls);

    // create the plan item for the sub goal
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    planItemKey.key = subGoalObj.createPlanItem(details.details.subGoalKey,
      createPlanItemDetails);

    return planItemKey;

  }

  // ___________________________________________________________________________
  /**
   * Create a new contract text and associate it with a plan item. The plan item
   * is
   * identified by a key contained in the details.
   *
   * @param details The contract text details
   */
  @Override
  public ContractTextKey createContractTextForSubGoal(
    CreateContractTextForSubGoalDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    final ContractTextKey contractTextKey = new ContractTextKey();

    contractTextKey.contractTextKey = subGoalObj.createContractText(
      details.subGoalKey, details.contractTextDetails);

    return contractTextKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates an sub goal.
   *
   * @param details Sub Goal details
   *
   * @return unique ID of the sub goal created
   */
  @Override
  public SubGoalKey createSubGoal(CreateSubGoalDetails details)
    throws AppException, InformationalException {

    // SubGoal BPO
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    // to be returned
    final SubGoalKey subGoalKey = new SubGoalKey();

    // create a sub goal
    subGoalKey.subGoalKey = subGoalObj.create(details.dtls);

    // return sub goal identification
    return subGoalKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates a new outcome for the sub goal identified in the details, using
   * the information in the details to build the outcome.
   *
   * @param details The new outcome details
   */
  @Override
  public OutcomeKey createOutcomeForSubGoal(
    CreateOutcomeForSubGoalDetails details) throws AppException,
      InformationalException {

    // return object
    final OutcomeKey outcomeKey = new OutcomeKey();

    // populate the create details
    final curam.serviceplans.sl.struct.CreateOutcomeDetails createOutcomeDetails = new curam.serviceplans.sl.struct.CreateOutcomeDetails();

    createOutcomeDetails.createOutcomeDetails.assign(
      details.details.outcomeDtls);

    // create the outcome
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    outcomeKey.key = subGoalObj.createOutcome(details.details.subGoalKey,
      createOutcomeDetails);

    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems for an sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return List of planItems associated with the sub goal.
   */
  @Override
  public SubGoalPlanItemList listPlanItemsForSubGoal(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalPlanItemList subGoalPlanItemList = new SubGoalPlanItemList();

    // read the list of planItems and populate the return object
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalPlanItemList.details = subGoalObj.listPlanItems(key.subGoalKey);

    // read context description
    subGoalPlanItemList.contextDescription = getSubGoalContextDescription(key);

    return subGoalPlanItemList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes not associated with the sub goal identified by the key.
   *
   * @param key Identifies the sub goal.
   *
   * @return The list of unassociated outcomes.
   */
  @Override
  public SubGoalUnassociatedPlanItemList listPlanItemsNotAssociatedWithSubGoal(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalUnassociatedPlanItemList subGoalUnassociatedPlanItemList = new SubGoalUnassociatedPlanItemList();

    // read the list and populate the return object
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalUnassociatedPlanItemList.details = subGoalObj.listUnassociatedPlanItems(
      key.subGoalKey);

    // read context description
    subGoalUnassociatedPlanItemList.contextDescription = getSubGoalContextDescription(
      key);

    return subGoalUnassociatedPlanItemList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the contract texts for an sub goal
   *
   * @param key Identifies the sub goal.
   *
   * @return The list of contract texts.
   */
  @Override
  public SubGoalContractTextList listContractTextsForSubGoal(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalContractTextList subGoalContractTextList = new SubGoalContractTextList();

    // read the list and populate the output struct
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalContractTextList.details = subGoalObj.listContractTexts(
      key.subGoalKey);

    // read context description
    subGoalContractTextList.contextDescription = getSubGoalContextDescription(
      key);

    return subGoalContractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all existing sub goals.
   *
   * @return List of sub goal details
   */
  @Override
  public SubGoalList listSubGoals() throws AppException,
      InformationalException {

    // SubGoal BPO
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    // To be returned
    final SubGoalList subGoalList = new SubGoalList();

    // list sub goals
    subGoalList.dtls = subGoalObj.list();

    // return sub goal list
    return subGoalList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes for an sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return List of outcomes associated with the sub goal.
   */
  @Override
  public SubGoalOutcomeList listOutcomesForSubGoal(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    final SubGoalOutcomeList subGoalOutcomeList = new SubGoalOutcomeList();

    // read the list of outcomes and populate the return object
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalOutcomeList.details = subGoalObj.listOutcomes(key.subGoalKey);

    // read context description
    subGoalOutcomeList.contextDescription = getSubGoalContextDescription(key);

    return subGoalOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes not associated with the sub goal identified by the key.
   *
   * @param key Identifies the sub goal.
   *
   * @return The list of unassociated outcomes.
   */
  @Override
  public SubGoalUnassociatedOutcomeList listOutcomesNotAssociatedWithSubGoal(
    SubGoalKey key) throws AppException, InformationalException {

    // return object
    final SubGoalUnassociatedOutcomeList subGoalUnassociatedOutcomeList = new SubGoalUnassociatedOutcomeList();

    // read the list and populate the return object
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalUnassociatedOutcomeList.details = subGoalObj.listUnassociatedOutcomes(
      key.subGoalKey);

    // read context description
    subGoalUnassociatedOutcomeList.contextDescription = getSubGoalContextDescription(
      key);

    return subGoalUnassociatedOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Changes the association between a contract text and an sub goal based on
   * the details, which identifies the two items and contains the new data.
   *
   * @param details The new contract text details.
   */
  @Override
  public void modifyContractTextForSubGoal(
    ModifyContractTextForSubGoalDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.struct.ModifyContractTextDetails modifyContractTextDetails = new curam.serviceplans.sl.struct.ModifyContractTextDetails();

    modifyContractTextDetails.dtls.contractText = details.details.dtls.contractText;
    modifyContractTextDetails.dtls.contractTextID = details.details.dtls.contractTextID;
    modifyContractTextDetails.dtls.versionNo = details.details.dtls.versionNo;

    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.modifyContractText(modifyContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Modifies an sub goal details.
   *
   * @param details Sub Goal details
   */
  @Override
  public void modifySubGoal(ModifySubGoalDetails details)
    throws AppException, InformationalException {

    // SubGoal BPO
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    // modify sub goal
    subGoalObj.modify(details.details);

  }

  // ___________________________________________________________________________
  /**
   * Reads the details for a contract text associated with an sub goal. The
   * items are identified by the key.
   *
   * @param key Identifies the contract text to read.
   */
  @Override
  public ReadContractTextForSubGoalDetails readContractTextForSubGoal(
    ReadContractTextForSubGoalKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    final ReadContractTextForSubGoalDetails readContractTextForSubGoalDetails = new ReadContractTextForSubGoalDetails();

    readContractTextForSubGoalDetails.details = subGoalObj.readContractText(
      key.key);

    final SubGoalKey subGoalKey = new SubGoalKey();

    // assign the plan item key
    subGoalKey.subGoalKey.assign(key.subGoalKey);

    // read context description
    readContractTextForSubGoalDetails.contextDescription = getSubGoalContextDescription(
      subGoalKey);

    return readContractTextForSubGoalDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads the sub goal details.
   *
   * @param key Sub Goal unique identifier
   *
   * @return Sub Goal details
   */
  @Override
  public ReadSubGoalDetails readSubGoal(SubGoalKey key) throws AppException,
      InformationalException {

    // SubGoal BPO
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    // return value
    final ReadSubGoalDetails readSubGoalDetails = new ReadSubGoalDetails();

    // read sub goal
    readSubGoalDetails.details = subGoalObj.read(key.subGoalKey);

    // read context description
    readSubGoalDetails.contextDescription = getSubGoalContextDescription(key);

    // return sub goal details
    return readSubGoalDetails;
  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an plan item and an sub goal. The sub goal
   * and the plan item are identified within the key.
   *
   * @param key Identifies the sub goal and planItem.
   */
  @Override
  public void removePlanItemForSubGoal(RemovePlanItemForSubGoalKey key)
    throws AppException, InformationalException {

    // remove the plan item from the sub goal
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.removePlanItem(key.subGoalKey, key.planItemKey);

  }

  // ___________________________________________________________________________
  /**
   * Removes a contract text from an sub goal. The key contains the sub goal
   * and contract text which are to be disconnected.
   *
   * @param key Identifies the contract text and sub goal.
   */
  @Override
  public void removeContractTextForSubGoal(RemoveContractTextForSubGoalKey key)
    throws AppException, InformationalException {

    // populate the remove key
    final curam.serviceplans.sl.struct.RemoveSubGoalContractTextKey removeSubGoalContractTextKey = new curam.serviceplans.sl.struct.RemoveSubGoalContractTextKey();

    removeSubGoalContractTextKey.subGoalID = key.subGoalKey.subGoalKey.subGoalID;
    removeSubGoalContractTextKey.contractTextID = key.contractTextCancelKey.key.contractTextID;
    removeSubGoalContractTextKey.contractTextVersionNo = key.contractTextCancelKey.key.versionNo;

    // remove the contract text
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.removeContractText(removeSubGoalContractTextKey);

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an outcome and an sub goal. The outcome
   * and the plan item are identified within the key.
   *
   * @param key Identifies the sub goal and outcome.
   */
  @Override
  public void removeOutcomeForSubGoal(RemoveOutcomeForSubGoalKey key)
    throws AppException, InformationalException {

    // remove the outcome from the sub goal
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.removeOutcome(key.subGoalKey, key.outcomeKey);

  }

  // ___________________________________________________________________________
  /**
   * Cancels outcome.
   *
   * @param details Outcome details
   */
  @Override
  public void cancelOutcome(CancelOutcomeDetails details)
    throws AppException, InformationalException {

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // cancel outcome
    outcomeObj.cancel(details.cancelOutcomeDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates outcome.
   *
   * @param details Outcome details
   */
  @Override
  public void createOutcome(CreateOutcomeDetails details)
    throws AppException, InformationalException {

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // create outcome
    outcomeObj.create(details.createOutcomeDetails);

  }

  // BEGIN, CR00218024, CSH
  // ___________________________________________________________________________
  /**
   * @return List of outcomes
   * @deprecated since v6.0 - replaced by {@link #listOutcomeDetails()} This
   * method has been deprecated to introduce new user interface
   * enhancements. See release note: CR00218024.
   *
   * Lists all existing outcomes.
   */
  @Override
  @Deprecated
  public OutcomeList listOutcomes() throws AppException,
      InformationalException {

    // Return value
    final OutcomeList outcomeList = new OutcomeList();

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // list outcomes
    outcomeList.outcomeList = outcomeObj.list();

    // return list of outcomes
    return outcomeList;

  }

  // BEGIN, CR00218024

  // ___________________________________________________________________________
  /**
   * Reads outcome.
   *
   * @param key Outcome unique identifier
   *
   * @return Outcome details
   */
  @Override
  public ReadOutcomeDetails readOutcome(OutcomeKey key) throws AppException,
      InformationalException {

    // return value
    final ReadOutcomeDetails readOutcomeDetails = new ReadOutcomeDetails();

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // read outcome
    readOutcomeDetails.readOutcomeDetails = outcomeObj.read(key.key);

    // read context description
    readOutcomeDetails.contextDescription = getOutcomeContextDescription(key);

    // return outcome details
    return readOutcomeDetails;

  }

  // ___________________________________________________________________________
  /**
   * The details of the Outcome to be modified
   *
   * @param details Outcome details
   */
  @Override
  public void modifyOutcome(ModifyOutcomeDetails details)
    throws AppException, InformationalException {

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // modify outcome
    outcomeObj.modify(details.modifyOutcomeDetails);
  }

  // ___________________________________________________________________________
  /**
   * Adds existing outcomes to a plan item. The outcomes and the plan item are
   * identified in the details. The outcomes are listed as a tab list, which
   * is parsed for further processing.
   *
   * @param details Identifies the plan item and contains the new outcome
   * details.
   */
  @Override
  public void addExistingOutcomesToPlanItem(
    AddExistingOutcomesToPlanItemDetails details) throws AppException,
      InformationalException {

    // parse the outcome list
    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();
    final curam.serviceplans.sl.struct.OutcomeKeyList outcomeKeyList = servicePlanUtilityObj.parseOutcomes(
      details.outcomeTabList);

    // add the list of outcomes to the planItem
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.addExistingOutcomes(details.planItemKey, outcomeKeyList);
  }

  // ___________________________________________________________________________
  /**
   * Cancels the plan item identified by the key.
   *
   * @param key the plan item key
   */
  @Override
  public void cancelPlanItem(CancelPlanItemKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.cancel(key.key);

  }

  // BEGIN, CR00234077, TV
  // ___________________________________________________________________________
  /**
   * Creates a new plan item from the details.
   *
   * @param details
   * the new plan item details
   *
   * @deprecated Since Curam v6, replaced with {@link createPlanItemDetails}.
   * As per code line issue, the attribute 'guidanceURL' and 'taskConfigID'
   * removed from
   * 'CreatePlanItemDetails' struct and added into
   * 'PlanItemDetails' struct along with existing attribute of
   * 'CreatePlanItemDetails' struct. See release note <CR00234077>
   */
  @Override
  @Deprecated
  public curam.serviceplans.facade.struct.PlanItemKey createPlanItem(
    curam.serviceplans.facade.struct.CreatePlanItemDetails details)
    throws AppException, InformationalException {

    // Manipulation struct
    final curam.serviceplans.facade.struct.PlanItemDetails planItemDetails = new curam.serviceplans.facade.struct.PlanItemDetails();

    planItemDetails.details.name = details.details.name;
    planItemDetails.details.planItemReference = details.details.planItemReference;
    planItemDetails.details.typeCode = details.details.typeCode;
    planItemDetails.details.createPageName = details.details.createPageName;
    planItemDetails.details.createPagePlanItemIDParamName = details.details.createPagePlanItemIDParamName;
    planItemDetails.details.createPageSubGoalIDParamName = details.details.createPageSubGoalIDParamName;
    planItemDetails.details.modifyPageName = details.details.modifyPageName;
    planItemDetails.details.modifyPagePlanItemParamName = details.details.modifyPagePlanItemParamName;
    planItemDetails.details.viewPageName = details.details.viewPageName;
    planItemDetails.details.viewPagePlanItemParamName = details.details.viewPagePlanItemParamName;
    planItemDetails.details.description = details.details.description;
    planItemDetails.details.approvalSID = details.details.approvalSID;
    planItemDetails.details.requiresApproval = details.details.requiresApproval;
    planItemDetails.details.associatedType = details.details.associatedType;
    planItemDetails.details.cost = details.details.cost;
    planItemDetails.details.unitType = details.details.unitType;
    planItemDetails.details.authorizedUnits = details.details.authorizedUnits;
    planItemDetails.details.maximumUnits = details.details.maximumUnits;
    planItemDetails.details.modifyAuthorizedSID = details.details.modifyAuthorizedSID;
    planItemDetails.details.associatedID = details.details.associatedID;

    return createPlanItemDetails(planItemDetails);
  }

  // END, CR00234077

  // ___________________________________________________________________________
  /**
   * Create a new contract text and associate it with a plan item. The plan item
   * is
   * identified by a key contained in the details.
   *
   * @param details The contract text details
   *
   * @return Key identifying the new contract text
   */
  @Override
  public ContractTextKey createContractTextForPlanItem(
    CreateContractTextForPlanItemDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final ContractTextKey contractTextKey = new ContractTextKey();

    contractTextKey.contractTextKey = planItemObj.createContractText(
      details.planItemKey, details.contractTextDetails);

    return contractTextKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates a new outcome for the plan item identified in the details, using
   * the
   * information in the details to build the outcome.
   *
   * @param details The new outcome details
   *
   * @return A key identifying the new outcome.
   */
  @Override
  public OutcomeKey createOutcomeForPlanItem(
    CreateOutcomeForPlanItemDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final OutcomeKey outcomeKey = new OutcomeKey();

    outcomeKey.key = planItemObj.createOutcome(details.planItemKey,
      details.outcomeDetails);

    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * List all planItems on the system.
   *
   * @return a list of planItems
   */
  @Override
  public PlanItemList listPlanItems() throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final PlanItemList planItemList = new PlanItemList();

    planItemList.planItemList = planItemObj.list();

    return planItemList;

  }

  // ___________________________________________________________________________
  /**
   * List all contract texts associated with an plan item identified by a key.
   *
   * @param key Identifies the planItem
   *
   * @return a list of contract texts
   */
  @Override
  public PlanItemContractTextList listContractTextsForPlanItem(PlanItemKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final PlanItemContractTextList planItemContractTextList = new PlanItemContractTextList();

    planItemContractTextList.dtls = planItemObj.listContractTexts(key.key);

    // read context description
    planItemContractTextList.contextDescription = getPlanItemContextDescription(
      key);

    return planItemContractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes associated with the plan item identified by the key.
   *
   * @param key Identifies the planItem
   */
  @Override
  public PlanItemOutcomeList listOutcomesForPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final PlanItemOutcomeList planItemOutcomeList = new PlanItemOutcomeList();

    planItemOutcomeList.dtls = planItemObj.listOutcomes(key.key);
    // BEGIN, CR00096677, SK
    for (int i = 0; i < planItemOutcomeList.dtls.dtls.dtls.size(); i++) {

      if (!CodeTable.isEnabled(OUTCOMENAME.TABLENAME,
        planItemOutcomeList.dtls.dtls.dtls.item(i).name, kCodeTableLanguage)) {
        planItemOutcomeList.dtls.dtls.dtls.remove(i);
        i--;
      }
    }
    // END, CR00096677
    // read context description
    planItemOutcomeList.contextDescription = getPlanItemContextDescription(key);

    return planItemOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes not associated with the plan item identified by the key.
   *
   * @param key Identifies the planItem.
   */
  @Override
  public PlanItemUnassociatedOutcomeList listOutcomesNotAssociatedWithPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final PlanItemUnassociatedOutcomeList planItemUnassociatedOutcomeList = new PlanItemUnassociatedOutcomeList();

    planItemUnassociatedOutcomeList.dtls = planItemObj.listUnassociatedOutcomes(
      key.key);

    // read context description
    planItemUnassociatedOutcomeList.contextDescription = getPlanItemContextDescription(
      key);

    return planItemUnassociatedOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies an plan item as identified by the details with the data in the
   * details.
   *
   * @param details the plan item details
   */
  @Override
  public void modifyPlanItem(ModifyPlanItemDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.modify(details.details);

  }

  // ___________________________________________________________________________
  /**
   * Changes the association between a contract text and an plan item based on
   * the
   * details, which identifies the two items and contains the new data.
   *
   * @param details The new contract text details.
   */
  @Override
  public void modifyContractTextForPlanItem(
    ModifyContractTextForPlanItemDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.struct.ModifyContractTextDetails modifyContractTextDetails = new curam.serviceplans.sl.struct.ModifyContractTextDetails();

    modifyContractTextDetails.dtls.contractText = details.details.contractText;
    modifyContractTextDetails.dtls.contractTextID = details.details.contractTextID;
    modifyContractTextDetails.dtls.versionNo = details.details.versionNo;
    // BEGIN CR00156191, SS
    modifyContractTextDetails.planItemKey.planItemID = details.planItemKey.key.planItemID;
    // END CR00156191

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.modifyContractText(modifyContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Reads an plan item based on the key provided and returns the its details.
   *
   * @param key Identifies the planItem.
   *
   * @return The plan item details.
   */
  @Override
  public ReadPlanItemDetails readPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final ReadPlanItemDetails details = new ReadPlanItemDetails();

    details.details = planItemObj.read(key.key);

    // read context description
    details.contextDescription = getPlanItemContextDescription(key);

    return details;

  }

  // ___________________________________________________________________________
  /**
   * Reads the details for a contract text associated with a plan item. The
   * items
   * are identified by the key.
   *
   * @param key Identifies the contract text to read.
   *
   * @return The contract text details.
   */
  @Override
  public ReadContractTextForPlanItemDetails readContractTextForPlanItem(
    ReadContractTextForPlanItemKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final ReadContractTextForPlanItemDetails readContractTextForPlanItemDetails = new ReadContractTextForPlanItemDetails();

    readContractTextForPlanItemDetails.details = planItemObj.readContractText(
      key.key);

    final PlanItemKey planItemKey = new PlanItemKey();

    // assign the plan item key
    planItemKey.key.assign(key.planItemKey);

    // read context description
    readContractTextForPlanItemDetails.contextDescription = getPlanItemContextDescription(
      planItemKey);

    return readContractTextForPlanItemDetails;

  }

  // ___________________________________________________________________________
  /**
   * Removes a contract text from a plan item. The key contains the plan item
   * and
   * contract text which are to be disconnected.
   *
   * @param key Identifies the contract text and planItem.
   */
  @Override
  public void removeContractTextForPlanItem(
    RemoveContractTextForPlanItemKey key) throws AppException,
      InformationalException {

    // populate the remove key
    final curam.serviceplans.sl.struct.RemovePlanItemContractTextKey removePlanItemContractTextKey = new curam.serviceplans.sl.struct.RemovePlanItemContractTextKey();

    removePlanItemContractTextKey.planItemID = key.planItemKey.key.planItemID;
    removePlanItemContractTextKey.contractTextID = key.contractTextCancelKey.key.contractTextID;
    removePlanItemContractTextKey.contractTextVersionNo = key.contractTextCancelKey.key.versionNo;

    // remove the contract text
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.removeContractText(removePlanItemContractTextKey);

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an outcome and a plan item. The outcome
   * and the plan item are identified within the key.
   *
   * @param key Identifies the plan item and outcome.
   */
  @Override
  public void removeOutcomeFromPlanItem(RemoveOutcomeFromPlanItemKey key)
    throws AppException, InformationalException {

    // set up the remove key
    final PlanItemOutcomeKey planItemOutcomeKey = new PlanItemOutcomeKey();

    planItemOutcomeKey.planItemOutcomeKey.planItemID = key.planItemKey.key.planItemID;
    planItemOutcomeKey.planItemOutcomeKey.outcomeID = key.outcomeKey.key.outcomeID;

    // remove the outcome from the planItem
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.removeOutcome(planItemOutcomeKey);

  }

  // ___________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Adds a plan item to the template.
   *
   * @param details the plan item details.
   *
   * @deprecated since Curam v6, replaced with {@link addPlanTemplatePlanItem}.
   * The new struct AddPlanTemplatePlanItemDetails aggregates
   * PlanTemplateAndPlanItemDetails, which along with existing functionality
   * adds plan item details to a template along with
   * mandatory and approval information. See release note <CR00226779>
   */
  @Override
  @Deprecated
  public void addTemplatePlanItem(
    curam.serviceplans.facade.struct.AddTemplatePlanItemDetails details)
    throws AppException, InformationalException {

    final AddPlanTemplatePlanItemDetails addPlanTemplatePlanItemDetails = new AddPlanTemplatePlanItemDetails();

    final PlanTemplateAndPlanItemDetails planTemplateAndPlanItemDetails = new PlanTemplateAndPlanItemDetails();

    planTemplateAndPlanItemDetails.dtls.authorizedUnits = details.details.dtls.authorizedUnits;
    planTemplateAndPlanItemDetails.dtls.description = details.details.dtls.description;
    planTemplateAndPlanItemDetails.dtls.duration = details.details.dtls.duration;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeID = details.details.dtls.expectedOutcomeID;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeName = details.details.dtls.expectedOutcomeName;
    planTemplateAndPlanItemDetails.dtls.maximumUnits = details.details.dtls.maximumUnits;
    planTemplateAndPlanItemDetails.dtls.name = details.details.dtls.name;
    planTemplateAndPlanItemDetails.dtls.outcomeRequiredInd = details.details.dtls.outcomeRequiredInd;
    planTemplateAndPlanItemDetails.dtls.planItemID = details.details.dtls.planItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplatePlanItemID = details.details.dtls.planTemplatePlanItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplateSubGoalID = details.details.dtls.planTemplateSubGoalID;
    planTemplateAndPlanItemDetails.dtls.startDay = details.details.dtls.startDay;
    planTemplateAndPlanItemDetails.dtls.versionNo = details.details.dtls.versionNo;

    addPlanTemplatePlanItemDetails.details = planTemplateAndPlanItemDetails;

    this.addPlanTemplatePlanItem(addPlanTemplatePlanItemDetails);

  }

  // END, CR00226779
  // ___________________________________________________________________________

  /**
   * Add an sub goal to the template
   *
   * @param details the sub goal details
   */

  @Override
  public PlanTemplateSubGoalKey addTemplateSubGoal(
    AddTemplateSubGoalDetails details) throws AppException,
      InformationalException {

    // Plan Template BPO and manipulation variables
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

    // add sub goal to the template
    planTemplateSubGoalKey.key = planTemplateObj.addSubGoal(details.details);

    return planTemplateSubGoalKey;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a template.
   *
   * @param details the template key
   */
  @Override
  public void cancelTemplate(CancelPlanTemplateDetails details)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // cancel template
    planTemplateObj.cancel(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Cancels a template planItem.
   *
   * @param key the template plan item key
   */
  @Override
  public void cancelTemplatePlanItem(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // cancel template
    planTemplateObj.cancelPlanItem(key.key);
  }

  // ___________________________________________________________________________
  /**
   * Cancels a template sub goal.
   *
   * @param key the template sub goal key
   */
  @Override
  public void cancelTemplateSubGoal(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // cancel template
    planTemplateObj.cancelSubGoal(key.key);
  }

  // ___________________________________________________________________________
  /**
   * Creates a template from details
   *
   * @param details the template details
   *
   * @return the key of the new template
   */
  @Override
  public CreateTemplateKey createTemplate(CreateTemplateDetails details)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Return value
    final CreateTemplateKey createTemplateKey = new CreateTemplateKey();

    // create plan template
    createTemplateKey.key = planTemplateObj.create(details.details);

    // return plan template ID
    return createTemplateKey;

  }

  // ___________________________________________________________________________
  /**
   * Gets the GANTT chart representing the template.
   *
   * @param key the template key
   *
   * @return the GANTT chart in XML form
   */
  @Override
  public ListTemplateDetailsDetails listTemplateDetails(
    ListTemplateDetailsKey key) throws AppException, InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * Lists all templates.
   *
   * @return a list of templates
   */
  @Override
  public ListTemplateDetailsList listTemplates() throws AppException,
      InformationalException {

    // return value
    final ListTemplateDetailsList listTemplateDetailsList = new ListTemplateDetailsList();

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // list templates
    listTemplateDetailsList.list = planTemplateObj.list();

    // return the list
    return listTemplateDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems not associated with the template.
   *
   * @param key the key of the template
   *
   * @return a list of planItems
   */
  @Override
  public ListUnassociatedTemplatePlanItemsDetailsList listUnassociatedTemplatePlanItems(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template BPO and manipulation variables
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final ListUnassociatedTemplatePlanItemsDetailsList listUnassociatedTemplatePlanItemsDetailsList = new ListUnassociatedTemplatePlanItemsDetailsList();

    // List all planItems unassociated with the template
    listUnassociatedTemplatePlanItemsDetailsList.list = planTemplateObj.listUnassociatedPlanItems(
      key.key);

    // return the list of unassociated planItems
    return listUnassociatedTemplatePlanItemsDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals not associated with the template.
   *
   * @param key the key of the template
   *
   * @return a list of sub goals
   */
  @Override
  public ListUnassociatedTemplateSubGoalsDetailsList listUnassociatedTemplateSubGoals(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template BPO and manipulation variables
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final ListUnassociatedTemplateSubGoalsDetailsList listUnassociatedTemplateSubGoalsDetailsList = new ListUnassociatedTemplateSubGoalsDetailsList();

    // List all planItems unassociated with the template
    listUnassociatedTemplateSubGoalsDetailsList.list = planTemplateObj.listUnassociatedSubGoals(
      key.key);

    // return the list of unassociated planItems
    return listUnassociatedTemplateSubGoalsDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies the template based on the details provided
   *
   * @param details the details
   */
  @Override
  public void modifyTemplate(ModifyTemplateDetails details)
    throws AppException, InformationalException {

    // Plan Template BPO and manipulation variables
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();
    final curam.serviceplans.sl.struct.PlanTemplateKey planTemplateKey = new curam.serviceplans.sl.struct.PlanTemplateKey();
    final curam.serviceplans.sl.struct.PlanTemplateDetails planTemplateDetails = new curam.serviceplans.sl.struct.PlanTemplateDetails();

    // assign the key
    planTemplateKey.assign(details.key);

    // assign the details
    planTemplateDetails.assign(details.details);

    // modify plan template
    planTemplateObj.modify(planTemplateKey, planTemplateDetails);
  }

  // ___________________________________________________________________________
  // BEGIN, CR00226905 MN
  /**
   * Modifies the template plan item based on the details provided
   *
   * @param details the details
   *
   * @deprecated since Curam v6, replaced with {@link
   * modifyTemplatePlanItemDetails(ModifyPlanTemplatePlanItemDetails details)}.
   * The new method modifyTemplatePlanItemDetails modifies a plan item in
   * a plan template along with approval and mandatory indicators.
   * See release note <CR00226905>.
   */
  @Override
  @Deprecated
  public void modifyTemplatePlanItem(
    curam.serviceplans.facade.struct.ModifyTemplatePlanItemDetails details)
    throws AppException, InformationalException {

    final ModifyPlanTemplatePlanItemDetails modifyDetails = new ModifyPlanTemplatePlanItemDetails();
    final PlanTemplateAndPlanItemModifyDetails planItemModifyDetails = new PlanTemplateAndPlanItemModifyDetails();

    final curam.serviceplans.sl.entity.struct.PlanTemplateAndPlanItemModifyDetails planTemplateAndPlanItemModifyDetails = new curam.serviceplans.sl.entity.struct.PlanTemplateAndPlanItemModifyDetails();

    planTemplateAndPlanItemModifyDetails.authorizedUnits = details.details.details.authorizedUnits;
    planTemplateAndPlanItemModifyDetails.description = details.details.details.description;
    planTemplateAndPlanItemModifyDetails.duration = details.details.details.duration;
    planTemplateAndPlanItemModifyDetails.expectedOutcomeID = details.details.details.expectedOutcomeID;
    planTemplateAndPlanItemModifyDetails.maximumUnits = details.details.details.maximumUnits;
    planTemplateAndPlanItemModifyDetails.planItemID = details.details.details.planItemID;
    planTemplateAndPlanItemModifyDetails.startDay = details.details.details.startDay;
    planTemplateAndPlanItemModifyDetails.versionNo = details.details.details.versionNo;

    planItemModifyDetails.details = planTemplateAndPlanItemModifyDetails;
    modifyDetails.details = planItemModifyDetails;

    modifyDetails.key = details.key;

    this.modifyTemplatePlanItemDetails(modifyDetails);

  }

  // END, CR00226905

  // ___________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Modify the template sub goal based on the details provided.
   *
   * @param details the details
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# modifyPlanTemplateSubGoal()} as part of implementing
   * localization of plan
   * template sub goal description. See release note: CR00229083.
   */
  @Override
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public void modifyTemplateSubGoal(
    curam.serviceplans.facade.struct.ModifyTemplateSubGoalDetails details)
    throws AppException, InformationalException {

    // END, CR00233815
    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // modify plan template sub goal
    planTemplateObj.modifySubGoal(details.key, details.details);
  }

  // BEGIN, CR00228796, GP
  /**
   * Modify the template sub goal based on the details provided.
   *
   * @param details the details of plan template subgoal.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplateSubGoal(
    ModifyPlanTemplateSubGoalDetails details) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().modifyPlanTemplateSubGoal(details.key,
      details.dtls);
  }

  // END, CR00228796

  // ___________________________________________________________________________
  /**
   * Reads a template from a key.
   *
   * @param key the template key
   *
   * @return the details of the template
   */
  @Override
  public ReadTemplateDetails readTemplate(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final ReadTemplateDetails readTemplateDetails = new ReadTemplateDetails();

    // read plan template
    readTemplateDetails.details = planTemplateObj.read(key.key);

    readTemplateDetails.details.planTemplateContextDescription = getPlanTemplateContextDescription(
      key);

    // return plan template details
    return readTemplateDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads a template plan item from a key.
   *
   * @param key the key
   *
   * @return the details of the template planItem
   *
   * @deprecated since Curam v6, replaced with {@link readPlanTemplatePlanItem}.
   * The new struct readPlanTemplatePlanItem aggregates
   * PlanTemplateAndPlanItemDetails, which along with existing functionality
   * reads template plan item details along with
   * mandatory and approval information. See release note <CR00226779>
   */
  @Override
  // BEGIN, CR00228422 MN
  @Deprecated
  public curam.serviceplans.facade.struct.ReadTemplatePlanItemDetails readTemplatePlanItem(PlanTemplatePlanItemKey key) throws AppException,
      InformationalException {

    final ReadPlanTemplatePlanItemDetails readPlanTemplatePlanItemDetails = this.readPlanTemplatePlanItem(
      key);

    final curam.serviceplans.facade.struct.ReadTemplatePlanItemDetails details = new curam.serviceplans.facade.struct.ReadTemplatePlanItemDetails();

    final curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails planTemplateAndPlanItemDetails = new curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails();

    // END, CR00228422

    planTemplateAndPlanItemDetails.dtls.authorizedUnits = readPlanTemplatePlanItemDetails.details.dtls.authorizedUnits;
    planTemplateAndPlanItemDetails.dtls.description = readPlanTemplatePlanItemDetails.details.dtls.description;
    planTemplateAndPlanItemDetails.dtls.duration = readPlanTemplatePlanItemDetails.details.dtls.duration;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeID = readPlanTemplatePlanItemDetails.details.dtls.expectedOutcomeID;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeName = readPlanTemplatePlanItemDetails.details.dtls.expectedOutcomeName;
    planTemplateAndPlanItemDetails.dtls.maximumUnits = readPlanTemplatePlanItemDetails.details.dtls.maximumUnits;
    planTemplateAndPlanItemDetails.dtls.name = readPlanTemplatePlanItemDetails.details.dtls.name;
    planTemplateAndPlanItemDetails.dtls.outcomeRequiredInd = readPlanTemplatePlanItemDetails.details.dtls.outcomeRequiredInd;
    planTemplateAndPlanItemDetails.dtls.planItemID = readPlanTemplatePlanItemDetails.details.dtls.planItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplatePlanItemID = readPlanTemplatePlanItemDetails.details.dtls.planTemplatePlanItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplateSubGoalID = readPlanTemplatePlanItemDetails.details.dtls.planTemplateSubGoalID;
    planTemplateAndPlanItemDetails.dtls.startDay = readPlanTemplatePlanItemDetails.details.dtls.startDay;
    planTemplateAndPlanItemDetails.dtls.versionNo = readPlanTemplatePlanItemDetails.details.dtls.versionNo;

    details.details = planTemplateAndPlanItemDetails;
    return details;

  }

  // ___________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Reads a template sub goal from a key.
   *
   * @param key the key.
   *
   * @return the details of the template sub goal.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# readPlanTemplateSubGoal()} as part of implementing
   * localization of plan
   * template sub goal description. See release note: CR00229083.
   */
  @Override
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public curam.serviceplans.facade.struct.ReadTemplateSubGoalDetails readTemplateSubGoal(PlanTemplateSubGoalKey key) throws AppException,
      InformationalException {

    // END, CR00233815
    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    // BEGIN, CR00233815, GP
    final curam.serviceplans.facade.struct.ReadTemplateSubGoalDetails readTemplateSubGoalDetails = new curam.serviceplans.facade.struct.ReadTemplateSubGoalDetails();

    // END, CR00233815

    // read template sub goal details
    readTemplateSubGoalDetails.details = planTemplateObj.readSubGoal(key.key);

    // read context description
    readTemplateSubGoalDetails.planTemplateSubGoalContextDescription = getPlanTemplateSubGoalContextDescription(
      key);

    // return template plan item details
    return readTemplateSubGoalDetails;

  }

  // BEGIN, CR00229083, GP
  /**
   * Reads a template sub goal from a key.
   *
   * @param key contains the plan template sub goal Key.
   *
   * @return the details of the template sub goal.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadPlanTemplateSubGoalDetails readPlanTemplateSubGoal(
    PlanTemplateSubGoalKey key) throws AppException, InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    final ReadPlanTemplateSubGoalDetails readPlanTemplateSubGoalDetails = new ReadPlanTemplateSubGoalDetails();

    readPlanTemplateSubGoalDetails.dtls = planTemplateObj.readTemplateSubGoal(
      key.key);

    readPlanTemplateSubGoalDetails.ctxtdtls = getPlanTemplateSubGoalContextDescription(
      key);

    return readPlanTemplateSubGoalDetails;

  }

  // END, CR00229083

  /**
   * @see curam.serviceplans.facade.intf.ServicePlan#reorderDetails(curam.serviceplans.facade.struct.ReorderTemplateDetailsDetails)
   */
  @Override
  public ListTemplateDetailsDetails reorderDetails(
    ReorderTemplateDetailsDetails details) throws AppException,
      InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * Reads plan template context description.
   *
   * @param key the key of the template
   *
   * @return Plan template context description
   */
  @Override
  protected PlanTemplateContextDescription getPlanTemplateContextDescription(
    PlanTemplateKey key) throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final PlanTemplateContextDescription planTemplateContextDescription = new PlanTemplateContextDescription();

    // read plan template name
    final curam.serviceplans.sl.struct.PlanTemplateNameDetails planTemplateNameDetails = planTemplateObj.readTemplateName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_DESCRIPTION);

    description.arg(planTemplateNameDetails.details.name);

    // assign it to the return object
    planTemplateContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return planTemplateContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Reads plan template sub goal context description.
   *
   * @param key the key of the template sub goal
   *
   * @return Plan template sub goal context description
   */
  @Override
  protected PlanTemplateSubGoalContextDescription getPlanTemplateSubGoalContextDescription(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final PlanTemplateSubGoalContextDescription planTemplateSubGoalContextDescription = new PlanTemplateSubGoalContextDescription();

    // read plan template sub goal name
    final curam.serviceplans.sl.struct.SubGoalNameDetails subGoalNameDetails = planTemplateObj.readSubGoalName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.SUBGOALNAME.TABLENAME,
      subGoalNameDetails.subGoalNameDetails.name));

    // assign it to the return object
    planTemplateSubGoalContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return planTemplateSubGoalContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Reads plan template plan item context description.
   *
   * @param key the key of the template planItem
   *
   * @return Plan template plan item context description
   */
  @Override
  protected PlanTemplatePlanItemContextDescription getPlanTemplatePlanItemContextDescription(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final PlanTemplatePlanItemContextDescription planTemplatePlanItemContextDescription = new PlanTemplatePlanItemContextDescription();

    // read plan template plan item name
    final curam.serviceplans.sl.struct.PlanItemNameDetails planItemNameDetails = planTemplateObj.readPlanItemName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.PLANITEMNAME.TABLENAME,
      planItemNameDetails.templatePlanItemNameDetails.name));

    // assign it to the return object
    planTemplatePlanItemContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return planTemplatePlanItemContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Lists names and IDs of all existing active goals.
   *
   * @return Goal name and ID details list
   */
  @Override
  public GoalNameAndIDDetailsList listActiveGoals() throws AppException,
      InformationalException {

    // Goal BPO
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // return value
    final GoalNameAndIDDetailsList goalNameAndIDDetailsList = new GoalNameAndIDDetailsList();

    // list active goals details
    goalNameAndIDDetailsList.goalNameAndIDDetailsList = goalObj.listActiveGoals();

    // return the list
    return goalNameAndIDDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads planned item context description.
   *
   * @param key the key of the service plan
   *
   * @return Service Plan context description
   */
  @Override
  protected ServicePlanContextDescription getServicePlanContextDescription(
    ReadServicePlanKey key) throws AppException, InformationalException {

    // Service Plan BPO
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // return value
    final ServicePlanContextDescription servicePlanContextDescription = new ServicePlanContextDescription();

    // read service plan type
    final curam.serviceplans.sl.struct.ServicePlanTypeDetails servicePlanTypeDetails = servicePlanObj.readType(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.SERVICEPLANTYPE.TABLENAME,
      servicePlanTypeDetails.servicePlanTypeStruct.servicePlanType));

    // assign it to the return object
    servicePlanContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return servicePlanContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan goal context description.
   *
   * @param key Goal unique identifier
   *
   * @return Service Plan Goal context description
   */
  @Override
  protected GoalContextDescription getGoalContextDescription(GoalKey key)
    throws AppException, InformationalException {

    // Goal BPO
    final curam.serviceplans.sl.intf.Goal goalObj = curam.serviceplans.sl.fact.GoalFactory.newInstance();

    // return value
    final GoalContextDescription goalContextDescription = new GoalContextDescription();

    // read goal name
    final curam.serviceplans.sl.struct.GoalNameDetails goalNameDetails = goalObj.readName(
      key.goalKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.GOALNAME.TABLENAME,
      goalNameDetails.goalNameDetails.name));

    // assign it to the return object
    goalContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return goalContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan sub goal context description.
   *
   * @param key Sub Goal unique identifier
   *
   * @return Service Plan Sub Goal context description
   */
  @Override
  protected SubGoalContextDescription getSubGoalContextDescription(
    SubGoalKey key) throws AppException, InformationalException {

    // SubGoal BPO
    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    // return value
    final SubGoalContextDescription subGoalContextDescription = new SubGoalContextDescription();

    // read sub goal name
    final curam.serviceplans.sl.struct.SubGoalNameDetails subGoalNameDetails = subGoalObj.readName(
      key.subGoalKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.SUBGOALNAME.TABLENAME,
      subGoalNameDetails.subGoalNameDetails.name));

    // assign it to the return object
    subGoalContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return subGoalContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Reads planned item context description.
   *
   * @param key PlanItem unique identifier
   *
   * @return planned item context description
   */
  @Override
  protected PlanItemContextDescription getPlanItemContextDescription(
    PlanItemKey key) throws AppException, InformationalException {

    // PlanItem BPO
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // return value
    final PlanItemContextDescription planItemContextDescription = new PlanItemContextDescription();

    // read plan item name
    final curam.serviceplans.sl.struct.PlanItemNameDetails planItemNameDetails = planItemObj.readName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.PLANITEMNAME.TABLENAME,
      planItemNameDetails.planItemNameDetails.name));

    // assign it to the return object
    planItemContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return planItemContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Reads service plan outcome context description.
   *
   * @param key Outcome unique identifier
   *
   * @return Service Plan Outcome context description
   */
  @Override
  protected OutcomeContextDescription getOutcomeContextDescription(
    OutcomeKey key) throws AppException, InformationalException {

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // return value
    final OutcomeContextDescription outcomeContextDescription = new OutcomeContextDescription();

    // read plan item name
    final curam.serviceplans.sl.struct.OutcomeNameDetails outcomeNameDetails = outcomeObj.readName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.OUTCOMENAME.TABLENAME,
      outcomeNameDetails.outcomeNameDetails.name));

    // assign it to the return object
    outcomeContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return outcomeContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Creates plan template and assigns it to service plan.
   *
   * @param createDetails contains plan template details and service plan ID
   *
   * @return Service Plan template ID
   */
  @Override
  public CreateTemplateKey createTemplateForServicePlan(
    CreateTemplateForPlanDetails createDetails) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    final CreateTemplateKey createTemplateKey = new CreateTemplateKey();

    createTemplateKey.key = servicePlanObj.createTemplate(createDetails.details,
      createDetails.key);

    return createTemplateKey;

  }

  // ___________________________________________________________________________
  /**
   * Removes template from service plan.
   *
   * @param removeKey Contains service plan ID and template ID.
   */
  @Override
  public void removeTemplateFromServicePlan(
    RemoveTemplateFromServicePlanKey removeKey) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    servicePlanObj.removeTemplate(removeKey.servicePlanKey,
      removeKey.planTemplateKey);

  }

  // ___________________________________________________________________________
  /**
   * Adds existing good causes to a plan item. The good causes and the plan item
   * are
   * identified in the details. The good causes are listed as a tab list, which
   * is parsed for further processing.
   *
   * @param details Identifies the plan item and contains the new good causes
   * details.
   */
  @Override
  public void addExistingGoodCausesToPlanItem(
    AddExistingGoodCausesToPlanItemDetails details) throws AppException,
      InformationalException {

    // parse the good cause list
    final curam.serviceplans.sl.intf.ServicePlanUtility servicePlanUtilityObj = curam.serviceplans.sl.fact.ServicePlanUtilityFactory.newInstance();
    final curam.serviceplans.sl.struct.GoodCauseKeyList goodCauseKeyList = servicePlanUtilityObj.parseGoodCauses(
      details.goodCauseTabList);

    // add the list of good causes to the planItem
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    planItemObj.addExistingGoodCauses(details.planItemKey, goodCauseKeyList);

  }

  // ___________________________________________________________________________
  /**
   * Cancels a good cause.
   *
   * @param details Identifies the good cause to be canceled.
   */
  @Override
  public void cancelGoodCause(GoodCauseCancelDetails details)
    throws AppException, InformationalException {

    // GoodCause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Cancel good cause
    goodCauseObj.cancel(details.goodCauseCancelDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new good cause.
   *
   * @param details The new good cause details
   *
   * @return A key identifying the new good cause.
   */
  @Override
  public GoodCauseKey createGoodCause(GoodCauseCreateDetails details)
    throws AppException, InformationalException {

    // GoodCause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Return value
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    // create good cause
    goodCauseKey.goodCauseKey = goodCauseObj.create(
      details.goodCauseCreateDetails);

    // return goalID
    return goodCauseKey;
  }

  // ___________________________________________________________________________
  /**
   * Creates a new good cause for the plan item identified in the details, using
   * the information in the details to build the good cause.
   *
   * @param details The new good cause details
   *
   * @return A key identifying the new good cause.
   */
  @Override
  public GoodCauseKey createGoodCauseForPlanItem(
    CreateGoodCauseForPlanItemDetails details) throws AppException,
      InformationalException {

    // PlanItem BPO
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // return value
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    // create a good cause for the planItem
    goodCauseKey.goodCauseKey = planItemObj.createGoodCause(details.planItemKey,
      details.goodCauseCreateDetails);

    // return the new good cause identifier
    return goodCauseKey;
  }

  // ___________________________________________________________________________
  /**
   * Reads good cause context description.
   *
   * @param key Identifies the good cause
   *
   * @return Good cause context description
   */
  @Override
  protected GoodCauseContextDescription getGoodCauseContextDescription(
    GoodCauseKey key) throws AppException, InformationalException {

    // Good cause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Return value
    final GoodCauseContextDescription goodCauseContextDescription = new GoodCauseContextDescription();

    // read good cause name
    final curam.serviceplans.sl.struct.GoodCauseNameDetails goodCauseNameDetails = goodCauseObj.readName(
      key.goodCauseKey);

    // create the context description
    final LocalisableString description = new LocalisableString(
      BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.GOODCAUSENAME.TABLENAME,
      goodCauseNameDetails.goodCauseNameDetails.name));

    // assign it to the return object
    goodCauseContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return goodCauseContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Lists all good causes.
   *
   * @return The list of good causes.
   */
  @Override
  public GoodCauseDetailsList listGoodCauses() throws AppException,
      InformationalException {

    // Good cause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Return value
    final GoodCauseDetailsList goodCauseDetailsList = new GoodCauseDetailsList();

    // List good causes
    goodCauseDetailsList.goodCauseDetailsList = goodCauseObj.list();

    // Return list of goals
    return goodCauseDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all good causes associated with the plan item identified by the key.
   *
   * @param key Identifies the planItem
   *
   * @return Good Cause details list
   */
  @Override
  public PlanItemGoodCauseList listGoodCausesForPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    // PlanItem BPO
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // return value
    final PlanItemGoodCauseList planItemGoodCauseList = new PlanItemGoodCauseList();

    // list good causes
    planItemGoodCauseList.planItemGoodCauseDetailsList = planItemObj.listGoodCauses(
      key.key);

    // read context description
    planItemGoodCauseList.contextDescription = getPlanItemContextDescription(
      key);

    return planItemGoodCauseList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all good causes not associated with the plan item identified by the
   * key.
   *
   * @param key Identifies the planItem.
   *
   * @return Good Cause details list
   */
  @Override
  public PlanItemUnassociatedGoodCauseList listGoodCausesNotAssociatedWithPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    // PlanItem BPO
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // return value
    final PlanItemUnassociatedGoodCauseList planItemUnassociatedGoodCauseList = new PlanItemUnassociatedGoodCauseList();

    // list unassociated good causes
    planItemUnassociatedGoodCauseList.planItemUnassociatedGoodCauseDetailsList = planItemObj.listUnassociatedGoodCauses(
      key.key);

    // read context description
    planItemUnassociatedGoodCauseList.contextDescription = getPlanItemContextDescription(
      key);

    return planItemUnassociatedGoodCauseList;
  }

  // BEGIN, CR00234442, GP
  /**
   * Modifies a good cause.
   *
   * @param details The modified details.
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# modifyGoodCause1()} as part of implementing
   * localization of Good Cause
   * description. See release note: CR00234442.
   */
  @Override
  @Deprecated
  public void modifyGoodCause(
    curam.serviceplans.facade.struct.GoodCauseModifyDetails details)
    throws AppException, InformationalException {

    // END, CR00234442

    // GoodCause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Modify GoodCause
    goodCauseObj.modify(details.goodCauseModifyDetails);

  }

  // BEGIN, CR00234442, GP
  /**
   * Modifies a good cause.
   *
   * @param details contains the details to be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyGoodCause1(ModifyGoodCauseDetails details)
    throws AppException, InformationalException {

    GoodCauseFactory.newInstance().modifyGoodCause(details.dtls);

  }

  // END, CR00234442

  // ___________________________________________________________________________
  /**
   * Reads a good cause's details.
   *
   * @param key Identifies the good cause.
   *
   * @return The good cause details.
   */
  @Override
  public GoodCauseDetails readGoodCause(GoodCauseKey key)
    throws AppException, InformationalException {

    // GoodCause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Return value
    final GoodCauseDetails goodCauseDetails = new GoodCauseDetails();

    // Read good cause details
    goodCauseDetails.goodCauseDetails = goodCauseObj.read(key.goodCauseKey);

    // read context description
    goodCauseDetails.goodCauseContextDescription = getGoodCauseContextDescription(
      key);

    // Return goal details
    return goodCauseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Removes the association between a good cause and a plan item. The good
   * cause
   * and the plan item are identified within the key.
   *
   * @param key Identifies the plan item and good cause.
   */
  @Override
  public void removeGoodCauseFromPlanItem(RemoveGoodCauseFromPlanItemKey key)
    throws AppException, InformationalException {

    // PlanItem BPO
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // remove the good cause from the planItem
    planItemObj.removeGoodCause(key.planItemGoodCauseKey);
  }

  // ___________________________________________________________________________
  /**
   * Lists all plan template sub goals associated with the plan template.
   *
   * @param key Plan Template Sub Goal unique identifier
   *
   * @return The list sub goals associated with plan template
   */
  @Override
  public TemplateSubGoalDetailsList listPlanTemplateSubGoals(
    PlanTemplateKey key) throws AppException, InformationalException {

    // Plan Template process class
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final curam.serviceplans.facade.struct.TemplateSubGoalDetailsList templateSubGoalDetailsList = new TemplateSubGoalDetailsList();

    // list sub goals
    templateSubGoalDetailsList.templateSubGoalDetailsList = planTemplateObj.listSubGoals(
      key.key);

    // get context description

    return templateSubGoalDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all plan template planItems associated with the plan template sub
   * goal.
   *
   * @param key Plan Template unique identifier
   *
   * @return The list of plan template planItems associated with plan template
   * sub goal
   */
  @Override
  public TemplatePlanItemDetailsList listPlanTemplateSubGoalPlanItems(
    PlanTemplateSubGoalKey key) throws AppException, InformationalException {

    // Plan Template process class
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final curam.serviceplans.facade.struct.TemplatePlanItemDetailsList templatePlanItemDetailsList = new TemplatePlanItemDetailsList();

    // list sub goals
    templatePlanItemDetailsList.templatePlanItemDetailsList = planTemplateObj.listPlanItemsForTemplateSubGoal(
      key.key);

    return templatePlanItemDetailsList;
  }

  // ___________________________________________________________________________

  /**
   * Lists all outcomes associated with the plan template planItem.
   *
   * @param key Identifies the planItem
   * @return list of the Plan Item Outcome Details
   */
  @Override
  public PlanItemOutcomeDetailsList listAvailableOutcomesForPlanTemplatePlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();
    final PlanItemOutcomeDetailsList planItemOutcomeDetailsList = new PlanItemOutcomeDetailsList();

    planItemOutcomeDetailsList.planItemOutcomeDetailsList = planItemObj.listOutcomes(
      key.key);

    planItemOutcomeDetailsList.key = key.key;
    return planItemOutcomeDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Reads plan item name and expected outcome name for plan template planItem.
   *
   * @param key planItemID and expectedOutcomeID
   *
   * @return PlanItem name and outcome name
   */
  @Override
  public PlanItemAndOutcomeNameDetails readPlanItemAndOutcomeName(
    PlanItemAndOutcomeNameKey key) throws AppException,
      InformationalException {

    // return value
    final PlanItemAndOutcomeNameDetails planItemAndOutcomeNameDetails = new PlanItemAndOutcomeNameDetails();

    // Plan Template process class
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // read plan item name and outcome name
    planItemAndOutcomeNameDetails.planItemAndOutcomeNameDetails = planTemplateObj.readPlanItemAndOutcomeName(
      key.planItemAndOutcomeKey);
    return planItemAndOutcomeNameDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates a service plan approval check .
   *
   * @param details Service Plan Approval Check Details
   * @return key The newly created key for the ServcePlanApprovalCheck
   */
  @Override
  public ServicePlanApprovalCheckKey createApprovalCheck(
    ServicePlanApprovalCheckDetails details) throws AppException,
      InformationalException {

    // ServicePlanApprovalCheck process class
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();
    // creating return struct
    final curam.serviceplans.facade.struct.ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new curam.serviceplans.facade.struct.ServicePlanApprovalCheckKey();

    // assigning the key
    servicePlanApprovalCheckKey.approvalcheckkey = servicePlanApprovalCheckObj.createSPApprovalCheck(
      details.details);

    return servicePlanApprovalCheckKey;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a service plan approval check
   *
   * @param key Identifies the service plan approval check.
   */
  @Override
  public void cancelApprovalCheck(CancelApprovalCheckKey key)
    throws AppException, InformationalException {

    // BPO manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();

    servicePlanApprovalCheckObj.cancelSPApprovalCheck(key.cancelkey);

  }

  // ___________________________________________________________________________
  /**
   * Lists the approval checks for the specified service plan.
   *
   * @param key Identifies the service plan key.
   * @return Approval Checks List
   */

  @Override
  public ApprovalChecksList listApprovalChecks(SPKey key)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();

    // creating the return struct
    final curam.serviceplans.facade.struct.ApprovalChecksList approvalChecksList = new curam.serviceplans.facade.struct.ApprovalChecksList();
    // creating the struct to hold context description
    curam.serviceplans.facade.struct.ServicePlanContextDescription servicePlanContextDescription = new curam.serviceplans.facade.struct.ServicePlanContextDescription();
    // struct used to read service plan key
    final curam.serviceplans.facade.struct.ReadServicePlanKey readServicePlanKey = new curam.serviceplans.facade.struct.ReadServicePlanKey();

    // assigning that with the service plan key
    readServicePlanKey.key.key.servicePlanID = key.key.spKey.servicePlanID;
    // reading context description for the service plan
    servicePlanContextDescription = getServicePlanContextDescription(
      readServicePlanKey);

    // list approval checks
    approvalChecksList.detailList = servicePlanApprovalCheckObj.listSPApprovalChecks(
      key.key);
    // set context description
    approvalChecksList.contextDescription = servicePlanContextDescription;
    return approvalChecksList;
  }

  // ___________________________________________________________________________
  /**
   * Reads a service plan approval check and returns its details.
   *
   * @param key Identifies the service plan approval check.
   * @return the service plan approval check details.
   */
  @Override
  public ServicePlanApprovalCheckDetails readApprovalCheck(
    ServicePlanApprovalCheckKey key) throws AppException,
      InformationalException {

    // ServicePlanApprovalCheck BPO manipulation variables
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();
    final ServicePlanApprovalCheckDetails servicePlanApprovalCheckDetails = new ServicePlanApprovalCheckDetails();

    // Read servicePlanApprovalCheck Details
    servicePlanApprovalCheckDetails.details = servicePlanApprovalCheckObj.readSPApprovalCheck(
      key.approvalcheckkey);
    // called for only service plan
    if (servicePlanApprovalCheckDetails.details.details.typeCode.equals(
      SERVICEPLANAPPROVALCHECK.SERVICE_PLAN)) {
      // getting service plan id to get context description
      curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.struct.ServicePlanKey();

      servicePlanKey = servicePlanApprovalCheckObj.readServicePlanName(
        key.approvalcheckkey);
      curam.serviceplans.facade.struct.ServicePlanContextDescription servicePlanContextDescription = new curam.serviceplans.facade.struct.ServicePlanContextDescription();

      final curam.serviceplans.facade.struct.ReadServicePlanKey readServicePlanKey = new curam.serviceplans.facade.struct.ReadServicePlanKey();

      readServicePlanKey.key.key.servicePlanID = servicePlanKey.key.servicePlanID;
      servicePlanContextDescription = getServicePlanContextDescription(
        readServicePlanKey);
      // setting return struct with context description
      servicePlanApprovalCheckDetails.contextDescription = servicePlanContextDescription;
    }
    return servicePlanApprovalCheckDetails;

  }

  // _________________________________________________________________________
  /**
   * Reads the context description for user type
   * service plan approval check.
   *
   * @param key Identifies the service plan approval check.
   * @return the userName Details
   */
  @Override
  protected UserContextDescription getUserContextDescription(
    ServicePlanApprovalCheckKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();
    final UserContextDescription userContextDescription = new UserContextDescription();
    final curam.serviceplans.sl.struct.UserNameDetails userNameDetails = servicePlanApprovalCheckObj.readUserName(
      key.approvalcheckkey);
    // reading user surname
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = userNameDetails.userNamedtl.userName;
    final UsersDtls usersDtls = usersObj.read(usersKey);

    // Prepare the context description details
    userContextDescription.contextDescription = usersDtls.firstname
      + CuramConst.gkSpace + usersDtls.surname;

    // return userContextDescription;
    return userContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Lists the service plan types which are active.
   *
   * @param key Identifies the status.
   * @return the ServicePlan type Detail List .
   */
  @Override
  public ServicePlantypeDtlList listActiveSPTypes(ServicePlanStatus key)
    throws AppException, InformationalException {

    // return struct
    final ServicePlantypeDtlList servicePlantypeDtlList = new ServicePlantypeDtlList();

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    servicePlantypeDtlList.servicePlanTypeDtlList = servicePlanObj.listActiveSPTypes(
      key.status);
    return servicePlantypeDtlList;
  }

  // ___________________________________________________________________________
  /**
   * Lists the approval checks for a user.
   *
   * @param key Identifies the user.
   * @return the Service Plan Approval Check List.
   */
  @Override
  public SPApprovalChecksList listUserApprovalChecks(
    UserApprovalCheckSearchKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();
    // return struct
    final SPApprovalChecksList spApprovalChecksList = new SPApprovalChecksList();

    spApprovalChecksList.SPapprovalcheckslist = servicePlanApprovalCheckObj.listUserApprovalChecks(
      key.userAppCheckSearch);
    final UserContextDescription userContextDescription = new UserContextDescription();
    // reading the user surname for context description
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userAppCheckSearch.searchKey.userName;

    userContextDescription.contextDescription = usersObj.getFullName(usersKey).fullname;
    // set context description
    spApprovalChecksList.contextDescription = userContextDescription;
    return spApprovalChecksList;
  }

  // ___________________________________________________________________________
  /**
   * Reads the service plan approval check and service
   * plan type.
   *
   * @param key Identifies the service plan approval check.
   * @return the ServicePlan Approval Checks Details
   */
  @Override
  public ApprovalChecksDetails readApprovalCheckandSPType(
    ServicePlanApprovalCheckKey key) throws AppException,
      InformationalException {

    final ApprovalChecksDetails approvalChecksDetails = new ApprovalChecksDetails();
    // approval check BPO
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();

    // return struct
    approvalChecksDetails.approvalChecksDetails = servicePlanApprovalCheckObj.readUserApprovalCheck(
      key.approvalcheckkey);

    // getting user name to get context description
    UserContextDescription userContextDescription = new UserContextDescription();

    userContextDescription = getUserContextDescription(key);
    // set context description
    approvalChecksDetails.contextDescription = userContextDescription;
    return approvalChecksDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the service plan approval check.
   *
   * @param details Service plan approval check details
   */
  @Override
  public void modifyApprovalCheck(
    curam.serviceplans.facade.struct.ModifyApprovalCheckDetail details)
    throws AppException, InformationalException {

    // ServicePlanApprovalCheck process class
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();
    // creating the structs
    final curam.serviceplans.sl.struct.ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new curam.serviceplans.sl.struct.ServicePlanApprovalCheckKey();
    final curam.serviceplans.sl.struct.ModifyApprovalCheckDetail modifyApprovalCheckDetail = new curam.serviceplans.sl.struct.ModifyApprovalCheckDetail();

    // setting key & details
    servicePlanApprovalCheckKey.key.servicePlanApprovalCheckID = details.detail.detail.servicePlanApprovalCheckID;
    modifyApprovalCheckDetail.detail = details.detail.detail;
    servicePlanApprovalCheckObj.modifySPApprovalCheck(
      servicePlanApprovalCheckKey, modifyApprovalCheckDetail);
  }

  // ___________________________________________________________________________
  /**
   * Reads template details for modify
   *
   * @param key Plan template key
   * @return the Service Plan Template Details
   */
  @Override
  public ReadTemplateDetails readTemplateForModify(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();
    final curam.serviceplans.sl.struct.GoalNameAndIDDetails goalNameAndIDDetails = new curam.serviceplans.sl.struct.GoalNameAndIDDetails();

    // return value
    final ReadTemplateDetails readTemplateDetails = new ReadTemplateDetails();

    // read plan template
    readTemplateDetails.details = planTemplateObj.read(key.key);

    // set the current goal ID
    goalNameAndIDDetails.details.goalID = readTemplateDetails.details.dtls.goalID;

    // read list of existing goals
    readTemplateDetails.goalList = planTemplateObj.listAvailableGoals(
      goalNameAndIDDetails);

    return readTemplateDetails;

  }

  // ___________________________________________________________________________
  /**
   * Lists all existing service plan security identifiers
   *
   * @return Security identifiers list
   */
  @Override
  public curam.serviceplans.facade.struct.SecurityIdentifierList listSIDs()
    throws AppException, InformationalException {

    // to be returned
    final curam.serviceplans.facade.struct.SecurityIdentifierList securityIdentifierList = new curam.serviceplans.facade.struct.SecurityIdentifierList();

    // ServicePlan process class
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // list service plan SIDs
    securityIdentifierList.list = servicePlanObj.listSIDs();

    // return the list
    return securityIdentifierList;
  }

  // BEGIN, CR00000010, PMD
  // ___________________________________________________________________________
  /**
   * Gets the template tree xml to send to the Tree Control Widget
   *
   * @param key Plan template key
   * @return the Service Plan Template Tree XML
   */
  @Override
  public XMLDetails getServicePlanTemplateTreeXML(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Return Object
    XMLDetails xmlDetails = new XMLDetails();

    // PlanTemplateTree process class
    final PlanTemplateTree planTemplateTreeObj = PlanTemplateTreeFactory.newInstance();

    // Get the XML representation of the template data
    xmlDetails = planTemplateTreeObj.getXMLStringForServicePlanTemplateTree(
      key.key);

    return xmlDetails;
  }

  // END, CR00000010

  // BEGIN, CR00000028, PMD
  // ___________________________________________________________________________
  /**
   * Creates a plan group for a service plan template
   *
   * @param details The plan group details
   * @return the key of the new plan group
   */
  @Override
  public PlanTemplatePlanGroupKey createTemplatePlanGroup(
    PlanTemplatePlanGroupDetails details) throws AppException,
      InformationalException {

    // Return Object
    final PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Create the plan group
    planTemplatePlanGroupKey.key = planTemplateObj.createPlanGroup(details.dtls);

    return planTemplatePlanGroupKey;
  }

  // BEGIN, CR00235328, GP
  /**
   * Modifies the template plan group based on the details provided
   *
   * @param details the plan group details
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# modifyPlanTemplatePlanGroup()} as part of implementing
   * localization of
   * plan template plan group attributes. See release note: CR00235328.
   */
  @Override
  @Deprecated
  // END, CR00235328
  public void modifyTemplatePlanGroup(ModifyTemplatePlanGroupDetails details)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Modify the plan group
    planTemplateObj.modifyPlanGroup(details.key, details.details);

  }

  // BEGIN, CR00235328, GP
  /**
   * Modifies the template plan group based on the details provided.
   *
   * @param details contains the plan group details to be modified.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplatePlanGroup(
    PlanTemplatePlanGroupModifyDetails details) throws AppException,
      InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    planTemplateObj.modifyTemplatePlanGroup(details.dtls);

  }

  // END, CR00235328

  // ___________________________________________________________________________
  /**
   * Reads a service plan template plan group
   *
   * @param key the plan group key
   * @return details the details of the plan group
   */
  @Override
  public ReadTemplatePlanGroupDetails readTemplatePlanGroup(
    PlanTemplatePlanGroupKey key) throws AppException, InformationalException {

    // Return Object
    final ReadTemplatePlanGroupDetails readTemplatePlanGroupDetails = new ReadTemplatePlanGroupDetails();

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Read the plan group details
    readTemplatePlanGroupDetails.details = planTemplateObj.readPlanGroup(
      key.key);

    readTemplatePlanGroupDetails.planTemplatePlanGroupContextDescription = getPlanTemplatePlanGroupContextDescription(
      key);

    return readTemplatePlanGroupDetails;
  }

  // ___________________________________________________________________________
  /**
   * Removes a service plan template plan group (physically deleted)
   *
   * @param key the plan group key
   */
  @Override
  public void removeTemplatePlanGroup(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Remove the plan group
    planTemplateObj.removePlanGroup(key.key);

  }

  // ___________________________________________________________________________
  /**
   * Reads the plan template plan group context description.
   *
   * @param key the key of the plan group
   *
   * @return Plan template plan group context description
   */
  @Override
  public PlanTemplatePlanGroupContextDescription getPlanTemplatePlanGroupContextDescription(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Return Object
    final PlanTemplatePlanGroupContextDescription planTemplatePlanGroupContextDescription = new PlanTemplatePlanGroupContextDescription();

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Read the plan group name
    final curam.serviceplans.sl.struct.PlanGroupNameDetails planGroupNameDetails = planTemplateObj.readPlanGroupName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(planGroupNameDetails.planGroupNameDetails.name);

    // assign it to the return object
    planTemplatePlanGroupContextDescription.contextDescription = description.toClientFormattedText();

    return planTemplatePlanGroupContextDescription;
  }

  // END, CR00000028

  // BEGIN, CR00000034, PMD
  // ___________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Reads plan item details and a list of plan item names
   *
   * @param key contains the plan item key and the plan template sub goal key
   *
   * @return list of plan items available for modification and the template plan
   * item details
   *
   * @deprecated since Curam v6, replaced with
   * {@link readPlanTemplatePlanItemForModify}.
   * The new method along with existing functionality reads template plan item
   * details along with mandatory and approval information.
   * See release note <CR00226779>
   */
  @Override
  // BEGIN, CR00228422 MN
  @Deprecated
  public curam.serviceplans.facade.struct.ReadTemplatePlanItemForModifyDetails readTemplatePlanItemForModify(ReadTemplatePlanItemForModifyKey key)
    throws AppException, InformationalException {

    final ReadPlanTemplatePlanItemForModifyDetails readPlanTemplatePlanItemDetails = this.readPlanTemplatePlanItemForModify(
      key);

    final curam.serviceplans.facade.struct.ReadTemplatePlanItemForModifyDetails details = new curam.serviceplans.facade.struct.ReadTemplatePlanItemForModifyDetails();

    final curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemDetails planTemplateAndPlanItemDetails = new curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemDetails();

    // END, CR00228422

    planTemplateAndPlanItemDetails.authorizedUnits = readPlanTemplatePlanItemDetails.dtls.details.authorizedUnits;
    planTemplateAndPlanItemDetails.description = readPlanTemplatePlanItemDetails.dtls.details.description;
    planTemplateAndPlanItemDetails.duration = readPlanTemplatePlanItemDetails.dtls.details.duration;
    planTemplateAndPlanItemDetails.expectedOutcomeID = readPlanTemplatePlanItemDetails.dtls.details.expectedOutcomeID;
    planTemplateAndPlanItemDetails.expectedOutcomeName = readPlanTemplatePlanItemDetails.dtls.details.expectedOutcomeName;
    planTemplateAndPlanItemDetails.maximumUnits = readPlanTemplatePlanItemDetails.dtls.details.maximumUnits;
    planTemplateAndPlanItemDetails.name = readPlanTemplatePlanItemDetails.dtls.details.name;
    planTemplateAndPlanItemDetails.outcomeRequiredInd = readPlanTemplatePlanItemDetails.dtls.details.outcomeRequiredInd;
    planTemplateAndPlanItemDetails.planItemID = readPlanTemplatePlanItemDetails.dtls.details.planItemID;
    planTemplateAndPlanItemDetails.planTemplatePlanItemID = readPlanTemplatePlanItemDetails.dtls.details.planTemplatePlanItemID;
    planTemplateAndPlanItemDetails.planTemplateSubGoalID = readPlanTemplatePlanItemDetails.dtls.details.planTemplateSubGoalID;
    planTemplateAndPlanItemDetails.startDay = readPlanTemplatePlanItemDetails.dtls.details.startDay;
    planTemplateAndPlanItemDetails.versionNo = readPlanTemplatePlanItemDetails.dtls.details.versionNo;

    details.dtls.planItemDetails = planTemplateAndPlanItemDetails;
    return details;

  }

  // END, CR00226779
  // END, CR00000034

  // BEGIN, CR00000038, CSH
  // ___________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Reads sub-goal details and a list of sub-goal names
   *
   * @param key contains the sub-goal key and the plan template key
   *
   * @return list of sub-goals available for modification and the template
   * sub-goal details
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# readPlanTemplateSubGoalForModify()} as part of
   * implementing localization of plan
   * template sub goal description. See release note: CR00229083.
   */
  @Override
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public curam.serviceplans.facade.struct.ReadTemplateSubGoalForModifyDetails readTemplateSubGoalForModify(ReadTemplateSubGoalForModifyKey key)
    throws AppException, InformationalException {

    // END, CR00233815

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Return Object
    // BEGIN, CR00233815, GP
    final curam.serviceplans.facade.struct.ReadTemplateSubGoalForModifyDetails readTemplateSubGoalForModifyDetails = new curam.serviceplans.facade.struct.ReadTemplateSubGoalForModifyDetails();

    // END, CR00233815

    // Get the sub-goal list and the template sub-goal details
    readTemplateSubGoalForModifyDetails.dtls = planTemplateObj.readTemplateSubGoalForModify(
      key.key);

    return readTemplateSubGoalForModifyDetails;
  }

  // END, CR00000038

  // BEGIN, CR00229083, GP
  /**
   * Reads sub-goal details and a list of sub-goal names.
   *
   * @param key contains the sub-goal key and the plan template key.
   *
   * @return list of sub-goals available for modification and the
   * template sub-goal details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadTemplateAndSubGoalForModifyDetails readPlanTemplateSubGoalForModify(ReadTemplateSubGoalForModifyKey key)
    throws AppException, InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    final ReadTemplateAndSubGoalForModifyDetails readTemplateSubGoalForModifyDetails = new ReadTemplateAndSubGoalForModifyDetails();

    // Get the sub-goal list and the template sub-goal details.
    readTemplateSubGoalForModifyDetails.dtls = planTemplateObj.readPlanTemplateSubGoalForModify(
      key.key);

    return readTemplateSubGoalForModifyDetails;
  }

  // END, CR00229083

  // BEGIN, CR00000022, PMD
  // ___________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Adds a plan item to the template.
   *
   * @param details the plan item details
   * @return the key of the new template plan item
   *
   * @deprecated since Curam v6, replaced with
   * {@link createPlanTemplatePlanItem}.
   * The new struct AddPlanTemplatePlanItemDetails aggregates
   * PlanTemplateAndPlanItemDetails, which along with existing functionality
   * adds plan item details to a sub goal along with
   * mandatory and approval information. See release note <CR00226779>
   */
  @Override
  @Deprecated
  public PlanTemplatePlanItemKey createTemplatePlanItem(
    curam.serviceplans.facade.struct.AddTemplatePlanItemDetails details)
    throws AppException, InformationalException {

    final AddPlanTemplatePlanItemDetails addPlanTemplatePlanItemDetails = new AddPlanTemplatePlanItemDetails();

    final PlanTemplateAndPlanItemDetails planTemplateAndPlanItemDetails = new PlanTemplateAndPlanItemDetails();

    planTemplateAndPlanItemDetails.dtls.authorizedUnits = details.details.dtls.authorizedUnits;
    planTemplateAndPlanItemDetails.dtls.description = details.details.dtls.description;
    planTemplateAndPlanItemDetails.dtls.duration = details.details.dtls.duration;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeID = details.details.dtls.expectedOutcomeID;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeName = details.details.dtls.expectedOutcomeName;
    planTemplateAndPlanItemDetails.dtls.maximumUnits = details.details.dtls.maximumUnits;
    planTemplateAndPlanItemDetails.dtls.name = details.details.dtls.name;
    planTemplateAndPlanItemDetails.dtls.outcomeRequiredInd = details.details.dtls.outcomeRequiredInd;
    planTemplateAndPlanItemDetails.dtls.planItemID = details.details.dtls.planItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplatePlanItemID = details.details.dtls.planTemplatePlanItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplateSubGoalID = details.details.dtls.planTemplateSubGoalID;
    planTemplateAndPlanItemDetails.dtls.startDay = details.details.dtls.startDay;
    planTemplateAndPlanItemDetails.dtls.versionNo = details.details.dtls.versionNo;

    addPlanTemplatePlanItemDetails.details = planTemplateAndPlanItemDetails;

    return this.createPlanTemplatePlanItem(addPlanTemplatePlanItemDetails);

  }

  // END, CR00226779
  // END, CR00000022

  // BEGIN, CR00000061, CM
  // ___________________________________________________________________________
  /**
   * Reads a plan item and a service unit based on the key provided and returns
   * the its details.
   *
   * @param key Identifies the planItem.
   *
   * @return The plan item details.
   */
  @Override
  public PlanItemServiceUnitDetails readPlanItemServiceUnitDeliveryDetails(
    PlanItemKey key) throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    final PlanItemServiceUnitDetails details = new PlanItemServiceUnitDetails();

    details.dtls = planItemObj.readPlanItemServiceUnitDeliveryDetails(key.key);

    // TODO Aggregate to the context description
    // // read context description
    // details.contextDescription = getPlanItemContextDescription(key);

    return details;

  }

  // END, CR00000061

  // BEGIN, CR00047794, PMD
  // ___________________________________________________________________________
  /**
   * Adds a milestone to a service plan template.
   *
   * @param details the milestone details
   * @return The newly created key for the PlanTemplateMilestone
   */
  @Override
  public PlanTemplateMilestoneKey addTemplateMilestone(
    PlanTemplateMilestoneDetails details) throws AppException,
      InformationalException {

    return PlanTemplateFactory.newInstance().addMilestone(
      details.planTemplateMilestoneDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies a service plan template milestone based on the details provided
   *
   * @param details the modified service plan template milestone details
   */
  @Override
  public void modifyTemplateMilestone(PlanTemplateMilestoneDetails details)
    throws AppException, InformationalException {

    PlanTemplateFactory.newInstance().modifyMilestone(
      details.planTemplateMilestoneDetails);
  }

  // BEGIN, CR00229083, GP
  /**
   * Reads a service plan template milestone.
   *
   * @param key the template milestone key.
   * @return the details of the template milestone.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServicePlan# readTemplateMilestone()} as part of implementing
   * localization of plan
   * template Milestone comments. See release note: CR00229083.
   */
  @Override
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public curam.serviceplans.facade.struct.ReadTemplateMilestoneDetails readTemplateMilestone(PlanTemplateMilestoneKey key) throws AppException,
      InformationalException {

    // Return struct
    final curam.serviceplans.facade.struct.ReadTemplateMilestoneDetails readTemplateMilestoneDetails = new curam.serviceplans.facade.struct.ReadTemplateMilestoneDetails();

    // END, CR00233815

    // Read the template milestone
    readTemplateMilestoneDetails.readDetails = PlanTemplateFactory.newInstance().readMilestone(
      key);

    return readTemplateMilestoneDetails;
  }

  // BEGIN, CR00228796, GP
  /**
   * Reads a service plan template milestone.
   *
   * @param key contains the template milestone key.
   * @return the details of the template milestone.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadPlanTemplateMilestoneDetails readPlanTemplateMilestone(
    PlanTemplateMilestoneKey key) throws AppException, InformationalException {

    final ReadPlanTemplateMilestoneDetails readPlanTemplateMilestoneDetails = new ReadPlanTemplateMilestoneDetails();

    readPlanTemplateMilestoneDetails.dtls = PlanTemplateFactory.newInstance().readTemplateMilestone(
      key);

    return readPlanTemplateMilestoneDetails;
  }

  // END, CR00228796

  // ___________________________________________________________________________
  /**
   * Removes a service plan template milestone (physically deleted)
   *
   * @param key the template milestone key
   */
  @Override
  public void removeTemplateMilestone(PlanTemplateMilestoneKey key)
    throws AppException, InformationalException {

    PlanTemplateFactory.newInstance().removeMilestone(key);
  }

  // _________________________________________________________________________
  /**
   * Method to return a list of active milestone configurations.
   *
   * @return a list of active milestone configurations
   */
  @Override
  public MilestoneConfigIDAndNameList listActiveMilestoneConfigs()
    throws AppException, InformationalException {

    // Return struct
    final MilestoneConfigIDAndNameList milestoneConfigIDAndNameList = new MilestoneConfigIDAndNameList();

    // Get the list of milestone configurations
    milestoneConfigIDAndNameList.dtlsList = PlanTemplateFactory.newInstance().listActiveMilestoneConfigs();

    return milestoneConfigIDAndNameList;
  }

  // END, CR00047794

  // BEGIN, CR00081013, PMD
  // ___________________________________________________________________________
  /**
   * Method to list all service plan types
   *
   * @return a list of all service plan types
   */
  @Override
  public ServicePlanTypes listAllServicePlanTypes() throws AppException,
      InformationalException {

    // Return struct
    final ServicePlanTypes servicePlanTypes = new ServicePlanTypes();

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    // Get the list of all service plan types
    servicePlanTypes.spConfigTypes = servicePlanObj.listAllServicePlanTypes();

    return servicePlanTypes;
  }

  // END, CR00081013

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for obtaining the list of approval criteria for a specific plan
   * item.
   *
   * @param key
   * contains ID of the plan item
   * @return PlanItemApprovalCriteriaList
   * a list of all approval criteria for a plan item
   * @throws AppException, InformationalException
   */
  @Override
  public PlanItemApprovalCriteriaList listApprovalCriteriaForPlanItem(
    PlanItemKey key) throws AppException, InformationalException {

    // Create return struct
    final PlanItemApprovalCriteriaList planItemApprovalCriteriaList = new PlanItemApprovalCriteriaList();

    // Create object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make call to populate return list
    planItemApprovalCriteriaList.list = planItemObj.listApprovalCriteria(
      key.key);

    // Read context description
    planItemApprovalCriteriaList.contextDesc = getPlanItemContextDescription(
      key);

    // Return back the list
    return planItemApprovalCriteriaList;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for adding existing approval criteria to a specific plan item.
   *
   * @param details
   * AddExistingApprovalCriteriaToPlanItemDetails - approval criteria
   * details to associate to the plan item
   *
   * @throws AppException, InformationalException
   */
  @Override
  public void addExistingApprovalCriteriaToPlanItem(
    AddExistingApprovalCriteriaToPlanItemDetails details)
    throws AppException, InformationalException {

    // Create the service plan utility object instance
    final ServicePlanUtility servicePlanUtilityObj = ServicePlanUtilityFactory.newInstance();

    // Parse the approval criteria list
    final ApprovalCriteriaKeyList approvalCriteriaKeyList = servicePlanUtilityObj.parseApprovalCriteria(
      details.approvalCriteriaTabList);

    // Create plan item object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make the call to add the approval criteria to the plan item
    planItemObj.addExistingApprovalCriteria(details.planItemKey,
      approvalCriteriaKeyList);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for removing the association between an approval criteria and a
   * specific plan item.
   *
   * @param details
   * PlanItemApprovalCriteriaCancelDetails - details of the plan item
   * approval criteria to cancel
   *
   * @throws AppException, InformationalException
   */
  @Override
  public void cancelApprovalCriteriaForPlanItem(
    PlanItemApprovalCriteriaCancelDetails details) throws AppException,
      InformationalException {

    // Create object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make the call to cancel the association between the plan item and
    // approval criteria
    planItemObj.cancelApprovalCriteria(details.cancelDtls);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for creating an approval criteria then linking it to a
   * specific plan item.
   *
   * @param details
   * details of the new approval criteria and plan item to link it to
   * @return PlanItemApprovalCriteriaLinkKey
   * key of the newly created link record
   * @throws AppException, InformationalException
   */
  @Override
  public PlanItemApprovalCriteriaLinkKey createApprovalCriteriaForPlanItem(
    CreateApprovalCriteriaForPlanItemDetails details) throws AppException,
      InformationalException {

    // Create return struct
    final PlanItemApprovalCriteriaLinkKey planItemApprovalCriteriaLinkKey = new PlanItemApprovalCriteriaLinkKey();

    // Create object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make call to create record and set return value
    planItemApprovalCriteriaLinkKey.key.key.planItemApprovalCriteriaLinkID = planItemObj.createApprovalCriteria(details.dtls).key.planItemApprovalCriteriaLinkID;

    // Return the result
    return planItemApprovalCriteriaLinkKey;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for modifying a plan item approval criteria link record
   *
   * @param details
   * PlanItemApprovalCriteriaLinkModifyDetails - details of the plan
   * item approval criteria to modify
   *
   * @throws AppException, InformationalException
   */
  @Override
  public void modifyApprovalCriteriaForPlanItem(
    PlanItemApprovalCriteriaLinkModifyDetails details) throws AppException,
      InformationalException {

    // Create object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make the call to modify the details
    planItemObj.modifyApprovalCriteria(details.dtls);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for listing all approval criteria not currently associated to a
   * specific plan item.
   *
   * @param key
   * contains ID of the plan item
   * @return PlanItemUnassociationApprovalCriteriaList
   * list of approval criteria not associated to the plan item
   * @throws AppException, InformationalException
   */
  @Override
  public PlanItemUnassociatedApprovalCriteriaList listApprovalCriteriaNotAssociatedWithPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    // Create return struct
    final PlanItemUnassociatedApprovalCriteriaList planItemUnassociatedAppCritList = new PlanItemUnassociatedApprovalCriteriaList();

    // Create object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make the call to obtain the list and populate return struct
    planItemUnassociatedAppCritList.dtlsList = planItemObj.listUnassociatedApprovalCriteria(
      key.key);

    // Return the result
    return planItemUnassociatedAppCritList;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Method for reading a specific plan item approval criteria details
   *
   * @param key
   * key of the plan item approval criteria record
   * @return PlanItemApprovalCriteriaDetails
   * details of the plan item approval criteria
   * @throws AppException, InformationalException
   */
  @Override
  public PlanItemApprovalCriteriaDetails readApprovalCriteriaForPlanItem(
    PlanItemApprovalCriteriaLinkKey key) throws AppException,
      InformationalException {

    // Create return struct
    final PlanItemApprovalCriteriaDetails planItemApprovalCriteriaDetails = new PlanItemApprovalCriteriaDetails();

    // Create object instance
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Make the call to read the details and populate return struct
    planItemApprovalCriteriaDetails.dtls = planItemObj.readApprovalCriteria(
      key.key);

    // Return the details
    return planItemApprovalCriteriaDetails;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * This method is used to list all the Approval Criteria that are not
   * associated with Plan Template Plan Item
   *
   * @param key
   * PlanTemplatePlanItemKey
   * @return UnassociatedTemplateApprovalCriteriaDetailsList
   * @throws AppException, InformationalException
   */
  @Override
  public UnassociatedTemplateApprovalCriteriaDetailsList listUnassociatedTemplateApprovalCriteria(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // Create Plan Template object
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    curam.serviceplans.sl.struct.PlanTemplatePlanItemKey planTempPlanItemKey = new curam.serviceplans.sl.struct.PlanTemplatePlanItemKey();

    // Create return struct
    final UnassociatedTemplateApprovalCriteriaDetailsList list = new UnassociatedTemplateApprovalCriteriaDetailsList();

    // Assign Plan Template Plan Item ID
    planTempPlanItemKey = key.key;

    // get the unassociated Plan Template Plan Item Approval Criteria List
    list.detailsList = planTemplateObj.listUnassociatedTemplateApprovalCriteria(
      planTempPlanItemKey);

    // Check for the associated approval criteria with plan template plan item
    if (list.detailsList.ApprCritAssociatedInd
      && list.detailsList.list.dtls.isEmpty()) {
      final AppException e = new AppException(
        BPOPLANTEMPLATE.ERR_PLAN_TEMPLATE_APPR_CRIT_ALL_ASSOCIATED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e, curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } // Check for the associated approval criteria with plan item
    else if (!list.detailsList.ApprCritAssociatedInd
      && list.detailsList.list.dtls.isEmpty()) {
      final AppException e = new AppException(
        BPOPLANTEMPLATE.ERR_PLAN_TEMPLATE_APPR_CRIT_NOT_ASSOCIATED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e, curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final ServicePlanInformationalMessage servicePlanInformationalMessage = new ServicePlanInformationalMessage();

      servicePlanInformationalMessage.informationMsgTxt = warnings[i];

      list.messageList.servicePlanInformationalMessage.addRef(
        servicePlanInformationalMessage);

    }
    return list;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Adds a Approval Criteria to the template.
   *
   * @param details
   * the plan item details
   * @return PlanTemplatePlanItemApprCritKey
   * @throws AppException, InformationalException
   */
  @Override
  public PlanTemplatePlanItemApprCritKey addTemplatePlanItemApprovalCriteria(
    AddTemplatePlanItemApprovalCriteriaDetails details) throws AppException,
      InformationalException {

    // Create Plan Template Object
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    // Create return value
    final PlanTemplatePlanItemApprCritKey key = new PlanTemplatePlanItemApprCritKey();

    // Create Plan Template Plan Item Approval Criteria
    key.key = planTemplateObj.createApprovalCriteria(details.dtls);

    return key;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Reads the service plan template plan item approval criteria key.
   *
   * @param key
   * Plan template plan item approval criteria
   * @return ReadTemplatePlanItemApprovalCriteriaDetails
   * Template plan item approval criteria details
   * @throws AppException, InformationalException
   */
  @Override
  public ReadTemplatePlanItemApprovalCriteriaDetails readTemplatePlanItemApprovalCriteria(PlanTemplatePlanItemApprCritKey key)
    throws AppException, InformationalException {

    // Create Plan Template Object
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    // Return object
    final ReadTemplatePlanItemApprovalCriteriaDetails details = new ReadTemplatePlanItemApprovalCriteriaDetails();

    // Read service plan template plan item approval criteria
    details.dtls = planTemplateObj.readApprovalCriteria(key.key);

    return details;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Modify existing service plan template plan item approval criteria entry.
   *
   * @param key
   * Modify template plan item approval criteria details
   * @throws AppException, InformationalException
   */
  @Override
  public void modifyTemplatePlanItemApprovalCriteria(
    ModifyTemplatePlanItemApprovalCriteriaDetails key) throws AppException,
      InformationalException {

    // Create Plan Template Object
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    // modifies the service plan template plan item approval criteria entry.
    planTemplateObj.modifyApprovalCriteria(key.dtls);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Remove the service plan template plan item approval criteria entry.
   *
   * @param key
   * Plan template plan item approval criteria
   * @throws AppException, InformationalException
   */
  @Override
  public void removeTemplatePlanItemApprovalCriteria(
    PlanTemplatePlanItemApprCritKey key) throws AppException,
      InformationalException {

    // Create Plan Template Object
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    // removes the service plan template plan item approval criteria entry
    planTemplateObj.removeApprovalCriteria(key.key);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Return a list of active plan items.
   *
   * @return PlanItemNameIDDetailsList
   * Plan item name id details list
   * @throws AppException, InformationalException
   */
  @Override
  public PlanItemNameIDDetailsList listActivePINames() throws AppException,
      InformationalException {

    final PlanItemNameIDDetailsList result = new PlanItemNameIDDetailsList();

    final PlanItem planItemObj = PlanItemFactory.newInstance();

    result.planItemNameIDDetailsList = planItemObj.listActivePINames();

    return result;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Reads approval criteria context description.
   *
   * @param details Details read from database
   * @return String context description
   * @throws AppException, InformationalException
   */
  protected String getApprovalCriteriaContextDescription(
    ApprovalCriteriaDetails details) throws AppException,
      InformationalException {

    String contextDescription = null;

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(
        curam.codetable.APPROVALCRITERIANAME.TABLENAME,
        details.details.dtls.criteriaName));

    // assign it to the return object
    contextDescription = description.toClientFormattedText();

    // return context description
    return contextDescription;
  }

  // END, CR00161962

  // BEGIN, CR00218024, CSH
  // ___________________________________________________________________________
  /**
   * Lists the details of all existing outcomes.
   *
   * @return List of outcomes
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public OutcomeDetailsList listOutcomeDetails() throws AppException,
      InformationalException {

    // Return value
    final OutcomeDetailsList outcomeDetailsList = new OutcomeDetailsList();

    // Outcome BPO
    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    // list outcomes
    outcomeDetailsList.list = outcomeObj.listOutcomeDetails();

    // return list of outcomes
    return outcomeDetailsList;
  }

  // END, CR00218024

  /**
   * Lists the approval checks for the specified service plan.with versionNo
   *
   * @param key Identifies the service plan key.
   * @return Approval Checks List
   */
  @Override
  public ApprovalChecksListAndVersionNo listApprovalChecksAndVersionNo(
    SPKey key) throws AppException, InformationalException {

    // create object from service layer
    final curam.serviceplans.sl.intf.ServicePlanApprovalCheck servicePlanApprovalCheckObj = curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory.newInstance();

    // creating the return struct
    final ApprovalChecksListAndVersionNo approvalChecksList = new ApprovalChecksListAndVersionNo();
    // struct used to read service plan key
    final curam.serviceplans.facade.struct.ReadServicePlanKey readServicePlanKey = new curam.serviceplans.facade.struct.ReadServicePlanKey();

    // assigning that with the service plan key
    readServicePlanKey.key.key.servicePlanID = key.key.spKey.servicePlanID;

    // list approval checks
    approvalChecksList.dtls = servicePlanApprovalCheckObj.listSPApprovalChecksAndVersionNo(
      key.key);
    return approvalChecksList;
  }

  /**
   * Lists all good causes. includes versionNo for delete to work fully.
   *
   * @return The list of good causes.
   */
  @Override
  public GoodCauseDetailsListAndVersionNo listGoodCausesAndVersionNo()
    throws AppException, InformationalException {

    // Good cause BPO manipulation variables
    final curam.serviceplans.sl.intf.GoodCause goodCauseObj = curam.serviceplans.sl.fact.GoodCauseFactory.newInstance();

    // Return value
    final GoodCauseDetailsListAndVersionNo goodCauseDetailsList = new GoodCauseDetailsListAndVersionNo();

    // List good causes
    goodCauseDetailsList.dtls = goodCauseObj.listAndVersionNo();

    // Return list of goals
    return goodCauseDetailsList;
  }

  // BEGIN, CR00226779 MN
  /**
   * Adds a plan item to the template including the mandatory and approval
   * information.
   *
   * @param details
   * the plan item details.
   */
  @Override
  public void addPlanTemplatePlanItem(AddPlanTemplatePlanItemDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.facade.intf.ServicePlan servicePlanObj = ServicePlanFactory.newInstance();

    servicePlanObj.createPlanTemplatePlanItem(details);
  }

  /**
   * Adds a plan item to the template including the mandatory and approval
   * information.
   *
   * @param details the plan item details
   * @return the key of the new template plan item
   */
  @Override
  public PlanTemplatePlanItemKey createPlanTemplatePlanItem(
    AddPlanTemplatePlanItemDetails details) throws AppException,
      InformationalException {

    // Return Object
    final PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // add plan item to the template sub goal
    planTemplatePlanItemKey.key = planTemplateObj.createTemplatePlanItem(
      details.details);

    return planTemplatePlanItemKey;
  }

  /**
   * Reads a template plan item from a key including the mandatory and approval
   * information.
   *
   * @param key the key
   *
   * @return the details of the template planItem
   */
  @Override
  public ReadPlanTemplatePlanItemDetails readPlanTemplatePlanItem(
    PlanTemplatePlanItemKey key) throws AppException, InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // return value
    final ReadPlanTemplatePlanItemDetails readTemplatePlanItemDetails = new ReadPlanTemplatePlanItemDetails();

    // read template plan item details
    readTemplatePlanItemDetails.details = planTemplateObj.readTemplatePlanItem(
      key.key);

    // read context description
    readTemplatePlanItemDetails.planTemplatePlanItemContextDescription = getPlanTemplatePlanItemContextDescription(
      key);

    // return template plan item details
    return readTemplatePlanItemDetails;
  }

  /**
   * Reads plan item details and a list of plan item names including the
   * mandatory and approval information.
   *
   * @param key contains the plan item key and the plan template sub goal key
   *
   * @return list of plan items available for modification and the
   * template plan item details
   */
  @Override
  public ReadPlanTemplatePlanItemForModifyDetails readPlanTemplatePlanItemForModify(ReadTemplatePlanItemForModifyKey key)
    throws AppException, InformationalException {

    // Return struct
    final ReadPlanTemplatePlanItemForModifyDetails readTemplatePlanItemForModifyDetails = new ReadPlanTemplatePlanItemForModifyDetails();

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // Get the plan item list and the template plan item details
    readTemplatePlanItemForModifyDetails.dtls = planTemplateObj.readPlanTemplatePlanItemForModify(
      key.key);

    return readTemplatePlanItemForModifyDetails;
  }

  // END, CR00226779

  // BEGIN, CR00226905 MN
  /**
   * Modifies the template plan item along with mandatory and approval
   * indicators based on the details provided.
   *
   * @param details the details
   */
  @Override
  public void modifyTemplatePlanItemDetails(
    ModifyPlanTemplatePlanItemDetails details) throws AppException,
      InformationalException {

    // Plan Template BPO
    final curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.fact.PlanTemplateFactory.newInstance();

    // modify plan template planItem
    planTemplateObj.modifyPlanTemplatePlanItem(details.key, details.details);

  }

  // END, CR00226905

  // BEGIN, CR00226647, GP
  /**
   * Assigns the text translation details.
   *
   * @param textTranslation
   * The text translation information.
   *
   * @return The text translation details.
   */
  // BEGIN, CR00227878, GP
  protected TextTranslationDetails assignTextTranslationDtls(
    final TextTranslation textTranslation) {

    // END, CR00227878
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    textTranslationDetails.dtls.localeCode = textTranslation.getLocale().getCode();
    textTranslationDetails.dtls.localizableTextID = textTranslation.getLocalizableTextID();
    final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      textTranslationDetails.dtls.localizableTextID);

    if (localizableTextHandler.isShortTextInd()) {

      textTranslationDetails.dtls.shortText = textTranslation.getShortText();
    } else {
      textTranslationDetails.dtls.text = textTranslation.getText();
    }

    textTranslationDetails.dtls.textTranslationID = textTranslation.getID();
    return textTranslationDetails;
  }

  /**
   * Provides text translation for the attribute.
   *
   * @param LocalizableNameTextTranslationDetails
   * The localizable name text translation details.
   *
   * @return The view localizable text details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ViewLocalizableTextDetails getTextTranslation(
    final LocalizableTextDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    final LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.dtls.localizableTextID);
    final ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();

    viewLocalizableTextDetails.dtls.localizableTextID = localizableTextHandler.getID();

    for (final TextTranslation textTranslation : localizableTextHandler.listTranslations()) {

      final TextTranslationDetails textTranslationDetails = assignTextTranslationDtls(
        textTranslation);

      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);

    }
    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Plan Template attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Plan Template
   * name.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplateNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    planTemplateObj.addNameTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Plan Template attribute,
   * name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Plan Template name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplateNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    planTemplateObj.modifyNameTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Reads the text translation for the Plan Template attribute, name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplateNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
      ReadPlanTemplateDetails readPlanTemplateDetails = new ReadPlanTemplateDetails();
      final PlanTemplateKey planTemplateKey = new PlanTemplateKey();

      planTemplateKey.key.planTemplateKey.planTemplateID = localizableTextDetails.dtls.localizableTextParentID;

      readPlanTemplateDetails = planTemplateObj.read(planTemplateKey.key);

      textTranslationDetails.dtls.text = readPlanTemplateDetails.dtls.name;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Plan Template attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplateNameText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    ReadPlanTemplateDetails readPlanTemplateDetails = new ReadPlanTemplateDetails();
    final PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    planTemplateKey.key.planTemplateKey.planTemplateID = localizableTextDetails.dtls.localizableTextParentID;
    readPlanTemplateDetails = planTemplateObj.read(planTemplateKey.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } // BEGIN, CR00229083, GP
    else if (0 != readPlanTemplateDetails.dtls.nameTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readPlanTemplateDetails.dtls.nameTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      // BEGIN, CR00246419, GP
      textTranslationDetails.dtls.shortText = readPlanTemplateDetails.dtls.name;
      // END, CR00246419
      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Plan Template attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Plan Template
   * description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplateDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    planTemplateObj.addDescriptionTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Plan Template attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Plan Template name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplateDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    planTemplateObj.modifyDescriptionTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Reads the text translation for the Plan Template attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplateDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
      ReadPlanTemplateDetails readPlanTemplateDetails = new ReadPlanTemplateDetails();
      final PlanTemplateKey planTemplateKey = new PlanTemplateKey();

      planTemplateKey.key.planTemplateKey.planTemplateID = localizableTextDetails.dtls.localizableTextParentID;

      readPlanTemplateDetails = planTemplateObj.read(planTemplateKey.key);

      textTranslationDetails.dtls.text = readPlanTemplateDetails.dtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Service Plan attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplateDescriptionText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    ReadPlanTemplateDetails readPlanTemplateDetails = new ReadPlanTemplateDetails();
    final PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    planTemplateKey.key.planTemplateKey.planTemplateID = localizableTextDetails.dtls.localizableTextParentID;
    readPlanTemplateDetails = planTemplateObj.read(planTemplateKey.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != readPlanTemplateDetails.dtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readPlanTemplateDetails.dtls.descriptionTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readPlanTemplateDetails.dtls.description;
      // BEGIN, CR00227878, GP
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        // END, CR00227878
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00226647

  // BEGIN, CR00227878, GP
  /**
   * Creates a text translation for the Service Plan attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Service Plan
   * description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addServicePlanDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    servicePlanObj.addDescriptionTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Service Plan attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Service Plan
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyServicePlanDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();

    servicePlanObj.modifyDescriptionTextTranslation(localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Service Plan attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readServicePlanDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();
      final ReadServicePlanDetails readServicePlanDetails = new ReadServicePlanDetails();
      final curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.struct.ServicePlanKey();

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      // As there is no localization yet, read it from Service Plan entity.
      servicePlanKey.key.servicePlanID = localizableTextDetails.dtls.localizableTextParentID;
      readServicePlanDetails.details = servicePlanObj.read(servicePlanKey);

      textTranslationDetails.dtls.text = readServicePlanDetails.details.plan.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Service Plan attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableServicePlanDescriptionText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final curam.serviceplans.sl.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.fact.ServicePlanFactory.newInstance();
    final ReadServicePlanDetails readServicePlanDetails = new ReadServicePlanDetails();
    final curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.struct.ServicePlanKey();

    servicePlanKey.key.servicePlanID = localizableTextDetails.dtls.localizableTextParentID;
    readServicePlanDetails.details = servicePlanObj.read(servicePlanKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != readServicePlanDetails.details.plan.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readServicePlanDetails.details.plan.descriptionTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      // As there is no localization yet, read it from Service Plan entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readServicePlanDetails.details.plan.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00227878

  // BEGIN, CR00228110, GP
  /**
   * Creates a text translation for the Goal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Goal description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final Goal goalObj = GoalFactory.newInstance();

    goalObj.addDescriptionTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Goal attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Goal
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final Goal goalObj = GoalFactory.newInstance();

    goalObj.modifyDescriptionTextTranslation(localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Goal attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Goal description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final Goal goalObj = GoalFactory.newInstance();
      final ReadGoalDetails readGoalDetails = new ReadGoalDetails();
      final GoalKey goalKey = new GoalKey();

      goalKey.goalKey.goalKey.goalID = localizableTextDetails.dtls.localizableTextParentID;
      // As there is no localization yet, read it from Goal entity.
      readGoalDetails.readGoalDetails = goalObj.read(goalKey.goalKey);

      textTranslationDetails.dtls.text = readGoalDetails.readGoalDetails.goalDtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Goal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableGoalDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final Goal goalObj = GoalFactory.newInstance();

    final ReadGoalDetails readGoalDetails = new ReadGoalDetails();
    final curam.serviceplans.sl.struct.GoalKey goalKey = new curam.serviceplans.sl.struct.GoalKey();

    goalKey.goalKey.goalID = localizableTextDetails.dtls.localizableTextParentID;

    readGoalDetails.readGoalDetails = goalObj.read(goalKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != readGoalDetails.readGoalDetails.goalDtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readGoalDetails.readGoalDetails.goalDtls.descriptionTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      // As there is no localization yet, read it from Goal entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readGoalDetails.readGoalDetails.goalDtls.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the SubGoal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for SubGoal
   * description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addSubGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final SubGoal subGoalObj = SubGoalFactory.newInstance();

    subGoalObj.addDescriptionTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the SubGoal attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of SubGoal
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifySubGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    subGoalObj.modifyDescriptionTextTranslation(localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the SubGoal attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the SubGoal description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readSubGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final SubGoal subGoalObj = SubGoalFactory.newInstance();
      final ReadSubGoalDetails readSubGoalDetails = new ReadSubGoalDetails();
      final SubGoalKey subGoalKey = new SubGoalKey();

      subGoalKey.subGoalKey.subGoalKey.subGoalID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from SubGoal entity.
      readSubGoalDetails.details = subGoalObj.read(subGoalKey.subGoalKey);

      textTranslationDetails.dtls.text = readSubGoalDetails.details.dtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the SubGoal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the SubGoal description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableSubGoalDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final SubGoal subGoalObj = SubGoalFactory.newInstance();

    final ReadSubGoalDetails readSubGoalDetails = new ReadSubGoalDetails();
    final curam.serviceplans.sl.struct.SubGoalKey subGoalKey = new curam.serviceplans.sl.struct.SubGoalKey();

    subGoalKey.subGoalKey.subGoalID = localizableTextDetails.dtls.localizableTextParentID;

    readSubGoalDetails.details = subGoalObj.read(subGoalKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != readSubGoalDetails.details.dtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readSubGoalDetails.details.dtls.descriptionTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      // As there is no localization yet, read it from SubGoal entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readSubGoalDetails.details.dtls.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Approval Check attribute, comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Approval Check
   * attribute, comments.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addApprovalCheckCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final ServicePlanApprovalCheck servicePlanApprovalCheckObj = ServicePlanApprovalCheckFactory.newInstance();

    servicePlanApprovalCheckObj.addCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Modifies the text translation details for the Approval Check attribute,
   * comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Approval Check
   * attribute, comments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyApprovalCheckCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    final ServicePlanApprovalCheck servicePlanApprovalCheckObj = ServicePlanApprovalCheckFactory.newInstance();

    servicePlanApprovalCheckObj.modifyCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Approval Check attribute,
   * comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Approval Check attribute,
   * comments.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readApprovalCheckCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final ServicePlanApprovalCheck servicePlanApprovalCheckObj = ServicePlanApprovalCheckFactory.newInstance();
      final ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new ServicePlanApprovalCheckKey();

      final ServicePlanApprovalCheckDetails servicePlanApprovalCheckDetails = new ServicePlanApprovalCheckDetails();

      servicePlanApprovalCheckKey.approvalcheckkey.key.servicePlanApprovalCheckID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from ServicePlanApprovalCheck
      // entity.
      servicePlanApprovalCheckDetails.details = servicePlanApprovalCheckObj.readSPApprovalCheck(
        servicePlanApprovalCheckKey.approvalcheckkey);

      textTranslationDetails.dtls.text = servicePlanApprovalCheckDetails.details.details.comments;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Approval Check attribute,
   * comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Approval Check attribute,
   * comments.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableApprovalCheckCommentsText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final ServicePlanApprovalCheck servicePlanApprovalCheckObj = ServicePlanApprovalCheckFactory.newInstance();
    final ServicePlanApprovalCheckKey servicePlanApprovalCheckKey = new ServicePlanApprovalCheckKey();

    final ServicePlanApprovalCheckDetails servicePlanApprovalCheckDetails = new ServicePlanApprovalCheckDetails();

    servicePlanApprovalCheckKey.approvalcheckkey.key.servicePlanApprovalCheckID = localizableTextDetails.dtls.localizableTextParentID;

    servicePlanApprovalCheckDetails.details = servicePlanApprovalCheckObj.readSPApprovalCheck(
      servicePlanApprovalCheckKey.approvalcheckkey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0
      != servicePlanApprovalCheckDetails.details.details.commentsTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = servicePlanApprovalCheckDetails.details.details.commentsTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      // As there is no localization yet, read it from ServicePlanApprovalCheck
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = servicePlanApprovalCheckDetails.details.details.comments;

      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00228110

  // BEGIN, CR00228796, GP
  /**
   * Creates a text translation for the PlanTemplateMilestone, comments.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for SubGoal
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplateMilestoneCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().addTemplateMilestoneCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Modifies the text translation details for the PlanTemplateMilestone
   * attribute,
   * comments.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text used for the localization of PlanTemplateMilestone
   * attribute, comments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplateMilestoneCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().modifyTemplateMilestoneCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the PlanTemplateMilestone attribute,
   * comments.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplateMilestone attribute,
   * comments.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplateMilestoneCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
      final PlanTemplateMilestoneKey planTemplateMilestoneKey = new PlanTemplateMilestoneKey();

      final ReadPlanTemplateMilestoneDetails readPlanTemplateMilestoneDetails = new ReadPlanTemplateMilestoneDetails();

      planTemplateMilestoneKey.planTemplateMilestoneID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from PlanTemplateMilestone
      // entity.
      readPlanTemplateMilestoneDetails.dtls = planTemplateObj.readTemplateMilestone(
        planTemplateMilestoneKey);

      textTranslationDetails.dtls.text = readPlanTemplateMilestoneDetails.dtls.dtls.comments;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the PlanTemplateMilestone attribute,
   * comments.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplateMilestone attribute,
   * comments.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplateMilestoneCommentsText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    final PlanTemplateMilestoneKey planTemplateMilestoneKey = new PlanTemplateMilestoneKey();

    final ReadPlanTemplateMilestoneDetails readPlanTemplateMilestoneDetails = new ReadPlanTemplateMilestoneDetails();

    planTemplateMilestoneKey.planTemplateMilestoneID = localizableTextDetails.dtls.localizableTextParentID;

    readPlanTemplateMilestoneDetails.dtls = planTemplateObj.readTemplateMilestone(
      planTemplateMilestoneKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != readPlanTemplateMilestoneDetails.dtls.dtls.commentsTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readPlanTemplateMilestoneDetails.dtls.dtls.commentsTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      // As there is no localization yet, read it from PlanTemplateMilestone
      // entity.
      textTranslationDetails.dtls.text = readPlanTemplateMilestoneDetails.dtls.dtls.comments;

      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the PlanTemplatePlanItem attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for
   * PlanTemplatePlanItem description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplatePlanItemDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().addTemplatePlanItemDescriptionTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Modifies the text translation details for the PlanTemplatePlanItem
   * attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text used for the localization of PlanTemplatePlanItem
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplatePlanItemDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().modifyTemplatePlanItemDescriptionTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the PlanTemplatePlanItem attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplatePlanItem description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplatePlanItemDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
      PlanTemplateAndPlanItemDetails planTemplateAndPlanItemDetails = new PlanTemplateAndPlanItemDetails();
      final curam.serviceplans.sl.struct.PlanTemplatePlanItemKey planTempPlanItemKey = new curam.serviceplans.sl.struct.PlanTemplatePlanItemKey();

      planTempPlanItemKey.key.planTemplatePlanItemID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from PlanTemplatePlanItem
      // entity.
      planTemplateAndPlanItemDetails = planTemplateObj.readTemplatePlanItem(
        planTempPlanItemKey);

      textTranslationDetails.dtls.text = planTemplateAndPlanItemDetails.dtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the PlanTemplatePlanItem attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplatePlanItem description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplatePlanItemDescriptionText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    PlanTemplateAndPlanItemDetails planTemplateAndPlanItemDetails = new PlanTemplateAndPlanItemDetails();
    final curam.serviceplans.sl.struct.PlanTemplatePlanItemKey planTempPlanItemKey = new curam.serviceplans.sl.struct.PlanTemplatePlanItemKey();

    planTempPlanItemKey.key.planTemplatePlanItemID = localizableTextDetails.dtls.localizableTextParentID;

    planTemplateAndPlanItemDetails = planTemplateObj.readTemplatePlanItem(
      planTempPlanItemKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != planTemplateAndPlanItemDetails.dtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = planTemplateAndPlanItemDetails.dtls.descriptionTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      // As there is no localization yet, read it from PlanTemplatePlanItem
      // entity.
      textTranslationDetails.dtls.text = planTemplateAndPlanItemDetails.dtls.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the PlanTemplateSubGoal attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for
   * PlanTemplateSubGoal description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplateSubGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    // BEGIN, CR00247170, GP
    PlanTemplateFactory.newInstance().addTemplateSubGoalDescriptionTextTranslation(
      localizableTextDetails.dtls);
    // END, CR00247170
  }

  /**
   * Modifies the text translation details for the PlanTemplateSubGoal
   * attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text used for the localization of PlanTemplateSubGoal
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplateSubGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    // BEGIN, CR00247170, GP
    PlanTemplateFactory.newInstance().modifyTemplateSubGoalDescriptionTextTranslation(
      localizableTextDetails.dtls);
    // END, CR00247170
  }

  /**
   * Reads the text translation for the PlanTemplateSubGoal attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplateSubGoal description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplateSubGoalDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
      PlanTemplateAndSubGoalReadDetails planTemplateSubGoalDetails = new PlanTemplateAndSubGoalReadDetails();
      final PlanTemplateSubGoalKey PlanTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      PlanTemplateSubGoalKey.key.key.planTemplateSubGoalID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from PlanTemplateSubGoal
      // entity.
      planTemplateSubGoalDetails = planTemplateObj.readTemplateSubGoal(
        PlanTemplateSubGoalKey.key);

      textTranslationDetails.dtls.text = planTemplateSubGoalDetails.dtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the PlanTemplateSubGoal attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplateSubGoal description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplateSubGoalDescriptionText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    // BEGIN, CR00229083, GP
    final PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    PlanTemplateAndSubGoalReadDetails planTemplateSubGoalDetails = new PlanTemplateAndSubGoalReadDetails();
    final PlanTemplateSubGoalKey PlanTemplateSubGoalKey = new PlanTemplateSubGoalKey();

    PlanTemplateSubGoalKey.key.key.planTemplateSubGoalID = localizableTextDetails.dtls.localizableTextParentID;

    planTemplateSubGoalDetails = planTemplateObj.readTemplateSubGoal(
      PlanTemplateSubGoalKey.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != planTemplateSubGoalDetails.dtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = planTemplateSubGoalDetails.dtls.descriptionTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {
      // END, CR00229083

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      // As there is no localization yet, read it from PlanTemplateSubGoal
      // entity.
      textTranslationDetails.dtls.text = planTemplateSubGoalDetails.dtls.description;

      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00228796

  // BEGIN, CR00234442, GP
  /**
   * Creates a text translation for the GoodCause entity attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for GoodCause
   * description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addGoodCauseDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    GoodCauseFactory.newInstance().addDescriptionTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the GoodCause entity attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of GoodCause
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyGoodCauseDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    GoodCauseFactory.newInstance().modifyDescriptionTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the GoodCause entity attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the GoodCause description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readGoodCauseDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final GoodCause goodCauseObj = GoodCauseFactory.newInstance();
      final GoodCauseDetails goodCauseDetails = new GoodCauseDetails();
      final GoodCauseKey goodCauseKey = new GoodCauseKey();

      goodCauseKey.goodCauseKey.goodCauseKey.goodCauseID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from GoodCause entity.
      goodCauseDetails.goodCauseDetails = goodCauseObj.read(
        goodCauseKey.goodCauseKey);

      textTranslationDetails.dtls.text = goodCauseDetails.goodCauseDetails.goodCauseDetails.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the GoodCause attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the GoodCause description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableGoodCauseDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    final GoodCause goodCauseObj = GoodCauseFactory.newInstance();

    final GoodCauseDetails goodCauseDetails = new GoodCauseDetails();
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    goodCauseKey.goodCauseKey.goodCauseKey.goodCauseID = localizableTextDetails.dtls.localizableTextParentID;

    // As there is no localization yet, read it from GoodCause entity.
    goodCauseDetails.goodCauseDetails = goodCauseObj.read(
      goodCauseKey.goodCauseKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0
      != goodCauseDetails.goodCauseDetails.goodCauseDetails.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = goodCauseDetails.goodCauseDetails.goodCauseDetails.descriptionTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from SubGoal entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = goodCauseDetails.goodCauseDetails.goodCauseDetails.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Outcome entity attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Outcome
   * description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addOutcomeDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    OutcomeFactory.newInstance().addDescriptionTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Outcome entity attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Outcome
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyOutcomeDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    OutcomeFactory.newInstance().modifyDescriptionTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Outcome entity attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Outcome description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readOutcomeDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final Outcome outcomeObj = OutcomeFactory.newInstance();
      final ReadOutcomeDetails readOutcomeDetails = new ReadOutcomeDetails();
      final OutcomeKey outcomeKey = new OutcomeKey();

      outcomeKey.key.key.outcomeID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from outcome entity.
      readOutcomeDetails.readOutcomeDetails = outcomeObj.read(outcomeKey.key);

      textTranslationDetails.dtls.text = readOutcomeDetails.readOutcomeDetails.outcomeDtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Outcome attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the GoodCause description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizableOutcomeDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    final Outcome outcomeObj = OutcomeFactory.newInstance();
    final ReadOutcomeDetails readOutcomeDetails = new ReadOutcomeDetails();
    final OutcomeKey outcomeKey = new OutcomeKey();

    outcomeKey.key.key.outcomeID = localizableTextDetails.dtls.localizableTextParentID;

    // As there is no localization yet, read it from outcome entity.
    readOutcomeDetails.readOutcomeDetails = outcomeObj.read(outcomeKey.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0
      != readOutcomeDetails.readOutcomeDetails.outcomeDtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readOutcomeDetails.readOutcomeDetails.outcomeDtls.descriptionTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from SubGoal entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readOutcomeDetails.readOutcomeDetails.outcomeDtls.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the PlanItem entity attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for PlanItem
   * description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanItemDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanItemFactory.newInstance().addDescriptionTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the PlanItem entity attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of PlanItem
   * description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanItemDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanItemFactory.newInstance().modifyDescriptionTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the PlanItem entity attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the PlanItem description.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanItemDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanItem planItemObj = PlanItemFactory.newInstance();
      final ReadPlanItemDetails readPlanItemDetails = new ReadPlanItemDetails();
      final PlanItemKey planItemKey = new PlanItemKey();

      planItemKey.key.key.planItemID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from PlanItem entity.
      readPlanItemDetails.details = planItemObj.read(planItemKey.key);

      textTranslationDetails.dtls.text = readPlanItemDetails.details.dtls.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the PlanItem attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the PlanItem description.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanItemDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final ReadPlanItemDetails readPlanItemDetails = new ReadPlanItemDetails();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.key.planItemID = localizableTextDetails.dtls.localizableTextParentID;

    // As there is no localization yet, read it from PlanItem entity.
    readPlanItemDetails.details = planItemObj.read(planItemKey.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != readPlanItemDetails.details.dtls.descriptionTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readPlanItemDetails.details.dtls.descriptionTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from PlanItem entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readPlanItemDetails.details.dtls.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00234442

  // BEGIN, CR00234077, TV
  // ___________________________________________________________________________
  /**
   * Creates a new plan item from the details.
   *
   * @param details
   * the new plan item details
   *
   * @return a key for the new planItem
   */
  @Override
  public PlanItemKey createPlanItemDetails(PlanItemDetails details)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();
    final PlanItemKey key = new PlanItemKey();

    key.key = planItemObj.createPlanItem(details.details);

    return key;

  }

  // END, CR00234077

  // BEGIN, CR00235328, GP
  /**
   * Creates a text translation for the PlanTemplatePlanGroup entity attribute,
   * comments.
   *
   * @param localizableTextTranslationDetails contains the localizable text
   * translation details used for PlanTemplatePlanGroup comments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplatePlanGroupCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().addTemplatePlanGroupCommentsTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the PlanTemplatePlanGroup entity
   * attribute, comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplatePlanGroup comments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplatePlanGroupCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().modifyTemplatePlanGroupCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the PlanTemplatePlanGroup entity attribute,
   * comments.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplatePlanGroup comments.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplatePlanGroupCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
      PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new PlanTemplatePlanGroupDtls();
      final PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

      planTemplatePlanGroupKey.key.key.planTemplatePlanGroupID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from PlanItem entity.
      planTemplatePlanGroupDtls = planTemplatePlanGroupObj.read(
        planTemplatePlanGroupKey.key.key);

      textTranslationDetails.dtls.text = planTemplatePlanGroupDtls.comments;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the PlanTemplatePlanGroup attribute,
   * comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplatePlanGroup comments.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplatePlanGroupCommentsText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    final PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new PlanTemplatePlanGroupDtls();
    final PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

    planTemplatePlanGroupKey.key.key.planTemplatePlanGroupID = localizableTextDetails.dtls.localizableTextParentID;

    // As there is no localization yet, read it from PlanTemplatePlanGroup
    // entity.
    planTemplatePlanGroupDtls = planTemplatePlanGroupObj.read(
      planTemplatePlanGroupKey.key.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != planTemplatePlanGroupDtls.commentsTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = planTemplatePlanGroupDtls.commentsTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from PlanTemplatePlanGroup
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = planTemplatePlanGroupDtls.comments;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the PlanTemplatePlanGroup entity attribute,
   * name.
   *
   * @param localizableTextTranslationDetails contains the localizable text
   * translation details used for PlanTemplatePlanGroup name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void addPlanTemplatePlanGroupNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().addTemplatePlanGroupNameTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the PlanTemplatePlanGroup entity
   * attribute, Name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplatePlanGroup Name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPlanTemplatePlanGroupNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    PlanTemplateFactory.newInstance().modifyTemplatePlanGroupNameTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the PlanTemplatePlanGroup entity attribute,
   * Name.
   *
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplatePlanGroup Name.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TextTranslationDetails readPlanTemplatePlanGroupNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      final PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
      PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new PlanTemplatePlanGroupDtls();
      final PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

      planTemplatePlanGroupKey.key.key.planTemplatePlanGroupID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from PlanItem entity.
      planTemplatePlanGroupDtls = planTemplatePlanGroupObj.read(
        planTemplatePlanGroupKey.key.key);

      textTranslationDetails.dtls.shortText = planTemplatePlanGroupDtls.name;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      final TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the PlanTemplatePlanGroup attribute,
   * Name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the PlanTemplatePlanGroup Name.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewLocalizableTextDetails listLocalizablePlanTemplatePlanGroupNameText(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    final TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    final PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new PlanTemplatePlanGroupDtls();
    final PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

    planTemplatePlanGroupKey.key.key.planTemplatePlanGroupID = localizableTextDetails.dtls.localizableTextParentID;

    // As there is no localization yet, read it from PlanItem entity.
    planTemplatePlanGroupDtls = planTemplatePlanGroupObj.read(
      planTemplatePlanGroupKey.key.key);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != planTemplatePlanGroupDtls.nameTextID) {

      final LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = planTemplatePlanGroupDtls.nameTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from PlanItem entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.shortText = planTemplatePlanGroupDtls.name;

    }

    return viewLocalizableTextDetails;
  }
  // END, CR00235328

}
