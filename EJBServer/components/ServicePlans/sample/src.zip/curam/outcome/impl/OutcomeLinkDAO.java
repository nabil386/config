/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.outcome.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.struct.OutcomeDtlsList;
import curam.serviceplans.sl.entity.struct.OutcomeKey;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import java.util.Set;


/**
 * Data access for {@linkplain curam.outcome.impl.OutcomeLink}.
 */
@ImplementedBy(OutcomeLinkDAOImpl.class)
public interface OutcomeLinkDAO extends StandardDAO<OutcomeLink> {

  /**
   * Searches for outcomes for a related reference.
   *
   * @param relatedReferenceKey
   * Contains related reference ID.
   *
   * @return Set of Outcome Link objects.
   */
  Set<OutcomeLink> searchByRelatedReference(
    RelatedReferenceKey relatedReferenceKey);

  /**
   * Searches for outcome references for an outcome.
   *
   * @param outcomeKey
   * Contains outcome ID.
   *
   * @return Set of outcome links.
   */
  Set<OutcomeLink> searchByOutcome(OutcomeKey outcomeKey);

  /**
   * Searches for the unassociated outcomes for the related reference specified.
   *
   * @param relatedReferenceID
   * The related reference ID.
   * @param recordStatus
   * The record status of the outcome.
   *
   * @return The list of outcomes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  OutcomeDtlsList searchUnassociatedOutcomesForRelatedReference(
    Long relatedReferenceID, RECORDSTATUSEntry recordStatus)
    throws AppException, InformationalException;
}
