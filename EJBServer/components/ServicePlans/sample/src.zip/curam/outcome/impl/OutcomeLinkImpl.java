/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.outcome.impl;


import curam.codetable.impl.OUTCOMELINKTYPEEntry;
import curam.serviceplans.sl.entity.struct.OutcomeDtls;
import curam.serviceplans.sl.entity.struct.OutcomeLinkDtls;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.ReadOutcomeDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of {@linkplain curam.outcome.impl.OutcomeLink}.
 */
// BEGIN, CR00183334, PS
public class OutcomeLinkImpl extends SingleTableEntityImpl<OutcomeLinkDtls>
  implements OutcomeLink {

  /**
   * Constructor for the class.
   */
  protected OutcomeLinkImpl() {

    // END, CR00183334
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OutcomeDtls getOutcome() throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.Outcome outcomeObj = curam.serviceplans.sl.fact.OutcomeFactory.newInstance();

    final OutcomeKey outcomeKey = new OutcomeKey();

    outcomeKey.key.outcomeID = getDtls().outcomeID;
    final ReadOutcomeDetails readOutcomeDetails = outcomeObj.read(outcomeKey);

    return readOutcomeDetails.outcomeDtls;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RelatedReferenceKey getRelatedReference() {

    final RelatedReferenceKey relatedReferenceKey = new RelatedReferenceKey();

    relatedReferenceKey.relatedID = getDtls().relatedID;

    return relatedReferenceKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OUTCOMELINKTYPEEntry getRelatedType() {

    return OUTCOMELINKTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setOutcome(final OutcomeKey outcomeKey) {

    getDtls().outcomeID = outcomeKey.key.outcomeID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedReference(
    final RelatedReferenceKey relatedReferenceKey) {

    getDtls().relatedID = relatedReferenceKey.relatedID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedType(final OUTCOMELINKTYPEEntry relatedType) {

    getDtls().relatedType = relatedType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void remove(final Integer versionNo) throws InformationalException {

    super.remove(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// Set the new instance defaults here.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// No cross entity validations exists.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// No cross field validations exists.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// No mandatory field validations exists.
  }
}
