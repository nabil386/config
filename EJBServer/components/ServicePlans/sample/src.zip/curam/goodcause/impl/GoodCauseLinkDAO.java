/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.goodcause.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.struct.GoodCauseDtlsList;
import curam.serviceplans.sl.entity.struct.GoodCauseKey;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import java.util.Set;


/**
 * Data access for {@linkplain curam.goodcause.impl.GoodCauseLink}.
 */
@ImplementedBy(GoodCauseLinkDAOImpl.class)
public interface GoodCauseLinkDAO extends StandardDAO<GoodCauseLink> {

  /**
   * Searches for good causes for a related reference.
   *
   * @param relatedReferenceKey
   * Contains related reference ID.
   *
   * @return Set of Good Cause Link objects.
   */
  Set<GoodCauseLink> searchByRelatedReference(
    RelatedReferenceKey relatedReferenceKey);

  /**
   * Searches for good cause references for an good cause.
   *
   * @param goodCauseKey
   * Contains good cause ID.
   *
   * @return Set of good cause links.
   */
  Set<GoodCauseLink> searchByGoodCause(GoodCauseKey goodCauseKey);

  /**
   * Searches for the unassociated good causes for the related reference
   * specified.
   *
   * @param relatedReferenceID
   * The related reference ID.
   * @param recordStatus
   * The record status of the good cause.
   *
   * @return The list of good causes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  GoodCauseDtlsList searchUnassociatedGoodCausesForRelatedReference(
    Long relatedReferenceID, RECORDSTATUSEntry recordStatus)
    throws AppException, InformationalException;
}
