/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.goodcause.impl;


import curam.codetable.impl.GOODCAUSELINKTYPEEntry;
import curam.serviceplans.sl.entity.struct.GoodCauseDtls;
import curam.serviceplans.sl.entity.struct.GoodCauseKey;
import curam.serviceplans.sl.entity.struct.GoodCauseLinkDtls;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of {@linkplain curam.goodcause.impl.GoodCauseLink}.
 */
// BEGIN, CR00183334, PS
public class GoodCauseLinkImpl extends SingleTableEntityImpl<GoodCauseLinkDtls> implements GoodCauseLink {

  /**
   * Constructor for the class.
   */
  protected GoodCauseLinkImpl() {

    // END, CR00183334
    // Bootstrap dependency injection for this class.
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public GoodCauseDtls getGoodCause() throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();
    final GoodCauseKey goodCauseKey = new GoodCauseKey();

    goodCauseKey.goodCauseID = getDtls().goodCauseID;

    return goodCauseObj.read(goodCauseKey);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setGoodCause(GoodCauseKey goodCauseKey) {

    getDtls().goodCauseID = goodCauseKey.goodCauseID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RelatedReferenceKey getRelatedReference() {

    final RelatedReferenceKey relatedReferenceKey = new RelatedReferenceKey();

    relatedReferenceKey.relatedID = getDtls().relatedID;

    return relatedReferenceKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedReference(RelatedReferenceKey relatedReferenceKey) {

    getDtls().relatedID = relatedReferenceKey.relatedID;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public GOODCAUSELINKTYPEEntry getRelatedType() {

    return GOODCAUSELINKTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedType(GOODCAUSELINKTYPEEntry goodCauseTypeEntry) {

    getDtls().relatedType = goodCauseTypeEntry.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void remove(Integer versionNo) throws InformationalException {

    super.remove(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// Set the new instance defaults here.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// No cross entity validations exists.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// No cross field validations exists.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// No mandatory field validations exists.
  }
}
