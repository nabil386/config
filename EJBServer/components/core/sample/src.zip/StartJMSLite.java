/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
import curam.util.jms.jmslite.JMSLiteEngine;


/**
 * Bootstrap class to start JMS lite.
 */
public class StartJMSLite {

  public static void main(String[] args) throws Exception {

    JMSLiteEngine.main(null);
  }
}
