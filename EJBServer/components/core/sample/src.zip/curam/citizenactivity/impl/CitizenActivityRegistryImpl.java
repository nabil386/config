/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import com.google.inject.Inject;
import curam.citizenactivity.codetable.impl.CITIZENACTIVITYTYPEEntry;
import curam.participant.impl.ConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.message.PERSISTENCE;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


/**
 * Default implementation for the {@link CitizenActivityRegistry}.
 */
class CitizenActivityRegistryImpl implements CitizenActivityRegistry {

  /**
   * This map contains implementations of the CitizenActivityDAO. These are
   * bound into the map using a binding.
   */
  @Inject(optional = true)
  protected Map<CITIZENACTIVITYTYPEEntry, CitizenActivityDAO> map;

  /**
   * Used to order the activities retrieved.
   */
  @Inject
  protected CitizenActivityComparator citizenActivityComparator;

  /**
   * {@inheritDoc}
   */
  @Override
  public CitizenActivity get(final long id,
    final CITIZENACTIVITYTYPEEntry type) {

    // BEGIN CR00234675, RR
    // Check that the map has been injected correctly
    if (map == null) {
      // Throw a runtime exception if the Map has not been injected
      final AppException appException = new AppException(PERSISTENCE.RUN_ID_NO_CONCRETE_READER_DAO_MAP).arg(
        type.toUserLocaleString());

      throw new AppRuntimeException(appException);
    }
    // END CR00234675

    // get the relevant child DAO from the map based on type
    final CitizenActivityDAO citizenActivityDAO = map.get(type);

    // BEGIN CR00234675, RR
    if (citizenActivityDAO == null) {
      // no entry in the map for this type
      final AppException appException = new AppException(PERSISTENCE.RUN_ID_NO_CONCRETE_READER_DAO).arg(
        type.toUserLocaleString());

      throw new AppRuntimeException(appException);
    }
    // END CR00234675

    final CitizenActivity citizenActivity = citizenActivityDAO.get(id);

    return citizenActivity;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<CitizenActivity> searchByConcernRole(
    final ConcernRole concernRole) {

    final List<CitizenActivity> citizenActivityList = new ArrayList<CitizenActivity>();

    if (map == null) {
      return citizenActivityList;
    }

    for (final CitizenActivityDAO citizenActivityDAO : map.values()) {

      citizenActivityList.addAll(
        citizenActivityDAO.searchByConcernRole(concernRole));
    }

    Collections.sort(citizenActivityList, citizenActivityComparator);

    return citizenActivityList;
  }
}
