/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import curam.participant.impl.ConcernRole;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;
import java.util.List;


/**
 * Represents the methods that should be implemented by a concrete DAO used to
 * retrieve citizen activities for a given entity. DAO interfaces should extend
 * this interface if they wish to serve citizen activities for display in
 * Citizen Workspace. The DAOs that extend this should implement the methods
 * defined on this interface, and should be bound into the map contained in the
 * {@link CitizenActivityRegistry}.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
@Implementable
public interface CitizenActivityDAO {

  /**
   * Returns a list of citizen activities for the given {@link ConcernRole}. The
   * records are ordered by calling the bound implementation of the
   * {@link CitizenActivityComparator}.
   *
   * @param concernRole
   * the participant in question.
   * @return a list of CitizenActivities for the given {@link ConcernRole}.
   */
  List<CitizenActivity> searchByConcernRole(ConcernRole concernRole);

  /**
   * Returns an instance of the CitizenActivity interface, based on the ID
   * passed in. The type is used to determine which concrete DAO to call to
   * retrieve the record.
   *
   * @param type
   * used to determine which concrete DAO to call to retrieve the
   * record, i.e. which entity it lives on.
   * @param id
   * ID of the record to be retrieved.
   * @return an instance of the CitizenActivity interface based on the ID /
   * Type.
   */
  CitizenActivity get(final Long id);
}
