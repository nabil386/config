/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import com.google.inject.Inject;
import curam.citizenactivity.codetable.impl.CITIZENACTIVITYTYPEEntry;
import curam.codetable.impl.COMMENTRELATEDTYPEEntry;
import curam.message.impl.CITIZENACTIVITYExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participantcomment.impl.ParticipantComment;
import curam.participantcomment.impl.ParticipantCommentDAO;
import curam.piwrapper.user.impl.User;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;
import curam.util.type.Implementable;
import java.io.ByteArrayOutputStream;
import java.util.List;


/**
 * Implementation of the CitizenActivity interface.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@AccessLevel(AccessLevelType.EXTERNAL)
@Implementable
public class CitizenActivityImpl implements CitizenActivity {

  @Inject
  ParticipantCommentDAO participantCommentDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  public User getAgencyContact() {

    return null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getName() {

    return "";
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CITIZENACTIVITYTYPEEntry getType() {

    return CITIZENACTIVITYTYPEEntry.NOT_SPECIFIED;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getParticipation() {

    return "";
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DateRange getPeriod() {

    return null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getID() {

    return 0L;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getProviderOfferingID() {

    return 0L;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getProviderName() {

    return "";
  }

  @Override
  public ByteArrayOutputStream getReferralDocument()
    throws InformationalException, AppException {

    return null;
  }

  @Override
  public List<ConcernRole> listConcernRoles() {

    return null;
  }

  @Override
  public Boolean hasReferralLetter() {

    return false;
  }

  @Override
  public void addComment(final String comment, final ConcernRole concernRole)
    throws AppException, InformationalException {

    if (null == getCommentRelatedType()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CITIZENACTIVITYExceptionCreator.ERR_PARTICIPANT_MESSAGE_TYPE_NOT_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final ParticipantComment participantComment = participantCommentDAO.newInstance();

    participantComment.setComment(comment);
    participantComment.setConcernRole(concernRole);
    participantComment.setCommentRelatedType(getCommentRelatedType());
    participantComment.setRelatedObjectID(getID());
    participantComment.insert();
  }

  @Override
  public COMMENTRELATEDTYPEEntry getCommentRelatedType() {

    return null;
  }
}
