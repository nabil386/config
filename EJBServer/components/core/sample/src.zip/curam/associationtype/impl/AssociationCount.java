/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.associationtype.impl;


import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTableEntry;


/**
 * This is a generic interface which can be used to get the number of
 * associations that exist between two business objects. The first business
 * object can be bound to the implementation class by using the map binder in
 * module class using code table "ObjectAssociationType". The second business
 * object can be specified as a related type and its ID through the defined
 * methods.
 * <p>
 * Example: Fund can be associated with a Product or Service Offering. An
 * implementation of this interface for Fund Association, can be called as
 * "FundAssociationCountImpl". This has to be created and bound using "Fund
 * Association" code in "ObjectAssociationType".
 * <p>
 * Example of binding in module class:
 *
 * <pre>
 * {@code
 * // Declare the map binder.
 *
 * // Binds the product name class to localized name type.
 * associationCountMapbinder.addBinding(OBJECTASSOCIATIONTYPE.FUND).to(
 * FundAssociationCountImpl.class);
 * }
 * </pre>
 *
 * Example usage:
 *
 * <pre>
 *
 *
 * {
 * &#064;code
 * AssociationCount associationCount =
 * associationCountMap.get(associationType);
 * associationCount.getAssociationCount(
 * FUNDRELATIONTYPEEntry.get(relatedType), productDetails.productID);
 * }
 * </pre>
 *
 */
public interface AssociationCount {

  /**
   * Gets the number of associations exist between two business objects. The
   * first business object has to be specified by using the map binder as
   * specified in the interface definition. The second business object's type
   * and ID have to be specified with this method as arguments.
   *
   * @param objectRelatedType
   * The type of the associated business object. For e.g., Product
   *
   * @param relatedID
   * The ID of the associated business object. For e.g., ProductID
   *
   * @return The number of associations exist between two business objects.
   */
  public Integer getAssociationCount(CodeTableEntry objectRelatedType,
    Long relatedID) throws AppException, InformationalException;

  /**
   * Gets the page identifier on which the associations are displayed.
   *
   * @return The page identifier on which the associations are displayed.
   */
  public String getAssociationPageID();
}
