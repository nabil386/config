/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import com.google.inject.AbstractModule;
import com.google.inject.multibindings.Multibinder;
import curam.meetings.sl.impl.Meeting.MeetingEvents;


/**
 * The module which contain the Guice bindings for
 * {@link curam.piwrapper.clientdiary.impl}.
 *
 * @since 6.0
 */
public class Module extends AbstractModule {

  /**
   * {@inheritDoc}
   */
  @Override
  protected void configure() {

    // BEGIN, CR00231006, GD
    /*
     * Get the listener set
     */
    final Multibinder<MeetingEvents> meetingEventsListeners = Multibinder.newSetBinder(
      binder(), MeetingEvents.class);

    /*
     * Add a listener
     */
    meetingEventsListeners.addBinding().to(MeetingEventsImpl.class);
    // END, CR00231006
  }
}
