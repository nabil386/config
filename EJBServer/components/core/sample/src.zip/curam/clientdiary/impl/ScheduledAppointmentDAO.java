/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import com.google.inject.ImplementedBy;
import curam.clientdiary.codetable.impl.CLIENTDIARYRELATEDTYPEEntry;
import curam.participant.impl.ConcernRole;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;
import java.util.List;


/**
 * Used to read details of {@link ScheduledAppointment}. <br/>
 * To add a new concrete DAO to the map of possible types of
 * {@link ScheduledAppointment}, a binding to the map should be done using the
 * {@link CLIENTDIARYRELATEDTYPEEntry} and the concrete DAO type.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(ScheduledAppointmentDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ScheduledAppointmentDAO {

  /**
   * Reads the {@link ScheduledAppointment} with the given ID and type.
   *
   * @param relatedID
   * The ID of the scheduled appointment
   * @param relatedType
   * The type of the scheduled appointment
   * @return The scheduled appointment with the given ID and type
   */
  ScheduledAppointment get(final Long relatedID,
    final CLIENTDIARYRELATEDTYPEEntry relatedType);

  /**
   * Returns a list of all active {@link ScheduledAppointment} for the given
   * {@link ConcernRole}, which overlaps with the given {@link DateRange}. The
   * list is sorted by start date.
   *
   * @param concernRole
   * The concern role to search by
   * @param dateRange
   * The start and end date to search by
   * @return A list of all active scheduled appointments for the given client
   * which overlap with the given date range.
   */
  List<ScheduledAppointment> listActiveByConcernRoleDateRange(
    final ConcernRole concernRole, final DateRange dateRange);

}
