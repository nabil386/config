/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.meetings.sl.impl.Meeting.MeetingEvents;
import curam.meetings.sl.impl.MeetingAttendee;
import curam.meetings.sl.impl.MeetingDetails;
import curam.piwrapper.activity.impl.Activity;
import curam.piwrapper.activity.impl.ActivityDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Implementation of {@link MeetingEvents}. This is used to trigger the
 * create/modify of a {@link ClientDiary} resulting from any changes to a
 * {@link Meeting}. <br/>
 * This is needed because the call to
 * {@link Meeting#modifyMeetingDetails(MeetingDetails)} does not trigger any
 * update of the {@link curam.core.intf.ActivityAttendee} which triggers the
 * update of the client diary table.
 *
 * @since 6.0
 */
public class MeetingEventsImpl implements MeetingEvents {

  @Inject
  protected Provider<ScheduledAppointmentHandler> scheduledAppointmentHandlerProvider;

  @Inject
  protected ActivityDAO activityDAO;

  MeetingEventsImpl() {// constructor for use with Guice
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void invalidAttendeeEmailAddress(MeetingDetails meetingDetails,
    MeetingAttendee meetingAttendee) throws AppException,
      InformationalException {// nothing needed
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void inviteAttendee(long meetingID, MeetingAttendee meetingAttendee)
    throws AppException, InformationalException {// nothing needed
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void postCancelMeeting(MeetingDetails meetingDetails)
    throws AppException, InformationalException {// nothing needed
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void postCreateMeeting(MeetingDetails meetingDetails)
    throws AppException, InformationalException {// nothing needed
  }

  /**
   * Search for all {@link ClientDiary} records related to this meeting and
   * update them with the new details.
   */
  @Override
  public void postModifyMeeting(MeetingDetails meetingDetails)
    throws AppException, InformationalException {

    // use the activity wrapper
    final Activity activity = activityDAO.get(meetingDetails.getMeetingID());

    scheduledAppointmentHandlerProvider.get().modify(activity,
      new DateRange(new Date(meetingDetails.getStartDateTime()),
      new Date(meetingDetails.getEndDateTime())));
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void preCancelMeeting(long meetingID) throws AppException,
      InformationalException {// nothing needed
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void preCreateMeeting(MeetingDetails meetingDetails)
    throws AppException, InformationalException {// nothing needed
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void preModifyMeeting(MeetingDetails meetingDetails)
    throws AppException, InformationalException {// nothing needed
  }

}
