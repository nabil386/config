/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import com.google.inject.Inject;
import curam.clientdiary.message.SCHEDULEDAPPOINTMENT;
import curam.core.impl.CuramConst;
import curam.participant.impl.ConcernRole;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import java.util.List;


/**
 * Implementation for the {@link ScheduledAppointmentHandler} functionality.
 *
 * @since 6.0
 */
class ScheduledAppointmentHandlerImpl implements ScheduledAppointmentHandler {

  @Inject
  protected ClientDiaryDAO clientDiaryDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final ConcernRole concernRole,
    final ScheduledAppointment scheduledAppointment)
    throws InformationalException {

    // remove the client diary record if one exists
    final ClientDiary clientDiary = clientDiaryDAO.readActiveByConcernRoleAndScheduledAppointment(
      concernRole, scheduledAppointment);

    if (null != clientDiary) {
      clientDiary.cancel(clientDiary.getVersionNo());
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final ScheduledAppointment scheduledAppointment)
    throws InformationalException {

    final List<ClientDiary> clientDiaryList = clientDiaryDAO.listActiveByScheduledAppointment(
      scheduledAppointment);

    for (final ClientDiary clientDiary : clientDiaryList) {
      clientDiary.cancel(clientDiary.getVersionNo());
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert(final ConcernRole concernRole,
    final ScheduledAppointment scheduledAppointment,
    final DateRange dateRange) throws InformationalException {

    // insert the client diary record
    final ClientDiary clientDiary = clientDiaryDAO.newInstance();

    clientDiary.setConcernRole(concernRole);
    clientDiary.setDateRange(dateRange);
    clientDiary.setScheduledAppointment(scheduledAppointment);
    clientDiary.insert();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final ScheduledAppointment scheduledAppointment,
    final DateRange dateRange) throws InformationalException {

    final List<ClientDiary> clientDiaryList = clientDiaryDAO.listActiveByScheduledAppointment(
      scheduledAppointment);

    for (final ClientDiary clientDiary : clientDiaryList) {
      clientDiary.setDateRange(dateRange);
      clientDiary.modify(clientDiary.getVersionNo());
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final ConcernRole concernRole,
    final ScheduledAppointment scheduledAppointment,
    final DateRange dateRange) throws InformationalException {

    // modify the client diary record if one exists
    final ClientDiary clientDiary = clientDiaryDAO.readActiveByConcernRoleAndScheduledAppointment(
      concernRole, scheduledAppointment);

    if (null != clientDiary) {
      clientDiary.setDateRange(dateRange);
      clientDiary.modify(clientDiary.getVersionNo());
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getFrequencyDuration(final FrequencyPattern frequencyPattern,
    final int durationInMinutes) {

    // if there is a frequency
    final StringBuffer frequencyDurationStringBuffer = new StringBuffer();
    boolean frequencyExists = false;

    if (frequencyPattern != null && !frequencyPattern.isZeroPattern()) {
      frequencyExists = true;

      // Add the frequency number code to the buffer
      frequencyDurationStringBuffer.append(frequencyPattern.toString());
    }

    // Add the pipe character
    frequencyDurationStringBuffer.append(CuramConst.gkPipeDelimiter);

    // if there is a duration
    if (durationInMinutes > 0) {
      LocalisableString localisableString;

      if (frequencyExists) {
        localisableString = new LocalisableString(
          SCHEDULEDAPPOINTMENT.INFO_FREQUENCY_DURATION_STRING);
      } else {
        localisableString = new LocalisableString(
          SCHEDULEDAPPOINTMENT.INFO_DURATION_STRING_HOURS_MINUTES);
      }
      localisableString.arg(getDurationHoursPart(durationInMinutes));
      localisableString.arg(getDurationMinutesPart(durationInMinutes));
      frequencyDurationStringBuffer.append(
        localisableString.toClientFormattedText());
    }
    return frequencyDurationStringBuffer.toString();
  }

  /**
   * Returns the number of whole hours in the given total duration in minutes.
   *
   * @param durationInMinutes
   * The total number of minutes to be converted
   * @return The number of whole hours in the given duration in minutes
   */
  int getDurationHoursPart(final int durationInMinutes) {

    return durationInMinutes / CuramConst.gkSixty;
  }

  /**
   * Returns the number of minutes left in the given total duration in minutes,
   * after the number of whole hours have been subtracted.
   *
   * @param durationInMinutes
   * The total number of minutes to be converted
   * @return The number of minutes remaining after hours have been subtracted
   */
  int getDurationMinutesPart(final int durationInMinutes) {

    return durationInMinutes % CuramConst.gkSixty;
  }

}
