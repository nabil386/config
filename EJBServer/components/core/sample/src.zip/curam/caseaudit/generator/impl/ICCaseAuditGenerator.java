/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditPlanCriteriaDtls;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.codetable.CASESEARCHFILTER;
import curam.codetable.CASESTATUS;
import curam.codetable.GENDER;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.GENDEREntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.core.facade.struct.CaseAuditDetails;
import curam.core.facade.struct.CaseLoadDetails;
import curam.core.facade.struct.CaseSampleKey;
import curam.core.facade.struct.NumberAndPercentageOfCases;
import curam.core.fact.LocationFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Location;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.struct.LocationKey;
import curam.message.BPOAUDITPLANSAMPLECRITERIA;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.samplingstrategy.impl.SamplingStrategy;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Locale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class ICCaseAuditGenerator implements CaseAuditGenerator {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  @Inject
  protected Map<SAMPLINGSTRATEGYEntry, SamplingStrategy> samplingStrategies;

  protected static final String kDateFormat = Locale.defaultDateFormat;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public ICCaseAuditGenerator() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Generates the sample list of integrated cases for audit based on the
   * supplied search criteria. This method filters the list using the algorithm
   * associated with the case type for this audit plan. The number of cases
   * returned in the list is also restricted by the number of cases or
   * percentage of cases specified by the user.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generateCaseAudits(final CaseSampleKey key)
    throws AppException, InformationalException {

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    // In the case of regeneration, remove existing case audits
    auditPlan.clearCaseLoad();
    auditPlan.clearSelectionCriteria();

    if (key.icDtls.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.icDtls.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.icDtls.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.icDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    key.icDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    key.icDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<curam.piwrapper.caseheader.impl.CaseHeader> caseList = caseHeaderDAO.searchCommonICCriteria(
      key.icDtls);

    final CaseAuditGeneratorHelper caseAuditGeneratorHelperObj = new CaseAuditGeneratorHelper();

    final CaseLoadDetails caseLoadDetails = new CaseLoadDetails();

    caseLoadDetails.numberOfCases = key.numberOfCases;
    caseLoadDetails.percentageOfCases = key.percentageOfCases;
    caseLoadDetails.totalCases = caseList.size();

    final NumberAndPercentageOfCases numberAndPercentageOfCases = caseAuditGeneratorHelperObj.determineNumCasesToProcess(
      caseLoadDetails);

    // Get algorithm to use to generate case sample
    final SamplingStrategy samplingStrategy = samplingStrategies.get(
      auditPlan.getAuditCaseConfig().getAuditAlgorithm());

    final List<Long> caseIDList = new ArrayList<Long>();

    for (final CaseHeader caseHeader : caseList) {
      caseIDList.add(caseHeader.getID());
    }

    // Auto generate algorithm parameters if necessary
    if (key.details.startPoint == 0) {
      key.details.startPoint = new Double(CuramConst.gkOne + Math.random() * numberAndPercentageOfCases.numberOfCases).intValue();
    }

    if (key.details.interval == 0) {
      key.details.interval = Math.round(
        key.totalNumCases / numberAndPercentageOfCases.numberOfCases);
    }

    final Map<String, Object> params = new TreeMap<String, Object>();

    params.put(CuramConst.kSystematicSamplingStartIndex,
      new Integer(key.details.startPoint));
    params.put(CuramConst.kSystematicSamplingInterval,
      new Integer(key.details.interval));

    // Call algorithm to generate case sample
    final List<Long> caseIDs = samplingStrategy.getRandomSample(caseIDList,
      numberAndPercentageOfCases.numberOfCases, params);

    final curam.core.facade.intf.CaseAudit caseAuditObj = curam.core.facade.fact.CaseAuditFactory.newInstance();

    // for each case, create a case audit
    for (int i = 0; i < caseIDs.size(); i++) {

      final CaseAuditDetails caseAuditDetails = new CaseAuditDetails();

      caseAuditDetails.dtls.auditPlanID = key.auditPlanID;
      caseAuditDetails.dtls.caseID = caseIDs.get(i);
      caseAuditObj.createCaseAudit(caseAuditDetails);
    }

    // Update audit plan with number/percentage cases and query used
    final SelectionQuery selectionQuery = selectionQueryDAO.get(
      key.selectionQueryID);

    auditPlan.setNumberCases(numberAndPercentageOfCases.numberOfCases);
    auditPlan.setPercentageCases(numberAndPercentageOfCases.percentageOfCases);
    auditPlan.setSelectionQuery(selectionQuery);

    auditPlan.modify(auditPlan.getVersionNo());

    // Record the criteria entered by the audit coordinator
    recordSelectionCriteria(key);

    auditPlan.auditPlanPending(auditPlan.getVersionNo());
    auditPlan.caseSampleListGenerated();
  }

  // ___________________________________________________________________________
  /**
   * Records the criteria entered by the audit coordinator during IC case sample
   * generation.
   *
   * @param auditPlanKey The unique identifier of the audit plan that the case
   * sample list is being generated for.
   * @param details The criteria entered by the audit coordinator during IC
   * case sample generation.
   */
  @Override
  public void recordSelectionCriteria(final CaseSampleKey key)
    throws AppException, InformationalException {

    final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(kDateFormat);

    final curam.core.facade.intf.AuditPlanCriteria auditPlanCriteriaObj = curam.core.facade.fact.AuditPlanCriteriaFactory.newInstance();

    if (!key.icDtls.startDateFrom.isZero()) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_START_DATE_FROM.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.icDtls.startDateFrom.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.icDtls.startDateTo.isZero()) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_START_DATE_TO.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.icDtls.startDateTo.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.icDtls.endDateFrom.isZero()) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_END_DATE_FROM.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.icDtls.endDateFrom.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.icDtls.endDateTo.isZero()) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_END_DATE_TO.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.icDtls.endDateTo.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.icDtls.status.equals(CASESTATUSEntry.NOT_SPECIFIED.getCode())) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_STATUS.getMessageText();
      auditPlanCriteriaDtls.value = CodeTable.getOneItem(CASESTATUS.TABLENAME,
        key.icDtls.status, TransactionInfo.getProgramLocale());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.icDtls.age > 0) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_AGE.getMessageText();
      auditPlanCriteriaDtls.value = String.valueOf(key.icDtls.age);
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.icDtls.gender.equals(GENDEREntry.NOT_SPECIFIED.getCode())) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_GENDER.getMessageText();
      auditPlanCriteriaDtls.value = CodeTable.getOneItem(GENDER.TABLENAME,
        key.icDtls.gender, TransactionInfo.getProgramLocale());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.icDtls.ownerLocation > 0) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_LOCATION.getMessageText();

      final Location locationObj = LocationFactory.newInstance();
      final LocationKey locationKey = new LocationKey();

      locationKey.locationID = key.icDtls.ownerLocation;
      auditPlanCriteriaDtls.value = locationObj.read(locationKey).name;
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.icDtls.searchWithIssues) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_CASES_WITH_ISSUES.getMessageText();
      auditPlanCriteriaDtls.value = String.valueOf(key.icDtls.searchWithIssues);
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.icDtls.searchWithAppeals) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_CASES_WITH_APPEALS.getMessageText();
      auditPlanCriteriaDtls.value = String.valueOf(key.icDtls.searchWithAppeals);
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!StringHelper.isEmpty(key.icDtls.caseOwner)
      && !key.icDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.NOT_SPECIFIED.getCode())) {
      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_OWNER.getMessageText();

      if (key.icDtls.orgObjectType.equals(ORGOBJECTTYPEEntry.USER.getCode())) {

        auditPlanCriteriaDtls.value = key.icDtls.caseOwner;

      } else if (key.icDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.ORGUNIT.getCode())) {

        final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = Long.parseLong(
          key.icDtls.caseOwner);
        auditPlanCriteriaDtls.value = organisationUnitObj.read(organisationUnitKey).name;

      } else if (key.icDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.POSITION.getCode())) {

        final curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = Long.parseLong(key.icDtls.caseOwner);
        auditPlanCriteriaDtls.value = positionObj.read(positionKey).name;

      } else if (key.icDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.WORKQUEUE.getCode())) {

        final curam.core.sl.entity.intf.WorkQueue workQueueObj = curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
        final WorkQueueKey workQueueKey = new WorkQueueKey();

        workQueueKey.workQueueID = Long.parseLong(key.icDtls.caseOwner);
        auditPlanCriteriaDtls.value = workQueueObj.read(workQueueKey).name;
      }
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
  }
}
