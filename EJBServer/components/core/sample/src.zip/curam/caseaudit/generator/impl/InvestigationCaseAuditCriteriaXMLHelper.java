/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.caseaudit.generator.impl;


import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.impl.CASECATEGORYEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.GENDEREntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.codetable.impl.RESOLUTIONCONIFIGURATIONEntry;
import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Locale;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import curam.common.util.xml.dom.Document;
import curam.common.util.xml.dom.DOMException;
import curam.common.util.xml.dom.xpath.XPath;


public class InvestigationCaseAuditCriteriaXMLHelper implements
  CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public InvestigationCaseAuditCriteriaXMLHelper() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample.
   *
   * @param key
   * The search criteria to be used in the generation of the case
   * audit sample.
   *
   * @return An XML <code>String</code> representation of the data to be used
   * in the creation of the case audit sample.
   */
  @Override
  public String buildCriteria(final CaseSampleKey key) throws AppException,
      InformationalException {

    final XMLBuilder xmlBuilder = new XMLBuilder(
      CaseAuditCriteriaXMLConst.kCaseSampleKey);

    if (key.auditPlanID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAuditPlanID);
      xmlBuilder.addTagData(String.valueOf(key.auditPlanID));
      xmlBuilder.closeTag();
    }

    if (key.totalNumCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTotalNumCases);
      xmlBuilder.addTagData(String.valueOf(key.totalNumCases));
      xmlBuilder.closeTag();
    }

    if (key.numberOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kNumCases);
      xmlBuilder.addTagData(String.valueOf(key.numberOfCases));
      xmlBuilder.closeTag();
    }

    if (key.percentageOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kPercentageOfCases);
      xmlBuilder.addTagData(String.valueOf(key.percentageOfCases));
      xmlBuilder.closeTag();
    }

    if (key.selectionQueryID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kSelectionQueryID);
      xmlBuilder.addTagData(String.valueOf(key.selectionQueryID));
      xmlBuilder.closeTag();
    }

    if (key.externalCaseAuditDataID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kExternalCaseAuditDataID);
      xmlBuilder.addTagData(String.valueOf(key.externalCaseAuditDataID));
      xmlBuilder.closeTag();
    }

    if (key.details != null) {

      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAlgorithmParameters);

      if (key.details.startPoint > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartPoint);
        xmlBuilder.addTagData(String.valueOf(key.details.startPoint));
        xmlBuilder.closeTag();
      }

      if (key.details.interval > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kInterval);
        xmlBuilder.addTagData(String.valueOf(key.details.interval));
        xmlBuilder.closeTag();
      }
      xmlBuilder.closeTag();
    }

    if (key.investigationCaseDtls != null) {

      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCommonInvSearchCriteria);

      if (!key.investigationCaseDtls.status.equals(
        CASESTATUSEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStatus);
        xmlBuilder.addTagData(key.investigationCaseDtls.status);
        xmlBuilder.closeTag();
      }

      if (key.investigationCaseDtls.age > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAge);
        xmlBuilder.addTagData(String.valueOf(key.investigationCaseDtls.age));
        xmlBuilder.closeTag();
      }

      if (!StringHelper.isEmpty(key.investigationCaseDtls.caseOwner)) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseOwner);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.caseOwner));
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.caseTypeCode.equals(
        CASETYPECODEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseTypeCode);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.caseTypeCode));
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.category.equals(
        CASECATEGORYEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseCategory);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.category));
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.endDateFrom.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kEndDateFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.investigationCaseDtls.endDateFrom,
          Locale.Date_ymd));
        // END, CR00298436
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.endDateTo.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kEndDateTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.investigationCaseDtls.endDateTo,
          Locale.Date_ymd));
        // END, CR00298436
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.startDateFrom.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartDateFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.investigationCaseDtls.startDateFrom,
          Locale.Date_ymd));
        // END, CR00298436
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.startDateTo.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartDateTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.investigationCaseDtls.startDateTo,
          Locale.Date_ymd));
        // END, CR00298436
        xmlBuilder.closeTag();

      }
      if (!key.investigationCaseDtls.gender.equals(
        GENDEREntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kGender);
        xmlBuilder.addTagData(String.valueOf(key.investigationCaseDtls.gender));
        xmlBuilder.closeTag();
      }

      if (key.investigationCaseDtls.ownerLocation != 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kOwnerLocation);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.ownerLocation));
        xmlBuilder.closeTag();
      }

      if (key.investigationCaseDtls.filterOptionList.length() > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kFilterOptionList);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.filterOptionList));
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kOrgObjectType);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.orgObjectType));
        xmlBuilder.closeTag();
      }

      if (!key.investigationCaseDtls.investigationResolution.equals(
        RESOLUTIONCONIFIGURATIONEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kInvResolution);
        xmlBuilder.addTagData(
          String.valueOf(key.investigationCaseDtls.investigationResolution));
        xmlBuilder.closeTag();
      }

      xmlBuilder.closeTag();
    }

    return xmlBuilder.getXmlString();
  }

  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the
   * creation of the case audit sample.
   *
   * @param document
   * The XML <code>String</code> representation of the data to be used
   * in the creation of the case audit sample.
   *
   * @return The key containing the search criteria.
   */
  @Override
  public CaseSampleKey parseCriteria(final Document document)
    throws AppException, InformationalException {

    final CaseSampleKey caseSampleKey = new CaseSampleKey();

    try {

      XPath xpath = new XPath("//CaseSampleKey/auditPlanID/text()");
      curam.common.util.xml.dom.Text text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(
        document.getRootElement());

      if (text != null) {
        caseSampleKey.auditPlanID = new Long(text.getText()).longValue();
      }

      xpath = new XPath("//CaseSampleKey/totalNumCases/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.totalNumCases = Integer.parseInt(text.getText());
      }

      xpath = new XPath("//CaseSampleKey/numberOfCases/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.numberOfCases = Integer.parseInt(text.getText());
      }

      xpath = new XPath("//CaseSampleKey/percentageOfCases/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.percentageOfCases = Double.parseDouble(text.getText());
      }

      xpath = new XPath("//CaseSampleKey/selectionQueryID/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.selectionQueryID = new Long(text.getText()).longValue();
      }

      xpath = new XPath(
        "//CaseSampleKey/externalCaseAuditDataID/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.externalCaseAuditDataID = new Long(text.getText()).longValue();
      }

      xpath = new XPath(
        "//CaseSampleKey/algorithmParameters/startPoint/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.startPoint = Integer.parseInt(text.getText());
      }

      xpath = new XPath(
        "//CaseSampleKey/algorithmParameters/interval/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.interval = Integer.parseInt(text.getText());
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/status/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.status = text.getText();
      }

      xpath = new XPath(
        "" + "//CaseSampleKey/commonInvSearchCriteria/age/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.age = Integer.parseInt(
          text.getText());
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/caseOwner/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.caseOwner = text.getText();
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/caseTypeCode/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.caseTypeCode = text.getText();
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/category/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.category = text.getText();
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/endDateFrom/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.investigationCaseDtls.endDateFrom = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/endDateTo/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.investigationCaseDtls.endDateTo = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/startDateFrom/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.investigationCaseDtls.startDateFrom = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/startDateTo/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.investigationCaseDtls.startDateTo = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/gender/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.gender = text.getText();
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/ownerLocation/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.ownerLocation = Long.parseLong(
          text.getText());
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/filterOptionList/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.filterOptionList = text.getText();
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/orgObjectType/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.orgObjectType = text.getText();
      }

      xpath = new XPath(
        "//CaseSampleKey/commonInvSearchCriteria/invResolution/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.investigationCaseDtls.investigationResolution = text.getText();
      }

    } catch (final DOMException e) {
      throw new AppRuntimeException(e);
    }
    return caseSampleKey;
  }
}
