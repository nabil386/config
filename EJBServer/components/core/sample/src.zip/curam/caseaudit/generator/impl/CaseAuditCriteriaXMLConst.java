/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


/**
 * Constants for use by <code>CaseAuditCriteriaXMLHelper</code>.
 *
 */
public final class CaseAuditCriteriaXMLConst {

  /**
   * The Case Sample Key String.
   */
  public static final String kCaseSampleKey = "CaseSampleKey";

  /**
   * The Audit Plan ID String.
   */
  public static final String kAuditPlanID = "auditPlanID";

  /**
   * The Total Number Of Cases String.
   */
  public static final String kTotalNumCases = "totalNumCases";

  /**
   * The Number Of Cases String.
   */
  public static final String kNumCases = "numberOfCases";

  /**
   * The Percentage Of Cases String.
   */
  public static final String kPercentageOfCases = "percentageOfCases";

  /**
   * The Selection Query ID String.
   */
  public static final String kSelectionQueryID = "selectionQueryID";

  /**
   * The External Case Audit Data ID String.
   */
  public static final String kExternalCaseAuditDataID = "externalCaseAuditDataID";

  /**
   * The Algorithm Parameters String.
   */
  public static final String kAlgorithmParameters = "algorithmParameters";

  /**
   * The Start Point String.
   */
  public static final String kStartPoint = "startPoint";

  /**
   * The Interval String.
   */
  public static final String kInterval = "interval";

  /**
   * The Common IC Search Criteria String.
   */
  public static final String kCommonICSearchCriteria = "commonICSearchCriteria";

  /**
   * The Status String.
   */
  public static final String kStatus = "status";

  /**
   * The Age String.
   */
  public static final String kAge = "age";

  /**
   * The Case Owner String.
   */
  public static final String kCaseOwner = "caseOwner";

  /**
   * The Case Type Code String.
   */
  public static final String kCaseTypeCode = "caseTypeCode";

  /**
   * The Case Category String.
   */
  public static final String kCaseCategory = "caseCategory";

  /**
   * The End Date From String.
   */
  public static final String kEndDateFrom = "endDateFrom";

  /**
   * The End Date To String.
   */
  public static final String kEndDateTo = "endDateTo";

  /**
   * The Start Date From String.
   */
  public static final String kStartDateFrom = "startDateFrom";

  /**
   * The Start Date To String.
   */
  public static final String kStartDateTo = "startDateTo";

  /**
   * The Gender String.
   */
  public static final String kGender = "gender";

  /**
   * The Owner Location String.
   */
  public static final String kOwnerLocation = "ownerLocation";

  /**
   * The Filter Option List String.
   */
  public static final String kFilterOptionList = "filterOptionList";

  /**
   * The Org Object Type String.
   */
  public static final String kOrgObjectType = "orgObjectType";

  /**
   * The Common PD Search Criteria String.
   */
  public static final String kCommonPDSearchCriteria = "commonPDSearchCriteria";

  /**
   * The Certification From String.
   */
  public static final String kCertificationFrom = "certificationFrom";

  /**
   * The Certification To String.
   */
  public static final String kCertificationTo = "certificationTo";

  /**
   * The Time Period From String.
   */
  public static final String kTimePeriodFrom = "timePeriodFrom";

  /**
   * The Time Period To String.
   */
  public static final String kTimePeriodTo = "timePeriodTo";

  /**
   * The Decision String.
   */
  public static final String kDecision = "decision";

  /**
   * The Common Liability Search Criteria String.
   */
  public static final String kCommonLPDSearchCriteria = "commonLPDSearchCriteria";

  /**
   * The Common Investigation Search Criteria String.
   */
  public static final String kCommonInvSearchCriteria = "commonInvSearchCriteria";

  /**
   * The Investigation Resolution String.
   */
  public static final String kInvResolution = "invResolution";

  /**
   * Protected constructor to prevent instantiation.
   */
  protected CaseAuditCriteriaXMLConst() {// Can't instantiate constant class.
  }

}
