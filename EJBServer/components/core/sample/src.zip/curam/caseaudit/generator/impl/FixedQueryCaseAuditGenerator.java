/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditPlanCriteriaDtls;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.CaseAuditQueryManagement;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.core.facade.struct.AuditPlanAndQueryKey;
import curam.core.facade.struct.CaseAuditDetails;
import curam.core.facade.struct.CaseLoadDetails;
import curam.core.facade.struct.CaseSampleKey;
import curam.core.facade.struct.NumberAndPercentageOfCases;
import curam.core.impl.CuramConst;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.samplingstrategy.impl.SamplingStrategy;
import curam.selectionquery.impl.Criteria;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class FixedQueryCaseAuditGenerator implements CaseAuditGenerator {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  @Inject
  protected Map<SAMPLINGSTRATEGYEntry, SamplingStrategy> samplingStrategies;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public FixedQueryCaseAuditGenerator() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00264606, GD
  // ___________________________________________________________________________
  /**
   * Generates the sample list of cases for audit using the supplied fixed
   * query. This method filters the list using the algorithm associated with
   * the case type for this audit plan. The number of cases returned in the list
   * is also restricted by the number of cases or percentage of cases specified
   * by the user. Only cases matching the case type being audited are returned.
   *
   * @param key The selection query, percentage/number of cases to generate and
   * any algorithm parameters.
   * @throws AppException
   * @throws InformationalException
   */
  // END, CR00264606
  @Override
  public void generateCaseAudits(final CaseSampleKey key)
    throws AppException, InformationalException {

    final CaseAuditQueryManagement caseAuditQueryManagement = new CaseAuditQueryManagement();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    // In the case of regeneration, remove existing case audits
    auditPlan.clearCaseLoad();
    auditPlan.clearSelectionCriteria();

    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    final List<CaseHeader> caseList = caseAuditQueryManagement.runFixedQueryCaseSearch(
      key.selectionQueryID);

    // BEGIN, CR00264606, GD
    // Filter case list so only cases matching that are of the case type being
    // audited are returned.
    final List<CaseHeader> filteredCaseList = new ArrayList<CaseHeader>();
    final String auditCaseTypeCode = auditPlan.getAuditCaseConfig().getCaseType().getCode();
    final String auditCaseCategoryCode = auditPlan.getAuditCaseConfig().getCaseCategory().getCode();

    for (final CaseHeader caseHeader : caseList) {

      if (caseHeader.getCaseType().getCode().equals(auditCaseTypeCode)
        && caseHeader.getIntegratedCaseType().getCode().equals(
          auditCaseCategoryCode)) {
        filteredCaseList.add(caseHeader);
      }
    }
    // END, CR00264606

    final CaseAuditGeneratorHelper caseAuditGeneratorHelperObj = new CaseAuditGeneratorHelper();

    final CaseLoadDetails caseLoadDetails = new CaseLoadDetails();

    caseLoadDetails.numberOfCases = key.numberOfCases;
    caseLoadDetails.percentageOfCases = key.percentageOfCases;
    // BEGIN, CR00264606, GD
    caseLoadDetails.totalCases = filteredCaseList.size();
    // END, CR00264606

    final NumberAndPercentageOfCases numberAndPercentageOfCases = caseAuditGeneratorHelperObj.determineNumCasesToProcess(
      caseLoadDetails);

    // Get algorithm to use to generate case sample
    final SamplingStrategy samplingStrategy = samplingStrategies.get(
      auditCaseConfig.getAuditAlgorithm());

    final List<Long> caseIDList = new ArrayList<Long>();

    // BEGIN, CR00264606, GD
    for (final CaseHeader caseHeader : filteredCaseList) {
      // END, CR00264606
      caseIDList.add(caseHeader.getID());
    }

    if (key.details.startPoint == 0) {
      key.details.startPoint = new Double(CuramConst.gkOne + Math.random() * numberAndPercentageOfCases.numberOfCases).intValue();
    }

    if (key.details.interval == 0) {
      key.details.interval = Math.round(
        key.totalNumCases / numberAndPercentageOfCases.numberOfCases);
    }

    final Map<String, Object> params = new TreeMap<String, Object>();

    params.put(CuramConst.kSystematicSamplingStartIndex,
      new Integer(key.details.startPoint));
    params.put(CuramConst.kSystematicSamplingInterval,
      new Integer(key.details.interval));

    // Call algorithm to generate case sample
    final List<Long> caseIDs = samplingStrategy.getRandomSample(caseIDList,
      numberAndPercentageOfCases.numberOfCases, params);

    final curam.core.facade.intf.CaseAudit caseAuditObj = curam.core.facade.fact.CaseAuditFactory.newInstance();

    // for each case, create a case audit
    for (int i = 0; i < caseIDs.size(); i++) {

      final CaseAuditDetails caseAuditDetails = new CaseAuditDetails();

      caseAuditDetails.dtls.auditPlanID = key.auditPlanID;
      caseAuditDetails.dtls.caseID = caseIDs.get(i);
      caseAuditObj.createCaseAudit(caseAuditDetails);
    }

    // Update audit plan with number/percentage cases and query used
    final SelectionQuery selectionQuery = selectionQueryDAO.get(
      key.selectionQueryID);

    auditPlan.setNumberCases(numberAndPercentageOfCases.numberOfCases);
    auditPlan.setPercentageCases(numberAndPercentageOfCases.percentageOfCases);
    auditPlan.setSelectionQuery(selectionQuery);
    auditPlan.modify(auditPlan.getVersionNo());

    // Record the criteria entered by the audit coordinator
    final AuditPlanAndQueryKey auditPlanAndQueryKey = new AuditPlanAndQueryKey();

    auditPlanAndQueryKey.auditPlanID = key.auditPlanID;
    auditPlanAndQueryKey.selectionQueryID = key.selectionQueryID;
    recordSelectionCriteria(key);

    auditPlan.auditPlanPending(auditPlan.getVersionNo());
    auditPlan.caseSampleListGenerated();
  }

  // ___________________________________________________________________________
  /**
   * Records the criteria used by the fixed query during case sample generation.
   *
   * @param key The selection query and audit plan.
   */
  @Override
  public void recordSelectionCriteria(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.core.facade.intf.AuditPlanCriteria auditPlanCriteriaObj = curam.core.facade.fact.AuditPlanCriteriaFactory.newInstance();

    final SelectionQuery selectionQuery = selectionQueryDAO.get(
      key.selectionQueryID);
    final List<Criteria> criteriaList = selectionQuery.getCriteria();

    for (final Criteria criteria : criteriaList) {

      final AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = criteria.getDisplayName();
      auditPlanCriteriaDtls.value = criteria.getDisplayValue();
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
  }
}
