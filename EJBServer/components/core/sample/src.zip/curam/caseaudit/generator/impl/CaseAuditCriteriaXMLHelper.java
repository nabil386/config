/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.caseaudit.generator.impl;


import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.common.util.xml.dom.Document;


public interface CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample.
   *
   * @param key
   * The search criteria to be used in the generation of the case
   * audit sample.
   *
   * @return An XML <code>String</code> representation of the data to be used
   * in the creation of the case audit sample.
   */
  public String buildCriteria(CaseSampleKey key) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the
   * creation of the case audit sample.
   *
   * @param document
   * The XML <code>String</code> representation of the data to be used
   * in the creation of the case audit sample.
   *
   * @return The key containing the search criteria.
   */
  public CaseSampleKey parseCriteria(Document document) throws AppException,
      InformationalException;

}
