/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.caseaudit.generator.impl;


import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.common.util.xml.dom.Document;
import curam.common.util.xml.dom.DOMException;
import curam.common.util.xml.dom.xpath.XPath;


public class ExternalServiceCaseAuditCriteriaXMLHelper implements
  CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public ExternalServiceCaseAuditCriteriaXMLHelper() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample.
   *
   * @param key
   * The search criteria to be used in the generation of the case
   * audit sample.
   *
   * @return An XML <code>String</code> representation of the data to be used
   * in the creation of the case audit sample.
   */
  @Override
  public String buildCriteria(final CaseSampleKey key) throws AppException,
      InformationalException {

    final XMLBuilder xmlBuilder = new XMLBuilder(
      CaseAuditCriteriaXMLConst.kCaseSampleKey);

    if (key.auditPlanID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAuditPlanID);
      xmlBuilder.addTagData(String.valueOf(key.auditPlanID));
      xmlBuilder.closeTag();
    }

    if (key.totalNumCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTotalNumCases);
      xmlBuilder.addTagData(String.valueOf(key.totalNumCases));
      xmlBuilder.closeTag();
    }

    if (key.numberOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kNumCases);
      xmlBuilder.addTagData(String.valueOf(key.numberOfCases));
      xmlBuilder.closeTag();
    }

    if (key.percentageOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kPercentageOfCases);
      xmlBuilder.addTagData(String.valueOf(key.percentageOfCases));
      xmlBuilder.closeTag();
    }

    if (key.externalCaseAuditDataID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kExternalCaseAuditDataID);
      xmlBuilder.addTagData(String.valueOf(key.externalCaseAuditDataID));
      xmlBuilder.closeTag();
    }

    if (key.details != null) {

      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAlgorithmParameters);

      if (key.details.startPoint > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartPoint);
        xmlBuilder.addTagData(String.valueOf(key.details.startPoint));
        xmlBuilder.closeTag();
      }

      if (key.details.interval > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kInterval);
        xmlBuilder.addTagData(String.valueOf(key.details.interval));
        xmlBuilder.closeTag();
      }
      xmlBuilder.closeTag();
    }

    return xmlBuilder.getXmlString();
  }

  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the
   * creation of the case audit sample.
   *
   * @param document
   * The XML <code>String</code> representation of the data to be used
   * in the creation of the case audit sample.
   *
   * @return The key containing the search criteria.
   */
  @Override
  public CaseSampleKey parseCriteria(final Document document)
    throws AppException, InformationalException {

    final CaseSampleKey caseSampleKey = new CaseSampleKey();

    try {

      XPath xpath = new XPath("//CaseSampleKey/auditPlanID/text()");
      curam.common.util.xml.dom.Text text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(
        document.getRootElement());

      if (text != null) {
        caseSampleKey.auditPlanID = new Long(text.getText()).longValue();
      }

      xpath = new XPath("//CaseSampleKey/totalNumCases/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.totalNumCases = Integer.parseInt(text.getText());
      }

      xpath = new XPath("//CaseSampleKey/numberOfCases/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.numberOfCases = Integer.parseInt(text.getText());
      }

      xpath = new XPath("//CaseSampleKey/percentageOfCases/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.percentageOfCases = Double.parseDouble(text.getText());
      }

      xpath = new XPath(
        "//CaseSampleKey/externalCaseAuditDataID/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.externalCaseAuditDataID = new Long(text.getText()).longValue();
      }

      xpath = new XPath(
        "//CaseSampleKey/algorithmParameters/startPoint/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.startPoint = Integer.parseInt(text.getText());
      }

      xpath = new XPath(
        "//CaseSampleKey/algorithmParameters/interval/text()");
      text = (curam.common.util.xml.dom.Text) xpath.selectSingleDOMNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.interval = Integer.parseInt(text.getText());
      }
    } catch (final DOMException e) {
      throw new AppRuntimeException(e);
    }
    return caseSampleKey;
  }
}
