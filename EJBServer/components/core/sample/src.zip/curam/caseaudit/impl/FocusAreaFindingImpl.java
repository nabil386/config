/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.FocusAreaFindingDtls;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.intf.CaseAuditSecurityManagement;
import curam.caseaudit.struct.ValidateCaseAuditUserActionKey;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.message.impl.ENTFOCUSAREAFINDINGSExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.StringHelper;


/**
 * Implementation for FocusAreaFinding.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.FocusAreaFinding
 */
// BEGIN, CR00183334, PS
public class FocusAreaFindingImpl extends SingleTableEntityImpl<FocusAreaFindingDtls> implements FocusAreaFinding {

  // END, CR00183334

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected AuditPlanFocusAreaDAO auditPlanFocusAreaDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected FocusAreaFindingImpl() {

    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the focus area finding record.
   *
   * @throws InformationalException
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Modifies the focus area finding record.
   *
   * @param versionNo
   * The version number of the focus area finding record.
   *
   * @throws InformationalException
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    // Validate that the user can modify the findings
    // BEGIN, CR00210526, GD
    final CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();

    final ValidateCaseAuditUserActionKey validateCaseAuditUserActionKey = new ValidateCaseAuditUserActionKey();

    validateCaseAuditUserActionKey.caseAuditID = getCaseAudit().getID();

    try {
      caseAuditSecurityManagementObj.validateCaseAuditUserAction(
        validateCaseAuditUserActionKey);
    } catch (final AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
    // END, CR00210526

    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Removes the focus area finding record. (Note: This is a physical delete).
   *
   * @param versionNo
   * The version number of the Focus Area Finding Entry being removed.
   *
   * @throws InformationalException
   */
  @Override
  public void remove(final Integer versionNo) throws InformationalException {

    super.remove(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to hold any validations that need to read another entity or other
   * instances of this entity.
   */
  @Override
  public void crossEntityValidation() {

    final CaseAudit caseAudit = getCaseAudit();

    if (caseAudit.getLifecycleState().equals(CASEAUDITSTATUSEntry.COMPLETE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTFOCUSAREAFINDINGSExceptionCreator.ERR_XFV_CANNOT_EDIT_CASEAUDIT_COMPLETE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final AuditPlan auditPlan = caseAudit.getAuditPlan();

    if (auditPlan.getLifecycleState().equals(AUDITPLANSTATUSEntry.COMPLETE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTFOCUSAREAFINDINGSExceptionCreator.ERR_XFV_CANNOT_EDIT_AUDITPLAN_COMPLETE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validations across fields on the entity.
   */
  @Override
  public void crossFieldValidation() {// none required
  }

  // ___________________________________________________________________________
  /**
   * Validations for any mandatory fields.
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getDtls().caseAuditID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTFOCUSAREAFINDINGSExceptionCreator.ERR_FV_MANDATORY_CASE_AUDIT_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().auditPlanFocusAreaID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTFOCUSAREAFINDINGSExceptionCreator.ERR_FV_MANDATORY_AUDIT_PLAN_FOCUS_AREA_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (StringHelper.isEmpty(getDtls().findingsText)
      && !FOCUSAREASATISFIEDEntry.get(getDtls().areaSatisfied).equals(
        FOCUSAREASATISFIEDEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTFOCUSAREAFINDINGSExceptionCreator.ERR_XFV_MANDATORY_AREA_FINDINGS_NOT_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to set any default values for a new object instance.
   */
  @Override
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setAuditPlanFocusArea(
    final AuditPlanFocusArea auditPlanFocusArea) {

    getDtls().auditPlanFocusAreaID = auditPlanFocusArea.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setCaseAudit(final CaseAudit caseAudit) {

    getDtls().caseAuditID = caseAudit.getID();
  }

  // BEGIN, CR00221556, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setFindingsText(final String findingsText) throws AppException,
      InformationalException {

    getDtls().findingsText = findingsText;
  }

  // END, CR00221556

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setFocusAreaSatisfied(
    final FOCUSAREASATISFIEDEntry focusAreaSatisfied) {

    getDtls().areaSatisfied = focusAreaSatisfied.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AuditPlanFocusArea getAuditPlanFocusArea() {

    return auditPlanFocusAreaDAO.get(getDtls().auditPlanFocusAreaID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseAudit getCaseAudit() {

    return caseAuditDAO.get(getDtls().caseAuditID);
  }

  // BEGIN, CR00221556, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getFindingsText() throws AppException, InformationalException {

    return getDtls().findingsText;
  }

  // END, CR00221556

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public FOCUSAREASATISFIEDEntry getFocusAreaSatisfied() {

    return FOCUSAREASATISFIEDEntry.get(getDtls().areaSatisfied);
  }

}
