/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


/**
 * This class assigns values to the Curam constants
 */
public abstract class CaseAuditConst {

  public static final String kCoordinatorUserRoleName = "AUDITCOORDINATORROLE";

  public static final String kAuditorUserRoleName = "AUDITORROLE";

  public static final String kYes = "Yes";

  public static final String kNo = "No";

  public static final String kProgressChart = "ProgressChart";

  public static final String kNumberOfCaseAudits = "Number of Case Audits";

}
