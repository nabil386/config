/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.AUDITPLANPRIORITYEntry;
import curam.codetable.impl.AUDITPLANPURPOSEEntry;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.AUDITPLANUSERACCESSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.Date;
import java.util.Set;


/**
 * AuditPlanAccessor Accessor for {@linkplain curam.caseaudit.impl.AuditPlan}.
 *
 */
public interface AuditPlanAccessor extends StandardEntity,
    Lifecycle<AUDITPLANSTATUSEntry> {

  // ___________________________________________________________________________
  /**
   * Returns the current status of this record.
   *
   * @return The current status of this record
   */
  public RECORDSTATUSEntry getRecordStatus();

  // ___________________________________________________________________________
  /**
   * Returns the date on which this audit plan was created.
   *
   * @return the date on which this audit plan was created
   */
  public Date getCreatedDate();

  // ___________________________________________________________________________
  /**
   * Returns the user id of the user that created the audit plan.
   *
   * @return the user id of the user that created the audit plan
   */
  public String getCreatedBy();

  // ___________________________________________________________________________
  /**
   * Returns the user id of the coordinator of this audit plan.
   *
   * @return the user id of the coordinator of this audit plan
   */
  public String getCoordinator();

  // ___________________________________________________________________________
  /**
   * Returns the purpose of this audit plan.
   *
   * @return the purpose of this audit plan
   */
  public AUDITPLANPURPOSEEntry getPurpose();

  // ___________________________________________________________________________
  /**
   * Returns the priority of this audit plan.
   *
   * @return the priority of this audit plan
   */
  public AUDITPLANPRIORITYEntry getPriority();

  // ___________________________________________________________________________
  /**
   * Returns the access granted to case owners/supervisors for audits on this
   * plan.
   *
   * @return the access granted to case owners/supervisors for audits on this
   * plan
   */
  public AUDITPLANUSERACCESSEntry getUserAccess();

  // ___________________________________________________________________________
  /**
   * Returns the percentage of cases to be chosen from the original selection.
   *
   * @return the percentage of cases to be chosen from the original selection
   */
  public double getPercentageCases();

  // ___________________________________________________________________________
  /**
   * Returns the number of cases to be chosen from the original selection.
   *
   * @return the number of cases to be chosen from the original selection
   */
  public int getNumberCases();

  // ___________________________________________________________________________
  /**
   * Returns the scheduled start date of this audit plan.
   *
   * @return the scheduled start date of this audit plan
   */
  public Date getScheduledStartDate();

  // ___________________________________________________________________________
  /**
   * Returns the scheduled end date of this audit plan.
   *
   * @return the scheduled end date of this audit plan
   */
  public Date getScheduledEndDate();

  // ___________________________________________________________________________
  /**
   * Returns the comments related to scheduling on this audit plan.
   *
   * @return the comments related to scheduling on this audit plan
   */
  public String getScheduleComments();

  // ___________________________________________________________________________
  /**
   * Returns whether or not the case list was manually selected.
   *
   * @return whether or not the case list was manually selected
   */
  public boolean areCasesUserSelected();

  // ___________________________________________________________________________
  /**
   * Returns the list of Case Audits associated with this Audit Plan.
   *
   * @return The list of Case Audits associated with this Audit Plan
   */
  public Set<CaseAudit> getCaseAudits();

  // ___________________________________________________________________________
  /**
   * Returns the textual comments of this audit plan.
   *
   * @return Returns the textual comments of this audit plan
   */
  public String getComments();

  // ___________________________________________________________________________
  /**
   * Returns the audit plan reference.
   *
   * @return The audit plan reference.
   */
  public String getAuditPlanReference();

  // ___________________________________________________________________________
  /**
   * Returns the audit case config.
   *
   * @return The audit case config.
   */
  public AuditCaseConfig getAuditCaseConfig();

  // ___________________________________________________________________________
  /**
   * Returns the summary findings for this audit plan.
   *
   * @return The findings for this audit plan.
   */
  public String getSummaryFindings() throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns whether or not summary findings have been entered yet.
   *
   * @return true if findings have been entered
   */
  public boolean areSummaryFindingsEntered();

  // ___________________________________________________________________________
  /**
   * Returns whether or not all case audits on the plan are complete.
   *
   * @return true if all case audits are complete
   */
  public boolean areAllCaseAuditsComplete();

  // ___________________________________________________________________________
  /**
   * Returns the selection query used in the generation of the case sample.
   *
   * @return The selection query used in the generation of the case sample.
   */
  public SelectionQuery getSelectionQuery() throws AppException,
      InformationalException;

}
