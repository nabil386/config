/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.Insertable;


/**
 * External Case Audit Data.
 *
 */
@ImplementedBy(ExternalCaseAuditDataImpl.class)
public interface ExternalCaseAuditData extends Insertable,
    ExternalCaseAuditDataAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the name that represents the set of case identifiers supplied by
   * an external source.
   *
   * @param The name that represents the set of case identifiers supplied by
   * an external source.
   */
  public void setName(final String name);

}
