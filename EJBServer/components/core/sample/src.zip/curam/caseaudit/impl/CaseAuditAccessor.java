/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.Date;
import java.util.List;


/**
 * CaseAuditAccessor Accessor for {@linkplain curam.caseaudit.impl.CaseAudit}.
 *
 */
public interface CaseAuditAccessor extends StandardEntity,
    Lifecycle<CASEAUDITSTATUSEntry> {

  // ___________________________________________________________________________
  /**
   * Returns the Case Header record associated with this CaseAudit.
   *
   * @return The Case Header record associated with this CaseAudit
   */
  public CaseHeader getCase();

  // ___________________________________________________________________________
  /**
   * Returns the AuditPlan record associated with this CaseAudit.
   *
   * @return The AuditPlan record associated with this CaseAudit
   */
  public AuditPlan getAuditPlan();

  // ___________________________________________________________________________
  /**
   * Returns the auditor for this case audit.
   *
   * @return The auditor for this case audit
   */
  public Auditor getAuditor();

  // ___________________________________________________________________________
  /**
   * Returns the date on which the auditor was assigned to the case audit.
   *
   * @return The date on which the case audit was assigned
   */
  public Date getDateAssigned();

  // ___________________________________________________________________________
  /**
   * Returns the comments on this case audit.
   *
   * @return The comments on this case audit
   */
  public String getComments();

  // ___________________________________________________________________________
  /**
   * Returns the reference number for this case audit.
   *
   * @return The reference number of this case audit
   */
  public String getCaseAuditReference();

  // ___________________________________________________________________________
  /**
   * Returns the list of focus area findings for this case audit.
   *
   * @return The list of focus area finding records
   */
  public List<FocusAreaFinding> getFocusAreaFindings();

  // ___________________________________________________________________________
  /**
   * Returns the list of case audit feedback records for this case audit.
   *
   * @return The list of case audit feedback records
   */
  public List<CaseAuditFeedback> getCaseAuditFeedback();

  // ___________________________________________________________________________
  /**
   * Returns the findings for this case audit.
   *
   * @return The findings for this case audit
   */
  public String getCaseAuditFindings() throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns whether or not findings have been entered yet.
   *
   * @return true if findings have been entered
   */
  public boolean areFindingsEntered();

  // ___________________________________________________________________________
  /**
   * Returns whether or not feedback is required for the case audit.
   *
   * @return true if feedback is required for the case audit
   */
  public boolean isFeedbackRequired();
}
