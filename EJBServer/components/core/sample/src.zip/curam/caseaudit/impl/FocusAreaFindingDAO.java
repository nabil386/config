/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.StandardDAO;
import java.util.List;


/**
 * Data access for {@linkplain curam.caseaudit.impl.FocusAreaFinding}.
 */
@ImplementedBy(FocusAreaFindingDAOImpl.class)
public interface FocusAreaFindingDAO extends StandardDAO<FocusAreaFinding> {

  // ___________________________________________________________________________
  /**
   * Returns a list of FocusAreaFinding records for the given CaseAudit and
   * AuditPlanFocusArea.
   *
   * @param caseAudit
   * The CaseAudit to search for
   * @param auditPlanFocusArea
   * The AuditPlanFocusArea to search for
   *
   * @return list of FocusAreaFinding records
   */
  public List<FocusAreaFinding> searchByCaseAuditAndAuditPlanFocusArea(
    final CaseAudit caseAudit, final AuditPlanFocusArea auditPlanFocusArea);

  // ___________________________________________________________________________
  /**
   * Returns a list of FocusAreaFinding records for a given CaseAudit.
   *
   * @param caseAudit
   * The CaseAudit to search for
   *
   * @return list of FocusAreaFinding records
   */
  public List<FocusAreaFinding> searchByCaseAudit(final CaseAudit caseAudit);

}
