/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.AUDITCASETYPECODEEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.util.persistence.StandardEntity;


/**
 * AuditCaseConfig Accessor for
 * {@linkplain curam.caseaudit.impl.AuditCaseConfig}.
 *
 */
public interface AuditCaseConfigAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the case type.
   *
   * @return The case type.
   */
  public AUDITCASETYPECODEEntry getCaseType();

  // ___________________________________________________________________________
  /**
   * Returns the case category.
   *
   * @return The case category.
   */
  public CASECATTYPECODEEntry getCaseCategory();

  // ___________________________________________________________________________
  /**
   * Returns the audit algorithm associated with the case type.
   *
   * @return The audit algorithm.
   */
  public SAMPLINGSTRATEGYEntry getAuditAlgorithm();

  // ___________________________________________________________________________
  /**
   * Returns the manual case selection indicator.
   *
   * @return The manual case selection indicator.
   */
  public boolean isManualCaseSelectionAllowed();

  // ___________________________________________________________________________
  /**
   * Gets the case audit type SID associated with this configuration.
   *
   * @return The case audit type SID associated with this configuration.
   */
  public String getCaseAuditTypeSID();
}
