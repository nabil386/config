/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.util.persistence.StandardEntity;


/**
 * AuditTeam Accessor for {@linkplain curam.caseaudit.impl.AuditTeam}.
 *
 */
public interface AuditTeamAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the name.
   *
   * @return The name.
   */
  public String getName();

  // ___________________________________________________________________________
  /**
   * Returns the audit plan.
   *
   * @return The audit plan.
   */
  public AuditPlan getAuditPlan();

}
