/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.StandardDAO;
import java.util.SortedSet;


/**
 * Data access for {@linkplain curam.caseaudit.impl.CaseAuditTransactionLog}.
 */
@ImplementedBy(CaseAuditTransactionLogDAOImpl.class)
public interface CaseAuditTransactionLogDAO extends
    StandardDAO<CaseAuditTransactionLog> {

  // ___________________________________________________________________________
  /**
   * Retrieves a list of case audit transaction records for a specified case
   * audit, sorted by transaction date descending.
   *
   * @param caseAudit
   * the case audit to search on.
   *
   * @return all the instances that are associated with the case audit.
   */
  public SortedSet<CaseAuditTransactionLog> searchByCaseAudit(
    final CaseAudit caseAudit);

}
