/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.CaseAuditTransactionLogAdapter;
import curam.caseaudit.entity.struct.CaseAuditTransactionLogDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.CaseAuditTransactionLog}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.CaseAuditTransactionLogDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class CaseAuditTransactionLogDAOImpl extends StandardDAOImpl<CaseAuditTransactionLog, CaseAuditTransactionLogDtls>
  implements CaseAuditTransactionLogDAO {

  // END, CR00183334
  protected static final CaseAuditTransactionLogAdapter adapter = new CaseAuditTransactionLogAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected CaseAuditTransactionLogDAOImpl() {

    // END, CR00183334
    super(adapter, CaseAuditTransactionLog.class);
  }

  // ___________________________________________________________________________
  /**
   * Incident Comparator.
   */
  protected class CaseAuditTransactionLogComparator implements
    Comparator<CaseAuditTransactionLog> {

    public CaseAuditTransactionLogComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sorts case audit transaction log list based on recorded date then by
     * sequence number.
     */
    @Override
    public int compare(final CaseAuditTransactionLog o1,
      final CaseAuditTransactionLog o2) {

      if (o1.getTransactionDateTime().before(o2.getTransactionDateTime())) {
        return 1;
      }

      if (o1.getTransactionDateTime().after(o2.getTransactionDateTime())) {
        return -1;
      }

      if (o1.getSequenceNumber() < o2.getSequenceNumber()) {
        return 1;
      } else if (o1.getSequenceNumber() > o2.getSequenceNumber()) {
        return -1;
      } else {
        return 0;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SortedSet<CaseAuditTransactionLog> searchByCaseAudit(
    final CaseAudit caseAudit) {

    final SortedSet<CaseAuditTransactionLog> sortedTransactions = new TreeSet<CaseAuditTransactionLog>(
      new CaseAuditTransactionLogComparator());

    sortedTransactions.addAll(
      newList(adapter.searchByCaseAudit(caseAudit.getID())));

    return sortedTransactions;
  }
}
