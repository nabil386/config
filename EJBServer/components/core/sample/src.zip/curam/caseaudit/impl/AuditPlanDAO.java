/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import java.util.SortedSet;


/**
 * Data access for {@linkplain curam.caseaudit.impl.AuditPlan}.
 */
@ImplementedBy(AuditPlanDAOImpl.class)
public interface AuditPlanDAO extends StandardDAO<AuditPlan> {

  // ___________________________________________________________________________
  /**
   * Searches for all Audit Plan records for a specified status and coordinator,
   * sorted by status descending, then audit plan reference number ascending.
   *
   * @param status
   * the status to search on.
   * @param coordinator
   * the coordinator to search on.
   * @return all the instances that have the specified status and coordinator.
   */
  public SortedSet<AuditPlan> searchByRecordStatusAndCoordinator(
    final RECORDSTATUSEntry status, final String coordinator);

  // BEGIN, CR00223243, GD
  // ___________________________________________________________________________
  /**
   * Searches for all Audit Plan records for a specified case id, record status
   * and coordinator, sorted by status descending, then audit plan reference
   * number ascending.
   *
   * @param caseID
   * the case id to search on.
   * @param status
   * the status to search on.
   * @param coordinator
   * the coordinator to search on.
   * @return all the instances that have the specified status and coordinator.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SortedSet<AuditPlan> searchByCaseIDRecordStatusAndCoordinator(
    final long caseID, final RECORDSTATUSEntry status,
    final String coordinator) throws AppException, InformationalException;

  // END, CR00223243

  // ___________________________________________________________________________
  /**
   * Reads an audit plan record by audit plan reference.
   *
   * @param auditPlanReference
   * the unique audit plan reference
   * @return the audit plan record relating to the audit plan reference
   */
  public AuditPlan readByAuditPlanReference(final String auditPlanReference);

  // ___________________________________________________________________________
  /**
   * Searches for all the Audit Plan records based on the criteria specified,
   * sorted by audit plan reference descending.
   * At least one criteria must be provided.
   *
   * @param coordinator
   * holds the coordinator for searching.
   * @param type
   * holds the type for searching.
   * @param status
   * holds the status for searching.
   * @param activeOnlyInd
   * indicates that only active records should be returned.
   *
   * @return all the instances that meet the search criteria.
   */
  public SortedSet<AuditPlan> search(final String coordinator,
    final CASECATTYPECODEEntry type, final AUDITPLANSTATUSEntry status,
    final boolean activeOnlyInd) throws AppException, InformationalException;

}
