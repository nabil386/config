/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;


/**
 * FocusAreaFinding Accessor for
 * {@linkplain curam.caseaudit.impl.FocusAreaFinding} .
 *
 */
public interface FocusAreaFindingAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the case audit associated with this finding.
   *
   * @return The case audit associated with this finding.
   */
  public CaseAudit getCaseAudit();

  // ___________________________________________________________________________
  /**
   * Returns the audit plan focus area associated with this finding.
   *
   * @return The audit plan focus area associated with this finding.
   */
  public AuditPlanFocusArea getAuditPlanFocusArea();

  // ___________________________________________________________________________
  /**
   * Returns the textual comments for the findings.
   *
   * @return The textual comments for the findings.
   */
  public String getFindingsText() throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns true if the focus area was satisfied.
   *
   * @return True if the focus area was satisfied.
   */
  public FOCUSAREASATISFIEDEntry getFocusAreaSatisfied();

}
