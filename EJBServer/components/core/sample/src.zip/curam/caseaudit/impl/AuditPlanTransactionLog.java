/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.AUDITPLANTRANSACTIONTYPEEntry;
import curam.util.persistence.Insertable;


/**
 * AuditPlanTransactionLog.
 *
 */
@ImplementedBy(AuditPlanTransactionLogImpl.class)
public interface AuditPlanTransactionLog extends Insertable,
    AuditPlanTransactionLogAccessor {

  // ____________________________________________________________________________
  /**
   * Sets the AuditPlan record associated with this AuditPlanTransactionLog.
   *
   * @param auditPlan
   * The AuditPlan record associated with this AuditPlanTransactionLog
   */
  public void setAuditPlan(final AuditPlan auditPlan);

  // ____________________________________________________________________________
  /**
   * Sets the transaction type for this AuditPlanTransactionLog.
   *
   * @param transactionType
   * The transaction type of this AuditPlanTransactionLog
   */
  public void setTransactionType(
    final AUDITPLANTRANSACTIONTYPEEntry transactionType);

  // ___________________________________________________________________________
  /**
   * Sets the name of the user that created the AuditPlanTransactionLog record.
   *
   * @param userName
   * The name of the user that created the AuditPlanTransactionLog.
   */
  public void setUserName(final String userName);

  // ___________________________________________________________________________
  /**
   * Sets the description of the AuditPlanTransactionLog record.
   *
   * @param description
   * The description of the AuditPlanTransactionLog.
   */
  public void setDescription(final String description);

  // ___________________________________________________________________________
  /**
   * Sets the relatedID, the unique ID of the record the audit plan transaction
   * log record relates to.
   *
   * @param relatedID
   * The unique ID of the related record.
   */
  public void setRelatedID(final long relatedID);

}
