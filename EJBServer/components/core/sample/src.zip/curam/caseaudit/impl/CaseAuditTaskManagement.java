/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.caseaudit.impl;


import curam.caseaudit.entity.struct.AllCaseAuditsCompleteNotificationDetails;
import curam.caseaudit.entity.struct.AssignCoordinatorNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditAuditorAssignmentNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditCompleteNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditFeedbackCompleteNotificationDetails;
import curam.caseaudit.entity.struct.CaseSampleListGeneratedNotificationDetails;
import curam.caseaudit.entity.struct.FeedbackRequiredTaskDetails;
import curam.caseaudit.entity.struct.ScheduledAuditPlanNotificationDetails;
import curam.caseaudit.entity.struct.ViewFindingsNotificationDetails;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.ArrayList;
import java.util.List;


/**
 * This class is used in the Case Audit Application to manage tasks
 * and notifications.
 */
public abstract class CaseAuditTaskManagement extends curam.caseaudit.base.CaseAuditTaskManagement {

  // ___________________________________________________________________________
  /**
   * Sends a notification to the new coordinator, informing them that the
   * audit plan has been assigned to them by the previous coordinator.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendAssignCoordinatorRoleNotification(
    final AssignCoordinatorNotificationDetails details) throws AppException,
      InformationalException {

    final List<AssignCoordinatorNotificationDetails> enactmentStructs = new ArrayList<AssignCoordinatorNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.assignedAuditCoordinatorRoleTaskDefinitionID,
      enactmentStructs);
  }

  // ___________________________________________________________________________
  /**
   * Sends a task to the specified user, informing them that feedback is
   * required on a case audit.
   *
   * @param details details used by the task.
   */
  @Override
  public void sendFeedbackRequiredTask(
    final FeedbackRequiredTaskDetails details) throws AppException,
      InformationalException {

    final List<FeedbackRequiredTaskDetails> enactmentStructs = new ArrayList<FeedbackRequiredTaskDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.caseAuditFeedbackTaskDefinitionID, enactmentStructs);
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification to a user, informing them that findings
   * have been completed for the case audit and can now be viewed.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendViewFindingsNotification(
    final ViewFindingsNotificationDetails details) throws AppException,
      InformationalException {

    final List<ViewFindingsNotificationDetails> enactmentStructs = new ArrayList<ViewFindingsNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.viewCaseAuditFindingsTaskDefinitionID,
      enactmentStructs);
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification to an audit coordinator,
   * informing them that a case audit has been completed.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendCaseAuditCompleteNotification(
    final CaseAuditCompleteNotificationDetails details) throws AppException,
      InformationalException {

    final List<CaseAuditCompleteNotificationDetails> enactmentStructs = new ArrayList<CaseAuditCompleteNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.caseAuditCompleteTaskDefinitionID, enactmentStructs);
  }

  // BEGIN, CR00219064, GD
  // ___________________________________________________________________________
  /**
   * Sends a notification to an auditor,
   * informing them that case audit feedback has been completed.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendCaseAuditFeedbackCompleteNotification(
    final CaseAuditFeedbackCompleteNotificationDetails details)
    throws AppException, InformationalException {

    final List<CaseAuditFeedbackCompleteNotificationDetails> enactmentStructs = new ArrayList<CaseAuditFeedbackCompleteNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.caseAuditFeedbackCompleteTaskDefinitionID,
      enactmentStructs);
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification to an auditor,
   * informing them that case audit has been assigned to them.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendCaseAuditAuditorAssignmentNotification(
    final CaseAuditAuditorAssignmentNotificationDetails details)
    throws AppException, InformationalException {

    final List<CaseAuditAuditorAssignmentNotificationDetails> enactmentStructs = new ArrayList<CaseAuditAuditorAssignmentNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.caseAuditAuditorAssignmentTaskDefinitionID,
      enactmentStructs);
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification to an audit coordinator,
   * informing them that all case audits on an audit plan have been completed.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendCaseSampleListGeneratedNotification(
    final CaseSampleListGeneratedNotificationDetails details)
    throws AppException, InformationalException {

    final List<CaseSampleListGeneratedNotificationDetails> enactmentStructs = new ArrayList<CaseSampleListGeneratedNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.caseSampleListGeneratedTaskDefinitionID,
      enactmentStructs);
  }

  // END, CR00219064

  // ___________________________________________________________________________
  /**
   * Sends a notification to an audit coordinator,
   * informing them that all case audits on an audit plan have been completed.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendAllCaseAuditsCompleteNotification(
    final AllCaseAuditsCompleteNotificationDetails details)
    throws AppException, InformationalException {

    final List<AllCaseAuditsCompleteNotificationDetails> enactmentStructs = new ArrayList<AllCaseAuditsCompleteNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.allCaseAuditsCompleteTaskDefinitionID,
      enactmentStructs);
  }

  // BEGIN, CR00222185, GD
  // ___________________________________________________________________________
  /**
   * Sends a notification to a supervisor, informing them that case(s) that they
   * are the supervisor of are scheduled for audit.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendScheduledAuditPlanSupervisorNotification(
    final ScheduledAuditPlanNotificationDetails details) throws AppException,
      InformationalException {

    final List<ScheduledAuditPlanNotificationDetails> enactmentStructs = new ArrayList<ScheduledAuditPlanNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.scheduledAuditPlanSupervisorTaskDefinitionID,
      enactmentStructs);
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification to a case owner, informing them that case(s) that they
   * are the case owner of are scheduled for audit.
   *
   * @param details details used by the notification.
   */
  @Override
  public void sendScheduledAuditPlanCaseownerNotification(
    final ScheduledAuditPlanNotificationDetails details) throws AppException,
      InformationalException {

    final List<ScheduledAuditPlanNotificationDetails> enactmentStructs = new ArrayList<ScheduledAuditPlanNotificationDetails>();

    enactmentStructs.add(details);
    curam.util.workflow.impl.EnactmentService.startProcess(
      TaskDefinitionIDConst.scheduledAuditPlanCaseownerTaskDefinitionID,
      enactmentStructs);
  }
  // END, CR00222185
}
