/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.CaseAuditFeedbackAdapter;
import curam.caseaudit.entity.struct.CaseAuditFeedbackDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.List;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.CaseAuditFeedback}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.CaseAuditFeedbackDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class CaseAuditFeedbackDAOImpl extends StandardDAOImpl<CaseAuditFeedback, CaseAuditFeedbackDtls> implements
  CaseAuditFeedbackDAO {

  // END, CR00183334
  protected static final CaseAuditFeedbackAdapter adapter = new CaseAuditFeedbackAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected CaseAuditFeedbackDAOImpl() {

    // END, CR00183334
    super(adapter, CaseAuditFeedback.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<CaseAuditFeedback> searchByCaseAudit(final CaseAudit caseAudit) {

    return newList(adapter.searchByCaseAudit(caseAudit.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<CaseAuditFeedback> searchByCaseAuditAndUsername(
    final CaseAudit caseAudit, final String username) {

    return newList(
      adapter.searchByCaseAuditAndUserName(caseAudit.getID(), username));
  }
}
