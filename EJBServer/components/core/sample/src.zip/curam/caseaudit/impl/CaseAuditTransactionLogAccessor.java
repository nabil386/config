/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.CASEAUDITTRANSACTIONTYPEEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateTime;


/**
 * CaseAuditTransactionLog Accessor for
 * {@linkplain curam.caseaudit.impl.CaseAuditTransactionLog}
 *
 */
public interface CaseAuditTransactionLogAccessor extends StandardEntity {

  // ____________________________________________________________________________
  /**
   * Returns the CaseAudit record associated with this CaseAuditTransactionLog.
   *
   * @return The CaseAudit record associated with this CaseAuditTransactionLog
   */
  public CaseAudit getCaseAudit();

  // ____________________________________________________________________________
  /**
   * Returns the transaction type for this CaseAuditTransactionLog.
   *
   * @return The transaction type of this CaseAuditTransactionLog
   */
  public CASEAUDITTRANSACTIONTYPEEntry getTransactionType();

  // ____________________________________________________________________________
  /**
   * Returns the date and time that this CaseAuditTransactionLog was created.
   *
   * @return The date and time that this CaseAuditTransactionLog was created
   */
  public DateTime getTransactionDateTime();

  // ___________________________________________________________________________
  /**
   * Returns the name of the user that created the CaseAuditTransactionLog
   * record.
   *
   * @return The name of the user that created the CaseAuditTransactionLog.
   */
  public String getUserName();

  // ___________________________________________________________________________
  /**
   * Returns the description of the CaseAuditTransactionLog record.
   *
   * @return The description of the CaseAuditTransactionLog.
   */
  public String getDescription();

  // ___________________________________________________________________________
  /**
   * Returns the relatedID, the unique ID of the record the case audit
   * transaction
   * log record relates to.
   *
   * @return The unique ID of the related record.
   */
  public long getRelatedID();

  // ___________________________________________________________________________
  /**
   * Returns the unique sequence number for this transaction, used to ensure
   * lists of transactions are sorted correctly
   *
   * @return The sequence number for this record
   */
  public long getSequenceNumber();

}
