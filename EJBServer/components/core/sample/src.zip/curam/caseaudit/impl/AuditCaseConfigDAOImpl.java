/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.AuditCaseConfigAdapter;
import curam.caseaudit.entity.struct.AuditCaseConfigDtls;
import curam.codetable.impl.AUDITCASETYPECODEEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.type.StringHelper;
import java.util.ArrayList;
import java.util.List;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.AuditCaseConfig}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditCaseConfigDAO
 */
@Singleton
public class AuditCaseConfigDAOImpl extends StandardDAOImpl<AuditCaseConfig, AuditCaseConfigDtls> implements
  AuditCaseConfigDAO {

  protected static final AuditCaseConfigAdapter adapter = new AuditCaseConfigAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  protected AuditCaseConfigDAOImpl() {

    super(adapter, AuditCaseConfig.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditCaseConfig> readAll() {

    // BEGIN, CR00266672, GD
    return newList(adapter.readAll());
    // END, CR00266672
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AuditCaseConfig readByCaseTypeAndCategory(final AUDITCASETYPECODEEntry caseType,
    final CASECATTYPECODEEntry caseCat) {

    // BEGIN, CR00266672, GD
    return getEntity(
      adapter.readByCaseTypeAndCategory(caseType.getCode(), caseCat.getCode()));
    // END, CR00266672
  }

  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Filters a list of audit case configurations removing any configurations
   * the current user doesn't have access to.
   */
  protected List<AuditCaseConfig> filterAuditCaseConfigListBySID(
    final List<AuditCaseConfig> auditCaseConfigList) {

    final List<AuditCaseConfig> filteredList = new ArrayList<AuditCaseConfig>();

    for (final AuditCaseConfig auditCaseConfig : auditCaseConfigList) {
      if (checkAuditCaseConfigBySID(auditCaseConfig)) {
        filteredList.add(auditCaseConfig);
      }
    }

    return filteredList;
  }

  // ___________________________________________________________________________
  /**
   * Checks if the current user has access to this case audit type.
   */
  protected boolean checkAuditCaseConfigBySID(
    final AuditCaseConfig auditCaseConfig) {

    boolean returnValue = false;

    // if AuditCaseConfig is null return true
    if (auditCaseConfig == null) {
      return true;
    }

    String currentUser;

    // Get the logged in user
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    try {

      currentUser = userAccessObj.getUserDetails().userName;

      if (StringHelper.isEmpty(auditCaseConfig.getCaseAuditTypeSID())
        || curam.util.security.Authorisation.isSIDAuthorised(
          auditCaseConfig.getCaseAuditTypeSID(), currentUser)) {

        returnValue = true;
      }
    } catch (final AppRuntimeException e) {// invalid security remove from list
    } catch (final AppException e) {// invalid security remove from list
    } catch (final InformationalException e) {// invalid security remove from
      // list
    }

    return returnValue;
  }
  // END, CR00210526

}
