/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditPlanCriteriaDtls;
import curam.message.impl.ENTAUDITPLANCRITERIAExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.StringHelper;


/**
 * Implementation for AuditPlanCriteria.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlanCriteria
 */
public class AuditPlanCriteriaImpl extends SingleTableEntityImpl<AuditPlanCriteriaDtls> implements AuditPlanCriteria {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  // ___________________________________________________________________________
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditPlanCriteriaImpl() {

    // no-arg constructor for use only by Guice
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit plan criteria.
   *
   * @throws InformationalException
   * {@link ENTAUDITPLANCRITERIA# ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET} - If
   * there is no audit plan
   * @throws InformationalException
   * {@link ENTAUDITPLANCRITERIA# ERR_FV_MANDATORY_CRITERIA_VALUE_NOT_SET} - If
   * no criteria value
   * has been entered
   * @throws InformationalException
   * {@link ENTAUDITPLANCRITERIA# ERR_FV_MANDATORY_CRITERIA_NAME_NOT_SET} - If
   * no criteria name
   * has been entered
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Removes the audit plan criteria record.
   *
   */
  @Override
  public void remove() throws InformationalException {

    super.remove();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getDtls().auditPlanID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANCRITERIAExceptionCreator.ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (StringHelper.isEmpty(getDtls().name)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANCRITERIAExceptionCreator.ERR_FV_MANDATORY_CRITERIA_NAME_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (StringHelper.isEmpty(getDtls().value)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANCRITERIAExceptionCreator.ERR_FV_MANDATORY_CRITERIA_VALUE_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AuditPlan getAuditPlan() {

    return auditPlanDAO.get(getDtls().auditPlanID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getName() {

    return getDtls().name;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getValue() {

    return getDtls().value;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setAuditPlan(final AuditPlan auditPlan) {

    getDtls().auditPlanID = auditPlan.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setName(final String name) {

    getDtls().name = name;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setValue(final String value) {

    getDtls().value = value;
  }

}
