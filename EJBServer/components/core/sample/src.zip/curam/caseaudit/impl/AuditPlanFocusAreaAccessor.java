/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.util.persistence.StandardEntity;


/**
 * AuditPlanFocusArea Accessor for
 * {@linkplain curam.caseaudit.impl.AuditPlanFocusArea}
 *
 */
public interface AuditPlanFocusAreaAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the audit plan associated with this audit plan
   * focus area.
   *
   * @return The audit plan associated with this audit plan
   * focus area.
   */
  public AuditPlan getAuditPlan();

  // ___________________________________________________________________________
  /**
   * Returns the focus area.
   *
   * @return The focus area.
   */
  public AUDITCASEFOCUSAREAEntry getFocusArea();
}
