/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.StandardDAO;
import java.util.SortedSet;


/**
 * Data access for {@linkplain curam.caseaudit.impl.AuditPlanTransactionLog}.
 */
@ImplementedBy(AuditPlanTransactionLogDAOImpl.class)
public interface AuditPlanTransactionLogDAO extends
    StandardDAO<AuditPlanTransactionLog> {

  // ___________________________________________________________________________
  /**
   * Retrieves a list of audit plan transaction records for a specified audit
   * plan, sorted by transaction date descending.
   *
   * @param auditPlan
   * the plan to search on.
   *
   * @return all the instances that are associated with the plan.
   */
  public SortedSet<AuditPlanTransactionLog> searchByAuditPlan(
    final AuditPlan auditPlan);

}
