/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.FocusAreaFindingAdapter;
import curam.caseaudit.entity.struct.FocusAreaFindingDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.List;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.FocusAreaFinding}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.FocusAreaFindingDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class FocusAreaFindingDAOImpl extends StandardDAOImpl<FocusAreaFinding, FocusAreaFindingDtls> implements
  FocusAreaFindingDAO {

  // END, CR00183334

  protected static final FocusAreaFindingAdapter adapter = new FocusAreaFindingAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected FocusAreaFindingDAOImpl() {

    // END, CR00183334
    super(adapter, FocusAreaFinding.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<FocusAreaFinding> searchByCaseAudit(final CaseAudit caseAudit) {

    return newList(adapter.searchByCaseAudit(caseAudit.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<FocusAreaFinding> searchByCaseAuditAndAuditPlanFocusArea(
    final CaseAudit caseAudit, final AuditPlanFocusArea auditPlanFocusArea) {

    return newList(
      adapter.searchByCaseAuditAndAuditPlanFocusArea(caseAudit.getID(),
      auditPlanFocusArea.getID()));
  }

}
