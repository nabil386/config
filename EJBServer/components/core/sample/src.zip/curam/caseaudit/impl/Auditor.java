/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockRemovable;


/**
 * Auditor.
 *
 */
@ImplementedBy(AuditorImpl.class)
public interface Auditor extends Insertable, OptimisticLockRemovable,
    AuditorAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the name.
   *
   * @param auditor
   * The name of the auditor.
   */
  public void setAuditorName(final String auditor) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the audit plan.
   *
   * @param auditPlan
   * The audit plan.
   */
  public void setAuditPlan(final AuditPlan auditPlan);

  // ___________________________________________________________________________
  /**
   * Sets the audit team where the auditor type is audit team.
   *
   * @param auditTeam
   * The audit team.
   */
  public void setAuditTeam(final AuditTeam auditTeam);

  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Validates that the auditor has access to the case audit type.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link BPOCASEAUDITSECURITY#ERR_FV_AUDITOR_ACCESS_DENIED} - If the auditor
   * hasn't access to this case audit type.</li>
   * </ul>
   *
   * @throws InformationalException
   */
  public void validateAuditorAccess() throws InformationalException;
  // END, CR00210526

}
