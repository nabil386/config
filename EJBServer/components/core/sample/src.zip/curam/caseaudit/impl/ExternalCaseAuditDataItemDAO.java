/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.struct.Count;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import java.util.List;


/**
 * Data access for {@linkplain curam.caseaudit.impl.ExternalCaseAuditDataItem}.
 */
@ImplementedBy(ExternalCaseAuditDataItemDAOImpl.class)
public interface ExternalCaseAuditDataItemDAO extends
    StandardDAO<ExternalCaseAuditDataItem> {

  // ___________________________________________________________________________
  /**
   * Retrieves a list of External Case Audit Data Items of a specified case type
   * that are associated with an External Case Audit Data record.
   *
   * @param externalCaseAuditData
   * the externalCaseAuditData record.
   * @param caseType
   * the type of case.
   * @param category
   * the category of case.
   *
   * @return all the instances of a specified case type that are associated with
   * an external Case Audit Data record.
   */
  public List<ExternalCaseAuditDataItem> searchByExternalCaseAuditDataAndCaseType(
    final ExternalCaseAuditData externalCaseAuditData,
    final CASETYPECODEEntry caseType, final CASECATTYPECODEEntry category)
    throws AppException, InformationalException;

  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of external case audit data items of a specified
   * case type that are associated with an external case audit data record.
   *
   * @param externalCaseAuditData the externalCaseAuditData record.
   * @param casetypecodeEntry the type of case.
   * @param casecattypecodeEntry the category of case.
   *
   * @return total number of specified case type that are associated with
   * an external case audit data record.
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  public Count countExternalCaseAuditDataByCaseType(
    final ExternalCaseAuditData externalCaseAuditData,
    final CASETYPECODEEntry casetypecodeEntry,
    final CASECATTYPECODEEntry casecattypecodeEntry) throws AppException,
      InformationalException;

  // END, CR00290965
}
