/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;


/**
 * FocusAreaFinding.
 *
 */
@ImplementedBy(FocusAreaFindingImpl.class)
public interface FocusAreaFinding extends Insertable,
    OptimisticLockModifiable, OptimisticLockRemovable, FocusAreaFindingAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the case audit associated with this finding.
   *
   * @param caseAudit
   * The case audit associated with this finding.
   */
  public void setCaseAudit(final CaseAudit caseAudit);

  // ___________________________________________________________________________
  /**
   * Sets the audit plan focus area that this finding is associated with.
   *
   * @param auditPlanFocusArea
   * The audit plan focus area that this finding is associated with.
   */
  public void setAuditPlanFocusArea(
    final AuditPlanFocusArea auditPlanFocusArea);

  // ___________________________________________________________________________
  /**
   * Sets if the focus area was satisfied or not.
   *
   * @param focusAreaSatisfied
   * If the focus area was satisfied or not.
   */
  public void setFocusAreaSatisfied(
    final FOCUSAREASATISFIEDEntry focusAreaSatisfied);

  // ___________________________________________________________________________
  /**
   * Sets the textual comments for the findings.
   *
   * @param findingsText
   * The textual comments for the findings.
   */
  public void setFindingsText(final String findingsText) throws AppException,
      InformationalException;

}
