/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.ImplementedBy;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.persistence.StandardDAO;
import java.util.List;


/**
 * Data access for {@linkplain curam.caseaudit.impl.AuditCaseSelectionQuery}.
 */
@ImplementedBy(AuditCaseSelectionQueryDAOImpl.class)
public interface AuditCaseSelectionQueryDAO extends
    StandardDAO<AuditCaseSelectionQuery> {

  // ___________________________________________________________________________
  /**
   * Returns a list of audit case selection query records for a
   * specified audit case config.
   *
   * @param auditCaseConfig the configuration to search by.
   *
   * @return List of audit case selection query records for a
   * specified audit case config.
   */
  public List<AuditCaseSelectionQuery> searchByAuditCaseConfig(
    AuditCaseConfig auditCaseConfig);

  // ___________________________________________________________________________
  /**
   * Returns a list of audit case selection query records for a specified
   * audit case configuration and selection query.
   *
   * @param auditCaseConfig
   * the audit case configuration.
   * @param selectionQuery
   * the selection query to search for.
   *
   * @return List of audit case selection query records
   * for a specified audit case configuration and selection query.
   */
  public List<AuditCaseSelectionQuery> searchByAuditCaseConfigAndSelectionQuery(
    final AuditCaseConfig auditCaseConfig,
    final SelectionQuery selectionQuery);

}
