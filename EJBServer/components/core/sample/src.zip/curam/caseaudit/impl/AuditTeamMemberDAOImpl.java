/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.AuditTeamMemberAdapter;
import curam.caseaudit.entity.struct.AuditTeamMemberDtls;
import curam.core.struct.UserNameKey;
import curam.util.dataaccess.CuramValueList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.List;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.AuditTeamMember}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditTeamMemberDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AuditTeamMemberDAOImpl extends StandardDAOImpl<AuditTeamMember, AuditTeamMemberDtls> implements
  AuditTeamMemberDAO {

  // END, CR00183334
  protected static final AuditTeamMemberAdapter adapter = new AuditTeamMemberAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AuditTeamMemberDAOImpl() {

    // END, CR00183334
    super(adapter, AuditTeamMember.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditTeamMember> searchByAuditTeam(final AuditTeam auditTeam) {

    return newList(adapter.searchByTeam(auditTeam.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditTeamMember> searchByAuditor(final Auditor auditor) {

    return newList(adapter.searchByAuditor(auditor.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditTeamMember> searchByUserName(final String userName)
    throws AppException, InformationalException {

    final List<AuditTeamMember> memberList = new ArrayList<AuditTeamMember>();

    final UserNameKey key = new UserNameKey();

    key.userName = userName;

    // BEGIN, CR00202947, GD
    final StringBuffer stringBuffer = new StringBuffer();

    // setup select part of SQL statement
    stringBuffer.append("SELECT AuditTeamMember.memberID,  ");
    stringBuffer.append("AuditTeamMember.teamID, AuditTeamMember.auditorID, ");
    stringBuffer.append("AuditTeamMember.versionNo ");
    stringBuffer.append("INTO :memberID, :teamID, :auditorID, :versionNo ");

    // setup the tables to select from
    stringBuffer.append("FROM AUDITTEAMMEMBER, AUDITOR ");

    // setup join
    stringBuffer.append("WHERE ");
    stringBuffer.append("Auditor.auditorID = AuditTeamMember.auditorID ");
    stringBuffer.append("AND Auditor.userName = :userName ");

    // Get a list of auditorIDs that correspond to the user name

    // Call dynamic SQL API to execute SQL
    final CuramValueList<AuditTeamMemberDtls> curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
      curam.caseaudit.entity.struct.AuditTeamMemberDtls.class, key, false,
      stringBuffer.toString());

    // END, CR00202947

    for (int i = 0; i < curamValueList.size(); i++) {
      memberList.add(getEntity(curamValueList.get(i)));
    }

    return memberList;
  }
}
