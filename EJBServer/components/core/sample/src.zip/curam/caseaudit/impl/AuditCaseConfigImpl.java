/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditCaseConfigDtls;
import curam.codetable.impl.AUDITCASETYPECODEEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.codetable.impl.SELECTIONQUERYTYPEEntry;
import curam.message.impl.ENTAUDITCASECONFIGExceptionCreator;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


/**
 * Implementation for AuditCaseConfig.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditCaseConfig
 */
public class AuditCaseConfigImpl extends SingleTableEntityImpl<AuditCaseConfigDtls> implements AuditCaseConfig {

  @Inject
  protected AuditCaseFocusAreaDAO auditCaseFocusAreaDAO;

  @Inject
  protected AuditCaseSelectionQueryDAO auditCaseSelectionQueryDAO;

  // ___________________________________________________________________________
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditCaseConfigImpl() {

    // no-arg constructor for use only by Guice
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit case config record.
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Modifies the audit case config record.
   *
   * @param versionNo
   * The version number of the audit case config record.
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setCaseCategory(final CASECATTYPECODEEntry value) {

    getDtls().caseCategory = value.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setCaseType(final AUDITCASETYPECODEEntry value) {

    getDtls().caseType = value.getCode();
  }

  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setCaseAuditTypeSID(final String value) {

    getDtls().caseAuditTypeSID = value;
  }

  // END, CR00210526

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setAuditAlgorithm(final SAMPLINGSTRATEGYEntry value) {

    getDtls().auditAlgorithm = value.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setManualCaseSelectionInd(final boolean value) {

    getDtls().manCaseSelectInd = value;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CASECATTYPECODEEntry getCaseCategory() {

    return CASECATTYPECODEEntry.get(getDtls().caseCategory);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AUDITCASETYPECODEEntry getCaseType() {

    return AUDITCASETYPECODEEntry.get(getDtls().caseType);
  }

  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getCaseAuditTypeSID() {

    return getDtls().caseAuditTypeSID;
  }

  // END, CR00210526

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SAMPLINGSTRATEGYEntry getAuditAlgorithm() {

    return SAMPLINGSTRATEGYEntry.get(getDtls().auditAlgorithm);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public boolean isManualCaseSelectionAllowed() {

    return getDtls().manCaseSelectInd;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public Set<AuditCaseFocusArea> getSelectedFocusAreas() {

    return auditCaseFocusAreaDAO.searchBy(this);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<SelectionQuery> getFixedQueries() {

    final List<SelectionQuery> fixedQueries = new ArrayList<SelectionQuery>();

    final List<AuditCaseSelectionQuery> queryList = auditCaseSelectionQueryDAO.searchByAuditCaseConfig(
      this);

    for (final AuditCaseSelectionQuery query : queryList) {

      final SelectionQuery selectionQuery = query.getSelectionQuery();

      if (selectionQuery.getType().getCode().equals(
        SELECTIONQUERYTYPEEntry.FIXED.getCode())) {

        fixedQueries.add(selectionQuery);
      }
    }

    return fixedQueries;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SelectionQuery getDynamicQuery() {

    final List<AuditCaseSelectionQuery> queryList = auditCaseSelectionQueryDAO.searchByAuditCaseConfig(
      this);

    // There should only be one dynamic query per configuration, in the
    // case that more than one is returned, return the first.
    for (final AuditCaseSelectionQuery query : queryList) {

      final SelectionQuery selectionQuery = query.getSelectionQuery();

      if (selectionQuery.getType().equals(SELECTIONQUERYTYPEEntry.DYNAMIC)
        || selectionQuery.getType().equals(SELECTIONQUERYTYPEEntry.PREDEFINED)) {

        return selectionQuery;
      }
    }
    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getAuditAlgorithm().equals(SAMPLINGSTRATEGYEntry.NOT_SPECIFIED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITCASECONFIGExceptionCreator.ERR_FV_ALGORITHM_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getCaseType().equals(AUDITCASETYPECODEEntry.NOT_SPECIFIED)
      || getCaseCategory().equals(CASECATTYPECODEEntry.NOT_SPECIFIED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITCASECONFIGExceptionCreator.ERR_FV_MANDATORY_CASE_AUDIT_TYPE_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// None Required
  }
}
