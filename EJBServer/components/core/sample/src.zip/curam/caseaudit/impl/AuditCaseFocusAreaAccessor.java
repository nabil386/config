/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.util.persistence.StandardEntity;


/**
 * AuditCaseFocusArea Accessor for
 * {@linkplain curam.caseaudit.impl.AuditCaseFocusArea}
 *
 */
public interface AuditCaseFocusAreaAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the audit case config associated with this audit case
   * focus area.
   *
   * @return The audit case config associated with this audit case
   * focus area.
   */
  AuditCaseConfig getAuditCaseConfig();

  // ___________________________________________________________________________
  /**
   * Returns the focus area.
   *
   * @return The focus area.
   */
  AUDITCASEFOCUSAREAEntry getFocusArea();

}
