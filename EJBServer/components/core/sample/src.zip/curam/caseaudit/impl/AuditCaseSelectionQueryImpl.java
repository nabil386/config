/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditCaseSelectionQueryDtls;
import curam.message.impl.ENTAUDITCASESELECTIONQUERYExceptionCreator;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Implementation for AuditCaseSelectionQuery.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditCaseSelectionQuery
 */
public class AuditCaseSelectionQueryImpl extends SingleTableEntityImpl<AuditCaseSelectionQueryDtls> implements
  AuditCaseSelectionQuery {

  @Inject
  protected AuditCaseConfigDAO auditCaseConfigDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditCaseSelectionQueryImpl() {

    // no-arg constructor for use only by Guice
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit case selection query.
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Removes the audit case selection query.
   *
   */
  @Override
  public void remove() throws InformationalException {

    super.remove();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getDtls().selectionQueryID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITCASESELECTIONQUERYExceptionCreator.ERR_FV_MANDATORY_SELECTION_QUERY_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().auditCaseConfigID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITCASESELECTIONQUERYExceptionCreator.ERR_FV_MANDATORY_AUDIT_CASE_CONFIG_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setAuditCaseConfig(final AuditCaseConfig auditCaseConfig) {

    getDtls().auditCaseConfigID = auditCaseConfig.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setSelectionQuery(final SelectionQuery selectionQuery) {

    getDtls().selectionQueryID = selectionQuery.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AuditCaseConfig getAuditCaseConfig() {

    return auditCaseConfigDAO.get(getDtls().auditCaseConfigID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SelectionQuery getSelectionQuery() {

    return selectionQueryDAO.get(getDtls().selectionQueryID);
  }

}
