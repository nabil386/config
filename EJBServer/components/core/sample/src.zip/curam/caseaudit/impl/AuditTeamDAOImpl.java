/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.AuditTeamAdapter;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.AuditTeamDtls;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import java.util.ArrayList;
import java.util.List;


/**
 * Data access Implementation for {@linkplain curam.caseaudit.impl.AuditTeam}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditTeamDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AuditTeamDAOImpl extends StandardDAOImpl<AuditTeam, AuditTeamDtls> implements AuditTeamDAO {

  // END, CR00183334
  protected static final AuditTeamAdapter adapter = new AuditTeamAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AuditTeamDAOImpl() {

    // END, CR00183334
    super(adapter, AuditTeam.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditTeam> searchByAuditPlan(final AuditPlan auditPlan)
    throws AppException, InformationalException {

    final List<AuditTeam> auditTeamList = new ArrayList<AuditTeam>();
    final AuditPlanKey key = new AuditPlanKey();

    // BEGIN, CR00202947, GD
    final StringBuffer stringBuffer = new StringBuffer();

    // setup the audit plan search key
    key.auditPlanID = auditPlan.getID();

    // setup select part of SQL statement
    stringBuffer.append("SELECT AuditTeam.auditTeamID, AuditTeam.name, ");
    stringBuffer.append("AuditTeam.versionNo ");
    stringBuffer.append("INTO :auditTeamID, :name, :versionNo ");

    // setup the tables to select from
    stringBuffer.append("FROM AUDITTEAM, AUDITOR ");

    // setup join
    stringBuffer.append("WHERE ");
    stringBuffer.append("Auditor.auditTeamID = AuditTeam.auditTeamID ");
    stringBuffer.append("AND Auditor.auditPlanID = :auditPlanID ");

    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    final CuramValueList<AuditTeamDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      AuditTeamDtls.class, key, false, true, stringBuffer.toString());

    // END, CR00290965

    // END, CR00202947

    for (int i = 0; i < curamValueList.size(); i++) {
      auditTeamList.add(getEntity(curamValueList.get(i)));
    }

    return auditTeamList;
  }

}
