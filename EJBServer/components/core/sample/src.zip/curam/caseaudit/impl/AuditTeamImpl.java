/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.fact.AuditTeamFactory;
import curam.caseaudit.entity.struct.AuditTeamCountDetails;
import curam.caseaudit.entity.struct.AuditTeamDtls;
import curam.caseaudit.entity.struct.AuditTeamNameAndPlanIDKey;
import curam.codetable.impl.AUDITPLANTRANSACTIONTYPEEntry;
import curam.message.BPOAUDITPLANTRANSACTIONEVENTS;
import curam.message.impl.ENTAUDITTEAMExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.transaction.TransactionInfo;
import java.util.List;


/**
 * Implementation for AuditTeam.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditTeam
 */
// BEGIN, CR00183334, PS
public class AuditTeamImpl extends SingleTableEntityImpl<AuditTeamDtls>
  implements AuditTeam {

  // END, CR00183334

  @Inject
  protected AuditorDAO auditorDAO;

  @Inject
  protected AuditTeamMemberDAO auditTeamMemberDAO;

  @Inject
  protected AuditPlanTransactionLogDAO auditPlanTransactionLogDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditTeamImpl() {

    // no-arg constructor for use only by Guice
    // END, CR00183334, PS
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit team record.
   *
   * @throws InformationalException
   */
  @Override
  public void insert() throws InformationalException {

    insertOperation();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit team record.
   *
   * @throws InformationalException
   */
  protected void insertOperation() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void insert(final AuditPlan auditPlan) throws InformationalException {

    // BEGIN, CR00202947, GD
    // validate audit team name is unique
    validateAuditTeamName(auditPlan.getID());
    // END, CR00202947

    insertOperation();

    final curam.caseaudit.impl.Auditor teamAuditorObj = auditorDAO.newInstance();

    teamAuditorObj.setAuditPlan(auditPlan);
    teamAuditorObj.setAuditTeam(this);
    teamAuditorObj.insert();
  }

  // ___________________________________________________________________________
  /**
   * Modifies the audit team record.
   *
   * @param versionNo
   * The version number of the audit team record.
   *
   * @throws InformationalException
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Removes the audit team record.
   *
   * @param versionNo
   * The version number of the audit team record.
   *
   * @throws InformationalException
   */
  @Override
  public void remove(final Integer versionNo) throws InformationalException {

    super.remove(versionNo);
    insertAuditTeamRemovedTransaction();
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that an audit
   * team has been removed from the audit plan.
   *
   * @throws InformationalException
   */
  protected void insertAuditTeamRemovedTransaction()
    throws InformationalException {

    final LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDIT_TEAM_REMOVED).arg(getName()).arg(
      getAuditPlan().getAuditPlanReference());

    final AuditPlanTransactionLog auditPlanTransactionLog = auditPlanTransactionLogDAO.newInstance();

    auditPlanTransactionLog.setAuditPlan(getAuditPlan());
    auditPlanTransactionLog.setTransactionType(
      AUDITPLANTRANSACTIONTYPEEntry.AUDIT_TEAM_REMOVED);
    auditPlanTransactionLog.setUserName(TransactionInfo.getProgramUser());
    auditPlanTransactionLog.setRelatedID(getID());
    auditPlanTransactionLog.setDescription(
      description.getMessage(TransactionInfo.getProgramLocale()));
    auditPlanTransactionLog.insert();

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setName(final String value) {

    getDtls().name = value;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getName() {

    return getDtls().name;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AuditPlan getAuditPlan() {

    return auditorDAO.readByAuditTeam(this).getAuditPlan();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditTeamMember> getMembers() {

    return auditTeamMemberDAO.searchByAuditTeam(this);
  }

  // BEGIN, CR00202947, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setMembers(final List<Auditor> members)
    throws InformationalException, AppException {

    // clear the list of current members
    final List<AuditTeamMember> currentMembers = getMembers();

    for (final AuditTeamMember auditTeamMember : currentMembers) {
      auditTeamMember.remove();
    }

    AuditTeamMember auditTeamMemberObj;

    // add the list of new auditors to the audit team
    for (final Auditor auditor : members) {

      auditTeamMemberObj = auditTeamMemberDAO.newInstance();
      auditTeamMemberObj.setAuditor(auditor);
      auditTeamMemberObj.setAuditTeam(this);
      auditTeamMemberObj.insert();
    }

    // BEGIN, CR00210526, GD
    // Check for informational messages
    ValidationHelper.failIfErrorsExist();
    // END, CR00210526

  }

  // END, CR00202947

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * Validates all mandatory field have been added to the audit plan.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITTEAM#ERR_FV_MANDATORY_NAME_NOT_SET} - If the team name has
   * not been set.</li>
   * </ul>
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getDtls().name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITTEAMExceptionCreator.ERR_FV_MANDATORY_NAME_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// None Required
  }

  // BEGIN, CR00202947, GD
  // ___________________________________________________________________________
  /**
   * Validates that the team has not already been added to the audit plan.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITTEAM#ERR_XRV_DUPLICATE_TEAM_EXISTS} - If the team has
   * already been added to the audit plan.</li>
   * </ul>
   *
   * * @param auditPlanID The unique identifier of the case audit that the team
   * is being added to.
   */
  protected void validateAuditTeamName(final Long auditPlanID)
    throws InformationalException {

    final curam.caseaudit.entity.intf.AuditTeam auditTeamObj = AuditTeamFactory.newInstance();

    final AuditTeamNameAndPlanIDKey auditTeamNameAndPlanIDKey = new AuditTeamNameAndPlanIDKey();

    auditTeamNameAndPlanIDKey.auditTeamName = getName();
    auditTeamNameAndPlanIDKey.auditPlanID = auditPlanID;

    try {

      final AuditTeamCountDetails auditTeamCountDetails = auditTeamObj.countAuditTeamByNameAndPlanID(
        auditTeamNameAndPlanIDKey);

      if (auditTeamCountDetails.count > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITTEAMExceptionCreator.ERR_XRV_DUPLICATE_TEAM_EXISTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    } catch (final AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
  }
  // END, CR00202947

}
