/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.AuditCaseSelectionQueryAdapter;
import curam.caseaudit.entity.struct.AuditCaseSelectionQueryDtls;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.persistence.StandardDAOImpl;
import java.util.List;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.AuditCaseSelectionQuery}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditCaseSelectionQueryDAO
 */
@Singleton
public class AuditCaseSelectionQueryDAOImpl extends StandardDAOImpl<AuditCaseSelectionQuery, AuditCaseSelectionQueryDtls>
  implements AuditCaseSelectionQueryDAO {

  protected static final AuditCaseSelectionQueryAdapter adapter = new AuditCaseSelectionQueryAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  protected AuditCaseSelectionQueryDAOImpl() {

    super(adapter, AuditCaseSelectionQuery.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditCaseSelectionQuery> searchByAuditCaseConfig(
    final AuditCaseConfig auditCaseConfig) {

    return newList(adapter.searchByAuditCaseConfig(auditCaseConfig.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public List<AuditCaseSelectionQuery> searchByAuditCaseConfigAndSelectionQuery(
    final AuditCaseConfig auditCaseConfig,
    final SelectionQuery selectionQuery) {

    return newList(
      adapter.searchByAuditCaseConfigAndSelectionQuery(auditCaseConfig.getID(),
      selectionQuery.getID()));
  }
}
