/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.fact.ExternalCaseAuditDataItemFactory;
import curam.caseaudit.entity.struct.ExternalCaseAuditDataItemDtls;
import curam.caseaudit.entity.struct.NameAndCaseID;
import curam.core.struct.Count;
import curam.message.impl.ENTEXTERNALCASEAUDITDATAITEMExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Implementation for ExternalCaseAuditDataItem.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.ExternalCaseAuditDataItem
 */
public class ExternalCaseAuditDataItemImpl extends SingleTableEntityImpl<ExternalCaseAuditDataItemDtls> implements
  ExternalCaseAuditDataItem {

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected ExternalCaseAuditDataDAO externalCaseAuditDataDAO;

  // ___________________________________________________________________________
  /*
   * no-arg constructor for use only by Guice
   */
  protected ExternalCaseAuditDataItemImpl() {

    // no-arg constructor for use only by Guice
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the external case audit data item.
   *
   */
  @Override
  public void insert() throws InformationalException {

    validateInsert();
    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getDtls().caseID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTEXTERNALCASEAUDITDATAITEMExceptionCreator.ERR_FV_MANDATORY_CASE_ID_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (getDtls().externalCaseAuditDataID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTEXTERNALCASEAUDITDATAITEMExceptionCreator.ERR_FV_MANDATORY_EXTERNAL_CASE_AUDIT_DATA_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseHeader getCase() {

    return caseHeaderDAO.get(getDtls().caseID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setCase(final CaseHeader caseHeader) {

    getDtls().caseID = caseHeader.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ExternalCaseAuditData getExternalCaseAuditData() {

    return externalCaseAuditDataDAO.get(getDtls().externalCaseAuditDataID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setExternalCaseAuditData(
    final ExternalCaseAuditData externalCaseAuditData) {

    getDtls().externalCaseAuditDataID = externalCaseAuditData.getID();
  }

  // ___________________________________________________________________________
  /**
   * Validate that the case does not already exist for this external case
   * audit data set.
   */
  public void validateInsert() throws InformationalException {

    final curam.caseaudit.entity.intf.ExternalCaseAuditDataItem extCaseAuditDataItemObj = ExternalCaseAuditDataItemFactory.newInstance();

    final NameAndCaseID nameAndCaseID = new NameAndCaseID();

    nameAndCaseID.name = getExternalCaseAuditData().getName();
    nameAndCaseID.caseID = getDtls().caseID;

    try {
      final Count count = extCaseAuditDataItemObj.countByNameAndCaseID(
        nameAndCaseID);

      if (count.numberOfRecords > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTEXTERNALCASEAUDITDATAITEMExceptionCreator.ERR_FV_CASE_ID_EXISTS_FOR_DATA_SET(
            String.valueOf(nameAndCaseID.caseID), nameAndCaseID.name),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } catch (final AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
  }
}
