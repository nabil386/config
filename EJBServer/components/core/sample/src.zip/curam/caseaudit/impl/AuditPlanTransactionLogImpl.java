/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditPlanTransactionLogDtls;
import curam.codetable.impl.AUDITPLANTRANSACTIONTYPEEntry;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.KeySets;
import curam.core.struct.UniqueIDKeySet;
import curam.message.impl.ENTAUDITPLANTRANSACTIONLOGExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Implementation for AuditPlanTransactionLog.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlanTransactionLog
 */
// BEGIN, CR00183334, PS
public class AuditPlanTransactionLogImpl extends SingleTableEntityImpl<AuditPlanTransactionLogDtls> implements
  AuditPlanTransactionLog {

  // END, CR00183334

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditPlanTransactionLogImpl() {

    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit plan transaction.
   *
   * @throws InformationalException
   * {@link ENTCRITERIA#ERR_FV_ENTITY_NAME_DOES_NOT_EXIST} - If the
   * entity name does not exist
   * @throws InformationalException
   * {@link ENTCRITERIA#ERR_XFV_CRITERIA_ALREADY_EXISTS_FOR_CASE_TYPE} - If the
   * selection criterion already exists for the case type.
   * @throws InformationalException
   * {@link ENTCRITERIA#ERR_FV_ATTRIBUTE_NAME_DOES_NOT_EXIST} - If the
   * attribute name does not exist
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link ENTAUDITPLANTRANSACTIONLOG#ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET}
   * - If the audit plan is not populated.</li>
   * <li>
   * {@link ENTAUDITPLANTRANSACTIONLOG#ERR_FV_MANDATORY_TRANSACTION_TYPE_NOT_SET}
   * - If the audit transaction is not populated.</li>
   * <li>
   * {@link ENTAUDITPLANTRANSACTIONLOG#ERR_FV_MANDATORY_TRANSACTION_DATE_NOT_SET}
   * - If the audit transaction date is not populated.</li>
   * <li> {@link ENTAUDITPLANTRANSACTIONLOG#ERR_FV_MANDATORY_USER_NAME_NOT_SET} -
   * If the user is not populated.</li>
   * </ul>
   */
  @Override
  public void mandatoryFieldValidation() {

    if (getDtls().auditPlanID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANTRANSACTIONLOGExceptionCreator.ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().transactionType.equals(
      AUDITPLANTRANSACTIONTYPEEntry.NOT_SPECIFIED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANTRANSACTIONLOGExceptionCreator.ERR_FV_MANDATORY_TRANSACTION_TYPE_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().transactionDateTime.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANTRANSACTIONLOGExceptionCreator.ERR_FV_MANDATORY_TRANSACTION_DATE_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (StringHelper.isEmpty(getDtls().userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANTRANSACTIONLOGExceptionCreator.ERR_FV_MANDATORY_USER_NAME_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// None required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setAuditPlan(final AuditPlan auditPlan) {

    getDtls().auditPlanID = auditPlan.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AuditPlan getAuditPlan() {

    return auditPlanDAO.get(getDtls().auditPlanID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setTransactionType(final AUDITPLANTRANSACTIONTYPEEntry value) {

    getDtls().transactionType = value.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setUserName(final String value) {

    getDtls().userName = value;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setDescription(final String value) {

    getDtls().description = StringHelper.trim(value);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedID(final long value) {

    getDtls().relatedID = value;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AUDITPLANTRANSACTIONTYPEEntry getTransactionType() {

    return AUDITPLANTRANSACTIONTYPEEntry.get(getDtls().transactionType);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public DateTime getTransactionDateTime() {

    return getDtls().transactionDateTime;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getUserName() {

    return getDtls().userName;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getDescription() {

    return getDtls().description;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public long getRelatedID() {

    return getDtls().relatedID;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public long getSequenceNumber() {

    return getDtls().sequenceNo;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// none required
  }

  @Override
  public void setNewInstanceDefaults() {

    getDtls().transactionDateTime = DateTime.getCurrentDateTime();

    // Set the unique sequence number
    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_AUDITPLANSEQNUM;
    try {
      getDtls().sequenceNo = (int) UniqueIDFactory.newInstance().getNextIDFromKeySet(
        uniqueIDKeySet);
    } catch (final Exception e) {
      getDtls().sequenceNo = 0;
    }
  }

}
