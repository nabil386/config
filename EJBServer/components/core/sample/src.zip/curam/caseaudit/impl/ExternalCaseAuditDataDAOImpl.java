/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Singleton;
import curam.caseaudit.entity.impl.ExternalCaseAuditDataAdapter;
import curam.caseaudit.entity.struct.ExternalCaseAuditDataDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.ExternalCaseAuditData}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.ExternalCaseAuditDataDAO
 */
@Singleton
public class ExternalCaseAuditDataDAOImpl extends StandardDAOImpl<ExternalCaseAuditData, ExternalCaseAuditDataDtls> implements
  ExternalCaseAuditDataDAO {

  protected static final ExternalCaseAuditDataAdapter adapter = new ExternalCaseAuditDataAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  protected ExternalCaseAuditDataDAOImpl() {

    super(adapter, ExternalCaseAuditData.class);
  }

  // ___________________________________________________________________________
  /**
   * Audit Plan Criteria Comparator.
   */
  protected class ExternalCaseAuditDataNameComparator implements
    Comparator<ExternalCaseAuditData> {

    public ExternalCaseAuditDataNameComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sorts external case audit data based on name.
     */
    @Override
    public int compare(final ExternalCaseAuditData o1,
      final ExternalCaseAuditData o2) {

      return o1.getName().compareTo(o2.getName());
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SortedSet<ExternalCaseAuditData> readAll() {

    final SortedSet<ExternalCaseAuditData> sortedExternalCaseAuditData = new TreeSet<ExternalCaseAuditData>(
      new ExternalCaseAuditDataNameComparator());

    sortedExternalCaseAuditData.addAll(newList(adapter.readAll()));

    return sortedExternalCaseAuditData;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SortedSet<ExternalCaseAuditData> searchByName(final String name) {

    final SortedSet<ExternalCaseAuditData> sortedExternalCaseAuditData = new TreeSet<ExternalCaseAuditData>(
      new ExternalCaseAuditDataNameComparator());

    sortedExternalCaseAuditData.addAll(newList(adapter.searchByName(name)));

    return sortedExternalCaseAuditData;
  }
}
