/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalcheck.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.APPROVALCHECKOVERRIDEEntry;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import java.util.List;


/**
 * This is the readerDAO interface for Approval Checks.
 */

@ImplementedBy(ApprovalCheckDAOImpl.class)
public interface ApprovalCheckDAO extends StandardDAO<ApprovalCheck> {

  /**
   * Interface used when raising events for override of an approval check.
   */
  public interface ApprovalCheckOverrideEvent {

    /**
     * Event raised when an approval check is about to be performed. This event
     * facilitates the override of an approval check. After the event has been
     * raised the approvalCheckRequired parameter is checked.
     * If the approvalCheckRequired parameter has been changed from its default
     * value of NOT_SPECIFIED then the approval check is considered overridden
     * and the
     * corresponding value is returned. If approvalCheckRequired is set to
     * APPROVALCHECKREQUIRED
     * then true is returned. If approvalCheckRequired is set to
     * APPROVALCHECKNOTREQUIRED then
     * false is returned.
     *
     * @param relatedID
     * The identifier for the related type.
     * @param relatedType
     * The specific type of the related identifier.
     * @param userName
     * The user that the check will be performed against.
     * @param approvalCheckRequired
     * An event listener for this event should only ever change this
     * parameter if they wish to override approval check.
     * This parameter will be checked after the event has been raised.
     * This must be set by the listener of this event if approval check
     * is overridden and must hold the result of the overridden
     * approval check. Initial value will be NOT_SPECIFIED, if a
     * listener changes this parameter then this value will be returned
     * as part of approval check.
     * @throws InformationalException
     * Generic Application exception.
     */
    public void overrideApprovalCheck(final long relatedID,
      final APPROVALRELATEDTYPEEntry relatedType, final String userName,
      APPROVALCHECKOVERRIDEEntry approvalCheckRequired)
      throws InformationalException;

  }

  /**
   * Searches for Approval Check records by type, relatedType, username &
   * recordStatus. This could be used to list approval checks for a particular
   * user of a particular relatedType.
   *
   * @param type
   * 'User', 'OrganisationUnit' or 'RelatedType'
   * @param relatedType
   * the artefact the approval check is related to, for example,
   * Assessment, or product.
   * @param username
   * the username related to the approval check
   * @param status
   * the record status
   * @return a list of ApprovalCheck
   */
  public List<ApprovalCheck> searchByTypeUsernameAndStatus(
    APPROVALCHECKTYPEEntry type, APPROVALRELATEDTYPEEntry relatedType,
    String username, RECORDSTATUSEntry status);

  /**
   * Searches for Approval Check records by type, relatedType, relatedID &
   * recordStatus. This could be used to list approval checks for a particular
   * artefact, for example to list approval checks for a particular productID.
   *
   * @param type
   * 'User', 'OrganisationUnit' or 'RelatedType'
   * @param relatedType
   * the artefact the approval check is related to, for example,
   * Assessment, or product.
   * @param relatedId
   * the unique identifier of the related artefact.
   * @param status
   * the record status
   * @return a list of ApprovalCheck
   */
  public List<ApprovalCheck> searchByTypeRelatedIDRelatedTypeAndStatus(
    APPROVALCHECKTYPEEntry type, APPROVALRELATEDTYPEEntry relatedType,
    long relatedId, RECORDSTATUSEntry status);

  /**
   * Searches for Approval Check records by type, relatedType,
   * organisationUnitID & recordStatus. This could be used to list approval
   * checks for a particular organisationUnit, of a particular relatedType, for
   * example to list approval checks related to an Assessment, for an orgUnit.
   *
   * @param type
   * 'User', 'OrganisationUnit' or 'RelatedType'
   * @param relatedType
   * the artefact the approval check is related to, for example,
   * Assessment, or product.
   * @param organisationUnitID
   * the organization unit to search by.
   * @param status
   * the record status
   * @return a list of ApprovalCheck
   */
  public List<ApprovalCheck> searchByTypeOrganisationUnitAndStatus(
    APPROVALCHECKTYPEEntry type, APPROVALRELATEDTYPEEntry relatedType,
    long organisationUnitID, RECORDSTATUSEntry status);

  /**
   * Raises an {@link ApprovalCheckOverrideEvent} event to allow override of
   * approval check.
   * If approval check is not overridden then default processing is performed as
   * follows.
   * Checks if approval is required against the user provided. If no approval
   * check is found for the user then checks if approval is required against any
   * organization unit approval checks for the user provided. If no organization
   * unit approval checks are found for the user, then checks if approval is
   * required for the related identifier and related type provided. If no
   * approval checks are found for the related identifier and related type then
   * false is returned.
   *
   * @param relatedID
   * The identifier for the related type.
   * @param relatedType
   * The specific type of the related identifier.
   * @param userName
   * The user that the check will be performed against.
   *
   * @return Boolean. True if one or more approval checks are found and approval
   * is required based on the highest percentage recorded on any of the
   * approval checks found. False if one or more approval checks are
   * found and approval is not required based on the highest percentage
   * recorded on any of the approval checks found. Also returns False if
   * no approval checks are found.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public Boolean checkApprovalRequired(final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType, String userName)
    throws InformationalException, AppException;
}
