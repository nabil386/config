/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalcheck.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.Money;


/**
 * This is the mutator interface for Approval Check. This interface extends the
 * Accessor interface for Approval Check. Interfaces for events related to
 * Approval Check are defined within this interface.
 */

@ImplementedBy(ApprovalCheckImpl.class)
public interface ApprovalCheck extends ApprovalCheckAccessor,
    LogicallyDeleteable {

  /**
   * Interface used when raising events for creation of an approval check.
   */
  public interface ApprovalCheckCreateEvent {

    /**
     * Event raised when an approval check is about to be created. Default
     * validations against the type of approval check being created are executed
     * after this event has been sent.
     *
     * @param approvalCheck
     * The immutable object holding the data being inserted.
     * @throws InformationalException
     * Generic Application exception.
     */
    public void preCreateApprovalCheck(ApprovalCheckAccessor approvalCheck)
      throws InformationalException;

    /**
     * Event raised when an approval check has been created. Default validations
     * against the type of approval check created are executed before this event
     * has been sent.
     *
     * @param approvalCheck
     * The immutable object holding the data that has been inserted.
     * @throws InformationalException
     * Generic Application exception.
     */
    public void postCreateApprovalCheck(ApprovalCheckAccessor approvalCheck)
      throws InformationalException;
  }


  /**
   * Interface used when raising events for modify of an approval check.
   */
  public interface ApprovalCheckModifyEvent {

    /**
     * Event raised when an approval check is about to be modified. Default
     * validations against the type of approval check being modified are
     * executed after this event has been sent.
     *
     * @param approvalCheck
     * The immutable object holding the data being modified.
     * @throws InformationalException
     * Generic Application exception.
     */
    public void preModifyApprovalCheck(ApprovalCheckAccessor approvalCheck)
      throws InformationalException;

    /**
     * Event raised when an approval check has been modified. Default
     * validations against the type of approval check modified are executed
     * before this event has been sent.
     *
     * @param approvalCheck
     * The immutable object holding the data that has been modified.
     * @throws InformationalException
     * Generic Application exception.
     */
    public void postModifyApprovalCheck(ApprovalCheckAccessor approvalCheck)
      throws InformationalException;
  }

  /**
   * Creates an Approval Check.
   *
   * @param relatedType
   * The type of artefact this approval check is related to, for
   * example Assessment, Product etc.
   *
   * @param relatedID
   * The unique identifier of the artefact this approval check is
   * related to, for example the Assessment identifier, or the type of
   * Product identifier.
   *
   * @param typeCode
   * The type that this approval check is for. For example, User.
   *
   * @throws InformationalException
   * Generic Application exception.
   */
  public void createApprovalCheck(final APPROVALRELATEDTYPEEntry relatedType,
    final long relatedID, final APPROVALCHECKTYPEEntry typeCode)
    throws InformationalException;

  /**
   * Modifies an Approval Check.
   *
   * @param versionNo
   * The versionNo for optimistic locking.
   * @throws InformationalException
   * Generic Application exception.
   */
  public void modifyApprovalCheck(int versionNo)
    throws InformationalException;

  /**
   * Sets the username field.
   *
   * @param username
   * the username
   */
  public void setUsername(String username);

  /**
   * Sets the organisationUnitID field.
   *
   * @param organisationUnitID
   * the organisationUnitID
   */
  public void setOrganisationUnitID(long organisationUnitID);

  /**
   * Sets the percentage field.
   *
   * @param percent
   * the percent
   */
  public void setPercentage(short percent);

  /**
   * Sets the cost field.
   *
   * @param cost
   * the cost
   */
  public void setCost(Money cost);

  /**
   * Sets the comments field.
   *
   * @param comments
   * the comments
   */
  public void setComments(String comments);

}
