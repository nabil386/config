/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachmentlink.impl;


import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;


/**
 * AttachmentLink Accessor.
 *
 */
public interface AttachmentLinkAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns a list of Attachment link records and Attachment data for a related
   * object.
   *
   * @param relatedObjectID
   * Holds the id and type of the related object record.
   * @param attachmentLinkType
   * Attachment link type
   * @return List of attachment and attachment link data
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ListAttachmentLinkDetails listAttachmentByRelatedObject(
    final long relatedObjectID,
    final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns a list of Attachment link records and Attachment data for a related
   * object by record status.
   *
   * @param relatedObjectID
   * Holds the id and type of the related object record.
   * @param attachmentLinkType
   * Attachment link type
   * @param recordStatus
   * The Record Status.
   * @return List of attachment and attachment link data.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ListAttachmentLinkDetails listAttachmentByRelatedObjectAndStatus(
    final long relatedObjectID,
    final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType,
    RECORDSTATUSEntry recordStatus) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns the related attachment record id.
   *
   * @return the unique identifier of the related attachment record.
   */
  public long getAttachmentID();

  // ___________________________________________________________________________
  /**
   * Returns the participantroleID of a related participant.
   *
   * @return the unique identifier of the related ConcernRole.
   */
  public long getParticipantRoleID();

  // ___________________________________________________________________________
  /**
   * Returns the related Object's unique identifier.
   *
   * @return the unique identifier of the related Object.
   */
  public long getRelatedObjectID();

  // ___________________________________________________________________________
  /**
   * Returns the related Object's type.
   *
   * @return the type of the related Object.
   */
  public ATTACHMENTOBJECTLINKTYPEEntry getRelatedObjectType();

  // ___________________________________________________________________________
  /**
   * Returns the free text description of the Attachment from the Attachment
   * link.
   *
   * @return the string value of the attachment description.
   */
  public String getDescription();

  // ___________________________________________________________________________
  /**
   * Returns the sensitivity code table value of the Attachment from the
   * Attachment link.
   *
   * @return the sensitivity code.
   */
  public SENSITIVITYEntry getSensitivityCode();

  // ___________________________________________________________________________
  /**
   * Returns the user name of the user who has created the Attachment.
   *
   * @return the user name of the Attachment creator.
   */
  public String getCreator();
}
