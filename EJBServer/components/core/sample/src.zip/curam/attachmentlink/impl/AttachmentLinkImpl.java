/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 * Copyright IBM Corporation 2012-2019. All Rights Reserved.
 *
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachmentlink.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachment.impl.Attachment;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkDtls;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.caseaudit.impl.FocusAreaFinding;
import curam.caseaudit.impl.FocusAreaFindingDAO;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.codetable.impl.CMSMETADATACLASSTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.core.sl.entity.struct.AllegationKey;
import curam.core.sl.fact.AllegationFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.intf.Allegation;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentHeaderDetails;
import curam.core.struct.AttachmentKey;
import curam.core.struct.AttachmentNameStruct;
import curam.core.struct.SensitivityCode;
import curam.incident.impl.IncidentDAO;
import curam.incident.impl.IncidentHelper;
import curam.message.impl.BPOATTACHMENTLINKExceptionCreator;
import curam.message.impl.GENERALExceptionCreator;
import curam.piwrapper.impl.ContactLog;
import curam.piwrapper.impl.ContactLogDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;
import java.util.List;

/**
 * AttachmentLink Implementation.
 *
 * For public method JavaDoc
 *
 * @see curam.attachmentlink.impl.AttachmentLink
 */
// BEGIN, CR00183334, PS
public class AttachmentLinkImpl
  extends SingleTableLogicallyDeleteableEntityImpl<AttachmentLinkDtls>
  implements AttachmentLink {

  // END, CR00183334

  // BEGIN, CR00231006, GD
  @Inject
  protected EventDispatcherFactory<AttachmentLinkEvents> eventDispatcherFactory;

  // BEGIN, CR00141221, PF
  @Inject
  protected EventDispatcherFactory<AttachmentLinkInsertionEvents> attachmentLinkInsertionEventDispatcherFactory;

  @Inject
  protected EventDispatcherFactory<AttachmentLinkCancelationEvents> attachmentLinkCancelationEventDispatcherFactory;

  @Inject
  protected EventDispatcherFactory<AttachmentLinkModificationEvents> attachmentLinkModificationEventDispatcherFactory;

  // END, CR00141221
  // END, CR00231006

  @Inject
  protected CMISAccessInterface cmisAccess;

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // BEGIN, CR00146458, VR

  @Inject
  protected Attachment attachment;

  // BEGIN, CR00365030, CD
  @Inject
  protected Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00365030

  @Inject
  protected FocusAreaFindingDAO focusAreaFindingDAO;

  @Inject
  protected ContactLogDAO contactLogDAO;

  // BEGIN, RTC 183047, COF
  @Inject
  protected IncidentDAO incidentDAO;

  // END, RTC 183047

  // END, CR00146458

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected AttachmentLinkImpl() {// no-arg constructor for use only by Guice

  }

  // END, CR00183334

  // ___________________________________________________________________________
  @Override
  public void crossEntityValidation() {// not required

  }

  // ___________________________________________________________________________
  @Override
  public void crossFieldValidation() {// not required

  }

  // ___________________________________________________________________________
  @Override
  public void mandatoryFieldValidation() {

    if (StringHelper.isEmpty(getDescription())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTLINKExceptionCreator
            .ERR_ATTACHMENT_FV_EMPTY_DESCRIPTION(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (getRelatedObjectType()
      .equals(ATTACHMENTOBJECTLINKTYPEEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTLINKExceptionCreator
            .ERR_ATTACHMENT_FV_MANDATORY_RELATED_OBJECT_TYPE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (getRelatedObjectID() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTLINKExceptionCreator
            .ERR_ATTACHMENT_FV_MANDATORY_RELATED_OBJECT_ID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  @Override
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).preCancel(this);

    // BEGIN, CR00141221, PF
    attachmentLinkCancelationEventDispatcherFactory
      .get(AttachmentLinkCancelationEvents.class).preCancel(this, versionNo);
    // END, CR00141221
    // END, CR00231006

    final AttachmentKey attachmentKey = new AttachmentKey();

    checkSensitivity();
    ValidationHelper.failIfErrorsExist();

    attachmentKey.attachmentID = getAttachmentID();
    attachment.cancel(attachmentKey);
    super.cancel(versionNo);

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).postCancel(this);
    // BEGIN, CR00141221, PF
    attachmentLinkCancelationEventDispatcherFactory
      .get(AttachmentLinkCancelationEvents.class).postCancel(this, versionNo);
    // END, CR00141221
    // END, CR00231006
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelAttachmentLink(final int versionNo)
    throws InformationalException {

    eventDispatcherFactory.get(AttachmentLinkEvents.class).preCancel(this);
    attachmentLinkCancelationEventDispatcherFactory
      .get(AttachmentLinkCancelationEvents.class).preCancel(this, versionNo);

    final AttachmentKey attachmentKey = new AttachmentKey();
    attachmentKey.attachmentID = getAttachmentID();

    checkSensitivity();
    ValidationHelper.failIfErrorsExist();

    super.cancel(versionNo);

    eventDispatcherFactory.get(AttachmentLinkEvents.class).postCancel(this);
    attachmentLinkCancelationEventDispatcherFactory
      .get(AttachmentLinkCancelationEvents.class).postCancel(this, versionNo);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public long insert(final AttachmentLinkDetails attachmentLinkDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).preCreate(this);

    // BEGIN, CR00141221, PF
    attachmentLinkInsertionEventDispatcherFactory
      .get(AttachmentLinkInsertionEvents.class)
      .preInsert(this, attachmentLinkDetails);
    // END, CR00141221
    // END, CR00231006
    final AttachmentDtls attachmentDtls =
      attachmentLinkDetails.attachmentDtls;

    // inserts attachment record
    attachment.insert(attachmentDtls);

    setAttachmentID(attachmentDtls.attachmentID);
    setRelatedObjectID(
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);
    setRelatedObjectType(ATTACHMENTOBJECTLINKTYPEEntry
      .get(attachmentLinkDetails.attachmentLinkDtls.relatedObjectType));
    setDescription(attachmentLinkDetails.attachmentLinkDtls.description);
    setRecordStatus(RECORDSTATUSEntry.NORMAL);
    setParticipantRoleID(
      attachmentLinkDetails.attachmentLinkDtls.participantRoleID);
    setSensitivity(SENSITIVITYEntry
      .get(attachmentLinkDetails.attachmentLinkDtls.sensitivityCode));
    setCreator();
    insert();

    checkSensitivity();

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = getID();
    attachmentLinkDetails.attachmentLinkDtls.versionNo = getVersionNo();

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).postCreate(this);
    // BEGIN, CR00141221, PF
    attachmentLinkInsertionEventDispatcherFactory
      .get(AttachmentLinkInsertionEvents.class)
      .postInsert(this, attachmentLinkDetails, getID());
    // END, CR00141221
    // END, CR00231006

    return getID();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public long
    insertAttachmentLink(final AttachmentLinkDetails attachmentLinkDetails)
      throws AppException, InformationalException {

    eventDispatcherFactory.get(AttachmentLinkEvents.class).preCreate(this);
    attachmentLinkInsertionEventDispatcherFactory
      .get(AttachmentLinkInsertionEvents.class)
      .preInsert(this, attachmentLinkDetails);

    setAttachmentID(attachmentLinkDetails.attachmentLinkDtls.attachmentID);
    setRelatedObjectID(
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);
    setRelatedObjectType(ATTACHMENTOBJECTLINKTYPEEntry
      .get(attachmentLinkDetails.attachmentLinkDtls.relatedObjectType));
    setDescription(attachmentLinkDetails.attachmentLinkDtls.description);
    setRecordStatus(RECORDSTATUSEntry.NORMAL);
    setParticipantRoleID(
      attachmentLinkDetails.attachmentLinkDtls.participantRoleID);
    setSensitivity(SENSITIVITYEntry
      .get(attachmentLinkDetails.attachmentLinkDtls.sensitivityCode));
    setCreator();
    insert();

    checkSensitivity();

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = getID();
    attachmentLinkDetails.attachmentLinkDtls.versionNo = getVersionNo();

    // if enabled, call the CMIS API to fetch the content by it's unique ID
    if (cmisAccess.isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.ATTACHMENT)) {
      updateMetaDataInCMIS(attachmentLinkDetails);
    }

    eventDispatcherFactory.get(AttachmentLinkEvents.class).postCreate(this);
    attachmentLinkInsertionEventDispatcherFactory
      .get(AttachmentLinkInsertionEvents.class)
      .postInsert(this, attachmentLinkDetails, getID());

    return getID();
  }

  // ___________________________________________________________________________
  @Override
  public long getAttachmentID() {

    return getDtls().attachmentID;
  }

  // ___________________________________________________________________________
  @Override
  public String getDescription() {

    return getDtls().description;
  }

  // ___________________________________________________________________________
  @Override
  public long getRelatedObjectID() {

    return getDtls().relatedObjectID;
  }

  // ___________________________________________________________________________
  @Override
  public SENSITIVITYEntry getSensitivityCode() {

    return SENSITIVITYEntry.get(getDtls().sensitivityCode);
  }

  // ___________________________________________________________________________
  @Override
  public ATTACHMENTOBJECTLINKTYPEEntry getRelatedObjectType() {

    return ATTACHMENTOBJECTLINKTYPEEntry.get(getDtls().relatedObjectType);
  }

  // ___________________________________________________________________________
  @Override
  public ListAttachmentLinkDetails listAttachmentByRelatedObject(
    final long relatedObjectID,
    final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType)
    throws AppException, InformationalException {

    final List<AttachmentLink> attachmentLinkList = attachmentLinkDAO
      .searchByRelatedIDAndType(relatedObjectID, attachmentLinkType);

    // BEGIN, CR00451908, AC
    return assignAttachmentLinkDtls(attachmentLinkList);
    // END, CR00451908
  }

  // ___________________________________________________________________________
  /**
   * Populates a ListAttachmentLinkDetails struct with the details from a list
   * of AttachmentLink objects.
   *
   * @param attachmentLinkList
   * A list of AttachmentLink objects
   * @return A struct containing a list of AttachmentLink, and associated
   * attachment, details
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected ListAttachmentLinkDetails
    assignAttachmentLinkDtls(final List<AttachmentLink> attachmentLinkList)
      throws AppException, InformationalException {

    final ListAttachmentLinkDetails listAttachmentLinkDetails =
      new ListAttachmentLinkDetails();

    for (final AttachmentLink attachmentLink : attachmentLinkList) {
      final AttachmentLinkDetails attachmentLinkDetails =
        new AttachmentLinkDetails();

      attachmentLinkDetails.attachmentLinkDtls.attachmentID =
        attachmentLink.getAttachmentID();
      attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID =
        attachmentLink.getID();
      attachmentLinkDetails.attachmentLinkDtls.description =
        attachmentLink.getDescription();
      attachmentLinkDetails.attachmentLinkDtls.recordStatus =
        attachmentLink.getLifecycleState().getCode();
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectID =
        attachmentLink.getRelatedObjectID();
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectType =
        attachmentLink.getRelatedObjectType().getCode();
      attachmentLinkDetails.attachmentLinkDtls.versionNo =
        attachmentLink.getVersionNo();
      attachmentLinkDetails.attachmentLinkDtls.sensitivityCode =
        attachmentLink.getSensitivityCode().getCode();
      attachmentLinkDetails.attachmentLinkDtls.creatorUserName =
        attachmentLink.getCreator();
      final AttachmentKey attachmentKey = new AttachmentKey();

      attachmentKey.attachmentID = attachmentLink.getAttachmentID();
      attachmentLinkDetails.attachmentDtls = attachment.read(attachmentKey);

      listAttachmentLinkDetails.attachmentLinkDetails
        .addRef(attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;

  }

  // ___________________________________________________________________________
  // BEGIN, CR00442192, SR
  /**
   * Populates a ListAttachmentLinkDetails struct with the details from a list
   * of AttachmentLink objects excluding the attachment contents.
   *
   * @param attachmentLinkList
   * A list of AttachmentLink objects
   * @return A struct containing a list of AttachmentLink, and associated
   * attachment, details
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  protected ListAttachmentLinkDetails assignAttachmentLinkDtlsWithoutContents(
    final List<AttachmentLink> attachmentLinkList)
    throws AppException, InformationalException {

    final ListAttachmentLinkDetails listAttachmentLinkDetails =
      new ListAttachmentLinkDetails();

    for (final AttachmentLink attachmentLink : attachmentLinkList) {
      final AttachmentLinkDetails attachmentLinkDetails =
        new AttachmentLinkDetails();

      attachmentLinkDetails.attachmentLinkDtls.attachmentID =
        attachmentLink.getAttachmentID();
      attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID =
        attachmentLink.getID();
      attachmentLinkDetails.attachmentLinkDtls.description =
        attachmentLink.getDescription();
      attachmentLinkDetails.attachmentLinkDtls.recordStatus =
        attachmentLink.getLifecycleState().getCode();
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectID =
        attachmentLink.getRelatedObjectID();
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectType =
        attachmentLink.getRelatedObjectType().getCode();
      attachmentLinkDetails.attachmentLinkDtls.versionNo =
        attachmentLink.getVersionNo();
      attachmentLinkDetails.attachmentLinkDtls.sensitivityCode =
        attachmentLink.getSensitivityCode().getCode();
      attachmentLinkDetails.attachmentLinkDtls.creatorUserName =
        attachmentLink.getCreator();
      final AttachmentKey attachmentKey = new AttachmentKey();

      attachmentKey.attachmentID = attachmentLink.getAttachmentID();
      attachmentLinkDetails.attachmentDtls =
        readAttachmentWithoutContents(attachmentKey);

      listAttachmentLinkDetails.attachmentLinkDetails
        .addRef(attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;
  }

  /**
   * A helper method that constructs and returns a version of attachment details
   * that doesn't contain
   * attachment contents
   *
   * @param attachmentKey The key to the attachment entity
   *
   * @return A version of attachment details that doesn't contain attachment
   * contents
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  private AttachmentDtls
    readAttachmentWithoutContents(final AttachmentKey attachmentKey)
      throws AppException, InformationalException {

    final AttachmentHeaderDetails attachmentHeaderDetails =
      curam.core.fact.AttachmentFactory.newInstance()
        .readHeader(attachmentKey);

    final AttachmentDtls localAttachmentDtls = new AttachmentDtls();

    localAttachmentDtls.attachedFileInd =
      attachmentHeaderDetails.attachedFileInd;
    localAttachmentDtls.attachmentID = attachmentHeaderDetails.attachmentID;
    localAttachmentDtls.attachmentName =
      attachmentHeaderDetails.attachmentName;
    localAttachmentDtls.attachmentStatus =
      attachmentHeaderDetails.attachmentStatus;
    localAttachmentDtls.documentType = attachmentHeaderDetails.documentType;
    localAttachmentDtls.fileLocation = attachmentHeaderDetails.fileLocation;
    localAttachmentDtls.fileReference = attachmentHeaderDetails.fileReference;
    localAttachmentDtls.receiptDate = attachmentHeaderDetails.receiptDate;
    localAttachmentDtls.statusCode = attachmentHeaderDetails.statusCode;
    localAttachmentDtls.versionNo = attachmentHeaderDetails.versionNo;

    return localAttachmentDtls;
  }

  // END, CR00442192

  // ___________________________________________________________________________
  @Override
  public ListAttachmentLinkDetails listAttachmentByRelatedObjectAndStatus(
    final long relatedObjectID,
    final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType,
    final RECORDSTATUSEntry recordStatus)
    throws AppException, InformationalException {

    final List<AttachmentLink> attachmentLinkList =
      attachmentLinkDAO.searchByRelatedIDTypeAndStatus(relatedObjectID,
        attachmentLinkType, recordStatus);

    return assignAttachmentLinkDtls(attachmentLinkList);
  }

  // ___________________________________________________________________________
  @Override
  public void checkSensitivity() throws InformationalException {

    boolean result = false;

    /*
     * Do perform sensitivity checking if the transaction is anything other than
     * an online transaction. For example, a batch transaction
     */
    if (!TransactionInfo.getTransactionType()
      .equals(TransactionInfo.TransactionType.kOnline)) {
      return;
    }

    // If sensitivity is not set, just return
    if (StringHelper.isEmpty(getDtls().sensitivityCode)) {
      return;
    }

    // If the user is not an internal user
    try {

      // get the users sensitivity
      SensitivityCode userSensitivityCode;

      userSensitivityCode =
        UserAccessFactory.newInstance().readSensitivityCode();

      // check if concernRole sensitivity is greater than user sensitivity
      final int userSensitivity =
        Integer.parseInt(userSensitivityCode.sensitivity);
      final int attachmentSensitivity =
        Integer.parseInt(getDtls().sensitivityCode);

      // BEGIN, RTC 183047, COF
      checkIncidentSensitivityWhenAttachedToIncident();
      // END, RTC 183047

      if (userSensitivity >= attachmentSensitivity) {
        result = true;
      }

    } catch (final NumberFormatException e) {// No action required, an error
      // means
      // it's false
    } catch (final AppException e) {// No action required, an error means it's
      // false
    } catch (final InformationalException e) {// No action required, an error
      // means
      // it's false
    }

    if (!result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTLINKExceptionCreator.ERR_ATTACHMENT_FV_SENSITIVE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    ValidationHelper.failIfErrorsExist();
  }

  // ___________________________________________________________________________
  @Override
  public void modify(final AttachmentLinkDetails attachmentLinkDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).preModify(this);

    // BEGIN, CR00141221, PF
    attachmentLinkModificationEventDispatcherFactory
      .get(AttachmentLinkModificationEvents.class)
      .preModify(this, attachmentLinkDetails);
    // END, CR00141221, PF
    // END, CR00231006

    // BEGIN, CR00150184, MC
    final curam.core.intf.MaintainAttachmentAssistant maintainAttachmentAssistantObj =
      curam.core.fact.MaintainAttachmentAssistantFactory.newInstance();
    final AttachmentNameStruct attachmentNameStruct =
      new AttachmentNameStruct();
    final boolean attachmentNameProvided =
      attachmentLinkDetails.attachmentDtls.attachmentName.length() != 0;

    if (attachmentNameProvided) {
      attachmentNameStruct.attachmentName =
        attachmentLinkDetails.attachmentDtls.attachmentName;
      // parse attachmentName from path of attachment, leaving just the
      // base name
      maintainAttachmentAssistantObj
        .parseAttachmentFileName(attachmentNameStruct);

      if (attachmentNameStruct.attachmentName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(new AppException(
            curam.message.BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_NAME_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    attachmentLinkDetails.attachmentDtls.attachmentName =
      attachmentNameStruct.attachmentName;
    // BEGIN, CR00155031, MC
    final AttachmentKey attachmentKey = new AttachmentKey();

    attachmentKey.attachmentID =
      attachmentLinkDetails.attachmentDtls.attachmentID;
    // END, CR00150184, MC

    if (RECORDSTATUSEntry.get(getLifecycleState().getCode())
      .equals(RECORDSTATUSEntry.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          GENERALExceptionCreator.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    }

    checkSensitivity();

    // BEGIN, CR00161481, ZV
    if (attachmentLinkDetails.attachmentDtls.attachmentContents
      .length() == 0) {

      final curam.core.intf.Attachment attachmentObj =
        curam.core.fact.AttachmentFactory.newInstance();
      final AttachmentDtls attachmentDtls =
        attachmentObj.read(attachmentKey, true);

      attachmentLinkDetails.attachmentDtls.attachmentName =
        attachmentDtls.attachmentName;
      attachmentLinkDetails.attachmentDtls.attachmentContents =
        attachmentDtls.attachmentContents;

    }
    // END, CR00161481

    // BEGIN, CR00365030, CD
    populateCMSMetadata(attachmentLinkDetails);
    // END, CR00365030

    // Modifies the attachment details
    attachment.modify(attachmentKey, attachmentLinkDetails.attachmentDtls);

    setDescription(attachmentLinkDetails.attachmentLinkDtls.description);
    setSensitivity(SENSITIVITYEntry
      .get(attachmentLinkDetails.attachmentLinkDtls.sensitivityCode));
    setParticipantRoleID(
      attachmentLinkDetails.attachmentLinkDtls.participantRoleID);
    modify();

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).postModify(this);
    // BEGIN, CR00141221, PF
    attachmentLinkModificationEventDispatcherFactory
      .get(AttachmentLinkModificationEvents.class)
      .postModify(this, attachmentLinkDetails);
    // END, CR00141221, PF
    // END, CR00231006
  }

  /**
   * Populate meta data for the attachment depending on the related object type.
   *
   * @param attachmentLinkDetails The attachment link details.
   * @throws AppException
   * @throws InformationalException
   */
  private void
    populateCMSMetadata(final AttachmentLinkDetails attachmentLinkDetails)
      throws AppException, InformationalException {

    // populate meta data for the attachment
    long caseID = 0;

    if (attachmentLinkDetails.attachmentLinkDtls.relatedObjectType
      .equals(ATTACHMENTOBJECTLINKTYPE.ALLEGATION)) {

      final Allegation allegationObj = AllegationFactory.newInstance();
      final AllegationKey allegationKey = new AllegationKey();

      allegationKey.allegationID =
        attachmentLinkDetails.attachmentLinkDtls.relatedObjectID;
      caseID = allegationObj.read(allegationKey).allegationDtls.caseID;

    } else if (attachmentLinkDetails.attachmentLinkDtls.relatedObjectType
      .equals(ATTACHMENTOBJECTLINKTYPE.FOCUSAREAFINDING)) {

      final FocusAreaFinding focusAreaFinding = focusAreaFindingDAO
        .get(attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);

      caseID = focusAreaFinding.getCaseAudit().getCase().getID();

    } else if (attachmentLinkDetails.attachmentLinkDtls.relatedObjectType
      .equals(ATTACHMENTOBJECTLINKTYPE.CONTACTLOG)) {
      // BEGIN, CR00391893, CMC
      final ContactLog contactLog = contactLogDAO
        .get(attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);

      if (null != contactLog.getCase()) {
        caseID = contactLog.getCase().getID();
      }
      // END, CR00391893
    }

    if (caseID != 0) {
      final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      cmsMetadata.add(CMSMetadataConst.kCaseID, Long.toString(caseID));
    }
  }

  // ___________________________________________________________________________
  @Override
  public void setAttachmentID(final long value) {

    getDtls().attachmentID = value;

  }

  // ___________________________________________________________________________
  @Override
  public void setDescription(final String value) {

    getDtls().description = value;

  }

  // ___________________________________________________________________________
  @Override
  public void setRelatedObjectID(final long value) {

    getDtls().relatedObjectID = value;

  }

  // ___________________________________________________________________________
  @Override
  public void
    setRelatedObjectType(final ATTACHMENTOBJECTLINKTYPEEntry value) {

    getDtls().relatedObjectType = value.getCode();

  }

  // ___________________________________________________________________________
  public void setRecordStatus(final RECORDSTATUSEntry value) {

    getDtls().recordStatus = value.getCode();

  }

  // ___________________________________________________________________________
  @Override
  public long getParticipantRoleID() {

    return getDtls().participantRoleID;
  }

  // ___________________________________________________________________________
  @Override
  public void setParticipantRoleID(final long value) {

    getDtls().participantRoleID = value;
  }

  // ___________________________________________________________________________
  @Override
  public void setSensitivity(final SENSITIVITYEntry value) {

    getDtls().sensitivityCode = value.getCode();
  }

  // ___________________________________________________________________________
  @Override
  public String getCreator() {

    return getDtls().creatorUserName;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00198672, VK
  protected void setCreator() {

    // END, CR00198672
    getDtls().creatorUserName = TransactionInfo.getProgramUser();
  }

  // BEGIN, RTC 183047, COF

  private void checkIncidentSensitivityWhenAttachedToIncident() {

    if (ATTACHMENTOBJECTLINKTYPEEntry.INCIDENT
      .equals(getRelatedObjectType())) {
      final curam.incident.impl.Incident incident =
        incidentDAO.get(getRelatedObjectID());
      final int incidentSensitivity =
        Integer.parseInt(incident.getSensitivity().getCode());
      final int attachmentSensitivity =
        Integer.parseInt(getDtls().sensitivityCode);
      if (incidentSensitivity > attachmentSensitivity) {
        IncidentHelper.sensitivityChecker(incident, 8);
      }
    }
  }

  private void
    updateMetaDataInCMIS(final AttachmentLinkDetails attachmentLinkDetails)
      throws AppException, InformationalException {

    populateCMSMetadata(attachmentLinkDetails);

    // if content exists on the CMS for the record in question
    if (cmisAccess.contentExists(
      attachmentLinkDetails.attachmentLinkDtls.attachmentID,
      CMSLINKRELATEDTYPEEntry.ATTACHMENT) == true) {

      cmisAccess.modify(attachmentLinkDetails.attachmentLinkDtls.attachmentID,
        CMSLINKRELATEDTYPEEntry.ATTACHMENT, null, null,
        CMSMETADATACLASSTYPEEntry.ATTACHMENT);

    } else {
      // RTC 252676
      // TODO - investigate if there is ever a possibility that the file may not
      // exist
      // on the CMS
    }
  }

}
