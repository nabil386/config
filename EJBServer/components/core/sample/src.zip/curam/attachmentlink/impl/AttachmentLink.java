/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachmentlink.impl;

import com.google.inject.ImplementedBy;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.OptimisticLockable;
import curam.util.persistence.helper.LogicallyDeleteable;

/**
 * This is the outer interface to attachments within CEF-core. This interface
 * will create, read, modify and list attachments relating them to another
 * object or class via the AttachmentLink table. To use this interface you will
 * need an entry in the AttachmentObjctLinkType codetable that denotes the
 * object you associated the attachment with.
 */
@ImplementedBy(AttachmentLinkImpl.class)
public interface AttachmentLink extends LogicallyDeleteable,
  // BEGIN, CR00141221, PF
  OptimisticLockable, AttachmentLinkAccessor {

  // END, CR00141221

  /**
   * Interface to the AttachmentLink events functionality. AttachmentLink events
   * are raised from methods called on AttachmentLink objects.
   *
   * This interface has been replaced by the individual interfaces for each
   * method, these should be used instead of this interface.
   */
  public interface AttachmentLinkEvents {

    // ___________________________________________________________________________
    /**
     * Event interface invoked before the main body of the cancellation method.
     * To influence the behavior of the cancel method this can modify the
     * parameter or add a validation failure.
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be cancelled
     * @throws InformationalException
     */
    public void
      preCancel(curam.attachmentlink.impl.AttachmentLink attachmentLink)
        throws InformationalException;

    // ___________________________________________________________________________
    /**
     * Event interface after before the main body of the cancellation method.
     * This can not influence the behavior of the cancel method.
     *
     * @param attachmentLink
     * Details of the cancelled AttachmentLink
     * @throws InformationalException
     */
    public void
      postCancel(curam.attachmentlink.impl.AttachmentLink attachmentLink)
        throws InformationalException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked before the main body of the creation method. To
     * influence the behavior of the insert method this can modify the
     * parameter, add a validation failure or throw an AppException.
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be created
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void
      preCreate(curam.attachmentlink.impl.AttachmentLink attachmentLink)
        throws AppException, InformationalException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked after the main body of the creation method. To
     * influence the behavior of the insert method this can throw an
     * AppException.
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be created
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void
      postCreate(curam.attachmentlink.impl.AttachmentLink attachmentLink)
        throws AppException, InformationalException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked before the main body of the modify method. To
     * influence the behavior of the modify method this can modify the
     * parameter, add a validation failure or throw an AppException.
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be modified
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void
      preModify(curam.attachmentlink.impl.AttachmentLink attachmentLink)
        throws AppException, InformationalException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked after the main body of the modify method. To
     * influence the behavior of the modify method this can throw an
     * AppException.
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be modified
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void
      postModify(curam.attachmentlink.impl.AttachmentLink attachmentLink)
        throws AppException, InformationalException;

  }

  // BEGIN, CR00141221, PF
  /**
   * Interface to the AttachmentLink events functionality surrounding the
   * insertion of an AttachmentLink.
   */
  interface AttachmentLinkInsertionEvents {

    // ___________________________________________________________________________
    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain AttachmentLink#insert}
     *
     * @param attachmentLink
     * Details of the attachmentLink to be created
     * @param attachmentLinkDetails
     * holds details of attachment to be created.
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void preInsert(AttachmentLinkAccessor attachmentLink,
      AttachmentLinkDetails attachmentLinkDetails)
      throws InformationalException, AppException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain AttachmentLink#insert}
     *
     * @param attachmentLink
     * Details of the attachment created
     * @param attachmentLinkDetails
     * holds details of attachment created.
     * @param returnValue
     * the id of the new Attachment
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void postInsert(AttachmentLinkAccessor attachmentLink,
      AttachmentLinkDetails attachmentLinkDetails, long returnValue)
      throws InformationalException, AppException;

  }

  /**
   * Interface to the AttachmentLink events functionality surrounding the
   * cancellation of an AttachmentLink.
   */
  interface AttachmentLinkCancelationEvents {

    // ___________________________________________________________________________
    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain AttachmentLink#cancel}
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be cancelled
     * @param versionNo
     * the version number as held by the client code.
     * @throws InformationalException
     */
    public void preCancel(AttachmentLinkAccessor attachmentLink,
      int versionNo) throws InformationalException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain AttachmentLink#cancel}
     *
     * @param attachmentLink
     * Details of the cancelled AttachmentLink
     * @param versionNo
     * the version number as held by the client code.
     * @throws InformationalException
     */
    public void postCancel(AttachmentLinkAccessor attachmentLink,
      int versionNo) throws InformationalException;

  }

  /**
   * Interface to the AttachmentLink events functionality surrounding the
   * modification of an AttachmentLink.
   */
  interface AttachmentLinkModificationEvents {

    // ___________________________________________________________________________
    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain AttachmentLink#modify}
     *
     * @param attachmentLink
     * Details of the AttachmentLink to be modified
     * @param attachmentLinkDetails
     * holds details of attachment to be modified.
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void preModify(AttachmentLinkAccessor attachmentLink,
      AttachmentLinkDetails attachmentLinkDetails)
      throws InformationalException, AppException;

    // ___________________________________________________________________________
    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain AttachmentLink#modify}
     *
     * @param attachmentLink
     * Details of the AttachmentLink modified
     * @param attachmentLinkDetails
     * holds details of attachment modified.
     * @throws AppException
     * If thrown, the transaction will be rolled back
     * @throws InformationalException
     */
    public void postModify(AttachmentLinkAccessor attachmentLink,
      AttachmentLinkDetails attachmentLinkDetails)
      throws InformationalException, AppException;
  }

  // END, CR00141221

  // ___________________________________________________________________________
  /**
   * Creates a new Attachment and Attachment link record. The user of this API
   * needs to pass in a related Object Id (of the object you are associating the
   * attachment to) and the related Object Type (populated in the
   * AttachmentObjectLinkType codetable) along with mandatory data in
   * 'attachmentDtls'.
   *
   * @param attachmentLinkDetails
   * holds details of attachment to be created.
   * @return long - return the id of the new Attachment
   * @throws InformationalException
   * @throws AppException
   */
  public long insert(AttachmentLinkDetails attachmentLinkDetails)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Creates a new Attachment link record to an existing Attachment record.
   * The user of this API needs to pass in a related Object Id (of the object you
   * are associating the attachment to) and the related Object Type (populated in
   * the AttachmentObjectLinkType codetable) along with an existing attachment id
   * in 'attachmentDtls'.
   *
   * @param attachmentLinkDetails
   * holds details of attachment to be created.
   * @return long - return the id of the new Attachment
   * @throws InformationalException
   * @throws AppException
   */
  public long
    insertAttachmentLink(AttachmentLinkDetails attachmentLinkDetails)
      throws AppException, InformationalException;

  /**
   * Cancels an AttachmentLink record, without canceling the corresponding
   * Attachment record. This may be used in situations where the Attachment record
   * is reused by containing links to other entities, in addition to the link
   * being cancelled, and so the corresponding Attachment should remain active.
   *
   * @param versionNo
   * @throws AppException
   * @throws InformationalException
   */
  public void cancelAttachmentLink(int versionNo)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Modifies an Attachment link record and the underlying Attachment.
   *
   * @param attachmentLinkDetails
   * holds details of attachment to be modified.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void modify(AttachmentLinkDetails attachmentLinkDetails)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the attachmentID for the Attachment link.
   *
   * @param value
   * unique identifier to the Attachment.
   */
  public void setAttachmentID(final long value);

  // ___________________________________________________________________________
  /**
   * Sets the participantroleID of a related participant.
   *
   * @param value
   * unique identifier to the ConcernRole.
   */
  public void setParticipantRoleID(final long value);

  // ___________________________________________________________________________
  /**
   * Sets the relatedObjectID for the Attachment link.
   *
   * @param value
   * unique identifier for the related Object.
   */
  public void setRelatedObjectID(final long value);

  // ___________________________________________________________________________
  /**
   * Sets the relatedObjectID for the Attachment link.
   *
   * @param value
   * unique identifier for the related Object.
   */
  public void setRelatedObjectType(final ATTACHMENTOBJECTLINKTYPEEntry value);

  // ___________________________________________________________________________
  /**
   * Sets the free text description for the Attachment to be recorded on the
   * Attachment Link.
   *
   * @param value
   * string value holding the description of the attachment.
   */
  public void setDescription(final String value);

  // ___________________________________________________________________________
  /**
   * Sets the sensitivity code table value for the Attachment to be recorded on
   * the Attachment Link.
   *
   * @param value
   * codetable code holding the sensitivity of the attachment.
   */
  public void setSensitivity(final SENSITIVITYEntry value);

  // ___________________________________________________________________________
  /**
   * Checks to see if the current user has the appropriate sensitivity to access
   * this Attachment.
   *
   * @throws InformationalException
   * if the users sensitivity is less that that for the attachment
   */
  public void checkSensitivity() throws InformationalException;

}
