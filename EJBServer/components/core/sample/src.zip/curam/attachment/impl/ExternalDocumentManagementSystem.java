/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachment.impl;


import com.google.inject.ImplementedBy;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * An interface which manages the External document management system
 * attachments .
 */

@ImplementedBy(ExternalDocumentManagementSystemImpl.class)
public interface ExternalDocumentManagementSystem {

  /**
   * Adds the attachment details to the External Document Management System
   *
   * @param dtls an instance of attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  void insert(AttachmentDtls dtls) throws AppException,
      InformationalException;

  /**
   * Updates the attachment details in the External Document Management System
   *
   * @param attachmentKey an instance of the attachment key
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  void modify(AttachmentDtls dtls) throws AppException,
      InformationalException;

  /**
   * Returns the attachment details from the External Document Management System
   *
   * @param attachmentKey an instance of the attachment key
   *
   * @return an instance of attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  AttachmentDtls read(AttachmentKey attachmentKey) throws AppException,
      InformationalException;

  /**
   * Returns the attachment details from the External Document Management System
   * This method can be used to
   *
   * @param attachmentKey an instance of the attachment key
   *
   * @param forUpdate boolean to represent whether optimistic locking on the
   * attachment record is required or not
   *
   * @return an instance of the attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   */
  AttachmentDtls read(AttachmentKey attachmentKey, boolean forUpdate)
    throws AppException, InformationalException;

  /**
   * Logically deletes the attachment in the External Document Management System
   *
   * @param attachmentKey an instance of the Attachment key
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  void cancel(AttachmentKey attachmentKey) throws AppException,
      InformationalException;

}
