/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009,2019. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.attachment.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachmentlink.fact.AttachmentLinkFactory;
import curam.attachmentlink.intf.AttachmentLink;
import curam.attachmentlink.struct.AttachmentLinkDtls;
import curam.attachmentlink.struct.AttachmentLinkDtlsList;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.CONTACTLOGTYPE;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.ATTACHMENTSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.ContactLogFactory;
import curam.core.sl.entity.fact.ContactLogLinkFactory;
import curam.core.sl.entity.intf.ContactLog;
import curam.core.sl.entity.intf.ContactLogLink;
import curam.core.sl.entity.struct.ContactLogDtls;
import curam.core.sl.entity.struct.ContactLogIDRecordStatusKey;
import curam.core.sl.entity.struct.ContactLogKey;
import curam.core.sl.entity.struct.LinkIDAndLinkTypeDtlsList;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentHeaderDetails;
import curam.core.struct.AttachmentKey;
import curam.core.struct.AttachmentNameStruct;
import curam.message.BPOATTACHMENT;
import curam.message.BPOCASEEVENTS;
import curam.message.impl.BPOATTACHMENTExceptionCreator;
import curam.message.impl.BPOATTACHMENTLINKExceptionCreator;
import curam.message.impl.GENERALExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Blob;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import java.io.File;

/**
 * Attachment default Implementation.
 *
 * For public method JavaDoc
 *
 * @see curam.attachment.impl.Attachment
 */
// BEGIN, CR00183334, PS
public class AttachmentImpl implements Attachment {

  // END, CR00183334
  @Inject
  protected ExternalDocumentManagementSystem documentManagementSystem;

  // BEGIN, CR00234804, PM
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END, CR00234804

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected AttachmentImpl() {// no-arg constructor for use only by Guice.

  }

  // END, CR00183334

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void insert(final AttachmentDtls details)
    throws AppException, InformationalException {

    final AttachmentDtls externalAttachmentDetails = new AttachmentDtls();

    externalAttachmentDetails.assign(details);
    boolean externalDocSystem = false;

    final String externalValue =
      Configuration.getProperty(EnvVars.ENV_EXTERNAL_DOCUMENT_SYSTEM_ENABLED);

    externalDocSystem = Boolean.parseBoolean(externalValue);

    if (details.receiptDate.after(Date.getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTExceptionCreator
            .ERR_ATTACHMENT_FV_RECEIPTDATE_LATER_THAN_TODAY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    ValidationHelper.failIfErrorsExist();

    final curam.core.intf.Attachment attachmentObj =
      curam.core.fact.AttachmentFactory.newInstance();

    if (details.attachmentName.length() != 0) {
      details.attachmentName = parseAttachmentName(details);
    }
    crossFieldAttachmentCreationValidation(details);

    // BEGIN, CR00154599, MC
    if (details.attachmentID == 0) {
      final curam.core.intf.UniqueID uniqueIDObj =
        curam.core.fact.UniqueIDFactory.newInstance();

      details.attachmentID = uniqueIDObj.getNextID();
    }
    // END, CR00154599

    details.attachmentStatus = ATTACHMENTSTATUSEntry.ACTIVE.getCode();
    details.statusCode = RECORDSTATUSEntry.NORMAL.getCode();

    if (externalDocSystem) {
      details.attachmentContents = new Blob(CuramConst.gkEmpty.getBytes());
      documentManagementSystem.insert(externalAttachmentDetails);
      attachmentObj.insert(details);
      setExternalDetailsToAttachmentLink(details, externalAttachmentDetails);

    } else {
      attachmentObj.insert(details);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final AttachmentKey attachmentKey,
    final AttachmentDtls details)
    throws AppException, InformationalException {

    final curam.core.intf.Attachment attachmentObj =
      curam.core.fact.AttachmentFactory.newInstance();

    crossFieldAttachmentModificationValidation(details);
    final AttachmentLink attachmentLink = AttachmentLinkFactory.newInstance();

    boolean externalDocSystem = false;

    final String externalValue =
      Configuration.getProperty(EnvVars.ENV_EXTERNAL_DOCUMENT_SYSTEM_ENABLED);

    externalDocSystem = Boolean.parseBoolean(externalValue);

    // BEGIN, CR00150184,MC
    if (details.attachmentName.length() != 0) {
      details.attachmentName = parseAttachmentName(details);
    }

    attachmentKey.attachmentID = details.attachmentID;
    final AttachmentDtls attachmentDtls =
      attachmentObj.read(attachmentKey, true);
    attachmentKey.attachmentID = details.attachmentID;
    attachmentDtls.attachmentName = details.attachmentName;

    attachmentDtls.attachmentContents = details.attachmentContents;
    // BEGIN, CR00150148, MC
    attachmentDtls.fileLocation = details.fileLocation;
    attachmentDtls.fileReference = details.fileReference;
    // END, CR00150148

    attachmentDtls.receiptDate = details.receiptDate;

    attachmentDtls.documentType = details.documentType;
    // END, CR00150184
    // BEGIN, CR00279099, PB
    attachmentDtls.versionNo = details.versionNo;
    // END, CR00279099
    attachmentDtls.attachmentStatus = details.attachmentStatus;
    Blob externalAttachmentContent = null;

    if (externalDocSystem) {
      externalAttachmentContent = attachmentDtls.attachmentContents;
      attachmentDtls.attachmentContents =
        new Blob(CuramConst.gkEmpty.getBytes());
      final AttachmentKey externalAttachmentKey = new AttachmentKey();
      final AttachmentLinkDtlsList attachmentLinkDtlsList =
        attachmentLink.searchByAttachmentID(attachmentKey);

      for (int i = 0; i < attachmentLinkDtlsList.dtls.size(); i++) {
        final AttachmentLinkDtls linkDtls =
          attachmentLinkDtlsList.dtls.get(i);

        if (linkDtls.relatedObjectType
          .equals(ATTACHMENTOBJECTLINKTYPEEntry.EXTERNALDOCUMENT.getCode())) {
          externalAttachmentKey.attachmentID = linkDtls.relatedObjectID;
          break;
        }
      }
      final boolean forUpdate = true;
      final AttachmentDtls externalDetails =
        documentManagementSystem.read(externalAttachmentKey, forUpdate);

      externalDetails.assign(attachmentDtls);
      externalDetails.attachmentContents =
        externalAttachmentContent.length() > 0 ? externalAttachmentContent
          : externalDetails.attachmentContents;

      documentManagementSystem.modify(externalDetails);
      attachmentObj.modify(attachmentKey, attachmentDtls);

    } else {
      attachmentObj.modify(attachmentKey, attachmentDtls);
    }

    // BEGIN, CR00241171, ZV
    // BEGIN, CR00234804, PM
    // Log Transaction Details.
    final AttachmentLinkDtlsList attachmentLinkDtlsList =
      attachmentLink.searchByAttachmentID(attachmentKey);
    final ContactLogIDRecordStatusKey contactLogIDRecordStatusKey =
      new ContactLogIDRecordStatusKey();
    long attachementLinkID = 0;

    for (final AttachmentLinkDtls attachmentLinkDtls : attachmentLinkDtlsList.dtls
      .items()) {
      final AttachmentLinkDtls linkDtls = attachmentLinkDtls;

      if (linkDtls.relatedObjectType
        .equals(ATTACHMENTOBJECTLINKTYPEEntry.CONTACTLOG.getCode())) {

        final ContactLogLink contactLogLinkObj =
          ContactLogLinkFactory.newInstance();

        contactLogIDRecordStatusKey.contactLogID = linkDtls.relatedObjectID;
        attachementLinkID = linkDtls.attachmentLinkID;

        final LinkIDAndLinkTypeDtlsList linkIDAndLinkTypeDtlsList =
          contactLogLinkObj.searchActiveLinkIDAndTypeByContactLogID(
            contactLogIDRecordStatusKey);

        for (int i = 0; i < linkIDAndLinkTypeDtlsList.dtls.size(); i++) {

          if (linkIDAndLinkTypeDtlsList.dtls.item(i).linkType
            .equals(CONTACTLOGLINKTYPE.CASE)) {

            final ContactLog contactLog = ContactLogFactory.newInstance();
            final ContactLogKey contactLogKey = new ContactLogKey();

            contactLogKey.contactLogID = linkDtls.relatedObjectID;
            final ContactLogDtls contactLogDtls =
              contactLog.read(contactLogKey);

            final CodeTableItemIdentifier codeTableItemIdentifier =
              new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME,
                contactLogDtls.contactLogType);

            final LocalisableString description =
              new LocalisableString(BPOCASEEVENTS.CONTACT_ATTACHMENT_MODIFIED)
                .arg(codeTableItemIdentifier);

            caseTransactionLogProvider.get().recordCaseTransaction(
              CASETRANSACTIONEVENTS.CONTACT_ATTACHMENT_MODIFIED, description,
              linkIDAndLinkTypeDtlsList.dtls.item(i).linkID,
              attachementLinkID);

          }
        }

      }
    }
    // END, CR00234804
    // END, CR00241171

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  // BEGIN, CR00409050, SG
  @AccessLevel(AccessLevelType.EXTERNAL)
  // END, CR00409050
  public AttachmentDtls read(final AttachmentKey key)
    throws AppException, InformationalException {

    final curam.core.intf.Attachment attachmentObj =
      curam.core.fact.AttachmentFactory.newInstance();
    final AttachmentLink attachmentLink = AttachmentLinkFactory.newInstance();

    boolean externalDocSystem = false;

    final String externalValue =
      Configuration.getProperty(EnvVars.ENV_EXTERNAL_DOCUMENT_SYSTEM_ENABLED);

    externalDocSystem = Boolean.parseBoolean(externalValue);
    // if external enabled, check if External document system is enabled
    // and call the new interface
    if (externalDocSystem) {
      final AttachmentKey externalAttachmentKey = new AttachmentKey();
      final AttachmentLinkDtlsList attachmentLinkDtlsList =
        attachmentLink.searchByAttachmentID(key);

      for (int i = 0; i < attachmentLinkDtlsList.dtls.size(); i++) {
        final AttachmentLinkDtls linkDtls =
          attachmentLinkDtlsList.dtls.get(i);

        if (linkDtls.relatedObjectType
          .equals(ATTACHMENTOBJECTLINKTYPEEntry.EXTERNALDOCUMENT.getCode())) {
          externalAttachmentKey.attachmentID = linkDtls.relatedObjectID;
          break;
        }
      }

      final AttachmentDtls attachmentDtls = attachmentObj.read(key);

      attachmentDtls.attachmentContents = documentManagementSystem
        .read(externalAttachmentKey).attachmentContents;
      return attachmentDtls;
    } else {
      return attachmentObj.read(key);
    }

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AttachmentDtls read(final AttachmentKey key, final boolean forUpdate)
    throws AppException, InformationalException {

    final curam.core.intf.Attachment attachmentObj =
      curam.core.fact.AttachmentFactory.newInstance();
    final AttachmentLink attachmentLink = AttachmentLinkFactory.newInstance();

    boolean externalDocSystem = false;

    final String externalValue =
      Configuration.getProperty(EnvVars.ENV_EXTERNAL_DOCUMENT_SYSTEM_ENABLED);

    externalDocSystem = Boolean.parseBoolean(externalValue);
    // if external enabled, check of link of type ExDMS and call the new
    // interface
    if (externalDocSystem) {
      final AttachmentKey externalAttachmentKey = new AttachmentKey();
      final AttachmentLinkDtlsList attachmentLinkDtlsList =
        attachmentLink.searchByAttachmentID(key);

      for (int i = 0; i < attachmentLinkDtlsList.dtls.size(); i++) {
        final AttachmentLinkDtls linkDtls =
          attachmentLinkDtlsList.dtls.get(i);

        if (linkDtls.relatedObjectType
          .equals(ATTACHMENTOBJECTLINKTYPEEntry.EXTERNALDOCUMENT.getCode())) {
          externalAttachmentKey.attachmentID = linkDtls.relatedObjectID;
          break;
        }
      }

      final AttachmentDtls attachmentDtls =
        attachmentObj.read(key, forUpdate);

      attachmentDtls.attachmentContents = documentManagementSystem
        .read(externalAttachmentKey).attachmentContents;
      return attachmentDtls;
    } else {
      return attachmentObj.read(key, forUpdate);
    }

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final AttachmentKey attachmentKey)
    throws InformationalException {

    final curam.core.intf.Attachment attachmentObj =
      curam.core.fact.AttachmentFactory.newInstance();
    final AttachmentLink attachmentLink = AttachmentLinkFactory.newInstance();

    boolean externalDocSystem = false;

    final String externalValue =
      Configuration.getProperty(EnvVars.ENV_EXTERNAL_DOCUMENT_SYSTEM_ENABLED);

    externalDocSystem = Boolean.parseBoolean(externalValue);

    try {
      if (externalDocSystem) {
        final AttachmentKey externalAttachmentKey = new AttachmentKey();
        final AttachmentLinkDtlsList attachmentLinkDtlsList =
          attachmentLink.searchByAttachmentID(attachmentKey);

        for (int i = 0; i < attachmentLinkDtlsList.dtls.size(); i++) {
          final AttachmentLinkDtls linkDtls =
            attachmentLinkDtlsList.dtls.get(i);

          if (linkDtls.relatedObjectType.equals(
            ATTACHMENTOBJECTLINKTYPEEntry.EXTERNALDOCUMENT.getCode())) {
            externalAttachmentKey.attachmentID = linkDtls.relatedObjectID;
            break;
          }
        }
        documentManagementSystem.cancel(externalAttachmentKey);
      }

      final AttachmentHeaderDetails attachmentDtls =
        attachmentObj.readHeader(attachmentKey);

      attachmentDtls.attachmentStatus =
        ATTACHMENTSTATUSEntry.REMOVED.getCode();
      attachmentDtls.statusCode = RECORDSTATUSEntry.CANCELLED.getCode();
      attachmentObj.modifyStatus(attachmentKey, attachmentDtls);
    } catch (final AppException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTLINKExceptionCreator.ERR_ATTACHMENT_CANCEL_FAILED(
            e.getMessage(TransactionInfo.getProgramLocale())),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    ValidationHelper.failIfErrorsExist();

  }

  // ___________________________________________________________________________
  /**
   * Parses an attachment name taking it in from the full name, including path.
   *
   * @param attachmenDetails an instance of attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected String parseAttachmentName(final AttachmentDtls attachmenDetails)
    throws AppException, InformationalException {

    final AttachmentNameStruct attachmentNameStruct =
      new AttachmentNameStruct();

    attachmentNameStruct.attachmentName = attachmenDetails.attachmentName;

    File attachmentName;

    attachmentName = new File(attachmentNameStruct.attachmentName);

    if (attachmentName.exists()) {
      attachmentNameStruct.attachmentName = attachmentName.getName();

    } else {

      // if this isn't a valid file path (the 'new File' statement above
      // validates against 'this' machine that the server runs
      // (an unlikely production scenario), so in order that the file and
      // path be stripped down to just the file name we do the following.
      final int lastPathSeparator =
        attachmenDetails.attachmentName.lastIndexOf("\\") + 1;

      final StringBuffer parsedFileName = new StringBuffer();

      for (int i = lastPathSeparator; i < attachmenDetails.attachmentName
        .length(); i++) {

        parsedFileName.append(attachmenDetails.attachmentName.charAt(i));

      }
      attachmentNameStruct.attachmentName = parsedFileName.toString();
    }

    return attachmentNameStruct.attachmentName;
  }

  // ___________________________________________________________________________
  /**
   * Validates across attachment entity attributes on creation.
   *
   * @param attachmentDetails an instance of the attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected void crossFieldAttachmentCreationValidation(
    final AttachmentDtls attachmentDetails)
    throws AppException, InformationalException {

    crossFieldAttachmentValidation(attachmentDetails);

    if (StringHelper.isEmpty(attachmentDetails.attachmentName)
      && (StringHelper.isEmpty(attachmentDetails.fileLocation)
        || StringHelper.isEmpty(attachmentDetails.fileReference))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTLINKExceptionCreator
            .ERR_ATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    ValidationHelper.failIfErrorsExist();
  }

  // ___________________________________________________________________________
  /**
   * Validates across attachment entity attributes.
   *
   * @param attachmentDetails an instance of the attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * {@link curam.message.impl.BPOATTACHMENTExceptionCreator#ERR_
   * ATTACHMENT_FV_RECEIPTDATE_LATER_THAN_TODAY()} -
   * If the attachment receipt date is later than today.
   * @throws AppException Generic Exception Signature.
   */
  protected void
    crossFieldAttachmentValidation(final AttachmentDtls attachmentDetails)
      throws AppException, InformationalException {

    // BEGIN, CR00160810, SS
    // If the attachment receipt date is later than today, then throw an error.
    if (attachmentDetails.receiptDate.after(Date.getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTExceptionCreator
            .ERR_ATTACHMENT_FV_RECEIPTDATE_LATER_THAN_TODAY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END, CR00160810

    if (!StringHelper.isEmpty(attachmentDetails.attachmentName)
      && (!StringHelper.isEmpty(attachmentDetails.fileLocation)
        || !StringHelper.isEmpty(attachmentDetails.fileReference))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          BPOATTACHMENTExceptionCreator
            .ERR_ATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // If the status code is CANCELLED then throw an error
    if (attachmentDetails.statusCode
      .equals(curam.codetable.RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addValidationHelperExceptionWithLookup(
          GENERALExceptionCreator.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    ValidationHelper.failIfErrorsExist();
  }

  // ___________________________________________________________________________
  /**
   * Validates across attachment entity attributes on modification.
   *
   * @param attachmentDetails an instance of the attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected void crossFieldAttachmentModificationValidation(
    final AttachmentDtls attachmentDetails)
    throws AppException, InformationalException {

    final curam.core.intf.Attachment attachmentObj =
      curam.core.fact.AttachmentFactory.newInstance();
    final AttachmentKey attachmentKey = new AttachmentKey();

    crossFieldAttachmentValidation(attachmentDetails);

    if (StringHelper.isEmpty(attachmentDetails.attachmentName)) {

      attachmentKey.attachmentID = attachmentDetails.attachmentID;
      // BEGIN, CR00295922, CD
      final AttachmentHeaderDetails attachmentHeaderDtls =
        attachmentObj.readHeader(attachmentKey);

      final boolean atachmentNameProvided =
        0 != attachmentDetails.attachmentName.length()
          || 0 != attachmentHeaderDtls.attachmentName.length();

      final boolean locationANDReferenceProvided =
        0 != attachmentDetails.fileLocation.length()
          && 0 != attachmentDetails.fileReference.length();

      final boolean locationORReferenceProvided =
        0 != attachmentDetails.fileLocation.length()
          || 0 != attachmentDetails.fileReference.length();

      if (StringHelper.isEmpty(attachmentHeaderDtls.attachmentName)
        && StringHelper.isEmpty(attachmentDetails.attachmentName)
        && (StringHelper.isEmpty(attachmentDetails.fileLocation)
          || StringHelper.isEmpty(attachmentDetails.fileReference))) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addValidationHelperExceptionWithLookup(
            BPOATTACHMENTExceptionCreator
              .ERR_ATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      }
      // END, CR00295922

      if (atachmentNameProvided
        && (locationANDReferenceProvided || locationORReferenceProvided)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addValidationHelperExceptionWithLookup(
            BPOATTACHMENTExceptionCreator
              .ERR_ATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }

    ValidationHelper.failIfErrorsExist();
  }

  /**
   * This method updates the attachment link entity with external attachment
   * details.
   *
   * @param attachmentDtls and externalAttachmentDtls
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  protected void setExternalDetailsToAttachmentLink(
    final AttachmentDtls attachmentDtls,
    final AttachmentDtls externalAttachmentDtls)
    throws AppException, InformationalException {

    final AttachmentLink attachmentLink = AttachmentLinkFactory.newInstance();
    final AttachmentLinkDtls attachmentLinkDtls = new AttachmentLinkDtls();

    attachmentLinkDtls.attachmentID = attachmentDtls.attachmentID;
    attachmentLinkDtls.relatedObjectID = externalAttachmentDtls.attachmentID;
    attachmentLinkDtls.relatedObjectType =
      ATTACHMENTOBJECTLINKTYPEEntry.EXTERNALDOCUMENT.getCode();
    // BEGIN, CR00150184, MC
    attachmentLinkDtls.description =
      BPOATTACHMENT.INF_EXTERNAL_DOCUMENT.getEntry();
    // END, CR00150184
    attachmentLinkDtls.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();
    attachmentLinkDtls.sensitivityCode = SENSITIVITYEntry.MINIMUM.getCode();
    attachmentLinkDtls.creatorUserName = TransactionInfo.getProgramUser();
    attachmentLink.insert(attachmentLinkDtls);

  }

}
