/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachment.impl;


import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.message.impl.BPOEXTDOCUMENTMANAGEMENTSYSTEMExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;


/**
 * ExternalDocumentManagementSystem default Implementation.
 *
 * For public method JavaDoc
 *
 * @see curam.attachment.impl.ExternalDocumentManagementSystem
 */
public class ExternalDocumentManagementSystemImpl implements
  ExternalDocumentManagementSystem {

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected ExternalDocumentManagementSystemImpl() {// no-arg constructor for
    // use only by Guice
  }

  // END, CR00183334

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(AttachmentKey attachmentKey) throws AppException,
      InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
      BPOEXTDOCUMENTMANAGEMENTSYSTEMExceptionCreator.ERR_EXT_DOCUMENT_SYSTEM_NOT_CONFIGURED(),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    ValidationHelper.failIfErrorsExist();

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void insert(AttachmentDtls dtls) throws AppException,
      InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
      BPOEXTDOCUMENTMANAGEMENTSYSTEMExceptionCreator.ERR_EXT_DOCUMENT_SYSTEM_NOT_CONFIGURED(),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    ValidationHelper.failIfErrorsExist();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(AttachmentDtls dtls) throws AppException,
      InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
      BPOEXTDOCUMENTMANAGEMENTSYSTEMExceptionCreator.ERR_EXT_DOCUMENT_SYSTEM_NOT_CONFIGURED(),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    ValidationHelper.failIfErrorsExist();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AttachmentDtls read(AttachmentKey attachmentKey)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
      BPOEXTDOCUMENTMANAGEMENTSYSTEMExceptionCreator.ERR_EXT_DOCUMENT_SYSTEM_NOT_CONFIGURED(),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    ValidationHelper.failIfErrorsExist();
    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AttachmentDtls read(AttachmentKey attachmentKey, boolean forUpdate)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
      BPOEXTDOCUMENTMANAGEMENTSYSTEMExceptionCreator.ERR_EXT_DOCUMENT_SYSTEM_NOT_CONFIGURED(),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);
    ValidationHelper.failIfErrorsExist();
    return null;
  }

}
