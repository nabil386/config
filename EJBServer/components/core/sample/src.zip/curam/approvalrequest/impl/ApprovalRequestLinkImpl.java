/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;


import com.google.inject.Inject;
import curam.approvalrequest.entity.struct.ApprovalRequestLinkDtls;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.APPROVALREQUESTSTATUSEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Implementation for ApprovalRequest and ApprovalRequestAccessor.
 */
// BEGIN, CR00183334, PS
public class ApprovalRequestLinkImpl extends SingleTableEntityImpl<ApprovalRequestLinkDtls> implements
  ApprovalRequestLink {

  @Inject
  protected ApprovalRequestDAO approvalRequestDAO;

  /*
   * no-arg constructor for use only by Guice.
   */
  protected ApprovalRequestLinkImpl() {// no-arg constructor for use only by
    // Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// no implementation
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// no implementation
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// no implementation
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void approve() throws InformationalException {

    getDtls().recordStatus = APPROVALREQUESTSTATUSEntry.APPROVED.getCode();
    modify();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public long getApprovalRequestID() {

    return getDtls().approvalRequestID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public APPROVALREQUESTSTATUSEntry getStatus() {

    return APPROVALREQUESTSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public void createApprovalRequestLink(final long approvalRequestID,
    final long relatedID, final APPROVALRELATEDTYPEEntry relatedType)
    throws InformationalException {

    createApprovalRequestLink(approvalRequestDAO.get(approvalRequestID),
      relatedID, relatedType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void createApprovalRequestLink(ApprovalRequest approvalRequest,
    long relatedID, APPROVALRELATEDTYPEEntry relatedType)
    throws InformationalException {

    getDtls().approvalRequestID = approvalRequest.getID();
    getDtls().relatedID = relatedID;
    getDtls().relatedType = relatedType.getCode();

    insert();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {

    getDtls().recordStatus = APPROVALREQUESTSTATUSEntry.SUBMITTED.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public APPROVALREQUESTSTATUSEntry getLifecycleState() {

    return APPROVALREQUESTSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void reject() throws InformationalException {

    getDtls().recordStatus = APPROVALREQUESTSTATUSEntry.REJECTED.getCode();
    modify();
  }

}
