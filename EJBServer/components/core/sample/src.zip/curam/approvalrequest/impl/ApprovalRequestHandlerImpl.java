/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2010, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.approvalrequest.impl;


import com.google.inject.Inject;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKPRIORITY;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.core.facade.struct.ApproveRejectStandardTaskDetails;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.NotificationFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Notification;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.TaskManagementUtilityFactory;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.intf.TaskManagementUtility;
import curam.core.sl.struct.DateTimeInSecondsKey;
import curam.core.sl.struct.WorkQueueIDKey;
import curam.core.sl.struct.WorkQueueName;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseReference;
import curam.core.struct.UserNameKey;
import curam.events.APPROVALREQUEST;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.impl.ClientURI;
import curam.piwrapper.organization.impl.WorkQueue;
import curam.piwrapper.organization.impl.WorkQueueDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.util.events.impl.EventService;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.workflow.impl.EnactmentService;
import curam.validationmanager.sl.fact.ValidationConfigurationAdminFactory;
import curam.validationmanager.sl.struct.ValidationConfigurationKey;
import java.util.ArrayList;
import java.util.List;


/**
 * Implementation of the {@link ApprovalRequestHandler} interface.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
public abstract class ApprovalRequestHandlerImpl implements
  ApprovalRequestHandler {

  @Inject
  protected UserDAO userDAO;

  @Inject
  protected WorkQueueDAO workQueueDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  public void postApprove(final long relatedID) throws InformationalException {

    createNotification(relatedID, getApprovalNotificationMessage());
    closeTask(relatedID);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void postReject(final long relatedID) throws InformationalException {

    createNotification(relatedID, getRejectionNotificationMessage());
    closeTask(relatedID);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void postSubmit(final User submittedByUser, final long relatedID)
    throws InformationalException {

    // BEGIN, CR00399517, MV
    // Get the supervisor of the case.
    // END, CR00399517
    final User supervisor = getSupervisor(submittedByUser, relatedID);

    // BEGIN, CR00276006, POH
    // create and assign the approval task
    createTask(relatedID, getUserAssignTaskTo(supervisor),
      getAssignTaskType(supervisor));

    // if no supervisor exists create the no supervisor exists task
    if (null == supervisor) {
      enactNoSupervisorForApprovalTask(getCaseHeader(relatedID));
      notifyDefaultWorkQueueAdministratorAndSubscribers(
        getCaseHeader(relatedID));
    }
    // END, CR00276006, POH

  }

  // BEGIN, CR00276006, POH
  /**
   * Sends notification to the administrator and subscribers of the default work
   * queue.
   *
   * @param caseHeader
   * the case the approval request is in relation to that has no
   * supervisor assigned to and in addition whose owner does not have a
   * supervisor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  void notifyDefaultWorkQueueAdministratorAndSubscribers(
    final CaseHeader caseHeader) throws InformationalException {

    // Send notification to administrator and subscribers of the work queue.
    final List<Object> notificationEnactmentDataList = new ArrayList<Object>();

    /*
     * Passing Case Reference as enactment attribute. Case Reference is required
     * to display in Notification message.
     */
    notificationEnactmentDataList.add(getCaseReference(caseHeader));

    /*
     * Passing Work Queue ID as enactment attribute. Work Queue ID is required
     * to get the list of subscribers and the administrator of the work queue.
     */
    notificationEnactmentDataList.add(getWorkQueueIDKeyForDefaultWorkQueue());

    /*
     * Passing Work Queue Name as enactment attribute. Work Queue Name is
     * required to display in Notification message.
     */
    final WorkQueueName workQueueName = new WorkQueueName();

    workQueueName.workQueueName = getDefaultWorkQueue().getName();
    notificationEnactmentDataList.add(workQueueName);

    enactProcessDefinition(notificationEnactmentDataList,
      TaskDefinitionIDConst.noSupervisorForCaseTaskNotificationDefinitionID);
  }

  /**
   * Enacts the passed in process definition.
   *
   * @param enactmentDataList
   * list containing the data required by the process that is to be
   * enacted
   * @param processDefinitionName
   * The name of the process to be enacted
   * @throws InformationalException
   * Generic Exception Signature
   */
  void enactProcessDefinition(
    final List<? extends java.lang.Object> enactmentDataList,
    final String processDefinitionName) throws InformationalException {

    try {
      EnactmentService.startProcessInV3CompatibilityMode(processDefinitionName,
        enactmentDataList);
    } catch (final AppException e) {
      throw new AppRuntimeException(e);
    }
  }

  /**
   * Enacts the no supervisor for approval task. Task is invoked when no
   * supervisor can be located to assign the approve/reject task
   *
   * @param caseHeader
   * the case the details of the task are to be retrieved from
   * @throws InformationalException
   * Generic Exception Signature
   */
  void enactNoSupervisorForApprovalTask(final CaseHeader caseHeader)
    throws InformationalException {

    // Assign a task to the default work queue.
    final List<Object> taskEnactmentDataList = new ArrayList<Object>();

    /*
     * Passing Case ID as enactment attribute. Case ID is used to construct the
     * business process object and this object is used create the link between
     * case ID and task ID
     */
    final CaseHeaderKey key = new CaseHeaderKey();

    key.caseID = caseHeader.getID();
    taskEnactmentDataList.add(key);

    /*
     * Passing Case Reference as enactment attribute. Case Reference is required
     * to display in Task message.
     */
    taskEnactmentDataList.add(getCaseReference(caseHeader));

    /*
     * Passing Work Queue ID as enactment attribute. Work Queue ID is required
     * to assign the Task to this work queue.
     */
    taskEnactmentDataList.add(getWorkQueueIDKeyForDefaultWorkQueue());

    enactProcessDefinition(taskEnactmentDataList,
      TaskDefinitionIDConst.noSupervisorForCaseApprovalTaskDefinitionID);

  }

  /**
   * Retrieves an instance of {@link WorkQueueIDKey} populated with the
   * identifier of the default {@link WorkQueue}.
   *
   * @return an instance of the work queue identifier key populated with the
   * identifier of the default work queue
   */
  WorkQueueIDKey getWorkQueueIDKeyForDefaultWorkQueue() {

    final WorkQueueIDKey workQueueIDKey = new WorkQueueIDKey();

    workQueueIDKey.workQueueID = getDefaultWorkQueue().getID();
    return workQueueIDKey;
  }

  /**
   * Retrieves an instance of a {@link CaseReference} populated with the case
   * reference details of the passed in {@link CaseHeader}.
   *
   * @param caseHeader
   * the case header to retrieve the case reference details from
   * @return an instance of the case reference object populated with the case
   * reference details of the passed in case header
   */
  CaseReference getCaseReference(final CaseHeader caseHeader) {

    final CaseReference caseRef = new CaseReference();

    caseRef.caseReference = caseHeader.getCaseReference();
    return caseRef;
  }

  /**
   * Retrieves the target of the approve/reject task that is to be created. If
   * no supervisor could be located that has permission to approve or reject the
   * related case the task is to be assign to the default work queue, and hence
   * {@link TARGETITEMTYPE#WORKQUEUE} is returned. If a supervisor is located,
   * the task is to be assign to that user and {@link TARGETITEMTYPE#USER} is
   * returned.
   *
   * @param supervisor
   * the supervisor from the parent case that has permission to
   * approve/reject the task, or null if no supervisor could be located
   * @return 'User' if the passed in supervisor is not <code>null</code>,
   * otherwise 'work queue'.
   */
  String getAssignTaskType(final User supervisor) {

    if (null == supervisor) {
      return TARGETITEMTYPE.WORKQUEUE;
    }

    return TARGETITEMTYPE.USER;
  }

  /**
   * Determines the user the task is to be assigned to.
   *
   * @param supervisor
   * the supervisor from the parent case that has permission to
   * approve/reject the task, or null if no supervisor could be located
   * @return the supervisor if one exists for the parent case, otherwise the
   * administrator of the default work queue
   */
  String getUserAssignTaskTo(final User supervisor) {

    if (null == supervisor) {

      return getDefaultWorkQueue().getID().toString();

    }
    return supervisor.getID();
  }

  /**
   * Retrieves a {@link WorkQueue} reference to the default work queue.
   *
   * @return the default work queue
   */
  WorkQueue getDefaultWorkQueue() {

    return workQueueDAO.get(
      Long.parseLong(
        getPropertyConfiguration(EnvVars.ENV_WORKFLOW_DEFAULT_ERROR_WORKQUEUE,
        new Integer(EnvVars.ENV_WORKFLOW_DEFAULT_ERROR_WORKQUEUE_DEFAULT).toString())));
  }

  // END, CR00276006

  // BEGIN, CR00275645, POH
  // BEGIN, CR00399517, MV
  /**
   * Retrieves the supervisor the approve/reject task is to be sent to. If there
   * is case supervisor specified on the case then this method will return case
   * supervisor. If there is no case supervisor specified on the case then this
   * method returns the submitted persons supervisor.
   *
   * @param submittedByUser
   * the user who submitted the record the approval request is in
   * relation to
   * @param relatedID
   * the unique identifier of the record the approval request is in
   * relation to
   * @return the user representing the supervisor the approve/reject task is to
   * be sent to. If no supervisor can be located <code>null</code> will
   * be returned
   */
  // END, CR00399517
  User getSupervisor(final User submittedByUser, final long relatedID) {

    final CaseHeader caseHeader = getCaseHeader(relatedID);
    User supervisor = caseHeader.readSupervisor();

    if (null == supervisor) {
      supervisor = caseHeader.readSupervisorForCaseOwner();
    }

    return supervisor;
  }

  // END, CR00275645

  /**
   * Retrieves the comments for the task.
   *
   * @param relatedID
   * the unique identifier of the record the approval request is in
   * relation to and the comments are to be retrieved from
   * @return the comments to be added to the task
   */
  abstract String getPostSubmitTaskComments(final Long relatedID);

  /**
   * Retrieves a {@link LocalisableString} representing the description to be
   * placed into the created task.
   *
   * @param relatedID
   * the {@link CaseHeader} the values to be used within the
   * description are to be retrieved from
   * @return the description to be used in the created task
   * @throws InformationalException
   */
  abstract LocalisableString getPostSubmitTaskSubject(final Long relatedID)
    throws InformationalException;

  /**
   * Retrieves the {@link CaseHeader} the related identifier given to the event
   * is in relation to.
   * <p>
   * If the related identifier is a case itself, it retrieves an instance of the
   * case header.
   * </p>
   * <p>
   * If the related identifier is a child record of a case, the parent case
   * header is retrieved and returned
   * </p>
   * <p>
   * If the related identifier is not on a case, then null is returned
   * </p>
   *
   *
   * @param relatedID
   * the related identifier to use in to retrieve the case header
   * @return the case header object, or null if the related identifier is a
   * record that does not exist on a case
   */
  abstract CaseHeader getCaseHeader(final long relatedID);

  /**
   * {@inheritDoc}
   */
  @Override
  public void preApprove(final User approvedByUser, final long relatedID)
    throws InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager = checkAuthorization(approvedByUser, relatedID,
      getNotAuthorizedToApproveMessage());

    informationalManager.failOperation();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void preReject(final User rejectedByUser, final long relatedID)
    throws InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager = checkAuthorization(rejectedByUser, relatedID,
      getNotAuthorizedToRejectMessage());
    informationalManager.failOperation();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  public void preSubmit(final User submittedByUser, final long relatedID)
    throws InformationalException {// no processing required
  }

  /**
   * Retrieves the {@link APPROVALRELATEDTYPEEntry} this approval request
   * handler is in relation to.
   *
   * @return the approval related type entryAPPROVALRELATEDTYPEEntry
   */
  abstract APPROVALRELATEDTYPEEntry getApprovalRelatedType();

  // BEGIN, CR00276006, POH
  /**
   * Creates a standard manual task.
   *
   * @param relatedID
   * The identifier for the related type.
   * @param taskAssignmentIdentifier
   * The identifier of who or what that the task will be assigned to.
   * @param targetItemType
   * where or who the task is to be assigned to, a work queue or user.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  void createTask(final long relatedID,
    final String taskAssignmentIdentifier, final String targetItemType)
    throws InformationalException {

    // Create the list we will pass to the enactment service.
    final java.util.List<ApproveRejectStandardTaskDetails> enactmentStructs = new java.util.ArrayList<ApproveRejectStandardTaskDetails>();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    addEnactmentStructs(relatedID, taskAssignmentIdentifier, targetItemType,
      enactmentStructs, informationalManager);

    try {
      // Always use synchronous mode, for batch and online tasks
      EnactmentService.startProcessInV3CompatibilityMode(
        CuramConst.kAPPROVALREQUESTAPPROVEREJECTTASK, enactmentStructs);
    } catch (final AppException a) {
      informationalManager.addInformationalMsg(a, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    informationalManager.failOperation();
  }

  /**
   * Creates the structs to be used in the enactment of the approve reject task
   * and adds them to the passed in enactment structs list.
   *
   * @param relatedID
   * The identifier for the related type.
   * @param taskAssignmentIdentifier
   * The identifier of who or what that the task will be assigned to.
   * @param targetItemType
   * where or who the task is to be assigned to, a work queue or user.
   * @param enactmentStructs
   * The list to hold the enactment structs details
   * @param informationalManager
   * the informational manager to store any exceptions
   * @throws InformationalException
   */
  void addEnactmentStructs(final long relatedID,
    final String taskAssignmentIdentifier, final String targetItemType,
    final java.util.List<ApproveRejectStandardTaskDetails> enactmentStructs,
    final InformationalManager informationalManager)
    throws InformationalException {

    final ApproveRejectStandardTaskDetails approveRejectStandardTaskDetails = new ApproveRejectStandardTaskDetails();

    approveRejectStandardTaskDetails.comments = getPostSubmitTaskComments(
      relatedID);
    approveRejectStandardTaskDetails.subject = getPostSubmitTaskSubject(relatedID).getMessage();
    approveRejectStandardTaskDetails.priority = TASKPRIORITY.NORMAL;
    approveRejectStandardTaskDetails.relatedID = relatedID;
    approveRejectStandardTaskDetails.assignType = targetItemType;
    approveRejectStandardTaskDetails.assignmentTo = taskAssignmentIdentifier;
    approveRejectStandardTaskDetails.relatedType = getApprovalRelatedType().getCode();

    final DateTimeInSecondsKey dateTimeInSecondsKey = new DateTimeInSecondsKey();

    dateTimeInSecondsKey.dateTime = approveRejectStandardTaskDetails.deadlineTime;

    final TaskManagementUtility taskManagementUtilityObj = TaskManagementUtilityFactory.newInstance();

    try {
      approveRejectStandardTaskDetails.deadlineDuration = taskManagementUtilityObj.convertDateTimeToSeconds(dateTimeInSecondsKey).seconds;
    } catch (final AppException a) {
      informationalManager.addInformationalMsg(a, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }
    informationalManager.failOperation();

    enactmentStructs.add(approveRejectStandardTaskDetails);
  }

  // END, CR00276006

  /**
   * Creates a notification when the related record the {@link ApprovalRequest}
   * is in relation to is approved or rejected. The notification is sent to the
   * user who approved or rejected the related record.
   *
   * @param relatedID
   * The identifier for the related type.
   * @param notificationMessage
   * The localisable message containing the comments and subject for
   * the notification
   * @throws InformationalException
   */
  void createNotification(final long relatedID,
    final LocalisableString notificationMessage)
    throws InformationalException {

    final Notification notificationObj = NotificationFactory.newInstance();
    final StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

    notificationMessage.arg(getCaseHeader(relatedID).getCaseReference());
    standardManualTaskDtls.dtls.taskDtls.comments = notificationMessage.getMessage();
    standardManualTaskDtls.dtls.taskDtls.subject = notificationMessage.getMessage();
    // have the notification sent to the user that submitted the approval
    // request
    standardManualTaskDtls.dtls.concerningDtls.caseID = getCaseHeader(relatedID).getID();
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    try {
      notificationObj.createWorkAllocationNotification(standardManualTaskDtls);
    } catch (final AppException a) {
      informationalManager.addInformationalMsg(a, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }
  }

  /**
   * Retrieves a localisable message to be used when the user is not authorized
   * to reject the approval request.
   *
   * @return the localisable message
   */
  abstract LocalisableString getNotAuthorizedToRejectMessage();

  /**
   * Retrieves a localisable message to be used when the user is not authorized
   * to approve the approval request.
   *
   * @return the localisable message
   */
  abstract LocalisableString getNotAuthorizedToApproveMessage();

  /**
   * Retrieves a localisable message to be used in the rejection notification.
   *
   * @return the localisable message
   */
  abstract LocalisableString getRejectionNotificationMessage();

  /**
   * Retrieves a localisable message to be used in the approval notification.
   *
   * @return the localisable message
   */
  abstract LocalisableString getApprovalNotificationMessage();

  /**
   * Closes the approval request manual task as the task has been either
   * approved or rejected.
   * <p>
   * The method raises the {@link APPROVALREQUEST#APPROVEDREJECTED} event. The
   * task is waiting for this event, and when raised will check the primary
   * event data of the event to see if it matches that of the case identifier
   * the task is in relation to. If this is the case, the task is closed. If
   * not, the event was not in relation to the task, and the task is not closed.
   * </p>
   *
   * @param relatedID
   * The identifier for the related record for the task.
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  void closeTask(final long relatedID) throws InformationalException {

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.primaryEventData = relatedID;
    event.eventKey.eventType = APPROVALREQUEST.APPROVEDREJECTED.eventType;
    event.eventKey.eventClass = APPROVALREQUEST.APPROVEDREJECTED.eventClass;

    try {
      EventService.raiseEvent(event);
    } catch (final AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

  }

  // BEGIN, CR00275925, POH
  /**
   * Checks that the user is authorized to approve or reject the related record.
   *
   * @param userName
   * The userName of the user performing the approve or reject.
   * @param relatedID
   * The identifier for the related record.
   * @param authorizationMessage
   * The authorization message used to add a validation.
   * @return InformationalManager holding any validations added.
   * @throws InformationalException
   * Generic Exception Signature
   */
  InformationalManager checkAuthorization(final User userName,
    final long relatedID, final LocalisableString authorizationMessage)
    throws InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    /*
     * Determine if the user is authorized to approve or reject the record
     */
    if (!determineUserAuthorizedToApproveReject(userName, relatedID)) {

      // if security is not authorized then add validation
      authorizationMessage.arg(userName.getFullName());
      informationalManager.addInformationalMsg(authorizationMessage,
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    return informationalManager;
  }

  // END, CR00275925

  /**
   * {@inheritDoc}
   */
  @Override
  public ClientURI getApproveClientURI(final Long relatedID) {

    final ClientURI clientURI = new ClientURI(getApprovalPageURI());

    getUriParamaters(relatedID, clientURI);
    return clientURI;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ClientURI getRejectClientURI(final Long relatedID) {

    final ClientURI clientURI = new ClientURI(getRejectPageURI());

    getUriParamaters(relatedID, clientURI);
    return clientURI;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ClientURI getHomeClientURI(final Long relatedID) {

    final ClientURI clientURI = new ClientURI(getHomePageURI());

    getUriParamaters(relatedID, clientURI);
    return clientURI;
  }

  /**
   * Reads the value of the given system property as configured by the system.
   *
   * @param propertyValue
   * The system property value to be retrieved
   * @param propertyValueDefault
   * The default value of the system property value to be retrieved
   * @return The value of the property configured for it by the system
   */
  String getPropertyConfiguration(final String propertyValue,
    final String propertyValueDefault) {

    String property = Configuration.getProperty(propertyValue);

    // If the property is not set, use default value
    if (null == property) {
      property = Configuration.getProperty(propertyValueDefault);
    }
    return property;
  }

  /**
   * Retrieves a string representing the name of the page for approving the
   * approval request.
   *
   * @return the name of the page for approving the approval request
   */
  abstract String getApprovalPageURI();

  /**
   * Retrieves a string representing the name of the page for rejecting the
   * approval request.
   *
   * @return the name of the page for rejecting the approval request
   */
  abstract String getRejectPageURI();

  /**
   * Retrieves a string representing the name of the page for the viewing of the
   * home page of the record the approval request is in relation to.
   *
   * @return the name of the page to be used for viewing the home page of the
   * record the approval request is in relation to
   */
  abstract String getHomePageURI();

  /**
   * Sets the parameters on the given {@link ClientURI}.
   *
   * @param relatedID
   * the unique identifier
   * @param approvalRequestURI
   * the client URI to append the parameters to
   */
  abstract void getUriParamaters(long relatedID,
    final ClientURI approvalRequestURI);

  // BEGIN, CR00275925, POH
  /**
   * {@inheritDoc}
   */
  @Override
  public boolean determineCurrentUserCanApproveReject(final Long relatedID) {

    // retrieve the current user
    final User currentUser = userDAO.get(TransactionInfo.getProgramUser());

    return determineUserAuthorizedToApproveReject(currentUser, relatedID);
  }

  /**
   * Determines is the passed in {@link User} is authorized to approve or reject
   * the related record.
   *
   * @param user
   * the user whose authorization is being determined
   * @param relatedID
   * the unique identifier of the record the requires approval
   * @return true if the user is authorized to approve/reject the record,
   * otherwise false
   */
  boolean determineUserAuthorizedToApproveReject(final User user,
    final Long relatedID) {

    final CaseHeader caseHeader = getCaseHeader(relatedID);

    /*
     * if the current user is the supervisor for the case then they have
     * permission to approve/reject the related record
     */
    if (null != caseHeader.readSupervisor()) {
      if (user.getID().equals(caseHeader.readSupervisor().getID())) {
        return true;
      }
    }

    /*
     * if the current user is a supervisor of the case owner then the user has
     * permission to approve/reject the related record
     */
    if (caseHeader.listSupervisorsForCaseOwner().contains(user)) {
      return true;
    }

    // BEGIN, CR00406851, MV
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = relatedID;
    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = user.getUsername();
    final ValidationConfigurationKey validationConfigurationKey = new ValidationConfigurationKey();

    validationConfigurationKey.dtls.exceptionID = CuramConst.gkERR_USER_NOT_AUTHORIZED;
    try {
      final boolean isValidationEnabled = ValidationConfigurationAdminFactory.newInstance().searchConfigurableValidations(validationConfigurationKey).dtls.item(0).enabled;

      if (!isValidationEnabled) {
        if (CaseUserRoleFactory.newInstance().isCaseApprovalTaskAssignedToCurrentUser(
          caseHeaderKey, userNameKey)) {
          return true;
        }
      }
    } catch (final Exception e) {}
    // END, CR00406851

    /*
     * If here the user is neither the supervisor of the case or case owner, and
     * does not have permission to approve/reject the related record.
     */
    return false;
  }
  // END, CR00275925
}
