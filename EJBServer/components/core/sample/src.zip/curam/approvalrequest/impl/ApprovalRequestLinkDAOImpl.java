/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;


import com.google.inject.Singleton;
import curam.approvalrequest.entity.impl.ApprovalRequestLinkAdapter;
import curam.approvalrequest.entity.struct.ApprovalRequestLinkDtls;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.APPROVALREQUESTSTATUSEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import java.util.Collections;
import java.util.List;


/**
 * Implementation of the {@link ApprovalRequestLinkDAO} interface.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@Singleton
public class ApprovalRequestLinkDAOImpl extends StandardDAOImpl<ApprovalRequestLink, ApprovalRequestLinkDtls> implements
  ApprovalRequestLinkDAO {

  protected static final ApprovalRequestLinkAdapter adapter = new ApprovalRequestLinkAdapter();

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected ApprovalRequestLinkDAOImpl() {

    // no-arg constructor for use only by Guice.
    // END, CR00183334
    super(adapter, ApprovalRequestLink.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<ApprovalRequestLink> readByRelatedIDAndRelatedType(
    final long relatedID, final APPROVALRELATEDTYPEEntry relatedType) {

    return newList(
      adapter.searchByRelatedIDAndType(relatedID, relatedType.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public long getApprovalRequestID(final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType) throws InformationalException {

    long approvalRequestID = 0;
    final List<ApprovalRequestLink> approvalRequestLinkList = readByRelatedIDAndRelatedType(
      relatedID, relatedType);

    // find the approval request link that is in state SUBMITTED.
    // will only ever be one for the related id and related type

    for (final ApprovalRequestLink approvalRequestLink : approvalRequestLinkList) {
      if (approvalRequestLink.getStatus().equals(
        APPROVALREQUESTSTATUSEntry.SUBMITTED)) {
        approvalRequestID = approvalRequestLink.getApprovalRequestID();

        break;
      }
    }

    return approvalRequestID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ApprovalRequestLink getApprovalRequestLink(final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType) {

    final List<ApprovalRequestLink> approvalRequestLinkList = readByRelatedIDAndRelatedType(
      relatedID, relatedType);

    // find the approval request link that is in state SUBMITTED.
    // will only ever be one for the related id and related type

    for (final ApprovalRequestLink approvalRequestLink : approvalRequestLinkList) {
      if (approvalRequestLink.getStatus().equals(
        APPROVALREQUESTSTATUSEntry.SUBMITTED)) {

        return approvalRequestLink;
      }
    }

    return null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public List<ApprovalRequestLink> readByRelatedIDAndRelatedType(
    final long relatedID, final String relatedType)
    throws InformationalException {

    return Collections.unmodifiableList(
      newList(adapter.searchByRelatedIDAndType(relatedID, relatedType)));
  }

}
