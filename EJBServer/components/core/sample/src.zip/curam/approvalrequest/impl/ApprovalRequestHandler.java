/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.approvalrequest.impl;


import com.google.inject.ImplementedBy;
import curam.piwrapper.impl.ClientURI;
import curam.piwrapper.user.impl.User;
import curam.util.exception.InformationalException;


/**
 * Interface for handling the approval process for records utilizing
 * the {@link ApprovalRequest} functionality
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(ApprovalRequestHandlerImpl.class)
public interface ApprovalRequestHandler {

  /**
   * Includes additional functionality to the pre {@link ApprovalRequest
   * approval request} submission processing.
   * <p>
   * This method is invoked from the listener for the
   * {@link ApprovalRequestSubmitEvent#preSubmitApprovalRequest(ApprovalRequestAccessor, String, long, curam.codetable.impl.APPROVALRELATEDTYPEEntry)}
   * event.
   * </p>
   *
   * @param submittedByUser
   * The user submitting the request
   * @param relatedID
   * The identifier for the related type
   * @throws InformationalException
   * Generic Informational Exception
   */
  void preSubmit(final User submittedByUser, final long relatedID)
    throws InformationalException;

  /**
   * Includes additional functionality to the post {@link ApprovalRequest
   * approval request} submission processing.
   * <p>
   * This method is invoked from the listener for the
   * {@link ApprovalRequestSubmitEvent#postSubmitApprovalRequest(ApprovalRequestAccessor, String, long, curam.codetable.impl.APPROVALRELATEDTYPEEntry)}
   * event.
   * </p>
   *
   * @param submittedByUser
   * The user submitting the request
   * @param relatedID
   * The identifier for the related type
   * @throws InformationalException
   * Generic Informational Exception
   */
  void postSubmit(User submittedByUser, final long relatedID)
    throws InformationalException;

  /**
   * Includes additional functionality to the pre {@link ApprovalRequest
   * approval request} approval processing.
   * <p>
   * This method is invoked from the listener for the
   * {@link ApprovalRequestApproveEvent#preApproveApprovalRequest(ApprovalRequestAccessor, String, long, curam.codetable.impl.APPROVALRELATEDTYPEEntry)}
   * event.
   * </p>
   *
   * @param approvedByUser
   * The user approving the approval request
   * @param relatedID
   * The identifier for the related type
   * @throws InformationalException
   * Generic Informational Exception
   */
  void preApprove(final User approvedByUser, final long relatedID)
    throws InformationalException;

  /**
   * Includes additional functionality to the post {@link ApprovalRequest
   * approval request} approval processing.
   * <p>
   * This method is invoked from the listener for the
   * {@link ApprovalRequestApproveEvent#postApproveApprovalRequest(ApprovalRequestAccessor, String, long, curam.codetable.impl.APPROVALRELATEDTYPEEntry)}
   * event.
   * </p>
   *
   * @param relatedID
   * The identifier for the related type
   * @throws InformationalException
   * Generic Informational Exception
   */
  void postApprove(final long relatedID) throws InformationalException;

  /**
   * Includes additional functionality to the pre {@link ApprovalRequest
   * approval request} rejection processing.
   * <p>
   * This method is invoked from the listener for the
   * {@link ApprovalRequestRejectEvent#preRejectApprovalRequest(ApprovalRequestAccessor, String, long, curam.codetable.impl.APPROVALRELATEDTYPEEntry)}
   * event.
   * </p>
   *
   * @param rejectedByUser
   * The user rejecting the request
   * @param relatedID
   * The identifier for the related type
   * @throws InformationalException
   * Generic Informational Exception
   */
  void preReject(final User rejectedByUser, final long relatedID)
    throws InformationalException;

  /**
   * Includes additional functionality to the pre {@link ApprovalRequest
   * approval request} rejection processing.
   * <p>
   * This method is invoked from the listener for the
   * {@link ApprovalRequestRejectEvent#postRejectApprovalRequest(ApprovalRequestAccessor, String, long, curam.codetable.impl.APPROVALRELATEDTYPEEntry)}
   * event.
   * </p>
   *
   * @param relatedID
   * The identifier for the related type
   * @throws InformationalException
   * Generic Informational Exception
   */
  void postReject(final long relatedID) throws InformationalException;

  /**
   * Retrieves the appropriate {@link ClientURI} to be used for the approval of
   * the approval request.
   *
   * @param relatedID
   * the unique identifier of the related record the approval client
   * URI to be retrieved is in relation to
   * @return the URI
   */
  ClientURI getApproveClientURI(final Long relatedID);

  /**
   * Retrieves the appropriate {@link ClientURI} to be used for the rejection of
   * the approval request.
   *
   * @param relatedID
   * the unique identifier of the related record the reject client URI
   * to be retrieved is in relation to
   * @return the URI
   */
  ClientURI getRejectClientURI(final Long relatedID);

  /**
   * Retrieves the appropriate {@link ClientURI} to be used for viewing the home
   * page of the record the approval request is in relation to.
   *
   * @param relatedID
   * the unique identifier of the related record the home page URI to
   * be retrieved is in relation to
   * @return the URI
   */
  ClientURI getHomeClientURI(final Long relatedID);

  // BEGIN, CR00275925, POH
  /**
   * Determines if the current {@link User} is permitted to approve or reject
   * the record requiring approval.
   * <p>
   * The current user is capable of approving or rejecting the related record if
   * they are the supervisor for the case the record is related to or one of the
   * users retrieved from the dynamic supervisor identification process.
   * </p>
   *
   * @param relatedID
   * the unique identifier of the related record the {@link ApprovalRequest} is
   * in relation to
   * @return true if the current user has permissions to approve or reject the
   * related record, otherwise false.
   */
  boolean determineCurrentUserCanApproveReject(final Long relatedID);
  // END, CR00275925
}
