/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.approvalrequest.impl;


import com.google.inject.Inject;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.caseheader.impl.IntegratedCase;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.impl.ClientURI;
import curam.piwrapper.user.impl.User;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;


/**
 * Implementation of the {@link IntegratedCaseApprovalRequestHandler} interface.
 *
 * @since 6.0
 */
class IntegratedCaseApprovalRequestHandlerImpl extends ApprovalRequestHandlerImpl implements IntegratedCaseApprovalRequestHandler {

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected curam.piwrapper.caseheader.impl.IntegratedCaseDAO integratedCaseDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  APPROVALRELATEDTYPEEntry getApprovalRelatedType() {

    return APPROVALRELATEDTYPEEntry.INTEGRATEDCASE;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  CaseHeader getCaseHeader(final long relatedID) {

    return caseHeaderDAO.get(relatedID);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  LocalisableString getPostSubmitTaskSubject(final Long relatedID)
    throws InformationalException {

    final LocalisableString description = new LocalisableString(
      curam.message.INTEGRATEDCASEAPPROVALREQUESTTASK.INTEGRATED_CASE_SUBMIT_SUBJECT);

    final IntegratedCase integratedCase = integratedCaseDAO.get(relatedID);

    description.arg(integratedCase.getName());
    description.arg(getCaseClients(integratedCase));

    return description;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  String getPostSubmitTaskComments(final Long relatedID) {

    return integratedCaseDAO.get(relatedID).getComments();
  }

  /**
   * Retrieves a comma separated list of all clients the exist on the given
   * {@link AssessmentCase}.
   *
   * @param assessmentCase
   * the assessment case the clients are to be retrieved from
   * @return the comma separated list of all clients
   */
  String getCaseClients(final IntegratedCase integratedCase) {

    String assessmentClients = " ";

    for (final CaseParticipantRole caseParticipantRole : integratedCase.listActiveCaseMembers()) {
      assessmentClients += caseParticipantRole.getConcernRole().getName()
        + CuramConst.gkComma + CuramConst.gkSpace;
    }
    assessmentClients = assessmentClients.substring(0,
      assessmentClients.lastIndexOf(CuramConst.gkComma));
    return assessmentClients;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  LocalisableString getRejectionNotificationMessage() {

    return new LocalisableString(
      curam.message.INTEGRATEDCASEAPPROVALREQUESTTASK.INTEGRATED_CASE_REJECTED_NOTIFICATION);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  LocalisableString getApprovalNotificationMessage() {

    return new LocalisableString(
      curam.message.INTEGRATEDCASEAPPROVALREQUESTTASK.INTEGRATED_CASE_APPROVED_NOTIFICATION);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  LocalisableString getNotAuthorizedToApproveMessage() {

    return new LocalisableString(
      curam.message.INTEGRATEDCASEAPPROVALREQUESTTASK.ERR_INTEGRATED_CASE_APPROVAL_NOT_AUTHORIZED);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  LocalisableString getNotAuthorizedToRejectMessage() {

    return new LocalisableString(
      curam.message.INTEGRATEDCASEAPPROVALREQUESTTASK.ERR_INTEGRATED_CASE_REJECT_NOT_AUTHORIZED);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @SuppressWarnings("unused")
  User getSupervisor(final User submittedByUser, final long relatedID) {

    return submittedByUser.getSupervisor();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  String getApprovalPageURI() {

    return getPropertyConfiguration(
      EnvVars.ENV_APPROVALREQUEST_INTEGRATEDCASE_APPROVE,
      EnvVars.ENV_APPROVALREQUEST_INTEGRATEDCASE_APPROVE_DEFAULT);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  String getRejectPageURI() {

    return getPropertyConfiguration(
      EnvVars.ENV_APPROVALREQUEST_INTEGRATEDCASE_REJECT,
      EnvVars.ENV_APPROVALREQUEST_INTEGRATEDCASE_REJECT_DEFAULT);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  String getHomePageURI() {

    return getPropertyConfiguration(
      EnvVars.ENV_APPROVALREQUEST_INTEGRATEDCASE_HOME,
      EnvVars.ENV_APPROVALREQUEST_INTEGRATEDCASE_HOME_DEFAULT);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  void getUriParamaters(final long relatedID,
    final ClientURI approvalRequestURI) {

    approvalRequestURI.appendParam(CuramConst.gkCaseIDParameter,
      new Long(relatedID).toString());
  }

}
