/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012-2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.collaboration.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.COLLABORATIONSHARINGTYPEEntry;
import curam.collaboration.facade.struct.CaseCollaborationMemberKey;
import curam.collaboration.facade.struct.ListCaseCollaborationMembersResult;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.impl.ClientURI;
import curam.piwrapper.user.impl.User;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.ArrayList;
import java.util.List;


/**
 * Case Collaboration Strategy implementation callable from CEF, a default
 * implementation exists in CEF however the real implementation of the strategy
 * lives in the SocialEnterpriseCollaboration component.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@SuppressWarnings("unused")
@ImplementedBy(CaseCollaborationStrategyImpl.class)
public abstract class CaseCollaborationStrategy {

  /**
   * Checks if collaboration has been set up for the case, checks if
   * collaboration is configured in admin and that a Collaboration SEF has been
   * created for the case.
   *
   * @param caseHeader
   * The case to check.
   * @return <code>true</code> if collaboration is enabled for the case,
   * <code>false</code> otherwise.
   */
  public boolean isCollaborationEnabled(final CaseHeader caseHeader) {

    return false;
  }

  /**
   * Retrieves a list of case collaboration members that can be selected when
   * choosing to share for collaboration.
   *
   * @param key
   * The key for the read, caseID and sharingType are mandatory, the
   * admin related details are only mandatory for activities as these
   * are required to check for restrictions.
   * @return The populated result value object.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListCaseCollaborationMembersResult listCaseCollaborationMembersForSharing(
    final CaseCollaborationMemberKey key) throws AppException,
      InformationalException {

    return new ListCaseCollaborationMembersResult();
  }

  // BEGIN, CR00307295, POH
  /**
   * Retrieves a list of case collaboration members that are currently selected
   * for sharing on a record where collaboration is allowed.
   *
   *
   * @param caseHeader
   * the case the collaboration members can exist and the related
   * record identifier exists on
   * @param collaborationSharingTypeEntry
   * the type of collaboration sharing record
   * @param relatedID
   * the unique identifier of the record the returned list of
   * collaboration members are to be associated to
   *
   * @return The populated list of all sharing members that are associated to
   * the sharing record, or an empty list of no collaboration members
   * are shared on the record
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListCaseCollaborationMembersResult listCurrentCaseCollaborationMembers(final CaseHeader caseHeader,
    final COLLABORATIONSHARINGTYPEEntry collaborationSharingTypeEntry,
    final Long relatedID) throws AppException, InformationalException {

    return new ListCaseCollaborationMembersResult();
  }

  // END, CR00307295

  /**
   * Creates a sharing record for a case collaboration member for a specified
   * item on a case.
   *
   * @param caseCollaborationMemberID
   * The identifier of the case collaboration member for which sharing
   * record should be created.
   * @param sharingTypeEntry
   * The type of sharing item to create the records for, e.g. note.
   * @param relatedID
   * The id of the item to be shared, e.e noteID.
   * @param caseHeader
   * The case that the item is linked to, this is required to improve
   * the performance for the retrieval of the sharing records.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createCaseCollaborationMemberSharing(
    final Long caseCollaborationMemberID,
    final COLLABORATIONSHARINGTYPEEntry sharingTypeEntry,
    final Long relatedID, final CaseHeader caseHeader)
    throws InformationalException {// Implemented in the
    // SocialEnterpriseCollaboration component
  }

  /**
   * Retrieves a list containing the case collaboration member details of each
   * collaboration member that currently exists on the given {@link CaseHeader
   * case}. If no collaboration members exist on the given case or collaboration
   * is not enabled for the case, an empty list is returned.
   *
   * @param caseHeader
   * The case the list of collaboration member details information for
   * each collaboration member is to be attempted to be retrieved from
   * @return the populated list containing the case collaboration member details
   * of each collaboration member that currently exists on the given
   * case, or an empty list if no collaboration members exist on the
   * given case or collaboration is not enabled for the case.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListCaseCollaborationMembersResult listCaseCollaborationMembersForMeeting(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    return new ListCaseCollaborationMembersResult();
  }

  /**
   * Checks if the logged in Collaboration Team Member has access to a
   * collaboration item.
   *
   * @param relatedID
   * The id of the item to check.
   * @param typeEntry
   * The type of the item to check.
   * @param caseHeader
   * The case that the item is related to.
   * @return <code>true</code> if the member has access to the item,
   * <code>false</code> otherwise.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public boolean isSharingEnabledForItem(final long relatedID,
    final COLLABORATIONSHARINGTYPEEntry typeEntry,
    final CaseHeader caseHeader) throws AppException,
      InformationalException {

    return false;
  }

  /**
   * Retrieve a list of the items that the current logged in member has access
   * to based on the type and related case.
   *
   * @param typeEntry
   * The item type to search for.
   * @param caseHeader
   * The related case linked to the shared item.
   * @return A list of shared items, or an empty list if none are found.
   * @throws AppException
   * @throws InformationalException
   */
  public List<Long> listSharedItemsByTypeAndCase(
    final COLLABORATIONSHARINGTYPEEntry typeEntry,
    final CaseHeader caseHeader) throws AppException,
      InformationalException {

    return new ArrayList<Long>();
  }

  /**
   * Retrieve a list of cases for the user where the user is a Collaboration
   * Member.
   *
   * @param caseType
   * The type of case to search by.
   * @param user
   * The user to search by.
   * @return A list of cases, or an empty list if none are found.
   * @throws AppException
   * @throws InformationalException
   */
  public List<CaseHeader> listCasesByCollaborationMemberAndCaseType(
    final CASETYPECODEEntry caseType, final User user) throws AppException,
      InformationalException {

    return new ArrayList<CaseHeader>();
  }

  /**
   * Retrieves the details of the case collaboration members for the specified
   * case. The list will include internal and external members. If the case has
   * not been configured for collaboration then the list will be empty.
   *
   * @param caseHeader
   * The {@link CaseHeader case} for which the member details are being
   * sought.
   *
   * @return A <code>list</code> of {@link CaseCollaborationMember} for the
   * specified {@link CaseHeader case}.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public List<CaseCollaborationMember> listCaseCollaborationMembers(
    final CaseHeader caseHeader) throws AppException, InformationalException {

    return new ArrayList<CaseCollaborationMember>();
  }

  /**
   * Retrieves the {@link ClientURI} for a case that displays the
   * {@link CaseCaseCollaborationMember case collaboration members}.
   *
   * @param caseHeader
   * The {@link CaseHeader case} for which the URI is being sought.
   *
   * @return The {@link ClientURI} which displays the
   * {@link CaseCaseCollaborationMember case collaboration members} for
   * the specified case. If collaboration is not configured for the case
   * <code>null</code> will be returned
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ClientURI getCaseCollaborationMembersURI(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    return null;
  }
}
