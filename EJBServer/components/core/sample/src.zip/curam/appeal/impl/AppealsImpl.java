/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.impl;


import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.codetable.impl.APPEALTYPEEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.ArrayList;


/**
 * Default implementation of the {@linkplain Appeals} interface.
 */
public class AppealsImpl implements Appeals {

  /**
   * {@inheritDoc}
   */
  @Override
  public APPEALTYPEEntry getNextStageForCaseType(long caseID)
    throws AppException, InformationalException {

    return null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ArrayList<APPEALTYPEEntry> listAllStagesForCaseType(long caseID)
    throws AppException, InformationalException {

    return null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean isObjectValidForStage(APPEALOBJECTTYPEEntry objectType,
    long objectID, APPEALTYPEEntry appealStageType, long caseID)
    throws AppException, InformationalException {

    return false;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public APPEALTYPEEntry getCurrentStageForAppealCase(long appealCaseID)
    throws AppException, InformationalException {

    return null;
  }

}
