/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.RESOLUTION;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.entity.struct.ResolutionConfigIDAndVersionNoDetails;
import curam.core.sl.entity.struct.ResolutionDtls;
import curam.core.sl.entity.struct.ResolutionKey;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndVersionNo;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when
 * modifications are made to the Resolution entity
 */
public abstract class IndexResolutionSynchronization extends curam.core.base.IndexResolutionSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the resolution entity insert operation
   *
   * @param dtls resolution details
   */
  @Override
  public void insert(final ResolutionDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = RESOLUTION.INSERT_RESOLUTION.eventClass;
    synchronizeEventsDetails.eventKey.eventType = RESOLUTION.INSERT_RESOLUTION.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.resolutionID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the resolution entity cancel operation
   *
   * @param key resolution identifier
   * @param dtls resolution details to cancel
   */
  @Override
  public void cancel(final ResolutionKey key,
    final RecordStatusAndVersionNo dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = RESOLUTION.CANCEL_RESOLUTION.eventClass;
    synchronizeEventsDetails.eventKey.eventType = RESOLUTION.CANCEL_RESOLUTION.eventType;
    synchronizeEventsDetails.primaryEventData = key.resolutionID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the resolution entity modify operation
   *
   * @param key resolution identifier
   * @param dtls resolution details to cancel
   */
  @Override
  public void modify(ResolutionKey key,
    ResolutionConfigIDAndVersionNoDetails dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = RESOLUTION.MODIFY_RESOLUTION.eventClass;
    synchronizeEventsDetails.eventKey.eventType = RESOLUTION.MODIFY_RESOLUTION.eventType;
    synchronizeEventsDetails.primaryEventData = key.resolutionID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }

}
