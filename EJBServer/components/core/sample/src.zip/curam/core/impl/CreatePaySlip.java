/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.PaySlipSummary;
import curam.core.struct.PayslipDetails;
import curam.core.struct.PayslipDtls;
import curam.core.struct.PayslipInstructionDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * To create PaySlips and their component parts.
 *
 */
public abstract class CreatePaySlip extends curam.core.base.CreatePaySlip {

  // ___________________________________________________________________________
  /**
   * To create the PayslipInstruction and Payslip records required for issuing
   * a Payslip, based on the specified input details.
   *
   * @param paySlipSumm Pay Slip summary information
   *
   * @return details of the payslip created
   */
  @Override
  public PayslipDetails createPaySlipInstruction(PaySlipSummary paySlipSumm)
    throws AppException, InformationalException {

    // payslipDetails variable
    final PayslipDetails payslipDetails = new PayslipDetails();

    // payslipInstruction manipulation variable
    final curam.core.intf.PayslipInstruction payslipInstructionObj = curam.core.fact.PayslipInstructionFactory.newInstance();
    final PayslipInstructionDtls paySlipInstructionDtls = new PayslipInstructionDtls();

    // payslip manipulation variables
    final curam.core.intf.Payslip payslipObj = curam.core.fact.PayslipFactory.newInstance();
    final PayslipDtls payslipDtls = new PayslipDtls();

    // set paySlipInstructionDtls for insert
    paySlipInstructionDtls.pslipInstructionID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
    paySlipInstructionDtls.assign(paySlipSumm);
    paySlipInstructionDtls.statusCode = curam.codetable.PAYSLIPINSTRUCTIONSTATUS.DEFAULTCODE;
    paySlipInstructionDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // insert payslipInstruction
    payslipInstructionObj.insert(paySlipInstructionDtls);

    // read in details to be returned
    payslipDetails.assign(paySlipInstructionDtls);

    // set payslipDtls for insert
    payslipDtls.payslipID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
    payslipDtls.paySlipInstructionID = paySlipInstructionDtls.pslipInstructionID;
    payslipDtls.caseNomineeID = paySlipSumm.caseNomineeID;
    payslipDtls.concernRoleID = paySlipSumm.concernRoleID;
    payslipDtls.recipientName = paySlipSumm.recipientName;
    payslipDtls.addressID = paySlipSumm.addressID;
    payslipDtls.issueDate = curam.util.type.Date.kZeroDate;
    payslipDtls.statusCode = curam.codetable.PAYSLIPINSTRUCTIONSTATUS.PENDINGISSUE;

    // insert payslip
    payslipObj.insert(payslipDtls);

    // assign payslipDtls to payslipDetails
    payslipDetails.assign(payslipDtls);

    return payslipDetails;
  }

}
