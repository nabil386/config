/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2003-2017. All Rights Reserved.
 *
 * PID 5725-H26
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.PhoneticEncoderFactory;
import curam.core.intf.PhoneticEncoder;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.SQLStatement;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressMap;
import curam.core.struct.AddressMapList;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.AlternateNameDtls;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DisableLinkIndicatorDetails;
import curam.core.struct.MaintainConcernRoleKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PersonAltSearchKey;
import curam.core.struct.PersonDatabasePhoneticEncoderKey;
import curam.core.struct.PersonDatabasePhoneticEncoderStatusKey;
import curam.core.struct.PersonDatabaseSearchKey;
import curam.core.struct.PersonDatabaseSearchKey1;
import curam.core.struct.PersonDatabaseSearchWithStatusKey;
import curam.core.struct.PersonDtls;
import curam.core.struct.PersonDtlsList;
import curam.core.struct.PersonKey;
import curam.core.struct.PersonReadDtls;
import curam.core.struct.PersonReadDtlsList;
import curam.core.struct.PersonSearchDetails;
import curam.core.struct.PersonSearchDtls;
import curam.core.struct.PersonSearchDtls1;
import curam.core.struct.PersonSearchFurtherDtls;
import curam.core.struct.PersonSearchKey;
import curam.core.struct.PersonSearchKey1;
import curam.core.struct.PersonSearchResult;
import curam.core.struct.PersonSearchResult1;
import curam.core.struct.PersonSummaryDetails;
import curam.core.struct.PersonSummaryDetailsList;
import curam.core.struct.PhoneticEncoderDetails;
import curam.core.struct.PhoneticEncoderKey;
import curam.core.struct.ReadPersonSummaryKey;
import curam.core.struct.ReadPersonSummaryStatusKey;
import curam.core.struct.SearchMessageDtls;
import curam.message.GENERAL;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;

/**
 * Person search in Database
 *
 */
public abstract class DatabasePersonSearch
  extends curam.core.base.DatabasePersonSearch {

  /**
   * Reads person information from database
   *
   * @param key person reference number
   *
   * @return A list of person details.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public PersonReadDtlsList
    searchByReferenceNumber(final AlternateIDSearchKey key)
      throws AppException, InformationalException {

    final PersonReadDtlsList personReadDtlsList = new PersonReadDtlsList();

    final PersonReadDtls personReadDtls = new PersonReadDtls();

    // variables for person
    final curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();
    PersonDtlsList personDetailsList;
    final PersonAltSearchKey personAltSearchKey = new PersonAltSearchKey();

    // concern role variables
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final curam.core.intf.Address addressObj =
      curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    final AddressKey addressKey = new AddressKey();
    final OtherAddressData otherAddressData = new OtherAddressData();

    // concern role security entity
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();

    // set search key from parameter
    personAltSearchKey.primaryAlternateID = key.alternateID;

    // do person search
    personDetailsList = personObj.searchByPrimaryAltID(personAltSearchKey);

    for (final PersonDtls personDetails : personDetailsList.dtls) {

      // set search key for concern role based on the person
      concernRoleKey.concernRoleID = personDetails.concernRoleID;

      // do concern role search
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      final ParticipantSecurityCheckKey participantSecurityCheckKey =
        new ParticipantSecurityCheckKey();

      // perform concern role sensitivity check
      participantSecurityCheckKey.participantID = personDetails.concernRoleID;
      participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
      final DataBasedSecurityResult dataBasedSecurityResult =
        dataBasedSecurity
          .checkParticipantSecurity(participantSecurityCheckKey);

      // pass out the indicator
      if (dataBasedSecurityResult.restricted) {

        // Return no details to client if User does not have access
        personReadDtls.fullName =
          personReadDtls.formattedAddressData = CuramConst.gkRestricted;
        personReadDtls.concernID = 0;
        personReadDtls.restricted = true;

      } else {
        // set search key according the concern role found
        addressKey.addressID = concernRoleDtls.primaryAddressID;

        // do address search
        addressDtls = addressObj.read(addressKey);

        // set the return values
        personReadDtls.fullName = concernRoleDtls.concernRoleName;

        otherAddressData.addressData = addressDtls.addressData;

        addressObj.getAddressStrings(otherAddressData);

        personReadDtls.formattedAddressData = otherAddressData.addressData;

        personReadDtls.concernID = concernRoleDtls.concernID;
      }

      personReadDtlsList.dtlsList.add(personReadDtls);
    }

    return personReadDtlsList;

  }

  /**
   * @param key data on which the searched will be based
   *
   * @return The details of any records found.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Performs a database search for persons using the specified search
   * criteria, or performs a database read if the alternate ID is specified.
   */
  @Override
  @Deprecated
  public PersonSearchResult search(final PersonSearchKey key)
    throws AppException, InformationalException {

    final PersonSearchResult personSearchResult = new PersonSearchResult();
    PersonSummaryDetailsList personSummaryDetailsList =
      new PersonSummaryDetailsList();

    // If the reference number is specified no need to process the complicated
    // query
    if (key.referenceNumber.length() == 0) {
      // BEGIN CR00077564, PD
      try {
        if (key.soundsLikeInd && !(key.surname.length() == 0)) {

          final PersonDatabasePhoneticEncoderKey personDatabasePhoneticEncoderKey =
            calculateSearchKey(key);

          // BEGIN, CR00077040, PMD
          personSummaryDetailsList =
            searchByNameAddressGenderDOBPhoneticEncode(
              personDatabasePhoneticEncoderKey);
          // END, CR00077040
        } else {

          final PersonDatabaseSearchKey personDatabaseSearchKey =
            calculateKey(key);

          // BEGIN, CR00077040, PMD
          personSummaryDetailsList =
            searchByNameAddressGenderOrDob(personDatabaseSearchKey);
          // END, CR00077040
        }
      } catch (final curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage = // BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS
            .getMessageText(TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        personSearchResult.messages.dtls.addRef(recordFoundMessage);
      }
      // END, CR00077040
      // BEGIN CR00020852, SG
    } else {

      final ReadPersonSummaryKey readPersonSummaryKey =
        new ReadPersonSummaryKey();

      // set the search key
      readPersonSummaryKey.primaryAlternateID = key.referenceNumber;

      try {
        // BEGIN, CR00077040, PMD
        personSummaryDetailsList =
          readSummaryDetailsByReferenceNumber(readPersonSummaryKey);
        // END, CR00077040
      } catch (final curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage = // BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS
            .getMessageText(TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        personSearchResult.messages.dtls.addRef(recordFoundMessage);
      }

    }
    // END CR00020852
    personSearchResult.result.numRecordsFound =
      personSummaryDetailsList.dtls.size();

    for (int i = 0; i < personSummaryDetailsList.dtls.size(); i++) {

      // Search details
      final PersonSearchDtls personSearchDtls = new PersonSearchDtls();

      // BEGIN, CR00100692, CR00101058, PDN
      // If an original concern role id is available and its duplicate status is
      // not unmarked then there is a duplicate concern role for this concern
      // role.
      if (personSummaryDetailsList.dtls.item(i).originalConcernRoleID != 0
        && !personSummaryDetailsList.dtls.item(i).duplicateStatus
          .equals(DUPLICATESTATUS.UNMARKED)) {
        personSummaryDetailsList.dtls.item(i).duplicateInd = true;
      }
      // END, CR00100692, CR00101058

      personSearchDtls.assign(personSummaryDetailsList.dtls.item(i));
      // BEGIN, CR00100529, VM
      personSearchDtls.sex = personSummaryDetailsList.dtls.item(i).gender;
      personSearchDtls.motherSurname =
        personSummaryDetailsList.dtls.item(i).motherBirthSurname;
      // END, CR00100529

      personSearchDtls.address =
        personSummaryDetailsList.dtls.item(i).addressLine1;
      personSearchDtls.city = personSummaryDetailsList.dtls.item(i).city;

      restrictResults(personSearchDtls);

      if (personSearchDtls.referenceNumber != null) {
        personSearchResult.details.dtls.addRef(personSearchDtls);
      } else {
        personSearchResult.result.numRecordsFound =
          personSearchResult.result.numRecordsFound - 1;
      }
    }

    return personSearchResult;

  }

  /**
   * Reads person's information from database
   *
   * @param key person reference number
   *
   * @return Person read details structure
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0.5.3, replaced by
   * {@link #searchByReferenceNumber()}
   */
  @Deprecated
  @Override
  public PersonReadDtls readByReferenceNumber(final AlternateIDSearchKey key)
    throws AppException, InformationalException {

    final PersonReadDtls personReadDtls = new PersonReadDtls();

    // variables for person
    final curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();
    PersonDtls personDetails;
    final PersonAltSearchKey personAltSearchKey = new PersonAltSearchKey();

    // concern role variables
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final curam.core.intf.Address addressObj =
      curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    final AddressKey addressKey = new AddressKey();
    final OtherAddressData otherAddressData = new OtherAddressData();

    // concern role security entity
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();

    // set search key from parameter
    personAltSearchKey.primaryAlternateID = key.alternateID;

    // do person search
    personDetails = personObj.readByAlternateID(personAltSearchKey);

    // set search key for concern role based on the person
    concernRoleKey.concernRoleID = personDetails.concernRoleID;

    // do concern role search
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // BEGIN, CR00226315, PM
    final ParticipantSecurityCheckKey participantSecurityCheckKey =
      new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = personDetails.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkParticipantSecurity(participantSecurityCheckKey);

    // pass out the indicator
    if (dataBasedSecurityResult.restricted) {

      // Return no details to client if User does not have access
      personReadDtls.fullName =
        personReadDtls.formattedAddressData = CuramConst.gkRestricted;
      personReadDtls.concernID = 0;
      personReadDtls.restricted = true;
      return personReadDtls;

    } else {
      // set search key according the concern role found
      addressKey.addressID = concernRoleDtls.primaryAddressID;

      // do address search
      addressDtls = addressObj.read(addressKey);

      // set the return values
      personReadDtls.fullName = concernRoleDtls.concernRoleName;

      otherAddressData.addressData = addressDtls.addressData;

      addressObj.getAddressStrings(otherAddressData);

      personReadDtls.formattedAddressData = otherAddressData.addressData;

      personReadDtls.concernID = concernRoleDtls.concernID;
    }

    // If the location data security is on then access denied
    if (!dataBasedSecurityResult.result) {

      return null;
    }
    // END, CR00226315

    return personReadDtls;
  }

  /**
   * Called to retrieve further details about a person selected from a person
   * search.
   *
   * @param key person key
   *
   * @return details found
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public PersonSearchFurtherDtls
    readFurtherDetails(final MaintainConcernRoleKey key)
      throws AppException, InformationalException {

    final PersonSearchFurtherDtls personSearchFurtherDtls =
      new PersonSearchFurtherDtls();

    // Person entity
    final curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();
    final PersonKey personKey = new PersonKey();
    PersonDtls personDtls; // Person structure

    // Concern role entity
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls; // Concern role structure
    // Concern role key
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // address manipulation variables
    final curam.core.intf.Address addressObj =
      curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    final AddressKey addressKey = new AddressKey();

    // Alternate name entity
    final curam.core.intf.AlternateName alternateNameObj =
      curam.core.fact.AlternateNameFactory.newInstance();
    AlternateNameDtls alternateNameDtls; // Alternate name structure
    // Alternate name key
    final AlternateNameKey alternateNameKey = new AlternateNameKey();

    // retrieve person details
    personKey.concernRoleID = key.concernRoleID;
    personDtls = personObj.read(personKey);

    // set the search key for alternate name read
    alternateNameKey.alternateNameID = personDtls.primaryAlternateNameID;

    // do the alternate name search
    alternateNameDtls = alternateNameObj.read(alternateNameKey);

    // set the person search further details struct
    personSearchFurtherDtls.title = alternateNameDtls.title;
    personSearchFurtherDtls.forename = alternateNameDtls.firstForename;
    personSearchFurtherDtls.otherForename = alternateNameDtls.otherForename;
    personSearchFurtherDtls.surname = alternateNameDtls.surname;
    personSearchFurtherDtls.preferredName = alternateNameDtls.fullName;
    personSearchFurtherDtls.birthSurname = personDtls.personBirthName;
    personSearchFurtherDtls.motherSurname = personDtls.motherBirthSurname;
    personSearchFurtherDtls.sex = personDtls.gender;
    personSearchFurtherDtls.dateOfBirth = personDtls.dateOfBirth;
    personSearchFurtherDtls.maritalStatus = personDtls.maritalStatusCode;
    personSearchFurtherDtls.nationality = personDtls.nationalityCode;

    // set the concern role key
    concernRoleKey.concernRoleID = key.concernRoleID;

    // retrieve concern role details
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // set the address key with the concern role primary address key
    addressKey.addressID = concernRoleDtls.primaryAddressID;

    // retrieve address details record for address lines
    addressDtls = addressObj.read(addressKey);

    // set the details with resulting address record
    final OtherAddressData addressDataStr = new OtherAddressData();

    addressDataStr.addressData = addressDtls.addressData;

    addressObj.getLongFormat(addressDataStr);
    personSearchFurtherDtls.formattedAddressData = addressDataStr.addressData;
    personSearchFurtherDtls.addressData = addressDtls.addressData;

    return personSearchFurtherDtls;
  }

  /**
   * @param key search details
   *
   * @return Key for database search
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #calculateKey1()}
   *
   * Calculates the details of the database search key based on the key
   */
  @Override
  @Deprecated
  protected PersonDatabaseSearchKey calculateKey(final PersonSearchKey key)
    throws AppException, InformationalException {

    final PersonDatabaseSearchKey personDatabaseSearchKey =
      new PersonDatabaseSearchKey();

    // Assign the key values
    personDatabaseSearchKey.firstForename = CuramConst.gkSqlWildcard
      + key.forename.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabaseSearchKey.surname = CuramConst.gkSqlWildcard
      + key.surname.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabaseSearchKey.addressLine1 = CuramConst.gkSqlWildcard
      + key.address.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabaseSearchKey.city = CuramConst.gkSqlWildcard
      + key.city.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabaseSearchKey.gender = key.sex;

    personDatabaseSearchKey.dateOfBirth = key.dateOfBirth;

    personDatabaseSearchKey.motherBirthSurname = CuramConst.gkSqlWildcard
      + key.motherSurname.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabaseSearchKey.personBirthname = CuramConst.gkSqlWildcard
      + key.birthSurname.toUpperCase() + CuramConst.gkSqlWildcard;

    // If a parameter is specified set the searchBy indicator for that parameter
    personDatabaseSearchKey.searchByAddressLine1 = key.address.length() > 0;

    personDatabaseSearchKey.searchByCity = key.city.length() > 0;

    personDatabaseSearchKey.searchByDateOfBirth = !key.dateOfBirth.isZero();

    personDatabaseSearchKey.searchByFirstForename = key.forename.length() > 0;

    personDatabaseSearchKey.searchByGender = key.sex.length() > 0;

    personDatabaseSearchKey.searchByMotherBirthName =
      key.motherSurname.length() > 0;

    personDatabaseSearchKey.searchByPersonBirthName =
      key.birthSurname.length() > 0;

    personDatabaseSearchKey.searchBySurname = key.surname.length() > 0;

    return personDatabaseSearchKey;
  }

  // BEGIN CR00077564, PD
  /**
   * @param key search details
   *
   * @return Key for database search
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #calculateKey1()}
   *
   * Calculates the details of the database search key based on the key
   */
  @Override
  @Deprecated
  public PersonDatabasePhoneticEncoderKey calculateSearchKey(
    final PersonSearchKey key) throws AppException, InformationalException {

    final PersonDatabasePhoneticEncoderKey personDatabasePhoneticEncoderKey =
      new PersonDatabasePhoneticEncoderKey();

    final curam.core.intf.PhoneticEncoder phoneticEncoderObj =
      curam.core.fact.PhoneticEncoderFactory.newInstance();
    final PhoneticEncoderKey phoneticEncoderKey = new PhoneticEncoderKey();
    PhoneticEncoderDetails phoneticEncoderDetails =
      new PhoneticEncoderDetails();

    phoneticEncoderKey.surname = key.surname;
    phoneticEncoderDetails = phoneticEncoderObj.encode(phoneticEncoderKey);

    // Assign the key values
    personDatabasePhoneticEncoderKey.firstForename = CuramConst.gkSqlWildcard
      + key.forename.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabasePhoneticEncoderKey.phoneticEncode =
      phoneticEncoderDetails.phoneticEncodingCode;

    personDatabasePhoneticEncoderKey.addressLine1 = CuramConst.gkSqlWildcard
      + key.address.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabasePhoneticEncoderKey.city = CuramConst.gkSqlWildcard
      + key.city.toUpperCase() + CuramConst.gkSqlWildcard;

    personDatabasePhoneticEncoderKey.gender = key.sex;

    personDatabasePhoneticEncoderKey.dateOfBirth = key.dateOfBirth;

    personDatabasePhoneticEncoderKey.motherBirthSurname =
      CuramConst.gkSqlWildcard + key.motherSurname.toUpperCase()
        + CuramConst.gkSqlWildcard;

    personDatabasePhoneticEncoderKey.personBirthname =
      CuramConst.gkSqlWildcard + key.birthSurname.toUpperCase()
        + CuramConst.gkSqlWildcard;

    // If a parameter is specified set the searchBy indicator for that parameter
    personDatabasePhoneticEncoderKey.searchByAddressLine1 =
      key.address.length() > 0;

    personDatabasePhoneticEncoderKey.searchByCity = key.city.length() > 0;

    personDatabasePhoneticEncoderKey.searchByDateOfBirth =
      !key.dateOfBirth.isZero();

    personDatabasePhoneticEncoderKey.searchByFirstForename =
      key.forename.length() > 0;

    personDatabasePhoneticEncoderKey.searchByGender = key.sex.length() > 0;

    personDatabasePhoneticEncoderKey.searchByMotherBirthName =
      key.motherSurname.length() > 0;

    personDatabasePhoneticEncoderKey.searchByPersonBirthName =
      key.birthSurname.length() > 0;

    personDatabasePhoneticEncoderKey.searchByPhoneticEncode =
      personDatabasePhoneticEncoderKey.phoneticEncode.length() > 0;

    return personDatabasePhoneticEncoderKey;
  }

  // END CR00077564, PD

  // BEGIN, CR00077040, PMD
  /**
   * Executes a person search using dynamic SQL
   *
   * @param key search details
   *
   * @return The search results
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected PersonSummaryDetailsList
    readSummaryDetailsByReferenceNumber(final ReadPersonSummaryKey key)
      throws AppException, InformationalException {

    final PersonSummaryDetailsList personSummaryDetailsList =
      new PersonSummaryDetailsList();

    // Build SQL
    final StringBuffer sBuf = new StringBuffer();

    // BEGIN, CR00100692, CR00101058, CR00101307 PDN
    sBuf.append("SELECT AlternateName.firstForename, ");
    sBuf.append("AlternateName.surname, Person.dateOfBirth, ");
    sBuf.append("Person.gender, Person.personBirthName, ");
    sBuf.append("Person.motherBirthSurname, Person.primaryAlternateID, ");
    sBuf.append("Person.concernRoleID, ConcernRole.sensitivity, ");
    sBuf.append("city.elementValue, addressLine1.elementValue, ");
    sBuf.append("ConcernRoleDuplicate.originalConcernRoleID, ");
    sBuf.append("ConcernRoleDuplicate.statusCode ");
    sBuf.append(
      "INTO :firstForename, :surname, :dateOfBirth, :gender, :personBirthName, ");
    sBuf.append(
      ":motherBirthSurname, :primaryAlternateID, :concernRoleID, :sensitivity, ");
    sBuf.append(":city, :addressLine1, :originalConcernRoleID, ");
    sBuf.append(":duplicateStatus ");
    sBuf.append("FROM (Person LEFT OUTER JOIN ConcernRoleDuplicate on ");
    sBuf.append(
      "(ConcernRoleDuplicate.duplicateConcernRoleID=Person.concernRoleID ");
    // BEGIN, CR00157584, AK
    sBuf.append("AND ConcernRoleDuplicate.statusCode=:duplicateStatus)),");
    // END, CR00157584
    sBuf.append("ConcernRole, AlternateName, ");
    sBuf.append("AddressElement city, AddressElement addressLine1 ");

    sBuf.append("WHERE ConcernRole.concernRoleID IN (");
    sBuf.append("SELECT concernRoleID FROM concernRoleAlternateID ");
    // BEGIN,CR00100549,GM
    sBuf.append(
      "WHERE concernRoleAlternateID.alternateID = :primaryAlternateID ");
    // BEGIN, CR00157584, AK
    sBuf.append(
      "AND concernRoleAlternateID.statuscode = :concernRoleStatusCode) ");
    // END, CR00157584, AK
    // END,CR00100549
    sBuf.append("AND Person.concernRoleID = ConcernRole.concernRoleID ");
    sBuf.append(
      "AND Person.primaryAlternateNameID = AlternateName.alternateNameID ");
    sBuf.append("AND (city.addressID = ConcernRole.primaryAddressID ");
    sBuf.append("AND city.elementType = :cityType) ");
    sBuf
      .append("AND (addressLine1.addressID = ConcernRole.primaryAddressID ");
    sBuf.append("AND addressLine1.elementType = :addressLine1Type)");

    // END, CR00100692, CR00101058, CR00101307

    // BEGIN, CR00100608, PDN
    sBuf.append(" ORDER BY primaryAlternateID");
    // END, CR00100608

    // BEGIN, CR00157584, AK
    final ReadPersonSummaryStatusKey keyWithStatus =
      new ReadPersonSummaryStatusKey();

    keyWithStatus.primaryAlternateID = key.primaryAlternateID;
    keyWithStatus.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    keyWithStatus.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;
    ;
    keyWithStatus.duplicateStatus = DUPLICATESTATUS.MARKED;
    keyWithStatus.concernRoleStatusCode =
      curam.codetable.RECORDSTATUS.DEFAULTCODE;
    // Call dynamic SQL API to execute SQL
    // BEGIN, CR00232051, GD
    // BEGIN, CR00290965, IBM
    final CuramValueList<PersonSummaryDetails> curamValueList =
      DynamicDataAccess.executeNsMulti(PersonSummaryDetails.class,
        keyWithStatus, false, true, sBuf.toString());

    // END, CR00290965
    // END, CR00232051
    // END, CR00157584

    for (int i = 0; i < curamValueList.size(); i++) {
      // BEGIN, CR00232051, GD
      personSummaryDetailsList.dtls.addRef(curamValueList.get(i));
      // END, CR00232051
    }

    return personSummaryDetailsList;
  }

  /**
   * Executes a person search using dynamic SQL
   *
   * @param key search details
   *
   * @return The search results
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected PersonSummaryDetailsList
    searchByNameAddressGenderDOBPhoneticEncode(
      final PersonDatabasePhoneticEncoderKey key)
      throws AppException, InformationalException {

    final PersonSummaryDetailsList personSummaryDetailsList =
      new PersonSummaryDetailsList();

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

    // Build SQL
    final StringBuffer sBuf = new StringBuffer();

    // BEGIN, CR00100692, CR00101058, CR00101307 PDN
    sBuf
      .append("SELECT AlternateName.firstForename, AlternateName.surname, ");
    sBuf
      .append("Person.dateOfBirth, Person.gender, Person.personBirthName, ");
    sBuf.append("Person.motherBirthSurname, Person.primaryAlternateID, ");
    sBuf.append("Person.concernRoleID, ConcernRole.sensitivity, ");
    sBuf.append("city.elementValue, addressLine1.elementValue, ");
    sBuf.append("ConcernRoleDuplicate.originalConcernRoleID, ");
    sBuf.append("ConcernRoleDuplicate.statusCode ");
    sBuf.append("INTO :firstForename, :surname, :dateOfBirth, :gender, ");
    sBuf
      .append(":personBirthName, :motherBirthSurname, :primaryAlternateID, ");
    sBuf.append(":concernRoleID, :sensitivity, :city, ");
    sBuf.append(":addressLine1, :originalConcernRoleID, ");
    sBuf.append(":duplicateStatus ");

    sBuf.append("FROM (Person LEFT OUTER JOIN ConcernRoleDuplicate on ");
    sBuf.append(
      "(ConcernRoleDuplicate.duplicateConcernRoleID=Person.concernRoleID ");
    // BEGIN, CR00157584, AK
    sBuf.append("AND ConcernRoleDuplicate.statusCode= :duplicateStatus)),");
    // END, CR00157584
    sBuf.append("ConcernRole, AlternateName, AddressElement city, ");
    sBuf.append("AddressElement addressLine1 ");
    sBuf.append("WHERE ConcernRole.concernRoleID = Person.concernRoleID ");
    sBuf.append("AND AlternateName.concernRoleID = Person.concernRoleID ");
    sBuf.append("AND addressLine1.addressID = ConcernRole.primaryAddressID ");
    sBuf.append("AND addressLine1.elementType = :addressLine1Type ");
    sBuf.append("AND city.addressID = ConcernRole.primaryAddressID ");
    sBuf.append("AND city.elementType = :cityType");
    // END, CR00100692, CR00101058, CR00101307

    if (key.searchByFirstForename) {

      sBuf
        .append(" AND AlternateName.upperFirstForename like :firstForename");
    }

    if (key.searchByPhoneticEncode) {

      sBuf.append(" AND AlternateName.phoneticEncoding = :phoneticEncode");
    }

    if (key.searchByAddressLine1) {

      sBuf.append(" AND addressLine1.upperElementValue like :addressLine1");
    }

    if (key.searchByCity) {

      sBuf.append(" AND city.upperElementValue like :city");
    }

    if (key.searchByGender) {

      sBuf.append(" AND Person.gender = :gender");
    }

    if (key.searchByDateOfBirth) {

      sBuf.append(" AND Person.dateOfBirth = :dateOfBirth");
    }

    if (key.searchByPersonBirthName) {

      sBuf.append(" AND Person.upperPersonBirthName like :personBirthname");
    }

    if (key.searchByMotherBirthName) {

      sBuf.append(
        " AND Person.upperMotherBirthSurname like :motherBirthSurname");
    }

    // BEGIN, CR00100608, PDN
    sBuf.append(" ORDER BY primaryAlternateID");
    // END, CR00100608

    // BEGIN, CR00157584, AK
    final PersonDatabasePhoneticEncoderStatusKey keyWithStatus =
      new PersonDatabasePhoneticEncoderStatusKey();

    keyWithStatus.assign(key);
    keyWithStatus.duplicateStatus = DUPLICATESTATUS.MARKED;
    // Call dynamic SQL API to execute SQL
    // BEGIN, CR00232051, GD
    // BEGIN, CR00290965, IBM
    final CuramValueList<PersonSummaryDetails> curamValueList =
      DynamicDataAccess.executeNsMulti(
        curam.core.struct.PersonSummaryDetails.class, keyWithStatus, false,
        true, sBuf.toString());

    // END, CR00290965
    // END, CR00232051
    // END, CR00157584

    for (int i = 0; i < curamValueList.size(); i++) {
      // BEGIN, CR00232051, GD
      personSummaryDetailsList.dtls.addRef(curamValueList.get(i));
      // END, CR00232051
    }

    return personSummaryDetailsList;
  }

  /**
   * Executes a person search using dynamic SQL
   *
   * @param key search details
   * @return The search results
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected PersonSummaryDetailsList
    searchByNameAddressGenderOrDob(final PersonDatabaseSearchKey key)
      throws AppException, InformationalException {

    final PersonSummaryDetailsList personSummaryDetailsList =
      new PersonSummaryDetailsList();

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

    // Build SQL
    final StringBuffer sBuf = new StringBuffer();

    // BEGIN, CR00100692, CR00101058, CR00101307 PDN
    sBuf.append("SELECT AlternateName.firstForename, ");
    sBuf.append("AlternateName.surname, Person.dateOfBirth, ");
    sBuf.append("Person.gender, Person.personBirthName, ");
    sBuf.append("Person.motherBirthSurname, Person.primaryAlternateID, ");
    sBuf.append("Person.concernRoleID, ConcernRole.sensitivity, ");
    sBuf.append("city.elementValue, addressLine1.elementValue, ");
    sBuf.append("ConcernRoleDuplicate.originalConcernRoleID, ");
    sBuf.append("ConcernRoleDuplicate.statusCode ");

    sBuf.append("INTO :firstForename, :surname, :dateOfBirth, ");
    sBuf.append(":gender, :personBirthName, :motherBirthSurname, ");
    sBuf.append(":primaryAlternateID, :concernRoleID, :sensitivity, ");
    sBuf.append(":city, :addressLine1, :originalConcernRoleID, ");
    sBuf.append(":duplicateStatus ");
    sBuf.append("FROM (Person LEFT OUTER JOIN ConcernRoleDuplicate on ");
    sBuf.append(
      "(ConcernRoleDuplicate.duplicateConcernRoleID=Person.concernRoleID ");
    // BEGIN, CR00157584, AK
    sBuf.append("AND ConcernRoleDuplicate.statusCode= :duplicateStatus)),");
    // END, CR00157584
    sBuf.append("ConcernRole, AlternateName, ");
    sBuf.append("AddressElement city, AddressElement addressLine1 ");

    sBuf.append("WHERE ConcernRole.concernRoleID = Person.concernRoleID ");
    sBuf.append("AND AlternateName.concernRoleID = Person.concernRoleID ");
    sBuf.append("AND addressLine1.addressID = ConcernRole.primaryAddressID ");
    sBuf.append("AND addressLine1.elementType = :addressLine1Type ");
    sBuf.append("AND city.addressID = ConcernRole.primaryAddressID ");
    sBuf.append("AND city.elementType = :cityType");
    // END, CR00100692, CR00101058, CR00101307
    if (key.searchByFirstForename) {

      sBuf
        .append(" AND AlternateName.upperFirstForename like :firstForename");
    }

    if (key.searchBySurname) {

      sBuf.append(" AND AlternateName.upperSurname like :surname");
    }

    if (key.searchByAddressLine1) {

      sBuf.append(" AND addressLine1.upperElementValue like :addressLine1");
    }

    if (key.searchByCity) {

      sBuf.append(" AND city.upperElementValue like :city");
    }

    if (key.searchByGender) {

      sBuf.append(" AND Person.gender = :gender");
    }

    if (key.searchByDateOfBirth) {

      sBuf.append(" AND Person.dateOfBirth = :dateOfBirth");
    }

    if (key.searchByPersonBirthName) {

      sBuf.append(" AND Person.upperPersonBirthName like :personBirthname");
    }

    if (key.searchByMotherBirthName) {

      sBuf.append(
        " AND Person.upperMotherBirthSurname like :motherBirthSurname");
    }

    // BEGIN, CR00100608, PDN
    sBuf.append(" ORDER BY primaryAlternateID");
    // END, CR00100608

    // BEGIN, CR00157584, AK
    final PersonDatabaseSearchWithStatusKey keyWithStatus =
      new PersonDatabaseSearchWithStatusKey();

    keyWithStatus.assign(key);
    keyWithStatus.duplicateStatus = DUPLICATESTATUS.MARKED;

    // Call dynamic SQL API to execute SQL
    // BEGIN, CR00232051, GD
    // BEGIN, CR00290965, IBM
    final CuramValueList<PersonSummaryDetails> curamValueList =
      curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
        curam.core.struct.PersonSummaryDetails.class, keyWithStatus, false,
        true, sBuf.toString());

    // END, CR00290965
    // END, CR00232051
    // END, CR00157584

    // Add the search results to the return list
    for (int i = 0; i < curamValueList.size(); i++) {
      // BEGIN, CR00232051, GD
      personSummaryDetailsList.dtls.addRef(curamValueList.get(i));
      // END, CR00232051
    }

    return personSummaryDetailsList;
  }

  // END, CR00077040

  // BEGIN, CR00218133, ZV
  /**
   * Performs a database search for persons using the specified search criteria.
   *
   * @param key data on which the searched will be based
   *
   * @return The details of any records found.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public PersonSearchResult1 search1(final PersonSearchKey1 key)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    final PersonSearchResult1 personSearchResult = new PersonSearchResult1();

    final PersonDatabaseSearchKey1 personDatabaseSearchKey =
      calculateKey1(key);

    // BEGIN, CR00232051, GD
    CuramValueList<PersonSearchDtls1> curamValueList =
      new CuramValueList<PersonSearchDtls1>(PersonSearchDtls1.class);

    // END, CR00232051

    try {

      // BEGIN, CR00282028, IBM
      // Call dynamic SQL API to execute SQL
      curamValueList = DynamicDataAccess.executeNsMulti(
        PersonSearchDtls1.class, personDatabaseSearchKey, false, true,
        formatSQL(personDatabaseSearchKey).sqlStatement);
      // END, CR00282028

    } catch (final curam.util.exception.ReadmultiMaxException e) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);

      informationalManager.failOperation();
    }

    final DisableLinkIndicatorDetails disableLinkIndicatorDetails =
      new DisableLinkIndicatorDetails();

    disableLinkIndicatorDetails.disableLinkInd = key.disableLinkInd;

    for (int i = 0; i < curamValueList.size(); i++) {

      final PersonSearchDetails personSearchDetails = processSearchDetails(
        curamValueList.get(i), disableLinkIndicatorDetails);

      if (personSearchDetails != null) {
        personSearchResult.dtlsList.addRef(personSearchDetails);
      }
    }

    return personSearchResult;

  }

  /**
   * Calculates the details of the database search key based on the search
   * criteria entered
   *
   * @param key person search criteria
   *
   * @return Key for database search
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected PersonDatabaseSearchKey1 calculateKey1(final PersonSearchKey1 key)
    throws AppException, InformationalException {

    final PersonDatabaseSearchKey1 personDatabaseSearchKey =
      new PersonDatabaseSearchKey1();

    personDatabaseSearchKey.dateOfBirth = key.dateOfBirth;
    personDatabaseSearchKey.gender = key.gender;
    personDatabaseSearchKey.referenceNumber = key.referenceNumber;

    if (key.surname.length() > 0) {

      if (key.soundsLikeInd) {

        // BEGIN, CR00341632, MV
        final PhoneticEncoder phoneticEncoderObj =
          PhoneticEncoderFactory.newInstance();
        // END, CR00341632

        final PhoneticEncoderKey phoneticEncoderKey =
          new PhoneticEncoderKey();
        PhoneticEncoderDetails phoneticEncoderDetails =
          new PhoneticEncoderDetails();

        phoneticEncoderKey.surname = key.surname.toUpperCase();
        phoneticEncoderDetails =
          phoneticEncoderObj.encode(phoneticEncoderKey);

        personDatabaseSearchKey.phoneticEncode =
          phoneticEncoderDetails.phoneticEncodingCode;
        // BEGIN, CR00341632, MV
        if (phoneticEncoderDetails.phoneticEncodingCode.isEmpty()) {
          personDatabaseSearchKey.surname =
            key.surname.toUpperCase() + CuramConst.gkSqlWildcard;
        }
        // END, CR00341632
      } else {
        // BEGIN, CR00338327, ZV
        personDatabaseSearchKey.surname = key.surname.toUpperCase();
        if (personDatabaseSearchKey.surname.length() > 1) {
          personDatabaseSearchKey.surname += CuramConst.gkSqlWildcard;
        }
        // END, CR00338327
      }

    }

    if (key.forename.length() > 0) {
      // BEGIN, CR00338327, ZV
      personDatabaseSearchKey.firstForename = key.forename.toUpperCase();
      if (personDatabaseSearchKey.firstForename.length() > 1
        || !personDatabaseSearchKey.surname.isEmpty()) {
        personDatabaseSearchKey.firstForename += CuramConst.gkSqlWildcard;
      }
      // END, CR00338327
    }

    if (key.birthSurname.length() > 0) {
      // BEGIN, CR00338327, ZV
      personDatabaseSearchKey.birthSurname = key.birthSurname.toUpperCase();
      if (personDatabaseSearchKey.birthSurname.length() > 1) {
        personDatabaseSearchKey.birthSurname += CuramConst.gkSqlWildcard;
      }
      // END, CR00338327
    }

    if (key.forename.length() > 0 && key.nicknameInd) {
      personDatabaseSearchKey.nickname = key.forename.toUpperCase();
    }

    // BEGIN, CR00457404, CR00458133, JAY
    if (!key.addressDtls.addressSearchData.isEmpty()) {
      final curam.core.intf.AddressData addressDataObj =
        curam.core.fact.AddressDataFactory.newInstance();
      OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = key.addressDtls.addressSearchData;
      final AddressMapList addressMapList =
        addressDataObj.parseDataToMap(otherAddressData);

      for (final AddressMap addressMap : addressMapList.dtls) {
        if (addressMap.value.length() > 0) {
          addressMap.value =
            addressMap.value.toUpperCase() + CuramConst.gkSqlWildcard;
        }
      }
      otherAddressData = addressDataObj.parseMapToData(addressMapList);
      personDatabaseSearchKey.addressSearchData =
        otherAddressData.addressData;
    } else {
      if (key.addressDtls.addressLine1.length() > 0) {
        personDatabaseSearchKey.addressLine1 =
          key.addressDtls.addressLine1.toUpperCase()
            + CuramConst.gkSqlWildcard;
      }

      if (key.addressDtls.addressLine2.length() > 0) {
        personDatabaseSearchKey.addressLine2 =
          key.addressDtls.addressLine2.toUpperCase()
            + CuramConst.gkSqlWildcard;
      }

      if (key.addressDtls.city.length() > 0) {
        personDatabaseSearchKey.city =
          key.addressDtls.city.toUpperCase() + CuramConst.gkSqlWildcard;
      }

      personDatabaseSearchKey.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
      personDatabaseSearchKey.addressLine2Type = ADDRESSELEMENTTYPE.LINE2;
      personDatabaseSearchKey.cityType = ADDRESSELEMENTTYPE.CITY;
    }

    personDatabaseSearchKey.recordStatus = RECORDSTATUS.NORMAL;
    personDatabaseSearchKey.duplicateStatus = DUPLICATESTATUS.MARKED;
    // END, CR00457404, CR00458133, JAY
    return personDatabaseSearchKey;
  }

  /**
   * Format SQL select statement for person and prospect person search
   *
   * @param key person search criteria
   *
   * @return SQL select statement for person and prospect person search
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected SQLStatement formatSQL(final PersonDatabaseSearchKey1 key)
    throws AppException, InformationalException {

    final SQLStatement sqlStatement = new SQLStatement();

    final ParticipantSearch participantSearchObj =
      ParticipantSearchFactory.newInstance();
    final SearchCriteriaString searchCriteriaString =
      new SearchCriteriaString();

    String sqlMainSelectStr = new String();
    String sqlSelectStr = new String();
    String sqlIntoStr = new String();
    String sqlPersonFromStr = new String();
    String sqlProspectPersonFromStr = new String();
    String sqlFromStr = new String();
    String sqlWhereStr = new String();
    String sqlPersonWhereStr = new String();
    String sqlProspectPersonWhereStr = new String();
    String sqlSortingStr = new String();

    sqlMainSelectStr = "SELECT dateOfBirth, ";
    sqlMainSelectStr += "primaryConcernRoleName, ";
    sqlMainSelectStr += "primaryAlternateID, ";
    sqlMainSelectStr += "concernRoleID, ";
    sqlMainSelectStr += "concernRoleType, ";
    sqlMainSelectStr += "primaryAddressData, ";
    sqlMainSelectStr += "originalConcernRoleID, ";
    sqlMainSelectStr += "originalConcernRoleName, ";
    sqlMainSelectStr += "originalPrimaryAlternateID ";
    // BEGIN, CR00265086, ZV
    sqlSelectStr = "SELECT DISTINCT dateOfBirth, ";
    // END, CR00265086
    // BEGIN, CR00464801, YF
    // BEGIN, CR00465087, YF
    sqlSelectStr += "ConcernRole.concernRoleName primaryConcernRoleName, ";
    sqlSelectStr += "ConcernRole.primaryAlternateID, ";
    sqlSelectStr += "ConcernRole.concernRoleID, ";
    sqlSelectStr += "ConcernRole.concernRoleType, ";
    sqlSelectStr += "PrimaryAddress.addressData primaryAddressData, ";
    sqlSelectStr += "ConcernRoleDuplicate.originalConcernRoleID, ";
    sqlSelectStr += "Concerndupli.concernRoleName originalConcernRoleName, ";
    sqlSelectStr +=
      "Concerndupli.primaryAlternateID originalPrimaryAlternateID, ";
    sqlSelectStr += "PrimaryName.surname, ";
    sqlSelectStr += "PrimaryName.firstForename ";

    sqlIntoStr = "INTO :dateOfBirth, ";
    sqlIntoStr += ":primaryConcernRoleName, ";
    sqlIntoStr += ":primaryAlternateID, ";
    sqlIntoStr += ":concernRoleID, ";
    sqlIntoStr += ":concernRoleType, ";
    sqlIntoStr += ":primaryAddress, ";
    sqlIntoStr += ":originalConcernRoleID, ";
    sqlIntoStr += ":originalConcernRoleName, ";
    sqlIntoStr += ":originalPrimaryAlternateID ";

    sqlPersonFromStr = "FROM Person, ";

    sqlProspectPersonFromStr = "FROM ProspectPerson, ";

    sqlFromStr = "ConcernRole ";
    sqlFromStr += "LEFT OUTER JOIN ConcernRoleDuplicate ";
    sqlFromStr += "ON (ConcernRoleDuplicate.duplicateConcernRoleID=";
    sqlFromStr += "ConcernRole.concernRoleID ";
    sqlFromStr += "AND ConcernRoleDuplicate.statusCode = :duplicateStatus) ";
    sqlFromStr += "LEFT OUTER JOIN ConcernRole Concerndupli ";
    sqlFromStr += "ON Concerndupli.concernRoleID=";
    sqlFromStr += "ConcernRoleDuplicate.originalConcernRoleID,";
    // END, CR00464801, YF
    // END, CR00465087, YF
    sqlFromStr += "Address PrimaryAddress, ";
    sqlFromStr += "AlternateName PrimaryName ";

    sqlPersonWhereStr = "WHERE ConcernRole.concernRoleID = ";
    sqlPersonWhereStr += "Person.concernRoleID ";
    sqlPersonWhereStr += "AND Person.primaryAlternateNameID = ";
    sqlPersonWhereStr += "PrimaryName.alternateNameID ";

    sqlProspectPersonWhereStr = "WHERE ConcernRole.concernRoleID = ";
    sqlProspectPersonWhereStr += "ProspectPerson.concernRoleID ";
    sqlProspectPersonWhereStr +=
      "AND ProspectPerson.personConcernRoleID IS NULL ";
    sqlProspectPersonWhereStr +=
      "AND ProspectPerson.primaryAlternateNameID = ";
    sqlProspectPersonWhereStr += "PrimaryName.alternateNameID ";

    sqlWhereStr = "AND ConcernRole.primaryAddressID = ";
    sqlWhereStr += "PrimaryAddress.addressID ";

    // Begin,200659,SS

    // sort the SQL query in varying case
    sqlSortingStr =
      "ORDER BY LOWER(surname), LOWER(firstForename), dateofBirth ";

    // End,200659,SS

    if (key.referenceNumber.length() > 0) {

      sqlMainSelectStr += ", alternateID ";
      sqlSelectStr += ", ConcernRoleAlternateID.alternateID ";

      sqlIntoStr += ", :alternateID ";

      sqlFromStr += ", ConcernRoleAlternateID ";

      sqlWhereStr += "AND ConcernRoleAlternateID.concernRoleID = ";
      sqlWhereStr += "ConcernRole.concernRoleID ";
      sqlWhereStr += "AND ConcernRoleAlternateID.alternateID = ";
      sqlWhereStr += ":referenceNumber ";
      sqlWhereStr += "AND ConcernRoleAlternateID.statusCode = :recordStatus ";
    }

    if (key.firstForename.length() > 0 || key.surname.length() > 0
      || key.phoneticEncode.length() > 0) {

      sqlMainSelectStr += ", concernRoleName ";
      sqlSelectStr += ", AlternateName.fullName concernRoleName ";

      sqlIntoStr += ", :concernRoleName ";

      sqlFromStr += ", AlternateName ";

      sqlWhereStr += "AND AlternateName.concernRoleID = ";
      sqlWhereStr += "ConcernRole.concernRoleID ";
      sqlWhereStr += "AND AlternateName.nameStatus = :recordStatus ";

      if (key.firstForename.length() > 0) {
        searchCriteriaString.string = key.firstForename;
        sqlWhereStr += "AND AlternateName.upperFirstForename ";
        sqlWhereStr += participantSearchObj
          .getWildcardSearchOperator(searchCriteriaString).sqlStatement
          + " :firstForename ";
      }

      if (key.surname.length() > 0) {
        searchCriteriaString.string = key.surname;
        sqlWhereStr += "AND AlternateName.upperSurname ";
        sqlWhereStr += participantSearchObj
          .getWildcardSearchOperator(searchCriteriaString).sqlStatement
          + " :surname ";
      }

      if (key.phoneticEncode.length() > 0) {
        sqlWhereStr +=
          "AND AlternateName.phoneticEncoding = :phoneticEncode ";
      }

    }

    // BEGIN, CR00457404, CR00458133, JAY
    if (key.addressLine1.length() > 0 || key.addressLine2.length() > 0
      || key.city.length() > 0 || key.addressSearchData.length() > 0) {

      sqlMainSelectStr += ", addressData ";
      sqlSelectStr += ", Address.addressData ";

      sqlIntoStr += ", :address ";

      sqlFromStr += ", ConcernRoleAddress, Address ";

      sqlWhereStr += "AND ConcernRole.concernRoleID = ";
      sqlWhereStr += "ConcernRoleAddress.concernRoleID ";
      sqlWhereStr += "AND ConcernRoleAddress.addressID = Address.addressID ";
      sqlWhereStr += "AND ConcernRoleAddress.statusCode = :recordStatus ";

      if (!key.addressSearchData.isEmpty()) {
        final curam.core.intf.AddressData addressDataObj =
          curam.core.fact.AddressDataFactory.newInstance();
        final OtherAddressData otherAddressData = new OtherAddressData();

        otherAddressData.addressData = key.addressSearchData;
        final AddressMapList addressMapList =
          addressDataObj.parseDataToMap(otherAddressData);

        for (final AddressMap addressMap : addressMapList.dtls) {
          if (addressMap.value.length() > 0) {
            searchCriteriaString.string = addressMap.value;

            sqlFromStr += ", AddressElement " + addressMap.name + " ";

            sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
            sqlWhereStr += addressMap.name + ".addressID ";
            sqlWhereStr += "AND " + addressMap.name + ".elementType = '"
              + addressMap.name + "'";
            sqlWhereStr += " AND " + addressMap.name + ".upperElementValue ";
            sqlWhereStr += participantSearchObj
              .getWildcardSearchOperator(searchCriteriaString).sqlStatement
              + " '" + addressMap.value + "' ";
          }
        }
      } else {

        if (key.addressLine1.length() > 0) {
          searchCriteriaString.string = key.addressLine1;

          sqlFromStr += ", AddressElement AddressLine1 ";

          sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
          sqlWhereStr += "AddressLine1.addressID ";
          sqlWhereStr += "AND AddressLine1.elementType = :addressLine1Type ";
          sqlWhereStr += "AND AddressLine1.upperElementValue ";
          sqlWhereStr += participantSearchObj
            .getWildcardSearchOperator(searchCriteriaString).sqlStatement
            + " :addressLine1 ";
        }

        if (key.addressLine2.length() > 0) {
          searchCriteriaString.string = key.addressLine2;

          sqlFromStr += ", AddressElement AddressLine2 ";

          sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
          sqlWhereStr += "AddressLine2.addressID ";
          sqlWhereStr += "AND AddressLine2.elementType = :addressLine2Type ";
          sqlWhereStr += "AND AddressLine2.upperElementValue ";
          sqlWhereStr += participantSearchObj
            .getWildcardSearchOperator(searchCriteriaString).sqlStatement
            + " :addressLine2 ";
        }

        if (key.city.length() > 0) {
          searchCriteriaString.string = key.city;

          sqlFromStr += ", AddressElement AddressCity ";

          sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
          sqlWhereStr += "AddressCity.addressID ";
          sqlWhereStr += "AND AddressCity.elementType = :cityType ";
          sqlWhereStr += "AND AddressCity.upperElementValue ";
          sqlWhereStr += participantSearchObj
            .getWildcardSearchOperator(searchCriteriaString).sqlStatement
            + " :city ";
        }
      }
    }
    // END, CR00457404, CR00458133, JAY
    if (key.birthSurname.length() > 0) {
      searchCriteriaString.string = key.birthSurname;
      sqlWhereStr += "AND upperPersonBirthName ";
      sqlWhereStr += participantSearchObj
        .getWildcardSearchOperator(searchCriteriaString).sqlStatement
        + " :birthSurname ";
    }

    if (key.gender.length() > 0) {
      sqlWhereStr += "AND gender = :gender ";
    }

    if (!key.dateOfBirth.isZero()) {
      sqlWhereStr += "AND dateOfBirth = :dateOfBirth ";
    }

    sqlStatement.sqlStatement = sqlMainSelectStr;
    sqlStatement.sqlStatement += sqlIntoStr;
    sqlStatement.sqlStatement += "FROM (";
    sqlStatement.sqlStatement += sqlSelectStr + sqlPersonFromStr + sqlFromStr
      + sqlPersonWhereStr + sqlWhereStr;
    sqlStatement.sqlStatement +=
      " UNION ALL " + sqlSelectStr + sqlProspectPersonFromStr + sqlFromStr
        + sqlProspectPersonWhereStr + sqlWhereStr;
    // BEGIN, CR00253958, ZV
    sqlStatement.sqlStatement += ") Person " + sqlSortingStr;
    // END, CR00253958

    return sqlStatement;
  }

}
