/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.impl;

import com.google.inject.Inject;
import curam.codetable.CASEDECISIONINITREASONCODE;
import curam.codetable.CASEDECISIONRESULTCODE;
import curam.codetable.CASEDECISIONSTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMPONENTDEDUCTIONTYPE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CREDITDEBIT;
import curam.codetable.DEDUCTIONITEMTYPE;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.ILICATEGORY;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.REASSESSMENTPROCMODE;
import curam.codetable.REASSESSMENTRESULT;
import curam.codetable.REASSESSMENT_AMOUNT;
import curam.codetable.RECORDSTATUS;
import curam.codetable.UTILITYDEDUCTIONTYPE;
import curam.codetable.UTILITYPAYMENTSTATUS;
import curam.codetable.impl.REASSESSMENTRESULTEntry;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CachedProductDeliveryFactory;
import curam.core.fact.CachedProductDeliveryPatternInfoFactory;
import curam.core.fact.CaseDecisionFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.DeductionFCGenerationFactory;
import curam.core.fact.DetermineReassessmentAmountTypeFactory;
import curam.core.fact.FCGenerationUtilFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.GenerateFinancialComponentsFactory;
import curam.core.fact.GetOverUnderPaymentResultFactory;
import curam.core.fact.HouseholdBudgetItemFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainCaseDecisionFactory;
import curam.core.fact.ManipulateCaseDecisionsFactory;
import curam.core.fact.NomineeOverUnderPaymentFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProductEligibilityFactory;
import curam.core.fact.ReassessmentAmountInfoFactory;
import curam.core.fact.ReassessmentBalanceInfoFactory;
import curam.core.fact.ReassessmentInfoFactory;
import curam.core.fact.RetrieveCaseFinancialDetailsFactory;
import curam.core.fact.UsersFactory;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CachedProductDelivery;
import curam.core.intf.CachedProductDeliveryPatternInfo;
import curam.core.intf.CaseDeductionItem;
import curam.core.intf.CaseHeader;
import curam.core.intf.DetermineReassessmentAmountType;
import curam.core.intf.FCGenerationUtil;
import curam.core.intf.GenerateFinancialComponents;
import curam.core.intf.HouseholdBudgetItem;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.ManipulateCaseDecisions;
import curam.core.intf.ProductDelivery;
import curam.core.intf.ProductEligibility;
import curam.core.intf.ReassessmentAmountInfo;
import curam.core.intf.ReassessmentBalanceInfo;
import curam.core.intf.RetrieveCaseFinancialDetails;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.intf.ProductDeliveryPlanItemLink;
import curam.core.sl.entity.struct.CaseNomineeIDDtls;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternDtls;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.PlannedItemCaseLinkPlannedItemIDKey;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.fact.CaseStatusModeFactory;
import curam.core.sl.infrastructure.assessment.event.impl.AssessmentEngineEvent;
import curam.core.sl.infrastructure.assessment.fact.CREOLECaseDecisionFactory;
import curam.core.sl.infrastructure.assessment.fact.CREOLECaseDeterminationFactory;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineEntity;
import curam.core.sl.infrastructure.assessment.impl.BreakdownInfo;
import curam.core.sl.infrastructure.assessment.impl.BreakdownInfoDAO;
import curam.core.sl.infrastructure.assessment.impl.OverUnderPaymentBreakdown;
import curam.core.sl.infrastructure.assessment.impl.OverUnderPaymentBreakdownDAO;
import curam.core.sl.infrastructure.assessment.impl.ReassessEligibilityHook;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDecisionDtls;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDecisionDtlsList;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDecisionKey;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDeterminationDtls;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDeterminationDtlsList;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDeterminationKey;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.struct.CaseNomineeCaseIDKey;
import curam.core.sl.struct.CaseNomineeDetailsList;
import curam.core.sl.struct.CaseStatusModeDetails;
import curam.core.struct.*;
import curam.message.BPOCASEREASSESSMENT;
import curam.message.BPOREFLECTION;
import curam.piwrapper.casemanager.impl.NomineeOverUnderPayment;
import curam.piwrapper.casemanager.impl.NomineeOverUnderPaymentDAO;
import curam.piwrapper.casemanager.impl.OverUnderPaymentHeaderDAO;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemModifyActualCostDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.jmx.mbeans.assessmentenginestats.impl.AssessmentEngineStats;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Implements Case Reassessment processing for the GenerateFinancialComponents
 * BPO in the situation where there are retrospective changes. This handles the
 * complexity of generating reassessed bills/payments, comparing them with the
 * actuals, and if necessary storing the results for viewing on the Curam
 * client.
 */
public abstract class CaseReassessment
    extends curam.core.base.CaseReassessment {

  // BEGIN, 187871, dmorton
  final String kReassessFinancialComponentsStatIdentifier = "CaseReassessment.reassessFCs";
  // END, 187871

  // BEGIN, 178020, CSH
  /**
   * Indicates a no change reassessment during calculations of actual amount.
   */
  boolean isNoChangeReassessment = false;

  /**
   * Indicates a result of zero during calculations of actual amount.
   */
  boolean totalActualAmountZero = false;

  // END, 178020

  // BEGIN, CR00142853, KH
  /**
   * The minimum size for a list of dates.
   */
  protected static final int kDateListMinumumSize = 2;

  /**
   * Holds a value used in percentage calculations..
   */
  protected static final int kOneHundred = 100;

  /**
   * One list element.
   */
  protected static final int kOneElement = 1;

  /**
   * Holds the cover period to date of the previous reassessment period.
   */
  protected Date previousCoverPeriodTo = Date.kZeroDate;

  /**
   * Holds the latest cover period to date of the actuals.
   */
  Date maxCoverPeriodTo = Date.kZeroDate;

  /**
   * Indicates that the maxCoverPeriodTo date was used during the reassessment.
   */
  boolean maxCoverPeriodToAddedToList = false;

  /**
   * Holds the earliest cover period from date of the actuals.
   */
  Date minCoverPeriodFrom = Date.kZeroDate;

  /**
   * Holds the latest component date list value date + 1 day.
   */
  Date finalComponentDateListDate = Date.kZeroDate;

  /**
   * Holds the date of the earliest decision.
   */
  Date tempEarliestDecisionDate = Date.kZeroDate;

  /**
   * Holds the date of the current decision.
   */
  Date tempNewDecisionDate = Date.kZeroDate;

  // BEGIN, CR00148989, KH
  /**
   * The nearest anchor date to the current date. This is stored so that we
   * don't have to start from the CaseHeader.effectiveDate when checking for
   * subsequent anchor dates.
   */
  protected Date mostRecentAnchorDate = Date.kZeroDate;

  // END, CR00148989

  /**
   * Indicates that the actuals for a specified cover period have been
   * considered as part of a reassessment run. Setting this flag to true/false
   * determines if the reassessed amounts for the same period need to be
   * considered or not. The flag would be set to false in the instance where the
   * period has already been considered. Processing the same period twice would
   * lead to incorrect reassessment amounts.
   */
  boolean actualsProcessed = true;

  /**
   * Indicates that more than one objective was used during the reassessment
   * period.
   */
  boolean multipleObjectiveInd = false;

  /**
   * Indicates that we have adjusted our current actual amount during the
   * reassessment period.
   */
  boolean actualAmountAdjustedInd = false;

  // BEGIN, CR00180474, VM
  protected boolean stmtOverlapsWithAssessPeriod = false;

  protected boolean reassessToCreateNewDecisions = false;

  // END, CR00180474

  // BEGIN, CR00192183, KH
  @Inject
  protected NomineeOverUnderPaymentDAO nomineeOverUnderPaymentDAO;

  // END, CR00192183

  // BEGIN, CR00189520, CSH
  @Inject
  protected OverUnderPaymentBreakdownDAO overUnderPaymentBreakdownDAO;

  // BEGIN, 178020, CSH
  @Inject
  protected BreakdownInfoDAO breakdownInfoDAO;

  // END, 178020

  // BEGIN, 179623, BD
  @Inject
  protected OverUnderPaymentHeaderDAO overUnderPaymentHeaderDAO;

  // END, 179623

  // BEGIN, CR00211744, VM
  @Inject
  protected EventDispatcherFactory<AssessmentEngineEvent> assessmentEngineEvent;

  @Inject
  protected AssessmentEngine assessmentEngine;

  // END, CR00211744

  @Inject
  protected AssessmentEngineEntity assessmentEngineEntity;

  // BEGIN, CR00354770, KH
  @Inject
  protected ReassessEligibilityHook reassessEligibilityHook;

  // END, CR00354770

  // ___________________________________________________________________________
  /**
   * Add injection.
   */
  public CaseReassessment() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00189520

  public static class CREOLECaseDeterminationComparator
      implements Comparator<CREOLECaseDeterminationDtls> {

    public CREOLECaseDeterminationComparator() {

      super();
    }

    @Override
    public int compare(final CREOLECaseDeterminationDtls o1,
        final CREOLECaseDeterminationDtls o2) {

      return -1 * o1.determinationDateTime.compareTo(o2.determinationDateTime);
    }
  }

  /**
   * Comparator used to order structs in a list by component from date.
   */
  public class ComponentDetailsComparator
      implements Comparator<ComponentDetails> {

    /**
     * Default constructor.
     */
    public ComponentDetailsComparator() {

      super();
    }

    /**
     * Compare two compDetails structs.
     */
    @Override
    public int compare(final ComponentDetails o1, final ComponentDetails o2) {

      return o1.fromDate.compareTo(o2.fromDate);
    }
  }

  /**
   * Comparator used to order structs in a list by date.
   */
  public class DateStructComparator implements Comparator<DateStruct> {

    /**
     * Default constructor.
     */
    public DateStructComparator() {

      super();
    }

    /**
     * Compare two dateStructs.
     */
    @Override
    public int compare(final DateStruct o1, final DateStruct o2) {

      return o1.date.compareTo(o2.date);
    }
  }

  // BEGIN, 178020, CSH
  /**
   * Comparator used to order structs in a list by reassessment payment from
   * date.
   */
  public class ReassessCaseDetailsComparator
      implements Comparator<ReassessCaseDetails> {

    /**
     * Default constructor.
     */
    public ReassessCaseDetailsComparator() {

      super();
    }

    /**
     * Compare two ReassessCaseDetails structs.
     */
    @Override
    public int compare(final ReassessCaseDetails o1,
        final ReassessCaseDetails o2) {

      return o1.coverPeriodFrom.compareTo(o2.coverPeriodFrom);
    }
  }

  // END, 178020

  // ___________________________________________________________________________
  /**
   * After product eligibility has been reassessed, this method takes the new
   * decisions and components and regenerates the appropriate FC. Reassessment
   * /Reconciliation and Over/Under payment processing is also performed if
   * required.
   *
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          A structure which aggregates a list of existing decisions and
   *          their associated components.
   * @param reassessmentMode
   *          the mode to run in
   * @param overUnderPaymentIn
   *          over/under payment details
   * @param storeDecisionsInd
   *          Indicates if the list of new decisions which are passed in to this
   *          method should be stored.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void reassessFCs(CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions,
      final ReassessmentMode reassessmentMode,
      final OverUnderPaymentIn overUnderPaymentIn,
      final StoreDecisionsInd storeDecisionsInd)
      throws AppException, InformationalException {

    // BEGIN, 187871, dmorton
    final long startTime = System.currentTimeMillis();
    // END, 187871

    // CaseHeader manipulation variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // CachedCaseHeader manipulation variable
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();

    // CachedProductDelivery manipulation variable
    final CachedProductDelivery cachedProductDeliveryObj = CachedProductDeliveryFactory
        .newInstance();

    // ProductDelivery manipulation variables
    ProductDeliveryDtls productDeliveryDtls;
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // getReassessmentDetailsResult variable
    GetReassessmentDetailsResult getReassessmentDetailsResult = new GetReassessmentDetailsResult();

    // ReassessmentBalanceInfo manipulation variables
    final ReassessmentBalanceInfo reassessmentBalanceInfoObj = ReassessmentBalanceInfoFactory
        .newInstance();
    final ReadmultiBalanceKey readmultiBalanceKey = new ReadmultiBalanceKey();
    ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList;

    final ProductDelivery productDeliveryObj = ProductDeliveryFactory
        .newInstance();

    // ProductEligibility manipulation variable
    final ProductEligibility productEligibiltyObj = ProductEligibilityFactory
        .newInstance();
    final DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();

    // ManipulateCaseDecision entity
    final ManipulateCaseDecisions manipulateCaseDecisionsObj = ManipulateCaseDecisionsFactory
        .newInstance();

    // indicates whether there has been a reassessment prior to this one.
    boolean previousReassessment = true;

    // indicates that the current reassessment period is outside a previous
    // period.
    boolean periodChanged = false;

    // Stores the current (or proposed) under/over payment amount
    Money currentReassessmentAmount = Money.kZeroMoney;

    // indicates whether the reassessment result has been determined.
    boolean reassessed = false;

    final GenerateFinancialComponents generateFinancialComponentsObj = GenerateFinancialComponentsFactory
        .newInstance();

    ComponentDetailsList componentDetailsList;
    final ComponentDetailsList futureComponentDetailsList = new ComponentDetailsList();
    final ComponentDetailsList pastComponentDetailsList = new ComponentDetailsList();

    final FCGenerationUtil fcGenerationUtilObj = FCGenerationUtilFactory
        .newInstance();

    // store the earliest decision date
    for (int i = 0; i < existingCaseDecisions.dtls.size(); i++) {

      if (existingCaseDecisions.dtls.item(i).details.decisionFromDate.before(
          tempEarliestDecisionDate) || tempEarliestDecisionDate.isZero()) {

        tempEarliestDecisionDate = existingCaseDecisions.dtls
            .item(i).details.decisionFromDate;
      }
    }

    for (int i = 0; i < newCaseDecisions.dtls.size(); i++) {

      // BEGIN, CR00021388, CB
      if (newCaseDecisions.dtls.item(i).details.decisionFromDate
          .before(tempNewDecisionDate) || tempNewDecisionDate.isZero()) {
        // END, CR00021388

        tempNewDecisionDate = newCaseDecisions.dtls
            .item(i).details.decisionFromDate;
      }
    }

    // BEGIN, CR00174460, KH
    // Need to check the case status here. If it's 'Suspended', a notification
    // must be sent to the case owner informing them that reassessment could
    // not be carried out on the case as it has a status of 'Suspended'. But we
    // will still store any new decisions so they are available for the case
    // workers even though the case is suspended.
    final CaseStatusModeDetails caseStatusModeDetails = CaseStatusModeFactory
        .newInstance().getMode();

    // BEGIN, CR00161231, KH
    if (storeDecisionsInd.storeDecisionsInd) {
      manipulateCaseDecisionsObj.store(newCaseDecisions, existingCaseDecisions);
      storeDecisionsInd.storeDecisionsInd = false;
    } else {
      if (caseStatusModeDetails.caseIsBeingSuspended) {
        final CheckForInvalidatedPaymentsResult result = checkForReplacementPayment(
            overUnderPaymentIn);

        overUnderPaymentIn.invalidatedPmtExistsInd = result.invalidatedPmtExistsInd;
        overUnderPaymentIn.relatedCaseExistsInd = result.relatedCaseExistsInd;
      }
    }
    // END, CR00161231, CR00174460

    // Check the case status - this is the status of the case just before
    // reassessment was kicked off.
    if (caseStatusModeDetails.caseIsSuspendedInd) {

      final ReassessmentNotificationDetails reassessmentNotificationDetails = new ReassessmentNotificationDetails();

      reassessmentNotificationDetails.caseID = overUnderPaymentIn.caseID;

      // Send notification
      sendNotification(reassessmentNotificationDetails);
      return;
    }

    if (!newCaseDecisions.dtls.isEmpty()) {
      // Set caseID as this is required in FCGenerationUtil::generateFutureFCs
      overUnderPaymentIn.caseID = newCaseDecisions.dtls.item(0).details.caseID;
    }

    // BEGIN, CR00354770, KH
    /*
     * Call out to the hook point to see if we should stop processing at this
     * point or continue with the financial calculations.
     */
    if (reassessEligibilityHook.stopFinancialProcessing(overUnderPaymentIn,
        newCaseDecisions, existingCaseDecisions)) {
      return; // The hook has told us to stop now
    }
    // END, CR00354770

    // BEGIN, CR00361058, KH
    /*
     * Call out to the hook point to see if the list of new decisions should be
     * filtered or altered before they're used in the reconciliation process.
     */
    newCaseDecisions = reassessEligibilityHook.filterNewCaseDecisions(
        overUnderPaymentIn, newCaseDecisions, existingCaseDecisions);
    // END, CR00361058

    componentDetailsList = generateFinancialComponentsObj
        .createComponentsListfromCaseDecisionSet(newCaseDecisions);

    // Call function to examine virtual financial components. Based on this
    // examination it may be necessary to re-start assessment of the case. The
    // from / to dates used in the re-start are the 'final' assessment dates
    // passed into reassessFCs.
    if (restartProcessingBasedOnComponentDetails(componentDetailsList)) {

      productEligibiltyObj.clearInReassessmentFlag();

      // BEGIN, CR00211744, CR00243401, VM
      assessmentEngine.reassessEligibility(determineEligibilityKey, false);
      // END, CR00211744, CR00243401
      return;
    }

    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {
      final ComponentDetails currentComponentDetails = componentDetailsList.dtls
          .item(i);

      // if the component is wholly in the past then we need to reassess it
      // if the reassessment engine was invoked without payments having been
      // made on the case, then it's possible for the toDate of a component to
      // be null. An example of where this could happen is if the case was
      // suspended just after being activated. In this instance, we do not
      // want to create past/future components.
      if (!currentComponentDetails.toDate.isZero()) {

        if (!currentComponentDetails.toDate
            .after(currentComponentDetails.lastPaidToDate)) {
          // BEGIN, CR00103515, BD
          pastComponentDetailsList.dtls.addRef(currentComponentDetails);
          // END, CR00103515

          // else if the component is wholly in the future then we only need to
          // regenerate the financials
        } else if (currentComponentDetails.fromDate
            .after(currentComponentDetails.lastPaidToDate)) {
          // BEGIN, CR00103515, BD
          futureComponentDetailsList.dtls.addRef(currentComponentDetails);
          // END, CR00103515

          // otherwise the component needs to be split into future and past
          // components
        } else {

          final ComponentDetails futureComponentDetails = new ComponentDetails();
          final ComponentDetails pastComponentDetails = new ComponentDetails();

          // copy the current details into both structures
          futureComponentDetails.assign(currentComponentDetails);
          pastComponentDetails.assign(currentComponentDetails);

          // amend the to date of the past component
          pastComponentDetails.toDate = pastComponentDetails.lastPaidToDate;

          // amend the from date of the future component
          futureComponentDetails.fromDate = futureComponentDetails.lastPaidToDate
              .addDays(1);

          // add the details to both lists
          // BEGIN, CR00103515, BD
          pastComponentDetailsList.dtls.addRef(pastComponentDetails);
          futureComponentDetailsList.dtls.addRef(futureComponentDetails);
          // END, CR00103515
        }
        // BEGIN, CR00203241, VM
      } else { // the code below caters for open-ended cases

        if (currentComponentDetails.fromDate
            .after(currentComponentDetails.lastPaidToDate)) {

          futureComponentDetailsList.dtls.addRef(currentComponentDetails);

          // otherwise the component needs to be split into future and past
          // components
        } else {
          final ComponentDetails futureComponentDetails = new ComponentDetails();
          final ComponentDetails pastComponentDetails = new ComponentDetails();

          // copy the current details into both structures
          futureComponentDetails.assign(currentComponentDetails);
          pastComponentDetails.assign(currentComponentDetails);

          // amend the to date of the past component
          pastComponentDetails.toDate = pastComponentDetails.lastPaidToDate;

          // amend the from date of the future component
          futureComponentDetails.fromDate = futureComponentDetails.lastPaidToDate
              .addDays(1);

          // add the details to both lists
          pastComponentDetailsList.dtls.addRef(pastComponentDetails);
          futureComponentDetailsList.dtls.addRef(futureComponentDetails);
        }
      }
      // END, CR00203241
    }

    // calculate the earliest from date and latest to date for each list
    calculateEarliestFromDateAndLatestToDate(pastComponentDetailsList);
    calculateEarliestFromDateAndLatestToDate(futureComponentDetailsList);
    calculateEarliestFromDateAndLatestToDate(componentDetailsList);

    // BEGIN, CR00242165, KH
    // if the start date from the date list is before the
    // overUnderPaymentIn.fromDate or the end date from the date list is after
    // the overUnderPaymentIn.toDate then decisions need to be added (to both
    // lists) from the database. If the overUnderPaymentIn.toDate is NULL then
    // we don't need to extend the period forward.
    if (!componentDetailsList.componentListSummary.earliestFromDate.isZero()
        && (componentDetailsList.componentListSummary.earliestFromDate
            .before(overUnderPaymentIn.fromDate)
            || componentDetailsList.componentListSummary.latestToDate
                .after(overUnderPaymentIn.toDate)
                && !overUnderPaymentIn.toDate.isZero())) {
      // END, CR00242165

      if (componentDetailsList.componentListSummary.earliestFromDate
          .before(overUnderPaymentIn.fromDate)
          && !componentDetailsList.componentListSummary.earliestFromDate
              .isZero()) {

        overUnderPaymentIn.fromDate = componentDetailsList.componentListSummary.earliestFromDate;
      }

      if (componentDetailsList.componentListSummary.latestToDate
          .after(overUnderPaymentIn.toDate)
          && !componentDetailsList.componentListSummary.latestToDate.isZero()) {

        overUnderPaymentIn.toDate = componentDetailsList.componentListSummary.latestToDate;
      }

      if (changePeriod(newCaseDecisions, existingCaseDecisions,
          reassessmentMode, overUnderPaymentIn, storeDecisionsInd)) {

        /*
         * Stop now, the reassessment will have already been processed inside
         * 'changePeriod' if it has returned 'true'.
         */
        return;
      }
    }

    // Set key to read product delivery
    productDeliveryKey.caseID = overUnderPaymentIn.caseID;
    boolean futureFCGenOK = false;

    // Check to see if the Product is certifiable or not
    final CertifiableInd certifiableInd = productDeliveryObj
        .readProductCertifiableInd(productDeliveryKey);

    if (certifiableInd.certifiableInd) {

      futureFCGenOK = fcGenerationUtilObj.generateFutureFCs(
          futureComponentDetailsList, reassessmentMode, overUnderPaymentIn);

    } else {
      futureFCGenOK = fcGenerationUtilObj.generateNonCertifiableProductFCs(
          futureComponentDetailsList, reassessmentMode, overUnderPaymentIn);
    }

    // The period of the reassessment needs to be expanded to cover the
    // entirety of any FC's which overlap into the period
    if (!futureFCGenOK) {

      if (changePeriod(newCaseDecisions, existingCaseDecisions,
          reassessmentMode, overUnderPaymentIn, storeDecisionsInd)) {

        /*
         * Stop now, the reassessment will have already been processed inside
         * 'changePeriod' if it has returned 'true'.
         */
        return;
      }
    }

    final RetrieveCaseFinancialsKey retrieveCaseFinancialsKey = new RetrieveCaseFinancialsKey();
    ReassessCaseDetailsList reassessCaseDetailsList;

    // Get processed financial for period from OverUnderPaymentIn.fromDate to
    // OverUnderPaymentIn.toDate if we did not find anything return, else
    // continue processing
    if (!newCaseDecisions.dtls.isEmpty()) {
      retrieveCaseFinancialsKey.caseID = newCaseDecisions.dtls
          .item(0).details.caseID;
    }
    retrieveCaseFinancialsKey.periodFromDate = overUnderPaymentIn.fromDate;
    retrieveCaseFinancialsKey.periodToDate = overUnderPaymentIn.toDate;

    // BEGIN, CR00211744, VM
    reassessCaseDetailsList = assessmentEngine
        .retrieveCaseFinancials(retrieveCaseFinancialsKey);
    // END, CR00211744

    // BEGIN, 178020, CSH
    // It is possible that previous payment(s) were cancelled
    // and regenerated so check for replacement payments
    final CheckForInvalidatedPaymentsResult repPmtResult = checkForReplacementPayment(
        overUnderPaymentIn);

    // BEGIN, 179623, BD
    overUnderPaymentIn.invalidatedPmtExistsInd = repPmtResult.invalidatedPmtExistsInd;
    overUnderPaymentIn.relatedCaseExistsInd = repPmtResult.relatedCaseExistsInd;
    // END, 179623

    boolean reassessReplacementPaymentRelatedCase = true;

    if (repPmtResult.invalidatedPmtExistsInd
        && repPmtResult.relatedCaseExistsInd) {

      // Check if any replacement payments are now ineligible
      // and therefore require reassessing
      reassessReplacementPaymentRelatedCase = checkForIneligibleReplacementPayment(
          overUnderPaymentIn);
    }

    // BEGIN, 187871, dmorton
    AssessmentEngineStats.addFinancialComponentStatistics(
        kReassessFinancialComponentsStatIdentifier,
        System.currentTimeMillis() - startTime);
    // END, 187871

    // if there are no past components, and no payments have been issued for
    // the period we don't need to proceed
    // and replacement payments are still eligible
    // OR we're dealing with non-certifiable products
    if (pastComponentDetailsList.dtls.isEmpty()
        && reassessCaseDetailsList.dtls.isEmpty()
        && !reassessReplacementPaymentRelatedCase
        || !certifiableInd.certifiableInd) {

      return;
    }
    // END, 178020

    if (!newCaseDecisions.dtls.isEmpty()) {

      // set key to read caseHeader
      caseHeaderKey.caseID = newCaseDecisions.dtls.item(0).details.caseID;

      // read caseHeader
      caseHeaderDtls = cachedCaseHeaderObj.read(caseHeaderKey);

      // set key to read caseHeader
      productDeliveryKey.caseID = caseHeaderKey.caseID;

      // read productDelivery
      productDeliveryDtls = cachedProductDeliveryObj.read(productDeliveryKey);

      overUnderPaymentIn.productID = productDeliveryDtls.productID;
      overUnderPaymentIn.primaryClientID = caseHeaderDtls.concernRoleID;
    } else {
      caseHeaderKey.caseID = overUnderPaymentIn.caseID;
    }

    // get the details of the reassessment
    getReassessmentDetailsResult = getReassessmentDetails(overUnderPaymentIn,
        pastComponentDetailsList, newCaseDecisions, existingCaseDecisions,
        reassessmentMode, reassessCaseDetailsList);

    // BEGIN, 178020, CSH
    // Track the reassessment details, if any, that existed before the current
    // reassessment results are stored. These will be used later when
    // determining if any results relating to replacement payment periods
    // need to be filled in.
    final CaseNomineeCaseIDKey nomKey = new CaseNomineeCaseIDKey();
    nomKey.caseNomineeCaseIDKey.caseID = overUnderPaymentIn.caseID;

    final CaseNomineeDetailsList nominees = CaseNomineeFactory.newInstance()
        .listCaseNominee(nomKey);

    final ReassessmentBalanceInfoDtlsList prevReassessmentBalanceInfoDtlsList = getReassessmentBalanceInfoForNominees(
        nominees);
    // END, 178020

    if (getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
        .size() > 0) {

      for (int j = 0; j < getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
          .size(); j++) {

        getReassessmentDetailsResult.beneficiaryDetails.caseNomineeID = getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).nomineeOverUnderPaymentDtls.caseNomineeID;

        readmultiBalanceKey.caseNomineeID = getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).nomineeOverUnderPaymentDtls.caseNomineeID;

        reassessmentBalanceInfoDtlsList = reassessmentBalanceInfoObj
            .searchReassessmentsForNominee(readmultiBalanceKey);

        // BEGIN, CR00161641, KH
        final GetReassessmentPeriodsKey getReassessmentPeriodsKey = new GetReassessmentPeriodsKey();

        // Indicates if any of the previous reassessments overlap with the
        // current reassessment period
        stmtOverlapsWithAssessPeriod = false;

        for (int i = 0; i < reassessmentBalanceInfoDtlsList.dtls.size(); i++) {

          // BEGIN, CR00211744, VM
          final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

          caseNomineeKey.caseNomineeID = reassessmentBalanceInfoDtlsList.dtls
              .item(i).caseNomineeID;

          final NomineeOverUnderPaymentDtlsList list = assessmentEngineEntity
              .getOverUnderPaymentsByCaseNomineeID(caseNomineeKey);
          // END, CR00211744

          for (int m = 0; m < list.dtls.size(); m++) {

            if (list.dtls.item(m).coverPeriodFrom.equals(
                reassessmentBalanceInfoDtlsList.dtls.item(i).coverPeriodFrom)
                && list.dtls.item(m).coverPeriodTo
                    .equals(reassessmentBalanceInfoDtlsList.dtls
                        .item(i).coverPeriodTo)) {

              // Get the cover period of the previous reassessment
              getReassessmentPeriodsKey.nomineeOverUnderPaymentID = list.dtls
                  .item(m).nomineeOverUnderPaymentID;

              final GetReassessmentPeriodsResult result = GetOverUnderPaymentResultFactory
                  .newInstance()
                  .getReassessmentPeriods(getReassessmentPeriodsKey);

              if (!result.dtlsList.dtls.isEmpty()) {

                // BEGIN, CR00166814, CR00203241, CR00269418, KH, VM
                if ((!result.dtlsList.dtls.item(0).fromDate
                    .after(overUnderPaymentIn.toDate)
                    || overUnderPaymentIn.toDate.isZero())
                    && !result.dtlsList.dtls
                        .item(result.dtlsList.dtls.size() - 1).toDate
                            .before(overUnderPaymentIn.fromDate)) {
                  // END, CR00269418

                  stmtOverlapsWithAssessPeriod = true;
                  break; // from m loop
                }

                // BEGIN, CR00211893, KH
                /*
                 * Also consider previous reassessments which are adjacent and
                 * after the current reassessment. Earlier adjacent
                 * reassessments will be identified by the decision traversal
                 * functionality.
                 */
                if (overUnderPaymentIn.toDate.addDays(1)
                    .equals(result.dtlsList.dtls.item(0).fromDate)) {

                  stmtOverlapsWithAssessPeriod = true;
                  break; // from m loop
                }
                // END, CR00211893, CR00166814, CR00203241
              } // end if !result.dtlsList.dtls.isEmpty()
            }
          } // end for m

          // BEGIN, CR00200778, KH
          // Once we find one overlap we can skip the rest
          if (stmtOverlapsWithAssessPeriod) {
            break; // from i loop
          }
          // END, CR00200778
        } // end for i
        // END, CR00161641

        if (!reassessmentBalanceInfoDtlsList.dtls.isEmpty()
            && stmtOverlapsWithAssessPeriod) {

          // Resetting the previousReassessment flag to true. This may have
          // been set to false for a previous nominee in the nominee header
          // list if the reassessmentBalanceInfoDtlsList was empty for that
          // nominee - see the else part of this statement
          previousReassessment = true;

          int k;

          // for every previous reassessment record we keep reading for their
          // cover periods to see if they are any different to the period we are
          // reassessing.
          for (k = 0; k < reassessmentBalanceInfoDtlsList.dtls.size(); k++) {
            if (reassessmentBalanceInfoDtlsList.dtls.item(k).coverPeriodFrom
                .before(overUnderPaymentIn.fromDate)) {

              // the periods are different, we must expand the reassessment
              // period.
              overUnderPaymentIn.fromDate = reassessmentBalanceInfoDtlsList.dtls
                  .item(k).coverPeriodFrom;

              periodChanged = true;
            }

            // BEGIN, CR00203241, VM
            if (reassessmentBalanceInfoDtlsList.dtls.item(k).coverPeriodTo
                .after(overUnderPaymentIn.toDate)
                && !overUnderPaymentIn.toDate.isZero()) {
              // END, CR00203241

              // the periods are different, we must expand the reassessment
              // period.
              overUnderPaymentIn.toDate = reassessmentBalanceInfoDtlsList.dtls
                  .item(k).coverPeriodTo;

              periodChanged = true;
            }
          }

          // If period was changed
          if (periodChanged) {
            // BEGIN, CR00251296, KH
            // Check if it is necessary to extend reassessment period
            if (changePeriod(newCaseDecisions, existingCaseDecisions,
                reassessmentMode, overUnderPaymentIn, storeDecisionsInd)) {

              /*
               * Stop now, the reassessment will have already been processed
               * inside 'changePeriod' if it has returned 'true'.
               */
              return;
            }
            // END, CR00251296
          }

        } else {

          previousReassessment = false;
        }

        if (previousReassessment) {

          for (int l = 0; l < reassessmentBalanceInfoDtlsList.dtls
              .size(); l++) {

            // re-set the reassessed flag
            reassessed = false;

            // If this is a reassessment of a reassessment get
            // the total under or over payment amount
            currentReassessmentAmount = getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentSummaryDetails.totalAmount;

            // currently the system thinks we're dealing with an underpayment
            if (getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentSummaryDetails.reassessmentResultType
                    .equals(REASSESSMENTRESULT.UNDERPAYMENT)
                && !reassessed) {

              if (reassessmentBalanceInfoDtlsList.dtls.item(l).amountType
                  .equals(REASSESSMENTRESULT.UNDERPAYMENT) && !reassessed) {

                // if the last reassessment was an underpayment and the
                // current reassessment is also for an underpayment and the
                // last reassessment amount is greater than the current
                // reassessment amount, we must subtract the current
                // reassessment from the last reassessment amount. e.g. we
                // previously underpaid by 100, and should have underpaid by
                // 80, therefore we need to OVERPAY by 20 (100-80)
                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(l).reassessmentAmount
                        .getValue() > currentReassessmentAmount.getValue()
                    && !reassessed) {

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.totalAmount = new Money(
                              reassessmentBalanceInfoDtlsList.dtls
                                  .item(l).reassessmentAmount.getValue()
                                  - currentReassessmentAmount.getValue());

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                              reassessmentBalanceInfoDtlsList.dtls
                                  .item(l).reassessmentAmount.getValue()
                                  - currentReassessmentAmount.getValue());

                  // this is an overpayment
                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

                  reassessed = true;

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
                }

                // if the last reassessment was an underpayment and the
                // current reassessment is also for an underpayment and the
                // last reassessment amount is less than the current
                // reassessment amount, we must subtract the last reassessment
                // from the current reassessment amount. e.g. we previously
                // underpaid by 100, and should have underpaid by 120,
                // therefore we need to UNDERPAY by 20 (120-100)
                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(l).reassessmentAmount
                        .getValue() < currentReassessmentAmount.getValue()
                    && !reassessed) {

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.totalAmount = new Money(
                              currentReassessmentAmount.getValue()
                                  - reassessmentBalanceInfoDtlsList.dtls
                                      .item(l).reassessmentAmount.getValue());

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                              currentReassessmentAmount.getValue()
                                  - reassessmentBalanceInfoDtlsList.dtls
                                      .item(l).reassessmentAmount.getValue());

                  // this is an underpayment
                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

                  reassessed = true;

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
                }

                // if the last reassessment was an underpayment and the
                // current reassessment is also for an underpayment and the
                // last reassessment amount is equal to the current
                // reassessment amount, there has been NO CHANGE.
                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(l).reassessmentAmount
                        .getValue() == currentReassessmentAmount.getValue()
                    && !reassessed) {

                  // there has been no change
                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

                  reassessed = true;

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;
                }
              }

              if (reassessmentBalanceInfoDtlsList.dtls.item(l).amountType
                  .equals(REASSESSMENTRESULT.OVERPAYMENT) && !reassessed) {

                // In all three scenarios when going from an overpayment to an
                // underpayment we do the same thing i.e. we always add the
                // reassessed amounts together for the new reassessed amount
                // of the overpayment.

                // 1.
                // If the last reassessment amount is greater than the current
                // reassessment amount, we must add the current reassessment
                // to the last reassessment amount. e.g. we previously
                // overpaid by 100, and should have underpaid by 80, therefore
                // we need to UNDERPAY by 180 (100+80)

                // 2.
                // If the last reassessment amount is less than the current
                // reassessment amount, we must add the current reassessment
                // to the last reassessment amount. e.g. we previously
                // overpaid by 100, and should have underpaid by 120,
                // therefore we need to UNDERPAY by 220 (100+120)

                // 3.
                // If the last reassessment amount is equal to the current
                // reassessment amount, we must add the current reassessment
                // amount to the last reassessment amount. e.g. we previously
                // overpaid by 100, and should have underpaid by 100,
                // therefore we need to UNDERPAY by 200 (100+100)

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentSummaryDetails.totalAmount = new Money(
                        currentReassessmentAmount.getValue()
                            + reassessmentBalanceInfoDtlsList.dtls
                                .item(l).reassessmentAmount.getValue());

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                            currentReassessmentAmount.getValue()
                                + reassessmentBalanceInfoDtlsList.dtls
                                    .item(l).reassessmentAmount.getValue());

                // this is an underpayment
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

                reassessed = true;

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
              }
            }

            // currently the system thinks we're dealing with an overpayment
            if (getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentSummaryDetails.reassessmentResultType
                    .equals(REASSESSMENTRESULT.OVERPAYMENT)
                && !reassessed) {

              if (reassessmentBalanceInfoDtlsList.dtls.item(l).amountType
                  .equals(REASSESSMENTRESULT.OVERPAYMENT) && !reassessed) {

                // if the last reassessment was an overpayment and the current
                // reassessment is also for an overpayment and the last
                // reassessment amount is greater than the current
                // reassessment amount, we must subtract the current
                // reassessment amount from the last reassessment amount. e.g.
                // we previously overpaid by 100, and should have overpaid by
                // 80, therefore we need to UNDERPAY by 20 (100-80)
                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(l).reassessmentAmount
                        .getValue() > currentReassessmentAmount.getValue()
                    && !reassessed) {

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.totalAmount = new Money(
                              reassessmentBalanceInfoDtlsList.dtls
                                  .item(l).reassessmentAmount.getValue()
                                  - currentReassessmentAmount.getValue());

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                              reassessmentBalanceInfoDtlsList.dtls
                                  .item(l).reassessmentAmount.getValue()
                                  - currentReassessmentAmount.getValue());

                  // this is an underpayment
                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

                  reassessed = true;

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
                }

                // if the last reassessment was an overpayment and the current
                // reassessment is also for an overpayment and the last
                // reassessment amount is less than the current reassessment
                // amount, we must subtract the last reassessment amount from
                // the current reassessment amount. e.g. we previously
                // overpaid by 100, and should have overpaid by 120, therefore
                // we need to OVERPAY by 20 (120-100)
                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(l).reassessmentAmount
                        .getValue() < currentReassessmentAmount.getValue()
                    && !reassessed) {

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.totalAmount = new Money(
                              currentReassessmentAmount.getValue()
                                  - reassessmentBalanceInfoDtlsList.dtls
                                      .item(l).reassessmentAmount.getValue());

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                              currentReassessmentAmount.getValue()
                                  - reassessmentBalanceInfoDtlsList.dtls
                                      .item(l).reassessmentAmount.getValue());

                  // this is an overpayment
                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

                  reassessed = true;

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
                }

                // if the last reassessment was an overpayment and the current
                // reassessment is also for an overpayment and the last
                // reassessment amount is equal to the current reassessment
                // amount, there has been NO CHANGE.
                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(l).reassessmentAmount
                        .getValue() == currentReassessmentAmount.getValue()
                    && !reassessed) {

                  // there has been no change
                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

                  reassessed = true;

                  getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(
                          j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;
                }
              }

              if (reassessmentBalanceInfoDtlsList.dtls.item(l).amountType
                  .equals(REASSESSMENTRESULT.UNDERPAYMENT) && !reassessed) {

                // In all three scenarios when going from an underpayment to
                // an overpayment we do the same thing i.e. we always add the
                // reassessed amounts together for the new reassessed amount
                // of the overpayment.

                // 1.
                // If the last reassessment amount is greater than the current
                // reassessment amount, we must add the current reassessment
                // to the last reassessment amount. e.g. we previously
                // underpaid by 100, and should have overpaid by 80, therefore
                // we need to OVERPAY by 180 (100+80)

                // 2.
                // If the last reassessment amount is less than the current
                // reassessment amount, we must add the current reassessment
                // to the last reassessment amount. e.g. we previously
                // underpaid by 100, and should have overpaid by 120,
                // therefore we need to OVERPAY by 220 (100+120)

                // 3.
                // If the last reassessment amount is equal to the current
                // reassessment amount, we must add the current reassessment
                // amount to the last reassessment amount. e.g. we previously
                // underpaid by 100, and should have overpaid by 100,
                // therefore we need to OVERPAY by 200 (100+100)

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentSummaryDetails.totalAmount = new Money(
                        currentReassessmentAmount.getValue()
                            + reassessmentBalanceInfoDtlsList.dtls
                                .item(l).reassessmentAmount.getValue());

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                            currentReassessmentAmount.getValue()
                                + reassessmentBalanceInfoDtlsList.dtls
                                    .item(l).reassessmentAmount.getValue());

                // this is an overpayment
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

                reassessed = true;

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
              }
            }

            // currently the system thinks we're dealing with a 'no change'
            // situation
            if (getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentSummaryDetails.reassessmentResultType
                    .equals(REASSESSMENTRESULT.NOCHANGE)
                && !reassessed) {

              // if the previous reassessment was an overpayment then we must
              // completely reverse that overpayment with an underpayment for
              // the same amount e.g. we overpaid by 100, we have reassessed
              // for 0 therefore we need to UNDERPAY by 100
              if (reassessmentBalanceInfoDtlsList.dtls.item(l).amountType
                  .equals(REASSESSMENTRESULT.OVERPAYMENT) && !reassessed) {

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentSummaryDetails.totalAmount = new Money(
                        reassessmentBalanceInfoDtlsList.dtls
                            .item(l).reassessmentAmount.getValue());

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                            reassessmentBalanceInfoDtlsList.dtls
                                .item(l).reassessmentAmount.getValue());

                // this is an underpayment
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

                reassessed = true;

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;

                // BEGIN, 178020, CSH
                // Setting indicator for use in later calculations
                isNoChangeReassessment = true;
                // END, 178020
              }

              // if the previous reassessment was an underpayment then we must
              // completely reverse that underpayment with an overpayment for
              // the same amount e.g. we underpaid by 100, we have reassessed
              // for 0 therefore we need to OVERPAY by 100
              if (reassessmentBalanceInfoDtlsList.dtls.item(l).amountType
                  .equals(REASSESSMENTRESULT.UNDERPAYMENT) && !reassessed) {

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentSummaryDetails.totalAmount = new Money(
                        reassessmentBalanceInfoDtlsList.dtls
                            .item(l).reassessmentAmount.getValue());

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                            reassessmentBalanceInfoDtlsList.dtls
                                .item(l).reassessmentAmount.getValue());

                // this is an overpayment
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

                reassessed = true;

                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;

                // BEGIN, 178020, CSH
                // Setting indicator for use in later calculations
                isNoChangeReassessment = true;
                // END, 178020
              }
            }
          }
        }

        // BEGIN, CR00201637, KH
        // Indicates that we should store the results of this reassessment
        boolean storeReassessmentResults = true;

        /*
         * If this reassessment is a NO CHANGE we do not want to store the
         * results unless we find that an over payment and an under payment have
         * balanced each other out. In this situation we will still store the
         * results as the fact that the component amounts have changed (even if
         * the total amount has not) is relevant.
         *
         * If this reassessment is a NO CHANGE and no granular results are
         * available from the previous reassessment then it will not be stored.
         */
        if (getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).reassessmentSummaryDetails.reassessmentResultType
                .equals(REASSESSMENTRESULT.NOCHANGE)) {

          // BEGIN, CR00243453, KH
          /*
           * If there is a previous reassessment, check whether it has granular
           * reassessment results.
           */
          if (previousReassessment) {

            final long prevNomOverUnderPaymentID = findPrecedingNomineeOverUnderPayment(
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j)).nomineeOverUnderPaymentID;

            // Search for OverUnderPaymentBreakdown records
            final NomineeOverUnderPayment nomineeOverUnderPayment = nomineeOverUnderPaymentDAO
                .get(prevNomOverUnderPaymentID);

            final List<OverUnderPaymentBreakdown> overUnderPaymentBreakdownList = overUnderPaymentBreakdownDAO
                .searchByNomineeOverUnderPayment(nomineeOverUnderPayment);

            if (0 == overUnderPaymentBreakdownList.size()) {
              storeReassessmentResults = false;
            }
          }

          // BEGIN, CR00204847, KH
          if (storeReassessmentResults) {
            storeReassessmentResults = checkCurrentReassessmentBreakdownResults(
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j));
          }
          // END, CR00204847, CR00243453

          // BEGIN, CR00241009, KH
          // If this is a NO CHANGE then the amount should always be zero
          getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).nomineeOverUnderPaymentDtls.totalAmount = new Money(0);
          // END, CR00241009
        }

        if (storeReassessmentResults) {

          // Store the current reassessment header details
          storeReassessmentResults(
              getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j),
              getReassessmentDetailsResult.completeCaseReassessment.overUnderPaymentHeaderDtls);

          /*
           * By default we will always store the granular results. The only
           * exception is when there is an existing reassessment on the case
           * which is not granular.
           */
          boolean granularReassessmentResults = true;

          if (previousReassessment) {

            // Search for OverUnderPaymentBreakdown records
            final NomineeOverUnderPayment nomineeOverUnderPayment = nomineeOverUnderPaymentDAO
                .get(
                    getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                        .item(
                            j).nomineeOverUnderPaymentDtls.prevNomOverUnderPaymentID);

            final List<OverUnderPaymentBreakdown> overUnderPaymentBreakdownList = overUnderPaymentBreakdownDAO
                .searchByNomineeOverUnderPayment(nomineeOverUnderPayment);

            /*
             * If only rolled-up results are available for the previous
             * reassessment (and no breakdown information), we cannot adjust the
             * current reassessment breakdown, so we can only store the
             * rolled-up results.
             */
            if (0 == overUnderPaymentBreakdownList.size()) {
              granularReassessmentResults = false;
            }
          }

          if (granularReassessmentResults) {

            // Record the Over/Under Payment Breakdown
            final OverUnderPaymentBreakdown overUnderPaymentBreakdownObj = overUnderPaymentBreakdownDAO
                .newInstance();

            overUnderPaymentBreakdownObj.storeReassessmentBreakdown(
                getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j));
          }

          // BEGIN, CR00003380, SD
          getReassessmentDetailsResult.beneficiaryDetails.invalidatedPmtExistsInd = overUnderPaymentIn.invalidatedPmtExistsInd;
          getReassessmentDetailsResult.beneficiaryDetails.relatedCaseExistsInd = overUnderPaymentIn.relatedCaseExistsInd;
          // END, CR00003380

          // Create the under/over payment details
          createUnderOverPayment(
              getReassessmentDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j),
              getReassessmentDetailsResult.beneficiaryDetails, reassessmentMode,
              getReassessmentDetailsResult.completeCaseReassessment.overUnderPaymentHeaderDtls,
              getReassessmentDetailsResult.completeCaseReassessment.objectiveTotalDetailsList);

          // BEGIN, 178020, CSH
          // Setting indicator for use in later calculations
          isNoChangeReassessment = false;
          // END, 178020
        }
        // END, CR00201637
      }
    }

    // BEGIN, 178020, CSH
    // Check whether the eligibility has changed for any replacement payments
    // created during previous reassessments and which overlap with the period
    // of the current reassessment
    if (!prevReassessmentBalanceInfoDtlsList.dtls.isEmpty()) {

      checkBalancingReassessmentForReplacementPayment(newCaseDecisions,
          existingCaseDecisions, reassessmentMode, overUnderPaymentIn, nominees,
          prevReassessmentBalanceInfoDtlsList);
    }
    // END, 178020

    DeductionFCGenerationFactory.newInstance()
        .createDeductionFCForStandaloneUnderpayment(caseHeaderKey);

    // BEGIN, CR00211744, VM
    assessmentEngineEvent.get(AssessmentEngineEvent.class).postReassessFCs(
        newCaseDecisions, existingCaseDecisions, reassessmentMode,
        overUnderPaymentIn, storeDecisionsInd);
    // END, CR00211744
  }

  // BEGIN, 178020, CSH
  // ___________________________________________________________________________
  /**
   * Gets a list of ReassessmentBalanceInfo records for the specified list of
   * case nominees.
   *
   * @param nominees
   *          The list of nominees on the case.
   *
   * @return The ReassessmentBalanceInfoDtlsList records for the specified
   *         nominees.
   */
  protected ReassessmentBalanceInfoDtlsList getReassessmentBalanceInfoForNominees(
      final CaseNomineeDetailsList nominees)
      throws AppException, InformationalException {

    ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList;
    final ReassessmentBalanceInfoDtlsList prevReassessmentBalanceInfoDtlsList = new ReassessmentBalanceInfoDtlsList();

    final ReassessmentBalanceInfo reassessmentBalanceInfoObj = ReassessmentBalanceInfoFactory
        .newInstance();
    final ReadmultiBalanceKey readmultiBalanceKey = new ReadmultiBalanceKey();

    for (int i = 0; i < nominees.caseNomineeDetailsList.size(); i++) {

      readmultiBalanceKey.caseNomineeID = nominees.caseNomineeDetailsList
          .item(i).caseNomineeID;
      reassessmentBalanceInfoDtlsList = reassessmentBalanceInfoObj
          .searchReassessmentsForNominee(readmultiBalanceKey);

      for (int j = 0; j < reassessmentBalanceInfoDtlsList.dtls.size(); j++) {

        final ReassessmentBalanceInfoDtls infoDtls = new ReassessmentBalanceInfoDtls();
        infoDtls.assign(reassessmentBalanceInfoDtlsList.dtls.item(j));

        prevReassessmentBalanceInfoDtlsList.dtls.addRef(infoDtls);
      }
    }
    return prevReassessmentBalanceInfoDtlsList;
  }

  // BEGIN, 179623, BD
  /**
   * Rereads the given case decisions from the database. These will normally
   * have been cached earlier in the current transaction, so reading them again
   * now should have minimal overhead.
   *
   * @param existingCaseDecisionsIn
   *          The in memory version of existing case decisions.
   *
   * @return The database versions of the same cases.
   *
   * @throws InformationalException
   *           Standard signature.
   * @throws AppException
   *           Standard signature.
   */
  protected CompleteDecisionCreationList rereadExistingDecisions(
      final CompleteDecisionCreationList existingCaseDecisionsIn)
      throws AppException, InformationalException {

    final CompleteDecisionCreationList result;

    if (existingCaseDecisionsIn.dtls.size() == 0) {
      // Nothing to do.
      result = existingCaseDecisionsIn;
    } else {
      final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory
          .newInstance();

      result = new CompleteDecisionCreationList();
      result.decisionIndDtls.assign(existingCaseDecisionsIn.decisionIndDtls);
      final int numRecords = existingCaseDecisionsIn.dtls.size();
      for (int i = 0; i < numRecords; i++) {

        final CaseDecisionKey decisionKey = new CaseDecisionKey();
        decisionKey.caseDecisionID = existingCaseDecisionsIn.dtls
            .get(i).details.caseDecisionID;

        // NB this class has state, safer to create once per loop iteration.
        final ManipulateCaseDecisions manipulator = ManipulateCaseDecisionsFactory
            .newInstance();
        // Reread the standard details struct from the database or cache...
        final CaseDecisionDtls caseDecisionDtls = caseDecisionObj
            .read(decisionKey);
        // ...and ensure it is fully re-populated to match the original one.
        final CompleteDecisionCreation pop2 = manipulator
            .populateCompleteDecisionDetails(caseDecisionDtls);
        result.dtls.add(pop2);
      }

    }

    return result;
  }

  // END, 179623

  // ___________________________________________________________________________
  /**
   * This method checks whether the eligibility has changed for any replacement
   * payments created during previous reassessments and which overlap with the
   * period of the current reassessment. If so, a balancing reassessment may
   * need to be created if it has not already been considered earlier in the
   * reassessment processing.
   *
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          A structure which aggregates a list of existing decisions and
   *          their associated components.
   * @param reassessmentMode
   *          the mode to run in
   * @param overUnderPaymentIn
   *          over/under payment details
   * @param nominees
   *          The list of nominees on the case.
   * @param prevReassessmentBalanceInfoDtlsList
   *          The list of previous reassessments on the case before the current
   *          reassessment processing commenced.
   */
  protected void checkBalancingReassessmentForReplacementPayment(
      final CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions,
      final ReassessmentMode reassessmentMode,
      final OverUnderPaymentIn overUnderPaymentIn,
      final CaseNomineeDetailsList nominees,
      final ReassessmentBalanceInfoDtlsList prevBalanceInfoDtlsList)
      throws AppException, InformationalException {

    final ReassessmentBalanceInfo reassessmentBalanceInfoObj = ReassessmentBalanceInfoFactory
        .newInstance();
    final ReadmultiBalanceKey readmultiBalanceKey = new ReadmultiBalanceKey();
    ReassessmentBalanceInfoDtlsList balanceInfoDtlsList;

    // Read the list of ReassessmentBalanceInfo records created already
    // during the current reassessment
    final ReassessmentBalanceInfoDtlsList currReassessmentBalanceInfoDtlsList = getCurrentReassessmentBalanceInfoList(
        nominees, prevBalanceInfoDtlsList);

    for (int n = 0; n < nominees.caseNomineeDetailsList.size(); n++) {

      readmultiBalanceKey.caseNomineeID = nominees.caseNomineeDetailsList
          .item(n).caseNomineeID;

      // Read the list of all ReassessmentBalanceInfo records for the case
      // nominee
      balanceInfoDtlsList = reassessmentBalanceInfoObj
          .searchReassessmentsForNominee(readmultiBalanceKey);

      boolean matchOneDecision = true; // default to true
      boolean createBalancingReassessment = false; // for a reassessed
                                                   // replacement period

      // Replacement period boundary dates
      Date repFromDate = Date.kZeroDate;
      Date repToDate = Date.kZeroDate;

      for (int i = 0; i < balanceInfoDtlsList.dtls.size(); i++) {

        // Check if the replacement period has already been included during the
        // current
        // reassessment for this nominee (so we don't create it twice)
        if (balanceInfoDtlsList.dtls.item(i).replacementPmtInd) {

          // Get the replacement payment period
          repFromDate = balanceInfoDtlsList.dtls.item(i).coverPeriodFrom;
          repToDate = balanceInfoDtlsList.dtls.item(i).coverPeriodTo;

          // We need to ensure that the replacement payment has not already
          // been balanced out in a previous reassessment
          for (final ReassessmentBalanceInfoDtls prevBI : prevBalanceInfoDtlsList.dtls) {

            if (!prevBI.coverPeriodFrom.after(repFromDate)
                && !prevBI.coverPeriodTo.before(repToDate)
                && prevBI.caseNomineeID == balanceInfoDtlsList.dtls
                    .item(i).caseNomineeID
                && !prevBI.replacementPmtInd) {

              // This means the replacement period for this nominee has already
              // been
              // considered during a previous reassessment, no need to progress
              // any further for the current reassessment
              boolean eligible = false;

              for (int w = 0; w < newCaseDecisions.dtls.size(); w++) {
                if (newCaseDecisions.dtls.item(w).details.resultCode
                    .equals(CASEDECISIONRESULTCODE.ELIGIBLE)) {
                  eligible = true;
                  break;
                }
              }

              if (!eligible) {
                break;
              }

              return;
            }
          }

          // We need to ensure that the replacement payment has not already
          // been balanced out during the current reassessment
          for (final ReassessmentBalanceInfoDtls currentBI : currReassessmentBalanceInfoDtlsList.dtls) {

            if (!currentBI.coverPeriodFrom.after(repFromDate)
                && !currentBI.coverPeriodTo.before(repToDate)
                && currentBI.caseNomineeID == balanceInfoDtlsList.dtls
                    .item(i).caseNomineeID) {

              // This means the replacement period for this nominee has already
              // been considered during the current reassessment, no need to
              // progress any further for this reassessmentBalanceInfoDtlsList
              // item
              return;
            }
          }

          // Get the reassessment details for any invalidated payment that
          // has been replaced during the reassessed period
          final ReassessCaseDetailsList reassessCaseDetailsList = getReplacementPaymentReassessmentDetails(
              overUnderPaymentIn);

          // Ensure the list is ordered by by from date ascending
          orderReassessCaseDetailsList(reassessCaseDetailsList);

          // Check the corresponding decision details for any replacement
          // payments that were found to determine whether the period is
          // currently eligible
          if (reassessCaseDetailsList.dtls.size() > 0) {

            // Find the list of new decisions for the replacement payment period
            final CompleteDecisionCreationList newList = filterDecisionListForPeriod(
                newCaseDecisions, repFromDate, repToDate);

            // BEGIN, 179623, BD
            // To be absolutely certain we are comparing against the unmodified
            // original decisions we re-read them from the database. These will
            // actually come from the sql cache so this is not an expensive
            // operation.
            final CompleteDecisionCreationList existingCaseDecisionsReloaded = rereadExistingDecisions(
                existingCaseDecisions);

            // Find the list of existing decisions for the replacement payment
            // period
            final CompleteDecisionCreationList existingList = filterDecisionListForPeriod(
                existingCaseDecisionsReloaded, repFromDate, repToDate);
            // END, 179623

            if (!(newList.dtls.isEmpty() && existingList.dtls.isEmpty())) {

              // Compare each existing decision with the new
              // decision list and check for a match
              for (int d = 0; d < existingList.dtls.size(); d++) {

                int c = 0;

                for (; c < newList.dtls.size(); c++) {

                  matchOneDecision = compareNewToExisting(newList.dtls.item(c),
                      existingList.dtls.item(d));

                  if (matchOneDecision) {

                    break;
                  }
                }

                // If the decisions no longer match for the replaced period then
                // eligibility has changed and we must create a balancing
                // reassessment
                if (!matchOneDecision) {

                  // Set the flag to indicate we need to create a
                  // balancing reassessment for the replacement payment
                  createBalancingReassessment = true;

                  break;
                }
              }
            }
          } else {

            // This means that the decisions have not
            // changed so no need to proceed any further
            return;
          }
        }

        if (createBalancingReassessment) {

          final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();
          caseNomineeKey.caseNomineeID = nominees.caseNomineeDetailsList
              .item(n).caseNomineeID;

          createBalancingReassessment(newCaseDecisions, existingCaseDecisions,
              reassessmentMode, overUnderPaymentIn, caseNomineeKey,
              balanceInfoDtlsList, repFromDate, repToDate);
        }

        createBalancingReassessment = false;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates a balancing reassessment for an over/under payment which originated
   * from an invalidated payment, but where eligibility of the period covered by
   * the replacement payment subsequently changed.
   * <p>
   * A typically scenario would be as follows:
   * <ul>
   * <li>Case is eligible for 3 weeks
   * <li>All 3 weeks are paid out
   * <li>The payment for week 3 is invalidated
   * <li>The case is reassessed and an underpayment for week 3 (i.e. a
   * replacement payment) is created.
   * <li>The evidence for the 3 weeks is cancelled.
   * <li>In this scenario, this function will deem that the underpayment needs
   * to be 'reversed' by virtue of a balancing overpayment.
   * </ul>
   * <p>
   * In the above scenario, if the period is subsequently made eligible again,
   * the system will deem that the overpayment now needs to be 'reversed' by
   * creating a new balancing underpayment.
   *
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          A structure which aggregates a list of existing decisions and
   *          their associated components.
   * @param reassessmentMode
   *          the mode to run in
   * @param overUnderPaymentIn
   *          over/under payment details
   * @param caseNomineeKey
   *          The nominee on the reassessment
   * @param reassessmentBalanceInfoDtlsList
   *          The full list of reassessments on the case
   * @param repFromDate
   *          The start date of the replacement payment
   * @param repToDate
   *          The end date of the replacement payment
   */
  protected void createBalancingReassessment(
      final CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions,
      final ReassessmentMode reassessmentMode,
      final OverUnderPaymentIn overUnderPaymentIn,
      final CaseNomineeKey caseNomineeKey,
      final ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList,
      final Date repFromDate, final Date repToDate)
      throws InformationalException, AppException {

    // We've now determined a change in eligibility across a period which has
    // a replacement payment. To reflect this, the reassessment that
    // represented the replacement payment needs to be 'reversed'. If during
    // a subsequent reassessment eligibility for this period changes again,
    // it will need to be 'reversed' back again.

    final GetReassessmentDetailsResult result = new GetReassessmentDetailsResult();
    final NomineeReassessmentHeader header = new NomineeReassessmentHeader();

    // Locate the details of the NomineeOverUnderPayment and associated
    // records and 'massage' a reassessment result that can be stored.
    final NomineeOverUnderPaymentDtlsList noupList = assessmentEngineEntity
        .getOverUnderPaymentsByCaseNomineeID(caseNomineeKey);

    long nomineeOverUnderPaymentID = 0;

    OUTER: for (int i = 0; i < reassessmentBalanceInfoDtlsList.dtls
        .size(); i++) {

      // BEGIN, 179623, BD
      if (!reassessmentBalanceInfoDtlsList.dtls.item(i).replacementPmtInd) {
        continue;
      }
      // END, 179623

      for (int j = 0; j < noupList.dtls.size(); j++) {
        // BEGIN, 179623, BD
        if (reassessmentBalanceInfoDtlsList.dtls.item(i).coverPeriodFrom
            .equals(noupList.dtls.item(j).coverPeriodFrom)
            && reassessmentBalanceInfoDtlsList.dtls.item(i).coverPeriodTo
                .equals(noupList.dtls.item(j).coverPeriodTo)
            && reassessmentBalanceInfoDtlsList.dtls.item(i).reassessmentAmount
                .equals(noupList.dtls.item(j).totalAmount)) {
          // END, 179623

          // Set the nomineeOverUnderPaymentID for the reassessment we are
          // 'reversing'
          nomineeOverUnderPaymentID = noupList.dtls
              .item(j).nomineeOverUnderPaymentID;

          break OUTER;
        }
      }
    }

    // Retrieve the NomineeOverUnderPayment record we are balancing out
    final NomineeOverUnderPayment piNomineeOverUnderPaymentObj = nomineeOverUnderPaymentDAO
        .get(nomineeOverUnderPaymentID);

    // Also locate the details of the associated break down records
    // so these can be added to the breakdownPerObjective part of the
    // struct passed to the storage method
    final List<OverUnderPaymentBreakdown> breakdownList = overUnderPaymentBreakdownDAO
        .searchByNomineeOverUnderPayment(piNomineeOverUnderPaymentObj);

    // Create the NomineeOverUnderPayment record
    final NomineeOverUnderPaymentKey noupKey = new NomineeOverUnderPaymentKey();
    noupKey.nomineeOverUnderPaymentID = nomineeOverUnderPaymentID;

    final NomineeOverUnderPaymentDtls noupDtls = NomineeOverUnderPaymentFactory
        .newInstance().read(noupKey);

    // Map the details on the return struct, reversing the result type
    if (noupDtls.amountTypeCode.equals(REASSESSMENTRESULT.OVERPAYMENT)) {
      header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
    } else if (noupDtls.amountTypeCode
        .equals(REASSESSMENTRESULT.UNDERPAYMENT)) {
      header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
    }

    header.nomineeOverUnderPaymentDtls.totalAmount = noupDtls.totalAmount;
    header.nomineeOverUnderPaymentDtls.caseNomineeID = caseNomineeKey.caseNomineeID;
    header.nomineeOverUnderPaymentDtls.prevNomOverUnderPaymentID = noupDtls.nomineeOverUnderPaymentID;
    header.nomineeOverUnderPaymentDtls.coverPeriodFrom = noupDtls.coverPeriodFrom;
    header.nomineeOverUnderPaymentDtls.coverPeriodTo = noupDtls.coverPeriodTo;

    // Retrieve the ReassessmentInfo records so they can also be 'reversed'
    final ReadmultiByNomineeOverUnderPaymentIDKey rmKey = new ReadmultiByNomineeOverUnderPaymentIDKey();
    rmKey.nomineeOverUnderPaymentID = noupDtls.nomineeOverUnderPaymentID;

    final ReassessmentInfoDtlsList infoDtlsList = ReassessmentInfoFactory
        .newInstance().searchByNomineeOverUnderPaymentID(rmKey);

    NomineeReassessmentDetails reassessmentDetails = null;

    for (int p = 0; p < infoDtlsList.dtls.size(); p++) {

      reassessmentDetails = new NomineeReassessmentDetails();

      // Create ReassessInfo record details
      final ReassessmentInfoDtls newDtls = new ReassessmentInfoDtls();
      newDtls.assign(infoDtlsList.dtls.item(p));

      reassessmentDetails.reassessmentInfoDtls.assign(newDtls);

      // Create ReassessAmountInfo record details
      final ReassessmentAmountInformationKey amountKey = new ReassessmentAmountInformationKey();
      amountKey.reassessmentInfoID = infoDtlsList.dtls
          .item(p).reassessmentInfoID;

      final ReassessmentAmountInfoDtlsList amountDetailsList = ReassessmentAmountInfoFactory
          .newInstance().searchByReassessInfoID(amountKey);

      for (int q = 0; q < amountDetailsList.dtls.size(); q++) {

        final ReassessmentAmountInfoDetails amountDetails = new ReassessmentAmountInfoDetails();

        // Reverse the amount values
        amountDetails.actualAmount = amountDetailsList.dtls
            .item(q).reassessedAmount;
        amountDetails.reassessedAmount = amountDetailsList.dtls
            .item(q).actualAmount;
        amountDetails.receivedAmount = amountDetailsList.dtls
            .item(q).receivedAmount;
        amountDetails.amountType = amountDetailsList.dtls.item(q).amountType;
        amountDetails.reassessmentInfoID = newDtls.reassessmentInfoID;

        if (amountDetails.amountType.equals("AT1")) {

          // Populate the breakdownPerObjective for use when storing
          // the granular reassessment results
          for (final OverUnderPaymentBreakdown breakdown : breakdownList) {

            final ObjectiveAmountDetails objAmt = new ObjectiveAmountDetails();

            objAmt.rulesObjectiveID = breakdown.getRulesObjective();

            final Money totalActualAmount = Money.kZeroMoney;
            final Money totalReassessedAmount = Money.kZeroMoney;

            final List<BreakdownInfo> breakdownInfoList = breakdownInfoDAO
                .searchByOverUnderPaymentBreakdown(breakdown);

            for (final BreakdownInfo breakdownInfo : breakdownInfoList) {
              if (breakdownInfo.getDateRange().start().equals(newDtls.fromDate)
                  && breakdownInfo.getDateRange().end()
                      .equals(newDtls.toDate)) {

                objAmt.actualAmount = breakdownInfo.getReassessedAmount();
                objAmt.reassessedAmount = breakdownInfo.getActualAmount();
                break;
              }
            }

            amountDetails.breakdownPerObjectiveList.details.addRef(objAmt);
          } // for final OverUnderPaymentBreakdown

        } // if "AT1"
        reassessmentDetails.amountDetailsList.addRef(amountDetails);
      } // for int q = 0

      // Add the reassessment details lists to the header
      header.reassessmentDetailsList.addRef(reassessmentDetails);
    } // for int p = 0

    // Add the reassessment summary details to the header
    final ReassessmentSummaryDetails summaryDetails = new ReassessmentSummaryDetails();

    // Reverse the result type
    if (noupDtls.amountTypeCode.equals(REASSESSMENTRESULT.OVERPAYMENT)) {
      summaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;
    } else if (noupDtls.amountTypeCode
        .equals(REASSESSMENTRESULT.UNDERPAYMENT)) {
      summaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;
    }

    summaryDetails.totalActualAmount = noupDtls.totalAmount;
    summaryDetails.totalAmount = noupDtls.totalAmount;

    header.reassessmentSummaryDetails.assign(summaryDetails);

    // Add the header to the nominee header list in the reassessment result
    // struct
    // BEGIN, 179623, BD
    header.reassessmentSummaryDetails.isBalancedReplacementPaymentCreatedOpt = true;

    result.completeCaseReassessment.nomineeReassessmentHeaderList
        .addRef(header);

    // Add decision details to the reassessment result struct
    result.completeCaseReassessment.overUnderPaymentHeaderDtls.caseID = overUnderPaymentIn.caseID;
    result.completeCaseReassessment = getReassessmentDecisions(newCaseDecisions,
        existingCaseDecisions, result.completeCaseReassessment);

    // Store the classic reassessment records for the 'reversed'
    // Over/Underpayment
    storeResult(
        result.completeCaseReassessment.nomineeReassessmentHeaderList.item(0),
        result.completeCaseReassessment.overUnderPaymentHeaderDtls,
        newCaseDecisions, repFromDate, repToDate);

    // Find all the granular information for the reassessment
    // that we are 'reversing'
    if (result.completeCaseReassessment.nomineeReassessmentHeaderList
        .item(0).nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID != 0) {

      // Search for OverUnderPaymentBreakdown records
      final NomineeOverUnderPayment prevNomineeOverUnderPayment = nomineeOverUnderPaymentDAO
          .get(noupKey.nomineeOverUnderPaymentID);
      final List<OverUnderPaymentBreakdown> overUnderPaymentBreakdownList = overUnderPaymentBreakdownDAO
          .searchByNomineeOverUnderPayment(prevNomineeOverUnderPayment);

      /*
       * By default we will always store the granular results. The only
       * exception is when there is an existing reassessment on the case which
       * is not granular.
       */
      boolean granularReassessmentResults = true;

      /*
       * If only rolled-up results are available for the previous reassessment
       * (and no breakdown information), we cannot adjust the current
       * reassessment breakdown, so we can only store the rolled-up results.
       */
      if (0 == overUnderPaymentBreakdownList.size()) {
        granularReassessmentResults = false;
      }

      if (granularReassessmentResults) {

        final OverUnderPaymentBreakdown overUnderPaymentBreakdownObj = overUnderPaymentBreakdownDAO
            .newInstance();

        overUnderPaymentBreakdownObj.storeReassessmentBreakdown(
            result.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(0));
      }
    }

    // Set the high level reassessment details
    result.beneficiaryDetails.caseNomineeID = result.completeCaseReassessment.nomineeReassessmentHeaderList
        .item(0).nomineeOverUnderPaymentDtls.caseNomineeID;
    result.beneficiaryDetails.invalidatedPmtExistsInd = overUnderPaymentIn.invalidatedPmtExistsInd;
    result.beneficiaryDetails.relatedCaseExistsInd = overUnderPaymentIn.relatedCaseExistsInd;

    // Create the under/over payment details
    createUnderOverPayment(
        result.completeCaseReassessment.nomineeReassessmentHeaderList.item(0),
        result.beneficiaryDetails, reassessmentMode,
        result.completeCaseReassessment.overUnderPaymentHeaderDtls,
        result.completeCaseReassessment.objectiveTotalDetailsList);
  }

  // BEGIN, 179623, BD
  /**
   * Stores the result that arises out of reversing a previous replacement
   * payment that arises out of making the entire period in-eligible.
   *
   * @param header
   * @param overUnderPaymentHeaderDtls
   * @param newCaseDecisions
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void storeResult(final NomineeReassessmentHeader header,
      final OverUnderPaymentHeaderDtls overUnderPaymentHeaderDtls,
      final CompleteDecisionCreationList newCaseDecisions,
      final Date repFromDate, final Date repToDate)
      throws AppException, InformationalException {

    // Retrieve reassessmentBalanceInfo records
    final ReadmultiBalanceKey readmultiBalanceKey = new ReadmultiBalanceKey();

    readmultiBalanceKey.caseNomineeID = header.nomineeOverUnderPaymentDtls.caseNomineeID;

    final ReassessmentBalanceInfoDtlsList list = ReassessmentBalanceInfoFactory
        .newInstance().searchReassessmentsForNominee(readmultiBalanceKey);

    // BEGIN, 179623, BD
    final ReassessmentBalanceInfoDtlsList chronologicalBIList = new ReassessmentBalanceInfoDtlsList();
    ReassessmentBalanceInfoDtls nextBalanceInfo = new ReassessmentBalanceInfoDtls();

    for (final ReassessmentBalanceInfoDtls dtls : list.dtls) {
      if (dtls.prevBalanceInfoID == 0) {

        nextBalanceInfo.assign(dtls);
        chronologicalBIList.dtls.addRef(nextBalanceInfo);
      }
    }

    boolean moreBalanceInfoRecordsExist = false;

    if (list.dtls.size() > 1) {
      moreBalanceInfoRecordsExist = true;
    }

    final PreviousReassessmentKey previousReassessmentKey = new PreviousReassessmentKey();

    while (moreBalanceInfoRecordsExist) {

      previousReassessmentKey.prevBalanceInfoID = nextBalanceInfo.reassessmentBalanceInfoID;

      try {
        nextBalanceInfo = ReassessmentBalanceInfoFactory.newInstance()
            .readReassessmentByPreviousID(previousReassessmentKey);

        chronologicalBIList.dtls.addRef(nextBalanceInfo);

      } catch (final RecordNotFoundException e) {
        moreBalanceInfoRecordsExist = false;
      }
    }

    final ReassessmentBalanceInfoDtlsList reverseBIList = new ReassessmentBalanceInfoDtlsList();

    for (int y = chronologicalBIList.dtls.size() - 1; y >= 0; y--) {

      ReassessmentBalanceInfoDtls dtls = new ReassessmentBalanceInfoDtls();
      dtls = chronologicalBIList.dtls.item(y);
      reverseBIList.dtls.addRef(dtls);
    }

    adjustForPreviousReassessment(header, reverseBIList, newCaseDecisions,
        repFromDate, repToDate);

    storeReassessmentResults(header, overUnderPaymentHeaderDtls);
  }

  // END, 179623

  /**
   * Adjusts the result of reversing the previous replacement payment. This is
   * required if one or more reassessments have occurred since the replacement
   * payment was issued.
   * <p>
   * How far back the processing checks previous reassessment balance info
   * records is determined by the following two factors:
   * <ul>
   * <li>Whether the case has been made entirely in-eligible and
   * <li>If the replacement payment being reversed has been reached
   * </ul>
   * <p>
   * When the above conditions are met, no more adjustments are made to the
   * rolled up amount.
   *
   * @param header
   * @param reassessmentBalanceInfoDtlsList
   * @param newCaseDecisions
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void adjustForPreviousReassessment(
      final NomineeReassessmentHeader header,
      final ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList,
      final CompleteDecisionCreationList newCaseDecisions,
      final Date repFromDate, final Date repToDate)
      throws AppException, InformationalException {

    Money currentReassessmentAmount;
    boolean reassessed;

    boolean eligible = false;

    // Find the list of new decisions for the replacement payment period
    final CompleteDecisionCreationList newList = filterDecisionListForPeriod(
        newCaseDecisions, repFromDate, repToDate);

    // Examine the decision details to determine if the period of the
    // replacement payment is eligible
    for (int w = 0; w < newList.dtls.size(); w++) {
      if (newList.dtls.item(w).details.resultCode
          .equals(CASEDECISIONRESULTCODE.ELIGIBLE)) {
        eligible = true;
        break;
      }
    }

    for (final ReassessmentBalanceInfoDtls balanceInfo : reassessmentBalanceInfoDtlsList.dtls) {

      if (!eligible && balanceInfo.replacementPmtInd) {

        // No need to adjust further
        break;
      }

      // re-set the reassessed flag
      reassessed = false;

      // If this is a reassessment of a reassessment get
      // the total under or over payment amount
      currentReassessmentAmount = header.reassessmentSummaryDetails.totalAmount;

      // currently the system thinks we're dealing with an underpayment
      if (header.reassessmentSummaryDetails.reassessmentResultType
          .equals(REASSESSMENTRESULT.UNDERPAYMENT) && !reassessed) {

        if (balanceInfo.amountType.equals(REASSESSMENTRESULT.UNDERPAYMENT)
            && !reassessed) {

          // if the last reassessment was an underpayment and the
          // current reassessment is also for an underpayment and the
          // last reassessment amount is greater than the current
          // reassessment amount, we must subtract the current
          // reassessment from the last reassessment amount. e.g. we
          // previously underpaid by 100, and should have underpaid by
          // 80, therefore we need to OVERPAY by 20 (100-80)
          if (balanceInfo.reassessmentAmount
              .getValue() > currentReassessmentAmount.getValue()
              && !reassessed) {

            header.reassessmentSummaryDetails.totalAmount = new Money(
                balanceInfo.reassessmentAmount.getValue()
                    - currentReassessmentAmount.getValue());

            header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
                balanceInfo.reassessmentAmount.getValue()
                    - currentReassessmentAmount.getValue());

            // this is an overpayment
            header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

            reassessed = true;

            header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
          }

          // if the last reassessment was an underpayment and the
          // current reassessment is also for an underpayment and the
          // last reassessment amount is less than the current
          // reassessment amount, we must subtract the last reassessment
          // from the current reassessment amount. e.g. we previously
          // underpaid by 100, and should have underpaid by 120,
          // therefore we need to UNDERPAY by 20 (120-100)
          if (balanceInfo.reassessmentAmount
              .getValue() < currentReassessmentAmount.getValue()
              && !reassessed) {

            header.reassessmentSummaryDetails.totalAmount = new Money(
                currentReassessmentAmount.getValue()
                    - balanceInfo.reassessmentAmount.getValue());

            header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
                currentReassessmentAmount.getValue()
                    - balanceInfo.reassessmentAmount.getValue());

            // this is an underpayment
            header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

            reassessed = true;

            header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
          }

          // if the last reassessment was an underpayment and the
          // current reassessment is also for an underpayment and the
          // last reassessment amount is equal to the current
          // reassessment amount, there has been NO CHANGE.
          if (balanceInfo.reassessmentAmount
              .getValue() == currentReassessmentAmount.getValue()
              && !reassessed) {

            // there has been no change
            header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

            reassessed = true;

            header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;
          }
        }

        if (balanceInfo.amountType.equals(REASSESSMENTRESULT.OVERPAYMENT)
            && !reassessed) {

          // In all three scenarios when going from an overpayment to an
          // underpayment we do the same thing i.e. we always add the
          // reassessed amounts together for the new reassessed amount
          // of the overpayment.

          // 1.
          // If the last reassessment amount is greater than the current
          // reassessment amount, we must add the current reassessment
          // to the last reassessment amount. e.g. we previously
          // overpaid by 100, and should have underpaid by 80, therefore
          // we need to UNDERPAY by 180 (100+80)

          // 2.
          // If the last reassessment amount is less than the current
          // reassessment amount, we must add the current reassessment
          // to the last reassessment amount. e.g. we previously
          // overpaid by 100, and should have underpaid by 120,
          // therefore we need to UNDERPAY by 220 (100+120)

          // 3.
          // If the last reassessment amount is equal to the current
          // reassessment amount, we must add the current reassessment
          // amount to the last reassessment amount. e.g. we previously
          // overpaid by 100, and should have underpaid by 100,
          // therefore we need to UNDERPAY by 200 (100+100)

          header.reassessmentSummaryDetails.totalAmount = new Money(
              currentReassessmentAmount.getValue()
                  + balanceInfo.reassessmentAmount.getValue());

          header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
              currentReassessmentAmount.getValue()
                  + balanceInfo.reassessmentAmount.getValue());

          // this is an underpayment
          header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

          reassessed = true;

          header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
        }
      }

      // currently the system thinks we're dealing with an overpayment
      if (header.reassessmentSummaryDetails.reassessmentResultType
          .equals(REASSESSMENTRESULT.OVERPAYMENT) && !reassessed) {

        if (balanceInfo.amountType.equals(REASSESSMENTRESULT.OVERPAYMENT)
            && !reassessed) {

          // if the last reassessment was an overpayment and the current
          // reassessment is also for an overpayment and the last
          // reassessment amount is greater than the current
          // reassessment amount, we must subtract the current
          // reassessment amount from the last reassessment amount. e.g.
          // we previously overpaid by 100, and should have overpaid by
          // 80, therefore we need to UNDERPAY by 20 (100-80)
          if (balanceInfo.reassessmentAmount
              .getValue() > currentReassessmentAmount.getValue()
              && !reassessed) {

            header.reassessmentSummaryDetails.totalAmount = new Money(
                balanceInfo.reassessmentAmount.getValue()
                    - currentReassessmentAmount.getValue());

            header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
                balanceInfo.reassessmentAmount.getValue()
                    - currentReassessmentAmount.getValue());

            // this is an underpayment
            header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

            reassessed = true;

            header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;
          }

          // if the last reassessment was an overpayment and the current
          // reassessment is also for an overpayment and the last
          // reassessment amount is less than the current reassessment
          // amount, we must subtract the last reassessment amount from
          // the current reassessment amount. e.g. we previously
          // overpaid by 100, and should have overpaid by 120, therefore
          // we need to OVERPAY by 20 (120-100)
          if (balanceInfo.reassessmentAmount
              .getValue() < currentReassessmentAmount.getValue()
              && !reassessed) {

            header.reassessmentSummaryDetails.totalAmount = new Money(
                currentReassessmentAmount.getValue()
                    - balanceInfo.reassessmentAmount.getValue());

            header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
                currentReassessmentAmount.getValue()
                    - balanceInfo.reassessmentAmount.getValue());

            // this is an overpayment
            header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

            reassessed = true;

            header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
          }

          // if the last reassessment was an overpayment and the current
          // reassessment is also for an overpayment and the last
          // reassessment amount is equal to the current reassessment
          // amount, there has been NO CHANGE.
          if (balanceInfo.reassessmentAmount
              .getValue() == currentReassessmentAmount.getValue()
              && !reassessed) {

            // there has been no change
            header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

            reassessed = true;

            header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;
          }
        }

        if (balanceInfo.amountType.equals(REASSESSMENTRESULT.UNDERPAYMENT)
            && !reassessed) {

          // In all three scenarios when going from an underpayment to
          // an overpayment we do the same thing i.e. we always add the
          // reassessed amounts together for the new reassessed amount
          // of the overpayment.

          // 1.
          // If the last reassessment amount is greater than the current
          // reassessment amount, we must add the current reassessment
          // to the last reassessment amount. e.g. we previously
          // underpaid by 100, and should have overpaid by 80, therefore
          // we need to OVERPAY by 180 (100+80)

          // 2.
          // If the last reassessment amount is less than the current
          // reassessment amount, we must add the current reassessment
          // to the last reassessment amount. e.g. we previously
          // underpaid by 100, and should have overpaid by 120,
          // therefore we need to OVERPAY by 220 (100+120)

          // 3.
          // If the last reassessment amount is equal to the current
          // reassessment amount, we must add the current reassessment
          // amount to the last reassessment amount. e.g. we previously
          // underpaid by 100, and should have overpaid by 100,
          // therefore we need to OVERPAY by 200 (100+100)

          header.reassessmentSummaryDetails.totalAmount = new Money(
              currentReassessmentAmount.getValue()
                  + balanceInfo.reassessmentAmount.getValue());

          header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
              currentReassessmentAmount.getValue()
                  + balanceInfo.reassessmentAmount.getValue());

          // this is an overpayment
          header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

          reassessed = true;

          header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;
        }
      }

      // currently the system thinks we're dealing with a 'no change'
      // situation
      if (header.reassessmentSummaryDetails.reassessmentResultType
          .equals(REASSESSMENTRESULT.NOCHANGE) && !reassessed) {

        // if the previous reassessment was an overpayment then we must
        // completely reverse that overpayment with an underpayment for
        // the same amount e.g. we overpaid by 100, we have reassessed
        // for 0 therefore we need to UNDERPAY by 100
        if (balanceInfo.amountType.equals(REASSESSMENTRESULT.OVERPAYMENT)
            && !reassessed) {

          header.reassessmentSummaryDetails.totalAmount = new Money(
              balanceInfo.reassessmentAmount.getValue());

          header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
              balanceInfo.reassessmentAmount.getValue());

          // this is an underpayment
          header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

          reassessed = true;

          header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;

          // BEGIN, 178020, CSH
          // Setting indicator for use in later calculations
          isNoChangeReassessment = true;
          // END, 178020
        }

        // if the previous reassessment was an underpayment then we must
        // completely reverse that underpayment with an overpayment for
        // the same amount e.g. we underpaid by 100, we have reassessed
        // for 0 therefore we need to OVERPAY by 100
        if (balanceInfo.amountType.equals(REASSESSMENTRESULT.UNDERPAYMENT)
            && !reassessed) {

          header.reassessmentSummaryDetails.totalAmount = new Money(
              balanceInfo.reassessmentAmount.getValue());

          header.nomineeOverUnderPaymentDtls.totalAmount = new Money(
              balanceInfo.reassessmentAmount.getValue());

          // this is an overpayment
          header.reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

          reassessed = true;

          header.nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;

          // BEGIN, 178020, CSH
          // Setting indicator for use in later calculations
          isNoChangeReassessment = true;
          // END, 178020
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * This method filters the list of Case Decisions passed in by the specified
   * date range.
   *
   * @param caseDecisions
   *          The list of case decisions to be filtered
   * @param fromDate
   *          The start date of the date range to filter by
   * @param toDate
   *          The end date of the date range to filter by
   *
   * @return The list of filtered case decisions.
   *
   */
  protected CompleteDecisionCreationList filterDecisionListForPeriod(
      final CompleteDecisionCreationList caseDecisions, final Date fromDate,
      final Date toDate) {

    final CompleteDecisionCreationList newList = new CompleteDecisionCreationList();

    // Find the list of new decisions for the replacement payment period
    for (int i = 0; i < caseDecisions.dtls.size(); i++) {

      // Find the decisions that are bound by fromDate / toDate
      if (caseDecisions.dtls.item(i).details.decisionFromDate.before(toDate)
          && (caseDecisions.dtls.item(i).details.decisionToDate.after(fromDate)
              || caseDecisions.dtls.item(i).details.decisionToDate
                  .equals(Date.kZeroDate))) {

        final CompleteDecisionCreation decision = new CompleteDecisionCreation();

        decision.details = caseDecisions.dtls.item(i).details;
        newList.dtls.addRef(decision);
      }
    }
    return newList;
  }

  // ___________________________________________________________________________
  /**
   * This method gets the list of ReassessmentBalanceInfo records that have been
   * created during the current transaction. This list will be used when
   * determining if any reassessed periods which contained replacement payments
   * have already been considered in the current reassessment.
   *
   * @param nominees
   *          The list of nominees on the case
   * @param prevReassessmentBalanceInfoDtlsList
   *          The list of ReassessmentBalnceInfo records that existed before the
   *          current reassessment begun.
   *
   * @return The list of ReassessmentBalanceInfo records that have been created
   *         during the current reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected ReassessmentBalanceInfoDtlsList getCurrentReassessmentBalanceInfoList(
      final CaseNomineeDetailsList nominees,
      final ReassessmentBalanceInfoDtlsList prevReassessmentBalanceInfoDtlsList)
      throws AppException, InformationalException {

    final ReassessmentBalanceInfoDtlsList currReassessmentBalanceInfoDtlsList = new ReassessmentBalanceInfoDtlsList();
    final ReassessmentBalanceInfoDtlsList tempReassessmentBalanceInfoDtlsList = getReassessmentBalanceInfoForNominees(
        nominees);

    // Compare the 2 lists to see which items have been added during the current
    // reassessment
    for (int i = 0; i < tempReassessmentBalanceInfoDtlsList.dtls.size(); i++) {

      boolean currentReassessmentResultCheck = true;

      for (int j = 0; j < prevReassessmentBalanceInfoDtlsList.dtls
          .size(); j++) {

        if (tempReassessmentBalanceInfoDtlsList.dtls.item(
            i).reassessmentBalanceInfoID == prevReassessmentBalanceInfoDtlsList.dtls
                .item(j).reassessmentBalanceInfoID) {

          currentReassessmentResultCheck = false;
        }
      }

      // Build the list of reassessment results created during the current
      // reassessment
      if (currentReassessmentResultCheck) {
        currReassessmentBalanceInfoDtlsList.dtls
            .addRef(tempReassessmentBalanceInfoDtlsList.dtls.item(i));
      }
    }
    return currReassessmentBalanceInfoDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to compare two Complete Case Decision Structs - this
   * function is business process specific, as the fields compared are dependent
   * on the context.
   *
   * @param c1
   *          details of the first complete decision
   * @param c2
   *          details of the second complete decision
   *
   * @return true if both complete decisions are the same, false if not.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected boolean compareNewToOld(final CompleteDecisionCreation c1,
      final CompleteDecisionCreation c2)
      throws AppException, InformationalException {

    boolean returnValue = false;

    if (isEqual(c1.details, c2.details)
        && !c1.details.decisionFromDate.before(c2.details.decisionFromDate)
        && !c1.details.decisionToDate.after(c2.details.decisionToDate)) {

      returnValue = true;
    }

    return returnValue;
  }

  // BEGIN, 179623, BD
  /**
   * This method is used to compare two Complete Case Decision Structs - this
   * function is business process specific, as the fields compared are dependent
   * on the context. This method differs from compareNewToOld in in that the
   * status field is excluded, as it will have been superseded earlier in the
   * transaction which will cause the compare to always fail and also the date
   * fields wil have previously been filtered appropriately and therefore not
   * included in the comparison.
   *
   * @param c1
   *          details of the first complete decision
   * @param c2
   *          details of the second complete decision
   *
   * @return true if both complete decisions are the same, false if not.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected boolean compareNewToExisting(final CompleteDecisionCreation c1,
      final CompleteDecisionCreation c2)
      throws AppException, InformationalException {

    boolean returnValue = false;

    if (c1.details.caseID == c2.details.caseID
        && c1.details.resultCode.equals(c2.details.resultCode)
        && c1.details.methodCode.equals(c2.details.methodCode)
        && c1.details.initReasonCode.equals(c2.details.initReasonCode)
        && c1.details.typeCode.equals(c2.details.typeCode)
        && c1.details.decisionFlow.equals(c2.details.decisionFlow)
        && c1.details.decisionResult.equals(c2.details.decisionResult)) {

      returnValue = true;
    }

    return returnValue;
  }

  /**
   * Determines equality between two case decisions.
   *
   * @param c1
   *          New case decision
   * @param c2
   *          Old case decision
   *
   * @return Returns {@code true} if the decisions are the same, otherwise
   *         {@code false}.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected boolean isEqual(final CaseDecisionDetails c1,
      final CaseDecisionDetails c2)
      throws AppException, InformationalException {

    boolean returnValue = false;

    if (c1.caseID == c2.caseID && c1.resultCode.equals(c2.resultCode)
        && c1.methodCode.equals(c2.methodCode)
        && c1.initReasonCode.equals(c2.initReasonCode)
        && c1.typeCode.equals(c2.typeCode)
        && c1.statusCode.equals(c2.statusCode)
        && c1.decisionFlow.equals(c2.decisionFlow)
        && c1.decisionResult.equals(c2.decisionResult)) {

      returnValue = true;
    }

    return returnValue;
  }

  // ___________________________________________________________________________
  /**
   * Checks the system to see if a replacement payment exists in the period
   * being reassessed and if so returns the details.
   *
   * @param key
   *          Contains the reassessment from / to dates.
   *
   * @return Flag to indicate if a replacement exists for the period specified
   *         in the key.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  protected ReassessCaseDetailsList getReplacementPaymentReassessmentDetails(
      final OverUnderPaymentIn key)
      throws AppException, InformationalException {

    final ReassessCaseDetailsList reassessCaseDetailsList = new ReassessCaseDetailsList();

    final FinInstructionIDList finInstructionIDList = getFinInstructionIDList(
        key);

    long caseNomineeID = 0;
    PaymentInstrumentDtls paymentInstrumentDtls = null;

    if (!finInstructionIDList.dtls.isEmpty()) {

      final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      OUTER: for (int i = 0; i < finInstructionIDList.dtls.size(); i++) {

        paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory
            .newInstance().readByFinInstructionID(
                finInstructionIDList.dtls.item(i)).pmtInstrumentID;

        // Check the payment instrument details to see if any were invalidated
        // within the period of interest
        paymentInstrumentDtls = PaymentInstrumentFactory.newInstance()
            .read(paymentInstrumentKey);

        if (paymentInstrumentDtls.invalidatedInd) {

          final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

          iliFinInstructID.finInstructionID = finInstructionIDList.dtls
              .item(i).finInstructionID;

          // Get the list of Instruction Line Items associated with the
          // Instrument/Instruction that was invalidated
          final InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory
              .newInstance().searchByFinInstructionID(iliFinInstructID);

          for (int j = 0; j < iliDtlsList.dtls.size(); j++) {

            if (iliDtlsList.dtls.item(j).caseID == key.caseID) {

              caseNomineeID = iliDtlsList.dtls.item(j).caseNomineeID;

              // We now know that an invalidated payment exists for the period.
              // A further check is required to see if it has been replaced.
              final CaseNomineePeriodAndReplacementPmtIndKey reassessmentKey = new CaseNomineePeriodAndReplacementPmtIndKey();

              // Set key to search ReassessmentBalanceInfo
              reassessmentKey.caseNomineeID = caseNomineeID;
              reassessmentKey.replacementPmtInd = true;
              reassessmentKey.coverPeriodFrom = iliDtlsList.dtls
                  .item(j).coverPeriodFrom;
              reassessmentKey.coverPeriodTo = iliDtlsList.dtls
                  .item(j).coverPeriodTo;

              final ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList = ReassessmentBalanceInfoFactory
                  .newInstance().searchByCaseNomineePeriodAndReplacementPmtInd(
                      reassessmentKey);

              if (reassessmentBalanceInfoDtlsList.dtls.isEmpty()) {

                // This means the invalidated period has not been replaced
                break OUTER;

              } else {

                // This means a replacement payment exists so return the details
                final ReassessCaseDetails reassessCaseDetails = new ReassessCaseDetails();

                reassessCaseDetails.amount = iliDtlsList.dtls.item(j).amount;
                reassessCaseDetails.caseNomineeID = iliDtlsList.dtls
                    .item(j).caseNomineeID;
                reassessCaseDetails.coverPeriodFrom = iliDtlsList.dtls
                    .item(j).coverPeriodFrom;
                reassessCaseDetails.coverPeriodTo = iliDtlsList.dtls
                    .item(j).coverPeriodTo;
                reassessCaseDetails.deliveryMethodType = iliDtlsList.dtls
                    .item(j).deliveryMethodType;
                reassessCaseDetails.financialCompID = iliDtlsList.dtls
                    .item(j).financialCompID;
                reassessCaseDetails.instructionLineItemType = iliDtlsList.dtls
                    .item(j).instructionLineItemType;
                reassessCaseDetails.instructLineItemID = iliDtlsList.dtls
                    .item(j).instructLineItemID;
                reassessCaseDetails.statusCode = iliDtlsList.dtls
                    .item(j).statusCode;

                final FinancialComponentKey finCompKey = new FinancialComponentKey();

                finCompKey.financialCompID = iliDtlsList.dtls
                    .item(j).financialCompID;
                final FinancialComponentDtls finCompDtls = FinancialComponentFactory
                    .newInstance().read(finCompKey);

                reassessCaseDetails.rulesObjectiveID = finCompDtls.rulesObjectiveID;

                reassessCaseDetailsList.dtls.addRef(reassessCaseDetails);
              }
            }
          } // end for j
        }
      } // end for i
    }

    return reassessCaseDetailsList;
  }

  // END, 178020

  // BEGIN, CR00201637, CR00204847, KH
  // ___________________________________________________________________________
  /**
   * Checks the individual component breakdown records for the current
   * reassessment to determine whether any of the amounts have changed for any
   * of the components involved in the reassessment.
   *
   * @param reassessmentHeader
   *          The reassessment details for a nominee.
   *
   * @return <code>TRUE</code> if the current reassessment results have changed
   *         otherwise <code>FALSE</CODE>.
   */
  @Override
  protected boolean checkCurrentReassessmentBreakdownResults(
      final NomineeReassessmentHeader reassessmentHeader)
      throws AppException, InformationalException {

    /*
     * Where the reassessment results in a NO CHANGE we must update the
     * breakdown amounts to ensure they're identical. If we do not do this we
     * may misinterpret this NO CHANGE result as an balancing over payment and
     * under payment.
     */
    // See if there is a previous reassessment to compare results with
    final long prevNomOverUnderPaymentID = findPrecedingNomineeOverUnderPayment(
        reassessmentHeader).nomineeOverUnderPaymentID;

    if (prevNomOverUnderPaymentID != 0) {

      if (checkPrecedingReassessmentResults(reassessmentHeader,
          prevNomOverUnderPaymentID)) {
        clearCurrentReassessmentBreakdownResults(reassessmentHeader);
        return false;
      }
    }

    // Check if it is a 'balancing' NO CHANGE
    for (int a = 0; a < reassessmentHeader.reassessmentDetailsList
        .size(); a++) {

      for (int b = 0; b < reassessmentHeader.reassessmentDetailsList
          .item(a).amountDetailsList.size(); b++) {

        for (int c = 0; c < reassessmentHeader.reassessmentDetailsList
            .item(a).amountDetailsList.item(b).breakdownPerObjectiveList.details
                .size(); c++) {

          if (!reassessmentHeader.reassessmentDetailsList
              .item(a).amountDetailsList
                  .item(b).breakdownPerObjectiveList.details
                      .item(c).actualAmount
                          .equals(reassessmentHeader.reassessmentDetailsList
                              .item(a).amountDetailsList
                                  .item(b).breakdownPerObjectiveList.details
                                      .item(c).reassessedAmount)) {

            return true;
          }
        } // end for c
      } // end for b
    } // end for a

    return false;
  }

  // END, CR00201637

  // ___________________________________________________________________________
  /**
   * Compare the current reassessment results with the preceding reassessment
   * results to determine whether there has been a change to any of the list
   * objectives included in the reassessment.
   *
   * @param reassessmentHeader
   *          Contains all the current reassessment information for a particular
   *          case nominee including the NomineeOverUnderPayment details.
   * @param prevNomOverUnderPaymentID
   *          ID used to obtain the preceding reassessment results for
   *          comparison.
   *
   * @return <code>TRUE</code> if the preceding reassessment results match the
   *         current reassessment results at the granular level otherwise
   *         <code>FALSE</CODE>.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected boolean checkPrecedingReassessmentResults(
      final NomineeReassessmentHeader reassessmentHeader,
      final long prevNomOverUnderPaymentID)
      throws AppException, InformationalException {

    final OverUnderPaymentBreakdown overUnderPaymentBreakdownObj = overUnderPaymentBreakdownDAO
        .newInstance();

    // BEGIN, CR00221971, CW
    // Build up the current breakdown list
    final List<OverUnderPaymentBreakdown> currBreakdownList = overUnderPaymentBreakdownObj
        .getCurrentBreakdown(reassessmentHeader, prevNomOverUnderPaymentID);

    // BEGIN, CR00243453, KH
    boolean changeDetected = false;

    // Loop through the current breakdown list and check for changes
    for (int i = 0; i < currBreakdownList.size(); i++) {

      if (!currBreakdownList.get(i).getReassessmentResult()
          .equals(REASSESSMENTRESULTEntry.NOCHANGE)) {

        changeDetected = true;
        break;
      }
    }
    // END, CR00221971

    if (!changeDetected) {
      // We have all NO CHANGE reassessments so this is a NO CHANGE scenario
      return true;
    }
    // END, CR00243453

    final NomineeOverUnderPayment prevNOUPayment = nomineeOverUnderPaymentDAO
        .get(prevNomOverUnderPaymentID);

    // Get the previous breakdown list
    final List<OverUnderPaymentBreakdown> prevBreakdownList = overUnderPaymentBreakdownDAO
        .searchByNomineeOverUnderPayment(prevNOUPayment);

    for (final Iterator<OverUnderPaymentBreakdown> itPrev = prevBreakdownList
        .iterator(); itPrev.hasNext();) {

      final OverUnderPaymentBreakdown prevBreakdown = itPrev.next();

      for (final Iterator<OverUnderPaymentBreakdown> itCurr = currBreakdownList
          .iterator(); itCurr.hasNext();) {

        final OverUnderPaymentBreakdown currBreakdown = itCurr.next();

        if (currBreakdown.getAmount().equals(prevBreakdown.getAmount())
            && currBreakdown.getRulesObjective()
                .equals(prevBreakdown.getRulesObjective())
            && currBreakdown.getReassessmentResult()
                .equals(prevBreakdown.getReassessmentResult())) {

          // Found a match so remove both
          itCurr.remove();
          itPrev.remove();
        }
      } // end itCurr
    } // end itPrev

    if (prevBreakdownList.size() == 0 && currBreakdownList.size() == 0) {
      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * Updates the objective breakdown records for the current reassessment to
   * ensure that the actual and reassessed amounts are equal. This must be done
   * for genuine NO CHANGE style reassessment results or we may misinterpret the
   * results as being comprised of a number of balancing granular reassessment
   * changes.
   *
   * @param reassessmentHeader
   *          Contains all the reassessment information for a particular case
   *          nominee including the NomineeOverUnderPayment details.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected void clearCurrentReassessmentBreakdownResults(
      final NomineeReassessmentHeader reassessmentHeader)
      throws AppException, InformationalException {

    for (int a = 0; a < reassessmentHeader.reassessmentDetailsList
        .size(); a++) {

      for (int b = 0; b < reassessmentHeader.reassessmentDetailsList
          .item(a).amountDetailsList.size(); b++) {

        for (int c = 0; c < reassessmentHeader.reassessmentDetailsList
            .item(a).amountDetailsList.item(b).breakdownPerObjectiveList.details
                .size(); c++) {

          reassessmentHeader.reassessmentDetailsList.item(a).amountDetailsList
              .item(b).breakdownPerObjectiveList.details.item(
                  c).reassessedAmount = reassessmentHeader.reassessmentDetailsList
                      .item(a).amountDetailsList
                          .item(b).breakdownPerObjectiveList.details
                              .item(c).actualAmount;
        } // end for c
      } // end for b
    } // end for a
  }

  // ___________________________________________________________________________
  /**
   * Identifies the NomineeOverUnderPayment record created during the
   * reassessment immediately preceding the current one. If no preceding record
   * is found then this must be the first reassessment. In this situation an
   * empty NomineeOverUnderPaymentDtls struct will be returned.
   *
   * @param reassessmentHeader
   *          Contains all the reassessment information for a particular case
   *          nominee including the NomineeOverUnderPayment details.
   *
   * @return The NomineeOverUnderPayment details created during the preceding
   *         reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected NomineeOverUnderPaymentDtls findPrecedingNomineeOverUnderPayment(
      final NomineeReassessmentHeader reassessmentHeader)
      throws AppException, InformationalException {

    final curam.core.intf.NomineeOverUnderPayment nomineeOverUnderPaymentObj = NomineeOverUnderPaymentFactory
        .newInstance();

    // Indicates that the most recent record has been found
    boolean mostRecentFound = false;

    // BEGIN, CR00211744, VM
    final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    caseNomineeKey.caseNomineeID = reassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID;

    final NomineeOverUnderPaymentDtlsList allNomineeOverUnderPayments = assessmentEngineEntity
        .getOverUnderPaymentsByCaseNomineeID(caseNomineeKey);

    // END, CR00211744

    if (allNomineeOverUnderPayments.dtls.isEmpty()) {
      return new NomineeOverUnderPaymentDtls();
    } else {

      // A previous record has been found so follow the chain to the most recent
      NomineeOverUnderPaymentDtls currNomineeOverUnderPaymentDtls = new NomineeOverUnderPaymentDtls();

      /*
       * Take the first item and check if the are any subsequent records i.e.
       * any records which have this ID as their 'previous'
       */
      final PreviousNomOverUnderPaymentKey previousKey = new PreviousNomOverUnderPaymentKey();

      previousKey.prevNomOverUnderPaymentID = allNomineeOverUnderPayments.dtls
          .item(0).nomineeOverUnderPaymentID;

      try {
        currNomineeOverUnderPaymentDtls = nomineeOverUnderPaymentObj
            .readByPreviousID(previousKey);
      } catch (final RecordNotFoundException e) {

        // There's no subsequent record so we've found the most recent
        mostRecentFound = true;
        currNomineeOverUnderPaymentDtls = allNomineeOverUnderPayments.dtls
            .item(0);
      }

      // Keep reading the next record in the chain
      while (!mostRecentFound) {

        previousKey.prevNomOverUnderPaymentID = currNomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

        try {
          currNomineeOverUnderPaymentDtls = nomineeOverUnderPaymentObj
              .readByPreviousID(previousKey);
        } catch (final RecordNotFoundException e) {
          mostRecentFound = true;
        }
      }

      return currNomineeOverUnderPaymentDtls;
    }
  }

  // END, CR00204847

  // ___________________________________________________________________________
  /**
   * If at any point during reassessment we determine that the period needs to
   * be extended this method will look up the decisions to cover this extended
   * period from the database and call reassFCs with a more complete decision
   * set.
   *
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          A structure which aggregates a list of existing decisions and
   *          their associated components.
   * @param reassessmentMode
   *          the mode to run in
   * @param overUnderPaymentIn
   *          the key details for this operation caseID, from and to date
   * @param storeDecisionsInd
   *          Indicates if any reassessment due to any change in the periods
   *          should result in the storing of the newly generated decisions.
   *
   * @return indicates if data exists to reassess over the extended period
   *         (true) or if reassessment over the extended period is unnecessary.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public boolean changePeriod(
      final CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions,
      final ReassessmentMode reassessmentMode,
      final OverUnderPaymentIn overUnderPaymentIn,
      final StoreDecisionsInd storeDecisionsInd)
      throws AppException, InformationalException {

    // key for determining eligibility for reassessment
    final DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();

    // caseDecision manipulation variables
    final CaseIDStatusInitReasonCodeDateKey caseIDStatusInitReasonCodeDateKey = new CaseIDStatusInitReasonCodeDateKey();
    CaseDecisionDtlsList currentCaseDecisionDtlsList = new CaseDecisionDtlsList();
    final CaseDecisionDtlsList appendNewCaseDecisionDtlsList = new CaseDecisionDtlsList();
    final CaseDecisionDtlsList appendExistCaseDecisionDtlsList = new CaseDecisionDtlsList();

    // periods do not match we need to return to reassFCs with a more
    // complete decision set

    determineEligibilityKey.caseID = overUnderPaymentIn.caseID;
    determineEligibilityKey.fromDate = overUnderPaymentIn.fromDate;
    determineEligibilityKey.toDate = overUnderPaymentIn.toDate;
    determineEligibilityKey.reconciliationInd = false;

    // set key to read caseDecision
    caseIDStatusInitReasonCodeDateKey.caseID = overUnderPaymentIn.caseID;
    caseIDStatusInitReasonCodeDateKey.statusCode = newCaseDecisions.dtls
        .item(0).details.statusCode;
    caseIDStatusInitReasonCodeDateKey.initReasonCode = newCaseDecisions.dtls
        .item(0).details.initReasonCode;
    caseIDStatusInitReasonCodeDateKey.fromDate = determineEligibilityKey.fromDate;
    caseIDStatusInitReasonCodeDateKey.toDate = determineEligibilityKey.toDate;

    // BEGIN, CR00211744, VM
    currentCaseDecisionDtlsList = assessmentEngineEntity
        .getDecisionByCaseIDStatusInitReasonCodeDate(
            caseIDStatusInitReasonCodeDateKey);
    // END, CR00211744

    // for every current stored decision
    for (int i = 0; i < currentCaseDecisionDtlsList.dtls.size(); i++) {

      // BEGIN, CR00244499, KH
      boolean existDecisionFound = false;
      boolean newDecisionFound = false;
      // END, CR00244499

      // BEGIN, CR00361058, KH
      final DateRange currentDecisionDateRange = new DateRange(
          currentCaseDecisionDtlsList.dtls.item(i).decisionFromDate,
          currentCaseDecisionDtlsList.dtls.item(i).decisionToDate);

      // END, CR00361058

      // iterate through full list of current existing case decisions
      for (int k = 0; k < existingCaseDecisions.dtls.size(); k++) {

        // BEGIN, CR00361058, KH
        final DateRange existingDecisionDateRange = new DateRange(
            existingCaseDecisions.dtls.item(k).details.decisionFromDate,
            existingCaseDecisions.dtls.item(k).details.decisionToDate);

        // Do we have a case decision for this period
        if (existingDecisionDateRange.equals(currentDecisionDateRange)) {
          existDecisionFound = true;
          break;
        }
        // END, CR00361058
      }

      if (!existDecisionFound) {
        // we don't have this decision and we need it, so we add it to
        // the 'append' list for existing case decisions.
        appendExistCaseDecisionDtlsList.dtls
            .addRef(currentCaseDecisionDtlsList.dtls.item(i));
      }

      // iterate through full list of current new case decisions
      for (int l = 0; l < newCaseDecisions.dtls.size(); l++) {

        // BEGIN, CR00361058, KH
        final DateRange newDecisionDateRange = new DateRange(
            newCaseDecisions.dtls.item(l).details.decisionFromDate,
            newCaseDecisions.dtls.item(l).details.decisionToDate);

        // Do we have this case decision already?
        if (newCaseDecisions.dtls
            .item(l).details.caseDecisionID == currentCaseDecisionDtlsList.dtls
                .item(i).caseDecisionID) {
          newDecisionFound = true;
          break;
        } else if (newDecisionDateRange.contains(currentDecisionDateRange)) {

          /*
           * We don't have this decision, but it's date range is covered by a
           * decision that we DO have, so ignore it. It may have been filtered
           * out earlier in the processing and we don't want to add it back in.
           */
          newDecisionFound = true;
          break;
        } else {
          newDecisionFound = false;
        }
        // END, CR00361058
      }

      if (!newDecisionFound) {
        // we don't have this decision and we need it.
        appendNewCaseDecisionDtlsList.dtls
            .addRef(currentCaseDecisionDtlsList.dtls.item(i));
      }
    }

    for (int i = 0; i < appendExistCaseDecisionDtlsList.dtls.size(); i++) {

      final CompleteDecisionCreation completeDecisionCreation = new CompleteDecisionCreation();

      completeDecisionCreation.details
          .assign(appendExistCaseDecisionDtlsList.dtls.item(i));

      updateCompleteCaseDecisionData(determineEligibilityKey,
          completeDecisionCreation);

      existingCaseDecisions.dtls.addRef(completeDecisionCreation);
    }

    for (int i = 0; i < appendNewCaseDecisionDtlsList.dtls.size(); i++) {

      final CompleteDecisionCreation completeDecisionCreation = new CompleteDecisionCreation();

      completeDecisionCreation.details
          .assign(appendNewCaseDecisionDtlsList.dtls.item(i));

      updateCompleteCaseDecisionData(determineEligibilityKey,
          completeDecisionCreation);

      newCaseDecisions.dtls.addRef(completeDecisionCreation);
    }

    // If new decisions where added to the list then we need to restart this
    // processing
    if (!appendNewCaseDecisionDtlsList.dtls.isEmpty()
        || !appendExistCaseDecisionDtlsList.dtls.isEmpty()) {

      // BEGIN, CR00180474, VM
      Date tempFromDate = Date.kZeroDate;
      Date tempToDate = Date.kZeroDate;

      if (!appendNewCaseDecisionDtlsList.dtls.isEmpty()) {
        // it may be that the OverUnderPaymentIn.toDate is later than the
        // latest newCaseDecisions.decisionToDate, or that the fromDate is
        // earlier than the newCaseDecisions.decisionFromDate. If that is
        // the case, then reassessment needs to be invoked again through
        // ProductEligibility.normalReassessment
        for (int i = 0; i < newCaseDecisions.dtls.size(); i++) {
          if (newCaseDecisions.dtls.item(i).details.decisionFromDate
              .before(tempFromDate) || tempFromDate.isZero()) {

            tempFromDate = newCaseDecisions.dtls
                .item(i).details.decisionFromDate;
          }
        }
        for (int i = 0; i < newCaseDecisions.dtls.size(); i++) {
          if (newCaseDecisions.dtls.item(i).details.decisionToDate
              .after(tempToDate) || tempToDate.isZero()) {

            tempToDate = newCaseDecisions.dtls.item(i).details.decisionToDate;
          }
        }
      }

      if (!reassessToCreateNewDecisions) {
        // BEGIN, CR00190883, KH
        // We can only compare the temp dates if they have been set
        if (!tempFromDate.isZero()
            && overUnderPaymentIn.fromDate.before(tempFromDate)
            || !tempToDate.isZero()
                && overUnderPaymentIn.toDate.after(tempToDate)) {
          // END, CR00190883

          reassessToCreateNewDecisions = true;
          ProductEligibilityFactory.newInstance()
              .normalReassessment(determineEligibilityKey, reassessmentMode);
        } else {
          reassessFCs(newCaseDecisions, existingCaseDecisions, reassessmentMode,
              overUnderPaymentIn, storeDecisionsInd);
        }

        // BEGIN, CR00251296, KH
        /*
         * We return true because the reassessments will have been processed by
         * either 'normalReassessment' or 'reassessFCs' and we want the current
         * processing to stop immediately.
         */
        return true;
        // END, CR00251296
      }
      // END, CR00180474
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * This method calculates the list of dates which cover the payment periods
   * inside the reassessment period.
   *
   * @param key
   *          Details of the reassessment, case, period etc.
   * @param componentDetailsList
   *          Details of the components to be reassessed
   * @param reassessCaseDetailsList
   *          Details of the reassessed case details
   *
   * @return A list of the dates of the payment periods inside the reassessment
   *         period.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DateList determineReassessmentPeriods(final OverUnderPaymentIn key,
      final ComponentDetailsList componentDetailsList,
      final ReassessCaseDetailsList reassessCaseDetailsList)
      throws AppException, InformationalException {

    // Call local method to order the component details list by from date
    orderComponentList(componentDetailsList);

    // Call local method to calculate cover period financial boundary dates
    calculateBoundaryFinancialCoverPeriodDates(reassessCaseDetailsList);

    // Call local method to retrieve the caseNomineeID
    key.caseNomineeID = getCaseNominee(componentDetailsList,
        reassessCaseDetailsList).caseNomineeID;

    // Call local method to compile the initial date list
    final DateList dateList = compileInitialDateList(key, componentDetailsList);

    // Call local method to see if the financials cover period from dates need
    // to be considered when compiling the reassessment date list
    DateList completeDateList = processFinancialDates(key, dateList,
        reassessCaseDetailsList, componentDetailsList);

    // BEGIN, CR00161231, CR00173527, KH
    // Check if there are any replacement payment dates which should be included
    completeDateList = considerDatesForReplacementPayment(key,
        completeDateList);
    // END, CR00161231, CR00173527

    // Call local method to order the component date list in ascending order
    orderDateList(completeDateList);

    // Finally, we need to see if the maxCoverPeriodTo date needs to be
    // considered in our reassessment processing
    return considerMaxCoverPeriodToDate(key, completeDateList,
        componentDetailsList);
  }

  // ___________________________________________________________________________
  /**
   * This method gets the details of the reassessment for each nominee over the
   * period covered by the dateList.
   *
   * @param overUnderPaymentIn
   *          Details of the reassessment, case, period etc.
   * @param componentDetailsList
   *          details of the components to be reassessed
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          A structure which aggregates a list of existing decisions and
   *          their associated components.
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   * @param reassessCaseDetailsList
   *          Details of the reassessed case
   *
   * @return Results of the reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public GetReassessmentDetailsResult getReassessmentDetails(
      final OverUnderPaymentIn overUnderPaymentIn,
      final ComponentDetailsList componentDetailsList,
      final CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions,
      final ReassessmentMode reassessmentMode,
      final ReassessCaseDetailsList reassessCaseDetailsList)
      throws AppException, InformationalException {

    // getReassessmentDetailsResult variable.
    final GetReassessmentDetailsResult getReassessmentDetailsResult = new GetReassessmentDetailsResult();

    // getActualDetailsResult variable.
    final GetActualDetailsResult getActualDetailsResult = new GetActualDetailsResult();

    // Indicates whether CaseNomineEObjective records should be inserted
    // where required for a FC for a default nominee.
    final InsertAssignmentInd insertAssignmentInd = new InsertAssignmentInd();

    // Set this to false as we only generate FCs for memory use here,
    // therefore don't want any CaseNomineeObjective records inserted.
    insertAssignmentInd.insertAssignmentInd = false;

    // BEGIN, CR00103515, BD
    final ArrayList<Long> nomineeCaseIDs = new ArrayList<Long>();

    // END, CR00103515

    // Make up a list of unique CaseNomineeID's between new components &
    // existing financials.
    for (int j = 0; j < componentDetailsList.dtls.size(); j++) {

      if (!nomineeCaseIDs.contains(
          new Long(componentDetailsList.dtls.item(j).caseNomineeID))) {

        nomineeCaseIDs
            .add(new Long(componentDetailsList.dtls.item(j).caseNomineeID));
      }
    }

    // BEGIN, 178020, CSH
    // Ensure any nominees from replacement payments which overlap the
    // period of this reassessment are included in the nominee list
    final ReassessCaseDetailsList replacementReassessCaseDetailsList = getReplacementPaymentReassessmentDetails(
        overUnderPaymentIn);

    for (int m = 0; m < replacementReassessCaseDetailsList.dtls.size(); m++) {

      if (!nomineeCaseIDs.contains(new Long(
          replacementReassessCaseDetailsList.dtls.item(m).caseNomineeID))) {
        // BEGIN, 179623, BD
        // Add the replacementReassessCaseDetailsList item to the
        // reassessCaseDetailsList
        // Note that this was previously tested as being outside the
        // if clause in 6203.
        reassessCaseDetailsList.dtls
            .addRef(replacementReassessCaseDetailsList.dtls.item(m));
        // END, 179623, BD

        nomineeCaseIDs.add(new Long(
            replacementReassessCaseDetailsList.dtls.item(m).caseNomineeID));
      }
    } // for int m
    // END, 178020

    for (int k = 0; k < reassessCaseDetailsList.dtls.size(); k++) {

      if (!nomineeCaseIDs.contains(
          new Long(reassessCaseDetailsList.dtls.item(k).caseNomineeID))) {

        nomineeCaseIDs
            .add(new Long(reassessCaseDetailsList.dtls.item(k).caseNomineeID));
      }
    }

    for (int l = 0; l < nomineeCaseIDs.size(); l++) {

      final ComponentDetailsList currentNomineeComponentDetailsList = new ComponentDetailsList();

      final ReassessCaseDetailsList currentNomineeReassessCaseDetailsList = new ReassessCaseDetailsList();

      // Get the components for this nominee.
      for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

        if (nomineeCaseIDs.get(l).equals(
            new Long(componentDetailsList.dtls.item(i).caseNomineeID))) {
          // BEGIN, CR00103515, BD
          currentNomineeComponentDetailsList.dtls
              .addRef(componentDetailsList.dtls.item(i));
          // END, CR00103515
        }
      }

      // Get the financials for this nominee.
      for (int i = 0; i < reassessCaseDetailsList.dtls.size(); i++) {

        if (nomineeCaseIDs.get(l).equals(
            new Long(reassessCaseDetailsList.dtls.item(i).caseNomineeID))) {

          // BEGIN, CR00103515, BD
          currentNomineeReassessCaseDetailsList.dtls
              .addRef(reassessCaseDetailsList.dtls.item(i));
          // END, CR00103515
        }
      }

      // Process the list for this nominee.
      getReassessmentDetailsForNominee(overUnderPaymentIn,
          currentNomineeComponentDetailsList, reassessmentMode,
          getActualDetailsResult, currentNomineeReassessCaseDetailsList);
    } // end for l

    // Form result list
    getReassessmentDetailsResult.completeCaseReassessment = formResultList(
        getActualDetailsResult.completeCaseReassessment, componentDetailsList,
        newCaseDecisions, existingCaseDecisions);

    // BEGIN, CR00198173, SS
    // Initially assigning caseReassessmentObj to the present class and
    // this might be assigned to a subclass of CaseReassessment, if it is
    // defined in the property.
    curam.core.intf.CaseReassessment caseReassessmentObj = this;

    // Read the class name from property file.
    final String financialResolverName = Configuration
        .getProperty(EnvVars.ENV_FINANCIAL_HOOK_CASEREASSESSMENT_CLASS);

    // BEGIN, CR00206354, SS
    final Object obj = FinancialUtil.getResolverClassName(financialResolverName,
        overUnderPaymentIn.caseID);

    if (null != obj) {
      caseReassessmentObj = (curam.core.intf.CaseReassessment) obj;
    }
    // END, CR00206354

    // BEGIN, 178020, CSH
    // Ensure the caseID field is populated
    if (getReassessmentDetailsResult.completeCaseReassessment.overUnderPaymentHeaderDtls.caseID == 0) {

      getReassessmentDetailsResult.completeCaseReassessment.overUnderPaymentHeaderDtls.caseID = overUnderPaymentIn.caseID;
    }
    // END, 178020

    // BEGIN, CR00175021, KH
    caseReassessmentObj.processReassessmentDetails1(
        getReassessmentDetailsResult.completeCaseReassessment,
        componentDetailsList, reassessmentMode);
    // END, CR00198173, CR00175021
    return getReassessmentDetailsResult;
  }

  // ___________________________________________________________________________
  /**
   * This method gets the reassessment details for a nominee.
   *
   * @param overUnderPaymentIn
   *          Details of the reassessment, case, period etc.
   * @param componentDetailsList
   *          Details of the components to be reassessed
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   * @param getActualDetailsResult
   *          Results of the reassessment.
   * @param reassessCaseDetailsList
   *          Details of the reassessed case
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void getReassessmentDetailsForNominee(
      final OverUnderPaymentIn overUnderPaymentIn,
      final ComponentDetailsList componentDetailsList,
      final ReassessmentMode reassessmentMode,
      final GetActualDetailsResult getActualDetailsResult,
      final ReassessCaseDetailsList reassessCaseDetailsList)
      throws AppException, InformationalException {

    final OverUnderPaymentIn periodOverUnderPaymentIn = new OverUnderPaymentIn();

    // start date of the reassessment
    Date startDate = Date.kZeroDate;

    // fCGenerationUtil object
    final FCGenerationUtil fCGenerationUtilObj = FCGenerationUtilFactory
        .newInstance();
    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList = new ProductDeliveryFinCompDtlsList();

    // Local OverUnderPaymentIn struct used to pass date details to
    // sub-routines initialized to input value
    periodOverUnderPaymentIn.assign(overUnderPaymentIn);

    // Get the date list
    final DateList dateList = determineReassessmentPeriods(overUnderPaymentIn,
        componentDetailsList, reassessCaseDetailsList);

    // Generate the financial components
    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      // BEGIN, CR00078445, CR00079392 VM
      final ProductDeliveryFinCompDtlsList tempProductDeliveryFinCompDtlsList = fCGenerationUtilObj
          .generateFCDetails(componentDetailsList.dtls.item(i),
              componentDetailsList.dtls.item(i).componentCaseDecisionLinkList);

      // END, CR00078445

      productDeliveryFinCompDtlsList.dtls
          .addAll(tempProductDeliveryFinCompDtlsList.dtls);
    } // end for i

    // Set start date to first iterator position, first date.
    if (!dateList.dtls.isEmpty()) {
      startDate = dateList.dtls.item(0).date;
    }

    // BEGIN, CR00167160, CR00173527, KH
    // Assign the variable the latest date in the dateList plus one day
    if (maxCoverPeriodToAddedToList) {
      finalComponentDateListDate = maxCoverPeriodTo;
    } else {
      finalComponentDateListDate = dateList.dtls
          .item(dateList.dtls.size() - 1).date.addDays(1);
    }
    // END, CR00167160, CR00173527

    // BEGIN, CR00211347, KH
    if (productDeliveryFinCompDtlsList.dtls.size() > 0) {

      /*
       * For daily patterns we need to add an additional date into the date list
       * so that we can correctly identify the actual and reassessed amounts for
       * the last day.
       */
      final FrequencyPattern freq = new FrequencyPattern(
          productDeliveryFinCompDtlsList.dtls.item(0).frequency);

      if (!freq.isZeroPattern() && freq.getPatternType()
          .equals(FrequencyPattern.PatternType.kDaily)) {

        final DateStruct extraDate = new DateStruct();

        extraDate.date = dateList.dtls.item(dateList.dtls.size() - 1).date
            .addDays(1);

        dateList.dtls.addRef(extraDate);
      }
    }
    // END, CR00211347

    if (dateList.dtls.size() >= kDateListMinumumSize) {

      for (int i = 1; i < dateList.dtls.size(); i++) {

        // Set the date values on the overUnderPaymentIn struct
        periodOverUnderPaymentIn.fromDate = startDate;
        periodOverUnderPaymentIn.toDate = dateList.dtls.item(i).date;
        periodOverUnderPaymentIn.caseNomineeID = dateList.caseNomineeID;

        // BEGIN, CR00180474, VM
        if (previousCoverPeriodTo.before(periodOverUnderPaymentIn.toDate)) {
          // END, CR00180474

          // BEGIN, CR00175021, KH
          getActualDetails1(periodOverUnderPaymentIn, reassessmentMode,
              getActualDetailsResult);
          // END, CR00175021

          // Only process the reassessed details if the actuals for the cover
          // period have also been processed
          if (actualsProcessed) {

            getReassessedDetails(periodOverUnderPaymentIn,
                productDeliveryFinCompDtlsList,
                getActualDetailsResult.completeCaseReassessment);
          }
        }

        // roll the start Date forward
        startDate = dateList.dtls.item(i).date;
      } // end for i
    } // if (dateList.dtls.size() >= kDateListMinumumSize)

    // Re-set to a null date for next nominee
    previousCoverPeriodTo = Date.kZeroDate;

    maxCoverPeriodToAddedToList = false;
  }

  // BEGIN, CR00195852, CSH
  // ___________________________________________________________________________
  /**
   * This method calculates the over under payment and determines the result
   * type for the reassessment.
   *
   * @param completeCaseReassessment
   *          Results of reassessment for processing.
   * @param componentDetailsList
   *          The list of components to be reassessed
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   *
   * @return Result of the reassessment processing.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  @Override
  public CompleteCaseReassessment processReassessmentDetails1(
      final CompleteCaseReassessment completeCaseReassessment,
      final ComponentDetailsList componentDetailsList,
      final ReassessmentMode reassessmentMode)
      throws AppException, InformationalException {

    // END, CR00198672

    // the total deductions 'actually' paid
    Money totalActualDeductionAmount = Money.kZeroMoney;

    // the 'reassessed' total for deductions
    Money totalReassessedDeductionAmount = Money.kZeroMoney;

    // the total amount received (for liability)
    Money totalReceivedAmount = Money.kZeroMoney;

    // the total amount 'actually' paid
    Money totalActualAmount = Money.kZeroMoney;

    // the total reassessed amount
    Money totalReassessedAmount = Money.kZeroMoney;

    // the total 'actual' amount less any deductions
    Money netActualAmount = Money.kZeroMoney;

    // the total reassessed amount less any deductions
    Money netReassessedAmount = Money.kZeroMoney;

    // the total received amount less any deductions (for liability)
    Money netReceivedAmount = Money.kZeroMoney;

    // the total figure for overpayment
    Money totalOverpayment = Money.kZeroMoney;

    // the total figure for underpayment
    Money totalUnderpayment = Money.kZeroMoney;

    // the final reassessed figure
    Money finalTotalReassessed = Money.kZeroMoney;

    // the final actual figure
    Money finalTotalActual = Money.kZeroMoney;

    ObjectiveTotalDetailsList objectiveTotalDetailsList = new ObjectiveTotalDetailsList();

    boolean objectiveMatchFound = false;

    // caseHeader manipulation variables
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // set key to read caseHeader
    caseHeaderKey.caseID = completeCaseReassessment.overUnderPaymentHeaderDtls.caseID;

    // read caseHeader
    final CaseHeaderDtls caseHeaderDtls = cachedCaseHeaderObj
        .read(caseHeaderKey);

    // if there are entries in the result list
    if (completeCaseReassessment.nomineeReassessmentHeaderList.size() > 0) {

      // Process reassessmentDetails to include AmountDetails for net values.
      // And set NomineeUnderOverpayment total and type code
      for (int i = 0; i < completeCaseReassessment.nomineeReassessmentHeaderList
          .size(); i++) {

        completeCaseReassessment.nomineeReassessmentHeaderList.item(
            i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

        // reset net values
        netActualAmount = Money.kZeroMoney;
        netReassessedAmount = Money.kZeroMoney;
        netReceivedAmount = Money.kZeroMoney;
        finalTotalReassessed = Money.kZeroMoney;
        finalTotalActual = Money.kZeroMoney;

        for (int j = 0; j < completeCaseReassessment.nomineeReassessmentHeaderList
            .item(i).reassessmentDetailsList.size(); j++) {

          // reset totals
          totalActualDeductionAmount = Money.kZeroMoney;
          totalReassessedDeductionAmount = Money.kZeroMoney;
          totalReceivedAmount = Money.kZeroMoney;
          totalActualAmount = Money.kZeroMoney;
          totalReassessedAmount = Money.kZeroMoney;

          for (int k = 0; k < completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentDetailsList.item(j).amountDetailsList
                  .size(); k++) {

            // add up gross values
            if (completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).reassessmentDetailsList.item(j).amountDetailsList
                    .item(k).amountType.equals(REASSESSMENT_AMOUNT.GROSS)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType.equals(REASSESSMENT_AMOUNT.BILL)) {

              totalReceivedAmount = new Money(totalReceivedAmount.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).receivedAmount.getValue());

              totalActualAmount = new Money(totalActualAmount.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).actualAmount.getValue());

              totalReassessedAmount = new Money(totalReassessedAmount.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).reassessedAmount.getValue());
            }

            // For each instruction line item of the reassessment payment get
            // the total actual and reassessed amounts for each objective
            // involved in each instruction line item.
            objectiveTotalDetailsList = completeCaseReassessment.objectiveTotalDetailsList;

            for (int m = 0; m < completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).reassessmentDetailsList.item(j).amountDetailsList
                    .item(k).breakdownPerObjectiveList.details.size(); m++) {

              objectiveMatchFound = false;

              for (int n = 0; n < objectiveTotalDetailsList.dtls.size(); n++) {

                // BEGIN, CR00175021, KH
                /*
                 * If there is a case decision objective match, add the actual
                 * amount and reassessed amount onto the current totals for that
                 * case decision objective.
                 */
                if (objectiveTotalDetailsList.dtls.item(n).rulesObjectiveID
                    .equals(
                        completeCaseReassessment.nomineeReassessmentHeaderList
                            .item(i).reassessmentDetailsList
                                .item(j).amountDetailsList
                                    .item(k).breakdownPerObjectiveList.details
                                        .item(m).rulesObjectiveID)
                    && objectiveTotalDetailsList.dtls.item(n).relatedReference
                        .equals(
                            completeCaseReassessment.nomineeReassessmentHeaderList
                                .item(i).reassessmentDetailsList
                                    .item(j).amountDetailsList.item(
                                        k).breakdownPerObjectiveList.details
                                            .item(m).relatedReference)) {
                  // END, CR00175021

                  objectiveMatchFound = true;

                  // Adjust the totals that exist for this
                  objectiveTotalDetailsList.dtls
                      .item(n).actualAmount = new Money(
                          objectiveTotalDetailsList.dtls.item(n).actualAmount
                              .getValue()
                              + completeCaseReassessment.nomineeReassessmentHeaderList
                                  .item(i).reassessmentDetailsList
                                      .item(j).amountDetailsList.item(
                                          k).breakdownPerObjectiveList.details
                                              .item(m).actualAmount.getValue());

                  objectiveTotalDetailsList.dtls
                      .item(n).reassessedAmount = new Money(
                          objectiveTotalDetailsList.dtls
                              .item(n).reassessedAmount.getValue()
                              + completeCaseReassessment.nomineeReassessmentHeaderList
                                  .item(i).reassessmentDetailsList
                                      .item(j).amountDetailsList.item(
                                          k).breakdownPerObjectiveList.details
                                              .item(m).reassessedAmount
                                                  .getValue());
                }
              } // end for n

              /*
               * If the case decision objective does not match any currently
               * contained in the list add a new record for it.
               */
              if (!objectiveMatchFound) {

                final ObjectiveTotalDetails objectiveTotalDetails = new ObjectiveTotalDetails();

                // BEGIN, CR00175021, KH
                objectiveTotalDetails.relatedReference = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).relatedReference;
                // END, CR00175021

                objectiveTotalDetails.rulesObjectiveID = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).rulesObjectiveID;

                objectiveTotalDetails.actualAmount = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).actualAmount;

                objectiveTotalDetails.reassessedAmount = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).reassessedAmount;

                objectiveTotalDetailsList.dtls.addRef(objectiveTotalDetails);
              }
            } // end for m

            // add up deductions
            if (completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).reassessmentDetailsList.item(j).amountDetailsList
                    .item(k).amountType.equals(REASSESSMENT_AMOUNT.TAX)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType.equals(REASSESSMENT_AMOUNT.UTILITY)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType
                            .equals(REASSESSMENT_AMOUNT.LIABILITY)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType
                            .equals(REASSESSMENT_AMOUNT.DEDUCTION)) {

              totalActualDeductionAmount = new Money(totalActualDeductionAmount
                  .getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).actualAmount.getValue());

              totalReassessedDeductionAmount = new Money(
                  totalReassessedDeductionAmount.getValue()
                      + completeCaseReassessment.nomineeReassessmentHeaderList
                          .item(i).reassessmentDetailsList
                              .item(j).amountDetailsList
                                  .item(k).reassessedAmount.getValue());
            }
          } // end for k

          // calculate net values
          netActualAmount = new Money(
              netActualAmount.getValue() + totalActualAmount.getValue());

          finalTotalActual = new Money(
              finalTotalActual.getValue() + totalActualAmount.getValue()
                  - totalActualDeductionAmount.getValue());

          netActualAmount = new Money(netActualAmount.getValue()
              - totalActualDeductionAmount.getValue());

          netReassessedAmount = new Money(netReassessedAmount.getValue()
              + totalReassessedAmount.getValue());

          finalTotalReassessed = new Money(
              finalTotalReassessed.getValue() + totalReassessedAmount.getValue()
                  - totalReassessedDeductionAmount.getValue());

          netReassessedAmount = new Money(netReassessedAmount.getValue()
              - totalReassessedDeductionAmount.getValue());

          netReceivedAmount = new Money(
              netReceivedAmount.getValue() + totalReceivedAmount.getValue());

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.actualAmount = new Money(
              totalActualAmount.getValue()
                  - totalActualDeductionAmount.getValue());

          reassessmentAmountInfoDetails.reassessedAmount = new Money(
              totalReassessedAmount.getValue()
                  - totalReassessedDeductionAmount.getValue());

          reassessmentAmountInfoDetails.receivedAmount = totalReceivedAmount;

          // if this is a liability
          if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

            // Set reassessed Amount Type
            reassessmentAmountInfoDetails.amountType = REASSESSMENT_AMOUNT.TOTALBILL;
          } else {

            // Set reassessed Amount Type
            reassessmentAmountInfoDetails.amountType = REASSESSMENT_AMOUNT.NET;
          }

          // Add net amount details record
          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentDetailsList.item(j).amountDetailsList
                  .addRef(reassessmentAmountInfoDetails);
        } // end for j

        // set the nomineeOverUnderPayment dtls
        // if this is a liability and were in reassessmentMode
        if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)
            && reassessmentMode.reassessmentMode
                .equals(REASSESSMENTPROCMODE.RECONCILIATION)) {

          if (netReassessedAmount.getValue() > netReceivedAmount.getValue()) {

            completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                    netReassessedAmount.getValue()
                        - netReceivedAmount.getValue());

            completeCaseReassessment.nomineeReassessmentHeaderList.item(
                i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;

            totalUnderpayment = new Money(totalUnderpayment.getValue()
                + completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).nomineeOverUnderPaymentDtls.totalAmount
                        .getValue());

          } else {

            if (netReceivedAmount.getValue() > netReassessedAmount.getValue()) {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                      netReceivedAmount.getValue()
                          - netReassessedAmount.getValue());

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;

              totalOverpayment = new Money(totalOverpayment.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).nomineeOverUnderPaymentDtls.totalAmount
                          .getValue());

            } else {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                      netReceivedAmount.getValue()
                          - netReassessedAmount.getValue());

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;
            }
          }
        } else {

          // If the total Reassessed Amount is greater that the actual amount
          // paid, there is an underpayment
          if (finalTotalReassessed.getValue() > finalTotalActual.getValue()) {

            completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                    finalTotalReassessed.getValue()
                        - finalTotalActual.getValue());

            completeCaseReassessment.nomineeReassessmentHeaderList.item(
                i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;

            totalUnderpayment = new Money(totalUnderpayment.getValue()
                + completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).nomineeOverUnderPaymentDtls.totalAmount
                        .getValue());

          } else {

            // If the total Reassessed Amount is less that the actual amount
            // paid, there is an overpayment
            if (finalTotalReassessed.getValue() < finalTotalActual.getValue()) {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                      finalTotalActual.getValue()
                          - finalTotalReassessed.getValue());

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;

              totalOverpayment = new Money(totalOverpayment.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).nomineeOverUnderPaymentDtls.totalAmount
                          .getValue());

            } else {

              // otherwise there has been no change in the amount to be paid,
              // but differences still exists in the calculations - i.e.
              // the deduction amounts have varied, but we don't issue under or
              // over payments in respect of this.
              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.totalAmount = new Money(0);

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).reassessmentSummaryDetails.totalAmount = Money.kZeroMoney;

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).reassessmentSummaryDetails.totalActualAmount = netReassessedAmount;
            }
          }
        }

        // Here is where we must total the over/under payment for the nominee -
        if (totalOverpayment.getValue() > totalUnderpayment.getValue()) {

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentSummaryDetails.totalAmount = new Money(
                  totalOverpayment.getValue() - totalUnderpayment.getValue());

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.totalActualAmount = netReassessedAmount;
        }

        if (totalUnderpayment.getValue() > totalOverpayment.getValue()) {

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentSummaryDetails.totalAmount = new Money(
                  totalUnderpayment.getValue() - totalOverpayment.getValue());

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.totalActualAmount = netReassessedAmount;
        }

        // now need to set the totalUnderPayment and totalOverPayment to zero,
        // as each nominee is getting reassessed separately
        totalOverpayment = curam.util.type.Money.kZeroMoney;
        totalUnderpayment = curam.util.type.Money.kZeroMoney;

        completeCaseReassessment.objectiveTotalDetailsList = objectiveTotalDetailsList;
      }
    }

    return completeCaseReassessment;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the details of the actual payments made by nominee.
   *
   * @param key
   *          Details of the reassessment, case, period etc.
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   * @param getActualDetailsResult
   *          A struct to hold the details of what was 'actually' paid already.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  @Override
  protected void getActualDetails1(final OverUnderPaymentIn key,
      final ReassessmentMode reassessmentMode,
      final GetActualDetailsResult getActualDetailsResult)
      throws AppException, InformationalException {

    // END, CR00198672

    // DetermineReassessmentAmountType object
    final DetermineReassessmentAmountType determineReassessmentAmountTypeObj = DetermineReassessmentAmountTypeFactory
        .newInstance();

    final RetrieveCaseFinancialsKey retrieveCaseFinancialsKey = new RetrieveCaseFinancialsKey();
    ReassessCaseDetailsList reassessCaseDetailsList;
    ReassessmentAmountInfoDtls reassessmentAmountInfoDtls;

    // indicates that a NomineeHeader exists for the nominee
    boolean nomineeHeaderFound = false;

    // indicates that a ReassessmentInfoDtls exists for the nominee
    boolean reassessmentDetailsFound = false;

    // indicates that a ReassessmentAmountInfoDtls exists for the nominee
    boolean reassessmentAmountInfoFound = false;

    // indicates if liability payments are received or benefit deductions made
    boolean receivedAmount = false;

    // BEGIN, CR00148989, KH
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();
    // END, CR00148989
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    final FCGenerationUtil fcGenerationUtilObj = FCGenerationUtilFactory
        .newInstance();
    final FCTestDates fcTestDates = new FCTestDates();
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey = new GetFCDatesAndValuesKey();
    Date tempDate = Date.kZeroDate;
    IsPaymentDateResult isPaymentDateResult;

    // CaseNomineeProdDelPattern manipulation variables
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

    // ProductDeliveryPatternInfo manipulation variables
    final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory
        .newInstance();
    final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = null;

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // BEGIN, CR00148989, KH
    final CaseHeaderDtls caseHeaderDtls = cachedCaseHeaderObj
        .read(caseHeaderKey);
    // END, CR00148989

    // BEGIN, CR00222604, CW

    //
    // Set key to read CaseNomineeProdDelPattern
    // If the given fromDate is prior to the caseHeader startDate then
    // read CaseNomineeProdDelPattern from the case start date
    //

    Date caseNomineeProdDelPatternReadDate = key.fromDate;

    if (key.fromDate.before(caseHeaderDtls.startDate)) {
      // Read caseNomineeProdDelPatternReadDate from the case start date
      caseNomineeProdDelPatternReadDate = caseHeaderDtls.startDate;
    }

    readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
    readEffectiveByDateKey.effectiveDate = caseNomineeProdDelPatternReadDate;
    // END, CR00222604

    // BEGIN, CR00211744, VM
    final CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = assessmentEngineEntity
        .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
    // END, CR00211744

    pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
    pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
    pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = key.fromDate;

    // read productDeliveryPatternInfo record
    try {
      productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
          .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);
    } catch (final RecordNotFoundException e) {

      final AppException ae = new AppException(
          BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

      // get the case reference for display
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      caseSearchKey.caseID = key.caseID;

      ae.arg(CaseHeaderFactory.newInstance()
          .readCaseReferenceByCaseID(caseSearchKey).caseReference);
      ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
      throw ae;
    }
    // END, CR00148989

    // setting an arbitrary tempDate
    tempDate = caseHeaderDtls.effectiveDate;

    // BEGIN, CR00148989, KH
    if (mostRecentAnchorDate.isZero()) {
      fcTestDates.paymentDate = tempDate;
    } else {
      fcTestDates.paymentDate = mostRecentAnchorDate;
      tempDate = mostRecentAnchorDate;
    }
    // END, CR00148989

    // Firstly need to check if key.toDate is a payment date
    fcTestDates.testDate = key.toDate;

    getFCDatesAndValuesKey.deliveryFrequency = productDeliveryPatternInfoDtls.deliveryFrequency;

    isPaymentDateResult = fcGenerationUtilObj
        .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

    // BEGIN, CR00148989, KH
    final FrequencyPattern deliveryPattern = new FrequencyPattern(
        productDeliveryPatternInfoDtls.deliveryFrequency);

    // If key.fromDate is earlier than previousCoverPeriodTo, then it means
    // there is
    // the potential for the period containing the key.fromDate to be included
    // twice
    // in the calculation of the over/under payment amount. To avoid this, roll
    // the
    // key.fromDate forward by the deliveryPattern
    if (!previousCoverPeriodTo.isZero()
        && key.fromDate.before(previousCoverPeriodTo)) {
      key.fromDate = deliveryPattern.getNextOccurrence(key.fromDate);
    }

    if (!isPaymentDateResult.result && productDeliveryPatternInfoDtls != null) {

      // BEGIN, CR00376248, KH
      /*
       * When using some of the more 'exotic' frequency patterns it's safer to
       * roll the from date.
       */
      key.toDate = deliveryPattern.getNextOccurrence(key.fromDate);
      // END, CR00376248

      // BEGIN, CR00050838, MR
      fcTestDates.testDate = key.toDate;

      isPaymentDateResult = fcGenerationUtilObj
          .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

      if (!isPaymentDateResult.result) {
        if (tempDate.after(key.toDate)) {
          while (tempDate.after(key.toDate)) {
            tempDate = deliveryPattern.getPrevOccurrence(tempDate);
          }
          key.toDate = tempDate;
        }
      } else {
        mostRecentAnchorDate = key.toDate;
      }
      // END, CR00148989

      // Ensure that end date would not be later than start date of next
      // delivery pattern
      readEffectiveByDateKey.effectiveDate = readEffectiveByDateKey.effectiveDate
          .addDays(1);

      // BEGIN, CR00211744, VM
      final CaseNomineeProdDelPatternDtls nextCaseNomineeProdDelPatternDtls = assessmentEngineEntity
          .getNextCaseNomineePatternByCaseNomineeDateAndStatus(
              readEffectiveByDateKey);

      if (nextCaseNomineeProdDelPatternDtls != null) {
        if (!key.toDate.before(nextCaseNomineeProdDelPatternDtls.fromDate)) {
          key.toDate = nextCaseNomineeProdDelPatternDtls.fromDate;
        }
      }
      // END, CR00211744

      // if the key.ToDate is later than the finalComponentListDate value
      // then update the key.ToDate value
      if (key.toDate.after(finalComponentDateListDate)) {
        key.toDate = finalComponentDateListDate;
      }

      // BEGIN, CR00148989, KH
    } else {
      mostRecentAnchorDate = key.toDate;
    }
    // END, CR00148989

    // Check if the previousCoverPeriodTo is the same as the key.toDate
    // If it is, then this means the period has been processed already and we
    // set the actualsProcessed flag to false
    if (previousCoverPeriodTo.equals(key.toDate)) {
      actualsProcessed = false;
    } else {
      // Update the previousCoverPeriodTo date to key.toDate and set the flag
      // to true to process the actuals
      previousCoverPeriodTo = key.toDate;
      actualsProcessed = true;
    }

    if (actualsProcessed) {

      // Get "Actual" from Financial
      retrieveCaseFinancialsKey.caseID = key.caseID;
      retrieveCaseFinancialsKey.periodFromDate = key.fromDate;
      retrieveCaseFinancialsKey.periodToDate = key.toDate.addDays(-1);
      retrieveCaseFinancialsKey.caseNomineeID = key.caseNomineeID;

      // BEGIN, CR00211744, VM
      reassessCaseDetailsList = assessmentEngine
          .retrieveCaseFinancials(retrieveCaseFinancialsKey);
      // END, CR00211744

      // BEGIN, CR00119200, KH
      // Read back list of component deduction types. This list contains the ILI
      // types which should not be considered during reassessment.
      final StringList componentDeductionTypeList = CodeTable
          .getDistinctCodesForAllLanguages(COMPONENTDEDUCTIONTYPE.TABLENAME);

      // END, CR00119200

      // For each payment made (or bill issued)
      for (int i = 0; i < reassessCaseDetailsList.dtls.size(); i++) {

        if (!componentDeductionTypeList.contains(
            reassessCaseDetailsList.dtls.item(i).instructionLineItemType)) {

          int j;
          int k;
          int l;

          // if the beneficiary details have not been populated, set them up now
          if (getActualDetailsResult.beneficiaryDetails.caseNomineeID == 0) {

            // nominee manipulation variables
            final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory
                .newInstance();
            final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();
            curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails;

            getActualDetailsResult.beneficiaryDetails.caseNomineeID = reassessCaseDetailsList.dtls
                .item(i).caseNomineeID;

            // read nominee details
            caseNomineeViewKey.caseNomineeID = reassessCaseDetailsList.dtls
                .item(i).caseNomineeID;

            caseNomineeDetails = caseNomineeObj
                .readCaseNomineeDetails(caseNomineeViewKey);

            getActualDetailsResult.beneficiaryDetails.concernRoleID = caseNomineeDetails.concernRoleID;
          }

          // if haven't already set up NomineeReassessmentHeader
          nomineeHeaderFound = false;

          for (j = 0; j < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
              .size(); j++) {

            if (getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(
                    j).nomineeOverUnderPaymentDtls.caseNomineeID == reassessCaseDetailsList.dtls
                        .item(i).caseNomineeID) {

              if (key.fromDate.before(
                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).nomineeOverUnderPaymentDtls.coverPeriodFrom)) {

                getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.coverPeriodFrom = key.fromDate;
              }

              if (key.toDate.after(
                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).nomineeOverUnderPaymentDtls.coverPeriodTo)) {

                getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.coverPeriodTo = key.toDate
                            .addDays(-1);
              }

              nomineeHeaderFound = true;
              break;
            }
          }

          // otherwise set up NomineeReassessmentHeader
          if (!nomineeHeaderFound) {

            final NomineeReassessmentHeader nomineeReassessmentHeader = new NomineeReassessmentHeader();

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID = reassessCaseDetailsList.dtls
                .item(i).caseNomineeID;

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom = key.fromDate;

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo = key.toDate
                .addDays(-1);

            getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .addRef(nomineeReassessmentHeader);

            // Set iterator to point to new record
            j = getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .size() - 1;
          }

          // Check to see if there is a matching NomineeReassessmentDetails
          reassessmentDetailsFound = false;

          for (k = 0; k < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.size(); k++) {

            if (getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList
                    .item(k).reassessmentInfoDtls.fromDate.equals(key.fromDate)
                && getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList
                        .item(k).reassessmentInfoDtls.toDate
                            .equals(key.toDate.addDays(-1))) {

              reassessmentDetailsFound = true;
              break;
            }
          }

          // If not add one in
          if (!reassessmentDetailsFound) {
            final NomineeReassessmentDetails nomineeReassessmentDetails = new NomineeReassessmentDetails();

            nomineeReassessmentDetails.reassessmentInfoDtls.fromDate = key.fromDate;

            nomineeReassessmentDetails.reassessmentInfoDtls.toDate = key.toDate
                .addDays(-1);

            getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList
                    .addRef(nomineeReassessmentDetails);

            // Set iterator to point to new record
            k = getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList.size() - 1;
          }

          // Reset type code.
          reassessmentAmountInfoDtls = new ReassessmentAmountInfoDtls();
          // BEGIN, CR00049218, GM
          reassessmentAmountInfoDtls.amountType = CuramConst.gkEmpty;
          // END, CR00049218

          reassessmentAmountInfoDtls = determineReassessmentAmountTypeObj
              .determineReassessmentAmountType(
                  reassessCaseDetailsList.dtls.item(i), reassessmentMode);

          // initialize Indicator
          reassessmentAmountInfoFound = false;

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.assign(reassessmentAmountInfoDtls);

          // if an amount type has been set
          if (reassessmentAmountInfoDetails.amountType.length() > 0) {

            for (l = 0; l < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList.item(k).amountDetailsList
                    .size(); l++) {

              if (getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).amountType
                          .equals(reassessmentAmountInfoDetails.amountType)) {

                reassessmentAmountInfoFound = true;
                break;
              }

            }

            // if not found, add new record
            if (!reassessmentAmountInfoFound) {

              // add to the list

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .addRef(reassessmentAmountInfoDetails);

              // Set iterator to point to new record
              l = getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .size()
                  - 1;
            }

            // initialize Indicator.
            receivedAmount = false;

            // Set the received amount indicator
            // System liability payments received
            if (reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                .equals(ILITYPE.ALLOCATEDPMTRECVD)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.OVERALLOCATION)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.LIABILITYOVERPAYMENT)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.OVERPAYMENTREPAYMENT)) {

              receivedAmount = true;
            }

            // System liability received / benefit deductions
            if ((reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                .equals(ILITYPE.WRITEOFF)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.UNALLOCATEDREVERSAL)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.ALLOCATEDREVERSAL)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.EMPLOYERCONTRIBUTIONLIABILITY)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.EMPLOYEECONTRIBUTIONLIABILITY))
                && reassessmentMode.reassessmentMode
                    .equals(REASSESSMENTPROCMODE.RECONCILIATION)) {

              receivedAmount = true;
            }

            // Add new details to reassessmentAmountInfoDetails
            if (receivedAmount) {

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).receivedAmount = new Money(
                          getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                              .item(j).reassessmentDetailsList
                                  .item(k).amountDetailsList
                                      .item(l).receivedAmount.getValue()
                              + reassessCaseDetailsList.dtls.item(i).amount
                                  .getValue());

            } else {

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).actualAmount = new Money(
                          getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                              .item(j).reassessmentDetailsList
                                  .item(k).amountDetailsList
                                      .item(l).actualAmount.getValue()
                              + reassessCaseDetailsList.dtls.item(i).amount
                                  .getValue());
            }

            // BEGIN, CR00209995, KH
            boolean objectiveMatchFound = false;

            /*
             * Look through the breakdown list for a matching objective and
             * related reference.
             */
            for (int p = 0; p < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList.item(k).amountDetailsList
                    .item(l).breakdownPerObjectiveList.details.size(); p++) {

              /*
               * We have a breakdown for this list objective already, so we only
               * need to adjust it.
               */
              if (reassessCaseDetailsList.dtls.item(i).rulesObjectiveID.equals(
                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).reassessmentDetailsList.item(k).amountDetailsList
                          .item(l).breakdownPerObjectiveList.details
                              .item(p).rulesObjectiveID)
                  && reassessCaseDetailsList.dtls.item(i).relatedReference
                      .equals(
                          getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                              .item(j).reassessmentDetailsList
                                  .item(k).amountDetailsList
                                      .item(l).breakdownPerObjectiveList.details
                                          .item(p).relatedReference)) {

                getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList.item(k).amountDetailsList
                        .item(l).breakdownPerObjectiveList.details
                            .item(p).actualAmount = new Money(
                                getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                                    .item(j).reassessmentDetailsList
                                        .item(k).amountDetailsList.item(
                                            l).breakdownPerObjectiveList.details
                                                .item(p).actualAmount.getValue()
                                    + reassessCaseDetailsList.dtls
                                        .item(i).amount.getValue());

                objectiveMatchFound = true; // from p
                break;
              }
            } // end for p

            /*
             * We don't have a breakdown for this objective and related
             * reference yet, so add one.
             */
            if (!objectiveMatchFound) {

              final ObjectiveAmountDetails objectiveAmountDetails = new ObjectiveAmountDetails();

              objectiveAmountDetails.rulesObjectiveID = reassessCaseDetailsList.dtls
                  .item(i).rulesObjectiveID;
              objectiveAmountDetails.actualAmount = new Money(
                  reassessCaseDetailsList.dtls.item(i).amount);
              objectiveAmountDetails.relatedReference = reassessCaseDetailsList.dtls
                  .item(i).relatedReference;

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).breakdownPerObjectiveList.details
                          .addRef(objectiveAmountDetails);
            }
            // END, CR00209995
          }
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * @param completeCaseReassessment
   *          Results of reassessment for processing.
   * @param componentDetailsList
   *          The list of components to be reassessed
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   *
   * @return Result of the reassessment processing.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   *             {@link curam.core.impl.CaseReassessment#processReassessmentDetails1()}.
   *             <p>
   *             With the introduction of granular reassessments is is no longer
   *             sufficient to calculate the over and under payment details
   *             based on the rules objective ID alone. Both the rules objective
   *             ID and the related reference must be used so that the over and
   *             under payment values for list objectives can be correctly
   *             recorded.
   *
   *             This method calculates the over under payment and determines
   *             the result type for the reassessment.
   */
  @Override
  @Deprecated
  public CompleteCaseReassessment processReassessmentDetails(
      final CompleteCaseReassessment completeCaseReassessment,
      final ComponentDetailsList componentDetailsList,
      final ReassessmentMode reassessmentMode)
      throws AppException, InformationalException {

    // the total deductions 'actually' paid
    Money totalActualDeductionAmount = Money.kZeroMoney;

    // the 'reassessed' total for deductions
    Money totalReassessedDeductionAmount = Money.kZeroMoney;

    // the total amount received (for liability)
    Money totalReceivedAmount = Money.kZeroMoney;

    // the total amount 'actually' paid
    Money totalActualAmount = Money.kZeroMoney;

    // the total reassessed amount
    Money totalReassessedAmount = Money.kZeroMoney;

    // the total 'actual' amount less any deductions
    Money netActualAmount = Money.kZeroMoney;

    // the total reassessed amount less any deductions
    Money netReassessedAmount = Money.kZeroMoney;

    // the total received amount less any deductions (for liability)
    Money netReceivedAmount = Money.kZeroMoney;

    // the total figure for overpayment
    Money totalOverpayment = Money.kZeroMoney;

    // the total figure for underpayment
    Money totalUnderpayment = Money.kZeroMoney;

    // the final reassessed figure
    Money finalTotalReassessed = Money.kZeroMoney;

    // the final actual figure
    Money finalTotalActual = Money.kZeroMoney;

    ObjectiveTotalDetailsList objectiveTotalDetailsList = new ObjectiveTotalDetailsList();

    boolean objectiveMatchFound = false;

    // caseHeader manipulation variables
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // set key to read caseHeader
    caseHeaderKey.caseID = completeCaseReassessment.overUnderPaymentHeaderDtls.caseID;

    // read caseHeader
    final CaseHeaderDtls caseHeaderDtls = cachedCaseHeaderObj
        .read(caseHeaderKey);

    // if there are entries in the result list
    if (completeCaseReassessment.nomineeReassessmentHeaderList.size() > 0) {

      // Process reassessmentDetails to include AmountDetails for net values.
      // And set NomineeUnderOverpayment total and type code
      for (int i = 0; i < completeCaseReassessment.nomineeReassessmentHeaderList
          .size(); i++) {

        completeCaseReassessment.nomineeReassessmentHeaderList.item(
            i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

        // reset net values
        netActualAmount = Money.kZeroMoney;
        netReassessedAmount = Money.kZeroMoney;
        netReceivedAmount = Money.kZeroMoney;
        finalTotalReassessed = Money.kZeroMoney;
        finalTotalActual = Money.kZeroMoney;

        for (int j = 0; j < completeCaseReassessment.nomineeReassessmentHeaderList
            .item(i).reassessmentDetailsList.size(); j++) {

          // reset totals
          totalActualDeductionAmount = Money.kZeroMoney;
          totalReassessedDeductionAmount = Money.kZeroMoney;
          totalReceivedAmount = Money.kZeroMoney;
          totalActualAmount = Money.kZeroMoney;
          totalReassessedAmount = Money.kZeroMoney;

          for (int k = 0; k < completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentDetailsList.item(j).amountDetailsList
                  .size(); k++) {

            // add up gross values
            if (completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).reassessmentDetailsList.item(j).amountDetailsList
                    .item(k).amountType.equals(REASSESSMENT_AMOUNT.GROSS)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType.equals(REASSESSMENT_AMOUNT.BILL)) {

              totalReceivedAmount = new Money(totalReceivedAmount.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).receivedAmount.getValue());

              totalActualAmount = new Money(totalActualAmount.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).actualAmount.getValue());

              totalReassessedAmount = new Money(totalReassessedAmount.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).reassessedAmount.getValue());
            }

            // For each instruction line item of the reassessment payment get
            // the total actual and reassessed amounts for each objective
            // involved in each instruction line item.
            objectiveTotalDetailsList = completeCaseReassessment.objectiveTotalDetailsList;

            for (int m = 0; m < completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).reassessmentDetailsList.item(j).amountDetailsList
                    .item(k).breakdownPerObjectiveList.details.size(); m++) {

              objectiveMatchFound = false;

              for (int n = 0; n < objectiveTotalDetailsList.dtls.size(); n++) {

                // If there is an objective match add the actual amount and
                // reassessed amount onto the current totals for that objective
                if (objectiveTotalDetailsList.dtls.item(n).rulesObjectiveID
                    .equals(
                        completeCaseReassessment.nomineeReassessmentHeaderList
                            .item(i).reassessmentDetailsList
                                .item(j).amountDetailsList
                                    .item(k).breakdownPerObjectiveList.details
                                        .item(m).rulesObjectiveID)) {

                  objectiveMatchFound = true;

                  // Adjust the totals that exist for this
                  objectiveTotalDetailsList.dtls
                      .item(n).actualAmount = new Money(
                          objectiveTotalDetailsList.dtls.item(n).actualAmount
                              .getValue()
                              + completeCaseReassessment.nomineeReassessmentHeaderList
                                  .item(i).reassessmentDetailsList
                                      .item(j).amountDetailsList.item(
                                          k).breakdownPerObjectiveList.details
                                              .item(m).actualAmount.getValue());

                  objectiveTotalDetailsList.dtls
                      .item(n).reassessedAmount = new Money(
                          objectiveTotalDetailsList.dtls
                              .item(n).reassessedAmount.getValue()
                              + completeCaseReassessment.nomineeReassessmentHeaderList
                                  .item(i).reassessmentDetailsList
                                      .item(j).amountDetailsList.item(
                                          k).breakdownPerObjectiveList.details
                                              .item(m).reassessedAmount
                                                  .getValue());
                }
              } // end for n

              // If the objective does not match any currently contained in
              // the objectiveTotalDetailsList add a new record for it.
              if (!objectiveMatchFound) {

                final ObjectiveTotalDetails objectiveTotalDetails = new ObjectiveTotalDetails();

                objectiveTotalDetails.rulesObjectiveID = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).rulesObjectiveID;

                objectiveTotalDetails.actualAmount = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).actualAmount;

                objectiveTotalDetails.reassessedAmount = completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).breakdownPerObjectiveList.details
                            .item(m).reassessedAmount;

                objectiveTotalDetailsList.dtls.addRef(objectiveTotalDetails);
              }
            } // end for m

            // add up deductions
            if (completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).reassessmentDetailsList.item(j).amountDetailsList
                    .item(k).amountType.equals(REASSESSMENT_AMOUNT.TAX)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType.equals(REASSESSMENT_AMOUNT.UTILITY)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType
                            .equals(REASSESSMENT_AMOUNT.LIABILITY)
                || completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList.item(j).amountDetailsList
                        .item(k).amountType
                            .equals(REASSESSMENT_AMOUNT.DEDUCTION)) {

              totalActualDeductionAmount = new Money(totalActualDeductionAmount
                  .getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).reassessmentDetailsList.item(j).amountDetailsList
                          .item(k).actualAmount.getValue());

              totalReassessedDeductionAmount = new Money(
                  totalReassessedDeductionAmount.getValue()
                      + completeCaseReassessment.nomineeReassessmentHeaderList
                          .item(i).reassessmentDetailsList
                              .item(j).amountDetailsList
                                  .item(k).reassessedAmount.getValue());
            }
          } // end for k

          // calculate net values
          netActualAmount = new Money(
              netActualAmount.getValue() + totalActualAmount.getValue());

          finalTotalActual = new Money(
              finalTotalActual.getValue() + totalActualAmount.getValue()
                  - totalActualDeductionAmount.getValue());

          netActualAmount = new Money(netActualAmount.getValue()
              - totalActualDeductionAmount.getValue());

          netReassessedAmount = new Money(netReassessedAmount.getValue()
              + totalReassessedAmount.getValue());

          finalTotalReassessed = new Money(
              finalTotalReassessed.getValue() + totalReassessedAmount.getValue()
                  - totalReassessedDeductionAmount.getValue());

          netReassessedAmount = new Money(netReassessedAmount.getValue()
              - totalReassessedDeductionAmount.getValue());

          netReceivedAmount = new Money(
              netReceivedAmount.getValue() + totalReceivedAmount.getValue());

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.actualAmount = new Money(
              totalActualAmount.getValue()
                  - totalActualDeductionAmount.getValue());

          reassessmentAmountInfoDetails.reassessedAmount = new Money(
              totalReassessedAmount.getValue()
                  - totalReassessedDeductionAmount.getValue());

          reassessmentAmountInfoDetails.receivedAmount = totalReceivedAmount;

          // if this is a liability
          if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

            // Set reassessed Amount Type
            reassessmentAmountInfoDetails.amountType = REASSESSMENT_AMOUNT.TOTALBILL;
          } else {

            // Set reassessed Amount Type
            reassessmentAmountInfoDetails.amountType = REASSESSMENT_AMOUNT.NET;
          }

          // Add net amount details record
          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentDetailsList.item(j).amountDetailsList
                  .addRef(reassessmentAmountInfoDetails);
        } // end for j

        // set the nomineeOverUnderPayment dtls
        // if this is a liability and were in reassessmentMode
        if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)
            && reassessmentMode.reassessmentMode
                .equals(REASSESSMENTPROCMODE.RECONCILIATION)) {

          if (netReassessedAmount.getValue() > netReceivedAmount.getValue()) {

            completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                    netReassessedAmount.getValue()
                        - netReceivedAmount.getValue());

            completeCaseReassessment.nomineeReassessmentHeaderList.item(
                i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;

            totalUnderpayment = new Money(totalUnderpayment.getValue()
                + completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).nomineeOverUnderPaymentDtls.totalAmount
                        .getValue());

          } else {

            if (netReceivedAmount.getValue() > netReassessedAmount.getValue()) {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                      netReceivedAmount.getValue()
                          - netReassessedAmount.getValue());

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;

              totalOverpayment = new Money(totalOverpayment.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).nomineeOverUnderPaymentDtls.totalAmount
                          .getValue());

            } else {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                      netReceivedAmount.getValue()
                          - netReassessedAmount.getValue());

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;
            }
          }
        } else {

          // If the total Reassessed Amount is greater that the actual amount
          // paid, there is an underpayment
          if (finalTotalReassessed.getValue() > finalTotalActual.getValue()) {

            completeCaseReassessment.nomineeReassessmentHeaderList
                .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                    finalTotalReassessed.getValue()
                        - finalTotalActual.getValue());

            completeCaseReassessment.nomineeReassessmentHeaderList.item(
                i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.UNDERPAYMENT;

            totalUnderpayment = new Money(totalUnderpayment.getValue()
                + completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(i).nomineeOverUnderPaymentDtls.totalAmount
                        .getValue());

          } else {

            // If the total Reassessed Amount is less that the actual amount
            // paid, there is an overpayment
            if (finalTotalReassessed.getValue() < finalTotalActual.getValue()) {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(i).nomineeOverUnderPaymentDtls.totalAmount = new Money(
                      finalTotalActual.getValue()
                          - finalTotalReassessed.getValue());

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.OVERPAYMENT;

              totalOverpayment = new Money(totalOverpayment.getValue()
                  + completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(i).nomineeOverUnderPaymentDtls.totalAmount
                          .getValue());

            } else {

              // otherwise there has been no change in the amount to be paid,
              // but differences still exists in the calculations - i.e.
              // the deduction amounts have varied, but we don't issue under or
              // over payments in respect of this.
              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.totalAmount = new Money(0);

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).nomineeOverUnderPaymentDtls.amountTypeCode = REASSESSMENTRESULT.NOCHANGE;

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.NOCHANGE;

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).reassessmentSummaryDetails.totalAmount = Money.kZeroMoney;

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  i).reassessmentSummaryDetails.totalActualAmount = netReassessedAmount;
            }
          }
        }

        // Here is where we must total the over/under payment for the nominee -
        if (totalOverpayment.getValue() > totalUnderpayment.getValue()) {

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.OVERPAYMENT;

          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentSummaryDetails.totalAmount = new Money(
                  totalOverpayment.getValue() - totalUnderpayment.getValue());

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.totalActualAmount = netReassessedAmount;
        }

        if (totalUnderpayment.getValue() > totalOverpayment.getValue()) {

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.reassessmentResultType = REASSESSMENTRESULT.UNDERPAYMENT;

          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(i).reassessmentSummaryDetails.totalAmount = new Money(
                  totalUnderpayment.getValue() - totalOverpayment.getValue());

          completeCaseReassessment.nomineeReassessmentHeaderList.item(
              i).reassessmentSummaryDetails.totalActualAmount = netReassessedAmount;
        }

        // now need to set the totalUnderPayment and totalOverPayment to zero,
        // as each nominee is getting reassessed separately
        totalOverpayment = curam.util.type.Money.kZeroMoney;
        totalUnderpayment = curam.util.type.Money.kZeroMoney;

        completeCaseReassessment.objectiveTotalDetailsList = objectiveTotalDetailsList;
      }
    }

    return completeCaseReassessment;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Details of the reassessment, case, period etc.
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   * @param getActualDetailsResult
   *          A struct to hold the details of what was 'actually' paid already.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   *             {@link curam.core.impl.CaseReassessment#getActualDetails1()}.
   *             <p>
   *             With the introduction of granular reassessments is is no longer
   *             sufficient to calculate the actual payment details based on the
   *             rules objective ID alone. Both the rules objective ID and the
   *             related reference must be used so that the actual values for
   *             list objectives can be correctly recorded.
   *
   *             This method retrieves the details of the actual payments made
   *             by nominee.
   */
  @Override
  @Deprecated
  public void getActualDetails(final OverUnderPaymentIn key,
      final ReassessmentMode reassessmentMode,
      final GetActualDetailsResult getActualDetailsResult)
      throws AppException, InformationalException {

    // DetermineReassessmentAmountType object
    final DetermineReassessmentAmountType determineReassessmentAmountTypeObj = DetermineReassessmentAmountTypeFactory
        .newInstance();

    // retrieveCaseFinancialDetails variable
    final RetrieveCaseFinancialDetails retrieveCaseFinancialDetails = RetrieveCaseFinancialDetailsFactory
        .newInstance();

    // reassessCaseSearchDetails variable
    final ReassessCaseSearchDetails reassessCaseSearchDetails = new ReassessCaseSearchDetails();

    // reassessCaseDetailsList variable
    ReassessCaseDetailsList reassessCaseDetailsList;

    // indicates that a NomineeHeader structure exists for the nominee
    boolean nomineeHeaderFound = false;

    // indicates that a ReassessmentInfoDtls structure exists for the nominee
    boolean reassessmentDetailsFound = false;

    // indicates that a ReassessmentAmountInfoDtls structure exists for the
    // nominee
    boolean reassessmentAmountInfoFound = false;

    // indicates whether liability payments are received or benefit deductions
    // made
    boolean receivedAmount = false;
    // BEGIN, CR00049218, GM
    String localRulesObjectiveID = CuramConst.gkEmpty;
    // END, CR00049218

    ReassessmentAmountInfoDtls reassessmentAmountInfoDtls;

    // Firstly need to check if key.toDate is a payment date
    // BEGIN, CR00148989, KH
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();
    // END, CR00148989
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    final FCGenerationUtil fcGenerationUtilObj = FCGenerationUtilFactory
        .newInstance();
    final FCTestDates fcTestDates = new FCTestDates();
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey = new GetFCDatesAndValuesKey();
    Date tempDate = Date.kZeroDate;
    IsPaymentDateResult isPaymentDateResult;

    // CaseNomineeProdDelPattern manipulation variables
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

    // ProductDeliveryPatternInfo manipulation variables
    final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory
        .newInstance();
    final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = null;

    // Set key to read CaseNomineeProdDelPattern
    readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
    readEffectiveByDateKey.effectiveDate = key.fromDate;

    // BEGIN, CR00211744, VM
    final CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = assessmentEngineEntity
        .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);

    // END, CR00211744

    pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
    pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
    pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = key.fromDate;

    // read productDeliveryPatternInfo record
    try {
      productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
          .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);
    } catch (final RecordNotFoundException e) {

      final AppException ae = new AppException(
          BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

      // get the case reference for display
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      caseSearchKey.caseID = key.caseID;

      ae.arg(CaseHeaderFactory.newInstance()
          .readCaseReferenceByCaseID(caseSearchKey).caseReference);
      ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
      throw ae;
    }

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // BEGIN, CR00148989, KH
    // Read cachedCaseHeader
    final CaseHeaderDtls caseHeaderDtls = cachedCaseHeaderObj
        .read(caseHeaderKey);

    // END, CR00148989

    // setting an arbitrary tempDate
    tempDate = caseHeaderDtls.effectiveDate;

    // BEGIN, CR00148989, KH
    if (mostRecentAnchorDate.isZero()) {
      fcTestDates.paymentDate = tempDate;
    } else {
      fcTestDates.paymentDate = mostRecentAnchorDate;
      tempDate = mostRecentAnchorDate;
    }
    // END, CR00148989

    fcTestDates.testDate = key.toDate;

    getFCDatesAndValuesKey.deliveryFrequency = productDeliveryPatternInfoDtls.deliveryFrequency;

    isPaymentDateResult = fcGenerationUtilObj
        .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

    // BEGIN, CR00148989, KH
    final FrequencyPattern deliveryPattern = new FrequencyPattern(
        productDeliveryPatternInfoDtls.deliveryFrequency);

    if (!isPaymentDateResult.result && productDeliveryPatternInfoDtls != null) {

      key.toDate = deliveryPattern.getNextOccurrence(key.toDate);

      // BEGIN, CR00050838, MR
      fcTestDates.testDate = key.toDate;

      isPaymentDateResult = fcGenerationUtilObj
          .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

      if (!isPaymentDateResult.result) {
        if (tempDate.after(key.toDate)) {
          while (tempDate.after(key.toDate)) {
            tempDate = deliveryPattern.getPrevOccurrence(tempDate);
          }
          key.toDate = tempDate;
        }
      } else {
        mostRecentAnchorDate = key.toDate;
      }
      // END, CR00148989

      // Ensure that end date would not be later than start date of next
      // delivery pattern
      readEffectiveByDateKey.effectiveDate = readEffectiveByDateKey.effectiveDate
          .addDays(1);

      // BEGIN, CR00211744, VM
      final CaseNomineeProdDelPatternDtls nextCaseNomineeProdDelPatternDtls = assessmentEngineEntity
          .getNextCaseNomineePatternByCaseNomineeDateAndStatus(
              readEffectiveByDateKey);

      if (nextCaseNomineeProdDelPatternDtls != null) {
        if (!key.toDate.before(nextCaseNomineeProdDelPatternDtls.fromDate)) {
          key.toDate = nextCaseNomineeProdDelPatternDtls.fromDate;
        }
      }
      // END, CR00211744

      // if the key.ToDate is later than the finalComponentListDate value
      // then update the key.ToDate value
      if (key.toDate.after(finalComponentDateListDate)) {
        key.toDate = finalComponentDateListDate;
      }

      // BEGIN, CR00148989, KH
    } else {
      mostRecentAnchorDate = key.toDate;
    }
    // END, CR00148989

    // Check if the previousCoverPeriodTo is the same as the key.toDate
    // If it is, then this means the period has been processed already and we
    // set the actualsProcessed flag to false
    if (previousCoverPeriodTo.equals(key.toDate)) {
      actualsProcessed = false;
    } else {
      // Update the previousCoverPeriodTo date to key.toDate and set the flag
      // to true to process the actuals
      previousCoverPeriodTo = key.toDate;
      actualsProcessed = true;
    }

    if (actualsProcessed) {

      // Get "Actual" from Financial
      reassessCaseSearchDetails.caseID = key.caseID;
      reassessCaseSearchDetails.periodFromDate = key.fromDate;
      reassessCaseSearchDetails.periodToDate = key.toDate.addDays(-1);

      reassessCaseSearchDetails.caseNomineeID = key.caseNomineeID;

      reassessCaseDetailsList = retrieveCaseFinancialDetails
          .retrieveCaseFinancialDtls(reassessCaseSearchDetails);

      // BEGIN, CR00119200, KH
      // Read back list of component deduction types. This list contains the ILI
      // types which should not be considered during reassessment.
      final StringList componentDeductionTypeList = CodeTable
          .getDistinctCodesForAllLanguages(COMPONENTDEDUCTIONTYPE.TABLENAME);

      // END, CR00119200

      // For each payment made (or bill issued)
      for (int i = 0; i < reassessCaseDetailsList.dtls.size(); i++) {

        if (!componentDeductionTypeList.contains(
            reassessCaseDetailsList.dtls.item(i).instructionLineItemType)) {

          int j;
          int k;
          int l;

          // if the beneficiary details have not been populated, set them up now
          if (getActualDetailsResult.beneficiaryDetails.caseNomineeID == 0) {

            // nominee manipulation variables
            final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory
                .newInstance();
            final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();
            curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails;

            getActualDetailsResult.beneficiaryDetails.caseNomineeID = reassessCaseDetailsList.dtls
                .item(i).caseNomineeID;

            // read nominee details
            caseNomineeViewKey.caseNomineeID = reassessCaseDetailsList.dtls
                .item(i).caseNomineeID;

            caseNomineeDetails = caseNomineeObj
                .readCaseNomineeDetails(caseNomineeViewKey);

            getActualDetailsResult.beneficiaryDetails.concernRoleID = caseNomineeDetails.concernRoleID;
          }

          // if haven't already set up NomineeReassessmentHeader
          nomineeHeaderFound = false;

          for (j = 0; j < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
              .size(); j++) {

            if (getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(
                    j).nomineeOverUnderPaymentDtls.caseNomineeID == reassessCaseDetailsList.dtls
                        .item(i).caseNomineeID) {

              if (key.fromDate.before(
                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).nomineeOverUnderPaymentDtls.coverPeriodFrom)) {

                getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.coverPeriodFrom = key.fromDate;
              }

              if (key.toDate.after(
                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).nomineeOverUnderPaymentDtls.coverPeriodTo)) {

                getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(
                        j).nomineeOverUnderPaymentDtls.coverPeriodTo = key.toDate
                            .addDays(-1);
              }

              nomineeHeaderFound = true;
              break;
            }
          }

          // otherwise set up NomineeReassessmentHeader
          if (!nomineeHeaderFound) {

            final NomineeReassessmentHeader nomineeReassessmentHeader = new NomineeReassessmentHeader();

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID = reassessCaseDetailsList.dtls
                .item(i).caseNomineeID;

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom = key.fromDate;

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo = key.toDate
                .addDays(-1);

            getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .addRef(nomineeReassessmentHeader);

            // Set iterator to point to new record
            j = getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .size() - 1;
          }

          // Check to see if there is a matching NomineeReassessmentDetails
          reassessmentDetailsFound = false;

          for (k = 0; k < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.size(); k++) {

            if (getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList
                    .item(k).reassessmentInfoDtls.fromDate.equals(key.fromDate)
                && getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList
                        .item(k).reassessmentInfoDtls.toDate
                            .equals(key.toDate.addDays(-1))) {

              reassessmentDetailsFound = true;
              break;
            }
          }

          // If not add one in
          if (!reassessmentDetailsFound) {
            final NomineeReassessmentDetails nomineeReassessmentDetails = new NomineeReassessmentDetails();

            nomineeReassessmentDetails.reassessmentInfoDtls.fromDate = key.fromDate;

            nomineeReassessmentDetails.reassessmentInfoDtls.toDate = key.toDate
                .addDays(-1);

            getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList
                    .addRef(nomineeReassessmentDetails);

            // Set iterator to point to new record
            k = getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList.size() - 1;
          }

          // Reset type code.
          reassessmentAmountInfoDtls = new ReassessmentAmountInfoDtls();
          // BEGIN, CR00049218, GM
          reassessmentAmountInfoDtls.amountType = CuramConst.gkEmpty;
          // END, CR00049218

          reassessmentAmountInfoDtls = determineReassessmentAmountTypeObj
              .determineReassessmentAmountType(
                  reassessCaseDetailsList.dtls.item(i), reassessmentMode);

          // initialize Indicator
          reassessmentAmountInfoFound = false;

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.assign(reassessmentAmountInfoDtls);

          // if an amount type has been set
          if (reassessmentAmountInfoDetails.amountType.length() > 0) {

            for (l = 0; l < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList.item(k).amountDetailsList
                    .size(); l++) {

              if (getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).amountType
                          .equals(reassessmentAmountInfoDetails.amountType)) {

                reassessmentAmountInfoFound = true;
                break;
              }

            }

            // if not found, add new record
            if (!reassessmentAmountInfoFound) {

              // add to the list

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .addRef(reassessmentAmountInfoDetails);

              // Set iterator to point to new record
              l = getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .size()
                  - 1;
            }

            // initialize Indicator.
            receivedAmount = false;

            // Set the received amount indicator
            // System liability payments received
            if (reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                .equals(ILITYPE.ALLOCATEDPMTRECVD)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.OVERALLOCATION)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.LIABILITYOVERPAYMENT)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.OVERPAYMENTREPAYMENT)) {

              receivedAmount = true;
            }

            // System liability received / benefit deductions
            if ((reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                .equals(ILITYPE.WRITEOFF)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.UNALLOCATEDREVERSAL)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.ALLOCATEDREVERSAL)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.EMPLOYERCONTRIBUTIONLIABILITY)
                || reassessCaseDetailsList.dtls.item(i).instructionLineItemType
                    .equals(ILITYPE.EMPLOYEECONTRIBUTIONLIABILITY))
                && reassessmentMode.reassessmentMode
                    .equals(REASSESSMENTPROCMODE.RECONCILIATION)) {

              receivedAmount = true;
            }

            // Add new details to reassessmentAmountInfoDetails
            if (receivedAmount) {

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).receivedAmount = new Money(
                          getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                              .item(j).reassessmentDetailsList
                                  .item(k).amountDetailsList
                                      .item(l).receivedAmount.getValue()
                              + reassessCaseDetailsList.dtls.item(i).amount
                                  .getValue());

            } else {

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).actualAmount = new Money(
                          getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                              .item(j).reassessmentDetailsList
                                  .item(k).amountDetailsList
                                      .item(l).actualAmount.getValue()
                              + reassessCaseDetailsList.dtls.item(i).amount
                                  .getValue());
            }

            // Check if the ruleObjectiveID differs as we want to find the
            // breakdown per objective
            if (reassessCaseDetailsList.dtls.item(i).rulesObjectiveID
                .length() > 0
                && !localRulesObjectiveID.equals(
                    reassessCaseDetailsList.dtls.item(i).rulesObjectiveID)
                || localRulesObjectiveID.length() == 0) {

              localRulesObjectiveID = reassessCaseDetailsList.dtls
                  .item(i).rulesObjectiveID;

              final ObjectiveAmountDetails objectiveAmountDetails = new ObjectiveAmountDetails();

              objectiveAmountDetails.rulesObjectiveID = reassessCaseDetailsList.dtls
                  .item(i).rulesObjectiveID;
              objectiveAmountDetails.actualAmount = new curam.util.type.Money(
                  reassessCaseDetailsList.dtls.item(i).amount.getValue());

              getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).breakdownPerObjectiveList.details
                          .addRef(objectiveAmountDetails);

            } else {

              for (int p = 0; p < getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).breakdownPerObjectiveList.details.size(); p++) {

                if (localRulesObjectiveID.equals(
                    getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                        .item(j).reassessmentDetailsList
                            .item(k).amountDetailsList
                                .item(l).breakdownPerObjectiveList.details
                                    .item(p).rulesObjectiveID)) {

                  // Adjust the objective amount
                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).reassessmentDetailsList.item(k).amountDetailsList
                          .item(l).breakdownPerObjectiveList.details
                              .item(p).actualAmount = new Money(
                                  getActualDetailsResult.completeCaseReassessment.nomineeReassessmentHeaderList
                                      .item(j).reassessmentDetailsList
                                          .item(k).amountDetailsList.item(
                                              l).breakdownPerObjectiveList.details
                                                  .item(p).actualAmount
                                                      .getValue()
                                      + reassessCaseDetailsList.dtls
                                          .item(i).amount.getValue());
                }
              }
            }
          }
        }
      }
    }
  }

  // END, CR00195852

  // ___________________________________________________________________________
  /**
   * This method gets the details of the reassessed values of payments that
   * should have been made by nominee.
   *
   * @param key
   *          Details of the reassessment, case, period etc.
   * @param productDeliveryFinCompDtlsList
   *          A list of Financial Components
   * @param completeCaseReassessment
   *          Results of reassessment for processing.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void getReassessedDetails(final OverUnderPaymentIn key,
      final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList,
      final CompleteCaseReassessment completeCaseReassessment)
      throws AppException, InformationalException {

    // indicates that a NomineeHeader structure exists for the nominee.
    boolean nomineeHeaderFound = false;

    // indicates that a ReassessmentInfoDtls structure exists for the nominee.
    boolean reassessmentDetailsFound = false;

    // indicates that a ReassessmentAmountInfoDtls structure exists for the
    // nominee.
    boolean reassessmentAmountInfoFound = false;

    // local for amountType
    // BEGIN, CR00049218, GM
    String amountType = CuramConst.gkEmpty;

    // END, CR00049218

    // for each financial component
    for (int i = 0; i < productDeliveryFinCompDtlsList.dtls.size(); i++) {

      int j;
      int k;
      int l;

      // Either the payment is entirely inside the period or if the payment is
      // for a single day, it's payable when the fromDate is that day.
      if (productDeliveryFinCompDtlsList.dtls.item(i).startDate
          .before(key.toDate)
          && !productDeliveryFinCompDtlsList.dtls.item(i).endDate
              .before(key.fromDate)
          || productDeliveryFinCompDtlsList.dtls.item(i).startDate
              .equals(productDeliveryFinCompDtlsList.dtls.item(i).endDate)
              && productDeliveryFinCompDtlsList.dtls.item(i).endDate
                  .equals(key.fromDate)) {

        // find the right record...

        // if haven't already set up NomineeReassessmentHeader
        nomineeHeaderFound = false;

        for (j = 0; j < completeCaseReassessment.nomineeReassessmentHeaderList
            .size(); j++) {

          if (completeCaseReassessment.nomineeReassessmentHeaderList.item(
              j).nomineeOverUnderPaymentDtls.caseNomineeID == productDeliveryFinCompDtlsList.dtls
                  .item(i).caseNomineeID) {

            if (key.fromDate
                .before(completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).nomineeOverUnderPaymentDtls.coverPeriodFrom)) {

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  j).nomineeOverUnderPaymentDtls.coverPeriodFrom = key.fromDate;
            }

            if (key.toDate
                .after(completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).nomineeOverUnderPaymentDtls.coverPeriodTo)) {

              completeCaseReassessment.nomineeReassessmentHeaderList.item(
                  j).nomineeOverUnderPaymentDtls.coverPeriodTo = key.toDate
                      .addDays(-1);
            }

            nomineeHeaderFound = true;
            break;
          }
        }

        // otherwise set up NomineeReassessmentHeader
        if (!nomineeHeaderFound) {

          final NomineeReassessmentHeader nomineeReassessmentHeader = new NomineeReassessmentHeader();

          nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID = productDeliveryFinCompDtlsList.dtls
              .item(i).caseNomineeID;

          nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom = key.fromDate;

          nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo = key.toDate
              .addDays(-1);

          completeCaseReassessment.nomineeReassessmentHeaderList
              .addRef(nomineeReassessmentHeader);

          // set iterator to the new record
          j = completeCaseReassessment.nomineeReassessmentHeaderList.size() - 1;
        }

        // Check to see if there is a matching NomineeReassessmentDetails
        reassessmentDetailsFound = false;

        for (k = 0; k < completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).reassessmentDetailsList.size(); k++) {

          if (completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList
                  .item(k).reassessmentInfoDtls.fromDate.equals(key.fromDate)
              && completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList
                      .item(k).reassessmentInfoDtls.toDate
                          .equals(key.toDate.addDays(-1))) {
            reassessmentDetailsFound = true;
            break;
          }
        }

        // If not add one in
        if (!reassessmentDetailsFound) {
          final NomineeReassessmentDetails nomineeReassessmentDetails = new NomineeReassessmentDetails();

          nomineeReassessmentDetails.reassessmentInfoDtls.fromDate = key.fromDate;

          nomineeReassessmentDetails.reassessmentInfoDtls.toDate = key.toDate
              .addDays(-1);

          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList
                  .addRef(nomineeReassessmentDetails);

          // Set iterator to point to new record
          k = completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.size() - 1;
        }

        // get the right value
        if (productDeliveryFinCompDtlsList.dtls.item(i).componentCategory
            .equals(FINCOMPONENTCATEGORY.CLAIM)) {

          amountType = REASSESSMENT_AMOUNT.GROSS;
        } else {
          amountType = REASSESSMENT_AMOUNT.BILL;
        }

        // Is there an amountInfo record for this type
        reassessmentAmountInfoFound = false;

        for (l = 0; l < completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).reassessmentDetailsList.item(k).amountDetailsList
                .size(); l++) {

          if (completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.item(k).amountDetailsList
                  .item(l).amountType.equals(amountType)) {

            reassessmentAmountInfoFound = true;
            break;
          }
        }

        // if not found, add new record
        if (!reassessmentAmountInfoFound) {

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.amountType = amountType;

          // add to the list
          completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.item(k).amountDetailsList
                  .addRef(reassessmentAmountInfoDetails);

          // Set iterator to point to new record
          l = completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.item(k).amountDetailsList.size()
              - 1;
        }

        // Add new details to reassessmentAmountInfoDetails
        completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).reassessmentDetailsList.item(k).amountDetailsList
                .item(l).reassessedAmount = new Money(
                    completeCaseReassessment.nomineeReassessmentHeaderList
                        .item(j).reassessmentDetailsList
                            .item(k).amountDetailsList.item(l).reassessedAmount
                                .getValue()
                        + productDeliveryFinCompDtlsList.dtls.item(i).amount
                            .getValue());

        // BEGIN, CR00251296, KH
        // Add or update the breakdown details
        if (completeCaseReassessment.nomineeReassessmentHeaderList
            .item(j).reassessmentDetailsList.item(k).amountDetailsList
                .size() > 0) {

          boolean breakdownFound = false;

          for (int m = 0; m < completeCaseReassessment.nomineeReassessmentHeaderList
              .item(j).reassessmentDetailsList.item(k).amountDetailsList
                  .item(l).breakdownPerObjectiveList.details.size(); m++) {

            /*
             * If the objective and related reference match we can update the
             * reassessed amount for the existing breakdown details.
             */
            if (completeCaseReassessment.nomineeReassessmentHeaderList
                .item(j).reassessmentDetailsList.item(k).amountDetailsList
                    .item(l).breakdownPerObjectiveList.details
                        .item(m).rulesObjectiveID
                            .equals(productDeliveryFinCompDtlsList.dtls
                                .item(i).rulesObjectiveID)
                && completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList.item(k).amountDetailsList
                        .item(l).breakdownPerObjectiveList.details
                            .item(m).relatedReference
                                .equals(productDeliveryFinCompDtlsList.dtls
                                    .item(i).relatedReference)) {

              completeCaseReassessment.nomineeReassessmentHeaderList
                  .item(j).reassessmentDetailsList.item(k).amountDetailsList
                      .item(l).breakdownPerObjectiveList.details
                          .item(m).reassessedAmount = new Money(
                              completeCaseReassessment.nomineeReassessmentHeaderList
                                  .item(j).reassessmentDetailsList
                                      .item(k).amountDetailsList.item(
                                          l).breakdownPerObjectiveList.details
                                              .item(m).reassessedAmount
                                                  .getValue()
                                  + productDeliveryFinCompDtlsList.dtls
                                      .item(i).amount.getValue());

              breakdownFound = true;
              break;
            }
          } // end for m

          // If the breakdown details were not found create them
          if (!breakdownFound) {

            /*
             * Read the rules objective from the financial component list for
             * the correct period.
             */
            final DateRange fcCoverPeriod = new DateRange(
                productDeliveryFinCompDtlsList.dtls.item(i).startDate,
                productDeliveryFinCompDtlsList.dtls.item(i).endDate);

            final DateRange reassessmentPeriod = new DateRange(
                completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList
                        .item(k).reassessmentInfoDtls.fromDate,
                completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList
                        .item(k).reassessmentInfoDtls.toDate);

            /*
             * Check to see if the financial component dates fall within the
             * reassessment period or if the reassessment period falls within
             * the financial component period
             */
            if (fcCoverPeriod.contains(reassessmentPeriod)
                || reassessmentPeriod.contains(fcCoverPeriod)) {

              final ObjectiveAmountDetailsList objectiveList = new ObjectiveAmountDetailsList();

              objectiveList
                  .assign(completeCaseReassessment.nomineeReassessmentHeaderList
                      .item(j).reassessmentDetailsList.item(k).amountDetailsList
                          .item(l).breakdownPerObjectiveList);

              boolean objectiveAlreadyAdded = false;

              for (int q = 0; q < objectiveList.details.size(); q++) {

                // BEGIN, CR00175021, KH
                // Check if we already have an entry for this objective
                if (productDeliveryFinCompDtlsList.dtls.item(i).rulesObjectiveID
                    .equals(objectiveList.details.item(q).rulesObjectiveID)
                    && productDeliveryFinCompDtlsList.dtls
                        .item(i).relatedReference.equals(
                            objectiveList.details.item(q).relatedReference)) {

                  objectiveAlreadyAdded = true;
                } // end if
                // END, CR00175021
              } // end for q

              // If we don't have an entry for this objective create one
              if (!objectiveAlreadyAdded) {

                final ObjectiveAmountDetails objectiveAmountDetails = new ObjectiveAmountDetails();

                objectiveAmountDetails.rulesObjectiveID = productDeliveryFinCompDtlsList.dtls
                    .item(i).rulesObjectiveID;

                // BEGIN, CR00175021, KH
                objectiveAmountDetails.relatedReference = productDeliveryFinCompDtlsList.dtls
                    .item(i).relatedReference;
                // END, CR00175021

                objectiveAmountDetails.reassessedAmount = new Money(
                    productDeliveryFinCompDtlsList.dtls.item(i).amount);

                completeCaseReassessment.nomineeReassessmentHeaderList
                    .item(j).reassessmentDetailsList.item(k).amountDetailsList
                        .item(l).breakdownPerObjectiveList.details
                            .addRef(objectiveAmountDetails);

              } // end if !objectiveAlreadyAdded
            } // end if fcCoverPeriod.contains
          }
        }
        // END, CR00251296
      }
    } // end for i
  }

  // ___________________________________________________________________________
  /**
   * This method forms a complete list of the periods where an over or under
   * payment occurred and the value for those periods.
   *
   * @param fullReassessmentDetails
   *          The details of the payments made and received and payments that
   *          should have been made and received from each nominee.
   * @param componentDetailsList
   *          The components to be reassessed
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          Structure which aggregates a list of existing decisions and their
   *          associated components
   *
   * @return The complete list of all periods where over or under payments were
   *         made and the values of those payments.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public CompleteCaseReassessment formResultList(
      final CompleteCaseReassessment fullReassessmentDetails,
      final ComponentDetailsList componentDetailsList,
      final CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions)
      throws AppException, InformationalException {

    // reassessmentDetails variable
    final CompleteCaseReassessment reassessmentDetails = new CompleteCaseReassessment();

    // indicates whether nomineeReassessmentHeader has been inserted
    boolean nomineeReassessmentHdrInserted = false;

    // indicates whether nomineeReassessmentDetails has been inserted
    boolean nomineeReassessmentDtlsInserted = false;

    for (int i = 0; i < fullReassessmentDetails.nomineeReassessmentHeaderList
        .size(); i++) {

      // re-set inserted flag
      nomineeReassessmentHdrInserted = false;

      for (int j = 0; j < fullReassessmentDetails.nomineeReassessmentHeaderList
          .item(i).reassessmentDetailsList.size(); j++) {

        // re-set inserted flag
        nomineeReassessmentDtlsInserted = false;

        for (int k = 0; k < fullReassessmentDetails.nomineeReassessmentHeaderList
            .item(i).reassessmentDetailsList.item(j).amountDetailsList
                .size(); k++) {

          // If not already copied add the Header to the new list
          if (!nomineeReassessmentHdrInserted) {

            final NomineeReassessmentHeader nomineeReassessmentHeader = new NomineeReassessmentHeader();

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls
                .assign(fullReassessmentDetails.nomineeReassessmentHeaderList
                    .item(i).nomineeOverUnderPaymentDtls);

            reassessmentDetails.nomineeReassessmentHeaderList
                .addRef(nomineeReassessmentHeader);

            nomineeReassessmentHdrInserted = true;
          }

          // If not already copied add the Dtls to the new list
          if (!nomineeReassessmentDtlsInserted) {

            final NomineeReassessmentDetails nomineeReassessmentDetails = new NomineeReassessmentDetails();

            nomineeReassessmentDetails.reassessmentInfoDtls
                .assign(fullReassessmentDetails.nomineeReassessmentHeaderList
                    .item(i).reassessmentDetailsList
                        .item(j).reassessmentInfoDtls);

            reassessmentDetails.nomineeReassessmentHeaderList
                .item(reassessmentDetails.nomineeReassessmentHeaderList.size()
                    - 1).reassessmentDetailsList
                        .addRef(nomineeReassessmentDetails);

            nomineeReassessmentDtlsInserted = true;
          }
        }

        // It is possible that the nominee reassessment details may not be
        // populated in which case no NomineeReassessmentHeader has been added.
        if (nomineeReassessmentHdrInserted) {

          // copy the ReassessmentAmountInfoList details into the new list
          reassessmentDetails.nomineeReassessmentHeaderList
              .item(reassessmentDetails.nomineeReassessmentHeaderList.size()
                  - 1).reassessmentDetailsList.item(
                      reassessmentDetails.nomineeReassessmentHeaderList.item(
                          reassessmentDetails.nomineeReassessmentHeaderList
                              .size() - 1).reassessmentDetailsList.size()
                          - 1).amountDetailsList.addAll(
                              fullReassessmentDetails.nomineeReassessmentHeaderList
                                  .item(i).reassessmentDetailsList
                                      .item(j).amountDetailsList);
        }
      }

    }

    // BEGIN, 178020, CSH
    // Form the decision list for the reassessment
    return getReassessmentDecisions(newCaseDecisions, existingCaseDecisions,
        reassessmentDetails);
    // END, 178020

  }

  // BEGIN, 178020, CSH
  // ___________________________________________________________________________
  /**
   * Retrieves the list of decision details for the current reassessment and
   * maps them in to the overall reassessment details struct. These decisions
   * will be stored later on the ReassessmentDecisionInfo entity.
   *
   * @param newCaseDecisions
   *          A structure which aggregates a list of new decisions and their
   *          associated components.
   * @param existingCaseDecisions
   *          A structure which aggregates a list of existing decisions and
   *          their associated components.
   * @param reassessmentDetails
   *          The reassessment details that are being built up for the current
   *          reassessment
   *
   * @return The reassessment details return struct with the decision details
   *         for this reassessment mapped in
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  protected CompleteCaseReassessment getReassessmentDecisions(
      final CompleteDecisionCreationList newCaseDecisions,
      final CompleteDecisionCreationList existingCaseDecisions,
      final CompleteCaseReassessment reassessmentDetails)
      throws AppException, InformationalException {

    if (newCaseDecisions.dtls.isEmpty()) {
      return reassessmentDetails;
    }

    // Set the key data on the output struct...
    reassessmentDetails.overUnderPaymentHeaderDtls.reassessmentDate = curam.util.type.Date
        .getCurrentDate();

    reassessmentDetails.overUnderPaymentHeaderDtls.caseID = newCaseDecisions.dtls
        .item(0).details.caseID;

    final CaseDecisionDtlsList tempOldCaseDecisionDtlsList = new CaseDecisionDtlsList();
    final CaseDecisionDtlsList tempNewCaseDecisionDtlsList = new CaseDecisionDtlsList();
    int l;

    ReassessmentDecisionInfoDtls reassessmentDecisionInfoDtls;
    CaseDecisionDtls caseDecisionDtls;

    for (int o = 0; o < reassessmentDetails.nomineeReassessmentHeaderList
        .size(); o++) {

      for (int p = 0; p < reassessmentDetails.nomineeReassessmentHeaderList
          .item(o).reassessmentDetailsList.size(); p++) {

        // BEGIN, CR00250121, KH
        final DateRange reassessmentPeriod = new DateRange(
            reassessmentDetails.nomineeReassessmentHeaderList
                .item(o).reassessmentDetailsList
                    .item(p).reassessmentInfoDtls.fromDate,
            reassessmentDetails.nomineeReassessmentHeaderList
                .item(o).reassessmentDetailsList
                    .item(p).reassessmentInfoDtls.toDate);

        // Add the ReassessmentDecisionInfo records
        for (l = 0; l < existingCaseDecisions.dtls.size(); l++) {

          final DateRange decisionPeriod = new DateRange(
              existingCaseDecisions.dtls.item(l).details.decisionFromDate,
              existingCaseDecisions.dtls.item(l).details.decisionToDate);

          /*
           * Get existing decisions which contain the reassessed payment period
           * or existing decision which are completely within the reassessment
           * payment period.
           */
          if (decisionPeriod.contains(reassessmentPeriod)
              || reassessmentPeriod.contains(decisionPeriod)) {

            caseDecisionDtls = new CaseDecisionDtls();
            caseDecisionDtls.assign(existingCaseDecisions.dtls.item(l).details);

            tempOldCaseDecisionDtlsList.dtls.addRef(caseDecisionDtls);
          }
        }

        for (l = 0; l < newCaseDecisions.dtls.size(); l++) {

          final DateRange decisionPeriod = new DateRange(
              newCaseDecisions.dtls.item(l).details.decisionFromDate,
              newCaseDecisions.dtls.item(l).details.decisionToDate);

          /*
           * Get existing decisions which contain the reassessed payment period
           * or existing decision which are completely within the reassessment
           * payment period.
           */
          if (decisionPeriod.contains(reassessmentPeriod)
              || reassessmentPeriod.contains(decisionPeriod)) {

            caseDecisionDtls = new CaseDecisionDtls();
            caseDecisionDtls.assign(newCaseDecisions.dtls.item(l).details);

            tempNewCaseDecisionDtlsList.dtls.addRef(caseDecisionDtls);
          }
        }
        // END, CR00250121

        // Compare each element on the list of new decision with the list of
        // old decisions, if the dates on the list match fully or partially
        // push a ReassessmentDecisionInfoDtls onto the list.

        // BEGIN, CR00238809, VM
        boolean overlapFound = false;

        for (int m = 0; m < tempNewCaseDecisionDtlsList.dtls.size(); m++) {

          // BEGIN, CR00242165, KH
          // Get date range of current new decision
          final DateRange newDateRange = new DateRange(
              tempNewCaseDecisionDtlsList.dtls.item(m).decisionFromDate,
              tempNewCaseDecisionDtlsList.dtls.item(m).decisionToDate);

          for (int n = 0; n < tempOldCaseDecisionDtlsList.dtls.size(); n++) {

            // Get date range of current old decision
            final DateRange oldDateRange = new DateRange(
                tempOldCaseDecisionDtlsList.dtls.item(n).decisionFromDate,
                tempOldCaseDecisionDtlsList.dtls.item(n).decisionToDate);

            if (newDateRange.overlapsWith(oldDateRange)) {
              // END, CR00242165

              reassessmentDecisionInfoDtls = new ReassessmentDecisionInfoDtls();
              reassessmentDecisionInfoDtls.oldDecisionID = tempOldCaseDecisionDtlsList.dtls
                  .item(n).caseDecisionID;
              reassessmentDecisionInfoDtls.reassessedDecisionID = tempNewCaseDecisionDtlsList.dtls
                  .item(m).caseDecisionID;
              reassessmentDetails.nomineeReassessmentHeaderList
                  .item(o).reassessmentDetailsList.item(p).decisionList
                      .addRef(reassessmentDecisionInfoDtls);

              overlapFound = true;
            }
          }
        }

        // If no overlap has been found, it's entirely possible that the case
        // start date was pushed back, in which case there will be one or more
        // new decisions but no old decisions
        if (!overlapFound) {

          if (!tempNewCaseDecisionDtlsList.dtls.isEmpty()
              && tempOldCaseDecisionDtlsList.dtls.isEmpty()) {

            for (int v = 0; v < tempNewCaseDecisionDtlsList.dtls.size(); v++) {

              reassessmentDecisionInfoDtls = new ReassessmentDecisionInfoDtls();

              reassessmentDecisionInfoDtls.oldDecisionID = 0;
              reassessmentDecisionInfoDtls.reassessedDecisionID = tempNewCaseDecisionDtlsList.dtls
                  .item(v).caseDecisionID;
              reassessmentDetails.nomineeReassessmentHeaderList
                  .item(o).reassessmentDetailsList.item(p).decisionList
                      .addRef(reassessmentDecisionInfoDtls);
            }
          }

          // BEGIN, CR00404711, CSH
          // It is also possible that a case end date which is earlier than
          // the expected end date has been set, resulting in
          // over payments, in which case there will be one or more old
          // decisions but no new decisions.

          if (!tempOldCaseDecisionDtlsList.dtls.isEmpty()
              && tempNewCaseDecisionDtlsList.dtls.isEmpty()) {

            for (int w = 0; w < tempOldCaseDecisionDtlsList.dtls.size(); w++) {

              reassessmentDecisionInfoDtls = new ReassessmentDecisionInfoDtls();

              reassessmentDecisionInfoDtls.oldDecisionID = tempOldCaseDecisionDtlsList.dtls
                  .item(w).caseDecisionID;
              reassessmentDecisionInfoDtls.reassessedDecisionID = 0;
              reassessmentDetails.nomineeReassessmentHeaderList
                  .item(o).reassessmentDetailsList.item(p).decisionList
                      .addRef(reassessmentDecisionInfoDtls);
              // }
            }
          }
          // END, CR00404711

          // If both lists are empty, we need to find the most recent superseded
          // decision(s)
          if (tempNewCaseDecisionDtlsList.dtls.size() == 0
              && tempOldCaseDecisionDtlsList.dtls.size() == 0) {

            final CREOLECaseDeterminationKey creoleCaseDeterminationKey = new CREOLECaseDeterminationKey();

            final CaseIDStatusInitReasonCodeFromDateKey rmKey = new CaseIDStatusInitReasonCodeFromDateKey();

            rmKey.caseID = newCaseDecisions.dtls.item(0).details.caseID;
            rmKey.statusCode = CASEDECISIONSTATUS.SUPERSEDED;
            rmKey.initReasonCode = CASEDECISIONINITREASONCODE.RELEASE;
            rmKey.fromDate = reassessmentPeriod.start().addDays(1);

            final CaseDecisionDtlsList list = CaseDecisionFactory.newInstance()
                .searchByCaseIDStatusInitReasonCodeFromDate(rmKey);

            for (int n = 0; n < list.dtls.size(); n++) {
              final DateRange dateRange = new DateRange(
                  list.dtls.item(n).decisionFromDate,
                  list.dtls.item(n).decisionToDate);

              if (reassessmentPeriod.overlapsWith(dateRange)) {
                tempOldCaseDecisionDtlsList.dtls.addRef(list.dtls.item(n));
              }
            }

            final CREOLECaseDeterminationDtlsList creoleCaseDeterminationList = new CREOLECaseDeterminationDtlsList();

            final NotFoundIndicator notFoundInd = new NotFoundIndicator();

            for (int q = 0; q < tempOldCaseDecisionDtlsList.dtls.size(); q++) {

              final CREOLECaseDecisionKey creoleCaseDecisionKey = new CREOLECaseDecisionKey();

              creoleCaseDecisionKey.caseDecisionID = tempOldCaseDecisionDtlsList.dtls
                  .item(q).caseDecisionID;

              final CREOLECaseDecisionDtls creoleCaseDecisionDtls = CREOLECaseDecisionFactory
                  .newInstance().read(notFoundInd, creoleCaseDecisionKey);

              // If not found then we are dealing with Classic Rules in which
              // case skip to the
              // next record
              if (notFoundInd.isNotFound()) {
                continue;
              }

              creoleCaseDeterminationKey.creoleCaseDeterminationID = creoleCaseDecisionDtls.creoleCaseDeterminationID;

              final CREOLECaseDeterminationDtls creoleCaseDeterminationDtls = CREOLECaseDeterminationFactory
                  .newInstance().read(creoleCaseDeterminationKey);

              if (!creoleCaseDeterminationList.dtls.isEmpty()) {

                boolean recordFound = false;

                for (int r = 0; r < creoleCaseDeterminationList.dtls
                    .size(); r++) {
                  if (creoleCaseDeterminationList.dtls.item(
                      r).creoleCaseDeterminationID == creoleCaseDeterminationDtls.creoleCaseDeterminationID) {
                    recordFound = true;
                    break;
                  }
                }

                if (!recordFound) {
                  creoleCaseDeterminationList.dtls
                      .addRef(creoleCaseDeterminationDtls);
                }

              } else {
                creoleCaseDeterminationList.dtls
                    .addRef(creoleCaseDeterminationDtls);
              }
            }

            // Firstly order the records by timestamp descending
            final CREOLECaseDeterminationComparator creoleCaseDeterminationComparator = new CREOLECaseDeterminationComparator();

            final ArrayList<CREOLECaseDeterminationDtls> creoleArray = new ArrayList<CREOLECaseDeterminationDtls>();

            if (creoleCaseDeterminationList.dtls.size() > 0) {

              creoleArray.addAll(creoleCaseDeterminationList.dtls);
              Collections.sort(creoleArray, creoleCaseDeterminationComparator);

              creoleCaseDeterminationList.dtls.clear();

              for (int s = 0; s < creoleArray.size(); s++) {
                creoleCaseDeterminationList.dtls.addRef(creoleArray.get(s));
              }

              // Find the most recent determination
              final CREOLECaseDeterminationDtls mostRecentDetermination = creoleCaseDeterminationList.dtls
                  .item(0);

              // Now find all the decisions for this determination
              creoleCaseDeterminationKey.creoleCaseDeterminationID = mostRecentDetermination.creoleCaseDeterminationID;

              final CREOLECaseDecisionDtlsList decisions = CREOLECaseDecisionFactory
                  .newInstance().searchByCREOLECaseDeterminationID(
                      creoleCaseDeterminationKey);

              for (int t = 0; t < decisions.dtls.size(); t++) {

                reassessmentDecisionInfoDtls = new ReassessmentDecisionInfoDtls();

                reassessmentDecisionInfoDtls.oldDecisionID = decisions.dtls
                    .item(t).caseDecisionID;
                reassessmentDecisionInfoDtls.reassessedDecisionID = decisions.dtls
                    .item(t).caseDecisionID;
                reassessmentDetails.nomineeReassessmentHeaderList
                    .item(o).reassessmentDetailsList.item(p).decisionList
                        .addRef(reassessmentDecisionInfoDtls);
              }

            }
          }

        }
        // END, CR00238809

        // clear the lists
        tempNewCaseDecisionDtlsList.dtls.clear();
        tempOldCaseDecisionDtlsList.dtls.clear();
      }
    }

    return reassessmentDetails;
  }

  // END, 178020

  // ___________________________________________________________________________
  /**
   * This method is used to store the over/under payment results of Case
   * Reassessment for viewing on the client.
   *
   * As a result, much of the functionality contained within this method deals
   * with the manipulation of reassessment amount info records, the detail of
   * which is used to populate the benefit statement when viewed.
   *
   * During subsequent reassessments, it is possible for the period of a
   * reassessment amount info record, covering a specific delivery period, not
   * to match exactly the period of a reassessment amount info record for the
   * previous reassessment for the same delivery period insofar as there will
   * only be a match on some but not all of the days.
   *
   * If the records match on even one day, the reassessment amount info record
   * from the previous reassessment needs to be considered when calculating the
   * amounts for the current reassessment amount info record.
   *
   * An example of the logic used in the calculation of these amounts is
   * included in the Inside The Curam Case Manager Guide.
   *
   * @param nomineeReassessmentHeader
   *          The details of an over or under payment to be made in respect of a
   *          nominee.
   * @param overUnderPaymentHeaderDtls
   *          Details of over or under payments.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void storeReassessmentResults(
      final NomineeReassessmentHeader nomineeReassessmentHeader,
      final OverUnderPaymentHeaderDtls overUnderPaymentHeaderDtls)
      throws AppException, InformationalException {

    // BEGIN, 178020, CSH
    // Setting indicator for use in later calculations
    totalActualAmountZero = nomineeReassessmentHeader.reassessmentSummaryDetails.totalActualAmount
        .isZero();
    // END, 178020

    // OverUnderPaymentHeader manipulation object
    final curam.core.intf.OverUnderPaymentHeader overUnderPaymentHeaderObj = curam.core.fact.OverUnderPaymentHeaderFactory
        .newInstance();

    // ReassessmentInfo manipulation variables
    final curam.core.intf.ReassessmentInfo reassessmentInfoObj = curam.core.fact.ReassessmentInfoFactory
        .newInstance();
    ReassessmentInfoDtlsList reassessmentInfoDtlsList;

    // ReassessmentDecisionInfo manipulation object
    final curam.core.intf.ReassessmentDecisionInfo reassessmentDecisionInfoObj = curam.core.fact.ReassessmentDecisionInfoFactory
        .newInstance();

    // uniqueID object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory
        .newInstance();

    // NomineeOverUnderPayment manipulation variables
    final curam.core.intf.NomineeOverUnderPayment nomineeOverUnderPaymentObj = curam.core.fact.NomineeOverUnderPaymentFactory
        .newInstance();
    final NomineeOverUnderPaymentKey nomineeOverUnderPaymentKey = new NomineeOverUnderPaymentKey();
    final PreviousNomOverUnderPaymentKey previousKey = new PreviousNomOverUnderPaymentKey();
    final ReadmultiByNomineeOverUnderPaymentIDKey searchByNomOverUnderKey = new ReadmultiByNomineeOverUnderPaymentIDKey();
    NomineeOverUnderPaymentDtls prevNomineeOverUnderPaymentDtls = new NomineeOverUnderPaymentDtls();

    // ReassessmentAmountInfo manipulation variables
    final curam.core.intf.ReassessmentAmountInfo reassessmentAmountInfoObj = curam.core.fact.ReassessmentAmountInfoFactory
        .newInstance();
    ReassessmentAmountInfoDtlsList reassessmentAmountInfoDtlsList = new ReassessmentAmountInfoDtlsList();
    ReassessmentAmountInfoDtlsList addReassessmentAmountInfoDtlsList = new ReassessmentAmountInfoDtlsList();
    final ReassessmentAmountInformationKey reassessmentAmountInformationKey = new ReassessmentAmountInformationKey();

    // indicates that this is the first time reassessment is being run for
    // this case.
    boolean thisIsTheFirstReassessment = false;

    // indicates that there is another NomineeOverUnderPayment record in the
    // history for the nomineeCaseLink.
    boolean nextNomOverUnderPayment = true;

    // indicates that the most recent NomineeOverUnderPayment record is the
    // first in the list.
    boolean mostRecentFirst = false;

    // BEGIN, CR00052157, MC
    // the total figure for overpayment
    curam.util.type.Money totalOverpayment = curam.util.type.Money.kZeroMoney;
    boolean matchReassessmentInfoDtls = true;
    int kCount = 0;
    // END, CR00052157, MC

    // Indicates if the period of a reassessmentInfo record, for a
    // specific nominee, from the previous reassessment matches exactly the
    // period of a reassesmentInfo record for the current reassessment, for the
    // same nominee
    boolean exactPeriodMatch = false;

    // local variable holds the earliest date upon which this case has been
    // reassessed in respect of the nominee.
    Date earliestDate = Date.kZeroDate;
    final Money zeroAmount = Money.kZeroMoney;

    overUnderPaymentHeaderDtls.overUnderPaymentHeaderID = uniqueIDObj
        .getNextID();

    // insert case reassessment header record
    overUnderPaymentHeaderObj.insert(overUnderPaymentHeaderDtls);

    nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID = uniqueIDObj
        .getNextID();

    nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.overUnderPaymentHeaderID = overUnderPaymentHeaderDtls.overUnderPaymentHeaderID;

    // BEGIN, CR00211744, VM
    final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    caseNomineeKey.caseNomineeID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID;

    final NomineeOverUnderPaymentDtlsList allNomineeOverUnderPayments = assessmentEngineEntity
        .getOverUnderPaymentsByCaseNomineeID(caseNomineeKey);

    // END, CR00211744

    if (!allNomineeOverUnderPayments.dtls.isEmpty()) {

      final int i = 0;

      previousKey.prevNomOverUnderPaymentID = allNomineeOverUnderPayments.dtls
          .item(i).nomineeOverUnderPaymentID;

      try {
        prevNomineeOverUnderPaymentDtls = nomineeOverUnderPaymentObj
            .readByPreviousID(previousKey);

      } catch (final RecordNotFoundException e) {

        // if theres no previous NomineeOverUnderPayment then we're already
        // at the most recent NomineeOverUnderpayment record.
        nextNomOverUnderPayment = false;
        mostRecentFirst = true;
      }

      // keep reading for the most recent NomineeOverUnderPayment record.
      while (nextNomOverUnderPayment) {

        previousKey.prevNomOverUnderPaymentID = prevNomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

        try {
          prevNomineeOverUnderPaymentDtls = nomineeOverUnderPaymentObj
              .readByPreviousID(previousKey);

        } catch (final RecordNotFoundException e) {

          nextNomOverUnderPayment = false;
        }

      }

      // If there is not just one NomineeOverUnderpayment, we
      // need to read the nomineeOverUnderPayment record we stopped on for
      // its previous ID.
      if (!mostRecentFirst) {

        nomineeOverUnderPaymentKey.nomineeOverUnderPaymentID = previousKey.prevNomOverUnderPaymentID;

        prevNomineeOverUnderPaymentDtls = nomineeOverUnderPaymentObj
            .read(nomineeOverUnderPaymentKey);

        searchByNomOverUnderKey.nomineeOverUnderPaymentID = prevNomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

        nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.prevNomOverUnderPaymentID = prevNomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

      } else {

        // the first one drawn from the list is the most recent.
        nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.prevNomOverUnderPaymentID = allNomineeOverUnderPayments.dtls
            .item(i).nomineeOverUnderPaymentID;
        searchByNomOverUnderKey.nomineeOverUnderPaymentID = allNomineeOverUnderPayments.dtls
            .item(i).nomineeOverUnderPaymentID;
      }

    } else {
      thisIsTheFirstReassessment = true;
    }

    // insert nomineeOverUnderPayment record
    nomineeOverUnderPaymentObj
        .insert(nomineeReassessmentHeader.nomineeOverUnderPaymentDtls);

    // Returning a list of all reassessmentInfo records for the most recent
    // NomineeOverUnderPayent to determine whether any of its dates are not
    // included in the current NomineeOverUnderPayment insertion.
    reassessmentInfoDtlsList = reassessmentInfoObj
        .searchByNomineeOverUnderPaymentID(searchByNomOverUnderKey);

    // BEGIN, CR00052157, MC

    // If payments are generated for more than one week and
    // if the last payment is cancelled, invalidated and
    // the certification period of last week is reduced, then
    // on changing the evidence type, an overpayment will be
    // created with benefit statement details missing last
    // week payment details. Below logic is to add the missing
    // last week payment details.

    if (reassessmentInfoDtlsList.dtls.size() != 0
        && nomineeReassessmentHeader.reassessmentDetailsList.size() != 0
        && reassessmentInfoDtlsList.dtls
            .size() > nomineeReassessmentHeader.reassessmentDetailsList.size()
        && reassessmentInfoDtlsList.dtls
            .size() == nomineeReassessmentHeader.reassessmentDetailsList.size()
                + 1
        && nomineeReassessmentHeader.reassessmentSummaryDetails.reassessmentResultType
            .equals(REASSESSMENTRESULT.OVERPAYMENT)) {

      for (kCount = 0; kCount < nomineeReassessmentHeader.reassessmentDetailsList
          .size(); kCount++) {

        if (!nomineeReassessmentHeader.reassessmentDetailsList
            .item(kCount).reassessmentInfoDtls.fromDate
                .equals(reassessmentInfoDtlsList.dtls.item(kCount).fromDate)
            || !nomineeReassessmentHeader.reassessmentDetailsList
                .item(kCount).reassessmentInfoDtls.toDate.equals(
                    reassessmentInfoDtlsList.dtls.item(kCount).toDate)) {

          matchReassessmentInfoDtls = false;
          break;
        } else {
          for (int k = 0; k < nomineeReassessmentHeader.reassessmentDetailsList
              .item(kCount).amountDetailsList.size() - 1; k++) {

            totalOverpayment = new Money(totalOverpayment.getValue()
                + nomineeReassessmentHeader.reassessmentDetailsList
                    .item(kCount).amountDetailsList.item(k).actualAmount
                        .getValue());
          } // end for k
        }
      } // end for kCount

      // BEGIN, CR00173527, KH
      if (nomineeReassessmentHeader.reassessmentSummaryDetails.totalAmount != totalOverpayment
          || matchReassessmentInfoDtls) {
        // END, CR00173527

        final NomineeReassessmentDetails nomineeReassessmentDetails = new NomineeReassessmentDetails();

        final ReassessmentAmountInfoDetails actualReassessmentAmtInfoDtls = new ReassessmentAmountInfoDetails();

        final ReassessmentAmountInfoDetails reassessedReassessmentAmtInfoDtls = new ReassessmentAmountInfoDetails();

        nomineeReassessmentDetails.reassessmentInfoDtls.fromDate = reassessmentInfoDtlsList.dtls
            .item(kCount).fromDate;
        nomineeReassessmentDetails.reassessmentInfoDtls.toDate = reassessmentInfoDtlsList.dtls
            .item(kCount).toDate;

        actualReassessmentAmtInfoDtls.amountType = curam.codetable.REASSESSMENT_AMOUNT.GROSS;
        reassessedReassessmentAmtInfoDtls.amountType = curam.codetable.REASSESSMENT_AMOUNT.NET;

        nomineeReassessmentDetails.amountDetailsList
            .addRef(actualReassessmentAmtInfoDtls);
        nomineeReassessmentDetails.amountDetailsList
            .addRef(reassessedReassessmentAmtInfoDtls);

        nomineeReassessmentDetails.decisionList
            .addRef(nomineeReassessmentHeader.reassessmentDetailsList
                .item(0).decisionList.item(0));

        nomineeReassessmentHeader.reassessmentDetailsList
            .addRef(nomineeReassessmentDetails);
      }
    }
    // END, CR00052157

    // BEGIN, CR00148989, KH
    // Create list of "previous" headers, including current one
    final NomineeOverUnderPaymentDtlsList nomineeOverUnderPaymentDtlsList = new NomineeOverUnderPaymentDtlsList();
    final NomineeOverUnderPaymentKey prevNomineeOverUnderPaymentKey = new NomineeOverUnderPaymentKey();

    NomineeOverUnderPaymentDtls nomineeOverUnderPaymentDtls = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls;

    // Add current Nominee Over Under Payment details to the list
    nomineeOverUnderPaymentDtlsList.dtls.addRef(nomineeOverUnderPaymentDtls);

    // Check if it's worth reading back through the previous ones
    if (nomineeOverUnderPaymentDtls.prevNomOverUnderPaymentID != 0) {

      boolean readPrev = true;

      while (readPrev) {

        prevNomineeOverUnderPaymentKey.nomineeOverUnderPaymentID = nomineeOverUnderPaymentDtls.prevNomOverUnderPaymentID;

        try {
          nomineeOverUnderPaymentDtls = nomineeOverUnderPaymentObj
              .read(prevNomineeOverUnderPaymentKey);

          nomineeOverUnderPaymentDtlsList.dtls
              .addRef(nomineeOverUnderPaymentDtls);
        } catch (final RecordNotFoundException e) {
          readPrev = false;
        }
      }
    }

    ReassessmentInfoDtlsList prevReassessmentInfoDtlsList;
    final ReadmultiByNomineeOverUnderPaymentIDKey searchPrevByNomOverUnderKey = new ReadmultiByNomineeOverUnderPaymentIDKey();
    final Map<Long, ReassessmentInfoDtlsList> noupMap = new HashMap<Long, ReassessmentInfoDtlsList>();

    for (int p = 0; p < nomineeOverUnderPaymentDtlsList.dtls.size(); p++) {

      // Set key to read previous reassessmentInfo
      searchPrevByNomOverUnderKey.nomineeOverUnderPaymentID = nomineeOverUnderPaymentDtlsList.dtls
          .item(p).nomineeOverUnderPaymentID;

      // Returning a list of all reassessmentInfo records for the
      // previous NomineeOverUnderPayment
      prevReassessmentInfoDtlsList = reassessmentInfoObj
          .searchByNomineeOverUnderPaymentID(searchPrevByNomOverUnderKey);

      noupMap.put(
          new Long(searchPrevByNomOverUnderKey.nomineeOverUnderPaymentID),
          prevReassessmentInfoDtlsList);
    }
    // END, CR00148989

    // insert nominee details records
    for (int j = 0; j < nomineeReassessmentHeader.reassessmentDetailsList
        .size(); j++) {

      if (earliestDate
          .after(nomineeReassessmentHeader.reassessmentDetailsList
              .item(j).reassessmentInfoDtls.fromDate)
          || earliestDate.isZero()) {

        earliestDate = nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).reassessmentInfoDtls.fromDate;
      }

      nomineeReassessmentHeader.reassessmentDetailsList.item(
          j).reassessmentInfoDtls.reassessmentInfoID = uniqueIDObj.getNextID();

      nomineeReassessmentHeader.reassessmentDetailsList.item(
          j).reassessmentInfoDtls.nomineeOverUnderPaymentID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

      reassessmentInfoObj
          .insert(nomineeReassessmentHeader.reassessmentDetailsList
              .item(j).reassessmentInfoDtls);

      // BEGIN, CR00142853, KH
      // We want to start with an empty list for each nominee
      reassessmentAmountInfoDtlsList = new ReassessmentAmountInfoDtlsList();

      // BEGIN, CR00180474, VM
      if (!thisIsTheFirstReassessment) {

        // Determine if there is an exact period match and try to populate
        // the reassessmentAmountInfoDtlsList
        exactPeriodMatch = checkForMatchingReassessmentPeriods(
            reassessmentInfoDtlsList,
            nomineeReassessmentHeader.reassessmentDetailsList
                .item(j).reassessmentInfoDtls,
            reassessmentAmountInfoDtlsList).exactPeriodMatch;
      }
      // END, CR00180474

      for (int l = 0; l < nomineeReassessmentHeader.reassessmentDetailsList
          .item(j).decisionList.size(); l++) {

        nomineeReassessmentHeader.reassessmentDetailsList.item(j).decisionList
            .item(l).reassessmentDecisionInfoID = uniqueIDObj.getNextID();

        nomineeReassessmentHeader.reassessmentDetailsList.item(j).decisionList
            .item(
                l).reassessmentInfoID = nomineeReassessmentHeader.reassessmentDetailsList
                    .item(j).reassessmentInfoDtls.reassessmentInfoID;

        reassessmentDecisionInfoObj
            .insert(nomineeReassessmentHeader.reassessmentDetailsList
                .item(j).decisionList.item(l));
      }

      // Reset flag to false
      multipleObjectiveInd = false;

      // Check the amounts for the current reassessment period
      for (int m = 0; m < nomineeReassessmentHeader.reassessmentDetailsList
          .item(j).amountDetailsList.size(); m++) {

        // If this list has more than 1 element then multiple objectives
        // have been used while calculating the amounts for this period
        if (nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).amountDetailsList.item(m).breakdownPerObjectiveList.details
                .size() > 1) {

          multipleObjectiveInd = true;
          break;
        }
      }

      // insert nominee amount details
      for (int l = 0; l < nomineeReassessmentHeader.reassessmentDetailsList
          .item(j).amountDetailsList.size(); l++) {

        // BEGIN, CR00180474, VM
        if (!thisIsTheFirstReassessment) {

          // Reset flag to false
          actualAmountAdjustedInd = false;

          // Indicates if we need to check previous reassessment info
          boolean readPrevious = true;

          // Holds the latest reassessment info
          ReassessmentAmountInfoDtlsList latestReassessmentAmountInfoDtlsList;

          // BEGIN, CR00148989, CR00164348, KH
          // This starts at 1 because we do not want to include the
          // current reassessment (index zero).
          for (int p = 1; p < nomineeOverUnderPaymentDtlsList.dtls
              .size(); p++) {

            final Object obj = noupMap
                .get(new Long(nomineeOverUnderPaymentDtlsList.dtls
                    .item(p).nomineeOverUnderPaymentID));

            prevReassessmentInfoDtlsList = (ReassessmentInfoDtlsList) obj;

            // We want to use an empty list
            latestReassessmentAmountInfoDtlsList = new ReassessmentAmountInfoDtlsList();

            // Determine if there is an exact period match and try to
            // populate the reassessmentAmountInfoDtlsList
            exactPeriodMatch = checkForMatchingReassessmentPeriods(
                prevReassessmentInfoDtlsList,
                nomineeReassessmentHeader.reassessmentDetailsList
                    .item(j).reassessmentInfoDtls,
                latestReassessmentAmountInfoDtlsList).exactPeriodMatch;

            // Calculate the current 'actual' amount and determine whether
            // we need to update this amount based on previous reassessments
            readPrevious = calculateActualReassessmentAmount(
                latestReassessmentAmountInfoDtlsList,
                nomineeReassessmentHeader.reassessmentDetailsList
                    .item(j).amountDetailsList.item(l),
                exactPeriodMatch).readPrevious;

            if (!readPrevious) {

              // BEGIN, 178020, CSH
              // BEGIN, CR00211444, KH
              /*
               * Now check whether the actual amount must be adjusted to
               * consider payments which have been cancelled and re-issued.
               */
              final Money tempAmount = nomineeReassessmentHeader.reassessmentDetailsList
                  .item(j).amountDetailsList.item(l).actualAmount;

              nomineeReassessmentHeader.reassessmentDetailsList
                  .item(j).amountDetailsList
                      .item(l).actualAmount = calculateActualAmount(
                          overUnderPaymentHeaderDtls.caseID,
                          nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID,
                          nomineeReassessmentHeader.reassessmentDetailsList
                              .item(j).reassessmentInfoDtls,
                          nomineeReassessmentHeader.reassessmentDetailsList
                              .item(j).amountDetailsList.item(l));

              // Ensure calculation does not result in a negative amount.
              // This can arise where the period being paid and subsequently
              // reassessed is shortened, but for which there already exists
              // a previous reassessment during that period.
              if (nomineeReassessmentHeader.reassessmentDetailsList
                  .item(j).amountDetailsList.item(l).actualAmount
                      .isNegative()) {
                nomineeReassessmentHeader.reassessmentDetailsList.item(
                    j).amountDetailsList.item(l).reassessedAmount = new Money(
                        -1 * nomineeReassessmentHeader.reassessmentDetailsList
                            .item(j).amountDetailsList.item(l).actualAmount
                                .getValue());

                nomineeReassessmentHeader.reassessmentDetailsList
                    .item(j).amountDetailsList.item(l).actualAmount = new Money(
                        0);

                // If the actualAmount is completely adjusted, then we should do
                // the same with the reassessedAmount
              } else if (tempAmount.isPositive()
                  && nomineeReassessmentHeader.reassessmentDetailsList
                      .item(j).amountDetailsList.item(l).actualAmount
                          .isZero()) {
                nomineeReassessmentHeader.reassessmentDetailsList
                    .item(j).amountDetailsList
                        .item(l).reassessedAmount = new Money(0);
              }
              // END, CR00211444
              // END, 178020

              // There is no need to look back at previous reassessments
              break; // from p
            }
          } // end for p
          // END, CR00148989, CR00164348, CR00180474
        }

        final ReassessmentAmountInfoDtls reassessmentAmountInfoDtls = new ReassessmentAmountInfoDtls();

        nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).amountDetailsList
                .item(l).reassessmentAmountInfoID = uniqueIDObj.getNextID();

        nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).amountDetailsList.item(
                l).reassessmentInfoID = nomineeReassessmentHeader.reassessmentDetailsList
                    .item(j).reassessmentInfoDtls.reassessmentInfoID;

        // BEGIN, 178020, CSH
        // Check where there was a canceled & Invalidated payment
        // with a replacement payment, that any periods filled in to balance
        // these out during reassessment are not duplicated

        // Read list of reassessmentAmountInfo records added for this
        // reassessInfo already during the current reassessment

        boolean alreadyAdded = false;
        final ReassessmentAmountInformationKey reassessmentAmountInfoKey = new ReassessmentAmountInformationKey();
        ReassessmentAmountInfoDtlsList checkRAInfoList = new ReassessmentAmountInfoDtlsList();
        reassessmentAmountInfoKey.reassessmentInfoID = nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).reassessmentInfoDtls.reassessmentInfoID;

        final ReassessmentAmountInfoDtls newReassessmentAmountInfoDtls = new ReassessmentAmountInfoDtls();
        newReassessmentAmountInfoDtls
            .assign(nomineeReassessmentHeader.reassessmentDetailsList
                .item(j).amountDetailsList.item(l));
        checkRAInfoList = reassessmentAmountInfoObj
            .searchByReassessInfoID(reassessmentAmountInfoKey);

        for (int z = 0; z < checkRAInfoList.dtls.size(); z++) {

          if (newReassessmentAmountInfoDtls.reassessmentInfoID == checkRAInfoList.dtls
              .item(z).reassessmentInfoID
              && newReassessmentAmountInfoDtls.amountType == checkRAInfoList.dtls
                  .item(z).amountType) {
            alreadyAdded = true;
          }
        }

        if (!alreadyAdded) {
          reassessmentAmountInfoObj.insert(reassessmentAmountInfoDtls
              .assign(nomineeReassessmentHeader.reassessmentDetailsList
                  .item(j).amountDetailsList.item(l)));
        }
        // END, 178020
      }
    }

    if (!thisIsTheFirstReassessment) {

      Date previousToDate = nomineeReassessmentHeader.reassessmentDetailsList
          .item(0).reassessmentInfoDtls.toDate;
      Date currentFromDate = Date.kZeroDate;
      Date toDate = Date.kZeroDate;

      for (int j = 1; j < nomineeReassessmentHeader.reassessmentDetailsList
          .size(); j++) {

        if (nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).reassessmentInfoDtls.fromDate.addDays(-1).after(
                previousToDate)
            && j < reassessmentInfoDtlsList.dtls.size()) {

          currentFromDate = previousToDate;

          // BEGIN, CR00021345, TV
          // Set toDate to match the future period that we have
          toDate = nomineeReassessmentHeader.reassessmentDetailsList
              .item(j).reassessmentInfoDtls.toDate;
          // END, CR00021345

          // A gap exists between currentFromDate and the toDate
          // Iterate through reassessmentInfoDtlsList to find the missing
          // record
          for (int k = 0; k < reassessmentInfoDtlsList.dtls.size(); k++) {

            // BEGIN, CR00021345, TV
            // If we find a match here, we have found a missing record. We need
            // to insert this
            if (reassessmentInfoDtlsList.dtls.item(k).fromDate.addDays(-1)
                .equals(currentFromDate)
                && reassessmentInfoDtlsList.dtls.item(k).toDate
                    .before(toDate)) {
              // END, CR00021345

              // BEGIN, CR00159904, KH
              // BEGIN, CR00211744, VM
              final RetrieveCaseFinancialsKey retrieveCaseFinancialsKey = new RetrieveCaseFinancialsKey();

              retrieveCaseFinancialsKey.caseID = overUnderPaymentHeaderDtls.caseID;
              retrieveCaseFinancialsKey.caseNomineeID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID;
              retrieveCaseFinancialsKey.periodFromDate = reassessmentInfoDtlsList.dtls
                  .item(k).fromDate;
              retrieveCaseFinancialsKey.periodToDate = reassessmentInfoDtlsList.dtls
                  .item(k).toDate;

              final ReassessCaseDetailsList reassessCaseDetailsList = assessmentEngine
                  .retrieveCaseFinancials(retrieveCaseFinancialsKey);

              // END, CR00211744

              if (!reassessCaseDetailsList.dtls.isEmpty()) {

                final ReassessmentInfoDtls newReassessmentInfoDtls = new ReassessmentInfoDtls();

                newReassessmentInfoDtls
                    .assign(reassessmentInfoDtlsList.dtls.item(k));

                final long oldReassessmentInfoID = reassessmentInfoDtlsList.dtls
                    .item(k).reassessmentInfoID;

                newReassessmentInfoDtls.reassessmentInfoID = uniqueIDObj
                    .getNextID();

                newReassessmentInfoDtls.nomineeOverUnderPaymentID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

                reassessmentInfoObj.insert(newReassessmentInfoDtls);

                reassessmentAmountInformationKey.reassessmentInfoID = oldReassessmentInfoID;

                addReassessmentAmountInfoDtlsList = reassessmentAmountInfoObj
                    .searchByReassessInfoID(reassessmentAmountInformationKey);

                // BEGIN, 178020, CSH
                // Set the dates on the header struct to match the cover period
                // dates on the ReassmentInfo records as these
                // may differ after considering previous reassessments
                final NomineeOverUnderPaymentKey noupKey = new NomineeOverUnderPaymentKey();
                noupKey.nomineeOverUnderPaymentID = newReassessmentInfoDtls.nomineeOverUnderPaymentID;

                final NomineeOverUnderPaymentDtls nomOverUnderPaymentDtls = nomineeOverUnderPaymentObj
                    .read(noupKey);

                if (newReassessmentInfoDtls.toDate
                    .after(nomOverUnderPaymentDtls.coverPeriodTo)) {

                  nomOverUnderPaymentDtls.coverPeriodTo = newReassessmentInfoDtls.toDate;
                  nomineeOverUnderPaymentObj.modify(noupKey,
                      nomOverUnderPaymentDtls);
                  // if changing the value on the stored record, also change it
                  // on the details
                  // struct passed on through the processing

                  nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo = newReassessmentInfoDtls.toDate;

                }

                if (newReassessmentInfoDtls.fromDate
                    .before(nomOverUnderPaymentDtls.coverPeriodFrom)) {

                  nomOverUnderPaymentDtls.coverPeriodFrom = newReassessmentInfoDtls.fromDate;
                  nomineeOverUnderPaymentObj.modify(noupKey,
                      nomOverUnderPaymentDtls);

                  nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom = newReassessmentInfoDtls.fromDate;
                }
                // END, 178020

                for (int m = 0; m < addReassessmentAmountInfoDtlsList.dtls
                    .size(); m++) {

                  if (addReassessmentAmountInfoDtlsList.dtls
                      .item(m).reassessedAmount.isPositive()) {

                    addReassessmentAmountInfoDtlsList.dtls.item(
                        m).actualAmount = addReassessmentAmountInfoDtlsList.dtls
                            .item(m).reassessedAmount;

                    addReassessmentAmountInfoDtlsList.dtls
                        .item(m).reassessedAmount = zeroAmount;
                  } else {

                    addReassessmentAmountInfoDtlsList.dtls
                        .item(m).actualAmount = zeroAmount;
                  }

                  // This will mean no records with 0.00 reassessed and actual
                  // amounts are stored, and therefore never returned to client.
                  if (!addReassessmentAmountInfoDtlsList.dtls
                      .item(m).reassessedAmount.isPositive()
                      && (!addReassessmentAmountInfoDtlsList.dtls
                          .item(m).actualAmount.isPositive()
                          || !addReassessmentAmountInfoDtlsList.dtls
                              .item(m).receivedAmount.isPositive())) {

                    addReassessmentAmountInfoDtlsList.dtls.item(
                        m).reassessmentAmountInfoID = uniqueIDObj.getNextID();

                    addReassessmentAmountInfoDtlsList.dtls.item(
                        m).reassessmentInfoID = newReassessmentInfoDtls.reassessmentInfoID;

                    reassessmentAmountInfoObj
                        .insert(addReassessmentAmountInfoDtlsList.dtls.item(m));
                  }
                } // end for m

                // BEGIN, CR00021345, TV
                // Update currentFrom date
                currentFromDate = reassessmentInfoDtlsList.dtls.item(k).toDate;
                // END, CR00021345
              }
              // END, CR00159904
            }
          } // end for k
        }

        previousToDate = nomineeReassessmentHeader.reassessmentDetailsList
            .item(j).reassessmentInfoDtls.toDate;
      }

    }

    if (!thisIsTheFirstReassessment) {

      for (int n = 0; n < reassessmentInfoDtlsList.dtls.size(); n++) {

        // BEGIN, CR00479278, JD
        // Check for each period of the previous reassessment
        // if there is an overlapping one in the current reassessment
        final boolean prevPeriodAlreadyIncluded = checkPreviousPeriodExistsInCurrentReassessment(
            nomineeReassessmentHeader, reassessmentInfoDtlsList.dtls.item(n));

        // BEGIN, CR00142853, CR00180474, KH, VM
        if (reassessmentInfoDtlsList.dtls.item(n).toDate.before(earliestDate)
            && stmtOverlapsWithAssessPeriod || !prevPeriodAlreadyIncluded) {
          // END, CR00142853, CR00180474

          final ReassessmentInfoDtls newReassessmentInfoDtls = new ReassessmentInfoDtls();

          newReassessmentInfoDtls.assign(reassessmentInfoDtlsList.dtls.item(n));

          long oldReassessmentInfoID;

          oldReassessmentInfoID = reassessmentInfoDtlsList.dtls
              .item(n).reassessmentInfoID;

          newReassessmentInfoDtls.reassessmentInfoID = uniqueIDObj.getNextID();

          newReassessmentInfoDtls.nomineeOverUnderPaymentID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

          reassessmentInfoObj.insert(newReassessmentInfoDtls);

          reassessmentAmountInformationKey.reassessmentInfoID = oldReassessmentInfoID;

          addReassessmentAmountInfoDtlsList = reassessmentAmountInfoObj
              .searchByReassessInfoID(reassessmentAmountInformationKey);

          // BEGIN, 178020, CSH
          // Set the dates on the header struct to match the cover period
          // dates on the ReassmentInfo records as these
          // may differ after considering previous reassessments
          final NomineeOverUnderPaymentKey noupKey = new NomineeOverUnderPaymentKey();
          noupKey.nomineeOverUnderPaymentID = newReassessmentInfoDtls.nomineeOverUnderPaymentID;

          final NomineeOverUnderPaymentDtls nomOverUnderPaymentDtls = nomineeOverUnderPaymentObj
              .read(noupKey);

          if (newReassessmentInfoDtls.toDate
              .after(nomOverUnderPaymentDtls.coverPeriodTo)) {

            nomOverUnderPaymentDtls.coverPeriodTo = newReassessmentInfoDtls.toDate;
            nomineeOverUnderPaymentObj.modify(noupKey, nomOverUnderPaymentDtls);

            // if changing the value on the stored record, also change it on the
            // details
            // struct passed on through the remaining processing
            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo = newReassessmentInfoDtls.toDate;
          }

          if (newReassessmentInfoDtls.fromDate
              .before(nomOverUnderPaymentDtls.coverPeriodFrom)) {

            nomOverUnderPaymentDtls.coverPeriodFrom = newReassessmentInfoDtls.fromDate;
            nomineeOverUnderPaymentObj.modify(noupKey, nomOverUnderPaymentDtls);

            nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom = newReassessmentInfoDtls.fromDate;
          }
          // END, 178020

          for (int m = 0; m < addReassessmentAmountInfoDtlsList.dtls
              .size(); m++) {

            if (addReassessmentAmountInfoDtlsList.dtls.item(m).reassessedAmount
                .isPositive()) {

              addReassessmentAmountInfoDtlsList.dtls
                  .item(m).actualAmount = addReassessmentAmountInfoDtlsList.dtls
                      .item(m).reassessedAmount;
              addReassessmentAmountInfoDtlsList.dtls
                  .item(m).reassessedAmount = zeroAmount;

            } else {

              addReassessmentAmountInfoDtlsList.dtls
                  .item(m).actualAmount = zeroAmount;
            }

            // this will mean no records with 0.00 reassessed and actual amounts
            // are stored, and therefore never returned to client.
            if (!addReassessmentAmountInfoDtlsList.dtls.item(m).reassessedAmount
                .isPositive()
                && (!addReassessmentAmountInfoDtlsList.dtls.item(m).actualAmount
                    .isPositive()
                    || !addReassessmentAmountInfoDtlsList.dtls
                        .item(m).receivedAmount.isPositive())) {

              addReassessmentAmountInfoDtlsList.dtls
                  .item(m).reassessmentAmountInfoID = uniqueIDObj.getNextID();

              addReassessmentAmountInfoDtlsList.dtls.item(
                  m).reassessmentInfoID = newReassessmentInfoDtls.reassessmentInfoID;

              reassessmentAmountInfoObj
                  .insert(addReassessmentAmountInfoDtlsList.dtls.item(m));
            }
          } // end for m
        } // END, CR00479278, JD
      } // end for n

      // BEGIN, CR00404711, CSH
      // Each ReassessmentInfo record needs to have an associated
      // ReassessmentDecisionInfo record. Check if these have already been
      // created and if not, add them now.
      ReassessmentInfoDtlsList currentList = new ReassessmentInfoDtlsList();
      final ReadmultiByNomineeOverUnderPaymentIDKey rbnoupKey = new ReadmultiByNomineeOverUnderPaymentIDKey();

      rbnoupKey.nomineeOverUnderPaymentID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;
      reassessmentInfoObj.searchByNomineeOverUnderPaymentID(rbnoupKey);

      ReassessmentDecisionInfoDtlsList previousList = new ReassessmentDecisionInfoDtlsList();
      final ReassessmentDecisionInfoReadmultiKey rdirKey = new ReassessmentDecisionInfoReadmultiKey();

      currentList = reassessmentInfoObj
          .searchByNomineeOverUnderPaymentID(rbnoupKey);
      for (int w = 0; w < currentList.dtls.size(); w++) {

        // As this is not the first reassessment, read the previous
        // ReassessmentDecisionInfo record to set the value of oldDecisionID
        rdirKey.reassessmentInfoID = currentList.dtls
            .item(w).reassessmentInfoID;
        previousList = reassessmentDecisionInfoObj
            .searchByReassessmentInfoID(rdirKey);

        if (previousList.dtls.size() == 0) {

          // Create the new reassessmentDecisionInfo record to back up the
          // reassessmentInfo record

          final ReassessmentDecisionInfoDtls rdiDtls = new ReassessmentDecisionInfoDtls();

          for (int x = 0; x < reassessmentInfoDtlsList.dtls.size(); x++) {

            if (currentList.dtls.item(w).fromDate
                .equals(reassessmentInfoDtlsList.dtls.item(x).fromDate)
                && currentList.dtls.item(w).toDate
                    .equals(reassessmentInfoDtlsList.dtls.item(x).toDate)) {

              rdiDtls.reassessmentInfoID = currentList.dtls
                  .item(w).reassessmentInfoID;
              rdiDtls.reassessmentDecisionInfoID = uniqueIDObj.getNextID();

              // Get the oldDecisionID from the reassessmentDecisionInfo
              // that matches the previous reassessmentInfo we are
              // currently iterating through
              ReassessmentDecisionInfoDtlsList tempReassessmentDecisionInfoList = new ReassessmentDecisionInfoDtlsList();
              final ReassessmentDecisionInfoReadmultiKey tempRdirKey = new ReassessmentDecisionInfoReadmultiKey();

              tempRdirKey.reassessmentInfoID = reassessmentInfoDtlsList.dtls
                  .item(x).reassessmentInfoID;
              tempReassessmentDecisionInfoList = reassessmentDecisionInfoObj
                  .searchByReassessmentInfoID(tempRdirKey);

              if (tempReassessmentDecisionInfoList.dtls.size() > 0) {

                rdiDtls.oldDecisionID = tempReassessmentDecisionInfoList.dtls
                    .item(0).reassessedDecisionID;
              } else {
                rdiDtls.oldDecisionID = 0;
              }

              // Get the reassessedDecisionID by finding the active
              // decision on the case that matches the dates for the
              // current (new) reassessmentInfo record
              final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory
                  .newInstance();
              final CaseIDStatusKey caseIDStatusKey = new CaseIDStatusKey();

              caseIDStatusKey.caseID = overUnderPaymentHeaderDtls.caseID;
              caseIDStatusKey.statusCode = curam.codetable.CASEDECISIONSTATUS.CURRENT;

              final CaseDecisionKeyList caseDecisionKeyList = caseDecisionObj
                  .searchByCaseIDStatus(caseIDStatusKey);

              for (int y = 0; y < caseDecisionKeyList.dtls.size(); y++) {

                CaseDecisionDtls caseDecisionDtls = new CaseDecisionDtls();
                final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();

                caseDecisionKey.caseDecisionID = caseDecisionKeyList.dtls
                    .item(y).caseDecisionID;
                caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

                final DateRange decisionPeriod = new DateRange(
                    caseDecisionDtls.decisionFromDate,
                    caseDecisionDtls.decisionToDate);
                final DateRange reassessmentPeriod = new DateRange(
                    currentList.dtls.item(w).fromDate,
                    currentList.dtls.item(w).toDate);

                if (decisionPeriod.contains(reassessmentPeriod)) {

                  rdiDtls.reassessedDecisionID = caseDecisionKey.caseDecisionID;
                  break;
                }

              } // end for y
              reassessmentDecisionInfoObj.insert(rdiDtls);
            }
          } // end for x
        }
      } // end for w
      // END, CR00404711
    }
    // BEGIN, 178020, CSH
    // Setting indicator for use in later calculations
    totalActualAmountZero = false;
    // END, 178020
  }

  // BEGIN, CR00479278, JD
  // ___________________________________________________________________________
  /**
   * This method takes in the full details of the current reassessment and a
   * single period from the previous reassessment and checks if that single
   * period is contained within the current reassessment. A boolean is returned
   * indicating if the period has been found or not. If a value of false is
   * returned, the calling method will proceed to recreate the period in the
   * current reassessment with the appropriate amount values.
   *
   * @param nomineeReassessmentHeader
   *          the current reassessment
   * @param prevReassessmentInfoDtls
   *          A period from the previous reassessment
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected boolean checkPreviousPeriodExistsInCurrentReassessment(
      final NomineeReassessmentHeader nomineeReassessmentHeader,
      final ReassessmentInfoDtls prevReassessmentInfoDtls) {

    boolean foundPeriodMatch = false;

    final DateRange prevReassessmentInfoDateRange = new DateRange(
        prevReassessmentInfoDtls.fromDate, prevReassessmentInfoDtls.toDate);

    // Check if the previous period supplied is already in the
    // reassessmentInfoDtlsList for the current reassessment
    for (int p = 0; p < nomineeReassessmentHeader.reassessmentDetailsList
        .size(); p++) {

      final DateRange currReassessmentDateRange = new DateRange(
          nomineeReassessmentHeader.reassessmentDetailsList
              .item(p).reassessmentInfoDtls.fromDate,
          nomineeReassessmentHeader.reassessmentDetailsList
              .item(p).reassessmentInfoDtls.toDate);

      if (prevReassessmentInfoDateRange
          .overlapsWith(currReassessmentDateRange)) {
        foundPeriodMatch = true;
        break; // break from for p
      }
    }

    // If the period has not already been included in the current
    // reassessment, check if it falls within the over all date
    // range before proceeding with recreating it.
    if (!foundPeriodMatch) {

      final DateRange currReassessmentOverallDateRange = new DateRange(
          nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom,
          nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo);

      if (!currReassessmentOverallDateRange
          .contains(prevReassessmentInfoDateRange)) {

        // Setting to true as we don't need to recreate this period
        foundPeriodMatch = true;
      }
    }

    return foundPeriodMatch;
  }

  // END, CR00479278, JD

  // ___________________________________________________________________________
  /**
   * This method calls the under/over payment creation processing.
   *
   * @param nomineeReassessmentHeader
   *          Details of whom the over or under payment is to be made to.
   * @param beneficiaryDetails
   *          Details of the beneficiary.
   * @param reassessmentMode
   *          Indicates 'normal' or 'reconciliation' mode.
   * @param overUnderPaymentHeaderDtls
   *          Details of over or under payments.
   * @param objectiveTotalDetailsList
   *          Contains a breakdown of amounts.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void createUnderOverPayment(
      final NomineeReassessmentHeader nomineeReassessmentHeader,
      final BeneficiaryDetails beneficiaryDetails,
      final ReassessmentMode reassessmentMode,
      final OverUnderPaymentHeaderDtls overUnderPaymentHeaderDtls,
      final ObjectiveTotalDetailsList objectiveTotalDetailsList)
      throws AppException, InformationalException {

    // ReassessmentBalanceInfo manipulation variables.
    final curam.core.intf.ReassessmentBalanceInfo reassessmentBalanceInfoObj = curam.core.fact.ReassessmentBalanceInfoFactory
        .newInstance();
    ReassessmentBalanceInfoDtls reassessmentBalanceInfoDtls = new ReassessmentBalanceInfoDtls();
    final ReassessmentBalanceInfoDtls newReassessmentBalanceInfoDtls = new ReassessmentBalanceInfoDtls();
    final ReadmultiBalanceKey readmultiBalanceKey = new ReadmultiBalanceKey();
    ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList;
    final PreviousReassessmentKey previousReassessmentKey = new PreviousReassessmentKey();

    // indicates whether there has been a reassessment prior to this one.
    boolean previousReassessment = true;

    // indicates that there is another more recent reassessment.
    boolean nextReassessment = true;

    int i = 0;

    // uniqueID object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory
        .newInstance();

    // processOverUnderPayments manipulation variables
    final curam.core.intf.ProcessOverUnderPayments processOverUnderPaymentsObj = curam.core.fact.ProcessOverUnderPaymentsFactory
        .newInstance();
    final ProcessOverUnderPaymentInput processOverUnderPaymentInput = new ProcessOverUnderPaymentInput();

    processOverUnderPaymentInput.caseID = overUnderPaymentHeaderDtls.caseID;
    processOverUnderPaymentInput.amount = nomineeReassessmentHeader.reassessmentSummaryDetails.totalAmount;
    processOverUnderPaymentInput.reassessmentResultType = nomineeReassessmentHeader.reassessmentSummaryDetails.reassessmentResultType;

    // handle the over/under payment
    processOverUnderPaymentsObj.process(processOverUnderPaymentInput,
        nomineeReassessmentHeader, beneficiaryDetails, reassessmentMode,
        overUnderPaymentHeaderDtls, objectiveTotalDetailsList);

    readmultiBalanceKey.caseNomineeID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID;

    reassessmentBalanceInfoDtlsList = reassessmentBalanceInfoObj
        .searchReassessmentsForNominee(readmultiBalanceKey);

    // BEGIN, CR00003380, SD
    if (beneficiaryDetails.invalidatedPmtExistsInd
        && !beneficiaryDetails.relatedCaseExistsInd) {

      newReassessmentBalanceInfoDtls.replacementPmtInd = true;
    }
    // END, CR00003380

    if (!reassessmentBalanceInfoDtlsList.dtls.isEmpty()) {

      for (i = 0; i < reassessmentBalanceInfoDtlsList.dtls.size(); i++) {

        if (reassessmentBalanceInfoDtlsList.dtls
            .item(i).prevBalanceInfoID == 0) {
          break;
        }
      }

    } else {

      previousReassessment = false;

      newReassessmentBalanceInfoDtls.reassessmentBalanceInfoID = uniqueIDObj
          .getNextID();
      newReassessmentBalanceInfoDtls.reassessedBalance = nomineeReassessmentHeader.reassessmentSummaryDetails.totalActualAmount;
      newReassessmentBalanceInfoDtls.reassessmentDate = overUnderPaymentHeaderDtls.reassessmentDate;
      newReassessmentBalanceInfoDtls.amountType = nomineeReassessmentHeader.reassessmentSummaryDetails.reassessmentResultType;
      newReassessmentBalanceInfoDtls.reassessmentAmount = nomineeReassessmentHeader.reassessmentSummaryDetails.totalAmount;
      newReassessmentBalanceInfoDtls.caseNomineeID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID;
      newReassessmentBalanceInfoDtls.coverPeriodFrom = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom;
      newReassessmentBalanceInfoDtls.coverPeriodTo = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo;

      // BEGIN, 178020, CSH
      // Set the dates on the ReassessmentBalanceInfo to match the cover
      // period dates on the ReassmentInfo records as these
      // may differ after considering previous reassessments

      // Retrieve the final breakdown
      final ReadmultiByNomineeOverUnderPaymentIDKey rmKey = new ReadmultiByNomineeOverUnderPaymentIDKey();
      rmKey.nomineeOverUnderPaymentID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

      final ReassessmentInfoDtlsList infoDtlsList = ReassessmentInfoFactory
          .newInstance().searchByNomineeOverUnderPaymentID(rmKey);

      // Get the latest to date from the reassessmentInfo list
      final Date reassessmentInfoToDate = infoDtlsList.dtls
          .item(infoDtlsList.dtls.size() - 1).toDate;

      if (reassessmentInfoToDate
          .after(newReassessmentBalanceInfoDtls.coverPeriodTo)) {
        newReassessmentBalanceInfoDtls.coverPeriodTo = reassessmentInfoToDate;
      }
      // END, 178020

      reassessmentBalanceInfoObj.insert(newReassessmentBalanceInfoDtls);
    }

    if (previousReassessment && reassessmentBalanceInfoDtlsList.dtls
        .item(i).prevBalanceInfoID == 0) {

      previousReassessmentKey.prevBalanceInfoID = reassessmentBalanceInfoDtlsList.dtls
          .item(i).reassessmentBalanceInfoID;

      try {
        reassessmentBalanceInfoDtls = reassessmentBalanceInfoObj
            .readReassessmentByPreviousID(previousReassessmentKey);

      } catch (final RecordNotFoundException e) {

        nextReassessment = false;
      }

      while (nextReassessment) {

        previousReassessmentKey.prevBalanceInfoID = reassessmentBalanceInfoDtls.reassessmentBalanceInfoID;

        try {
          reassessmentBalanceInfoDtls = reassessmentBalanceInfoObj
              .readReassessmentByPreviousID(previousReassessmentKey);

        } catch (final RecordNotFoundException e) {

          nextReassessment = false;
        }
      }

      if (!nextReassessment) {

        newReassessmentBalanceInfoDtls.reassessmentBalanceInfoID = uniqueIDObj
            .getNextID();
        newReassessmentBalanceInfoDtls.coverPeriodFrom = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodFrom;
        newReassessmentBalanceInfoDtls.coverPeriodTo = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.coverPeriodTo;
        newReassessmentBalanceInfoDtls.reassessmentAmount = nomineeReassessmentHeader.reassessmentSummaryDetails.totalAmount;
        newReassessmentBalanceInfoDtls.reassessmentDate = overUnderPaymentHeaderDtls.reassessmentDate;
        newReassessmentBalanceInfoDtls.amountType = nomineeReassessmentHeader.reassessmentSummaryDetails.reassessmentResultType;
        newReassessmentBalanceInfoDtls.prevBalanceInfoID = previousReassessmentKey.prevBalanceInfoID;
        newReassessmentBalanceInfoDtls.reassessedBalance = nomineeReassessmentHeader.reassessmentSummaryDetails.totalActualAmount;

        newReassessmentBalanceInfoDtls.caseNomineeID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.caseNomineeID;

        // BEGIN, 178020, CSH
        // Retrieve the final breakdown
        final ReadmultiByNomineeOverUnderPaymentIDKey rmKey = new ReadmultiByNomineeOverUnderPaymentIDKey();
        rmKey.nomineeOverUnderPaymentID = nomineeReassessmentHeader.nomineeOverUnderPaymentDtls.nomineeOverUnderPaymentID;

        final ReassessmentInfoDtlsList infoDtlsList = ReassessmentInfoFactory
            .newInstance().searchByNomineeOverUnderPaymentID(rmKey);

        // Get the latest to date from the reassessmentInfo list and update
        // the to date on the reassessment balance info record to match it
        final Date reassessmentInfoToDate = infoDtlsList.dtls
            .item(infoDtlsList.dtls.size() - 1).toDate;

        if (reassessmentInfoToDate
            .after(newReassessmentBalanceInfoDtls.coverPeriodTo)) {
          newReassessmentBalanceInfoDtls.coverPeriodTo = reassessmentInfoToDate;
        }
        // END, 178020
      }

      reassessmentBalanceInfoObj.insert(newReassessmentBalanceInfoDtls);
    }
    // BEGIN CR00052856
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    final PlannedItemModifyActualCostDetails plannedItemModifyActualCostDetails = new PlannedItemModifyActualCostDetails();
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemCaseLinkPlannedItemIDKey plannedItemCaseLinkPlannedItemIDKey;
    final ProductDeliveryPlanItemLink productDeliveryPlanItemLinkEntityObj = ProductDeliveryPlanItemLinkFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    PlannedItemDtls planItemDtls = new PlannedItemDtls();

    caseHeaderKey.caseID = overUnderPaymentHeaderDtls.caseID;
    try {
      plannedItemCaseLinkPlannedItemIDKey = productDeliveryPlanItemLinkEntityObj
          .readPlannedItemIDByCaseID(caseHeaderKey);
    } catch (final RecordNotFoundException e) {
      plannedItemCaseLinkPlannedItemIDKey = null;
    }

    if (plannedItemCaseLinkPlannedItemIDKey != null) {

      plannedItemKey.plannedItemID = plannedItemCaseLinkPlannedItemIDKey.plannedItemID;
      planItemDtls = plannedItemObj.read(plannedItemKey);

      // BEGIN, CR00296014, KH
      if (newReassessmentBalanceInfoDtls.amountType
          .equals(REASSESSMENTRESULT.OVERPAYMENT)) {

        planItemDtls.actualCost = new Money(planItemDtls.actualCost.getValue()
            - nomineeReassessmentHeader.reassessmentSummaryDetails.totalAmount
                .getValue());

      } else if (newReassessmentBalanceInfoDtls.amountType
          .equals(REASSESSMENTRESULT.UNDERPAYMENT)) {

        planItemDtls.actualCost = new Money(planItemDtls.actualCost.getValue()
            + nomineeReassessmentHeader.reassessmentSummaryDetails.totalAmount
                .getValue());
      }
      // END, CR00296014

      plannedItemModifyActualCostDetails.actualCost = planItemDtls.actualCost;

      // set actual cost
      plannedItemObj.setActualCost(plannedItemKey,
          plannedItemModifyActualCostDetails);
    }
    // END CR00052856
  }

  // ___________________________________________________________________________
  /**
   * Method to apply utility payments to the reassessed details.
   *
   * @param productDeliveryFinCompDtls
   *          Financial Component details for Utility payment application.
   * @param nomineeReassessmentDetailsIn
   *          Nominee Reassessment information for the Financial Component.
   *
   * @return NomineeReassessmentDetails Nominee Reassessment information with
   *         Utility payment applied.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public NomineeReassessmentDetails applyUtilityPayments(
      final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
      final NomineeReassessmentDetails nomineeReassessmentDetailsIn)
      throws AppException, InformationalException {

    // nomineeReassessmentDetails variable
    final NomineeReassessmentDetails nomineeReassessmentDetailsOut = new NomineeReassessmentDetails();

    // HouseholdBudgetItem manipulation variables
    final GetHouseholdBugetItemsByComponentKey getHouseholdBugetItemsByComponentKey = new GetHouseholdBugetItemsByComponentKey();
    HouseholdBudgetItemDtlsList householdBudgetItemDtlsList;
    HouseholdBudgetItemDtlsList combinedHouseholdBudgetItemDtlsList;
    final HouseholdBudgetItem householdBudgetItemObj = HouseholdBudgetItemFactory
        .newInstance();

    Money tmpAmount = Money.kZeroMoney;

    // indicates that a ReassessmentAmountInfoDtls structure exists for the
    // nominee
    boolean reassessmentAmountInfoFound = false;

    // apply utility payments if required
    getHouseholdBugetItemsByComponentKey.effectiveDate = nomineeReassessmentDetailsIn.reassessmentInfoDtls.toDate;
    getHouseholdBugetItemsByComponentKey.statusCode = UTILITYPAYMENTSTATUS.ACTIVE;
    getHouseholdBugetItemsByComponentKey.rulesObjectiveID = productDeliveryFinCompDtls.rulesObjectiveID;
    getHouseholdBugetItemsByComponentKey.caseID = productDeliveryFinCompDtls.caseID;

    // Read HouseHoldBudgetItems
    combinedHouseholdBudgetItemDtlsList = householdBudgetItemObj
        .searchItemsForComponents(getHouseholdBugetItemsByComponentKey);

    getHouseholdBugetItemsByComponentKey.statusCode = UTILITYPAYMENTSTATUS.PENDINGRELEASE;

    householdBudgetItemDtlsList = householdBudgetItemObj
        .searchItemsForComponents(getHouseholdBugetItemsByComponentKey);

    // push onto combined list
    for (int i = 0; i < householdBudgetItemDtlsList.dtls.size(); i++) {

      combinedHouseholdBudgetItemDtlsList.dtls
          .addRef(householdBudgetItemDtlsList.dtls.item(i));
    }

    // Iterate through the combined list
    for (int j = 0; j < combinedHouseholdBudgetItemDtlsList.dtls.size(); j++) {

      int k;

      // Only need to act if the utility payment applies for any part of the FC
      if ((!combinedHouseholdBudgetItemDtlsList.dtls.item(j).endDate
          .before(productDeliveryFinCompDtls.startDate)
          || combinedHouseholdBudgetItemDtlsList.dtls.item(j).endDate.isZero())
          && !combinedHouseholdBudgetItemDtlsList.dtls.item(j).startDate
              .after(productDeliveryFinCompDtls.endDate)
          && (!combinedHouseholdBudgetItemDtlsList.dtls.item(j).endDate.before(
              nomineeReassessmentDetailsIn.reassessmentInfoDtls.fromDate)
              || combinedHouseholdBudgetItemDtlsList.dtls.item(j).endDate
                  .isZero())) {

        // Is there an amountInfo record for this type
        reassessmentAmountInfoFound = false;

        for (k = 0; k < nomineeReassessmentDetailsIn.amountDetailsList
            .size(); k++) {

          if (nomineeReassessmentDetailsIn.amountDetailsList.item(k).amountType
              .equals(REASSESSMENT_AMOUNT.UTILITY)) {

            reassessmentAmountInfoFound = true;
            break;
          }
        }

        // if not found, add new record
        if (!reassessmentAmountInfoFound) {

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.amountType = REASSESSMENT_AMOUNT.UTILITY;

          // add to the list
          nomineeReassessmentDetailsIn.amountDetailsList
              .addRef(reassessmentAmountInfoDetails);

          // Set iterator to point to new record
          k = nomineeReassessmentDetailsIn.amountDetailsList.size() - 1;
        }

        // Calculate FC Amount
        if (combinedHouseholdBudgetItemDtlsList.dtls.item(j).deductionType
            .equals(UTILITYDEDUCTIONTYPE.FIXED)) {

          tmpAmount = combinedHouseholdBudgetItemDtlsList.dtls.item(j).amount;

        } else {

          tmpAmount = new Money(
              combinedHouseholdBudgetItemDtlsList.dtls.item(j).rate
                  * productDeliveryFinCompDtls.amount.getValue() / kOneHundred);

          if (tmpAmount.getValue() < combinedHouseholdBudgetItemDtlsList.dtls
              .item(j).minimumAmount.getValue()) {

            tmpAmount = combinedHouseholdBudgetItemDtlsList.dtls
                .item(j).minimumAmount;
          }

          if (tmpAmount.getValue() > combinedHouseholdBudgetItemDtlsList.dtls
              .item(j).maximumAmount.getValue()) {

            tmpAmount = combinedHouseholdBudgetItemDtlsList.dtls
                .item(j).maximumAmount;
          }
        }

        nomineeReassessmentDetailsIn.amountDetailsList
            .item(k).reassessedAmount = new Money(
                nomineeReassessmentDetailsIn.amountDetailsList
                    .item(k).reassessedAmount.getValue()
                    + tmpAmount.getValue());
      }
    }

    nomineeReassessmentDetailsOut.assign(nomineeReassessmentDetailsIn);

    return nomineeReassessmentDetailsOut;
  }

  // ___________________________________________________________________________
  /**
   * Method to apply deduction payments to the reassessed details.
   *
   * @param productDeliveryFinCompDtls
   *          Financial Component details for deduction payment application.
   * @param nomineeReassessmentDetailsIn
   *          Nominee Reassessment information for the Financial Component.
   *
   * @return NomineeReassessmentDetails Nominee Reassessment information with
   *         deduction payment applied.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public NomineeReassessmentDetails applyDeductionPayments(
      final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
      final NomineeReassessmentDetails nomineeReassessmentDetailsIn)
      throws AppException, InformationalException {

    // nomineeReassessmentDetails variable
    final NomineeReassessmentDetails nomineeReassessmentDetailsOut = new NomineeReassessmentDetails();

    Money tmpAmount = Money.kZeroMoney;

    // indicates that a ReassessmentAmountInfoDtls structure exists for the
    // nominee
    boolean reassessmentAmountInfoFound = false;

    // caseDeductionItem manipulation variable
    final CaseDeductionItem caseDeductionItemObj = CaseDeductionItemFactory
        .newInstance();
    final GetDeductionItemByComponentKey getDeductionItemByComponentKey = new GetDeductionItemByComponentKey();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    getDeductionItemByComponentKey.effectiveDate = nomineeReassessmentDetailsIn.reassessmentInfoDtls.toDate;
    getDeductionItemByComponentKey.statusCode = RECORDSTATUS.DEFAULTCODE;
    getDeductionItemByComponentKey.caseID = productDeliveryFinCompDtls.caseID;
    getDeductionItemByComponentKey.rulesObjectiveID = productDeliveryFinCompDtls.rulesObjectiveID;

    // read caseDeductionItem
    caseDeductionItemDtlsList = caseDeductionItemObj
        .searchItemsForComponents(getDeductionItemByComponentKey);

    // Iterate through the list
    for (int j = 0; j < caseDeductionItemDtlsList.dtls.size(); j++) {

      int k;

      // Only need to act if the deduction payment is for any part of the FC
      if ((!caseDeductionItemDtlsList.dtls.item(j).endDate
          .before(productDeliveryFinCompDtls.startDate)
          || caseDeductionItemDtlsList.dtls.item(j).endDate.isZero())
          && !caseDeductionItemDtlsList.dtls.item(j).startDate
              .after(productDeliveryFinCompDtls.endDate)
          && (!caseDeductionItemDtlsList.dtls.item(j).endDate.before(
              nomineeReassessmentDetailsIn.reassessmentInfoDtls.fromDate)
              || caseDeductionItemDtlsList.dtls.item(j).endDate.isZero())) {

        // Is there an amountInfo record for this type
        reassessmentAmountInfoFound = false;

        for (k = 0; k < nomineeReassessmentDetailsIn.amountDetailsList
            .size(); k++) {

          if (nomineeReassessmentDetailsIn.amountDetailsList.item(k).amountType
              .equals(REASSESSMENT_AMOUNT.DEDUCTION)) {

            reassessmentAmountInfoFound = true;
            break;
          }
        }

        // if not found, add new record
        if (!reassessmentAmountInfoFound) {

          final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails = new ReassessmentAmountInfoDetails();

          reassessmentAmountInfoDetails.amountType = REASSESSMENT_AMOUNT.DEDUCTION;

          // add to the list
          nomineeReassessmentDetailsIn.amountDetailsList
              .addRef(reassessmentAmountInfoDetails);

          // Set iterator to point to new record
          k = nomineeReassessmentDetailsIn.amountDetailsList.size() - 1;
        }

        // Calculate FC Amount
        if (caseDeductionItemDtlsList.dtls.item(j).deductionType
            .equals(DEDUCTIONITEMTYPE.DEFAULTCODE)) {

          tmpAmount = caseDeductionItemDtlsList.dtls.item(j).amount;

        } else {

          tmpAmount = new Money(caseDeductionItemDtlsList.dtls.item(j).rate
              * productDeliveryFinCompDtls.amount.getValue() / kOneHundred);
        }

        nomineeReassessmentDetailsIn.amountDetailsList
            .item(k).reassessedAmount = new Money(
                nomineeReassessmentDetailsIn.amountDetailsList
                    .item(k).reassessedAmount.getValue()
                    + tmpAmount.getValue());
      }
    }

    nomineeReassessmentDetailsOut.assign(nomineeReassessmentDetailsIn);

    return nomineeReassessmentDetailsOut;
  }

  // ___________________________________________________________________________
  /**
   * Updates complete case decision data for a case decision, includes case
   * decision evidence, case decision objective, and case decision objective tag
   * information.
   *
   * @param determineEligibilityKey
   *          Period over which eligibility will be reassessed.
   * @param completeDecisionCreation
   *          struct holding all case decision data.
   *
   * @return struct holding all case decision data.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public CompleteDecisionCreation updateCompleteCaseDecisionData(
      final DetermineEligibilityKey determineEligibilityKey,
      final CompleteDecisionCreation completeDecisionCreation)
      throws AppException, InformationalException {

    // BEGIN, CR00211744, VM
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();

    caseDecisionKey.caseDecisionID = completeDecisionCreation.details.caseDecisionID;

    final CaseDecisionObjectiveDtlsList caseDecisionObjectiveDtlsList = assessmentEngineEntity
        .getObjectivesByCaseDecisionID(caseDecisionKey);

    // END, CR00211744

    completeDecisionCreation.dtlsList.clear();

    // reserve space in completeDecisionCreation struct
    completeDecisionCreation.dtlsList
        .ensureCapacity(caseDecisionObjectiveDtlsList.dtls.size());

    for (int j = 0; j < caseDecisionObjectiveDtlsList.dtls.size(); j++) {
      completeDecisionCreation.dtlsList
          .addRef(caseDecisionObjectiveDtlsList.dtls.item(j));
    }

    // BEGIN, CR00211744, VM
    final CaseDecisionObjectiveTagDtlsList caseDecisionObjectiveTagDtlsList = assessmentEngineEntity
        .getObjectiveTagsByCaseDecisionID(caseDecisionKey);

    // END, CR00211744

    for (int j = 0; j < caseDecisionObjectiveTagDtlsList.dtls.size(); j++) {
      completeDecisionCreation.tagList
          .addRef(caseDecisionObjectiveTagDtlsList.dtls.item(j));
    }

    return completeDecisionCreation;
  }

  // ___________________________________________________________________________
  /**
   * This method calculates the the earliest From Date and latest To Date for a
   * given Component Details List.
   *
   * @param componentDetailsList
   *          the Component Details List.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void calculateEarliestFromDateAndLatestToDate(
      final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    // BEGIN, CR00269418, KH
    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      if (componentDetailsList.dtls.item(i).fromDate
          .before(componentDetailsList.componentListSummary.earliestFromDate)
          || componentDetailsList.componentListSummary.earliestFromDate
              .isZero()) {

        componentDetailsList.componentListSummary.earliestFromDate = componentDetailsList.dtls
            .item(i).fromDate;
      }

      if (componentDetailsList.dtls.item(i).toDate
          .after(componentDetailsList.componentListSummary.latestToDate)
          || componentDetailsList.componentListSummary.latestToDate.isZero()) {

        componentDetailsList.componentListSummary.latestToDate = componentDetailsList.dtls
            .item(i).toDate;
      }
    } // end for i

    // If we haven't found a 'toDate' we can use the last paid date
    if (componentDetailsList.componentListSummary.latestToDate.isZero()) {
      for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

        if (componentDetailsList.dtls.item(i).lastPaidToDate
            .after(componentDetailsList.componentListSummary.latestToDate)) {

          componentDetailsList.componentListSummary.latestToDate = componentDetailsList.dtls
              .item(i).lastPaidToDate;
        }
      }
    }
    // END, CR00269418
  }

  // ___________________________________________________________________________
  /**
   * This method sends a notification.
   *
   * @param details
   *          Notification details.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void sendNotification(final ReassessmentNotificationDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00074750, CM
    // check the environment variable
    String genCaseStatusSuspended = Configuration
        .getProperty(EnvVars.ENV_GENCASESTATUSSUSPENDEDTICKET);

    // BEGIN, CR00227215, GSP
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    final OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();
    OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final Users userObj = UsersFactory.newInstance();
    final UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale;

    // END, CR00227215

    if (genCaseStatusSuspended == null) {

      genCaseStatusSuspended = EnvVars.ENV_GENCASESTATUSSUSPENDEDTICKET_DEFAULT;
    }

    if (genCaseStatusSuspended.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }
    // END, CR00074750

    // Set key to read CaseHeader entity
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    // Read CaseHeader
    final CaseOwnerAndCaseRefDetails caseOwnerAndCaseRefDetails = CaseHeaderFactory
        .newInstance().readCaseOwnerAndCaseRef(caseHeaderKey);

    final AppException e = new AppException(
        BPOCASEREASSESSMENT.INF_CASE_STATUS_SUSPENDED_REASON);

    e.arg(caseOwnerAndCaseRefDetails.caseReference);

    final AppException ex = new AppException(
        BPOCASEREASSESSMENT.INF_CASE_STATUS_SUSPENDED_SUBJECT);

    ex.arg(caseOwnerAndCaseRefDetails.caseReference);
    // BEGIN, CR00234114, AK
    caseHeaderKey.caseID = details.caseID;
    orgObjectLinkKey.orgObjectLinkID = caseHeaderObj
        .readCaseOwner(caseHeaderKey).ownerOrgObjectLinkID;
    orgObjectLinkDtls = orgObjectLinkObj.read(orgObjectLinkKey);
    userKey.userName = orgObjectLinkDtls.userName;
    usersDtls = userObj.read(nfIndicator, userKey);
    if (!nfIndicator.isNotFound()) {
      userLocale = usersDtls.defaultLocale;
    } else {
      userLocale = TransactionInfo.getProgramLocale();
    }
    // Retrieve product type
    final ProductDelivery productDeliveryObj = ProductDeliveryFactory
        .newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = details.caseID;

    final ProductDeliveryTypeDetails productDeliveryTypeDetails = productDeliveryObj
        .readProductType(productDeliveryKey);

    // Get Product description
    final String productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        productDeliveryTypeDetails.productType, userLocale);

    ex.arg(productTypeDesc);

    // Retrieve primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();

    caseHeaderKey.caseID = details.caseID;
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails = CaseHeaderFactory
        .newInstance().readParticipantRoleID(caseHeaderKey);

    concernRoleKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;

    // Read concernRole Name
    final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj
        .readConcernRoleName(concernRoleKey);

    ex.arg(concernRoleNameDetails.concernRoleName);

    final StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

    // BEGIN, CR00227215, GSP
    standardManualTaskDtls.dtls.taskDtls.subject = ex.getMessage(userLocale);
    standardManualTaskDtls.dtls.taskDtls.comments = e.getMessage(userLocale);
    // END, CR00227215
    // BEGIN, CR00023618, SK
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.notificationTaskDefinitionID;
    // END, CR00023618
    standardManualTaskDtls.dtls.concerningDtls.caseID = details.caseID;

    // BEGIN, CR00124834, SAI
    standardManualTaskDtls.dtls.concerningDtls.participantType = CONCERNROLETYPE.PERSON;
    standardManualTaskDtls.dtls.concerningDtls.participantRoleID = readParticipantRoleIDDetails.concernRoleID;
    // END, CR00124834
    NotificationFactory.newInstance()
        .sendCaseOwnerNotification(standardManualTaskDtls);
    // END, CR00069238
  }

  // BEGIN, 178020, CSH
  // ___________________________________________________________________________
  /**
   * This method orders the case reassessment details list by cover period from
   * date ascending.
   *
   * @param reassessCaseDetailsList
   *          List of case reassessment details which may be unordered.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  public void orderReassessCaseDetailsList(
      final ReassessCaseDetailsList reassessCaseDetailsList)
      throws AppException, InformationalException {

    // Struct to temporarily hold the sorted reassessment details - these are
    // sorted by coverPeriodFrom date using the comparator below
    final ReassessCaseDetailsList tempReassessCaseDetailsList = new ReassessCaseDetailsList();

    // Need to sort the entries in the reassessCaseDetailsList by
    // coverPeriodFrom
    // This is to overcome issues in the determination of the reassessment
    // dates whereby the dates were not sequential
    final Comparator<ReassessCaseDetails> reassessCaseDetailsComparator = new ReassessCaseDetailsComparator();
    final ArrayList<ReassessCaseDetails> list = new ArrayList<ReassessCaseDetails>(
        reassessCaseDetailsList.dtls);

    Collections.sort(list, reassessCaseDetailsComparator);

    for (int i = 0; i < list.size(); i++) {

      ReassessCaseDetails reassessCaseDetails;

      reassessCaseDetails = list.get(i);

      tempReassessCaseDetailsList.dtls.addRef(reassessCaseDetails);
    }

    // Clear input struct for re-use
    reassessCaseDetailsList.dtls.clear();

    for (int j = 0; j < tempReassessCaseDetailsList.dtls.size(); j++) {

      final ReassessCaseDetails reassessCaseDetails = new ReassessCaseDetails();

      reassessCaseDetails.assign(tempReassessCaseDetailsList.dtls.item(j));

      reassessCaseDetailsList.dtls.addRef(reassessCaseDetails);
    }
  }

  // END, 178020

  // ___________________________________________________________________________
  /**
   * This method orders the component details list by from date ascending.
   *
   * @param componentDetailsList
   *          List of component details which may be unordered.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void orderComponentList(
      final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    // Struct to temporarily hold the sorted component details - these are
    // sorted by fromDate using the comparator below
    final ComponentDetailsList tempComponentDetailsList = new ComponentDetailsList();

    // Need to sort the entries in the componentDetailsList by fromDate
    // This is to overcome issues in the determination of the reassessment
    // dates whereby the dates were not sequential
    final Comparator<ComponentDetails> compDetailsComparator = new ComponentDetailsComparator();
    final ArrayList<ComponentDetails> list = new ArrayList<ComponentDetails>(
        componentDetailsList.dtls);

    Collections.sort(list, compDetailsComparator);

    for (int i = 0; i < list.size(); i++) {

      ComponentDetails componentDetails;

      componentDetails = list.get(i);

      tempComponentDetailsList.dtls.addRef(componentDetails);
    }

    // Clear input struct for re-use
    componentDetailsList.dtls.clear();

    for (int j = 0; j < tempComponentDetailsList.dtls.size(); j++) {

      final ComponentDetails componentDetails = new ComponentDetails();

      componentDetails.assign(tempComponentDetailsList.dtls.item(j));

      componentDetailsList.dtls.addRef(componentDetails);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method calculates the earliest cover period from and latest cover
   * period to dates from the financials.
   *
   * @param reassessCaseDetailsList
   *          List of case financials.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void calculateBoundaryFinancialCoverPeriodDates(
      final ReassessCaseDetailsList reassessCaseDetailsList)
      throws AppException, InformationalException {

    // Initialize boundary dates
    minCoverPeriodFrom = Date.kZeroDate;
    maxCoverPeriodTo = Date.kZeroDate;

    // BEGIN, CR00142853, KH
    final InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

    for (int i = 0; i < reassessCaseDetailsList.dtls.size(); i++) {

      // We should only be considering financial details that arise out of
      // eligibility and entitlement calculations, i.e. ignore deduction ILIs,
      // tax ILIs etc.
      instructionLineItemKey.instructLineItemID = reassessCaseDetailsList.dtls
          .item(i).instructLineItemID;

      final InstructionLineItemDtls instructionLineItemDtls = InstructionLineItemFactory
          .newInstance().read(instructionLineItemKey);

      if (instructionLineItemDtls.instructLineItemCategory
          .equals(ILICATEGORY.PAYMENTINSTRUCTION)
          && instructionLineItemDtls.creditDebitType.equals(CREDITDEBIT.DEBIT)
          || instructionLineItemDtls.instructLineItemCategory
              .equals(ILICATEGORY.LIABILITYINSTRUCTION)
              && instructionLineItemDtls.creditDebitType
                  .equals(CREDITDEBIT.DEBIT)) {

        // calculate the min coverPeriodFrom date
        if (reassessCaseDetailsList.dtls.item(i).coverPeriodFrom
            .before(minCoverPeriodFrom) || minCoverPeriodFrom.isZero()) {

          minCoverPeriodFrom = reassessCaseDetailsList.dtls
              .item(i).coverPeriodFrom;
        }

        // calculate the max coverPeriodTo date
        if (reassessCaseDetailsList.dtls.item(i).coverPeriodTo
            .after(maxCoverPeriodTo) || maxCoverPeriodTo.isZero()) {

          maxCoverPeriodTo = reassessCaseDetailsList.dtls.item(i).coverPeriodTo;
        }
      }
    } // end for i
    // END, CR00142853
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the case nominee for the reassessment processing.
   *
   * @param componentDetailsList
   *          Component details list.
   * @param reassessCaseDetailsList
   *          List of case financial line items.
   *
   * @return Case nominee identifier.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public CaseNomineeIDDtls getCaseNominee(
      final ComponentDetailsList componentDetailsList,
      final ReassessCaseDetailsList reassessCaseDetailsList)
      throws AppException, InformationalException {

    final CaseNomineeIDDtls caseNomineeIDDtls = new CaseNomineeIDDtls();

    if (!componentDetailsList.dtls.isEmpty()) {

      caseNomineeIDDtls.caseNomineeID = componentDetailsList.dtls
          .item(0).caseNomineeID;

    } else {

      if (!reassessCaseDetailsList.dtls.isEmpty()) {

        caseNomineeIDDtls.caseNomineeID = reassessCaseDetailsList.dtls
            .item(0).caseNomineeID;
      }
    }

    return caseNomineeIDDtls;
  }

  // ___________________________________________________________________________
  /**
   * This method compiles the initial date list to be used in case reassessment.
   *
   * @param key
   *          Contains the case identifier, and initial reassessment from/to
   *          dates.
   * @param componentDetailsList
   *          List of (ordered) component details.
   *
   * @return List of dates to be used in case reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DateList compileInitialDateList(final OverUnderPaymentIn key,
      final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    // ProductDeliveryPatternInfo manipulation variables
    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = null;

    // CachedCaseHeader manipulation variables
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Date manipulation variables
    final DateValueList componentDateList = new DateValueList();
    Date tempDate = Date.kZeroDate;

    // BEGIN, CR00049218, GM
    String freq = CuramConst.gkEmpty;
    // END, CR00049218
    // Struct containing product delivery pattern ID
    final ProductDeliveryPatternKey tempProductDeliveryPatternKey = new ProductDeliveryPatternKey();

    // Variable to hold most recent toDate in list of components
    Date mostRecentToDate = Date.kZeroDate;

    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      final ComponentDetails currentComponentDetails = componentDetailsList.dtls
          .item(i);

      // BEGIN, CR00050838, MR
      final ProductDeliveryPatternFrequencyDetails productDeliveryPatternFrequencyDetails = new ProductDeliveryPatternFrequencyDetails();

      productDeliveryPatternFrequencyDetails.caseNomineeID = key.caseNomineeID;
      productDeliveryPatternFrequencyDetails.effectiveDate = componentDetailsList.dtls
          .item(i).fromDate;
      productDeliveryPatternFrequencyDetails.productDeliveryPatternID = componentDetailsList.dtls
          .item(i).productDeliveryPatternID;
      productDeliveryPatternInfoDtls = getFrequency(
          productDeliveryPatternFrequencyDetails);
      freq = productDeliveryPatternInfoDtls.deliveryFrequency;
      // END, CR00050838

      // BEGIN, CR00148989, KH
      final FrequencyPattern freqPattern = new FrequencyPattern(freq);

      // check to see if the componentDateList is empty
      if (componentDateList.isEmpty()) {

        // This is the first time through this list - we need to make sure we
        // get the payment date before the key.toDate as well as the first one
        // within the CaseNomineeProdDelPattern.startDate
        caseHeaderKey.caseID = key.caseID;

        // Read cachedCaseHeader
        tempDate = cachedCaseHeaderObj.read(caseHeaderKey).effectiveDate;

        if (tempDate.after(currentComponentDetails.fromDate)) {

          while (tempDate.after(currentComponentDetails.fromDate)) {
            tempDate = freqPattern.getPrevOccurrence(tempDate);
          }
        } else {
          // Notice if the tempDate is equal, that's fine. We step into neither
          // of the while loops and add it to our output list.
          while (tempDate.before(currentComponentDetails.fromDate)) {
            tempDate = freqPattern.getNextOccurrence(tempDate);
          }

          // When we finish this loop we are at the first payment date after the
          // CNPDP.startDate, we want the one before this however, unless the
          // first payment date is the CNPDP.startDate
          if (!tempDate.equals(currentComponentDetails.fromDate)) {
            tempDate = freqPattern.getPrevOccurrence(tempDate);
          }
        }

        // Now we need to make sure this date is not before the key.fromDate,
        // we do not want to reassess a period that we have no decision data
        // for.
        if (tempDate.before(key.fromDate)) {

          while (tempDate.before(key.fromDate)) {
            tempDate = freqPattern.getNextOccurrence(tempDate);
          }
        }

        // now we have reached the payment date after the key.fromDate, need to
        // add currentComponentDetails.fromDate to the list, provided
        // currentComponentDetails.fromDate is not a payment date itself
        if (!tempDate.equals(currentComponentDetails.fromDate)) {

          // BEGIN, CR00269418, KH
          /*
           * If the tempDate is before the current component from date, then the
           * current component from date does not fall on a payment date. Add
           * the payment date so it is available for the statements.
           */
          if (tempDate.before(currentComponentDetails.fromDate)) {
            componentDateList.addRef(tempDate);
          }
          // END, CR00269418

          componentDateList.addRef(currentComponentDetails.fromDate);
        }

        // at this stage we have established the first payment date we are going
        // to add to our output list.

        // BEGIN, CR00032821, MR
        // Check if the (case start date and certification start date are
        // different) and (delivery frequency pattern delivery day and case
        // start day are equal) then add the next delivery frequency pattern
        // date to our output list else add the tempDate to our output list.
        // BEGIN, CR00069996, SK
        final String deliverDay = freqPattern.getDayOfWeekMask().toString();
        int j;

        if (deliverDay
            .equals(FrequencyPattern.DayOfWeekMask.kSunday.toString())) {
          j = 1;
        } else if (deliverDay
            .equals(FrequencyPattern.DayOfWeekMask.kMonday.toString())) {
          j = 2;
        } else if (deliverDay
            .equals(FrequencyPattern.DayOfWeekMask.kTuesday.toString())) {
          j = 3;
        } else if (deliverDay
            .equals(FrequencyPattern.DayOfWeekMask.kWednesday.toString())) {
          j = 4;
        } else if (deliverDay
            .equals(FrequencyPattern.DayOfWeekMask.kThursday.toString())) {
          j = 5;
        } else if (deliverDay
            .equals(FrequencyPattern.DayOfWeekMask.kFriday.toString())) {
          j = 6;
        } else {
          j = 7;
        }

        final Calendar cal = Calendar.getInstance();

        cal.setTimeInMillis(key.fromDate.asLong());
        final int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);

        // BEGIN, CR00128018, ZV
        if (!tempDate.before(currentComponentDetails.fromDate)) {
          if (!key.fromDate.equals(currentComponentDetails.fromDate) // BEGIN,
              // CR00180474,
              // VM
              /*
               * Checking if this is the first element in the list as it's
               * possible to miss out the start of the week if it begins with a
               * partial cert on a day other than the delivery date
               */ && i != 0 // END, CR00180474, VM
              && j == dayOfWeek) {

            componentDateList.addRef(freqPattern.getNextOccurrence(tempDate));
          } else {
            componentDateList.addRef(tempDate);
          }
        }
        // END, CR00128018
        // END, CR00032821
        // END, CR00069996

      } else { // if this is not the first iteration through the loop

        // We need to start from the point that we left off, so get the next
        // occurrence of our delivery pattern from the last added date that
        // is equal to or after the current CNPDP.startDate

        if (!componentDateList.isEmpty()) {
          tempDate = componentDateList.item(componentDateList.size() - 1);

          while (tempDate.before(currentComponentDetails.fromDate)) {
            tempDate = freqPattern.getNextOccurrence(tempDate);

            // BEGIN, CR00269418, KH
            /*
             * Add the intermediary payment dates so that the statement can
             * split on the correct dates.
             */
            if (tempDate.before(currentComponentDetails.toDate)) {
              componentDateList.addRef(tempDate);
            }
            // END, CR00269418
          }

          // BEGIN, CR00299747, CW
          // Do not include the date for reassessment if it is after the last
          // paid to date of the case
          if (tempDate.after(currentComponentDetails.toDate)
              && !tempDate.after(currentComponentDetails.lastPaidToDate)) {
            // END, CR00299747

            // Check the frequency of the tempDate. If it differs from
            // frequencyPattern above, then don't add tempDate to the list,
            // otherwise do.
            // At this stage we have established the first payment date we will
            // add to our output list.
            // Perform a sanity check here to ensure the effective date and
            // the temp date have the same frequency pattern.
            final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

            // Set key to read CaseNomineeProdDelPattern
            readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
            readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
            readEffectiveByDateKey.effectiveDate = tempDate;

            // BEGIN, CR00211744, VM
            final CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = assessmentEngineEntity
                .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);

            // END, CR00211744

            // BEGIN, CR00050838, MR
            productDeliveryPatternFrequencyDetails.caseNomineeID = key.caseNomineeID;
            productDeliveryPatternFrequencyDetails.effectiveDate = tempDate;
            productDeliveryPatternFrequencyDetails.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;

            productDeliveryPatternInfoDtls = getFrequency(
                productDeliveryPatternFrequencyDetails);
            // END, CR00050838

            // if the delivery frequencies are the same for the two dates and
            // the temp date is prior to the toDate add the temp date
            if (productDeliveryPatternInfoDtls.deliveryFrequency.equals(freq)
                && tempDate.before(key.toDate)) {

              componentDateList.addRef(tempDate);
            }
            // BEGIN, CR00299747, CW
            // Do not include the date for reassessment if it is after the last
            // paid to date of the case
          } else if (!tempDate.after(currentComponentDetails.lastPaidToDate)) {
            // END, CR00299747
            componentDateList.addRef(tempDate);
          }
        }
      }

      // This is not the last CNPDP record. Get all payment dates between the
      // current tempDate and the current CNPDP.endDate
      tempDate = freqPattern.getNextOccurrence(tempDate);

      if (!tempDate.after(currentComponentDetails.toDate)) {
        while (!tempDate.after(currentComponentDetails.toDate)) {
          componentDateList.addRef(tempDate);
          tempDate = freqPattern.getNextOccurrence(tempDate);
        }
      }
      // END, CR00148989

      // BEGIN, CR00238678, KH
      /*
       * Need this check here despite the fact that the componentDetailsList is
       * ordered by from date ascending. Even though the list is ordered by from
       * date, it's not ordered by to date. We need to ensure the
       * mostRecentToDate variable does, in fact, get populated with the most
       * recent to date.
       */
      if (mostRecentToDate.isZero()
          || currentComponentDetails.toDate.after(mostRecentToDate)) {
        mostRecentToDate = currentComponentDetails.toDate;
      }
      // END, CR00238678

      // Assign current product delivery pattern ID
      tempProductDeliveryPatternKey.productDeliveryPatternID = currentComponentDetails.productDeliveryPatternID;
    } // end for i

    // Add mostRecentToDate to componentDateList
    if (!mostRecentToDate.isZero()) {
      componentDateList.addRef(mostRecentToDate);
    }

    // Create return object
    final DateList initialDateList = new DateList();

    // Copy dates to return object
    for (int j = 0; j < componentDateList.size(); j++) {

      final DateStruct newDate = new DateStruct();

      newDate.date = componentDateList.item(j);
      initialDateList.dtls.addRef(newDate);
    }

    return initialDateList;
  }

  // ___________________________________________________________________________
  /**
   * Processes the case financial cover period from dates. These may need to be
   * included in the date list used in case reassessment.
   *
   * @param key
   *          Contains the case identifier plus the initial reassessment from/to
   *          dates.
   * @param dateList
   *          Initial component date list.
   * @param reassessCaseDetailsList
   *          List of case financial items.
   * @param componentDetailsList
   *          list of component details.
   *
   * @return List of dates to be used in case reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DateList processFinancialDates(final OverUnderPaymentIn key,
      final DateList dateList,
      final ReassessCaseDetailsList reassessCaseDetailsList,
      final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    final DateValueList componentDateList = new DateValueList();
    final DateValueList financialDateList = new DateValueList();

    // Copy entries in dateList to arrayList for manipulation
    for (int i = 0; i < dateList.dtls.size(); i++) {

      componentDateList.addRef(dateList.dtls.item(i).date);
    }

    // BEGIN, CR00184177, KH
    // Read back list of component deduction types. This list contains the ILI
    // types which should not be considered during reassessment.
    final StringList componentDeductionTypeList = CodeTable
        .getDistinctCodesForAllLanguages(COMPONENTDEDUCTIONTYPE.TABLENAME);

    // END, CR00184177

    // Get the list of from dates for the financials here. We should always
    // do this step regardless of whether the componentDateList is populated
    // or not. It's possible to have a list of dates in the componentDateList
    // with certain gaps which can be accounted for by the financial data in
    // reassessCaseDetailsList.
    for (int j = 0; j < reassessCaseDetailsList.dtls.size(); j++) {

      // BEGIN, CR00184177, KH
      // Only use ILIs which are relevant
      if (!componentDeductionTypeList.contains(
          reassessCaseDetailsList.dtls.item(j).instructionLineItemType)) {

        if (!componentDateList.isEmpty()) {

          if (!componentDateList
              .contains(reassessCaseDetailsList.dtls.item(j).coverPeriodFrom)) {

            if (!financialDateList.contains(// ensure it does not exist already
                reassessCaseDetailsList.dtls.item(j).coverPeriodFrom)) {

              financialDateList
                  .addRef(reassessCaseDetailsList.dtls.item(j).coverPeriodFrom);
            }
          }
        } else {
          financialDateList
              .addRef(reassessCaseDetailsList.dtls.item(j).coverPeriodFrom);
        }
      }
      // END, CR00184177
    } // end for j

    // merge the lists
    for (int n = 0; n < financialDateList.size(); n++) {

      if (!componentDateList.contains(financialDateList.item(n))) {

        boolean newDateAdded = false;

        for (int p = 0; p < componentDateList.size(); p++) {

          if (componentDateList.item(p).after(financialDateList.item(n))) {

            componentDateList.add(p, financialDateList.item(n));
            newDateAdded = true;
            break;
          }
        }

        if (!newDateAdded) {
          componentDateList.addRef(financialDateList.item(n));
        }
      }
    }

    // Clear dateList.dtls for re-use
    dateList.dtls.clear();

    // Copy dates from arrayList to dateList structure
    for (int q = 0; q < componentDateList.size(); q++) {

      final DateStruct newDate = new DateStruct();

      newDate.date = componentDateList.item(q);
      dateList.dtls.addRef(newDate);
    }

    return fillInMissingPaymentDates(key, dateList, componentDetailsList);
  }

  // ___________________________________________________________________________
  /**
   * Need to consider the maxCoverPeriodTo date that was calculated from the
   * financials earlier in the processing.
   *
   * @param key
   *          Contains the case identifier plus the initial reassessment from/to
   *          dates
   * @param completeDateList
   *          Contains the list of reassessment dates compiled thus far.
   * @param componentDetailsList
   *          List of virtual financial components.
   *
   * @return DateList Final list of dates to be considered for reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DateList considerMaxCoverPeriodToDate(final OverUnderPaymentIn key,
      final DateList completeDateList,
      final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    // ProductDeliveryPatternInfo manipulation variables
    final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory
        .newInstance();
    final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
    ProductDeliveryPatternInfoDtls prodDelPatternInfoDtls;

    // CaseNomineeProdDelPattern manipulation variables
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();
    CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls;

    // Flag to indicate if we need to consider adding maxCoverPeriodTo
    // to the list
    boolean considerMaxCoverPeriodTo = true;

    // Iterate through the list of dates and see if we need to consider
    // maxCoverPeriodTo
    maxCoverPeriodTo = maxCoverPeriodTo.addDays(1);

    for (int i = 0; i < completeDateList.dtls.size(); i++) {

      if (!maxCoverPeriodTo.after(completeDateList.dtls.item(i).date)) {

        considerMaxCoverPeriodTo = false;
        break;
      }
    }

    if (considerMaxCoverPeriodTo) {

      if (completeDateList.dtls.size() == kOneElement) {

        final DateStruct lastDate = new DateStruct();

        lastDate.date = maxCoverPeriodTo;
        completeDateList.dtls.addRef(lastDate);

        completeDateList.caseNomineeID = key.caseNomineeID;
        completeDateList.caseID = key.caseID;
        return completeDateList;
      }

      if (!componentDetailsList.dtls.isEmpty()) {

        pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = componentDetailsList.dtls
            .item(
                componentDetailsList.dtls.size() - 1).productDeliveryPatternID;
        pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
        pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = componentDetailsList.dtls
            .item(componentDetailsList.dtls.size() - 1).fromDate;

      } else {

        readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
        readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
        readEffectiveByDateKey.effectiveDate = completeDateList.dtls
            .item(completeDateList.dtls.size() - 1).date;

        // BEGIN, CR00211744, VM
        caseNomineeProdDelPatternDtls = assessmentEngineEntity
            .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
        // END, CR00211744

        pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
        pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
        pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = completeDateList.dtls
            .item(completeDateList.dtls.size() - 1).date;
      }
      // BEGIN, CR00049218, GM
      String freq = CuramConst.gkEmpty;

      // END, CR00049218

      // read productDeliveryPatternInfo record
      try {
        prodDelPatternInfoDtls = cachedProductDeliveryPatternInfoObj
            .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);

        freq = prodDelPatternInfoDtls.deliveryFrequency;
      } catch (final RecordNotFoundException e) {

        final AppException ae = new AppException(
            BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

        // get the case reference for display
        final CaseSearchKey caseSearchKey = new CaseSearchKey();

        caseSearchKey.caseID = key.caseID;

        ae.arg(CaseHeaderFactory.newInstance()
            .readCaseReferenceByCaseID(caseSearchKey).caseReference);
        ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
        throw ae;
      }

      // Need to do an extra sanity check to see if the delivery pattern on
      // maxCoverPeriodTo is the same as the last day in the list
      readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
      readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
      readEffectiveByDateKey.effectiveDate = maxCoverPeriodTo;

      // BEGIN, CR00211744, VM
      caseNomineeProdDelPatternDtls = assessmentEngineEntity
          .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
      // END, CR00211744

      pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
      pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
      pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = maxCoverPeriodTo;
      // BEGIN, CR00049218, GM
      String maxCoverPeriodToFreq = CuramConst.gkEmpty;

      // END, CR00049218

      try {
        prodDelPatternInfoDtls = cachedProductDeliveryPatternInfoObj
            .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);

        maxCoverPeriodToFreq = prodDelPatternInfoDtls.deliveryFrequency;
      } catch (final RecordNotFoundException e) {

        final AppException ae = new AppException(
            BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

        // get the case reference for display
        final CaseSearchKey caseSearchKey = new CaseSearchKey();

        caseSearchKey.caseID = key.caseID;

        ae.arg(CaseHeaderFactory.newInstance()
            .readCaseReferenceByCaseID(caseSearchKey).caseReference);
        ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
        throw ae;
      }

      // If the frequencies don't match, we need to get roll forward
      // the last date in the list based on freq
      if (maxCoverPeriodToFreq.equals(freq)) {

        final DateStruct dateStruct = new DateStruct();

        dateStruct.date = maxCoverPeriodTo;
        completeDateList.dtls.addRef(dateStruct);

        maxCoverPeriodToAddedToList = true;
      }
    }

    // One last check is to see if we're dealing with a daily pattern
    if (!considerMaxCoverPeriodTo && !completeDateList.dtls.isEmpty()) {

      readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
      readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
      readEffectiveByDateKey.effectiveDate = completeDateList.dtls
          .item(completeDateList.dtls.size() - 1).date;

      // BEGIN, CR00211744, VM
      caseNomineeProdDelPatternDtls = assessmentEngineEntity
          .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
      // END, CR00211744

      pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
      pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
      pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = completeDateList.dtls
          .item(completeDateList.dtls.size() - 1).date;

      // read productDeliveryPatternInfo record
      try {
        prodDelPatternInfoDtls = cachedProductDeliveryPatternInfoObj
            .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);

        // BEGIN, CR00191533, KH
        // When checking for a daily pattern, use the generic daily pattern type
        if (new FrequencyPattern(prodDelPatternInfoDtls.deliveryFrequency)
            .getPatternType().equals(FrequencyPattern.PatternType.kDaily)) {
          // END, CR00191533

          final DateStruct dateStruct = new DateStruct();
          final Date lastDate = completeDateList.dtls
              .item(completeDateList.dtls.size() - 1).date;

          dateStruct.date = lastDate.addDays(1);
          completeDateList.dtls.addRef(dateStruct);
        }

      } catch (final RecordNotFoundException e) {

        final AppException ae = new AppException(
            BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

        // get the case reference for display
        final CaseSearchKey caseSearchKey = new CaseSearchKey();

        caseSearchKey.caseID = key.caseID;

        ae.arg(CaseHeaderFactory.newInstance()
            .readCaseReferenceByCaseID(caseSearchKey).caseReference);
        ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
        throw ae;
      }
    }

    // Set case and nominee identifiers in return objects
    completeDateList.caseNomineeID = key.caseNomineeID;
    completeDateList.caseID = key.caseID;

    return completeDateList;
  }

  // ___________________________________________________________________________
  /**
   * This method orders a list of dates in ascending order.
   *
   * @param dateList
   *          List of dates to be ordered.
   */
  @Override
  public void orderDateList(final DateList dateList) {

    // Need to sort the dates in the dateList in ascending order. The entries
    // in the componentDetailsList struct passed into this operation were
    // sorted by fromDate up front before any manipulation was performed.
    // However, it is still possible for the final list of dates not to be
    // ordered and for duplicates to exist. This list needs to be ordered and
    // any duplicates removed
    final Comparator<DateStruct> dateStructComparator = new DateStructComparator();

    // Create a HashSet to remove the duplicates
    // BEGIN, CR00103515, BD
    final java.util.HashSet<Date> dateHashSet = new java.util.HashSet<Date>();
    // END, CR00103515

    final int dateListSize = dateList.dtls.size();

    for (int i = 0; i < dateListSize; i++) {

      final DateStruct dateStruct = dateList.dtls.item(i);

      dateHashSet.add(dateStruct.date);
    }

    // Sort the list without duplicates
    // BEGIN, CR00103515, BD
    final ArrayList<DateStruct> dateListNoDuplicates = new ArrayList<DateStruct>();
    // END, CR00103515

    final Iterator<Date> it = dateHashSet.iterator();

    while (it.hasNext()) {

      final DateStruct dateStruct = new DateStruct();

      dateStruct.date = it.next();
      dateListNoDuplicates.add(dateStruct);
    }

    Collections.sort(dateListNoDuplicates, dateStructComparator);

    // Clear dateList for re-use
    dateList.dtls.clear();

    // Copy dates from dateListNoDuplicates to dateList
    final int dateListNoDuplicatesSize = dateListNoDuplicates.size();

    for (int i = 0; i < dateListNoDuplicatesSize; i++) {

      // BEGIN, CR00103515, BD
      dateList.dtls.addRef(dateListNoDuplicates.get(i));
      // END, CR00103515
    }
  }

  // ___________________________________________________________________________
  /**
   * This method fills in the missing payment dates in the date list. An example
   * of where this would be required is where the date list comprises of
   * (financial) cover period from dates and these dates themselves are not
   * payment dates.
   *
   * @param key
   *          Contains the case identifier plus the initial reassessment from/to
   *          dates.
   * @param dateList
   *          List of compiled dates for reassessment.
   * @param componentDetailsList
   *          List of virtual financial components.
   *
   * @return Complete list of dates to be used in case reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DateList fillInMissingPaymentDates(final OverUnderPaymentIn key,
      final DateList dateList, final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    // BEGIN, 254277, BD

    // NB whenever you add to this collection you *must* also add to
    // componentDateSet because the latter is used for searches.
    final DateValueList componentDateList = new DateValueList();

    // This is a side saddle set for componentDateList and must always
    // contain the same contents as it, to faciliate fast searching.
    final Set<Date> componentDateSet = new HashSet<Date>();
    // END, 254277

    // Copy entries in dateList to arrayList for manipulation
    for (int i = 0; i < dateList.dtls.size(); i++) {
      // BEGIN, 254277, BD
      final Date currentDate = dateList.dtls.item(i).date;
      componentDateList.addRef(currentDate);
      componentDateSet.add(currentDate);
      // END, 254277
    }

    if (!componentDateList.isEmpty()) {

      // ProductDeliveryPatternInfo manipulation variables
      final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory
          .newInstance();
      final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
      ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = null;

      // CaseNomineeProdDelPattern manipulation variables
      final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

      final GetFCDatesAndValuesKey getFCDatesAndValuesKey = new GetFCDatesAndValuesKey();

      final Date lastFinancialDate = componentDateList
          .item(componentDateList.size() - 1);
      Date testPaymentDate = componentDateList.item(0);

      final FCTestDates fcTestDates = new FCTestDates();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      Date anchorDate = CachedCaseHeaderFactory.newInstance()
          .read(caseHeaderKey).effectiveDate;

      // END, CR00148989

      // Set key to read CaseNomineeProdDelPattern
      readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
      readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
      readEffectiveByDateKey.effectiveDate = testPaymentDate;

      // Read CaseNomineeProdDelPattern for the testPaymentDate and check the
      // delivery pattern
      // BEGIN, CR00211744, VM
      final CaseNomineeProdDelPatternDtls firstDateCaseNomineeProdDelPatternDtls = assessmentEngineEntity
          .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);

      // END, CR00211744

      // BEGIN, CR00148989, KH
      if (mostRecentAnchorDate.isZero()) {
        fcTestDates.paymentDate = anchorDate;
      } else {
        fcTestDates.paymentDate = mostRecentAnchorDate;
        anchorDate = mostRecentAnchorDate;
      }
      // END, CR00148989

      fcTestDates.testDate = testPaymentDate;

      pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = firstDateCaseNomineeProdDelPatternDtls.productDeliveryPatternID;
      pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
      pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = testPaymentDate;

      // read productDeliveryPatternInfo record
      productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
          .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);

      // BEGIN, CR00148989, KH
      FrequencyPattern frequencyPattern = new FrequencyPattern(
          productDeliveryPatternInfoDtls.deliveryFrequency);

      IsPaymentDateResult isPaymentDateResult;
      Date testDate = anchorDate;

      // BEGIN, CR00190883, KH
      while (!testDate.before(testPaymentDate)) {
        testDate = frequencyPattern.getPrevOccurrence(testDate);
      }
      // END, CR00190883

      testDate = frequencyPattern.getNextOccurrence(testDate);
      // END, CR00148989

      testPaymentDate = testDate;

      for (int j = 1; j < dateList.dtls.size(); j++) {

        // Set key to read CaseNomineeProdDelPattern
        readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
        readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
        readEffectiveByDateKey.effectiveDate = dateList.dtls.item(j).date;

        // Read CaseNomineeProdDelPattern
        // BEGIN, CR00211744, VM
        final CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = assessmentEngineEntity
            .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);

        // END, CR00211744

        pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
        pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
        pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = componentDateList
            .item(j);

        // read productDeliveryPatternInfo record
        try {
          productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
              .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);
        } catch (final RecordNotFoundException e) {

          final AppException ae = new AppException(
              BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

          // get the case reference for display
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          caseSearchKey.caseID = key.caseID;

          ae.arg(CaseHeaderFactory.newInstance()
              .readCaseReferenceByCaseID(caseSearchKey).caseReference);
          ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
          throw ae;
        }

        getFCDatesAndValuesKey.deliveryFrequency = productDeliveryPatternInfoDtls.deliveryFrequency;

        final Date tempPaymentDate = testPaymentDate;

        // BEGIN, CR00148989, KH
        frequencyPattern = new FrequencyPattern(
            productDeliveryPatternInfoDtls.deliveryFrequency);
        // END, CR00148989

        while (testPaymentDate.before(lastFinancialDate)
            && !testPaymentDate.before(tempEarliestDecisionDate)
            || testPaymentDate.before(lastFinancialDate)
                && tempNewDecisionDate.before(tempEarliestDecisionDate)) {

          // BEGIN, CR00148989, KH
          testPaymentDate = frequencyPattern.getNextOccurrence(testPaymentDate);
          // END, CR00148989

          if (testPaymentDate.before(lastFinancialDate)) {
            // BEGIN, 254277, BD
            if (!componentDateSet.contains(tempPaymentDate)) {
              // BEGIN, CR00103515, BD
              componentDateList.addRef(tempPaymentDate);
              componentDateSet.add(tempPaymentDate);
              // END, CR00103515
            }
            // END, 254277

            // Set key to read CaseNomineeProdDelPattern
            readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;
            readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
            readEffectiveByDateKey.effectiveDate = testPaymentDate;

            // Read CaseNomineeProdDelPattern for the testPaymentDate and check
            // the delivery pattern
            // BEGIN, CR00211744, VM
            final CaseNomineeProdDelPatternDtls rolledForwardPmtDateCaseNomineeProdDelPatternDtls = assessmentEngineEntity
                .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);

            // END, CR00211744

            pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = rolledForwardPmtDateCaseNomineeProdDelPatternDtls.productDeliveryPatternID;
            pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
            pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = testPaymentDate;

            // read productDeliveryPatternInfo record
            ProductDeliveryPatternInfoDtls rolledForwardPmtDateProductDeliveryPatternInfoDtls = null;

            try {
              rolledForwardPmtDateProductDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
                  .readNearestProdDelPatInfo(
                      pdpiByProdDelPatIDStatusAndDateKey);
            } catch (final RecordNotFoundException e) {

              final AppException ae = new AppException(
                  BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

              // get the case reference for display
              final CaseSearchKey caseSearchKey = new CaseSearchKey();

              caseSearchKey.caseID = key.caseID;

              ae.arg(CaseHeaderFactory.newInstance()
                  .readCaseReferenceByCaseID(caseSearchKey).caseReference);
              ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
              throw ae;
            }

            // BEGIN, 254277, BD
            if (!componentDateSet.contains(testPaymentDate)) {
              // END, 254277

              // If the delivery frequency is the same, add test date to list
              if (rolledForwardPmtDateProductDeliveryPatternInfoDtls != null
                  && rolledForwardPmtDateProductDeliveryPatternInfoDtls.deliveryFrequency
                      .equals(productDeliveryPatternInfoDtls.deliveryFrequency)
                  // also need to check that testPaymentDate is before toDate
                  && testPaymentDate.before(key.toDate)) {

                // BEGIN, CR00050838, MR
                fcTestDates.testDate = testPaymentDate;
                fcTestDates.paymentDate = anchorDate;

                getFCDatesAndValuesKey.deliveryFrequency = productDeliveryPatternInfoDtls.deliveryFrequency;

                isPaymentDateResult = FCGenerationUtilFactory.newInstance()
                    .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

                // Add date to the componentDateList - we have already checked
                // that it did not exist in the list
                if (isPaymentDateResult.result) {
                  // BEGIN, CR00103515, BD
                  componentDateList.addRef(testPaymentDate);
                  // BEGIN, 254277, BD
                  componentDateSet.add(testPaymentDate);
                  // END, 254277
                  // END, CR00103515
                }
                // END, CR00050838

              } else {

                // 1. getPrevOccurrence of testPaymentDate on
                final Date tempDate = new FrequencyPattern(
                    rolledForwardPmtDateProductDeliveryPatternInfoDtls.deliveryFrequency)
                        .getPrevOccurrence(testPaymentDate);

                // BEGIN, CR00050838, MR
                final ProductDeliveryIsPaymentDateDetails productDeliveryIsPaymentDateDetails = new ProductDeliveryIsPaymentDateDetails();

                productDeliveryIsPaymentDateDetails.caseID = key.caseID;
                productDeliveryIsPaymentDateDetails.tempDate = tempDate;
                productDeliveryIsPaymentDateDetails.deliveryFrequency = productDeliveryPatternInfoDtls.deliveryFrequency;
                final boolean isPaymentDateInd = isPaymentDate(
                    productDeliveryIsPaymentDateDetails);

                // END, CR00050838

                getFCDatesAndValuesKey.deliveryFrequency = productDeliveryPatternInfoDtls.deliveryFrequency;
                final FCGenerationUtil fcGenerationUtilObj = FCGenerationUtilFactory
                    .newInstance();

                isPaymentDateResult = fcGenerationUtilObj
                    .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

                // 2. check if the new rolled back date is a payment date, if it
                // is add it to the list

                // BEGIN, CR00050838, MR
                if (isPaymentDateInd) { // isPaymentDateResult.result
                  // END, CR00050838

                  // BEGIN, CR00103515, BD
                  componentDateList.addRef(tempDate);
                  // BEGIN, 254277, BD
                  componentDateSet.add(tempDate);
                  // EMD, 254277
                  // END, CR00103515
                }
                fcTestDates.testDate = testPaymentDate;

                getFCDatesAndValuesKey.deliveryFrequency = rolledForwardPmtDateProductDeliveryPatternInfoDtls.deliveryFrequency;

                isPaymentDateResult = fcGenerationUtilObj
                    .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

                // 2. check if the new rolled back date is a payment date
                // if it is, add it to the list

                if (isPaymentDateResult.result // need to check that
                    // testPaymentDate is before
                    // the toDate
                    && testPaymentDate.before(key.toDate)) {

                  boolean addDateInd = false;

                  if (rolledForwardPmtDateProductDeliveryPatternInfoDtls.deliveryFrequency
                      .equals(
                          productDeliveryPatternInfoDtls.deliveryFrequency)) {

                    addDateInd = true;
                  } else if (!testPaymentDate.after(
                      rolledForwardPmtDateProductDeliveryPatternInfoDtls.fromDate)) {

                    addDateInd = true;
                  }

                  if (addDateInd) {
                    // BEGIN, CR00103515, BD
                    componentDateList.addRef(testPaymentDate);
                    // BEGIN, 254277, BD
                    componentDateSet.add(tempPaymentDate);
                    // END, 254277
                    // END, CR00103515
                  }
                }
              }
            }
          }
        } // end while

        testPaymentDate = dateList.dtls.item(j).date;
      } // end for i
    }

    // Clear dateList for re-use
    dateList.dtls.clear();

    // Copy dates for arrayList to dateList structure
    for (int k = 0; k < componentDateList.size(); k++) {

      final DateStruct newDate = new DateStruct();

      newDate.date = componentDateList.item(k);
      dateList.dtls.addRef(newDate);
    }

    return dateList;
  } // method fillInMissingPaymentDates

  // ___________________________________________________________________________
  /**
   * This function provides a hook for customers so that they can examine the
   * 'virtual' financial components created from the eligible case decisions.
   * The function returns <code>false</code> by default indicating that
   * processing should continue. Customized code, however, may result in
   * <code>true</code> being returned which will result in assessment being
   * restarted on the case.
   *
   * @param componentDetailsList
   *          List of financial components.
   *
   * @return boolean indicates if processing is to be restarted.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public boolean restartProcessingBasedOnComponentDetails(
      final ComponentDetailsList componentDetailsList)
      throws AppException, InformationalException {

    // BEGIN, CR00050173, MR
    Boolean returnValue = new Boolean(false);

    // Check the Environmental variable
    // Retrieve the Environment variable for the ISU component installation
    // setting. If the environment variable is present and set to 'true', run
    // the Reflection code.
    if (Configuration.getBooleanProperty(EnvVars.ENV_ISU_INSTALLED)) {

      final String className = CuramConst.gkCaseReassessmentFactClass;
      final String methodName = CuramConst.gkCaseReassessmentClassMethod;

      // Set the arguments to pass through
      final Object[] arguments = new Object[] { componentDetailsList };

      // Set the passed class types to the method
      final Class[] parameterTypes = new Class[] { ComponentDetailsList.class };

      returnValue = (Boolean) performReflection(className, methodName,
          arguments, parameterTypes);
    }

    return returnValue.booleanValue();
    // END, CR00050173
  }

  // ___________________________________________________________________________
  /**
   * This method checks if the period of the reassessmentInfo record (from the
   * previous reassessment) overlaps with a period of a prospective
   * reassessmentInfo record from the current reassessment. If an overlap is
   * found, the relevant reassessmentAmountInfoDtlsList is retrieved. A further
   * check is performed inside this if statement to see if there is an exact
   * match of the period.
   *
   * @param reassessmentInfoDtlsList
   *          A list of information on the previous reassessments.
   * @param reassessmentInfoDtls
   *          Information about the current reassessment.
   * @param reassessmentAmountInfoDtlsList
   *          A list of information on the previous reassessment amounts for the
   *          matching period. This list will be empty initially and will be
   *          populated if an overlap is found.
   *
   * @return matchingReassessmentPeriodResult Contains an indicator to record
   *         whether the previous and current reassessment periods matched
   *         exactly.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public MatchingReassessmentPeriodResult checkForMatchingReassessmentPeriods(
      final ReassessmentInfoDtlsList reassessmentInfoDtlsList,
      final ReassessmentInfoDtls reassessmentInfoDtls,
      final ReassessmentAmountInfoDtlsList reassessmentAmountInfoDtlsList)
      throws AppException, InformationalException {

    // ReassessmentAmountInfo manipulation variables
    final ReassessmentAmountInfo reassessmentAmountInfoObj = ReassessmentAmountInfoFactory
        .newInstance();
    final ReassessmentAmountInformationKey reassessmentAmountInformationKey = new ReassessmentAmountInformationKey();
    ReassessmentAmountInfoDtlsList localReassessmentAmountInfoDtlsList = new ReassessmentAmountInfoDtlsList();

    // Return struct
    final MatchingReassessmentPeriodResult matchingReassessmentPeriodResult = new MatchingReassessmentPeriodResult();

    // Indicates whether we have found an exact match
    matchingReassessmentPeriodResult.exactPeriodMatch = false;

    for (int i = 0; i < reassessmentInfoDtlsList.dtls.size(); i++) {

      // BEGIN, CR00142853, KH
      // Check if the period of the reassessmentInfo record (from the
      // previous reassessment) overlaps with a period of a
      // prospective reassessmentInfo record from the current
      // reassessment.
      if (!reassessmentInfoDtls.fromDate
          .after(reassessmentInfoDtlsList.dtls.item(i).toDate)
          && !reassessmentInfoDtls.toDate
              .before(reassessmentInfoDtlsList.dtls.item(i).fromDate)) {
        // END, CR00142853

        // Whether there is an exact match or not determines how the
        // actual/reassessed amounts will be manipulated before the
        // reassessmentInfo record is written to the database
        // Check if the periods match exactly
        if (reassessmentInfoDtlsList.dtls.item(i).fromDate
            .equals(reassessmentInfoDtls.fromDate)
            && reassessmentInfoDtlsList.dtls.item(i).toDate
                .equals(reassessmentInfoDtls.toDate)) {

          matchingReassessmentPeriodResult.exactPeriodMatch = true;
        }

        // Set key to read reassessment amount info
        reassessmentAmountInformationKey.reassessmentInfoID = reassessmentInfoDtlsList.dtls
            .item(i).reassessmentInfoID;

        // Read info and store in local variable
        localReassessmentAmountInfoDtlsList = reassessmentAmountInfoObj
            .searchByReassessInfoID(reassessmentAmountInformationKey);

        // Populate the reassessment amount info list parameter so that it is
        // available to the calling method
        for (int j = 0; j < localReassessmentAmountInfoDtlsList.dtls
            .size(); j++) {

          reassessmentAmountInfoDtlsList.dtls
              .addRef(localReassessmentAmountInfoDtlsList.dtls.item(j));
        } // end for j

        break;
      }
    } // end for i

    return matchingReassessmentPeriodResult;
  }

  // ___________________________________________________________________________
  /**
   * This method calculates the current 'actual' amount. If more than one
   * objective has been paid out for the current reassessment period we may need
   * to consider previous reassessments when calculating the current 'actual'
   * amount. In this situation we set the 'readPrevious' indicator.
   *
   * @param reassessmentAmountInfoDtlsList
   *          A list of the previous reassessment amount information.
   * @param reassessmentAmountInfoDetails
   *          The current reassessment amount info.
   * @param exactPeriodMatch
   *          Indicates that we have found an exact match between the previous
   *          and current reassessment periods.
   *
   * @return calculateActualReassessmentAmountResult Contains an indicator to
   *         record whether we need to consider previous reassessment info
   *         amounts.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public CalculateActualReassessmentAmountResult calculateActualReassessmentAmount(
      final ReassessmentAmountInfoDtlsList reassessmentAmountInfoDtlsList,
      final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails,
      final boolean exactPeriodMatch)
      throws AppException, InformationalException {

    // Return struct
    final CalculateActualReassessmentAmountResult calculateActualReassessmentAmountResult = new CalculateActualReassessmentAmountResult();

    // Indicates that we need to check previous reassessment info
    calculateActualReassessmentAmountResult.readPrevious = false;

    // BEGIN, CR00180474, VM
    if (reassessmentAmountInfoDtlsList.dtls.isEmpty()) {
      calculateActualReassessmentAmountResult.readPrevious = true;
      return calculateActualReassessmentAmountResult;
    }
    // END, CR00180474

    for (int i = 0; i < reassessmentAmountInfoDtlsList.dtls.size(); i++) {

      if (reassessmentAmountInfoDtlsList.dtls.item(i).amountType
          .equals(reassessmentAmountInfoDetails.amountType)) {

        // BEGIN, CR00297933, KH
        // Need to perform some calculations based on the previous
        // reassessment amount info details
        if (!exactPeriodMatch && !reassessmentAmountInfoDetails.actualAmount
            .equals(reassessmentAmountInfoDetails.reassessedAmount)) {

          /*
           * If the periods do not match and the actual and reassessed amounts
           * are not equal we must consider the difference between the current
           * and previous actuals
           */

          // Money variables for amount data manipulation
          Money tempDiff = Money.kZeroMoney;
          Money actual = Money.kZeroMoney;

          // Find diff between actuals
          tempDiff = new Money(
              reassessmentAmountInfoDetails.actualAmount.getValue()
                  - reassessmentAmountInfoDtlsList.dtls.item(i).actualAmount
                      .getValue());

          // Current actual is the previous reassessed plus the diff
          actual = new Money(
              reassessmentAmountInfoDtlsList.dtls.item(i).reassessedAmount
                  .getValue() + tempDiff.getValue());

          // Set the reassessed actual with the calculated value
          reassessmentAmountInfoDetails.actualAmount = new Money(
              actual.getValue());

          // Need to consider previous reassessments for this period
          calculateActualReassessmentAmountResult.readPrevious = true;

        } else { // We have found an exact matching reassessment period

          // BEGIN, CR00275245, KH
          /*
           * If more than one objective was used and the reassessed amounts have
           * changed between reassessments then we need to adjust the current
           * actual amount.
           */
          // BEGIN, CR00021616, SK
          if (reassessmentAmountInfoDtlsList.dtls.item(i).reassessedAmount
              .isZero()
              && reassessmentAmountInfoDtlsList.dtls.item(i).actualAmount
                  .isZero()
              || multipleObjectiveInd && (actualAmountAdjustedInd
                  || reassessmentAmountInfoDetails.reassessedAmount
                      .getValue() != reassessmentAmountInfoDtlsList.dtls
                          .item(i).reassessedAmount.getValue()
                  || reassessmentAmountInfoDtlsList.dtls
                      .item(i).reassessedAmount.isZero())) {
            // END, CR00021616

            reassessmentAmountInfoDetails.actualAmount = new Money(
                reassessmentAmountInfoDetails.actualAmount.getValue()
                    - reassessmentAmountInfoDtlsList.dtls.item(i).actualAmount
                        .getValue()
                    + reassessmentAmountInfoDtlsList.dtls
                        .item(i).reassessedAmount.getValue());

            // Need to consider previous reassessments for this period
            calculateActualReassessmentAmountResult.readPrevious = true;

            // We have adjusted the current actual amount
            actualAmountAdjustedInd = true;

          } else {

            /*
             * This is a simple reassessment. We can use the previous reassessed
             * amount for the current actual amount.
             */
            reassessmentAmountInfoDetails.actualAmount = reassessmentAmountInfoDtlsList.dtls
                .item(i).reassessedAmount;

            // BEGIN, 178020, CSH
            // For a No Change reassessment set the reassessed
            // amount equal to the actual amount
            if (isNoChangeReassessment && totalActualAmountZero) {
              reassessmentAmountInfoDetails.reassessedAmount = reassessmentAmountInfoDtlsList.dtls
                  .item(i).actualAmount;
            }
            // END, 178020
          } // end if (multipleObjectiveInd == true) && ...
        } // end if (!exactPeriodMatch)
        // END, CR00275245, CR00297933
      }
    } // end for i

    return calculateActualReassessmentAmountResult;
  }

  // BEGIN, CR00211444, KH
  // ___________________________________________________________________________
  /**
   * Calculates the actual amount that should be recorded against the current
   * reassessment for the specified period.
   * <p>
   * Typically this will be the reassessed amount from the previous reassessment
   * for the same period, but this amount may need to be adjusted if there have
   * been any cancelled and re-issued payments for the period in question.
   *
   * @param previousBreakdownInfo
   *          Contains the reassessment amount that may need to be adjusted.
   *
   * @param caseID
   *          The case on which this reassessment is being recorded.
   * @param caseNomineeID
   *          The nominee against which this reassessment is being recorded.
   * @param reassessmentInfoDtls
   *          Contains the reassessment period that we are interested in.
   * @return The actual amount that should be recorded against the current
   *         reassessment for the specified period.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected Money calculateActualAmount(final long caseID,
      final long caseNomineeID, final ReassessmentInfoDtls reassessmentInfoDtls,
      final ReassessmentAmountInfoDetails reassessmentAmountInfoDetails)
      throws AppException, InformationalException {

    double currentActualAmount = reassessmentAmountInfoDetails.actualAmount
        .getValue();

    final InstructionLineItem instructionLineItemObj = InstructionLineItemFactory
        .newInstance();
    final InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

    // Get a list of ILIs for the case which overlap with the cover period
    final ILICaseIDCoverPeriod iliCaseIDCoverPeriod = new ILICaseIDCoverPeriod();

    iliCaseIDCoverPeriod.caseID = caseID;
    iliCaseIDCoverPeriod.coverPeriodFrom = reassessmentInfoDtls.fromDate;
    iliCaseIDCoverPeriod.coverPeriodTo = reassessmentInfoDtls.toDate;

    final ILICaseFinancialDtlsList iliDtlsList = instructionLineItemObj
        .searchByCaseIDCoverPeriodOverlap(iliCaseIDCoverPeriod);

    // Remove any ILIs which are not relevant to the current reassessment
    filterILIList(caseNomineeID, iliDtlsList);

    for (int i = 0; i < iliDtlsList.dtls.size(); i++) {

      instructionLineItemKey.instructLineItemID = iliDtlsList.dtls
          .item(i).instructLineItemID;
      final InstructionLineItemDtls iliDtls = instructionLineItemObj
          .read(instructionLineItemKey);

      // BEGIN, CR00211893, KH
      // Check if this ILI should be used to alter the actual amount
      if (iliDtls.adjustReassessmentInd) {

        currentActualAmount = currentActualAmount - iliDtls.amount.getValue();

        /*
         * NB: We don't mark the ILI here as considered, we need it later during
         * the breakdown processing as well. It will be updated then.
         */
      }
      // END, CR00211893
    }

    return new Money(currentActualAmount);
  }

  // ___________________________________________________________________________
  /**
   * Filters the list of instruction line items (ILIs). Any ILIs which fall into
   * one of the following categories will be removed:
   * <OL>
   * <LI>ILIs which are not a payment or a liability</LI>
   * <LI>ILIs which are not cancelled</LI>
   * <LI>ILIs which are not for our nominee</LI>
   * </OL>
   *
   * @param caseNomineeID
   *          The ID of our nominee.
   * @param iliDtlsList
   *          The full list of ILIs for the reassessment period.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected void filterILIList(final long caseNomineeID,
      final ILICaseFinancialDtlsList iliDtlsList)
      throws AppException, InformationalException {

    // Filter on the category
    for (int i = 0; i < iliDtlsList.dtls.size(); i++) {

      // If it's not a payment or liability remove it
      if (!iliDtlsList.dtls.item(i).instructLineItemCategory
          .equals(ILICATEGORY.PAYMENTINSTRUCTION)
          && !iliDtlsList.dtls.item(i).instructLineItemCategory
              .equals(ILICATEGORY.LIABILITYINSTRUCTION)) {

        iliDtlsList.dtls.remove(i);
        i--; // this ensures we don't skip any records
        continue; // with next record
      }

      // Filter on the nominee and status
      if (iliDtlsList.dtls.item(i).caseNomineeID != caseNomineeID
          || !iliDtlsList.dtls.item(i).statusCode.equals(ILISTATUS.CANCELLED)) {

        iliDtlsList.dtls.remove(i);
        i--; // this ensures we don't skip any records
      }
    } // end for i
  }

  // END, CR00211444

  // BEGIN, CR00050838, MR
  // ___________________________________________________________________________
  /**
   * Retrieves the delivery pattern info effective on a specified date.
   *
   * @param details
   *          The product delivery pattern details.
   *
   * @return The delivery pattern info effective on the specified date.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  protected ProductDeliveryPatternInfoDtls getFrequency(
      final ProductDeliveryPatternFrequencyDetails details)
      throws AppException, InformationalException {

    // ProductDeliveryPatternInfo manipulation variables
    final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory
        .newInstance();
    final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = null;

    // Set key to read ProductDeliveryPatternInfo
    pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = details.productDeliveryPatternID;
    pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
    pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = details.effectiveDate;

    // read productDeliveryPatternInfo record
    try {
      productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
          .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);

      return productDeliveryPatternInfoDtls;

    } catch (final RecordNotFoundException e) {

      final AppException ae = new AppException(
          BPOCASEREASSESSMENT.ERR_NO_CASE_DELIVERY_PATTERN_ON_DATE);

      // get the case reference for display
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      caseSearchKey.caseID = details.caseNomineeID;

      ae.arg(CaseHeaderFactory.newInstance()
          .readCaseReferenceByCaseID(caseSearchKey).caseReference);
      ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
      throw ae;
    }
  }

  // ___________________________________________________________________________
  /**
   * Checks to see if a given date is a payment date for a specified delivery
   * pattern.
   *
   * @param details
   *          The product delivery pattern details.
   *
   * @return <code>true</code> if the given date is a payment date for the
   *         specified delivery pattern, <code>false</code> otherwise.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  protected boolean isPaymentDate(
      final ProductDeliveryIsPaymentDateDetails details)
      throws AppException, InformationalException {

    // Check that the tempDate is a payment date for the given delivery pattern
    final FCTestDates fcTestDates = new FCTestDates();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CachedCaseHeader caseHeaderObj = CachedCaseHeaderFactory
        .newInstance();

    // FCGenerationUtil manipulation variables
    final curam.core.intf.FCGenerationUtil fcGenerationUtilObj = FCGenerationUtilFactory
        .newInstance();
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey = new GetFCDatesAndValuesKey();

    // Set key to read CaseHeaderss
    caseHeaderKey.caseID = details.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    fcTestDates.paymentDate = caseHeaderDtls.effectiveDate;
    fcTestDates.testDate = details.tempDate;

    getFCDatesAndValuesKey.deliveryFrequency = details.deliveryFrequency;

    final IsPaymentDateResult isPaymentDateResult = fcGenerationUtilObj
        .isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

    return isPaymentDateResult.result;
  }

  // END, CR00050838

  // BEGIN, CR00050173, MR
  // ___________________________________________________________________________
  /**
   * Execute reflection on the Argument Class and Method, using argument
   * parameters.
   *
   * @param className
   *          Class name to instantiate
   * @param methodName
   *          Method to be run
   * @param arguments
   *          Arguments to be passed to Method
   * @param parameterTypes
   *          Class Types of Parameters used
   *
   * @return Invoked method will return object which can be case by cast method.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected Object performReflection(final String className,
      final String methodName, final Object[] arguments,
      final Class[] parameterTypes)
      throws AppException, InformationalException {

    // END, CR00198672
    Class<?> cls = null;

    try {
      // Load the class
      cls = Class.forName(className);

      // Create a method for the static newInstance constructor
      // BEGIN, CR00053248, GM
      final Method constructorMethod = cls
          .getMethod(ReflectionConst.kNewInstance);
      // END, CR00053248
      final Object classObj = constructorMethod.invoke(cls);

      // Define the method
      // BEGIN, CR00142355, CD
      final Method method = classObj.getClass().getMethod(methodName,
          parameterTypes);

      // END, CR00142355

      // Now invoke the method
      return method.invoke(classObj, arguments);

    } catch (final IllegalAccessException e) {// ignore - biz methods MUST be
      // public
    } catch (final ClassNotFoundException e) {

      final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

      ae.arg(className);
      ae.arg(getClass().toString());
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL));

      throw new RuntimeException(ae);

    } catch (final NoSuchMethodException e) {

      final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

      ae.arg(className);
      // BEGIN, CR00053248, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00053248
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL));

      throw new RuntimeException(ae);

    } catch (final IllegalArgumentException e) {

      final AppException ae = new AppException(
          BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);

      // BEGIN, CR00053248, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00053248
      ae.arg(className);
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL));

      throw new RuntimeException(ae);

    } catch (final InvocationTargetException e) {

      final AppException exc = new AppException(
          BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

      exc.arg(e.getTargetException().getMessage());
      throw exc;
    }

    return null;
  }

  // END, CR00050173
  // END, CR00142853

  // BEGIN, CR00161231, KH
  // ___________________________________________________________________________
  /**
   * Retrieve the financial instruction(s) for a case for a given period of
   * time.
   *
   * @param key
   *          Contains the reassessment from / to dates.
   *
   * @return List of financial instruction identifiers.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected FinInstructionIDList getFinInstructionIDList(
      final OverUnderPaymentIn key)
      throws AppException, InformationalException {

    final CaseIDStatusAndCoverPeriodKey searchKey = new CaseIDStatusAndCoverPeriodKey();

    searchKey.caseID = key.caseID;
    searchKey.statusCode = ILISTATUS.CANCELLED;
    searchKey.coverPeriodFrom = key.fromDate;
    searchKey.coverPeriodTo = key.toDate;

    final FinInstructionIDList finInstructionIDList = InstructionLineItemFactory
        .newInstance()
        .searchDistinctFinInstructIDByCaseStatusAndPeriod(searchKey);

    return finInstructionIDList;
  }

  // ___________________________________________________________________________
  /**
   * Considers the replacement payment cover period from dates as part of
   * reassessment.
   *
   * @param key
   *          Contains the reassessment from / to dates.
   * @param dateList
   *          The date list to be used as part of reassessment.
   *
   * @return The date list to be used as part of reassessment.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected DateList considerDatesForReplacementPayment(
      final OverUnderPaymentIn key, final DateList dateList)
      throws AppException, InformationalException {

    final FinInstructionIDList finInstructionIDList = getFinInstructionIDList(
        key);

    // There should only be one finInstructionID in the list
    if (!finInstructionIDList.dtls.isEmpty()) {

      final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      for (int i = 0; i < finInstructionIDList.dtls.size(); i++) {

        // BEGIN, CR00465838, CSH
        // If payments are processed by an external system it's possible that
        // there will be no associated financial instruction.
        // Skip this record if this is the case.
        if (finInstructionIDList.dtls.item(i).finInstructionID == 0) {

          continue;
        }
        // END, CR00465838

        paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory
            .newInstance().readByFinInstructionID(
                finInstructionIDList.dtls.item(i)).pmtInstrumentID;

        final PaymentInstrumentDtls paymentInstrumentDtls = PaymentInstrumentFactory
            .newInstance().read(paymentInstrumentKey);

        if (paymentInstrumentDtls.invalidatedInd) {
          final StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

          statusFinInstructID.finInstructionID = finInstructionIDList.dtls
              .item(i).finInstructionID;
          statusFinInstructID.statusCode = ILISTATUS.CANCELLED;

          final InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory
              .newInstance().searchByFinInstructStatus(statusFinInstructID);

          for (int j = 0; j < iliDtlsList.dtls.size(); j++) {

            // BEGIN, CR00166377, KH
            // Payments may be rolled up across cases. We need to filter the
            // instruction line items by the case we're reassessing. Including
            // line items from the other cases may lead to issues further
            // on in the reassessment processing as the case being reassessed
            // may have a start date later than some of the cover period from
            // dates on the other case(s). Later on we read the
            // CaseNomineeProdDelPattern entity by effective date. This
            // read will fail if the date used in the read is earlier than
            // the case start date. In addition, we must ensure that the
            // replacement payment is for the relevant nominee.
            if (iliDtlsList.dtls.item(j).caseID != 0
                && iliDtlsList.dtls.item(j).caseID == key.caseID
                && iliDtlsList.dtls
                    .item(j).caseNomineeID == key.caseNomineeID) {

              final DateStruct dateStruct = new DateStruct();

              dateStruct.date = iliDtlsList.dtls.item(j).coverPeriodFrom;

              // BEGIN, CR00161641, KH
              // Need to order the date list each time as we could be adding
              // additional dates out of order
              orderDateList(dateList);

              // BEGIN, CR00173527, KH
              // We will add a date if it falls within the existing period
              if (dateList.dtls.item(0).date.before(dateStruct.date)
                  && dateList.dtls.item(dateList.dtls.size() - 1).date
                      .after(dateStruct.date)) {
                dateList.dtls.addRef(dateStruct);

                // Or it immediately precedes the existing period
              } else if (iliDtlsList.dtls.item(j).coverPeriodTo.addDays(1)
                  .equals(dateList.dtls.item(0).date)) {
                dateList.dtls.addRef(dateStruct);

                // Or it immediately follows the existing period
              } else if (dateStruct.date.addDays(-1)
                  .equals(dateList.dtls.item(dateList.dtls.size() - 1).date)) {
                dateList.dtls.addRef(dateStruct);
              }
              // END, CR00173527
            }
            // END, CR00166377
          } // end for j
        }
      } // end for i
    }

    return dateList;
  }

  // ___________________________________________________________________________
  /**
   * Checks the system to see if a replacement payment exists in the period
   * being reassessed.
   *
   * @param key
   *          Contains the reassessment from / to dates.
   *
   * @return Flag to indicate if a replacement exists for the period specified
   *         in the key.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected CheckForInvalidatedPaymentsResult checkForReplacementPayment(
      final OverUnderPaymentIn key)
      throws AppException, InformationalException {

    final CheckForInvalidatedPaymentsResult checkForInvalidatedPaymentsResult = new CheckForInvalidatedPaymentsResult();

    final FinInstructionIDList finInstructionIDList = getFinInstructionIDList(
        key);

    long caseNomineeID = 0;
    PaymentInstrumentDtls paymentInstrumentDtls = null;

    if (!finInstructionIDList.dtls.isEmpty()) {

      final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      OUTER: for (int i = 0; i < finInstructionIDList.dtls.size(); i++) {

        paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory
            .newInstance().readByFinInstructionID(
                finInstructionIDList.dtls.item(i)).pmtInstrumentID;

        paymentInstrumentDtls = PaymentInstrumentFactory.newInstance()
            .read(paymentInstrumentKey);

        if (paymentInstrumentDtls.invalidatedInd) {

          checkForInvalidatedPaymentsResult.invalidatedPmtExistsInd = true;
          final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

          iliFinInstructID.finInstructionID = finInstructionIDList.dtls
              .item(i).finInstructionID;

          final InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory
              .newInstance().searchByFinInstructionID(iliFinInstructID);

          for (int j = 0; j < iliDtlsList.dtls.size(); j++) {

            if (iliDtlsList.dtls.item(j).caseID == key.caseID) {

              caseNomineeID = iliDtlsList.dtls.item(j).caseNomineeID;

              // We now know that an invalidated payment exists for the period.
              // A further check is required to see if it has been replaced.
              final CaseNomineePeriodAndReplacementPmtIndKey reassessmentKey = new CaseNomineePeriodAndReplacementPmtIndKey();

              // Set key to search ReassessmentBalanceInfo
              reassessmentKey.caseNomineeID = caseNomineeID;
              reassessmentKey.replacementPmtInd = true;
              reassessmentKey.coverPeriodFrom = iliDtlsList.dtls
                  .item(j).coverPeriodFrom;
              reassessmentKey.coverPeriodTo = iliDtlsList.dtls
                  .item(j).coverPeriodTo;

              final ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList = ReassessmentBalanceInfoFactory
                  .newInstance().searchByCaseNomineePeriodAndReplacementPmtInd(
                      reassessmentKey);

              if (reassessmentBalanceInfoDtlsList.dtls.isEmpty()) {
                checkForInvalidatedPaymentsResult.relatedCaseExistsInd = false;
                break OUTER;
              } else {
                checkForInvalidatedPaymentsResult.relatedCaseExistsInd = true;
              }
            }
          } // end for j
        }
      } // end for i
    }

    return checkForInvalidatedPaymentsResult;
  }

  // END, CR00161231

  // BEGIN, 178020, CSH
  // ___________________________________________________________________________
  /**
   * Checks if the period of a replacement payment created during a previous is
   * Ineligible during the current reassessment.
   *
   * @param key
   *          Contains the reassessment from / to dates.
   *
   * @return Returns true if the replacement payment period is Ineligible,
   *         indicating that the replacement payment needs to be considered
   *         during the current reassessment.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  protected boolean checkForIneligibleReplacementPayment(
      final OverUnderPaymentIn key)
      throws AppException, InformationalException {

    boolean reassessReplacementPaymentRelatedCase = true;

    final FinInstructionIDList finInstructionIDList = getFinInstructionIDList(
        key);

    long caseNomineeID = 0;
    PaymentInstrumentDtls paymentInstrumentDtls = null;

    if (!finInstructionIDList.dtls.isEmpty()) {

      final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      OUTER: for (int i = 0; i < finInstructionIDList.dtls.size(); i++) {

        paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory
            .newInstance().readByFinInstructionID(
                finInstructionIDList.dtls.item(i)).pmtInstrumentID;

        paymentInstrumentDtls = PaymentInstrumentFactory.newInstance()
            .read(paymentInstrumentKey);

        if (paymentInstrumentDtls.invalidatedInd) {

          final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

          iliFinInstructID.finInstructionID = finInstructionIDList.dtls
              .item(i).finInstructionID;

          final InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory
              .newInstance().searchByFinInstructionID(iliFinInstructID);

          for (int j = 0; j < iliDtlsList.dtls.size(); j++) {

            if (iliDtlsList.dtls.item(j).caseID == key.caseID) {

              caseNomineeID = iliDtlsList.dtls.item(j).caseNomineeID;

              // We now know that an invalidated payment exists for the period.
              // A further check is required to see if it has been replaced,
              // and also if the period of that replacement payment is still
              // eligible
              final CaseNomineePeriodAndReplacementPmtIndKey reassessmentKey = new CaseNomineePeriodAndReplacementPmtIndKey();

              // Set key to search ReassessmentBalanceInfo
              reassessmentKey.caseNomineeID = caseNomineeID;
              reassessmentKey.replacementPmtInd = true;
              reassessmentKey.coverPeriodFrom = iliDtlsList.dtls
                  .item(j).coverPeriodFrom;
              reassessmentKey.coverPeriodTo = iliDtlsList.dtls
                  .item(j).coverPeriodTo;

              final ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList = ReassessmentBalanceInfoFactory
                  .newInstance().searchByCaseNomineePeriodAndReplacementPmtInd(
                      reassessmentKey);

              for (int k = 0; k < reassessmentBalanceInfoDtlsList.dtls
                  .size(); k++) {

                if (reassessmentBalanceInfoDtlsList.dtls
                    .item(k).replacementPmtInd) {

                  final MaintainCaseDecisionCaseIDKey activeDecisionsKey = new MaintainCaseDecisionCaseIDKey();

                  activeDecisionsKey.caseID = key.caseID;
                  final CaseDecisionSummaryList activeDecisionList = MaintainCaseDecisionFactory
                      .newInstance().getActiveCaseDecisions(activeDecisionsKey);

                  for (int m = 0; m < activeDecisionList.dtls.size(); m++) {

                    if ((activeDecisionList.dtls.item(m).decisionFromDate
                        .before(reassessmentBalanceInfoDtlsList.dtls
                            .item(k).coverPeriodTo)
                        || activeDecisionList.dtls.item(m).decisionFromDate
                            .equals(reassessmentBalanceInfoDtlsList.dtls
                                .item(k).coverPeriodTo))
                        &&

                        (activeDecisionList.dtls.item(m).decisionToDate
                            .after(reassessmentBalanceInfoDtlsList.dtls
                                .item(k).coverPeriodFrom)
                            || activeDecisionList.dtls.item(m).decisionToDate
                                .equals(reassessmentBalanceInfoDtlsList.dtls
                                    .item(k).coverPeriodFrom))
                        || activeDecisionList.dtls.item(m).decisionToDate
                            .equals(Date.kZeroDate)) {

                      if (activeDecisionList.dtls.item(m).resultCode
                          .equals(CASEDECISIONRESULTCODE.ELIGIBLE)) {

                        // If the period of the replacement payment is elgible,
                        // then don't include in the reassessment
                        reassessReplacementPaymentRelatedCase = false;
                        break OUTER;

                      }

                    }
                  }
                }
              }
            } // end for j
          }
        } // end for i
      }
    }
    return reassessReplacementPaymentRelatedCase;
  }
  // END, 178020
}
