/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2002-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOCURAMBATCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Locale;
import curam.util.resources.ProgramLocale;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import java.text.NumberFormat;


/**
 * Program to send emails that will be called from within batch and report
 * programs.
 *
 */
// BEGIN, CR00372024, VT
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
// END, CR00372024
public class CuramBatch {

  protected static final int kNumberOfSecondsInMinute = 60000;

  protected static final int kNumberOfMinutesInHour = 60000;

  protected static final int kNumberOfMillisInHour = 3600000;

  // string to hold email message

  // BEGIN, CR00049218, GM
  public String emailMessage = CuramConst.gkEmpty;

  // output file identifier
  public String outputFileID = CuramConst.gkEmpty;

  // output file name
  public String outputFilename = CuramConst.gkEmpty;

  // data file extension
  public String datFileExt = CuramConst.gkEmpty;

  // END, CR00049218

  // email subject
  protected AppException subject;

  // variable to hold runtime text, including
  // length of time for job to run
  protected AppException runtimeText;

  // username of user requesting batch job to be run
  // BEGIN, CR00049218, GM
  protected String username = CuramConst.gkEmpty;

  // END, CR00049218

  // variables used to send the email
  // BEGIN, CR00049218, GM
  protected int port;

  protected String servername = CuramConst.gkEmpty;

  protected String from = CuramConst.gkEmpty;

  protected String to = CuramConst.gkEmpty;

  protected String bcc = CuramConst.gkEmpty;

  protected String cc = CuramConst.gkEmpty;

  // END, CR00049218

  // stringBuffer to hold the concatenation of error messages
  // that may occur when sending the email. The length is based
  // on the max length that errMsg can be
  protected int kBufSize = 2048;

  protected StringBuffer errMsg = new StringBuffer(kBufSize);

  // flags that are set in batch jobs to indicate runtime
  // logging being switched on. startTimeSet is set to true
  // before call to batch process and endTimeSet is set to
  // true when all records are processed
  protected boolean startTimeSet = false;

  protected boolean endTimeSet = false;

  // time at which the batch job was requested
  protected curam.util.type.DateTime requestedAt = curam.util.type.DateTime.kZeroDateTime;

  // time at which the batch job started
  protected curam.util.type.DateTime startTime = curam.util.type.DateTime.kZeroDateTime;

  // time at which the batch job completed
  protected curam.util.type.DateTime endTime = curam.util.type.DateTime.kZeroDateTime;

  // length of time for batch job to run
  // (i.e. endTime - startTime)

  // BEGIN, CR00049218, GM
  protected String elapsedTime = CuramConst.gkEmpty;

  // END, CR00049218

  /**
   * This method is used to set the email subject.
   *
   * @param c message catalog entry
   */
  public void setEmailSubject(curam.util.message.CatEntry c)
    throws AppException, InformationalException {

    // BEGIN, CR00070529, "PA"
    /*
     * curam.core.intf.FormatDate formatDateObj =
     * curam.core.fact.FormatDateFactory.newInstance();
     * FormatDateAsStringKey formatDateAsStringKey = new
     * FormatDateAsStringKey();
     * FormatDateAsStringDtls formatDateAsStringDtls;
     */
    // END, CR00070529

    // setting the email subject text
    requestedAt = curam.util.transaction.TransactionInfo.getSystemDateTime();

    subject = new AppException(c);

    // BEGIN, CR00070529, "PA"

    // BEGIN, CR00086110, POB
    subject.arg(new Date(requestedAt).toString());

    subject.arg(Locale.getFormattedTime(requestedAt));
    // END, CR00086110
    /*
     * formatDateAsStringKey.inputDate = requestedAt;
     * formatDateAsStringDtls =
     * formatDateObj.formatDateAsString(formatDateAsStringKey);
     * subject.arg(formatDateAsStringDtls.stringDate);
     *
     * // format request as time
     * formatDateAsStringDtls =
     * formatDateObj.formatTimeAsString(formatDateAsStringKey);
     *
     * subject.arg(formatDateAsStringDtls.stringDate);
     */

    subject.arg(
      requestedAt.toString() + CuramConst.gkSpace
      + TransactionInfo.getServerTimeZone().getID());

    // END, CR00070529

  }

  // BEGIN, CR00352167, SR

  /**
   * To send e-mails from batch and report jobs. The sendEmail function is
   * called from within the batch and report jobs. In the case where the email
   * can't be sent, the error message is dumped out to the log file along with
   * the email message itself. Irrespective of the fact that whether the
   * e-mail sending operation succeeds or not, the contents are always
   * logged to the appropriate destination.
   *
   * In the case where the output log file can't be opened the output is
   * written to the console.
   *
   */
  // END, CR00352167
  // BEGIN, CR00372024, VT
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00372024
  public void sendEmail() throws AppException, InformationalException {

    // BEGIN, CR00352167, SR
    try {
      setupAndSendEmail();
    } catch (final Throwable exception) {

      final AppException appException = new AppException(
        BPOCURAMBATCH.INF_EMAIL_ERROR_CONNECTING_TO_SERVER_WITH_MSG);

      appException.arg(exception.getMessage());
      errMsg.append(appException.toString()).append(CuramConst.gkNewLine);

    } finally {
      sendToOutputFile();
    }
    // END, CR00352167
  }

  // BEGIN, CR00352167, SR
  /**
   * To send e-mails from batch and report jobs. The sendEmail function is
   * called from within the batch and report jobs.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  private void setupAndSendEmail() throws AppException,
      InformationalException {

    setTo();
    setFrom();
    setPort();
    setServer();

    curam.util.resources.SMTPConnection emailConnection = null;

    try {
      emailConnection = new curam.util.resources.SMTPConnection(username,
        servername, port);

    } catch (final Exception e) {

      final AppException ae = new AppException(
        curam.message.BPOCURAMBATCH.INF_EMAIL_ERROR_CONNECTING_TO_SERVER_WITH_MSG);

      ae.arg(e.getMessage());

      errMsg.append(ae.toString()).append(CuramConst.gkNewLine);
    }

    // need to append runtime logging to mail if it was switched on
    if (startTimeSet && endTimeSet) {

      getElapsedTime();
      setRuntimeText();
      emailMessage += CuramConst.gkNewLine + CuramConst.gkNewLine;
      emailMessage += runtimeText.getMessage(
        ProgramLocale.getDefaultServerLocale());
    } else {

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_NO_LOGGING_SPECIFIED);

      emailMessage += CuramConst.gkNewLine + CuramConst.gkNewLine;
      emailMessage += e.getMessage(ProgramLocale.getDefaultServerLocale());
    }

    // if creation of an instance of the SMTPConnection succeeded above,
    // it's safe to send the email
    if (emailConnection != null) {

      // send the mail
      try {
        emailConnection.sendMessage(from,
          subject.getMessage(ProgramLocale.getDefaultServerLocale()), to, cc,
          bcc, emailMessage);

        final AppException ae = new AppException(
          curam.message.BPOCURAMBATCH.INF_EMAIL_SUCCESSFULLY_SENT);

        Trace.kTopLevelLogger.info(
          Trace.objectAsTraceString(
            CuramConst.gkNewLine + CuramConst.gkNewLine
            + ae.getMessage(ProgramLocale.getDefaultServerLocale())
            + CuramConst.gkNewLine + CuramConst.gkNewLine));

      } catch (final curam.util.exception.AppException e) {

        final AppException ae = new AppException(
          curam.message.BPOCURAMBATCH.INF_EMAIL_UNSUCCESSFUL_WITH_MSG);

        ae.arg(e.getMessage(ProgramLocale.getDefaultServerLocale()));

        errMsg.append(ae.getMessage(ProgramLocale.getDefaultServerLocale())).append(
          CuramConst.gkNewLine);

        Trace.kTopLevelLogger.info(
          Trace.objectAsTraceString(
            CuramConst.gkNewLine + CuramConst.gkNewLine
            + ae.getMessage(ProgramLocale.getDefaultServerLocale())
            + CuramConst.gkNewLine + CuramConst.gkNewLine));
      } catch (final Exception e) {

        final AppException ae = new AppException(
          curam.message.BPOCURAMBATCH.INF_EMAIL_UNSUCCESSFUL);

        Trace.kTopLevelLogger.info(
          Trace.objectAsTraceString(
            CuramConst.gkNewLine + CuramConst.gkNewLine
            + ae.getMessage(ProgramLocale.getDefaultServerLocale())
            + CuramConst.gkNewLine + CuramConst.gkNewLine));
      }
    }
  }

  /**
   * This method is used to set the output filename
   *
   */
  public void setFileName() throws AppException, InformationalException {

    // report extension string
    String reportExt;

    if (requestedAt.isZero()) { // setFileName() may be called publicly

      requestedAt = curam.util.transaction.TransactionInfo.getSystemDateTime();
    }

    // deciding on file extension
    if (datFileExt.length() == 0) {

      reportExt = CuramConst.gkLogFileExt;

    } else {

      reportExt = datFileExt;
    }

    // creating output file name with date and time-stamp
    outputFilename = outputFileID + CuramConst.gkUnderscore
      + curam.util.resources.Locale.getFormattedDateTime(requestedAt,
      curam.util.resources.Locale.Date_dmy)
      + CuramConst.gkUnderscore
      + curam.util.resources.Locale.getFormattedDateTime(requestedAt,
      curam.util.resources.Locale.Time_ISO)
      + reportExt;

    // resetting requestedAt to be an empty date
    requestedAt = curam.util.type.DateTime.kZeroDateTime;

  }

  /**
   * This method is used to set the start time of the batch job.
   *
   */
  // BEGIN, CR00372024, VT
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00372024
  public void setStartTime() throws AppException, InformationalException {

    setStartTime(curam.util.transaction.TransactionInfo.getSystemDateTime());

  }

  /**
   * This method is used to set the start time of the batch job.
   *
   * @param inStartTime The start time of batch program
   */
  // BEGIN, CR00372024, VT
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00372024
  public void setStartTime(curam.util.type.DateTime inStartTime)
    throws AppException, InformationalException {

    startTime = inStartTime;
    startTimeSet = true;
  }

  /**
   * This method is used to set the end time of the batch job.
   *
   */
  // BEGIN, CR00372024, VT
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00372024
  public void setEndTime() throws AppException, InformationalException {

    endTime = curam.util.transaction.TransactionInfo.getSystemDateTime();
    endTimeSet = true;
  }

  /**
   * To set correct date from formatted string as dd/mm/yyyy.
   *
   * @param string formatted string
   *
   * @return converted date
   */
  public curam.util.type.Date formattedString2Date(String string)
    throws AppException, InformationalException {

    // variable for holding converted date
    curam.util.type.Date date;

    // start position of day in the string
    final int kDayStartPos = 0;

    // start position of month in the string
    final int kMonthStartPos = 3;

    // start position of year in the string
    final int kYearStartPos = 6;

    // size of day length in the string
    final int kDaySize = 2;

    // size of month length in the string
    final int kMonthSize = 2;

    // size of year length in the string
    final int kYearSize = 4;

    // variable used for constructing date
    int year;
    int month;
    int day;

    // temp string to hold substring date values, i.e. month,
    // day, year, of the date being formatted
    String buf;

    if (string.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.BPOCURAMBATCH.ERR_INPUT_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // get day from string and convert it to Short type
    buf = string.substring(kDayStartPos, kDayStartPos + kDaySize);

    try {
      day = Integer.parseInt(String.valueOf(buf));
    } catch (final java.lang.NumberFormatException e) {
      throw new DateConversionError();
    }

    // get month from string and convert it to Short type
    buf = string.substring(kMonthStartPos, kMonthStartPos + kMonthSize);

    try {
      month = Integer.parseInt(String.valueOf(buf));
    } catch (final java.lang.NumberFormatException e) {
      throw new DateConversionError();
    }

    // get year from string and convert it to Short type
    buf = string.substring(kYearStartPos, kYearStartPos + kYearSize);

    // converts month from string to number
    year = Integer.parseInt(String.valueOf(buf));

    final java.util.Calendar gregDate = new java.util.GregorianCalendar(year,
      month - 1, day, 0, 0, 0);

    date = new curam.util.type.Date(gregDate);

    return date;
  }

  /**
   * This method is used to set the 'from' email address.
   *
   */
  protected void setFrom() throws AppException, InformationalException {

    // retrieve the 'from' email address from the environmentMap
    from = curam.util.resources.Configuration.getProperty(EnvVars.ENV_EMAILFROM);

    if (from == null) {

      // prevent null pointer exception
      from = EnvVars.ENV_EMAILFROM_DEFAULT;
    }

    if (from.length() == 0) {

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_READING_FROM_ADDRESS);

      // BEGIN, CR00163236, CL
      errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

      from = setErrorEmailAddress();
    }

  }

  /**
   * This method is used to set the 'to' email address based on the username
   * specified. If no username is specified a default error email address is
   * used instead.
   *
   */
  protected void setTo() throws AppException, InformationalException {

    // retrieve the username from the environmentMap
    username = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_EMAILUSERNAME);

    if (username == null) {

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_ERROR_READING_USERNAME);

      // BEGIN, CR00163236, CL
      errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

      to = setErrorEmailAddress();

    } else {

      setToEmailAddress();
    }

  }

  /**
   * This method is used to set the email port number.
   *
   */
  protected void setPort() throws AppException, InformationalException {

    // retrieve the port number from the environmentMap
    String value = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_EMAILPORT);

    if (value == null) {

      // prevent null pointer exception
      // BEGIN, CR00049218, GM

      value = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (value.length() == 0) {

      // default value if not specified
      port = EnvVars.ENV_EMAILPORT_DEFAULT;

    } else {

      // convert the port number to an integer
      port = Integer.parseInt(value);
    }

  }

  /**
   * This method is used to the email server address.
   *
   */
  protected void setServer() throws AppException, InformationalException {

    // retrieve the server name from the environmentMap
    servername = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_EMAILSERVER);

    if (servername == null) {

      // prevent null pointer exception
      // BEGIN, CR00049218, GM
      servername = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (servername.length() == 0) {

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_SERVERNAME_NOT_FOUND);

      // BEGIN, CR00163236, CL
      errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236
    }

  }

  /**
   * This method sends the report to the output file.
   *
   */
  protected void sendToOutputFile() throws AppException,
      InformationalException {

    // set file name
    setFileName();

    // create output stream variable
    java.io.PrintStream outStream;

    try {
      outStream = new java.io.PrintStream(
        new java.io.FileOutputStream(outputFilename));
    } catch (final java.io.FileNotFoundException e) {
      throw new curam.util.exception.AppRuntimeException(e);
    }

    if (outStream.checkError()) {

      // check for file open failure
      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_OPENING_OUTPUT_FILE);

      // BEGIN, CR00163236, CL
      errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(CuramConst.gkNewLine).append(
        CuramConst.gkNewLine);
      // END, CR00163236

      if (errMsg.length() > 0) {

        errMsg.append(CuramConst.gkNewLine);
      }

      Trace.kTopLevelLogger.info(
        Trace.objectAsTraceString(errMsg.append(emailMessage)));

    } else {

      if (errMsg.length() > 0) {

        errMsg.append(CuramConst.gkNewLine);
      }

      // BEGIN, CR00163236, CL
      outStream.print(
        errMsg.append(
          subject.getMessage(ProgramLocale.getDefaultServerLocale())));
      // END, CR00163236
      outStream.print(
        CuramConst.gkNewLine + CuramConst.gkNewLine + emailMessage);

      outStream.close();

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_FILE_SENT_TO_OUPUT);

      // BEGIN, CR00163236, CL
      Trace.kTopLevelLogger.info(
        Trace.objectAsTraceString(
          e.getMessage(ProgramLocale.getDefaultServerLocale()) + outputFilename));
      // END, CR00163236
    }

  }

  /**
   * This method is used to find the duration of the batch job.
   *
   */
  protected void getElapsedTime() throws AppException, InformationalException {

    elapsedTime = getTimeAsString(endTime.asLong() - startTime.asLong());

  }

  /**
   * This method is used to format the elapsed time.
   *
   */
  protected String getTimeAsString(long elapsed) {

    long hours, minutes, seconds;
    final AppException format = new AppException(
      curam.message.GENERALBATCH.INF_TIME_FORMAT);

    hours = elapsed / kNumberOfMillisInHour;
    elapsed = elapsed - hours * kNumberOfMillisInHour;
    minutes = elapsed / kNumberOfMinutesInHour;
    elapsed = elapsed - minutes * kNumberOfSecondsInMinute;
    seconds = elapsed / 1000;

    final NumberFormat nf = NumberFormat.getInstance();

    nf.setMinimumIntegerDigits(2);

    format.arg(nf.format(hours));
    format.arg(nf.format(minutes));
    format.arg(nf.format(seconds));
    return format.getLocalizedMessage();

  }

  /**
   * This method is used to set the text for reporting the duration for the
   * output log/email
   *
   */
  protected void setRuntimeText() throws AppException, InformationalException {

    runtimeText = new AppException(curam.message.GENERALBATCH.INF_JOB_RUNTIME);

    runtimeText.arg(curam.util.resources.Locale.getFormattedTime(startTime));
    runtimeText.arg(elapsedTime);
  }

  /**
   * To retrieve specified email address.
   *
   */
  protected void setToEmailAddress() throws AppException,
      InformationalException {

    // users manipulation variables
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UsersDtls usersDtls;

    // emailAddress manipulation variables
    final curam.core.intf.EmailAddress emailAddressObj = curam.core.fact.EmailAddressFactory.newInstance();
    final EmailAddressKey emailAddressKey = new EmailAddressKey();
    EmailAddressDtls emailAddressDtls;

    // set key to read users entity
    usersKey.userName = username;

    try {
      usersDtls = usersObj.read(usersKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      usersDtls = null;
    }

    if (usersDtls != null) {

      // set key to read emailAddress entity
      emailAddressKey.emailAddressID = usersDtls.businessEmailID;

      try {
        emailAddressDtls = emailAddressObj.read(emailAddressKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        emailAddressDtls = null;
      }

      if (emailAddressDtls != null) {
        if (emailAddressDtls.emailAddress.length() == 0) {

          final AppException e = new AppException(
            curam.message.BPOCURAMBATCH.INF_USERNAME_EMAIL_ADDRESS_EMPTY);

          // BEGIN, CR00163236, CL
          errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
            CuramConst.gkNewLine);
          // END, CR00163236

          to = setErrorEmailAddress();

        } else {

          to = emailAddressDtls.emailAddress;
        }

      } else {

        final AppException e = new AppException(
          curam.message.BPOCURAMBATCH.INF_USERNAME_EMAIL_ADDRESS_NOT_FOUND);

        // BEGIN, CR00163236, CL
        errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
          CuramConst.gkNewLine);
        // END, CR00163236

        to = setErrorEmailAddress();
      }

    } else {

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_USER_NOT_FOUND);

      // BEGIN, CR00163236, CL
      errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

      to = setErrorEmailAddress();
    }

  }

  /**
   * To retrieve error email address.
   *
   * @return Error email address
   */
  protected String setErrorEmailAddress() throws AppException,
      InformationalException {

    // retrieve default error email address from the environmentMap
    String str = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_EMAILERRORTO);

    if (str == null) {

      str = EnvVars.ENV_EMAILERRORTO_DEFAULT;
    }

    if (str.length() == 0) {

      final AppException e = new AppException(
        curam.message.BPOCURAMBATCH.INF_ERROR_READING_DEFAULT_ADDRESS);

      // BEGIN, CR00163236, CL
      errMsg.append(e.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236
    }

    return str;
  }

}
