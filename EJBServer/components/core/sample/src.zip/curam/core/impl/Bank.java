/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.BankBranchDtls;
import curam.core.struct.BankBranchStatusAndBankIDKey;
import curam.core.struct.BankDtls;
import curam.core.struct.BankKey;
import curam.core.struct.BankNameStructRef;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Implementation of functions to be executed before insert, modify, etc.
 *
 */
public abstract class Bank extends curam.core.base.Bank {

  // __________________________________________________________________________
  /**
   * Readmulti class to close a bank if possible
   *
   */
  static class CloseBankBranches extends curam.util.dataaccess.ReadmultiOperation {

    // __________________________________________________________________________
    /**
     * An operation which will be called for each record in the CloseBank
     * readmulti class. This calls bankBranch.close() to attempt to close
     * the branch.
     *
     * @param objDtls BankBranchDtls
     *
     * @return True
     */
    @Override
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      final BankBranchDtls bankBranchDtls = (BankBranchDtls) objDtls;

      final curam.core.intf.BankBranch bankBranchObj = curam.core.fact.BankBranchFactory.newInstance();

      // comment to be added to automatically closed bank branches
      bankBranchDtls.comments = // BEGIN, CR00163471, JC
        curam.message.BPOBANK.INF_BANK_BRANCH_AUTO_CLOSED.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      // attempt to close each branch for the bank
      bankBranchObj.close(bankBranchDtls);

      return true;

    }
  }

  // __________________________________________________________________________
  /**
   * Checks if the bank with specified name already exist in db table and
   * if bank ID is correct
   *
   * @param details Bank information to be inserted into db table
   */
  @Override
  protected void autovalidate(BankDtls details) throws AppException,
      InformationalException {

    // variables, to perform information checking
    final BankNameStructRef bankNameStructRef = new BankNameStructRef();
    BankDtls bankDtls;

    // Check if bank name is provided
    if (details.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.BPOBANK.ERR_BANK_FV_NAME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    bankNameStructRef.assign(details);

    bankNameStructRef.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // try to find bank with the same name in db table
    try {
      bankDtls = readBankByName(bankNameStructRef);

      // if bank with the same name exists, check IDs
      if (bankDtls.bankID != details.bankID) {
        final AppException e = new AppException(
          curam.message.BPOBANK.ERR_BANK_DRE_NAME);

        e.arg(details.name);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

    } catch (final curam.util.exception.RecordNotFoundException e) {// ignore
      // record
      // not found
      // exception.
    }

  }

  // __________________________________________________________________________
  /**
   * Method to close a bank if there are no open accounts
   *
   * @param details Structure to contain new bank details
   */
  @Override
  public void close(BankDtls details) throws AppException,
      InformationalException {

    final BankKey bankKey = new BankKey();

    // declare specialized readmulti to close branches
    final CloseBankBranches closeBankBranches = new CloseBankBranches();

    // declare parameters to read bank branch
    final BankBranchStatusAndBankIDKey bankBranchStatusAndBankIDKey = new BankBranchStatusAndBankIDKey();

    bankBranchStatusAndBankIDKey.bankID = details.bankID;
    bankBranchStatusAndBankIDKey.bankBranchStatus = curam.codetable.BANKBRANCHSTATUS.DEFAULTCODE;
    bankBranchStatusAndBankIDKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    try {

      // perform specialized readmulti to close bank branches
      curam.core.fact.BankBranchFactory.newInstance().searchByBankBranchStatusAndBankID(
        bankBranchStatusAndBankIDKey, closeBankBranches);

    } catch (final curam.util.exception.AppException e) {

      // If the bank branch has open accounts, it names an account
      // that is open.
      // But, as we are closing the higher entity - the bank, we
      // don't want to mention an individual account. Hence, the
      // exception is intercepted so that we can report a more
      // relevant message.
      if (e.getCatEntry().equals(
        curam.message.BPOBANKBRANCH.ERR_BANKBRANCH_XRV_AT_LEAST_ONE_OPEN_ACCOUNT)) {

        throw new AppException(
          curam.message.BPOBANK.ERR_BANK_XRV_AT_LEAST_ONE_OPEN_ACCOUNT);

      } else {
        throw e;
      }
    }

    details.bankStatus = curam.codetable.BANKSTATUS.CLOSED;
    bankKey.bankID = details.bankID;

    if (details.endDate.isZero()) {

      details.endDate = curam.util.type.Date.getCurrentDate();

    }

    // update the bank record

    modify(bankKey, details);

  }

}
