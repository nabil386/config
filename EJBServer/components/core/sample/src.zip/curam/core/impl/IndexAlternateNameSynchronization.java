/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.AlternateNameDtls;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.events.ALTERNATENAME;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when
 * modifications are made to the Alternate Name entity
 */
public abstract class IndexAlternateNameSynchronization extends curam.core.base.IndexAlternateNameSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the alternate name entity insert operation
   *
   * @param dtls alternate name details
   */
  @Override
  public void insert(final AlternateNameDtls dtls) throws AppException,
      InformationalException {

    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALTERNATENAME.INSERT_ALTERNATE_NAME.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALTERNATENAME.INSERT_ALTERNATE_NAME.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.alternateNameID;
    // BEGIN, CR00191954, ZV
    synchronizeEventsDetails.secondaryEventData = dtls.concernRoleID;
    // END, CR00191954

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the alternate name entity modify operation
   *
   * @param key alternate name identifier
   * @param dtls alternate name details
   */
  @Override
  public void modify(final AlternateNameKey key, final AlternateNameDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALTERNATENAME.MODIFY_ALTERNATE_NAME.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALTERNATENAME.MODIFY_ALTERNATE_NAME.eventType;
    synchronizeEventsDetails.primaryEventData = key.alternateNameID;
    // BEGIN, CR00191954, ZV
    synchronizeEventsDetails.secondaryEventData = dtls.concernRoleID;
    // END, CR00191954

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119

  }

  // BEGIN, CR00250206, ZV
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the alternate name entity remove operation
   *
   * @param dtls alternate name details
   */
  @Override
  public void remove(final AlternateNameDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALTERNATENAME.REMOVE_ALTERNATE_NAME.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALTERNATENAME.REMOVE_ALTERNATE_NAME.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.alternateNameID;
    synchronizeEventsDetails.secondaryEventData = dtls.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }
  // END, CR00250206

}
