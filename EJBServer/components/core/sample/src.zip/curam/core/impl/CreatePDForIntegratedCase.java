/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASECLASSIFICATION;
import curam.codetable.CASEPRIORITY;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.fact.CaseFactory;
import curam.core.sl.struct.OwnershipStrategyDetails;
import curam.core.struct.BaseCurrency;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CurrencyExchangeDateTypeStructRef;
import curam.core.struct.MaintainCaseHeaderDetails;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.RegisterProductDeliveryDetails;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.core.struct.TypeFrequencyOverrideAndBenefitIndicator;
import curam.message.GENERALADMIN;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;


/**
 * Code for creating and maintaining integrated cases.
 *
 */
public abstract class CreatePDForIntegratedCase extends curam.core.base.CreatePDForIntegratedCase {

  // ___________________________________________________________________________
  /**
   * This method registers the fact that a product delivery is part of an IC.
   *
   * @param key
   * Contains details of Product Delivery.
   * @param maintainCaseHeaderDetails
   * Contains details of case.
   *
   * @return Contains IDs of case.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_PRODUCTDELIVERY_XFV_FROMDATE_TODATE} - If
   * toDate is earlier than fromDate.
   * {@link GENERALADMIN#ERR_CURRENCYEXCHANGE_RNFE_DATE_TYPE} - If a
   * currency exchange record for certain date and type cannot be
   * found.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public RegisterProductDeliveryDetails setICProductDelivery(
    RegisterProductDeliveryKey key,
    MaintainCaseHeaderDetails maintainCaseHeaderDetails) throws AppException,
      InformationalException {

    final RegisterProductDeliveryDetails registerProductDeliveryDetails = new RegisterProductDeliveryDetails();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    final curam.core.intf.CurrencyExchange currencyExchangeObj = curam.core.fact.CurrencyExchangeFactory.newInstance();
    final CurrencyExchangeDateTypeStructRef currDateType = new CurrencyExchangeDateTypeStructRef();

    String currencyTypeDesc;

    final curam.core.intf.CreateProductDeliveryAssistant createProductDeliveryAssistantObj = curam.core.fact.CreateProductDeliveryAssistantFactory.newInstance();

    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // Set new Case ID to unique number.
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();

    // Date Validation.

    // If not empty, toDate cannot be earlier than fromDate.
    if (!key.expectedEndDate.isZero()
      && key.expectedEndDate.before(key.expectedStartDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCASE.ERR_PRODUCTDELIVERY_XFV_FROMDATE_TODATE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // If product is a liability, default payment method to 'CHEQUE'
    // this will only be used for any benefit components generated.

    final curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
    final ProductKey productKey = new ProductKey();
    TypeFrequencyOverrideAndBenefitIndicator typeFrequencyOverrideAndBenefitIndicator;
    final RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();

    // BEGIN, CR00060051, PMD
    final OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();

    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // END, CR00060051

    registerProductDeliveryKey.assign(key);

    // Set key to read product.
    productKey.productID = key.productID;

    // Insert product.
    typeFrequencyOverrideAndBenefitIndicator = productObj.readTypeFrequencyOverrideAndBenefitIndicator(
      productKey);

    if (!typeFrequencyOverrideAndBenefitIndicator.benefitInd) {

      registerProductDeliveryKey.paymentMethodType = METHODOFDELIVERY.CHEQUE;
    }

    // Fill Case details struct
    caseHeaderDtls.startDate = Date.getCurrentDate();
    caseHeaderDtls.registrationDate = Date.getCurrentDate();
    caseHeaderDtls.statusCode = CASESTATUS.OPEN;
    caseHeaderDtls.priorityCode = CASEPRIORITY.DEFAULTCODE;
    caseHeaderDtls.classificationCode = CASECLASSIFICATION.DEFAULTCODE;

    caseHeaderDtls.assign(registerProductDeliveryKey);
    // Set default values.
    caseHeaderDtls.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

    // BEGIN, CR00060051, PMD
    caseHeaderDtls.ownerOrgObjectLinkID = 0;
    // END, CR00060051
    caseHeaderDtls.integratedCaseID = maintainCaseHeaderDetails.caseID;

    // initialize unused fields.
    caseHeaderDtls.appealIndicator = false;

    // Check Currency selected has currency exchange record at Start Date.
    currDateType.currencyTypeCode = key.currencyType;
    currDateType.theDate = key.receivedDate;
    currDateType.statusCode = RECORDSTATUS.NORMAL;

    // Only currencies which the system knows about can be used, so a
    // check is performed here. The base currency does not exist in the
    // exchange rate table.
    final curam.core.intf.MaintainCurrency maintainCurrencyObj = curam.core.fact.MaintainCurrencyFactory.newInstance();
    final BaseCurrency baseCurrency = maintainCurrencyObj.getBaseCurrency();

    if (!key.currencyType.equals(baseCurrency.currencyType)) {

      try {

        currencyExchangeObj.readRateByDateType(currDateType);

      } catch (final curam.util.exception.RecordNotFoundException e) {
        // Get currencyType description.
        // BEGIN, CR00163098, JC
        currencyTypeDesc = curam.util.type.CodeTable.getOneItem(
          curam.codetable.CURRENCY.TABLENAME, key.currencyType,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        final AppException ae = new AppException(
          GENERALADMIN.ERR_CURRENCYEXCHANGE_RNFE_DATE_TYPE);

        ae.arg(key.receivedDate);
        ae.arg(currencyTypeDesc);

        throw ae;
      }
    }

    // Set the case reference.
    caseHeaderDtls.caseReference = CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;

    caseHeaderObj.insert(caseHeaderDtls);

    // BEGIN, CR00118995, KH
    // Create case user roles first, to ensure there is a case owner for any
    // security checks performed later.
    // BEGIN, CR00060051, PMD
    // Set the case header key to be the current case id.
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = maintainCaseHeaderDetails.caseID;

    // Set the case owner to be the current user.
    orgObjectLinkDtls.userName = TransactionInfo.getProgramUser();
    orgObjectLinkDtls.orgObjectType = ORGOBJECTTYPE.USER;

    // Create the case owner.
    // BEGIN, CR00205191, SS
    // Check if a workflow is configured for this particular case type.
    productKey.productID = key.productID;
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();

    if (0 != productKey.productID) {

      // Retrieve the ownershipStrategyName configured for this case type.
      final ProductDtls productDtls = productObj.read(nfIndicator, productKey);

      if (!nfIndicator.isNotFound()
        && !StringUtil.isNullOrEmpty(productDtls.ownershipStrategyName)) {

        final CaseKey caseID = new CaseKey();

        caseID.caseID = caseHeaderKey.caseID;
        final OwnershipStrategyDetails ownershipStrategyDetails = new OwnershipStrategyDetails();

        ownershipStrategyDetails.ownershipStrategyName = productDtls.ownershipStrategyName;
        caseUserRoleObj.createOwnerBasedOnOwnershipStrategy(caseID,
          ownershipStrategyDetails);
      } else {

        caseUserRoleObj.createOwner(caseHeaderKey, orgObjectLinkDtls);
      }
    } else {

      caseUserRoleObj.createOwner(caseHeaderKey, orgObjectLinkDtls);
    }

    // END, CR00205191
    // END, CR00060051, CR00118995

    // Assign the new case identifier to the output parameters.
    registerProductDeliveryDetails.caseID = caseHeaderDtls.caseID;

    maintainCaseHeaderDetails.assign(caseHeaderDtls);

    // BEGIN, CR00119564, CW
    // Insert the product delivery prior to insert of case participant role.
    createProductDeliveryAssistantObj.insertProductDelivery(
      registerProductDeliveryKey, maintainCaseHeaderDetails,
      typeFrequencyOverrideAndBenefitIndicator);
    // END, CR00119564

    // Update details.
    createProductDeliveryAssistantObj.insertConcernCaseRole(
      registerProductDeliveryKey, maintainCaseHeaderDetails);

    // Prepare to do CaseStatus insert operation.
    caseStatusDtls.caseID = maintainCaseHeaderDetails.caseID;
    caseStatusDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    caseStatusDtls.startDate = curam.util.type.Date.getCurrentDate();

    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    // BEGIN, CR00150402, PDN
    // Get user name.
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    caseStatusDtls.userName = systemUserObj.getUserDetails().userName;
    // END, CR00150402

    // Insert new record to CaseStatus.
    caseStatusObj.insert(caseStatusDtls);

    return registerProductDeliveryDetails;
  }

}
