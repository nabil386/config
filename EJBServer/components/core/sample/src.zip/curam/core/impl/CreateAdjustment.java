/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.AdjInstructionDetails;
import curam.core.struct.AdjustmentInstructionDtls;
import curam.core.struct.CreateAdjustmentResult;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to create Adjustments and their component parts.
 *
 */
public abstract class CreateAdjustment extends curam.core.base.CreateAdjustment {

  // ___________________________________________________________________________
  /**
   * To create a charge or deduction adjustment on the Concerns account.
   *
   * @param adjInstructionDetails Adjustment Instruction Details
   *
   * @return Adjustment Instruction Details and Financial Instruction Details
   */
  @Override
  public CreateAdjustmentResult createAdjustmentInstruction(
    AdjInstructionDetails adjInstructionDetails) throws AppException,
      InformationalException {

    final CreateAdjustmentResult createAdjustmentResult = new CreateAdjustmentResult();

    // uniqueID manipulation variables
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // financialInstruction manipulation variables
    final curam.core.intf.FinancialInstruction financialInstructionObj = curam.core.fact.FinancialInstructionFactory.newInstance();
    final FinancialInstructionDtls financialInstructionDtls = new FinancialInstructionDtls();
    long financialInstructionID = 0;

    // financialInstructionStatus manipulation variables
    final curam.core.intf.FinancialInstructionStatus financialInstructionStatusObj = curam.core.fact.FinancialInstructionStatusFactory.newInstance();
    final FinancialInstructionStatusDtls finInstructionStatusDtls = new FinancialInstructionStatusDtls();
    long finInstructionStatusID = 0;

    // adjustmentInstruction manipulation variables
    final curam.core.intf.AdjustmentInstruction adjustmentInstructionObj = curam.core.fact.AdjustmentInstructionFactory.newInstance();
    final AdjustmentInstructionDtls adjustmentInstructionDtls = new AdjustmentInstructionDtls();
    long adjustmentInstructionID = 0;

    // set details to create the financialInstruction record
    financialInstructionID = uniqueIDObj.getNextID();

    financialInstructionDtls.finInstructionID = financialInstructionID;
    financialInstructionDtls.typeCode = curam.codetable.FINANCIALINSTRUCTION.ADJUSTMENT;
    financialInstructionDtls.concernRoleID = adjInstructionDetails.concernRoleID;
    financialInstructionDtls.statusCode = curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    financialInstructionDtls.amount = adjInstructionDetails.amount;
    financialInstructionDtls.effectiveDate = curam.util.type.Date.getCurrentDate();
    financialInstructionDtls.postingDate = curam.util.type.Date.getCurrentDate();

    if (adjInstructionDetails.adjustmentType.equals(
      curam.codetable.ADJUSTMENTTYPE.CHARGE)) {

      financialInstructionDtls.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;

    } else {

      financialInstructionDtls.creditDebitType = curam.codetable.CREDITDEBIT.CREDIT;
    }

    financialInstructionDtls.currencyTypeCode = adjInstructionDetails.currencyTypeCode;
    financialInstructionDtls.currencyExchangeID = adjInstructionDetails.currencyExchangeID;
    financialInstructionDtls.instrumentGenInd = adjInstructionDetails.instrumentGenInd;
    financialInstructionDtls.comments = adjInstructionDetails.comments;

    // insert financialInstruction record
    financialInstructionObj.insert(financialInstructionDtls);

    // set details for the adjustmentInstruction record
    adjustmentInstructionID = uniqueIDObj.getNextID();

    adjustmentInstructionDtls.assign(adjInstructionDetails);

    adjustmentInstructionDtls.adjInstructionID = adjustmentInstructionID;
    adjustmentInstructionDtls.finInstructionID = financialInstructionID;
    adjustmentInstructionDtls.effectiveDate = curam.util.type.Date.getCurrentDate();

    // insert adjustmentInstruction record
    adjustmentInstructionObj.insert(adjustmentInstructionDtls);

    // set details for the financialInstructionStatus record
    finInstructionStatusID = uniqueIDObj.getNextID();

    finInstructionStatusDtls.finInstructionStatusID = finInstructionStatusID;
    finInstructionStatusDtls.finInstructionID = financialInstructionID;
    finInstructionStatusDtls.statusCode = curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    finInstructionStatusDtls.statusDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // insert financialInstructionStatus record
    financialInstructionStatusObj.insert(finInstructionStatusDtls);

    // map output struct details
    createAdjustmentResult.amount = adjInstructionDetails.amount;
    createAdjustmentResult.finInstructionID = financialInstructionID;
    createAdjustmentResult.concernRoleID = adjInstructionDetails.concernRoleID;
    createAdjustmentResult.adjustmentType = adjInstructionDetails.adjustmentType;
    createAdjustmentResult.currencyTypeCode = adjInstructionDetails.currencyTypeCode;
    createAdjustmentResult.currencyExchangeID = adjInstructionDetails.currencyExchangeID;

    return createAdjustmentResult;
  }

}
