/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.struct.FIstatusCode;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.core.struct.ILICaseIDList;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.PIReconcilStatusCode;
import curam.core.struct.PSPaySlipInstructionID;
import curam.core.struct.PSStatusCodeVersNo;
import curam.core.struct.PaymentApprovalEventDtls;
import curam.core.struct.PaymentDetailsSummary;
import curam.core.struct.PaymentEventDetails;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.PayslipDtls;
import curam.core.struct.PayslipKey;
import curam.message.BPOCASEEVENTS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;


/**
 * To approve a Payment Instrument which was suspended due to the payment
 * amount exceeding the maximum product payment limit.
 *
 */
public abstract class ApprovePayment extends curam.core.base.ApprovePayment {

  // BEGIN CR00110127, MR
  // Add injection for using the new CaseTransactionLog API
  public ApprovePayment() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00110127

  // ___________________________________________________________________________
  /**
   * To approve the issue of a suspended Payment Instrument
   *
   * @param paymentDetailsSummary Approve payment details
   */
  @Override
  public void approvePaymentIssue(PaymentDetailsSummary paymentDetailsSummary)
    throws AppException, InformationalException {

    // financialInstruction manipulation variables
    final curam.core.intf.FinancialInstruction financialInstructionObj = curam.core.fact.FinancialInstructionFactory.newInstance();
    final FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();
    FinancialInstructionDtls financialInstructionDtls;
    final FIstatusCode fiStatusCode = new FIstatusCode();

    // maintainPaymentApprovalEvent manipulation variable
    final curam.core.intf.MaintainPaymentApprovalEvent maintainPaymentApprovalEventObj = curam.core.fact.MaintainPaymentApprovalEventFactory.newInstance();

    // financialInstructionStatus manipulation variables
    final curam.core.intf.FinancialInstructionStatus financialInstructionStatusObj = curam.core.fact.FinancialInstructionStatusFactory.newInstance();
    final FinancialInstructionStatusDtls financialInstructionStatusDtls = new FinancialInstructionStatusDtls();

    // uniqueID manipulation variable
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // paymentInstruction manipulation variables
    final curam.core.intf.PaymentInstruction paymentInstructionObj = curam.core.fact.PaymentInstructionFactory.newInstance();
    final FinInstructionID finInstructionID = new FinInstructionID();
    PaymentInstructionDtls paymentInstructionDtls;

    // paymentInstrument manipulation variables
    final curam.core.intf.PaymentInstrument paymentInstrumentObj = curam.core.fact.PaymentInstrumentFactory.newInstance();
    final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();
    PaymentInstrumentDtls paymentInstrumentDtls;
    final PIReconcilStatusCode piReconcilStatusCode = new PIReconcilStatusCode();

    // payslip manipulation variables
    final curam.core.intf.Payslip payslipObj = curam.core.fact.PayslipFactory.newInstance();
    final PayslipKey payslipKey = new PayslipKey();
    PayslipDtls payslipDtls;
    final PSPaySlipInstructionID psPaySlipInstructionID = new PSPaySlipInstructionID();
    final PSStatusCodeVersNo psStatusCodeVersNo = new PSStatusCodeVersNo();

    // instructionLineItem manipulation variables
    final curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();
    ILICaseIDList iliCaseIDList;

    // maintainCasePaymentApproval manipulation variables
    final PaymentApprovalEventDtls paymentApprovalEventDtls = new PaymentApprovalEventDtls();

    // maintainCasePaymentEvents manipulation variables
    final curam.core.intf.MaintainCasePaymentEvents maintainCasePaymentEventsObj = curam.core.fact.MaintainCasePaymentEventsFactory.newInstance();
    final PaymentEventDetails paymentEventDetails = new PaymentEventDetails();

    // set key to read financialInstruction
    financialInstructionKey.finInstructionID = paymentDetailsSummary.finInstructionID;

    // read financialInstruction record
    financialInstructionDtls = financialInstructionObj.read(
      financialInstructionKey);

    // The status of the payment that's being approved must be 'Suspended'
    // If it's not, then an error must be thrown
    if (!financialInstructionDtls.statusCode.equals(
      curam.codetable.PMTRECONCILIATIONSTATUS.SUSPENDED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOAPPROVEPAYMENT.ERR_PAYMENT_NOT_SUSPENDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // set status to 'Issued' for modification
    fiStatusCode.statusCode = curam.codetable.FININSTRUCTIONSTATUS.ISSUED;
    fiStatusCode.versionNo = financialInstructionDtls.versionNo;

    // modify financialInstruction entity
    financialInstructionObj.modifyStatus(financialInstructionKey, fiStatusCode);

    financialInstructionStatusDtls.finInstructionID = financialInstructionDtls.finInstructionID;
    financialInstructionStatusDtls.statusCode = fiStatusCode.statusCode;
    financialInstructionStatusDtls.statusDate = curam.util.transaction.TransactionInfo.getSystemDate();

    financialInstructionStatusDtls.finInstructionStatusID = uniqueIDObj.getNextID();

    // insert financialInstructionStatus record
    financialInstructionStatusObj.insert(financialInstructionStatusDtls);

    finInstructionID.finInstructionID = paymentDetailsSummary.finInstructionID;

    // read paymentInstruction using finInstructionID
    paymentInstructionDtls = paymentInstructionObj.readByFinInstructionID(
      finInstructionID);

    // set key to read paymentInstrument
    paymentInstrumentKey.pmtInstrumentID = paymentInstructionDtls.pmtInstrumentID;

    // read paymentInstrument entity
    paymentInstrumentDtls = paymentInstrumentObj.read(paymentInstrumentKey);

    // set details for modification
    piReconcilStatusCode.versionNo = paymentInstrumentDtls.versionNo;
    piReconcilStatusCode.reconcilStatusCode = curam.codetable.PMTRECONCILIATIONSTATUS.DEFAULTCODE;

    // modify paymentInstrument entity
    paymentInstrumentObj.modifyReconcilStatusCode(paymentInstrumentKey,
      piReconcilStatusCode);

    psPaySlipInstructionID.paySlipInstructionID = paymentInstrumentDtls.pslipInstructionID;

    try {
      payslipDtls = payslipObj.readByPayslipInstructionID(
        psPaySlipInstructionID, true);

      payslipKey.payslipID = payslipDtls.payslipID;
      psStatusCodeVersNo.statusCode = curam.codetable.PAYSLIPINSTRUCTIONSTATUS.PENDINGISSUE;
      psStatusCodeVersNo.versionNo = payslipDtls.versionNo;

      // modify payslip status code
      payslipObj.modifyStatusCode(payslipKey, psStatusCodeVersNo);

    } catch (final curam.util.exception.RecordNotFoundException e) {// ignore
      // exceptions for
      // this type
    }

    iliFinInstructID.finInstructionID = paymentDetailsSummary.finInstructionID;

    iliCaseIDList = instructionLineItemObj.searchForCaseIDByFinInstructID(
      iliFinInstructID);

    // based on domain CASE_ID
    long lastCaseID = 0;

    for (int i = 0; i < iliCaseIDList.dtls.size(); i++) {

      if (iliCaseIDList.dtls.item(i).caseID != lastCaseID) {

        paymentApprovalEventDtls.caseID = iliCaseIDList.dtls.item(i).caseID;
        paymentApprovalEventDtls.approvalDate = paymentDetailsSummary.approvalDate;

        paymentApprovalEventDtls.userName = curam.util.transaction.TransactionInfo.getProgramUser();

        paymentApprovalEventDtls.approvalReason = paymentDetailsSummary.reasonText;

        maintainPaymentApprovalEventObj.insertPaymentApprovalEvent(
          paymentApprovalEventDtls);

        paymentEventDetails.caseID = iliCaseIDList.dtls.item(i).caseID;
        paymentEventDetails.effectiveDate = curam.util.type.Date.getCurrentDate();
        paymentEventDetails.instructionID = paymentDetailsSummary.finInstructionID;

        maintainCasePaymentEventsObj.insertPaymentEvents(paymentEventDetails);

        lastCaseID = iliCaseIDList.dtls.item(i).caseID;
      }
      // BEGIN, CR00022525, AK
      // BEGIN, CR00022728, RR
      // BEGIN, CR00057432, AK
      if (i == iliCaseIDList.dtls.size() - 1) {
        if (paymentEventDetails != null && paymentEventDetails.caseID != 0) {
          // Log Transaction Details
          // BEGIN CR00110127, MR
          // if the payment is sent then log the transaction details
          final LocalisableString descriptionForPaymentsSent = new LocalisableString(BPOCASEEVENTS.PAYMENTS_SENT).arg(
            paymentInstrumentDtls.effectiveDate);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.PAYMENTS_SENT, descriptionForPaymentsSent,
            paymentEventDetails.caseID, paymentDetailsSummary.finInstructionID);

          // if the payment is approved then log the transaction details
          final LocalisableString descriptionForPaymentApproved = new LocalisableString(BPOCASEEVENTS.PAYMENT_APPROVED).arg(
            paymentInstructionDtls.creationDate);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.PAYMENT_APPROVED,
            descriptionForPaymentApproved, paymentEventDetails.caseID,
            paymentDetailsSummary.finInstructionID);
          // END CR00110127
        }
      }
      // END, CR00057432
      // END, CR00022728
      // END, CR00022525
    }

  }

}
