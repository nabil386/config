/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CurrencyExchangeDtls;
import curam.core.struct.CurrencyExchangeKey;
import curam.core.struct.FinancialItemDetails;
import curam.core.struct.InstructionLineItemDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Code to get financial item currency.
 */
public abstract class GetFinancialItemCurrency extends curam.core.base.GetFinancialItemCurrency {

  // ___________________________________________________________________________
  /**
   * To retrieve the foreign currency details where currency type differs from
   * base currency.
   *
   * @param instructionLineItemDtls Instruction Line Item details
   * @param financialItemDetails Financial item details
   */
  @Override
  public void getCurrencyDetails(
    InstructionLineItemDtls instructionLineItemDtls,
    FinancialItemDetails financialItemDetails) throws AppException,
      InformationalException {

    // currencyExchange manipulation variables
    final curam.core.intf.CurrencyExchange currencyExchangeObj = curam.core.fact.CurrencyExchangeFactory.newInstance();
    // BEGIN, CR00052124, NRV
    // BEGIN, HARP 68631, GSP
    // currencyExchange details
    CurrencyExchangeDtls currencyExchangeDtls;

    // currencyExchange manipulation variables
    final CurrencyExchangeKey currencyExchangeKey = new CurrencyExchangeKey();

    // set key to read currencyExchange entity
    currencyExchangeKey.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;

    // read currencyExchange entity
    try {
      currencyExchangeDtls = currencyExchangeObj.read(currencyExchangeKey);

    } catch (final curam.util.exception.RecordNotFoundException rnfe) {
      throw rnfe;
    }

    if (currencyExchangeDtls.rate == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERALADMIN.ERR_CURRENCYEXCHANGE_FV_RATE_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          5);
    }

    double foreignCurrencyValue; // foreign currency variable

    curam.util.type.Money foreignAmount; // Foreign currency amount

    // calculate foreign currency amount based on rate
    foreignCurrencyValue = instructionLineItemDtls.amount.getValue()
      * currencyExchangeDtls.rate;

    foreignAmount = new curam.util.type.Money(foreignCurrencyValue);

    final AppException inf = new AppException(
      curam.message.BPOVIEWCONCERNACCOUNT.INF_FOREIGN_CURRENCY);

    inf.arg(currencyExchangeDtls.currencyTypeCode);
    inf.arg(currencyExchangeDtls.rate);
    inf.arg(foreignAmount.getValue());
    // END, HARP 68631
    // END, CR00052124
    // BEGIN, CR00163236, CL
    financialItemDetails.foreignCurrency = inf.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236

  }

}
