/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008-2019. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.CASECATEGORY;
import curam.codetable.CASEGROUPTYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLEALTERNATEID;
import curam.codetable.CONCERNROLESEARCHALTERNATEID;
import curam.codetable.INVESTIGATECONFIGTYPE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESOLUTIONSTATUSCODE;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.SERVICEPLANTYPE;
import curam.core.fact.MaintainCaseFactory;
import curam.core.intf.MaintainCase;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.CaseParticipantRoleTypeNameDtls1;
import curam.core.sl.entity.struct.CaseParticipantRoleTypeNameDtls1List;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.struct.SQLStatement;
import curam.core.sl.util.impl.CommonUtils;
import curam.core.struct.CaseGroupEligibleMembersDetails1;
import curam.core.struct.CaseGroupEligibleMembersDetails1List;
import curam.core.struct.CaseGroupsCaseIDAndTypeKey;
import curam.core.struct.CaseIDAndRecordStatus;
import curam.core.struct.CaseIDAndTypeCodeKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseSearchCriteria;
import curam.core.struct.CaseSearchCriteria1;
import curam.core.struct.CaseSearchCriteriaWithMultiStatus;
import curam.core.struct.CaseSearchDetails;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSearchList;
import curam.core.struct.CaseSearchList1;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DatabaseCaseSearchKey;
import curam.core.struct.DatabaseCaseSearchMultiStatusKey;
import curam.core.struct.DatabaseInvestigationMultiStatusSearchKey;
import curam.core.struct.DatabaseInvestigationSearchKey;
import curam.core.struct.InvestigationSearchCriteria;
import curam.core.struct.InvestigationSearchDetails;
import curam.core.struct.InvestigationSearchDetailsList;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.SearchMessageDtls;
import curam.core.struct.UsersKey;
import curam.message.GENERAL;
import curam.message.GENERALSEARCH;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.List;

/**
 * Case search in Database
 *
 */
public abstract class DatabaseCaseSearch
  extends curam.core.base.DatabaseCaseSearch {

  /**
   * The names of case status fields in the search criteria struct.
   */
  private static final String[] kStatusFields =
    {"status", "status2", "status3", "status4", "status5", "status6",
      "status7", "status8", "status9" };

  /**
   * The number of case status fields in the search criteria struct.
   */
  private static final int kNumStatusFields = 9;

  // BEGIN, CR00342605, VT

  // Holds the case search maximum value which is read from
  // ENV_CASESEARCHMAXIMUM.
  private int caseSearchMaximum = 0;

  // Holds the number of cases searched.
  private int caseSearchCount = 0;

  // Holds the number of investigations searched.
  private int investigationSearchCount = 0;

  // END, CR00342605
  // BEGIN, CR00349272, VT
  // Holds the readMultiMax value which is read from curam.db.readMultiMax.
  private int readMultiMax = 0;

  // END, CR00349272

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * @param caseSearchCriteria data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}.
   * This method has been deprecated to introduce new case search enhancements.
   *
   * Method to perform a case search
   */
  @Deprecated
  @Override
  public CaseSearchList search(final CaseSearchCriteria caseSearchCriteria)
    throws AppException, InformationalException {

    // Return struct
    final CaseSearchList caseSearchList = new CaseSearchList();

    // Return struct from data access API
    // BEGIN, CR00232051, GD
    CuramValueList<CaseSearchDetails> curamValueList =
      new CuramValueList<CaseSearchDetails>(CaseSearchDetails.class);

    // END, CR00232051

    // If the reference number is specified no need to process the complicated
    // query
    if (caseSearchCriteria.caseReference.length() == 0) {

      try {

        // Build SQL
        final StringBuffer finalBuf = new StringBuffer();
        final StringBuffer selectBuf = new StringBuffer();
        final StringBuffer intoBuf = new StringBuffer();
        final StringBuffer fromBuf = new StringBuffer();
        final StringBuffer whereBuf = new StringBuffer();

        selectBuf.append("SELECT CaseHeader.caseReference, ");
        selectBuf.append("ConcernRole.concernRoleName, ");
        selectBuf.append("ConcernRole.primaryAlternateID, ");
        selectBuf.append("CaseHeader.caseTypeCode, ");
        selectBuf
          .append("CaseHeader.registrationDate, CaseHeader.startDate, ");
        selectBuf.append("CaseHeader.statusCode, CaseHeader.caseID, ");
        selectBuf
          .append("CaseHeader.concernRoleID, CaseHeader.integratedCaseID ");
        intoBuf.append("INTO :caseReference, :concernRoleName, ");
        intoBuf.append(":primaryAlternateID, :caseTypeCode, ");
        intoBuf.append(":registrationDate, :startDate, ");
        intoBuf.append(":statusCode, :caseID, :concernRoleID, ");
        intoBuf.append(":integratedCaseID ");
        fromBuf.append("FROM CaseHeader, ConcernRole ");
        whereBuf.append("WHERE CaseHeader.concernRoleID = ");
        whereBuf.append("ConcernRole.concernRoleID");

        if (caseSearchCriteria.concernRoleID != 0) {

          whereBuf.append(" AND ConcernRole.concernRoleID = :concernRoleID");
        }

        if (caseSearchCriteria.primaryAlternateID.length() > 0) {

          whereBuf.append(" AND ConcernRole.primaryAlternateID ");
          whereBuf.append("= :primaryAlternateID");
        }

        if (!caseSearchCriteria.startDate.isZero()
          && !caseSearchCriteria.endDate.isZero()) {

          whereBuf.append(" AND CaseHeader.startDate >= :startDate ");
          whereBuf.append("AND (CaseHeader.endDate <= :endDate ");
          whereBuf.append("OR CaseHeader.endDate IS NULL)");

        } else if (!caseSearchCriteria.startDate.isZero()) {

          whereBuf.append(" AND CaseHeader.startDate = :startDate");
        } else if (!caseSearchCriteria.endDate.isZero()) {

          whereBuf.append(" AND CaseHeader.endDate = :endDate");
        }

        if (caseSearchCriteria.status.length() > 0) {

          // BEGIN, CR00425263, BD
          whereBuf.append(getStatusCodesClause(caseSearchCriteria.status));
          // BEGIN, CR00425263, BD
        }

        if (caseSearchCriteria.category.length() > 0) {

          whereBuf.append(" AND CaseHeader.caseTypeCode = :category");
        }

        if (caseSearchCriteria.category.length() > 0
          && caseSearchCriteria.type.length() > 0) {

          if (caseSearchCriteria.category.equals(CASETYPECODE.SERVICEPLAN)) {

            // If the case type is service plan,
            // search the service plan tables
            fromBuf.setLength(0);
            fromBuf.append(
              "FROM CaseHeader, ConcernRole, ServicePlanDelivery, ServicePlan ");
            whereBuf
              .append(" AND CaseHeader.caseID = ServicePlanDelivery.caseID");
            whereBuf.append(" AND ServicePlanDelivery.servicePlanID ");
            whereBuf.append(" = ServicePlan.servicePlanID");
            whereBuf.append(" AND ServicePlan.servicePlanType = :type");

          } else if (caseSearchCriteria.category.equals(CASETYPECODE.ISSUE)) {

            // If the case type is issue,
            // search the issue tables
            fromBuf.setLength(0);
            fromBuf.append("FROM CaseHeader, ConcernRole, IssueDelivery ");
            whereBuf.append(" AND CaseHeader.caseID = IssueDelivery.caseID");
            whereBuf.append(" AND IssueDelivery.issueType = :type");
            // BEGIN, CR00113482, JMA
          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.INVESTIGATIONCASE)) {

            // If the case type is investigation,
            // search the investigation table
            fromBuf.setLength(0);
            fromBuf
              .append("FROM CaseHeader, ConcernRole, InvestigationDelivery ");
            whereBuf.append(
              " AND CaseHeader.caseID = InvestigationDelivery.caseID");
            whereBuf
              .append(" AND InvestigationDelivery.investigationType = :type");
            // END, CR00113482
          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

            // If the case type is assessment delivery,
            // search the assessment tables
            fromBuf.setLength(0);
            fromBuf
              .append("FROM CaseHeader, ConcernRole, AssessmentDelivery, ");
            fromBuf.append("AssessmentConfiguration ");
            whereBuf
              .append(" AND CaseHeader.caseID = AssessmentDelivery.caseID");
            whereBuf
              .append(" AND AssessmentDelivery.assessmentConfigurationID = ");
            whereBuf
              .append("AssessmentConfiguration.assessmentConfigurationID");
            whereBuf
              .append(" AND AssessmentConfiguration.assessmentType = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.SCREENINGCASE)) {

            // If the case type is screening,
            // search the screening tables
            fromBuf.setLength(0);
            fromBuf.append("FROM CaseHeader, ConcernRole, Screening, ");
            fromBuf.append("ScreeningConfiguration ");
            whereBuf.append(" AND CaseHeader.caseID = Screening.caseID");
            whereBuf.append(" AND Screening.screeningConfigID = ");
            whereBuf.append("ScreeningConfiguration.screeningConfigID");
            whereBuf.append(" AND ScreeningConfiguration.name = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.INTEGRATEDCASE)) {

            whereBuf.append(" AND CaseHeader.integratedCaseType = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.PRODUCTDELIVERY)
            || caseSearchCriteria.category.equals(CASETYPECODE.LIABILITY)) {

            // If the case type is product delivery or liability,
            // search the product delivery table
            fromBuf.setLength(0);
            fromBuf.append("FROM CaseHeader, ConcernRole, ProductDelivery ");
            whereBuf
              .append(" AND CaseHeader.caseID = ProductDelivery.caseID");
            whereBuf.append(" AND ProductDelivery.productType = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.APPEAL)) {

            // Check the Environmental variable
            // Retrieve the Environment variable for the Appeals component
            // installation setting.
            if (Configuration
              .getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

              // If the case type is appeal, search the appeal table
              fromBuf.setLength(0);
              fromBuf.append("FROM CaseHeader, ConcernRole, Appeal ");
              whereBuf.append(" AND CaseHeader.caseID = Appeal.caseID");
              whereBuf.append(" AND Appeal.appealTypeCode = :type");
            }
          }
        }

        caseSearchCriteria.servicePlanCaseType = CASETYPECODE.SERVICEPLAN;
        caseSearchCriteria.issueCaseType = CASETYPECODE.ISSUE;
        caseSearchCriteria.investigationCaseType =
          CASETYPECODE.INVESTIGATIONCASE;

        // If searching by all four indicators
        if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          whereBuf.append(" AND ((CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID )");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by issues and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by issues and investigations
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations and service plans
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :servicePlanCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations, service plans and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations, service plans and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations, appeals and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans, appeals and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans only
          whereBuf.append(" AND CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType)");

        } else if (caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by issues only
          whereBuf.append(" AND CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType)");

        } else if (caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by appeals only
          whereBuf.append(" AND CaseHeader.appealIndicator = '1'");

        } else if (!caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations only
          whereBuf.append(" AND CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");

        }

        finalBuf.append(selectBuf);
        finalBuf.append(intoBuf);
        finalBuf.append(fromBuf);
        finalBuf.append(whereBuf);

        // Call dynamic SQL API to execute SQL
        // BEGIN, CR00425263, BD
        curamValueList =
          executeNsMulti(curam.core.struct.CaseSearchDetails.class,
            caseSearchCriteria, false, false, finalBuf.toString());
        // END, CR00425263, BD

      } catch (final curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage =
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS
            .getMessageText();

        caseSearchList.messages.dtls.addRef(recordFoundMessage);
      }

    } else {

      final CaseReference caseReference = new CaseReference();

      caseReference.caseReference = caseSearchCriteria.caseReference;

      // Build SQL
      final StringBuffer sBuf = new StringBuffer();

      sBuf.append("SELECT CaseHeader.caseReference, ");
      sBuf.append("ConcernRole.concernRoleName, ");
      sBuf.append("ConcernRole.primaryAlternateID, ");
      sBuf.append("CaseHeader.caseTypeCode, ");
      sBuf.append("CaseHeader.registrationDate, CaseHeader.startDate, ");
      sBuf.append("CaseHeader.statusCode, CaseHeader.caseID, ");
      sBuf.append("CaseHeader.concernRoleID, CaseHeader.integratedCaseID ");
      sBuf.append("INTO :caseReference, :concernRoleName, ");
      sBuf.append(":primaryAlternateID, :caseTypeCode, ");
      sBuf.append(":registrationDate, :startDate, ");
      sBuf.append(":statusCode, :caseID, :concernRoleID, ");
      sBuf.append(":integratedCaseID ");
      sBuf.append("FROM CaseHeader, ConcernRole ");
      sBuf.append("WHERE CaseHeader.caseReference = :caseReference ");
      sBuf.append("AND caseHeader.concernRoleID = ConcernRole.concernRoleID");

      // Call dynamic SQL API to execute SQL
      // BEGIN, CR00425263, BD
      curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
        curam.core.struct.CaseSearchDetails.class, caseReference, false,
        sBuf.toString());
      // END, CR00425263, BD
    }

    // If no search results are found, alert user
    if (curamValueList.isEmpty()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    }

    // BEGIN, CR00088189, CM
    // Gets the environment variable value which the CaseSearchMaximum
    // value is set to.

    // BEGIN, CR00096562 , DJ
    boolean isMaxSet = false;

    if (curam.util.resources.Configuration
      .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM) != null) {
      caseSearchMaximum = curam.util.resources.Configuration
        .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM);
      isMaxSet = true;
    }

    // If the list is greater that the case search maximum value
    if (isMaxSet == true && curamValueList.size() > caseSearchMaximum) {
      // END, CR00096562

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOCASESEARCH.ERR_CASESEARCH_MAXIMUM),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    } else { // END, CR00088189

      // Add the search results to the return list
      for (int i = 0; i < curamValueList.size(); i++) {

        final CaseSearchDetails caseSearchDetails = new CaseSearchDetails();

        // BEGIN, CR00232051, GD
        caseSearchDetails.assign(curamValueList.get(i));
        // END, CR00232051

        // If case is a Product Delivery on an Integrated Case return the
        // Integrated Case ID and Indicator (to indicate that the PD is part of
        // an Integrated Case) to the client
        if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
          && caseSearchDetails.integratedCaseID != 0) {

          caseSearchDetails.integratedCaseID =
            caseSearchDetails.integratedCaseID;
          caseSearchDetails.partOfIntegCaseInd = true;
        }

        // Set the types for each case type
        if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
          || caseSearchDetails.caseTypeCode
            .equals(curam.codetable.CASETYPECODE.LIABILITY)) {

          // productDelivery manipulation variables
          final curam.core.intf.ProductDelivery productDeliveryObj =
            curam.core.fact.ProductDeliveryFactory.newInstance();
          final ProductDeliveryKey productDeliveryKey =
            new ProductDeliveryKey();
          ProductDeliveryDtls productDeliveryDtls;

          // set key to read productDelivery entity
          productDeliveryKey.caseID = caseSearchDetails.caseID;

          // read productDelivery entity
          productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

          // BEGIN, CR00087242, PMD
          // Set the type
          caseSearchDetails.caseCatTypeCode =
            curam.util.type.CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
              productDeliveryDtls.productType);
          // END, CR00087242

        } else if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {

          // CaseHeader manipulation variables
          final curam.core.intf.CaseHeader caseHeaderObj =
            curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseKey caseKey = new CaseKey();

          caseKey.caseID = caseSearchDetails.caseID;

          // BEGIN, CR00087242, PMD
          // Set the type
          caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
            .getOneItem(PRODUCTCATEGORY.TABLENAME, caseHeaderObj
              .readIntegratedCaseType(caseKey).integratedCaseType);
          // END, CR00087242

        } else if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.SERVICEPLAN)) {

          // ServicePlanDelivery manipulation variables
          final curam.serviceplans.sl.entity.intf.ServicePlanDelivery spDeliveryObj =
            curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory
              .newInstance();
          final ServicePlanDeliveryKey spDeliveryKey =
            new ServicePlanDeliveryKey();

          spDeliveryKey.caseID = caseSearchDetails.caseID;

          // BEGIN, CR00087242, PMD
          // Set the type
          caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
            .getOneItem(SERVICEPLANTYPE.TABLENAME, spDeliveryObj
              .readServicePlanType(spDeliveryKey).servicePlanType);
          // END, CR00087242

        } else if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.ISSUE)) {

          // IssueDelivery manipulation variables
          final curam.core.sl.entity.intf.IssueDelivery issueDeliveryObj =
            curam.core.sl.entity.fact.IssueDeliveryFactory.newInstance();
          final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

          issueDeliveryKey.caseID = caseSearchDetails.caseID;

          // BEGIN, CR00087242, PMD
          // Set the type
          caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
            .getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME,
              issueDeliveryObj.readIssueType(issueDeliveryKey).issueType);
          // END, CR00087242
          // BEGIN, CR00113482, JMA
        } else if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.INVESTIGATIONCASE)) {

          // IssueDelivery manipulation variables
          final curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryObj =
            curam.core.sl.entity.fact.InvestigationDeliveryFactory
              .newInstance();
          final InvestigationDeliveryKey investigationDeliveryKey =
            new InvestigationDeliveryKey();

          investigationDeliveryKey.caseID = caseSearchDetails.caseID;

          // Set the type
          caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
            .getOneItem(INVESTIGATECONFIGTYPE.TABLENAME,
              investigationDeliveryObj.readInvestigationType(
                investigationDeliveryKey).investigationType);

          // END, CR00113482
        } else if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.ASSESSMENTDELIVERY)) {

          // AssessmentDelivery manipulation variables
          final curam.core.sl.entity.intf.AssessmentDelivery assessmentDeliveryObj =
            curam.core.sl.entity.fact.AssessmentDeliveryFactory.newInstance();
          final AssessmentDeliveryKey assessmentDeliveryKey =
            new AssessmentDeliveryKey();

          assessmentDeliveryKey.caseID = caseSearchDetails.caseID;

          // BEGIN, CR00087242, PMD
          // Set the type
          caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
            .getOneItem(ASSESSMENTTYPE.TABLENAME, assessmentDeliveryObj
              .readAssessmentType(assessmentDeliveryKey).assessmentType);
          // END, CR00087242

        } else if (caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.SCREENINGCASE)) {

          // Screening manipulation variables
          final curam.core.sl.entity.intf.Screening screeningObj =
            curam.core.sl.entity.fact.ScreeningFactory.newInstance();
          final CaseKeyStruct caseKey = new CaseKeyStruct();

          caseKey.caseID = caseSearchDetails.caseID;

          // BEGIN, CR00087242, PMD
          // Set the type
          caseSearchDetails.caseCatTypeCode =
            curam.util.type.CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
              screeningObj.readName(caseKey).name);
          // END, CR00087242, PMD

        } else {

          caseSearchDetails.caseCatTypeCode = "";
        }

        // Apply security restrictions
        restrictResults(caseSearchDetails);

        if (caseSearchDetails.caseReference != null) {
          caseSearchList.searchDtls.addRef(caseSearchDetails);
        }
      }
    }
    return caseSearchList;
  }

  // END, CR00201195

  // ___________________________________________________________________________
  /**
   * Method to perform a case search
   *
   * @param caseSearchCriteria data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public CaseSearchList
    searchCurrentUserCasesOnly(final CaseSearchCriteria caseSearchCriteria)
      throws AppException, InformationalException {

    // Return struct
    final CaseSearchList caseSearchList = new CaseSearchList();

    // Return struct from data access API
    // BEGIN, CR00232051, GD
    CuramValueList<CaseSearchDetails> curamValueList =
      new CuramValueList<CaseSearchDetails>(CaseSearchDetails.class);
    // END, CR00232051

    // BEGIN, CR00121404, BD
    // if the search is for the current user owned cases only,
    // check that an org object link record exists for that
    // username before adding the criteria.
    boolean searchCurrentUsersCasesOnlyInd = false;

    final OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();

    final UsersKey key = new UsersKey();

    key.userName = TransactionInfo.getProgramUser();

    final NotFoundIndicator record = new NotFoundIndicator();

    final OrgObjectLinkDtls orgObjectLinkDtls =
      orgObjectLinkObj.readByUsername(record, key);

    if (!record.isNotFound()) {
      searchCurrentUsersCasesOnlyInd = true;
    }
    // END, CR00121404

    // If the reference number is specified no need to process the complicated
    // query
    if (caseSearchCriteria.caseReference.length() == 0) {

      try {

        // Build SQL
        final StringBuffer finalBuf = new StringBuffer();
        final StringBuffer selectBuf = new StringBuffer();
        final StringBuffer intoBuf = new StringBuffer();
        final StringBuffer fromBuf = new StringBuffer();
        final StringBuffer whereBuf = new StringBuffer();

        selectBuf.append("SELECT CaseHeader.caseReference, ");
        selectBuf.append("ConcernRole.concernRoleName, ");
        selectBuf.append("ConcernRole.primaryAlternateID, ");
        selectBuf.append("CaseHeader.caseTypeCode, ");
        selectBuf
          .append("CaseHeader.registrationDate, CaseHeader.startDate, ");
        selectBuf.append("CaseHeader.statusCode, CaseHeader.caseID, ");
        selectBuf
          .append("CaseHeader.concernRoleID, CaseHeader.integratedCaseID ");
        intoBuf.append("INTO :caseReference, :concernRoleName, ");
        intoBuf.append(":primaryAlternateID, :caseTypeCode, ");
        intoBuf.append(":registrationDate, :startDate, ");
        intoBuf.append(":statusCode, :caseID, :concernRoleID, ");
        intoBuf.append(":integratedCaseID ");
        fromBuf.append("FROM CaseHeader, ConcernRole ");
        whereBuf.append("WHERE CaseHeader.concernRoleID = ");
        whereBuf.append("ConcernRole.concernRoleID");

        if (searchCurrentUsersCasesOnlyInd) {
          whereBuf.append(" AND CaseHeader.ownerOrgObjectLinkID = ");
          whereBuf.append(orgObjectLinkDtls.orgObjectLinkID);
        }

        if (caseSearchCriteria.concernRoleID != 0) {

          whereBuf.append(" AND ConcernRole.concernRoleID = :concernRoleID");
        }

        if (caseSearchCriteria.primaryAlternateID.length() > 0) {

          whereBuf.append(" AND ConcernRole.primaryAlternateID ");
          whereBuf.append("= :primaryAlternateID");
        }

        if (!caseSearchCriteria.startDate.isZero()) {

          whereBuf.append(" AND CaseHeader.startDate >= :startDate ");
        }

        if (!caseSearchCriteria.endDate.isZero()) {

          // BEGIN, CR00122286, SPD
          whereBuf.append(" AND CaseHeader.endDate <= :endDate");
          // END, CR00122286
        }

        if (caseSearchCriteria.status.length() > 0) {
          // BEGIN, CR00425263, BD
          whereBuf.append(getStatusCodesClause(caseSearchCriteria.status));
          // END, CR00425263, BD
        }

        if (caseSearchCriteria.category.length() > 0) {

          whereBuf.append(" AND CaseHeader.caseTypeCode = :category");
        }

        if (caseSearchCriteria.category.length() > 0
          && caseSearchCriteria.type.length() > 0) {

          if (caseSearchCriteria.category.equals(CASETYPECODE.SERVICEPLAN)) {

            // If the case type is service plan,
            // search the service plan tables
            fromBuf.setLength(0);
            fromBuf.append(
              "FROM CaseHeader, ConcernRole, ServicePlanDelivery, ServicePlan ");
            whereBuf
              .append(" AND CaseHeader.caseID = ServicePlanDelivery.caseID");
            whereBuf.append(" AND ServicePlanDelivery.servicePlanID ");
            whereBuf.append(" = ServicePlan.servicePlanID");
            whereBuf.append(" AND ServicePlan.servicePlanType = :type");

          } else if (caseSearchCriteria.category.equals(CASETYPECODE.ISSUE)) {

            // If the case type is issue,
            // search the issue tables
            fromBuf.setLength(0);
            fromBuf.append("FROM CaseHeader, ConcernRole, IssueDelivery ");
            whereBuf.append(" AND CaseHeader.caseID = IssueDelivery.caseID");
            whereBuf.append(" AND IssueDelivery.issueType = :type");
            // BEGIN, CR00113482, JMA
          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.INVESTIGATIONCASE)) {

            // If the case type is investigation,
            // search the investigation table
            fromBuf.setLength(0);
            fromBuf
              .append("FROM CaseHeader, ConcernRole, InvestigationDelivery ");
            whereBuf.append(
              " AND CaseHeader.caseID = InvestigationDelivery.caseID");
            whereBuf
              .append(" AND InvestigationDelivery.investigationType = :type");
            // END, CR00113482
          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

            // If the case type is assessment delivery,
            // search the assessment tables
            fromBuf.setLength(0);
            fromBuf
              .append("FROM CaseHeader, ConcernRole, AssessmentDelivery, ");
            fromBuf.append("AssessmentConfiguration ");
            whereBuf
              .append(" AND CaseHeader.caseID = AssessmentDelivery.caseID");
            whereBuf
              .append(" AND AssessmentDelivery.assessmentConfigurationID = ");
            whereBuf
              .append("AssessmentConfiguration.assessmentConfigurationID");
            whereBuf
              .append(" AND AssessmentConfiguration.assessmentType = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.SCREENINGCASE)) {

            // If the case type is screening,
            // search the screening tables
            fromBuf.setLength(0);
            fromBuf.append("FROM CaseHeader, ConcernRole, Screening, ");
            fromBuf.append("ScreeningConfiguration ");
            whereBuf.append(" AND CaseHeader.caseID = Screening.caseID");
            whereBuf.append(" AND Screening.screeningConfigID = ");
            whereBuf.append("ScreeningConfiguration.screeningConfigID");
            whereBuf.append(" AND ScreeningConfiguration.name = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.INTEGRATEDCASE)) {

            whereBuf.append(" AND CaseHeader.integratedCaseType = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.PRODUCTDELIVERY)
            || caseSearchCriteria.category.equals(CASETYPECODE.LIABILITY)) {

            // If the case type is product delivery or liability,
            // search the product delivery table
            fromBuf.setLength(0);
            fromBuf.append("FROM CaseHeader, ConcernRole, ProductDelivery ");
            whereBuf
              .append(" AND CaseHeader.caseID = ProductDelivery.caseID");
            whereBuf.append(" AND ProductDelivery.productType = :type");

          } else if (caseSearchCriteria.category
            .equals(CASETYPECODE.APPEAL)) {

            // Check the Environmental variable
            // Retrieve the Environment variable for the Appeals component
            // installation setting.
            if (Configuration
              .getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

              // If the case type is appeal, search the appeal table
              fromBuf.setLength(0);
              fromBuf.append("FROM CaseHeader, ConcernRole, Appeal ");
              whereBuf.append(" AND CaseHeader.caseID = Appeal.caseID");
              whereBuf.append(" AND Appeal.appealTypeCode = :type");
            }
          }
        }

        caseSearchCriteria.servicePlanCaseType = CASETYPECODE.SERVICEPLAN;
        caseSearchCriteria.issueCaseType = CASETYPECODE.ISSUE;
        caseSearchCriteria.investigationCaseType =
          CASETYPECODE.INVESTIGATIONCASE;

        // If searching by all four indicators
        if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          whereBuf.append(" AND ((CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID )");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by issues and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by issues and investigations
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations and service plans
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :servicePlanCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations, service plans and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :issueCaseType)) ");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations, service plans and appeals
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (!caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations, appeals and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (caseSearchCriteria.searchWithServicePlans
          && caseSearchCriteria.searchWithIssues
          && caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans, appeals and issues
          whereBuf.append(" AND (CASEHEADER.CASEID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType) ");
          whereBuf.append("OR CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType) ");
          whereBuf.append("OR CaseHeader.appealIndicator = '1')");

        } else if (caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by service plans only
          whereBuf.append(" AND CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf
            .append("WHERE CaseHeader.caseTypeCode = :servicePlanCaseType)");

        } else if (caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by issues only
          whereBuf.append(" AND CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseHeader.integratedCaseID ");
          whereBuf.append("FROM CaseHeader ");
          whereBuf.append("WHERE CaseHeader.caseTypeCode = :issueCaseType)");

        } else if (caseSearchCriteria.searchWithAppeals
          && !caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithInvestigations) {

          // If searching by appeals only
          whereBuf.append(" AND CaseHeader.appealIndicator = '1'");

        } else if (!caseSearchCriteria.searchWithIssues
          && !caseSearchCriteria.searchWithServicePlans
          && !caseSearchCriteria.searchWithAppeals
          && caseSearchCriteria.searchWithInvestigations) {

          // If searching by investigations only
          whereBuf.append(" AND CaseHeader.caseID IN (");
          whereBuf.append("SELECT CaseRelationship.relatedCaseID ");
          whereBuf.append("FROM CaseRelationship, CaseHeader ");
          whereBuf.append(
            "WHERE CaseHeader.caseTypeCode = :investigationCaseType ");
          whereBuf
            .append("  AND CaseRelationship.caseID = CaseHeader.caseID ) ");

        }

        finalBuf.append(selectBuf);
        finalBuf.append(intoBuf);
        finalBuf.append(fromBuf);
        finalBuf.append(whereBuf);

        // BEGIN, CR00282028, IBM

        //
        // Call dynamic SQL API to execute SQL
        // BEGIN, CR00425263, BD
        curamValueList = executeNsMulti(CaseSearchDetails.class,
          caseSearchCriteria, false, true, finalBuf.toString());
        // END, CR00425263, BD
        // END, CR00282028

      } catch (final curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage =
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS
            .getMessageText();

        caseSearchList.messages.dtls.addRef(recordFoundMessage);
      }

    } else {

      final CaseReference caseReference = new CaseReference();

      caseReference.caseReference = caseSearchCriteria.caseReference;

      // Build SQL
      final StringBuffer sBuf = new StringBuffer();

      sBuf.append("SELECT CaseHeader.caseReference, ");
      sBuf.append("ConcernRole.concernRoleName, ");
      sBuf.append("ConcernRole.primaryAlternateID, ");
      sBuf.append("CaseHeader.caseTypeCode, ");
      sBuf.append("CaseHeader.registrationDate, CaseHeader.startDate, ");
      sBuf.append("CaseHeader.statusCode, CaseHeader.caseID, ");
      sBuf.append("CaseHeader.concernRoleID, CaseHeader.integratedCaseID ");
      sBuf.append("INTO :caseReference, :concernRoleName, ");
      sBuf.append(":primaryAlternateID, :caseTypeCode, ");
      sBuf.append(":registrationDate, :startDate, ");
      sBuf.append(":statusCode, :caseID, :concernRoleID, ");
      sBuf.append(":integratedCaseID ");
      sBuf.append("FROM CaseHeader, ConcernRole ");
      sBuf.append("WHERE CaseHeader.caseReference = :caseReference ");
      sBuf.append("AND caseHeader.concernRoleID = ConcernRole.concernRoleID");

      if (searchCurrentUsersCasesOnlyInd) {
        sBuf.append(" AND CaseHeader.ownerOrgObjectLinkID = ");
        sBuf.append(orgObjectLinkDtls.orgObjectLinkID);
      }

      // BEGIN, CR00282028, IBM
      // Call dynamic SQL API to execute SQL
      curamValueList = DynamicDataAccess.executeNsMulti(
        CaseSearchDetails.class, caseReference, false, true, sBuf.toString());
      // END, CR00282028

    }

    // If no search results are found, alert user
    if (curamValueList.isEmpty()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // BEGIN, CR00088189, CM
    // Gets the environment variable value which the CaseSearchMaximum
    // value is set to.

    // BEGIN, CR00096562 , DJ

    boolean isMaxSet = false;

    if (curam.util.resources.Configuration
      .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM) != null) {
      caseSearchMaximum = curam.util.resources.Configuration
        .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM);
      isMaxSet = true;
    }

    // BEGIN, CR00274833, ELG
    int maxCount = 0;

    // If the list is greater that the case search maximum value
    if (isMaxSet == true && curamValueList.size() > caseSearchMaximum) {
      // END, CR00096562

      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();

      final AppException ae =
        new AppException(GENERALSEARCH.INF_SEARCH_MAXIMUM_EXCEEDED);

      ae.arg(caseSearchMaximum);
      ae.arg(curamValueList.size());
      ae.arg(caseSearchMaximum);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(ae, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);

      maxCount = caseSearchMaximum;

    } else {
      maxCount = curamValueList.size();
    }
    // END, CR00274833
    // END, CR00088189

    // BEGIN, CR00274833, ELG
    // Add the search results to the return list
    for (int i = 0; i < maxCount; i++) {
      // END, CR00274833

      final CaseSearchDetails caseSearchDetails = new CaseSearchDetails();

      // BEGIN, CR00232051, GD
      caseSearchDetails.assign(curamValueList.get(i));
      // END, CR00232051

      // If case is a Product Delivery on an Integrated Case return the
      // Integrated Case ID and Indicator (to indicate that the PD is part of
      // an Integrated Case) to the client
      if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
        && caseSearchDetails.integratedCaseID != 0) {

        caseSearchDetails.integratedCaseID =
          caseSearchDetails.integratedCaseID;
        caseSearchDetails.partOfIntegCaseInd = true;
      }

      // Set the types for each case type
      if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
        || caseSearchDetails.caseTypeCode
          .equals(curam.codetable.CASETYPECODE.LIABILITY)) {

        // productDelivery manipulation variables
        final curam.core.intf.ProductDelivery productDeliveryObj =
          curam.core.fact.ProductDeliveryFactory.newInstance();
        final ProductDeliveryKey productDeliveryKey =
          new ProductDeliveryKey();
        ProductDeliveryDtls productDeliveryDtls;

        // set key to read productDelivery entity
        productDeliveryKey.caseID = caseSearchDetails.caseID;

        // read productDelivery entity
        productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

        // BEGIN, CR00087242, PMD
        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
          .getOneItem(PRODUCTTYPE.TABLENAME, productDeliveryDtls.productType);
        // END, CR00087242

      } else if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {

        // CaseHeader manipulation variables
        final curam.core.intf.CaseHeader caseHeaderObj =
          curam.core.fact.CaseHeaderFactory.newInstance();
        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = caseSearchDetails.caseID;

        // BEGIN, CR00087242, PMD
        // Set the type
        caseSearchDetails.caseCatTypeCode =
          curam.util.type.CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
            caseHeaderObj.readIntegratedCaseType(caseKey).integratedCaseType);
        // END, CR00087242

      } else if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery manipulation variables
        final curam.serviceplans.sl.entity.intf.ServicePlanDelivery spDeliveryObj =
          curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanDeliveryKey spDeliveryKey =
          new ServicePlanDeliveryKey();

        spDeliveryKey.caseID = caseSearchDetails.caseID;

        // BEGIN, CR00087242, PMD
        // Set the type
        caseSearchDetails.caseCatTypeCode =
          curam.util.type.CodeTable.getOneItem(SERVICEPLANTYPE.TABLENAME,
            spDeliveryObj.readServicePlanType(spDeliveryKey).servicePlanType);
        // END, CR00087242

      } else if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.ISSUE)) {

        // IssueDelivery manipulation variables
        final curam.core.sl.entity.intf.IssueDelivery issueDeliveryObj =
          curam.core.sl.entity.fact.IssueDeliveryFactory.newInstance();
        final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

        issueDeliveryKey.caseID = caseSearchDetails.caseID;

        // BEGIN, CR00087242, PMD
        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
          .getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME,
            issueDeliveryObj.readIssueType(issueDeliveryKey).issueType);
        // END, CR00087242
        // BEGIN, CR00113482, JMA
      } else if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.INVESTIGATIONCASE)) {

        // IssueDelivery manipulation variables
        final curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryObj =
          curam.core.sl.entity.fact.InvestigationDeliveryFactory
            .newInstance();
        final InvestigationDeliveryKey investigationDeliveryKey =
          new InvestigationDeliveryKey();

        investigationDeliveryKey.caseID = caseSearchDetails.caseID;

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
          .getOneItem(INVESTIGATECONFIGTYPE.TABLENAME,
            investigationDeliveryObj.readInvestigationType(
              investigationDeliveryKey).investigationType);

        // END, CR00113482
      } else if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.ASSESSMENTDELIVERY)) {

        // AssessmentDelivery manipulation variables
        final curam.core.sl.entity.intf.AssessmentDelivery assessmentDeliveryObj =
          curam.core.sl.entity.fact.AssessmentDeliveryFactory.newInstance();
        final AssessmentDeliveryKey assessmentDeliveryKey =
          new AssessmentDeliveryKey();

        assessmentDeliveryKey.caseID = caseSearchDetails.caseID;

        // BEGIN, CR00087242, PMD
        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable
          .getOneItem(ASSESSMENTTYPE.TABLENAME, assessmentDeliveryObj
            .readAssessmentType(assessmentDeliveryKey).assessmentType);
        // END, CR00087242

      } else if (caseSearchDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.SCREENINGCASE)) {

        // Screening manipulation variables
        final curam.core.sl.entity.intf.Screening screeningObj =
          curam.core.sl.entity.fact.ScreeningFactory.newInstance();
        final CaseKeyStruct caseKey = new CaseKeyStruct();

        caseKey.caseID = caseSearchDetails.caseID;

        // BEGIN, CR00087242, PMD
        // Set the type
        caseSearchDetails.caseCatTypeCode =
          curam.util.type.CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
            screeningObj.readName(caseKey).name);
        // END, CR00087242, PMD

      } else {

        caseSearchDetails.caseCatTypeCode = "";
      }

      // Apply security restrictions
      restrictResults(caseSearchDetails);

      if (caseSearchDetails.caseReference != null) {
        caseSearchList.searchDtls.addRef(caseSearchDetails);
      }
    }

    return caseSearchList;
  }

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * @param caseSearchDetails the case search result
   * @deprecated Since Curam 6.0, replaced by {@link #restrictResults1()}.
   * This method has been deprecated to introduce new case search enhancements.
   *
   * Method to apply security restrictions to case search results
   */
  @Override
  @Deprecated
  public void restrictResults(final CaseSearchDetails caseSearchDetails)
    throws AppException, InformationalException {

    // Security variables
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    // BEGIN, CR00226315, PM
    caseSecurityCheckKey.caseID = caseSearchDetails.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    if (dataBasedSecurityResult.restricted) {

      caseSearchDetails.startDate = curam.util.type.Date.kZeroDate;
      caseSearchDetails.registrationDate = curam.util.type.Date.kZeroDate;
      caseSearchDetails.caseTypeCode = CuramConst.gkEmpty;
      caseSearchDetails.statusCode = CuramConst.gkEmpty;
      caseSearchDetails.primaryAlternateID = CuramConst.gkRestricted;
      caseSearchDetails.concernRoleName = CuramConst.gkRestricted;
      caseSearchDetails.productTypeCode = CuramConst.gkEmpty;
      caseSearchDetails.restricted = true;
      return;
    }

    if (!dataBasedSecurityResult.result) {

      caseSearchDetails.caseReference = null;
    }
  }

  // END, CR00226315
  // END, CR00201195

  // BEGIN, CR00231396, ZV
  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * Method to perform a case search.
   * Method replaces {@link #search()} but is not backward compatible because
   * a) old method returns cases only for primary alternate id, new method
   * returns cases for all alternate ids,
   * b) old methods returns cases only where concern role is primary client,
   * new method returns cases where concern role is any case participant role
   * for a case.
   * Before returning the list of cases found, if
   * primaryclient.display.caselistpages.caseclients is set to true
   * the info needed to populate the client's column is retrieved.
   *
   *
   * @param caseSearchCriteria data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @throws AppException Generic Exception Signature.
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If case search results exceeds case search maximum value.
   */
  @Override
  public CaseSearchList1 search1(final CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    // BEGIN, CR00342605, VT
    caseSearchCount = 0;
    // END, CR00342605

    // BEGIN, CR00349272, VT
    readMultiMax = Configuration.getReadMultiMax();
    // END, CR00349272

    // Gets the environment variable value which the CaseSearchMaximum
    // value is set to.
    boolean isMaxSet = false;

    if (curam.util.resources.Configuration
      .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM) != null) {
      caseSearchMaximum = curam.util.resources.Configuration
        .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM);

    }
    // BEGIN, CR00349272, VT
    // BEGIN, CR00359339, VT
    // The case search maximum value should be ignored,
    // if it is greater than readMultiMax value.
    if (0 != readMultiMax && caseSearchMaximum > readMultiMax) {
      caseSearchMaximum = readMultiMax;
    } else {
      isMaxSet = true;
    }
    // END, CR00359339
    // END, CR00349272

    // BEGIN, CR00245352, ZV
    if (caseSearchCriteria.caseReference.length() > 0) {
      final DatabaseCaseSearchKey databaseKey = new DatabaseCaseSearchKey();

      databaseKey.caseReference = caseSearchCriteria.caseReference;

      caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);
    } else if (caseSearchCriteria.ownerList.length() > 0) {
      // END, CR00245352
      caseList.searchDtls
        .addAll(searchCaseByOrgObject(caseSearchCriteria).searchDtls);
    } else if (caseSearchCriteria.statusList.length() > 0) {
      caseList.searchDtls
        .addAll(searchCaseByStatus(caseSearchCriteria).searchDtls);
    } else if (caseSearchCriteria.categoryTypeList.length() > 0) {
      caseList.searchDtls
        .addAll(searchCaseByCategoryType(caseSearchCriteria).searchDtls);
    } else if (caseSearchCriteria.categoryList.length() > 0) {
      caseList.searchDtls
        .addAll(searchCaseByCategory(caseSearchCriteria).searchDtls);
    } else if (caseSearchCriteria.alternateID.length() > 0) {
      caseList.searchDtls
        .addAll(searchCaseByAlternateID(caseSearchCriteria).searchDtls);
    } else {
      final DatabaseCaseSearchKey databaseKey =
        assignCaseSearchCriteria(caseSearchCriteria);

      caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);
    }

    // BEGIN, CR00274833, ELG
    CaseSearchList1 caseListRet;

    // BEGIN, CR00342605, VT
    if (true == isMaxSet && caseSearchMaximum < caseSearchCount) {

      final AppException ae =
        new AppException(GENERALSEARCH.INF_SEARCH_MAXIMUM_LIMIT_EXCEEDED);

      ae.arg(caseSearchMaximum);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(ae, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    caseListRet = caseList;
    if (Configuration.getBooleanProperty(EnvVars.ENV_DISPLAY_CASE_CLIENTS)) {
      addClientsInformation(caseListRet);
    }
    return caseListRet;

    // END, CR00342605
    // END, CR00274833

  }

  // ___________________________________________________________________________
  /**
   * Method to apply security restrictions to case search results
   *
   * @param caseSearchDetails the case search result
   */
  @Override
  public void restrictResults1(final CaseSearchDetails1 caseSearchDetails)
    throws AppException, InformationalException {

    // Security variables
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    // BEGIN, CR00226315, PM
    caseSecurityCheckKey.caseID = caseSearchDetails.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    if (dataBasedSecurityResult.restricted) {

      caseSearchDetails.startDate = curam.util.type.Date.kZeroDate;
      caseSearchDetails.caseTypeCode = CuramConst.gkEmpty;
      caseSearchDetails.statusCode = CuramConst.gkEmpty;
      caseSearchDetails.concernRoleName = CuramConst.gkRestricted;
      // BEGIN, CR00243722, ZV
      caseSearchDetails.caseReference = CuramConst.gkRestricted;
      caseSearchDetails.caseCatTypeCode = CuramConst.gkRestricted;
      // END, CR00243722
      caseSearchDetails.participantCount = 0;
      caseSearchDetails.restricted = true;
      return;
    }

    if (!dataBasedSecurityResult.result) {
      caseSearchDetails.caseReference = null;
    }
    // END, CR00226315
  }

  // ___________________________________________________________________________
  /**
   * Method to apply common logic to case search details.
   *
   * @param caseSearchDetails The case search result details
   */
  @Override
  public void processSearchDetails(final CaseSearchDetails1 caseSearchDetails)
    throws AppException, InformationalException {

    // Set the types for each case type
    final MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
    final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey =
      new CaseIDAndTypeCodeKey();

    caseIDAndTypeCodeKey.caseTypeCode = caseSearchDetails.caseTypeCode;
    caseIDAndTypeCodeKey.caseID = caseSearchDetails.caseID;

    caseSearchDetails.caseCatTypeCode = maintainCaseObj
      .getCaseTypeDescription(caseIDAndTypeCodeKey).caseTypeDesc;

    // Apply security restrictions
    restrictResults1(caseSearchDetails);

  }

  // END, CR00201195

  // BEGIN, CR00204411, ZV
  // ___________________________________________________________________________
  /**
   * Method to perform an investigation search.
   *
   * @param searchCriteria data on which the search will be based
   *
   * @return The details of any investigation records found
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If investigation search results exceeds search maximum value.
   */
  @Override
  public InvestigationSearchDetailsList
    investigationSearch(final InvestigationSearchCriteria searchCriteria)
      throws AppException, InformationalException {

    // BEGIN, CR00342605, VT
    investigationSearchCount = 0;
    // END, CR00342605

    final InvestigationSearchDetailsList investigationList =
      new InvestigationSearchDetailsList();

    // Gets the environment variable value which the CaseSearchMaximum
    // value is set to.

    boolean isMaxSet = false;

    // BEGIN, CR00349272, VT
    readMultiMax = Configuration.getReadMultiMax();
    // END, CR00349272

    if (curam.util.resources.Configuration
      .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM) != null) {
      caseSearchMaximum = curam.util.resources.Configuration
        .getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM);
    }

    // BEGIN, CR00349272, VT
    // BEGIN, CR00359339, VT
    // Case search maximum value should be ignored,
    // if it is greater than readMultiMax value.
    if (0 != readMultiMax && caseSearchMaximum > readMultiMax) {
      caseSearchMaximum = readMultiMax;
    } else {
      isMaxSet = true;
    }
    // END, CR00359339
    // END, CR00349272

    // BEGIN, CR00245352, ZV
    if (searchCriteria.caseReference.length() > 0) {
      final DatabaseInvestigationSearchKey databaseKey =
        new DatabaseInvestigationSearchKey();

      databaseKey.caseReference = searchCriteria.caseReference;

      investigationList.searchDtls
        .addAll(searchInvestigationByKey(databaseKey).searchDtls);
    } else if (searchCriteria.ownerList.length() > 0) {
      // END, CR00245352
      investigationList.searchDtls
        .addAll(searchInvestigationByOrgObject(searchCriteria).searchDtls);
    } else if (searchCriteria.statusList.length() > 0) {
      investigationList.searchDtls
        .addAll(searchInvestigationByStatus(searchCriteria).searchDtls);
    } else if (searchCriteria.typeList.length() > 0) {
      investigationList.searchDtls
        .addAll(searchInvestigationByType(searchCriteria).searchDtls);
    } else if (searchCriteria.subtypeList.length() > 0) {
      investigationList.searchDtls
        .addAll(searchInvestigationBySubtype(searchCriteria).searchDtls);
    } else if (searchCriteria.alternateID.length() > 0) {
      investigationList.searchDtls
        .addAll(searchInvestigationByAlternateID(searchCriteria).searchDtls);
    } else {
      final DatabaseInvestigationSearchKey databaseKey =
        new DatabaseInvestigationSearchKey();

      databaseKey.assign(searchCriteria);

      investigationList.searchDtls
        .addAll(searchInvestigationByKey(databaseKey).searchDtls);
    }

    // BEGIN, CR00274833, ELG
    InvestigationSearchDetailsList investigationListRet;

    // BEGIN, CR00342605, VT
    // If the list is greater that the case search maximum value
    if (true == isMaxSet && caseSearchMaximum < investigationSearchCount) {

      final AppException ae =
        new AppException(GENERALSEARCH.INF_SEARCH_MAXIMUM_LIMIT_EXCEEDED);

      ae.arg(caseSearchMaximum);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(ae, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    }
    // END, CR00342605
    investigationListRet = investigationList;

    return investigationListRet;
    // END, CR00274833

  }

  // ___________________________________________________________________________
  /**
   * Method to apply security restrictions to investigation search results
   *
   * @param searchDetails the investigation search result
   */
  @Override
  public void restrictInvestigationResults(
    final InvestigationSearchDetails searchDetails)
    throws AppException, InformationalException {

    // Security variables
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    // BEGIN, CR00226315, PM
    caseSecurityCheckKey.caseID = searchDetails.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    if (dataBasedSecurityResult.restricted) {

      searchDetails.startDate = curam.util.type.Date.kZeroDate;
      searchDetails.investigationType = CuramConst.gkEmpty;
      searchDetails.subtype = CuramConst.gkEmpty;
      searchDetails.resolution = CuramConst.gkEmpty;
      searchDetails.statusCode = CuramConst.gkEmpty;
      searchDetails.concernRoleName = CuramConst.gkRestricted;
      // BEGIN, CR00243722, ZV
      searchDetails.caseReference = CuramConst.gkRestricted;
      searchDetails.investigationType = CuramConst.gkEmpty;
      // END, CR00243722
      searchDetails.allegationParticipantCount = 0;
      searchDetails.restricted = true;
      return;
    }

    if (!dataBasedSecurityResult.result) {
      searchDetails.caseReference = null;
    }
    // END, CR00226315
  }

  // END, CR00204411

  // ___________________________________________________________________________
  /**
   * Format SQL select statement for case search
   *
   * @param key Case search criteria
   *
   * @return SQL select statement for case search
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected SQLStatement formatCaseSQL(final DatabaseCaseSearchKey key)
    throws AppException, InformationalException {

    final SQLStatement sqlStatement = new SQLStatement();

    String selectStr = new String();
    String intoStr = new String();
    String fromStr = new String();
    String whereStr = new String();
    String groupByStr = new String();

    selectStr = "SELECT CaseHeader.caseReference, ";
    selectStr += "ConcernRole.concernRoleName, ";
    selectStr += "ConcernRole.concernRoleType, ";
    selectStr += "CaseHeader.caseTypeCode, CaseHeader.startDate, ";
    selectStr += "CaseHeader.statusCode, CaseHeader.caseID, ";
    selectStr += "CaseHeader.concernRoleID, ";
    selectStr += "COUNT(DISTINCT CPRCount.participantRoleID) ";

    intoStr = "INTO :caseReference, :concernRoleName, ";
    intoStr += ":concernRoleType, ";
    intoStr += ":caseTypeCode, :startDate, ";
    intoStr += ":statusCode, :caseID, :concernRoleID, ";
    intoStr += ":participantCount ";

    fromStr = "FROM CaseHeader, ConcernRole, ";
    fromStr += "CaseParticipantRole CPRCount ";

    whereStr = "WHERE CaseHeader.concernRoleID = ";
    whereStr += "ConcernRole.concernRoleID ";
    whereStr += "AND CPRCount.caseID = CaseHeader.caseID ";
    whereStr += "AND CPRCount.recordStatus = :recordStatus";

    groupByStr = " GROUP BY CaseHeader.caseReference, ";
    groupByStr += "ConcernRole.concernRoleName, ";
    groupByStr += "ConcernRole.concernRoleType, ";
    groupByStr += "CaseHeader.caseTypeCode, ";
    groupByStr += "CaseHeader.startDate, CaseHeader.statusCode, ";
    groupByStr += "CaseHeader.caseID, CaseHeader.concernRoleID";

    if (key.caseReference.length() > 0) {
      whereStr += " AND CaseHeader.caseReference = :caseReference";

      if (key.category.length() > 0 && key.type.length() == 0) {
        whereStr += " AND CaseHeader.caseTypeCode = :category";
      }

      sqlStatement.sqlStatement =
        selectStr + intoStr + fromStr + whereStr + groupByStr;

      return sqlStatement;
    }

    if (key.concernRoleID != 0) {

      fromStr += ", CaseParticipantRole ";
      whereStr += " AND CaseParticipantRole.caseID = CaseHeader.caseID";
      whereStr +=
        " AND CaseParticipantRole.participantRoleID = :concernRoleID";
      whereStr += " AND CaseParticipantRole.recordStatus = :recordStatus";
    }

    if (key.orgObjectLinkID != 0) {

      whereStr += " AND CaseHeader.ownerOrgObjectLinkID = :orgObjectLinkID";
    }

    if (key.status.length() > 0) {
      whereStr += getStatusCodesClause(key.status);
    }

    if (key.alternateID.length() > 0) {

      if (key.alternateIDType.length() > 0) {

        fromStr += ", ConcernRoleAlternateID ";
        fromStr += ", CaseParticipantRole CPRAlternateID ";
        whereStr += " AND CPRAlternateID.caseID = CaseHeader.caseID";
        whereStr += " AND CPRAlternateID.participantRoleID";
        whereStr += "= ConcernRoleAlternateID.concernRoleID";
        whereStr += " AND CPRAlternateID.recordStatus";
        whereStr += "= :recordStatus";
        whereStr += " AND ConcernRoleAlternateID.alternateID ";
        whereStr += "= :alternateID";
        whereStr += " AND ConcernRoleAlternateID.statusCode ";
        whereStr += "= :recordStatus";
        whereStr += " AND ConcernRoleAlternateID.typeCode ";
        whereStr += "= :alternateIDType";
      } else {
        whereStr += " AND ConcernRole.primaryAlternateID ";
        whereStr += "= :alternateID";
      }

    }

    if (!key.startDateFrom.isZero()) {
      whereStr += " AND CaseHeader.startDate >= :startDateFrom ";
    }

    if (!key.startDateTo.isZero()) {
      whereStr += " AND CaseHeader.startDate <= :startDateTo";
    }

    if (!key.endDateFrom.isZero()) {
      if (key.endDateTo.isZero()) {
        whereStr += " AND (CaseHeader.endDate >= :endDateFrom ";
        whereStr += "OR CaseHeader.endDate IS NULL) ";
      } else {
        whereStr += " AND CaseHeader.endDate >= :endDateFrom ";
        whereStr += "AND CaseHeader.endDate <= :endDateTo";
      }
    } else if (!key.endDateTo.isZero()) {
      whereStr += " AND CaseHeader.endDate <= :endDateTo ";
    }
    // END, CR00150153

    if (key.category.length() > 0 && key.type.length() == 0) {

      whereStr += " AND CaseHeader.caseTypeCode = :category";

    } else if (key.category.length() > 0 && key.type.length() > 0) {

      whereStr += " AND CaseHeader.caseID IN (";

      String unionBuf = new String();

      String servicePlanStr = new String();
      String issueStr = new String();
      String investigationStr = new String();
      String assessmentStr = new String();
      String screeningStr = new String();
      String integratedStr = new String();
      String productStr = new String();
      String liabilityStr = new String();
      String appealStr = new String();

      if (key.category.equals(CASETYPECODE.SERVICEPLAN)) {

        if (servicePlanStr.length() == 0) {

          // If the case type is service plan,
          // search the service plan tables
          servicePlanStr += " SELECT CaseHeader.caseID";
          servicePlanStr +=
            " FROM CaseHeader, ServicePlanDelivery, ServicePlan";
          servicePlanStr += " WHERE CaseHeader.caseTypeCode = :category";
          servicePlanStr +=
            " AND CaseHeader.caseID = ServicePlanDelivery.caseID";
          servicePlanStr += " AND ServicePlanDelivery.servicePlanID ";
          servicePlanStr += " = ServicePlan.servicePlanID AND (";

        }

        servicePlanStr += " ServicePlan.servicePlanType = :type OR";

      } else if (key.category.equals(CASETYPECODE.ISSUE)) {

        if (issueStr.length() == 0) {
          // If the case type is issue,
          // search the issue tables
          issueStr += " SELECT CaseHeader.caseID";
          issueStr += " FROM CaseHeader, IssueDelivery";
          issueStr += " WHERE CaseHeader.caseTypeCode = :category";
          issueStr += " AND CaseHeader.caseID = IssueDelivery.caseID AND (";
        }

        issueStr += " IssueDelivery.issueType = :type OR";

      } else if (key.category.equals(CASETYPECODE.INVESTIGATIONCASE)) {

        if (investigationStr.length() == 0) {
          // If the case type is investigation,
          // search the investigation table
          investigationStr += " SELECT CaseHeader.caseID";
          investigationStr += " FROM CaseHeader, InvestigationDelivery";
          investigationStr += " WHERE CaseHeader.caseTypeCode = :category";
          investigationStr +=
            " AND CaseHeader.caseID = InvestigationDelivery.caseID AND (";
        }

        investigationStr +=
          " InvestigationDelivery.investigationType = :type OR";

      } else if (key.category.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

        if (assessmentStr.length() == 0) {
          // If the case type is assessment delivery,
          // search the assessment tables
          assessmentStr += " SELECT CaseHeader.caseID";
          assessmentStr +=
            " FROM CaseHeader, AssessmentDelivery, AssessmentConfiguration";
          assessmentStr += " WHERE CaseHeader.caseTypeCode = :category";
          assessmentStr +=
            " AND CaseHeader.caseID = AssessmentDelivery.caseID";
          assessmentStr +=
            " AND AssessmentDelivery.assessmentConfigurationID = ";
          assessmentStr +=
            "AssessmentConfiguration.assessmentConfigurationID AND (";

        }

        assessmentStr += " AssessmentConfiguration.assessmentType = :type OR";

      } else if (key.category.equals(CASETYPECODE.SCREENINGCASE)) {

        if (screeningStr.length() == 0) {
          // If the case type is screening,
          // search the screening tables
          screeningStr += " SELECT CaseHeader.caseID";
          screeningStr +=
            " FROM CaseHeader, Screening, ScreeningConfiguration";
          screeningStr += " WHERE CaseHeader.caseTypeCode = :category";
          screeningStr += " AND CaseHeader.caseID = Screening.caseID";
          screeningStr += " AND Screening.screeningConfigID = ";
          screeningStr += "ScreeningConfiguration.screeningConfigID AND (";

        }

        screeningStr += " ScreeningConfiguration.name = :type OR";

      } else if (key.category.equals(CASETYPECODE.INTEGRATEDCASE)) {

        if (integratedStr.length() == 0) {

          integratedStr += " SELECT CaseHeader.caseID FROM CaseHeader WHERE";
          integratedStr += " CaseHeader.caseTypeCode = :category AND (";
        }

        integratedStr += " CaseHeader.integratedCaseType = :type OR";

        // BEGIN, CR00166085, ZV
      } else if (key.category.equals(CASETYPECODE.PRODUCTDELIVERY)) {

        if (productStr.length() == 0) {

          // If the case type is product delivery
          // search the product delivery table
          productStr +=
            " SELECT CaseHeader.caseID FROM CaseHeader, ProductDelivery, Product";
          productStr += " WHERE CaseHeader.caseTypeCode = :category ";
          productStr += " AND Product.productID = ProductDelivery.productID";
          productStr +=
            " AND CaseHeader.caseID = ProductDelivery.caseID AND (";
        }

        productStr += " Product.name = :type OR";

      } else if (key.category.equals(CASETYPECODE.LIABILITY)) {

        if (liabilityStr.length() == 0) {

          // If the case type is liability,
          // search the product delivery table
          liabilityStr +=
            " SELECT CaseHeader.caseID FROM CaseHeader, ProductDelivery, Product";
          liabilityStr += " WHERE CaseHeader.caseTypeCode = :category ";
          liabilityStr +=
            " AND Product.productID = ProductDelivery.productID";
          liabilityStr +=
            " AND CaseHeader.caseID = ProductDelivery.caseID AND (";
        }

        liabilityStr += " Product.name = :type OR";

        // END, CR00166085
      } else if (key.category.equals(CASETYPECODE.APPEAL)) {

        // Check the Environmental variable
        // Retrieve the Environment variable for the Appeals component
        // installation setting.
        if (Configuration
          .getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

          if (appealStr.length() == 0) {
            appealStr += " SELECT CaseHeader.caseID FROM CaseHeader, Appeal";
            appealStr += " WHERE CaseHeader.caseTypeCode = :category ";
            appealStr += " AND CaseHeader.caseID = Appeal.caseID AND (";
          }
          appealStr += " AND Appeal.appealTypeCode = :type OR";

        }
      }

      // remove last OR from where statements
      final int kORLength = new String("OR").length();

      if (servicePlanStr.length() > 0) {
        servicePlanStr = servicePlanStr.substring(CuramConst.gkZero,
          servicePlanStr.length() - kORLength);
        servicePlanStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += servicePlanStr;
      }

      if (issueStr.length() > 0) {
        issueStr = issueStr.substring(CuramConst.gkZero,
          issueStr.length() - kORLength);
        issueStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += issueStr;
      }

      if (investigationStr.length() > 0) {
        investigationStr = investigationStr.substring(CuramConst.gkZero,
          investigationStr.length() - kORLength);
        investigationStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += investigationStr;
      }

      if (assessmentStr.length() > 0) {
        assessmentStr = assessmentStr.substring(CuramConst.gkZero,
          assessmentStr.length() - kORLength);
        assessmentStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += assessmentStr;
      }

      if (screeningStr.length() > 0) {
        screeningStr = screeningStr.substring(CuramConst.gkZero,
          screeningStr.length() - kORLength);
        screeningStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += screeningStr;
      }

      if (productStr.length() > 0) {
        productStr = productStr.substring(CuramConst.gkZero,
          productStr.length() - kORLength);
        productStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += productStr;
      }

      // BEGIN, CR00166085, ZV
      if (liabilityStr.length() > 0) {
        liabilityStr = liabilityStr.substring(CuramConst.gkZero,
          liabilityStr.length() - kORLength);
        liabilityStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += liabilityStr;
      }
      // END, CR00166085

      if (integratedStr.length() > 0) {
        integratedStr = integratedStr.substring(CuramConst.gkZero,
          integratedStr.length() - kORLength);
        integratedStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += integratedStr;
      }

      if (appealStr.length() > 0) {
        appealStr = appealStr.substring(CuramConst.gkZero,
          appealStr.length() - kORLength);
        appealStr += " )";

        if (unionBuf.length() > 0) {
          unionBuf += " UNION ";
        }

        unionBuf += appealStr;
      }

      whereStr += unionBuf;
      whereStr += " )";

    }

    if (key.searchWithServicePlans) {
      whereStr += " AND CaseHeader.caseID IN (";
      whereStr += "SELECT CaseHeader.integratedCaseID ";
      whereStr += "FROM CaseHeader ";
      whereStr += "WHERE CaseHeader.caseTypeCode = :servicePlanCaseType)";
    }

    if (key.searchWithIssues) {
      whereStr += " AND CaseHeader.caseID IN (";
      whereStr += "SELECT CaseHeader.integratedCaseID ";
      whereStr += "FROM CaseHeader ";
      whereStr += "WHERE CaseHeader.caseTypeCode = :issueCaseType)";
    }

    if (key.searchWithInvestigations) {
      whereStr += " AND CaseHeader.caseID IN (";
      whereStr += "SELECT CaseHeader.integratedCaseID ";
      whereStr += "FROM CaseHeader ";
      whereStr += "WHERE CaseHeader.caseTypeCode = :investigationCaseType)";
    }

    if (key.searchWithAppeals) {
      whereStr += " AND CaseHeader.appealIndicator = '1'";
    }

    sqlStatement.sqlStatement =
      selectStr + intoStr + fromStr + whereStr + groupByStr;

    return sqlStatement;
  }

  // ___________________________________________________________________________
  /**
   * Format SQL select statement for investigation search
   *
   * @param key Investigation search criteria
   *
   * @return SQL select statement for investigation search
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected SQLStatement
    formatInvestigationSQL(final DatabaseInvestigationSearchKey key)
      throws AppException, InformationalException {

    final SQLStatement sqlStatement = new SQLStatement();

    // Build SQL
    String selectStr = new String();
    String intoStr = new String();
    String fromStr = new String();
    String whereStr = new String();
    String groupByStr = new String();

    selectStr = "SELECT CaseHeader.caseReference, ";
    selectStr += "ConcernRole.concernRoleName, ";
    selectStr += "ConcernRole.concernRoleType, ";
    selectStr += "InvestigationDelivery.investigationType, ";
    selectStr += "InvestigationDelivery.investigationSubtype, ";
    selectStr += "Resolution.resolution, ";
    selectStr += "CaseHeader.startDate, CaseHeader.statusCode, ";
    selectStr += "CaseHeader.caseID, CaseHeader.concernRoleID, ";
    selectStr += "COUNT (DISTINCT APCount.participantRoleID) ";

    intoStr = "INTO :caseReference, :concernRoleName, ";
    intoStr += ":concernRoleType, :investigationType, :subtype, ";
    intoStr += ":resolution, :startDate, :statusCode, ";
    intoStr += ":caseID, :concernRoleID,  ";
    intoStr += ":allegationParticipantCount ";

    fromStr = "FROM CaseHeader, InvestigationDelivery ";
    fromStr += "LEFT OUTER JOIN (SELECT ";
    fromStr += "ResolutionConfiguration.resolution, ";
    fromStr += "Resolution.caseID ";
    fromStr += "FROM InvestigationDelivery, Resolution, ";
    fromStr += "ResolutionConfiguration ";
    fromStr += "WHERE InvestigationDelivery.resolutionStatus =  ";
    fromStr += ":resolutionStatus ";
    fromStr += "AND InvestigationDelivery.caseID = ";
    fromStr += "Resolution.caseID ";
    fromStr += "AND Resolution.resolutionConfigurationID = ";
    fromStr += "ResolutionConfiguration.resolutionConfigurationID ";
    fromStr += "AND Resolution.recordStatus = :recordStatus) ";
    fromStr += "Resolution ON Resolution.caseID = ";
    fromStr += "InvestigationDelivery.caseID ";
    fromStr += "LEFT OUTER JOIN (SELECT Allegation.caseID, ";
    fromStr += "CaseParticipantRole.participantRoleID ";
    fromStr += "FROM Allegation, AllegationRole, ";
    fromStr += "CaseParticipantRole ";
    fromStr += "WHERE Allegation.recordStatus = :recordStatus ";
    fromStr += "AND AllegationRole.caseParticipantRoleID = ";
    fromStr += "CaseParticipantRole.caseParticipantRoleID ";
    // BEGIN, CR00342834, MV
    fromStr += "AND CaseParticipantRole.recordStatus = :recordStatus ";
    fromStr +=
      "AND Allegation.allegationID = AllegationRole.allegationID) APCount ";
    // END, CR00342834
    fromStr += "ON APCount.caseID = InvestigationDelivery.caseID, ";
    fromStr += "ConcernRole ";

    whereStr = "WHERE InvestigationDelivery.caseID = ";
    whereStr += "CaseHeader.caseID ";
    whereStr += "AND CaseHeader.concernRoleID = ";
    whereStr += "ConcernRole.concernRoleID ";

    groupByStr = " GROUP BY CaseHeader.caseReference, ";
    groupByStr += "ConcernRole.concernRoleName, ";
    groupByStr += "ConcernRole.concernRoleType, ";
    groupByStr += "InvestigationDelivery.investigationType, ";
    groupByStr += "InvestigationDelivery.investigationSubtype, ";
    groupByStr += "Resolution.resolution, ";
    groupByStr += "CaseHeader.startDate, CaseHeader.statusCode, ";
    groupByStr += "CaseHeader.caseID, CaseHeader.concernRoleID";

    if (key.caseReference.length() > 0) {
      whereStr += " AND CaseHeader.caseReference = :caseReference";

      sqlStatement.sqlStatement =
        selectStr + intoStr + fromStr + whereStr + groupByStr;

      return sqlStatement;
    }

    if (key.concernRoleID != 0) {
      fromStr += ", CaseParticipantRole ";
      whereStr += " AND CaseParticipantRole.caseID = CaseHeader.caseID";
      whereStr +=
        " AND CaseParticipantRole.participantRoleID = :concernRoleID";
      whereStr += " AND CaseParticipantRole.recordStatus = :recordStatus";
    }

    if (key.orgObjectLinkID != 0) {
      whereStr += " AND CaseHeader.ownerOrgObjectLinkID = :orgObjectLinkID";
    }

    if (key.status.length() > 0) {
      // BEGIN, CR00425263, BD
      whereStr += getStatusCodesClause(key.status);
      // END, CR00425263, BD
    }

    if (key.alternateID.length() > 0) {

      if (key.alternateIDType.length() > 0) {

        fromStr += ", ConcernRoleAlternateID ";
        fromStr += ", CaseParticipantRole CPRAlternateID ";
        whereStr += " AND CPRAlternateID.caseID = CaseHeader.caseID";
        whereStr += " AND CPRAlternateID.participantRoleID";
        whereStr += "= ConcernRoleAlternateID.concernRoleID";
        whereStr += " AND CPRAlternateID.recordStatus";
        whereStr += "= :recordStatus";
        whereStr += " AND ConcernRoleAlternateID.alternateID ";
        whereStr += "= :alternateID";
        whereStr += " AND ConcernRoleAlternateID.statusCode ";
        whereStr += "= :recordStatus";
        whereStr += " AND ConcernRoleAlternateID.typeCode ";
        whereStr += "= :alternateIDType";
      } else {
        whereStr += " AND ConcernRole.primaryAlternateID ";
        whereStr += "= :alternateID";
      }

    }

    if (!key.startDateFrom.isZero()) {
      whereStr += " AND CaseHeader.startDate >= :startDateFrom ";
    }

    if (!key.startDateTo.isZero()) {
      whereStr += " AND CaseHeader.startDate <= :startDateTo";
    }

    if (!key.endDateFrom.isZero()) {
      if (key.endDateTo.isZero()) {
        whereStr += " AND (CaseHeader.endDate >= :endDateFrom ";
        whereStr += "OR CaseHeader.endDate IS NULL) ";
      } else {
        whereStr += " AND CaseHeader.endDate >= :endDateFrom ";
        whereStr += "AND CaseHeader.endDate <= :endDateTo";
      }
    } else if (!key.endDateTo.isZero()) {
      whereStr += " AND CaseHeader.endDate <= :endDateTo ";
    }

    if (key.type.length() > 0) {
      whereStr += " AND InvestigationDelivery.investigationType = :type";
    }

    if (key.subtype.length() > 0) {
      whereStr +=
        " AND InvestigationDelivery.investigationSubtype = :subtype";
    }

    sqlStatement.sqlStatement =
      selectStr + intoStr + fromStr + whereStr + groupByStr;

    return sqlStatement;
  }

  // ___________________________________________________________________________
  /**
   * Performs case search for specified search criteria by single values.
   *
   * @param sqlStatement SQL statement to search cases
   *
   * @param key Contains case search criteria
   * @return Found case details list.
   *
   * @throws AppException Generic Exception Signature.
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If investigation search results exceeds search maximum value.
   */
  @Override
  protected CaseSearchList1 searchCaseByKey(final DatabaseCaseSearchKey key)
    throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    // BEGIN, CR00342605, VT
    if (caseSearchMaximum < caseSearchCount) {
      return caseList;
    }
    // END, CR00342605

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.servicePlanCaseType = CASETYPECODE.SERVICEPLAN;
    key.issueCaseType = CASETYPECODE.ISSUE;
    key.investigationCaseType = CASETYPECODE.INVESTIGATIONCASE;

    CuramValueList<CaseSearchDetails1> curamValueList = null;

    try {

      // BEGIN, CR00282028, IBM
      // Call dynamic SQL API to execute SQL
      // BEGIN, CR00425263, BD
      curamValueList = executeNsMulti(CaseSearchDetails1.class, key, false,
        true, formatCaseSQL(key).sqlStatement);
      // END, CR00425263, BD
      // END, CR00282028

    } catch (final curam.util.exception.ReadmultiMaxException e) {

      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);

      informationalManager.failOperation();
    }

    // BEGIN, CR00342605, VT

    for (final CaseSearchDetails1 caseSearchDetails : curamValueList) {

      if (caseSearchMaximum > caseSearchCount) {
        processSearchDetails(caseSearchDetails);

        if (null != caseSearchDetails.caseReference) {
          caseList.searchDtls.addRef(caseSearchDetails);
        }

      }
      caseSearchCount++;

      if (caseSearchMaximum < caseSearchCount) {
        break;
      }
    }

    return caseList;

    // END, CR00342605
  }

  // ___________________________________________________________________________
  /**
   * Performs investigation search for specified search criteria by single
   * values.
   *
   * @param key Contains investigation search criteria
   *
   * @return Found investigation details list.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException
   * {@link GENERAL#INF_GENERAL_SEARCH_TOO_MANY_RECORDS} -
   * If investigation search results exceeds search maximum value.
   */
  @Override
  protected InvestigationSearchDetailsList
    searchInvestigationByKey(final DatabaseInvestigationSearchKey key)
      throws AppException, InformationalException {

    final InvestigationSearchDetailsList investigationSearchDetailsList =
      new InvestigationSearchDetailsList();

    // BEGIN, CR00342605, VT
    if (caseSearchMaximum < investigationSearchCount) {
      return investigationSearchDetailsList;
    }
    // END, CR00342605

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.resolutionStatus = RESOLUTIONSTATUSCODE.NORMAL;

    CuramValueList<InvestigationSearchDetails> curamValueList = null;

    try {

      // BEGIN, CR00282028, IBM
      // Call dynamic SQL API to execute SQL
      // BEGIN, CR00425263, BD
      curamValueList = executeNsMulti(InvestigationSearchDetails.class, key,
        false, true, formatInvestigationSQL(key).sqlStatement);
      // END, CR00425263, BD
      // END, CR00282028

    } catch (final curam.util.exception.ReadmultiMaxException e) {

      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

      informationalManager.failOperation();
    }

    // BEGIN, CR00342605, VT
    for (final InvestigationSearchDetails investigationSearchDetails : curamValueList) {

      if (caseSearchMaximum > investigationSearchCount) {

        restrictInvestigationResults(investigationSearchDetails);

        if (null != investigationSearchDetails.caseReference) {
          investigationSearchDetailsList.searchDtls
            .addRef(investigationSearchDetails);
        }
      }
      investigationSearchCount++;

      if (caseSearchMaximum < investigationSearchCount) {
        break;
      }
    }
    // END, CR00342605
    return investigationSearchDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Performs investigation search for specified search criteria by owner
   * values.
   *
   * @param key Contains investigation search criteria
   *
   * @return Found investigation details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected InvestigationSearchDetailsList
    searchInvestigationByOrgObject(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    final InvestigationSearchDetailsList investigationList =
      new InvestigationSearchDetailsList();

    if (key.ownerList.length() > 0) {

      final StringList ownerList =
        StringUtil.tabText2StringListWithTrim(key.ownerList);

      for (int i = 0; i < ownerList.size(); i++) {

        final String owner = ownerList.item(i);

        if (owner.length() > 0) {

          final InvestigationSearchCriteria searchKey =
            new InvestigationSearchCriteria();

          searchKey.assign(key);
          searchKey.ownerList = owner;

          if (key.statusList.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByStatus(searchKey).searchDtls);
          } else if (key.typeList.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByType(searchKey).searchDtls);
          } else if (key.subtypeList.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationBySubtype(searchKey).searchDtls);
          } else if (key.alternateID.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByAlternateID(searchKey).searchDtls);
          } else {
            final DatabaseInvestigationSearchKey databaseKey =
              new DatabaseInvestigationSearchKey();

            databaseKey.assign(key);
            databaseKey.orgObjectLinkID = Long.parseLong(owner);

            investigationList.searchDtls
              .addAll(searchInvestigationByKey(databaseKey).searchDtls);
          }
        }
      }
    }

    return investigationList;
  }

  // ___________________________________________________________________________
  /**
   * Performs investigation search for specified search criteria by status
   * values.
   *
   * @param key Contains investigation search criteria
   *
   * @return Found investigation details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected InvestigationSearchDetailsList
    searchInvestigationByStatus(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    final InvestigationSearchDetailsList investigationList =
      new InvestigationSearchDetailsList();

    if (key.statusList.length() > 0) {

      final StringList statusList =
        StringUtil.tabText2StringListWithTrim(key.statusList);

      for (int i = 0; i < statusList.size(); i++) {

        final String status = statusList.item(i);

        if (status.length() > 0) {

          final InvestigationSearchCriteria searchKey =
            new InvestigationSearchCriteria();

          searchKey.assign(key);
          searchKey.statusList = status;

          if (key.typeList.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByType(searchKey).searchDtls);
          } else if (key.subtypeList.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationBySubtype(searchKey).searchDtls);
          } else if (key.alternateID.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByAlternateID(searchKey).searchDtls);
          } else {
            final DatabaseInvestigationSearchKey databaseKey =
              assignInvestigationSearchCriteria(key);

            databaseKey.status = status;

            investigationList.searchDtls
              .addAll(searchInvestigationByKey(databaseKey).searchDtls);
          }
        }
      }
    }

    return investigationList;
  }

  // ___________________________________________________________________________
  /**
   * Performs investigation search for specified search criteria by type values.
   *
   * @param key Contains investigation search criteria
   *
   * @return Found investigation details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected InvestigationSearchDetailsList
    searchInvestigationByType(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    final InvestigationSearchDetailsList investigationList =
      new InvestigationSearchDetailsList();

    if (key.typeList.length() > 0) {

      final StringList typeList =
        StringUtil.tabText2StringListWithTrim(key.typeList);

      for (int i = 0; i < typeList.size(); i++) {

        final String type = typeList.item(i);

        if (type.length() > 0) {

          final InvestigationSearchCriteria searchKey =
            new InvestigationSearchCriteria();

          searchKey.assign(key);
          searchKey.typeList = type;

          if (key.subtypeList.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationBySubtype(searchKey).searchDtls);
          } else if (key.alternateID.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByAlternateID(searchKey).searchDtls);
          } else {

            final DatabaseInvestigationSearchKey databaseKey =
              assignInvestigationSearchCriteria(key);

            databaseKey.type = type;

            investigationList.searchDtls
              .addAll(searchInvestigationByKey(databaseKey).searchDtls);
          }
        } // if (type.length() > 0)
      } // for i
    } // if (key.typeList.length() > 0)

    return investigationList;
  }

  // ___________________________________________________________________________
  /**
   * Performs investigation search for specified search criteria by subtype
   * values.
   *
   * @param key Contains investigation search criteria
   *
   * @return Found investigation details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected InvestigationSearchDetailsList
    searchInvestigationBySubtype(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    final InvestigationSearchDetailsList investigationList =
      new InvestigationSearchDetailsList();

    if (key.subtypeList.length() > 0) {

      final StringList subtypeList =
        StringUtil.tabText2StringListWithTrim(key.subtypeList);

      for (int i = 0; i < subtypeList.size(); i++) {

        final String subtype = subtypeList.item(i);

        if (subtype.length() > 0) {

          final InvestigationSearchCriteria searchKey =
            new InvestigationSearchCriteria();

          searchKey.assign(key);
          searchKey.subtypeList = subtype;

          if (key.alternateID.length() > 0) {
            investigationList.searchDtls
              .addAll(searchInvestigationByAlternateID(searchKey).searchDtls);
          } else {

            final DatabaseInvestigationSearchKey databaseKey =
              assignInvestigationSearchCriteria(key);

            databaseKey.subtype = subtype;

            investigationList.searchDtls
              .addAll(searchInvestigationByKey(databaseKey).searchDtls);
          }
        }

      }
    }

    return investigationList;
  }

  // ___________________________________________________________________________
  /**
   * Performs investigation search for specified search criteria by alternate
   * id values.
   *
   * @param key Contains investigation search criteria
   *
   * @return Found investigation details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected InvestigationSearchDetailsList
    searchInvestigationByAlternateID(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    InvestigationSearchDetailsList investigationList =
      new InvestigationSearchDetailsList();

    final DatabaseInvestigationSearchKey databaseKey =
      new DatabaseInvestigationSearchKey();

    databaseKey.assign(key);

    if (key.alternateID.length() > 0) {

      if (key.alternateIDType.length() > 0) {

        // if 'reference number' selected, search for
        // all three available reference types
        if (key.alternateIDType
          .equals(CONCERNROLESEARCHALTERNATEID.REFERENCE_NUMBER)) {

          investigationList.searchDtls
            .addAll(searchInvestigationByKey(databaseKey).searchDtls);

          databaseKey.alternateIDType =
            CONCERNROLEALTERNATEID.PERSON_REFERENCE_NUMBER;
          investigationList.searchDtls
            .addAll(searchInvestigationByKey(databaseKey).searchDtls);

          databaseKey.alternateIDType =
            CONCERNROLEALTERNATEID.PROSPECT_PERSON_REFERENCE_NUMBER;
          investigationList.searchDtls
            .addAll(searchInvestigationByKey(databaseKey).searchDtls);
        } else {
          investigationList = searchInvestigationByKey(databaseKey);
        }
      }

    }

    return investigationList;
  }

  // ___________________________________________________________________________
  /**
   * Performs case search for specified search criteria by owner values.
   *
   * @param key Contains case search criteria
   *
   * @return Found case details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected CaseSearchList1
    searchCaseByOrgObject(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    if (key.ownerList.length() > 0) {

      final StringList ownerList =
        StringUtil.tabText2StringListWithTrim(key.ownerList);

      for (int i = 0; i < ownerList.size(); i++) {

        final String owner = ownerList.item(i);

        if (owner.length() > 0) {

          final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

          searchKey.assign(key);
          searchKey.ownerList = owner;

          if (key.statusList.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByStatus(searchKey).searchDtls);
          } else if (key.categoryTypeList.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByCategoryType(searchKey).searchDtls);
          } else if (key.categoryList.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByCategory(searchKey).searchDtls);
          } else if (key.alternateID.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByAlternateID(searchKey).searchDtls);
          } else {
            final DatabaseCaseSearchKey databaseKey =
              assignCaseSearchCriteria(key);

            databaseKey.orgObjectLinkID = Long.parseLong(owner);

            caseList.searchDtls
              .addAll(searchCaseByKey(databaseKey).searchDtls);
          }
        }
      }
    }

    return caseList;
  }

  // ___________________________________________________________________________
  /**
   * Performs case search for specified search criteria by status values.
   *
   * @param key Contains case search criteria
   *
   * @return Found case details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected CaseSearchList1 searchCaseByStatus(final CaseSearchCriteria1 key)
    throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    if (key.statusList.length() > 0) {

      // BEGIN, CR00425263, BD
      // BD key.statusList is coming in as a tab delimited string.
      // Batch these together, ensuring that there are no more than 9 per batch
      // because our key struct has only 9 fields which it can use.
      final StringList listsOfUpToNineStatuses =
        getBatchedCaseStatuses(key.statusList);

      // END, CR00425263, BD

      for (int i = 0; i < listsOfUpToNineStatuses.size(); i++) {

        final String statuses = listsOfUpToNineStatuses.item(i);

        if (statuses.length() > 0) {

          final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

          searchKey.assign(key);
          searchKey.statusList = statuses;

          if (key.categoryTypeList.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByCategoryType(searchKey).searchDtls);
          } else if (key.categoryList.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByCategory(searchKey).searchDtls);
          } else if (key.alternateID.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByAlternateID(searchKey).searchDtls);
          } else {
            final DatabaseCaseSearchKey databaseKey =
              assignCaseSearchCriteria(key);

            databaseKey.status = statuses;
            caseList.searchDtls
              .addAll(searchCaseByKey(databaseKey).searchDtls);
          }
        }
      }
    }

    return caseList;
  }

  // ___________________________________________________________________________
  /**
   * Performs case search for specified search criteria by category and type
   * values.
   *
   * @param key Contains case search criteria
   *
   * @return Found case details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected CaseSearchList1
    searchCaseByCategoryType(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    if (key.categoryTypeList.length() > 0) {

      final StringList categoryTypeList =
        StringUtil.tabText2StringListWithTrim(key.categoryTypeList);

      // iterate through the category type list entries:
      for (int i = 0; i < categoryTypeList.size(); i++) {

        final String categoryTypeString = categoryTypeList.item(i);

        final StringList categoryType =
          StringUtil.delimitedText2StringListWithTrim(categoryTypeString,
            CuramConst.gkPipeDelimiterChar);

        if (categoryType.size() > CuramConst.gkOne) {

          if (key.alternateID.length() > 0) {
            final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

            searchKey.assign(key);
            searchKey.categoryTypeList = categoryTypeString;
            caseList.searchDtls
              .addAll(searchCaseByAlternateID(searchKey).searchDtls);
          } else {
            final DatabaseCaseSearchKey databaseKey =
              assignCaseSearchCriteria(key);
            // get case category and type
            final String category = categoryType.item(0);
            final String type = categoryType.item(1);

            databaseKey.category = category;
            databaseKey.type = type;

            caseList.searchDtls
              .addAll(searchCaseByKey(databaseKey).searchDtls);
          }
        }

      }
    }

    return caseList;
  }

  // ___________________________________________________________________________
  /**
   * Performs case search for specified search criteria by category values.
   *
   * @param key Contains case search criteria
   *
   * @return Found case details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected CaseSearchList1
    searchCaseByCategory(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    if (key.categoryList.length() > 0) {

      final StringList categoryList =
        StringUtil.tabText2StringListWithTrim(key.categoryList);

      for (int i = 0; i < categoryList.size(); i++) {

        final String category = categoryList.item(i);

        if (category.length() > 0) {

          final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

          searchKey.assign(key);
          searchKey.categoryList = category;

          if (key.alternateID.length() > 0) {
            caseList.searchDtls
              .addAll(searchCaseByAlternateID(searchKey).searchDtls);
          } else {

            final DatabaseCaseSearchKey databaseKey =
              assignCaseSearchCriteria(key);

            databaseKey.category = category;

            caseList.searchDtls
              .addAll(searchCaseByKey(databaseKey).searchDtls);
          }
        }
      }
    }

    return caseList;
  }

  // ___________________________________________________________________________
  /**
   * Performs case search for specified search criteria by alternate id values.
   *
   * @param key Contains case search criteria
   *
   * @return Found case details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected CaseSearchList1
    searchCaseByAlternateID(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    CaseSearchList1 caseList = new CaseSearchList1();

    final DatabaseCaseSearchKey databaseKey = assignCaseSearchCriteria(key);

    if (key.alternateID.length() > 0) {

      if (key.alternateIDType.length() > 0) {

        // if 'reference number' selected, search for
        // all three available reference types
        if (key.alternateIDType
          .equals(CONCERNROLESEARCHALTERNATEID.REFERENCE_NUMBER)) {

          caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);

          databaseKey.alternateIDType =
            CONCERNROLEALTERNATEID.PERSON_REFERENCE_NUMBER;
          caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);

          databaseKey.alternateIDType =
            CONCERNROLEALTERNATEID.PROSPECT_PERSON_REFERENCE_NUMBER;
          caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);
        } else {
          caseList = searchCaseByKey(databaseKey);
        }
      }
    }

    return caseList;
  }

  // ___________________________________________________________________________
  /**
   * Converts case search criteria to database search details.
   *
   * @param key Contains case search criteria
   *
   * @return Details for database case search.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected DatabaseCaseSearchKey
    assignCaseSearchCriteria(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    final DatabaseCaseSearchKey databaseKey = new DatabaseCaseSearchKey();

    databaseKey.assign(key);

    if (key.categoryTypeList.length() > 0) {

      final StringList categoryTypeList =
        StringUtil.tabText2StringListWithTrim(key.categoryTypeList);

      final StringList categoryType =
        StringUtil.delimitedText2StringListWithTrim(categoryTypeList.item(0),
          CuramConst.gkPipeDelimiterChar);

      if (categoryType.size() > CuramConst.gkOne) {
        databaseKey.category = categoryType.item(0);
        databaseKey.type = categoryType.item(1);
      }
    }

    if (key.ownerList.length() > 0) {
      databaseKey.orgObjectLinkID = Long.parseLong(key.ownerList);
    }

    return databaseKey;
  }

  // ___________________________________________________________________________
  /**
   * Converts investigation search criteria to database search details.
   *
   * @param key Contains investigation search criteria
   *
   * @return Details for database investigation search.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected DatabaseInvestigationSearchKey
    assignInvestigationSearchCriteria(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    final DatabaseInvestigationSearchKey databaseKey =
      new DatabaseInvestigationSearchKey();

    databaseKey.assign(key);

    if (key.ownerList.length() > 0) {
      databaseKey.orgObjectLinkID = Long.parseLong(key.ownerList);
    }

    return databaseKey;
  }

  // END, CR00231396

  // BEGIN, CR00425263, BD
  /**
   * Gets a fixed size string array with 9 entries containing the values
   * found in a tab delimited string. If there are fewer than 9 values present,
   * the remaining entries are left at null. There will never be more than 9
   * values in the string as the string is processed earlier.
   *
   * @param delimitedValues A tab delimited string.
   *
   * @return A 9 entry string array containing either the given values or null.
   */
  private String[] getNineCaseStatusValues(final String delimitedValues) {

    final String[] result = new String[kNumStatusFields];

    final StringList valueList =
      StringUtil.tabText2StringListWithTrim(delimitedValues);

    for (int i = 0; i < valueList.size(); i++) {
      result[i] = valueList.get(i);
    }

    return result;
  }

  /**
   * Gets a batch of case statuses from the tab delimited list, such that
   * each entry in the return list contains no more than 9 statuses.
   *
   * @param tabDelimitedString A tab delimited list of statuses.
   *
   * @return A list of strings, each one containing no more than 9 tab
   * delimited entries.
   */
  private StringList getBatchedCaseStatuses(final String tabDelimitedString) {

    final StringList result = new StringList();

    final int batchSize = kNumStatusFields;
    int tabCount = 0;
    int iChunkStart = 0;
    int iEnd = 0;

    for (int iBegin = 0; iEnd != -1;) {
      iEnd = tabDelimitedString.indexOf(GeneralConstants.kTab, iBegin);

      if (-1 == iEnd) {
        // no more delimiters found.
        final String currentChunk = tabDelimitedString.substring(iChunkStart);

        result.add(currentChunk);
        break;
      }
      iBegin = iEnd + 1; // move the search space forward.
      tabCount++;
      if (tabCount >= batchSize) {
        // we have filled up the current chunk.
        final String currentChunk =
          tabDelimitedString.substring(iChunkStart, iEnd);

        result.add(currentChunk);
        iChunkStart = iEnd;
        tabCount = 0;
      }
    }
    return result;

  }

  /**
   * Generates part of a where clause which combines a number of status codes.
   *
   * @param statusCodesString A tab delimited list of status codes.
   *
   * @return Part of a WHERE clause specifying one or more status codes.
   */
  private String getStatusCodesClause(final String statusCodesString) {

    final StringList statusList =
      StringUtil.tabText2StringListWithTrim(statusCodesString);

    final String result;

    if (statusList.size() == 0) {
      result = "";
    } else if (statusList.size() < 2) {
      result = " AND CaseHeader.statusCode = :status ";
    } else {
      // Produce a clause which matches multiple status codes.
      // Looks like:
      // (CaseHeader.statusCode = :status OR CaseHeader.statusCode = :status2
      // OR CaseHeader.statusCode = :status3)
      final StringBuffer resultBuf =
        new StringBuffer(" AND (CaseHeader.statusCode = :");

      resultBuf.append(kStatusFields[0]);
      for (int i = 1; i < statusList.size(); i++) {
        resultBuf.append(" OR CaseHeader.statusCode = :");
        resultBuf.append(kStatusFields[i]);
      }
      resultBuf.append(" ) ");
      result = resultBuf.toString();
    }

    return result;
  }

  /**
   * Wrapper for executing the case search data access.
   *
   * @param returnClassType
   * The return type of the query.
   * @param caseSearchCriteria
   * A struct containing the search criteria.
   * @param enableAuditing Auditing flag.
   * @param requireInformational Indicator as to whether an informational is
   * required when the readmulti maximum is reached.
   * @param sqlString The operation SQL.
   *
   * @return A list of matching records.
   *
   * @throws AppException Standard signature.
   * @throws InformationalException Standard signature.
   */
  private CuramValueList<CaseSearchDetails> executeNsMulti(
    final Class<CaseSearchDetails> returnClassType,
    final CaseSearchCriteria caseSearchCriteria, final boolean enableAuditing,
    final boolean requireInformational, final String sqlString)
    throws AppException, InformationalException {

    // caseSearchCriteria.status contains a tab delimited list of statuses
    // so explode these into a CaseSearchCriteriaWithMultiStatus
    final CaseSearchCriteriaWithMultiStatus multiStatusCriteria =
      new CaseSearchCriteriaWithMultiStatus();
    final String[] caseStatus =
      getNineCaseStatusValues(caseSearchCriteria.status);

    multiStatusCriteria.assign(caseSearchCriteria);
    multiStatusCriteria.status = caseStatus[0];
    multiStatusCriteria.status2 = caseStatus[1];
    multiStatusCriteria.status3 = caseStatus[2];
    multiStatusCriteria.status4 = caseStatus[3];
    multiStatusCriteria.status5 = caseStatus[4];
    multiStatusCriteria.status6 = caseStatus[5];
    multiStatusCriteria.status7 = caseStatus[6];
    multiStatusCriteria.status8 = caseStatus[7];
    multiStatusCriteria.status9 = caseStatus[8];

    final CuramValueList<CaseSearchDetails> result =
      DynamicDataAccess.executeNsMulti(returnClassType, multiStatusCriteria,
        enableAuditing, requireInformational, sqlString);

    return result;
  }

  /**
   * Searches for matching cases.
   *
   * @param caseSearchDetails1 The type of class to return.
   * @param databaseCaseSearchKey The search criteria, including a tab
   * delimited list of case statuses.
   * @param enableAuditing Auditing flag.
   * @param requireInformational Indicator as to whether an informational is
   * required when the readmulti maximum is reached.
   * @param sqlString The operation SQL.
   *
   * @return A list of matching records.
   *
   * @throws AppException Standard signature.
   * @throws InformationalException Standard signature.
   */
  private CuramValueList<CaseSearchDetails1> executeNsMulti(
    final Class<CaseSearchDetails1> caseSearchDetails1,
    final DatabaseCaseSearchKey databaseCaseSearchKey,
    final boolean enableAuditing, final boolean requireInformational,
    final String sqlStatement) throws AppException, InformationalException {

    // Break the delimited list of case statuses into individual fields.
    // The incoming SQL already references these fields.
    final DatabaseCaseSearchMultiStatusKey multiStatusCriteria =
      new DatabaseCaseSearchMultiStatusKey();

    multiStatusCriteria.assign(databaseCaseSearchKey);
    final String[] caseStatus =
      getNineCaseStatusValues(multiStatusCriteria.status);

    multiStatusCriteria.status = caseStatus[0];
    multiStatusCriteria.status2 = caseStatus[1];
    multiStatusCriteria.status3 = caseStatus[2];
    multiStatusCriteria.status4 = caseStatus[3];
    multiStatusCriteria.status5 = caseStatus[4];
    multiStatusCriteria.status6 = caseStatus[5];
    multiStatusCriteria.status7 = caseStatus[6];
    multiStatusCriteria.status8 = caseStatus[7];
    multiStatusCriteria.status9 = caseStatus[8];

    final CuramValueList<CaseSearchDetails1> curamValueList =
      DynamicDataAccess.executeNsMulti(caseSearchDetails1,
        multiStatusCriteria, enableAuditing, requireInformational,
        sqlStatement);

    return curamValueList;
  }

  /**
   * Searches for investigations.
   *
   * @param returnTypeClass The type of class to return.
   * @param databaseInvestigationSearchKey The investigation search criteria
   * which may include a delimited list of case statuses.
   * @param enableAuditing Auditing flag.
   * @param requireInformational Indicator as to whether an informational is
   * required when the readmulti maximum is reached.
   * @param sqlString The operation SQL.
   *
   * @return A list of matching records.
   *
   * @throws AppException Standard signature.
   * @throws InformationalException Standard signature.
   */
  private CuramValueList<InvestigationSearchDetails> executeNsMulti(
    final Class<InvestigationSearchDetails> returnTypeClass,
    final DatabaseInvestigationSearchKey databaseInvestigationSearchKey,
    final boolean enableAuditing, final boolean requireInformational,
    final String sqlStatement) throws AppException, InformationalException {

    // Break the delimited list of case statuses into individual fields.
    // The incoming SQL already references these fields.
    final DatabaseInvestigationMultiStatusSearchKey multiStatusCriteria =
      new DatabaseInvestigationMultiStatusSearchKey();

    multiStatusCriteria.assign(databaseInvestigationSearchKey);
    final String[] caseStatus =
      getNineCaseStatusValues(multiStatusCriteria.status);

    multiStatusCriteria.status = caseStatus[0];
    multiStatusCriteria.status2 = caseStatus[1];
    multiStatusCriteria.status3 = caseStatus[2];
    multiStatusCriteria.status4 = caseStatus[3];
    multiStatusCriteria.status5 = caseStatus[4];
    multiStatusCriteria.status6 = caseStatus[5];
    multiStatusCriteria.status7 = caseStatus[6];
    multiStatusCriteria.status8 = caseStatus[7];
    multiStatusCriteria.status9 = caseStatus[8];

    final CuramValueList<InvestigationSearchDetails> result =
      DynamicDataAccess.executeNsMulti(returnTypeClass, multiStatusCriteria,
        enableAuditing, requireInformational, sqlStatement);

    return result;
  }

  // END, CR00425263, BD

  /**
   * Iterates through a list of CaseSearchList1 to retrieve the case participant
   * role and Case Group Participant of type member for each case.
   * Case Group Participants will be retrieved only if case is of type Product
   * Delivery.
   *
   * @param caseSearchList1
   * @throws AppException
   * @throws InformationalException
   */
  private void addClientsInformation(final CaseSearchList1 caseSearchList1)
    throws AppException, InformationalException {

    for (final CaseSearchDetails1 caseSearchDetails1 : caseSearchList1.searchDtls) {
      addCaseParticipantRoleOfTypeMemberOrPrimaryInformation(
        caseSearchDetails1);
      if (caseSearchDetails1.caseTypeCode != null
        && caseSearchDetails1.caseTypeCode
          .equals(CASECATEGORY.PRODUCTDELIVERY)) {
        addCaseGroupClientOfTypeMemberInformation(caseSearchDetails1);
      }
    }
  }

  /**
   * Retrieves the active participants of type member or primary for the case ID
   * in caseSearchDetails1 and format the resulting list as comma separated
   * string of names.
   *
   * @param caseSearchDetails1
   * @throws AppException
   * @throws InformationalException
   */
  private void addCaseParticipantRoleOfTypeMemberOrPrimaryInformation(
    final CaseSearchDetails1 caseSearchDetails1)
    throws AppException, InformationalException {

    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    final List<String> clientsList = new ArrayList<>();
    final List<Long> clientsIDs = new ArrayList<>();
    final CaseIDAndRecordStatus caseIDAndRecordStatus =
      new CaseIDAndRecordStatus();
    caseIDAndRecordStatus.caseID = caseSearchDetails1.caseID;
    caseIDAndRecordStatus.recordStatus = RECORDSTATUS.NORMAL;
    final CaseParticipantRoleTypeNameDtls1List caseParticipantRoleTypeNameDtlsList =
      caseParticipantRoleObj.searchActiveByCaseID1(caseIDAndRecordStatus);
    for (final CaseParticipantRoleTypeNameDtls1 caseParticipantRoleTypeNameDtls : caseParticipantRoleTypeNameDtlsList.dtls) {
      if (CommonUtils.isParticipantTypeMemberOrPrimaryOrNull(
        caseParticipantRoleTypeNameDtls.typeCode)
        && !clientsIDs
          .contains(caseParticipantRoleTypeNameDtls.participantRoleID)) {
        clientsList.add(caseParticipantRoleTypeNameDtls.concernRoleName);
        clientsIDs.add(caseParticipantRoleTypeNameDtls.participantRoleID);
      }
    }
    // if there are no case participants of type Member or Primary, the
    // clients column will be populated with the concern role on case header
    // if there are no case participants of type Member or Primary, the
    // clients column will be populated with the concern role on case header
    if (clientsList.isEmpty()) {
      clientsList.add(caseSearchDetails1.concernRoleName);
    }
    caseSearchDetails1.cprClientsOpt =
      CommonUtils.formatForClientsDisplay(clientsList);
  }

  /**
   * Retrieves active case group member of type Member for the case ID in
   * caseSearchDetails1 and format the resulting list as comma separated
   * string of names.
   *
   * @param caseSearchDetails1
   * @throws AppException
   * @throws InformationalException
   */
  private void addCaseGroupClientOfTypeMemberInformation(
    final CaseSearchDetails1 caseSearchDetails1)
    throws AppException, InformationalException {

    final curam.core.intf.CaseGroups caseGroupsObj =
      curam.core.fact.CaseGroupsFactory.newInstance();

    final List<String> clientsList = new ArrayList<>();
    final List<Long> clientsIDs = new ArrayList<>();
    final CaseGroupsCaseIDAndTypeKey caseGroupsCaseIDAndTypeKey =
      new CaseGroupsCaseIDAndTypeKey();
    caseGroupsCaseIDAndTypeKey.caseID = caseSearchDetails1.caseID;
    caseGroupsCaseIDAndTypeKey.groupCode = CASEGROUPTYPE.MEMBER;

    final CaseGroupEligibleMembersDetails1List caseGroupEligibleMembersDetailsList =
      caseGroupsObj
        .searchCaseMembersByCaseIDAndType(caseGroupsCaseIDAndTypeKey);
    for (final CaseGroupEligibleMembersDetails1 caseGroupEligibleMembersDetails : caseGroupEligibleMembersDetailsList.dtls) {
      if (!clientsIDs
        .contains(caseGroupEligibleMembersDetails.concernRoleID)) {
        clientsList.add(caseGroupEligibleMembersDetails.eligibleMemberName);
        clientsIDs.add(caseGroupEligibleMembersDetails.concernRoleID);
      }
    }

    caseSearchDetails1.cgMembersOpt =
      CommonUtils.formatForClientsDisplay(clientsList);
  }
}
