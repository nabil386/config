/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.sl.entity.struct.CaseNomNameAddressKey;
import curam.core.sl.entity.struct.CaseNomineeNameAddressID;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.FinInstructionIDStatus;
import curam.core.struct.IssueProductDeliveryLiabilityResult;
import curam.core.struct.LbyInstrumentSummary;
import curam.core.struct.LiabilityInstructionDtls;
import curam.core.struct.LiabilityInstructionKey;
import curam.core.struct.LiabilityInstrumentDetails;
import curam.core.struct.LiabilityInstrumentDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code for issuing liabilities
 *
 */
public abstract class IssueLiability extends curam.core.base.IssueLiability {

  // ___________________________________________________________________________
  /**
   * To issue a liability instrument to the nominee of a product delivery.
   *
   * @param lbyInstrumentSummary Information required
   * for issuing the liability
   *
   * @return details of the Liability Instrument inserted
   */
  @Override
  public IssueProductDeliveryLiabilityResult issueProductDeliveryLiability(
    LbyInstrumentSummary lbyInstrumentSummary) throws AppException,
      InformationalException {

    // IssueProductDeliveryLiabilityResult variable
    final IssueProductDeliveryLiabilityResult issueProductDeliveryLiabilityResult = new IssueProductDeliveryLiabilityResult();

    // liabilityInstruction manipulation variables
    final curam.core.intf.LiabilityInstruction liabilityInstructionObj = curam.core.fact.LiabilityInstructionFactory.newInstance();
    final LiabilityInstructionKey liabilityInstructionKey = new LiabilityInstructionKey();
    LiabilityInstructionDtls liabilityInstructionDtls;
    LiabilityInstrumentDtls liabilityInstrumentDtls;

    // set key to read liabilityInstruction
    liabilityInstructionKey.liabInstructionID = lbyInstrumentSummary.liabilityInstructionID;

    // read liabilityInstruction
    liabilityInstructionDtls = liabilityInstructionObj.read(
      liabilityInstructionKey);

    // caseNominee manipulation object
    final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();

    // CaseNomineeViewKey key and details
    CaseNomineeNameAddressID caseNomineeNameAddressID;
    final CaseNomNameAddressKey caseNomNameAddressKey = new CaseNomNameAddressKey();

    // set key to search for the nominee
    caseNomNameAddressKey.caseNomineeID = lbyInstrumentSummary.caseNomineeID;

    caseNomNameAddressKey.destinationType = curam.codetable.DESTINATIONTYPECODE.ADDRESS;
    caseNomNameAddressKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // search for nominee details
    caseNomineeNameAddressID = caseNomineeObj.readCaseNomineeDetailsAndAddressID(
      caseNomNameAddressKey);

    // retrieve the Concern Role details for the instrument
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set key to read concernRole entity
    concernRoleKey.concernRoleID = lbyInstrumentSummary.concernRoleID;

    // read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // create and populate the input parameter for the create liability
    // instrument
    final curam.core.intf.CreateLiability createLiabilityObj = curam.core.fact.CreateLiabilityFactory.newInstance();
    final LiabilityInstrumentDetails lbyInstrumentDtls = new LiabilityInstrumentDetails();

    // set liabilityInstrument details
    lbyInstrumentDtls.assign(concernRoleDtls);

    // CHRIS NEED TO CREATE ASSIGNMENT;
    // lbyInstrumentDtls.assign(caseNomineeDetails);
    lbyInstrumentDtls.addressID = caseNomineeNameAddressID.addressID;
    lbyInstrumentDtls.caseNomineeID = lbyInstrumentSummary.caseNomineeID;
    lbyInstrumentDtls.concernRoleID = caseNomineeNameAddressID.concernRoleID;

    lbyInstrumentDtls.assign(lbyInstrumentSummary);

    lbyInstrumentDtls.nomineeName = caseNomineeNameAddressID.concernRoleName;
    lbyInstrumentDtls.nomineeAlternateID = caseNomineeNameAddressID.alternateID;
    // BEGIN, CR00049218, GM
    lbyInstrumentDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218
    // create the liability instrument
    liabilityInstrumentDtls = createLiabilityObj.createLiabilityInstrument(
      lbyInstrumentDtls);

    issueProductDeliveryLiabilityResult.liabilityInstrumentDetails.assign(
      liabilityInstrumentDtls);

    // now the instrument is successfully issued, update the liability
    // instruction status to reflect this
    final curam.core.intf.MaintainFinInstruction maintainFinInstructionObj = curam.core.fact.MaintainFinInstructionFactory.newInstance();
    final FinInstructionIDStatus finInstructionIDStatus = new FinInstructionIDStatus();

    // set status to 'Issued' for update
    finInstructionIDStatus.finInstructionID = liabilityInstructionDtls.finInstructionID;
    finInstructionIDStatus.statusCode = curam.codetable.FININSTRUCTIONSTATUS.ISSUED;

    // update financialInstruction status
    maintainFinInstructionObj.updateFinInstructionStatus(finInstructionIDStatus);

    // output the updated financial instruction versionNo
    issueProductDeliveryLiabilityResult.relatedVersionNo.finInstructionVersNo = finInstructionIDStatus.versionNo;

    // set the output liability instruction versionNo even though we are
    // currently not changing this - a calling BPO might try to use it.
    issueProductDeliveryLiabilityResult.relatedVersionNo.lbyInstructionVersNo = liabilityInstructionDtls.versionNo;

    return issueProductDeliveryLiabilityResult;
  }

}
