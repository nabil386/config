/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.CASECATEGORY;
import curam.codetable.CASESEARCHFILTER;
import curam.codetable.CASESEARCHSTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.INVESTIGATECONFIGTYPE;
import curam.codetable.INVESTIGATIONSEARCHSTATUS;
import curam.codetable.INVESTIGDELIVERYSUBTYPE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTNAME;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.USERSEARCHTYPE;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.intf.Case;
import curam.core.facade.struct.CaseContextPanelKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseSearchRouterFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProductFactory;
import curam.core.hook.impl.CaseClientsPopulationHook;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseSearchRouter;
import curam.core.intf.Product;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.fact.InvestigationConfigFactory;
import curam.core.sl.entity.fact.InvestigationDeliveryFactory;
import curam.core.sl.entity.intf.InvestigationConfig;
import curam.core.sl.entity.intf.InvestigationDelivery;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetails;
import curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetailsList;
import curam.core.sl.entity.struct.CurrentUserWorkQueueKey;
import curam.core.sl.entity.struct.InvestigationConfigurationTypeDtlsList;
import curam.core.sl.entity.struct.InvestigationTypeAndResolutionDtls;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.PositionName;
import curam.core.sl.entity.struct.ReadInvestigationTypeAndActiveResolutionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueNameDetails;
import curam.core.sl.fact.OrganisationUnitFactory;
import curam.core.sl.fact.PositionFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.UserSearchFilterFactory;
import curam.core.sl.fact.WorkQueueFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.UserSearchFilter;
import curam.core.sl.intf.WorkQueue;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.ListUserOrgUnitDetails;
import curam.core.sl.struct.ListUserPositionDetails;
import curam.core.sl.struct.ReadTransactionLogDetails;
import curam.core.sl.struct.ReadTransactionLogDetailsList;
import curam.core.sl.struct.UserNameAndUserSearchTypeDetails;
import curam.core.sl.struct.UserSearchFilterData;
import curam.core.sl.struct.UserSearchFilterDataList;
import curam.core.sl.struct.UserSearchFilterDetails;
import curam.core.struct.AdminIntegratedCaseByStatusCodeKey;
import curam.core.struct.AdminIntegratedCaseFilterDtlsList;
import curam.core.struct.CaseCategoryTypeDetails;
import curam.core.struct.CaseCategoryTypeDetailsList;
import curam.core.struct.CaseFilterOptionDetails;
import curam.core.struct.CaseFilterOptionDetailsList;
import curam.core.struct.CaseHeaderByConcernRoleIDKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderDtlsList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseOwnerList;
import curam.core.struct.CaseOwnerTypeDetails;
import curam.core.struct.CaseOwnerTypeDetailsList;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceSearchKey;
import curam.core.struct.CaseSearchAndLastTransactionDetails;
import curam.core.struct.CaseSearchAndLastTransactionDetailsList;
import curam.core.struct.CaseSearchCriteria;
import curam.core.struct.CaseSearchCriteria1;
import curam.core.struct.CaseSearchCriteriaValue;
import curam.core.struct.CaseSearchDetails;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSearchList;
import curam.core.struct.CaseSearchList1;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusFilterDetails;
import curam.core.struct.CaseStatusFilterDetailsList;
import curam.core.struct.CaseTypeFilterDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DataStringList;
import curam.core.struct.InitialCaseSearchCriteria;
import curam.core.struct.InitialInvestigationSearchCriteria;
import curam.core.struct.InvestigationSearchCriteria;
import curam.core.struct.InvestigationSearchDetails;
import curam.core.struct.InvestigationSearchDetailsList;
import curam.core.struct.InvestigationSubtypeDetails;
import curam.core.struct.InvestigationSubtypeDetailsList;
import curam.core.struct.InvestigationTypeDetails;
import curam.core.struct.InvestigationTypeDetailsList;
import curam.core.struct.MyCasesFilterList;
import curam.core.struct.MyInvestigationFilterList;
import curam.core.struct.PersonSummaryDetails;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductFilterDtls;
import curam.core.struct.ProductFilterDtlsList;
import curam.core.struct.ReadByPrimaryAlternateIDDtls;
import curam.core.struct.ReadPersonSummaryKey;
import curam.core.struct.SearchByPrimaryAlternateIDKey;
import curam.core.struct.StatusCodeKeyStruct;
import curam.core.struct.UserFullname;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.message.BPOCASESEARCH;
import curam.message.GENERALCASE;
import curam.message.GENERALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;

/**
 * Implements Case Searches.
 *
 */
public abstract class CaseSearch extends curam.core.base.CaseSearch {

  protected static final String kCommaSpace = CuramConst.gkComma
      + CuramConst.gkSpace;

  protected static final int kCommaSpaceLength = kCommaSpace.length();

  // BEGIN, CROO211297, CW
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;

  // END, CROO211297
  // BEGIN, 191389, GG
  @Inject
  protected CaseClientsPopulationHook caseClientsPopulationHook;
  // END, 191389

  // BEGIN, CR00201195, ZV
  // Add injection for using the new CaseTransactionLog API
  public CaseSearch() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END, CR00201195

  // BEGIN, CR00213606, MR
  /**
   * Locates cases by CaseID.
   *
   * @param key
   *          Contains the case ID.
   *
   * @return Case search details.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public CaseSearchDetails readByCaseID(final CaseSearchKey key)
      throws AppException, InformationalException {

    // END, CR00213606
    final CaseSearchDetails dtls = new CaseSearchDetails();

    // caseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // productDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory
        .newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // check if case ID is provided
    if (key.caseID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(
                  BPOCASESEARCH.INF_BPOCASESEARCH_NO_CASE_REFERENCE_SPECIFIED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    // set key to read caseHeader entity
    caseHeaderKey.caseID = key.caseID;

    // read caseHeader entity
    try {
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // throw alternative error message
      throw new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH);
    }

    // Fill the return structure with values
    dtls.startDate = caseHeaderDtls.startDate;
    dtls.registrationDate = caseHeaderDtls.registrationDate;
    dtls.caseTypeCode = caseHeaderDtls.caseTypeCode;
    dtls.partOfIntegCaseInd = false;

    // If case is a Product Delivery on an Integrated Case return the
    // Integrated Case ID and Indicator (to indicate that the PD is part of
    // an Integrated Case) to the client
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
        && caseHeaderDtls.integratedCaseID != 0) {

      dtls.integratedCaseID = caseHeaderDtls.integratedCaseID;
      dtls.partOfIntegCaseInd = true;
    }

    // set key to read concernRole entity
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Continue filling the return structure with values
    dtls.primaryAlternateID = concernRoleDtls.primaryAlternateID;
    dtls.concernRoleName = concernRoleDtls.concernRoleName;
    dtls.concernRoleID = concernRoleKey.concernRoleID;

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
        || caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

      // set key to read productDelivery entity
      productDeliveryKey.caseID = key.caseID;

      // read productDelivery entity
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // Type code and status code converted to descriptions
      dtls.productTypeCode = productDeliveryDtls.productType;
    }

    dtls.statusCode = caseHeaderDtls.statusCode;
    dtls.caseID = key.caseID;
    dtls.restricted = false;

    // BEGIN, CR00226315, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
        .get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
        .checkCaseSecurity1(caseSecurityCheckKey);

    // pass out the indicator
    if (dataBasedSecurityResult.restricted) {
      dtls.startDate = curam.util.type.Date.kZeroDate;
      dtls.registrationDate = curam.util.type.Date.kZeroDate;
      // BEGIN, CR00049218, GM
      dtls.caseTypeCode = CuramConst.gkEmpty;
      dtls.statusCode = CuramConst.gkEmpty;
      // END, CR00049218
      dtls.primaryAlternateID = CuramConst.gkRestricted;
      dtls.concernRoleName = CuramConst.gkRestricted;
      // BEGIN, CR00049218, GM
      dtls.productTypeCode = CuramConst.gkEmpty;
      // END, CR00049218
      dtls.restricted = true;
      return dtls;
    }

    // If the location data security is set to on, and when user does not have
    // access to view this case an exception is thrown.
    if (!dataBasedSecurityResult.result) {
      throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      // END, CR00226315
    }

    return dtls;
  }

  /**
   * This method locates cases by alternateID only.
   *
   * @param key
   *          primaryAlternateID
   *
   * @return case search details
   */
  @Override
  public ReadByPrimaryAlternateIDDtls readByPrimaryAlternateID(
      final SearchByPrimaryAlternateIDKey key)
      throws AppException, InformationalException {

    final ReadByPrimaryAlternateIDDtls details = new ReadByPrimaryAlternateIDDtls();

    // caseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;
    CaseHeaderDtlsList caseHeaderDtlsList;
    final CaseHeaderByConcernRoleIDKey caseHeaderByConcernRoleIDKey = new CaseHeaderByConcernRoleIDKey();

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // productDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory
        .newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // person manipulation variables
    final curam.core.intf.Person personObj = curam.core.fact.PersonFactory
        .newInstance();
    final ReadPersonSummaryKey readPersonSummaryKey = new ReadPersonSummaryKey();
    PersonSummaryDetails personSummaryDetails;

    // read the person details by AlternateID and if there is no person
    // set the indicator to true and return
    // set the personAltSearchKey
    // set the search key
    readPersonSummaryKey.primaryAlternateID = key.alternateID;

    // read person entity
    try {
      personSummaryDetails = personObj.readSummaryDetails(readPersonSummaryKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      details.caseExistsInd = false;
      return details;
    }

    details.caseExistsInd = true;

    // set key to read concernRole entity
    concernRoleKey.concernRoleID = personSummaryDetails.concernRoleID;

    // read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Fill the return structure with values
    details.primaryAlternateID = concernRoleDtls.primaryAlternateID;
    details.concernRoleName = concernRoleDtls.concernRoleName;
    details.concernRoleID = concernRoleKey.concernRoleID;

    // Need to read the cases for this concern
    // there should only be one case per person.
    caseHeaderByConcernRoleIDKey.concernRoleID = concernRoleDtls.concernRoleID;

    // read caseHeader entity by concernRoleID
    caseHeaderDtlsList = caseHeaderObj
        .searchByConcernRoleID(caseHeaderByConcernRoleIDKey);

    // as there should ever only be one in the list we can set the casID
    // as follows
    caseHeaderKey.caseID = caseHeaderDtlsList.dtls
        .item(caseHeaderDtlsList.dtls.size() - 1).caseID;

    // read caseHeader entity
    try {
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // throw alternative error message
      throw new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH);
    }

    // If case is a Product Delivery on an Integrated Case return the
    // Integrated Case ID and Indicator (to indicate that the PD is part of
    // an Integrated Case) to the client
    details.registrationDate = caseHeaderDtls.registrationDate;
    details.caseTypeCode = caseHeaderDtls.caseTypeCode;

    // set key to read productDelivery entity
    productDeliveryKey.caseID = caseHeaderDtls.caseID;

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
        || caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

      // read productDelivery entity
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // type code and status code converted to descriptions
      details.productTypeCode = productDeliveryDtls.productType;
    }

    details.statusCode = caseHeaderDtls.statusCode;
    details.caseID = caseHeaderDtls.caseID;

    return details;
  }

  /**
   * This method locates Cases by Case reference only.
   *
   * @param key
   *          the case reference
   *
   * @return case search details
   */
  @Override
  public CaseSearchDetails readByCaseReference(final CaseReferenceSearchKey key)
      throws AppException, InformationalException {

    final CaseSearchDetails dtls = new CaseSearchDetails();

    // caseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseReference caseReference = new CaseReference();
    CaseHeaderDtls caseHeaderDtls;

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // productDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory
        .newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // check if case ID is provided
    if (key.caseReference.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(
                  BPOCASESEARCH.INF_BPOCASESEARCH_NO_CASE_REFERENCE_SPECIFIED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
    }

    // set key to read caseHeader entity
    caseReference.caseReference = key.caseReference;

    // read caseHeader entity
    try {
      caseHeaderDtls = caseHeaderObj.readByCaseReference(caseReference);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // throw alternative error message
      throw new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH);
    }

    // If a service plan case is entered, do not return the record.
    // Service Plans should not be returned following a case search
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              4);
    }
    // Fill the return structure with values
    dtls.startDate = caseHeaderDtls.startDate;
    dtls.registrationDate = caseHeaderDtls.registrationDate;
    dtls.caseTypeCode = caseHeaderDtls.caseTypeCode;
    dtls.partOfIntegCaseInd = false;

    // If case is a Product Delivery on an Integrated Case return the
    // Integrated Case ID and Indicator (to indicate that the PD is part of
    // an Integrated Case) to the client
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
        && caseHeaderDtls.integratedCaseID != 0) {

      dtls.integratedCaseID = caseHeaderDtls.integratedCaseID;
      dtls.partOfIntegCaseInd = true;
    }

    // set key to read concernRole entity
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Continue filling the return structure with values
    dtls.primaryAlternateID = concernRoleDtls.primaryAlternateID;
    dtls.concernRoleName = concernRoleDtls.concernRoleName;
    dtls.concernRoleID = concernRoleKey.concernRoleID;

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
        || caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

      // set key to read productDelivery entity
      productDeliveryKey.caseID = caseHeaderDtls.caseID;

      // read productDelivery entity
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // Type code and status code converted to descriptions
      dtls.productTypeCode = productDeliveryDtls.productType;
    }

    dtls.statusCode = caseHeaderDtls.statusCode;
    dtls.caseID = caseHeaderDtls.caseID;
    dtls.restricted = false;

    // BEGIN, CR00226315, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
        .get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult = new DataBasedSecurityResult();

    caseSecurityCheckKey.caseID = caseHeaderDtls.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity
        .checkCaseSecurity1(caseSecurityCheckKey);

    // pass out the indicator
    if (dataBasedSecurityResult.restricted) {

      dtls.startDate = curam.util.type.Date.kZeroDate;
      dtls.registrationDate = curam.util.type.Date.kZeroDate;
      // BEGIN, CR00049218, GM
      dtls.caseTypeCode = CuramConst.gkEmpty;
      dtls.statusCode = CuramConst.gkEmpty;
      // END, CR00049218
      dtls.primaryAlternateID = CuramConst.gkRestricted;
      dtls.concernRoleName = CuramConst.gkRestricted;
      // BEGIN, CR00049218, GM
      dtls.productTypeCode = CuramConst.gkEmpty;
      // END, CR00049218
      dtls.restricted = true;
      return dtls;
    }

    // If the location data security is set to on, and when user does not have
    // access to view this case an exception is thrown.
    if (!dataBasedSecurityResult.result) {
      throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      // END, CR00226315
    }

    return dtls;

  }

  // BEGIN, CR00201195, ZV
  // BEGIN, CR00077040, PMD
  /**
   * @param caseSearchCriteria
   *          data on which the searched will be based
   *
   * @return The details of any records found
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}. This method
   *             has been deprecated to introduce new case search enhancements.
   *
   *             Method to perform a case search
   */
  @Override
  @Deprecated
  public CaseSearchList search(final CaseSearchCriteria caseSearchCriteria)
      throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
            new AppException(BPOCASESEARCH.ERR_CASESEARCH_UNIMPLEMENTED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
    // Should not reach this point without throwing a validation
    return null;
  }

  // END, CR00201195

  // END, CR00077040
  // BEGIN, CR00121404, BD
  /**
   * Method to perform a case search
   *
   * @param personSearchKey
   *          data on which the searched will be based
   *
   * @return The details of any records found
   */
  @Override
  public CaseSearchList searchCurrentUserCasesOnly(
      final CaseSearchCriteria caseSearchCriteria)
      throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
            new AppException(BPOCASESEARCH.ERR_CASESEARCH_UNIMPLEMENTED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            2);
    // Should not reach this point without throwing a validation
    return null;

  }

  // END, CR00121404

  // BEGIN, CR00129355, JC
  /**
   * Method to read the caseID by Case reference
   *
   * @param CaseReferenceSearchKey
   *          the case reference
   *
   * @return The details of the case (CaseID) found
   */
  @Override
  public CaseSearchDetails readCaseIDByCaseReference(
      final CaseReferenceSearchKey key)
      throws AppException, InformationalException {

    final CaseSearchDetails dtls = new CaseSearchDetails();

    // caseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseReference caseReference = new CaseReference();
    CaseHeaderDtls caseHeaderDtls;

    // check if case reference is provided
    if (key.caseReference.length() == 0) {
      return null;
    }

    // set key to read caseHeader entity
    caseReference.caseReference = key.caseReference;

    // read caseHeader entity
    try {
      caseHeaderDtls = caseHeaderObj.readByCaseReference(caseReference);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // throw alternative error message
      return null;
    }

    // If a service plan case is entered, do not return the record.
    // Service Plans should not be returned following a case search
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {
      // throw alternative error message
      return null;
    }
    // Fill the return structure with values

    dtls.caseID = caseHeaderDtls.caseID;

    return dtls;
  }

  // END, CR00129355, JC

  // BEGIN, CR00150153, ZV
  /**
   * Returns initial details to populate case search criteria.
   *
   * @return Initial details to populate case search criteria.
   */
  @Override
  public InitialCaseSearchCriteria getCaseSearchCiteria()
      throws AppException, InformationalException {

    final InitialCaseSearchCriteria initialCaseSearchCriteria = new InitialCaseSearchCriteria();

    // BEGIN, CR00202673, ZV
    final CaseTypeFilterDetails caseTypeFilterDetails = new CaseTypeFilterDetails();

    caseTypeFilterDetails.caseSearchFilterInd = true;
    caseTypeFilterDetails.myCasesFilterInd = false;

    initialCaseSearchCriteria.typeDtlsList = getCaseTypeFilterList(
        caseTypeFilterDetails);

    initialCaseSearchCriteria.statusDtlsList = getCaseStatusFilterList();
    // END, CR00202673

    // BEGIN, CR00201195, ZV
    initialCaseSearchCriteria.indexCaseSearchEnabledInd = Configuration
        .getBooleanProperty(EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED)
        && Configuration.getBooleanProperty(
            EnvVars.ENV_LUCENE_ENHANCED_CASE_SEARCH_ENABLED);
    // END, CR00201195

    // BEGIN, CR00202080, ZV
    initialCaseSearchCriteria.appealsInstalledInd = Configuration
        .getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED);
    // END, CR00202080

    initialCaseSearchCriteria.displayClientsOpt = Configuration
        .getBooleanProperty(EnvVars.ENV_DISPLAY_CASE_CLIENTS);

    return initialCaseSearchCriteria;
  }

  /*
   * Comparator used to order a case type list by type description
   */
  protected class CaseTypeComparator
      implements Comparator<CaseCategoryTypeDetails> {

    public CaseTypeComparator() {

      super();
    }

    @Override
    public int compare(final CaseCategoryTypeDetails struct1,
        final CaseCategoryTypeDetails struct2) {

      return struct1.typeDescription.compareTo(struct2.typeDescription);
    }

  }

  // END, CR00150153

  // BEGIN, CR00165038, ZV
  /**
   * Returns initial details to populate my cases search filter lists.
   *
   * @return Initial details to populate my cases search filter lists.
   */
  @Override
  public MyCasesFilterList getMyCasesFilterList()
      throws AppException, InformationalException {

    final MyCasesFilterList myCasesFilterList = new MyCasesFilterList();

    // get stored default case search filter values
    final UserSearchFilter userSearchFilterObj = UserSearchFilterFactory
        .newInstance();
    final UserNameAndUserSearchTypeDetails userNameAndUserSearchTypeDetails = new UserNameAndUserSearchTypeDetails();

    // get stored case search filter values
    userNameAndUserSearchTypeDetails.userName = TransactionInfo
        .getProgramUser();
    userNameAndUserSearchTypeDetails.userSearchType = USERSEARCHTYPE.CASE;

    final UserSearchFilterDataList userSearchFilterDataList = userSearchFilterObj
        .read(userNameAndUserSearchTypeDetails);

    String storedCaseTypeList = new String();
    String storedCaseStatusList = new String();
    String storedCaseOwnerList = new String();

    for (int i = 0; i < userSearchFilterDataList.dtlsList.size(); i++) {

      final UserSearchFilterData userSearchFilterData = userSearchFilterDataList.dtlsList
          .item(i);

      if (userSearchFilterData.userSearchFilterType
          .equals(CuramConst.kUserSearchCaseTypeList)) {
        storedCaseTypeList = userSearchFilterData.userSearchFilterValue;
        continue;
      }
      if (userSearchFilterData.userSearchFilterType
          .equals(CuramConst.kUserSearchCaseStatusList)) {
        storedCaseStatusList = userSearchFilterData.userSearchFilterValue;
        continue;
      }
      if (userSearchFilterData.userSearchFilterType
          .equals(CuramConst.kUserSearchCaseOwnerList)) {
        storedCaseOwnerList = userSearchFilterData.userSearchFilterValue;
        continue;
      }

    }

    // BEGIN, CR00202673, ZV
    final CaseTypeFilterDetails caseTypeFilterDetails = new CaseTypeFilterDetails();

    caseTypeFilterDetails.caseSearchFilterInd = false;
    caseTypeFilterDetails.myCasesFilterInd = true;

    myCasesFilterList.typeDtlsList = getCaseTypeFilterList(
        caseTypeFilterDetails);
    // END, CR00202673

    String initialCaseTypeList = new String();
    String initialCaseStatusList = new String();
    String initialCaseOwnerList = new String();

    for (int i = 0; i < myCasesFilterList.typeDtlsList.dtlsList.size(); i++) {

      initialCaseTypeList += myCasesFilterList.typeDtlsList.dtlsList
          .item(i).categoryType + CuramConst.gkTabDelimiter;
    }

    // remove last tab delimiter from the tab delimited string
    if (initialCaseTypeList.length() > CuramConst.gkZero) {
      initialCaseTypeList = initialCaseTypeList.substring(CuramConst.gkZero,
          initialCaseTypeList.length() - CuramConst.gkTabDelimiter.length());
    }

    // BEGIN, CR00202673, ZV
    myCasesFilterList.statusDtlsList = getCaseStatusFilterList();

    for (int i = 0; i < myCasesFilterList.statusDtlsList.dtlsList.size(); i++) {

      final String statusCode = myCasesFilterList.statusDtlsList.dtlsList
          .item(i).statusCode;

      // by default select all case statuses except closed
      if (!statusCode.equals(CASESEARCHSTATUS.CLOSED)) {
        initialCaseStatusList += statusCode + CuramConst.gkTabDelimiter;
      }
    }
    // END, CR00202673

    // remove last tab delimiter from the tab delimited string
    if (initialCaseStatusList.length() > CuramConst.gkZero) {
      initialCaseStatusList = initialCaseStatusList.substring(CuramConst.gkZero,
          initialCaseStatusList.length() - CuramConst.gkTabDelimiter.length());
    }

    myCasesFilterList.ownerDtlsList = getCaseOwnerFilterList(
        caseTypeFilterDetails);

    for (int i = 0; i < myCasesFilterList.ownerDtlsList.dtlsList.size(); i++) {

      initialCaseOwnerList += myCasesFilterList.ownerDtlsList.dtlsList
          .item(i).ownerType + CuramConst.gkTabDelimiter;
    }

    // remove last tab delimiter from the tab delimited string
    if (initialCaseOwnerList.length() > CuramConst.gkZero) {
      initialCaseOwnerList = initialCaseOwnerList.substring(CuramConst.gkZero,
          initialCaseOwnerList.length() - CuramConst.gkTabDelimiter.length());
    }

    // set default or stored case search filter values
    if (userSearchFilterDataList.dtlsList.isEmpty()) {
      myCasesFilterList.categoryTypeList = initialCaseTypeList;
      myCasesFilterList.statusList = initialCaseStatusList;
      myCasesFilterList.ownerList = initialCaseOwnerList;
    } else {
      myCasesFilterList.categoryTypeList = storedCaseTypeList;
      myCasesFilterList.statusList = storedCaseStatusList;
      myCasesFilterList.ownerList = storedCaseOwnerList;
    }
    // END, CR00174336

    return myCasesFilterList;
  }

  // BEGIN, CR00203865, ZV
  // BEGIN, CR00201195, ZV
  /**
   * This method replaces the deprecated method {@link #curam
   * #listCasesForOrgObject()} Method to perform a case search based on search
   * criteria which includes owner list passed as tab delimited string. Owner
   * can be any organizational object.
   *
   * @param caseSearchCriteria
   *          data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           {@link BPOCASESEARCH#ERR_BPOCASESEARCH_FV_OWNER_EMPTY} - If the
   *           case owner is not specified.
   */
  @Override
  public CaseSearchAndLastTransactionDetailsList searchCaseByOwner(
      final CaseSearchCriteria1 caseSearchCriteria)
      throws AppException, InformationalException {

    CaseSearchAndLastTransactionDetailsList caseSearchDetailsList = new CaseSearchAndLastTransactionDetailsList();

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    if (caseSearchCriteria.ownerList.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_FV_OWNER_EMPTY),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);

    }

    informationalManager.failOperation();

    if (caseSearchCriteria.categoryTypeList.length() == CuramConst.gkZero) {
      // BEGIN, CR00210281, ZV
      caseSearchCriteria.categoryList = CASECATEGORY.INTEGRATEDCASE
          + CuramConst.gkTabDelimiter + CASECATEGORY.PRODUCTDELIVERY
          + CuramConst.gkTabDelimiter + CASECATEGORY.LIABILITY;
      // END, CR00210281
    }

    CaseSearchList1 caseSearchList = new CaseSearchList1();

    final CaseSearchRouter caseSearchRouterObj = CaseSearchRouterFactory
        .newInstance();

    try {
      caseSearchList = caseSearchRouterObj.search1(caseSearchCriteria);

    } catch (final AppException ae) {
      if (!ae.getCatEntry().equals(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH)) {
        throw ae;
      }
    }

    // BEGIN, CR00211297, CW
    // Remove any net zero payment correction cases from the list
    // as these should never be displayed to the user
    removeNetZeroCasesFromList(caseSearchList);
    // END, CR00211297

    // Remove filtered out cases if case type is not provided
    if (caseSearchCriteria.categoryTypeList.length() == CuramConst.gkZero) {
      filterMyCasesResult(caseSearchList);
    }

    // BEGIN, CR00202673, ZV
    caseSearchDetailsList = assignCaseSearchResult(caseSearchList);
    // END, CR00202673
    // BEGIN, CR00230649, JMA
    final Case caseObj = CaseFactory.newInstance();
    CaseContextPanelKey caseContextPanelKey;

    for (final CaseSearchAndLastTransactionDetails details : caseSearchDetailsList.searchDtls) {

      caseContextPanelKey = new CaseContextPanelKey();

      caseContextPanelKey.caseID = details.caseID;

      details.caseContextDetailsURL = caseObj
          .resolveContextPanel(caseContextPanelKey).homePageName;
    }
    // END, CR00230649
    final CaseSearchCriteriaValue caseSearchCriteriaValue = getCaseSearchCriteriaText(
        caseSearchCriteria);

    caseSearchDetailsList.criteriaText = caseSearchCriteriaValue.criteriaText;

    return caseSearchDetailsList;
  }

  // END, CR00201195
  // END, CR00203865

  /**
   * Method to return available user related organization object list based on
   * which case search by owner operation may be performed.
   *
   * @param details
   *          filter indicators for my cases or case search options
   *
   * @return Configured cases owner details list
   */
  @Override
  public CaseOwnerTypeDetailsList getCaseOwnerFilterList(
      final CaseTypeFilterDetails details)
      throws AppException, InformationalException {

    final CaseOwnerTypeDetailsList caseOwnerTypeDetailsList = new CaseOwnerTypeDetailsList();

    final CaseOwnerList caseOwnerList = getCaseOwnerList(details);

    CaseOwnerTypeDetails caseOwnerTypeDetails;

    for (int i = 0; i < caseOwnerList.dtlsList.size(); i++) {

      caseOwnerTypeDetails = new CaseOwnerTypeDetails();

      final CaseOwnerDetails caseOwnerDetails = caseOwnerList.dtlsList.item(i);

      caseOwnerTypeDetails.ownerType = caseOwnerDetails.orgObjectType
          + CuramConst.gkPipeDelimiter;

      if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

        caseOwnerTypeDetails.ownerType += caseOwnerDetails.userName;
        // BEGIN, CR00329210, ZV
        caseOwnerTypeDetails.ownerDescription = new LocalisableString(
            GENERALSEARCH.INF_SEARCH_CURRENT_USER)
                .getMessage(TransactionInfo.getProgramLocale());
        // END, CR00329210

      } else {

        caseOwnerTypeDetails.ownerType += Long
            .toString(caseOwnerDetails.orgObjectReference);
        // BEGIN, CR00329210, ZV
        caseOwnerTypeDetails.ownerDescription = new LocalisableString(
            GENERALSEARCH.INF_SEARCH_CURRENT_USER_ORG_OBJECT)
                .arg(caseOwnerDetails.orgObjectReferenceName)
                .arg(new CodeTableItemIdentifier(ORGOBJECTTYPE.TABLENAME,
                    caseOwnerDetails.orgObjectType))
                .getMessage(TransactionInfo.getProgramLocale());
        // END, CR00329210
      }

      caseOwnerTypeDetailsList.dtlsList.addRef(caseOwnerTypeDetails);

    }

    return caseOwnerTypeDetailsList;
  }

  /**
   * Stores user case search criteria values.
   *
   * @param caseSearchCriteria
   *          User Case search criteria values to be stored.
   *
   * @throws InformationalException
   *           {@link BPOCASESEARCH#ERR_BPOCASESEARCH_FV_OWNER_EMPTY} - If the
   *           case owner is not specified.
   */
  @Override
  public void storeCaseSearchCriteria(
      final CaseSearchCriteria1 caseSearchCriteria)
      throws AppException, InformationalException {

    // BEGIN, CR00167930 ZV
    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    if (caseSearchCriteria.ownerList.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_FV_OWNER_EMPTY),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);

    }

    // BEGIN, CR00202080 ZV
    final CaseSearchRouter caseSearchRouterObj = CaseSearchRouterFactory
        .newInstance();

    caseSearchRouterObj.validateTypeAndStatus(caseSearchCriteria);
    // END, CR00202080

    informationalManager.failOperation();
    // END CR00167930

    final UserSearchFilter userSearchFilterObj = UserSearchFilterFactory
        .newInstance();
    final UserSearchFilterDetails userSearchFilterDetails = new UserSearchFilterDetails();

    userSearchFilterDetails.userName = TransactionInfo.getProgramUser();
    userSearchFilterDetails.userSearchType = USERSEARCHTYPE.CASE;

    UserSearchFilterData userSearchFilterData = new UserSearchFilterData();

    userSearchFilterData.userSearchFilterType = CuramConst.kUserSearchCaseTypeList;
    userSearchFilterData.userSearchFilterValue = caseSearchCriteria.categoryTypeList;

    userSearchFilterDetails.filterDetails.dtlsList.addRef(userSearchFilterData);

    userSearchFilterData = new UserSearchFilterData();

    userSearchFilterData.userSearchFilterType = CuramConst.kUserSearchCaseStatusList;
    userSearchFilterData.userSearchFilterValue = caseSearchCriteria.statusList;

    userSearchFilterDetails.filterDetails.dtlsList.addRef(userSearchFilterData);

    userSearchFilterData = new UserSearchFilterData();

    userSearchFilterData.userSearchFilterType = CuramConst.kUserSearchCaseOwnerList;
    userSearchFilterData.userSearchFilterValue = caseSearchCriteria.ownerList;

    userSearchFilterDetails.filterDetails.dtlsList.addRef(userSearchFilterData);

    userSearchFilterObj.createOrModify(userSearchFilterDetails);

  }

  // END, CR00165038

  // BEGIN, CR00167930, ZV
  /**
   * Returns case search criteria text value.
   *
   * @param details
   *          Case search criteria details.
   *
   * @return Case search criteria text value
   */
  @Override
  public CaseSearchCriteriaValue getCaseSearchCriteriaText(
      final CaseSearchCriteria1 details)
      throws AppException, InformationalException {

    final CaseSearchCriteriaValue caseSearchCriteriaValue = new CaseSearchCriteriaValue();

    // BEGIN CR00327929, ZV
    // BEGIN CR00174336, ZV
    String typeList = new String();

    final DataStringList dataList = new DataStringList();

    if (!details.categoryTypeList.isEmpty()) {

      dataList.list = details.categoryTypeList;

      typeList = getSearchCriteriaCaseTypeList(dataList).list;

    }

    String ownerList = new String();

    if (!details.ownerList.isEmpty()) {

      dataList.list = details.ownerList;

      ownerList = getSearchCriteriaOwnerList(dataList).list;

    }

    String statusList = new String();

    if (!details.statusList.isEmpty()) {

      dataList.list = details.statusList;

      statusList = getSearchCriteriaStatusList(dataList).list;

    }

    // check if all case types are selected
    final MyCasesFilterList myCasesFilterList = getMyCasesFilterList();

    final boolean allTypesInd = myCasesFilterList.typeDtlsList.dtlsList
        .size() == StringUtil
            .tabText2StringListWithTrim(details.categoryTypeList).size();

    // BEGIN CR00331517, ZV
    LocalisableString localisableString = null;

    if (allTypesInd) {
      if (statusList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_ALL_TYPES_OWNER);
        localisableString.arg(ownerList);
      } else {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_ALL_TYPES_OWNER_STATUS);
        localisableString.arg(ownerList);
        localisableString.arg(statusList);
      }
    } else {
      if (statusList.isEmpty() && details.categoryTypeList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_OWNER);
        localisableString.arg(ownerList);
      } else if (!statusList.isEmpty() && details.categoryTypeList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_OWNER_STATUS);
        localisableString.arg(ownerList);
        localisableString.arg(statusList);
      } else if (statusList.isEmpty() && !details.categoryTypeList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_TYPE_OWNER);
        localisableString.arg(typeList);
        localisableString.arg(ownerList);
      } else {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_TYPE_OWNER_STATUS);
        localisableString.arg(typeList);
        localisableString.arg(ownerList);
        localisableString.arg(statusList);
      }
    }

    caseSearchCriteriaValue.criteriaText = localisableString
        .getMessage(curam.util.transaction.TransactionInfo.getProgramLocale());
    // END CR00331517
    // END CR00327929
    // END CR00174336

    return caseSearchCriteriaValue;
  }

  // END, CR00167930

  // BEGIN, CR00175976, ZV
  /**
   * Method to return work queue subscribed by current user or by current user
   * associated organization object list.
   *
   * @param details
   *          filter too indicate if owner list should be filtered by my cases
   *          or case search configuration
   *
   * @return Configured work queue owner details list
   */
  @Override
  public CaseOwnerList getCaseOwnerWorkQueueList(
      final CaseTypeFilterDetails details)
      throws AppException, InformationalException {

    final CaseOwnerList caseOwnerList = new CaseOwnerList();

    final boolean searchByPositionOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_CASES_SEARCH_BY_POSITION);
    final boolean searchByOrganizationUnitOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_CASES_SEARCH_BY_ORGANIZATION_UNIT);

    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    // BEGIN, CR00226714, LP
    CurrentUserWorkQueueAndSubscriberDetailsList workQueueDetailsList;
    // END, CR00226714

    CaseOwnerDetails caseOwnerDetails;

    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = TransactionInfo.getProgramUser();

    final ArrayList<CaseOwnerDetails> workQueueList = new ArrayList<CaseOwnerDetails>();

    final curam.core.sl.entity.intf.WorkQueue workQueueEntityObj = curam.core.sl.entity.fact.WorkQueueFactory
        .newInstance();

    final CurrentUserWorkQueueKey currentUserWorkQueueKey = new CurrentUserWorkQueueKey();

    currentUserWorkQueueKey.userName = userNameKey.userName;
    // BEGIN, CR00226714, LP
    workQueueDetailsList = workQueueEntityObj
        .searchWorkQueuesForUser(currentUserWorkQueueKey);
    // END, CR00226714

    for (int i = 0; i < workQueueDetailsList.dtls.size(); i++) {

      caseOwnerDetails = new CaseOwnerDetails();

      caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;
      caseOwnerDetails.orgObjectReference = workQueueDetailsList.dtls
          .item(i).workQueueID;
      caseOwnerDetails.orgObjectReferenceName = workQueueDetailsList.dtls
          .item(i).workQueueName;

      workQueueList.add(caseOwnerDetails);
    }

    if (!(details.caseSearchFilterInd && details.myCasesFilterInd)
        || details.caseSearchFilterInd && searchByPositionOwnerInd
        || details.myCasesFilterInd && searchByPositionOwnerInd) {

      workQueueDetailsList = workQueueObj
          .getUserPositionWorkQueues(userNameKey);

      for (int i = 0; i < workQueueDetailsList.dtls.size(); i++) {
        // BEGIN, CR00226714, LP
        final CurrentUserWorkQueueAndSubscriberDetails currentWQDtls = workQueueDetailsList.dtls
            .item(i);

        boolean workQueueExistInd = false;

        for (int j = 0; j < workQueueList.size(); j++) {
          if (currentWQDtls.workQueueID == workQueueList
              .get(j).orgObjectReference) {
            // END, CR00226714
            workQueueExistInd = true;
            break;
          }
        }

        if (!workQueueExistInd) {
          caseOwnerDetails = new CaseOwnerDetails();

          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;

          // BEGIN, CR00226714, LP
          caseOwnerDetails.orgObjectReference = currentWQDtls.workQueueID;
          caseOwnerDetails.orgObjectReferenceName = currentWQDtls.workQueueName;
          // END, CR00226714

          workQueueList.add(caseOwnerDetails);
        }

      }

    }

    if (!(details.caseSearchFilterInd && details.myCasesFilterInd)
        || details.caseSearchFilterInd && searchByOrganizationUnitOwnerInd
        || details.myCasesFilterInd && searchByOrganizationUnitOwnerInd) {

      workQueueDetailsList = workQueueObj.getUserOrgUnitWorkQueues(userNameKey);

      for (int i = 0; i < workQueueDetailsList.dtls.size(); i++) {

        // BEGIN, CR00226714, LP
        final CurrentUserWorkQueueAndSubscriberDetails currentWQDtls = workQueueDetailsList.dtls
            .item(i);
        boolean workQueueExistInd = false;

        for (int j = 0; j < workQueueList.size(); j++) {
          if (currentWQDtls.workQueueID == workQueueList
              .get(j).orgObjectReference) {
            // END, CR00226714
            workQueueExistInd = true;
            break;
          }
        }

        if (!workQueueExistInd) {
          caseOwnerDetails = new CaseOwnerDetails();

          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;
          caseOwnerDetails.orgObjectReference = workQueueDetailsList.dtls
              .item(i).workQueueID;
          caseOwnerDetails.orgObjectReferenceName = workQueueDetailsList.dtls
              .item(i).workQueueName;
          workQueueList.add(caseOwnerDetails);
        }

      }
    }

    // sort work queues by name and add into owner list
    final Comparator<CaseOwnerDetails> workQueueNameComparator = new OwnerWorkQueueNameComparator();

    Collections.sort(workQueueList, workQueueNameComparator);

    for (int i = 0; i < workQueueList.size(); i++) {
      caseOwnerList.dtlsList.addRef(workQueueList.get(i));
    }

    return caseOwnerList;
  }

  /*
   * Comparator used to order a owner work queue list by name
   */
  public class OwnerWorkQueueNameComparator
      implements Comparator<CaseOwnerDetails> {

    public OwnerWorkQueueNameComparator() {

      super();
    }

    @Override
    public int compare(final CaseOwnerDetails struct1,
        final CaseOwnerDetails struct2) {

      return struct1.orgObjectReferenceName
          .compareTo(struct2.orgObjectReferenceName);
    }

  }

  // END, CR00175976

  // BEGIN, CR00201195, ZV
  /**
   * Method to perform a case search
   *
   * @param caseSearchCriteria
   *          data on which the searched will be based
   *
   * @return The details of any records found
   */
  @Override
  public CaseSearchList1 search1(final CaseSearchCriteria1 caseSearchCriteria)
      throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
            new AppException(BPOCASESEARCH.ERR_CASESEARCH_UNIMPLEMENTED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
    // Should not reach this point without throwing a validation
    return null;
  }

  /**
   * Method to filter out cases from my cases result
   *
   * @param details
   *          Found case details list
   */
  @Override
  protected void filterMyCasesResult(final CaseSearchList1 details)
      throws AppException, InformationalException {

    CaseTypeFilterDetails caseTypeFilterDetails = new CaseTypeFilterDetails();

    for (int i = 0; i < details.searchDtls.size(); i++) {

      final CaseSearchDetails1 caseSearchDetails = details.searchDtls.item(i);

      // BEGIN, CR00210281, ZV
      if (caseSearchDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
          || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {
        // END, CR00210281
        final ProductDelivery productDeliveryObj = ProductDeliveryFactory
            .newInstance();
        final CaseIDKey caseIDKey = new CaseIDKey();

        caseIDKey.caseID = caseSearchDetails.caseID;

        caseTypeFilterDetails = productDeliveryObj
            .readProductFilterDetailsByCaseID(caseIDKey);

      } else if (caseSearchDetails.caseTypeCode
          .equals(CASETYPECODE.INTEGRATEDCASE)) {
        final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
        final CaseIDKey caseIDKey = new CaseIDKey();

        caseIDKey.caseID = caseSearchDetails.caseID;

        caseTypeFilterDetails = caseHeaderObj
            .readIntegratedCaseFilterDetailsByCaseID(caseIDKey);

      }

      // BEGIN, CR00210281, ZV
      if ((caseSearchDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
          || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.LIABILITY)
          || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE))
          && !caseTypeFilterDetails.myCasesFilterInd) {
        // END, CR00210281
        details.searchDtls.remove(i--);
      }

    }

  }

  // END, CR00201195

  // BEGIN, CR00202080, ZV
  /**
   * Method to perform integrated case or product delivery case search by search
   * criteria.
   *
   * @param key
   *          Contains the case search criteria.
   *
   * @return Details for the list of cases found.
   */
  @Override
  public CaseSearchList1 caseSearch(
      final CaseSearchCriteria1 caseSearchCriteria)
      throws AppException, InformationalException {

    CaseSearchList1 caseSearchList = new CaseSearchList1();

    // Case Search Router object.
    final CaseSearchRouter caseSearchRouterObj = CaseSearchRouterFactory
        .newInstance();

    if (caseSearchCriteria.categoryTypeList.length() == CuramConst.gkZero) {
      // BEGIN, CR00210281, ZV
      caseSearchCriteria.categoryList = CASECATEGORY.INTEGRATEDCASE
          + CuramConst.gkTabDelimiter + CASECATEGORY.PRODUCTDELIVERY
          + CuramConst.gkTabDelimiter + CASECATEGORY.LIABILITY;
      // END, CR00210281
    }

    caseSearchList = caseSearchRouterObj.search1(caseSearchCriteria);

    // BEGIN, CR00211297, CW
    // Remove any net zero payment correction cases from the list
    // as these should never be displayed to the user
    removeNetZeroCasesFromList(caseSearchList);
    // END, CR00211297

    // Remove filtered out cases if case type is not provided
    if (caseSearchCriteria.categoryTypeList.length() == CuramConst.gkZero) {
      filterCaseSearchResult(caseSearchList, caseSearchCriteria);
    }

    return caseSearchList;
  }

  // BEGIN, CR00211297, CW
  /**
   * Method to remove any net zero style payment correction cases from the given
   * case list.
   *
   * @param caseSearchList
   *          The list of cases.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  protected void removeNetZeroCasesFromList(
      final CaseSearchList1 caseSearchList)
      throws AppException, InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    for (int i = 0; i < caseSearchList.searchDtls.size(); i++) {

      caseHeaderKey.caseID = caseSearchList.searchDtls.item(i).caseID;

      if (paymentCorrection.isPaymentCorrectionCase(caseHeaderKey)
          && paymentCorrection.isNetZeroPaymentCorrection(caseHeaderKey)) {

        caseSearchList.searchDtls.remove(i--);
      }
    }
  }

  // END, CR00211297

  /**
   * Method to filter out cases from case search result.
   *
   * @param details
   *          Found case details list
   * @param searchCiteria
   *          data on which the case search was based
   *
   * @throws InformationalException
   *           {@link BPOCASESEARCH#ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED} -
   *           If case reference is specified and case found is of type which
   *           should net be displayed in case search results.
   */
  @Override
  protected void filterCaseSearchResult(final CaseSearchList1 details,
      final CaseSearchCriteria1 searchCiteria)
      throws AppException, InformationalException {

    CaseTypeFilterDetails caseTypeFilterDetails = new CaseTypeFilterDetails();

    for (int i = 0; i < details.searchDtls.size(); i++) {

      final CaseSearchDetails1 caseSearchDetails = details.searchDtls.item(i);

      // BEGIN, CR00364812, CSH
      if (caseSearchDetails.caseTypeCode
          .equals(CASETYPECODE.PARTICIPANTDATACASE)) {

        details.searchDtls.remove(i--);
        continue;
      }
      // END, CR00364812

      // BEGIN, CR00210281, ZV
      if (caseSearchDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
          || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.LIABILITY)) {
        // END, CR00210281
        final ProductDelivery productDeliveryObj = ProductDeliveryFactory
            .newInstance();
        final CaseIDKey caseIDKey = new CaseIDKey();

        caseIDKey.caseID = caseSearchDetails.caseID;

        caseTypeFilterDetails = productDeliveryObj
            .readProductFilterDetailsByCaseID(caseIDKey);

      } else if (caseSearchDetails.caseTypeCode
          .equals(CASETYPECODE.INTEGRATEDCASE)) {
        final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
        final CaseIDKey caseIDKey = new CaseIDKey();

        caseIDKey.caseID = caseSearchDetails.caseID;

        caseTypeFilterDetails = caseHeaderObj
            .readIntegratedCaseFilterDetailsByCaseID(caseIDKey);

      }

      // BEGIN, CR00210281, ZV
      if ((caseSearchDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
          || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.LIABILITY)
          || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE))
          && !caseTypeFilterDetails.caseSearchFilterInd) {
        // END, CR00210281

        if (searchCiteria.caseReference.length() > CuramConst.gkZero) {

          final InformationalManager informationalManager = TransactionInfo
              .getInformationalManager();

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().addInfoMgrExceptionWithLookup(
                  new AppException(
                      BPOCASESEARCH.INF_BPOCASESEARCH_CASE_NOT_SEARCHABLE),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);

          informationalManager.failOperation();

        }

        details.searchDtls.remove(i--);
      }
    }
  }

  // END, CR00202080

  // BEGIN, CR00202673, ZV
  /**
   * Method converts case search results into case details with last
   * transaction.
   *
   * @param result
   *          Case search details list
   *
   * @return case search details with last transaction list
   */
  @Override
  public CaseSearchAndLastTransactionDetailsList assignCaseSearchResult(
      final CaseSearchList1 result)
      throws AppException, InformationalException {

    final CaseSearchAndLastTransactionDetailsList returnList = new CaseSearchAndLastTransactionDetailsList();

    CaseSearchAndLastTransactionDetails caseSearchDetails;
    final CaseIDKey caseIDKey = new CaseIDKey();

    for (int i = 0; i < result.searchDtls.size(); i++) {

      caseSearchDetails = new CaseSearchAndLastTransactionDetails();

      caseSearchDetails.assign(result.searchDtls.item(i));
      // BEGIN, 191389, GG
      if (Configuration.getBooleanProperty(EnvVars.ENV_DISPLAY_CASE_CLIENTS)) {
        caseSearchDetails.caseClientsOpt = caseClientsPopulationHook
            .populateCaseClients(caseSearchDetails.caseID,
                caseSearchDetails.caseTypeCode,
                result.searchDtls.item(i).cprClientsOpt,
                result.searchDtls.item(i).cgMembersOpt);
      }
      // END, 191389
      caseIDKey.caseID = caseSearchDetails.caseID;

      // BEGIN, CR00295753, ZV
      if (!result.searchDtls.item(i).restricted) {
        // read last transaction details
        final ReadTransactionLogDetailsList readTransactionLogDetailsList = caseTransactionLogProvider
            .get().readNumberOfTransactions(caseIDKey);

        if (!readTransactionLogDetailsList.dtlsList.isEmpty()) {

          final ReadTransactionLogDetails readTransactionLogDetails = readTransactionLogDetailsList.dtlsList
              .item(CuramConst.gkZero);

          final LocalisableString lastTransactionDetails = new LocalisableString(
              BPOCASESEARCH.INF_BPOCASESEARCH_LAST_TRANSACTION);

          // Add the items to the localizable string
          lastTransactionDetails.arg(readTransactionLogDetails.eventTypeDesc);
          lastTransactionDetails
              .arg(new Date(readTransactionLogDetails.transactionDateTime));

          caseSearchDetails.transactionDescription = lastTransactionDetails
              .getMessage(TransactionInfo.getProgramLocale());

        }
      }
      // END, CR00295753

      returnList.searchDtls.addRef(caseSearchDetails);
    }

    return returnList;
  }

  /**
   * Method to return case filter option list used for case search.
   *
   * @return case filter option list
   */
  @Override
  public CaseFilterOptionDetailsList getCaseFilterOptionList()
      throws AppException, InformationalException {

    final CaseFilterOptionDetailsList caseFilterOptionDetailsList = new CaseFilterOptionDetailsList();

    // Get case search filter options for locale value and codetable
    final java.util.LinkedHashMap<String, String> caseFilterOptionList = CodeTable
        .getAllEnabledItems(CASESEARCHFILTER.TABLENAME,
            TransactionInfo.getProgramLocale());

    CaseFilterOptionDetails caseFilterOptionDetails;

    if (!caseFilterOptionList.isEmpty()) {

      final Set<String> keys = caseFilterOptionList.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        caseFilterOptionDetails = new CaseFilterOptionDetails();

        caseFilterOptionDetails.filterOption = itr.next();
        caseFilterOptionDetails.filterOptionDescription = caseFilterOptionList
            .get(caseFilterOptionDetails.filterOption);

        caseFilterOptionDetailsList.dtlsList.addRef(caseFilterOptionDetails);
      }
    }

    return caseFilterOptionDetailsList;

  }

  /**
   * Method to return case status list used for case search.
   *
   * @return case status list
   */
  @Override
  public CaseStatusFilterDetailsList getCaseStatusFilterList()
      throws AppException, InformationalException {

    final CaseStatusFilterDetailsList caseStatusFilterDetailsList = new CaseStatusFilterDetailsList();

    // Get case search status filter options for locale value and codetable
    final java.util.LinkedHashMap<String, String> caseStatusFilterOptionList = CodeTable
        .getAllEnabledItems(CASESEARCHSTATUS.TABLENAME,
            TransactionInfo.getProgramLocale());

    CaseStatusFilterDetails caseStatusFilterDetails;

    if (!caseStatusFilterOptionList.isEmpty()) {

      final Set<String> keys = caseStatusFilterOptionList.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        caseStatusFilterDetails = new CaseStatusFilterDetails();

        caseStatusFilterDetails.statusCode = itr.next();
        caseStatusFilterDetails.statusDescription = caseStatusFilterOptionList
            .get(caseStatusFilterDetails.statusCode);

        caseStatusFilterDetailsList.dtlsList.addRef(caseStatusFilterDetails);
      }
    }

    return caseStatusFilterDetailsList;
  }

  /**
   * Method to return case type list used for case search.
   *
   * @param details
   *          contains optional my cases or case search filter indicators
   *
   * @return case category and type details list
   */
  @Override
  public CaseCategoryTypeDetailsList getCaseTypeFilterList(
      final CaseTypeFilterDetails details)
      throws AppException, InformationalException {

    final CaseCategoryTypeDetailsList caseCategoryTypeDetailsList = new CaseCategoryTypeDetailsList();

    // populate case type code list
    CaseCategoryTypeDetails caseCategoryTypeDetails;

    final ArrayList<CaseCategoryTypeDetails> caseTypes = new ArrayList<CaseCategoryTypeDetails>();

    // Product manipulation variables
    final Product productObj = ProductFactory.newInstance();
    final StatusCodeKeyStruct statusCodeKeyStruct = new StatusCodeKeyStruct();

    // Get all products
    final ProductFilterDtlsList productFilterDtlsList = productObj
        .searchActiveProductForFilter(statusCodeKeyStruct);

    for (int i = 0; i < productFilterDtlsList.dtls.size(); i++) {

      final ProductFilterDtls productFilterDtls = productFilterDtlsList.dtls
          .item(i);

      // BEGIN, CR00231396, ZV
      if (!(details.caseSearchFilterInd || details.myCasesFilterInd)
          || details.caseSearchFilterInd
              && productFilterDtls.caseSearchFilterInd
          || details.myCasesFilterInd && productFilterDtls.myCasesFilterInd) {
        // END, CR00231396

        caseCategoryTypeDetails = new CaseCategoryTypeDetails();

        if (productFilterDtls.benefitInd) {
          caseCategoryTypeDetails.categoryType = CASECATEGORY.PRODUCTDELIVERY;
        } else {
          caseCategoryTypeDetails.categoryType = CASECATEGORY.LIABILITY;
        }

        caseCategoryTypeDetails.categoryType += CuramConst.gkPipeDelimiter
            + productFilterDtls.name;
        caseCategoryTypeDetails.typeDescription = CodeTable
            .getOneItem(PRODUCTNAME.TABLENAME, productFilterDtls.name);

        caseTypes.add(caseCategoryTypeDetails);

      }

    }

    final curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory
        .newInstance();
    final AdminIntegratedCaseByStatusCodeKey adminIntegratedCaseByStatusCodeKey = new AdminIntegratedCaseByStatusCodeKey();

    // Get the list of integrated cases
    final AdminIntegratedCaseFilterDtlsList adminIntegratedCaseFilterDtlsList = adminIntegratedCaseObj
        .searchActiveAdminIntegratedCaseForFilter(
            adminIntegratedCaseByStatusCodeKey);

    for (int i = 0; i < adminIntegratedCaseFilterDtlsList.dtls.size(); i++) {

      // BEGIN, CR00231396, ZV
      if (!(details.caseSearchFilterInd || details.myCasesFilterInd)
          || details.caseSearchFilterInd
              && adminIntegratedCaseFilterDtlsList.dtls
                  .item(i).caseSearchFilterInd
          || details.myCasesFilterInd && adminIntegratedCaseFilterDtlsList.dtls
              .item(i).myCasesFilterInd) {
        // END, CR00231396

        caseCategoryTypeDetails = new CaseCategoryTypeDetails();

        final String caseType = adminIntegratedCaseFilterDtlsList.dtls
            .item(i).integratedCaseType;

        caseCategoryTypeDetails.categoryType = CASECATEGORY.INTEGRATEDCASE
            + CuramConst.gkPipeDelimiter + caseType;
        caseCategoryTypeDetails.typeDescription = CodeTable
            .getOneItem(PRODUCTCATEGORY.TABLENAME, caseType);

        caseTypes.add(caseCategoryTypeDetails);
      }
    }

    // Sort the case type values by description
    final Comparator<CaseCategoryTypeDetails> caseTypeComparator = new CaseTypeComparator();

    Collections.sort(caseTypes, caseTypeComparator);

    for (int i = 0; i < caseTypes.size(); i++) {

      caseCategoryTypeDetailsList.dtlsList.addRef(caseTypes.get(i));
    }

    return caseCategoryTypeDetailsList;
  }

  /**
   * Method to return configured cases owned by list. For example, where the
   * administrator has configured that cases are owned by users and positions,
   * this list will contain the current user and the positions to which they are
   * assigned in the organization structure e.g. Eligibility Specialist
   * Position, Supervisor Position.
   *
   * @param details
   *          filter indicators for my cases or case search options
   *
   * @return Configured cases owner details list
   */
  @Override
  public CaseOwnerList getCaseOwnerList(final CaseTypeFilterDetails details)
      throws AppException, InformationalException {

    final CaseOwnerList caseOwnerList = new CaseOwnerList();

    final boolean searchByUserOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_CASES_SEARCH_BY_USER);

    CaseOwnerDetails caseOwnerDetails;

    if (!(details.caseSearchFilterInd && details.myCasesFilterInd)
        || details.caseSearchFilterInd && searchByUserOwnerInd
        || details.myCasesFilterInd && searchByUserOwnerInd) {

      caseOwnerDetails = new CaseOwnerDetails();

      caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;
      caseOwnerDetails.userName = TransactionInfo.getProgramUser();

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();
      UserFullname userFullName;

      usersKey.userName = caseOwnerDetails.userName;

      userFullName = userAccessObj.getFullName(usersKey);

      caseOwnerDetails.orgObjectReferenceName = userFullName.fullname;

      caseOwnerList.dtlsList.addRef(caseOwnerDetails);

    }

    final boolean searchByPositionOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_CASES_SEARCH_BY_POSITION);

    if (!(details.caseSearchFilterInd && details.myCasesFilterInd)
        || details.caseSearchFilterInd && searchByPositionOwnerInd
        || details.myCasesFilterInd && searchByPositionOwnerInd) {

      final ListUserPositionDetails listUserPositionDetails = PositionFactory
          .newInstance().getPositionsForUser();

      for (int i = 0; i < listUserPositionDetails.dtlsList.dtls.size(); i++) {

        caseOwnerDetails = new CaseOwnerDetails();

        caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.POSITION;
        caseOwnerDetails.orgObjectReference = listUserPositionDetails.dtlsList.dtls
            .item(i).positionID;
        caseOwnerDetails.orgObjectReferenceName = listUserPositionDetails.dtlsList.dtls
            .item(i).positionName;

        caseOwnerList.dtlsList.addRef(caseOwnerDetails);
      }

    }

    final boolean searchByOrganizationUnitOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_CASES_SEARCH_BY_ORGANIZATION_UNIT);

    if (!(details.caseSearchFilterInd && details.myCasesFilterInd)
        || details.caseSearchFilterInd && searchByOrganizationUnitOwnerInd
        || details.myCasesFilterInd && searchByOrganizationUnitOwnerInd) {

      final ListUserOrgUnitDetails listUserOrgUnitDetails = OrganisationUnitFactory
          .newInstance().getOrgUnitsForUser();

      for (int i = 0; i < listUserOrgUnitDetails.dtlsList.dtls.size(); i++) {

        caseOwnerDetails = new CaseOwnerDetails();

        caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.ORGUNIT;
        caseOwnerDetails.orgObjectReference = listUserOrgUnitDetails.dtlsList.dtls
            .item(i).organisationUnitID;
        caseOwnerDetails.orgObjectReferenceName = listUserOrgUnitDetails.dtlsList.dtls
            .item(i).name;

        caseOwnerList.dtlsList.addRef(caseOwnerDetails);
      }

    }

    final boolean searchByWorkQueueOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_CASES_SEARCH_BY_WORK_QUEUE);

    if (!(details.caseSearchFilterInd && details.myCasesFilterInd)
        || details.caseSearchFilterInd && searchByWorkQueueOwnerInd
        || details.myCasesFilterInd && searchByWorkQueueOwnerInd) {

      // BEGIN, CR00175976, ZV
      final CaseOwnerList workQueueOwnerList = getCaseOwnerWorkQueueList(
          details);

      caseOwnerList.dtlsList.addAll(workQueueOwnerList.dtlsList);
      // END, CR00175976
      // END, CR00172650

    }

    return caseOwnerList;
  }

  // END, CR00202673

  // BEGIN, CR00203865, ZV
  /**
   * Returns initial details to populate my investigation search filter lists.
   *
   * @return Initial details to populate my investigation search filter lists.
   */
  @Override
  public MyInvestigationFilterList getMyInvestigationFilterList()
      throws AppException, InformationalException {

    final MyInvestigationFilterList myInvestigationFilterList = new MyInvestigationFilterList();

    // get stored default case search filter values
    final UserSearchFilter userSearchFilterObj = UserSearchFilterFactory
        .newInstance();
    final UserNameAndUserSearchTypeDetails userNameAndUserSearchTypeDetails = new UserNameAndUserSearchTypeDetails();

    // get stored case search filter values
    userNameAndUserSearchTypeDetails.userName = TransactionInfo
        .getProgramUser();
    userNameAndUserSearchTypeDetails.userSearchType = USERSEARCHTYPE.INVESTIGATION;

    final UserSearchFilterDataList userSearchFilterDataList = userSearchFilterObj
        .read(userNameAndUserSearchTypeDetails);

    String storedInvestigationTypeList = new String();
    String storedInvestigationStatusList = new String();
    String storedInvestigationOwnerList = new String();

    for (int i = 0; i < userSearchFilterDataList.dtlsList.size(); i++) {

      final UserSearchFilterData userSearchFilterData = userSearchFilterDataList.dtlsList
          .item(i);

      if (userSearchFilterData.userSearchFilterType
          .equals(CuramConst.kUserSearchInvestigationTypeList)) {
        storedInvestigationTypeList = userSearchFilterData.userSearchFilterValue;
        continue;
      }
      if (userSearchFilterData.userSearchFilterType
          .equals(CuramConst.kUserSearchInvestigationStatusList)) {
        storedInvestigationStatusList = userSearchFilterData.userSearchFilterValue;
        continue;
      }
      if (userSearchFilterData.userSearchFilterType
          .equals(CuramConst.kUserSearchInvestigationOwnerList)) {
        storedInvestigationOwnerList = userSearchFilterData.userSearchFilterValue;
        continue;
      }

    }

    myInvestigationFilterList.typeDtlsList = getInvestigationTypeFilterList();

    String initialInvestigationTypeList = new String();
    String initialInvestigationStatusList = new String();
    String initialInvestigationOwnerList = new String();

    for (int i = 0; i < myInvestigationFilterList.typeDtlsList.dtlsList
        .size(); i++) {

      initialInvestigationTypeList += myInvestigationFilterList.typeDtlsList.dtlsList
          .item(i).investigationType + CuramConst.gkTabDelimiter;
    }

    // remove last tab delimiter from the tab delimited string
    if (initialInvestigationTypeList.length() > CuramConst.gkZero) {
      initialInvestigationTypeList = initialInvestigationTypeList
          .substring(CuramConst.gkZero, initialInvestigationTypeList.length()
              - CuramConst.gkTabDelimiter.length());
    }

    myInvestigationFilterList.statusDtlsList = getInvestigationStatusFilterList();

    for (int i = 0; i < myInvestigationFilterList.statusDtlsList.dtlsList
        .size(); i++) {

      final String statusCode = myInvestigationFilterList.statusDtlsList.dtlsList
          .item(i).statusCode;

      // by default select all case statuses except closed
      if (!statusCode.equals(CASESEARCHSTATUS.CLOSED)) {
        initialInvestigationStatusList += statusCode
            + CuramConst.gkTabDelimiter;
      }
    }

    // remove last tab delimiter from the tab delimited string
    if (initialInvestigationStatusList.length() > CuramConst.gkZero) {
      initialInvestigationStatusList = initialInvestigationStatusList
          .substring(CuramConst.gkZero, initialInvestigationStatusList.length()
              - CuramConst.gkTabDelimiter.length());
    }

    myInvestigationFilterList.ownerDtlsList = getInvestigationOwnerFilterList();

    for (int i = 0; i < myInvestigationFilterList.ownerDtlsList.dtlsList
        .size(); i++) {

      initialInvestigationOwnerList += myInvestigationFilterList.ownerDtlsList.dtlsList
          .item(i).ownerType + CuramConst.gkTabDelimiter;
    }

    // remove last tab delimiter from the tab delimited string
    if (initialInvestigationOwnerList.length() > CuramConst.gkZero) {
      initialInvestigationOwnerList = initialInvestigationOwnerList
          .substring(CuramConst.gkZero, initialInvestigationOwnerList.length()
              - CuramConst.gkTabDelimiter.length());
    }

    // set default or stored case search filter values
    if (userSearchFilterDataList.dtlsList.isEmpty()) {
      myInvestigationFilterList.typeList = initialInvestigationTypeList;
      myInvestigationFilterList.statusList = initialInvestigationStatusList;
      myInvestigationFilterList.ownerList = initialInvestigationOwnerList;
    } else {
      myInvestigationFilterList.typeList = storedInvestigationTypeList;
      myInvestigationFilterList.statusList = storedInvestigationStatusList;
      myInvestigationFilterList.ownerList = storedInvestigationOwnerList;
    }

    return myInvestigationFilterList;
  }

  /**
   * Method to perform an investigation search based on search criteria which
   * includes owner list passed as tab delimited string. Owner can be any
   * organizational object.
   *
   * @param searchCriteria
   *          data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           {@link BPOCASESEARCH# ERR_BPOCASESEARCH_FV_INVESTIGATION_OWNER_EMPTY}
   *           - If the investigation owner is not specified.
   */
  @Override
  public InvestigationSearchDetailsList searchInvestigationByOwner(
      final InvestigationSearchCriteria searchCriteria)
      throws AppException, InformationalException {

    InvestigationSearchDetailsList investigationSearchDetailsList = new InvestigationSearchDetailsList();

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    if (searchCriteria.ownerList.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(
                  BPOCASESEARCH.ERR_BPOCASESEARCH_FV_INVESTIGATION_OWNER_EMPTY),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);

    }

    informationalManager.failOperation();

    final CaseSearchRouter caseSearchRouterObj = CaseSearchRouterFactory
        .newInstance();

    try {
      investigationSearchDetailsList = caseSearchRouterObj
          .investigationSearch(searchCriteria);
    } catch (final AppException ae) {
      if (!ae.getCatEntry()
          .equals(BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_NO_MATCH)) {
        throw ae;
      }
    }

    final CaseSearchCriteriaValue caseSearchCriteriaValue = getInvestigationSearchCriteriaText(
        searchCriteria);

    investigationSearchDetailsList.criteriaText = caseSearchCriteriaValue.criteriaText;

    return investigationSearchDetailsList;
  }

  /**
   * Method to return investigation type list used for investigation search.
   *
   * @return investigation category and type details list
   */
  @Override
  public InvestigationTypeDetailsList getInvestigationTypeFilterList()
      throws AppException, InformationalException {

    final InvestigationTypeDetailsList investigationTypeDetailsList = new InvestigationTypeDetailsList();

    InvestigationTypeDetails investigationTypeDetails;

    InvestigationConfigurationTypeDtlsList investigationConfigurationTypeDtlsList = new InvestigationConfigurationTypeDtlsList();

    final InvestigationConfig investigationConfigObj = InvestigationConfigFactory
        .newInstance();

    investigationConfigurationTypeDtlsList = investigationConfigObj
        .searchAllInvestigationTypes();

    for (int i = 0; i < investigationConfigurationTypeDtlsList.dtls
        .size(); i++) {

      investigationTypeDetails = new InvestigationTypeDetails();

      investigationTypeDetails.investigationType = investigationConfigurationTypeDtlsList.dtls
          .item(i).type;
      investigationTypeDetails.typeDescription = CodeTable.getOneItem(
          INVESTIGATECONFIGTYPE.TABLENAME,
          investigationTypeDetails.investigationType);

      investigationTypeDetailsList.dtlsList.addRef(investigationTypeDetails);

    }

    // Sort the case type values by description
    final Comparator<InvestigationTypeDetails> investigationTypeComparator = new InvestigationTypeComparator();

    Collections.sort(investigationTypeDetailsList.dtlsList,
        investigationTypeComparator);

    return investigationTypeDetailsList;
  }

  /**
   * Method to return available user related organization object list based on
   * which investigation search by owner operation may be performed.
   *
   * @return Configured investigation owner details list
   */
  @Override
  public CaseOwnerTypeDetailsList getInvestigationOwnerFilterList()
      throws AppException, InformationalException {

    final CaseOwnerTypeDetailsList caseOwnerTypeDetailsList = new CaseOwnerTypeDetailsList();

    final CaseOwnerList caseOwnerList = getInvestigationOwnerList();

    CaseOwnerTypeDetails caseOwnerTypeDetails;

    for (int i = 0; i < caseOwnerList.dtlsList.size(); i++) {

      caseOwnerTypeDetails = new CaseOwnerTypeDetails();

      final CaseOwnerDetails caseOwnerDetails = caseOwnerList.dtlsList.item(i);

      caseOwnerTypeDetails.ownerType = caseOwnerDetails.orgObjectType
          + CuramConst.gkPipeDelimiter;

      if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

        caseOwnerTypeDetails.ownerType += caseOwnerDetails.userName;
        // BEGIN, CR00329210, ZV
        caseOwnerTypeDetails.ownerDescription = new LocalisableString(
            GENERALSEARCH.INF_SEARCH_CURRENT_USER)
                .getMessage(TransactionInfo.getProgramLocale());
        // END, CR00329210

      } else {

        caseOwnerTypeDetails.ownerType += Long
            .toString(caseOwnerDetails.orgObjectReference);
        // BEGIN, CR00329210, ZV
        caseOwnerTypeDetails.ownerDescription = new LocalisableString(
            GENERALSEARCH.INF_SEARCH_CURRENT_USER_ORG_OBJECT)
                .arg(caseOwnerDetails.orgObjectReferenceName)
                .arg(new CodeTableItemIdentifier(ORGOBJECTTYPE.TABLENAME,
                    caseOwnerDetails.orgObjectType))
                .getMessage(TransactionInfo.getProgramLocale());
        // END, CR00329210
      }

      caseOwnerTypeDetailsList.dtlsList.addRef(caseOwnerTypeDetails);

    }

    return caseOwnerTypeDetailsList;
  }

  /**
   * Method to return configured investigation owned by list. For example, where
   * the administrator has configured that investigations are owned by users and
   * positions, this list will contain the current user and the positions to
   * which they are assigned in the organization structure e.g. Eligibility
   * Specialist Position, Supervisor Position.
   *
   * @return Configured investigation owner details list
   */
  @Override
  public CaseOwnerList getInvestigationOwnerList()
      throws AppException, InformationalException {

    final CaseOwnerList caseOwnerList = new CaseOwnerList();

    final boolean searchByUserOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_INVESTIGATION_SEARCH_BY_USER);

    CaseOwnerDetails caseOwnerDetails;

    if (searchByUserOwnerInd) {

      caseOwnerDetails = new CaseOwnerDetails();

      caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;
      caseOwnerDetails.userName = TransactionInfo.getProgramUser();

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();
      UserFullname userFullName;

      usersKey.userName = caseOwnerDetails.userName;

      userFullName = userAccessObj.getFullName(usersKey);

      caseOwnerDetails.orgObjectReferenceName = userFullName.fullname;

      caseOwnerList.dtlsList.addRef(caseOwnerDetails);

    }

    final boolean searchByPositionOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_INVESTIGATION_SEARCH_BY_POSITION);

    if (searchByPositionOwnerInd) {

      final ListUserPositionDetails listUserPositionDetails = PositionFactory
          .newInstance().getPositionsForUser();

      for (int i = 0; i < listUserPositionDetails.dtlsList.dtls.size(); i++) {

        caseOwnerDetails = new CaseOwnerDetails();

        caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.POSITION;
        caseOwnerDetails.orgObjectReference = listUserPositionDetails.dtlsList.dtls
            .item(i).positionID;
        caseOwnerDetails.orgObjectReferenceName = listUserPositionDetails.dtlsList.dtls
            .item(i).positionName;

        caseOwnerList.dtlsList.addRef(caseOwnerDetails);
      }

    }

    final boolean searchByOrganizationUnitOwnerInd = Configuration
        .getBooleanProperty(
            EnvVars.ENV_MY_INVESTIGATION_SEARCH_BY_ORGANIZATION_UNIT);

    if (searchByOrganizationUnitOwnerInd) {

      final ListUserOrgUnitDetails listUserOrgUnitDetails = OrganisationUnitFactory
          .newInstance().getOrgUnitsForUser();

      for (int i = 0; i < listUserOrgUnitDetails.dtlsList.dtls.size(); i++) {

        caseOwnerDetails = new CaseOwnerDetails();

        caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.ORGUNIT;
        caseOwnerDetails.orgObjectReference = listUserOrgUnitDetails.dtlsList.dtls
            .item(i).organisationUnitID;
        caseOwnerDetails.orgObjectReferenceName = listUserOrgUnitDetails.dtlsList.dtls
            .item(i).name;

        caseOwnerList.dtlsList.addRef(caseOwnerDetails);
      }

    }

    final boolean searchByWorkQueueOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_INVESTIGATION_SEARCH_BY_WORK_QUEUE);

    if (searchByWorkQueueOwnerInd) {

      final CaseOwnerList workQueueOwnerList = getInvestigationOwnerWorkQueueList();

      caseOwnerList.dtlsList.addAll(workQueueOwnerList.dtlsList);

    }

    return caseOwnerList;
  }

  /**
   * Method to return work queue subscribed by current user or by current user
   * associated organization object list.
   *
   * @return Configured work queue owner details list
   */
  @Override
  public CaseOwnerList getInvestigationOwnerWorkQueueList()
      throws AppException, InformationalException {

    final CaseOwnerList caseOwnerList = new CaseOwnerList();

    final boolean searchByPositionOwnerInd = Configuration
        .getBooleanProperty(EnvVars.ENV_MY_INVESTIGATION_SEARCH_BY_POSITION);
    final boolean searchByOrganizationUnitOwnerInd = Configuration
        .getBooleanProperty(
            EnvVars.ENV_MY_INVESTIGATION_SEARCH_BY_ORGANIZATION_UNIT);

    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    // BEGIN, CR00226714, LP
    CurrentUserWorkQueueAndSubscriberDetailsList workQueueDetailsList;
    // END, CR00226714
    CaseOwnerDetails caseOwnerDetails;

    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = TransactionInfo.getProgramUser();

    final ArrayList<CaseOwnerDetails> workQueueList = new ArrayList<CaseOwnerDetails>();

    final curam.core.sl.entity.intf.WorkQueue workQueueEntityObj = curam.core.sl.entity.fact.WorkQueueFactory
        .newInstance();

    final CurrentUserWorkQueueKey currentUserWorkQueueKey = new CurrentUserWorkQueueKey();

    currentUserWorkQueueKey.userName = userNameKey.userName;

    // BEGIN, CR00226714, LP
    workQueueDetailsList = workQueueEntityObj
        .searchWorkQueuesForUser(currentUserWorkQueueKey);
    // END, CR00226714

    for (int i = 0; i < workQueueDetailsList.dtls.size(); i++) {

      caseOwnerDetails = new CaseOwnerDetails();

      caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;
      caseOwnerDetails.orgObjectReference = workQueueDetailsList.dtls
          .item(i).workQueueID;
      caseOwnerDetails.orgObjectReferenceName = workQueueDetailsList.dtls
          .item(i).workQueueName;

      workQueueList.add(caseOwnerDetails);
    }

    if (searchByPositionOwnerInd) {

      workQueueDetailsList = workQueueObj
          .getUserPositionWorkQueues(userNameKey);

      for (int i = 0; i < workQueueDetailsList.dtls.size(); i++) {

        // BEGIN, CR00226714, LP
        final CurrentUserWorkQueueAndSubscriberDetails currentWQDtls = workQueueDetailsList.dtls
            .item(i);

        boolean workQueueExistInd = false;

        for (int j = 0; j < workQueueList.size(); j++) {
          if (currentWQDtls.workQueueID == workQueueList
              .get(j).orgObjectReference) {
            // END, CR00226714
            workQueueExistInd = true;
            break;
          }
        }

        if (!workQueueExistInd) {
          caseOwnerDetails = new CaseOwnerDetails();

          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;
          // BEGIN, CR00226714, LP
          caseOwnerDetails.orgObjectReference = currentWQDtls.workQueueID;
          caseOwnerDetails.orgObjectReferenceName = currentWQDtls.workQueueName;
          // END, CR00226714
          workQueueList.add(caseOwnerDetails);
        }

      }

    }

    if (searchByOrganizationUnitOwnerInd) {

      workQueueDetailsList = workQueueObj.getUserOrgUnitWorkQueues(userNameKey);

      for (int i = 0; i < workQueueDetailsList.dtls.size(); i++) {

        // BEGIN, CR00226714, LP
        final CurrentUserWorkQueueAndSubscriberDetails currentWQDtls = workQueueDetailsList.dtls
            .item(i);
        boolean workQueueExistInd = false;

        for (int j = 0; j < workQueueList.size(); j++) {
          if (currentWQDtls.workQueueID == workQueueList
              .get(j).orgObjectReference) {
            // END, CR00226714
            workQueueExistInd = true;
            break;
          }
        }

        if (!workQueueExistInd) {
          caseOwnerDetails = new CaseOwnerDetails();

          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;
          caseOwnerDetails.orgObjectReference = workQueueDetailsList.dtls
              .item(i).workQueueID;
          caseOwnerDetails.orgObjectReferenceName = workQueueDetailsList.dtls
              .item(i).workQueueName;
          workQueueList.add(caseOwnerDetails);
        }

      }
    }

    // sort work queues by name and add into owner list
    final Comparator<CaseOwnerDetails> workQueueNameComparator = new OwnerWorkQueueNameComparator();

    Collections.sort(workQueueList, workQueueNameComparator);

    for (int i = 0; i < workQueueList.size(); i++) {
      caseOwnerList.dtlsList.addRef(workQueueList.get(i));
    }

    return caseOwnerList;
  }

  /**
   * Method to return investigation status list used for investigation search.
   *
   * @return investigation status list
   */
  @Override
  public CaseStatusFilterDetailsList getInvestigationStatusFilterList()
      throws AppException, InformationalException {

    final CaseStatusFilterDetailsList caseStatusFilterDetailsList = new CaseStatusFilterDetailsList();

    // Get case search status filter options for locale value and codetable
    final java.util.LinkedHashMap<String, String> caseStatusFilterOptionList = CodeTable
        .getAllEnabledItems(INVESTIGATIONSEARCHSTATUS.TABLENAME,
            TransactionInfo.getProgramLocale());

    CaseStatusFilterDetails caseStatusFilterDetails;

    if (!caseStatusFilterOptionList.isEmpty()) {

      final Set<String> keys = caseStatusFilterOptionList.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        caseStatusFilterDetails = new CaseStatusFilterDetails();

        caseStatusFilterDetails.statusCode = itr.next();
        caseStatusFilterDetails.statusDescription = caseStatusFilterOptionList
            .get(caseStatusFilterDetails.statusCode);

        caseStatusFilterDetailsList.dtlsList.addRef(caseStatusFilterDetails);
      }
    }

    return caseStatusFilterDetailsList;
  }

  /**
   * Returns investigation search criteria text value.
   *
   * @param details
   *          Investigation search criteria details.
   *
   * @return Investigation search criteria text value
   */
  @Override
  public CaseSearchCriteriaValue getInvestigationSearchCriteriaText(
      final InvestigationSearchCriteria details)
      throws AppException, InformationalException {

    final CaseSearchCriteriaValue investigationSearchCriteriaValue = new CaseSearchCriteriaValue();

    // BEGIN CR00327929, ZV
    final DataStringList dataList = new DataStringList();

    String typeList = new String();

    if (!details.typeList.isEmpty()) {

      dataList.list = details.typeList;

      typeList = getSearchCriteriaCaseTypeList(dataList).list;

    }

    String ownerList = new String();

    if (!details.ownerList.isEmpty()) {

      dataList.list = details.ownerList;

      ownerList = getSearchCriteriaOwnerList(dataList).list;

    }

    String statusList = new String();

    if (!details.statusList.isEmpty()) {

      dataList.list = details.statusList;

      statusList = getSearchCriteriaStatusList(dataList).list;

    }

    // check if all investigation types are selected
    final MyInvestigationFilterList myInvestigationFilterList = getMyInvestigationFilterList();

    final boolean allTypesInd = myInvestigationFilterList.typeDtlsList.dtlsList
        .size() == StringUtil.tabText2StringListWithTrim(details.typeList)
            .size();

    // BEGIN CR00331517, ZV
    LocalisableString localisableString = null;

    if (allTypesInd) {
      if (statusList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_SEARCH_CRITERIA_TEXT_ALL_TYPES_OWNER);
        localisableString.arg(ownerList);
      } else {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_SEARCH_CRITERIA_TEXT_ALL_TYPES_OWNER_STATUS);
        localisableString.arg(ownerList);
        localisableString.arg(statusList);
      }
    } else {
      if (statusList.isEmpty() && details.typeList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_SEARCH_CRITERIA_TEXT_OWNER);
        localisableString.arg(ownerList);
      } else if (!statusList.isEmpty() && details.typeList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_SEARCH_CRITERIA_TEXT_OWNER_STATUS);
        localisableString.arg(ownerList);
        localisableString.arg(statusList);
      } else if (statusList.isEmpty() && !details.typeList.isEmpty()) {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_SEARCH_CRITERIA_TEXT_TYPE_OWNER);
        localisableString.arg(typeList);
        localisableString.arg(ownerList);
      } else {
        localisableString = new LocalisableString(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_SEARCH_CRITERIA_TEXT_TYPE_OWNER_STATUS);
        localisableString.arg(typeList);
        localisableString.arg(ownerList);
        localisableString.arg(statusList);
      }
    }

    investigationSearchCriteriaValue.criteriaText = localisableString
        .getMessage();
    // END CR00331517
    // END CR00174336
    // END CR00327929

    return investigationSearchCriteriaValue;
  }

  // END, CR00203865

  // BEGIN, CR00204411, ZV
  /**
   * Method converts case search results into investigations details list.
   *
   * @param result
   *          Case search details list
   *
   * @return investigation details list
   */
  @Override
  public InvestigationSearchDetailsList assignInvestigationSearchResult(
      final CaseSearchList1 result)
      throws AppException, InformationalException {

    final InvestigationSearchDetailsList returnList = new InvestigationSearchDetailsList();

    InvestigationSearchDetails investigationSearchDetails;
    final InvestigationDelivery investigationDeliveryObj = InvestigationDeliveryFactory
        .newInstance();
    final ReadInvestigationTypeAndActiveResolutionKey readInvestigationTypeAndActiveResolutionKey = new ReadInvestigationTypeAndActiveResolutionKey();

    for (int i = 0; i < result.searchDtls.size(); i++) {

      investigationSearchDetails = new InvestigationSearchDetails();

      investigationSearchDetails.assign(result.searchDtls.item(i));

      readInvestigationTypeAndActiveResolutionKey.caseID = investigationSearchDetails.caseID;

      final InvestigationTypeAndResolutionDtls investigationTypeAndResolutionDtls = investigationDeliveryObj
          .readTypeAndActiveResolution(
              readInvestigationTypeAndActiveResolutionKey);

      investigationSearchDetails.resolution = investigationTypeAndResolutionDtls.resolution;

      returnList.searchDtls.addRef(investigationSearchDetails);
    }

    return returnList;
  }

  /**
   * Method to perform an investigation search
   *
   * @param searchCriteria
   *          data on which the searched will be based
   *
   * @return The details of any investigation records found
   */
  @Override
  public InvestigationSearchDetailsList investigationSearch(
      final InvestigationSearchCriteria searchCriteria)
      throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(new AppException(
            BPOCASESEARCH.ERR_BPOCASESEARCH_INVESTIGATION_SEARCH_UNIMPLEMENTED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
    // Should not reach this point without throwing a validation
    return null;
  }

  /**
   * Returns initial details to populate investigation search criteria.
   *
   * @return Initial details to populate investigation search criteria.
   */
  @Override
  public InitialInvestigationSearchCriteria getInvestigationSearchCiteria()
      throws AppException, InformationalException {

    final InitialInvestigationSearchCriteria initialSearchCriteria = new InitialInvestigationSearchCriteria();

    initialSearchCriteria.typeDtlsList = getInvestigationTypeFilterList();

    initialSearchCriteria.statusDtlsList = getInvestigationStatusFilterList();

    initialSearchCriteria.subtypeDtlsList = getInvestigationSubtypeFilterList();

    initialSearchCriteria.indexInvestigationSearchEnabledInd = Configuration
        .getBooleanProperty(EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED)
        && Configuration.getBooleanProperty(
            EnvVars.ENV_LUCENE_ENHANCED_INVESTIGATION_SEARCH_ENABLED);

    return initialSearchCriteria;
  }

  /**
   * Method to return investigation subtype list used for investigation search.
   *
   * @return investigation subtype details list
   */
  @Override
  public InvestigationSubtypeDetailsList getInvestigationSubtypeFilterList()
      throws AppException, InformationalException {

    final InvestigationSubtypeDetailsList investigationSubtypeDetailsList = new InvestigationSubtypeDetailsList();

    InvestigationSubtypeDetails investigationSubtypeDetails;

    final java.util.LinkedHashMap<String, String> investigationSubTypeList = CodeTable
        .getAllEnabledItems(INVESTIGDELIVERYSUBTYPE.TABLENAME,
            TransactionInfo.getProgramLocale());

    if (!investigationSubTypeList.isEmpty()) {

      final Set<String> keys = investigationSubTypeList.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        investigationSubtypeDetails = new InvestigationSubtypeDetails();

        investigationSubtypeDetails.subtype = itr.next().toString();
        investigationSubtypeDetails.subtypeDescription = investigationSubTypeList
            .get(investigationSubtypeDetails.subtype).toString();

        investigationSubtypeDetailsList.dtlsList
            .addRef(investigationSubtypeDetails);
      }
    }

    // Sort the investigation subtype values by description
    final Comparator<InvestigationSubtypeDetails> investigationSubtypeComparator = new InvestigationSubtypeComparator();

    Collections.sort(investigationSubtypeDetailsList.dtlsList,
        investigationSubtypeComparator);

    return investigationSubtypeDetailsList;
  }

  /**
   * Stores user investigation search criteria values.
   *
   * @param searchCriteria
   *          User Investigation search criteria values to be stored.
   *
   * @throws InformationalException
   *           {@link BPOCASESEARCH# ERR_BPOCASESEARCH_FV_INVESTIGATION_OWNER_EMPTY}
   *           - If the investigation owner is not specified.
   */
  @Override
  public void storeInvestigationSearchCriteria(
      final InvestigationSearchCriteria searchCriteria)
      throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    if (searchCriteria.ownerList.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(
                  BPOCASESEARCH.ERR_BPOCASESEARCH_FV_INVESTIGATION_OWNER_EMPTY),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);

    }

    informationalManager.failOperation();

    final UserSearchFilter userSearchFilterObj = UserSearchFilterFactory
        .newInstance();
    final UserSearchFilterDetails userSearchFilterDetails = new UserSearchFilterDetails();

    userSearchFilterDetails.userName = TransactionInfo.getProgramUser();
    userSearchFilterDetails.userSearchType = USERSEARCHTYPE.INVESTIGATION;

    UserSearchFilterData userSearchFilterData = new UserSearchFilterData();

    userSearchFilterData.userSearchFilterType = CuramConst.kUserSearchInvestigationTypeList;
    userSearchFilterData.userSearchFilterValue = searchCriteria.typeList;

    userSearchFilterDetails.filterDetails.dtlsList.addRef(userSearchFilterData);

    userSearchFilterData = new UserSearchFilterData();

    userSearchFilterData.userSearchFilterType = CuramConst.kUserSearchInvestigationStatusList;
    userSearchFilterData.userSearchFilterValue = searchCriteria.statusList;

    userSearchFilterDetails.filterDetails.dtlsList.addRef(userSearchFilterData);

    userSearchFilterData = new UserSearchFilterData();

    userSearchFilterData.userSearchFilterType = CuramConst.kUserSearchInvestigationOwnerList;
    userSearchFilterData.userSearchFilterValue = searchCriteria.ownerList;

    userSearchFilterDetails.filterDetails.dtlsList.addRef(userSearchFilterData);

    userSearchFilterObj.createOrModify(userSearchFilterDetails);

  }

  /*
   * Comparator used to order a investigation type list by type description
   */
  protected class InvestigationTypeComparator
      implements Comparator<InvestigationTypeDetails> {

    public InvestigationTypeComparator() {

      super();
    }

    @Override
    public int compare(final InvestigationTypeDetails struct1,
        final InvestigationTypeDetails struct2) {

      return struct1.typeDescription.compareTo(struct2.typeDescription);
    }
  }

  /*
   * Comparator used to order a investigation subtype list by type description
   */
  protected class InvestigationSubtypeComparator
      implements Comparator<InvestigationSubtypeDetails> {

    public InvestigationSubtypeComparator() {

      super();
    }

    @Override
    public int compare(final InvestigationSubtypeDetails struct1,
        final InvestigationSubtypeDetails struct2) {

      return struct1.subtypeDescription.compareTo(struct2.subtypeDescription);
    }
  }

  // END, CR00204411

  // BEGIN CR00327929, ZV
  /**
   * Returns case search criteria case type list.
   *
   * @param details
   *          Case type codetable value list.
   * @return Case type codetable description list
   */
  @Override
  public DataStringList getSearchCriteriaCaseTypeList(
      final DataStringList details)
      throws AppException, InformationalException {

    String listSeparator = Configuration
        .getProperty(EnvVars.ENV_LIST_SEPARATOR);

    if (listSeparator == null) {
      listSeparator = curam.util.resources.Configuration
          .getProperty(EnvVars.ENV_LIST_SEPARATOR_DEFAULT);
    }

    listSeparator = listSeparator + CuramConst.gkSpace;

    final int listSeparatorLength = listSeparator.length();

    final DataStringList returnList = new DataStringList();

    final StringList typeList = StringUtil
        .tabText2StringListWithTrim(details.list);

    for (int i = 0; i < typeList.size(); i++) {

      final StringList categoryType = StringUtil
          .delimitedText2StringListWithTrim(typeList.item(i),
              CuramConst.gkPipeDelimiterChar);

      if (categoryType.size() > CuramConst.gkOne) {
        // get case category and type
        final String category = categoryType.item(0);
        final String type = categoryType.item(1);

        if (category.equals(CASETYPECODE.SERVICEPLAN)) {
          returnList.list += CodeTable.getOneItem(SERVICEPLANTYPE.TABLENAME,
              type);
        } else if (category.equals(CASETYPECODE.ISSUE)) {
          returnList.list += CodeTable
              .getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME, type);
        } else if (category.equals(CASETYPECODE.INVESTIGATIONCASE)) {
          returnList.list += CodeTable
              .getOneItem(INVESTIGATECONFIGTYPE.TABLENAME, type);
        } else if (category.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {
          returnList.list += CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
              type);
        } else if (category.equals(CASETYPECODE.SCREENINGCASE)) {
          returnList.list += CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
              type);
        } else if (category.equals(CASETYPECODE.INTEGRATEDCASE)) {
          returnList.list += CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
              type);
        } else if (category.equals(CASETYPECODE.PRODUCTDELIVERY)
            || category.equals(CASETYPECODE.LIABILITY)) {
          returnList.list += CodeTable.getOneItem(PRODUCTNAME.TABLENAME, type);
        } else if (category.equals(CASETYPECODE.APPEAL)) {// appeal type
        }
        returnList.list += listSeparator;
      } // if (categoryType.size() > CuramConst.gkOne)
    } // for i

    // remove last list separator from the text
    if (!returnList.list.isEmpty()) {
      returnList.list = returnList.list.substring(CuramConst.gkZero,
          returnList.list.length() - listSeparatorLength);
    }

    return returnList;
  }

  /**
   * Returns investigation search criteria investigation type list.
   *
   * @param details
   *          Case type codetable value list.
   * @return Case type codetable description list
   */
  @Override
  public DataStringList getSearchCriteriaInvestigationTypeList(
      final DataStringList details)
      throws AppException, InformationalException {

    String listSeparator = Configuration
        .getProperty(EnvVars.ENV_LIST_SEPARATOR);

    if (listSeparator == null) {
      listSeparator = curam.util.resources.Configuration
          .getProperty(EnvVars.ENV_LIST_SEPARATOR_DEFAULT);
    }

    listSeparator = listSeparator + CuramConst.gkSpace;

    final int listSeparatorLength = listSeparator.length();

    final DataStringList returnList = new DataStringList();

    final StringList typeList = StringUtil
        .tabText2StringListWithTrim(details.list);

    for (int i = 0; i < typeList.size(); i++) {
      returnList.list += CodeTable.getOneItem(INVESTIGATECONFIGTYPE.TABLENAME,
          typeList.item(i));
      returnList.list += listSeparator;
    }

    // remove last separator from the list
    if (!returnList.list.isEmpty()) {
      returnList.list = returnList.list.substring(CuramConst.gkZero,
          returnList.list.length() - listSeparatorLength);
    }

    return returnList;
  }

  /**
   * Returns case search criteria owner list.
   *
   * @param details
   *          Case owner data list.
   * @return Case owner name list
   */
  @Override
  public DataStringList getSearchCriteriaOwnerList(final DataStringList details)
      throws AppException, InformationalException {

    String listSeparator = Configuration
        .getProperty(EnvVars.ENV_LIST_SEPARATOR);

    if (listSeparator == null) {
      listSeparator = curam.util.resources.Configuration
          .getProperty(EnvVars.ENV_LIST_SEPARATOR_DEFAULT);
    }

    listSeparator = listSeparator + CuramConst.gkSpace;

    final int listSeparatorLength = listSeparator.length();

    final DataStringList returnList = new DataStringList();

    final StringList ownerList = StringUtil
        .tabText2StringListWithTrim(details.list);

    for (int i = 0; i < ownerList.size(); i++) {

      final StringList orgObjectTypeOwner = StringUtil
          .delimitedText2StringListWithTrim(ownerList.item(i),
              CuramConst.gkPipeDelimiterChar);

      if (orgObjectTypeOwner.size() > CuramConst.gkOne) {

        final String orgObjectType = orgObjectTypeOwner.item(0);

        if (orgObjectType.equals(ORGOBJECTTYPE.USER)) {

          final UserAccess userAccessObj = UserAccessFactory.newInstance();
          final UsersKey usersKey = new UsersKey();
          UserFullname userFullName;

          usersKey.userName = orgObjectTypeOwner.item(1);

          userFullName = userAccessObj.getFullName(usersKey);

          returnList.list += userFullName.fullname;

        } else if (orgObjectType.equals(ORGOBJECTTYPE.POSITION)) {

          final Position positionObj = curam.core.sl.entity.fact.PositionFactory
              .newInstance();
          final PositionKey positionKey = new PositionKey();

          positionKey.positionID = Long.parseLong(orgObjectTypeOwner.item(1));

          final PositionName positionName = positionObj
              .readPositionName(positionKey);

          returnList.list += positionName.name;

        } else if (orgObjectType.equals(ORGOBJECTTYPE.ORGUNIT)) {

          final OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory
              .newInstance();
          final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

          organisationUnitKey.organisationUnitID = Long
              .parseLong(orgObjectTypeOwner.item(1));

          final OrganisationUnitName organisationUnitName = organisationUnitObj
              .readOrgUnitName(organisationUnitKey);

          returnList.list += organisationUnitName.name;

        } else if (orgObjectType.equals(ORGOBJECTTYPE.WORKQUEUE)) {

          final curam.core.sl.entity.intf.WorkQueue workQueueObj = curam.core.sl.entity.fact.WorkQueueFactory
              .newInstance();
          final WorkQueueKey workQueueKey = new WorkQueueKey();

          workQueueKey.workQueueID = Long.parseLong(orgObjectTypeOwner.item(1));

          final WorkQueueNameDetails workQueueNameDetails = workQueueObj
              .readWorkQueueName(workQueueKey);

          returnList.list += workQueueNameDetails.name;

        }

        if (!orgObjectType.equals(ORGOBJECTTYPE.USER)) {
          returnList.list += CuramConst.gkSpace
              + CodeTable.getOneItem(ORGOBJECTTYPE.TABLENAME, orgObjectType);
        }

        returnList.list += listSeparator;
      }
    }

    // remove last separator from the list
    if (!returnList.list.isEmpty()) {
      returnList.list = returnList.list.substring(CuramConst.gkZero,
          returnList.list.length() - listSeparatorLength);
    }

    return returnList;
  }

  /**
   * Returns case search criteria case status list.
   *
   * @param details
   *          Case type codetable value list.
   * @return Case type codetable description list
   */
  @Override
  public DataStringList getSearchCriteriaStatusList(
      final DataStringList details)
      throws AppException, InformationalException {

    String listSeparator = Configuration
        .getProperty(EnvVars.ENV_LIST_SEPARATOR);

    if (listSeparator == null) {
      listSeparator = curam.util.resources.Configuration
          .getProperty(EnvVars.ENV_LIST_SEPARATOR_DEFAULT);
    }

    listSeparator = listSeparator + CuramConst.gkSpace;

    final int listSeparatorLength = listSeparator.length();

    final DataStringList returnList = new DataStringList();

    final StringList statusList = StringUtil
        .tabText2StringListWithTrim(details.list);

    for (int i = 0; i < statusList.size(); i++) {

      if (statusList.item(i).length() > 0) {
        returnList.list += CodeTable.getOneItem(CASESEARCHSTATUS.TABLENAME,
            statusList.item(i));
        returnList.list += listSeparator;
      }
    }

    // remove last separator from the list
    if (!returnList.list.isEmpty()) {
      returnList.list = returnList.list.substring(CuramConst.gkZero,
          returnList.list.length() - listSeparatorLength);
    }

    return returnList;
  }
  // END, CR00327929
}
