/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.sl.entity.struct.CloseTaskDetails;
import curam.core.sl.entity.struct.CloseTaskKey_eo;
import curam.core.sl.entity.struct.ReservationTaskDetails;
import curam.core.sl.entity.struct.ReservationTaskKey_eo;
import curam.core.sl.entity.struct.Task_waDtls;
import curam.core.sl.entity.struct.Task_waKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Raise an events for lucene index search as a result of entity updates
 *
 */
public abstract class IndexTask_waSynchronization extends curam.core.base.IndexTask_waSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the task entity insert operation
   *
   * @param dtls task details
   */
  @Override
  public void insert(Task_waDtls dtls) throws AppException,
      InformationalException {// this will post the event indicating that the
    // specific Task_WA has been updated.
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the task entity modify operation
   *
   * @param key task identifier
   * @param dtls task details
   */
  @Override
  public void modify(Task_waKey key, Task_waDtls dtls) throws AppException,
      InformationalException {// this will post the event indicating that the
    // specific Task_WA has been updated.
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the task entity modify closure operation
   *
   * @param key close task identifier
   * @param dtls close task details
   */
  @Override
  public void modifyClosure(CloseTaskKey_eo key, CloseTaskDetails dtls)
    throws AppException, InformationalException {// this will post the event
    // indicating that the specific
    // Task_WA has been updated.
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the task entity modify reserved operation
   *
   * @param key task reservation identifier
   * @param dtls task reservation details
   */
  @Override
  public void modifyReserve(ReservationTaskKey_eo key,
    ReservationTaskDetails dtls) throws AppException, InformationalException {// this
    // will
    // post
    // the
    // event
    // indicating
    // that
    // the
    // specific
    // Task_WA
    // has
    // been
    // updated.
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the task entity modify unreserved operation
   *
   * @param key task unreserve identifier
   * @param dtls task unreserve details
   */
  @Override
  public void modifyUnreserve(ReservationTaskKey_eo key,
    ReservationTaskDetails dtls) throws AppException, InformationalException {// this
    // will
    // post
    // the
    // event
    // indicating
    // that
    // the
    // specific
    // Task_WA
    // has
    // been
    // updated.
  }

}
