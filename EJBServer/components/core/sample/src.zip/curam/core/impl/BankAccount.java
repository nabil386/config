/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.BANKACCOUNTSTATUS;
import curam.codetable.BANKBRANCHSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.events.BANKACCOUNT;
import curam.core.facade.struct.InternationalBankAccountIndicator;
import curam.core.fact.BankAccountFactory;
import curam.core.fact.BankBranchFactory;
import curam.core.fact.ConcernRoleBankAccountFactory;
import curam.core.fact.MaintainConcernRoleBankAcFactory;
import curam.core.intf.BankBranch;
import curam.core.intf.ConcernRoleBankAccount;
import curam.core.intf.MaintainConcernRoleBankAc;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.BankAccountDtls;
import curam.core.struct.BankAccountIDData;
import curam.core.struct.BankAccountKey;
import curam.core.struct.BankBranchDtls;
import curam.core.struct.BankBranchDtlsList;
import curam.core.struct.ConcernRoleBankAccountDtls;
import curam.core.struct.ConcernRoleBankAccountDtlsList;
import curam.core.struct.ConcernRoleBankAccountKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ReadConcernRoleBankAcKey;
import curam.core.struct.SortCodeStruct;
import curam.core.struct.SwiftBusinessIdentifierCode;
import curam.message.BPOBANKACCOUNT;
import curam.message.GENERALADMIN;
import curam.message.PARTICIPANTDATACASE;
import curam.pdc.fact.PDCBankAccountFactory;
import curam.pdc.fact.PDCUtilFactory;
import curam.pdc.intf.PDCBankAccount;
import curam.pdc.struct.ParticipantBankAccountDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;


/**
 * Implementation of functions to be executed before insert, modify, etc.
 *
 */
public abstract class BankAccount extends curam.core.base.BankAccount {

  // BEGIN, CR00377370, VT
  /*
   * Reference to AccountNumberAlgorithm object.
   */
  @Inject
  protected AccountNumberAlgorithm accountNumberAlgorithm;

  public BankAccount() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00377370
  /**
   * Function for checking if bank account information is correct
   *
   * @param details Contains bank account details to be checked
   */
  @Override
  protected void autovalidate(BankAccountDtls details) throws AppException,
      InformationalException {

    // variables, used to check if the bank sortCode is valid
    final curam.core.intf.BankBranch bankBranchObj = curam.core.fact.BankBranchFactory.newInstance();

    final SortCodeStruct sortCodeStruct = new SortCodeStruct();
    // BEGIN, CR00371769, VT
    final SwiftBusinessIdentifierCode swiftBusinessIdentifierCode = new SwiftBusinessIdentifierCode();
    // END, CR00371769

    BankBranchDtlsList bankBranchDtlsList;

    // variable to operate with date
    // based on domain CURAM_DATE
    curam.util.type.Date todaysDate;

    todaysDate = curam.util.type.Date.getCurrentDate();

    // String for returning failed validation details
    final StringBuffer validationString = new StringBuffer();

    // BEGIN, CR00371769, VT
    final InternationalBankAccountIndicator internationalBankAccountIndicator = new InternationalBankAccountIndicator();

    internationalBankAccountIndicator.ibanInd = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_ENABLE_IBAN_FUNCTIONALITY);

    if (!internationalBankAccountIndicator.ibanInd) {
      if (0 == details.accountNumber.length()) {

        ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_NUM_EMPTY),
          ValidationManagerConst.kSetOne, 0);
      }
      if (0 == details.bankSortCode.length()) {

        ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(GENERALADMIN.ERR_BANKACCOUNT_FV_SORTCODE_EMPTY),
          ValidationManagerConst.kSetOne, 0);
      }

    } else {
      if (0 == details.iban.length() && 0 == details.bic.length()) {

        if (0 == details.accountNumber.length()
          && 0 == details.bankSortCode.length()) {

          validationString.append(CuramConst.gkNewLine).append(
            BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_IBAN_NUM_EMPTY.getMessageText(
              TransactionInfo.getProgramLocale()));
        }

        if (0 != details.accountNumber.length()
          && 0 == details.bankSortCode.length()) {
          validationString.append(CuramConst.gkNewLine).append(
            BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_SORT_CODE_EMPTY.getMessageText(
              TransactionInfo.getProgramLocale()));
        } else {

          if (0 == details.accountNumber.length()
            && 0 != details.bankSortCode.length()) {
            validationString.append(CuramConst.gkNewLine).append(
              BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_NUMBER_EMPTY.getMessageText(
                TransactionInfo.getProgramLocale()));
          }
        }

      } else {

        if (0 != details.iban.length() && 0 == details.bic.length()) {

          validationString.append(CuramConst.gkNewLine).append(
            BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_BIC_EMPTY.getMessageText(
              TransactionInfo.getProgramLocale()));
        }

        if (0 == details.iban.length() && 0 != details.bic.length()) {

          validationString.append(CuramConst.gkNewLine).append(
            BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_IBAN_EMPTY.getMessageText(
              TransactionInfo.getProgramLocale()));

        }
        if (0 != details.accountNumber.length()
          && 0 == details.bankSortCode.length()) {

          validationString.append(CuramConst.gkNewLine).append(
            BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_SORT_CODE_EMPTY.getMessageText(
              TransactionInfo.getProgramLocale()));
        } else {
          if (0 == details.accountNumber.length()
            && 0 != details.bankSortCode.length()) {

            validationString.append(CuramConst.gkNewLine).append(
              BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_NUMBER_EMPTY.getMessageText(
                TransactionInfo.getProgramLocale()));
          }
        }
      }
    }
    // END, CR00371769

    // Check if the account type has been selected
    if (details.typeCode.length() == 0) {
      validationString.append(CuramConst.gkNewLine).append(
        // BEGIN, CR00163471, JC
        curam.message.BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_TYPE_EMPTY.getMessageText(
          TransactionInfo.getProgramLocale()));
      // END, CR00163471, JC
    }

    // check if the account name is empty
    if (details.name.length() == 0) {
      validationString.append(CuramConst.gkNewLine).append(
        // BEGIN, CR00163471, JC
        curam.message.BPOBANKACCOUNT.ERR_BANKACCOUNT_FV_NAME_EMPTY.getMessageText(
          TransactionInfo.getProgramLocale()));
      // END, CR00163471, JC
    }

    // start date cannot be empty
    if (details.startDate.isZero()) {
      validationString.append(CuramConst.gkNewLine).append(
        // BEGIN, CR00163471, JC
        curam.message.GENERAL.ERR_GENERAL_FV_FROM_DATE_EMPTY.getMessageText(
          TransactionInfo.getProgramLocale()));
      // END, CR00163471, JC
    }

    // check if end date and start dates are correct
    if (!details.endDate.isZero()) {

      // check if relationship between start and end dates are correct
      if (!details.startDate.isZero()
        && details.startDate.after(details.endDate)) {

        validationString.append(CuramConst.gkNewLine).append(
          // BEGIN, CR00163471, JC
          curam.message.GENERAL.ERR_GENERAL_XFV_FROM_DATE_TO_DATE.getMessageText(
            TransactionInfo.getProgramLocale()));
        // END, CR00163471, JC

      }

      // check if end date is not more than todays date
      if (details.endDate.after(todaysDate)) {

        validationString.append(CuramConst.gkNewLine).append(
          // BEGIN, CR00163471, JC
          curam.message.GENERAL.ERR_GENERAL_FV_TO_DATE_LARGE.getMessageText(
            TransactionInfo.getProgramLocale()));
        // END, CR00163471, JC

      }

    }

    // only want to continue with validation if there are no problems so far.
    if (validationString.length() == 0) {

      // BEGIN, CR00371769, VT
      if (0 != details.bankSortCode.length()) {
        sortCodeStruct.bankSortCode = details.bankSortCode;

        bankBranchDtlsList = bankBranchObj.searchBySortCode(sortCodeStruct);

        if (bankBranchDtlsList.dtls.isEmpty()) {

          final AppException e = new AppException(
            GENERALADMIN.ERR_BANKACCOUNT_RNFE_SORTCODE);

          e.arg(sortCodeStruct.bankSortCode);

          validationString.append(CuramConst.gkNewLine).append(
            e.getMessage(TransactionInfo.getProgramLocale()));

        } else {
          validationString.append(
            validateBankBranchStatus(bankBranchDtlsList, details,
            validationString));
        }

      }

      if (0 != details.bic.length()) {
        swiftBusinessIdentifierCode.bic = details.bic;

        bankBranchDtlsList = bankBranchObj.searchByBic(
          swiftBusinessIdentifierCode);

        if (bankBranchDtlsList.dtls.isEmpty()) {

          final AppException e = new AppException(
            GENERALADMIN.ERR_BANKACCOUNT_RNFE_BIC);

          e.arg(swiftBusinessIdentifierCode.bic);

          validationString.append(CuramConst.gkNewLine).append(
            e.getMessage(TransactionInfo.getProgramLocale()));

        } else {
          validationString.append(
            validateBankBranchStatus(bankBranchDtlsList, details,
            validationString));
        }
      }
      // END, CR00371769
    }

    // Return the string of failed validations in this exception
    if (validationString.length() > 0) {

      final AppException e = new AppException(
        curam.message.BPOBANKACCOUNT.ERR_BANKACCOUNT_VALIDATION_FAILURE_LIST);

      e.arg(validationString);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  /**
   * Method to call uniqueID generation and return bankBranchID for insert
   *
   * @param details Contains bank account details
   */
  @Override
  protected void preinsert(BankAccountDtls details) throws AppException,
      InformationalException {

    final curam.core.intf.BankBranch bankBranchObj = curam.core.fact.BankBranchFactory.newInstance();

    // BEGIN, CR00371769, VT
    final SortCodeStruct sortCodeStruct = new SortCodeStruct();
    final SwiftBusinessIdentifierCode swiftBusinessIdentifierCode = new SwiftBusinessIdentifierCode();

    sortCodeStruct.bankSortCode = details.bankSortCode;
    swiftBusinessIdentifierCode.bic = details.bic;

    details.statusCode = RECORDSTATUS.DEFAULTCODE;
    details.bankAccountStatus = BANKACCOUNTSTATUS.DEFAULTCODE;

    BankBranchDtlsList bankBranchDtlsListForBic, bankBranchDtlsListForSortCode;

    bankBranchDtlsListForSortCode = bankBranchObj.searchBySortCode(
      sortCodeStruct);

    bankBranchDtlsListForBic = bankBranchObj.searchByBic(
      swiftBusinessIdentifierCode);

    if (0 != details.bic.length() && 0 != details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForSortCode : bankBranchDtlsListForSortCode.dtls) {

        for (final BankBranchDtls bankBranchDtlsForBic : bankBranchDtlsListForBic.dtls) {

          if (bankBranchDtlsForSortCode.bankBranchID
            == bankBranchDtlsForBic.bankBranchID) {

            if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForBic.statusCode)) {
              details.bankBranchID = bankBranchDtlsForBic.bankBranchID;
              break;
            }

          } else {
            ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BIC_SORT_CODE_BELONG_TO_SAME_BRANCH),
                ValidationManagerConst.kSetOne,
                0);

          }
        }
      }
    }

    if (0 != details.bic.length() && 0 == details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForBic : bankBranchDtlsListForBic.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForBic.statusCode)) {

          details.bankBranchID = bankBranchDtlsForBic.bankBranchID;

          break;
        }
      }

    }
    if (0 == details.bic.length() && 0 != details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForSortCode : bankBranchDtlsListForSortCode.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForSortCode.statusCode)) {

          details.bankBranchID = bankBranchDtlsForSortCode.bankBranchID;

          break;
        }
      }
    }
    // END, CR00371769

    // BEGIN, CR00377370, VT
    accountNumberAlgorithm.encodeIban(details);
    // END, CR00377370

    getUniqueID(details);

  }

  /**
   * Method to generate a Unique ID for the Bank Account record
   *
   * @param bankAccountDetails Contains bank account details
   */
  @Override
  public void getUniqueID(BankAccountDtls bankAccountDetails)
    throws AppException, InformationalException {

    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    bankAccountDetails.bankAccountID = uniqueIDObj.getNextID();

  }

  /**
   * Method to retrieve a Unique bankBranchID for the Bank Account record
   * depending upon sortCode
   *
   * @param key Contains bank account id (not currently used)
   * @param details Contains bank account details
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled and the bank account being modified is
   * linked to a concern role for whom invocation of the modify method is
   * not allowed.
   */
  @Override
  protected void premodify(BankAccountKey key, BankAccountDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00354954, GD
    // Is PDC enabled
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      // Check to see if this bank account is linked to a concern role
      // for whom invocation of the modify method is not allowed
      final ConcernRoleBankAccountDtlsList concernRoleBankAccountDtlsList = ConcernRoleBankAccountFactory.newInstance().searchByBankAccountID(
        key);

      final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      for (final ConcernRoleBankAccountDtls concernRoleBankAccountDtls : concernRoleBankAccountDtlsList.dtls) {
        concernRoleBankAccountKey.concernRoleBankAccountID = concernRoleBankAccountDtls.concernRoleBankAccountID;
        concernRoleKey.concernRoleID = ConcernRoleBankAccountFactory.newInstance().read(concernRoleBankAccountKey).concernRoleID;

        if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
          throw new AppException(
            PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
        }
      }
    }
    // END, CR00354954

    // bankBranch entity, sortCodeStruct, bankBranchDtls, bankBranchDtlsList
    // BEGIN, CR00371769, VT
    final BankBranch bankBranchObj = BankBranchFactory.newInstance();
    final SortCodeStruct sortCodeStruct = new SortCodeStruct();
    final SwiftBusinessIdentifierCode swiftBusinessIdentifierCode = new SwiftBusinessIdentifierCode();

    details.bankAccountID = key.bankAccountID;
    sortCodeStruct.bankSortCode = details.bankSortCode;

    swiftBusinessIdentifierCode.bic = details.bic;

    BankBranchDtlsList bankBranchDtlsListForBic, bankBranchDtlsListForSortCode;

    bankBranchDtlsListForSortCode = bankBranchObj.searchBySortCode(
      sortCodeStruct);

    bankBranchDtlsListForBic = bankBranchObj.searchByBic(
      swiftBusinessIdentifierCode);

    if (0 != details.bic.length() && 0 != details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForSortCode : bankBranchDtlsListForSortCode.dtls) {

        for (final BankBranchDtls bankBranchDtlsForBic : bankBranchDtlsListForBic.dtls) {

          if (bankBranchDtlsForSortCode.bankBranchID
            == bankBranchDtlsForBic.bankBranchID) {

            if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForBic.statusCode)) {
              details.bankBranchID = bankBranchDtlsForBic.bankBranchID;
              break;
            }

          } else {
            ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BIC_SORT_CODE_BELONG_TO_SAME_BRANCH),
                ValidationManagerConst.kSetOne,
                0);

          }
        }
      }
    }

    if (0 != details.bic.length() && 0 == details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForBic : bankBranchDtlsListForBic.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForBic.statusCode)) {

          details.bankBranchID = bankBranchDtlsForBic.bankBranchID;

          break;
        }
      }

    }
    if (0 == details.bic.length() && 0 != details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForSortCode : bankBranchDtlsListForSortCode.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForSortCode.statusCode)) {

          details.bankBranchID = bankBranchDtlsForSortCode.bankBranchID;

          break;
        }
      }
    }
    // END, CR00371769
    // BEGIN, CR00377370, VT
    accountNumberAlgorithm.encodeIban(details);
    // END, CR00377370

  }

  // BEGIN, CR00407584, SS
  /**
   * Method to retrieve a Unique bankBranchID for the Bank Account record
   * depending upon sortCode or swift business identifier code when IBAN system
   * property is enabled.
   *
   * @param key
   * Contains bank account id.
   * @param details
   * Contains bank account details
   */
  // END, CR00407584
  @Override
  protected void prepdcModify(BankAccountKey key, BankAccountDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00407584, SS
    final BankBranch bankBranchObj = BankBranchFactory.newInstance();
    final SortCodeStruct sortCodeStruct = new SortCodeStruct();
    final SwiftBusinessIdentifierCode swiftBusinessIdentifierCode = new SwiftBusinessIdentifierCode();

    details.bankAccountID = key.bankAccountID;
    sortCodeStruct.bankSortCode = details.bankSortCode;

    swiftBusinessIdentifierCode.bic = details.bic;

    final BankBranchDtlsList bankBranchDtlsListForBic, bankBranchDtlsListForSortCode;

    bankBranchDtlsListForSortCode = bankBranchObj.searchBySortCode(
      sortCodeStruct);

    bankBranchDtlsListForBic = bankBranchObj.searchByBic(
      swiftBusinessIdentifierCode);

    if (0 != details.bic.length() && 0 != details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForSortCode : bankBranchDtlsListForSortCode.dtls) {

        for (final BankBranchDtls bankBranchDtlsForBic : bankBranchDtlsListForBic.dtls) {

          if (bankBranchDtlsForSortCode.bankBranchID
            == bankBranchDtlsForBic.bankBranchID) {

            if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForBic.statusCode)) {
              details.bankBranchID = bankBranchDtlsForBic.bankBranchID;
              break;
            }

          } else {
            ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BIC_SORT_CODE_BELONG_TO_SAME_BRANCH),
                ValidationManagerConst.kSetOne,
                0);

          }
        }
      }
    }

    if (0 != details.bic.length() && 0 == details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForBic : bankBranchDtlsListForBic.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForBic.statusCode)) {

          details.bankBranchID = bankBranchDtlsForBic.bankBranchID;

          break;
        }
      }

    }
    if (0 == details.bic.length() && 0 != details.bankSortCode.length()) {

      for (final BankBranchDtls bankBranchDtlsForSortCode : bankBranchDtlsListForSortCode.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtlsForSortCode.statusCode)) {

          details.bankBranchID = bankBranchDtlsForSortCode.bankBranchID;

          break;
        }
      }
    }
    // END, CR00407584
  }

  /**
   * Prevents invocation of the sortCodeForAccounts method if Participant Data
   * Case is enabled.
   *
   * @param newSortCode Sort code for a bank branch. Note that this sortCode is
   * the new sort Code.
   *
   * @param oldSortCode Sort code for a bank branch. Note that this sortCode is
   * the old sort Code.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */
  @Override
  protected void premodifySortCodeForAccounts(SortCodeStruct newSortCode,
    SortCodeStruct oldSortCode) throws AppException, InformationalException {

    // BEGIN, CR00354954, GD
    // Is PDC enabled
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
    }
    // END, CR00354954
  }

  /**
   * Method to close a bank account
   *
   * @param details Structure to contain new bank account details
   */
  @Override
  public void close(BankAccountDtls details) throws AppException,
      InformationalException {

    // BEGIN, CR00360612, ELG
    final BankAccountKey bankAccountKey = new BankAccountKey();

    bankAccountKey.bankAccountID = details.bankAccountID;

    final ConcernRoleBankAccount concernRoleBankAccountObj = ConcernRoleBankAccountFactory.newInstance();
    final ConcernRoleBankAccountDtlsList concernRoleBankAccountList = concernRoleBankAccountObj.searchByBankAccountID(
      bankAccountKey);

    boolean nonPDCModifyInd = true;

    // There may be PDC related records involved.
    // If there is at least one of them then PDC modify operation will later
    // replicate changes to the Bank Account. As a result we will not need to
    // call standard modify.

    final PDCBankAccount pdcBankAccount = PDCBankAccountFactory.newInstance();
    final MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = MaintainConcernRoleBankAcFactory.newInstance();

    for (final ConcernRoleBankAccountDtls listDetails : concernRoleBankAccountList.dtls.items()) {

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = listDetails.concernRoleID;

      if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {

        final ReadConcernRoleBankAcKey readConcernRoleBankAcKey = new ReadConcernRoleBankAcKey();

        readConcernRoleBankAcKey.concernRoleBankAccountID = listDetails.concernRoleBankAccountID;

        final BankAccountDetails bankAccountDetails = maintainConcernRoleBankAcObj.readBankAccount(
          readConcernRoleBankAcKey);
        final ParticipantBankAccountDetails participantBankAccountDetails = new ParticipantBankAccountDetails();

        participantBankAccountDetails.assign(bankAccountDetails);
        participantBankAccountDetails.bankAccountStatus = curam.codetable.BANKACCOUNTSTATUS.CLOSED;
        participantBankAccountDetails.endDate = curam.util.type.Date.getCurrentDate();

        pdcBankAccount.modify(participantBankAccountDetails);

        nonPDCModifyInd = false;

      }

    }

    // There are no PDC related records involved
    // So we modify bank account details directly.
    if (nonPDCModifyInd) {

      details.bankAccountStatus = curam.codetable.BANKACCOUNTSTATUS.CLOSED;

      if (details.endDate.isZero()) {
        details.endDate = curam.util.type.Date.getCurrentDate();
      }

      modify(bankAccountKey, details);

    }
    // END, CR00360612

  }

  /**
   * @superseded - replaced by readEarliestBankAccountDateByBranchId
   */
  @Override
  public curam.core.struct.StartDateStruct getEarliestBankAccountDateByBranchId(
    curam.core.struct.BankAccountStatusBankBranchKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return BankAccountFactory.newInstance().readEarliestBankAccountDateByBranchId(
      key);
  }

  /**
   * @superseded - replaced by countDuplicates
   */
  @Override
  public curam.core.struct.ActiveAccountsStruct searchDuplicateBankAccount(
    curam.core.struct.ConcernRoleBankAccDtlsKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return BankAccountFactory.newInstance().countDuplicates(key);
  }

  /**
   * Raise a post Modify event
   *
   * @param key Identifier of the record that has been modified
   * @param details The updated details for the record
   */
  @Override
  protected void postmodify(BankAccountKey key, BankAccountDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00090470, SD
    // If there is no concern role record for the bank account then
    // it is the organization bank account and the event should be
    // raised. Otherwise the event will be raised when the concern
    // role bank account record is modified.
    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();

    final ConcernRoleBankAccountDtlsList concernRoleBankAccountDtlsList = concernRoleBankAccountObj.searchByBankAccountID(
      key);

    if (concernRoleBankAccountDtlsList.dtls.size() == 0) {

      // BEGIN, CR00080234, MG
      final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

      event.eventKey = BANKACCOUNT.MODIFY_BANKACCOUNT;

      event.primaryEventData = details.bankAccountID;
      curam.util.events.impl.EventService.raiseEvent(event);

      // END, CR00080234
    }
    // END, CR00090470

  }

  /**
   * Raise a post Modify event
   *
   * @param key Identifier of the record that has been modified
   * @param details The updated details for the record
   */
  @Override
  protected void postpdcModify(BankAccountKey key, BankAccountDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00090470, SD
    // If there is no concern role record for the bank account then
    // it is the organization bank account and the event should be
    // raised. Otherwise the event will be raised when the concern
    // role bank account record is modified.
    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();

    final ConcernRoleBankAccountDtlsList concernRoleBankAccountDtlsList = concernRoleBankAccountObj.searchByBankAccountID(
      key);

    if (concernRoleBankAccountDtlsList.dtls.size() == 0) {

      // BEGIN, CR00080234, MG
      final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

      event.eventKey = BANKACCOUNT.MODIFY_BANKACCOUNT;

      event.primaryEventData = details.bankAccountID;
      curam.util.events.impl.EventService.raiseEvent(event);

      // END, CR00080234
    }
    // END, CR00090470

  }

  /**
   * Raise a post Modify event
   *
   * @param oldSortCode The old bank account sort code
   * @param newSortCode The updated bank account sort code
   */
  @Override
  protected void postmodifySortCodeForAccounts(SortCodeStruct oldSortCode,
    SortCodeStruct newSortCode) throws AppException, InformationalException {// hook
    // for
    // post
    // operations
    // tasks
    // when
    // modifying
    // sort
    // code
  }

  // BEGIN, CR00371769, VT
  /**
   * Raise a post modify event
   *
   * @param oldBic
   * The old bank account business identifier code
   * @param newBic
   * The new bank account business identifier code
   */
  @Override
  protected void postmodifyBicForBankAccounts(
    SwiftBusinessIdentifierCode oldBic, SwiftBusinessIdentifierCode newBic)
    throws AppException, InformationalException {// hook for post operations
    // tasks when modifying
    // Business Identifier
    // Code(BIC).
  }

  // END, CR00371769

  // BEGIN, CR00175612, SPD

  /**
   * This method validates the selecting of a bank account. The user can choose
   * to either select an existing bank account or create a new one.
   *
   * @link BPOBANKACCOUNT#ERR_BANKACCOUNT_XFV_NOT_SUPPLIED
   * - A bank account must be selected or a new bank account entered.}
   * @link BPOBANKACCOUNT#ERR_BANKACCOUNT_XFV_MULTIPLE_ADDRESS
   * - A bank account must be selected or a new bank account entered
   * but not both.}
   *
   * @param details Bank account details to be validated.
   *
   * @throws AppException {
   * @throws AppException {
   */
  @Override
  public void validateSelectBankAc(BankAccountIDData details)
    throws AppException, InformationalException {

    // Create an informational manager to handle any validations thrown
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Determine if a new address has been entered
    // boolean bankAcEmpty = addressObj.isEmpty(otherAddressData).emptyInd;
    boolean bankAcEmpty = true;

    if (details.bankAcDetails.name.length() > 0
      || details.bankAcDetails.accountNumber.length() > 0
      || details.bankAcDetails.bankSortCode.length() > 0) {

      bankAcEmpty = false;

    }
    // Cannot select an address and also create a new address record
    if (!bankAcEmpty && details.bankAccountID != 0) {

      final AppException e = new AppException(
        BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_MULTIPLE_SELECT);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();
    }

    // Address is mandatory.
    if (details.bankAccountID == 0 && bankAcEmpty) {

      final AppException e = new AppException(
        BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_NOT_SUPPLIED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();
    }
  }

  // END CR00175612

  // BEGIN, CR00371769, VT

  /*
   * Validates the bank branch status.
   *
   * @param bankBranchDtlsList Bank branch details.
   *
   * @param details Bank account details.
   *
   * @param validations
   *
   * @Return validationString.
   */

  protected StringBuffer validateBankBranchStatus(
    BankBranchDtlsList bankBranchDtlsList, BankAccountDtls details,
    StringBuffer validations) throws AppException, InformationalException {

    final StringBuffer validationString = new StringBuffer();
    BankBranchDtls bankBranchDtls;
    final int kActiveRecords = 1;

    int bankBranchActiveRecords = 0;
    int bankBranchCanceledRecords = 0;

    bankBranchDtls = null; // this will refer to the active branch

    for (final BankBranchDtls bankBranchDetails : bankBranchDtlsList.dtls) {

      if (bankBranchDetails.statusCode.equals(
        curam.codetable.RECORDSTATUS.NORMAL)) {

        bankBranchActiveRecords++;
        bankBranchDtls = bankBranchDetails;

      } else {
        bankBranchCanceledRecords++;
      }

    }

    // if more than one active records found
    if (0 != details.bankSortCode.length()
      && bankBranchActiveRecords > kActiveRecords) {

      validationString.append(CuramConst.gkNewLine).append(
        GENERALADMIN.ERR_BANKBRANCH_XRV_ACTIVE_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale()));
    }

    if (0 != details.bic.length() && bankBranchActiveRecords > kActiveRecords) {
      validationString.append(CuramConst.gkNewLine).append(
        GENERALADMIN.ERR_BANKBRANCH_XRV_ACTIVE_BIC_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale()));
    }

    // one or more canceled records found and no active record
    if (!validations.toString().contains(
      GENERALADMIN.ERR_BANKBRANCH_XRV_CANCELLED_RECORDS.getMessageText())
        && (0 != details.bankSortCode.length() || 0 != details.bic.length())
        && bankBranchCanceledRecords > 0
        && bankBranchDtls == null) {

      validationString.append(CuramConst.gkNewLine).append(
        GENERALADMIN.ERR_BANKBRANCH_XRV_CANCELLED_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale()));

    }

    if (!validations.toString().contains(
      BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BANKBRANCH_CANCELLED.getMessageText())
        && (0 != details.bankSortCode.length()
          || 0 != details.bankSortCode.length())
          && bankBranchDtls != null
          && bankBranchDtls.statusCode.equals(
            curam.codetable.RECORDSTATUS.CANCELLED)) {

      validationString.append(CuramConst.gkNewLine).append(
        BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BANKBRANCH_CANCELLED.getMessageText(
          TransactionInfo.getProgramLocale()));

    }

    if (!validations.toString().contains(
      BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BANKBRANCH_CLOSED.getMessageText())
        && (0 != details.bankSortCode.length() || 0 != details.bic.length())
        && null != bankBranchDtls
        && bankBranchDtls.bankBranchStatus.equals(BANKBRANCHSTATUS.CLOSED)) {

      validationString.append(CuramConst.gkNewLine).append(
        BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_BANKBRANCH_CLOSED.getMessageText(
          TransactionInfo.getProgramLocale()));

    }

    if (null != bankBranchDtls
      && !validations.toString().contains(
        BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_START_DATE_END_DATE.getMessageText())) {

      if (bankBranchDtls.startDate.after(details.startDate)) {

        validationString.append(CuramConst.gkNewLine).append(
          BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_START_DATE_END_DATE.getMessageText(
            TransactionInfo.getProgramLocale()));
      }
      if (!bankBranchDtls.endDate.isZero()) {

        if (bankBranchDtls.endDate.before(details.endDate)
          || bankBranchDtls.endDate.before(details.startDate)) {

          validationString.append(CuramConst.gkNewLine).append(
            BPOBANKACCOUNT.ERR_BANKACCOUNT_XFV_START_DATE_END_DATE.getMessageText(
              TransactionInfo.getProgramLocale()));
        }

      }
    }
    return validationString;
  }
  // END, CR00371769
}
