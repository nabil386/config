/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2003, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.ADDRESSLAYOUTTYPE;
import curam.codetable.CONCERNROLETYPE;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.CharCount;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.struct.AddressMap;
import curam.core.struct.AddressMapList;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.EmployerReadDtls;
import curam.core.struct.EmployerReadDtlsList;
import curam.core.struct.EmployerSearchKey;
import curam.core.struct.EmployerSearchKey1;
import curam.core.struct.EmployerSearchResult;
import curam.core.struct.EmployerSearchResult1;
import curam.core.struct.OtherAddressData;
import curam.message.BPOEMPLOYERSEARCH;
import curam.message.GENERALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import java.util.Map;


/**
 * Provides methods which will route employer searches to the appropriate
 * search engine based on environment settings
 *
 */
public abstract class EmployerSearchRouter extends curam.core.base.EmployerSearchRouter {

  @Inject
  private Map<String, SearchKeyValidator> searchKeyValidator;

  public EmployerSearchRouter() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00098528, NP
  // ___________________________________________________________________________
  /**
   * Checks if the lucene environmental variable is enable to determine if the
   * search
   * will be a database or lucene index search.
   *
   * * @return employerSearchObj
   */
  // BEGIN, CR00198672, VK
  protected curam.core.intf.EmployerSearch getEmployerSearchObj() {

    // END, CR00198672
    curam.core.intf.EmployerSearch employerSearchObj;

    if (Configuration.getBooleanProperty(
      EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED)
        && Configuration.getBooleanProperty(
          EnvVars.ENV_LUCENE_ENHANCED_EMPLOYER_SEARCH_ENABLED)) {

      employerSearchObj = curam.core.fact.IndexEmployerSearchFactory.newInstance();

    } else {

      employerSearchObj = curam.core.fact.DatabaseEmployerSearchFactory.newInstance();
    }
    return employerSearchObj;
  }

  // ___________________________________________________________________________
  /**
   * @param employerSearchKey data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}.
   *
   * Method which routes Employer Search calls to the appropriate implementation
   */
  @Override
  @Deprecated
  public EmployerSearchResult search(EmployerSearchKey employerSearchKey)
    throws AppException, InformationalException {

    // Trim space characters from the beginning and end of search criteria which
    // may be accidentally entered
    employerSearchKey.businessAddress = employerSearchKey.businessAddress.trim();
    employerSearchKey.businessCity = employerSearchKey.businessCity.trim();
    employerSearchKey.registeredName = employerSearchKey.registeredName.trim();
    employerSearchKey.tradingName = employerSearchKey.tradingName.trim();

    // check if any search criteria are provided
    if (employerSearchKey.businessAddress.length() == 0
      && employerSearchKey.businessCity.length() == 0
      && employerSearchKey.referenceNumber.length() == 0
      && employerSearchKey.registeredName.length() == 0
      && employerSearchKey.tradingName.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          13);
    }
    // BEGIN, CR00098528, NP
    return getEmployerSearchObj().search(employerSearchKey);
    // END, CR00098528

  }

  // ___________________________________________________________________________
  /**
   * Method to perform an employer search, based solely on the employer
   * reference number
   *
   * @param alternateIDSearchKey employer reference number
   *
   * @return Employer details
   * @deprecated Since Curam 6.0.5.3, replaced by
   * {@link #searchByReferenceNumber()}
   */
  @Deprecated
  @Override
  public EmployerReadDtls readByReferenceNumber(
    AlternateIDSearchKey alternateIDSearchKey) throws AppException,
      InformationalException {

    // BEGIN, CR00098528, NP
    return getEmployerSearchObj().readByReferenceNumber(alternateIDSearchKey);
    // END, CR00098528

  }

  // ___________________________________________________________________________
  /**
   * Method to perform an employer search, based solely on the employer
   * reference number
   *
   * @param alternateIDSearchKey employer reference number
   *
   * @return Employer details
   */
  @Override
  public EmployerReadDtlsList searchByReferenceNumber(
    AlternateIDSearchKey alternateIDSearchKey) throws AppException,
      InformationalException {

    return getEmployerSearchObj().searchByReferenceNumber(alternateIDSearchKey);

  }

  // BEGIN, CR00218664, ZV
  // ___________________________________________________________________________
  /**
   * Method to validate employer search criteria
   *
   * @param key person search criteria to be validated
   *
   * @throws InformationalException
   * {@link GENERALSEARCH#ERR_SEARCH_FV_CITY_SHORT} -
   * If city contains less than 2 alphanumerical characters.
   * @throws InformationalException
   * @throws InformationalException
   * {@link BPOEMPLOYERSEARCH#ERR_EMPLOYERSEARCH_FV_TRADING_NAME_SHORT} -
   * If trading name contains less than 2 alphanumerical characters.
   * @throws InformationalException
   * {@link GENERALSEARCH#ERR_SEARCH_FV_ADDRESS_LINE_1_SHORT} -
   * If address line 1 contains less than 2 alphanumerical characters.
   * @throws InformationalException
   * {@link GENERALSEARCH#ERR_SEARCH_FV_STREET_NAME_SHORT} -
   * If street name contains less than 2 alphanumerical characters.
   * @throws InformationalException
   * {@link BPOEMPLOYERSEARCH#ERR_EMPLOYERSEARCH_FV_REGISTERED_NAME_SHORT} -
   * If registered name contains less than 2 alphanumerical characters.
   * @throws InformationalException
   * {@link GENERALSEARCH#ERR_SEARCH_FV_STREET_NUMBER_SHORT} -
   * If street number contains less than 1 alphanumerical characters.
   * @throws InformationalException
   * {@link GENERALSEARCH#ERR_SEARCH_FV_ADDRESS_LINE_2_SHORT} -
   * If address line 2 contains less than 2 alphanumerical characters.
   * @throws InformationalException
   * {@link GENERALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING} -
   * If there is no criteria specified.
   * @throws InformationalException
   * {@link BPOEMPLOYERSEARCH#ERR_EMPLOYERSEARCH_XFV_ADDITIONAL_CRITERIA} -
   * If additional search criteria is required.
   */
  @Override
  protected void validateSearchKey(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00250660, ZV
    final ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
    final SearchCriteriaString searchCriteriaString = new SearchCriteriaString();
    CharCount count;

    // END, CR00250660

    // check if any search criteria are provided
    if (key.tradingName.length() == 0 && key.registeredName.length() == 0
      && key.referenceNumber.length() == 0
      && key.addressDtls.addressLine1.length() == 0
      && key.addressDtls.addressLine2.length() == 0
      && key.addressDtls.city.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00250660, ZV
    if (key.tradingName.length() > 0) {

      searchCriteriaString.string = key.tradingName;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < 2) {
        informationalManager.addInformationalMsg(
          new AppException(BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_FV_TRADING_NAME_SHORT).arg(
            2),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
      }
    }

    // BEGIN, CR00379119, SS
    if (0 < key.referenceNumber.length()) {
      searchCriteriaString.string = key.referenceNumber;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);
      if (1 > count.count) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(GENERALSEARCH.ERR_SEARCH_FV_REFERENCE_NUMBER_SHORT).arg(
            1),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00379119

    if (key.registeredName.length() > 0) {

      searchCriteriaString.string = key.registeredName;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < 2) {
        informationalManager.addInformationalMsg(
          new AppException(BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_FV_REGISTERED_NAME_SHORT).arg(
            2),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
      }
    }

    // BEGIN, CR00290794, ZV
    String addressLayout = Configuration.getProperty(EnvVars.ENV_ADDRESS_LAYOUT);

    if (addressLayout == null || addressLayout.isEmpty()) {
      addressLayout = EnvVars.ENV_ADDRESS_LAYOUT_DEFAULT;
    }
    // END, CR00290794

    if (key.addressDtls.addressLine1.length() > 0) {

      // BEGIN, CR00290794, ZV
      final int addressLine2Minimum = addressLayout.equals(
        ADDRESSLAYOUTTYPE.CA_CIVIC)
          ? 1
          : 2;

      searchCriteriaString.string = key.addressDtls.addressLine1;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < addressLine2Minimum) {
        final AppException ae = addressLayout.equals(ADDRESSLAYOUTTYPE.CA_CIVIC)
          ? new AppException(GENERALSEARCH.ERR_SEARCH_FV_STREET_NUMBER_SHORT)
          : new AppException(GENERALSEARCH.ERR_SEARCH_FV_ADDRESS_LINE_1_SHORT);

        informationalManager.addInformationalMsg(ae.arg(addressLine2Minimum),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
      // END, CR00290794
    }

    if (key.addressDtls.addressLine2.length() > 0) {

      searchCriteriaString.string = key.addressDtls.addressLine2;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < 2) {
        final AppException ae = addressLayout.equals(ADDRESSLAYOUTTYPE.CA_CIVIC)
          ? new AppException(GENERALSEARCH.ERR_SEARCH_FV_STREET_NAME_SHORT)
          : new AppException(GENERALSEARCH.ERR_SEARCH_FV_ADDRESS_LINE_2_SHORT);

        informationalManager.addInformationalMsg(ae.arg(2), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }
    }

    if (key.addressDtls.city.length() > 0) {

      searchCriteriaString.string = key.addressDtls.city;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < 2) {
        informationalManager.addInformationalMsg(
          new AppException(GENERALSEARCH.ERR_SEARCH_FV_CITY_SHORT).arg(2),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }
    // END, CR00250660

    // BEGIN, CR00290794, ZV
    if (key.tradingName.length() == 0 && key.registeredName.length() == 0
      && key.referenceNumber.length() == 0
      && key.addressDtls.addressLine1.length() == 0
      && key.addressDtls.addressLine2.length() == 0
      && key.addressDtls.city.length() != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_XFV_ADDITIONAL_CRITERIA),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00290794

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Method which routes Employer Search calls to the appropriate implementation
   *
   * @param key data on which the searched will be based
   *
   * @return The details of any employer records found
   */
  @Override
  public EmployerSearchResult1 search1(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // BEGIN, CR00457404, CR00458133, JAY
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // Trim space characters from the beginning and end of search criteria which
    // may be accidentally entered
    key.referenceNumber = key.referenceNumber.trim();
    key.registeredName = key.registeredName.trim();
    key.tradingName = key.tradingName.trim();
    if (!key.addressDtls.addressSearchData.isEmpty()) {
      OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = key.addressDtls.addressSearchData;
      final AddressMapList addressMapList = addressDataObj.parseDataToMap(
        otherAddressData);

      for (final AddressMap addressMap : addressMapList.dtls) {
        addressMap.name = addressMap.name.trim();
        addressMap.value = addressMap.value.trim();
      }
      otherAddressData = addressDataObj.parseMapToData(addressMapList);
      key.addressDtls.addressSearchData = otherAddressData.addressData;
    } else {
      key.addressDtls.addressLine1 = key.addressDtls.addressLine1.trim();
      key.addressDtls.addressLine2 = key.addressDtls.addressLine2.trim();
      key.addressDtls.city = key.addressDtls.city.trim();
    }
    // BEGIN, CR00461880, JAY
    final EmployerSearchKeyValidatorIntf employerSearchKeyValidator = (EmployerSearchKeyValidatorIntf) searchKeyValidator.get(
      CONCERNROLETYPE.EMPLOYER);

    // END, CR00461880, JAY

    employerSearchKeyValidator.validateSearchKey(key);
    // END, CR00457404, CR00458133, JAY
    final EmployerSearchResult1 employerSearchResult = getEmployerSearchObj().search1(
      key);

    // If no search results are found, alert user
    if (employerSearchResult.dtlsList.isEmpty()) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);

      informationalManager.failOperation();

    }

    return employerSearchResult;
  }
  // END, CR00218664

}
