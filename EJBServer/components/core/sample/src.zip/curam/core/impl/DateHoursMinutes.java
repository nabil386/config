/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


/**
 * Structure to hold Date, Hours code and Minutes code
 *
 */
public class DateHoursMinutes {

  protected curam.util.type.Date myDate;

  protected String myHourCode;

  protected String myMinuteCode;

  /**
   * Construct from parts
   *
   * @param date the date
   * @param hourCode the hour code from the codetable
   * @param minuteCode the minute code from the codetable
   */
  public DateHoursMinutes(curam.util.type.Date date, String hourCode,
    String minuteCode) {

    myDate = date;
    myHourCode = hourCode;
    myMinuteCode = minuteCode;
  }

  /**
   * Returns the date part
   */
  public curam.util.type.Date getDate() {

    return myDate;
  }

  /**
   * Returns the hour code part
   */
  public String getHourCode() {

    return myHourCode;
  }

  /**
   * Returns the minute code part
   */
  public String getMinuteCode() {

    return myMinuteCode;
  }
}
