/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.rules.rdo.DecisionDetailsGroup;
import curam.rules.rdo.DecisionDetailsGroup.DecisionDetailsGroupDtls;
import curam.rules.rdo.ObjectiveDetailsGroup;
import curam.rules.rdo.ObjectiveDetailsGroup.ObjectiveDetailsGroupDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.rules.RulesParameters;
import curam.util.type.Date;


/**
 * This class provides common functionality to inspect values in the
 * pre initialized RDOs which are passed to the rule set as part of
 * the eligibility determination process.
 */
public class CaseDecisionRDOData {

  protected DecisionDetailsGroup rdoDecisionDetails;

  protected ObjectiveDetailsGroup rdoObjectiveDetails;

  protected RulesParameters rp;

  // ___________________________________________________________________________
  /**
   * Create an instance of this class based on the specified
   * <code>RulesParameters</code> object.
   *
   * @param rp The <code>RulesParameters</code> object contains details of the
   * current rule execution context.
   */
  public CaseDecisionRDOData(RulesParameters rp) {

    this.rdoDecisionDetails = DecisionDetailsGroup.getCurrentInstance(rp);
    this.rdoObjectiveDetails = ObjectiveDetailsGroup.getCurrentInstance(rp);
    this.rp = rp;
  }

  // ___________________________________________________________________________
  /**
   * Determines if an objective was achieved on the specified decision date
   * which
   * matches the target id and has the specified type.
   *
   * @param decisionDate The decision date to look for the objective on
   * @param targetID The objective target id which the objective must have
   * @param type The objective type which must be matched
   *
   * @return <code>true</code> if and only if a match was found on the specified
   * date
   */
  public boolean objectiveExistsForDateTargetAndType(Date decisionDate,
    long targetID, String type) throws AppException, InformationalException {

    for (int i = 0; i < rdoObjectiveDetails.getLoopSize(rp); i++) {

      // Set loop variable
      rdoObjectiveDetails.setCurrentPos(i);

      final ObjectiveDetailsGroupDtls details = rdoObjectiveDetails.current();

      final Date decisionFromDate = details.getfromDate().getValueNoLoad();
      final Date decisionToDate = details.gettoDate().getValueNoLoad();
      final long objectiveTargetID = details.getobjectiveTargetID().getValueNoLoad();
      final String objectiveType = details.getobjectiveType().getValueNoLoad();

      if (!decisionDate.before(decisionFromDate)
        && !decisionDate.after(decisionToDate) && objectiveTargetID == targetID
        && objectiveType.equals(type)) {
        return true;
      }
    }
    return false;
  }

  // ___________________________________________________________________________
  /**
   * Determines if an 'eligible' decision exists on the specified date
   *
   * @param testDate The date to check for the 'eligible' decision
   *
   * @return <code>true</code> if and only if a match was found on the specified
   * date
   */
  public boolean eligibleDecisionExistsForDate(Date testDate)
    throws AppException, InformationalException {

    return decisionExistsForResultCodeAndDate(
      curam.codetable.CASEDECISIONRESULTCODE.ELIGIBLE, testDate);
  }

  // ___________________________________________________________________________
  /**
   * Determines if a decision with the specified result code exists on the
   * specified date
   *
   * @param resultCode The result code of the decision
   *
   * @param testDate The date to check for the decision
   * @return <code>true</code> if and only if a match was found on the specified
   * date
   */
  public boolean decisionExistsForResultCodeAndDate(String resultCode,
    Date testDate) throws AppException, InformationalException {

    for (int i = 0; i < rdoDecisionDetails.getLoopSize(rp); i++) {

      // Set loop variable
      rdoDecisionDetails.setCurrentPos(i);

      final DecisionDetailsGroupDtls details = rdoDecisionDetails.current();

      final Date decisionFromDate = details.getfromDate().getValueNoLoad();
      final Date decisionToDate = details.gettoDate().getValueNoLoad();
      final String decisionResultCode = details.getresultCode().getValueNoLoad();

      if (!testDate.before(decisionFromDate) && !testDate.after(decisionToDate)) {
        if (decisionResultCode.equals(resultCode)) {
          return true;
        }
      }
    }

    return false;
  }

}
