/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2009, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

/**
 * Utility search in Database
 *
 */

package curam.core.impl;


import curam.core.struct.ReadUtilitySummaryKey;
import curam.core.struct.SearchMessageDtls;
import curam.core.struct.UtilityDatabaseSearchKey;
import curam.core.struct.UtilitySearchDtls;
import curam.core.struct.UtilitySearchKey;
import curam.core.struct.UtilitySearchResult;
import curam.core.struct.UtilitySummaryDetails;
import curam.core.struct.UtilitySummaryDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * @deprecated Since Curam 6.0, this class is replaced by
 * {@link curam.core.sl.impl.DatabaseParticipantSearch}
 *
 * Utility search in Database
 */
@Deprecated
public abstract class DatabaseUtilitySearch extends curam.core.base.DatabaseUtilitySearch {

  // ___________________________________________________________________________
  /**
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, this class is replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#search(ParticipantSearchKey)}
   *
   * Performs a database search for utilities using the specified search
   * criteria, or performs a database read if the alternate ID is specified.
   */
  @Override
  @Deprecated
  public UtilitySearchResult search(UtilitySearchKey key)
    throws AppException, InformationalException {

    final UtilitySearchResult utilitySearchResult = new UtilitySearchResult();
    UtilitySummaryDetailsList utilitySummaryDetailsList = new UtilitySummaryDetailsList();

    final ReadUtilitySummaryKey readUtilitySummaryKey = new ReadUtilitySummaryKey();

    final curam.core.intf.Utility utilityObj = curam.core.fact.UtilityFactory.newInstance();

    // If the reference number is specified no need to process the complicated
    // query
    if (key.referenceNumber.length() == 0) {

      final UtilityDatabaseSearchKey utilityDatabaseSearchKey = calculateKey(
        key);

      try {
        utilitySummaryDetailsList = utilityObj.searchByNameTypeOrAddress(
          utilityDatabaseSearchKey);
      } catch (final curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage = // BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        utilitySearchResult.searchMessageDtlsList.dtls.addRef(
          recordFoundMessage);

      }

      // BEGIN CR00020852, SG
    } else {
      // set the search key
      readUtilitySummaryKey.primaryAlternateID = key.referenceNumber;
      try {
        utilitySummaryDetailsList = utilityObj.readSummaryDetailsByReferenceNumber(
          readUtilitySummaryKey);
      } catch (final curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage = // BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        utilitySearchResult.searchMessageDtlsList.dtls.addRef(
          recordFoundMessage);

      }
    }
    // END CR00020852

    utilitySearchResult.searchResults.numRecordsFound = utilitySummaryDetailsList.dtls.size();

    for (int i = 0; i < utilitySummaryDetailsList.dtls.size(); i++) {

      // Search details
      final UtilitySearchDtls utilitySearchDtls = new UtilitySearchDtls();

      final UtilitySummaryDetails utilitySummaryDetails = utilitySummaryDetailsList.dtls.item(
        i);

      utilitySearchDtls.assign(utilitySummaryDetails);

      utilitySearchDtls.address = utilitySummaryDetails.addressLine1;

      utilitySearchDtls.type = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(
        curam.codetable.UTILITYTYPE.TABLENAME, utilitySearchDtls.type,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      restrictResults(utilitySearchDtls);

      if (utilitySearchDtls.referenceNumber != null) {
        utilitySearchResult.utilitySearchDtlsList.dtls.addRef(utilitySearchDtls);
      } else {
        utilitySearchResult.searchResults.numRecordsFound = utilitySearchResult.searchResults.numRecordsFound
          - 1;
      }
    }

    return utilitySearchResult;

  }

  // ___________________________________________________________________________
  /**
   * @param key utility search details
   *
   * @return Key for database search
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#calculateKey(ParticipantSearchKey)}
   *
   * Calculates the details of the database search key based on the key
   */
  @Override
  @Deprecated
  protected UtilityDatabaseSearchKey calculateKey(UtilitySearchKey key)
    throws AppException, InformationalException {

    final UtilityDatabaseSearchKey utilityDatabaseSearchKey = new UtilityDatabaseSearchKey();

    // Assign the key values
    utilityDatabaseSearchKey.name = CuramConst.gkSqlWildcard
      + key.name.toUpperCase() + CuramConst.gkSqlWildcard;

    utilityDatabaseSearchKey.utilityTypeCode = CuramConst.gkSqlWildcard
      + key.type.toUpperCase() + CuramConst.gkSqlWildcard;

    utilityDatabaseSearchKey.addressLine1 = CuramConst.gkSqlWildcard
      + key.address.toUpperCase() + CuramConst.gkSqlWildcard;

    utilityDatabaseSearchKey.city = CuramConst.gkSqlWildcard
      + key.city.toUpperCase() + CuramConst.gkSqlWildcard;

    // If a parameter is specified set the searchBy indicator for that parameter
    utilityDatabaseSearchKey.searchByName = key.name.length() > 0;
    utilityDatabaseSearchKey.searchByUtilityTypeCode = key.type.length() > 0;
    utilityDatabaseSearchKey.searchByAddressLine1 = key.address.length() > 0;
    utilityDatabaseSearchKey.searchByCity = key.city.length() > 0;

    return utilityDatabaseSearchKey;
  }
}
