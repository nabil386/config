/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.AdjInstructionDetails;
import curam.core.struct.AdjustmentDetails;
import curam.core.struct.CreateAdjustmentResult;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InstructionLineItemDetails;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to create an account adjustment online.
 *
 */
public abstract class AccountAdjustment extends curam.core.base.AccountAdjustment {

  /**
   * To use the adjustment details specified as input, to create Adjustment
   * records in persistent storage.
   *
   *
   * @param adjustmentDtls Details of the adjustment
   */
  @Override
  public void captureAccountAdjustment(AdjustmentDetails adjustmentDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00247101, PM
    if (0 != adjustmentDtls.concernRoleID) {
      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
      final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

      participantSecurityCheckKey.participantID = adjustmentDtls.concernRoleID;
      participantSecurityCheckKey.type = LOCATIONACCESSTYPE.MAINTAIN;
      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
        participantSecurityCheckKey);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
        } else {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }
    }
    // END, CR00247101

    // createAdjustment manipulation variables
    final curam.core.intf.CreateAdjustment createAdjustmentObj = curam.core.fact.CreateAdjustmentFactory.newInstance();
    CreateAdjustmentResult createAdjustmentResult;

    // maintainInstructionLineItem manipulation variables
    final curam.core.intf.MaintainInstructionLineItem maintainInstructionLineItemObj = curam.core.fact.MaintainInstructionLineItemFactory.newInstance();
    final InstructionLineItemDetails instructionLineItemDetails = new InstructionLineItemDetails();

    // adjustmentInstruction manipulation variables
    final AdjInstructionDetails adjInstructionDetails = new AdjInstructionDetails();

    // validateAccountAdjustment manipulation variables
    final curam.core.intf.ValidateAccountAdjustment validateAccountAdjustmentObj = curam.core.fact.ValidateAccountAdjustmentFactory.newInstance();

    adjInstructionDetails.assign(adjustmentDtls);

    // validate the adjustment details
    validateAccountAdjustmentObj.validateAdjustmentDtls(adjustmentDtls,
      adjInstructionDetails);

    adjInstructionDetails.instrumentGenInd = false;

    // Create the adjustment instruction
    createAdjustmentResult = createAdjustmentObj.createAdjustmentInstruction(
      adjInstructionDetails);

    // Create Adjustment Instruction Line Item
    instructionLineItemDetails.amount = createAdjustmentResult.amount;
    instructionLineItemDetails.unprocessedAmount = createAdjustmentResult.amount;
    instructionLineItemDetails.instructLineItemCategory = curam.codetable.ILICATEGORY.ADJUSTMENTINSTRUCTION;

    if (createAdjustmentResult.adjustmentType.equals(
      curam.codetable.ADJUSTMENTTYPE.DEDUCTION)) {

      instructionLineItemDetails.instructionLineItemType = curam.codetable.ILITYPE.DEDUCTIONADJUSTMENT;

    } else {

      instructionLineItemDetails.instructionLineItemType = curam.codetable.ILITYPE.CHARGEADJUSTMENT;
    }

    instructionLineItemDetails.effectiveDate = curam.util.type.Date.getCurrentDate();
    instructionLineItemDetails.statusCode = curam.codetable.ILISTATUS.PROCESSED;
    instructionLineItemDetails.caseID = 0;
    instructionLineItemDetails.finInstructionID = createAdjustmentResult.finInstructionID;
    instructionLineItemDetails.concernRoleID = createAdjustmentResult.concernRoleID;
    instructionLineItemDetails.primaryClientID = createAdjustmentResult.concernRoleID;

    if (createAdjustmentResult.adjustmentType.equals(
      curam.codetable.ADJUSTMENTTYPE.DEDUCTION)) {

      instructionLineItemDetails.creditDebitType = curam.codetable.CREDITDEBIT.CREDIT;

    } else {

      instructionLineItemDetails.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
    }

    instructionLineItemDetails.currencyTypeCode = createAdjustmentResult.currencyTypeCode;
    instructionLineItemDetails.currencyExchangeID = createAdjustmentResult.currencyExchangeID;
    instructionLineItemDetails.adjustmentInd = false;
    // BEGIN, CR00049218, GM
    instructionLineItemDetails.adjustmentFrequency = CuramConst.gkEmpty;
    // END, CR00049218

    instructionLineItemDetails.nextAdjustmentDate = curam.util.type.Date.kZeroDate;

    instructionLineItemDetails.instrumentGenInd = false;
    instructionLineItemDetails.fundID = 0;
    // BEGIN, CR00074927, JI
    instructionLineItemDetails.dueDate = curam.util.type.Date.getCurrentDate();
    instructionLineItemDetails.inRespectOfID = 0;
    // END, CR00074927

    // insert instructionLineItem
    maintainInstructionLineItemObj.addInstructionLineItem(
      instructionLineItemDetails);

  }

}
