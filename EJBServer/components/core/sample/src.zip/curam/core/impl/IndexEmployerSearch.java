/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.codetable.TERMTYPE;
import curam.core.fact.SearchServiceFactory;
import curam.core.impl.util.CuramDocToResultStruct;
import curam.core.sl.entity.fact.ProspectEmployerFactory;
import curam.core.sl.entity.intf.ProspectEmployer;
import curam.core.sl.entity.struct.ProspectEmployerDtls;
import curam.core.sl.entity.struct.ProspectEmployerKey;
import curam.core.sl.fact.IndexParticipantSearchFactory;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.infrastructure.impl.IndexSearchConst;
import curam.core.sl.intf.IndexParticipantSearch;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.sl.struct.TextFieldDetails;
import curam.core.struct.CuramDocument;
import curam.core.struct.CuramField;
import curam.core.struct.CuramQuery;
import curam.core.struct.CuramTerm;
import curam.core.struct.DisableLinkIndicatorDetails;
import curam.core.struct.EmployerSearchDetails;
import curam.core.struct.EmployerSearchDtls;
import curam.core.struct.EmployerSearchDtls1;
import curam.core.struct.EmployerSearchKey;
import curam.core.struct.EmployerSearchKey1;
import curam.core.struct.EmployerSearchResult;
import curam.core.struct.EmployerSearchResult1;
import curam.core.struct.SearchServerResults;
import curam.core.struct.SearchServiceKey;
import curam.message.BPOPARTICIPANTSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * This class creates the search query and performs the search for
 * Employer lucene index search
 */
public abstract class IndexEmployerSearch extends curam.core.base.IndexEmployerSearch {

  // dictionary used for matching the entity attribute names
  // with the return struct name for output display
  protected final static HashMap<String, String> dictionary = new HashMap<String, String>();
  // BEGIN, CR00085608 SK
  static {
    dictionary.put(IndexSearchConst.kBusinessCity, IndexSearchConst.kCity);
    dictionary.put(IndexSearchConst.kBusinessAddress,
      IndexSearchConst.kAddressLine1);
    dictionary.put(IndexSearchConst.kReferenceNumber,
      IndexSearchConst.kPrimaryAlternateID);
  }

  // END, CR00085608 SK

  // BEGIN, CR00222456 ZV
  protected final static HashMap<String, String> dictionary1 = new HashMap<String, String>();
  static {
    dictionary1.put(IndexSearchConst.kBusinessAddress,
      IndexSearchConst.kAddressData);
  }

  // END, CR00222456

  // ___________________________________________________________________________
  /**
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} This method has
   * been deprecated to introduce new employer search
   * enhancements.
   *
   * Performs a lucene index search for employers using the specified search
   * criteria.
   */
  @Override
  @Deprecated
  public EmployerSearchResult search(EmployerSearchKey key)
    throws AppException, InformationalException {

    final EmployerSearchResult result = new EmployerSearchResult();
    final CuramQuery curamQuery = new CuramQuery();
    final LuceneHelper luceneHelper = new LuceneHelper();

    // add the terms to the curam query if they exist
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kRegisteredName,
      key.registeredName, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kAddressLine1,
      key.businessAddress, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kCity, key.businessCity,
      true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kPrimaryAlternateID,
      key.referenceNumber, false),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kTradingName,
      key.tradingName, true),
      curamQuery);

    final SearchServiceKey searchServiceKey = new SearchServiceKey();

    searchServiceKey.searchServiceId = IndexSearchConst.kEmployerSearch;
    // BEGIN, CR00112556, CW
    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;
    // END, CR00112556

    // add field data to the search query
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kRegisteredName));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kAddressLine1));
    curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kCity));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kTradingName));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kPrimaryAlternateID));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kSensitivity));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kConcernRoleID));

    final SearchServerResults searchResults = SearchServiceConnector.search(
      curamQuery);

    // For each field in the CuramDocument, the method attempts
    // to find an attribute in the struct of the same name and data type
    // A dictionary is passed to resolve attribute names that do not match
    // A struct containing all mapped values is returned.
    for (int i = 0; i < searchResults.documents.dtls.size(); i++) {
      EmployerSearchDtls employerSearchDtls = new EmployerSearchDtls();
      final CuramDocument document = searchResults.documents.dtls.item(i);

      employerSearchDtls = (EmployerSearchDtls) CuramDocToResultStruct.convert(
        document, employerSearchDtls, dictionary);

      restrictResults(employerSearchDtls);

      result.details.dtls.addRef(employerSearchDtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Adds a term to the curam query if the term exists
   *
   * @param term the curam term type
   * @param curamQuery the curam query
   */
  // BEGIN, CR00198672, VK
  protected void addTermIfExists(final CuramTerm term,
    final CuramQuery curamQuery) {

    // END, CR00198672
    if (term.termType.equals(TERMTYPE.STANDARD)) {
      if (term.stdTerm.value.length() > 0) {
        curamQuery.terms.dtls.addRef(term);
      }
    } else if (term.termType.equals(TERMTYPE.DATE)) {
      if (!term.dtTerm.value.isZero()) {
        curamQuery.terms.dtls.addRef(term);
      }
    }
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Creates a result field for the curam query
   *
   * @param field the field name
   *
   * @return CuramField the curam field
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link curam.core.impl.LuceneHelper#createResultField()}
   */
  // BEGIN, CR00198672, VK
  @Deprecated
  protected CuramField createResultField(final String field) {

    // END, CR00198672
    final LuceneHelper luceneHelper = new LuceneHelper();

    return luceneHelper.createResultField(field);
  }

  // END, CR00257963

  // BEGIN, CR00222456, ZV
  // ___________________________________________________________________________
  /**
   * Performs a lucene index search for employers using the specified search
   * criteria.
   *
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   */
  @Override
  public EmployerSearchResult1 search1(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // BEGIN, CR00257963, ZV
    final CuramQuery curamQuery = createSearchQuery(key);

    final SearchServerResults searchResults = executeQuery(curamQuery);

    final EmployerSearchResult1 result = processSearchQueryResults(
      searchResults, key);

    // END, CR00257963

    return result;
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for participant lucene index search for the specified search
   * criteria.
   *
   * @param key data on which the query will be based
   *
   * @return The Curam query for participant lucene index search
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #createSearchQuery()}
   */
  @Deprecated
  public CuramQuery createQuery(EmployerSearchKey1 key) throws AppException,
      InformationalException {

    return createSearchQuery(key);

  }

  // END, CR00257963

  // ___________________________________________________________________________
  /**
   * Executes a lucene index search query
   *
   * @param curamQuery Query to execute
   *
   * @return The lucene index search query results
   */
  protected SearchServerResults executeQuery(CuramQuery curamQuery)
    throws AppException, InformationalException {

    return SearchServiceConnector.search(curamQuery);
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Method to process employer query search results.
   *
   * @param searchServerResults Lucene index search query results
   * @param key data on which the search was based
   *
   * @return The details of any employer records found
   *
   * @throws AppException
   * {@link BPOPARTICIPANTSEARCH#ERR_PARTICIPANTSEARCH_XRV_MAXIMUM} -
   * If search results exceeds participant search maximum value.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #processSearchQueryResults()}
   */
  @Deprecated
  public EmployerSearchResult1 processQueryResults(
    SearchServerResults searchServerResults, EmployerSearchKey1 key)
    throws AppException, InformationalException {

    return processSearchQueryResults(searchServerResults, key);

  }

  // END, CR00257963
  // END, CR00222456

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for participant lucene index search for the specified search
   * criteria.
   *
   * @param key data on which the query will be based
   *
   * @return The Curam query for participant lucene index search
   */
  public static CuramQuery createSearchQuery(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    final CuramQuery curamQuery = new CuramQuery();
    final SearchServiceKey searchServiceKey = new SearchServiceKey();
    final LuceneHelper luceneHelper = new LuceneHelper();
    final IndexParticipantSearch indexParticipantSearchObj = IndexParticipantSearchFactory.newInstance();
    final TextFieldDetails textFieldDetails = new TextFieldDetails();

    searchServiceKey.searchServiceId = IndexSearchConst.kParticipantSearch;

    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

    // Add the fields which will be used to store the results to the query
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kPrimaryAlternateID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kAddressData));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kTradingName));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kRegisteredName));

    curamQuery.text = "(" + IndexSearchConst.kConcernRoleType
      + CuramConst.gkColon + CONCERNROLETYPE.EMPLOYER;
    curamQuery.text += IndexSearchConst.kORString;
    curamQuery.text += IndexSearchConst.kConcernRoleType + CuramConst.gkColon
      + CONCERNROLETYPE.PROSPECTEMPLOYER + ")";

    if (key.referenceNumber.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kAlternateIDList;
      // BEGIN, CR00379119, SS
      final ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
      final SearchCriteriaString referenceKeyvalue = new SearchCriteriaString();

      referenceKeyvalue.string = key.referenceNumber;
      textFieldDetails.fieldValue = participantSearchObj.formatReferenceFieldValue(referenceKeyvalue).fieldValue;
      // END, CR00379119
      // BEGIN, CR00298781, ZV
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
      // END, CR00298781
    }

    if (key.tradingName.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kTradingName;
      textFieldDetails.fieldValue = key.tradingName;
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }

    if (key.registeredName.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kRegisteredName;
      textFieldDetails.fieldValue = key.registeredName;
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }

    if (key.addressDtls.addressLine1.length() > 0
      || key.addressDtls.addressLine2.length() > 0
      || key.addressDtls.city.length() > 0) {

      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
        + IndexSearchConst.kIndexFalseInd;

      curamQuery.text += indexParticipantSearchObj.createQueryAddressSearch(key.addressDtls).statement;

    } else {
      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
        + IndexSearchConst.kIndexTrueInd;
    }

    return curamQuery;
  }

  // ___________________________________________________________________________
  /**
   * Method to process employer query search results.
   *
   * @param searchServerResults Lucene index search query results
   * @param key data on which the search was based
   *
   * @return The details of any employer records found
   *
   * @throws AppException
   * {@link BPOPARTICIPANTSEARCH#ERR_PARTICIPANTSEARCH_XRV_MAXIMUM} -
   * If search results exceeds participant search maximum value.
   */
  public static EmployerSearchResult1 processSearchQueryResults(
    SearchServerResults searchServerResults, EmployerSearchKey1 key)
    throws AppException, InformationalException {

    final EmployerSearchResult1 result = new EmployerSearchResult1();
    final List<Long> concernRoleIDList = new ArrayList<Long>();

    int searchMaximum = CuramConst.gkZero;

    if (Configuration.getIntProperty(EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM)
      != null) {
      searchMaximum = Configuration.getIntProperty(
        EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM);
    } else {
      searchMaximum = EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM_DEFAULT;
    }

    if (searchServerResults.documents.dtls.size() > searchMaximum) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        BPOPARTICIPANTSEARCH.ERR_PARTICIPANTSEARCH_XRV_MAXIMUM);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      informationalManager.failOperation();

    } else {

      final DisableLinkIndicatorDetails disableLinkIndicatorDetails = new DisableLinkIndicatorDetails();

      disableLinkIndicatorDetails.disableLinkInd = key.disableLinkInd;

      // Convert the results into the result structure.
      for (int i = 0; i < searchServerResults.documents.dtls.size(); i++) {

        EmployerSearchDtls1 employerSearchDtls = new EmployerSearchDtls1();

        final CuramDocument document = searchServerResults.documents.dtls.item(
          i);

        employerSearchDtls = (EmployerSearchDtls1) CuramDocToResultStruct.convert(
          document, employerSearchDtls, dictionary1);

        if (employerSearchDtls.tradingName.equals(IndexSearchConst.kNull)) {
          employerSearchDtls.tradingName = new String();
        }
        if (employerSearchDtls.registeredName.equals(IndexSearchConst.kNull)) {
          employerSearchDtls.registeredName = new String();
        }

        // set alternate id to input key
        // this is to set correct alternate id in the case when
        // it does not match primary alternate id
        if (key.referenceNumber.length() > 0) {
          employerSearchDtls.alternateID = key.referenceNumber;
        }

        final curam.core.intf.EmployerSearch employerSearchObj = curam.core.fact.EmployerSearchFactory.newInstance();

        final EmployerSearchDetails employerSearchDetails = employerSearchObj.processSearchDetails(
          employerSearchDtls, disableLinkIndicatorDetails);

        // BEGIN, CR00362049, ZV
        if (employerSearchDetails != null
          && !concernRoleIDList.contains(employerSearchDetails.concernRoleID)) {
          // END, CR00362049

          // BEGIN, CR00256231, ZV
          boolean prospectRegisteredInd = false;

          if (employerSearchDtls.concernRoleType.equals(
            CONCERNROLETYPE.PROSPECTEMPLOYER)) {

            final ProspectEmployer prospectEmployerObj = ProspectEmployerFactory.newInstance();
            final ProspectEmployerKey prospectEmployerKey = new ProspectEmployerKey();

            prospectEmployerKey.concernRoleID = employerSearchDtls.concernRoleID;
            final ProspectEmployerDtls prospectEmployerDtls = prospectEmployerObj.read(
              prospectEmployerKey);

            prospectRegisteredInd = prospectEmployerDtls.employerConcernRoleID
              != 0;

          }

          if (!prospectRegisteredInd) {
            result.dtlsList.addRef(employerSearchDetails);
            concernRoleIDList.add(employerSearchDetails.concernRoleID);
          }
          // END, CR00256231
        }

      }
    }

    return result;
  }
  // END, CR00257963

}
