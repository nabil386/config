/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.UniqueIDFactory;
import curam.core.struct.AdhocBonusCriteriaDtls;
import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Functions for manipulating ADhoc bonus criteria information (insert, modify,
 * etc.)
 *
 */
public abstract class AdhocBonusCriteria extends curam.core.base.AdhocBonusCriteria {

  /**
   * Generates an unique adhocBonusCriteriaID.
   *
   * @param details
   * ADhoc bonus criteria entity details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final AdhocBonusCriteriaDtls details)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_PRODUCTBO;

    details.adhocBonusCriteriaID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
      uniqueIDKeySet);

  }
}
