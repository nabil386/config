/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.IndexLiabilityInstructionSynchronizationFactory;
import curam.core.intf.IndexLiabilityInstructionSynchronization;
import curam.core.struct.LbyInstrAmountPeriod;
import curam.core.struct.LiabilityInstructionDtls;
import curam.core.struct.LiabilityInstructionKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Pre and post data access routines for LiabilityInstruction.
 *
 */
public abstract class LiabilityInstruction extends curam.core.base.LiabilityInstruction {

  // ___________________________________________________________________________
  // BEGIN, CR00078922, CC
  /**
   * Called after the insert operation.
   *
   * @param details The details for the new liability instruction record
   */
  @Override
  protected void postinsert(LiabilityInstructionDtls details)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the liability
    // instruction entity.
    final IndexLiabilityInstructionSynchronization pmtInstructionSynchronizationObj = IndexLiabilityInstructionSynchronizationFactory.newInstance();

    pmtInstructionSynchronizationObj.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Called after the modifyAmountPeriod operation.
   *
   * @param liabilityInstructionKey generated standard key for Liability
   * Instruction
   * @param lbyInstrAmountPeriod contains the amount and period to be updated on
   * liability instruction record
   */
  @Override
  protected void postmodifyAmountPeriod(
    LiabilityInstructionKey liabilityInstructionKey,
    LbyInstrAmountPeriod lbyInstrAmountPeriod) throws AppException,
      InformationalException {

    // Synchronize the indexed staging database with the update to the liability
    // instruction entity.
    final IndexLiabilityInstructionSynchronization pmtInstructionSynchronizationObj = IndexLiabilityInstructionSynchronizationFactory.newInstance();

    pmtInstructionSynchronizationObj.modifyAmountPeriod(liabilityInstructionKey,
      lbyInstrAmountPeriod);
  }
  // END, CR00078922, CC
}
