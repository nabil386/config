/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.EducationalInstituteDatabaseSearchKey;
import curam.core.struct.ReadInformationProviderSummaryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Education Institute Definition: A Information Provider .
 *
 */
public class EducationalInstitute extends curam.core.base.EducationalInstitute {

  /**
   * Sets up details for the read to ensure the correct details are always
   * returned
   *
   * @param key
   * details for the read
   */
  @Override
  protected void presearchByNameOrAddressOrType(
    EducationalInstituteDatabaseSearchKey key) throws AppException,
      InformationalException {

    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;
    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;

  }

  /**
   * Sets up details for the read to ensure the correct details are always
   * returned
   *
   * @param key
   * details for the read
   */
  @Override
  protected void presearchSummaryDetailsByReferenceNumber(
    ReadInformationProviderSummaryKey key) throws AppException,
      InformationalException {

    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;
    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;

  }

}
