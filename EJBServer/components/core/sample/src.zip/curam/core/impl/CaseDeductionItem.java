/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.BUSINESSSTATUS;
import curam.codetable.DEDUCTIONCATEGORYCODE;
import curam.core.events.CASEDEDUCTIONITEM;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.struct.BusinessStatusVersionNo;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemKey;
import curam.core.struct.CaseIDNameDateRangeStatusDetails;
import curam.core.struct.CaseIDPriorityStatus;
import curam.core.struct.CaseIDRecordStatus;
import curam.core.struct.CaseNomineeIDStatusEndDate;
import curam.core.struct.CountCasesByConcernRoleKey;
import curam.core.struct.DeductionNameDateRangeStatusDetails;
import curam.core.struct.StatusCodeBusinessStatus;
import curam.message.BPOMAINTAINDEDUCTIONITEMS;
import curam.message.BPOMAINTAINDEDUCTIONITEMSASSISTANT;
import curam.message.GENERAL;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Case Deduction Item
 * Entity
 */
public abstract class CaseDeductionItem extends curam.core.base.CaseDeductionItem {

  // ___________________________________________________________________________
  /**
   * Checks that the data being inserted/modified for the entity
   * contains valid fields.
   *
   * @param details the data being inserted/modified
   */
  @Override
  protected void autovalidate(CaseDeductionItemDtls details)
    throws AppException, InformationalException {

    // Check that a start date has been entered for the deduction
    if (details.startDate.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_START_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 15);
    }

    // Check the start date is not later than the end date
    if (!details.endDate.isZero() && details.startDate.after(details.endDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_XFV_START_DATE_END_DATE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 20);
    }

    // Entity validations specific to applied, un-applied and
    // third party deductions
    if (details.category.equals(DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION)
      || details.category.equals(DEDUCTIONCATEGORYCODE.UNAPPLIEDDEDUCTION)
      || details.category.equals(DEDUCTIONCATEGORYCODE.THIRDPARTYDEDUCTION)) {

      // Check that an action type has been selected
      if (details.actionType.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINDEDUCTIONITEMS.ERR_DEDUCTION_FV_ACTION_TYPE_SELECT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // Check that the priority is not a negative number
      if (details.priority < 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPODEDUCTION.ERR_DEDUCTION_FV_PRIORITY_POSITIVE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    if (details.category.equals(DEDUCTIONCATEGORYCODE.THIRDPARTYDEDUCTION)) {

      // Check that account name has been entered
      if (details.customerAccName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINDEDUCTIONITEMS.ERR_DEDUCTION_FV_ACCOUNT_NAME_ENTER),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }

      // Check that account number has been entered
      if (details.customerAccNumber.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINDEDUCTIONITEMS.ERR_DEDUCTION_FV_ACCOUNT_NUMBER_ENTER),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Called before the insert operation.
   *
   * @param details The details for the new case deduction item record
   */
  @Override
  protected void preinsert(CaseDeductionItemDtls details)
    throws AppException, InformationalException {

    // Validate deduction details.
    validateInsert(details);

    // Set status for the new deduction record to 'Active'.
    details.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // Set business status for the new deduction record to inactive
    details.businessStatus = BUSINESSSTATUS.INACTIVE;
  }

  // ___________________________________________________________________________
  /**
   * Called before the modification operation.
   *
   * @param key The key of case deduction item being modified
   * @param details The new details for the case deduction item
   */
  @Override
  protected void premodify(CaseDeductionItemKey key,
    CaseDeductionItemDtls details) throws AppException,
      InformationalException {

    // Validate deduction details.
    validateModify(key);
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the data being inserted.
   *
   * @param details the data being inserted
   */
  @Override
  public void validateInsert(CaseDeductionItemDtls details)
    throws AppException, InformationalException {

    // Entity validation specific to applied, un-applied and
    // third party deductions
    if (details.category.equals(DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION)
      || details.category.equals(DEDUCTIONCATEGORYCODE.UNAPPLIEDDEDUCTION)
      || details.category.equals(DEDUCTIONCATEGORYCODE.THIRDPARTYDEDUCTION)) {

      // Check that a deduction name has been entered
      if (details.deductionName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINDEDUCTIONITEMS.ERR_DEDUCTION_FV_NAME_ENTER),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the data being modified.
   *
   * @param key The key of deduction being modified
   */
  @Override
  public void validateModify(CaseDeductionItemKey key) throws AppException,
      InformationalException {

    // CaseDeductionItem manipulation variables
    final curam.core.intf.CaseDeductionItem caseDeductionItemObj = curam.core.fact.CaseDeductionItemFactory.newInstance();
    CaseDeductionItemDtls caseDeductionItemDtls;

    // Read back details of record to be modified
    caseDeductionItemDtls = caseDeductionItemObj.read(key);

    // If the deduction has been cancelled it cannot be modified.
    if (caseDeductionItemDtls.statusCode.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINDEDUCTIONITEMSASSISTANT.ERR_DEDUCTIONITEMASSISTANT_MODIFICATION_STATUS_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Calls validation of the data being modified.
   *
   * @param key The key of deduction being modified
   * @param details The details of new deduction business status
   */
  @Override
  protected void premodifyBusinessStatus(CaseDeductionItemKey key,
    BusinessStatusVersionNo details) throws AppException,
      InformationalException {

    // Validate the business status
    validateModifyBusinessStatus(key, details);
  }

  // BEGIN, CR00089673, KH
  // ___________________________________________________________________________
  /**
   * Raises an event when the new business status is 'Active'.
   *
   * @param key The key of deduction being modified.
   * @param details The details of new deduction business status.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void postmodifyBusinessStatus(CaseDeductionItemKey key,
    BusinessStatusVersionNo details) throws AppException,
      InformationalException {

    if (details.businessStatus.equals(BUSINESSSTATUS.ACTIVE)) {

      // Raise an event if the case deduction item has been activated
      final Event event = new Event();

      event.eventKey = CASEDEDUCTIONITEM.ACTIVATE_DEDUCTION;
      event.primaryEventData = key.caseDeductionItemID;

      EventService.raiseEvent(event);
    }
  }

  // END, CR00089673

  // ___________________________________________________________________________
  /**
   * Sets deduction status details before searching for overlapping
   * deductions.
   *
   * @param key Deduction details for which overlapping deductions will be
   * retrieved.
   */
  @Override
  protected void presearchOverlappingDeductions(
    DeductionNameDateRangeStatusDetails key) throws AppException,
      InformationalException {

    // Set the status code and business status details. The search
    // will only be carried out for deductions where both statuses
    // are 'Active'.
    key.businessStatus = curam.codetable.BUSINESSSTATUS.ACTIVE;

    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the data being modified.
   *
   * @param key The key of deduction being modified
   * @param details The details of new deduction business status
   */
  @Override
  public void validateModifyBusinessStatus(CaseDeductionItemKey key,
    BusinessStatusVersionNo details) throws AppException,
      InformationalException {

    StatusCodeBusinessStatus statusCodeBusinessStatus = new StatusCodeBusinessStatus();

    // Read the current status code and business status
    statusCodeBusinessStatus = readStatusBusinessStatus(key);

    if (details.businessStatus.equals(curam.codetable.BUSINESSSTATUS.ACTIVE)) {

      // The status code cannot be cancelled when activating the deduction
      if (statusCodeBusinessStatus.statusCode.equals(
        curam.codetable.RECORDSTATUS.CANCELLED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPODEDUCTION.ERR_DEDUCTION_XRV_ACTIVATE_CANCELED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // The deduction cannot be activated already.
      if (statusCodeBusinessStatus.businessStatus.equals(
        curam.codetable.BUSINESSSTATUS.ACTIVE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPODEDUCTION.ERR_DEDUCTION_XRV_ALREADY_ACTIVATED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    } else if (details.businessStatus.equals(
      curam.codetable.BUSINESSSTATUS.INACTIVE)) {

      // The status code cannot be cancelled when deactivating the deduction
      if (statusCodeBusinessStatus.statusCode.equals(
        curam.codetable.RECORDSTATUS.CANCELLED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPODEDUCTION.ERR_DEDUCTION_XRV_DEACTIVATE_CANCELED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // The deduction cannot be deactivated already.
      if (statusCodeBusinessStatus.businessStatus.equals(
        curam.codetable.BUSINESSSTATUS.INACTIVE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPODEDUCTION.ERR_DEDUCTION_XRV_ALREADY_DEACTIVATED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Sets the status to active before reading the lowest priority.
   *
   * @param key The key for the search, contains caseID, statusCode
   */
  @Override
  protected void prereadLowestPriority(CaseIDAndStatusKey key)
    throws AppException, InformationalException {

    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Sets the status to active before reading the deduction item.
   *
   * @param key The key for the search, contains caseID, priority, statusCode
   */
  @Override
  protected void prereadActiveDeductionByCaseIDPriority(
    CaseIDPriorityStatus key) throws AppException, InformationalException {

    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Sets the status to active before counting the number of active
   * deductions for a participant
   *
   * @param key The key for the search, contains concernRoleID
   */
  @Override
  protected void precountActiveDeductionByConcernRoleID(
    CountCasesByConcernRoleKey key) throws AppException,
      InformationalException {

    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Called before the searchActivePriorityByCaseID operation.
   * Sets the record status to 'Active' before performing the search.
   *
   * @param key The key of deduction being searched
   */
  @Override
  protected void presearchActivePriorityByCaseID(CaseIDRecordStatus key)
    throws AppException, InformationalException {

    // Search records with an 'Active' status.
    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Called before the searchActiveCDIByCaseNomineeID operation.
   * Sets the record status to 'Active' and the endDate to today
   * before performing the search.
   *
   * @param key The key of deductions being searched
   */
  @Override
  protected void presearchActiveCDIByCaseNomineeID(
    CaseNomineeIDStatusEndDate key) throws AppException,
      InformationalException {

    // Search records with an 'Active' status.
    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // Search records where the endDate is either null or not
    // before today's date.
    key.endDate = curam.util.type.Date.getCurrentDate();
  }

  // BEGIN, CR00004093, SPD
  // ___________________________________________________________________________
  /**
   * Sets deduction status details before searching for overlapping
   * deductions.
   *
   * @param key Deduction details for which overlapping deductions will be
   * retrieved.
   */
  @Override
  protected void presearchByCaseIDNameDateRangeStatus(
    CaseIDNameDateRangeStatusDetails key) throws AppException,
      InformationalException {

    // Set the status code and business status details. The search
    // will only be carried out for deductions where both statuses
    // are 'Active'.
    key.businessStatus = curam.codetable.BUSINESSSTATUS.ACTIVE;

    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
  }
  // END, CR00004093
}
