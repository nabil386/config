/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.InfoProviderSearchKey;
import curam.core.struct.InfoProviderSearchResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * @deprecated Since Curam 6.0, this class is replaced by {@link #curam.core.sl.ParticipantSearchRouter}
 *
 * Provides methods which will route information provider searches to the
 * appropriate search engine based on environment settings
 */
@Deprecated
public abstract class InformationProviderSearchRouter extends curam.core.base.InformationProviderSearchRouter {

  // ___________________________________________________________________________
  /**
   * @param informationProviderSearchKey data on which the search will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.ParticipantSearchRouter#search(ParticipantSearchKey)}
   * .
   *
   * Method which routes InformationProvider Search calls to the appropriate
   * implementation
   */
  @Override
  @Deprecated
  public InfoProviderSearchResult search(
    InfoProviderSearchKey informationProviderSearchKey) throws AppException,
      InformationalException {

    // BEGIN, CR00232051, GD
    final curam.core.intf.InformationProviderSearch informationProviderSearchObj = curam.core.fact.DatabaseInformationProviderSearchFactory.newInstance();

    // END, CR00232051

    // Trim space characters from the beginning and end of search criteria which
    // may be accidentally entered
    informationProviderSearchKey.address = informationProviderSearchKey.address.trim();
    informationProviderSearchKey.city = informationProviderSearchKey.city.trim();
    informationProviderSearchKey.name = informationProviderSearchKey.name.trim();

    // check if any search criteria are provided
    if (informationProviderSearchKey.address.length() == 0
      && informationProviderSearchKey.city.length() == 0
      && informationProviderSearchKey.name.length() == 0
      && informationProviderSearchKey.referenceNumber.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          14);
    }

    return informationProviderSearchObj.search(informationProviderSearchKey);

  }

}
