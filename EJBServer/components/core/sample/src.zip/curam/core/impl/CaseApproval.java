/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CaseApprovalDtls;
import curam.events.CASE;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Case Approval entity.
 */
public abstract class CaseApproval extends curam.core.base.CaseApproval {

  // ___________________________________________________________________________
  /**
   * This method will raise a Case Approval Event.
   *
   * @param caseApprovalDtls The case approval entity data which was inserted.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected void postinsert(CaseApprovalDtls caseApprovalDtls)
    throws AppException, InformationalException {

    // Raise an event following this case approval
    final Event event = new Event();

    event.eventKey = CASE.INSERT_APPROVAL;

    event.primaryEventData = caseApprovalDtls.caseApprovalID;
    EventService.raiseEvent(event);
  }

}
