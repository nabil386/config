/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.sl.infrastructure.impl.CalendarExportConst;
import curam.core.struct.ActivityOwnerAndDateRangeKey;
import curam.core.struct.ActivitySummaryDetails;
import curam.core.struct.CalendarExportDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * This process class provides the functionality to export calendar
 * information to a flat file.
 *
 */
public abstract class CalendarExport extends curam.core.base.CalendarExport {

  /**
   * The PrintStream to which the calendar information will be written.
   */
  protected static java.io.PrintStream stOutFile = null;

  // BEGIN, CR00023323, SK
  /**
   * Used to mark the start position of a calendar in a string
   * its value is {@value}
   */
  protected static final String kCalendarBeginString = CalendarExportConst.kCalendarBeginString;

  /**
   * Used to mark the end position of a calendar in a string,
   * its value is {@value}
   *
   */
  protected static final String kCalendarEndString = CalendarExportConst.kCalendarEndString;

  /**
   * Used the mark the position of a version number in a string,
   * its value is {@value}
   */
  protected static final String kVersionString = CalendarExportConst.kVersionString;

  /**
   * Used to mark the position of a product ID in a string,
   * its value is {@value}
   */
  protected static final String kProdIDString = CalendarExportConst.kProdIDString;

  /**
   * The name of the product,
   * its value is {@value}
   */
  protected static final String kProductIDString = CalendarExportConst.kProductIDString;

  // END, CR00023323

  /**
   * The maximum number of activity owners, its value is {@value}
   */
  protected static final short kMaxNumberOfActivityOwners = 1;

  // ____________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * SelectUserActivities nsmulti operation
   *
   */
  static class SelectAllActivities extends curam.util.dataaccess.ReadmultiOperation {

    protected static curam.core.intf.ProcessCalendarExport processCalendarExportObj = curam.core.fact.ProcessCalendarExportFactory.newInstance();

    // __________________________________________________________________________
    /**
     * This method is executed for each of the records retrieved
     * during a read-multi operation, and is passed an object of
     * type ActivitySummaryDetails. If the summary details are
     * for an activity that has not been canceled, then they
     * are written to a CalendarExport PrintStream.
     *
     * @param objDtls Contains details about activity.
     *
     * @return true
     */
    @Override
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      final ActivitySummaryDetails output = (ActivitySummaryDetails) objDtls;

      // Only output normal records (not canceled records)
      if (output.recordStatusCode.equals(curam.codetable.RECORDSTATUS.NORMAL)) {

        // put export line into output file
        stOutFile.print(
          processCalendarExportObj.processActivitySummaryDetails(output));
      }

      return true;
    }

  }

  // BEGIN, CR00351119, AC
  /**
   * To export activity details to output file in vCalendar format.
   *
   * @param exportDetails Contains activity owner, dates range and
   * export file path
   */
  // END, CR00351119
  @Override
  public void exportActivityDetails(CalendarExportDetails exportDetails)
    throws AppException, InformationalException {

    int checkSum = 0;

    // register the security implementation
    SecurityImplementationFactory.register();

    // validate key information
    if (exportDetails.userName.length() > 0) {
      checkSum++;
    }

    if (exportDetails.organisationID != 0) {
      checkSum++;
    }

    // there should be one owner provided
    if (checkSum == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCALENDAREXPORT.ERR_CALENDAREXPORT_XFV_NO_OWNER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (checkSum > kMaxNumberOfActivityOwners) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCALENDAREXPORT.ERR_CALENDAREXPORT_XFV_MANY_OWNERS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // check if start date is not provided
    if (exportDetails.startDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.GENERAL.ERR_GENERAL_FV_START_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 7);
    }

    // check if end date is not provided
    if (exportDetails.endDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.GENERAL.ERR_GENERAL_FV_END_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // check relation between start date and end date
    if (exportDetails.startDate.after(exportDetails.endDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERAL.ERR_GENERAL_XFV_START_DATE_END_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          14);
    }

    // open file
    if (exportDetails.exportFilePath.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCALENDAREXPORT.ERR_CALENDAREXPORT_FV_FILEPATH_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    try {

      stOutFile = new java.io.PrintStream(
        new java.io.FileOutputStream(exportDetails.exportFilePath));
    } catch (final java.io.FileNotFoundException e) {
      throw new curam.util.exception.AppRuntimeException(e);
    }

    if (stOutFile.checkError()) {
      stOutFile.close();
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCALENDAREXPORT.ERR_CALENDAREXPORT_FILEOPEN_FAILURE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // object to perform read all Activity records
    final SelectAllActivities selectAllActivitiesObj = new SelectAllActivities();

    // object called to perform all the searches
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();

    // mark calendar export beginning, product ID, version No

    stOutFile.print(
      kCalendarBeginString + CuramConst.gkNewLine + kProdIDString
      + kProductIDString + CuramConst.gkNewLine + kVersionString
      + CuramConst.gkNewLine);

    // set key for activity export
    final ActivityOwnerAndDateRangeKey activityOwnerAndDateRangeKey = new ActivityOwnerAndDateRangeKey();

    activityOwnerAndDateRangeKey.assign(exportDetails);

    // format startDateTime and endDateTime from input start and end
    // dates to perform query
    if (!exportDetails.startDate.isZero()) {
      activityOwnerAndDateRangeKey.startDateTime = exportDetails.startDate.getDateTime();

    }

    if (!exportDetails.endDate.isZero()) {
      // add one day
      activityOwnerAndDateRangeKey.endDateTime = exportDetails.endDate.addDays(1).getDateTime();

    }

    // select activities according to owner provided
    if (activityOwnerAndDateRangeKey.userName.length() > 0) {

      // BEGIN, CR00070184, NB
      // For user based search , dates are adjusted to user's time zone
      activityOwnerAndDateRangeKey.startDateTime = Date.getTimeZoneAdjustedDateTime(
        exportDetails.startDate, TransactionInfo.getUserTimeZone());
      activityOwnerAndDateRangeKey.endDateTime = Date.getTimeZoneAdjustedDateTime(
        exportDetails.endDate.addDays(1), TransactionInfo.getUserTimeZone());
      // END,CR00070184

      // export activities for user
      activityObj.searchUserActivitiesInDateRange(activityOwnerAndDateRangeKey,
        selectAllActivitiesObj);
      // export activities for organization of user
      activityObj.searchUserOrganisationActivitiesInDateRange(
        activityOwnerAndDateRangeKey, selectAllActivitiesObj);
    } else {

      // select activities according to organization provided
      if (activityOwnerAndDateRangeKey.organisationID != 0) {

        // BEGIN, CR00070184, NB
        // For organization based search , dates are adjusted to server's time
        // zone
        activityOwnerAndDateRangeKey.startDateTime = Date.getTimeZoneAdjustedDateTime(
          exportDetails.startDate, TransactionInfo.getServerTimeZone());
        activityOwnerAndDateRangeKey.endDateTime = Date.getTimeZoneAdjustedDateTime(
          exportDetails.endDate.addDays(1), TransactionInfo.getServerTimeZone());
        // END,CR00070184

        // export activities for organization
        activityObj.searchOrganisationActivitiesInDatesRange(
          activityOwnerAndDateRangeKey, selectAllActivitiesObj);
        // export activities for users of organization
        activityObj.searchOrganisationUsersActivitiesInDatesRange(
          activityOwnerAndDateRangeKey, selectAllActivitiesObj);
      }

    }

    // mark calendar export end

    stOutFile.print(kCalendarEndString + CuramConst.gkNewLine);

    // close file
    stOutFile.close();
  }

}
