/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.impl;

import com.google.inject.Inject;
import curam.codetable.BUSINESSSTATUS;
import curam.codetable.CASEDECISIONRESULTCODE;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTRELATIONSHIP;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.FINCOMPONENTTYPE;
import curam.codetable.PRODUCTCOVERPERIOD;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CachedProductDeliveryFactory;
import curam.core.fact.CachedProductDeliveryPatternInfoFactory;
import curam.core.fact.CachedProductFactory;
import curam.core.fact.CaseDecisionObjectiveFactory;
import curam.core.fact.CaseDeductionItemFCLinkFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.FinancialComponentRelationFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainCaseDecisionFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CachedProduct;
import curam.core.intf.CachedProductDelivery;
import curam.core.intf.CachedProductDeliveryPatternInfo;
import curam.core.intf.CaseDeductionItem;
import curam.core.intf.CaseDeductionItemFCLink;
import curam.core.intf.DeliveryMethod;
import curam.core.intf.FinancialComponent;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainFinancialComponent;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.struct.CaseNomineeCaseIDKey;
import curam.core.sl.entity.struct.CaseNomineeDtls;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetails;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetailsList;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.CaseNomineeObjectiveHistoryKey;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineEntity;
import curam.core.sl.intf.CaseNominee;
import curam.core.sl.struct.CaseNomineeDeliveryPatternDetailsList;
import curam.core.sl.struct.CaseNomineeDeliveryPatternKey;
import curam.core.sl.struct.CaseNomineeObjectiveHistoryDetailsList;
import curam.core.sl.struct.GetNomineeForObjectiveKey;
import curam.core.sl.struct.GetNomineeForObjectiveResult;
import curam.core.struct.CaseDecisionComponentDecisionIDKey;
import curam.core.struct.CaseDecisionObjectiveDtlsList;
import curam.core.struct.CaseDecisionSummaryList;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemDtlsList;
import curam.core.struct.CaseDeductionItemFCLinkDtls;
import curam.core.struct.CaseDeductionItemFCLinkDtlsList;
import curam.core.struct.CaseDeductionItemID;
import curam.core.struct.CaseDeductionItemKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDStatusBusStatusCaseEndDateLastPaidDate;
import curam.core.struct.Count;
import curam.core.struct.DeductionItemFinCompDetails;
import curam.core.struct.DeductionItemFinCompDetailsList;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.FCCoverDate;
import curam.core.struct.FCProcessingDtls;
import curam.core.struct.FCstatusCodeCaseID;
import curam.core.struct.FinComponentID;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.FinancialComponentID;
import curam.core.struct.FinancialComponentKey;
import curam.core.struct.FinancialComponentRelationDtls;
import curam.core.struct.GetLatestCoverPeriodToForCaseAndObjectiveKey;
import curam.core.struct.MaintainCaseDecisionCaseIDKey;
import curam.core.struct.PDPIByProdDelPatIDStatusAndDateKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Class to generate Financial Components for any Case Deduction Items
 * associated with a given case.
 */
public abstract class DeductionFCGeneration
    extends curam.core.base.DeductionFCGeneration {

  /**
   * AssessmentEngineEntity object.
   */
  @Inject
  AssessmentEngineEntity assessmentEngineEntity;

  /**
   * FinancialHooks object.
   */
  @Inject
  FinancialHooks financialHooks;

  /**
   * Constructor.
   */
  public DeductionFCGeneration() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Comparator to order the deductions by start date ascending.
   */
  public static class DeductionFCStartDateComparator
      implements Comparator<DeductionItemFinCompDetails> {

    public DeductionFCStartDateComparator() {

      super();
    }

    /**
     * Compare the two objects on start date.
     *
     * @param o1
     *          First object to be compared
     * @param o2
     *          Second object to be compared
     */
    @Override
    public int compare(final DeductionItemFinCompDetails o1,
        final DeductionItemFinCompDetails o2) {

      return o1.startDate.compareTo(o2.startDate);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method creates the financial component(s) required for any case
   * deduction item(s) associated with the given case. It also sets up a link
   * between the case deduction item(s) and the FCs generated from it.
   *
   * @param caseHeaderKey
   *          the ID of the case.
   */
  @Override
  public void createDeductionFCs(final CaseHeaderKey caseHeaderKey)
      throws AppException, InformationalException {

    // caseDeductionItemFCLink manipulation variables
    final CaseDeductionItemFCLink caseDeductionItemFCLinkObj = CaseDeductionItemFCLinkFactory
        .newInstance();
    final CaseDeductionItemFCLinkDtls caseDeductionItemFCLinkDtls = new CaseDeductionItemFCLinkDtls();

    // maintainFinancialComponent manipulation variables
    final MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory
        .newInstance();

    // uniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Get list of Deduction FCs
    final DeductionItemFinCompDetailsList deductionItemFCDtlsList = generateDeductionFCDetails(
        caseHeaderKey);

    for (int i = 0; i < deductionItemFCDtlsList.dtls.size(); i++) {

      // Add Deduction Item FC
      final FinComponentID deductionItemFinComponentID = maintainFinancialComponentObj
          .addDeductionItemFinComp(deductionItemFCDtlsList.dtls.item(i));

      // Set caseDeductionItemFCLinkDtls for insert
      caseDeductionItemFCLinkDtls.caseDeductionItemFCLinkID = uniqueIDObj
          .getNextID();
      caseDeductionItemFCLinkDtls.financialComponentID = deductionItemFinComponentID.finComponentID;
      caseDeductionItemFCLinkDtls.caseDeductionItemID = deductionItemFCDtlsList.dtls
          .item(i).caseDeductionItemID;

      // Insert caseDeductionItemFCLink
      caseDeductionItemFCLinkObj.insert(caseDeductionItemFCLinkDtls);

    } // end for i
  }

  // ___________________________________________________________________________
  /**
   * This method generates a list of financial component(s) for any case
   * deduction item(s) associated with the specified case. This generation
   * process takes into consideration all delivery patterns associated with the
   * nominees for whom the Deduction Items were created.
   *
   * @param caseHeaderKey
   *          the ID of the case.
   *
   * @return List of deduction financial components to be generated on the case.
   */
  @Override
  public DeductionItemFinCompDetailsList generateDeductionFCDetails(
      final CaseHeaderKey caseHeaderKey)
      throws AppException, InformationalException {

    // caseHeader manipulation variables
    final CaseHeaderDtls caseHeaderDtls;
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory
        .newInstance();

    // productDelivery manipulation variables
    final CachedProductDelivery cachedProductDeliveryObj = CachedProductDeliveryFactory
        .newInstance();
    final ProductDeliveryDtls productDeliveryDtls;
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // product manipulation variables
    final ProductKey productKey = new ProductKey();
    final ProductDtls productDtls;
    final CachedProduct cachedProductObj = CachedProductFactory.newInstance();

    // maintainFinancialComponent manipulation variables
    final MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory
        .newInstance();

    // caseDeductionItem manipulation variables
    final CaseDeductionItem caseDeductionItemObj = CaseDeductionItemFactory
        .newInstance();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;
    // BEGIN, CR00003850
    final CaseIDStatusBusStatusCaseEndDateLastPaidDate caseIDStatusBusStatusCaseEndDateLastPaidDate = new CaseIDStatusBusStatusCaseEndDateLastPaidDate();
    final DeductionItemFinCompDetailsList deductionItemFCDtlsList = new DeductionItemFinCompDetailsList();
    DeductionItemFinCompDetails deductionItemFCDtls;

    // Read caseHeader
    caseHeaderDtls = cachedCaseHeaderObj.read(caseHeaderKey);

    // Set key to read productDelivery
    productDeliveryKey.caseID = caseHeaderKey.caseID;
    productDeliveryDtls = cachedProductDeliveryObj.read(productDeliveryKey);

    // Set key to read product
    productKey.productID = productDeliveryDtls.productID;
    productDtls = cachedProductObj.read(productKey);

    // BEGIN, CR00283273, KH
    // Get all eligible objectives on the case
    final Set<String> objectives = new HashSet<>();

    final MaintainCaseDecisionCaseIDKey activeDecisionsKey = new MaintainCaseDecisionCaseIDKey();

    activeDecisionsKey.caseID = caseHeaderKey.caseID;

    final CaseDecisionSummaryList activeDecisionList = MaintainCaseDecisionFactory
        .newInstance().getActiveCaseDecisions(activeDecisionsKey);

    for (int i = 0; i < activeDecisionList.dtls.size(); i++) {

      if (activeDecisionList.dtls.item(i).resultCode
          .equals(CASEDECISIONRESULTCODE.ELIGIBLE)) {

        // Find all the objectives for this eligible decision
        final CaseDecisionComponentDecisionIDKey key = new CaseDecisionComponentDecisionIDKey();

        key.caseDecisionID = activeDecisionList.dtls.item(i).caseDecisionID;

        final CaseDecisionObjectiveDtlsList cdoDtlsList = CaseDecisionObjectiveFactory
            .newInstance().searchByCaseDecisionID(key);

        for (int j = 0; j < cdoDtlsList.dtls.size(); j++) {
          objectives.add(cdoDtlsList.dtls.item(j).objectiveID);
        } // end for j
      }
    } // end for i

    Date earliestFCCoverDate = Date.kZeroDate;

    final GetLatestCoverPeriodToForCaseAndObjectiveKey fcCaseID = new GetLatestCoverPeriodToForCaseAndObjectiveKey();

    fcCaseID.key.caseID = caseHeaderKey.caseID;

    // For each eligible objective on the case find the latest payment date.
    for (final String objective : objectives) {

      fcCaseID.key.rulesObjectiveID = objective;

      final FCCoverDate currentFCCoverDate = maintainFinancialComponentObj
          .getLatestCoverPeriodToForCaseAndObjective(fcCaseID);

      // If any component has not been paid then the earliest date should not be
      // set
      if (currentFCCoverDate.coverDate.isZero()) {
        earliestFCCoverDate = Date.kZeroDate;
        break;
      }

      /*
       * If the earliest date has not been set OR the earliest date and the
       * current date have both been set but the current date is earlier, then
       * set the earliest date to the current date
       */
      if (earliestFCCoverDate.isZero() || !earliestFCCoverDate.isZero()
          && currentFCCoverDate.coverDate.before(earliestFCCoverDate)) {

        earliestFCCoverDate = currentFCCoverDate.coverDate;
      }
    }

    final FCCoverDate fcCoverDate = new FCCoverDate();

    fcCoverDate.coverDate = earliestFCCoverDate;
    // END, CR00283273

    // BEGIN, CR00003850, CR00017151, KH
    // If the case has never been paid, set to the case start date
    if (fcCoverDate.coverDate.isZero()) {

      fcCoverDate.coverDate = caseHeaderDtls.startDate;
    }
    // END, CR00017151

    // Set key to read case deduction items
    caseIDStatusBusStatusCaseEndDateLastPaidDate.caseID = caseHeaderKey.caseID;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.status = RECORDSTATUS.NORMAL;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.businessStatus = BUSINESSSTATUS.ACTIVE;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.caseEndDate = caseHeaderDtls.expectedEndDate;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.caseLastPaidDate = fcCoverDate.coverDate;

    caseDeductionItemDtlsList = caseDeductionItemObj
        .searchByCaseIDStatusBusinessStatusStartDateEndDate(
            caseIDStatusBusStatusCaseEndDateLastPaidDate);
    // END, CR00003850

    // Fill out the CDI list for all relevant nominees
    caseDeductionItemDtlsList = getNomineesForDeductions(
        caseDeductionItemDtlsList);

    // BEGIN, CR00431540, CSH
    // Filter out any CDIs where the associated FCs should not be regenerated
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      final CaseDeductionItemFCLink caseDeductionItemFCLinkObj = CaseDeductionItemFCLinkFactory
          .newInstance();
      final curam.core.struct.CaseDeductionItem caseDeductionItem = new curam.core.struct.CaseDeductionItem();

      caseDeductionItem.caseDeductionItemID = caseDeductionItemDtlsList.dtls
          .item(i).caseDeductionItemID;

      // Read the Financial Components(s) associated with the Case Deduction
      // Item
      final CaseDeductionItemFCLinkDtlsList cdifcDtlsList = caseDeductionItemFCLinkObj
          .searchByCaseDeductionItem(caseDeductionItem);

      int countClosedFCs = 0;

      for (int j = 0; j < cdifcDtlsList.dtls.size(); j++) {

        // Check for Closed deduction financial components
        final FinancialComponent financialComponentObj = FinancialComponentFactory
            .newInstance();
        final FinancialComponentKey financialComponentKey = new FinancialComponentKey();

        financialComponentKey.financialCompID = cdifcDtlsList.dtls
            .item(j).financialComponentID;
        final FinancialComponentDtls financialComponentDtls = financialComponentObj
            .read(financialComponentKey);

        if (financialComponentDtls.statusCode
            .equals(FINCOMPONENTSTATUS.CLOSED_OUTOFDATE)) {
          countClosedFCs++;
        }
      }

      final boolean allFCcClosedInd = countClosedFCs == cdifcDtlsList.dtls
          .size();

      for (int k = 0; k < cdifcDtlsList.dtls.size(); k++) {

        // For each case deduction item, if any associated financial components
        // have been Closed, check if these have been realized into ILIs
        if (allFCcClosedInd) {

          // If the ILIs have been generated and the deduction end date has been
          // set, then filter these out to prevent them from being regenerated
          final InstructionLineItem instructionLineItemObj = InstructionLineItemFactory
              .newInstance();
          final FinancialComponentID fcID = new FinancialComponentID();

          fcID.financialCompID = cdifcDtlsList.dtls
              .item(k).financialComponentID;
          final Count iliCount = instructionLineItemObj
              .countByFinancialCompID(fcID);

          if (iliCount.numberOfRecords > 0) {

            if (!caseDeductionItemDtlsList.dtls.item(i).endDate.isZero()) {
              caseDeductionItemDtlsList.dtls.remove(i);
              i--;
              break;
            }
          }
        }
      } // end for k
    } // END, CR00431540

    // Loop through the remaining CDIs and create the financial components
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // BEGIN, CR00003905, KH
      // If the case has been paid, we only want CDIs which have no end date or
      // which end after the last paid to date of the case.
      if (fcCoverDate.coverDate.equals(caseHeaderDtls.startDate)
          || caseDeductionItemDtlsList.dtls.item(i).endDate.isZero()
          || caseDeductionItemDtlsList.dtls.item(i).endDate
              .after(fcCoverDate.coverDate)) {

        deductionItemFCDtls = new DeductionItemFinCompDetails();

        // Set common deduction FC details
        deductionItemFCDtls.adjustmentInd = false;
        deductionItemFCDtls.caseDecisionID = 0;
        deductionItemFCDtls.caseID = caseHeaderKey.caseID;
        deductionItemFCDtls.caseType = caseHeaderDtls.caseTypeCode;
        deductionItemFCDtls.componentCategory = FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM;
        deductionItemFCDtls.componentType = FINCOMPONENTTYPE.DEDUCTIONPAYMENT;
        deductionItemFCDtls.fundID = productDtls.fundID;
        deductionItemFCDtls.primaryClientID = caseHeaderDtls.concernRoleID;
        deductionItemFCDtls.productID = 0;
        // BEGIN, CR00074927, JI
        deductionItemFCDtls.inRespectOfID = caseHeaderDtls.concernRoleID;
        // END, CR00074927

        // Set CDI specific deduction FC details
        deductionItemFCDtls.amount = caseDeductionItemDtlsList.dtls
            .item(i).amount;
        deductionItemFCDtls.caseNomineeID = caseDeductionItemDtlsList.dtls
            .item(i).caseNomineeID;
        deductionItemFCDtls.concernRoleID = caseDeductionItemDtlsList.dtls
            .item(i).concernRoleID;
        deductionItemFCDtls.rate = caseDeductionItemDtlsList.dtls.item(i).rate;
        deductionItemFCDtls.rulesObjectiveID = caseDeductionItemDtlsList.dtls
            .item(i).rulesObjectiveID;

        // BEGIN, CR00003905, KH
        // If the case has been paid, any new deduction FCs created must start
        // after the last paid to date of the case.
        if (fcCoverDate.coverDate.equals(caseHeaderDtls.startDate)
            || caseDeductionItemDtlsList.dtls.item(i).startDate
                .after(fcCoverDate.coverDate)) {

          deductionItemFCDtls.startDate = caseDeductionItemDtlsList.dtls
              .item(i).startDate;

        } else { // Otherwise they will start the day after the last paid to
          // date

          deductionItemFCDtls.startDate = fcCoverDate.coverDate.addDays(1);
        }
        // END, CR00003905

        // Is the CDI end date set?
        if (caseDeductionItemDtlsList.dtls.item(i).endDate.isZero()) {

          // No, use expected end date from case
          deductionItemFCDtls.endDate = caseHeaderDtls.expectedEndDate;

        } else {

          // Yes, use CDI end date
          deductionItemFCDtls.endDate = caseDeductionItemDtlsList.dtls
              .item(i).endDate;
        }

        // Set up the nominee specific details
        setNomineeFCDetails(deductionItemFCDtls);

        // Set dueDate & nextProcessingDate
        // Is this an 'in arrears' cover period?
        if (deductionItemFCDtls.coverPeriodType
            .equals(PRODUCTCOVERPERIOD.ISSUEINARREARS)
            || deductionItemFCDtls.coverPeriodType
                .equals(PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET)) {

          deductionItemFCDtls.dueDate = new FrequencyPattern(
              deductionItemFCDtls.frequency)
                  .getNextOccurrence(deductionItemFCDtls.startDate);

        } else { // This is an 'in advance' cover period

          // If the start date is a product recurrence date (e.g. a Monday if
          // paying weekly) then getPrevOccurence() will return the previous
          // Monday. We don't want this, we want to keep the current date. To
          // solve this problem we will add a day to our simulation date (to
          // make it Tuesday). Now getPrevOccurence() returns the date we
          // need.
          deductionItemFCDtls.dueDate = new FrequencyPattern(
              deductionItemFCDtls.frequency)
                  .getPrevOccurrence(deductionItemFCDtls.startDate.addDays(1));
        }

        // financial component processing details
        final FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();

        fcProcessingDtls.frequencyPattern = deductionItemFCDtls.frequency;
        fcProcessingDtls.deliveryMethod = deductionItemFCDtls.nomineeDelivMethod;
        fcProcessingDtls.dueDate = deductionItemFCDtls.dueDate;
        fcProcessingDtls.coverPeriodOffset = deductionItemFCDtls.coverPeriodOffset;
        fcProcessingDtls.deliveryMethodOffset = deductionItemFCDtls.deliveryMethodOffset;
        fcProcessingDtls.coverPeriodType = deductionItemFCDtls.coverPeriodType;

        // Set next processing date
        maintainFinancialComponentObj.setNextProcessingDate(fcProcessingDtls);

        deductionItemFCDtls.nextProcessingDate = fcProcessingDtls.nextProcessingDate;

        // Set Case Deduction Item ID for use in link table
        deductionItemFCDtls.caseDeductionItemID = caseDeductionItemDtlsList.dtls
            .item(i).caseDeductionItemID;

        // Add FC to deductions list
        deductionItemFCDtlsList.dtls.addRef(deductionItemFCDtls);

      }
      // END, CR00003905

    }

    // Find the list of nominees associated with the deductions
    final DeductionItemFinCompDetailsList finalDeductionsList = new DeductionItemFinCompDetailsList();

    final Set<Long> nominees = getDeductionNominees(deductionItemFCDtlsList);

    for (final Long nominee : nominees) {

      // Now retrieve the patterns associated with the nominee - the nominee
      // may have different patterns specified in the future
      final CaseNomineeDeliveryPatternDetailsList patterns = getNomineeDeliveryPatterns(
          nominee);

      if (patterns.dtls.size() > 1) {

        for (int i = 0; i < deductionItemFCDtlsList.dtls.size(); i++) {

          final DeductionItemFinCompDetails deduction = deductionItemFCDtlsList.dtls
              .item(i);

          final DeductionItemFinCompDetailsList nomineeDeductionsPerPattern = new DeductionItemFinCompDetailsList();

          if (deductionItemFCDtlsList.dtls.item(i).caseNomineeID == nominee) {

            for (int j = 0; j < patterns.dtls.size(); j++) {

              // Filter out patterns completely in the past, or patterns that
              // are
              // in the future
              if (patterns.dtls.item(j).fromDate
                  .equals(patterns.dtls.item(j).toDate)
                  || !patterns.dtls.item(j).toDate.isZero()
                      && patterns.dtls.item(j).toDate
                          .before(deduction.startDate)
                  || !deduction.endDate.isZero()
                      && patterns.dtls.item(j).fromDate
                          .after(deduction.endDate)) {
                continue;
              }

              // The entire 'if' block here is essentially setting the deduction
              // start dates in line with the delivery pattern 'from' dates. Any
              // end dates, apart from the end date on the last record,
              // will be overwritten by the 'for' loop below. The end date on
              // the last record is taken from the deduction item itself
              if (patterns.dtls.item(j).fromDate.after(deduction.startDate)) {

                final DeductionItemFinCompDetails newDeduction = new DeductionItemFinCompDetails();

                newDeduction.assign(deduction);
                newDeduction.startDate = patterns.dtls.item(j).fromDate;

                setNomineeFCDetails(newDeduction);

                nomineeDeductionsPerPattern.dtls.addRef(newDeduction);

              } else {
                if (!patterns.dtls.item(j).toDate.isZero()) {

                  final DeductionItemFinCompDetails newDeduction = new DeductionItemFinCompDetails();

                  newDeduction.assign(deduction);
                  newDeduction.endDate = patterns.dtls.item(j).toDate;

                  setNomineeFCDetails(newDeduction);

                  nomineeDeductionsPerPattern.dtls.addRef(newDeduction);
                } else {
                  final DeductionItemFinCompDetails newDeduction = new DeductionItemFinCompDetails();

                  newDeduction.assign(deduction);

                  setNomineeFCDetails(newDeduction);

                  nomineeDeductionsPerPattern.dtls.addRef(newDeduction);
                }
              }
            }
          }

          setDeductionDates(nomineeDeductionsPerPattern);

          // Iterate through the deductions and set the end date on all bar
          // the last record. Once set, we should be left with a list of
          // contiguous records
          for (int k = 1; k < nomineeDeductionsPerPattern.dtls.size(); k++) {
            nomineeDeductionsPerPattern.dtls
                .item(k - 1).endDate = nomineeDeductionsPerPattern.dtls
                    .item(k).startDate.addDays(-1);
          }

          finalDeductionsList.dtls.addAll(nomineeDeductionsPerPattern.dtls);
        }
      } else {

        for (int k = 0; k < deductionItemFCDtlsList.dtls.size(); k++) {

          if (deductionItemFCDtlsList.dtls.item(k).caseNomineeID == nominee) {
            final DeductionItemFinCompDetails deduction = new DeductionItemFinCompDetails();
            deduction.assign(deductionItemFCDtlsList.dtls.item(k));
            finalDeductionsList.dtls.addRef(deduction);
          }
        }
      }
    }

    if (!finalDeductionsList.dtls.isEmpty()) {
      deductionItemFCDtlsList.dtls.clear();
      deductionItemFCDtlsList.dtls.addAll(finalDeductionsList.dtls);
    }

    return deductionItemFCDtlsList;
  }

  /**
   * Set the processing dates on the deductions financial components. That is,
   * the {@code dueDate} and {@code nextProcessingDate}.
   *
   * @param list
   *          List of deduction financial components
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  void setDeductionDates(final DeductionItemFinCompDetailsList list)
      throws AppException, InformationalException {

    // Firstly order the records by start date
    final DeductionFCStartDateComparator deductionComparator = new DeductionFCStartDateComparator();

    final ArrayList<DeductionItemFinCompDetails> deductionFCArrayList = new ArrayList<>();

    deductionFCArrayList.addAll(list.dtls);
    Collections.sort(deductionFCArrayList, deductionComparator);

    list.dtls.clear();

    for (int i = 0; i < deductionFCArrayList.size(); i++) {
      list.dtls.addRef(deductionFCArrayList.get(i));
    }

    // Now set the dueDate and nextProcessingDate
    for (int j = 0; j < list.dtls.size(); j++) {

      if (list.dtls.item(j).coverPeriodType
          .equals(PRODUCTCOVERPERIOD.ISSUEINARREARS)
          || list.dtls.item(j).coverPeriodType
              .equals(PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET)) {

        list.dtls.item(j).dueDate = new FrequencyPattern(
            list.dtls.item(j).frequency)
                .getNextOccurrence(list.dtls.item(j).startDate);

      } else { // This is an 'in advance' cover period

        list.dtls.item(j).dueDate = new FrequencyPattern(
            list.dtls.item(j).frequency)
                .getPrevOccurrence(list.dtls.item(j).startDate.addDays(1));
      }

      // financial component processing details
      final FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();

      fcProcessingDtls.frequencyPattern = list.dtls.item(j).frequency;
      fcProcessingDtls.deliveryMethod = list.dtls.item(j).nomineeDelivMethod;
      fcProcessingDtls.dueDate = list.dtls.item(j).dueDate;
      fcProcessingDtls.coverPeriodOffset = list.dtls.item(j).coverPeriodOffset;
      fcProcessingDtls.deliveryMethodOffset = list.dtls
          .item(j).deliveryMethodOffset;
      fcProcessingDtls.coverPeriodType = list.dtls.item(j).coverPeriodType;

      // Set next processing date
      MaintainFinancialComponentFactory.newInstance()
          .setNextProcessingDate(fcProcessingDtls);

      list.dtls
          .item(j).nextProcessingDate = fcProcessingDtls.nextProcessingDate;
    }
  }

  /**
   * Retrieve the list of delivery patterns associated with a case nominee.
   *
   * @param caseNomineeID
   *          Case nominee identifier
   *
   * @return List of case nominee product delivery patterns
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  CaseNomineeDeliveryPatternDetailsList getNomineeDeliveryPatterns(
      final long caseNomineeID) throws AppException, InformationalException {

    final CaseNomineeDeliveryPatternKey deliveryPatternKey = new CaseNomineeDeliveryPatternKey();
    deliveryPatternKey.caseNomineeID = caseNomineeID;

    return CaseNomineeFactory.newInstance()
        .listNomineeDeliveryPatternHistory(deliveryPatternKey);
  }

  /**
   * Find the set of nominees associated with the third party deductions.
   *
   * @param list
   *          List of deductions to be realized into financial components
   *
   * @return The set of nominees associated with the third party deductions
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  Set<Long> getDeductionNominees(final DeductionItemFinCompDetailsList list)
      throws AppException, InformationalException {

    final Set<Long> nominees = new HashSet<>();

    for (int i = 0; i < list.dtls.size(); i++) {

      // We're only interested in third party deductions
      if (list.dtls.item(i).rulesObjectiveID.trim().length() == 0) {
        nominees.add(list.dtls.item(i).caseNomineeID);
      }
    }

    return nominees;
  }

  // ___________________________________________________________________________
  /**
   * This method populates the nominee specific information required on the FC.
   *
   * @param deductionItemFCDtls
   *          The deduction FC details to be updated.
   */
  @Override
  protected void setNomineeFCDetails(
      final DeductionItemFinCompDetails deductionItemFCDtls)
      throws AppException, InformationalException {

    // caseNominee entity layer manipulation variables
    final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory
        .newInstance();
    final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    // caseNomineeProdDelPattern manipulation variables
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

    // deliveryMethod manipulation variables
    final DeliveryMethod deliveryMethodObj = DeliveryMethodFactory
        .newInstance();
    final DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();
    final DeliveryMethodDtls deliveryMethodDtls;

    // productDeliveryPatternInfo manipulation variables
    final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory
        .newInstance();
    final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
    final ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls;

    // BEGIN, CR00280098, AKr
    final Date effectiveDate;

    if (Date.getCurrentDate().after(deductionItemFCDtls.startDate)) {
      effectiveDate = Date.getCurrentDate();
    } else {
      effectiveDate = deductionItemFCDtls.startDate;
    }
    // END, CR00280098
    caseNomineeKey.caseNomineeID = deductionItemFCDtls.caseNomineeID;
    final CaseNomineeDtls caseNomineeDtls = caseNomineeObj.read(caseNomineeKey);

    deductionItemFCDtls.currencyType = caseNomineeDtls.currencyType;

    readEffectiveByDateKey.caseNomineeID = caseNomineeKey.caseNomineeID;
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
    // BEGIN, CR00280098, AKr
    readEffectiveByDateKey.effectiveDate = effectiveDate;
    // END, CR00280098

    // BEGIN, CR00211744, VM
    final CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = assessmentEngineEntity
        .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
    // END, CR00211744

    // Set up key to read ProductDeliveryPatternInfo
    pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
    pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00280098, AKr
    pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = effectiveDate;
    // END, CR00280098

    // Get the product delivery pattern info
    productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
        .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);

    // Set the FC delivery pattern details
    deductionItemFCDtls.frequency = productDeliveryPatternInfoDtls.deliveryFrequency;
    deductionItemFCDtls.coverPeriodOffset = productDeliveryPatternInfoDtls.offset;
    deductionItemFCDtls.coverPeriodType = productDeliveryPatternInfoDtls.coverPattern;

    // Set up key to read DeliveryMethod
    deliveryMethodKey.deliveryMethodID = productDeliveryPatternInfoDtls.deliveryMethodID;

    // Get the delivery method details
    deliveryMethodDtls = deliveryMethodObj.read(deliveryMethodKey);

    // Set the FC delivery method details
    deductionItemFCDtls.nomineeDelivMethod = deliveryMethodDtls.name;
    deductionItemFCDtls.deliveryMethodOffset = deliveryMethodDtls.offset;
  }

  // ___________________________________________________________________________
  /**
   * This method will determine the nominee(s) for each case deduction item
   * (CDI), adding additional CDIs as necessary where the deduction applies to
   * multiple nominees over its lifetime.
   *
   * @param caseDeductionItemDtlsList
   *          the initial list of case deduction items
   *
   * @return newCaseDeductionItemDtlsList the updated list of CDIs
   */
  @Override
  protected CaseDeductionItemDtlsList getNomineesForDeductions(
      final CaseDeductionItemDtlsList caseDeductionItemDtlsList)
      throws AppException, InformationalException {

    // Variable to hold the full list of case deduction items
    final CaseDeductionItemDtlsList newCaseDeductionItemDtlsList = new CaseDeductionItemDtlsList();

    // caseNominee service layer manipulation variables
    // BEGIN, CR00190939, GD
    final CaseNomineeObjectiveHistoryKey caseNomineeObjectiveHistoryKey = new CaseNomineeObjectiveHistoryKey();

    // END, CR00190939
    final CaseNominee caseNomineeSLObj = CaseNomineeFactory.newInstance();
    final GetNomineeForObjectiveKey getNomineeForObjectiveKey = new GetNomineeForObjectiveKey();

    // caseNominee entity layer manipulation variables
    final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory
        .newInstance();
    CaseNomineeForCaseDetailsList caseNomineeForCaseDetailsList = new CaseNomineeForCaseDetailsList();
    final CaseNomineeForCaseDetails caseNomineeForCaseDetails = new CaseNomineeForCaseDetails();
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

    // Loop through the original case deduction items
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // Get current CDI
      final CaseDeductionItemDtls currentCaseDeductionItemDtls = caseDeductionItemDtlsList.dtls
          .item(i);

      // Do we have a rules objective ID?
      if (currentCaseDeductionItemDtls.rulesObjectiveID.length() != 0) {

        // Set key to find nominee(s)
        getNomineeForObjectiveKey.caseID = currentCaseDeductionItemDtls.caseID;
        getNomineeForObjectiveKey.rulesObjectiveID = currentCaseDeductionItemDtls.rulesObjectiveID;
        getNomineeForObjectiveKey.concernRoleID = currentCaseDeductionItemDtls.concernRoleID;
        getNomineeForObjectiveKey.fromDate = currentCaseDeductionItemDtls.startDate;
        getNomineeForObjectiveKey.toDate = currentCaseDeductionItemDtls.endDate;

        // Get the Nominee(s) assigned for the period
        final GetNomineeForObjectiveResult getNomineeForObjectiveResult = caseNomineeSLObj
            .getNomineeForObjective(getNomineeForObjectiveKey);

        // For each assignment we will add a separate CDI
        for (int j = 0; j < getNomineeForObjectiveResult.getObjectiveDetailsList
            .size(); j++) {

          final CaseDeductionItemDtls newCaseDeductionItemDtls = new CaseDeductionItemDtls();

          newCaseDeductionItemDtls.assign(currentCaseDeductionItemDtls);
          newCaseDeductionItemDtls.caseNomineeID = getNomineeForObjectiveResult.getObjectiveDetailsList
              .item(j).caseNomineeID;
          newCaseDeductionItemDtls.startDate = getNomineeForObjectiveResult.getObjectiveDetailsList
              .item(j).fromDate;
          newCaseDeductionItemDtls.endDate = getNomineeForObjectiveResult.getObjectiveDetailsList
              .item(j).toDate;

          newCaseDeductionItemDtlsList.dtls.addRef(newCaseDeductionItemDtls);

        } // end for j

      } else {

        // BEGIN, CR00002218, KH
        // Clear list for re-use
        caseNomineeForCaseDetailsList.dtls.clear();
        // END, CR00002218

        // Do we have a case nominee ID?
        if (currentCaseDeductionItemDtls.caseNomineeID != 0) {

          // Add current nominee to nominee list
          caseNomineeForCaseDetails.caseNomineeID = currentCaseDeductionItemDtls.caseNomineeID;

          caseNomineeForCaseDetailsList.dtls.addRef(caseNomineeForCaseDetails);

        } else {

          // Add all nominees to nominee list
          caseNomineeCaseIDKey.caseID = currentCaseDeductionItemDtls.caseID;
          caseNomineeForCaseDetailsList = caseNomineeObj
              .searchByCaseID(caseNomineeCaseIDKey);
        }

        // Loop through all nominees in list
        for (int j = 0; j < caseNomineeForCaseDetailsList.dtls.size(); j++) {

          // BEGIN, CR00190939, GD
          // Set key to find nominee component history
          caseNomineeObjectiveHistoryKey.caseNomineeID = caseNomineeForCaseDetailsList.dtls
              .item(j).caseNomineeID;
          caseNomineeObjectiveHistoryKey.statusCode = RECORDSTATUS.DEFAULTCODE;

          // Get the nominee history
          final CaseNomineeObjectiveHistoryDetailsList caseNomineeObjectiveHistoryDetailsList = caseNomineeSLObj
              .listCaseNomineeObjectiveHistory(caseNomineeObjectiveHistoryKey);

          // For each assignment we will add a separate CDI
          for (int k = 0; k < caseNomineeObjectiveHistoryDetailsList.dtls
              .size(); k++) {

            // BEGIN, CR00287427, KH
            // if this assignment ends before the deduction starts we should
            // skip it
            if (!caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate
                .isZero()
                && caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate
                    .before(currentCaseDeductionItemDtls.startDate)) {
              continue; // skip this assignment
            }
            // END, CR00287427

            // Variable to hold new CDI details
            final CaseDeductionItemDtls newCaseDeductionItemDtls = new CaseDeductionItemDtls();

            // Copy over the default details and the nominee ID
            newCaseDeductionItemDtls.assign(currentCaseDeductionItemDtls);
            newCaseDeductionItemDtls.caseNomineeID = caseNomineeForCaseDetailsList.dtls
                .item(j).caseNomineeID;

            // Only want assignments that are valid
            if (!caseNomineeObjectiveHistoryDetailsList.dtls.item(k).fromDate
                .isZero()) {

              // Set start and end dates using the component assignment info

              // BEGIN, CR00287427, KH
              /*
               * Only change the deduction FC start date if it is earlier than
               * the assignment from date.
               */
              if (newCaseDeductionItemDtls.startDate
                  .before(caseNomineeObjectiveHistoryDetailsList.dtls
                      .item(k).fromDate)) {
                newCaseDeductionItemDtls.startDate = caseNomineeObjectiveHistoryDetailsList.dtls
                    .item(k).fromDate;
              }

              /*
               * Only change the deduction FC end date if it is later than the
               * assignment to date (and the assignment to date is set).
               */
              if (!caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate
                  .isZero()
                  && newCaseDeductionItemDtls.endDate
                      .after(caseNomineeObjectiveHistoryDetailsList.dtls
                          .item(k).toDate)) {
                newCaseDeductionItemDtls.endDate = caseNomineeObjectiveHistoryDetailsList.dtls
                    .item(k).toDate;
              }
              // END, CR00287427

              // Add new CDI to list
              newCaseDeductionItemDtlsList.dtls
                  .addRef(newCaseDeductionItemDtls);

            } else if (caseNomineeObjectiveHistoryDetailsList.dtls
                .item(k).fromCaseStartDateInd) {
              // END, CR00190939
              // In this situation we are dealing with the default nominee.
              // Since we don't have a specific component to deduct from,
              // we only want one CDI from the deduction start date.

              // Add new CDI to list
              newCaseDeductionItemDtlsList.dtls
                  .addRef(newCaseDeductionItemDtls);

              break; // break out of k loop
            }
          } // end for k
        } // end for j
      }
    } // end for i

    // BEGIN, CR00037209, KH
    // We need to consolidate any overlapping CDI which are for the same nominee
    // and which have been generated from the same original case deduction item

    // Variable to hold the consolidated list of case deduction items
    final CaseDeductionItemDtlsList consolidatedCDIList = new CaseDeductionItemDtlsList();

    // Loop through the new case deduction items
    for (int i = 0; i < newCaseDeductionItemDtlsList.dtls.size(); i++) {

      // Get current CDI
      final CaseDeductionItemDtls currentCaseDeductionItemDtls = newCaseDeductionItemDtlsList.dtls
          .item(i);

      // This indicates that it is a unique CDI
      boolean uniqueCDI = true;

      // Check each entry in the consolidated CDI list
      for (int j = 0; j < consolidatedCDIList.dtls.size(); j++) {

        // Are the 2 new CDIs from the same original CDI (and for the same
        // nominee)?
        if (consolidatedCDIList.dtls.item(
            j).caseDeductionItemID == currentCaseDeductionItemDtls.caseDeductionItemID
            && consolidatedCDIList.dtls.item(
                j).caseNomineeID == currentCaseDeductionItemDtls.caseNomineeID) {

          // Yes, it's not unique. We won't add this CDI to our filtered list
          uniqueCDI = false;

          // Instead, we will extend the dates (if necessary)
          if (currentCaseDeductionItemDtls.startDate
              .before(consolidatedCDIList.dtls.item(j).startDate)) {

            consolidatedCDIList.dtls
                .item(j).startDate = currentCaseDeductionItemDtls.startDate;
          }

          // If the CDI end date is a 'zero date' this is the equivalent of
          // the case end date and therefore cannot be extended further
          if (!consolidatedCDIList.dtls.item(j).endDate.equals(Date.kZeroDate)
              && (currentCaseDeductionItemDtls.endDate.equals(Date.kZeroDate)
                  || currentCaseDeductionItemDtls.endDate
                      .after(consolidatedCDIList.dtls.item(j).endDate))) {

            consolidatedCDIList.dtls
                .item(j).endDate = currentCaseDeductionItemDtls.endDate;
          }

          break; // for j
        }
      } // end for j

      // Have we found a unique CDI?
      if (uniqueCDI) {

        // Yes, so add it to our filtered list
        consolidatedCDIList.dtls.addRef(currentCaseDeductionItemDtls);
      }
    } // end for i

    return consolidatedCDIList;
    // END, CR00037209
  }

  // BEGIN, CR00369134, KRK
  /**
   * Generates the financial component details for a case deduction item
   * associated with the given case.
   *
   * @param caseDeductionItemID
   *          The deduction ID of the case.
   *
   * @return DeductionItemFinCompDetails The details of the deduction FCs.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DeductionItemFinCompDetails getDeductionFCDetails(
      final CaseDeductionItemID caseDeductionItemID)
      throws AppException, InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final DeductionItemFinCompDetails deductionItemFCDtls = new DeductionItemFinCompDetails();
    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = caseDeductionItemID.caseDeductionItemID;

    final CaseDeductionItemDtls caseDeductionItemDtls = CaseDeductionItemFactory
        .newInstance().read(caseDeductionItemKey);

    caseHeaderKey.caseID = caseDeductionItemDtls.caseID;

    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = caseHeaderKey.caseID;
    final ProductDeliveryDtls productDeliveryDtls = CachedProductDeliveryFactory
        .newInstance().read(productDeliveryKey);

    final ProductKey productKey = new ProductKey();

    productKey.productID = productDeliveryDtls.productID;

    final ProductDtls productDtls = CachedProductFactory.newInstance()
        .read(productKey);

    final CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance()
        .read(caseHeaderKey);

    deductionItemFCDtls.adjustmentInd = false;
    deductionItemFCDtls.caseDecisionID = 0;
    deductionItemFCDtls.caseID = caseDeductionItemDtls.caseID;
    deductionItemFCDtls.caseType = caseHeaderDtls.caseTypeCode;
    deductionItemFCDtls.componentCategory = FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM;
    deductionItemFCDtls.componentType = FINCOMPONENTTYPE.DEDUCTIONPAYMENT;
    deductionItemFCDtls.fundID = productDtls.fundID;
    deductionItemFCDtls.primaryClientID = caseHeaderDtls.concernRoleID;
    deductionItemFCDtls.productID = productDtls.productID;
    deductionItemFCDtls.inRespectOfID = caseHeaderDtls.concernRoleID;
    deductionItemFCDtls.amount = caseDeductionItemDtls.amount;
    deductionItemFCDtls.caseNomineeID = caseDeductionItemDtls.caseNomineeID;
    deductionItemFCDtls.concernRoleID = caseDeductionItemDtls.concernRoleID;
    deductionItemFCDtls.rate = caseDeductionItemDtls.rate;
    deductionItemFCDtls.rulesObjectiveID = caseDeductionItemDtls.rulesObjectiveID;
    deductionItemFCDtls.startDate = caseDeductionItemDtls.startDate;
    deductionItemFCDtls.endDate = caseDeductionItemDtls.endDate;

    setNomineeFCDetails(deductionItemFCDtls);

    if (deductionItemFCDtls.coverPeriodType
        .equals(curam.codetable.PRODUCTCOVERPERIOD.ISSUEINARREARS)
        || deductionItemFCDtls.coverPeriodType.equals(
            curam.codetable.PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET)) {

      deductionItemFCDtls.dueDate = new curam.util.type.FrequencyPattern(
          deductionItemFCDtls.frequency)
              .getNextOccurrence(deductionItemFCDtls.startDate);

    } else {
      deductionItemFCDtls.dueDate = new curam.util.type.FrequencyPattern(
          deductionItemFCDtls.frequency)
              .getPrevOccurrence(deductionItemFCDtls.startDate.addDays(1));
    }

    final FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();

    fcProcessingDtls.frequencyPattern = deductionItemFCDtls.frequency;
    fcProcessingDtls.deliveryMethod = deductionItemFCDtls.nomineeDelivMethod;
    fcProcessingDtls.dueDate = deductionItemFCDtls.dueDate;
    fcProcessingDtls.coverPeriodOffset = deductionItemFCDtls.coverPeriodOffset;
    fcProcessingDtls.deliveryMethodOffset = deductionItemFCDtls.deliveryMethodOffset;
    fcProcessingDtls.coverPeriodType = deductionItemFCDtls.coverPeriodType;

    MaintainFinancialComponentFactory.newInstance()
        .setNextProcessingDate(fcProcessingDtls);

    deductionItemFCDtls.nextProcessingDate = fcProcessingDtls.nextProcessingDate;

    deductionItemFCDtls.caseDeductionItemID = caseDeductionItemDtls.caseDeductionItemID;

    return deductionItemFCDtls;
  }
  // END, CR00369134

  /**
   * {@inheritDoc}.
   */
  @Override
  public void createDeductionFCForStandaloneUnderpayment(
      final CaseHeaderKey caseHeaderKey)
      throws AppException, InformationalException {

    final CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance()
        .read(caseHeaderKey);

    // Set key to read Product Delivery entity
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    productDeliveryKey.caseID = caseHeaderKey.caseID;
    final ProductDeliveryDtls productDeliveryDtls = CachedProductDeliveryFactory
        .newInstance().read(productDeliveryKey);

    // Set key to read Product entity
    final ProductKey productKey = new ProductKey();
    productKey.productID = productDeliveryDtls.productID;

    final ProductDtls productDtls = CachedProductFactory.newInstance()
        .read(productKey);

    // MaintainFinancialComponent manipulation variables
    final MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory
        .newInstance();

    // CaseDeductionItem entity manipulation variables
    final CaseDeductionItem caseDeductionItemObj = CaseDeductionItemFactory
        .newInstance();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    // Get all eligible objectives on the case
    final Set<String> objectives = new HashSet<>();

    final CaseIDStatusBusStatusCaseEndDateLastPaidDate cdiRMKey = new CaseIDStatusBusStatusCaseEndDateLastPaidDate();

    final MaintainCaseDecisionCaseIDKey activeDecisionsKey = new MaintainCaseDecisionCaseIDKey();

    activeDecisionsKey.caseID = caseHeaderKey.caseID;

    final CaseDecisionSummaryList activeDecisionList = MaintainCaseDecisionFactory
        .newInstance().getActiveCaseDecisions(activeDecisionsKey);

    for (int i = 0; i < activeDecisionList.dtls.size(); i++) {

      if (activeDecisionList.dtls.item(i).resultCode
          .equals(CASEDECISIONRESULTCODE.ELIGIBLE)) {

        // Find all the objectives for this eligible decision
        final CaseDecisionComponentDecisionIDKey key = new CaseDecisionComponentDecisionIDKey();

        key.caseDecisionID = activeDecisionList.dtls.item(i).caseDecisionID;

        final CaseDecisionObjectiveDtlsList cdoDtlsList = CaseDecisionObjectiveFactory
            .newInstance().searchByCaseDecisionID(key);

        for (int j = 0; j < cdoDtlsList.dtls.size(); j++) {
          objectives.add(cdoDtlsList.dtls.item(j).objectiveID);
        } // end for j
      }
    } // end for i

    Date earliestFCCoverDate = Date.kZeroDate;

    final GetLatestCoverPeriodToForCaseAndObjectiveKey fcCaseID = new GetLatestCoverPeriodToForCaseAndObjectiveKey();

    fcCaseID.key.caseID = caseHeaderKey.caseID;

    // For each eligible objective on the case find the latest payment date.
    for (final String objective : objectives) {

      fcCaseID.key.rulesObjectiveID = objective;

      final FCCoverDate currentFCCoverDate = maintainFinancialComponentObj
          .getLatestCoverPeriodToForCaseAndObjective(fcCaseID);

      // If any component has not been paid then the earliest date should not be
      // set
      if (currentFCCoverDate.coverDate.isZero()) {
        earliestFCCoverDate = Date.kZeroDate;
        break;
      }

      /*
       * If the earliest date has not been set OR the earliest date and the
       * current date have both been set but the current date is earlier, then
       * set the earliest date to the current date
       */
      if (earliestFCCoverDate.isZero() || !earliestFCCoverDate.isZero()
          && currentFCCoverDate.coverDate.before(earliestFCCoverDate)) {

        earliestFCCoverDate = currentFCCoverDate.coverDate;
      }
    }

    final FCCoverDate fcCoverDate = new FCCoverDate();
    fcCoverDate.coverDate = earliestFCCoverDate;
    // END, CR00283273

    // If the case has never been paid, set to the case start date
    if (fcCoverDate.coverDate.isZero()) {

      fcCoverDate.coverDate = caseHeaderDtls.startDate;
    }

    // Set key to read case deduction items
    cdiRMKey.caseID = caseHeaderKey.caseID;
    cdiRMKey.status = RECORDSTATUS.NORMAL;
    cdiRMKey.businessStatus = BUSINESSSTATUS.ACTIVE;
    cdiRMKey.caseEndDate = caseHeaderDtls.expectedEndDate;
    cdiRMKey.caseLastPaidDate = fcCoverDate.coverDate;

    caseDeductionItemDtlsList = caseDeductionItemObj
        .searchByCaseIDStatusBusinessStatusStartDateEndDate(cdiRMKey);

    // Fill out the CDI list for all relevant nominees
    caseDeductionItemDtlsList = getNomineesForDeductions(
        caseDeductionItemDtlsList);

    // Iterate over the CDIs to determine if we need to create a discrete
    // deduction FC to offset the underpayment
    final Map<Long, DeductionItemFinCompDetailsList> fcMap = new HashMap<>();

    if (underpaymentFCExistsOnCase(caseHeaderKey)) {

      for (int j = 0; j < caseDeductionItemDtlsList.dtls.size(); j++) {

        final boolean createDeductionFCInd = financialHooks
            .deductFromStandaloneUnderpayment(
                caseDeductionItemDtlsList.dtls.item(j));

        if (createDeductionFCInd) {

          final FinancialComponentDtls rbuFCDtls = getStandaloneUnderpaymentFC(
              caseDeductionItemDtlsList.dtls.item(j));

          if (rbuFCDtls != null) {
            final Date startDate = rbuFCDtls.startDate;
            final Date endDate = rbuFCDtls.endDate;

            final DeductionItemFinCompDetails rbuCaseDeductionFCDtls = new DeductionItemFinCompDetails();

            // Set common deduction FC details
            rbuCaseDeductionFCDtls.adjustmentInd = false;
            rbuCaseDeductionFCDtls.caseDecisionID = 0;
            rbuCaseDeductionFCDtls.caseID = caseHeaderKey.caseID;
            rbuCaseDeductionFCDtls.caseType = caseHeaderDtls.caseTypeCode;
            rbuCaseDeductionFCDtls.componentCategory = FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM;
            rbuCaseDeductionFCDtls.componentType = FINCOMPONENTTYPE.DEDUCTIONPAYMENT;
            rbuCaseDeductionFCDtls.fundID = productDtls.fundID;
            rbuCaseDeductionFCDtls.primaryClientID = caseHeaderDtls.concernRoleID;
            rbuCaseDeductionFCDtls.productID = 0;
            rbuCaseDeductionFCDtls.inRespectOfID = caseHeaderDtls.concernRoleID;

            // Set CDI specific deduction FC details
            rbuCaseDeductionFCDtls.amount = caseDeductionItemDtlsList.dtls
                .item(j).amount;
            rbuCaseDeductionFCDtls.caseNomineeID = caseDeductionItemDtlsList.dtls
                .item(j).caseNomineeID;
            rbuCaseDeductionFCDtls.concernRoleID = caseDeductionItemDtlsList.dtls
                .item(j).concernRoleID;
            rbuCaseDeductionFCDtls.rate = caseDeductionItemDtlsList.dtls
                .item(j).rate;

            if (caseDeductionItemDtlsList.dtls.item(j).rulesObjectiveID
                .length() > 0) {
              rbuCaseDeductionFCDtls.rulesObjectiveID = rbuFCDtls.rulesObjectiveID;
            }

            rbuCaseDeductionFCDtls.startDate = startDate;
            rbuCaseDeductionFCDtls.endDate = endDate;

            // Set up the nominee specific details
            setNomineeFCDetails(rbuCaseDeductionFCDtls);

            // We need to overwrite whatever frequency that was set to
            // be once-off
            rbuCaseDeductionFCDtls.frequency = FrequencyPattern.kZeroFrequencyPattern
                .toString();

            // For convenience, set the dueDate to be equal to the startDate
            // of the RBU financial component. The RBU will be in the past,
            // so this should be okay to do as we really want the underpayment
            // to be issued as soon as possible
            rbuCaseDeductionFCDtls.dueDate = rbuFCDtls.dueDate;
            rbuCaseDeductionFCDtls.nextProcessingDate = rbuFCDtls.nextProcessingDate;

            // Set Case Deduction Item ID for use in link table
            rbuCaseDeductionFCDtls.caseDeductionItemID = caseDeductionItemDtlsList.dtls
                .item(j).caseDeductionItemID;

            DeductionItemFinCompDetailsList list = fcMap
                .get(rbuFCDtls.financialCompID);

            if (list == null) {
              list = new DeductionItemFinCompDetailsList();
              list.dtls.addRef(rbuCaseDeductionFCDtls);
              fcMap.put(rbuFCDtls.financialCompID, list);
            } else {
              list.dtls.addRef(rbuCaseDeductionFCDtls);
              fcMap.put(rbuFCDtls.financialCompID, list);
            }

          }

        }

      }

    }

    if (!fcMap.isEmpty()) {

      final CaseDeductionItemFCLinkDtls caseDeductionItemFCLinkDtls = new CaseDeductionItemFCLinkDtls();

      final Iterator<Long> itr = fcMap.keySet().iterator();

      while (itr.hasNext()) {

        final long rbuFinCompID = itr.next();

        final DeductionItemFinCompDetailsList deductionItemFCList = fcMap
            .get(rbuFinCompID);

        for (int i = 0; i < deductionItemFCList.dtls.size(); i++) {

          final FinComponentID deductionItemFinComponentID = maintainFinancialComponentObj
              .addDeductionItemFinComp(deductionItemFCList.dtls.item(i));

          caseDeductionItemFCLinkDtls.caseDeductionItemFCLinkID = curam.core.fact.UniqueIDFactory
              .newInstance().getNextID();
          caseDeductionItemFCLinkDtls.financialComponentID = deductionItemFinComponentID.finComponentID;
          caseDeductionItemFCLinkDtls.caseDeductionItemID = deductionItemFCList.dtls
              .item(i).caseDeductionItemID;

          CaseDeductionItemFCLinkFactory.newInstance()
              .insert(caseDeductionItemFCLinkDtls);

          // Also create a link between the RBU FC and the associated Deduction
          // FC
          final FinancialComponentRelationDtls fcRelationDtls = new FinancialComponentRelationDtls();

          fcRelationDtls.financialCompRelationID = curam.core.fact.UniqueIDFactory
              .newInstance().getNextID();
          fcRelationDtls.startDate = deductionItemFCList.dtls.item(i).startDate;
          fcRelationDtls.endDate = deductionItemFCList.dtls.item(i).endDate;
          fcRelationDtls.financialCompID = rbuFinCompID;
          fcRelationDtls.relatedFcID = deductionItemFinComponentID.finComponentID;
          fcRelationDtls.statusCode = RECORDSTATUS.NORMAL;
          fcRelationDtls.typeCode = FINCOMPONENTRELATIONSHIP.CASEDEDUCTIONITEM;

          FinancialComponentRelationFactory.newInstance()
              .insert(fcRelationDtls);
        }

      }

    }

  }

  /**
   * Get the standalone underpayment financial component.
   *
   * @param dtls
   *          Case Deduction Item
   *
   * @return Financial Component entity details for the underpayment
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  FinancialComponentDtls getStandaloneUnderpaymentFC(
      final CaseDeductionItemDtls dtls)
      throws AppException, InformationalException {

    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();
    fcStatusCodeCaseID.caseID = dtls.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    final FinancialComponentDtlsList fcList = FinancialComponentFactory
        .newInstance().searchByStatusCaseID(fcStatusCodeCaseID);

    for (final FinancialComponentDtls fc : fcList.dtls) {

      if (fc.typeCode.equals(FINCOMPONENTTYPE.BENEFITUNDERPAYMENT)
          && (dtls.caseNomineeID != 0
              && isEqual(dtls.caseNomineeID, fc.caseNomineeID)
              || dtls.rulesObjectiveID.length() > 0)) {
        return fc;
      }
    }

    return null;
  }

  /**
   * Determines if two case nominee identifiers represent the same participant.
   *
   * @param cdiCaseNomineeID
   *          Case Deduction Item case nominee identifier
   * @param fcCaseNomineeID
   *          Financial Component case nominee identifier
   *
   * @return {@code true} if the two case nominee identifiers represent the same
   *         participant, otherwise {@code false}
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  boolean isEqual(final long cdiCaseNomineeID, final long fcCaseNomineeID)
      throws AppException, InformationalException {

    // Return true if the identifiers are the same
    if (cdiCaseNomineeID == fcCaseNomineeID) {
      return true;
    }

    // If they're not the same, the could still be the same concern
    // Get the concernRoleID for the deduction
    final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();
    caseNomineeKey.caseNomineeID = cdiCaseNomineeID;

    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = curam.core.sl.entity.fact.CaseNomineeFactory
        .newInstance().read(caseNomineeKey).caseParticipantRoleID;

    final long cdiConcernRoleID = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance().read(caseParticipantRoleKey).participantRoleID;

    // Get the concernRoleID for the fc
    caseNomineeKey.caseNomineeID = fcCaseNomineeID;

    caseParticipantRoleKey.caseParticipantRoleID = curam.core.sl.entity.fact.CaseNomineeFactory
        .newInstance().read(caseNomineeKey).caseParticipantRoleID;

    final long fcConcernRoleID = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance().read(caseParticipantRoleKey).participantRoleID;

    return cdiConcernRoleID == fcConcernRoleID;
  }

  /**
   * Determines if an underpayment (RBU) financial component exists on the
   * original product delivery.
   *
   * @param key
   *          CaseHeader entity key
   *
   * @return {@code true} if an RBU financial component exists on the product
   *         delivery, otherwise {@code false}
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  boolean underpaymentFCExistsOnCase(final CaseHeaderKey key)
      throws AppException, InformationalException {

    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();
    fcStatusCodeCaseID.caseID = key.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    final FinancialComponentDtlsList fcList = FinancialComponentFactory
        .newInstance().searchByStatusCaseID(fcStatusCodeCaseID);

    for (final FinancialComponentDtls fc : fcList.dtls) {
      if (fc.typeCode.equals(FINCOMPONENTTYPE.BENEFITUNDERPAYMENT)) {
        return true;
      }
    }

    return false;
  }

}
