/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.CASECATEGORY;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLEALTERNATEID;
import curam.codetable.CONCERNROLESEARCHALTERNATEID;
import curam.codetable.INVESTIGATECONFIGTYPE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.TERMOCCURS;
import curam.codetable.TERMTYPE;
import curam.core.fact.AssessmentConfigurationFactory;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductFactory;
import curam.core.fact.SearchServiceFactory;
import curam.core.impl.util.CuramDocToResultStruct;
import curam.core.intf.Product;
import curam.core.sl.entity.fact.ResolutionConfigurationFactory;
import curam.core.sl.entity.fact.ScreeningConfigurationFactory;
import curam.core.sl.entity.intf.ResolutionConfiguration;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.ResolutionConfigurationDtls;
import curam.core.sl.entity.struct.ResolutionConfigurationKey;
import curam.core.sl.entity.struct.ScreeningConfigurationDtls;
import curam.core.sl.entity.struct.ScreeningConfigurationDtlsList;
import curam.core.sl.entity.struct.ScreeningNameAndStatus;
import curam.core.sl.fact.IndexParticipantSearchFactory;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.infrastructure.impl.IndexSearchConst;
import curam.core.sl.intf.IndexParticipantSearch;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.sl.struct.TextFieldDetails;
import curam.core.struct.AssessmentConfigurationType;
import curam.core.struct.AssessmentConfigurationTypeDtls;
import curam.core.struct.AssessmentConfigurationTypeDtlsList;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSearchCriteria;
import curam.core.struct.CaseSearchCriteria1;
import curam.core.struct.CaseSearchDetails;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSearchList;
import curam.core.struct.CaseSearchList1;
import curam.core.struct.ConcernRoleAlternateIDDtlsStruct1;
import curam.core.struct.ConcernRoleAlternateIDDtlsStruct1List;
import curam.core.struct.ConcernRoleAlternateIDKey1;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CuramDocument;
import curam.core.struct.CuramField;
import curam.core.struct.CuramQuery;
import curam.core.struct.CuramTerm;
import curam.core.struct.InvestigationSearchCriteria;
import curam.core.struct.InvestigationSearchDetails;
import curam.core.struct.InvestigationSearchDetailsList;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductNameStructRef;
import curam.core.struct.SearchServerResults;
import curam.core.struct.SearchServiceKey;
import curam.message.GENERALSEARCH;
import curam.serviceplans.sl.entity.fact.ServicePlanFactory;
import curam.serviceplans.sl.entity.intf.ServicePlan;
import curam.serviceplans.sl.entity.struct.ServicePlanIDDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeAndStatusKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Searches the lucene index using details supplied by the caller and returns
 * any cases that match the criteria.
 */
public abstract class IndexCaseSearch extends curam.core.base.IndexCaseSearch {

  // A local dictionary that defines how to map from the output details of
  // the search to the result structure for the caller
  protected final static HashMap<String, String> dictionary = new HashMap<String, String>();

  // Initialized in a static initializer as it will never change once created.
  static {
    dictionary.put(IndexSearchConst.kStatus, IndexSearchConst.kStatusCode);
    dictionary.put(IndexSearchConst.kProductType,
      IndexSearchConst.kProductTypeCode);
    dictionary.put(IndexSearchConst.kSubtype,
      IndexSearchConst.kInvestigationSubtype);
  }

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * @param caseSearchCriteria data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} This method has
   * been deprecated to introduce new case search enhancements.
   *
   * Performs a lucene index search for case using the specified search
   * criteria.
   */
  @Deprecated
  @Override
  public CaseSearchList search(final CaseSearchCriteria caseSearchCriteria)
    throws AppException, InformationalException {

    // BEGIN, CR00395267, JMA
    CaseSearchList result = new CaseSearchList();
    CuramQuery curamQuery = new CuramQuery();
    final SearchServiceKey searchServiceKey = new SearchServiceKey();
    final LuceneHelper luceneHelper = new LuceneHelper();

    // If an alternate id has been specified we should read the concern role
    // details
    // from the data base to retrieve the concern role id to search the index
    if (caseSearchCriteria.primaryAlternateID.length() != 0) {

      final ConcernRoleAlternateIDKey1 concernRoleAlternateIDKey1 = new ConcernRoleAlternateIDKey1();

      concernRoleAlternateIDKey1.alternateID = caseSearchCriteria.primaryAlternateID;
      // BEGIN, CR00393706, JMA
      final curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = ConcernRoleAlternateIDFactory.newInstance();
      final ConcernRoleAlternateIDDtlsStruct1List concernRoleAlternateIDDtlsStruct1List = concernRoleAlternateIDObj.searchByAlternateID(
        concernRoleAlternateIDKey1);

      if (concernRoleAlternateIDDtlsStruct1List.dtls.size() == 0) {
        return result;
      } else {

        final CaseSearchList fullResult = new CaseSearchList();

        for (final ConcernRoleAlternateIDDtlsStruct1 concernRoleAlternateIDDtlsStruct1 : concernRoleAlternateIDDtlsStruct1List.dtls) {

          result = new CaseSearchList();
          curamQuery = new CuramQuery();

          addTermIfExists(
            luceneHelper.createStandardTerm(IndexSearchConst.kConcernRoleID,
            Long.toString(concernRoleAlternateIDDtlsStruct1.concernRoleID),
            false),
            curamQuery);

          // If both the start and end dates were specified create a date range
          // for both
          // The search server does not support searching of a time span over
          // two fields
          // but for our purposes it is equivalent to search both the start date
          // and end date
          // fields as date ranges. In that way all cases after the start date
          // and before the end date will be
          // returned (even if for some reason they only span one day or have an
          // end date
          // prior to the start date.
          // Return cases where start date is on or after given start date AND
          // end date is either null
          // or on or before given end date.
          if (!caseSearchCriteria.endDate.isZero()
            && !caseSearchCriteria.startDate.isZero()) {
            // Start date on or after the entered start date
            addTermIfExists(
              luceneHelper.createDateRangeTerm(IndexSearchConst.kStartDate,
              caseSearchCriteria.startDate, IndexSearchConst.kHighDate, false),
              curamQuery);
            // End date on or before the entered end date (including end date of
            // null)
            addTermIfExists(
              luceneHelper.createDateRangeTerm(IndexSearchConst.kEndDate,
              Date.kZeroDate, caseSearchCriteria.endDate, false),
              curamQuery);
          } else {

            // If only an end date is specified search for all cases with that
            // end date
            if (!caseSearchCriteria.endDate.isZero()) {
              addTermIfExists(
                luceneHelper.createDateTerm(IndexSearchConst.kEndDate,
                caseSearchCriteria.endDate),
                curamQuery);
            }

            // If only a start date is specified search for all cases with that
            // start date
            if (!caseSearchCriteria.startDate.isZero()) {
              addTermIfExists(
                luceneHelper.createDateTerm(IndexSearchConst.kStartDate,
                caseSearchCriteria.startDate),
                curamQuery);
            }
          }

          // Add the status and type code as fields in the search if they exist
          addTermIfExists(
            luceneHelper.createStandardTerm(IndexSearchConst.kStatusCode,
            caseSearchCriteria.status, false),
            curamQuery);
          addTermIfExists(
            luceneHelper.createStandardTerm(IndexSearchConst.kCaseTypeCode,
            caseSearchCriteria.category, false),
            curamQuery);
          addTermIfExists(
            luceneHelper.createStandardTerm(IndexSearchConst.kCaseReference,
            caseSearchCriteria.caseReference, true),
            curamQuery);

          // Add the sub type of the case (e.g. appeal type for appeals, product
          // type for
          // product deliveries
          if (caseSearchCriteria.category.equals(CASETYPECODE.SERVICEPLAN)) {

            // If this is a service plan search we convert the type that was
            // specified
            // into the service plan id in order to search in the index. The
            // service plan
            // id was inserted in the index so that if the service plan type was
            // ever updated the index would not have to be updated as well as
            // this would
            // have been quite performance intensive.

            final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
            final ServicePlanTypeAndStatusKey servicePlanTypeAndStatusKey = new ServicePlanTypeAndStatusKey();

            servicePlanTypeAndStatusKey.servicePlanType = caseSearchCriteria.type;
            servicePlanTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

            final ServicePlanIDDetails servicePlanIDDetails = servicePlanObj.readIDByTypeAndStatus(
              servicePlanTypeAndStatusKey);

            addTermIfExists(
              luceneHelper.createStandardTerm(IndexSearchConst.kServicePlanID,
              Long.toString(servicePlanIDDetails.servicePlanID), false),
              curamQuery);
          } else if (caseSearchCriteria.category.equals(
            CASETYPECODE.INTEGRATEDCASE)) {
            addTermIfExists(
              luceneHelper.createStandardTerm(
                IndexSearchConst.kIntegratedCaseType, caseSearchCriteria.type,
                false),
                curamQuery);
          } else if (caseSearchCriteria.category.equals(CASETYPECODE.ISSUE)) {
            addTermIfExists(
              luceneHelper.createStandardTerm(IndexSearchConst.kIssueType,
              caseSearchCriteria.type, false),
              curamQuery);
          } else if (caseSearchCriteria.category.equals(CASETYPECODE.LIABILITY)
            || caseSearchCriteria.category.equals(CASETYPECODE.PRODUCTDELIVERY)) {
            addTermIfExists(
              luceneHelper.createStandardTerm(IndexSearchConst.kProductType,
              caseSearchCriteria.type, false),
              curamQuery);
          } else if (caseSearchCriteria.category.equals(CASETYPECODE.APPEAL)) {
            addTermIfExists(
              luceneHelper.createStandardTerm(IndexSearchConst.kAppealType,
              caseSearchCriteria.type, false),
              curamQuery);
          } else if (caseSearchCriteria.category.equals(
            CASETYPECODE.INVESTIGATIONCASE)) {
            addTermIfExists(
              luceneHelper.createStandardTerm(
                IndexSearchConst.kInvestigationType, caseSearchCriteria.type,
                false),
                curamQuery);
          }

          if (caseSearchCriteria.searchWithAppeals) {
            addTermIfExists(
              luceneHelper.createStandardTerm(
                IndexSearchConst.kHasRelatedAppeal,
                IndexSearchConst.kArgumentAsOne, false),
                curamQuery);
          }

          if (caseSearchCriteria.searchWithIssues) {
            addTermIfExists(
              luceneHelper.createStandardTerm(IndexSearchConst.kHasRelatedIssue,
              IndexSearchConst.kArgumentAsOne, false),
              curamQuery);
          }

          if (caseSearchCriteria.searchWithServicePlans) {
            addTermIfExists(
              luceneHelper.createStandardTerm(
                IndexSearchConst.kHasRelatedServicePlan,
                IndexSearchConst.kArgumentAsOne, false),
                curamQuery);
          }
          if (caseSearchCriteria.searchWithInvestigations) {
            addTermIfExists(
              luceneHelper.createStandardTerm(
                IndexSearchConst.kHasRelatedInvestigationDelivery,
                IndexSearchConst.kArgumentAsOne, false),
                curamQuery);
          }

          searchServiceKey.searchServiceId = IndexSearchConst.kCaseSearch;

          curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

          // Add the fields which will be used to store the results to the query
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kCaseReference));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kStartDate));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kCaseTypeCode));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kCaseID));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kStatusCode));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kAssessmentConfigurationID));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kScreeningConfigurationID));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kIssueType));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kProductType));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kAppealType));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kIntegratedCaseType));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kInvestigationType));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kServicePlanID));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kConcernRoleID));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kIntegratedCaseID));
          curamQuery.fields.dtls.addRef(
            createResultField(IndexSearchConst.kRegistrationDate));

          // If this is a screening case search delegate to the screening search
          // function
          if (caseSearchCriteria.category.equals(CASETYPECODE.SCREENINGCASE)) {
            return doScreeningSearch(curamQuery, caseSearchCriteria);
          }

          // If this is an assessment case search delegate to the screening
          // search function
          if (caseSearchCriteria.category.equals(
            CASETYPECODE.ASSESSMENTDELIVERY)) {
            return doAssessmentSearch(curamQuery, caseSearchCriteria);
          }

          // Query the search server
          final SearchServerResults searchResults = SearchServiceConnector.search(
            curamQuery);

          // Convert the results into the result structure.
          processSearchResults(result, searchResults);

          fullResult.searchDtls.addAll(result.searchDtls);

        }
        return fullResult;
      }

    } else {

      // If the concern role id is present add it. Note that it may have been
      // specified
      // by the caller or alternatively it may have been calculated from the
      // primary
      // alternate id
      if (caseSearchCriteria.concernRoleID != 0L) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kConcernRoleID,
          Long.toString(caseSearchCriteria.concernRoleID), false),
          curamQuery);
      }

      // BEGIN, CR00103070, CW
      // If both the start and end dates were specified create a date range for
      // both
      // The search server does not support searching of a time span over two
      // fields
      // but for our purposes it is equivalent to search both the start date and
      // end date
      // fields as date ranges. In that way all cases after the start date and
      // before the end date will be
      // returned (even if for some reason they only span one day or have an end
      // date
      // prior to the start date.
      // Return cases where start date is on or after given start date AND end
      // date is either null
      // or on or before given end date.
      if (!caseSearchCriteria.endDate.isZero()
        && !caseSearchCriteria.startDate.isZero()) {
        // Start date on or after the entered start date
        addTermIfExists(
          luceneHelper.createDateRangeTerm(IndexSearchConst.kStartDate,
          caseSearchCriteria.startDate, IndexSearchConst.kHighDate, false),
          curamQuery);
        // End date on or before the entered end date (including end date of
        // null)
        addTermIfExists(
          luceneHelper.createDateRangeTerm(IndexSearchConst.kEndDate,
          Date.kZeroDate, caseSearchCriteria.endDate, false),
          curamQuery);
        // END, CR00103070
      } else {

        // BEGIN, CR00098694, CW
        // If only an end date is specified search for all cases with that end
        // date
        if (!caseSearchCriteria.endDate.isZero()) {
          addTermIfExists(
            luceneHelper.createDateTerm(IndexSearchConst.kEndDate,
            caseSearchCriteria.endDate),
            curamQuery);
        }

        // If only a start date is specified search for all cases with that
        // start date
        if (!caseSearchCriteria.startDate.isZero()) {
          addTermIfExists(
            luceneHelper.createDateTerm(IndexSearchConst.kStartDate,
            caseSearchCriteria.startDate),
            curamQuery);
        }
        // END, CR00098694
      }

      // Add the status and type code as fields in the search if they exist
      addTermIfExists(
        luceneHelper.createStandardTerm(IndexSearchConst.kStatusCode,
        caseSearchCriteria.status, false),
        curamQuery);
      addTermIfExists(
        luceneHelper.createStandardTerm(IndexSearchConst.kCaseTypeCode,
        caseSearchCriteria.category, false),
        curamQuery);
      addTermIfExists(
        luceneHelper.createStandardTerm(IndexSearchConst.kCaseReference,
        caseSearchCriteria.caseReference, true),
        curamQuery);

      // Add the sub type of the case (e.g. appeal type for appeals, product
      // type for
      // product deliveries
      if (caseSearchCriteria.category.equals(CASETYPECODE.SERVICEPLAN)) {

        // If this is a service plan search we convert the type that was
        // specified
        // into the service plan id in order to search in the index. The service
        // plan
        // id was inserted in the index so that if the service plan type was
        // ever updated the index would not have to be updated as well as this
        // would
        // have been quite performance intensive.

        final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
        final ServicePlanTypeAndStatusKey servicePlanTypeAndStatusKey = new ServicePlanTypeAndStatusKey();

        servicePlanTypeAndStatusKey.servicePlanType = caseSearchCriteria.type;
        servicePlanTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

        final ServicePlanIDDetails servicePlanIDDetails = servicePlanObj.readIDByTypeAndStatus(
          servicePlanTypeAndStatusKey);

        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kServicePlanID,
          Long.toString(servicePlanIDDetails.servicePlanID), false),
          curamQuery);
      } else if (caseSearchCriteria.category.equals(CASETYPECODE.INTEGRATEDCASE)) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kIntegratedCaseType,
          caseSearchCriteria.type, false),
          curamQuery);
      } else if (caseSearchCriteria.category.equals(CASETYPECODE.ISSUE)) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kIssueType,
          caseSearchCriteria.type, false),
          curamQuery);
      } else if (caseSearchCriteria.category.equals(CASETYPECODE.LIABILITY)
        || caseSearchCriteria.category.equals(CASETYPECODE.PRODUCTDELIVERY)) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kProductType,
          caseSearchCriteria.type, false),
          curamQuery);
      } else if (caseSearchCriteria.category.equals(CASETYPECODE.APPEAL)) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kAppealType,
          caseSearchCriteria.type, false),
          curamQuery);
        // BEGIN, CR00113482, JMA
      } else if (caseSearchCriteria.category.equals(
        CASETYPECODE.INVESTIGATIONCASE)) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kInvestigationType,
          caseSearchCriteria.type, false),
          curamQuery);
      }
      // END, CR00113482

      if (caseSearchCriteria.searchWithAppeals) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kHasRelatedAppeal,
          IndexSearchConst.kArgumentAsOne, false),
          curamQuery);
      }

      if (caseSearchCriteria.searchWithIssues) {
        addTermIfExists(
          luceneHelper.createStandardTerm(IndexSearchConst.kHasRelatedIssue,
          IndexSearchConst.kArgumentAsOne, false),
          curamQuery);
      }

      if (caseSearchCriteria.searchWithServicePlans) {
        addTermIfExists(
          luceneHelper.createStandardTerm(
            IndexSearchConst.kHasRelatedServicePlan,
            IndexSearchConst.kArgumentAsOne, false),
            curamQuery);
      }
      // BEGIN, CR00113482, JMA
      if (caseSearchCriteria.searchWithInvestigations) {
        addTermIfExists(
          luceneHelper.createStandardTerm(
            IndexSearchConst.kHasRelatedInvestigationDelivery,
            IndexSearchConst.kArgumentAsOne, false),
            curamQuery);
      }
      // END, CR00113482

      searchServiceKey.searchServiceId = IndexSearchConst.kCaseSearch;

      // BEGIN, CR00112556, CW
      curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;
      // END, CR00112556

      // Add the fields which will be used to store the results to the query
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kCaseReference));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kStartDate));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kCaseTypeCode));
      curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kCaseID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kStatusCode));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kAssessmentConfigurationID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kScreeningConfigurationID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kIssueType));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kProductType));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kAppealType));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kIntegratedCaseType));
      // BEGIN, CR00113482, JMA
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kInvestigationType));
      // END, CR00113482
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kServicePlanID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kConcernRoleID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kIntegratedCaseID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kRegistrationDate));

      // If this is a screening case search delegate to the screening search
      // function
      if (caseSearchCriteria.category.equals(CASETYPECODE.SCREENINGCASE)) {
        return doScreeningSearch(curamQuery, caseSearchCriteria);
      }

      // If this is an assessment case search delegate to the screening search
      // function
      if (caseSearchCriteria.category.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {
        return doAssessmentSearch(curamQuery, caseSearchCriteria);
      }

      // Query the search server
      final SearchServerResults searchResults = SearchServiceConnector.search(
        curamQuery);

      // Convert the results into the result structure.
      processSearchResults(result, searchResults);
    }

    return result;
    // BEGIN, CR00395267
  }

  // END, CR00201195

  // ___________________________________________________________________________
  /**
   * Performs a search for a screening case. This is different because instead
   * of storing the actual screening name code in the index we have stored the
   * id of the configuration. This prevents huge cascade updates to the index
   * but means that we need to call the index once for each screening
   * configuration.
   *
   * @param curamQuery The query with all details except the screening name
   * identifier pre-populated
   * @param caseSearchCriteria The criteria for the search
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} This method has
   * been deprecated to introduce new case search enhancements.
   */
  // BEGIN, CR00198672, VK
  @Deprecated
  protected CaseSearchList doScreeningSearch(final CuramQuery curamQuery,
    final CaseSearchCriteria caseSearchCriteria) throws AppException,
      InformationalException {

    // END, CR00198672
    final CaseSearchList result = new CaseSearchList();
    final ScreeningNameAndStatus screeningNameAndStatus = new ScreeningNameAndStatus();
    final LuceneHelper luceneHelper = new LuceneHelper();

    ScreeningConfigurationDtlsList screeningConfigurationDtlsList;

    screeningNameAndStatus.name = caseSearchCriteria.type;
    screeningNameAndStatus.recordStatus = RECORDSTATUS.NORMAL;

    screeningConfigurationDtlsList = ScreeningConfigurationFactory.newInstance().searchByNameAndStatus(
      screeningNameAndStatus);

    for (int i = 0; i < screeningConfigurationDtlsList.dtls.size(); i++) {

      final ScreeningConfigurationDtls screeningConfigurationDtls = screeningConfigurationDtlsList.dtls.item(
        i);

      if (screeningConfigurationDtls.recordStatus.equals(RECORDSTATUS.NORMAL)) {

        // remove the previous screening configuration id if there was one
        removeTermFromQuery(curamQuery,
          IndexSearchConst.kScreeningConfigurationID);

        curamQuery.terms.dtls.addRef(
          luceneHelper.createStandardTerm(
            IndexSearchConst.kScreeningConfigurationID,
            Long.toString(screeningConfigurationDtls.screeningConfigID), false));

        final SearchServerResults searchResults = SearchServiceConnector.search(
          curamQuery);

        // convert the search results to the result struct
        processSearchResults(result, searchResults);
      }
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Performs a search for an assessment case. This is different because instead
   * of storing the actual assessment type code in the index we have stored the
   * id of the configuration. This prevents huge cascade updates to the index
   * but means that we need to call the index once for each assessment
   * configuration.
   *
   * @param curamQuery The query with all details except the assessment type
   * code
   * pre-populated
   * @param caseSearchCriteria The criteria for the search
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} This method has
   * been deprecated to introduce new case search enhancements.
   */
  // BEGIN, CR00198672, VK
  @Deprecated
  protected CaseSearchList doAssessmentSearch(final CuramQuery curamQuery,
    final CaseSearchCriteria caseSearchCriteria) throws AppException,
      InformationalException {

    // END, CR00198672
    final CaseSearchList result = new CaseSearchList();
    final AssessmentConfigurationType assessmentConfigurationType = new AssessmentConfigurationType();
    final LuceneHelper luceneHelper = new LuceneHelper();

    assessmentConfigurationType.assessmentType = caseSearchCriteria.type;

    final AssessmentConfigurationTypeDtlsList assConfigurationDtlsList = AssessmentConfigurationFactory.newInstance().searchAssessmentConfigurationByType(
      assessmentConfigurationType);

    for (int i = 0; i < assConfigurationDtlsList.dtls.size(); i++) {
      final AssessmentConfigurationTypeDtls assessmentConfigurationTypeDtls = assConfigurationDtlsList.dtls.item(
        i);

      if (assessmentConfigurationTypeDtls.status.equals(RECORDSTATUS.NORMAL)) {

        // remove the previous assessment configuration id if there was one
        removeTermFromQuery(curamQuery,
          IndexSearchConst.kAssessmentConfigurationID);

        curamQuery.terms.dtls.addRef(
          luceneHelper.createStandardTerm(
            IndexSearchConst.kAssessmentConfigurationID,
            Long.toString(
              assessmentConfigurationTypeDtls.assessmentConfigurationID),
              false));

        final SearchServerResults searchResults = SearchServiceConnector.search(
          curamQuery);

        // convert the search results to the result struct
        processSearchResults(result, searchResults);
      }
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Iterates over a search server query and removes any terms based on the
   * specified field if found.
   *
   * @param curamQuery The query for the search server
   * @param field The name of the field to be removed
   */
  // BEGIN, CR00198672, VK
  protected void removeTermFromQuery(final CuramQuery curamQuery,
    final String field) {

    // END, CR00198672
    for (int j = 0; j < curamQuery.terms.dtls.size(); j++) {

      final CuramTerm term = curamQuery.terms.dtls.item(j);

      if (term.termType.equals(TERMTYPE.STANDARD)
        && term.stdTerm.field.equals(field)) {
        curamQuery.terms.dtls.remove(j);
        break;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Takes search results from the search server and converts them into the
   * search result format.
   *
   * @param result The search list to put the results into
   * @param searchResults The results from the search server
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} This method has
   * been deprecated to introduce new case search enhancements.
   */
  // BEGIN, CR00198672, VK
  @Deprecated
  protected void processSearchResults(final CaseSearchList result,
    final SearchServerResults searchResults) throws AppException,
      InformationalException {

    // END, CR00198672
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    for (int i = 0; i < searchResults.documents.dtls.size(); i++) {

      CaseSearchDetails caseSearchDetails = new CaseSearchDetails();

      final CuramDocument document = searchResults.documents.dtls.item(i);

      caseSearchDetails = (CaseSearchDetails) CuramDocToResultStruct.convert(
        document, caseSearchDetails, dictionary);

      caseSearchDetails.partOfIntegCaseInd = caseSearchDetails.integratedCaseID
        != 0;

      concernRoleKey.concernRoleID = caseSearchDetails.concernRoleID;

      concernRoleDtls = ConcernRoleFactory.newInstance().read(concernRoleKey);

      caseSearchDetails.concernRoleName = concernRoleDtls.concernRoleName;
      caseSearchDetails.primaryAlternateID = concernRoleDtls.primaryAlternateID;

      if (caseSearchDetails.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {
        // its a service plan - we need to first get the type code from the
        // database and then get the category code

        final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
        final ServicePlanKey servicePlanKey = new ServicePlanKey();

        final CuramField field = findField(document,
          IndexSearchConst.kServicePlanID);

        servicePlanKey.servicePlanID = Long.valueOf(field.value);

        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          SERVICEPLANTYPE.TABLENAME,
          servicePlanObj.readType(servicePlanKey).servicePlanType);

      } else if (caseSearchDetails.caseTypeCode.equals(
        CASETYPECODE.ASSESSMENTDELIVERY)) {
        // AssessmentDelivery manipulation variables
        final curam.core.sl.entity.intf.AssessmentDelivery assessmentDeliveryObj = curam.core.sl.entity.fact.AssessmentDeliveryFactory.newInstance();
        final AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();

        assessmentDeliveryKey.caseID = caseSearchDetails.caseID;

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          ASSESSMENTTYPE.TABLENAME,
          assessmentDeliveryObj.readAssessmentType(assessmentDeliveryKey).assessmentType);

      } else if (caseSearchDetails.caseTypeCode.equals(
        CASETYPECODE.INTEGRATEDCASE)) {
        // CaseHeader manipulation variables
        final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = caseSearchDetails.caseID;

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          PRODUCTCATEGORY.TABLENAME,
          caseHeaderObj.readIntegratedCaseType(caseKey).integratedCaseType);

      } else if (caseSearchDetails.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
        // IssueDelivery manipulation variables
        final curam.core.sl.entity.intf.IssueDelivery issueDeliveryObj = curam.core.sl.entity.fact.IssueDeliveryFactory.newInstance();
        final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

        issueDeliveryKey.caseID = caseSearchDetails.caseID;

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          ISSUECONFIGURATIONTYPE.TABLENAME,
          issueDeliveryObj.readIssueType(issueDeliveryKey).issueType);
        // BEGIN, CR00113482, JMA
      } else if (caseSearchDetails.caseTypeCode.equals(
        CASETYPECODE.INVESTIGATIONCASE)) {
        // IssueDelivery manipulation variables
        final curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryObj = curam.core.sl.entity.fact.InvestigationDeliveryFactory.newInstance();
        final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

        investigationDeliveryKey.caseID = caseSearchDetails.caseID;

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          INVESTIGATECONFIGTYPE.TABLENAME,
          investigationDeliveryObj.readInvestigationType(investigationDeliveryKey).investigationType);
        // END, CR00113482
      } else if (caseSearchDetails.caseTypeCode.equals(CASETYPECODE.LIABILITY)
        || caseSearchDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
        // productDelivery manipulation variables
        final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
        final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
        ProductDeliveryDtls productDeliveryDtls;

        // set key to read productDelivery entity
        productDeliveryKey.caseID = caseSearchDetails.caseID;

        // read productDelivery entity
        productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          PRODUCTTYPE.TABLENAME, productDeliveryDtls.productType);

      } else if (caseSearchDetails.caseTypeCode.equals(
        CASETYPECODE.SCREENINGCASE)) {
        // Screening manipulation variables
        final curam.core.sl.entity.intf.Screening screeningObj = curam.core.sl.entity.fact.ScreeningFactory.newInstance();
        final CaseKeyStruct caseKey = new CaseKeyStruct();

        caseKey.caseID = caseSearchDetails.caseID;

        // Set the type
        caseSearchDetails.caseCatTypeCode = curam.util.type.CodeTable.getOneItem(
          SCREENINGNAMECODE.TABLENAME, screeningObj.readName(caseKey).name);

      }

      restrictResults(caseSearchDetails);

      result.searchDtls.addRef(caseSearchDetails);
    }
  }

  // ___________________________________________________________________________
  /**
   * Finds a field with the specified name in the document and returns it to
   * the caller.
   *
   * @param document The document containing the search results
   * @param field The name of the field
   *
   * @return The <code>CuramField</code> with the specified name
   */
  // BEGIN, CR00198672, VK
  protected CuramField findField(final CuramDocument document,
    final String field) {

    // END, CR00198672
    for (int i = 0; i < document.fields.dtls.size(); i++) {
      final CuramField current = document.fields.dtls.item(i);

      if (current.name.equals(field)) {
        return current;
      }
    }
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Adds a term to the curam query if the term exists
   *
   * @param term the curam term type
   * @param curamQuery the curam query
   */
  // BEGIN, CR00198672, VK
  protected void addTermIfExists(final CuramTerm term,
    final CuramQuery curamQuery) {

    // END, CR00198672
    if (term.termType.equals(TERMTYPE.STANDARD)) {
      if (term.stdTerm.value.length() > 0) {
        curamQuery.terms.dtls.addRef(term);
      }
    } else if (term.termType.equals(TERMTYPE.DATE)) {
      if (!term.dtTerm.value.isZero()) {
        curamQuery.terms.dtls.addRef(term);
      }
    } else if (term.termType.equals(TERMTYPE.DATERANGE)) {
      // BEGIN, CR00103070, CW
      // Add the date range if there is a start or end date
      if (!term.dateRangeTerm.beginDate.isZero()
        || !term.dateRangeTerm.endDate.isZero()) {
        // END, CR00103070
        curamQuery.terms.dtls.addRef(term);
      }
    }
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Creates a result field for the curam query
   *
   * @param field the field name
   *
   * @return CuramField the curam field
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link curam.core.impl.LuceneHelper#createResultField()}
   */
  // BEGIN, CR00198672, VK
  @Deprecated
  protected CuramField createResultField(final String field) {

    // END, CR00198672
    final LuceneHelper luceneHelper = new LuceneHelper();

    return luceneHelper.createResultField(field);
  }

  // END, CR00257963

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * Performs a lucene index search for case using the specified search
   * criteria.
   * Method replaces {@link #search()} but is not backward compatible because
   * a) old method returns cases only for primary alternate id, new method
   * returns cases for all alternate ids,
   * b) old methods returns cases only where concern role is primary client,
   * new method returns cases where concern role is any case participant role
   * for a case.
   *
   * @param caseSearchCriteria data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If case search results exceeds case search maximum value.
   */
  @Override
  public CaseSearchList1 search1(CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    // BEGIN, CR00257963, ZV
    // BEGIN, CR00221505, ZV
    final CuramQuery curamQuery = createCaseSearchQuery(caseSearchCriteria);

    // Query the search server
    final SearchServerResults searchResults = executeQuery(curamQuery);

    final CaseSearchList1 result = processCaseSearchQueryResults(searchResults);

    // END, CR00221505
    // END, CR00257963

    return result;
  }

  // BEGIN, CR00221505, ZV
  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for case lucene index search for the specified search
   * criteria.
   *
   * @param caseSearchCriteria data on which the query will be based
   *
   * @return The Curam query for case lucene index search
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #createCaseSearchQuery()}
   */
  @Deprecated
  public CuramQuery createCaseQuery(CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    return createCaseSearchQuery(caseSearchCriteria);

  }

  // END, CR00257963

  // ___________________________________________________________________________
  /**
   * Executes a lucene index search query
   *
   * @param curamQuery Query to execute
   *
   * @return The lucene index search query results
   */
  protected SearchServerResults executeQuery(CuramQuery curamQuery)
    throws AppException, InformationalException {

    return SearchServiceConnector.search(curamQuery);
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Method to process case query results .
   *
   * @param searchServerResults Lucene index search query results
   *
   * @return The details of any case records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If case search results exceeds case search maximum value.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #processCaseSearchQueryResults()}
   */
  @Deprecated
  public CaseSearchList1 processCaseQueryResults(
    SearchServerResults searchServerResults) throws AppException,
      InformationalException {

    return processCaseSearchQueryResults(searchServerResults);

  }

  // END, CR00257963
  // END, CR00221505

  // ___________________________________________________________________________
  /**
   * Adds a term to the curam query if the term exists
   *
   * @param category case category code
   * @param type case type code
   *
   * @return query term with set case type value
   */
  protected CuramTerm getCaseTypeTerm(final String category, final String type)
    throws AppException, InformationalException {

    final LuceneHelper luceneHelper = new LuceneHelper();
    CuramTerm caseTypeTerm = new CuramTerm();

    if (category.equals(CASECATEGORY.PRODUCTDELIVERY)
      || category.equals(CASECATEGORY.LIABILITY)) {

      final Product productObj = ProductFactory.newInstance();
      final ProductNameStructRef productNameStructRef = new ProductNameStructRef();

      productNameStructRef.name = type;
      productNameStructRef.statusCode = RECORDSTATUS.NORMAL;

      final ProductDtls productDtls = productObj.readProductsByName(
        productNameStructRef);

      caseTypeTerm = luceneHelper.createStandardTerm(
        IndexSearchConst.kProductID, Long.toString(productDtls.productID),
        false);

    } else if (category.equals(CASECATEGORY.INTEGRATEDCASE)) {

      caseTypeTerm = luceneHelper.createStandardTerm(
        IndexSearchConst.kIntegratedCaseType, type, false);

    } else if (category.equals(CASECATEGORY.INVESTIGATION)) {

      caseTypeTerm = luceneHelper.createStandardTerm(
        IndexSearchConst.kInvestigationType, type, false);

    } else if (category.equals(CASECATEGORY.SCREENINGCASE)) {

      final ScreeningNameAndStatus screeningNameAndStatus = new ScreeningNameAndStatus();

      screeningNameAndStatus.name = type;
      screeningNameAndStatus.recordStatus = RECORDSTATUS.NORMAL;

      final ScreeningConfigurationDtlsList screeningConfigurationDtlsList = ScreeningConfigurationFactory.newInstance().searchByNameAndStatus(
        screeningNameAndStatus);

      if (screeningConfigurationDtlsList.dtls.size() > CuramConst.gkZero) {

        caseTypeTerm = luceneHelper.createStandardTerm(
          IndexSearchConst.kScreeningConfigurationID,
          Long.toString(
            screeningConfigurationDtlsList.dtls.item(CuramConst.gkZero).screeningConfigID),
            false);

      }

    } else if (category.equals(CASECATEGORY.ASSESSMENTDELIVERY)) {

      final AssessmentConfigurationType assessmentConfigurationType = new AssessmentConfigurationType();

      assessmentConfigurationType.assessmentType = type;

      final AssessmentConfigurationTypeDtlsList assConfigurationDtlsList = AssessmentConfigurationFactory.newInstance().searchAssessmentConfigurationByType(
        assessmentConfigurationType);

      if (assConfigurationDtlsList.dtls.size() > CuramConst.gkZero) {

        caseTypeTerm = luceneHelper.createStandardTerm(
          IndexSearchConst.kAssessmentConfigurationID,
          Long.toString(
            assConfigurationDtlsList.dtls.item(CuramConst.gkZero).assessmentConfigurationID),
            false);

      }

    } else if (category.equals(CASECATEGORY.ISSUE)) {

      caseTypeTerm = luceneHelper.createStandardTerm(
        IndexSearchConst.kIssueType, type, false);

    } else if (category.equals(CASECATEGORY.SERVICEPLAN)) {

      // If this is a service plan search we convert the type that was
      // specified into the service plan id in order to search in the index.
      // The service plan id was inserted in the index so that if the
      // service plan type was ever updated the index would not have to be
      // updated as well as this would have been quite performance intensive.

      final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
      final ServicePlanTypeAndStatusKey servicePlanTypeAndStatusKey = new ServicePlanTypeAndStatusKey();

      servicePlanTypeAndStatusKey.servicePlanType = type;
      servicePlanTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      final ServicePlanIDDetails servicePlanIDDetails = servicePlanObj.readIDByTypeAndStatus(
        servicePlanTypeAndStatusKey);

      caseTypeTerm = luceneHelper.createStandardTerm(
        IndexSearchConst.kServicePlanID,
        Long.toString(servicePlanIDDetails.servicePlanID), false);

    } else if (category.equals(CASETYPECODE.APPEAL)) {
      caseTypeTerm = luceneHelper.createStandardTerm(
        IndexSearchConst.kAppealType, type, false);

    }

    caseTypeTerm.occurs = TERMOCCURS.SHOULD;

    return caseTypeTerm;

  }

  // END, CR00201195

  // BEGIN, CR00221505, ZV
  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Format case type condition
   *
   * @param category case category code
   * @param type case type code
   *
   * @return query term with set case type value
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #getCaseSearchTypeStatement()}
   */
  @Deprecated
  protected String getCaseTypeStatement(final String category,
    final String type) throws AppException, InformationalException {

    return getCaseSearchTypeStatement(category, type);

  }

  // END, CR00257963
  // END, CR00221505

  // BEGIN, CR00204411, ZV
  // ___________________________________________________________________________
  /**
   * Performs a lucene index search for investigation using the specified search
   * criteria.
   *
   * @param searchCriteria data on which the searched will be based
   *
   * @return The details of any investigation records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If investigation search results exceeds search maximum value.
   */
  @Override
  public InvestigationSearchDetailsList investigationSearch(
    InvestigationSearchCriteria searchCriteria) throws AppException,
      InformationalException {

    // BEGIN, CR00257963, ZV
    // BEGIN, CR00221505, ZV
    final CuramQuery curamQuery = createInvestigationSearchQuery(searchCriteria);

    // Query the search server
    final SearchServerResults searchResults = executeQuery(curamQuery);

    final InvestigationSearchDetailsList results = processInvestigationSearchQueryResults(
      searchResults);

    // END, CR00221505
    // END, CR00257963

    return results;
  }

  // END, CR00204411

  // BEGIN, CR00221505, ZV
  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for investigation lucene index search for the specified search
   * criteria.
   *
   * @param searchCriteria data on which the query will be based
   *
   * @return The Curam query for investigation lucene index search
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #createInvestigationSearchQuery()}
   */
  @Deprecated
  public CuramQuery createInvestigationQuery(
    InvestigationSearchCriteria searchCriteria) throws AppException,
      InformationalException {

    return createInvestigationSearchQuery(searchCriteria);

  }

  // END, CR00257963

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Method to process investigation query results.
   *
   * @param searchServerResults Lucene index search query results
   *
   * @return The details of any investigation records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If investigation search results exceeds case search maximum value.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #processInvestigationSearchQueryResults()}
   */
  @Deprecated
  public InvestigationSearchDetailsList processInvestigationQueryResults(
    SearchServerResults searchServerResults) throws AppException,
      InformationalException {

    return processInvestigationSearchQueryResults(searchServerResults);

  }

  // END, CR00257963
  // END, CR00221505

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for case lucene index search for the specified search
   * criteria.
   *
   * @param caseSearchCriteria data on which the query will be based
   *
   * @return The Curam query for case lucene index search
   */
  public static CuramQuery createCaseSearchQuery(
    CaseSearchCriteria1 caseSearchCriteria) throws AppException,
      InformationalException {

    final CuramQuery curamQuery = new CuramQuery();
    final SearchServiceKey searchServiceKey = new SearchServiceKey();
    final LuceneHelper luceneHelper = new LuceneHelper();
    final IndexParticipantSearch indexParticipantSearchObj = IndexParticipantSearchFactory.newInstance();
    final TextFieldDetails textFieldDetails = new TextFieldDetails();

    searchServiceKey.searchServiceId = IndexSearchConst.kCaseSearch;

    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

    // Add the fields which will be used to store the results to the query
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kCaseReference));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kStartDate));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kCaseTypeCode));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kCaseID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kStatusCode));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(
        IndexSearchConst.kAssessmentConfigurationID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kScreeningConfigurationID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kIssueType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kProductType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kAppealType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kIntegratedCaseType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kInvestigationType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kServicePlanID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kParticipantCount));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleName));

    if (caseSearchCriteria.categoryList.length() > 0) {

      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += "(";

      final StringList categoryList = StringUtil.tabText2StringListWithTrim(
        caseSearchCriteria.categoryList);

      for (int i = 0; i < categoryList.size(); i++) {

        if (categoryList.item(i).length() > 0) {
          curamQuery.text += IndexSearchConst.kCaseTypeCode
            + CuramConst.gkColon + categoryList.item(i)
            + IndexSearchConst.kORString;
        }
      }
      // remove last OR from statement
      curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
        curamQuery.text.length() - IndexSearchConst.kORLength);
      curamQuery.text += ")";
    }

    if (caseSearchCriteria.caseReference.length() == CuramConst.gkZero) {

      // Add date ranges if required
      if (!caseSearchCriteria.startDateFrom.isZero()
        || !caseSearchCriteria.startDateTo.isZero()) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kStartDate + CuramConst.gkColon;
        curamQuery.text += "[";

        if (!caseSearchCriteria.startDateFrom.isZero()) {
          curamQuery.text += Locale.getFormattedDate(
            caseSearchCriteria.startDateFrom, Locale.Date_ymd);
        } else {
          curamQuery.text += Locale.getFormattedDate(IndexSearchConst.kLowDate,
            Locale.Date_ymd);
        }

        curamQuery.text += " TO ";

        if (!caseSearchCriteria.startDateTo.isZero()) {
          curamQuery.text += Locale.getFormattedDate(
            caseSearchCriteria.startDateTo, Locale.Date_ymd);
        } else {
          curamQuery.text += Locale.getFormattedDate(IndexSearchConst.kHighDate,
            Locale.Date_ymd);
        }

        curamQuery.text += "]";

      }

      if (!caseSearchCriteria.endDateFrom.isZero()
        || !caseSearchCriteria.endDateTo.isZero()) {

        String endDateStatement = IndexSearchConst.kEndDate
          + CuramConst.gkColon + "[";

        if (!caseSearchCriteria.endDateFrom.isZero()) {
          endDateStatement += Locale.getFormattedDate(
            caseSearchCriteria.endDateFrom, Locale.Date_ymd);
        } else {
          endDateStatement += Locale.getFormattedDate(IndexSearchConst.kLowDate,
            Locale.Date_ymd);
        }

        endDateStatement += " TO ";

        if (!caseSearchCriteria.endDateTo.isZero()) {
          endDateStatement += Locale.getFormattedDate(
            caseSearchCriteria.endDateTo, Locale.Date_ymd);
        } else {
          endDateStatement += Locale.getFormattedDate(
            IndexSearchConst.kHighDate, Locale.Date_ymd);
        }

        endDateStatement += "]";

        curamQuery.text += IndexSearchConst.kANDString;

        // Add null value for end date
        if (caseSearchCriteria.endDateTo.isZero()) {
          curamQuery.text += "(" + endDateStatement
            + IndexSearchConst.kORString + IndexSearchConst.kEndDate
            + CuramConst.gkColon
            + Locale.getFormattedDate(Date.kZeroDate, Locale.Date_ymd) + ")";
        } else {
          curamQuery.text += endDateStatement;
        }
      }

      if (caseSearchCriteria.statusList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList statusList = StringUtil.tabText2StringListWithTrim(
          caseSearchCriteria.statusList);

        for (int i = 0; i < statusList.size(); i++) {

          if (statusList.item(i).length() > 0) {
            curamQuery.text += IndexSearchConst.kStatusCode
              + CuramConst.gkColon + statusList.item(i)
              + IndexSearchConst.kORString;
          }
        }
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";
      }

      // Add the sub type of the case (e.g. appeal type for appeals, product
      // type for
      // product deliveries
      if (caseSearchCriteria.categoryTypeList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList categoryTypeList = StringUtil.tabText2StringListWithTrim(
          caseSearchCriteria.categoryTypeList);

        for (int i = 0; i < categoryTypeList.size(); i++) {

          final StringList categoryType = StringUtil.delimitedText2StringListWithTrim(
            categoryTypeList.item(i), CuramConst.gkPipeDelimiterChar);

          if (categoryType.size() > CuramConst.gkOne) {
            // get case category and type
            final String category = categoryType.item(0);
            final String type = categoryType.item(1);

            curamQuery.text += "(" + IndexSearchConst.kCaseTypeCode
              + CuramConst.gkColon + category + " AND ";

            // BEGIN, CR00257963, ZV
            curamQuery.text += getCaseSearchTypeStatement(category, type) + ")"
              + IndexSearchConst.kORString;
            // END, CR00257963

          } // if (categoryType.size() > CuramConst.gkOne)
        } // for (int i = 0; i < categoryTypeList.size(); i++)
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";
      } // if (caseSearchCriteria.categoryTypeList.length() > 0)

      if (caseSearchCriteria.searchWithAppeals) {
        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kHasRelatedAppeal
          + CuramConst.gkColon + IndexSearchConst.kIndexTrueInd;
      }

      if (caseSearchCriteria.searchWithIssues) {
        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kHasRelatedIssue
          + CuramConst.gkColon + IndexSearchConst.kIndexTrueInd;
      }

      if (caseSearchCriteria.searchWithServicePlans) {
        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kHasRelatedServicePlan
          + CuramConst.gkColon + IndexSearchConst.kIndexTrueInd;
      }

      if (caseSearchCriteria.searchWithInvestigations) {
        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kHasRelatedInvestigationDelivery
          + CuramConst.gkColon + IndexSearchConst.kIndexTrueInd;
      }

      // search for case primary client concern role id is left for backward
      // compatibility
      if (caseSearchCriteria.concernRoleID != 0L) {
        curamQuery.text += IndexSearchConst.kANDString;
        if (caseSearchCriteria.concernRoleID > 0) {
          curamQuery.text += IndexSearchConst.kConcernRoleID
            + CuramConst.gkColon + caseSearchCriteria.concernRoleID;

        } else {
          curamQuery.text += IndexSearchConst.kConcernRoleID
            + CuramConst.gkColon + CuramConst.gkBackslash
            + caseSearchCriteria.concernRoleID;
        }
      }

      if (caseSearchCriteria.clientFirstName.length() == 0
        && caseSearchCriteria.clientSurname.length() == 0
        && caseSearchCriteria.alternateID.length() == 0) {
        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
          + IndexSearchConst.kIndexTrueInd;
      }

      if (caseSearchCriteria.clientFirstName.length() > 0) {
        curamQuery.text += IndexSearchConst.kANDString;
        textFieldDetails.fieldName = IndexSearchConst.kConcernRoleFirstName;
        textFieldDetails.fieldValue = caseSearchCriteria.clientFirstName;
        // BEGIN, CR00338327, ZV
        if (caseSearchCriteria.clientFirstName.length() > 1
          || !caseSearchCriteria.clientSurname.isEmpty()) {
          textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
        }
        // END, CR00338327
        curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
      }

      if (caseSearchCriteria.clientSurname.length() > 0) {
        curamQuery.text += IndexSearchConst.kANDString;
        textFieldDetails.fieldName = IndexSearchConst.kConcernRoleSurname;
        textFieldDetails.fieldValue = caseSearchCriteria.clientSurname;
        // BEGIN, CR00338327, ZV
        if (caseSearchCriteria.clientSurname.length() > 1) {
          textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
        }
        // END, CR00338327
        curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
      }

      if (caseSearchCriteria.alternateIDType.length() > 0
        && caseSearchCriteria.alternateID.length() > 0) {

        if (caseSearchCriteria.alternateIDType.equals(
          CONCERNROLESEARCHALTERNATEID.REFERENCE_NUMBER)) {

          curamQuery.text += IndexSearchConst.kANDString;

          curamQuery.text += "(";
          textFieldDetails.fieldName = IndexSearchConst.kConcernRoleAlternateIDList;
          textFieldDetails.fieldValue = CONCERNROLEALTERNATEID.REFERENCE_NUMBER
            + CuramConst.gkPipeDelimiter + caseSearchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;

          curamQuery.text += IndexSearchConst.kORString;
          textFieldDetails.fieldValue = CONCERNROLEALTERNATEID.PERSON_REFERENCE_NUMBER
            + CuramConst.gkPipeDelimiter + caseSearchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;

          curamQuery.text += IndexSearchConst.kORString;
          textFieldDetails.fieldValue = CONCERNROLEALTERNATEID.EMPLOYER_REFERENCE_NUMBER
            + CuramConst.gkPipeDelimiter + caseSearchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
          curamQuery.text += ")";

        } else {
          curamQuery.text += IndexSearchConst.kANDString;

          textFieldDetails.fieldName = IndexSearchConst.kConcernRoleAlternateIDList;
          textFieldDetails.fieldValue = caseSearchCriteria.alternateIDType
            + CuramConst.gkPipeDelimiter + caseSearchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
        }
      }

      if (caseSearchCriteria.ownerList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList ownerList = StringUtil.tabText2StringListWithTrim(
          caseSearchCriteria.ownerList);

        for (int i = 0; i < ownerList.size(); i++) {

          if (ownerList.item(i).length() > 0) {
            if (Long.parseLong(ownerList.item(i)) > 0) {
              curamQuery.text += IndexSearchConst.kOwnerOrgObjectLinkID
                + CuramConst.gkColon + ownerList.item(i)
                + IndexSearchConst.kORString;
            } else {
              curamQuery.text += IndexSearchConst.kOwnerOrgObjectLinkID
                + CuramConst.gkColon + CuramConst.gkBackslash
                + ownerList.item(i) + IndexSearchConst.kORString;
            }
          }
        }
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";

      }

    } else {

      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kCaseReference;
      // BEGIN, CR00379119, SS
      final ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
      final SearchCriteriaString referenceKeyvalue = new SearchCriteriaString();

      referenceKeyvalue.string = caseSearchCriteria.caseReference;
      textFieldDetails.fieldValue = participantSearchObj.formatReferenceFieldValue(referenceKeyvalue).fieldValue;
      // END, CR00379119
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;

    }

    // remove first AND from statement
    curamQuery.text = curamQuery.text.substring(IndexSearchConst.kANDLength,
      curamQuery.text.length());

    return curamQuery;
  }

  // ___________________________________________________________________________
  /**
   * Method to process case query results .
   *
   * @param searchServerResults Lucene index search query results
   *
   * @return The details of any case records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If case search results exceeds case search maximum value.
   */
  public static CaseSearchList1 processCaseSearchQueryResults(
    SearchServerResults searchServerResults) throws AppException,
      InformationalException {

    final CaseSearchList1 result = new CaseSearchList1();
    final List<Long> caseIDList = new ArrayList<Long>();

    int searchMaximum = 0;

    if (Configuration.getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM) != null) {
      searchMaximum = curam.util.resources.Configuration.getIntProperty(
        EnvVars.ENV_CASESEARCHMAXIMUM);
    } else {
      searchMaximum = EnvVars.ENV_CASESEARCHMAXIMUM_DEFAULT;
    }

    // BEGIN, CR00274833, ELG
    // If the list is greater that the case search maximum value
    int numItems = 0;

    if (searchServerResults.documents.dtls.size() > searchMaximum) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException ae = new AppException(
        GENERALSEARCH.INF_SEARCH_MAXIMUM_EXCEEDED);

      ae.arg(searchMaximum);
      ae.arg(searchServerResults.documents.dtls.size());
      ae.arg(searchMaximum);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);

      numItems = searchMaximum;

    } else {
      numItems = searchServerResults.documents.dtls.size();
    }

    // Convert the results into the result structure.
    for (int i = 0; i < numItems; i++) {
      // END, CR00274833

      CaseSearchDetails1 caseSearchDetails = new CaseSearchDetails1();

      final CuramDocument document = searchServerResults.documents.dtls.item(i);

      caseSearchDetails = (CaseSearchDetails1) CuramDocToResultStruct.convert(
        document, caseSearchDetails, dictionary);

      final curam.core.intf.DatabaseCaseSearch databaseCaseSearchObj = curam.core.fact.DatabaseCaseSearchFactory.newInstance();

      databaseCaseSearchObj.processSearchDetails(caseSearchDetails);

      if (!caseIDList.contains(caseSearchDetails.caseID)
        && caseSearchDetails.caseReference != null) {
        result.searchDtls.addRef(caseSearchDetails);
        caseIDList.add(caseSearchDetails.caseID);
      }

    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Format case type condition
   *
   * @param category case category code
   * @param type case type code
   *
   * @return query term with set case type value
   */
  protected static String getCaseSearchTypeStatement(final String category,
    final String type) throws AppException, InformationalException {

    String caseTypeStatement = new String();

    if (category.equals(CASECATEGORY.PRODUCTDELIVERY)
      || category.equals(CASECATEGORY.LIABILITY)) {

      final Product productObj = ProductFactory.newInstance();
      final ProductNameStructRef productNameStructRef = new ProductNameStructRef();

      productNameStructRef.name = type;
      productNameStructRef.statusCode = RECORDSTATUS.NORMAL;

      final ProductDtls productDtls = productObj.readProductsByName(
        productNameStructRef);

      if (productDtls.productID > 0) {
        caseTypeStatement = IndexSearchConst.kProductID + CuramConst.gkColon
          + Long.toString(productDtls.productID);

      } else {
        caseTypeStatement = IndexSearchConst.kProductID + CuramConst.gkColon
          + CuramConst.gkBackslash + Long.toString(productDtls.productID);
      }

    } else if (category.equals(CASECATEGORY.INTEGRATEDCASE)) {

      caseTypeStatement = IndexSearchConst.kIntegratedCaseType
        + CuramConst.gkColon + type;

    } else if (category.equals(CASECATEGORY.INVESTIGATION)) {

      caseTypeStatement = IndexSearchConst.kInvestigationType
        + CuramConst.gkColon + type;

    } else if (category.equals(CASECATEGORY.SCREENINGCASE)) {

      final ScreeningNameAndStatus screeningNameAndStatus = new ScreeningNameAndStatus();

      screeningNameAndStatus.name = type;
      screeningNameAndStatus.recordStatus = RECORDSTATUS.NORMAL;

      final ScreeningConfigurationDtlsList screeningConfigurationDtlsList = ScreeningConfigurationFactory.newInstance().searchByNameAndStatus(
        screeningNameAndStatus);

      if (screeningConfigurationDtlsList.dtls.size() > CuramConst.gkZero) {

        final long screeningConfigID = screeningConfigurationDtlsList.dtls.item(CuramConst.gkZero).screeningConfigID;

        if (screeningConfigID > 0) {
          caseTypeStatement = IndexSearchConst.kScreeningConfigurationID
            + CuramConst.gkColon + Long.toString(screeningConfigID);
        } else {
          caseTypeStatement = IndexSearchConst.kScreeningConfigurationID
            + CuramConst.gkColon + CuramConst.gkBackslash
            + Long.toString(screeningConfigID);
        }

      }

    } else if (category.equals(CASECATEGORY.ASSESSMENTDELIVERY)) {

      final AssessmentConfigurationType assessmentConfigurationType = new AssessmentConfigurationType();

      assessmentConfigurationType.assessmentType = type;

      final AssessmentConfigurationTypeDtlsList assConfigurationDtlsList = AssessmentConfigurationFactory.newInstance().searchAssessmentConfigurationByType(
        assessmentConfigurationType);

      if (assConfigurationDtlsList.dtls.size() > CuramConst.gkZero) {

        final long assessmentConfigurationID = assConfigurationDtlsList.dtls.item(CuramConst.gkZero).assessmentConfigurationID;

        if (assessmentConfigurationID > 0) {
          caseTypeStatement = IndexSearchConst.kAssessmentConfigurationID
            + CuramConst.gkColon + assessmentConfigurationID;
        } else {
          caseTypeStatement = IndexSearchConst.kAssessmentConfigurationID
            + CuramConst.gkColon + CuramConst.gkBackslash
            + assessmentConfigurationID;
        }

      }

    } else if (category.equals(CASECATEGORY.ISSUE)) {

      caseTypeStatement = IndexSearchConst.kIssueType + CuramConst.gkColon
        + type;

    } else if (category.equals(CASECATEGORY.SERVICEPLAN)) {

      // If this is a service plan search we convert the type that was
      // specified into the service plan id in order to search in the index.
      // The service plan id was inserted in the index so that if the
      // service plan type was ever updated the index would not have to be
      // updated as well as this would have been quite performance intensive.

      final ServicePlan servicePlanObj = ServicePlanFactory.newInstance();
      final ServicePlanTypeAndStatusKey servicePlanTypeAndStatusKey = new ServicePlanTypeAndStatusKey();

      servicePlanTypeAndStatusKey.servicePlanType = type;
      servicePlanTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      final ServicePlanIDDetails servicePlanIDDetails = servicePlanObj.readIDByTypeAndStatus(
        servicePlanTypeAndStatusKey);

      if (servicePlanIDDetails.servicePlanID > 0) {
        caseTypeStatement = IndexSearchConst.kServicePlanID
          + CuramConst.gkColon
          + Long.toString(servicePlanIDDetails.servicePlanID);
      } else {
        caseTypeStatement = IndexSearchConst.kServicePlanID
          + CuramConst.gkColon + CuramConst.gkBackslash
          + Long.toString(servicePlanIDDetails.servicePlanID);
      }

    } else if (category.equals(CASETYPECODE.APPEAL)) {

      caseTypeStatement = IndexSearchConst.kAppealType + CuramConst.gkColon
        + type;

    }

    return caseTypeStatement;

  }

  // ___________________________________________________________________________
  /**
   * Crates query for investigation lucene index search for the specified search
   * criteria.
   *
   * @param searchCriteria data on which the query will be based
   *
   * @return The Curam query for investigation lucene index search
   */
  public static CuramQuery createInvestigationSearchQuery(
    InvestigationSearchCriteria searchCriteria) throws AppException,
      InformationalException {

    final CuramQuery curamQuery = new CuramQuery();
    final SearchServiceKey searchServiceKey = new SearchServiceKey();
    final LuceneHelper luceneHelper = new LuceneHelper();
    final IndexParticipantSearch indexParticipantSearchObj = IndexParticipantSearchFactory.newInstance();
    final TextFieldDetails textFieldDetails = new TextFieldDetails();

    searchServiceKey.searchServiceId = IndexSearchConst.kCaseSearch;

    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

    // Add the fields which will be used to store the results to the query
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kCaseReference));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kStartDate));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kInvestigationType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kInvestigationSubtype));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kCaseID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kStatusCode));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleName));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(
        IndexSearchConst.kResolutionConfigurationID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(
        IndexSearchConst.kAllegationParticipantCount));

    curamQuery.text = IndexSearchConst.kCaseTypeCode + CuramConst.gkColon
      + CASETYPECODE.INVESTIGATIONCASE;

    if (searchCriteria.caseReference.length() == CuramConst.gkZero) {

      // Add date ranges if required
      if (!searchCriteria.startDateFrom.isZero()
        || !searchCriteria.startDateTo.isZero()) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kStartDate + CuramConst.gkColon;
        curamQuery.text += "[";

        if (!searchCriteria.startDateFrom.isZero()) {
          curamQuery.text += Locale.getFormattedDate(
            searchCriteria.startDateFrom, Locale.Date_ymd);
        } else {
          curamQuery.text += Locale.getFormattedDate(IndexSearchConst.kLowDate,
            Locale.Date_ymd);
        }

        curamQuery.text += " TO ";

        if (!searchCriteria.startDateTo.isZero()) {
          curamQuery.text += Locale.getFormattedDate(searchCriteria.startDateTo,
            Locale.Date_ymd);
        } else {
          curamQuery.text += Locale.getFormattedDate(IndexSearchConst.kHighDate,
            Locale.Date_ymd);
        }

        curamQuery.text += "]";

      }

      if (!searchCriteria.endDateFrom.isZero()
        || !searchCriteria.endDateTo.isZero()) {

        String endDateStatement = IndexSearchConst.kEndDate
          + CuramConst.gkColon + "[";

        if (!searchCriteria.endDateFrom.isZero()) {
          endDateStatement += Locale.getFormattedDate(
            searchCriteria.endDateFrom, Locale.Date_ymd);
        } else {
          endDateStatement += Locale.getFormattedDate(IndexSearchConst.kLowDate,
            Locale.Date_ymd);
        }

        endDateStatement += " TO ";

        if (!searchCriteria.endDateTo.isZero()) {
          endDateStatement += Locale.getFormattedDate(searchCriteria.endDateTo,
            Locale.Date_ymd);
        } else {
          endDateStatement += Locale.getFormattedDate(
            IndexSearchConst.kHighDate, Locale.Date_ymd);
        }

        endDateStatement += "]";

        curamQuery.text += IndexSearchConst.kANDString;

        // Add null value for end date
        if (searchCriteria.endDateTo.isZero()) {
          curamQuery.text += "(" + endDateStatement
            + IndexSearchConst.kORString + IndexSearchConst.kEndDate
            + CuramConst.gkColon
            + Locale.getFormattedDate(Date.kZeroDate, Locale.Date_ymd) + ")";
        } else {
          curamQuery.text += endDateStatement;
        }
      }

      if (searchCriteria.statusList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList statusList = StringUtil.tabText2StringListWithTrim(
          searchCriteria.statusList);

        for (int i = 0; i < statusList.size(); i++) {

          if (statusList.item(i).length() > 0) {
            curamQuery.text += IndexSearchConst.kStatusCode
              + CuramConst.gkColon + statusList.item(i)
              + IndexSearchConst.kORString;
          }
        }
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";
      }

      if (searchCriteria.typeList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList typeList = StringUtil.tabText2StringListWithTrim(
          searchCriteria.typeList);

        for (int i = 0; i < typeList.size(); i++) {

          if (typeList.item(i).length() > CuramConst.gkZero) {
            curamQuery.text += IndexSearchConst.kInvestigationType
              + CuramConst.gkColon + typeList.item(i)
              + IndexSearchConst.kORString;
          }
        }
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";
      }

      if (searchCriteria.subtypeList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList subtypeList = StringUtil.tabText2StringListWithTrim(
          searchCriteria.subtypeList);

        for (int i = 0; i < subtypeList.size(); i++) {

          if (subtypeList.item(i).length() > CuramConst.gkZero) {
            curamQuery.text += IndexSearchConst.kInvestigationSubtype
              + CuramConst.gkColon + subtypeList.item(i)
              + IndexSearchConst.kORString;
          }
        }
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";
      }

      // search for case primary client concern role id is left for backward
      // compatibility
      if (searchCriteria.concernRoleID != 0L) {
        curamQuery.text += IndexSearchConst.kANDString;
        if (searchCriteria.concernRoleID > 0) {
          curamQuery.text += IndexSearchConst.kConcernRoleID
            + CuramConst.gkColon + searchCriteria.concernRoleID;

        } else {
          curamQuery.text += IndexSearchConst.kConcernRoleID
            + CuramConst.gkColon + CuramConst.gkBackslash
            + searchCriteria.concernRoleID;
        }
      }

      if (searchCriteria.clientFirstName.length() == 0
        && searchCriteria.clientSurname.length() == 0
        && searchCriteria.alternateID.length() == 0) {
        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
          + IndexSearchConst.kIndexTrueInd;
      }

      if (searchCriteria.clientFirstName.length() > 0) {
        curamQuery.text += IndexSearchConst.kANDString;
        textFieldDetails.fieldName = IndexSearchConst.kConcernRoleFirstName;
        textFieldDetails.fieldValue = searchCriteria.clientFirstName;
        // BEGIN, CR00338327, ZV
        if (searchCriteria.clientFirstName.length() > 1
          || !searchCriteria.clientSurname.isEmpty()) {
          textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
        }
        // END, CR00338327
        curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
      }

      if (searchCriteria.clientSurname.length() > 0) {
        curamQuery.text += IndexSearchConst.kANDString;
        textFieldDetails.fieldName = IndexSearchConst.kConcernRoleSurname;
        textFieldDetails.fieldValue = searchCriteria.clientSurname;
        // BEGIN, CR00338327, ZV
        if (searchCriteria.clientSurname.length() > 1) {
          textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
        }
        // END, CR00338327
        curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
      }

      if (searchCriteria.alternateIDType.length() > 0
        && searchCriteria.alternateID.length() > 0) {

        if (searchCriteria.alternateIDType.equals(
          CONCERNROLESEARCHALTERNATEID.REFERENCE_NUMBER)) {

          curamQuery.text += IndexSearchConst.kANDString;

          curamQuery.text += "(";
          textFieldDetails.fieldName = IndexSearchConst.kConcernRoleAlternateIDList;
          textFieldDetails.fieldValue = CONCERNROLEALTERNATEID.REFERENCE_NUMBER
            + CuramConst.gkPipeDelimiter + searchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;

          curamQuery.text += IndexSearchConst.kORString;
          textFieldDetails.fieldValue = CONCERNROLEALTERNATEID.PERSON_REFERENCE_NUMBER
            + CuramConst.gkPipeDelimiter + searchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;

          curamQuery.text += IndexSearchConst.kORString;
          textFieldDetails.fieldValue = CONCERNROLEALTERNATEID.EMPLOYER_REFERENCE_NUMBER
            + CuramConst.gkPipeDelimiter + searchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
          curamQuery.text += ")";

        } else {
          curamQuery.text += IndexSearchConst.kANDString;

          textFieldDetails.fieldName = IndexSearchConst.kConcernRoleAlternateIDList;
          textFieldDetails.fieldValue = searchCriteria.alternateIDType
            + CuramConst.gkPipeDelimiter + searchCriteria.alternateID
            + CuramConst.gkPipeDelimiter;
          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
        }
      }

      if (searchCriteria.ownerList.length() > 0) {

        curamQuery.text += IndexSearchConst.kANDString;
        curamQuery.text += "(";

        final StringList ownerList = StringUtil.tabText2StringListWithTrim(
          searchCriteria.ownerList);

        for (int i = 0; i < ownerList.size(); i++) {

          if (ownerList.item(i).length() > 0) {
            if (Long.parseLong(ownerList.item(i)) > 0) {
              curamQuery.text += IndexSearchConst.kOwnerOrgObjectLinkID
                + CuramConst.gkColon + ownerList.item(i)
                + IndexSearchConst.kORString;
            } else {
              curamQuery.text += IndexSearchConst.kOwnerOrgObjectLinkID
                + CuramConst.gkColon + CuramConst.gkBackslash
                + ownerList.item(i) + IndexSearchConst.kORString;
            }
          }
        }
        // remove last OR from statement
        curamQuery.text = curamQuery.text.substring(CuramConst.gkZero,
          curamQuery.text.length() - IndexSearchConst.kORLength);
        curamQuery.text += ")";

      }

    } else {

      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kCaseReference;
      // BEGIN, CR00379119, SS
      final ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
      final SearchCriteriaString referenceKeyvalue = new SearchCriteriaString();

      referenceKeyvalue.string = searchCriteria.caseReference;
      textFieldDetails.fieldValue = participantSearchObj.formatReferenceFieldValue(referenceKeyvalue).fieldValue;
      // END, CR00379119
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }
    return curamQuery;
  }

  // ___________________________________________________________________________
  /**
   * Method to process investigation query results.
   *
   * @param searchServerResults Lucene index search query results
   *
   * @return The details of any investigation records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#ERR_CASESEARCH_MAXIMUM} -
   * If investigation search results exceeds case search maximum value.
   */
  public static InvestigationSearchDetailsList processInvestigationSearchQueryResults(
    SearchServerResults searchServerResults) throws AppException,
      InformationalException {

    final InvestigationSearchDetailsList result = new InvestigationSearchDetailsList();
    final List<Long> caseIDList = new ArrayList<Long>();

    int searchMaximum = 0;

    if (Configuration.getIntProperty(EnvVars.ENV_CASESEARCHMAXIMUM) != null) {
      searchMaximum = curam.util.resources.Configuration.getIntProperty(
        EnvVars.ENV_CASESEARCHMAXIMUM);
    } else {
      searchMaximum = EnvVars.ENV_CASESEARCHMAXIMUM_DEFAULT;
    }

    // BEGIN, CR00274833, ELG
    int numItems = 0;

    // If the list is greater that the case search maximum value
    if (searchServerResults.documents.dtls.size() > searchMaximum) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException ae = new AppException(
        GENERALSEARCH.INF_SEARCH_MAXIMUM_EXCEEDED);

      ae.arg(searchMaximum);
      ae.arg(searchServerResults.documents.dtls.size());
      ae.arg(searchMaximum);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);

      numItems = searchMaximum;

    } else {
      numItems = searchServerResults.documents.dtls.size();
    }

    // Convert the results into the result structure.
    for (int i = 0; i < numItems; i++) {
      // END, CR00274833

      InvestigationSearchDetails investigationSearchDetails = new InvestigationSearchDetails();

      final CuramDocument document = searchServerResults.documents.dtls.item(i);

      investigationSearchDetails = (InvestigationSearchDetails) CuramDocToResultStruct.convert(
        document, investigationSearchDetails, dictionary);

      if (investigationSearchDetails.resolutionConfigurationID != 0) {

        final ResolutionConfiguration resolutionConfigurationObj = ResolutionConfigurationFactory.newInstance();
        final ResolutionConfigurationKey resolutionConfigurationKey = new ResolutionConfigurationKey();

        resolutionConfigurationKey.resolutionConfigurationID = investigationSearchDetails.resolutionConfigurationID;

        final ResolutionConfigurationDtls resolutionConfigurationDtls = resolutionConfigurationObj.read(
          resolutionConfigurationKey);

        investigationSearchDetails.resolution = resolutionConfigurationDtls.resolution;

      }

      // BEGIN, CR00231382, ZV
      if (investigationSearchDetails.subtype.equals(IndexSearchConst.kNull)) {
        investigationSearchDetails.subtype = new String();
      }
      // END, CR00231382

      final curam.core.intf.DatabaseCaseSearch databaseCaseSearchObj = curam.core.fact.DatabaseCaseSearchFactory.newInstance();

      databaseCaseSearchObj.restrictInvestigationResults(
        investigationSearchDetails);

      if (!caseIDList.contains(investigationSearchDetails.caseID)
        && investigationSearchDetails.caseReference != null) {
        result.searchDtls.addRef(investigationSearchDetails);
        caseIDList.add(investigationSearchDetails.caseID);
      }

    }

    return result;
  }
  // END, CR00257963
}
