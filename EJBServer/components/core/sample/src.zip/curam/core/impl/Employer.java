/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.EMPLOYEREXAMINATIONCLASS;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.INDUSTRYTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.events.EMPLOYER;
import curam.core.fact.EmployerFactory;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.EmployerDatabaseSearchKey;
import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerDtlsList;
import curam.core.struct.EmployerIndustryType;
import curam.core.struct.EmployerKey;
import curam.core.struct.EmployerNextPmtDate;
import curam.core.struct.EmployerSnapshotDtls;
import curam.core.struct.EmployerSnapshotKey;
import curam.core.struct.IndustryType;
import curam.core.struct.ReadEmployerSummaryKey;
import curam.core.struct.SearchAllEmployersKey;
import curam.message.ENTEMPLOYERINSPECTION;
import curam.message.SUMMARYDETAILS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.GeneralConstants;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * A concern that employs one or more persons.
 *
 */
public abstract class Employer extends curam.core.base.Employer implements
  ParticipantEvidenceInterface {

  // BEGIN, CR00059195, POH
  protected static ThreadLocal<EmployerCache> cachedReadTL = new ThreadLocal<EmployerCache>();

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadTL
   */
  protected void clearCaches() {

    EmployerCache cache = cachedReadTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new EmployerCache();
      cachedReadTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Caching Details for Improved Performance
   */
  protected class EmployerCache {

    public EmployerCache() {

      map = new HashMap<Long, EmployerDtls>();
      transactionID = 0;
    }

    HashMap<Long, EmployerDtls> map;

    int transactionID;
  }

  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * Calculate the attribution dates for the case
   *
   * @param caseKey Contains the case identifier
   * @param evKey Contains the evidenceID and evidenceType
   *
   * @return The attribution dates for the entity
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    // return struct
    final AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00060591, POH
    // populate return struct
    attributedDateDetails.fromDate = curam.util.type.Date.kZeroDate;
    attributedDateDetails.toDate = curam.util.type.Date.kZeroDate;
    // END, CR00060591

    return attributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   *
   * @return Evidence details to be displayed on the list page
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // manipulation variables
    final EmployerKey employerKey = new EmployerKey();
    EmployerDtls employerDtls = new EmployerDtls();
    final curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();

    // populate the employerKey with passed in parameter
    employerKey.concernRoleID = key.evidenceID;

    // BEGIN, CR00060494, JPG
    try {
      // read employer details
      employerDtls = employerObj.read(employerKey);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot employer entity
      final EmployerSnapshotKey employerSnapshotKey = new EmployerSnapshotKey();
      final curam.core.intf.EmployerSnapshot employerSnapshotObj = curam.core.fact.EmployerSnapshotFactory.newInstance();

      // populate the employer snapshot key with passed in parameter
      employerSnapshotKey.employerSnapshotID = key.evidenceID;

      // read employer snapshot details
      final EmployerSnapshotDtls employerSnapshotDtls = employerSnapshotObj.read(
        employerSnapshotKey);

      employerDtls.assign(employerSnapshotDtls);
    }
    // END, CR00060494

    // BEGIN, CR00060475, POH
    // set start and end dates
    eiFieldsForListDisplayDtls.startDate = Date.kZeroDate;
    eiFieldsForListDisplayDtls.endDate = Date.kZeroDate;
    // END, CR00060475

    // Set the summary details.
    // BEGIN, CR00241068, CD
    final LocalisableString message = new LocalisableString(
      SUMMARYDETAILS.EMPLOYER_DETAILS);

    message.arg(employerDtls.tradingName);

    message.arg(
      CodeTable.getOneItem(INDUSTRYTYPE.TABLENAME, employerDtls.industryType));

    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068

    return eiFieldsForListDisplayDtls;

  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey Key for parent
   *
   * @return eiEvidenceKey - key for inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((EmployerDtls) dtls);

    eiEvidenceKey.evidenceID = ((EmployerDtls) dtls).concernRoleID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYER;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Employer evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((EmployerDtls) dtls);

    eiEvidenceKey.evidenceID = ((EmployerDtls) dtls).concernRoleID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYER;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify Employer evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   * @param dtls Employer entity details
   */
  @Override
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Employer entity key
    final EmployerKey employerKey = new EmployerKey();

    // Set entity key for modify
    employerKey.concernRoleID = key.evidenceID;

    // Modify details
    modify(employerKey, (EmployerDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Insert Employer evidence
   *
   * @param details - Employer entity details
   */
  @Override
  public void insert(EmployerDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Modify Employer evidence
   *
   * @param key - the uniqueID of the Employer record
   * @param details - Employer details
   */
  @Override
  public void modify(EmployerKey key, EmployerDtls details)
    throws AppException, InformationalException {

    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * Read all child record identifiers.
   *
   * @param key Evidence key for the parent evidence record
   *
   * @return A list of child record evidence keys for the parent
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read Employer evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   *
   * @return Employer or EmployerSnapshot entity details
   */
  @Override
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // manipulation variables
    final EmployerKey employerKey = new EmployerKey();
    EmployerDtls employerDtls = new EmployerDtls();
    final curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();

    // populate the employer key with passed in parameter
    employerKey.concernRoleID = key.evidenceID;

    try {
      // read employer details
      employerDtls = employerObj.read(employerKey);

      return employerDtls;

    } catch (final RecordNotFoundException recordNotFoundException) {

      // BEGIN, CR00060045, POH
      // If no record has been return for ID passed
      // read from the snapshot employer entity
      employerDtls = new EmployerDtls();
      final EmployerSnapshotKey employerSnapshotKey = new EmployerSnapshotKey();
      EmployerSnapshotDtls employerSnapshotDtls = new EmployerSnapshotDtls();
      final curam.core.intf.EmployerSnapshot employerSnapshotObj = curam.core.fact.EmployerSnapshotFactory.newInstance();

      // populate the employer snapshot key with passed in parameter
      employerSnapshotKey.employerSnapshotID = key.evidenceID;

      // read employer snapshot details
      employerSnapshotDtls = employerSnapshotObj.read(employerSnapshotKey);

      // replace primary key on concernRoleDtls with concernRoleSnapshot
      // primary key concernRoleSnapshotID
      employerDtls.assign(employerSnapshotDtls);
      employerDtls.concernRoleID = employerSnapshotDtls.concernRoleID;

      return employerDtls;
      // END, CR00060045
    }

  }

  // ___________________________________________________________________________
  /**
   * Selects all the records for validations
   *
   * @param evKey Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  @Override
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey Evidence key
   * @param evKeyList Evidence key list
   * @param mode Validate mode (insert, delete, applyChanges, modify)
   */
  @Override
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * Create a snapshot record of the Employer record
   *
   * @param key Evidence key
   *
   * @return EIEvidenceKey - the id of the newly created snapshot record
   */
  @Override
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // manipulation variables
    final EmployerKey employerKey = new EmployerKey();
    EmployerDtls employerDtls = new EmployerDtls();
    final EmployerSnapshotDtls employerSnapshotDtls = new EmployerSnapshotDtls();
    final curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();
    final curam.core.intf.EmployerSnapshot employerSnapshotObj = curam.core.fact.EmployerSnapshotFactory.newInstance();

    // populate the key with passed in parameter
    employerKey.concernRoleID = key.evidenceID;

    // read employer details
    employerDtls = employerObj.read(employerKey);

    // BEGIN, CR00060045, POH
    // populate snapshot details
    employerSnapshotDtls.assign(employerDtls);
    // END, CR00060045
    employerSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();

    // insert snapshot record
    employerSnapshotObj.insert(employerSnapshotDtls);

    // populate return struct
    eiEvidenceKey.evidenceID = employerSnapshotDtls.employerSnapshotID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYER;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Method removing participant evidence. This method is called when
   * participant evidence
   * is being cancelled
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - Modified evidence details
   */
  @Override
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    final EmployerKey employerKey = new EmployerKey();

    // Set entity key for modify
    employerKey.concernRoleID = key.evidenceID;

    // Modify details
    modify(employerKey, (EmployerDtls) dtls);

  }

  // END, CR00059195

  // __________________________________________________________________________
  /**
   * Performs a check if the employer's industry is high risk
   *
   * @param key employer concernRoleID for codetable check
   *
   * @return IndustryType with indicator set to true or false
   */
  @Override
  public IndustryType checkEmployerIndustry(EmployerKey key)
    throws AppException, InformationalException {

    // result
    final IndustryType industryType = new IndustryType();

    // contains codes to loop for match against
    curam.util.type.StringList highRiskIndCodes;

    // retrieved industry type for employer
    EmployerIndustryType employerIndustryType;

    // using concern to obtain industryType code from the code table
    employerIndustryType = readIndustryType(key);

    highRiskIndCodes = curam.util.type.CodeTable.getDistinctCodesForAllLanguages(
      curam.codetable.HIGHRISKINDUSTRY.TABLENAME);

    // setting output to false before high risk industry codetable is found
    industryType.highRiskIndustry = false;

    for (int i = 0; i < highRiskIndCodes.size(); i++) {

      if (employerIndustryType.industryType.equals(highRiskIndCodes.item(i))) {

        industryType.industryType = employerIndustryType.industryType;
        industryType.highRiskIndustry = true;
        break;

      }

    }

    return industryType;
  }

  // __________________________________________________________________________
  /**
   * Sets up details for the read to ensure the correct details are always
   * returned
   *
   * @param key details for the read
   */
  @Override
  protected void prereadSummaryDetails(ReadEmployerSummaryKey key)
    throws AppException, InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // __________________________________________________________________________
  /**
   * Sets up details for the search to ensure the correct details are always
   * returned
   *
   * @param key details for the search
   */
  @Override
  protected void presearchAllEmployers(SearchAllEmployersKey key)
    throws AppException, InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // __________________________________________________________________________
  /**
   * Sets up details for the search to ensure the correct details are always
   * returned
   *
   * @param key details for the search
   */
  @Override
  protected void presearchByNameOrAddress(EmployerDatabaseSearchKey key)
    throws AppException, InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchByNameOrAddress
   */
  @Override
  public curam.core.struct.EmployerSummaryDetailsList search(
    curam.core.struct.EmployerDatabaseSearchKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return EmployerFactory.newInstance().searchByNameOrAddress(key);
  }

  // ______________________________________________________________________________
  /**
   * Sets up details for the search to ensure the correct details are always
   * returned
   *
   * @param key details for the search
   */
  @Override
  protected void prereadSummaryDetailsByReferenceNumber(
    ReadEmployerSummaryKey key) throws AppException, InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // BEGIN, CR00020369, NG
  // __________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details details for the employer record.
   */

  @Override
  protected void postinsert(EmployerDtls details) throws AppException,
      InformationalException {

    // Synchronize the indexed staging database with the update to the Employer
    // entity.
    final curam.core.intf.IndexEmployerSynchronization indexEmployerSynchronization = curam.core.fact.IndexEmployerSynchronizationFactory.newInstance();

    indexEmployerSynchronization.insert(details);

  }

  // ___________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key employment key to modify
   * @param details for the employer record.
   */
  @Override
  protected void postmodify(EmployerKey key, EmployerDtls details)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the Employer
    // entity.
    final curam.core.intf.IndexEmployerSynchronization indexEmployerSynchronization = curam.core.fact.IndexEmployerSynchronizationFactory.newInstance();

    indexEmployerSynchronization.modify(key, details);

    // BEGIN, CR00092446, DG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = EMPLOYER.MODIFY_EMPLOYER;

    event.primaryEventData = details.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00092446

  }

  // END, CR00020369

  // BEGIN, CR00022078, CH
  // ___________________________________________________________________________
  /**
   * Preinsert function. Allows components to add additional
   * inspection/validation code through specifying the class which will preform
   * the additional processing
   *
   * @param details Employment details to be inspected
   */
  @Override
  protected void preinsert(EmployerDtls details) throws AppException,
      InformationalException {

    // validation object
    IEmployerExamination employerInspection = null;

    // object to be used to perform cast
    final List objList = getExaminationObjects();

    for (int i = 0; i < objList.size(); i++) {

      // Check that the class implements the required interface before casting
      if (objList.get(i) instanceof IEmployerExamination) {

        employerInspection = (IEmployerExamination) objList.get(i);

      } else {
        final AppException exc = new AppException(
          ENTEMPLOYERINSPECTION.ERR_EMPLOYER_VALIDATION_CLASS_INCORRECT_INTERFACE);

        exc.arg(objList.get(i).getClass().getName());
        exc.arg(IReassessmentConfiguration.class.getName());
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          exc, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }

      employerInspection.examineEmployerInsert(details);

    }
    // BEGIN, CR00076104, PMD
    // Convert employer details to upper case
    convertDetailsToUpper(details);
    // END, CR00076104
  }

  // ___________________________________________________________________________
  /**
   * Premodify function. Allows components to add additional
   * inspection/validation code through specifying the class which will preform
   * the additional processing
   *
   * @param key The unique identifier of the record being modified
   * @param details Employment details to be inspected
   */
  @Override
  protected void premodify(EmployerKey key, EmployerDtls details)
    throws AppException, InformationalException {

    // validation object
    IEmployerExamination employerInspection = null;

    // object to be used to perform cast
    final List objList = getExaminationObjects();

    for (int i = 0; i < objList.size(); i++) {

      // Check that the class implements the required interface before casting
      if (objList.get(i) instanceof IEmployerExamination) {

        employerInspection = (IEmployerExamination) objList.get(i);

      } else {
        final AppException exc = new AppException(
          ENTEMPLOYERINSPECTION.ERR_EMPLOYER_VALIDATION_CLASS_INCORRECT_INTERFACE);

        exc.arg(objList.get(i).getClass().getName());
        exc.arg(IReassessmentConfiguration.class.getName());
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          exc, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

      employerInspection.examineEmployerModify(key, details);

    }
    // BEGIN, CR00076104, PMD
    // Convert employer details to upper case
    convertDetailsToUpper(details);
    // END, CR00076104
  }

  // ___________________________________________________________________________
  /**
   * Private function which inspects the EMPLOYERINSPECTIONCLASS codetable.
   * Each entry description string should be a fully qualified classname.
   * We then create an instance of each class specified and return each class
   * object through a list object.
   *
   * @return list A list of class objects
   */
  // BEGIN, CR00198672, VK
  protected List getExaminationObjects() throws AppException,
      InformationalException {

    // END, CR00198672
    // return object
    final List list = new ArrayList();

    // Codetable maintenance business process object

    // BEGIN, CR00101928, BD
    // Get locale value
    final String locale = curam.util.transaction.TransactionInfo.getProgramLocale();

    final String[] codeTableItems = curam.util.type.CodeTable.getAllCodes(
      EMPLOYEREXAMINATIONCLASS.TABLENAME, locale);

    // The code table amounts to a list of registered listeners.
    // Each item in the code table is instantiated in turn and
    // asked if cases based on the specified product should be reassessed
    // forward
    // to the last active decision.

    // There is currently no caching of the instantiated objects however for
    // performance
    // purposes it may be something we want to look at in the future.
    for (int i = 0; i < codeTableItems.length; i++) {

      final String className = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(EMPLOYEREXAMINATIONCLASS.TABLENAME,
        codeTableItems[i], TransactionInfo.getProgramLocale());

      // END, CR00163098, JC

      // END, CR00101928

      // BEGIN, CR00053248, GM
      if (!className.equals(GeneralConstants.kNull)) {
        // END, CR00053248

        Class cls;
        Object obj = new Object();

        // Create the class instance
        try {
          cls = Class.forName(className);
        } catch (final ClassNotFoundException e) {
          final AppException exc = new AppException(
            ENTEMPLOYERINSPECTION.ERR_EMPLOYER_VALIDATION_CLASS_DOES_NOT_EXIST);

          exc.arg(className);
          throw exc;
        }

        // Create an instance of the class
        try {
          obj = cls.newInstance();
        } catch (final Exception e) {
          final AppException exc = new AppException(
            ENTEMPLOYERINSPECTION.ERR_EMPLOYER_VALIDATION_CLASS_COULD_NOT_BE_CREATED);

          exc.arg(className);
          throw exc;
        }

        list.add(obj);
      }
    }
    return list;
  }

  // END, CR00022078

  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID and
   * status.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing an
   * evidenceID/evidenceType pair.
   */
  @Override
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060407, SSK
    // BEIGN, CR00066203, AC
    // return struct
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();
    // Check if a record exists for this concern.

    // manipulation variables
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();
    EmployerDtlsList employerDtlsList = new EmployerDtlsList();
    final curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();
    EIEvidenceKey eiEvidenceKey;

    // populate the key with passed in parameter
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of employer records for concernRole
    employerDtlsList = employerObj.searchByConcernRoleIDAndStatus(
      concernRoleIDStatusCodeKey);

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < employerDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = employerDtlsList.dtls.item(i).concernRoleID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYER;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    // END, CR00066203
    return eiEvidenceKeyList;
    // END, CR00060407
  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute
   * that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the
   * attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  @Override
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key,
    Object dtls) throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    final ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create EmployerDtls structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    EmployerDtls employerCompareDtls1 = new EmployerDtls();
    final EmployerDtls employerCompareDtls2 = new EmployerDtls();

    try {

      final curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();

      final EmployerKey employerKey = new EmployerKey();

      employerKey.concernRoleID = key.evidenceID;

      // read Employer details
      employerCompareDtls1 = employerObj.read(employerKey);

      // Populate the Employer struct that will be compared against
      employerCompareDtls2.assign((EmployerDtls) dtls);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot Employer entity
      final curam.core.intf.EmployerSnapshot employerSnapshotObj = curam.core.fact.EmployerSnapshotFactory.newInstance();

      final EmployerSnapshotKey employerSnapshotKey = new EmployerSnapshotKey();

      // populate the Employer snapshot key with passed in parameter
      employerSnapshotKey.employerSnapshotID = key.evidenceID;

      // Read the Employer snapshot details
      employerCompareDtls2.assign(employerSnapshotObj.read(employerSnapshotKey));

      // Populate the Employer struct that will be compared against
      employerCompareDtls1.assign((EmployerDtls) dtls);
    }

    if (!employerCompareDtls1.registeredName.equals(
      employerCompareDtls2.registeredName)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.REGISTEREDNAME);
    }
    if (employerCompareDtls1.concernRoleID
      != employerCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!employerCompareDtls1.tradingName.equals(
      employerCompareDtls2.tradingName)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TRADINGNAME);
    }
    if (!employerCompareDtls1.industryType.equals(
      employerCompareDtls2.industryType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.INDUSTRYTYPE);
    }
    if (!employerCompareDtls1.companyType.equals(
      employerCompareDtls2.companyType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMPANYTYPE);
    }
    if (!employerCompareDtls1.businessDesc.equals(
      employerCompareDtls2.businessDesc)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.BUSINESSDESC);
    }
    if (!employerCompareDtls1.specialInterestCode.equals(
      employerCompareDtls2.specialInterestCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.SPECIALINTERESTCODE);
    }
    if (employerCompareDtls1.exemptionInd != employerCompareDtls2.exemptionInd) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.EXEMPTIONIND);
    }
    if (!employerCompareDtls1.statusCode.equals(employerCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (!employerCompareDtls1.comments.equals(employerCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }
    if (!employerCompareDtls1.primaryAlternateID.equals(
      employerCompareDtls2.primaryAlternateID)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYALTERNATEID);
    }
    if (employerCompareDtls1.numberPermanentStaff
      != employerCompareDtls2.numberPermanentStaff) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.NUMBERPERMANENTSTAFF);
    }
    if (employerCompareDtls1.numberCasualStaff
      != employerCompareDtls2.numberCasualStaff) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.NUMBERCASUALSTAFF);
    }
    if (employerCompareDtls1.pinNumber != employerCompareDtls2.pinNumber) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PINNUMBER);
    }
    if (!employerCompareDtls1.paymentFrequency.equals(
      employerCompareDtls2.paymentFrequency)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PAYMENTFREQUENCY);
    }
    if (!employerCompareDtls1.nextPaymentDate.equals(
      employerCompareDtls2.nextPaymentDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.NEXTPAYMENTDATE);
    }
    if (!employerCompareDtls1.currencyType.equals(
      employerCompareDtls2.currencyType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CURRENCYTYPE);
    }
    if (!employerCompareDtls1.methodOfPmtCode.equals(
      employerCompareDtls2.methodOfPmtCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.METHODOFPMTCODE);
    }
    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of
   * an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  @Override
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set a indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // END, CR00069014

  // BEGIN, CR00076104, PMD
  // ___________________________________________________________________________
  /**
   * Method to convert the employer details to upper case
   *
   * @param details the employer details
   */
  @Override
  public void convertDetailsToUpper(EmployerDtls details)
    throws AppException, InformationalException {

    // Convert the tradingName and registeredName fields to upper case
    details.upperTradingName = details.tradingName.toUpperCase();
    details.upperRegisteredName = details.registeredName.toUpperCase();
  }

  // END, CR00076104

  // __________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key Identifier of the record that has been modified
   * @param details The updated payment details for the record
   */
  @Override
  protected void postmodifyNextPmtDate(EmployerKey key,
    EmployerNextPmtDate details) throws AppException, InformationalException {// Insert
    // post
    // modify
    // implementation
    // here.
  }

  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    return new Date();
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    return new Date();
  }
  // END, CR002204022
}
