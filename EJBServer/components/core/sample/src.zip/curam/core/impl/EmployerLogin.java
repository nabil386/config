/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmployerAltSearchDetails;
import curam.core.struct.EmployerAltSearchKey;
import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerKey;
import curam.core.struct.EmployerLoginDetails;
import curam.core.struct.EmployerValidDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * It will simply do a read of the employer record and check the PIN
 * number against the one supplied.
 *
 */
public abstract class EmployerLogin extends curam.core.base.EmployerLogin {

  // ___________________________________________________________________________
  /**
   * This operation will be used by eCuram to verify the employer for Login
   * purposes. It will simply do a read of the employer record and check the
   * PIN number against the one supplied. It will pass back the concernRoleName
   * and the concernRoleID of the employer.
   *
   * @param loginDetails Structure to contain employer login details
   *
   * @return Structure to contain valid employer details
   */
  @Override
  public EmployerValidDetails validateEmployer(
    EmployerLoginDetails loginDetails) throws AppException,
      InformationalException {

    // employerValidDetails variable
    final EmployerValidDetails employerValidDetails = new EmployerValidDetails();

    // employer manipulation variables
    final curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();
    final EmployerKey employerKey = new EmployerKey();
    final EmployerAltSearchKey employerAltSearchKey = new EmployerAltSearchKey();
    EmployerAltSearchDetails employerAltSearchDetails;
    EmployerDtls employerDtls;

    // set employerAltSearchKey
    employerAltSearchKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    employerAltSearchKey.assign(loginDetails);

    // read employer
    try {
      employerAltSearchDetails = employerObj.readByAlternateID(
        employerAltSearchKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      final AppException ae = new AppException(
        curam.message.BPOEMPLOYERLOGIN.ERR_EMPLOYER_RNFE_ALTERNATE_ID);

      ae.arg(loginDetails.alternateID);
      throw ae;
    } catch (final curam.util.exception.MultipleRecordException e) {
      final AppException ae = new AppException(
        curam.message.BPOEMPLOYERLOGIN.ERR_EMPLOYER_MRE_ALTERNATE_ID);

      ae.arg(loginDetails.alternateID);
      throw ae;
    }

    // set key to read employer by concernRoleID
    employerKey.concernRoleID = employerAltSearchDetails.concernRoleID;

    // read employer by concernRoleID
    employerDtls = employerObj.read(employerKey);

    if (!employerDtls.pinNumber.equals(loginDetails.pinNumber)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERALCONCERN.ERR_PERSON_XRV_PIN_INCORRECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);

    } else {

      // concernRole manipulation variables
      final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      ConcernRoleDtls concernRoleDtls;

      // set key to read concernRole
      concernRoleKey.concernRoleID = employerAltSearchDetails.concernRoleID;

      // read concernRole
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // pass the details to output parameter from concernRoleDtls
      employerValidDetails.assign(concernRoleDtls);
    }

    return employerValidDetails;
  }

}
