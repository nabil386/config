/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.AssessmentConfigurationFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.AssessmentConfigurationDtls;
import curam.core.struct.AssessmentConfigurationKey;
import curam.core.struct.AssessmentConfigurationNonCancelKey;
import curam.core.struct.SearchByConfigurationBeforeKey;
import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This entity records the details of the Assessment Configurations
 * available in the system.
 *
 */
public abstract class AssessmentConfiguration extends curam.core.base.AssessmentConfiguration {

  // ___________________________________________________________________________
  /**
   * Called prior to modify to validate the data being modified. Specifically,
   * that there will not be any ScreeningAssessmentConfigs of the wrong status
   * or date, and that there are no Assessments which were created prior to any
   * new start date.
   *
   * @param key The Case Header details to validate against this screening.
   *
   * @param dtls The Screening details to validate for insert.
   */
  @Override
  protected void premodify(AssessmentConfigurationKey key,
    AssessmentConfigurationDtls dtls) throws AppException,
      InformationalException {

    // At the moment, the service layer provides
    // a check for whether we are canceled or not.
    final curam.core.sl.entity.intf.ScreeningAssessmentConfig screeningAssessmentConfigObj = curam.core.sl.entity.fact.ScreeningAssessmentConfigFactory.newInstance();
    RecordCount count;

    if (dtls.status.equals(curam.codetable.RECORDSTATUS.CANCELLED)) {

      final AssessmentConfigurationNonCancelKey assessmentConfigurationNonCancelKey = new AssessmentConfigurationNonCancelKey();

      assessmentConfigurationNonCancelKey.assessmentConfigurationID = key.assessmentConfigurationID;
      assessmentConfigurationNonCancelKey.canceledStatusCode = curam.codetable.RECORDSTATUS.CANCELLED;
      count = screeningAssessmentConfigObj.countByAssessmentConfigStatus(
        assessmentConfigurationNonCancelKey);

      if (count.count != 0) {

        final AppException e = new AppException(
          curam.message.GENERALSCREENINGCONFIGURATION.ERR_SCREENING_CONFIG_XRV_SAC_EXISTS_OUTSIDE_DATES);

        e.arg(count.count);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }

    }

    // The following checks are only mandatory if the start date is moving
    // forward or the end date is moving back. We perform them regardless.

    final SearchByConfigurationBeforeKey searchByConfigurationBeforeKey = new SearchByConfigurationBeforeKey();

    searchByConfigurationBeforeKey.assessmentConfigurationID = key.assessmentConfigurationID;
    searchByConfigurationBeforeKey.assessmentCreationDate = dtls.startDate;

    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();

    count = assessmentObj.countAssessmentsOfTypeBefore(
      searchByConfigurationBeforeKey);

    if (count.count != 0) {

      final AppException e = new AppException(
        curam.message.GENERALSCREENINGCONFIGURATION.ERR_SCREENING_CONFIG_XRV_ASSESSMENT_EXISTS_BEFORE_STARTDATE);

      e.arg(count.count);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    count = screeningAssessmentConfigObj.countByAssessmentConfigOutside(dtls);

    if (count.count != 0) {

      final AppException e = new AppException(
        curam.message.GENERALSCREENINGCONFIGURATION.ERR_SCREENING_CONFIG_XRV_SAC_EXISTS_OUTSIDE_DATES);

      e.arg(count.count);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readOverlap
   */
  @Override
  public curam.core.struct.AssessmentConfigurationKey searchForOverlap(
    curam.core.struct.AssessmentOverlapStruct key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return AssessmentConfigurationFactory.newInstance().readOverlap(key);
  }

  // BEGIN, CR00270875, MR
  /**
   * Generates an unique assessmentConfigurationID.
   *
   * @param details Assessment configuration details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final AssessmentConfigurationDtls details)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_ASSMENTBO;
    details.assessmentConfigurationID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
      uniqueIDKeySet);
  }
  // END, CR00270875

}
