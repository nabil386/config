/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.UniqueIDFactory;
import curam.core.struct.FinancialCalendarDtls;
import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class to perform operations on the Financial Calendar data.
 */
public abstract class FinancialCalendar extends curam.core.base.FinancialCalendar {

  /**
   * Set the unique id for the Financial Calendar primary key.
   *
   * @param details
   * The Financial Calendar details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(FinancialCalendarDtls details)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_FINANCIALCALENDAR;

    details.financialCalendarID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
      uniqueIDKeySet);
  }
}
