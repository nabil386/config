
/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2005, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import curam.codetable.BANKACCOUNTTYPE;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.core.events.CONCERNROLEBANKACCOUNT;
import curam.core.fact.ConcernRoleBankAccountFactory;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.BankAccountDtls;
import curam.core.struct.BankAccountRMDtlsList;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleBankAccountDtls;
import curam.core.struct.ConcernRoleBankAccountKey;
import curam.core.struct.ConcernRoleBankAccountSnapshotDtls;
import curam.core.struct.ConcernRoleBankAccountSnapshotKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.message.PARTICIPANTDATACASE;
import curam.message.SUMMARYDETAILS;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class ConcernRoleBankAccount extends curam.core.base.ConcernRoleBankAccount implements
  ParticipantEvidenceInterface {

  @Override
  protected void preinsert(ConcernRoleBankAccountDtls details)
    throws AppException, InformationalException {

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;

    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
    }
  }

  @Override
  protected void premodify(ConcernRoleBankAccountKey key,
    ConcernRoleBankAccountDtls details) throws AppException,
      InformationalException {

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;

    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
    }
  }

  // BEGIN, CR00059580, MMC
  protected class ConcernRoleBankAccountCache {

    public ConcernRoleBankAccountCache() {

      map = new HashMap<Long, ConcernRoleBankAccountDtls>();
      transactionID = 0;
    }

    HashMap<Long, ConcernRoleBankAccountDtls> map;

    int transactionID;
  }

  protected static ThreadLocal<ConcernRoleBankAccountCache> cachedReadDetailsTL = new ThreadLocal<ConcernRoleBankAccountCache>();

  // BEGIN, CR00065902, MMC

  // __________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details Contains entity details to insert
   */
  @Override
  public void insert(ConcernRoleBankAccountDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // __________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key Contains key to access entity details
   * @param details Contains details to modify
   */
  @Override
  public void modify(ConcernRoleBankAccountKey key,
    ConcernRoleBankAccountDtls details) throws AppException,
      InformationalException {

    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadDetailsTL
   */
  protected void clearCaches() {

    ConcernRoleBankAccountCache cache = cachedReadDetailsTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new ConcernRoleBankAccountCache();
      cachedReadDetailsTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // END, CR00059580

  // BEGIN, CR00059195, POH
  // BEGIN, CR00059580, MMC
  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the ConcernRoleBankAccount entity,
   * specifically for its use as a ParticipantEvidence.
   *
   * @param key the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  @Override
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    final EIEvidenceKey retEIEvidenceKey = new EIEvidenceKey();
    final curam.core.intf.ConcernRoleBankAccountSnapshot concernRoleBankAccountSnapshotObj = curam.core.fact.ConcernRoleBankAccountSnapshotFactory.newInstance();

    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();

    final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();

    concernRoleBankAccountKey.concernRoleBankAccountID = key.evidenceID;
    final ConcernRoleBankAccountDtls concernRoleBankAccountDtls = concernRoleBankAccountObj.read(
      concernRoleBankAccountKey);

    final ConcernRoleBankAccountSnapshotDtls concernRoleBankAccountSnapshotDtls = new ConcernRoleBankAccountSnapshotDtls();

    concernRoleBankAccountSnapshotDtls.assign(concernRoleBankAccountDtls);
    concernRoleBankAccountSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    concernRoleBankAccountSnapshotObj.insert(concernRoleBankAccountSnapshotDtls);

    // BEGIN, CR00068202, POH
    retEIEvidenceKey.evidenceID = concernRoleBankAccountSnapshotDtls.concernRoleBnkAccSnapshotID;
    retEIEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEBANKACC;
    // END, CR00068202

    return retEIEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls of entity to remove
   */
  @Override
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();

    // Set entity key for modify
    concernRoleBankAccountKey.concernRoleBankAccountID = key.evidenceID;

    // Modify details
    modify(concernRoleBankAccountKey, (ConcernRoleBankAccountDtls) dtls);
  }

  // END, CR00059195

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param caseKey
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return AttributedDateDetails
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();
    final AttributedDateDetails retAttributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final BankAccountDtls bankAccountDtls = readBankAccountDtls(evKey);

    // END, CR00240667

    retAttributedDateDetails.fromDate = bankAccountDtls.startDate;
    retAttributedDateDetails.toDate = bankAccountDtls.endDate;
    return retAttributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   *
   * @return Evidence details to be displayed on the list page
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final BankAccountDtls bankAccountDtls = readBankAccountDtls(key);

    // END, CR00240667

    // Set the start / end dates
    eiFieldsForListDisplayDtls.startDate = bankAccountDtls.startDate;
    eiFieldsForListDisplayDtls.endDate = bankAccountDtls.endDate;

    // Set the summary details.
    // BEGIN, CR00241068, CD
    final LocalisableString message = new LocalisableString(
      SUMMARYDETAILS.BANK_ACCOUNT);

    message.arg(
      CodeTable.getOneItem(BANKACCOUNTTYPE.TABLENAME, bankAccountDtls.typeCode));

    message.arg(bankAccountDtls.accountNumber);

    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068

    return eiFieldsForListDisplayDtls;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected BankAccountDtls readBankAccountDtls(EIEvidenceKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060473, MMC
    // ConcernRoleBankAccount entity key
    final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();

    // Read the ConcernRoleBankAccount entity to get display details
    concernRoleBankAccountKey.concernRoleBankAccountID = key.evidenceID;

    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();
    curam.core.struct.ConcernRoleBankAccountDtls concernRoleBankAccountDtls = new ConcernRoleBankAccountDtls();

    // BEGIN, CR00060494, JPG
    try {

      concernRoleBankAccountDtls = concernRoleBankAccountObj.read(
        concernRoleBankAccountKey);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot entity
      final curam.core.intf.ConcernRoleBankAccountSnapshot concernRoleBankAccountSnapshotObj = curam.core.fact.ConcernRoleBankAccountSnapshotFactory.newInstance();
      final curam.core.struct.ConcernRoleBankAccountSnapshotKey concernRoleBankAccountSnapshotKey = new curam.core.struct.ConcernRoleBankAccountSnapshotKey();

      // BEGIN, CR00068202, POH
      concernRoleBankAccountSnapshotKey.concernRoleBnkAccSnapshotID = key.evidenceID;
      // END, CR00068202
      final curam.core.struct.ConcernRoleBankAccountSnapshotDtls concernRoleBankAccountSnapshotDtls = concernRoleBankAccountSnapshotObj.read(
        concernRoleBankAccountSnapshotKey);

      concernRoleBankAccountDtls.assign(concernRoleBankAccountSnapshotDtls);

    }
    // END, CR00060494

    // Get the associated Bank Account start and end dates
    // These are the attribute details
    final curam.core.intf.BankAccount bankAccountObj = curam.core.fact.BankAccountFactory.newInstance();
    final curam.core.struct.BankAccountKey bankAccountKey = new curam.core.struct.BankAccountKey();

    bankAccountKey.bankAccountID = concernRoleBankAccountDtls.bankAccountID;

    final curam.core.struct.BankAccountDtls bankAccountDtls = bankAccountObj.read(
      bankAccountKey);

    return bankAccountDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey EIEvidenceKey for parent
   * @return the eiEvidenceKey to access the inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleBankAccountDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleBankAccountDtls) dtls).concernRoleBankAccountID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEBANKACC;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts ConcernRoleBankAccount evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleBankAccountDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleBankAccountDtls) dtls).concernRoleBankAccountID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEBANKACC;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls Object containing details of entity
   */
  @Override
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // ConcernRoleBankAccount entity key
    final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();

    // Set entity key for modify
    concernRoleBankAccountKey.concernRoleBankAccountID = key.evidenceID;

    // Modify details
    modify(concernRoleBankAccountKey, (ConcernRoleBankAccountDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * reads all ConcernRoleBankAccount Entities by its Parent ID
   *
   * @param key EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract
   * method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   *
   * @return the Object with the readEvidence details
   */
  @Override
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Snapshot object
    final curam.core.intf.ConcernRoleBankAccountSnapshot concernRoleBankAccountSnapshotObj = curam.core.fact.ConcernRoleBankAccountSnapshotFactory.newInstance();

    // BEGIN, CR00060473, MMC
    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();
    ConcernRoleBankAccountDtls concernRoleBankAccountDtls = new ConcernRoleBankAccountDtls();

    try {
      final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();

      concernRoleBankAccountKey.concernRoleBankAccountID = key.evidenceID;
      concernRoleBankAccountDtls = concernRoleBankAccountObj.read(
        concernRoleBankAccountKey);

      return concernRoleBankAccountDtls;

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot entity
      final curam.core.struct.ConcernRoleBankAccountSnapshotKey concernRoleBankAccountSnapshotKey = new curam.core.struct.ConcernRoleBankAccountSnapshotKey();

      // BEGIN, CR00068202, POH
      concernRoleBankAccountSnapshotKey.concernRoleBnkAccSnapshotID = key.evidenceID;
      // END, CR00068202

      final curam.core.struct.ConcernRoleBankAccountSnapshotDtls concernRoleBankAccountSnapshotDtls = concernRoleBankAccountSnapshotObj.read(
        concernRoleBankAccountSnapshotKey);

      concernRoleBankAccountDtls.assign(concernRoleBankAccountSnapshotDtls);
      return concernRoleBankAccountDtls;
    }
    // END, CR00060473, MMC
  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  @Override
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey EIEvidenceKey
   * @param evKeyList EIEvidenceKeyList
   * @param mode Validate Mode
   */
  @Override
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // END, CR00059580


  // ___________________________________________________________________________
  /**
   * @deprecated Since 8.0.3.0 method has been replaced by
   * readNumberOfOpenBankAccounts
   * that filter the end date is null or greater than the current day.
   * @superseded - replaced by countBankAccounts
   */
  @Override
  @Deprecated
  public curam.core.struct.BankAccountCount readNumberOfBankAccounts(
    final curam.core.struct.BankAccountCountKey bankAccountCountKey)
    throws curam.util.exception.AppException,
    curam.util.exception.InformationalException {

    return ConcernRoleBankAccountFactory.newInstance()
      .countBankAccounts(bankAccountCountKey);
  }

  // BEGIN, CR00059697, SK

  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing a
   * evidenceID/evidenceType pair.
   */
  @Override
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060375, MMC

    // return struct
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;
    BankAccountRMDtlsList bankAccountRMDtlsList = new BankAccountRMDtlsList();
    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();

    // BEGIN, CR00065999, SSK
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    // populate the concern role and status key
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of concernRoleAddress records for concernRole
    bankAccountRMDtlsList = concernRoleBankAccountObj.searchByConcernRoleIDAndStatus(
      concernRoleIDStatusCodeKey);

    // BEGIN, CR00065999

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < bankAccountRMDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = bankAccountRMDtlsList.dtls.item(i).concernRoleBankAccountID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEBANKACC;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    return eiEvidenceKeyList;
    // END, CR00060375, MMC

  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute
   * that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the
   * attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  @Override
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key,
    Object dtls) throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    final ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create ConcernRoleBankAccountDtls structs to allow a comparison of what
    // is
    // in the database and what is in the struct dtls.
    ConcernRoleBankAccountDtls concernRoleBankAccountCompareDtls1 = new ConcernRoleBankAccountDtls();
    final ConcernRoleBankAccountDtls concernRoleBankAccountCompareDtls2 = new ConcernRoleBankAccountDtls();

    try {

      final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();

      final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();

      concernRoleBankAccountKey.concernRoleBankAccountID = key.evidenceID;

      // read ConcernRoleBankAccount details
      concernRoleBankAccountCompareDtls1 = concernRoleBankAccountObj.read(
        concernRoleBankAccountKey);

      // Populate the ConcernRoleBankAccount struct that will be compared
      // against
      concernRoleBankAccountCompareDtls2.assign(
        (ConcernRoleBankAccountDtls) dtls);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot ConcernRoleBankAccount entity
      final curam.core.intf.ConcernRoleBankAccountSnapshot concernRoleBankAccountSnapshotObj = curam.core.fact.ConcernRoleBankAccountSnapshotFactory.newInstance();

      final ConcernRoleBankAccountSnapshotKey concernRoleBankAccountSnapshotKey = new ConcernRoleBankAccountSnapshotKey();

      // populate the ConcernRoleBankAccount snapshot key with passed in
      // parameter
      concernRoleBankAccountSnapshotKey.concernRoleBnkAccSnapshotID = key.evidenceID;

      // Read the ConcernRoleBankAccount snapshot details
      concernRoleBankAccountCompareDtls2.assign(
        concernRoleBankAccountSnapshotObj.read(
          concernRoleBankAccountSnapshotKey));

      // Populate the ConcernRoleBankAccount struct that will be compared
      // against
      concernRoleBankAccountCompareDtls1.assign(
        (ConcernRoleBankAccountDtls) dtls);
    }

    if (concernRoleBankAccountCompareDtls1.concernRoleBankAccountID
      != concernRoleBankAccountCompareDtls2.concernRoleBankAccountID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEBANKACCOUNTID);
    }
    if (concernRoleBankAccountCompareDtls1.concernRoleID
      != concernRoleBankAccountCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (concernRoleBankAccountCompareDtls1.bankAccountID
      != concernRoleBankAccountCompareDtls2.bankAccountID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.BANKACCOUNTID);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of
   * an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  @Override
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set a indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // __________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details The details of the record that has been inserted.
   */
  @Override
  protected void postinsert(ConcernRoleBankAccountDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00080234, MG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEBANKACCOUNT.INSERT_CONCERNROLEBANKACCOUNT;

    event.primaryEventData = details.concernRoleBankAccountID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00080234

  }

  // __________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key Identifier of the record that has been modified
   * @param details The updated details for the record
   */
  @Override
  protected void postmodify(ConcernRoleBankAccountKey key,
    ConcernRoleBankAccountDtls details) throws AppException,
      InformationalException {

    // BEGIN, CR00080234, MG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEBANKACCOUNT.MODIFY_CONCERNROLEBANKACCOUNT;

    event.primaryEventData = details.concernRoleBankAccountID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00080234
    // END, CR00069014
  }

  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return readBankAccountDtls(evKey).endDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return readBankAccountDtls(evKey).startDate;
    // END, CR00240667
  }

  // END, CR002204022

  // BEGIN, CR00346492, ZV
  // __________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details The details of the record that has been inserted.
   */
  @Override
  protected void postpdcInsert(ConcernRoleBankAccountDtls details)
    throws AppException, InformationalException {

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEBANKACCOUNT.INSERT_CONCERNROLEBANKACCOUNT;

    event.primaryEventData = details.concernRoleBankAccountID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // __________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key Identifier of the record that has been modified
   * @param details The updated details for the record
   */
  @Override
  protected void postpdcModify(ConcernRoleBankAccountKey key,
    ConcernRoleBankAccountDtls details) throws AppException,
      InformationalException {

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEBANKACCOUNT.MODIFY_CONCERNROLEBANKACCOUNT;

    event.primaryEventData = details.concernRoleBankAccountID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }
  // END, CR00346492

  /**
   * Method to count the number of bank accounts opened.
   *
   * @param key Contains the concernRoleID, recordStatus and date to filter the
   * bank accounts from the participant.
   *
   * @return number The number of bank accounts.
   */
  @Override
  public curam.core.struct.BankAccountCount readNumberOfOpenBankAccounts(
    final curam.core.struct.ActiveBankAccountCountKey key)
    throws curam.util.exception.AppException,
    curam.util.exception.InformationalException {

    return ConcernRoleBankAccountFactory.newInstance()
      .countOpenBankAccounts(key);
  }

}