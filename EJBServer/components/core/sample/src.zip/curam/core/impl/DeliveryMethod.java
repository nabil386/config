/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.METHODOFDELIVERY;
import curam.core.fact.UniqueIDFactory;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodDtlsList;
import curam.core.struct.UniqueIDKeySet;
import curam.message.BPODELIVERYMETHOD;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * The delivery methods and their respective offset values.
 */
public abstract class DeliveryMethod extends curam.core.base.DeliveryMethod {

  // ___________________________________________________________________________
  /**
   * Perform auto validate validation.
   *
   * @param details
   * delivery method details
   */
  @Override
  protected void autovalidate(DeliveryMethodDtls details)
    throws AppException, InformationalException {

    // deliveryMethod manipulation variables
    final curam.core.intf.DeliveryMethod deliveryMethodObj = curam.core.fact.DeliveryMethodFactory.newInstance();
    DeliveryMethodDtlsList deliveryMethodDtlsList;

    // read all delivery methods
    deliveryMethodDtlsList = deliveryMethodObj.readAll();

    for (int i = 0; i < deliveryMethodDtlsList.dtls.size(); i++) {

      if (deliveryMethodDtlsList.dtls.item(i).name.equals(details.name)
        && deliveryMethodDtlsList.dtls.item(i).deliveryMethodID
          != details.deliveryMethodID) {

        final curam.util.type.CodeTableItemIdentifier methodOfDelivery = new curam.util.type.CodeTableItemIdentifier(
          METHODOFDELIVERY.TABLENAME, details.name);

        final AppException e = new AppException(
          BPODELIVERYMETHOD.ERR_DELIVERYMETHOD_XRV_NAME_DRE);

        e.arg(methodOfDelivery);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

    }

  }

  // BEGIN, CR00260989, MR
  /**
   * Generates an unique deliveryMethodID.
   *
   * @param details
   * Delivery method details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final DeliveryMethodDtls details)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_PRODUCTBO;

    details.deliveryMethodID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
      uniqueIDKeySet);

  }
  // END, CR00260989
}
