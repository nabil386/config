/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2004, 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.UsersFactory;
import curam.core.intf.Users;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.struct.CreateTicketForDelayedReturnProcessingDetails;
import curam.core.struct.ProcessSupplierReturnLineItemsKey;
import curam.core.struct.ProcessSupplierReturnMessage;
import curam.core.struct.SupplierReturnHeaderDtls;
import curam.core.struct.SupplierReturnHeaderKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.NotFoundIndicator;


/**
 * Implements Delayed Supplier Return Processing
 *
 */
public abstract class DelayedSupplierReturnProc extends curam.core.base.DelayedSupplierReturnProc {

  // ___________________________________________________________________________
  /**
   * Method to process a supplier return
   *
   * @param ticketID the ID of the ticket which controls this processing.
   * @param inst_data_id the ID of the instance data associated with this
   * processing
   * @param flag If ticket closing is deferred
   */
  @Override
  public void processSupplierReturn(long ticketID, long inst_data_id,
    boolean flag) throws AppException, InformationalException {

    // clearCachedRecords object
    final curam.core.intf.ClearCachedRecords clearCachedRecordsObj = curam.core.fact.ClearCachedRecordsFactory.newInstance();

    // supplierReturnHeader manipulation variables
    final curam.core.intf.SupplierReturnHeader supplierReturnHeaderObj = curam.core.fact.SupplierReturnHeaderFactory.newInstance();
    final SupplierReturnHeaderKey supplierReturnHeaderKey = new SupplierReturnHeaderKey();
    SupplierReturnHeaderDtls supplierReturnHeaderDtls;

    // wmInstanceData manipulation variables
    final curam.core.intf.WMInstanceData wmInstanceDataObj = curam.core.fact.WMInstanceDataFactory.newInstance();
    final WMInstanceDataKey wmInstanceDataKey = new WMInstanceDataKey();
    WMInstanceDataDtls wmInstanceDataDtls;
    // BEGIN, CR00213430, AK
    final Users userObj = UsersFactory.newInstance();
    final UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale = TransactionInfo.getProgramLocale();

    // END, CR00213430

    // register the security implementation
    SecurityImplementationFactory.register();

    // assign key value to read wmInstanceData
    wmInstanceDataKey.wm_instDataID = inst_data_id;

    // read wmInstanceData
    wmInstanceDataDtls = wmInstanceDataObj.read(wmInstanceDataKey);

    // clear cached records
    clearCachedRecordsObj.clearAllCaches();

    // processServiceSupplierReturn manipulation variables
    final curam.core.intf.ProcessServiceSupplierReturn processSupplierReturnObj = curam.core.fact.ProcessServiceSupplierReturnFactory.newInstance();
    final ProcessSupplierReturnLineItemsKey procSupplRetrnLineItemKey = new ProcessSupplierReturnLineItemsKey();
    ProcessSupplierReturnMessage processSupplierReturnMessage;

    // set key to process supplier return headers
    procSupplRetrnLineItemKey.returnID = wmInstanceDataDtls.supplierReturnID;

    processSupplierReturnMessage = processSupplierReturnObj.process(
      procSupplRetrnLineItemKey);

    // if the returned message list is not empty an error has occurred, send a
    // ticket with the details of the error(s).
    if (processSupplierReturnMessage.messageText.length() > 0) {

      // ticket to be created instead of exception
      final CreateTicketForDelayedReturnProcessingDetails ticketDetails = new CreateTicketForDelayedReturnProcessingDetails();

      // assign ticket details to be processed
      ticketDetails.reason = processSupplierReturnMessage.messageText;
      ticketDetails.userName = wmInstanceDataDtls.enteredByID;

      // BEGIN, CR00213430, AK
      userKey.userName = ticketDetails.userName;
      usersDtls = userObj.read(nfIndicator, userKey);
      if (nfIndicator.isNotFound()) {
        userLocale = usersDtls.defaultLocale;
      }

      ticketDetails.subject = // BEGIN, CR00163471, JC
        curam.message.BPODELAYEDSUPPLIERRETURNPROC.INF_SUPPLIERRETURNPROCESSING_FAILED.getMessageText(
        userLocale);
      // END, CR00163471, JC
      // END, CR00213430
      // create ticket instead of throwing an exception
      createTicket(ticketDetails);

      // set key to read supplierReturnHeader
      supplierReturnHeaderKey.supplierReturnID = wmInstanceDataDtls.supplierReturnID;

      // read supplierReturnHeader
      supplierReturnHeaderDtls = supplierReturnHeaderObj.read(
        supplierReturnHeaderKey, true);

      // set status to 'Not Processed' for update
      supplierReturnHeaderDtls.statusCode = curam.codetable.SUPPLIERRETURNSTATUS.NOTPROCESSED;

      // update supplierReturnHeader
      supplierReturnHeaderObj.modify(supplierReturnHeaderKey,
        supplierReturnHeaderDtls);

      return;
    }

    // if no error occurred, modify the return header status and close ticket

    // set key to read supplierReturnHeader
    supplierReturnHeaderKey.supplierReturnID = wmInstanceDataDtls.supplierReturnID;

    // read supplierReturnHeader
    supplierReturnHeaderDtls = supplierReturnHeaderObj.read(
      supplierReturnHeaderKey, true);

    // set status to 'Processed' for update
    supplierReturnHeaderDtls.statusCode = curam.codetable.SUPPLIERRETURNSTATUS.PROCESSED;

    // update supplierReturnHeader
    supplierReturnHeaderObj.modify(supplierReturnHeaderKey,
      supplierReturnHeaderDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method to create a ticket.
   *
   * @param key struct containing a user name, reason and subject
   */
  @Override
  public void createTicket(CreateTicketForDelayedReturnProcessingDetails key)
    throws AppException, InformationalException {

    // notification manipulation variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

    standardManualDtls.dtls.taskDtls.subject = key.subject;
    standardManualDtls.dtls.taskDtls.comments = key.reason;
    // BEGIN, CR00023618, SK
    standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.delayedSupplierReturnTaskDefinitionID;
    // END, CR00023618
    standardManualDtls.dtls.assignDtls.assignmentID = key.userName;

    notificationObj.createWorkAllocationNotification(standardManualDtls);

  }

}
