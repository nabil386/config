/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.TERMTYPE;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.fact.SearchServiceFactory;
import curam.core.fact.ValidateLiabilityIssuedSearchDetailsFactory;
import curam.core.impl.util.CuramDocToResultStruct;
import curam.core.intf.ConcernRoleAlternateID;
import curam.core.intf.ValidateLiabilityIssuedSearchDetails;
import curam.core.sl.infrastructure.impl.IndexSearchConst;
import curam.core.struct.ConcernRoleAlternateIDDtlsStruct1;
import curam.core.struct.ConcernRoleAlternateIDDtlsStruct1List;
import curam.core.struct.ConcernRoleAlternateIDKey1;
import curam.core.struct.ConcernRoleAlternateIDRMKey;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.CuramDocument;
import curam.core.struct.CuramField;
import curam.core.struct.CuramQuery;
import curam.core.struct.CuramTerm;
import curam.core.struct.LiabilityIssuedInstrumentDtls;
import curam.core.struct.LiabilityIssuedSearchDtls;
import curam.core.struct.SearchForLiabilityIssuedInstrumentResult;
import curam.core.struct.SearchServerResults;
import curam.core.struct.SearchServiceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.NotFoundIndicator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Index Search for Liability Issued. This class uses the Lucene search engine
 * to search
 * indexes in the SEARCHSERVICEROW table that were previously created via events
 * triggered upon
 * an insert or modify of a Liability Instrument table.
 *
 */
public abstract class IndexSearchForLiabilityIssued extends curam.core.base.IndexSearchForLiabilityIssued {

  // HashMap to match attribute names in structs with the
  // names of the attributes on the LiabilityInstrument entity.
  protected final static HashMap<String, String> dictionary = new HashMap<String, String>();

  static {
    dictionary.put(IndexSearchConst.kLbyExternalRefNo,
      IndexSearchConst.kLiabInstrumentID);
  }

  // ___________________________________________________________________________
  /**
   * To retrieve a list of records from the liability instrument entity when
   * searched using the criteria passed in.
   *
   * @param liabSearchDtls Contains the details of the search criteria.
   *
   * @return Liability instrument details, financial search result summary and
   * search message details list.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SearchForLiabilityIssuedInstrumentResult searchForLiabilityIssuedInstrument(
    final LiabilityIssuedSearchDtls liabSearchDtls) throws AppException,
      InformationalException {

    final SearchForLiabilityIssuedInstrumentResult result = new SearchForLiabilityIssuedInstrumentResult();

    final ValidateLiabilityIssuedSearchDetails validateLiabilityIssuedSearchDetailsObj = ValidateLiabilityIssuedSearchDetailsFactory.newInstance();

    validateLiabilityIssuedSearchDetailsObj.validateInputDetails(liabSearchDtls);

    final LuceneHelper luceneHelper = new LuceneHelper();

    final CuramQuery curamQuery = new CuramQuery();

    // Long wrapper objects to convert values to string literals
    final List<ConcernRoleID> concernRoleIDs = retrieveConcernRoleIDs(
      liabSearchDtls);

    // If the alternateID entered is not valid and no concernRoleID is retrieved
    // return null to the screen to show invalid data was entered.
    if (liabSearchDtls.alternateID.length() != 0 && concernRoleIDs.size() == 0) {
      return result;
    }

    for (final ConcernRoleID concernRoleID : concernRoleIDs) {
      // Checking which search criteria was entered by the user and adding
      // them to a CuramQuery to be used by the GSS to search the indexes
      addTermIfExists(
        luceneHelper.createStandardTerm(IndexSearchConst.kConcernRoleID,
        String.valueOf(concernRoleID.concernRoleID), false),
        curamQuery);

      addTermIfExists(
        luceneHelper.createStandardTerm(IndexSearchConst.kConcernRoleName,
        liabSearchDtls.concernRoleName, true),
        curamQuery);

      // BEGIN, CR00311415, DJ
      addTermIfExists(
        luceneHelper.createDateTerm(IndexSearchConst.kPeriodFromDate,
        liabSearchDtls.periodFromDate),
        curamQuery);
      addTermIfExists(
        luceneHelper.createDateTerm(IndexSearchConst.kPeriodToDate,
        liabSearchDtls.periodToDate),
        curamQuery);
      addTermIfExists(
        luceneHelper.createStandardTerm(IndexSearchConst.kAmount,
        liabSearchDtls.amount.toString(), false),
        curamQuery);
      addTermIfExists(
        luceneHelper.createDateTerm(IndexSearchConst.kEffectiveDate,
        liabSearchDtls.effectiveDate),
        curamQuery);
      // END, CR00311415

      final SearchServiceKey searchServiceKey = new SearchServiceKey();

      searchServiceKey.searchServiceId = IndexSearchConst.kSearchForLiabilityIssued;
      // BEGIN, CR00112556, CW
      curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;
      // END, CR00112556

      // Specifying required result fields that need to be retrieved from
      // any index that matches the search parameters above.
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kConcernRoleID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kConcernRoleName));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kPeriodFromDate));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kPeriodToDate));
      curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kAmount));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kLiabInstrumentID));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kEffectiveDate));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kStatusCode));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kCurrencyTypeCode));
      curamQuery.fields.dtls.addRef(
        createResultField(IndexSearchConst.kFinInstructionID));

      final SearchServerResults searchResults = SearchServiceConnector.search(
        curamQuery);

      // Iterate through search result indexes retrieved by the
      // GSS and populate the return details struct.
      for (int i = 0; i < searchResults.documents.dtls.size(); i++) {

        LiabilityIssuedInstrumentDtls liabilityIssuedInstrumentDtls = new LiabilityIssuedInstrumentDtls();

        final CuramDocument document = searchResults.documents.dtls.item(i);

        liabilityIssuedInstrumentDtls = (LiabilityIssuedInstrumentDtls) CuramDocToResultStruct.convert(
          document, liabilityIssuedInstrumentDtls, dictionary);

        result.liabilityIssuedInstrumentDtlsList.dtls.addRef(
          liabilityIssuedInstrumentDtls);
      }
    }
    return result;
  }

  // _______________________________________________________________________________________
  /**
   * Based on the alternateID(Reference Number) passed as a search parameter
   * this method searches the CONCERNROLEALTERNATEID table to retrieve the
   * relevant concernRoleID.
   *
   * @param liabSearchDtls Contains the liability search details.
   *
   * @return concernRoleID Contains the concern role id.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected ConcernRoleID retrieveConcernRoleID(
    LiabilityIssuedSearchDtls liabSearchDtls) throws AppException,
      InformationalException {

    // END, CR00198672
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    if (liabSearchDtls.alternateID.length() > 0) {
      // BEGIN, CR00303410, DJ
      final NotFoundIndicator recordNotFoundInd = new NotFoundIndicator();
      final ConcernRoleAlternateIDKey1 concernRoleAlternateIDKey1 = new ConcernRoleAlternateIDKey1();

      concernRoleAlternateIDKey1.alternateID = liabSearchDtls.alternateID;
      ConcernRoleAlternateIDRMKey concernRoleAlternateIDRMKey = new ConcernRoleAlternateIDRMKey();

      ConcernRoleAlternateIDFactory.newInstance().readConcernRoleID(
        recordNotFoundInd, concernRoleAlternateIDKey1);
      // BEGIN, CR00306900, DJ
      if (recordNotFoundInd.isNotFound()) {
        concernRoleAlternateIDRMKey = null;
        concernRoleID.concernRoleID = 0;
      } // END, CR00306900
      else {
        concernRoleAlternateIDRMKey.concernRoleID = ConcernRoleAlternateIDFactory.newInstance().readConcernRoleID(recordNotFoundInd, concernRoleAlternateIDKey1).concernRoleID;
        concernRoleID.concernRoleID = concernRoleAlternateIDRMKey.concernRoleID;
      }
    }
    // END, CR00303410
    return concernRoleID;
  }

  // BEGIN, CR00393706, JMA
  // _______________________________________________________________________________________
  /**
   * Based on the alternateID(Reference Number) passed as a search parameter
   * this method searches the CONCERNROLEALTERNATEID table to retrieve the
   * relevant concernRoleIDs
   *
   * @param dtls Contains the payment received search details.
   * @return concernRoleID Contains the concern role id.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected List<ConcernRoleID> retrieveConcernRoleIDs(
    final LiabilityIssuedSearchDtls liabSearchDtls) throws AppException,
      InformationalException {

    final List<ConcernRoleID> concernRoleIDList = new ArrayList<ConcernRoleID>();
    ConcernRoleID concernRoleID;

    if (liabSearchDtls.alternateID.length() > 0) {

      final ConcernRoleAlternateIDKey1 concernRoleAlternateIDKey1 = new ConcernRoleAlternateIDKey1();

      concernRoleAlternateIDKey1.alternateID = liabSearchDtls.alternateID;

      final ConcernRoleAlternateID concernRoleAlternateIDObj = ConcernRoleAlternateIDFactory.newInstance();
      final ConcernRoleAlternateIDDtlsStruct1List concernRoleAlternateIDDtlsStruct1List = concernRoleAlternateIDObj.searchByAlternateID(
        concernRoleAlternateIDKey1);

      if (concernRoleAlternateIDDtlsStruct1List.dtls.size() == 0) {
        concernRoleID = new ConcernRoleID();
        concernRoleID.concernRoleID = 0;
      } else {

        for (final ConcernRoleAlternateIDDtlsStruct1 concernRoleAlternateIDDtlsStruct1 : concernRoleAlternateIDDtlsStruct1List.dtls) {
          concernRoleID = new ConcernRoleID();
          concernRoleID.concernRoleID = concernRoleAlternateIDDtlsStruct1.concernRoleID;
          concernRoleIDList.add(concernRoleID);

        }
      }
    }
    return concernRoleIDList;
  }

  // END, CR00393706

  // BEGIN, CR00198672, VK
  protected CuramField createResultField(final String field) {

    // END, CR00198672
    final CuramField result = new CuramField();

    result.name = field;
    return result;
  }

  /**
   * Adds a term to the curam query if the term exists.
   *
   * @param term Contains the term to be added.
   * @param curamQuery is the query to which the term is added.
   */
  // BEGIN, CR00198672, VK
  protected void addTermIfExists(final CuramTerm term,
    final CuramQuery curamQuery) {

    // END, CR00198672
    // Standard Term
    if (term.termType.equals(TERMTYPE.STANDARD)) {

      // Check if values have been entered in these fields.
      // If no valid value has been entered do not add attribute to
      // the CuramQuery.

      // check concernRoleID field
      if (term.stdTerm.field.equals(IndexSearchConst.kConcernRoleID)) {
        if (!term.stdTerm.value.equals(CuramConst.gkStringZero)
          && term.stdTerm.value.length() > 0) {
          curamQuery.terms.dtls.addRef(term);
        }
      } // check liabInstrumentID field
      else if (term.stdTerm.field.equals(IndexSearchConst.kLiabInstrumentID)) {
        if (!term.stdTerm.value.equals(CuramConst.gkStringZero)
          && term.stdTerm.value.length() > 0) {
          curamQuery.terms.dtls.addRef(term);
        }
      } // check amount field
      else if (term.stdTerm.field.equals(IndexSearchConst.kAmount)) {
        if (!term.stdTerm.value.equals(CuramConst.gkDecimalDoubleZero)
          && term.stdTerm.value.length() > 0) {
          curamQuery.terms.dtls.addRef(term);
        }
      } else if (!term.stdTerm.field.equals(IndexSearchConst.kConcernRoleID)
        || !term.stdTerm.field.equals(IndexSearchConst.kLiabInstrumentID)
        || !term.stdTerm.field.equals(IndexSearchConst.kAmount)) {
        if (term.stdTerm.value.length() > 0) {
          curamQuery.terms.dtls.addRef(term);
        }
      }

      // Date Term
    } else if (term.termType.equals(TERMTYPE.DATE)) {
      if (!term.dtTerm.value.isZero()) {
        curamQuery.terms.dtls.addRef(term);
      }
    } // BEGIN , CR00306900, DJ
    else if (term.termType.equals(TERMTYPE.DATERANGE)) {
      if (!term.dateRangeTerm.beginDate.isZero()
        && !term.dateRangeTerm.endDate.isZero()) {
        curamQuery.terms.dtls.addRef(term);
      }
    }
    // END, CR00306900

  }

}
