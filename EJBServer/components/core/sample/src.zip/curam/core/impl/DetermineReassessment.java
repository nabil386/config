/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.ReassessmentCaseID;
import curam.core.struct.ReassessmentIndicator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class is used to determine whether or not reassessment is required for
 * a particular case during financial processing.
 *
 */
public abstract class DetermineReassessment extends curam.core.base.DetermineReassessment {

  // ___________________________________________________________________________
  /**
   * To determine whether or not reassessment is required for a case during
   * financial processing. A True or False indicator will be returned.
   *
   * Note: There are certain products where evidence will remain the same
   * throughout the life time of the claim( e.g. O.A.P.) and therefore
   * it would is not necessary to reassess these cases on each payment
   * run, This file can facilitate a check to see if reassessment is
   * required for a certain case, and return a true or false indicator to
   * the financial processing.
   *
   * @param reassessmentCaseID the CaseID of the case being processed
   *
   * @return Indicator to determine if reassessment is required on the case
   */
  @Override
  public ReassessmentIndicator determineCaseReassessment(
    ReassessmentCaseID reassessmentCaseID) throws AppException,
      InformationalException {

    // reassessmentIndicator variable
    final ReassessmentIndicator reassessmentIndicator = new ReassessmentIndicator();

    // set reassessmentIndicator to true
    reassessmentIndicator.reassessIndicator = true;

    return reassessmentIndicator;
  }

}
