/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


/**
 * This class attempts to compare string values as doubles if this isn't
 * possible it falls back to compare them as strings.
 *
 */
public class CompareStringAsDouble {

  /**
   * Compare two string values.
   *
   * @param value1 First String value
   * @param value2 Second String value
   * @return 0 if the first and second values are equal, if they are not equal
   * a value of less than zero indicates that the first value was
   * lower, greater than zero if the second value was lower.
   */
  static public int compare(String value1, String value2) {

    double doubleValue1 = 0;
    double doubleValue2 = 0;

    try {
      doubleValue1 = Double.parseDouble(value1);
      doubleValue2 = Double.parseDouble(value2);
    } catch (final NumberFormatException e) {
      return value1.compareTo(value2);
    }

    return Double.compare(doubleValue1, doubleValue2);

  }

}
