/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.core.fact.EmployerFactory;
import curam.core.fact.InformationProviderFactory;
import curam.core.fact.MaintainFinancialCalendarFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProcessConcernTypePaymentFactory;
import curam.core.fact.ProductProviderFactory;
import curam.core.fact.ServiceSupplierFactory;
import curam.core.fact.UtilityFactory;
import curam.core.intf.Employer;
import curam.core.intf.InformationProvider;
import curam.core.intf.MaintainFinancialCalendar;
import curam.core.intf.Person;
import curam.core.intf.ProductProvider;
import curam.core.intf.ServiceSupplier;
import curam.core.intf.Utility;
import curam.core.sl.entity.fact.ExternalPartyFactory;
import curam.core.sl.entity.fact.RepresentativeFactory;
import curam.core.sl.entity.intf.ExternalParty;
import curam.core.sl.entity.intf.Representative;
import curam.core.sl.entity.struct.ExternalPartyDtls;
import curam.core.sl.entity.struct.RepresentativeDtls;
import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.struct.EmployerDtls;
import curam.core.struct.FinCalendarNextValidDate;
import curam.core.struct.FinancialProcessingDetails;
import curam.core.struct.InformationProviderDtls;
import curam.core.struct.IssueConcernPmtsProcessingDateSummary;
import curam.core.struct.IssueConcernPmtsSummary;
import curam.core.struct.PPnextPmtDateMOP;
import curam.core.struct.PPnextPmtDateRangeMOP;
import curam.core.struct.PaymentDateRangeTypeMOP;
import curam.core.struct.PersonDtls;
import curam.core.struct.ProductProviderDtls;
import curam.core.struct.SSnextPmtDateMOP;
import curam.core.struct.SSnextPmtDateRangeMOP;
import curam.core.struct.ServiceSupplierDtls;
import curam.core.struct.UtilNextPmtDateMOP;
import curam.core.struct.UtilNextPmtDateRangeMOP;
import curam.core.struct.UtilityDtls;
import curam.message.BPOISSUECONCERNPAYMENTS;
import curam.message.EXTERNALERPVALIDATIONS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.StringList;
import java.util.ArrayList;


/**
 * Code to issue payments to Service Suppliers, Product Providers, Utilities,
 * Persons, Employers, Information Providers, Representatives and External
 * Parties.
 *
 */
public abstract class IssueConcernPayments extends curam.core.base.IssueConcernPayments {

  protected static int gCommitCounter = 0;

  protected static int gTotUtilityProcessed = 0;

  protected static int gTotServiceSupplierProc = 0;

  protected static int gTotProductProviderProc = 0;

  protected static int gTotPersonProc = 0;

  protected static int gTotEmployerProc = 0;

  protected static int gTotInformationProviderProc = 0;

  protected static int gTotRepresentativeProc = 0;

  // BEGIN, CR00141662, CW
  protected static int gTotExternalPartyProc = 0;

  // END, CR00141662

  protected static final int kProcessCommitCount;

  protected static final boolean kCommitCountEnabled;

  // BEGIN, CR00071077, GM
  protected static String eRPAdapterEnabledErrMsg = CuramConst.gkEmpty;
  // END, CR00071077

  // ___________________________________________________________________________
  /**
   * Static initialization which looks up the commit count status from the
   * environment and sets the static members used to control the processing.
   */
  static {

    // Get the value of the Commit Count Enabled environment variable
    String commitCountEnabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_ISSUECONCERNPAYMENTS_COMMITCOUNTENABLED);

    // If it's not set, use the default
    if (commitCountEnabled == null) {

      commitCountEnabled = EnvVars.ENV_ISSUECONCERNPAYMENTS_COMMITCOUNTENABLED_DEFAULT;
    }

    // If commit count processing is on, look up the commit count value
    // i.e. the number of records to be processed before the results are
    // committed to the database.
    if (commitCountEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      kCommitCountEnabled = true;

      // Get the value of the Commit Count environment variable
      final String commitCount = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_ISSUECONCERNPAYMENTS_COMMITCOUNT);

      // If it's not set, use the default
      if (commitCount == null) {
        kProcessCommitCount = EnvVars.ENV_ISSUECONCERNPAYMENTS_COMMITCOUNT_DEFAULT;

      } else {
        // Convert string value to integer
        kProcessCommitCount = Integer.parseInt(commitCount);
      }

    } else {
      // Otherwise commit count processing is off
      kCommitCountEnabled = false;
      kProcessCommitCount = 0;
    }
  }

  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueUtilityPayment readmulti operation.
   */
  static class IssueUtilityPayment extends curam.util.dataaccess.ReadmultiOperation<UtilityDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Utility Payment readmulti operation.
     *
     * @param utilityDtls Utility Details.
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final UtilityDtls utilityDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForUtility(
        utilityDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotUtilityProcessed++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueServiceSupplierPayments readmulti operation.
   */
  static class IssueServiceSupplierPayments extends curam.util.dataaccess.ReadmultiOperation<ServiceSupplierDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Service Supplier readmulti operation.
     *
     * @param serviceSupplierDtls Service Supplier Details.
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final ServiceSupplierDtls serviceSupplierDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForServiceSupplier(
        serviceSupplierDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotServiceSupplierProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueProductProviderPayments readmulti operation.
   */
  static class IssueProductProviderPayments extends curam.util.dataaccess.ReadmultiOperation<ProductProviderDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Product Provider readmulti operation.
     *
     * @param productProviderDtls Product Provider Details.
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final ProductProviderDtls productProviderDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForProductProvider(
        productProviderDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotProductProviderProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssuePersonPayments readmulti operation.
   */
  static class IssuePersonPayments extends curam.util.dataaccess.ReadmultiOperation<PersonDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Person readmulti operation.
     *
     * @param personDtls Person Details.
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final PersonDtls personDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForPerson(
        personDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotPersonProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // BEGIN, CR00141662, CW
  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueExternalPartyPayments readmulti operation.
   */
  static class IssueExternalPartyPayments extends curam.util.dataaccess.ReadmultiOperation<ExternalPartyDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue External Party readmulti operation.
     *
     * @param externalPartyDtls External Party Details
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final ExternalPartyDtls externalPartyDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForExternalParty(
        externalPartyDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotExternalPartyProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // END, CR00141662

  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueEmployerPayments readmulti operation.
   */
  static class EmployerPayments extends curam.util.dataaccess.ReadmultiOperation<EmployerDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Employer readmulti operation.
     *
     * @param employerDtls Employer Details.
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final EmployerDtls employerDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForEmployer(
        employerDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotEmployerProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueInformationProviderPayments readmulti operation.
   */
  static class IssueInformationProviderPayments extends curam.util.dataaccess.ReadmultiOperation<InformationProviderDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Information Provider readmulti operation.
     *
     * @param infoProviderDtls Information Provider Details
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final InformationProviderDtls infoProviderDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForInformationProvider(
        infoProviderDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotInformationProviderProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }


  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * IssueRepresentativePayments readmulti operation.
   */
  static class IssueRepresentativePayments extends curam.util.dataaccess.ReadmultiOperation<RepresentativeDtls> {

    // BEGIN, CR00102258, CW
    // Contains details of the batch process being run
    IssueConcernPmtsProcessingDateSummary concernPaymentsSummary;

    // END, CR00102258

    // _________________________________________________________________________
    /**
     * Issue Representative readmulti operation.
     *
     * @param repDtls Representative Details.
     *
     * @return true
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final RepresentativeDtls repDtls)
      throws AppException, InformationalException {

      // BEGIN, CR00096556, DJ
      final curam.core.sl.struct.RepresentativeDtls representativeDtls = new curam.core.sl.struct.RepresentativeDtls();

      representativeDtls.dtls = repDtls;
      // END, CR00096556

      // BEGIN, CR00102258, CW
      final long paymentInstrumentCount = ProcessConcernTypePaymentFactory.newInstance().issueConcernPaymentForRepresentative(
        representativeDtls, concernPaymentsSummary);

      // END, CR00102258

      if (paymentInstrumentCount != 0) {
        if (kCommitCountEnabled) {
          gCommitCounter++;
        }
        gTotRepresentativeProc++;
      }

      if (kCommitCountEnabled && gCommitCounter >= kProcessCommitCount) {
        return false;
      } else {
        return true;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is used to call readmulti operations to issue payments to
   * utilities, service suppliers and product providers.
   *
   * @param pmtDateRangeTypeMOP Payment Date Range Type Method Of Payment
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void issueConcernTypePayment(
    final PaymentDateRangeTypeMOP pmtDateRangeTypeMOP) throws AppException,
      InformationalException {

    // BEGIN, CR00073939, JI
    final CuramBatch curamBatchObj = new CuramBatch();

    // If the ERP Adapter is enabled do not execute the batch job
    // and write an error message into the log file
    // BEGIN, CR00080249, CW
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()) {
      // END, CR00080249

      // Construct the error message
      curamBatchObj.setStartTime();
      // BEGIN, CR00077050, CW
      // BEGIN, CR00076996, KH
      eRPAdapterEnabledErrMsg = // BEGIN, CR00163471, JC
        EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_ENABLED_BATCH_JOB.getMessageText(
        ProgramLocale.getDefaultServerLocale())
          // END, CR00163471, JC
          + CuramConst.gkNewLine
          + CuramConst.gkNewLine;
      // END, CR00076996
      // END, CR00077050
      curamBatchObj.setEndTime();

    } else { // If the ERP Adapter is not enabled run the batch job
      // END, CR00073939

      final MaintainFinancialCalendar maintainFinCalendarObj = MaintainFinancialCalendarFactory.newInstance();

      // register the security implementation
      SecurityImplementationFactory.register();

      final IssueConcernPmtsProcessingDateSummary issueConcernPmtsSumm = getProcessingAndDateDetails(
        pmtDateRangeTypeMOP);

      final FinancialProcessingDetails finProcessingDetails = new FinancialProcessingDetails();

      finProcessingDetails.processingDate = issueConcernPmtsSumm.dateTo;

      // retrieving all codes from MethodOfDelivery codetable
      final StringList deliveryCodes = CodeTable.getDistinctCodesForAllLanguages(
        METHODOFDELIVERY.TABLENAME);

      // record the number of method of delivery codes so we know how many
      // we are dealing with
      final int numberOfMODCodes = deliveryCodes.size();

      // retrieving all codes from concern type codetable
      final StringList concernRoleTypes = CodeTable.getDistinctCodesForAllLanguages(
        CONCERNROLETYPE.TABLENAME);

      // record the number of concern type codes so we know how many we are
      // dealing with
      final int numOfConcernCodes = concernRoleTypes.size();

      // defining iterators
      int j = 0;

      curamBatchObj.setStartTime(); // set start time for batch processing

      for (int i = 0; i < numberOfMODCodes; i++) {

        if (pmtDateRangeTypeMOP.methodOfPayment.length() > 0) {

          issueConcernPmtsSumm.methodOfPayment = pmtDateRangeTypeMOP.methodOfPayment;

          i = numberOfMODCodes;

        } else {

          for (; j < deliveryCodes.size();) {

            final String methodOfDeliveryCode = deliveryCodes.item(j);

            issueConcernPmtsSumm.methodOfPayment = methodOfDeliveryCode;
            finProcessingDetails.deliveryMethodType = methodOfDeliveryCode;

            j++;
            break;
          }
        }

        // initialize counter
        int m = 0;

        final FinCalendarNextValidDate nextValidDate = maintainFinCalendarObj.getNextValidDate(
          finProcessingDetails);

        issueConcernPmtsSumm.dateTo = nextValidDate.nextValidDate;

        for (int p = 0; p < numOfConcernCodes; p++) {

          if (pmtDateRangeTypeMOP.concernTypeCode.length() > 0) {

            issueConcernPmtsSumm.concernTypeCode = pmtDateRangeTypeMOP.concernTypeCode;

            p = numOfConcernCodes;

          } else {

            for (; m < concernRoleTypes.size();) {

              final String concernRoleTypeCode = concernRoleTypes.item(m);

              issueConcernPmtsSumm.concernTypeCode = concernRoleTypeCode;

              m++;
              break;
            }
          }

          issueConcernPmtsByConcernTypeMOP1(issueConcernPmtsSumm);
        } // end for p
      } // end for i

      curamBatchObj.setEndTime(); // set end time for batch processing
    }

    // BEGIN, CR00157011, MC
    final int kStringBufferSize = 4096;
    final StringBuffer emailMessage = new StringBuffer(kStringBufferSize);
    final Object addressErrorObj = TransactionInfo.getFacadeScopeObject(
      CuramConst.gkAddressExpiryError);

    if (addressErrorObj != null) {
      final ArrayList<LocalisableString> errorList = (ArrayList<LocalisableString>) addressErrorObj;

      for (int i = 0; i < errorList.size(); i++) {
        final LocalisableString errorMsg = errorList.get(i);

        emailMessage.append(CuramConst.gkNewLine).append(errorMsg.getMessage()).append(
          CuramConst.gkNewLine);
      }
      TransactionInfo.setFacadeScopeObject(CuramConst.gkAddressExpiryError,
        null);
    }

    final Object bankAccountExpErrorObj = TransactionInfo.getFacadeScopeObject(
      CuramConst.gkBankAccountExpiryError);

    if (bankAccountExpErrorObj != null) {
      final ArrayList<LocalisableString> errorList = (ArrayList<LocalisableString>) bankAccountExpErrorObj;

      for (int i = 0; i < errorList.size(); i++) {
        final LocalisableString errorMsg = errorList.get(i);

        emailMessage.append(CuramConst.gkNewLine).append(errorMsg.getMessage()).append(
          CuramConst.gkNewLine);
      }
      TransactionInfo.setFacadeScopeObject(CuramConst.gkBankAccountExpiryError,
        null);
    }
    // END, CR00157011

    // BEGIN, CR00073939, JI
    emailMessage.append(eRPAdapterEnabledErrMsg);
    // END, CR00073939
    // Constructing the e-mail message
    final AppException totUtilityProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_UTILITY_PROCESSED);

    totUtilityProc.arg(gTotUtilityProcessed);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totUtilityProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException totServSuppProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_SERVSUPPLIER_PROCESSED);

    totServSuppProc.arg(gTotServiceSupplierProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totServSuppProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException totProdProvProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_PRODPROVIDER_PROCESSED);

    totProdProvProc.arg(gTotProductProviderProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totProdProvProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException totPersonProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_PERSON_PROCESSED);

    totPersonProc.arg(gTotPersonProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totPersonProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException totEmployerProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_EMPLOYER_PROCESSED);

    totEmployerProc.arg(gTotEmployerProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totEmployerProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException totInfoProvProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_INFOPROVIDER_PROCESSED);

    totInfoProvProc.arg(gTotInformationProviderProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totInfoProvProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException totRepProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_REPRESENTATIVE_PROCESSED);

    totRepProc.arg(gTotRepresentativeProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totRepProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    // BEGIN, CR00141662, CW
    final AppException totExternalPartyProc = new AppException(
      BPOISSUECONCERNPAYMENTS.INF_TOTAL_EXTERNALPARTY_PROCESSED);

    totExternalPartyProc.arg(gTotExternalPartyProc);
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(totExternalPartyProc.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236
    // END, CR00141662

    curamBatchObj.emailMessage = emailMessage.toString();

    // Constructing the E-mail Subject
    curamBatchObj.setEmailSubject(
      BPOISSUECONCERNPAYMENTS.INF_ISSUECONCERNPMTS_SUB);

    // Setting output log file id
    curamBatchObj.outputFileID = // BEGIN, CR00163471, JC
      BPOISSUECONCERNPAYMENTS.INF_ISSUE_CONC_PAYMENTS.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163471, JC

    // Sending the e-mail
    curamBatchObj.sendEmail();
  }

  // ___________________________________________________________________________
  /**
   * @param issueConcernPmtsSumm Issue Concern Payment Summary
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #issueConcernPmtsByConcernTypeMOP1(IssueConcernPmtsProcessingDateSummary)}
   * The new method takes a processing date as an additional parameter.
   *
   * To retrieve concern records for the specified concern role type who are
   * due for payment within the specified date range by the specified method of
   * payment and for these, issue payments that are due to them.
   */
  @Override
  @Deprecated
  public void issueConcernPmtsByConcernTypeMOP(
    final IssueConcernPmtsSummary issueConcernPmtsSumm) throws AppException,
      InformationalException {

    if (issueConcernPmtsSumm.concernTypeCode.equals(CONCERNROLETYPE.UTILITY)) {

      final Utility utilityObj = UtilityFactory.newInstance();
      final IssueUtilityPayment issUtilityPmt = new IssueUtilityPayment();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP utilNextPmtDateMOP = new UtilNextPmtDateMOP();

          utilNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          utilNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          utilityObj.searchByNextPmtDateMOP(utilNextPmtDateMOP, issUtilityPmt);

        } else {

          final UtilNextPmtDateRangeMOP utilNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          utilNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          utilNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          utilNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          utilityObj.searchByNextPmtDateRangeMOP(utilNextPmtDateRangeMOP,
            issUtilityPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.SERVICESUPPLIER)) {

      final ServiceSupplier serviceSupplierObj = ServiceSupplierFactory.newInstance();
      final IssueServiceSupplierPayments issSSPmt = new IssueServiceSupplierPayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final SSnextPmtDateMOP ssNextPmtDateMOP = new SSnextPmtDateMOP();

          ssNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          ssNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          serviceSupplierObj.searchByNextPmtDateMOP(ssNextPmtDateMOP, issSSPmt);

        } else {

          final SSnextPmtDateRangeMOP ssNextPmtDateRangeMOP = new SSnextPmtDateRangeMOP();

          ssNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          ssNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          ssNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          serviceSupplierObj.searchByNextPmtDateRangeMOP(ssNextPmtDateRangeMOP,
            issSSPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.PRODUCTPROVIDER)) {

      final ProductProvider prodProviderObj = ProductProviderFactory.newInstance();
      final IssueProductProviderPayments issProdProvPmt = new IssueProductProviderPayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final PPnextPmtDateMOP ppNextPmtDateMOP = new PPnextPmtDateMOP();

          ppNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          ppNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          prodProviderObj.searchByNextPmtDateMOP(ppNextPmtDateMOP,
            issProdProvPmt);

        } else {

          final PPnextPmtDateRangeMOP ppNextPmtDateRangeMOP = new PPnextPmtDateRangeMOP();

          ppNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          ppNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          ppNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          prodProviderObj.searchByNextPmtDateRangeMOP(ppNextPmtDateRangeMOP,
            issProdProvPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(CONCERNROLETYPE.PERSON)) {

      final Person personObj = PersonFactory.newInstance();
      final IssuePersonPayments issPersonPmt = new IssuePersonPayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final SSnextPmtDateMOP personNextPmtDateMOP = new SSnextPmtDateMOP();

          personNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          personNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          personObj.searchByNextPmtDateMOP(personNextPmtDateMOP, issPersonPmt);

        } else {

          final SSnextPmtDateRangeMOP personNextPmtDateRangeMOP = new SSnextPmtDateRangeMOP();

          personNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          personNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          personNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          personObj.searchByNextPmtDateRangeMOP(personNextPmtDateRangeMOP,
            issPersonPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(CONCERNROLETYPE.EMPLOYER)) {

      final Employer employerObj = EmployerFactory.newInstance();
      final EmployerPayments issEmployerPmts = new EmployerPayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP employerNextPmtDateMOP = new UtilNextPmtDateMOP();

          employerNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          employerNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          employerObj.searchByNextPmtDateMOP(employerNextPmtDateMOP,
            issEmployerPmts);

        } else {

          final UtilNextPmtDateRangeMOP employerNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          employerNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          employerNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          employerNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          employerObj.searchByNextPmtDateRangeMOP(employerNextPmtDateRangeMOP,
            issEmployerPmts);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.INFORMATIONPROVIDER)) {

      final InformationProvider infoProviderobj = InformationProviderFactory.newInstance();
      final IssueInformationProviderPayments issInfoProviderPayments = new IssueInformationProviderPayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP infoProvNextPmtDateMOP = new UtilNextPmtDateMOP();

          infoProvNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          infoProvNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          infoProviderobj.searchByNextPmtDateMOP(infoProvNextPmtDateMOP,
            issInfoProviderPayments);

        } else {

          final UtilNextPmtDateRangeMOP infoProvNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          infoProvNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          infoProvNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          infoProvNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          infoProviderobj.searchByNextPmtDateRangeMOP(
            infoProvNextPmtDateRangeMOP, issInfoProviderPayments);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    // Representative
    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.REPRESENTATIVE)) {

      final Representative representativeObj = RepresentativeFactory.newInstance();
      final IssueRepresentativePayments issRepresentativePayments = new IssueRepresentativePayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP representativeNextPmtDateMOP = new UtilNextPmtDateMOP();

          representativeNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          representativeNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          representativeObj.searchByNextPmtDateMOP(representativeNextPmtDateMOP,
            issRepresentativePayments);

        } else {

          final UtilNextPmtDateRangeMOP representativeNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          representativeNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          representativeNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          representativeNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          representativeObj.searchByNextPmtDateRangeMOP(
            representativeNextPmtDateRangeMOP, issRepresentativePayments);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    // BEGIN, CR00141662, CW
    // External Party
    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.EXTERNALPARTY)) {

      final ExternalParty externalPartyObj = ExternalPartyFactory.newInstance();
      final IssueExternalPartyPayments issExternalPartyPmt = new IssueExternalPartyPayments();

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final SSnextPmtDateMOP externalPartyNextPmtDateMOP = new SSnextPmtDateMOP();

          externalPartyNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          externalPartyNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          externalPartyObj.searchByNextPmtDateMOP(externalPartyNextPmtDateMOP,
            issExternalPartyPmt);

        } else {

          final SSnextPmtDateRangeMOP externalPartyNextPmtDateRangeMOP = new SSnextPmtDateRangeMOP();

          externalPartyNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          externalPartyNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          externalPartyNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          externalPartyObj.searchByNextPmtDateRangeMOP(
            externalPartyNextPmtDateRangeMOP, issExternalPartyPmt);

        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }
    // END, CR00141662
  }

  // ___________________________________________________________________________
  /**
   * To retrieve concern records for the specified concern role type who are
   * due for payment within the specified date range by the specified method of
   * payment and for these, issue payments that are due to them.
   *
   * @param issueConcernPmtsSumm Issue Concern Payment Summary
   */
  @Override
  public void issueConcernPmtsByConcernTypeMOP1(
    final IssueConcernPmtsProcessingDateSummary issueConcernPmtsSumm)
    throws AppException, InformationalException {

    if (issueConcernPmtsSumm.concernTypeCode.equals(CONCERNROLETYPE.UTILITY)) {

      final Utility utilityObj = UtilityFactory.newInstance();
      final IssueUtilityPayment issUtilityPmt = new IssueUtilityPayment();

      // BEGIN, CR00102258, CW
      issUtilityPmt.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP utilNextPmtDateMOP = new UtilNextPmtDateMOP();

          utilNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          utilNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          utilityObj.searchByNextPmtDateMOP(utilNextPmtDateMOP, issUtilityPmt);

        } else {

          final UtilNextPmtDateRangeMOP utilNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          utilNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          utilNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          utilNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          utilityObj.searchByNextPmtDateRangeMOP(utilNextPmtDateRangeMOP,
            issUtilityPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.SERVICESUPPLIER)) {

      final ServiceSupplier serviceSupplierObj = ServiceSupplierFactory.newInstance();
      final IssueServiceSupplierPayments issSSPmt = new IssueServiceSupplierPayments();

      // BEGIN, CR00102258, CW
      issSSPmt.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final SSnextPmtDateMOP ssNextPmtDateMOP = new SSnextPmtDateMOP();

          ssNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          ssNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          serviceSupplierObj.searchByNextPmtDateMOP(ssNextPmtDateMOP, issSSPmt);

        } else {

          final SSnextPmtDateRangeMOP ssNextPmtDateRangeMOP = new SSnextPmtDateRangeMOP();

          ssNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          ssNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          ssNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          serviceSupplierObj.searchByNextPmtDateRangeMOP(ssNextPmtDateRangeMOP,
            issSSPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.PRODUCTPROVIDER)) {

      final ProductProvider prodProviderObj = ProductProviderFactory.newInstance();
      final IssueProductProviderPayments issProdProvPmt = new IssueProductProviderPayments();

      // BEGIN, CR00102258, CW
      issProdProvPmt.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final PPnextPmtDateMOP ppNextPmtDateMOP = new PPnextPmtDateMOP();

          ppNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          ppNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          prodProviderObj.searchByNextPmtDateMOP(ppNextPmtDateMOP,
            issProdProvPmt);

        } else {

          final PPnextPmtDateRangeMOP ppNextPmtDateRangeMOP = new PPnextPmtDateRangeMOP();

          ppNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          ppNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          ppNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          prodProviderObj.searchByNextPmtDateRangeMOP(ppNextPmtDateRangeMOP,
            issProdProvPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(CONCERNROLETYPE.PERSON)) {

      final Person personObj = PersonFactory.newInstance();
      final IssuePersonPayments issPersonPmt = new IssuePersonPayments();

      // BEGIN, CR00102258, CW
      issPersonPmt.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final SSnextPmtDateMOP personNextPmtDateMOP = new SSnextPmtDateMOP();

          personNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          personNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          personObj.searchByNextPmtDateMOP(personNextPmtDateMOP, issPersonPmt);

        } else {

          final SSnextPmtDateRangeMOP personNextPmtDateRangeMOP = new SSnextPmtDateRangeMOP();

          personNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          personNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          personNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          personObj.searchByNextPmtDateRangeMOP(personNextPmtDateRangeMOP,
            issPersonPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(CONCERNROLETYPE.EMPLOYER)) {

      final Employer employerObj = EmployerFactory.newInstance();
      final EmployerPayments issEmployerPmts = new EmployerPayments();

      // BEGIN, CR00102258, CW
      issEmployerPmts.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP employerNextPmtDateMOP = new UtilNextPmtDateMOP();

          employerNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          employerNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          employerObj.searchByNextPmtDateMOP(employerNextPmtDateMOP,
            issEmployerPmts);

        } else {

          final UtilNextPmtDateRangeMOP employerNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          employerNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          employerNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          employerNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          employerObj.searchByNextPmtDateRangeMOP(employerNextPmtDateRangeMOP,
            issEmployerPmts);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.INFORMATIONPROVIDER)) {

      final InformationProvider infoProviderObj = InformationProviderFactory.newInstance();
      final IssueInformationProviderPayments issInfoProviderPayments = new IssueInformationProviderPayments();

      // BEGIN, CR00102258, CW
      issInfoProviderPayments.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP infoProvNextPmtDateMOP = new UtilNextPmtDateMOP();

          infoProvNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          infoProvNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          infoProviderObj.searchByNextPmtDateMOP(infoProvNextPmtDateMOP,
            issInfoProviderPayments);

        } else {

          final UtilNextPmtDateRangeMOP infoProvNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          infoProvNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          infoProvNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          infoProvNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          infoProviderObj.searchByNextPmtDateRangeMOP(
            infoProvNextPmtDateRangeMOP, issInfoProviderPayments);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.REPRESENTATIVE)) {

      final Representative representativeObj = RepresentativeFactory.newInstance();
      final IssueRepresentativePayments issRepresentativePayments = new IssueRepresentativePayments();

      // BEGIN, CR00102258, CW
      issRepresentativePayments.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final UtilNextPmtDateMOP representativeNextPmtDateMOP = new UtilNextPmtDateMOP();

          representativeNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          representativeNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          representativeObj.searchByNextPmtDateMOP(representativeNextPmtDateMOP,
            issRepresentativePayments);

        } else {

          final UtilNextPmtDateRangeMOP representativeNextPmtDateRangeMOP = new UtilNextPmtDateRangeMOP();

          representativeNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          representativeNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          representativeNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          representativeObj.searchByNextPmtDateRangeMOP(
            representativeNextPmtDateRangeMOP, issRepresentativePayments);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }

    // BEGIN, CR00141662, CW
    if (issueConcernPmtsSumm.concernTypeCode.equals(
      CONCERNROLETYPE.EXTERNALPARTY)) {

      final ExternalParty externalPartyObj = ExternalPartyFactory.newInstance();
      final IssueExternalPartyPayments issExternalPartyPmt = new IssueExternalPartyPayments();

      // BEGIN, CR00102258, CW
      issExternalPartyPmt.concernPaymentsSummary = issueConcernPmtsSumm;
      // END, CR00102258

      do {
        gCommitCounter = 0;

        if (!issueConcernPmtsSumm.dateRangeIndicator) {

          final SSnextPmtDateMOP externalPartyNextPmtDateMOP = new SSnextPmtDateMOP();

          externalPartyNextPmtDateMOP.nextPaymentDate = issueConcernPmtsSumm.dateTo;
          externalPartyNextPmtDateMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          externalPartyObj.searchByNextPmtDateMOP(externalPartyNextPmtDateMOP,
            issExternalPartyPmt);

        } else {

          final SSnextPmtDateRangeMOP externalPartyNextPmtDateRangeMOP = new SSnextPmtDateRangeMOP();

          externalPartyNextPmtDateRangeMOP.nextPmtDateFrom = issueConcernPmtsSumm.dateFrom;
          externalPartyNextPmtDateRangeMOP.nextPmtDateTo = issueConcernPmtsSumm.dateTo;
          externalPartyNextPmtDateRangeMOP.methodOfPmtCode = issueConcernPmtsSumm.methodOfPayment;

          // call readmulti operation
          externalPartyObj.searchByNextPmtDateRangeMOP(
            externalPartyNextPmtDateRangeMOP, issExternalPartyPmt);
        }

        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();

      } while (gCommitCounter > 0);
    }
    // END, CR00141662
  }

  // ___________________________________________________________________________
  /**
   * @param pmtDateRangeTypeMOP Payment Date Range Type Method Of Payment
   *
   * @return Issue Concern Payments Summary
   * @deprecated Since Curam 6.0, replaced by
   * {@link #getProcessingAndDateDetails(PaymentDateRangeTypeMOP)} The new
   * method returns the same details but also returns the processing
   * date.
   *
   * To get the date range within which the Concern Payments will be processed.
   */
  @Override
  @Deprecated
  public IssueConcernPmtsSummary getProcessingDetails(
    final PaymentDateRangeTypeMOP pmtDateRangeTypeMOP) throws AppException,
      InformationalException {

    final IssueConcernPmtsSummary issueConcernPmtsSumm = new IssueConcernPmtsSummary();

    issueConcernPmtsSumm.assign(
      getProcessingAndDateDetails(pmtDateRangeTypeMOP));

    return issueConcernPmtsSumm;
  }

  // ___________________________________________________________________________
  /**
   * To get the date range within which the Concern Payments will be processed.
   *
   * @param pmtDateRangeTypeMOP Payment Date Range Type Method Of Payment
   *
   * @return Issue Concern Payments Summary
   */
  @Override
  public IssueConcernPmtsProcessingDateSummary getProcessingAndDateDetails(
    final PaymentDateRangeTypeMOP pmtDateRangeTypeMOP) throws AppException,
      InformationalException {

    final IssueConcernPmtsProcessingDateSummary issueConcernPmtsSumm = new IssueConcernPmtsProcessingDateSummary();

    if (pmtDateRangeTypeMOP.nextPaymentDateFrom.isZero()
      && pmtDateRangeTypeMOP.nextPaymentDateTo.isZero()) {

      final Date currentDate = Date.getCurrentDate();

      issueConcernPmtsSumm.dateRangeIndicator = false;
      issueConcernPmtsSumm.dateFrom = currentDate;
      issueConcernPmtsSumm.dateTo = currentDate;

    } else {

      if (pmtDateRangeTypeMOP.nextPaymentDateFrom.isZero()
        && !pmtDateRangeTypeMOP.nextPaymentDateTo.isZero()) {

        issueConcernPmtsSumm.dateRangeIndicator = false;
        issueConcernPmtsSumm.dateFrom = pmtDateRangeTypeMOP.nextPaymentDateTo;
        issueConcernPmtsSumm.dateTo = pmtDateRangeTypeMOP.nextPaymentDateTo;

      } else {

        if (!pmtDateRangeTypeMOP.nextPaymentDateFrom.isZero()
          && pmtDateRangeTypeMOP.nextPaymentDateTo.isZero()) {

          issueConcernPmtsSumm.dateRangeIndicator = false;
          issueConcernPmtsSumm.dateFrom = pmtDateRangeTypeMOP.nextPaymentDateFrom;
          issueConcernPmtsSumm.dateTo = pmtDateRangeTypeMOP.nextPaymentDateFrom;

        } else {

          issueConcernPmtsSumm.dateRangeIndicator = true;
          issueConcernPmtsSumm.dateFrom = pmtDateRangeTypeMOP.nextPaymentDateFrom;
          issueConcernPmtsSumm.dateTo = pmtDateRangeTypeMOP.nextPaymentDateTo;
        }
      }
    }

    // BEGIN, CR00102258, CR00229490, CW
    // If no processingDate is specified use the current date
    if (pmtDateRangeTypeMOP.processingDate.isZero()) {
      issueConcernPmtsSumm.processingDate = Date.getCurrentDate();
    } else {
      issueConcernPmtsSumm.processingDate = pmtDateRangeTypeMOP.processingDate;
    }
    // END, CR00102258, CR00229490

    return issueConcernPmtsSumm;
  }
}
