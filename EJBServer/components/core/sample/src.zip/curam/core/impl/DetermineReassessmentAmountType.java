/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2004, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.codetable.ILITYPE;
import curam.codetable.REASSESSMENTPROCMODE;
import curam.codetable.REASSESSMENT_AMOUNT;
import curam.codetable.TRANSLATEILITYPE;
import curam.core.struct.ReassessCaseDetails;
import curam.core.struct.ReassessmentAmountInfoDtls;
import curam.core.struct.ReassessmentMode;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Implements the Determine Reassessment Amount Type functionality.
 */
public abstract class DetermineReassessmentAmountType extends curam.core.base.DetermineReassessmentAmountType {

  // ___________________________________________________________________________
  /**
   * Method to determine the reassessment amount type based on the ILI type.
   * This method can be overridden for any new ILI types introduced.
   *
   * @param reassessCaseDetails Reassessment Amount Information structs
   * for amount Type determination.
   * @param reassessmentMode Indicates 'normal' or 'reconciliation' mode.
   *
   * @return A struct to hold amount information details including correct
   * amount type.
   */
  @Override
  public ReassessmentAmountInfoDtls determineReassessmentAmountType(ReassessCaseDetails reassessCaseDetails,
    ReassessmentMode reassessmentMode) throws AppException,
      InformationalException {

    final ReassessmentAmountInfoDtls reassessmentAmountInfoDtls = getAmountType(
      reassessCaseDetails, reassessmentMode);

    return reassessmentAmountInfoDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to get the reassessment amount type based on the ILI type.
   *
   * @param reassessCaseDetails Reassessment Amount Information structs
   * for amount Type determination.
   * @param reassessmentMode Indicates 'normal' or 'reconciliation' mode.
   *
   * @return A struct to hold amount information details including correct
   * amount type.
   */
  @Override
  public ReassessmentAmountInfoDtls getAmountType(ReassessCaseDetails reassessCaseDetails,
    ReassessmentMode reassessmentMode) throws AppException,
      InformationalException {

    // reassessmentAmountInfoDtls variable
    final ReassessmentAmountInfoDtls reassessmentAmountInfoDtls = new ReassessmentAmountInfoDtls();

    // translate ILI type to amount type
    final String amountType = // BEGIN, CR00163098, JC
      CodeTable.getOneItem(TRANSLATEILITYPE.TABLENAME,
      reassessCaseDetails.instructionLineItemType,
      TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (amountType != null) {

      reassessmentAmountInfoDtls.amountType = amountType;
      return reassessmentAmountInfoDtls;
    }

    // Write-off or allocated / unallocated reversal
    if (reassessCaseDetails.instructionLineItemType.equals(ILITYPE.WRITEOFF)
      || reassessCaseDetails.instructionLineItemType.equals(
        ILITYPE.UNALLOCATEDREVERSAL)
        || reassessCaseDetails.instructionLineItemType.equals(
          ILITYPE.ALLOCATEDREVERSAL)) {

      if (reassessmentMode.reassessmentMode.equals(
        REASSESSMENTPROCMODE.RECONCILIATION)) {
        reassessmentAmountInfoDtls.amountType = REASSESSMENT_AMOUNT.BILL;
      } else {
        reassessmentAmountInfoDtls.amountType = REASSESSMENT_AMOUNT.LIABILITY;
      }
    }

    return reassessmentAmountInfoDtls;
  }

}
