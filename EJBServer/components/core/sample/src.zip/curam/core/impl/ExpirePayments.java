/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.struct.DateStruct;
import curam.core.struct.PIExpiredPaymentDtls;
import curam.core.struct.PIStatusDeliveryMethodEffDate;
import curam.core.struct.PmtInstrumentExpiryDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;


/**
 * Batch job to expire payments on the system based on the expiry period that
 * is specified in the parameter file.
 *
 */
public abstract class ExpirePayments extends curam.core.base.ExpirePayments {

  protected static int stExpiryDaysForReport = 0;

  protected static int stTotalRecords = 0;

  protected static int stCommitCounter = 0;

  protected static boolean stFileOpen = false;

  // based on domain CURAM_AMOUNT
  protected static curam.util.type.Money stTotalAmount = curam.util.type.Money.kZeroMoney;

  protected static java.io.PrintStream stOutstream;

  protected static final int kProcessCommitCount;

  protected static final boolean kCommitCountEnabled;

  // BEGIN, CR00071077, GM
  protected static String eRPAdapterEnabledErrMsg = CuramConst.gkEmpty;
  // END, CR00071077

  // ___________________________________________________________________________
  /**
   * Static initialization which looks up the commit count status from
   * the environment and sets the static members used to control the processing
   */
  static {

    // Get the value of the Commit Count Enabled environment variable
    String commitCountEnabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_EXPIREPAYMENTS_COMMITCOUNTENABLED);

    // If it's not set, use the default
    if (commitCountEnabled == null) {

      commitCountEnabled = EnvVars.ENV_EXPIREPAYMENTS_COMMITCOUNTENABLED_DEFAULT;
    }

    // If commit count processing is on, look up the commit count value
    // i.e. the number of records to be processed before the results are
    // committed to the database.

    if (commitCountEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      kCommitCountEnabled = true;

      // Get the value of the Commit Count environment variable
      final String commitCount = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_EXPIREPAYMENTS_COMMITCOUNT);

      // If it's not set, use the default
      if (commitCount == null) {

        kProcessCommitCount = EnvVars.ENV_EXPIREPAYMENTS_COMMITCOUNT_DEFAULT;

      } else {

        // Convert string value to integer
        kProcessCommitCount = Integer.parseInt(commitCount);

      }

    } else {

      // Otherwise commit count processing is off
      kCommitCountEnabled = false;
      kProcessCommitCount = 0;

    }

  }

  // ___________________________________________________________________________
  /*
   * Definition of the class containing the specialized functions for the
   * ModifyExpiredPayments nsmulti operation.
   */
  static class ModifyExpiredPayments extends curam.util.dataaccess.ReadmultiOperation {

    // Process object to process the details for the output file

    protected static curam.core.intf.ExtractPaymentInstrumentExpiryDetails extractPaymentExpiredDetailsObj = curam.core.fact.ExtractPaymentInstrumentExpiryDetailsFactory.newInstance();

    // _________________________________________________________________________
    /**
     * ModifyExpiredPayments readmulti operation.
     *
     * @param objDtls payment instrument expired payment details
     *
     * @return A flag indicating whether the readmulti should continue
     */
    @Override
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      // paymentInstrument expired payment details
      final PIExpiredPaymentDtls piExpiredPaymentDtls = (PIExpiredPaymentDtls) objDtls;

      final curam.util.type.Date expiryDate = piExpiredPaymentDtls.effectiveDate.addDays(
        stExpiryDaysForReport);

      final DateStruct dateStruct = new DateStruct();

      dateStruct.date = expiryDate;
      final String detailsAsString = extractPaymentExpiredDetailsObj.extractDetails(
        piExpiredPaymentDtls, dateStruct);

      // writing the output record
      stOutstream.print(detailsAsString);

      // increasing counter and running totals
      if (kCommitCountEnabled) {

        stCommitCounter++;

      }

      stTotalRecords++;

      // when does this get written
      stTotalAmount = new curam.util.type.Money(
        stTotalAmount.getValue() + piExpiredPaymentDtls.amount.getValue());

      if (kCommitCountEnabled && stCommitCounter >= kProcessCommitCount) {

        return false;

      } else {

        return true;

      }

    }

    // _________________________________________________________________________
    /**
     * Operation to filter records in the ModifyExpiredPayments readmulti class
     *
     * @param objDtls payment instrument expired payment details
     *
     * @return false if commit counter has reached commit point or
     * deliveryMethodType is CASH, otherwise return true
     */
    @Override
    public boolean filter(Object objDtls) throws AppException,
        InformationalException {

      // paymentInstrument expired payment details
      final PIExpiredPaymentDtls piExpiredPaymentDtls = (PIExpiredPaymentDtls) objDtls;

      if (piExpiredPaymentDtls.deliveryMethodType.equals(
        curam.codetable.METHODOFDELIVERY.CASH)) {

        return false;

      } else {

        return true;

      }

    }

    // _________________________________________________________________________
    /**
     * Operation to open output file. This is performed before any records are
     * returned.
     *
     */
    @Override
    public void pre() throws AppException, InformationalException {

      // Even when no records exist we want to open file, because we write a
      // summary when we are finished. Otherwise we'll get a null pointer,which
      // is exactly what we were getting when this code was in first()
      if (!stFileOpen) {

        // open payment instrument file for output
        final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

        curamBatchObj.outputFileID = // BEGIN, CR00163471, JC
          curam.message.BPOEXPIREPAYMENTS.INF_EXPIRE_PMTS_ID.getMessageText(
          ProgramLocale.getDefaultServerLocale());
        // END, CR00163471, JC

        curamBatchObj.datFileExt = CuramConst.gkDataFileExt;
        curamBatchObj.setFileName();

        try {
          stOutstream = new java.io.PrintStream(
            new java.io.FileOutputStream(curamBatchObj.outputFilename));

        } catch (final java.io.FileNotFoundException e) {
          throw new curam.util.exception.AppRuntimeException(e);
        }

        if (stOutstream.checkError()) { // check for file open failure

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOEXPIREPAYMENTS.ERR_EXPIREPAYMENTS_FILE_OPEN),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }

        stFileOpen = true;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is used to call the ModifyExpiredPayments readmulti of the
   * PaymentInstrument table in order to determine the payments that have
   * expired.
   *
   * @param pmtInstrumentExpiryDtls payment instrument expired payment details
   */
  @Override
  public void expirePaymentInstrument(
    PmtInstrumentExpiryDtls pmtInstrumentExpiryDtls) throws AppException,
      InformationalException {

    final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

    // BEGIN, CR00073939, JI
    // If the ERP Adapter is enabled do not execute the batch job
    // and write an error message into the log file
    // BEGIN, CR00080249, CW
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()) {
      // END, CR00080249

      // Construct the error message
      curamBatchObj.setStartTime();
      // BEGIN, CR00077050, CW
      // BEGIN, CR00076996, KH
      eRPAdapterEnabledErrMsg = // BEGIN, CR00163471, JC
        curam.message.EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_ENABLED_BATCH_JOB.getMessageText(
        ProgramLocale.getDefaultServerLocale())
          // END, CR00163471, JC
          + CuramConst.gkNewLine
          + CuramConst.gkNewLine;
      // END, CR00076996
      // END, CR00077050
      curamBatchObj.setEndTime();

      // If the ERP Adapter is not enabled run the batch job
    } else {
      // END, CR00073939

      // piStatusDeliveryMethodEffDate variable
      final PIStatusDeliveryMethodEffDate piStatusDeliveryMethodEffDate = new PIStatusDeliveryMethodEffDate();

      // currentDate variable
      final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

      // register the security implementation
      SecurityImplementationFactory.register();

      // perform a readmulti of the paymentInstrument entity to determine the
      // payments that have expired
      piStatusDeliveryMethodEffDate.assign(pmtInstrumentExpiryDtls);

      piStatusDeliveryMethodEffDate.reconcilStatusCode = curam.codetable.PMTRECONCILIATIONSTATUS.ISSUED;

      // subtracting expiryPeriod(in days) from totalDays to obtain search date
      // in days
      piStatusDeliveryMethodEffDate.effectiveDate = currentDate.addDays(
        0 - pmtInstrumentExpiryDtls.expiryPeriod);

      // using public variable here so that it can be used above for
      // calculating the expiry date
      stExpiryDaysForReport = pmtInstrumentExpiryDtls.expiryPeriod;

      curamBatchObj.setStartTime(); // set start time for batch processing

      do {

        stCommitCounter = 0;

        final ModifyExpiredPayments expayment = new ModifyExpiredPayments();

        // Check if Delivery method type is provided
        if (piStatusDeliveryMethodEffDate.deliveryMethodType.length() != 0) {

          // calling readmulti
          curam.core.fact.PaymentInstrumentFactory.newInstance().searchByDeliveryMethodStatusEffectiveDate(
            piStatusDeliveryMethodEffDate, expayment);

        } else {
          // calling readmulti
          curam.core.fact.PaymentInstrumentFactory.newInstance().searchByStatusEffectiveDate(
            piStatusDeliveryMethodEffDate, expayment);
        }

        curam.util.transaction.TransactionInfo.getInfo().commit();
        curam.util.transaction.TransactionInfo.getInfo().begin();

      } while (stCommitCounter > 0);

      curamBatchObj.setEndTime(); // set end time for batch processing

      stOutstream.print(stTotalRecords);
      stOutstream.print(CuramConst.gkTabDelimiter);
      stOutstream.print(stTotalAmount.toString());
      stOutstream.close();
    }
    final int stringBufferZeroSize = 0;
    final int messageLength = 4096;
    final StringBuffer emailMessageString = new StringBuffer(messageLength);

    // reset string buffer to empty
    emailMessageString.setLength(stringBufferZeroSize);

    // BEGIN, CR00073939, JI
    emailMessageString.append(eRPAdapterEnabledErrMsg)// BEGIN, CR00163471, JC
      .append(curam.message.GENERALFINANCE.INF_TOT_RECS_PROCESSED.getMessageText(ProgramLocale.getDefaultServerLocale())).append(String.valueOf(stTotalRecords)).append(CuramConst.gkNewLine).append(curam.message.GENERALFINANCE.INF_TOT_AMT_PROCESSED.getMessageText(ProgramLocale.getDefaultServerLocale())).append(stTotalAmount.toString()).append(
      // END, CR00163471, JC
      CuramConst.gkNewLine);
    // END, CR00073939

    curamBatchObj.emailMessage = emailMessageString.toString();

    // constructing the email subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOEXPIREPAYMENTS.INF_EXPIRE_PAYMENTS_SUB);

    // setting output log file identifier
    curamBatchObj.outputFileID = // BEGIN, CR00163471, JC
      curam.message.BPOEXPIREPAYMENTS.INF_EXPIRE_PMTS_ID.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163471, JC

    // sending the email
    curamBatchObj.sendEmail();
  }

}
