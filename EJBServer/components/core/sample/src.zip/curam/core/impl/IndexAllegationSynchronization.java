/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.ALLEGATION;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.entity.struct.AllegationDtls;
import curam.core.sl.entity.struct.AllegationKey;
import curam.core.sl.entity.struct.CancelAllegationDetails;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when
 * modifications are made to the Allegation entity
 */
public abstract class IndexAllegationSynchronization extends curam.core.base.IndexAllegationSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the allegation entity insert operation
   *
   * @param dtls allegation details
   */
  @Override
  public void insert(final AllegationDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALLEGATION.INSERT_ALLEGATION.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALLEGATION.INSERT_ALLEGATION.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.allegationID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the allegation entity modify operation
   *
   * @param key allegation identifier
   * @param dtls allegation details
   */
  @Override
  public void modify(final AllegationKey key, final AllegationDtls dtls)
    throws AppException, InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALLEGATION.MODIFY_ALLEGATION.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALLEGATION.MODIFY_ALLEGATION.eventType;
    synchronizeEventsDetails.primaryEventData = key.allegationID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the allegation entity cancel operation
   *
   * @param key allegation identifier
   * @param dtls allegation details to cancel
   */
  @Override
  public void cancel(final AllegationKey key,
    final CancelAllegationDetails dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALLEGATION.CANCEL_ALLEGATION.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALLEGATION.CANCEL_ALLEGATION.eventType;
    synchronizeEventsDetails.primaryEventData = key.allegationID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

}
