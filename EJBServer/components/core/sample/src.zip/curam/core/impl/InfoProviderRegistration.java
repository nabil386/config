/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2009, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CONCERNROLEADDRESSTYPE;
import curam.codetable.CONCERNROLEALTERNATEID;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.EMAILTYPE;
import curam.codetable.LOCATIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.intf.ConcernRoleAlternateID;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.ValidationManager;
import curam.core.sl.intf.Representative;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AdminConcernRoleDetails;
import curam.core.struct.AlternateIDTypeCodeKey;
import curam.core.struct.ConcernDtls;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleAlternateReadKey;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleEmailDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.DupConcernRoleAltIDDetailsList;
import curam.core.struct.InfoProvRegistrationDetails;
import curam.core.struct.InformationProviderDtls;
import curam.core.struct.LocationKey;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.core.struct.MaintainEmailKey;
import curam.core.struct.PhoneNumberDetails;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.RegistrationIDDetails;
import curam.core.struct.SearchCRTypeAltIDType;
import curam.message.BPOINFOPROVIDERREGISTRATION;
import curam.message.BPOMAINTAINCONCERNROLEALTID;
import curam.message.BPOMAINTAINCONTACTS;
import curam.message.BPOPERSONREGISTRATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTable;
import java.util.Map;


/**
 * register information provider
 */
public abstract class InfoProviderRegistration extends curam.core.base.InfoProviderRegistration {

  // BEGIN, CR00312286, SG
  @Inject
  private Map<String, AllocateParticipantID> allocateParticipantIDMap;

  /**
   * Add injection.
   */
  public InfoProviderRegistration() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00312286

  /**
   * Called to register a new information provider.
   *
   * @param details
   * Details of the info provider to be registered.
   *
   * @return Details of the info provider's registration id.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public RegistrationIDDetails registerInfoProvider(
    InfoProvRegistrationDetails details) throws AppException,
      InformationalException {

    final RegistrationIDDetails idDetails = new RegistrationIDDetails();

    // general objects and variables

    // BEGIN, CR00061099, POH
    // Variables to manipulate participant evidence
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();
    EIEvidenceInsertDtls eiEvidenceInsertDtls = new EIEvidenceInsertDtls();
    // END, CR00061099

    // object for any unique id generation
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // based on domain CURAM_DATE
    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // variables declaration to prevent duplicate alternative ID's
    final AlternateIDTypeCodeKey alternateIDTypeCodeKey = new AlternateIDTypeCodeKey();
    boolean altIDExist = true;

    // concernRolePhoneNumber manipulation variables
    final curam.core.intf.ConcernRolePhoneNumber concernRolePhoneNumberObj = curam.core.fact.ConcernRolePhoneNumberFactory.newInstance();
    final ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = new ConcernRolePhoneNumberDtls();

    // phoneNumber manipulation variables
    final curam.core.intf.PhoneNumber phoneNumberObj = curam.core.fact.PhoneNumberFactory.newInstance();
    final PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    // based on domain PHONE_NUMBER_ID
    long primaryPhoneNumberID;

    // concern manipulation variables
    final curam.core.intf.Concern concernObj = curam.core.fact.ConcernFactory.newInstance();
    final ConcernDtls concernDtls = new ConcernDtls();

    // Concern ID
    long concernID = 0;

    // variables for different IDs
    // based on domain CONCERN_ROLE_ID
    // local concernRoleID
    long concernRoleID = 0;

    // based on domain ADDRESS_ID
    long primaryAddressID = 0;

    // based on domain ALTERNATE_ID
    // BEGIN, CR00049218, GM
    String alternateInformationProviderReferenceNo = CuramConst.gkEmpty;
    // END, CR00049218

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleAlternateReadKey concernRoleAlternateReadKey = new ConcernRoleAlternateReadKey();

    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // concernRoleAlternateID manipulation variables
    final curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();

    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();

    // based on domain CONCERN_ROLE_ALTERNATE_ID
    long concernRoleAlternateID = 0;

    // informationProvider manipulation variables
    final curam.core.intf.InformationProvider informationProviderObj = curam.core.fact.InformationProviderFactory.newInstance();
    final InformationProviderDtls informationProviderDtls = new InformationProviderDtls();

    // concernRoleAddress manipulation variables
    final ConcernRoleAddressDtls concernRoleAddressDtls = new ConcernRoleAddressDtls();

    // based on domain CONCERN_ROLE_ADDRESS_ID
    long concernRoleAddressID = 0;

    // address manipulation variables
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final AddressDtls addressDtls = new AddressDtls();

    // Maintain Admin Concern Role Details
    final curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRoleObj = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();
    final MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();

    // Call the validation method
    final curam.core.intf.ValidateInfoProviderDetails validateInfoProviderDetailsObj = curam.core.fact.ValidateInfoProviderDetailsFactory.newInstance();

    // validate information provider details
    validateInfoProviderDetailsObj.validateInfoProvider(details);

    if (details.concernID == 0) {

      // generate unique concern id
      concernID = uniqueIDObj.getNextID();
    }

    // unique concern role ID
    concernRoleID = uniqueIDObj.getNextID();

    // validation to prevent the user from selecting a canceled office location
    if (details.prefPublicOfficeID != 0) {

      // Location business process object
      final curam.core.intf.Location locationObj = curam.core.fact.LocationFactory.newInstance();

      final LocationKey locationKey = new LocationKey();

      locationKey.locationID = details.prefPublicOfficeID;

      // read the public office status details
      final String locationStatus = locationObj.read(locationKey).locationStatus;

      // if the public office is closed
      if (locationStatus.equals(LOCATIONSTATUS.CLOSED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPERSONREGISTRATION.ERR_PUBLIC_OFFICE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }

      // if the public office is deleted.
      if (locationStatus.equals(RECORDSTATUS.CANCELLED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPERSONREGISTRATION.ERR_PUBLIC_OFFICE_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }
    }

    // validation to prevent duplicate alternative ID's

    // BEGIN CR00020797, NH
    // BEGIN, CR00096068, SD
    boolean recordNotFound = false;
    // END, CR00096068
    // BEGIN, CR00095820, SD
    boolean isAlternateReferenceNo = false;

    // END, CR00095820
    if (details.socialSecurityNumber.length() != 0) {
      alternateInformationProviderReferenceNo = details.socialSecurityNumber;

      // BEGIN, CR00095820, SD
      alternateIDTypeCodeKey.typeCode = CONCERNROLEALTERNATEID.INFORMATION_PROVIDER_REFERENCE_NUMBER;
      // END, CR00095820

      alternateIDTypeCodeKey.alternateID = alternateInformationProviderReferenceNo;

      alternateIDTypeCodeKey.statusCode = RECORDSTATUS.NORMAL;

      // BEGIN, CR00394323, PMD
      final ValidationManager validationManagerObj = curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager();

      if (validationManagerObj.enabled(
        BPOMAINTAINCONCERNROLEALTID.ERR_CONCERNROLEALTID_XRV_ID_TYPE_CONCERNTYPE_OVERLAP,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 8)) {

        final ConcernRoleAlternateID concernRoleAltIDObj = ConcernRoleAlternateIDFactory.newInstance();

        final SearchCRTypeAltIDType searchCRTypeAltIDType = new SearchCRTypeAltIDType();

        searchCRTypeAltIDType.alternateID = alternateInformationProviderReferenceNo;
        searchCRTypeAltIDType.alternateIDType = CONCERNROLEALTERNATEID.INFORMATION_PROVIDER_REFERENCE_NUMBER;
        searchCRTypeAltIDType.statusCode = RECORDSTATUS.NORMAL;
        searchCRTypeAltIDType.concernRoleType = CONCERNROLETYPE.INFORMATIONPROVIDER;

        final DupConcernRoleAltIDDetailsList dupConcernRoleAltIDDetailsList = concernRoleAltIDObj.searchByCRTypeAltIDAndType(
          searchCRTypeAltIDType);

        if (dupConcernRoleAltIDDetailsList.dtls.size() > 0) {

          final AppException ae = new AppException(
            BPOMAINTAINCONCERNROLEALTID.ERR_CONCERNROLEALTID_XRV_ID_TYPE_CONCERNTYPE_OVERLAP);

          ae.arg(
            CodeTable.getOneItem(CONCERNROLETYPE.TABLENAME,
            CONCERNROLETYPE.INFORMATIONPROVIDER));
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            ae,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 8);
        } else {
          recordNotFound = true;
        }
      } else {
        recordNotFound = true;
      }
      // END, CR00394323

      // BEGIN, CR00394029, GD
      if (validationManagerObj.enabled(
        BPOINFOPROVIDERREGISTRATION.ERR_INFOPROVIDER_SSN_ALREADY_EXISTS,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0)) {

        try {
          concernRoleAlternateIDDtls = concernRoleAlternateIDObj.readByAltIDTypeCode(
            alternateIDTypeCodeKey);

          if (details.socialSecurityNumber.length() > 0
            && details.socialSecurityNumber.equals(
              concernRoleAlternateIDDtls.alternateID)) {
            final AppException ae = new AppException(
              BPOINFOPROVIDERREGISTRATION.ERR_INFOPROVIDER_SSN_ALREADY_EXISTS);

            ae.arg(details.socialSecurityNumber);
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              ae,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
          }
        } catch (final curam.util.exception.MultipleRecordException e) {

          final AppException ae = new AppException(
            BPOINFOPROVIDERREGISTRATION.ERR_INFOPROVIDER_SSN_ALREADY_EXISTS);

          ae.arg(details.socialSecurityNumber);
          throw ae;
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }
      } else {
        recordNotFound = true;
      }
      // END, CR00394029
      // BEGIN, CR00096068, SD
      if (recordNotFound) {
        concernRoleAlternateReadKey.primaryAlternateID = alternateInformationProviderReferenceNo;

        concernRoleAlternateReadKey.statusCode = CONCERNROLESTATUS.DEFAULTCODE;

        // BEGIN, CR00394029, GD
        if (validationManagerObj.enabled(
          BPOINFOPROVIDERREGISTRATION.ERR_REFERENCE_NUM_ALREADY_EXISTS_AS_PRIMARY_ALT_ID,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0)) {
          try {
            concernRoleDtls = concernRoleObj.readByAlternateID(
              concernRoleAlternateReadKey);

            if (concernRoleAlternateReadKey.primaryAlternateID.equals(
              concernRoleDtls.primaryAlternateID)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                new AppException(
                  BPOINFOPROVIDERREGISTRATION.ERR_REFERENCE_NUM_ALREADY_EXISTS_AS_PRIMARY_ALT_ID),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
            }
          } catch (final curam.util.exception.RecordNotFoundException e) {
            altIDExist = false;
          }
        } else {
          altIDExist = false;
        }
        // END, CR00394029
      }
      // END, CR00096068
    } else {
      // BEGIN, CR00095820, SD
      isAlternateReferenceNo = true;
      // END, CR00095820
      while (altIDExist) {

        // BEGIN, CR00312286, SG
        alternateInformationProviderReferenceNo = allocateParticipantIDMap.get("INFORMATIONPROVIDER").getNextID();
        // END, CR00312286

        // BEGIN, CR00095820, SD
        alternateIDTypeCodeKey.typeCode = CONCERNROLEALTERNATEID.REFERENCE_NUMBER;
        // END, CR00095820

        alternateIDTypeCodeKey.alternateID = alternateInformationProviderReferenceNo;

        alternateIDTypeCodeKey.statusCode = RECORDSTATUS.NORMAL;

        recordNotFound = false;

        try {
          concernRoleAlternateIDDtls = concernRoleAlternateIDObj.readByAltIDTypeCode(
            alternateIDTypeCodeKey);

          if (alternateInformationProviderReferenceNo.equals(
            concernRoleAlternateIDDtls.alternateID)) {
            // if found continue to generate the next number
            continue;
          }
        } catch (final curam.util.exception.MultipleRecordException e) {// BEGIN,
          // CR00158767,
          // LD
          /*
           * If you find possibility of more than one records in the database
           * and if you have any specific
           * exception message to display then implement it. In this case, we
           * are making sure system generated alternate ID is unique.
           * There could be an existing identical alternate id record, if any
           * then we are continuing until we get a unique one generated.
           */// END, CR00158767
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (recordNotFound) {

          concernRoleAlternateReadKey.primaryAlternateID = alternateInformationProviderReferenceNo;

          concernRoleAlternateReadKey.statusCode = CONCERNROLESTATUS.DEFAULTCODE;

          try {
            concernRoleDtls = concernRoleObj.readByAlternateID(
              concernRoleAlternateReadKey);
          } catch (final curam.util.exception.RecordNotFoundException e) {
            altIDExist = false;
          }
        }
      }
    }
    // END CR00020797

    if (details.concernID == 0) {

      // fill in the data structure
      concernDtls.assign(details);
      concernDtls.concernID = concernID;
      concernDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

      // BEGIN, CR00049218, GM
      concernDtls.comments = CuramConst.gkEmpty;
      // END, CR00049218

      // insert concern record
      concernObj.insert(concernDtls);
    }

    // fill in the address data structure for insert
    addressDtls.addressData = details.addressData;

    // save record to DB
    addressObj.insert(addressDtls);
    primaryAddressID = addressDtls.addressID;

    final boolean phoneDetailsSpecified = details.phoneAreaCode.length()
      + details.phoneCountryCode.length() + details.phoneExtension.length()
      + details.phoneNumber.length()
        > 0
          ? true
          : false;

    if (phoneDetailsSpecified) {

      if (details.phoneType.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINCONTACTS.ERR_CONTACTS_XFV_PHONE_TYPE_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      }

      // fill in the data structure
      final curam.core.intf.MaintainPhoneNumber maintainPhoneNumberObj = curam.core.fact.MaintainPhoneNumberFactory.newInstance();
      final PhoneNumberDetails phoneNumberDetails = new PhoneNumberDetails();

      phoneNumberDetails.phoneExtension = details.phoneExtension;
      phoneNumberDetails.phoneCountryCode = details.phoneCountryCode;
      phoneNumberDetails.phoneAreaCode = details.phoneAreaCode;
      phoneNumberDetails.phoneNumber = details.phoneNumber;

      // BEGIN, CR00049218, GM
      phoneNumberDetails.comments = CuramConst.gkEmpty;
      // END, CR00049218

      maintainPhoneNumberObj.validatePhoneNumber(phoneNumberDetails);

      phoneNumberDtls.assign(phoneNumberDetails);

      // save phoneNumber to database
      phoneNumberObj.insert(phoneNumberDtls);

      // BEGIN, CR00260989, MR
      primaryPhoneNumberID = phoneNumberDtls.phoneNumberID;
      // END, CR00260989

    } else {

      primaryPhoneNumberID = 0;

    }

    if (concernRoleDtls == null) {

      concernRoleDtls = new ConcernRoleDtls();
    }

    // insert concern role
    // fill in the data structure
    concernRoleDtls.concernRoleID = concernRoleID;

    if (details.concernID == 0) {
      concernRoleDtls.concernID = concernID;
    } else {
      concernRoleDtls.assign(details);
    }

    concernRoleDtls.concernRoleType = CONCERNROLETYPE.INFORMATIONPROVIDER;
    // BEGIN ,HARP 48658, KH
    concernRoleDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();
    concernRoleDtls.registrationDate = details.registrationDate;
    concernRoleDtls.startDate = details.registrationDate;
    concernRoleDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleDtls.statusCode = CONCERNROLESTATUS.CURRENT;
    concernRoleDtls.concernRoleName = details.name;
    concernRoleDtls.primaryAddressID = primaryAddressID;
    concernRoleDtls.primaryAlternateID = alternateInformationProviderReferenceNo;
    concernRoleDtls.prefCommMethod = details.prefCommMethod;
    concernRoleDtls.sensitivity = SENSITIVITY.DEFAULTCODE;

    if (details.prefCommMethod.length() > 0) {
      concernRoleDtls.prefCommFromDate = details.registrationDate;
    }

    concernRoleDtls.primaryPhoneNumberID = primaryPhoneNumberID;

    concernRoleDtls.primaryEmailAddressID = 0;

    final String user = curam.util.transaction.TransactionInfo.getProgramUser();

    concernRoleDtls.regUserName = user;
    // BEGIN, CR00049218, GM
    concernRoleDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218

    concernRoleDtls.prefPublicOfficeID = details.prefPublicOfficeID;

    // pass in the preferred language from the concern role table
    concernRoleDtls.preferredLanguage = details.preferredLanguage;

    concernRoleDtls.sensitivity = SENSITIVITY.DEFAULTCODE;

    concernRoleDtls.prefCommMethod = details.prefCommMethod;

    if (details.prefCommMethod.length() > 0) {
      concernRoleDtls.prefCommFromDate = details.registrationDate;
    }

    // save data to DB

    // BEGIN, CR00061193, POH
    // Call the EvidenceController object and insert evidence
    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLE;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END, CR00061193

    // insert informationProvider
    // fill in the data
    informationProviderDtls.assign(details);
    informationProviderDtls.concernRoleID = concernRoleID;
    informationProviderDtls.statusCode = RECORDSTATUS.NORMAL;
    // BEGIN, CR00049218, GM
    informationProviderDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218
    informationProviderDtls.primaryAlternateID = alternateInformationProviderReferenceNo;
    informationProviderDtls.paymentFrequency = details.paymentFrequency;
    informationProviderDtls.currencyType = details.currencyType;
    informationProviderDtls.methodOfPmtCode = details.methodOfPmtCode;
    // based on domain FREQUENCY_PATTERN
    // calculate the next payment date if payment frequency has been entered
    if (informationProviderDtls.paymentFrequency.length() != 0) {
      // BEGIN, CR00049218, GM
      String frequencyPattern = CuramConst.gkEmpty;

      // END, CR00049218
      frequencyPattern = informationProviderDtls.paymentFrequency;
      informationProviderDtls.nextPaymentDate = new curam.util.type.FrequencyPattern(frequencyPattern).getNextOccurrence(
        currentDate);
    }

    // save data to DB
    informationProviderObj.insert(informationProviderDtls);

    // unique concern role alternate ID
    concernRoleAlternateID = uniqueIDObj.getNextID();

    // unique concern role address ID for the primary address
    concernRoleAddressID = uniqueIDObj.getNextID();

    // insert concern role alternate id
    // fill in the data structure
    if (concernRoleAlternateIDDtls == null) {

      concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();
    }

    concernRoleAlternateIDDtls.concernRoleAlternateID = concernRoleAlternateID;
    concernRoleAlternateIDDtls.concernRoleID = concernRoleID;
    concernRoleAlternateIDDtls.alternateID = alternateInformationProviderReferenceNo;

    // BEGIN, CR00095820, SD
    if (isAlternateReferenceNo) {
      concernRoleAlternateIDDtls.typeCode = CONCERNROLEALTERNATEID.REFERENCE_NUMBER;
    } else {
      concernRoleAlternateIDDtls.typeCode = CONCERNROLEALTERNATEID.INFORMATION_PROVIDER_REFERENCE_NUMBER;
    }
    // END, CR00095820

    concernRoleAlternateIDDtls.startDate = details.registrationDate;
    concernRoleAlternateIDDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleAlternateIDDtls.statusCode = RECORDSTATUS.NORMAL;

    // BEGIN, CR00049218, GM
    concernRoleAlternateIDDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218

    // BEGIN, CR00059688, POH
    // Call the EvidenceController object and insert evidence

    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleAlternateIDDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLEALTERNATEID;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleAlternateIDDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleAlternateIDDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END, CR00059688

    // insert concern role address
    // fill in the data structure
    concernRoleAddressDtls.concernRoleAddressID = concernRoleAddressID;
    concernRoleAddressDtls.concernRoleID = concernRoleID;
    concernRoleAddressDtls.addressID = primaryAddressID;
    concernRoleAddressDtls.typeCode = CONCERNROLEADDRESSTYPE.BUSINESS;
    concernRoleAddressDtls.startDate = details.registrationDate;
    concernRoleAddressDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleAddressDtls.statusCode = RECORDSTATUS.NORMAL;

    // insert concernRoleAddress record
    // BEGIN, CR00061099, POH
    // Call the EvidenceController object and insert evidence
    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleAddressDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleAddressDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleAddressDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END, CR00061099

    if (primaryPhoneNumberID != 0) {

      // generate new unique id for inserting concernRolePhoneNumber
      // unique concern role phone number ID for the primary phone number

      final long concernRolePhoneNumberID = uniqueIDObj.getNextID();

      // fill in the data structure
      concernRolePhoneNumberDtls.assign(details);
      concernRolePhoneNumberDtls.concernRolePhoneNumberID = concernRolePhoneNumberID;
      concernRolePhoneNumberDtls.concernRoleID = concernRoleID;
      concernRolePhoneNumberDtls.phoneNumberID = primaryPhoneNumberID;
      concernRolePhoneNumberDtls.startDate = details.registrationDate;
      concernRolePhoneNumberDtls.endDate = curam.util.type.Date.kZeroDate;

      // insert concernRolePhoneNumber record
      concernRolePhoneNumberObj.insert(concernRolePhoneNumberDtls);

    }

    // BEGIN, CR00070459, MM
    // determine whether any contact should be registered
    final boolean contactDetailsSpecified = details.contactName.length()
      + details.contactPhoneAreaCode.length()
      + details.contactPhoneCountryCode.length()
      + details.contactPhoneExtension.length()
      + details.contactPhoneNumber.length() + details.contactTitle.length()
        > 0
          ? true
          : false;

    // END, CR00070459

    if (contactDetailsSpecified) {

      if (details.contactTitle.length() == 0
        || details.contactName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOMAINTAINCONTACTS.ERR_CONTACTS_XFV_NAME_TYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }

      // concernRoleContact manipulation variables
      final curam.core.intf.ConcernRoleContact concernRoleContactObj = curam.core.fact.ConcernRoleContactFactory.newInstance();
      final ConcernRoleContactDtls concernRoleContactDtls = new ConcernRoleContactDtls();

      // Representative maintenance object
      // BEGIN, CR00155209, AK
      final Representative representativeObj = RepresentativeFactory.newInstance();
      // END, CR00155209

      // Struct passed to Representative::registerRepresentative
      final RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.contactName;
      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;
      representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = details.contactPhoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.contactPhoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.contactPhoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = details.contactPhoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = details.registrationDate;
      representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = SENSITIVITY.DEFAULTCODE;

      // Call registerRepresentative
      // BEGIN, CR00095820, SD
      representativeObj.registerRepresentativeForParticipants(
        representativeRegistrationDetails, concernRoleAlternateIDDtls.typeCode);
      // END, CR00095820

      // Generate unique ID for contact details
      concernRoleContactDtls.contactID = uniqueIDObj.getNextID();

      // Insert concern role information
      concernRoleContactDtls.contactConRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
      concernRoleContactDtls.concernRoleID = concernRoleID;
      concernRoleContactDtls.contactTypeCode = details.contactTitle;
      concernRoleContactDtls.name = details.contactName;
      // BEGIN, CR00294967, MV
      concernRoleContactDtls.statusCode = RECORDSTATUS.NORMAL;
      // END, CR00294967
      // BEGIN, CR00108971 - PA
      concernRoleContactDtls.startDate = details.registrationDate;
      // END, CR00108971 - PA

      // Insert concernRoleContact
      concernRoleContactObj.insert(concernRoleContactDtls);

    }

    // BEGIN, CR00070459, MM
    // check whether any contactEmailAddress record has to be inserted into
    // database
    if (details.contactEmailAddress.length() != 0) {
      final curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = curam.core.fact.MaintainConcernRoleEmailFactory.newInstance();
      final MaintainEmailKey maintainEmailKey = new MaintainEmailKey();
      final ConcernRoleEmailDetails concernRoleEmailDetails = new ConcernRoleEmailDetails();

      maintainEmailKey.concernRoleID = concernRoleID;
      concernRoleEmailDetails.emailAddress = details.contactEmailAddress;

      // check whether contactEmailType is entered
      if (details.contactEmailType.length() == 0) {
        concernRoleEmailDetails.typeCode = EMAILTYPE.DEFAULTCODE;
      } else {
        concernRoleEmailDetails.typeCode = details.contactEmailType;
      }
      concernRoleEmailDetails.startDate = currentDate;

      // Insert concernRoleEmailDetails
      maintainConcernRoleEmailObj.createEmailAddress(maintainEmailKey,
        concernRoleEmailDetails);
    }
    // END, CR00070459

    idDetails.alternateID = alternateInformationProviderReferenceNo;
    idDetails.concernRoleID = concernRoleID;

    // set the key to create new concern role owner
    maintainAdminConcernRoleKey.concernRoleID = concernRoleID;

    // BEGIN, CR00176534, RPB
    final AdminConcernRoleDetails adminConcernRoleDetails = new AdminConcernRoleDetails();

    adminConcernRoleDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    adminConcernRoleDetails.startDate = currentDate;
    adminConcernRoleDetails.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();
    maintainAdminConcernRoleObj.createConcernRoleOwner(
      maintainAdminConcernRoleKey, adminConcernRoleDetails);
    // END, CR00176534

    return idDetails;
  }

}
