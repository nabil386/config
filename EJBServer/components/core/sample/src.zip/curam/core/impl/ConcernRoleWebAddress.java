/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2006, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleWebAddressDtls;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Concern Role Web Address entity operation
 */
public abstract class ConcernRoleWebAddress extends curam.core.base.ConcernRoleWebAddress {

  // ___________________________________________________________________________
  /**
   * Checks that the data being inserted/modified contains valid fields.
   *
   * @param details type the data being inserted/modified
   */
  @Override
  protected void autovalidate(ConcernRoleWebAddressDtls details)
    throws AppException, InformationalException {

    // Type should be selected
    if (details.typeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCONCERNROLEWEBADDRESS.ERR_CONCERNROLEWEBADDRESS_FV_TYPE_SELECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // A from date must be entered
    if (details.startDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.GENERAL.ERR_GENERAL_FV_FROM_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 9);
    }

    // From date must not be later than to date
    if (!details.endDate.isZero() && details.startDate.after(details.endDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERAL.ERR_GENERAL_XFV_FROM_DATE_TO_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          18);
    }

    // validation for concern role dates
    // Concern Role object, key and details
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // set key and read concern role web address data
    concernRoleKey.concernRoleID = details.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // BEGIN, CR00313069, RV
    // Check if concern role is of type Person or Prospect Person
    // start date in this case will contain the date of birth
    // web address start date should not be earlier than concern start date
    // (date of birth)
    if (CONCERNROLETYPE.PERSON.equals(concernRoleDtls.concernRoleType)
      || CONCERNROLETYPE.PROSPECTPERSON.equals(concernRoleDtls.concernRoleType)) {
      if (!concernRoleDtls.startDate.isZero()
        && concernRoleDtls.startDate.after(details.startDate)) {
        final AppException e = new AppException(
          GENERALCONCERN.ERR_CONCERNROLE_XRV_PERSON_START_DATE);

        e.arg(concernRoleDtls.concernRoleName);
        e.arg(concernRoleDtls.startDate);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
      }
    } else {

      // in case of concern role types other than Person or
      // Prospect Person, Web address start date should not be
      // earlier than registration date
      if (!concernRoleDtls.registrationDate.isZero()
        && concernRoleDtls.registrationDate.after(details.startDate)) {

        final AppException e = new AppException(
          GENERALCONCERN.ERR_CONCERNROLE_XRV_NONPERSON_START_DATE);

        e.arg(concernRoleDtls.concernRoleName);
        e.arg(concernRoleDtls.registrationDate);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
      }
    }
    // END, CR00313069

    // Web address start date must not be later than the concern role end date
    if (!concernRoleDtls.endDate.isZero()) {
      if (details.startDate.after(concernRoleDtls.endDate)) {
        final AppException e = new AppException(
          curam.message.GENERALCONCERN.ERR_CONCERNROLE_XRV_START_DATE_END_DATE);

        e.arg(concernRoleDtls.concernRoleName);
        e.arg(concernRoleDtls.endDate);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          7);
      }

      // Web address end date must not be later than concern role end date
      if (!details.endDate.isZero()
        && details.endDate.after(concernRoleDtls.endDate)) {
        final AppException e = new AppException(
          curam.message.GENERALCONCERN.ERR_CONCERNROLE_XRV_END_DATE);

        e.arg(concernRoleDtls.concernRoleName);
        e.arg(concernRoleDtls.endDate);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          7);
      }

    }

  }

}
