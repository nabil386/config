/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.impl;

import com.google.inject.Inject;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.EVIDENCETREESTATUS;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.FINCOMPONENTTYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.ONCEOFFFINANCIALCOMPONENTTYPE;
import curam.codetable.PRODUCTCOMPONENTFCCONV;
import curam.codetable.PRODUCTCOVERPERIOD;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RULESCOMPONENTTARGET;
import curam.codetable.impl.RULESCOMPONENTFCTYPEEntry;
import curam.codetable.impl.RULESTAGTYPEEntry;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CachedCaseNomineeProdDelPatternFactory;
import curam.core.fact.CachedProductDeliveryFactory;
import curam.core.fact.CachedProductDeliveryPatternInfoFactory;
import curam.core.fact.CachedProductFactory;
import curam.core.fact.CaseDecisionFinancialCompFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.DeductionFCGenerationFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.UsersFactory;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CachedCaseNomineeProdDelPattern;
import curam.core.intf.CachedProductDeliveryPatternInfo;
import curam.core.intf.CaseDecisionFinancialComp;
import curam.core.intf.CaseHeader;
import curam.core.intf.DeductionFCGeneration;
import curam.core.intf.FinancialComponent;
import curam.core.intf.MaintainCase;
import curam.core.intf.MaintainFinancialComponent;
import curam.core.intf.Notification;
import curam.core.intf.ProductDelivery;
import curam.core.intf.UniqueID;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.BenefitUnderpaymentEvidenceFactory;
import curam.core.sl.entity.fact.CaseNomineeFactory;
import curam.core.sl.entity.fact.LiabilityOverbillingEvidenceFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.fact.OverpaymentEvidenceFactory;
import curam.core.sl.entity.intf.BenefitUnderpaymentEvidence;
import curam.core.sl.entity.intf.CaseNominee;
import curam.core.sl.entity.intf.LiabilityOverbillingEvidence;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.intf.OverpaymentEvidence;
import curam.core.sl.entity.struct.BenefitUnderpaymentEvidenceDtls;
import curam.core.sl.entity.struct.BenefitUnderpaymentEvidenceKey;
import curam.core.sl.entity.struct.CaseNomineeDetails;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternDtls;
import curam.core.sl.entity.struct.CaseNomineeViewKey;
import curam.core.sl.entity.struct.DeliveryPatternByCaseDateStatusKey;
import curam.core.sl.entity.struct.LiabilityOverbillingEvidenceDtls;
import curam.core.sl.entity.struct.LiabilityOverbillingEvidenceKey;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.OverpaymentEvidenceDtls;
import curam.core.sl.entity.struct.OverpaymentEvidenceKey;
import curam.core.sl.fact.CaseEvidenceAPIFactory;
import curam.core.sl.fact.CaseStatusModeFactory;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineHooks;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculator;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.assessment.impl.EligibilityEntitlementRuleSet;
import curam.core.sl.infrastructure.assessment.impl.FCGenerationHook;
import curam.core.sl.infrastructure.assessment.impl.ObjectiveType;
import curam.core.sl.infrastructure.assessment.impl.TagType;
import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.intf.CaseEvidenceAPI;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseStatusModeDetails;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeDetails;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeKey;
import curam.core.sl.struct.ListActiveInEditEvidenceKey;
import curam.core.sl.struct.ListActiveInEditEvidenceResult;
import curam.core.struct.CalculateAmountDtls;
import curam.core.struct.CalculateAmountKey;
import curam.core.struct.CaseDecisionFinancialCompDtls;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.ComponentCaseDecisionLinkList;
import curam.core.struct.ComponentDetails;
import curam.core.struct.ComponentDetailsList;
import curam.core.struct.Count;
import curam.core.struct.DateStruct;
import curam.core.struct.DeductionItemFinCompDetailsList;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.FCProcessingDtls;
import curam.core.struct.FCTestDates;
import curam.core.struct.FCstatusCodeCaseID;
import curam.core.struct.FinComponentDecisionDetails;
import curam.core.struct.FinComponentDecisionDetailsList;
import curam.core.struct.FinComponentID;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.GetFCDatesAndValuesKey;
import curam.core.struct.InsertAssignmentInd;
import curam.core.struct.IsPaymentDateResult;
import curam.core.struct.OverUnderPaymentIn;
import curam.core.struct.PDPIByProdDelPatIDStatusAndDateKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryFinCompDtls;
import curam.core.struct.ProductDeliveryFinCompDtlsList;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.ReassessmentMode;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOFCGENERATIONUTIL;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;
import java.util.List;

/**
 * Code to generate financial Components associated with a given case decision.
 * Code was refactored from GenerateFinancialComponents.java.
 */
public abstract class FCGenerationUtil
  extends curam.core.base.FCGenerationUtil {

  // BEGIN, CR00171379, MH
  protected boolean recurringFCExists;

  // END, CR00171379

  // BEGIN, CR00021648, CMB
  protected boolean adjustForPatternTypeInd;

  // END, CR00021648

  // BEGIN, CR00211744, VM
  @Inject
  AssessmentEngineHooks assessmentEngineHooks;

  // END, CR00211744

  // BEGIN, CR00421880, BD
  @Inject(optional = true)
  private FCGenerationHook fcGenerationHook;

  // END, CR00421880, BD

  // BEGIN, CR00210098, KH
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;

  // END, CR00210098

  // BEGIN, CR00174295, CD
  /**
   * Reference to determination calculator factory.
   */
  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  /**
   * Constructor.
   */
  public FCGenerationUtil() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00174295

  // ___________________________________________________________________________
  /**
   * This operation compares two Financial Components.
   *
   * @param p1
   * The Product delivery financial component
   * @param f2
   * The financial component
   *
   * @return boolean - True if the components match
   *
   * @throws AppException if calculation fails
   * @throws InformationalException Generic Exception Signature.
   */
  boolean isEqual(final ProductDeliveryFinCompDtls p1,
    final FinancialComponentDtls f2)
    throws AppException, InformationalException {

    boolean returnValue = false;

    if (p1.concernRoleID == f2.concernRoleID
      && p1.caseNomineeID == f2.caseNomineeID && p1.caseID == f2.caseID
      && p1.componentCategory.equals(f2.categoryCode)
      && p1.componentType.equals(f2.typeCode) && p1.endDate.equals(f2.endDate)
      && p1.amount.getValue() == f2.amount.getValue() && p1.rate == f2.rate
      && p1.fundID == f2.fundID
      && p1.nomineeDelivMethod.equals(f2.nomineeDelivMethod)
      && p1.productID == f2.productID && p1.caseType.equals(f2.caseTypeCode)
      && p1.currencyType.equals(f2.currencyTypeCode)
      && p1.rulesObjectiveID.equals(f2.rulesObjectiveID)
      && p1.frequency.equals(f2.frequency)
      && p1.coverPeriodType.equals(f2.coverPeriodType)
      && p1.startDate.equals(f2.startDate)) {

      returnValue = true;
    }

    return returnValue;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if a date is a processing date.
   *
   * @param getFCDatesAndValuesKey
   * key struct containing frequency pattern
   * @param fcTestDates
   * The financial component dates to be tested
   *
   * @return true if the date is a valid payment date
   */
  @Override
  public IsPaymentDateResult isPaymentDate(
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final FCTestDates fcTestDates)
    throws AppException, InformationalException {

    final IsPaymentDateResult isPaymentDateResult = new IsPaymentDateResult();

    // set isPaymentDateResult.result flag to false
    isPaymentDateResult.result = false;

    // frequencyPattern variable
    final String frequencyPattern = getFCDatesAndValuesKey.deliveryFrequency;

    // temporary date variable for comparison testing purposes
    Date tempDate = fcTestDates.paymentDate;

    if (!fcTestDates.testDate.isZero()
      && fcTestDates.testDate.before(tempDate)) {

      while (!fcTestDates.testDate.after(tempDate)) {

        if (fcTestDates.testDate.compareTo(tempDate) == 0) {

          isPaymentDateResult.result = true;
        }

        tempDate =
          new FrequencyPattern(frequencyPattern).getPrevOccurrence(tempDate);
      }

    } else if (!tempDate.isZero()) {

      // BEGIN, CR00302918, CW
      // Set the temporary date to the previous occurrence of the frequency
      // pattern
      tempDate =
        new FrequencyPattern(frequencyPattern).getPrevOccurrence(tempDate);
      // END, CR00302918

      while (!fcTestDates.testDate.before(tempDate)) {

        if (fcTestDates.testDate.compareTo(tempDate) == 0) {

          isPaymentDateResult.result = true;
        }

        tempDate =
          new FrequencyPattern(frequencyPattern).getNextOccurrence(tempDate);
      }
    }

    return isPaymentDateResult;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to calculate the financial value associated with a
   * financial component.
   *
   * @param calculateAmountKey
   * the details of the FC needed to calculate its value
   * @param componentCaseDecisionLinkList
   * List of decision details that were original used to create the FC
   *
   * @return the value of the FC
   *
   * @deprecated since Curam v6.0, replaced with
   * {@link AssessmentEngineHooks#calculateAmount(CalculateAmountKey, ComponentCaseDecisionLinkList)}
   */
  @Override
  @Deprecated
  public CalculateAmountDtls calculateAmount(
    final CalculateAmountKey calculateAmountKey, // BEGIN, CR00078445, VM
    final ComponentCaseDecisionLinkList componentCaseDecisionLinkList)
    throws AppException, InformationalException {

    // BEGIN, CR00211744, VM
    return assessmentEngineHooks.calculateAmount(calculateAmountKey,
      componentCaseDecisionLinkList);
    // END, CR00211744
  }

  // END, CR00078445

  // ___________________________________________________________________________
  /**
   * This method will generate the FC's in advance of the last payment date for
   * this case.
   *
   * @param componentDetailsList
   * The list of components from which the FCs should be generated
   * @param reassessmentMode
   * determines which reassessment mode the application is running in
   * @param overUnderPaymentIn
   * Contains the case identifier
   *
   * @return <code>TRUE</code> if the financial components were created
   * successfully or <code>FALSE</code> if the period covered by the
   * reassessment needs to be widened.
   */
  @Override
  public boolean generateFutureFCs(ComponentDetailsList componentDetailsList,
    final ReassessmentMode reassessmentMode,
    final OverUnderPaymentIn overUnderPaymentIn)
    throws AppException, InformationalException {

    final DeductionFCGeneration deductionFCGenerationObj =
      DeductionFCGenerationFactory.newInstance();

    final FinancialComponent financialComponentObj =
      FinancialComponentFactory.newInstance();
    FinancialComponentDtlsList currentFinancialComponents;

    final MaintainFinancialComponent maintainFinancialComponentObj =
      MaintainFinancialComponentFactory.newInstance();

    final CaseDecisionFinancialComp caseDecisionFinancialCompObj =
      CaseDecisionFinancialCompFactory.newInstance();
    final CaseDecisionFinancialCompDtls caseDecisionFinancialCompDtls =
      new CaseDecisionFinancialCompDtls();

    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // BEGIN, CR00211744, VM
    componentDetailsList = assessmentEngineHooks
      .manipulateFinancialComponents(componentDetailsList);
    // END, CR00211744

    final FinComponentDecisionDetailsList finComponentDecisionDetailsList =
      new FinComponentDecisionDetailsList();
    int newFCCount = 0;

    // financialComponent identifier variables
    FinComponentID financialComponentID = new FinComponentID();

    // BEGIN, CR00001064, KH
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = overUnderPaymentIn.caseID;
    // END, CR00001064

    boolean matchFound = false;

    // Read back list of once-off types
    final StringList onceOffFCTypeList =
      CodeTable.getDistinctCodesForAllLanguages(
        ONCEOFFFINANCIALCOMPONENTTYPE.TABLENAME);

    final InsertAssignmentInd insertAssignmentInd = new InsertAssignmentInd();

    insertAssignmentInd.insertAssignmentInd = true;

    // for each decision component generate the FC details
    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      final FinComponentDecisionDetails finComponentDecisionDetails =
        new FinComponentDecisionDetails();

      finComponentDecisionDetails.productDeliveryFinCompDtlsList =
        generateFCDetails(componentDetailsList.dtls.item(i), // BEGIN,
          // CR00078445, VM
          componentDetailsList.dtls.item(i).componentCaseDecisionLinkList);
      // END, CR00078445

      finComponentDecisionDetails.componentCaseDecisionLinkList =
        componentDetailsList.dtls.item(i).componentCaseDecisionLinkList;

      finComponentDecisionDetailsList.dtls
        .addRef(finComponentDecisionDetails);

      newFCCount +=
        finComponentDecisionDetails.productDeliveryFinCompDtlsList.dtls
          .size();
    } // end for i

    // BEGIN, CR00001064, KH
    if (componentDetailsList.dtls.size() > 0) {

      // Variable to hold the deduction FC details
      final FinComponentDecisionDetails deductionFCDecisionDetails =
        new FinComponentDecisionDetails();

      // Now get the Deduction FC details for comparison
      final DeductionItemFinCompDetailsList deductionItemFCDtlsList =
        deductionFCGenerationObj.generateDeductionFCDetails(caseHeaderKey);

      // Iterate through the list returned and add to deductionFCDecisionDetails
      for (int n = 0; n < deductionItemFCDtlsList.dtls.size(); n++) {

        final ProductDeliveryFinCompDtls productDeliveryFinCompDtls =
          new ProductDeliveryFinCompDtls();

        // Assign details
        productDeliveryFinCompDtls
          .assign(deductionItemFCDtlsList.dtls.item(n));

        deductionFCDecisionDetails.productDeliveryFinCompDtlsList.dtls
          .addRef(productDeliveryFinCompDtls);
      } // end for n

      // Add deduction FCs to complete FC list
      finComponentDecisionDetailsList.dtls.addRef(deductionFCDecisionDetails);

      newFCCount +=
        deductionFCDecisionDetails.productDeliveryFinCompDtlsList.dtls.size();
    }
    // END, CR00001064

    // set key to read financialComponent - returns ALL live FCs on this case
    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();

    fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    // read financialComponent
    currentFinancialComponents =
      financialComponentObj.searchByStatusCaseID(fcStatusCodeCaseID);

    boolean periodChangeNeeded = false;

    // need to check if any of the current financial components span into or
    // out of the period being reassessed without being fully contained in it.
    for (int i = 0; i < currentFinancialComponents.dtls.size(); i++) {

      final FinancialComponentDtls currentFC =
        currentFinancialComponents.dtls.item(i);

      // BEGIN, CR00383276, KH
      /*
       * Deduction FCs should not be included when calculating these dates,
       * only FCs which are derived from case decisions should be considered.
       */
      if (!FINCOMPONENTTYPE.DEDUCTIONPAYMENT.equals(currentFC.typeCode)) {

        // if the FC starts before the fromDate and ends after the from date we
        // need to widen the period
        if (currentFC.startDate.before(overUnderPaymentIn.fromDate)
          && !currentFC.endDate.isZero()
          && !currentFC.endDate.before(overUnderPaymentIn.fromDate)) {

          overUnderPaymentIn.fromDate = currentFC.startDate;
          periodChangeNeeded = true;
        }

        if (currentFC.endDate.after(overUnderPaymentIn.toDate)
          && !currentFC.startDate.after(overUnderPaymentIn.toDate)) {

          overUnderPaymentIn.toDate = currentFC.endDate;
          periodChangeNeeded = true;
        }
      }
      // END, CR00383276

    } // end for i

    if (periodChangeNeeded) {
      return false;
    }

    // flag to indicate regeneration of all FCs
    boolean regenerateAllFCs = false;

    // The first thing to do is see if the size of the two lists are the same
    // In the case where the size of the lists vary, we will regenerate
    // everything from the completeFinCompDtlsList list and expire everything
    // in the currentFinancialComponents list
    if (newFCCount > 0
      && currentFinancialComponents.dtls.size() != newFCCount) {

      regenerateAllFCs = true;

      // BEGIN, CR00001064, KH
    } else {

      // Here we now need to deal with the scenario where the size of the lists
      // are the same, i.e. currentFinancialComponents and
      // completeFinCompDtlsList
      int r = 0;
      int s = 0;

      // Create a copy of the currentFinancialComponents list so we can remove
      // matching FCs as they are found below (this prevents an FC from being
      // matched multiple times).
      final FinancialComponentDtlsList tempCurrentFinancialComponents =
        new FinancialComponentDtlsList();

      tempCurrentFinancialComponents.assign(currentFinancialComponents);

      // If the 'newFCCount' is zero this list will be empty
      for (r = 0; r < finComponentDecisionDetailsList.dtls.size(); r++) {

        final FinComponentDecisionDetails currentFinComponentDecisionDetails =
          finComponentDecisionDetailsList.dtls.item(r);

        for (int j =
          0; j < currentFinComponentDecisionDetails.productDeliveryFinCompDtlsList.dtls
            .size(); j++) {

          final ProductDeliveryFinCompDtls currentProductDeliveryFinCompDtls =
            currentFinComponentDecisionDetails.productDeliveryFinCompDtlsList.dtls
              .item(j);

          matchFound = false;

          for (s = 0; s < tempCurrentFinancialComponents.dtls.size(); s++) {

            if (isEqual(currentProductDeliveryFinCompDtls,
              tempCurrentFinancialComponents.dtls.item(s))) {

              // Exact match found
              matchFound = true;

              // If a match is found remove the relevant FC from the list
              tempCurrentFinancialComponents.dtls.remove(s);

              break;
            }
          } // end for s

          // If we have iterated through all records and haven't found a match
          if (!matchFound) {

            // There's at least one different, so we break out of the for
            // loop and regenerate all the FCs
            // We don't want to iterate around the 'r' loop any more so set
            // r to the size of its list
            r = finComponentDecisionDetailsList.dtls.size();
            break;
          }
        } // end for j
      } // end for r

    }
    // BEGIN, CR00281001, AKr
    boolean deductionsCreated = false;

    // END, CR00281001

    if (regenerateAllFCs || !matchFound) {
      // END, CR00001064

      // If the 'newFCCount' is zero this list will be empty
      for (int p = 0; p < finComponentDecisionDetailsList.dtls.size(); p++) {

        final FinComponentDecisionDetails currentFinComponentDecisionDetails =
          finComponentDecisionDetailsList.dtls.item(p);

        for (int j =
          0; j < currentFinComponentDecisionDetails.productDeliveryFinCompDtlsList.dtls
            .size(); j++) {

          final ProductDeliveryFinCompDtls currentProductDeliveryFinCompDtls =
            currentFinComponentDecisionDetails.productDeliveryFinCompDtlsList.dtls
              .item(j);

          // insert new FC
          if (currentProductDeliveryFinCompDtls.componentType
            .equals(FINCOMPONENTTYPE.LOANREPAYMENT)) {

            // add repayment schedule financial component
            financialComponentID = maintainFinancialComponentObj
              .addRepaymentScheduleFC(currentProductDeliveryFinCompDtls);

          } else {

            // Don't want to process these as they will be taken care of below
            if (!(currentProductDeliveryFinCompDtls.componentCategory
              .equals(FINCOMPONENTCATEGORY.HOUSEHOLDBUDGETITEM)
              || currentProductDeliveryFinCompDtls.componentCategory
                .equals(FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM))) {

              // add product delivery financial component
              financialComponentID = maintainFinancialComponentObj
                .addProductDeliveryFinComp(currentProductDeliveryFinCompDtls);
            }
          }

          // Insert as many CaseDecisionFinancialComponent records as
          // needed (at least 1)
          for (int q =
            0; q < currentFinComponentDecisionDetails.componentCaseDecisionLinkList.dtls
              .size(); q++) {

            // set caseDecisionFinancialComponent details for insert
            caseDecisionFinancialCompDtls.caseDecisionID =
              currentFinComponentDecisionDetails.componentCaseDecisionLinkList.dtls
                .item(q).caseDecisionID;

            // BEGIN, CR00068167, KH
            caseDecisionFinancialCompDtls.caseDecisionObjectiveID =
              currentFinComponentDecisionDetails.componentCaseDecisionLinkList.dtls
                .item(q).caseDecisionObjectiveID;
            // END, CR00068167

            caseDecisionFinancialCompDtls.financialCompID =
              financialComponentID.finComponentID;
            caseDecisionFinancialCompDtls.caseDecisionFinCompID =
              uniqueIDObj.getNextID();

            caseDecisionFinancialCompObj
              .insert(caseDecisionFinancialCompDtls);
          } // end for q
        } // end for j
      } // end for p

      // BEGIN, CR00001064, KH
      if (componentDetailsList.dtls.size() > 0) {

        deductionFCGenerationObj.createDeductionFCs(caseHeaderKey);
        // BEGIN, CR00281001, AKr
        deductionsCreated = true;
        // END, CR00281001

      }
      // END, CR00001064

      final DateRange decisionDateRange =
        new DateRange(overUnderPaymentIn.fromDate, overUnderPaymentIn.toDate);

      // We now need to expire all FCs that were originally on the database
      for (int q = 0; q < currentFinancialComponents.dtls.size(); q++) {

        final DateRange fcDateRange =
          new DateRange(currentFinancialComponents.dtls.item(q).startDate,
            currentFinancialComponents.dtls.item(q).endDate);

        if (fcDateRange.overlapsWith(decisionDateRange)) {

          // Don't want to expire once-off FC types such as benefit
          // underpayments, liability under/over payments as these will not
          // have been regenerated above
          if (!onceOffFCTypeList
            .contains(currentFinancialComponents.dtls.item(q).typeCode)) {

            maintainFinancialComponentObj
              .expireFinancialComp(currentFinancialComponents.dtls.item(q));
          }
        } // Otherwise they're before the decision, and we can leave them
      } // end for q
    } // end if (regenerateAllFCs || !matchFound)
    // BEGIN, CR00281001, AK
    // Expiring existing Deductions FCs here as there may be a chance
    // that another overlapping one has been created via the
    // createDeductionFCs call above
    if (deductionsCreated) {
      for (final FinancialComponentDtls dtls : currentFinancialComponents.dtls
        .items()) {
        if (FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM
          .equals(dtls.categoryCode)) {
          maintainFinancialComponentObj.expireFinancialComp(dtls);
        }
      }
    }
    // END, CR00281001

    // set key to read financialComponent - returns ALL live FCs on this case
    fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    // Check if live financialComponents exist on this case - count will be
    // zero if they don't
    final Count count =
      financialComponentObj.countByCaseIDAndStatus(fcStatusCodeCaseID);

    // If there were live FCs to start with (if we're reassessing for instance)
    // and now there are none (certification was deleted say), then a
    // notification will be sent to the case owner. The check against the
    // currentFinancialComponents list being empty prevents a notification being
    // sent in the scenarios where someone adds a deduction/utility to a case
    // after all payments have been issued on the case. In this instance, a
    // user may intend to either lengthen certification or add a new
    // certification after adding the deduction/utility.
    if (!currentFinancialComponents.dtls.isEmpty()
      && count.numberOfRecords == 0) {

      // Set key for sending notification
      final CaseID caseID = new CaseID();

      caseID.caseID = overUnderPaymentIn.caseID;

      // Send notification about case with all financials expired
      sendNotification(caseID);
    }

    return true;
  }

  // ___________________________________________________________________________
  /**
   * This method generates the details of the FC's to be generated in respect of
   * a component.
   *
   * @param componentDetails
   * The component details
   * @param componentCaseDecisionLinkList
   * List of decision details from which the "virtual" FCs were created
   *
   * @return a list of the financial components generated based on this
   * component.
   */
  @Override
  public ProductDeliveryFinCompDtlsList generateFCDetails(
    final ComponentDetails componentDetails, // BEGIN, CR00078445, VM
    final ComponentCaseDecisionLinkList componentCaseDecisionLinkList)
    // END, CR00078445
    throws AppException, InformationalException {

    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList =
      new ProductDeliveryFinCompDtlsList();

    final GetFCDatesAndValuesKey getFCDatesAndValuesKey =
      new GetFCDatesAndValuesKey();
    final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj =
      CachedProductDeliveryPatternInfoFactory.newInstance();
    final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey =
      new PDPIByProdDelPatIDStatusAndDateKey();
    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls;

    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls =
      new ProductDeliveryFinCompDtls();
    ProductDeliveryFinCompDtlsList componentProductDeliveryFinCompDtlsList =
      new ProductDeliveryFinCompDtlsList();

    // set key to read caseHeader
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = componentDetails.caseID;
    final CaseHeaderDtls caseHeaderDtls =
      CachedCaseHeaderFactory.newInstance().read(caseHeaderKey);

    // set key to read productDelivery
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = componentDetails.caseID;

    final ProductDeliveryDtls productDeliveryDtls =
      CachedProductDeliveryFactory.newInstance().read(productDeliveryKey);

    // set key to read product
    final ProductKey productKey = new ProductKey();

    productKey.productID = productDeliveryDtls.productID;
    final ProductDtls productDtls =
      CachedProductFactory.newInstance().read(productKey);

    // BEGIN, CR00174295, CD
    final DeterminationCalculator determinationCalculator =
      determinationCalculatorFactory
        .newInstanceForProductID(productDeliveryDtls.productID);

    // BEGIN, CR00243265, KH
    /*
     * Find the rule set which applies on the from date of the component. A
     * rule set must exist on this date for the component to have been
     * deemed eligible.
     */
    final EligibilityEntitlementRuleSet ruleSet = determinationCalculator
      .getEligibilityEntitlementRuleSet(componentDetails.fromDate);
    // END, CR00243265

    final ObjectiveType objectiveType =
      ruleSet.getObjectiveType(componentDetails.objectiveID);
    // END, CR00174295

    // BEGIN, CR00174782, CD
    final List<? extends TagType> tagTypeList = objectiveType.getTagTypes();

    if (!tagTypeList.isEmpty()) {

      if (!tagTypeList.get(0).getValueType()
        .equals(RULESTAGTYPEEntry.MONEY)) {
        // END, CR00174782
        return productDeliveryFinCompDtlsList;
      }
    } else {
      return productDeliveryFinCompDtlsList;
    }

    if (productDtls.benefitInd) {
      productDeliveryFinCompDtls.componentCategory =
        FINCOMPONENTCATEGORY.CLAIM;
    } else {
      productDeliveryFinCompDtls.componentCategory =
        FINCOMPONENTCATEGORY.LIABILITY;
    }

    // lookup translation code table to convert Product Component Type to
    // Financial Component Type.
    // BEGIN, CR00174295, CD
    productDeliveryFinCompDtls.componentType = CodeTable.getOneItem(
      PRODUCTCOMPONENTFCCONV.TABLENAME, objectiveType.getName().getCode());
    // END, CR00174295

    if (productDeliveryFinCompDtls.componentType == null) {

      // throw exception if can't find conversion code
      final AppException e = new AppException(
        BPOFCGENERATIONUTIL.ERR_ID_PRODCOMP_TO_FINCOMP_CONV_FAILURE);

      // BEGIN, CR00174295, CD
      e.arg(objectiveType.getName().getCode());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID =
      componentDetails.productDeliveryPatternID;

    // get the delivery frequency from the product delivery pattern
    pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
    pdpiByProdDelPatIDStatusAndDateKey.effectiveDate =
      componentDetails.fromDate;

    try {
      productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
        .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);
    } catch (final RecordNotFoundException e) {

      // removed read on nominee entity as we will always have nomineeName
      final AppException ae = new AppException(
        BPOFCGENERATIONUTIL.ERR_NO_NOMINEE_DELIVERY_PATTERN_ON_DATE);

      ae.arg(componentDetails.nomineeName);
      ae.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
      throw ae;
    }

    // set key to read deliveryMethod
    final DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    deliveryMethodKey.deliveryMethodID =
      productDeliveryPatternInfoDtls.deliveryMethodID;

    final DeliveryMethodDtls deliveryMethodDtls =
      DeliveryMethodFactory.newInstance().read(deliveryMethodKey);

    if (componentDetails.rulesComponentTarget
      .equals(RULESCOMPONENTTARGET.PRODUCTPROVIDER)
      || componentDetails.rulesComponentTarget
        .equals(RULESCOMPONENTTARGET.SERVICESUPPLIER)) {

      productDeliveryFinCompDtls.concernRoleID =
        componentDetails.concernRoleID;
    } else {
      productDeliveryFinCompDtls.concernRoleID = caseHeaderDtls.concernRoleID;
    }

    // BEGIN, CR00074927, KH
    // BEGIN, CR00174295, CD
    // BEGIN, CR00404532, CW
    productDeliveryFinCompDtls.inRespectOfID =
      componentDetails.inRespectOfIDOpt;
    // END, CR00404532
    // END, CR00174295
    // END, CR00074927

    // BEGIN, CR00175021, KH
    // Set the description
    // This will hold the related reference for a list objective
    productDeliveryFinCompDtls.relatedReference =
      componentDetails.relatedReference;
    // END, CR00175021

    productDeliveryFinCompDtls.caseID = componentDetails.caseID;
    productDeliveryFinCompDtls.caseType = caseHeaderDtls.caseTypeCode;
    productDeliveryFinCompDtls.fundID = productDtls.fundID;
    productDeliveryFinCompDtls.primaryClientID = caseHeaderDtls.concernRoleID;
    productDeliveryFinCompDtls.productID = productDeliveryDtls.productID;
    productDeliveryFinCompDtls.rulesObjectiveID =
      componentDetails.objectiveID;
    productDeliveryFinCompDtls.caseNomineeID = componentDetails.caseNomineeID;
    productDeliveryFinCompDtls.nomineeDelivMethod = deliveryMethodDtls.name;
    productDeliveryFinCompDtls.coverPeriodType =
      productDeliveryPatternInfoDtls.coverPattern;
    productDeliveryFinCompDtls.coverPeriodOffset =
      productDeliveryPatternInfoDtls.offset;
    productDeliveryFinCompDtls.deliveryMethodOffset =
      deliveryMethodDtls.offset;
    productDeliveryFinCompDtls.currencyType =
      componentDetails.currencyTypeCode;
    productDeliveryFinCompDtls.maximumAmount =
      productDeliveryPatternInfoDtls.maximumAmount;
    productDeliveryFinCompDtls.productDelPatInfoStartDate =
      productDeliveryPatternInfoDtls.fromDate;
    productDeliveryFinCompDtls.frequency =
      productDeliveryPatternInfoDtls.deliveryFrequency;
    productDeliveryFinCompDtls.adjustmentInd = productDtls.adjustmentInd;

    // BEGIN, CR00089535, CW
    // Set instrumentGenInd to false for ERP systems as no instrument is
    // generated
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()) {
      // ERP system is enabled
      productDeliveryFinCompDtls.instrumentGenInd = false;
    } else {
      // ERP system is not enabled
      productDeliveryFinCompDtls.instrumentGenInd = true;
    }
    // END, CR00089535

    // if the rules Component FC Type is Liability, then the delivery method
    // is always invoice.

    // This section should not be required, the financial component type
    // should be stored on the Rules component.

    // BEGIN, CR00174295, CD
    final List<? extends ObjectiveType> objectiveTypeList =
      ruleSet.getObjectiveTypes();

    for (int j = 0; j < objectiveTypeList.size(); j++) {

      if (objectiveTypeList.get(j).getID()
        .equals(componentDetails.objectiveID)
        && objectiveTypeList.get(j).getFinancialComponentType()
          .equals(RULESCOMPONENTFCTYPEEntry.LIABILITY)) {
        // END, CR00174295
        productDeliveryFinCompDtls.nomineeDelivMethod =
          METHODOFDELIVERY.INVOICE;
        break;
      }
    }

    getFCDatesAndValuesKey.caseID = productDeliveryFinCompDtls.caseID;
    getFCDatesAndValuesKey.coverPeriodOffsetAmount =
      productDeliveryFinCompDtls.coverPeriodOffset;
    getFCDatesAndValuesKey.coverPeriodType =
      productDeliveryFinCompDtls.coverPeriodType;
    getFCDatesAndValuesKey.deliveryFrequency =
      productDeliveryFinCompDtls.frequency;
    getFCDatesAndValuesKey.endDate = componentDetails.toDate;
    getFCDatesAndValuesKey.productID = productDeliveryFinCompDtls.productID;
    getFCDatesAndValuesKey.startDate = componentDetails.fromDate;

    // BEGIN, CR00078445, VM
    componentProductDeliveryFinCompDtlsList =
      getFCDatesAndValues(getFCDatesAndValuesKey, productDeliveryFinCompDtls,
        componentDetails, componentCaseDecisionLinkList);
    // END, CR00078445

    for (int j = 0; j < componentProductDeliveryFinCompDtlsList.dtls
      .size(); j++) {

      productDeliveryFinCompDtlsList.dtls
        .addRef(componentProductDeliveryFinCompDtlsList.dtls.item(j));
    }

    return productDeliveryFinCompDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method works out the appropriate dates and values for the FC's.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * the shared details for the FC's
   * @param componentDetails
   * the component from which the FC's should be generated.
   * @param componentCaseDecisionLinkList
   * List of decision details from which the "virtual" FCs were created
   *
   * @return The list of the FC's generated.
   */
  @Override
  public ProductDeliveryFinCompDtlsList getFCDatesAndValues(
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    final ComponentDetails componentDetails, // BEGIN, CR00078445, VM
    final ComponentCaseDecisionLinkList componentCaseDecisionLinkList)
    // END, CR00078445
    throws AppException, InformationalException {

    ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList =
      new ProductDeliveryFinCompDtlsList();

    getFCDates(getFCDatesAndValuesKey, productDeliveryFinCompDtls,
      productDeliveryFinCompDtlsList);

    // BEGIN, CR00078445, VM
    getFCValues(getFCDatesAndValuesKey, productDeliveryFinCompDtls,
      productDeliveryFinCompDtlsList, componentDetails,
      componentCaseDecisionLinkList);
    // END, CR00078445

    // BEGIN, CR00421880, BD
    if (fcGenerationHook != null) {

      productDeliveryFinCompDtlsList =
        fcGenerationHook.getFCDatesAndValues(productDeliveryFinCompDtlsList,
          getFCDatesAndValuesKey, productDeliveryFinCompDtls,
          componentDetails, componentCaseDecisionLinkList);
    }
    // END, CR00421880

    return productDeliveryFinCompDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method works out the appropriate dates for the FC's.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * the shared details for the FC's
   * @param productDeliveryFinCompDtlsList
   * list of product delivery Financial Component details
   */
  @Override
  public void getFCDates(final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList)
    throws AppException, InformationalException {

    // testDate variable
    Date testDate = Date.kZeroDate;

    Date tempDate = Date.kZeroDate;

    // BEGIN, CR00051171, NRV
    String frequencyPattern =
      FrequencyPattern.kZeroFrequencyPattern.toString();

    final DateStruct mainFCStartDateStruct = new DateStruct();
    final DateStruct mainFCEndDateStruct = new DateStruct();

    Date mainFCStartDate = Date.kZeroDate;
    Date mainFCEndDate = Date.kZeroDate;

    // END, CR00051171

    // set frequency pattern
    frequencyPattern = getFCDatesAndValuesKey.deliveryFrequency;

    // fcTestDates variable
    final FCTestDates fcTestDates = new FCTestDates();

    // IsPaymentDateResult variables
    IsPaymentDateResult isKeyStartDatePaymentDate;
    IsPaymentDateResult isKeyDayAfterEndDatePaymentDate = null;

    final ProductDeliveryFinCompDtls newProductDeliveryFinCompDtls =
      new ProductDeliveryFinCompDtls();

    newProductDeliveryFinCompDtls.assign(productDeliveryFinCompDtls);

    // CachedCaseHeader manipulation variables
    final CachedCaseHeader cachedCaseHeaderObj =
      CachedCaseHeaderFactory.newInstance();

    // BEGIN, CR00021648, CMB
    adjustForPatternTypeInd = false;
    // END, CR00021648

    // Set key to read CachedCaseHeader
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = productDeliveryFinCompDtls.caseID;

    // Read cachedCaseHeader
    final CaseHeaderDtls caseHeaderDtls =
      cachedCaseHeaderObj.read(caseHeaderKey);

    // Set test date to be the effective date of the case
    testDate = caseHeaderDtls.effectiveDate;

    // Check if the test date is later than getFCDatesAndValuesKey.startDate
    if (testDate.after(getFCDatesAndValuesKey.startDate)) {

      // roll the test date back before getFCDatesAndValuesKey.startDate
      while (testDate.after(getFCDatesAndValuesKey.startDate)) {

        testDate =
          new FrequencyPattern(frequencyPattern).getPrevOccurrence(testDate);
      }
    }

    while (!testDate.after(getFCDatesAndValuesKey.startDate)) {

      testDate =
        new FrequencyPattern(frequencyPattern).getNextOccurrence(testDate);
    }

    fcTestDates.paymentDate = testDate;
    fcTestDates.testDate = getFCDatesAndValuesKey.startDate;

    isKeyStartDatePaymentDate =
      isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

    // if the first date supplied (getFCDatesAndValuesKey.startDate)
    // is a payment date, then the testDate should be set to this
    // as it is in sync with the delivery pattern
    if (isKeyStartDatePaymentDate.result) {
      testDate = getFCDatesAndValuesKey.startDate;
    }

    // if the pattern is daily, then the main FC Start date is the
    // getFCDatesAndValuesKey.startDate
    if (new FrequencyPattern(frequencyPattern)
      .equals(FrequencyPattern.kDailyPattern) // BEGIN, CR00021305, NK
      || new FrequencyPattern(frequencyPattern)
        .equals(FrequencyPattern.kEachWeekdayPattern)) {
      // END, CR00021305

      mainFCStartDate = getFCDatesAndValuesKey.startDate;
    } else {
      mainFCStartDate = testDate;
    }

    while (testDate.before(getFCDatesAndValuesKey.endDate)) {

      testDate =
        new FrequencyPattern(frequencyPattern).getNextOccurrence(testDate);
    }

    // if the pattern is daily, then the main FC End date is the test date
    if (new FrequencyPattern(frequencyPattern)
      .equals(FrequencyPattern.kDailyPattern) // BEGIN, CR00021305, NK
      || new FrequencyPattern(frequencyPattern)
        .equals(FrequencyPattern.kEachWeekdayPattern)) {
      // END, CR00021305

      if (!getFCDatesAndValuesKey.endDate.isZero()) {
        mainFCEndDate = testDate;
      } else {
        mainFCEndDate = Date.kZeroDate;
      }

    } else {

      // otherwise
      if (!getFCDatesAndValuesKey.endDate.isZero()) {

        final Date dayAfterEndDate =
          getFCDatesAndValuesKey.endDate.addDays(1);

        if (!testDate.after(dayAfterEndDate)) {
          mainFCEndDate = testDate.addDays(-1);

        } else {

          mainFCEndDate = new FrequencyPattern(frequencyPattern)
            .getPrevOccurrence(testDate).addDays(-1);

          if (mainFCEndDate.before(mainFCStartDate)) {

            mainFCEndDate = testDate.addDays(-1);
            // BEGIN, CR00021648, CMB
            // We may be using a frequency pattern with a PatternType of daily
            // but
            // the pattern itself may not be daily => the pattern is of the type
            // Daily Every N Days.
            //
            // We have just set the mainFCEndDate to (testDate - 1) where
            // testDate
            // is in sync with the CaseHeader.effectiveDate, i.e. it is a
            // payment
            // date. Later on we get the previous occurrence of mainFCEndDate to
            // see if it's equal to mainFCStartDate. This is in order to
            // determine if we are dealing with a recurring pattern or not.
            // However, a previous occurrence of the mainFCEndDate will be one
            // day
            // earlier than the mainFCStartDate because the pattern is Every N
            // Days
            // on ANY date. We really need to add one day to the mainFCEndDate
            // before getting the previous occurrence.
            if (new FrequencyPattern(frequencyPattern).getPatternType()
              .equals(FrequencyPattern.PatternType.kDaily)
              && !new FrequencyPattern(frequencyPattern)
                .equals(FrequencyPattern.kDailyPattern)) {

              adjustForPatternTypeInd = true;
            }
            // END, CR00021648
          }
        }
      } else {
        mainFCEndDate = Date.kZeroDate;
      }
    }

    // BEGIN, CR00051171, NRV
    mainFCStartDateStruct.date = mainFCStartDate;
    mainFCEndDateStruct.date = mainFCEndDate;
    // END, CR00051171

    // special one day case
    if (getFCDatesAndValuesKey.startDate
      .compareTo(getFCDatesAndValuesKey.endDate) == 0) {

      newProductDeliveryFinCompDtls.startDate =
        getFCDatesAndValuesKey.startDate;
      newProductDeliveryFinCompDtls.endDate = getFCDatesAndValuesKey.endDate;
      // Explicitly setting the frequency to have a zero pattern
      newProductDeliveryFinCompDtls.frequency =
        FrequencyPattern.kZeroFrequencyPattern.toString();

      // BEGIN, CR00051171, NRV
      // get effective date for FC
      getEffectiveDateForFC(getFCDatesAndValuesKey,
        newProductDeliveryFinCompDtls, mainFCStartDateStruct,
        mainFCEndDateStruct);
      // END, CR00051171
      productDeliveryFinCompDtlsList.dtls
        .addRef(newProductDeliveryFinCompDtls);
      return;
    }

    // set payment date and test date
    fcTestDates.paymentDate = mainFCStartDate;
    fcTestDates.testDate = getFCDatesAndValuesKey.startDate;

    // check to see if the start date is a payment date
    isKeyStartDatePaymentDate =
      isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

    // set test date
    if (!getFCDatesAndValuesKey.endDate.isZero()) {
      fcTestDates.testDate = getFCDatesAndValuesKey.endDate.addDays(1);

      // check to see of the day after the end date is a payment date
      isKeyDayAfterEndDatePaymentDate =
        isPaymentDate(getFCDatesAndValuesKey, fcTestDates);
    }

    // If the frequency pattern is other than daily, a check needs to be
    // performed to see if a recurring FC needs to be generated or not. If this
    // check is not performed, a recurring FC may be generated in error. This
    // can happen in the situation where there will be a ramp-up FC,
    // ramp-down FC but should not be a main recurring one.
    //
    // Example: Friday June 4th 2004 to Wednesday June 9th 2004 with a pattern
    // of weekly in advance on a Monday

    if (mainFCEndDate.isZero()) {
      recurringFCExists = true;
    } else {

      if (!new FrequencyPattern(frequencyPattern)
        .equals(FrequencyPattern.kDailyPattern)) {

        // BEGIN, CR00021648, CMB
        if (adjustForPatternTypeInd) {
          tempDate = new FrequencyPattern(frequencyPattern)
            .getPrevOccurrence(mainFCEndDate.addDays(1));
        } else {

          tempDate = new FrequencyPattern(frequencyPattern)
            .getPrevOccurrence(mainFCEndDate);
        }
        // END, CR00021648

        if (tempDate.equals(mainFCStartDate)
          && getFCDatesAndValuesKey.endDate.before(mainFCEndDate)) {

          recurringFCExists = false;
        } else {
          recurringFCExists = true;
        }

      } else {
        // daily patterns will always have a recurring FC
        recurringFCExists = true;
      }
    }

    // If there is a start FC i.e. if the start date != a processing date
    // => a ramp-up Financial Component
    if (!isKeyStartDatePaymentDate.result || !recurringFCExists) {
      // BEGIN, CR00051171, NRV
      getStartFCDates(getFCDatesAndValuesKey, productDeliveryFinCompDtls,
        productDeliveryFinCompDtlsList, mainFCStartDateStruct,
        mainFCEndDateStruct);
      // END,CR00051171
    }

    if ((!mainFCEndDate.before(mainFCStartDate) || mainFCEndDate.isZero())
      && recurringFCExists) {
      // BEGIN, CR00051171, NRV
      getMainFCDates(getFCDatesAndValuesKey, productDeliveryFinCompDtls,
        productDeliveryFinCompDtlsList, mainFCStartDateStruct,
        mainFCEndDateStruct);
      // END,CR00051171
    }

    // If there are odd days after the end date, there must be
    // a ramp-down Financial Component
    if (isKeyDayAfterEndDatePaymentDate != null
      && !isKeyDayAfterEndDatePaymentDate.result) {
      // BEGIN, CR00051171, NRV
      getEndFCDates(getFCDatesAndValuesKey, productDeliveryFinCompDtls,
        productDeliveryFinCompDtlsList, mainFCStartDateStruct,
        mainFCEndDateStruct);
      // END, CR00051171
    }

  }

  // ___________________________________________________________________________
  /**
   * This method works out the next processing date for a FC.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * The shared details for the FC's
   */
  @Override
  public void getEffectiveDateForFC(
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    // BEGIN, CR00051171, NRV
    final DateStruct mainFCStartDateStruct,
    final DateStruct mainFCEndDateStruct)
    // END, CR00051171
    throws AppException, InformationalException {

    // nextProcessingDate variable
    Date nextProcessingDate = Date.kZeroDate;
    // BEGIN, CR00051171, NRV
    final String frequencyPattern = getFCDatesAndValuesKey.deliveryFrequency;
    final Date mainFCStartDate = mainFCStartDateStruct.date;
    final Date mainFCEndDate = mainFCEndDateStruct.date;
    // END, CR00051171
    final String nullFrequencyPattern =
      FrequencyPattern.kZeroFrequencyPattern.toString();

    // financialComponent manipulation variables
    final FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();
    final MaintainFinancialComponent maintainFinancialComponentObj =
      MaintainFinancialComponentFactory.newInstance();

    // fcTestDates manipulation variable
    final FCTestDates fcTestDates = new FCTestDates();

    // IsPaymentDateResult variables
    IsPaymentDateResult isFCStartDatePaymentDate;
    IsPaymentDateResult isFCEndDatePaymentDate;

    // if single day FC
    if (getFCDatesAndValuesKey.startDate
      .compareTo(getFCDatesAndValuesKey.endDate) == 0) {

      // if single day is a processing date
      fcTestDates.paymentDate = mainFCStartDate;
      fcTestDates.testDate = productDeliveryFinCompDtls.startDate;

      isFCStartDatePaymentDate =
        isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

      if (isFCStartDatePaymentDate.result) {
        nextProcessingDate = productDeliveryFinCompDtls.startDate;
      } else {
        // If productDeliveryFinCompDtls.startDate is not a payment date, just
        // get the previous occurrence of it based on the frequency pattern
        nextProcessingDate = new FrequencyPattern(frequencyPattern)
          .getPrevOccurrence(productDeliveryFinCompDtls.startDate);
      }

    } else {

      if (productDeliveryFinCompDtls.frequency.equals(nullFrequencyPattern)) {

        if (getFCDatesAndValuesKey.startDate
          .compareTo(productDeliveryFinCompDtls.startDate) == 0) {

          // for a ramp up FC
          fcTestDates.paymentDate = mainFCStartDate;
          fcTestDates.testDate = productDeliveryFinCompDtls.startDate;

          isFCStartDatePaymentDate =
            isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

          if (isFCStartDatePaymentDate.result) {
            nextProcessingDate = productDeliveryFinCompDtls.startDate;
          } else {

            if (productDeliveryFinCompDtls.startDate.after(mainFCStartDate)) {

              nextProcessingDate = new FrequencyPattern(frequencyPattern)
                .getPrevOccurrence(productDeliveryFinCompDtls.startDate);

            } else {

              nextProcessingDate = new FrequencyPattern(frequencyPattern)
                .getPrevOccurrence(mainFCStartDate);
            }
          }

        } else {

          if (getFCDatesAndValuesKey.endDate
            .compareTo(productDeliveryFinCompDtls.endDate) == 0) {

            if (!recurringFCExists) {

              nextProcessingDate = productDeliveryFinCompDtls.startDate;
            } else {

              // for a ramp down FC
              fcTestDates.paymentDate = mainFCStartDate;
              fcTestDates.testDate = productDeliveryFinCompDtls.endDate;

              isFCEndDatePaymentDate =
                isPaymentDate(getFCDatesAndValuesKey, fcTestDates);

              if (isFCEndDatePaymentDate.result) {

                nextProcessingDate = productDeliveryFinCompDtls.endDate;
              } else {
                nextProcessingDate = mainFCEndDate.addDays(1);
              }
            }
          }
        }

      } else {

        // for a recurring FC
        nextProcessingDate = productDeliveryFinCompDtls.startDate;
      }

    }

    if (!getFCDatesAndValuesKey.coverPeriodType
      .equals(PRODUCTCOVERPERIOD.ISSUEINARREARS)
      && !getFCDatesAndValuesKey.coverPeriodType
        .equals(PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET)) {

      productDeliveryFinCompDtls.dueDate = nextProcessingDate;

    } else {
      // due date has been calculated for issue in advance cover periods
      // to get issue in arrears etc. go to the next date
      productDeliveryFinCompDtls.dueDate =
        new FrequencyPattern(frequencyPattern)
          .getNextOccurrence(nextProcessingDate);
    }

    fcProcessingDtls.frequencyPattern = productDeliveryFinCompDtls.frequency;
    fcProcessingDtls.deliveryMethod =
      productDeliveryFinCompDtls.nomineeDelivMethod;
    fcProcessingDtls.dueDate = productDeliveryFinCompDtls.dueDate;
    fcProcessingDtls.coverPeriodOffset =
      productDeliveryFinCompDtls.coverPeriodOffset;
    fcProcessingDtls.deliveryMethodOffset =
      productDeliveryFinCompDtls.deliveryMethodOffset;
    fcProcessingDtls.coverPeriodType =
      productDeliveryFinCompDtls.coverPeriodType;

    // set next processing date
    maintainFinancialComponentObj.setNextProcessingDate(fcProcessingDtls);

    productDeliveryFinCompDtls.nextProcessingDate =
      fcProcessingDtls.nextProcessingDate;
  }

  // ___________________________________________________________________________
  /**
   * This method works out the start FC i.e. the FC from the start date of the
   * case of the case to the first processing date.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * The shared details for the FC's
   * @param productDeliveryFinCompDtlsList
   * The list of the FC's generated
   */
  @Override
  public void getStartFCDates(
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList,
    // BEGIN, CR00051171, NRV
    final DateStruct mainFCStartDateStruct,
    final DateStruct mainFCEndDateStruct)
    // END, CR00051171
    throws AppException, InformationalException {

    // must create new object so that we don't copy input struct
    final ProductDeliveryFinCompDtls newProductDeliveryFinCompDtls =
      new ProductDeliveryFinCompDtls();

    newProductDeliveryFinCompDtls.assign(productDeliveryFinCompDtls);

    newProductDeliveryFinCompDtls.frequency =
      FrequencyPattern.kZeroFrequencyPattern.toString();
    newProductDeliveryFinCompDtls.startDate =
      getFCDatesAndValuesKey.startDate;
    // BEGIN, CR00051171, NRV
    final Date mainFCStartDate = mainFCStartDateStruct.date;
    final Date mainFCEndDate = mainFCEndDateStruct.date;

    // END, CR00051171

    // test if case length is fully inside, or starts inside and ends on a
    // single delivery period
    if (!recurringFCExists) {

      if (getFCDatesAndValuesKey.startDate.before(mainFCStartDate)) {

        newProductDeliveryFinCompDtls.endDate = mainFCStartDate.addDays(-1);

      } else {

        if (!mainFCEndDate.after(getFCDatesAndValuesKey.endDate)) {

          newProductDeliveryFinCompDtls.endDate = mainFCEndDate;
        } else {
          newProductDeliveryFinCompDtls.endDate =
            getFCDatesAndValuesKey.endDate;
        }
      }
    } else {

      if (!mainFCEndDate.after(getFCDatesAndValuesKey.endDate)) {

        newProductDeliveryFinCompDtls.endDate = mainFCStartDate.addDays(-1);

      } else {

        newProductDeliveryFinCompDtls.endDate =
          getFCDatesAndValuesKey.endDate;
      }
    }
    // BEGIN, CR00051171, NRV
    // get effective date for FC
    getEffectiveDateForFC(getFCDatesAndValuesKey,
      newProductDeliveryFinCompDtls, mainFCStartDateStruct,
      mainFCEndDateStruct);
    // END, CR00051171

    productDeliveryFinCompDtlsList.dtls.addRef(newProductDeliveryFinCompDtls);
  }

  // ___________________________________________________________________________
  /**
   * This method works out the main FC i.e. where there is a full delivery
   * period.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * the shared details for the FC's
   * @param productDeliveryFinCompDtlsList
   * the list of the FC's generated
   */
  @Override
  public void getMainFCDates(
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList,
    // BEGIN, CR00051171, NRV
    final DateStruct mainFCStartDateStruct,
    final DateStruct mainFCEndDateStruct)
    // END, CR00051171
    throws AppException, InformationalException {

    final ProductDeliveryFinCompDtls newProductDeliveryFinCompDtls =
      new ProductDeliveryFinCompDtls();

    newProductDeliveryFinCompDtls.assign(productDeliveryFinCompDtls);
    // BEGIN, CR00051171, NRV
    final Date mainFCStartDate = mainFCStartDateStruct.date;
    final Date mainFCEndDate = mainFCEndDateStruct.date;

    // END, CR00051171

    newProductDeliveryFinCompDtls.startDate = mainFCStartDate;
    newProductDeliveryFinCompDtls.frequency =
      getFCDatesAndValuesKey.deliveryFrequency;
    newProductDeliveryFinCompDtls.endDate = mainFCEndDate;

    // Only create the main FC if the start is before the end date
    // if (newProductDeliveryFinCompDtls.startDate
    // .before(newProductDeliveryFinCompDtls.endDate)) {
    // BEGIN, CR00051171, NRV
    // get effective date for FC
    getEffectiveDateForFC(getFCDatesAndValuesKey,
      newProductDeliveryFinCompDtls, mainFCStartDateStruct,
      mainFCEndDateStruct);
    // END, CR00051171
    productDeliveryFinCompDtlsList.dtls.addRef(newProductDeliveryFinCompDtls);
    // }

  }

  // ___________________________________________________________________________
  /**
   * This method works out the end FC i.e. from a delivery date to the end of
   * the case.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * the shared details for the FC's
   * @param productDeliveryFinCompDtlsList
   * the list of the FC's generated.
   */
  @Override
  public void getEndFCDates(
    final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList,
    // BEGIN, CR00051171, NRV
    final DateStruct mainFCStartDateStruct,
    final DateStruct mainFCEndDateStruct)
    // END, CR00051171
    throws AppException, InformationalException {

    final ProductDeliveryFinCompDtls endFCProductDeliveryFinCompDtls =
      new ProductDeliveryFinCompDtls();

    endFCProductDeliveryFinCompDtls.assign(productDeliveryFinCompDtls);
    // BEGIN, CR00051171, NRV
    final Date mainFCEndDate = mainFCEndDateStruct.date;

    // END, CR00051171

    endFCProductDeliveryFinCompDtls.frequency =
      FrequencyPattern.kZeroFrequencyPattern.toString();
    endFCProductDeliveryFinCompDtls.startDate = mainFCEndDate.addDays(1);
    endFCProductDeliveryFinCompDtls.endDate = getFCDatesAndValuesKey.endDate;

    if (!endFCProductDeliveryFinCompDtls.startDate
      .after(endFCProductDeliveryFinCompDtls.endDate)) {
      // BEGIN, CR00051171, NRV
      // get effective date for FC
      getEffectiveDateForFC(getFCDatesAndValuesKey,
        endFCProductDeliveryFinCompDtls, mainFCStartDateStruct,
        mainFCEndDateStruct);
      // END, CR00051171

      productDeliveryFinCompDtlsList.dtls
        .addRef(endFCProductDeliveryFinCompDtls);
    } else {

      if (!recurringFCExists) {

        // The ramp-down FC should only be generated if it is required
        if (productDeliveryFinCompDtlsList.dtls.size() > 0
          && productDeliveryFinCompDtlsList.dtls.item(0).endDate
            .before(getFCDatesAndValuesKey.endDate)) {

          endFCProductDeliveryFinCompDtls.startDate =
            productDeliveryFinCompDtlsList.dtls.item(0).endDate.addDays(1);
          // BEGIN, CR00051171, NRV
          // get effective date for FC
          getEffectiveDateForFC(getFCDatesAndValuesKey,
            endFCProductDeliveryFinCompDtls, mainFCStartDateStruct,
            mainFCEndDateStruct);
          // END, CR00051171
          productDeliveryFinCompDtlsList.dtls
            .addRef(endFCProductDeliveryFinCompDtls);
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * This method works out the values for FCs.
   *
   * @param getFCDatesAndValuesKey
   * the details of the period to be covered by the FC's
   * @param productDeliveryFinCompDtls
   * the shared details for the FC's
   * @param productDeliveryFinCompDtlsList
   * list of product delivery Financial Component details
   * @param componentDetails
   * the component from which the FC's should be generated.
   * @param componentCaseDecisionLinkList
   * List of decision details from which the "virtual" FCs were created
   */
  @Override
  public void getFCValues(final GetFCDatesAndValuesKey getFCDatesAndValuesKey,
    final ProductDeliveryFinCompDtls productDeliveryFinCompDtls,
    final ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList,
    final ComponentDetails componentDetails, // BEGIN, CR00078445, VM
    final ComponentCaseDecisionLinkList componentCaseDecisionLinkList)
    // END, CR00078445
    throws AppException, InformationalException {

    final String nullFrequencyPattern =
      FrequencyPattern.kZeroFrequencyPattern.toString();

    // temp frequency pattern variable
    FrequencyPattern tmpFrequencyPattern;

    // calculateAmount manipulation variables
    final CalculateAmountKey calculateAmountKey = new CalculateAmountKey();
    CalculateAmountDtls calculateAmountDtls = new CalculateAmountDtls();

    final CaseNominee caseNomineeObj = CaseNomineeFactory.newInstance();

    // CaseNomineeViewKey key and details
    final CaseNomineeViewKey caseNomineeViewKey = new CaseNomineeViewKey();
    CaseNomineeDetails caseNomineeDetails;

    // set calculateAmountKey
    calculateAmountKey.assign(productDeliveryFinCompDtls);
    calculateAmountKey.rulesObjectiveID = componentDetails.objectiveID;
    calculateAmountKey.concernRoleID = componentDetails.concernRoleID;

    // BEGIN, CR00021647, CMB
    boolean dailyEveryNDaysOneDayCase = false;

    // END, CR00021647

    // calculate the amount of each FC
    for (int i = 0; i < productDeliveryFinCompDtlsList.dtls.size(); i++) {

      calculateAmountDtls.amount = new Money(0.0);
      calculateAmountKey.deliveryFrequency =
        productDeliveryFinCompDtlsList.dtls.item(i).frequency;
      calculateAmountKey.caseID = getFCDatesAndValuesKey.caseID;
      calculateAmountKey.concernRoleID =
        productDeliveryFinCompDtls.primaryClientID;
      calculateAmountKey.fromDate =
        productDeliveryFinCompDtlsList.dtls.item(i).startDate;
      calculateAmountKey.toDate =
        productDeliveryFinCompDtlsList.dtls.item(i).endDate;

      // getFCDatesAndValuesKey is a constant so we can't call getPatternType()
      tmpFrequencyPattern =
        new FrequencyPattern(getFCDatesAndValuesKey.deliveryFrequency);

      // Special case for a one day case with a daily frequency pattern.
      // Although the FC will be stored on the database with no frequency
      // we need to calculate its amount using the frequency.

      if (getFCDatesAndValuesKey.startDate
        .compareTo(getFCDatesAndValuesKey.endDate) == 0
        && tmpFrequencyPattern.getPatternType()
          .equals(FrequencyPattern.PatternType.kDaily)) {

        calculateAmountKey.deliveryFrequency =
          getFCDatesAndValuesKey.deliveryFrequency;

        // BEGIN, CR00021647, CMB
        // The FrequencyPattern.PatternType may be daily which means that we
        // could be using a delivery frequency of 'Daily Every N Days'.
        // However, we need to explicitly check for this by seeing if the
        // delivery frequency 'is' daily. If it is not, then we're dealing with
        // a one day case with a 'Daily Every N Days' pattern. In this case, we
        // want to call calculateAmount below.
        if (!new FrequencyPattern(getFCDatesAndValuesKey.deliveryFrequency)
          .equals(FrequencyPattern.kDailyPattern)) {

          dailyEveryNDaysOneDayCase = true;
        }
        // END, CR00021647
      }

      // BEGIN, CR00021647, CMB
      // BEGIN, CR00049218, GM
      if (calculateAmountKey.deliveryFrequency.length() > 0
        && calculateAmountKey.deliveryFrequency.equals(nullFrequencyPattern)
        || calculateAmountKey.deliveryFrequency.equals(CuramConst.gkEmpty)
        || dailyEveryNDaysOneDayCase) {
        // END, CR00049218
        // END, CR00021647

        // BEGIN, CR00174460, KH
        // Use frequency of case when calculating FC amount
        calculateAmountKey.deliveryFrequency =
          getFCDatesAndValuesKey.deliveryFrequency;
        // END, CR00174460

        // BEGIN, CR00078445, VM
        calculateAmountDtls =
          calculateAmount(calculateAmountKey, componentCaseDecisionLinkList);
        // END, CR00078445

        productDeliveryFinCompDtlsList.dtls.item(i).amount =
          calculateAmountDtls.amount;

      } else {

        // If the delivery pattern for the primary nominee is different to that
        // specified then the amount needs to be re-calculated.

        // CaseNomineeProdDelPattern manipulation object
        final CachedCaseNomineeProdDelPattern cachedCaseNomineeProdDelPatternObj =
          CachedCaseNomineeProdDelPatternFactory.newInstance();

        CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls;
        final DeliveryPatternByCaseDateStatusKey delPatByCaseDateStatusKey =
          new DeliveryPatternByCaseDateStatusKey();

        // productDeliveryPatternInfo manipulation variables
        final CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj =
          CachedProductDeliveryPatternInfoFactory.newInstance();
        final PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey =
          new PDPIByProdDelPatIDStatusAndDateKey();
        ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls;

        // set key to read nomineeCaseLink
        delPatByCaseDateStatusKey.caseID = calculateAmountKey.caseID;
        delPatByCaseDateStatusKey.effectiveDate = calculateAmountKey.fromDate;
        delPatByCaseDateStatusKey.defaultNomInd = true;
        delPatByCaseDateStatusKey.statusCode = RECORDSTATUS.NORMAL;

        caseNomineeProdDelPatternDtls = cachedCaseNomineeProdDelPatternObj
          .readDeliveryPatternByCaseDateStatus(delPatByCaseDateStatusKey);

        // As there is only ever one primary nominee can take the front of the
        // list
        pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID =
          caseNomineeProdDelPatternDtls.productDeliveryPatternID;

        // get the delivery frequency from the product delivery pattern
        pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
        // BEGIN, CR00209826, CW
        pdpiByProdDelPatIDStatusAndDateKey.effectiveDate =
          calculateAmountKey.fromDate;
        // END, CR00209826
        try {
          productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj
            .readNearestProdDelPatInfo(pdpiByProdDelPatIDStatusAndDateKey);
        } catch (final RecordNotFoundException ex) {

          final AppException e = new AppException(
            BPOFCGENERATIONUTIL.ERR_NO_NOMINEE_DELIVERY_PATTERN_ON_DATE);

          // BEGIN, CR00209826, CW
          // set key to find the nomineeName
          caseNomineeViewKey.caseNomineeID =
            caseNomineeProdDelPatternDtls.caseNomineeID;
          // END, CR00209826
          caseNomineeDetails =
            caseNomineeObj.readCaseNomineeDetails(caseNomineeViewKey);

          e.arg(caseNomineeDetails.concernRoleName);
          e.arg(pdpiByProdDelPatIDStatusAndDateKey.effectiveDate);
          throw e;
        }

        if (!calculateAmountKey.deliveryFrequency
          .equals(productDeliveryPatternInfoDtls.deliveryFrequency)) {

          // Note:
          // -----
          // The code below caters for all instances where the delivery
          // frequencies differ, not just in the case of ad-hoc bonus payments
          // occurring on the case.
          // ------------------------------------------------------------------
          //
          // if (toDate - fromDate) is greater than a delivery frequency we
          // need to synthesize a delivery pattern (from and to date) in order
          // to pass to the rules engine to calculate the amount

          // BEGIN, CR00404221, CSH

          if (!calculateAmountKey.toDate.isZero()) {

            // We only go down this path if toDate is non-null, otherwise we'd
            // end up calling computeValue with a null toDate which would
            // always return zero
            if (!new FrequencyPattern(calculateAmountKey.deliveryFrequency)
              .getNextOccurrence(calculateAmountKey.fromDate)
              .after(calculateAmountKey.toDate)) {

              final Date tempToDate =
                new FrequencyPattern(calculateAmountKey.deliveryFrequency)
                  .getNextOccurrence(calculateAmountKey.fromDate);

              calculateAmountKey.toDate = tempToDate;
              calculateAmountKey.toDate =
                calculateAmountKey.toDate.addDays(-1);
            }

            // BEGIN, CR00078445, VM
            // calculate amount
            calculateAmountDtls = calculateAmount(calculateAmountKey,
              componentCaseDecisionLinkList);
            // END, CR00078445

            productDeliveryFinCompDtlsList.dtls.item(i).amount =
              calculateAmountDtls.amount;

          } else {
            // If calculateAmountKey.toDate is null, we're dealing with a
            // recurring
            // payment based on the calculateAmountKey.deliveryFrequency, i.e.
            // the payment recurs and it's for the full amount. In this
            // instance,
            // we can just take the (full) amount from componentDetails.value
            productDeliveryFinCompDtlsList.dtls.item(i).amount =
              new Money(componentDetails.value);
          }
          // END, CR00404221
        } else {

          // if the financial component does not span an entire delivery period
          if (new FrequencyPattern(calculateAmountKey.deliveryFrequency)
            .getNextOccurrence(calculateAmountKey.fromDate)
            .after(calculateAmountKey.toDate)
            && !calculateAmountKey.toDate.isZero()
            && !new FrequencyPattern(calculateAmountKey.deliveryFrequency)
              .getPatternType().equals(FrequencyPattern.PatternType.kDaily)) {

            // BEGIN, CR00174460, KH
            // Use frequency of case when calculating FC amount
            calculateAmountKey.deliveryFrequency =
              getFCDatesAndValuesKey.deliveryFrequency;
            // END, CR00174460

            // BEGIN, CR00078445, VM
            calculateAmountDtls = calculateAmount(calculateAmountKey,
              componentCaseDecisionLinkList);
            // END, CR00078445

            productDeliveryFinCompDtlsList.dtls.item(i).amount =
              calculateAmountDtls.amount;

          } else {

            productDeliveryFinCompDtlsList.dtls.item(i).amount =
              new Money(componentDetails.value);
          }
        }
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Sends a notification to the case owner informing them that no more payments
   * will be made on the case as all financial components are expired.
   *
   * @param caseID Case identifier
   */
  @Override
  protected void sendNotification(final CaseID caseID)
    throws AppException, InformationalException {

    final MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;
    final CaseIDKey caseIDKey = new CaseIDKey();

    final Notification notificationObj = NotificationFactory.newInstance();

    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualDtls =
      new StandardManualTaskDtls();

    // BEGIN, CR00213430, AK
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    final OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();
    OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final Users userObj = UsersFactory.newInstance();
    final UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale;
    // END, CR00213430
    // BEGIN, CR00076804, CM
    // check the environment variable
    String genFCExpired =
      Configuration.getProperty(EnvVars.ENV_GENFCEXPIREDTICKET);

    if (genFCExpired == null) {
      genFCExpired = EnvVars.ENV_GENFCEXPIREDTICKET_DEFAULT;
    }

    if (genFCExpired.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }
    // END, CR00076804

    // Set key to read maintainCase
    caseIDKey.caseID = caseID.caseID;
    // BEGIN, CR00234114, AK
    caseHeaderKey.caseID = caseID.caseID;
    orgObjectLinkKey.orgObjectLinkID =
      caseHeaderObj.readCaseOwner(caseHeaderKey).ownerOrgObjectLinkID;
    orgObjectLinkDtls = orgObjectLinkObj.read(orgObjectLinkKey);
    userKey.userName = orgObjectLinkDtls.userName;
    usersDtls = userObj.read(nfIndicator, userKey);
    if (!nfIndicator.isNotFound()) {
      userLocale = usersDtls.defaultLocale;
    } else {
      userLocale = TransactionInfo.getProgramLocale();
    }

    // Call service layer method to retrieve Concern, Case Reference and
    // Product Name
    caseReferenceProductNameConcernRoleName = maintainCaseObj
      .readCaseReferenceConcernRoleNameProductNameByCaseIDAndLocale(caseIDKey,
        userLocale);
    // END, CR00234114

    final AppException e = new AppException(
      BPOFCGENERATIONUTIL.INF_ALL_FINANCIAL_COMPONENTS_ARE_EXPIRED);

    e.arg(caseReferenceProductNameConcernRoleName.caseReference);
    e.arg(caseReferenceProductNameConcernRoleName.productName);
    e.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

    standardManualDtls.dtls.concerningDtls.caseID = caseID.caseID;
    // BEGIN, CR00213430, AK
    // BEGIN, CR00163236, CL
    standardManualDtls.dtls.taskDtls.subject = e.getMessage(userLocale);
    standardManualDtls.dtls.taskDtls.comments = e.getMessage(userLocale);
    // END, CR00163236
    // END, CR00213430
    // assign notification id
    // BEGIN, CR00023618, SK
    standardManualDtls.dtls.taskDtls.taskDefinitionID =
      TaskDefinitionIDConst.financialComponentTaskDefinitionID;
    // END, CR00023618
    // END, HARP 58448

    // Send notification
    notificationObj.sendCaseOwnerNotification(standardManualDtls);
  }

  // ___________________________________________________________________________
  /**
   * Generates financial components for non-certifiable products.
   *
   * @param componentDetailsList
   * The list of components from which the FCs should be generated
   * @param reassessmentMode
   * Determines which reassessment mode the application is running in
   * @param overUnderPaymentIn
   * Contains the case identifier
   *
   * @return a boolean to indicate if the processing succeeded (true) or the
   * period covered by the reassessment needs to be widened
   */
  @Override
  public boolean generateNonCertifiableProductFCs(
    final ComponentDetailsList componentDetailsList,
    final ReassessmentMode reassessmentMode,
    final OverUnderPaymentIn overUnderPaymentIn)
    throws AppException, InformationalException {

    // Check to see if we're dealing with an underpayment or an overpayment
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // Set key to retrieve the product type
    productDeliveryKey.caseID = overUnderPaymentIn.caseID;

    // Retrieve the product type
    final ProductDeliveryTypeDetails productDeliveryTypeDetails =
      productDeliveryObj.readProductType(productDeliveryKey);

    if (productDeliveryTypeDetails.productType
      .equals(PRODUCTTYPE.BENEFITUNDERPAYMENT)) {

      processBenefitUnderpaymentFC(componentDetailsList, reassessmentMode,
        overUnderPaymentIn);

    } else if (productDeliveryTypeDetails.productType
      .equals(PRODUCTTYPE.BENEFITOVERPAYMENT)) {

      processBenefitOverpaymentFC(componentDetailsList, reassessmentMode,
        overUnderPaymentIn);
      // BEGIN, CR00059330, VM
      // BEGIN, CR00107312, RPM
    } else if (productDeliveryTypeDetails.productType
      .equals(PRODUCTTYPE.LIABILITYOVERBILLING)) {

      processLiabilityOverbillingFC(componentDetailsList, overUnderPaymentIn);
      // END, CR00107312

      // BEGIN, CR00210098, KH
    } else if (productDeliveryTypeDetails.productType
      .equals(PRODUCTTYPE.PAYMENTCORRECTION)) {

      processPaymentCorrectionFC(overUnderPaymentIn);
      // END, CR00210098

    } else {

      // BEGIN, CR00211744, VM
      return assessmentEngineHooks.processNonCertifiableProductFCs(
        componentDetailsList, reassessmentMode, overUnderPaymentIn);
      // END, CR00211744
    }
    // END, CR00059330

    return true;
  }

  // ___________________________________________________________________________
  /**
   * To create a benefit overpayment financial component.
   *
   * @param componentDetailsList
   * The list of components from which the FCs should be generated
   * @param reassessmentMode
   * Determines which reassessment mode the application is running in
   * @param overUnderPaymentIn
   * Contains the case identifier
   */
  @Override
  public void processBenefitOverpaymentFC(
    final ComponentDetailsList componentDetailsList,
    final ReassessmentMode reassessmentMode,
    final OverUnderPaymentIn overUnderPaymentIn)
    throws AppException, InformationalException {

    final FinancialComponent financialComponentObj =
      FinancialComponentFactory.newInstance();
    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();
    FinancialComponentDtlsList currentFinancialComponents;

    // set key to read financialComponent - returns ALL live FCs on this case
    fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    // read financialComponent
    currentFinancialComponents =
      financialComponentObj.searchByStatusCaseID(fcStatusCodeCaseID);

    if (!componentDetailsList.dtls.isEmpty()) {

      // CaseEvidenceAPI manipulation variables
      final CaseEvidenceAPI caseEvidenceAPIObj =
        CaseEvidenceAPIFactory.newInstance();
      final ListActiveInEditEvidenceKey listActiveInEditEvidenceKey =
        new ListActiveInEditEvidenceKey();

      // Retrieve all 'Active' and 'In Edit' evidence trees on the case
      listActiveInEditEvidenceKey.caseID = overUnderPaymentIn.caseID;

      final ListActiveInEditEvidenceResult listActiveInEditEvidenceResult =
        caseEvidenceAPIObj
          .listActiveInEditEvidence(listActiveInEditEvidenceKey);

      if (!listActiveInEditEvidenceResult.dtls.isEmpty()) {

        // OverpaymentEvidence manipulation variables
        final OverpaymentEvidence overpaymentEvidenceObj =
          OverpaymentEvidenceFactory.newInstance();
        final OverpaymentEvidenceKey overpaymentEvidenceKey =
          new OverpaymentEvidenceKey();

        // CaseEvidenceAPI manipulation variables
        final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey =
          new GetLinksAndGroupByTreeAndTypeKey();
        GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;

        getLinksAndGroupByTreeAndTypeKey.key.evidenceType =
          CASEEVIDENCE.OVERPAYMENT;

        for (int i = 0; i < listActiveInEditEvidenceResult.dtls.size(); i++) {

          if (listActiveInEditEvidenceResult.dtls.item(i).statusCode
            .equals(EVIDENCETREESTATUS.CURRENT)) {

            getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID =
              listActiveInEditEvidenceResult.dtls.item(i).caseEvidenceTreeID;

            getLinksAndGroupByTreeAndTypeDetails =
              caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
                getLinksAndGroupByTreeAndTypeKey);

            if (!getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls
              .isEmpty()) {

              // Read BenefitUnderpaymentEvidence to retrieve evidence details
              overpaymentEvidenceKey.overpaymentEvidenceID =
                getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls
                  .item(0).relatedID;

              final OverpaymentEvidenceDtls overpaymentEvidenceDtls =
                overpaymentEvidenceObj.read(overpaymentEvidenceKey);

              ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList =
                new ProductDeliveryFinCompDtlsList();
              final ProductDeliveryFinCompDtls productDeliveryFinCompDtls =
                new ProductDeliveryFinCompDtls();

              // BEGIN, CR00078445, CR00079392 VM
              productDeliveryFinCompDtlsList = generateFCDetails(
                componentDetailsList.dtls.item(0), componentDetailsList.dtls
                  .item(0).componentCaseDecisionLinkList);
              // END, CR00078445

              productDeliveryFinCompDtls
                .assign(productDeliveryFinCompDtlsList.dtls.item(0));

              productDeliveryFinCompDtls.startDate =
                overpaymentEvidenceDtls.fromDate;
              productDeliveryFinCompDtls.endDate =
                overpaymentEvidenceDtls.toDate;
              productDeliveryFinCompDtls.amount =
                overpaymentEvidenceDtls.overpaymentAmount;
              productDeliveryFinCompDtls.frequency =
                FrequencyPattern.kZeroFrequencyPattern.toString();

              final FinComponentID finComponentID =
                MaintainFinancialComponentFactory.newInstance()
                  .addProductDeliveryFinComp(productDeliveryFinCompDtls);

              // Insert CaseDecisionFinancialComponent records - there should
              // only be one
              for (int j = 0; j < componentDetailsList.dtls
                .item(0).componentCaseDecisionLinkList.dtls.size(); j++) {

                final CaseDecisionFinancialComp caseDecisionFinancialCompObj =
                  CaseDecisionFinancialCompFactory.newInstance();
                final CaseDecisionFinancialCompDtls caseDecisionFinancialCompDtls =
                  new CaseDecisionFinancialCompDtls();

                // Set caseDecisionFinancialComponent details for insert
                caseDecisionFinancialCompDtls.caseDecisionID =
                  componentDetailsList.dtls
                    .item(0).componentCaseDecisionLinkList.dtls
                      .item(j).caseDecisionID;

                // BEGIN, CR00068167, KH
                caseDecisionFinancialCompDtls.caseDecisionObjectiveID =
                  componentDetailsList.dtls
                    .item(0).componentCaseDecisionLinkList.dtls
                      .item(j).caseDecisionObjectiveID;
                // END, CR00068167

                caseDecisionFinancialCompDtls.financialCompID =
                  finComponentID.finComponentID;

                caseDecisionFinancialCompDtls.caseDecisionFinCompID =
                  UniqueIDFactory.newInstance().getNextID();

                caseDecisionFinancialCompObj
                  .insert(caseDecisionFinancialCompDtls);
              } // end for j
            }
          } // end if EVIDENCETREESTATUS.CURRENT
        } // end for i
      }
    }

    // We need to expire all of the FCs that were originally on the database
    for (int k = 0; k < currentFinancialComponents.dtls.size(); k++) {

      // If they're during or after the decision we must cancel them
      if (!currentFinancialComponents.dtls.item(k).startDate
        .before(overUnderPaymentIn.fromDate)
        && !currentFinancialComponents.dtls.item(k).startDate
          .after(overUnderPaymentIn.toDate)
        || !currentFinancialComponents.dtls.item(k).endDate
          .before(overUnderPaymentIn.fromDate)
          && !currentFinancialComponents.dtls.item(k).endDate
            .after(overUnderPaymentIn.toDate)) {

        MaintainFinancialComponentFactory.newInstance()
          .expireFinancialComp(currentFinancialComponents.dtls.item(k));
      } // Otherwise they're before the decision, and we can leave them
    } // end for k

  }

  // ___________________________________________________________________________
  /**
   * To create a benefit underpayment financial component.
   *
   * @param componentDetailsList
   * The list of components from which the FCs should be generated
   * @param reassessmentMode
   * Determines which reassessment mode the application is running in
   * @param overUnderPaymentIn
   * Contains the case identifier
   */
  @Override
  public void processBenefitUnderpaymentFC(
    final ComponentDetailsList componentDetailsList,
    final ReassessmentMode reassessmentMode,
    final OverUnderPaymentIn overUnderPaymentIn)
    throws AppException, InformationalException {

    final FinancialComponent financialComponentObj =
      FinancialComponentFactory.newInstance();
    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();
    FinancialComponentDtlsList currentFinancialComponents;

    // Set key to read financialComponent - returns ALL live FCs on this case
    fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    // Read financialComponent
    currentFinancialComponents =
      financialComponentObj.searchByStatusCaseID(fcStatusCodeCaseID);

    if (!componentDetailsList.dtls.isEmpty()) {

      // CaseEvidenceAPI manipulation variables
      final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj =
        CaseEvidenceAPIFactory.newInstance();
      final ListActiveInEditEvidenceKey listActiveInEditEvidenceKey =
        new ListActiveInEditEvidenceKey();
      ListActiveInEditEvidenceResult listActiveInEditEvidenceResult;

      // Set key to retrieve all 'Active' and 'In Edit' evidence trees on the
      // case
      listActiveInEditEvidenceKey.caseID = overUnderPaymentIn.caseID;

      listActiveInEditEvidenceResult = caseEvidenceAPIObj
        .listActiveInEditEvidence(listActiveInEditEvidenceKey);

      if (!listActiveInEditEvidenceResult.dtls.isEmpty()) {

        // BenefitUnderpaymentEvidence manipulation variables
        final BenefitUnderpaymentEvidence benefitUnderpaymentEvidenceObj =
          BenefitUnderpaymentEvidenceFactory.newInstance();
        final BenefitUnderpaymentEvidenceKey benefitUnderpaymentEvidenceKey =
          new BenefitUnderpaymentEvidenceKey();

        // CaseEvidenceAPI manipulation variables
        final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey =
          new GetLinksAndGroupByTreeAndTypeKey();
        GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;

        getLinksAndGroupByTreeAndTypeKey.key.evidenceType =
          CASEEVIDENCE.BENEFITUNDERPAYMENT;

        for (int i = 0; i < listActiveInEditEvidenceResult.dtls.size(); i++) {

          if (listActiveInEditEvidenceResult.dtls.item(i).statusCode
            .equals(EVIDENCETREESTATUS.CURRENT)) {

            getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID =
              listActiveInEditEvidenceResult.dtls.item(i).caseEvidenceTreeID;

            getLinksAndGroupByTreeAndTypeDetails =
              caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
                getLinksAndGroupByTreeAndTypeKey);

            if (!getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls
              .isEmpty()) {

              // Read BenefitUnderpaymentEvidence to retrieve evidence details
              benefitUnderpaymentEvidenceKey.benefitUnderpaymentEvidenceID =
                getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls
                  .item(0).relatedID;

              final BenefitUnderpaymentEvidenceDtls benefitUnderpaymentEvidenceDtls =
                benefitUnderpaymentEvidenceObj
                  .read(benefitUnderpaymentEvidenceKey);

              ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList =
                new ProductDeliveryFinCompDtlsList();
              final ProductDeliveryFinCompDtls productDeliveryFinCompDtls =
                new ProductDeliveryFinCompDtls();

              // BEGIN, CR00078445, CR00079392 VM
              productDeliveryFinCompDtlsList = generateFCDetails(
                componentDetailsList.dtls.item(0), componentDetailsList.dtls
                  .item(0).componentCaseDecisionLinkList);
              // END, CR00078445

              productDeliveryFinCompDtls
                .assign(productDeliveryFinCompDtlsList.dtls.item(0));

              productDeliveryFinCompDtls.startDate =
                benefitUnderpaymentEvidenceDtls.fromDate;
              productDeliveryFinCompDtls.endDate =
                benefitUnderpaymentEvidenceDtls.toDate;
              productDeliveryFinCompDtls.amount =
                benefitUnderpaymentEvidenceDtls.amount;
              productDeliveryFinCompDtls.frequency =
                FrequencyPattern.kZeroFrequencyPattern.toString();

              // Add the financial component
              final FinComponentID finComponentID =
                MaintainFinancialComponentFactory.newInstance()
                  .addProductDeliveryFinComp(productDeliveryFinCompDtls);

              // BEGIN, CR00001064, KH
              final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

              caseHeaderKey.caseID = overUnderPaymentIn.caseID;

              DeductionFCGenerationFactory.newInstance()
                .createDeductionFCs(caseHeaderKey);
              // END, CR00001064

              // Insert CaseDecisionFinancialComponent records - there should
              // only be one
              for (int j = 0; j < componentDetailsList.dtls
                .item(0).componentCaseDecisionLinkList.dtls.size(); j++) {

                // CaseDecisionFinancialComp manipulation variables
                final CaseDecisionFinancialComp caseDecisionFinancialCompObj =
                  CaseDecisionFinancialCompFactory.newInstance();
                final CaseDecisionFinancialCompDtls caseDecisionFinancialCompDtls =
                  new CaseDecisionFinancialCompDtls();

                // Set caseDecisionFinancialComponent details for insert
                caseDecisionFinancialCompDtls.caseDecisionID =
                  componentDetailsList.dtls
                    .item(0).componentCaseDecisionLinkList.dtls
                      .item(j).caseDecisionID;

                // BEGIN, CR00068167, KH
                caseDecisionFinancialCompDtls.caseDecisionObjectiveID =
                  componentDetailsList.dtls
                    .item(0).componentCaseDecisionLinkList.dtls
                      .item(j).caseDecisionObjectiveID;
                // END, CR00068167

                caseDecisionFinancialCompDtls.financialCompID =
                  finComponentID.finComponentID;

                caseDecisionFinancialCompDtls.caseDecisionFinCompID =
                  UniqueIDFactory.newInstance().getNextID();

                caseDecisionFinancialCompObj
                  .insert(caseDecisionFinancialCompDtls);
              } // end for j
            }
          } // end if EVIDENCETREESTATUS.CURRENT
        } // end for i
      }
    }

    // We need to expire all of the FCs that were originally on the database
    for (int k = 0; k < currentFinancialComponents.dtls.size(); k++) {

      // If they're during or after the decision we must cancel them
      if (!currentFinancialComponents.dtls.item(k).startDate
        .before(overUnderPaymentIn.fromDate)
        && !currentFinancialComponents.dtls.item(k).startDate
          .after(overUnderPaymentIn.toDate)
        || !currentFinancialComponents.dtls.item(k).endDate
          .before(overUnderPaymentIn.fromDate)
          && !currentFinancialComponents.dtls.item(k).endDate
            .after(overUnderPaymentIn.toDate)) {

        MaintainFinancialComponentFactory.newInstance()
          .expireFinancialComp(currentFinancialComponents.dtls.item(k));
      } // Otherwise they're before the decision, and we can leave them
    } // end for k
  }

  // BEGIN, CR00107312, RPM
  // ___________________________________________________________________________
  /**
   * To create the financial component related to Liability Overbilling.
   *
   * @param componentDetailsList
   * The list of components from which the FC should be generated
   * @param overUnderPaymentIn
   * Contains the case identifier
   */
  @Override
  public void processLiabilityOverbillingFC(
    final ComponentDetailsList componentDetailsList,
    final OverUnderPaymentIn overUnderPaymentIn)
    throws AppException, InformationalException {

    final FinancialComponent financialComponentObj =
      FinancialComponentFactory.newInstance();
    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();
    FinancialComponentDtlsList currentFinancialComponents;

    // set key to read financialComponent - returns ALL live FCs on this case
    fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    // read financialComponent
    currentFinancialComponents =
      financialComponentObj.searchByStatusCaseID(fcStatusCodeCaseID);

    if (!componentDetailsList.dtls.isEmpty()) {

      // CaseEvidenceAPI manipulation variables
      final CaseEvidenceAPI caseEvidenceAPIObj =
        CaseEvidenceAPIFactory.newInstance();
      final ListActiveInEditEvidenceKey listActiveInEditEvidenceKey =
        new ListActiveInEditEvidenceKey();
      ListActiveInEditEvidenceResult listActiveInEditEvidenceResult;

      // Set key to retrieve all 'Active' and 'In Edit' evidence trees on the
      // case
      listActiveInEditEvidenceKey.caseID = overUnderPaymentIn.caseID;

      listActiveInEditEvidenceResult = caseEvidenceAPIObj
        .listActiveInEditEvidence(listActiveInEditEvidenceKey);

      if (!listActiveInEditEvidenceResult.dtls.isEmpty()) {

        // LiabilityOverbilling Evidence manipulation variables
        final LiabilityOverbillingEvidence liabilityOverbillingEvidenceObj =
          LiabilityOverbillingEvidenceFactory.newInstance();
        final LiabilityOverbillingEvidenceKey liabilityOverbillingEvidenceKey =
          new LiabilityOverbillingEvidenceKey();
        LiabilityOverbillingEvidenceDtls liabilityOverbillingEvidenceDtls =
          new LiabilityOverbillingEvidenceDtls();

        // CaseEvidenceAPI manipulation variables
        final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey =
          new GetLinksAndGroupByTreeAndTypeKey();
        GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;

        // Evidence type for Liability Overbilling
        getLinksAndGroupByTreeAndTypeKey.key.evidenceType =
          CASEEVIDENCE.OVERBILLING;

        // FC detail related variables
        ProductDeliveryFinCompDtlsList productDeliveryFinCompDtlsList = null;
        ProductDeliveryFinCompDtls productDeliveryFinCompDtls = null;

        productDeliveryFinCompDtlsList =
          generateFCDetails(componentDetailsList.dtls.item(0),
            componentDetailsList.dtls.item(0).componentCaseDecisionLinkList);

        for (int i = 0; i < listActiveInEditEvidenceResult.dtls.size(); i++) {

          if (listActiveInEditEvidenceResult.dtls.item(i).statusCode
            .equals(EVIDENCETREESTATUS.CURRENT)) {

            getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID =
              listActiveInEditEvidenceResult.dtls.item(i).caseEvidenceTreeID;

            getLinksAndGroupByTreeAndTypeDetails =
              caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
                getLinksAndGroupByTreeAndTypeKey);

            if (!getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls
              .isEmpty()) {

              // Read LiabilityOverbilling Evidence to retrieve evidence details
              liabilityOverbillingEvidenceKey.liabilityOverbillingEvidenceID =
                getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls
                  .item(0).relatedID;
              liabilityOverbillingEvidenceDtls =
                liabilityOverbillingEvidenceObj
                  .read(liabilityOverbillingEvidenceKey);

              productDeliveryFinCompDtls = new ProductDeliveryFinCompDtls();
              productDeliveryFinCompDtls
                .assign(productDeliveryFinCompDtlsList.dtls.item(0));

              productDeliveryFinCompDtls.startDate =
                liabilityOverbillingEvidenceDtls.fromDate;
              productDeliveryFinCompDtls.endDate =
                liabilityOverbillingEvidenceDtls.toDate;
              productDeliveryFinCompDtls.amount =
                liabilityOverbillingEvidenceDtls.overbillingAmount;
              productDeliveryFinCompDtls.frequency =
                FrequencyPattern.kZeroFrequencyPattern.toString();

              final FinComponentID finComponentID =
                MaintainFinancialComponentFactory.newInstance()
                  .addProductDeliveryFinComp(productDeliveryFinCompDtls);

              // Insert CaseDecisionFinancialComponent records - there should
              // only be one
              for (int j = 0; j < componentDetailsList.dtls
                .item(0).componentCaseDecisionLinkList.dtls.size(); j++) {

                final CaseDecisionFinancialCompDtls caseDecisionFinancialCompDtls =
                  new CaseDecisionFinancialCompDtls();

                // Set caseDecisionFinancialComponent details for insert
                caseDecisionFinancialCompDtls.caseDecisionID =
                  componentDetailsList.dtls
                    .item(0).componentCaseDecisionLinkList.dtls
                      .item(j).caseDecisionID;
                caseDecisionFinancialCompDtls.caseDecisionObjectiveID =
                  componentDetailsList.dtls
                    .item(0).componentCaseDecisionLinkList.dtls
                      .item(j).caseDecisionObjectiveID;
                caseDecisionFinancialCompDtls.financialCompID =
                  finComponentID.finComponentID;
                caseDecisionFinancialCompDtls.caseDecisionFinCompID =
                  UniqueIDFactory.newInstance().getNextID();

                CaseDecisionFinancialCompFactory.newInstance()
                  .insert(caseDecisionFinancialCompDtls);
              } // end for j
            }
          } // end if EVIDENCETREESTATUS.CURRENT
        } // end for i
      }
    }

    // We need to expire all of the FCs that were originally on the database
    for (int k = 0; k < currentFinancialComponents.dtls.size(); k++) {

      // If they're during or after the decision we must cancel them
      if (!currentFinancialComponents.dtls.item(k).startDate
        .before(overUnderPaymentIn.fromDate)
        && !currentFinancialComponents.dtls.item(k).startDate
          .after(overUnderPaymentIn.toDate)
        || !currentFinancialComponents.dtls.item(k).endDate
          .before(overUnderPaymentIn.fromDate)
          && !currentFinancialComponents.dtls.item(k).endDate
            .after(overUnderPaymentIn.toDate)) {

        MaintainFinancialComponentFactory.newInstance()
          .expireFinancialComp(currentFinancialComponents.dtls.item(k));
      } // Otherwise they're before the decision, and we can leave them
    } // end for k

  }

  // END, CR00107312

  // BEGIN, CR00210098, KH
  // ___________________________________________________________________________
  /**
   * Creates the financial components (FCs) for a payment correction case,
   * including deduction FCs if required. Any existing live FCs are expired
   * once the new FCs have been created.
   *
   * @param overUnderPaymentIn Contains the case ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void
    processPaymentCorrectionFC(final OverUnderPaymentIn overUnderPaymentIn)
      throws AppException, InformationalException {

    final MaintainFinancialComponent fcObj =
      MaintainFinancialComponentFactory.newInstance();

    // Read all current Live FCs on this case
    final FCstatusCodeCaseID fcStatusCodeCaseID = new FCstatusCodeCaseID();

    final CaseStatusModeDetails caseStatusModeDetails =
      CaseStatusModeFactory.newInstance().getMode();

    // If the payment correction case is being suspended or closed, then expire
    // the live financial components on the database
    if (caseStatusModeDetails.caseIsBeingSuspended
      || caseStatusModeDetails.caseIsBeingClosed) {
      fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
      fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

      final FinancialComponentDtlsList currentFinancialComponents =
        FinancialComponentFactory.newInstance()
          .searchByStatusCaseID(fcStatusCodeCaseID);

      // Expire all of the FCs that were originally on the database
      for (int k = 0; k < currentFinancialComponents.dtls.size(); k++) {
        fcObj.expireFinancialComp(currentFinancialComponents.dtls.item(k));
      } // end for k

      return;
    }

    fcStatusCodeCaseID.caseID = overUnderPaymentIn.caseID;
    fcStatusCodeCaseID.statusCode = FINCOMPONENTSTATUS.LIVE;

    final FinancialComponentDtlsList currentFinancialComponents =
      FinancialComponentFactory.newInstance()
        .searchByStatusCaseID(fcStatusCodeCaseID);

    // Expire all of the FCs that were originally on the database
    for (int k = 0; k < currentFinancialComponents.dtls.size(); k++) {
      fcObj.expireFinancialComp(currentFinancialComponents.dtls.item(k));
    } // end for k

    // Generate the new financial components
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = overUnderPaymentIn.caseID;

    // BEGIN, CR00240870, VM
    paymentCorrection.createPaymentCorrectionFCs(caseHeaderKey,
      new CaseNomineeKey());
    // END, CR00240870

    DeductionFCGenerationFactory.newInstance()
      .createDeductionFCs(caseHeaderKey);
  }
  // END, CR00210098

}
