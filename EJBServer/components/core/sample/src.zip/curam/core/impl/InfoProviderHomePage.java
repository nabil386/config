/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleCommExcRMDtlsList;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleHomePageKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InformationProviderDtls;
import curam.core.struct.InformationProviderKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.ReadActiveCommExcKey;
import curam.core.struct.ReadBasicContactDetailsKey;
import curam.core.struct.ReadBasicContactDetailsResult;
import curam.core.struct.ReadInfoProviderResult;
import curam.core.struct.SearchForAltIDKey;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.workflow.impl.BusinessObjectAssociationSearch;
import curam.util.workflow.struct.BizObjectTypeKey;
import curam.util.workflow.struct.TaskCount;


/**
 * Information home page of provider
 *
 */
public abstract class InfoProviderHomePage extends curam.core.base.InfoProviderHomePage {

  /**
   * Called to retrieve details to be displayed on the information provider
   * home page.
   *
   * @param key identifies information provider to be found
   *
   * @return information provider's details and informational messages
   */
  @Override
  public ReadInfoProviderResult read(ConcernRoleHomePageKey key)
    throws AppException, InformationalException {

    final ReadInfoProviderResult readInfoProviderResult = new ReadInfoProviderResult();

    // Variables used to read information provider
    final curam.core.intf.InformationProvider informationProviderObj = curam.core.fact.InformationProviderFactory.newInstance();
    final InformationProviderKey informationProviderKey = new InformationProviderKey();
    InformationProviderDtls informationProviderDtls;

    // current date
    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // informational message
    InformationalMsgDtls informationalMsgDtls;

    final curam.core.intf.MaintainContractAssistant maintainContractAssistantObj = curam.core.fact.MaintainContractAssistantFactory.newInstance();

    // Communication Exception details
    final curam.core.intf.ConcernRoleCommException concernRoleCommExceptionObj = curam.core.fact.ConcernRoleCommExceptionFactory.newInstance();
    final ReadActiveCommExcKey readActiveCommExcKey = new ReadActiveCommExcKey();
    ConcernRoleCommExcRMDtlsList concernRoleCommExcRMDtlsList;

    // Concern role variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // variables for readBasicContactDetails method
    final ReadBasicContactDetailsKey readBasicContactDetailsKey = new ReadBasicContactDetailsKey();
    ReadBasicContactDetailsResult readBasicContactDetailsResult;

    // variables to read primary alternate ID for client
    final curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();
    final SearchForAltIDKey searchForAltIDKey = new SearchForAltIDKey();
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls;

    // BEGIN, CR00226619, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = key.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00226619

    // set the concern role key with the given key
    concernRoleKey.concernRoleID = key.concernRoleID;

    // retrieve concern role details record for registration date
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // retrieve info provider details
    informationProviderKey.concernRoleID = key.concernRoleID;

    informationProviderDtls = informationProviderObj.read(
      informationProviderKey);

    // set info provider home page details with the retrieved info provider
    // details
    readInfoProviderResult.details.assign(informationProviderDtls);

    // set registration date from the retrieved concern role details
    readInfoProviderResult.details.assign(concernRoleDtls);

    // set the details for a readActive
    readActiveCommExcKey.assign(informationProviderDtls);
    readActiveCommExcKey.emptyDate = curam.util.type.Date.kZeroDate;
    readActiveCommExcKey.currentDate = currentDate;

    readActiveCommExcKey.status = curam.codetable.RECORDSTATUS.NORMAL;

    // retrieve records
    concernRoleCommExcRMDtlsList = concernRoleCommExceptionObj.searchActiveExceptions(
      readActiveCommExcKey);

    if (!concernRoleCommExcRMDtlsList.dtls.isEmpty()) {
      readInfoProviderResult.details.commExceptionInd = true;
    } else {
      readInfoProviderResult.details.commExceptionInd = false;
    }

    // pass values to key structure
    readBasicContactDetailsKey.concernRoleID = key.concernRoleID;
    readBasicContactDetailsKey.primaryAddressID = concernRoleDtls.primaryAddressID;
    readBasicContactDetailsKey.primaryPhoneNumberID = concernRoleDtls.primaryPhoneNumberID;

    readBasicContactDetailsResult = maintainContractAssistantObj.readBasicContactDetails(
      readBasicContactDetailsKey);

    readInfoProviderResult.details.assign(
      readBasicContactDetailsResult.basicContactDetails);

    // variable to see if messages should be displayed
    final boolean getHomePagePrimaryWarnings = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_HOMEPAGEPRIMARYWARNINGS);

    // Pass values returned from readBasicContactDetails messageList
    // to messages struct
    if (getHomePagePrimaryWarnings) {

      readInfoProviderResult.messages.dtls.ensureCapacity(
        readBasicContactDetailsResult.messageList.dtls.size());

      for (int i = 0; i < readBasicContactDetailsResult.messageList.dtls.size(); i++) {

        informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = readBasicContactDetailsResult.messageList.dtls.item(i).informationMsgTxt;

        readInfoProviderResult.messages.dtls.addRef(informationalMsgDtls);
      }
    }

    final BizObjectTypeKey bizObjectTypeKey = new BizObjectTypeKey();

    bizObjectTypeKey.bizObjectID = key.concernRoleID;
    bizObjectTypeKey.bizObjectType = BUSINESSOBJECTTYPE.PERSON;
    final TaskCount taskCount = BusinessObjectAssociationSearch.countOpenTasksByBizObjectTypeAndID(
      bizObjectTypeKey);

    readInfoProviderResult.details.numberOfOpenTickets = (int) taskCount.count;

    // only look up by alternate ID if getHomePagePrimaryWarnings is true
    // and there is a primaryAlternateID set
    if (getHomePagePrimaryWarnings
      && informationProviderDtls.primaryAlternateID.length() > 0) {

      searchForAltIDKey.alternateID = informationProviderDtls.primaryAlternateID;
      searchForAltIDKey.concernRoleID = key.concernRoleID;

      searchForAltIDKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

      // search for primary alternate ID for client
      try {
        concernRoleAlternateIDDtls = concernRoleAlternateIDObj.readForAltID(
          searchForAltIDKey);

      } catch (final curam.util.exception.RecordNotFoundException e) {

        concernRoleAlternateIDDtls = null;
      }

      if (concernRoleAlternateIDDtls != null) {

        // check date of primary alternate ID
        if (!concernRoleAlternateIDDtls.endDate.isZero()
          && concernRoleAlternateIDDtls.endDate.before(currentDate)) {

          // add an informational if date of primary alternate ID is not
          // correct

          informationalMsgDtls = new InformationalMsgDtls();

          informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
            GENERALCONCERN.ERR_CONCERNROLEALTID_FV_DATE_PASSED.getMessageText(
            TransactionInfo.getProgramLocale());
          // END, CR00163471, JC

          readInfoProviderResult.messages.dtls.addRef(informationalMsgDtls);

        }

      } else {

        // add an informational if primary alternate ID was not found

        informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
          GENERALCONCERN.ERR_CONCERNROLEALTID_RNFE_PRIMARY.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        readInfoProviderResult.messages.dtls.addRef(informationalMsgDtls);

      }

      if (!concernRoleDtls.endDate.isZero()) {

        final AppException inf = new AppException(
          curam.message.GENERALCONCERN.INF_CONCERNROLE_ENDDATE_PASSED);

        inf.arg(concernRoleDtls.concernRoleName);

        informationalMsgDtls = new InformationalMsgDtls();

        // BEGIN, CR00163236, CL
        informationalMsgDtls.informationMsgTxt = inf.getMessage(
          TransactionInfo.getProgramLocale());
        // END, CR00163236

        readInfoProviderResult.messages.dtls.addRef(informationalMsgDtls);

      }

    }

    return readInfoProviderResult;
  }

}
