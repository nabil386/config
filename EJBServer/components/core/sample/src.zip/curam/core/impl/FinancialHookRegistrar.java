/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;

import com.google.inject.Inject;
import curam.codetable.PRODUCTTYPE;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.message.BPOPRODUCTHOOKREGISTRAR;
import curam.util.exception.AppException;
import curam.util.type.CodeTableItemIdentifier;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Interface implemented by classes which register financial hooks.
 * These classes are dynamically created by the FinancialHookManager at
 * runtime. The names of the classes to be dynamically created are taken
 * from the 'curam.financial.financialhook.registrars' environment variable.
 */
public interface FinancialHookRegistrar {

  /**
   * The HookMap class is a generic product name to Curam factory class mapping.
   */
  public final class HookMap {

    // BEGIN, CR00198200, GYH
    /**
     * Internal storage of the hook factory classes in a concurrent hash map.
     */
    protected Map hookMap = new ConcurrentHashMap();

    /**
     * Registers all the maps of Financial Hook implementations from
     * corresponding module class during the process of this class instance
     * creation.
     * 
     * @param moduleEvidenceMap
     * Contains all the maps of Financial Hook
     * implementations.
     */
    @Inject(optional = true)
    void registerAll(final @Registrar(Registrar.RegistrarType.FINANCIAL_HOOK)
    Map<String, Method> moduleEvidenceMap) {

      // Register all the maps of Financial Hook implementations.
      hookMap.putAll(moduleEvidenceMap);
    }

    // END, CR00198200

    /**
     * Add a mapping for the specified product to the specified factory
     * class.
     * 
     * @param productType The type of the product
     * @param factory The factory class which can create the hook
     */
    public void addMapping(final String productType, final Class factory) {

      Method newInstance = null;
      // BEGIN, CR00023618, SK
      try {
        newInstance =
          factory.getMethod(ReflectionConst.kNewInstance, new Class[0]);
      } catch (final NoSuchMethodException e) {
        // END, CR00023618
        final AppException ae =
          new AppException(
            BPOPRODUCTHOOKREGISTRAR.ERR_REGISTRAR_NEW_INSTANCE_UNIMPLEMENTED);

        ae.arg(factory.getName());
        ae.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME, productType));

        throw new RuntimeException(ae);
      }

      hookMap.put(productType, newInstance);
    }

    /**
     * Creates an instance of the hook for the specified product.
     * 
     * @param productType The type of the product.
     * @param intf The type that the hook should implement.
     * 
     * @return The created hook object
     */
    public Object createHookInstance(final String productType,
      final Class intf) throws AppException {

      final Method newInstance = (Method) hookMap.get(productType);

      if (newInstance == null) {
        return null;
      }

      try {
        final Object bpoObject = newInstance.invoke(null, new Object[0]);

        // Check that the created Business Process Object can be safely cast
        // to the type intf
        if (!intf.isInstance(bpoObject)) {

          final AppException e =
            new AppException(
              BPOPRODUCTHOOKREGISTRAR.ERR_REGISTRAR_INCORRECT_BPOCLASS);

          e.arg(bpoObject.getClass().getName());
          e.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
            productType));
          e.arg(intf.getName());
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .throwWithLookup(
              e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }

        return bpoObject;
      } catch (final Exception e) {

        final AppException ae =
          new AppException(
            BPOPRODUCTHOOKREGISTRAR.ERR_REGISTRAR_HOOK_INSTANTIATION_FAILED);

        ae.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME, productType));
        ae.arg(e.getLocalizedMessage());
        throw ae;
      }
    }
  }

  /**
   * Implementors should use this method to add details of the hooks to use
   * for financial processing on a product by product basis.
   */
  public void registerFinancialHooks();

}
