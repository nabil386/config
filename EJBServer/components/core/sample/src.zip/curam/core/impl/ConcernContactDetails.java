/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.HomePageContactDetails;
import curam.core.struct.HomePageContactKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class ConcernContactDetails extends curam.core.base.ConcernContactDetails {

  // ___________________________________________________________________________
  /*
   * This method will return the address and phone number details for display
   * on the home pages based on the primary Address ID and the Primary Phone
   * number ID.
   *
   * @param key Contains home page contact key.
   */
  @Override
  public HomePageContactDetails readContactDetails(HomePageContactKey key)
    throws AppException, InformationalException {

    throw new curam.util.exception.UnimplementedException();
  }

}
