/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.sl.entity.struct.CaseNomNameAddressKey;
import curam.core.sl.entity.struct.CaseNomineeDestinationDtls;
import curam.core.sl.entity.struct.DestinationTypeStatusCaseNomineeIDKey;
import curam.core.struct.ConcernRoleBankAccountDtls;
import curam.core.struct.ConcernRoleBankAccountKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.FinInstructionIDStatus;
import curam.core.struct.GetProductDeliveryPmtDtlsResult;
import curam.core.struct.IssueProductDeliveryPaymentResult;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstructionKey;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PmtInstrumentDetails;
import curam.core.struct.PmtInstrumentIDversNo;
import curam.core.struct.PmtInstrumentSummary;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code for issuing payments.
 *
 */
public abstract class IssuePayment extends curam.core.base.IssuePayment {

  // ___________________________________________________________________________
  /**
   * To issue a payment instrument to the nominee of a product delivery
   *
   * @param instrumentSummary payment instrument summary details
   *
   * @return contains payment instrument details
   */
  @Override
  public IssueProductDeliveryPaymentResult issueProductDeliveryPayment(
    PmtInstrumentSummary instrumentSummary) throws AppException,
      InformationalException {

    // issueProductDeliveryPaymentResult variable
    final IssueProductDeliveryPaymentResult issueProductDeliveryPaymentResult = new IssueProductDeliveryPaymentResult();

    // getProductDeliveryPmtDtlsResult variable
    GetProductDeliveryPmtDtlsResult getProductDeliveryPmtDtlsResult;

    // createPayments manipulation variable
    final curam.core.intf.CreatePayments createPaymentsObj = curam.core.fact.CreatePaymentsFactory.newInstance();

    // Retrieve product payment details
    getProductDeliveryPmtDtlsResult = getProductDeliveryPmtDtls(
      instrumentSummary);

    // paymentInstrument manipulation variables
    final PmtInstrumentDetails pmtInstrumentDetails = new PmtInstrumentDetails();
    PaymentInstrumentDtls paymentInstrumentDtls;

    // set paymentInstrument details
    pmtInstrumentDetails.pmtAmount = instrumentSummary.amount;
    pmtInstrumentDetails.effectiveDate = instrumentSummary.effectiveDate;
    pmtInstrumentDetails.deliveryMethodType = instrumentSummary.deliveryMethodType;

    if (instrumentSummary.deliveryMethodType.equals(
      curam.codetable.METHODOFDELIVERY.EFT)) {

      // bank Account processing - get bankAccountID for the nominee

      // variables used to manage case nominee destination
      final curam.core.sl.entity.intf.CaseNomineeDestination caseNomineeDestinationObj = curam.core.sl.entity.fact.CaseNomineeDestinationFactory.newInstance();
      CaseNomineeDestinationDtls caseNomineeDestinationDtls = new CaseNomineeDestinationDtls();

      final DestinationTypeStatusCaseNomineeIDKey destinationTypeStatusCaseNomineeIDKey = new DestinationTypeStatusCaseNomineeIDKey();

      destinationTypeStatusCaseNomineeIDKey.caseNomineeID = instrumentSummary.caseNomineeID;
      destinationTypeStatusCaseNomineeIDKey.destinationType = curam.codetable.DESTINATIONTYPECODE.BANKACCOUNT;
      destinationTypeStatusCaseNomineeIDKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

      caseNomineeDestinationDtls = caseNomineeDestinationObj.readByTypeStatusAndCaseNomineeID(
        destinationTypeStatusCaseNomineeIDKey);

      // concernRoleBankAccount manipulation variables
      final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();
      final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();
      ConcernRoleBankAccountDtls concernRoleBankAccountDtls;

      // Read the concernRoleBankAccountID using the destinationID
      // (this is the concernRoleBankAccountID) to get the bankAccountID
      concernRoleBankAccountKey.concernRoleBankAccountID = caseNomineeDestinationDtls.destinationID;
      concernRoleBankAccountDtls = concernRoleBankAccountObj.read(
        concernRoleBankAccountKey);

      pmtInstrumentDetails.bankAccountID = concernRoleBankAccountDtls.bankAccountID;

    }

    pmtInstrumentDetails.concernRoleID = instrumentSummary.concernRoleID;

    if (getProductDeliveryPmtDtlsResult.caseNomineeNameAndAddressID.concernRoleID
      == instrumentSummary.concernRoleID) {

      pmtInstrumentDetails.concernRoleName = getProductDeliveryPmtDtlsResult.caseNomineeNameAndAddressID.concernRoleName;

    } else {

      pmtInstrumentDetails.concernRoleName = getProductDeliveryPmtDtlsResult.concernRoleDetails.concernRoleName;
    }

    pmtInstrumentDetails.caseNomineeID = instrumentSummary.caseNomineeID;
    pmtInstrumentDetails.nomineeName = getProductDeliveryPmtDtlsResult.caseNomineeNameAndAddressID.concernRoleName;
    pmtInstrumentDetails.nomineeAlternateID = getProductDeliveryPmtDtlsResult.caseNomineeNameAndAddressID.alternateID;
    pmtInstrumentDetails.addressID = getProductDeliveryPmtDtlsResult.caseNomineeNameAndAddressID.addressID;
    pmtInstrumentDetails.currencyTypeCode = instrumentSummary.currencyTypeCode;
    pmtInstrumentDetails.currencyExchangeID = instrumentSummary.currencyExchangeID;
    pmtInstrumentDetails.comments = instrumentSummary.comments;
    pmtInstrumentDetails.pslipInstructionID = instrumentSummary.pslipInstructionID;
    paymentInstrumentDtls = createPaymentsObj.createPmtInstrument(
      pmtInstrumentDetails);

    issueProductDeliveryPaymentResult.paymentInstrumentDetails.assign(
      paymentInstrumentDtls);

    // financialInstruction status manipulation variables
    final curam.core.intf.MaintainFinInstruction maintainFinInstructionObj = curam.core.fact.MaintainFinInstructionFactory.newInstance();
    final FinInstructionIDStatus finInstructionIDStatus = new FinInstructionIDStatus();

    finInstructionIDStatus.finInstructionID = getProductDeliveryPmtDtlsResult.paymentInstructionDetails.finInstructionID;

    // set status to 'Issued' for update
    finInstructionIDStatus.statusCode = curam.codetable.FININSTRUCTIONSTATUS.ISSUED;

    // update financialInstruction status
    maintainFinInstructionObj.updateFinInstructionStatus(finInstructionIDStatus);

    // output the updated financial instruction versionNo
    issueProductDeliveryPaymentResult.piVersionNo.finInstructionVersNo = finInstructionIDStatus.versionNo;

    final PmtInstrumentIDversNo pmtInstrumentIDversNo = new PmtInstrumentIDversNo();

    pmtInstrumentIDversNo.pmtInstrumentID = paymentInstrumentDtls.pmtInstrumentID;
    pmtInstrumentIDversNo.versionNo = getProductDeliveryPmtDtlsResult.paymentInstructionDetails.versionNo;

    // paymentInstruction manipulation variables
    final curam.core.intf.PaymentInstruction paymentInstructionObj = curam.core.fact.PaymentInstructionFactory.newInstance();
    final PaymentInstructionKey paymentInstructionKey = new PaymentInstructionKey();

    // set paymentInstructionKey for update
    paymentInstructionKey.pmtInstructionID = instrumentSummary.pmtInstructionID;

    // update paymentInstruction status
    paymentInstructionObj.modifyPmtInstrumentID(paymentInstructionKey,
      pmtInstrumentIDversNo);

    // output the updated payment instruction versionNo
    issueProductDeliveryPaymentResult.piVersionNo.pmtInstructionVersNo = pmtInstrumentIDversNo.versionNo;

    return issueProductDeliveryPaymentResult;

  }

  // ___________________________________________________________________________
  /**
   * To read the PaymentInstruction ,Nominee, and ConcernRole database tables
   * to retrieve data for issuing a payment instrument to the nominee of a
   * product delivery
   *
   * @param instrumentSummary payment instrument summary details
   *
   * @return contains payment instruction details, nominee details
   * and concern role details
   */
  @Override
  public GetProductDeliveryPmtDtlsResult getProductDeliveryPmtDtls(
    PmtInstrumentSummary instrumentSummary) throws AppException,
      InformationalException {

    // getProductDeliveryPmtDtlsResult variable
    final GetProductDeliveryPmtDtlsResult getProductDeliveryPmtDtlsResult = new GetProductDeliveryPmtDtlsResult();

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // nomineeSearch manipulation variables
    final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();
    final CaseNomNameAddressKey caseNomNameAddressKey = new CaseNomNameAddressKey();

    caseNomNameAddressKey.caseNomineeID = instrumentSummary.caseNomineeID;

    // paymentInstruction manipulation variables
    final curam.core.intf.PaymentInstruction paymentInstructionObj = curam.core.fact.PaymentInstructionFactory.newInstance();
    final PaymentInstructionKey paymentInstructionKey = new PaymentInstructionKey();
    PaymentInstructionDtls paymentInstructionDtls;

    // set key to read paymentInstruction entity
    paymentInstructionKey.pmtInstructionID = instrumentSummary.pmtInstructionID;

    // read paymentInstruction entity
    paymentInstructionDtls = paymentInstructionObj.read(paymentInstructionKey);

    getProductDeliveryPmtDtlsResult.paymentInstructionDetails.assign(
      paymentInstructionDtls);

    caseNomNameAddressKey.caseNomineeID = instrumentSummary.caseNomineeID;
    caseNomNameAddressKey.destinationType = curam.codetable.DESTINATIONTYPECODE.ADDRESS;
    caseNomNameAddressKey.statusCode = RECORDSTATUS.NORMAL;

    // read the Nominee Name and Address details
    getProductDeliveryPmtDtlsResult.caseNomineeNameAndAddressID = caseNomineeObj.readCaseNomineeDetailsAndAddressID(
      caseNomNameAddressKey);
    // set key to read
    concernRoleKey.concernRoleID = instrumentSummary.concernRoleID;

    // read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    getProductDeliveryPmtDtlsResult.concernRoleDetails.assign(concernRoleDtls);

    return getProductDeliveryPmtDtlsResult;
  }

}
