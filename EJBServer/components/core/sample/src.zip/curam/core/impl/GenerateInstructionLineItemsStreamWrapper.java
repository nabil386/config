/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.BatchProcessingID;
import curam.core.struct.BatchProcessingSkippedRecord;
import curam.core.struct.BatchProcessingSkippedRecordList;
import curam.core.struct.GenerateInstructionLineItemsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This interface is used to allow the batch streaming infrastructure to invoke
 * the implementation of the GenerateInstructionLineItemsStream.
 */
public class GenerateInstructionLineItemsStreamWrapper implements BatchStream {

  protected curam.core.intf.GenerateInstructionLineItemsStream generateInstructionLineItemsStreamObj;

  // ___________________________________________________________________________
  /**
   * Constructor, takes an instance of the class implementing the
   * GenerateinstructionLineItemsStream
   */
  public GenerateInstructionLineItemsStreamWrapper(
    curam.core.intf.GenerateInstructionLineItemsStream generateInstructionLineItemsStream) {

    generateInstructionLineItemsStreamObj = generateInstructionLineItemsStream;

  }

  // ___________________________________________________________________________
  /**
   * Call the getChunkResult method of the GenerateinstructionLineItemsStream
   */
  @Override
  public String getChunkResult(int skippedCasesCount) throws AppException,
      InformationalException {

    return generateInstructionLineItemsStreamObj.getChunkResult(
      skippedCasesCount);

  }

  // ___________________________________________________________________________
  /**
   * Call the processRecord method of the GenerateinstructionLineItemsStream
   */
  @Override
  public BatchProcessingSkippedRecord processRecord(
    BatchProcessingID batchProcessingID, Object parameters)
    throws AppException, InformationalException {

    return generateInstructionLineItemsStreamObj.processRecord(
      batchProcessingID, (GenerateInstructionLineItemsKey) parameters);

  }

  // ___________________________________________________________________________
  /**
   * Call the processSkippedCases method of the
   * GenerateinstructionLineItemsStream
   */
  @Override
  public void processSkippedCases(
    BatchProcessingSkippedRecordList batchProcessingSkippedRecordList)
    throws AppException, InformationalException {

    generateInstructionLineItemsStreamObj.processSkippedCases(
      batchProcessingSkippedRecordList);

  }

}
