/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.CITIZENSHIPREASON;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CitizenshipDtls;
import curam.core.struct.CitizenshipKey;
import curam.core.struct.CitizenshipReadMultiDtlsList;
import curam.core.struct.CitizenshipSnapshotDtls;
import curam.core.struct.CitizenshipSnapshotKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.message.SUMMARYDETAILS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * This class represents a Citizenship entity. This implementation class
 * contains some customized methods used for the search operation
 */

public abstract class Citizenship extends curam.core.base.Citizenship
  implements ParticipantEvidenceInterface {

  // BEGIN, CR00059405, POH
  protected static ThreadLocal<CitizenshipCache> cachedReadTL = new ThreadLocal<CitizenshipCache>();

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadTL
   */
  protected void clearCaches() {

    CitizenshipCache cache = cachedReadTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new CitizenshipCache();
      cachedReadTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Caching Details for Improved Performance
   */
  protected class CitizenshipCache {

    public CitizenshipCache() {

      map = new HashMap<Long, CitizenshipDtls>();
      transactionID = 0;
    }

    HashMap<Long, CitizenshipDtls> map;

    int transactionID;
  }

  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * Calculate the attribution dates for the case
   *
   * @param caseKey
   * Contains the case identifier
   * @param evKey
   * Contains the evidenceID and evidenceType
   *
   * @return The attribution dates for the entity
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    // return struct
    final AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final CitizenshipDtls citizenshipDtls = read(evKey);

    // END, CR00240667

    // populate return struct
    attributedDateDetails.fromDate = citizenshipDtls.fromDate;
    attributedDateDetails.toDate = citizenshipDtls.toDate;

    return attributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected CitizenshipDtls read(EIEvidenceKey key) throws AppException,
      InformationalException {

    // manipulation variables
    final CitizenshipKey citizenshipKey = new CitizenshipKey();
    final curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();
    CitizenshipDtls citizenshipDtls = new CitizenshipDtls();

    // populate the key with passed in parameter
    citizenshipKey.citizenshipID = key.evidenceID;

    // BEGIN, CR00067890, POH
    // read citizenship details
    try {
      citizenshipDtls = citizenshipObj.read(citizenshipKey);
    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot citizenship entity
      final CitizenshipSnapshotKey citizenshipSnapshotKey = new CitizenshipSnapshotKey();

      final curam.core.intf.CitizenshipSnapshot citizenshipSnapshotObj = curam.core.fact.CitizenshipSnapshotFactory.newInstance();

      // populate the citizenship snapshot key with passed in parameter
      citizenshipSnapshotKey.citizenshipSnapshotID = key.evidenceID;

      // read citizenship snapshot details
      final CitizenshipSnapshotDtls citizenshipSnapshotDtls = citizenshipSnapshotObj.read(
        citizenshipSnapshotKey);

      citizenshipDtls.assign(citizenshipSnapshotDtls);
    }
    // END, CR00067890
    return citizenshipDtls;
  }

  // ___________________________________________________________________________
  /**
   * Gets evidence details for the list display
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   *
   * @return Evidence details to be displayed on the list page
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final CitizenshipDtls citizenshipDtls = read(key);

    // END, CR00240667

    // set start and end dates
    eiFieldsForListDisplayDtls.startDate = citizenshipDtls.fromDate;
    eiFieldsForListDisplayDtls.endDate = citizenshipDtls.toDate;

    // Set the summary details.
    // BEGIN, CR00241068, CD
    final LocalisableString message = new LocalisableString(
      SUMMARYDETAILS.CITIZENSHIP);

    message.arg(
      CodeTable.getOneItem(CITIZENSHIPREASON.TABLENAME,
      citizenshipDtls.reasonCode));
    message.arg(
      CodeTable.getOneItem(curam.codetable.COUNTRY.TABLENAME,
      citizenshipDtls.countryCode));

    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068

    // END, CR00059389
    return eiFieldsForListDisplayDtls;

  }

  // ___________________________________________________________________________
  /**
   * Inserts Citizenship evidence
   *
   * @param parentKey
   * Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  @Override
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((CitizenshipDtls) dtls);

    eiEvidenceKey.evidenceID = ((CitizenshipDtls) dtls).citizenshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CITIZENSHIP;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Citizenship evidence on modification
   *
   * @param origKey
   * @param parentKey
   * Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((CitizenshipDtls) dtls);

    eiEvidenceKey.evidenceID = ((CitizenshipDtls) dtls).citizenshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CITIZENSHIP;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify Citizenship evidence
   *
   * @param key
   * Evidence key containing evidenceID and evidenceType
   * @param dtls
   * Citizenship entity details
   */
  @Override
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Citizenship entity key
    final CitizenshipKey citizenshipKey = new CitizenshipKey();

    // Set entity key for modify
    citizenshipKey.citizenshipID = key.evidenceID;

    // Modify details
    modify(citizenshipKey, (CitizenshipDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Insert Citizenship evidence
   *
   * @param details
   * - Citizenship entity details
   */
  @Override
  public void insert(CitizenshipDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Modify Citizenship evidence
   *
   * @param key
   * - the uniqueID of the Citizenship record
   * @param details
   * - Citizenship details
   */
  @Override
  public void modify(CitizenshipKey key, CitizenshipDtls details)
    throws AppException, InformationalException {

    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * Read all child record identifiers.
   *
   * @param key
   * Evidence key for the parent evidence record
   *
   * @return A list of child record evidence keys for the parent
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read Citizenship evidence
   *
   * @param key
   * Evidence key containing evidenceID and evidenceType
   *
   * @return Citizenship or CitizenshipSnapshot entity details
   */
  @Override
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // manipulation variables
    final CitizenshipKey citizenshipKey = new CitizenshipKey();
    CitizenshipDtls citizenshipDtls = new CitizenshipDtls();
    final curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();

    // populate the citizenship key with passed in parameter
    citizenshipKey.citizenshipID = key.evidenceID;
    // BEGIN, CR00059389, PCAL
    try {
      // read citizenship details
      citizenshipDtls = citizenshipObj.read(citizenshipKey);
      return citizenshipDtls;

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot citizenship entity
      final CitizenshipSnapshotKey citizenshipSnapshotKey = new CitizenshipSnapshotKey();
      CitizenshipSnapshotDtls citizenshipSnapshotDtls = new CitizenshipSnapshotDtls();
      final curam.core.intf.CitizenshipSnapshot citizenshipSnapshotObj = curam.core.fact.CitizenshipSnapshotFactory.newInstance();

      // populate the citizenship snapshot key with passed in parameter
      citizenshipSnapshotKey.citizenshipSnapshotID = key.evidenceID;

      // read citizenship snapshot details
      citizenshipSnapshotDtls = citizenshipSnapshotObj.read(
        citizenshipSnapshotKey);
      citizenshipDtls.assign(citizenshipSnapshotDtls);
      return citizenshipDtls;
    }
    // END, CR00059389
  }

  // ___________________________________________________________________________
  /**
   * Selects all the records for validations
   *
   * @param evKey
   * Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  @Override
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey
   * Evidence key
   * @param evKeyList
   * Evidence key list
   * @param mode
   * Validate mode (insert, delete, applyChanges, modify)
   */
  @Override
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method
    // is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * Create a snapshot record of the Citizenship record
   *
   * @param key
   * Evidence key
   *
   * @return EIEvidenceKey - the id of the newly created snapshot record
   */
  @Override
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // manipulation variables
    final CitizenshipKey citizenshipKey = new CitizenshipKey();
    CitizenshipDtls citizenshipDtls = new CitizenshipDtls();
    final CitizenshipSnapshotDtls citizenshipSnapshotDtls = new CitizenshipSnapshotDtls();
    final curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();
    final curam.core.intf.CitizenshipSnapshot citizenshipSnapshotObj = curam.core.fact.CitizenshipSnapshotFactory.newInstance();

    // populate the key with passed in parameter
    citizenshipKey.citizenshipID = key.evidenceID;

    // read citizenship details
    citizenshipDtls = citizenshipObj.read(citizenshipKey);

    // populate snapshot details
    citizenshipSnapshotDtls.assign(citizenshipDtls);
    citizenshipSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    // insert snapshot record
    citizenshipSnapshotObj.insert(citizenshipSnapshotDtls);

    // populate return struct
    eiEvidenceKey.evidenceID = citizenshipSnapshotDtls.citizenshipSnapshotID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CITIZENSHIP;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Method removing participant evidence. This method is called when
   * participant evidence is being cancelled
   *
   * @param key
   * - Contains an evidenceID / evidenceType pairing
   * @param dtls
   * - Modified evidence details
   */
  @Override
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    final CitizenshipKey citizenshipKey = new CitizenshipKey();

    // Set entity key for modify
    citizenshipKey.citizenshipID = key.evidenceID;

    // Modify details
    modify(citizenshipKey, (CitizenshipDtls) dtls);

  }

  @Override
  protected void dummy() throws AppException, InformationalException {// Dummy
    // method
    // to
    // force
    // factory
    // class
    // to
    // extend
    // the
    // impl
    // class
    // instead
    // of the
    // base
    // class.
  }

  // END, CR00059405

  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID and
   * status.
   *
   * @param key
   * - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing an
   * evidenceID/evidenceType pair.
   */
  @Override
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060045, POH
    // return struct
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;
    // BEGIN, CR00060163, POH
    // BEGIN, CR00066203, AC
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();
    CitizenshipReadMultiDtlsList citizenshipReadMultiDtlsList = new CitizenshipReadMultiDtlsList();
    final curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();

    // populate the concernRoleAddress key with passed in parameter
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of concernRoleAddress records for concernRole
    citizenshipReadMultiDtlsList = citizenshipObj.searchByConcernRoleIDAndStatus(
      concernRoleIDStatusCodeKey);
    // END, CR00066203

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < citizenshipReadMultiDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = citizenshipReadMultiDtlsList.dtls.item(i).citizenshipID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.CITIZENSHIP;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    // END, CR00060163

    return eiEvidenceKeyList;
    // END, CR00060045

  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type. It
   * then returns an ArrayList of strings with the names of each attribute that
   * was different between them.
   *
   * @param key
   * - Contains an evidenceID / evidenceType pairing
   * @param dtls
   * - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  @Override
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key,
    Object dtls) throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    final ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create Citizenship structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    CitizenshipDtls citizenshipCompareDtls1 = new CitizenshipDtls();
    final CitizenshipDtls citizenshipCompareDtls2 = new CitizenshipDtls();

    try {

      final curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();

      final CitizenshipKey citizenshipKey = new CitizenshipKey();

      citizenshipKey.citizenshipID = key.evidenceID;

      // read Citizenship details
      citizenshipCompareDtls1 = citizenshipObj.read(citizenshipKey);

      // Populate the Citizenship struct that will be compared against
      citizenshipCompareDtls2.assign((CitizenshipDtls) dtls);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot Citizenship entity
      final curam.core.intf.CitizenshipSnapshot citizenshipSnapshotObj = curam.core.fact.CitizenshipSnapshotFactory.newInstance();

      final CitizenshipSnapshotKey citizenshipSnapshotKey = new CitizenshipSnapshotKey();

      // populate the Citizenship snapshot key with passed in parameter
      citizenshipSnapshotKey.citizenshipSnapshotID = key.evidenceID;

      // Read the Citizenship snapshot details
      citizenshipCompareDtls2.assign(
        citizenshipSnapshotObj.read(citizenshipSnapshotKey));

      // Populate the Citizenship struct that will be compared against
      citizenshipCompareDtls1.assign((CitizenshipDtls) dtls);
    }

    if (citizenshipCompareDtls1.concernRoleID
      != citizenshipCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!citizenshipCompareDtls1.reasonCode.equals(
      citizenshipCompareDtls2.reasonCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.REASONCODE);
    }
    if (!citizenshipCompareDtls1.countryCode.equals(
      citizenshipCompareDtls2.countryCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COUNTRYCODE);
    }
    if (!citizenshipCompareDtls1.fromDate.equals(
      citizenshipCompareDtls2.fromDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.FROMDATE);
    }
    if (!citizenshipCompareDtls1.toDate.equals(citizenshipCompareDtls2.toDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TODATE);
    }
    if (!citizenshipCompareDtls1.statusCode.equals(
      citizenshipCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (citizenshipCompareDtls1.citizenshipID
      != citizenshipCompareDtls2.citizenshipID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CITIZENSHIPID);
    }
    if (!citizenshipCompareDtls1.comments.equals(
      citizenshipCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged
   * - A list of Strings. Each represents the name of an attribute that
   * changed
   *
   * @return true if Reassessment required
   */
  @Override
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications to
     * participant evidence when specified attributes are changed during the
     * modification. Currently this method returns true so any modifications to
     * participant evidence will trigger reassessment. To Implement set an
     * indicator to false and check the attributesChanged list for the
     * attributes that require reassessment. If one is found set the in
     * indicator to true
     */
  }

  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return read(evKey).toDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return read(evKey).fromDate;
    // END, CR00240667
  }
  // END, CR002204022

}
