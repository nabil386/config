/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2003, 2014.
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

/**
 * Functions for manipulating address entity.
 */

package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.ADDRESSLAYOUTTYPE;
import curam.codetable.COUNTRY;
import curam.codetable.PROVINCEREGION_CHINA_ADF;
import curam.codetable.PROVINCEREGION_JAPAN_ADF;
import curam.codetable.STREETNUMBERSUFFIXTYPE;
import curam.codetable.STREETTYPE;
import curam.core.address.impl.AddressFormat;
import curam.core.events.ADDRESS;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.ConcernRoleAddressFactory;
import curam.core.fact.IndexAddressSynchronizationFactory;
import curam.core.intf.IndexAddressSynchronization;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.AddressString;
import curam.core.sl.struct.GeoCodeDetails;
import curam.core.struct.AddressDataLineStruct;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtls;
import curam.core.struct.AddressElementStruct;
import curam.core.struct.AddressHeaderDetails;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressKeyStruct;
import curam.core.struct.AddressLineList;
import curam.core.struct.AddressMap;
import curam.core.struct.AddressMapList;
import curam.core.struct.AddressReadMultiDtls;
import curam.core.struct.AddressReadMultiDtlsList;
import curam.core.struct.AddressTagDetails;
import curam.core.struct.ConcernRoleAddressKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ElementDetails;
import curam.core.struct.EmptyIndStruct;
import curam.core.struct.EqualIndStruct;
import curam.core.struct.FormatPostalCode;
import curam.core.struct.LayoutKey;
import curam.core.struct.LoggedInUser;
import curam.core.struct.OtherAddressData;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UniqueIDKeySet;
import curam.core.struct.UserNameAndIDStruct;
import curam.core.struct.UsersKey;
import curam.core.struct.ValidateAddressResult;
import curam.message.BPOADDRESS;
import curam.message.PARTICIPANTDATACASE;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import java.util.Map;
import org.apache.xerces.impl.xpath.regex.RegularExpression;


/**
 * This process class provides the functionality for the Address impl methods.
 */
public abstract class Address extends curam.core.base.Address {

  /**
   * Version number for new address, its value is {@value} .
   */
  protected static final short kVersionNo = 1;

  /**
   * The minimum allowed address length, its value is {@value} .
   */
  @Deprecated
  protected static final short kAddressElementMinLength = 3;

  /**
   * The number of the first line in the address, its value is {@value} .
   */
  @Deprecated
  protected static final short kAddressFirstLine = 1;

  /**
   * Number of non zero-length address lines required, its value is {@value} .
   */
  @Deprecated
  protected static final short kOtherAddressLinesCount = 2;

  /**
   * Line number in address which is too short, its value is {@value} .
   */
  @Deprecated
  protected static final short kAddressLineOffset = 2;

  /**
   * The number of parts in a US address format, its value is {@value} .
   */
  @Deprecated
  protected static final int US_ADDRESS_ELEMENT_COUNT = 6;

  // BEGIN, CR00099876, SD
  /**
   * The number of parts in a US County address format, its value is {@value} .
   */
  @Deprecated
  protected static final int US_COUNTY_ADDRESS_ELEMENT_COUNT = 7;

  // END, CR00099876

  /**
   * The number of parts in a UK address format, its value is {@value} .
   */
  @Deprecated
  protected static final int UK_ADDRESS_ELEMENT_COUNT = 7;

  // BEGIN, CR00199929, SS
  /**
   * The number of parts in a CA address format, its value is {@value} .
   */
  @Deprecated
  protected static final int CA_ADDRESS_ELEMENT_COUNT = 6;

  // END, CR00199929

  // BEGIN, CR00285272, SW
  /**
   * The number of parts in a DE address format, its value is {@value} .
   */
  @Deprecated
  protected static final int DE_ADDRESS_ELEMENT_COUNT = 7;

  // END, CR00219204

  // BEGIN, CR00345816, SPD
  /**
   * The number of parts in a Traditional Chinese address format, its value
   * is {@value} .
   */
  @Deprecated
  protected static final int TW_ADDRESS_ELEMENT_COUNT = 5;

  /**
   * The number of parts in a Simplified Chinese address format, its value
   * is {@value} .
   */
  @Deprecated
  protected static final int CN_ADDRESS_ELEMENT_COUNT = 6;

  /**
   * The number of parts in a Japanese address format, its value
   * is {@value} .
   */
  @Deprecated
  protected static final int JP_ADDRESS_ELEMENT_COUNT = 5;

  /**
   * The number of parts in a South Korean address format, its value
   * is {@value} .
   */
  @Deprecated
  protected static final int KR_ADDRESS_ELEMENT_COUNT = 4;

  // END, CR00345816

  // BEGIN, CR00285272, ZV
  /**
   * The number of parts in a CA Civic address format, its value is {@value} .
   */
  @Deprecated
  protected static final int CA_CIVIC_ADDRESS_ELEMENT_COUNT = 10;

  // END, CR00199929

  /**
   * Constant for 1, its value is {@value} .
   */
  protected static final int kOne = 1;

  /**
   * length of gkTabDelimiter constant in characters, its value is {@value} .
   */
  @Deprecated
  protected static final int kTabDelimiterLen = 1;

  /**
   * The maximum size of the address data field. Its value is
   *
   * @value bytes.
   */
  @Deprecated
  protected static final int kMaxAddressDataSize = 2048;

  // BEGIN, CR00099136, GSP
  /**
   * The maximum size of the address line fields such as apt.suite, city, zip.
   * Its value is
   *
   * @value bytes.
   */
  @Deprecated
  protected static final int kMaxAddressLineSize = 256;

  // END, CR00099136

  @Inject
  protected Map<String, AddressFormat> addressFormatMap;

  public Address() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Nested class implementing `java.util.Comparator` interface used to sort
   * incoming address data into non-natural tag order.
   */
  protected static final class TagComparator implements
    java.util.Comparator<AddressMap> {

    /**
     * constant value for checking equality in compare method, its value is * *
     * * {@value} .
     */
    protected static final int kLess = -1;

    /**
     * constant value for checking equality in compare method, its value is * *
     * * {@value} .
     */
    protected static final int kGreater = 1;

    /**
     * constant value for checking equality in compare method, its value is * *
     * * {@value} .
     */
    protected static final int kEqual = 0;

    /**
     * list reflecting valid sort order.
     */
    protected final java.util.List tagList;

    // _________________________________________________________________________
    /**
     * Constructor.
     *
     * @param tagArray
     * array of Strings representing address data tags, in the order
     * into which they should be sorted.
     */
    protected TagComparator(final String[] tagArray) {

      // copy array into local list for ease of indexing
      tagList = java.util.Arrays.asList(tagArray);
    }

    // _________________________________________________________________________
    /**
     * Returns static instance for use in sorting address format specified.
     *
     * @param layoutIndicator
     * indicates which address format is to be sorted
     *
     * @return appropriate instance of this class
     *
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    protected static TagComparator getInstance(
      final String[] addressFormatTags) throws AppException,
        InformationalException {

      return new TagComparator(addressFormatTags);
    }

    // _________________________________________________________________________
    /**
     * Compares two instances of AddressMap based on the tag names they
     * represent. This method is used to sort incoming address data into valid
     * tag order.
     *
     * @param o1
     * reference to first instance of AddressMap
     * @param o2
     * reference to second instance of AddressMap
     *
     * @return -1 if the tag name represented by o1 appears before that
     * represented by o2 in the ordering of the stored list +1 if the
     * tag name represented by o1 appears after that represented by o2
     * in the ordering of the stored list 0 otherwise
     */
    @Override
    public int compare(final AddressMap addressMap1,
      final AddressMap addressMap2) {

      // Perform comparisons
      if (tagList.indexOf(addressMap1.name) < tagList.indexOf(addressMap2.name)) {

        return kLess;

      } else {

        if (tagList.indexOf(addressMap1.name)
          > tagList.indexOf(addressMap2.name)) {

          return kGreater;

        } else {

          return kEqual;
        }

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates supplied AddressDtls.
   *
   * @param details
   * contains address dtls struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void autovalidate(final AddressDtls details) throws AppException,
      InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Sets other address header details before modification. Removes related
   * address element records.
   *
   * @param key
   * address key structure (contains address ID).
   * @param details
   * address details structure.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled and the address being modified is
   * linked to a concern role for whom invocation of the modify method is
   * not allowed.
   */
  @Override
  protected void premodify(final AddressKey key, final AddressDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00354954, GD
    // Is PDC enabled
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      // Check to see if this address is linked to a concern role
      // for whom invocation of the modify method is not allowed
      final AddressReadMultiDtlsList addressReadMultiDtlsList = ConcernRoleAddressFactory.newInstance().searchAddressByAddressID(
        key);

      final ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      for (final AddressReadMultiDtls addressReadMultiDtls : addressReadMultiDtlsList.dtls) {
        concernRoleAddressKey.concernRoleAddressID = addressReadMultiDtls.concernRoleAddressID;
        concernRoleKey.concernRoleID = ConcernRoleAddressFactory.newInstance().read(concernRoleAddressKey).concernRoleID;

        if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
          throw new AppException(
            PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
        }
      }
    }
    // END, CR00354954

    // address element object and key structs.
    final curam.core.intf.AddressElement addressElementObj = curam.core.fact.AddressElementFactory.newInstance();
    final AddressKeyStruct addressKeyStruct = new AddressKeyStruct();

    // address data object and address header details structs
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    AddressHeaderDetails addressHeaderDetails;

    // address data manipulation variables
    OtherAddressData otherAddressData = new OtherAddressData();
    final AddressDataLineStruct addressDataLineStruct = new AddressDataLineStruct();

    otherAddressData.addressData = details.addressData;

    addressHeaderDetails = addressDataObj.parseDataToHeader(otherAddressData);

    if (!addressHeaderDetails.modifiableInd) {
      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_NOT_MODIFIABLE);

      e.arg(addressHeaderDetails.addressID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // increment versionNo in address data
    // since modify method in DAL will increment
    // versionNo field on the entity.
    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_VERSION_NO;
    addressDataLineStruct.lineValue = String.valueOf(
      addressHeaderDetails.versionNo + 1);
    setAddressDataLine(otherAddressData, addressDataLineStruct);

    // set widget version
    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_WIDGET_VERSION;
    addressDataLineStruct.lineValue = AddressUtil.kWidgetVersion;
    setAddressDataLine(otherAddressData, addressDataLineStruct);

    // set address header details:
    details.addressID = addressHeaderDetails.addressID;
    details.addressLayoutType = addressHeaderDetails.addressLayoutType;
    details.countryCode = addressHeaderDetails.countryCode;
    details.modifiableInd = addressHeaderDetails.modifiableInd;
    details.versionNo = addressHeaderDetails.versionNo;

    // reorder incoming tagged data into appropriate order
    otherAddressData = reorderAddressDataTags(otherAddressData);

    details.addressData = otherAddressData.addressData;
    addressKeyStruct.addressID = key.addressID;

    try {

      addressElementObj.removeByAddressID(addressKeyStruct);

    } catch (final curam.util.exception.RecordNotFoundException e) {// Do
      // nothing
      // (freeform
      // addresses will
      // have no address
      // elements
      // to remove)
    }

  }

  // ___________________________________________________________________________
  /**
   * Prevents invocation of the modifyAddress method if Participant Data Case
   * is enabled and the address being modified is linked to a concern role for
   * whom invocation of the method is not allowed.
   *
   * @param key
   * address key structure (contains address ID).
   * @param details
   * address details structure.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled and the address being modified is
   * linked to a concern role for whom invocation of the modify method is
   * not allowed.
   */
  @Override
  protected void premodifyAddress(final AddressKey key,
    final AddressDtls details) throws AppException, InformationalException {

    // BEGIN, CR00354954, GD
    // Is PDC enabled
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      // Check to see if this address is linked to a concern role
      // for whom invocation of the modify method is not allowed
      final AddressReadMultiDtlsList addressReadMultiDtlsList = ConcernRoleAddressFactory.newInstance().searchAddressByAddressID(
        key);

      final ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      for (final AddressReadMultiDtls addressReadMultiDtls : addressReadMultiDtlsList.dtls) {
        concernRoleAddressKey.concernRoleAddressID = addressReadMultiDtls.concernRoleAddressID;
        concernRoleKey.concernRoleID = ConcernRoleAddressFactory.newInstance().read(concernRoleAddressKey).concernRoleID;

        if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
          throw new AppException(
            PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
        }
      }
    }
    // END, CR00354954
  }

  // ___________________________________________________________________________
  /**
   * Prevents invocation of the modifyAddress method if Participant Data Case
   * is enabled and the address being modified is linked to a concern role for
   * whom invocation of the method is not allowed.
   *
   * @param key
   * address key structure (contains address ID).
   * @param details
   * address details structure.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled and the address being modified is
   * linked to a concern role for whom invocation of the modify method is
   * not allowed.
   */
  @Override
  protected void premodifyAddressDetails(final AddressKey key,
    final AddressDtls details) throws AppException, InformationalException {

    // BEGIN, CR00354954, GD
    // Is PDC enabled
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      // Check to see if this address is linked to a concern role
      // for whom invocation of the modify method is not allowed
      final AddressReadMultiDtlsList addressReadMultiDtlsList = ConcernRoleAddressFactory.newInstance().searchAddressByAddressID(
        key);

      final ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      for (final AddressReadMultiDtls addressReadMultiDtls : addressReadMultiDtlsList.dtls) {
        concernRoleAddressKey.concernRoleAddressID = addressReadMultiDtls.concernRoleAddressID;
        concernRoleKey.concernRoleID = ConcernRoleAddressFactory.newInstance().read(concernRoleAddressKey).concernRoleID;

        if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
          throw new AppException(
            PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);
        }
      }
    }
    // END, CR00354954
  }

  // ___________________________________________________________________________
  /**
   * Restores related address element records and Raise a post Modify event.
   *
   * @param key
   * the address key
   * @param details
   * the address details
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void postmodify(final AddressKey key, final AddressDtls details)
    throws AppException, InformationalException {

    storeElements(details);

    // BEGIN, CR00091119, DMC
    // Synchronize the indexed staging database with the
    // update to address entity
    final IndexAddressSynchronization addressSynchronizationObj = IndexAddressSynchronizationFactory.newInstance();

    addressSynchronizationObj.modify(key, details);
    // END, CR00091119

    // BEGIN, CR00092446, DG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = ADDRESS.MODIFY_ADDRESS;
    event.primaryEventData = details.addressID;

    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00092446

  }

  // ___________________________________________________________________________
  /**
   * Removes related address element records.
   *
   * @param key
   * address key structure (contains address ID).
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void preremove(final AddressKey key) throws AppException,
      InformationalException {

    // address element object and key structs.
    final curam.core.intf.AddressElement addressElementObj = curam.core.fact.AddressElementFactory.newInstance();
    final AddressKeyStruct addressKeyStruct = new AddressKeyStruct();

    addressKeyStruct.addressID = key.addressID;
    addressElementObj.removeByAddressID(addressKeyStruct);

    // BEGIN, CR00091119, DMC
    // Synchronize the indexed staging database
    // with the update to address entity
    final IndexAddressSynchronization addressSynchronizationObj = IndexAddressSynchronizationFactory.newInstance();

    addressSynchronizationObj.remove(key);
    // END, CR00091119
  }

  // ___________________________________________________________________________
  /**
   * Method takes an addressData string and returns value of first line based on
   * address format
   *
   * @param addressDataString
   * contains address data string.
   *
   * @return contains the first address line.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AddressElementStruct getFirstLine(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    AddressHeaderDetails addressHeaderDetails;

    // convert address data string to vector
    addressHeaderDetails = addressDataObj.parseDataToHeader(addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    return addressFormat.getFirstLine(addressDataString);
  }

  // ___________________________________________________________________________
  /**
   * method takes in address data and returns CITY tag (for US/UK) or the blank
   * string (for FREEFORM format).
   *
   * @param addressDataString
   * contains address data string.
   *
   * @return contains city value from address.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AddressElementStruct getCity(final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    return addressFormat.getCity(addressDataString);
  }

  // BEGIN, CR00147711, ELG
  // ___________________________________________________________________________
  /**
   * This method takes in address data and returns: USCOUNTY tag
   * This method is not used at any place and can be removed
   *
   * @param addressDataString
   * contains address data string.
   *
   * @return contains USCOUNTY value from address.
   *
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  @Deprecated
  public AddressElementStruct getCounty(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    // return structure
    final AddressElementStruct addressElementStruct = new AddressElementStruct();

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // address layout type string
    String addressLayoutType;

    AddressHeaderDetails addressHeaderDetails;

    boolean searchForElementInd = false;
    final AddressMap addressMap = new AddressMap();

    addressHeaderDetails = addressDataObj.parseDataToHeader(addressDataString);

    // get addressLayout type
    addressLayoutType = addressHeaderDetails.addressLayoutType;

    if (addressLayoutType.equals(ADDRESSLAYOUTTYPE.US)) {

      if (curam.util.resources.Configuration.getBooleanProperty(
        EnvVars.ENV_USADDRESSWITHCOUNTY,
        curam.util.resources.Configuration.getBooleanProperty(
          EnvVars.ENV_USADDRESSWITHCOUNTY_DEFAULT))) {

        searchForElementInd = true;
        addressMap.name = ADDRESSELEMENTTYPE.USCOUNTY;
      }

    }

    if (searchForElementInd) {

      AddressMapList addressMapList;
      ElementDetails elementDetails;

      // convert address data string into <name><value> pairs vector
      addressMapList = addressDataObj.parseDataToMap(addressDataString);

      // get the first address line of other format address
      elementDetails = addressDataObj.findElement(addressMapList, addressMap);

      // check if element was found
      if (elementDetails.elementFound) {
        addressElementStruct.addressElementString = elementDetails.elementValue;
      }

    } else {
      // set string to blank string
      addressElementStruct.addressElementString = CuramConst.gkEmpty;
    }

    return addressElementStruct;

  }

  // END, CR00147711

  // ___________________________________________________________________________
  /**
   * Method takes in addressDataString and returns formatted address string.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void getLongFormat(final OtherAddressData addressDataString)
    throws AppException, InformationalException {

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    addressFormat.getLongFormat(addressDataString);

  }

  // ___________________________________________________________________________
  /**
   * Placeholder method to allow CURAM customization.
   *
   * @param key
   * contains address ID.
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void getReportFormat(final AddressKeyStruct key,
    OtherAddressData addressDataString) throws AppException,
      InformationalException {

    addressDataString = getLongFormat(key);
  }

  // ___________________________________________________________________________
  /**
   * This method formats the specified address string into a single line of
   * text. This is useful for business scenarios where the full address details
   * are needed to be displayed in list rows for instance.
   *
   * @param addressDataString
   * contains address data string.
   *
   * @return contains address line.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public OtherAddressData getShortFormat(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    final OtherAddressData otherAddressData = new OtherAddressData();

    if (isEmpty(addressDataString).emptyInd) {
      return otherAddressData;
    }

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    return addressFormat.getShortFormat(addressDataString);
  }

  // BEGIN, CR00353168, SPD
  // ___________________________________________________________________________
  /**
   * @param formatString
   * String format to format address.
   * @param addressString
   * Formatted address string.
   *
   * @return Formatted address string including city element.
   * @deprecated Since Curam 6.0.5.8, replaced with
   * Formats address city element for a formatted address string.
   */
  @Deprecated
  protected AddressString formatAddressCityElement(
    AddressString formatString, AddressString addressString)
    throws AppException, InformationalException {

    final AddressString formattedString = new AddressString();

    formattedString.addressString = addressString.addressString;

    int intFormatPosEnd = formatString.addressString.indexOf(
      ADDRESSELEMENTTYPE.CITY)
        - CuramConst.gkOne;

    int intTagPosEnd = formattedString.addressString.indexOf(
      ADDRESSELEMENTTYPE.CITY)
        - CuramConst.gkOne;

    if (intFormatPosEnd >= CuramConst.gkZero) {
      int intFormatPosStart = intFormatPosEnd;

      if (intFormatPosStart > CuramConst.gkZero) {
        // BEGIN, CR00415968, SP
        while (intFormatPosStart >= 0
          && (CuramConst.gkPipeDelimiterChar
            == formatString.addressString.charAt(intFormatPosStart)
              || CuramConst.gkCommaDelimiterChar
                == formatString.addressString.charAt(intFormatPosStart)
                || CuramConst.gkSpaceChar
                  == formatString.addressString.charAt(intFormatPosStart))) {
          intFormatPosStart--;
        }
        // END, CR00415968
      }

      intFormatPosStart++;
      intFormatPosEnd++;

      int intTagPosStart = intTagPosEnd;

      if (intTagPosStart > CuramConst.gkZero) {
        // BEGIN, CR00415968, SP
        while (intTagPosStart >= 0
          && (CuramConst.gkPipeDelimiterChar
            == formattedString.addressString.charAt(intTagPosStart)
              || CuramConst.gkCommaDelimiterChar
                == formattedString.addressString.charAt(intTagPosStart)
                || CuramConst.gkSpaceChar
                  == formattedString.addressString.charAt(intTagPosStart))) {
          intTagPosStart--;
        }
        // END, CR00415968
      }

      intTagPosStart++;
      intTagPosEnd++;

      final String strFormatDelimiters = formatString.addressString.substring(
        intFormatPosStart, intFormatPosEnd);

      final String strTagDelimiters = formattedString.addressString.substring(
        intTagPosStart, intTagPosEnd);

      if (!strFormatDelimiters.equals(strTagDelimiters)) {

        formattedString.addressString = formattedString.addressString.substring(
          CuramConst.gkZero, intTagPosStart)
            + strFormatDelimiters
            + formattedString.addressString.substring(intTagPosEnd);

      }
    }

    return formattedString;
  }

  // END. CR00353168

  // ___________________________________________________________________________
  /**
   * Method decodes code table fields (e.g. city, state) to be in normal manner.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void getOneLineAddressString(final OtherAddressData addressDataString)
    throws AppException, InformationalException {

    // structure to contain address as collection of strings.
    AddressLineList addressLineList;
    int i; // reused

    // boolean indicating that an address
    // element was added to the resulting string
    boolean fWasAdded = false;

    addressLineList = getAddressAsList(addressDataString);

    // make sure that output parameter is initially empty
    // BEGIN, CR00049218, GM
    addressDataString.addressData = CuramConst.gkEmpty;
    // END, CR00049218

    final StringBuffer formatBuffer = new StringBuffer();
    int buffLen = 0;
    int stringCount = 0;

    // calculate and ensure needed format buffer length
    for (i = 0; i < addressLineList.dtls.size(); i++) {

      if (addressLineList.dtls.item(i).addressString.length() > 0) {
        buffLen = buffLen + addressLineList.dtls.item(i).addressString.length();
        stringCount++;
      }

    }

    if (stringCount > 1) {
      buffLen = buffLen
        + (CuramConst.gkComma.length() + CuramConst.gkSpace.length())
          * (stringCount - 1);
    }

    formatBuffer.ensureCapacity(buffLen);

    // format result string
    for (i = 0; i < addressLineList.dtls.size(); i++) {

      if (addressLineList.dtls.item(i).addressString.length() > 0) {

        if (fWasAdded) {
          formatBuffer.append(CuramConst.gkComma);
          formatBuffer.append(CuramConst.gkSpace);
          fWasAdded = false;
        }

        formatBuffer.append(addressLineList.dtls.item(i).addressString);
        fWasAdded = true;
      }

    }

    addressDataString.addressData = formatBuffer.toString();
  }

  // ___________________________________________________________________________
  /**
   * Method returns formatted address line passing in address ID.
   *
   * @param key
   * contains address ID.
   *
   * @return contains formatted address data.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public OtherAddressData getLongFormat(final AddressKeyStruct key)
    throws AppException, InformationalException {

    OtherAddressData otherAddressData;

    final AddressKey addressKey = new AddressKey();

    addressKey.addressID = key.addressID;
    // read address data
    otherAddressData = readAddressData(addressKey);

    // process address data
    getLongFormat(otherAddressData);

    return otherAddressData;
  }

  // ___________________________________________________________________________
  /**
   * If address layout type is not default address layout and user is not
   * "system" user then sends a ticket to user's supervisor (depending on
   * environment settings).
   *
   * @param details
   * contains address dtls struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void notifyNonDefaultLayout(final AddressDtls details)
    throws AppException, InformationalException {

    // SystemUser Object and Detail structure to read system details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Logged in user struct.
    final LoggedInUser loggedInUser = new LoggedInUser();

    final UserNameAndIDStruct userNameAndIDStruct = new UserNameAndIDStruct();

    String sNonStandardWrite = null;

    // get current user
    loggedInUser.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // get notification setting from the environment
    sNonStandardWrite = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_NOTIFYONNONSTANDARDWRITE);

    // if property does not exist the getProperty will
    // return null, so we need to check for this
    if (sNonStandardWrite == null) {
      sNonStandardWrite = curam.core.impl.EnvVars.ENV_NOTIFYONNONSTANDARDWRITE_DEFAULT;
    }

    // get system user
    systemUserDtls = systemUserObj.getSystemUserDetails();

    if (!details.addressLayoutType.equals(ADDRESSLAYOUTTYPE.DEFAULTCODE)
      && !loggedInUser.userName.equals(systemUserDtls.userName)

      && sNonStandardWrite.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      if (userNameAndIDStruct.userName != null) {

        // set up the comments for the notification
        final AppException taskComments = new AppException(
          BPOADDRESS.INF_ADDRESS_TICKET_REASON);

        taskComments.arg(loggedInUser.userName);
        taskComments.arg(details.addressID);

        // get the manager's ID (task will be assigned to them)
        final UsersKey managerUserKey = new UsersKey();

        managerUserKey.userName = userNameAndIDStruct.userName;

        // notification manipulation variables
        final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
        // WorkAllocationTask service layer object
        final StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

        standardManualDtls.dtls.assignDtls.assignmentID = loggedInUser.userName;

        // BEGIN, CR00163236, CL
        // set the details not to return the message name in the contents
        standardManualDtls.dtls.taskDtls.comments = taskComments.getMessage(
          TransactionInfo.getProgramLocale());
        // END, CR00163236

        standardManualDtls.dtls.taskDtls.subject = // BEGIN, CR00163471, JC
          BPOADDRESS.INF_ADDRESS_TICKET_SUBJECT.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC
        // BEGIN, CR00023618, SK
        standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.addressTaskDefinitionID;
        // END, CR00023618
        // Create notification
        notificationObj.createWorkAllocationNotification(standardManualDtls);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Sets modifiable Ind to true and inserts address details to database.
   *
   * @param details
   * contains address dtls struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void insert(final AddressDtls details) throws AppException,
      InformationalException {

    // details.modifiableInd will be set
    // in preInternalInsert.

    final OtherAddressData otherAddressData = new OtherAddressData();
    final AddressDataLineStruct addressDataLineStruct = new AddressDataLineStruct();

    otherAddressData.addressData = details.addressData;
    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_MODIFIABLE_IND;
    addressDataLineStruct.lineValue = String.valueOf(kOne);

    setAddressDataLine(otherAddressData, addressDataLineStruct);
    details.addressData = otherAddressData.addressData;

    insertInternal(details);
  }

  // ___________________________________________________________________________
  /**
   * Generates unique ID and assigns it to the supplied details.addressID. Also
   * initializes addressID in details.addressData.
   *
   * @param details
   * contains address dtls struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsertInternal(final AddressDtls details)
    throws AppException, InformationalException {

    // unique id object struct
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // address data manipulation variables
    AddressElementStruct addressElementStruct;
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    AddressHeaderDetails addressHeaderDetails;
    OtherAddressData otherAddressData = new OtherAddressData();
    final AddressDataLineStruct addressDataLineStruct = new AddressDataLineStruct();

    otherAddressData.addressData = details.addressData;

    // set versionNo in addressData header to 1
    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_VERSION_NO;
    addressDataLineStruct.lineValue = String.valueOf(kVersionNo);
    setAddressDataLine(otherAddressData, addressDataLineStruct);

    // generate and set unique id in addressData header

    // BEGIN, CR00260989, MR
    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    // BEGIN, CR00293207, SS
    uniqueIDKeySet.keySetName = KeySets.KEY_SET_ADDRESS;
    // END, CR00293207

    details.addressID = uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet);
    // END, CR00260989

    // set address id
    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_ADDRESS_ID;
    addressDataLineStruct.lineValue = String.valueOf(details.addressID);
    setAddressDataLine(otherAddressData, addressDataLineStruct);

    // set widget version
    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_WIDGET_VERSION;
    addressDataLineStruct.lineValue = AddressUtil.kWidgetVersion;
    setAddressDataLine(otherAddressData, addressDataLineStruct);

    addressHeaderDetails = addressDataObj.parseDataToHeader(otherAddressData);
    details.addressLayoutType = addressHeaderDetails.addressLayoutType;

    addressElementStruct = getCountry(otherAddressData);

    if (addressElementStruct.addressElementString.length() == 0) {
      details.countryCode = addressHeaderDetails.countryCode;
    } else {
      details.countryCode = addressElementStruct.addressElementString;
    }

    details.modifiableInd = addressHeaderDetails.modifiableInd;
    details.versionNo = 0;

    // reorder incoming tagged data into valid order for insert
    otherAddressData = reorderAddressDataTags(otherAddressData);

    details.addressData = otherAddressData.addressData;

    // BEGIN, CR00296699, ZV
    OtherAddressData addressLineStruct = new OtherAddressData();

    // BEGIN, CR00262618, JMA
    if (otherAddressData.addressData.length() > 0) {

      addressLineStruct = getShortFormat(otherAddressData);
    }
    // END CR00296699

    // If address is a dummy address 'Address Unavailable' then don't
    // get map information
    // BEGIN CR00340652, KRK
    if (!BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
      addressLineStruct.addressData)) {
      // END, CR00340652

      // BEGIN, CR00167389, ZV
      // get address geoCode data
      if (curam.util.resources.Configuration.getProperty(EnvVars.ENV_GEOCODE_ENABLED).equals(
        EnvVars.ENV_VALUE_YES)) {

        final curam.core.sl.intf.GeoCode geoCodeObj = curam.core.sl.fact.GeoCodeFactory.newInstance();

        getLongFormat(otherAddressData);

        final GeoCodeDetails geoCodeDetails = geoCodeObj.getGeoCodeDetails(
          otherAddressData);

        details.assign(geoCodeDetails);

      }
      // END, CR00167389
    }
    // END, CR00262618
  }

  // ___________________________________________________________________________
  /**
   * Calls storeElements and raise a post Insert event.
   *
   * @param details
   * contains address dtls struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void postinsertInternal(final AddressDtls details)
    throws AppException, InformationalException {

    storeElements(details);

    // BEGIN, CR00020369, NG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = ADDRESS.INSERT_ADDRESS;
    // END, CR00047242
    event.primaryEventData = details.addressID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00020369

    // BEGIN, CR00285272, ZV
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = details.addressData;

    if (details.addressLayoutType.equals(ADDRESSLAYOUTTYPE.CA_CIVIC)) {

      AddressMapList addressMapList;
      final AddressMap addressMap = new AddressMap();

      ElementDetails elementDetails;

      addressMap.name = ADDRESSELEMENTTYPE.STREET_TYPE;

      addressMapList = addressDataObj.parseDataToMap(otherAddressData);

      // get the street type element from the address
      elementDetails = addressDataObj.findElement(addressMapList, addressMap);

      // raise event for 'Not Available' street type
      if (elementDetails.elementFound
        && elementDetails.elementValue.equals(STREETTYPE.NOT_AVAILABLE)) {
        event.eventKey = ADDRESS.STREET_TYPE_NOT_AVAILABLE;
        curam.util.events.impl.EventService.raiseEvent(event);
      }

    }
    // END, CR00285272

  }

  // ___________________________________________________________________________
  /**
   * Clones the address specified by the details and returns the new address
   * details. The new details has modifiableInd set to False.
   *
   * @param details
   * contains address dtls struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void clone(final AddressDtls details) throws AppException,
      InformationalException {

    AddressDtls addressDtls;
    final AddressKey addressKey = new AddressKey();

    addressKey.addressID = details.addressID;

    try {
      addressDtls = read(addressKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {

      final AppException exc = new AppException(
        BPOADDRESS.ERR_ADDRESS_RNFE_TO_CLONE, e);

      exc.arg(details.addressID);
      throw exc;
    }

    addressDtls.modifiableInd = false;
    addressDtls.addressID = 0;

    // BEGIN, CR00273325, KRK
    final OtherAddressData otherAddressData = new OtherAddressData();
    final AddressDataLineStruct addressDataLineStruct = new AddressDataLineStruct();

    otherAddressData.addressData = addressDtls.addressData;

    addressDataLineStruct.lineIndex = AddressUtil.AddressDataLineIndex.I_MODIFIABLE_IND;
    addressDataLineStruct.lineValue = CuramConst.gkStringZero;

    setAddressDataLine(otherAddressData, addressDataLineStruct);
    addressDtls.addressData = otherAddressData.addressData;
    // END, CR00273325

    insertInternal(addressDtls);

    details.assign(addressDtls);
  }

  // ___________________________________________________________________________
  /**
   * Returns a boolean (in structure) showing: - for name/value formats, whether
   * all the tags have an empty value. - for FREEFORM format, if the freeform
   * address data is empty.
   *
   * @param details
   * Other address details struct.
   *
   * @return Returned indicator struct.
   */
  @Override
  public EmptyIndStruct isEmpty(final OtherAddressData details)
    throws AppException, InformationalException {

    final EmptyIndStruct emptyIndStruct = new EmptyIndStruct();

    if (details.addressData.length() == 0) {

      emptyIndStruct.emptyInd = true;

    } else {

      final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
      final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
        details);

      final AddressFormat addressFormat = addressFormatMap.get(
        addressHeaderDetails.addressLayoutType);

      if (addressFormat != null) {
        emptyIndStruct.emptyInd = addressFormat.isEmpty(details).emptyInd;
      } else {

        // BEGIN, CR00103736, ELG
        // unrecognized format
        final AppException ae = new AppException(
          BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

        ae.arg(addressHeaderDetails.addressLayoutType);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }
    }
    return emptyIndStruct;
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided and notifies user's
   * supervisor of non-standard address writes.
   *
   * @param details
   * Address details struct.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void storeElements(final AddressDtls details)
    throws AppException, InformationalException {

    final AddressFormat addressFormat = addressFormatMap.get(
      details.addressLayoutType);

    if (addressFormat == null) {

      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(details.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }
    addressFormat.storeElements(details);

    if (!ADDRESSLAYOUTTYPE.DEFAULTCODE.equals(details.addressLayoutType)) {

      notifyNonDefaultLayout(details);

    }

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the element from the AddressMapList specified by AddressMap.name
   * and stores the value retrieved as an address element.
   *
   * @param addressMapList
   * the list of the address map
   * @param addressElementDtls
   * the details of the address elements
   * @param addressMap
   * the address map
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void storeElement(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls, final AddressMap addressMap)
    throws AppException, InformationalException {

    // Address element object and details structs.
    final curam.core.intf.AddressElement addressElementObj = curam.core.fact.AddressElementFactory.newInstance();
    ElementDetails elementDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    addressElementDtls.elementType = addressMap.name;

    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound) {

      addressElementDtls.elementValue = elementDetails.elementValue;
      // generate unique id here
      addressElementDtls.addressElementID = uniqueIDObj.getNextID();
      addressElementObj.insert(addressElementDtls);
    }

  }

  // ___________________________________________________________________________
  /**
   * Method returns address as vector of strings.
   *
   * @param addressDataString
   * contains address ID.
   *
   * @return .contains address vector of strings.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AddressLineList getAddressAsList(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    AddressLineList addressLineList = new AddressLineList();

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // convert address data string to vector
    if (addressDataString.addressData.length() > 0) {
      AddressHeaderDetails addressHeaderDetails;

      addressHeaderDetails = addressDataObj.parseDataToHeader(addressDataString);

      final AddressFormat addressFormat = addressFormatMap.get(
        addressHeaderDetails.addressLayoutType);

      if (addressFormat == null) {
        final AppException ae = new AppException(
          BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

        ae.arg(addressHeaderDetails.addressLayoutType);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }

      addressLineList = addressFormat.getAddressAsList(addressDataString);
    }

    return addressLineList;
  }

  // ___________________________________________________________________________
  /**
   * Returns tab separated string of address tags for the address layout
   * specified.
   *
   * @param key
   * contains address layout type code.
   *
   * @return contains returned addressTags tab separated string
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected AddressTagDetails getAddressTagsForLayout(final LayoutKey key)
    throws AppException, InformationalException {

    final AddressFormat addressFormat = addressFormatMap.get(
      key.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(key.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    return addressFormat.getAddressTagsForLayout();

  }

  // ___________________________________________________________________________
  /**
   * Validates the contents of the specified address. Returns the address header
   * information and a list of address details, either freeform or a list of
   * name-value pairs for non-freeform.
   *
   * @param addressDtls
   * address details to be validated.
   *
   * @return structure to indicate if address is valid.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ValidateAddressResult validate(final AddressDtls addressDtls)
    throws AppException, InformationalException {

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = addressDtls.addressData;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      otherAddressData);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      e.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    return addressFormat.validate(addressDtls);
  }

  // ___________________________________________________________________________
  /**
   * Checks that the details in the specified address header are valid.
   *
   * @param addressHeaderDetails
   * address header details
   */
  @Override
  @Deprecated
  protected void validateHeader(
    final AddressHeaderDetails addressHeaderDetails) throws AppException,
      InformationalException {

    if (addressHeaderDetails.versionNo < 0) {
      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_VERSION_NO_INVALID);

      e.arg(addressHeaderDetails.versionNo);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Checks that each of the specified freeform address lines are valid.
   *
   * @param addressLineList
   * list of address lines
   */
  @Override
  @Deprecated
  protected void validateFreeformAddress(final AddressLineList addressLineList)
    throws AppException, InformationalException {

    String sBuff;

    // raise an exception if address line list is empty at all
    if (addressLineList.dtls.size() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_FREEFORM_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    } else {

      for (int i = 0; i < addressLineList.dtls.size(); i++) {

        sBuff = addressLineList.dtls.item(i).addressString;

        if (curam.util.resources.StringUtil.rtrim(sBuff).length()
          < AddressUtil.kMinAddrLineLen) {

          final AppException e = new AppException(
            BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

          e.arg(i);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            5);
        }

      }

    }
  }

  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid US format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateUSAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    // AddressData object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // Address map and element details
    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    // boolean indicator for first address line
    boolean fFirstLineEmpty;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.US;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {

      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    // fields of elementDetails are set to the right values inside
    // the AddressData.findElement method even if element is not found,
    // so there is no need to initialize elementDetails fields before
    // this call
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    fFirstLineEmpty = elementDetails.elementValue.length() == 0;

    // check for second address line
    addressMap.name = ADDRESSELEMENTTYPE.LINE2;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (fFirstLineEmpty) {

      if (elementDetails.elementValue.length() < AddressUtil.kMinAddrLineLen) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOADDRESS.ERR_ADDRESS_XFV_ADDRESS_LINE1_LINE2),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

    } else {

      if (elementDetails.elementValue.length() > 0
        && elementDetails.elementValue.length() < AddressUtil.kMinAddrLineLen) {

        final AppException e = new AppException(
          BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

        e.arg(AddressUtil.kSecond);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
      }

    }

    // check for third address line
    addressMap.name = ADDRESSELEMENTTYPE.LINE3;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() > 0
      && elementDetails.elementValue.length() < AddressUtil.kMinAddrLineLen) {

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

      e.arg(AddressUtil.kThird);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }
    // BEGIN, CR00099136, GSP
    addressMap.name = ADDRESSELEMENTTYPE.ZIP;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    // BEGIN, CR00380472, MV
    if (0 < elementDetails.elementValue.length()) {
      final RegularExpression regExp = new RegularExpression(
        CuramConst.gkUSValidZIP);

      if (!regExp.matches(elementDetails.elementValue)) {
        ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOADDRESS.ERR_ADDRESS_FV_ZIP_NOTVALID),
          ValidationManagerConst.kSetOne, 0);
      }
    }
    // END, CR00380472

    // BEGIN, CR00190252, NP
    if (elementDetails.elementValue.length() > kMaxAddressLineSize) {
      // END, CR00190252

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ZIP_LONG);

      e.arg(elementDetails.elementValue.length());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }
    // END, CR00099136
  }

  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid UK format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateUKAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    // AddressData object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // Address map and element details
    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.UK;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() == 0
      || elementDetails.elementValue.length() < kAddressElementMinLength) {

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

      e.arg(kAddressFirstLine);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    // based on domain ADDRESS_ELEMENT_TYPE_CODE
    final String[] addressLine = {
      ADDRESSELEMENTTYPE.LINE2,
      ADDRESSELEMENTTYPE.LINE3 };

    for (int i = 0; i < kOtherAddressLinesCount; i++) {

      addressMap.name = addressLine[i];
      elementDetails = addressDataObj.findElement(addressMapList, addressMap);

      if (elementDetails.elementValue.length() > 0
        && elementDetails.elementValue.length() < kAddressElementMinLength) {

        final AppException e = new AppException(
          BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

        e.arg(i + kAddressLineOffset);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

    }
    // BEGIN, CR00099136, GSP
    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);
    // BEGIN, CR00190252, NP
    if (elementDetails.elementValue.length() > kMaxAddressLineSize) {
      // END, CR00190252
      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ZIP_LONG);

      e.arg(elementDetails.elementValue.length());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00099136
  }

  // BEGIN, CR00199929, SS
  /**
   * Checks that the specified address details are in a valid CA format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateCAAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.CA;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() == 0
      || elementDetails.elementValue.length() < kAddressElementMinLength) {
      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

      e.arg(kAddressFirstLine);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 6);
    }

    addressMap.name = ADDRESSELEMENTTYPE.CITY;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() == 0) {
      final AppException e = new AppException(BPOADDRESS.ERR_CITY_UNAVAILABLE);

      e.arg(kAddressFirstLine);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() > kMaxAddressLineSize) {
      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ZIP_LONG);

      e.arg(elementDetails.elementValue.length());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (elementDetails.elementValue.length() != 0
      && !isValidCAPostalCode(elementDetails.elementValue.trim())) {
      final AppException excp = new AppException(
        BPOADDRESS.ERR_POSTAL_CODE_FORMAT);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        excp, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    }
  }

  // END, CR00199929

  // BEGIN, CR00219873, ELG
  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid DE format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateDEAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    // AddressData object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // Address map and element details
    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.DE;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {

      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    // BEGIN, CR00390589, SPD
    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    // fields of elementDetails are set to the right values inside
    // the AddressData.findElement method even if element is not found,
    // so there is no need to initialize elementDetails fields before
    // this call
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    // Check Street/Number
    if (elementDetails.elementValue.length() < AddressUtil.kMinAddrLineLen) {

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ADDRESS_LINE_LENGTH);

      e.arg(AddressUtil.kFirst);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00390589
    // BEGIN, CR00219204, SW

    // Check that both city and post code are entered
    addressMap.name = ADDRESSELEMENTTYPE.CITY;
    final ElementDetails cityElementDetails = addressDataObj.findElement(
      addressMapList, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    final ElementDetails postCodeElementDetails = addressDataObj.findElement(
      addressMapList, addressMap);

    if (cityElementDetails.elementValue.length() == CuramConst.gkZero
      || postCodeElementDetails.elementValue.length() == CuramConst.gkZero) {

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_CITY_POSTCODE_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
    // END, CR00219204
  }

  // END, CR00219873

  // ___________________________________________________________________________
  /**
   * Takes in an address data string and returns: - for US/UK/DE format, four
   * address line strings (if available) separated by newline character. - for
   * FREEFORM format, four lines (if available) from address data, starting from
   * line 7.
   *
   * @param addressDataString
   * contains layout format and address data string
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void getAddressStrings(final OtherAddressData addressDataString)
    throws AppException, InformationalException {

    getLongFormat(addressDataString);
  }

  // ___________________________________________________________________________
  /**
   * Checks if firstAddressData and secondAddressData strings contain the same
   * address.
   *
   * @param firstAddressData
   * Contains first addressData string for comparison.
   * @param secondAddressData
   * Contains second addressData string for comparison
   *
   * @return Contains comparison result.
   */
  @Override
  public EqualIndStruct isEqual(final OtherAddressData firstAddressData,
    final OtherAddressData secondAddressData) throws AppException,
      InformationalException {

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    final AddressHeaderDetails addressHeaderDetailsFirst = addressDataObj.parseDataToHeader(
      firstAddressData);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetailsFirst.addressLayoutType);

    if (addressFormat == null) {
      // BEGIN, CR00103736, ELG
      // unrecognized format
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetailsFirst.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }
    return addressFormat.isEqual(firstAddressData, secondAddressData);

  }

  // ___________________________________________________________________________
  /**
   * Sets addressData line according to the value and index specified in
   * lineData.
   *
   * @param addressData
   * contains addressData string.
   * @param lineData
   * contains line index and value for modification.
   */
  @Override
  public void setAddressDataLine(final OtherAddressData addressData,
    final AddressDataLineStruct lineData) throws AppException,
      InformationalException {

    // AddressData object, Address Line list structures
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    AddressLineList addressLineList = null;

    if (addressData.addressData.length() > 0) {

      // split the addressData into string list
      addressLineList = addressDataObj.newlineText2List(addressData);

    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADDRESS.ERR_ADDRESS_FV_ADDRESSDATA_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (lineData.lineIndex < AddressUtil.AddressDataLineIndex.I_WIDGET_VERSION
      || lineData.lineIndex + 1 > addressLineList.dtls.size()) {

      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_LINE_INDEX_OUTOFRANGE);

      e.arg(lineData.lineIndex);
      e.arg(AddressUtil.AddressDataLineIndex.I_WIDGET_VERSION);
      e.arg(addressLineList.dtls.size() - 1);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // change value of line specified
    addressLineList.dtls.item(lineData.lineIndex).addressString = lineData.lineValue;

    // build up addressData string from string list
    final StringBuffer formatBuffer = new StringBuffer();
    int bufferSize = 0;

    // length of all newline characters that will be added to the string
    final int nlAddLength = CuramConst.gkNewLine.length()
      * addressLineList.dtls.size();

    // calculate needed buffer size

    for (int i = 0; i < addressLineList.dtls.size(); i++) {

      bufferSize = bufferSize
        + addressLineList.dtls.item(i).addressString.length();
    }

    bufferSize = bufferSize + nlAddLength;
    formatBuffer.ensureCapacity(bufferSize);

    for (int i = 0; i < addressLineList.dtls.size(); i++) {

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    addressData.addressData = formatBuffer.toString();
  }

  // ___________________________________________________________________________
  /**
   * Puts address data tags into correct order.
   *
   * @param data
   * address data for reordering.
   *
   * @return reordered address data or original address data if we don't know
   * how to sort specified format
   */
  @Override
  public OtherAddressData reorderAddressDataTags(final OtherAddressData data)
    throws AppException, InformationalException {

    // variable providing address data manipulation utility methods
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    // variable used to assist in sorting of list
    TagComparator tagComparator = null;

    // store meta-data portion of address
    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      data);

    if (addressHeaderDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.FREEFORM)) {
      return data;
    }
    // retrieve appropriate comparator based on address layout type
    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    tagComparator = TagComparator.getInstance(addressFormat.getTagArray());

    // parse String data into list of name/tag pairs
    final AddressMapList addressMapList = addressDataObj.parseDataToMap(data);

    // invoke sort method on list which will use Comparator object supplied
    // to establish sort order
    java.util.Collections.sort(addressMapList.dtls, tagComparator);

    // convert newly sorted map back to original String format
    final OtherAddressData otherAddressData = addressDataObj.parseMapToData(
      addressMapList);

    // recombine meta-data and address data
    // prepare a StringBuffer of sufficient size to recreate meta-data as string
    final StringBuffer formatBuffer = new StringBuffer();

    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * AddressUtil.kAddressHeaderLineCount
        + String.valueOf(addressHeaderDetails.widgetVersion).length()
        + String.valueOf(addressHeaderDetails.addressID).length()
        + addressHeaderDetails.addressLayoutType.length()
        + addressHeaderDetails.countryCode.length()
        + CuramConst.gkStringZero.length()
        + String.valueOf(addressHeaderDetails.versionNo).length());

    // rebuild meta-data string
    formatBuffer.append(addressHeaderDetails.widgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressHeaderDetails.addressID);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressHeaderDetails.addressLayoutType);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressHeaderDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);

    if (addressHeaderDetails.modifiableInd) {

      formatBuffer.append(kOne);

    } else {

      formatBuffer.append(CuramConst.gkStringZero);
    }

    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressHeaderDetails.versionNo);
    formatBuffer.append(CuramConst.gkNewLine);

    // insert meta-data before address data
    otherAddressData.addressData = formatBuffer + otherAddressData.addressData;

    return otherAddressData;
  }

  // ___________________________________________________________________________
  /**
   * method takes in address data and returns STATE tag US Address.
   *
   * @param addressDataString
   * Contains address data string.
   *
   * @return Contains state value from address if one exists. If there is no
   * state element or if the address format is not US then the
   * addressElement returned will contain an empty string.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AddressElementStruct getState(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    return addressFormat.getState(addressDataString);

  }

  // ___________________________________________________________________________
  /**
   * method takes in address data and returns COUNTRY tag US/UK/DE Address.
   *
   * @param addressDataString
   * Contains address data string.
   *
   * @return Contains country value from address if one exists. If there is no
   * country element then the addressElement returned will contain an
   * empty string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AddressElementStruct getCountry(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    return addressFormat.getCountry(addressDataString);

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by insertInternal
   * @param details
   * the address details
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void internalInsert(final AddressDtls details)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    insertInternal(details);

    // BEGIN, CR00091119, DMC
    // Synchronize the indexed staging database
    // with the update to address entity
    final IndexAddressSynchronization addressSynchronizationObj = IndexAddressSynchronizationFactory.newInstance();

    addressSynchronizationObj.insertInternal(details);
    // END, CR00091119
  }

  // __________________________________________________________________________
  /**
   * Raise a post remove event.
   *
   * @param key
   * Address key to remove
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void postremove(final AddressKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00020369, NG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = ADDRESS.REMOVE_ADDRESS;
    event.primaryEventData = key.addressID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00020369
  }

  // BEGIN, CR00199929, SS
  /**
   * Ensures the post code is in the format ANA NAN example: B9T 9A9.
   *
   * @param postCode
   * Postal Code
   *
   * @return true if postal code matches pattern
   */
  @Deprecated
  protected boolean isValidCAPostalCode(final String postCode) {

    // CA postal code regular expression.
    // BEGIN, CR00285272, ZV
    final RegularExpression regExp = new RegularExpression(
      CuramConst.gkCanadianREWithSpace);

    // END, CR00285272

    return regExp.matches(postCode);
  }

  // BEGIN, CR00305878, KRK
  /**
   * Format the postcode - lower case to caps, and add a central space. Example:
   * "v6e3w2" becomes "V6E 3W2".
   *
   * @param postCode
   * Postal Code
   *
   * @return reformatted postal code string
   *
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link Address# formatPostalCodeValue(String postCode)}. The
   * current method is difficult to access as it was not being
   * hand-crafted in the model level. So, a new method has been
   * introduced in the model which makes more easily accessible
   * within the code base. See release note : CS-10787/CR00305878.
   */
  @Deprecated
  protected String formatPostalCode(final String postCode) {

    // END, CR00305878
    final short firstPostalCodePartLen = 3;
    final short postalCodeLen = 6;
    // CA postal code regular expression.
    final RegularExpression exp1 = new RegularExpression(
      CuramConst.gkCanadianREWithSpace);
    final RegularExpression exp2 = new RegularExpression(
      CuramConst.gkCanadianRE);

    if (exp1.matches(postCode)) {
      return postCode.toUpperCase();
    } else if (exp2.matches(postCode)) {
      return (postCode.substring(0, firstPostalCodePartLen) + CuramConst.gkSpace + postCode.substring(firstPostalCodePartLen, postalCodeLen)).toUpperCase();
    }

    // If the postal code cannot be formated just return it in upper case.
    return postCode.toUpperCase();
  }

  // END, CR00199929

  // BEGIN, CR00222456, ZV
  // ___________________________________________________________________________
  /**
   * Method takes an addressData string and returns value of <ADD2> tag (UK
   * format), <ADD3> tag (US/DE format) or first line of address (FREEFORM
   * format).
   *
   * @param addressDataString
   * contains address data string.
   *
   * @return contains the second address line.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AddressElementStruct getSecondLine(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    // address data object
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    AddressHeaderDetails addressHeaderDetails;

    // convert address data string to vector
    addressHeaderDetails = addressDataObj.parseDataToHeader(addressDataString);

    final AddressFormat addressFormat = addressFormatMap.get(
      addressHeaderDetails.addressLayoutType);

    if (addressFormat == null) {
      final AppException ae = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_LAYOUT_TYPE_INVALID);

      ae.arg(addressHeaderDetails.addressLayoutType);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    return addressFormat.getSecondLine(addressDataString);

  }

  // END, CR00222456

  // BEGIN, CR00265303, ZV
  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the US layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsUS(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    storeElementsCommon(addressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.STATE;
    storeElement(addressMapList, addressElementDtls, addressMap);

    // BEGIN, CR00147857, ELG
    if (curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_USADDRESSWITHCOUNTY,
      curam.util.resources.Configuration.getBooleanProperty(
        EnvVars.ENV_USADDRESSWITHCOUNTY_DEFAULT))) {

      addressMap.name = ADDRESSELEMENTTYPE.USCOUNTY;
      storeElement(addressMapList, addressElementDtls, addressMap);

    }
    // END, CR00147857

    addressMap.name = ADDRESSELEMENTTYPE.ZIP;
    storeElement(addressMapList, addressElementDtls, addressMap);

    // BEGIN, CR00222456, ZV
    addressMap.name = ADDRESSELEMENTTYPE.LINE3;
    storeElement(addressMapList, addressElementDtls, addressMap);
    // END, CR00222456
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the UK layout.
   *
   * @param addressMapList
   * Contains the list of the address map.
   * @param addressElementDtls
   * Contains the details of the address elements.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsUK(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    storeElementsCommon(addressMapList, addressElementDtls);

    // BEGIN, CR00322310, DJ
    addressMap.name = ADDRESSELEMENTTYPE.LINE3;
    storeElement(addressMapList, addressElementDtls, addressMap);
    // END, CR00322310

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(addressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the DE layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsDE(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    storeElementsCommon(addressMapList, addressElementDtls);

    // BEGIN, CR00222456, ZV
    addressMap.name = ADDRESSELEMENTTYPE.LINE3;
    storeElement(addressMapList, addressElementDtls, addressMap);
    // END, CR00222456

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(addressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.DISTRICT;
    storeElement(addressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.POBOXNO;
    storeElement(addressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the CA layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsCA(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    storeElementsCommon(addressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.PROVINCE;
    storeElement(addressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(addressMapList, addressElementDtls, addressMap);

  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the non
   * specific layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsNonSpecificLayout(
    final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    storeElementsCommon(addressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(addressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Creates common address elements from the address data provided.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsCommon(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    storeElement(addressMapList, addressElementDtls, addressMap);

    // BEGIN, CR00218133, ZV
    addressMap.name = ADDRESSELEMENTTYPE.LINE2;
    storeElement(addressMapList, addressElementDtls, addressMap);
    // END, CR00218133

    addressMap.name = ADDRESSELEMENTTYPE.CITY;
    storeElement(addressMapList, addressElementDtls, addressMap);
  }

  // END, CR00265303

  // BEGIN, CR00285272, ZV
  /**
   * Checks that the specified address details are in a valid CA Civic format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateCACivicAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.CA_CIVIC;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NAME;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NAME;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADDRESS.ERR_ADDRESS_FV_STREET_NAME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() > kMaxAddressLineSize) {
      final AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_ZIP_LONG);

      e.arg(elementDetails.elementValue.length());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if (elementDetails.elementValue.length() != 0
      && !isValidCAPostalCode(elementDetails.elementValue.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADDRESS.ERR_ADDRESS_FV_POSTAL_CODE_FORMAT_A1A_1A1),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the CA Civic
   * layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsCACivic(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    AddressMap addressMap = new AddressMap();

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMapList storeAddressMapList = new AddressMapList();

    storeAddressMapList.assign(addressMapList);

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NUMBER;

    ElementDetails elementDetails = addressDataObj.findElement(addressMapList,
      addressMap);

    if (elementDetails.elementFound) {
      addressMap.value = elementDetails.elementValue;
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NUMBER_SUFFIX;

    // get the first address line of other format address
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (addressMap.value.length() > CuramConst.gkZero) {
        addressMap.value += CuramConst.gkSpace;
      }
      addressMap.value += CodeTable.getOneItem(STREETNUMBERSUFFIXTYPE.TABLENAME,
        elementDetails.elementValue);
    }

    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    storeAddressMapList.dtls.addRef(addressMap);

    addressMap = new AddressMap();

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NAME;

    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      addressMap.value = elementDetails.elementValue;
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_TYPE;

    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (!elementDetails.elementValue.equals(STREETTYPE.NOT_AVAILABLE)) {
        if (addressMap.value.length() > CuramConst.gkZero) {
          addressMap.value += CuramConst.gkSpace;
        }
        addressMap.value += CodeTable.getOneItem(STREETTYPE.TABLENAME,
          elementDetails.elementValue);
      }
    }

    addressMap.name = ADDRESSELEMENTTYPE.LINE2;
    storeAddressMapList.dtls.addRef(addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.LINE2;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.CITY;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.PROVINCE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Method takes in address data and returns PROVINCE tag CA Address.
   *
   * @param addressDataString
   * Contains address data string.
   *
   * @return Contains province value from address if one exists. If there is no
   * province element or if the address format is not CA then the
   * addressElement returned will contain an empty string.
   *
   * @throws InformationalException
   *
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AddressElementStruct getProvince(
    final OtherAddressData addressDataString) throws AppException,
      InformationalException {

    final AddressElementStruct addressElementStruct = new AddressElementStruct();

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressHeaderDetails addressHeaderDetails = addressDataObj.parseDataToHeader(
      addressDataString);

    if (addressHeaderDetails.addressLayoutType.equals(ADDRESSLAYOUTTYPE.CA)
      || addressHeaderDetails.addressLayoutType.equals(
        ADDRESSLAYOUTTYPE.CA_CIVIC)) {

      AddressMapList addressMapList;
      final AddressMap addressMap = new AddressMap();

      ElementDetails elementDetails;

      addressMap.name = ADDRESSELEMENTTYPE.PROVINCE;

      // convert address data string into <name><value> pairs vector
      addressMapList = addressDataObj.parseDataToMap(addressDataString);

      // get the state element from the address
      elementDetails = addressDataObj.findElement(addressMapList, addressMap);

      // check if element was found
      if (elementDetails.elementFound) {
        addressElementStruct.addressElementString = elementDetails.elementValue;
      }
    }

    return addressElementStruct;
  }

  // END, CR00285272

  // BEGIN, CR00305878, KRK
  /**
   * Retrieves the formatted postal code in the pattern of ANA NAN.
   *
   * @param postalCode
   * Contains the postal code.
   *
   * @return The formatted postal code.
   */
  @Override
  @Deprecated
  public FormatPostalCode formatPostalCodeValue(final String postalCode)
    throws AppException, InformationalException {

    final short firstPostalCodePartLen = 3;
    final short postalCodeLen = 6;
    // CA postal code regular expression.
    final RegularExpression canadianREWithSpace = new RegularExpression(
      CuramConst.gkCanadianREWithSpace);
    final RegularExpression canadianREWithoutSpace = new RegularExpression(
      CuramConst.gkCanadianRE);

    final FormatPostalCode formatPostCode = new FormatPostalCode();

    if (canadianREWithSpace.matches(postalCode)) {
      formatPostCode.postalCode = postalCode.toUpperCase();
      return formatPostCode;
    } else if (canadianREWithoutSpace.matches(postalCode)) {
      formatPostCode.postalCode = (postalCode.substring(0, firstPostalCodePartLen) + CuramConst.gkSpace + postalCode.substring(firstPostalCodePartLen, postalCodeLen)).toUpperCase();
      return formatPostCode;

    }
    formatPostCode.postalCode = postalCode.toUpperCase();
    // If the postal code cannot be formated just return it in upper case.
    return formatPostCode;
  }

  // END, CR00305878

  /**
   * {@inheritDoc}
   */
  @Deprecated
  protected void addCountryDescription(
    final OtherAddressData addressDataString,
    AddressLineList addressLineList,
    AddressHeaderDetails addressHeaderDetails, int j,
    final StringBuffer formatBuffer, int addLength) throws AppException,
      InformationalException {

    // address variables
    AddressElementStruct addressElementStruct;

    int i;
    boolean countryEntered = false;
    String countryDescriptionStr = CuramConst.gkEmpty;

    addressElementStruct = getCountry(addressDataString);

    if (addressElementStruct.addressElementString.length() == 0) {

      // BEGIN, CR00219873, ELG
      if (TransactionInfo.getProgramLocale().equals(CuramConst.gkDELocale)) {
        countryDescriptionStr = CuramConst.gkEmpty;
      } else {
        // END, CR00219873

        if (addressHeaderDetails.countryCode.length() > 0) {
          // BEGIN, CR00163098, JC
          countryDescriptionStr = curam.util.type.CodeTable.getOneItem(// BEGIN, CR00439896, RB
            COUNTRY.TABLENAME, addressHeaderDetails.countryCode,
            TransactionInfo.getProgramLocale());
          // END, CR00439896
          // END, CR00163098, JC
          addLength = addLength + countryDescriptionStr.length()
            + 2 * CuramConst.gkNewLine.length();

        } else {
          // BEGIN, CR00049218, GM
          countryDescriptionStr = CuramConst.gkEmpty;
          // END, CR00049218
        }

        // BEGIN, CR00219873, ELG
      }
      // END, CR00219873

    } else {

      if (addressHeaderDetails.countryCode.length() > 0) {

        countryEntered = true;
        // BEGIN, CR00163098, JC
        // BEGIN, CR00439896, RB
        countryDescriptionStr = curam.util.type.CodeTable.getOneItem(
          COUNTRY.TABLENAME, addressElementStruct.addressElementString,
          TransactionInfo.getProgramLocale());
        // END, CR00439896
        // END, CR00163098, JC

        addLength = addLength + countryDescriptionStr.length()
          + 2 * CuramConst.gkNewLine.length();
      }
    }

    // reallocate format buffer
    formatBuffer.ensureCapacity(addLength);

    // boolean indicating that an address
    // element was added to the resulting string
    boolean fWasAdded = false;

    // format output string
    for (i = j; i < addressLineList.dtls.size(); i++) {

      if (addressLineList.dtls.item(i).addressString.length() > 0) {

        if (fWasAdded) {
          formatBuffer.append(CuramConst.gkNewLine);
          fWasAdded = false;
        }
        formatBuffer.append(addressLineList.dtls.item(i).addressString);
        fWasAdded = true;
      }
    }

    if (!countryEntered) {
      // BEGIN, CR00285272, ZV
      // BEGIN, CR00272990, KRK
      // add country at the end of formatted address
      if (addressHeaderDetails.countryCode.length() > 0
        && !(ADDRESSLAYOUTTYPE.US.equals(addressHeaderDetails.addressLayoutType)
          || ADDRESSLAYOUTTYPE.CA_CIVIC.equals(
            addressHeaderDetails.addressLayoutType)
            || ADDRESSLAYOUTTYPE.TW.equals(
              addressHeaderDetails.addressLayoutType)
              || ADDRESSLAYOUTTYPE.CN.equals(
                addressHeaderDetails.addressLayoutType)
                || ADDRESSLAYOUTTYPE.JP.equals(
                  addressHeaderDetails.addressLayoutType)
                  || ADDRESSLAYOUTTYPE.KR.equals(
                    addressHeaderDetails.addressLayoutType))) {
        // END, CR00272990
        // END, CR00285272
        // add country code at the end of the string.
        formatBuffer.append(CuramConst.gkNewLine);
        formatBuffer.append(countryDescriptionStr);
      }
    }
  }

  // BEGIN, CR00345882, SPD
  // ___________________________________________________________________________
  /**
   * This method returns a formatted Simplified Chinese address string which is
   * typically displayed over two or more lines of text for the user. This is
   * in contrast to the short format which is always displayed as one line of
   * text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getCNLongFormat(AddressLineList addressLineList,
    final StringBuffer formatBuffer) throws AppException,
      InformationalException {

    int i;
    int k;
    int j;
    int l;

    // First line - Postal Code and Province
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_2;

    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());

      // Handle formatting when no PROVINCE element is set
      if (addressLineList.dtls.item(j).addressString.length() == 0) {

        formatBuffer.append(addressLineList.dtls.item(i).addressString);
        formatBuffer.append(CuramConst.gkNewLine);
      } else {
        formatBuffer.append(addressLineList.dtls.item(i).addressString);
      }
    }

    if (addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkSpace.length());

      // Handle formatting when no POSTCODE element is set
      if (addressLineList.dtls.item(i).addressString.length() == 0) {

        formatBuffer.append(
          CodeTable.getOneItem(PROVINCEREGION_CHINA_ADF.TABLENAME,
          addressLineList.dtls.item(j).addressString));
        formatBuffer.append(CuramConst.gkNewLine);

      } else {
        formatBuffer.append(CuramConst.gkSpace);
        formatBuffer.append(
          CodeTable.getOneItem(PROVINCEREGION_CHINA_ADF.TABLENAME,
          addressLineList.dtls.item(j).addressString));
        formatBuffer.append(CuramConst.gkNewLine);
      }
    }

    // Second line - Merge CITY, DISTRICT, ADD1 and ADD2 elements into one line
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_3;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_4;
    k = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_5;
    l = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_6;

    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkComma.length() + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkComma);
      formatBuffer.append(CuramConst.gkSpace);
    }

    if (addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkComma.length() + CuramConst.gkSpace.length());

      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkComma);
      formatBuffer.append(CuramConst.gkSpace);
    }

    if (addressLineList.dtls.item(k).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(k).addressString.length()
          + CuramConst.gkComma.length() + CuramConst.gkSpace.length());

      formatBuffer.append(addressLineList.dtls.item(k).addressString);
      formatBuffer.append(CuramConst.gkComma);
      formatBuffer.append(CuramConst.gkSpace);
    }

    if (addressLineList.dtls.item(l).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(l).addressString.length());

      formatBuffer.append(addressLineList.dtls.item(l).addressString);
    }

    // Remove trailing comma and space characters (if one exists)
    final int sbLength = formatBuffer.length();
    final Integer indexTrailingComma = new Integer(sbLength - 2);
    final Integer checkLastCommaIndex = new Integer(
      formatBuffer.lastIndexOf(CuramConst.gkComma));

    // remove trailing comma and space characters
    if (indexTrailingComma.equals(checkLastCommaIndex)) {
      formatBuffer.delete(checkLastCommaIndex.intValue(), sbLength);
    }
    // set j to point to the next address line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_7;
    return j;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a formatted Japanese address string which is typically
   * displayed over two or more lines of text for the user. This is in contrast
   * to the short format which is always displayed as one line of text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getJPLongFormat(AddressLineList addressLineList,
    final StringBuffer formatBuffer) throws AppException,
      InformationalException {

    int i;
    int k;
    int j;
    int l;

    // First line - Postal Code
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;

    // Postal code
    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    // Second Line - Merge PROVINCE, CITY, ADD1 and ADD2 elements into one line
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_2;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_3;
    k = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_4;
    l = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_5;

    // Province (Prefecture)
    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkSpace.length());

      formatBuffer.append(
        CodeTable.getOneItem(PROVINCEREGION_JAPAN_ADF.TABLENAME,
        addressLineList.dtls.item(i).addressString));
      formatBuffer.append(CuramConst.gkSpace);
    }

    // City/Town
    if (addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkSpace.length());

      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkSpace);
    }

    // Address Line 1
    if (addressLineList.dtls.item(k).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(k).addressString.length()
          + CuramConst.gkSpace.length());

      formatBuffer.append(addressLineList.dtls.item(k).addressString);
      formatBuffer.append(CuramConst.gkSpace);
    }

    // Address Line 2
    if (addressLineList.dtls.item(l).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(l).addressString.length()
          + CuramConst.gkSpace.length());

      formatBuffer.append(addressLineList.dtls.item(l).addressString);
    }

    // Remove trailing space character (if one exists)
    final int sbLength = formatBuffer.length();
    final Integer indexTrailingSpace = new Integer(sbLength - 1);
    final Integer checkLastSpaceIndex = new Integer(
      formatBuffer.lastIndexOf(CuramConst.gkSpace));

    // remove trailing space character
    if (indexTrailingSpace.equals(checkLastSpaceIndex)) {
      formatBuffer.delete(checkLastSpaceIndex.intValue(), sbLength);
    }

    // set j to point to the next address line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_6;
    return j;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a formatted South Korean address string which is
   * typically displayed over two or more lines of text for the user. This is
   * in contrast to the short format which is always displayed as one line of
   * text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getKRLongFormat(AddressLineList addressLineList,
    final StringBuffer formatBuffer) throws AppException,
      InformationalException {

    int i;
    int j;

    // First line - Postal Code and City
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_2;

    // Postal code
    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
    }

    // City
    if (addressLineList.dtls.item(j).addressString.length() > 0) {

      // Handle formatting when no POSTCODE element is set
      if (addressLineList.dtls.item(i).addressString.length() == 0) {
        formatBuffer.ensureCapacity(
          formatBuffer.capacity()
            + addressLineList.dtls.item(j).addressString.length());

        formatBuffer.append(addressLineList.dtls.item(j).addressString);
      } else {
        formatBuffer.ensureCapacity(
          formatBuffer.capacity()
            + addressLineList.dtls.item(j).addressString.length()
            + CuramConst.gkComma.length() + CuramConst.gkSpace.length());

        formatBuffer.append(CuramConst.gkComma);
        formatBuffer.append(CuramConst.gkSpace);
        formatBuffer.append(addressLineList.dtls.item(j).addressString);
      }
    }

    // Second Line - Address Line 1
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_3;
    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      final String addressUnavailable = BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(
        TransactionInfo.getProgramLocale());

      if (addressLineList.dtls.item(i).addressString.equalsIgnoreCase(
        addressUnavailable)) {
        formatBuffer.ensureCapacity(
          addressLineList.dtls.item(i).addressString.length());

        formatBuffer.append(addressLineList.dtls.item(i).addressString);
      } else {
        formatBuffer.ensureCapacity(
          addressLineList.dtls.item(i).addressString.length()
            + CuramConst.gkNewLine.length());

        formatBuffer.append(CuramConst.gkNewLine);
        formatBuffer.append(addressLineList.dtls.item(i).addressString);
      }
    }

    // Third Line - Address Line 2
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_4;
    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(CuramConst.gkNewLine);
      formatBuffer.append(addressLineList.dtls.item(i).addressString);
    }

    // set j to point to the next address line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_5;
    return j;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a formatted Traditional Chinese address string which is
   * typically displayed over two or more lines of text for the user. This is in
   * contrast to the short format which is always displayed as one line of text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getTWLongFormat(AddressLineList addressLineList,
    final StringBuffer formatBuffer) {

    int i;
    int j;

    // First line - Postal Code has it's own address line
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;

    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    // Second line - Merge City and District details
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_2;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_3;

    if (addressLineList.dtls.item(i).addressString.length() > 0
      && addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkComma.length() + CuramConst.gkSpace.length()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkComma);
      formatBuffer.append(CuramConst.gkSpace);
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    if (addressLineList.dtls.item(i).addressString.length() > 0
      && addressLineList.dtls.item(j).addressString.length() == 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    if (addressLineList.dtls.item(i).addressString.length() == 0
      && addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    // Third line - Merge Address Line 1 and Address Line 2 details
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_4;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_5;

    if (addressLineList.dtls.item(i).addressString.length() > 0
      && addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkComma.length() + CuramConst.gkSpace.length()
          + addressLineList.dtls.item(j).addressString.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkComma);
      formatBuffer.append(CuramConst.gkSpace);
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
    }

    if (addressLineList.dtls.item(i).addressString.length() > 0
      && addressLineList.dtls.item(j).addressString.length() == 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
    }

    if (addressLineList.dtls.item(i).addressString.length() == 0
      && addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length());

      formatBuffer.append(addressLineList.dtls.item(j).addressString);
    }

    // set j to point to the next address line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_6;
    return j;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a formatted Canadian CIVIC address string which is
   * typically displayed over two or more lines of text for the user. This is in
   * contrast to the short format which is always displayed as one line of text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getCACIVICLongFormat(
    final OtherAddressData addressDataString,
    AddressLineList addressLineList, final StringBuffer formatBuffer)
    throws AppException, InformationalException {

    // Address manipulation variables
    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();
    final AddressMap addressMap = new AddressMap();
    AddressMapList addressMapList;
    ElementDetails elementDetails;
    final AddressElementStruct addressLineStruct = new AddressElementStruct();
    int i;
    int k;
    int j;

    // Merge lines in CA Civic address format for display

    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;

    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    //
    // Merge second line details together
    //
    // convert address data string into <name><value> pairs vector
    addressMapList = addressDataObj.parseDataToMap(addressDataString);

    addressMap.name = ADDRESSELEMENTTYPE.UNIT_NUMBER;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      addressLineStruct.addressElementString = elementDetails.elementValue;
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NUMBER;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (addressLineStruct.addressElementString.length() > CuramConst.gkZero) {
        addressLineStruct.addressElementString += CuramConst.gkDash;
      }
      addressLineStruct.addressElementString += elementDetails.elementValue;
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NUMBER_SUFFIX;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (addressLineStruct.addressElementString.length() > CuramConst.gkZero) {
        addressLineStruct.addressElementString += CuramConst.gkSpace;
      }
      addressLineStruct.addressElementString += CodeTable.getOneItem(
        STREETNUMBERSUFFIXTYPE.TABLENAME, elementDetails.elementValue);
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_NAME;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (addressLineStruct.addressElementString.length() > CuramConst.gkZero) {
        addressLineStruct.addressElementString += CuramConst.gkSpace;
      }
      addressLineStruct.addressElementString += elementDetails.elementValue;
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_TYPE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (!elementDetails.elementValue.equals(STREETTYPE.NOT_AVAILABLE)) {
        if (addressLineStruct.addressElementString.length() > CuramConst.gkZero) {
          addressLineStruct.addressElementString += CuramConst.gkSpace;
        }
        addressLineStruct.addressElementString += CodeTable.getOneItem(
          STREETTYPE.TABLENAME, elementDetails.elementValue);
      }
    }

    addressMap.name = ADDRESSELEMENTTYPE.STREET_DIRECTION;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementFound && !elementDetails.elementValue.isEmpty()) {
      if (addressLineStruct.addressElementString.length() > CuramConst.gkZero) {
        addressLineStruct.addressElementString += CuramConst.gkSpace;
      }
      addressLineStruct.addressElementString += elementDetails.elementValue;
    }

    formatBuffer.append(addressLineStruct.addressElementString);
    formatBuffer.append(CuramConst.gkNewLine);

    //
    // Merge third line
    //
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_8;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_9;
    k = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_10;

    if (addressLineList.dtls.item(i).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkSpace);
    }

    if (addressLineList.dtls.item(j).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkSpace.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkSpace);
    }

    if (addressLineList.dtls.item(k).addressString.length() > 0) {

      formatBuffer.ensureCapacity(
        formatBuffer.capacity()
          + addressLineList.dtls.item(k).addressString.length());
      formatBuffer.append(addressLineList.dtls.item(k).addressString);
    }

    // set j to point to the next address line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_11;
    // END, CR00285272
    return j;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a formatted German address string which is typically
   * displayed over two or more lines of text for the user. This is in contrast
   * to the short format which is always displayed as one line of text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getDELongFormat(AddressLineList addressLineList,
    final StringBuffer formatBuffer) {

    int i;
    int j;

    // Merge lines in DE address format for display

    //
    // Merge lines 1 and 2
    //
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_2;

    if (addressLineList.dtls.item(i).addressString.length() == 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    } else {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()

          + CuramConst.gkSpace.length()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkSpace);
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    // Address Line 3 appears as individual line so add to buffer as
    // separate line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_3;

    if (addressLineList.dtls.item(j).addressString.length() > CuramConst.gkZero) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    // Address Line 4 appears as individual line so add to buffer as
    // separate line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_4;

    if (addressLineList.dtls.item(j).addressString.length() > CuramConst.gkZero) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    //
    // Merge lines 5 and 6
    //
    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_5;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_6;

    if (addressLineList.dtls.item(i).addressString.length() == 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      // BEGIN, CR00332652, PB
      formatBuffer.append(CuramConst.gkNewLine);
      // END, CR00332652
    } else {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkSpace.length()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkSpace);
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      // BEGIN, CR00332652, PB
      formatBuffer.append(CuramConst.gkNewLine);
      // END, CR00332652
    }

    // set j to point to the next address line
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_7;
    // END, CR00219204
    return j;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a formatted American address string which is typically
   * displayed over two or more lines of text for the user. This is in contrast
   * to the short format which is always displayed as one line of text.
   *
   * @param addressDataString
   * contains address data string.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected int getUSLongFormat(AddressLineList addressLineList,
    final StringBuffer formatBuffer) {

    int i;
    int k;
    int j;

    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_1;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_2;

    if (addressLineList.dtls.item(i).addressString.length() == 0) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()

          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    } else {

      // BEGIN, CR00307123, AKr
      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkComma.length() + CuramConst.gkSpace.length()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());

      // BEGIN, CR00272990, KRK

      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkComma);
      formatBuffer.append(CuramConst.gkSpace);
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      // END, CR00272990
      // END, CR00307123

      formatBuffer.append(CuramConst.gkNewLine);
    }

    // BEGIN, CR00272990, KRK
    // Address Line 3 appears as individual line so add to buffer as
    // separate line.
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_3;

    if (addressLineList.dtls.item(j).addressString.length() > CuramConst.gkZero) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkNewLine.length());
      formatBuffer.append(addressLineList.dtls.item(j).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    // BEGIN, CR00314190, AKr

    i = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_4;
    j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_5;
    k = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_6;

    boolean prevElementEmpty = true;

    if (!(CuramConst.gkZero
      == addressLineList.dtls.item(i).addressString.length())) {

      formatBuffer.ensureCapacity(
        addressLineList.dtls.item(i).addressString.length()
          + CuramConst.gkSpace.length());
      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      prevElementEmpty = false;
    }

    if (!(CuramConst.gkZero
      == addressLineList.dtls.item(j).addressString.length())) {

      if (prevElementEmpty) {

        formatBuffer.ensureCapacity(
          addressLineList.dtls.item(j).addressString.length()
            + CuramConst.gkSpace.length());

        formatBuffer.append(addressLineList.dtls.item(j).addressString);
      } else {

        formatBuffer.ensureCapacity(
          CuramConst.gkComma.length() + CuramConst.gkSpace.length()
          + addressLineList.dtls.item(j).addressString.length()
          + CuramConst.gkSpace.length());
        formatBuffer.append(
          CuramConst.gkComma + CuramConst.gkSpace
          + addressLineList.dtls.item(j).addressString);
      }
      prevElementEmpty = false;

    }

    if (!(CuramConst.gkZero
      == addressLineList.dtls.item(k).addressString.length())) {

      if (prevElementEmpty) {

        formatBuffer.ensureCapacity(
          addressLineList.dtls.item(k).addressString.length()
            + CuramConst.gkSpace.length());
        formatBuffer.append(addressLineList.dtls.item(k).addressString);
      } else {

        formatBuffer.ensureCapacity(
          CuramConst.gkComma.length() + CuramConst.gkSpace.length()

          + addressLineList.dtls.item(k).addressString.length()
          + CuramConst.gkSpace.length());
        formatBuffer.append(
          CuramConst.gkComma + CuramConst.gkSpace
          + addressLineList.dtls.item(k).addressString);
      }
      prevElementEmpty = false;

    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_USADDRESSWITHCOUNTY)) {

      final int l = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_7;

      // BEGIN, CR00314636, AKr

      if (addressLineList.dtls.size() >= 7) {

        if (!(CuramConst.gkZero
          == addressLineList.dtls.item(l).addressString.length())) {

          if (prevElementEmpty) {

            formatBuffer.ensureCapacity(
              addressLineList.dtls.item(l).addressString.length()
                + CuramConst.gkSpace.length());
            formatBuffer.append(addressLineList.dtls.item(l).addressString);
          } else {

            formatBuffer.ensureCapacity(
              CuramConst.gkComma.length() + CuramConst.gkSpace.length()
              + addressLineList.dtls.item(l).addressString.length()
              + CuramConst.gkSpace.length());
            formatBuffer.append(
              CuramConst.gkComma + CuramConst.gkSpace
              + addressLineList.dtls.item(l).addressString);
          }
        }
      }
      // END, CR00314636
      j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_8;
    } else {
      j = AddressUtil.AddressDataIndex.ADDRESS_DATA_LINE_7;
    }
    return j;
  }

  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid JP format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateJPAddress(AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.JP;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    // 1. Validate that LINE1 & LINE2 cannot both be empty
    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    // If LINE1 is empty, ensure LINE2 is not also
    if (elementDetails.elementValue.length() == 0) {
      final AddressMap addressMapLINE2 = new AddressMap();
      ElementDetails elementDetailsLINE2;

      addressMapLINE2.name = ADDRESSELEMENTTYPE.LINE2;
      elementDetailsLINE2 = addressDataObj.findElement(addressMapList,
        addressMapLINE2);

      if (elementDetailsLINE2.elementValue.length() == 0) {
        final AppException e = new AppException(
          BPOADDRESS.ERR_ADDRESS_XFV_ADD1_AND_ADD2_EMPTY);

        e.arg(kAddressFirstLine);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
      }
    }

    // 2. Validate postal code format
    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() != 0
      && !isValidSevenDigitDashPostalCode(elementDetails.elementValue.trim())) {
      final AppException excp = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_POSTAL_CODE_FORMAT_XXX_XXXX);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        excp, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid KR format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateKRAddress(AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.KR;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    // 1. validate that LINE1 & LINE2 cannot both be empty
    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    // If LINE1 is empty, ensure LINE2 is not also
    if (elementDetails.elementValue.length() == 0) {
      final AddressMap addressMapLINE2 = new AddressMap();
      ElementDetails elementDetailsLINE2;

      addressMapLINE2.name = ADDRESSELEMENTTYPE.LINE2;
      elementDetailsLINE2 = addressDataObj.findElement(addressMapList,
        addressMapLINE2);

      if (elementDetailsLINE2.elementValue.length() == 0) {
        final AppException e = new AppException(
          BPOADDRESS.ERR_ADDRESS_XFV_ADD1_AND_ADD2_EMPTY);

        e.arg(kAddressFirstLine);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
      }
    }

    // 2. Validate postal code format
    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() != 0
      && !isValidSixDigitDashPostalCode(elementDetails.elementValue.trim())) {
      final AppException excp = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_POSTAL_CODE_FORMAT_XXX_XXX);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        excp, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the Taiwan
   * (ZH_TW) layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsTW(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMapList storeAddressMapList = new AddressMapList();

    storeAddressMapList.assign(addressMapList);

    // LINE1, LINE2 and CITY elements are common
    storeElementsCommon(storeAddressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.DISTRICT;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the Chinese
   * (ZH_CN) layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsCN(final AddressMapList addressMapList,
    final AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMapList storeAddressMapList = new AddressMapList();

    storeAddressMapList.assign(addressMapList);

    // LINE1, LINE2 and CITY elements are common
    storeElementsCommon(storeAddressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.PROVINCE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.DISTRICT;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the Japanese
   * (JP) layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsJP(AddressMapList addressMapList,
    AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMapList storeAddressMapList = new AddressMapList();

    storeAddressMapList.assign(addressMapList);

    // LINE1, LINE2 and CITY elements are common
    storeElementsCommon(storeAddressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);

    addressMap.name = ADDRESSELEMENTTYPE.PROVINCE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Creates address elements from the address data provided for the South
   * Korean (KR) layout.
   *
   * @param addressMapList
   * The list of the address map
   * @param addressElementDtls
   * The details of the address elements
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  protected void storeElementsKR(AddressMapList addressMapList,
    AddressElementDtls addressElementDtls) throws AppException,
      InformationalException {

    final AddressMap addressMap = new AddressMap();

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMapList storeAddressMapList = new AddressMapList();

    storeAddressMapList.assign(addressMapList);

    // LINE1, LINE2 and CITY elements are common
    storeElementsCommon(storeAddressMapList, addressElementDtls);

    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    storeElement(storeAddressMapList, addressElementDtls, addressMap);
  }

  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid ZH_TW format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateTWAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.TW;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    // 1. Validate that LINE1 & LINE2 cannot both be empty
    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    // If LINE1 is empty, ensure LINE2 is not also
    if (elementDetails.elementValue.length() == 0) {
      final AddressMap addressMapLINE2 = new AddressMap();
      ElementDetails elementDetailsLINE2;

      addressMapLINE2.name = ADDRESSELEMENTTYPE.LINE2;
      elementDetailsLINE2 = addressDataObj.findElement(addressMapList,
        addressMapLINE2);

      if (elementDetailsLINE2.elementValue.length() == 0) {
        final AppException e = new AppException(
          BPOADDRESS.ERR_ADDRESS_XFV_ADD1_AND_ADD2_EMPTY);

        e.arg(kAddressFirstLine);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
      }
    }

    // 2. Validate postal code format for Traditional Chinese
    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() != 0
      && !isValidFiveDigitPostalCode(elementDetails.elementValue.trim())) {
      final AppException excp = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_POSTAL_CODE_FORMAT_XXXXX);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        excp, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Checks that the specified address details are in a valid CN format.
   *
   * @param addressMapList
   * list of address maps
   */
  @Override
  @Deprecated
  protected void validateCNAddress(final AddressMapList addressMapList)
    throws AppException, InformationalException {

    // Layout key and address tag details
    final LayoutKey layoutKey = new LayoutKey();
    AddressTagDetails addressTagDetails;

    final curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory.newInstance();

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    layoutKey.addressLayoutType = ADDRESSLAYOUTTYPE.CN;
    addressTagDetails = getAddressTagsForLayout(layoutKey);

    if (addressTagDetails.addressTags.length() > 0) {
      addressDataObj.validateTags(addressMapList, addressTagDetails);
    }

    // 1. Validate that LINE1 & LINE2 cannot both be empty
    addressMap.name = ADDRESSELEMENTTYPE.LINE1;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    // If LINE1 is empty, ensure LINE2 is not also
    if (elementDetails.elementValue.length() == 0) {
      final AddressMap addressMapLINE2 = new AddressMap();
      ElementDetails elementDetailsLINE2;

      addressMapLINE2.name = ADDRESSELEMENTTYPE.LINE2;
      elementDetailsLINE2 = addressDataObj.findElement(addressMapList,
        addressMapLINE2);

      if (elementDetailsLINE2.elementValue.length() == 0) {
        final AppException e = new AppException(
          BPOADDRESS.ERR_ADDRESS_XFV_ADD1_AND_ADD2_EMPTY);

        e.arg(kAddressFirstLine);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
      }
    }

    // 2. Validate postal code format for Taiwan
    addressMap.name = ADDRESSELEMENTTYPE.POSTCODE;
    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() != 0
      && !isValidSixDigitPostalCode(elementDetails.elementValue.trim())) {
      final AppException excp = new AppException(
        BPOADDRESS.ERR_ADDRESS_FV_POSTAL_CODE_FORMAT_XXXXXX);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        excp, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Ensures the post code is in the format NNNNN example: 34234.
   *
   * @param postCode
   * Postal Code
   *
   * @return true if postal code matches pattern
   */
  @Deprecated
  protected boolean isValidFiveDigitPostalCode(final String postCode) {

    // Five digit postal code regular expression.
    final RegularExpression regExp = new RegularExpression(
      CuramConst.gkFiveDigitPostalFormat);

    return regExp.matches(postCode);
  }

  // ___________________________________________________________________________
  /**
   * Ensures the post code is in the format NNNNNN example: 342345.
   *
   * @param postCode
   * Postal Code
   *
   * @return true if postal code matches pattern
   */
  @Deprecated
  protected boolean isValidSixDigitPostalCode(final String postCode) {

    // Six digit postal code regular expression.
    final RegularExpression regExp = new RegularExpression(
      CuramConst.gkSixDigitPostalFormat);

    return regExp.matches(postCode);
  }

  // ___________________________________________________________________________
  /**
   * Ensures the post code is in the format NNN-NNNN example: 342-3456.
   *
   * @param postCode
   * Postal Code
   *
   * @return true if postal code matches pattern
   */
  @Deprecated
  protected boolean isValidSevenDigitDashPostalCode(final String postCode) {

    // Seven digit with a dash postal code regular expression.
    final RegularExpression regExp = new RegularExpression(
      CuramConst.gkSevenDigitDashPostalFormat);

    return regExp.matches(postCode);
  }

  // ___________________________________________________________________________
  /**
   * Ensures the post code is in the format NNN-NNN example: 342-457.
   *
   * @param postCode
   * Postal Code
   *
   * @return true if postal code matches pattern
   */
  @Deprecated
  protected boolean isValidSixDigitDashPostalCode(final String postCode) {

    // Six digit with a dash postal code regular expression.
    final RegularExpression regExp = new RegularExpression(
      CuramConst.gkSixDigitDashPostalFormat);

    return regExp.matches(postCode);
  }
  // END, CR00345882
}
