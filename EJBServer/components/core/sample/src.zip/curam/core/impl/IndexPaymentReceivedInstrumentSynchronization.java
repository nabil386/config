/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.PAYMENTRECEIVEDINSTRUMENT;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.PaymentReceivedInstrumentDtls;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class creates the search query and performs the search for
 * Payment Received lucene index search
 */
public abstract class IndexPaymentReceivedInstrumentSynchronization extends curam.core.base.IndexPaymentReceivedInstrumentSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment received instrument entity
   * insert operation
   *
   * @param paymentReceivedInstrumentDtls The payment instrument received
   * instrument details
   */
  @Override
  public void insert(
    final PaymentReceivedInstrumentDtls paymentReceivedInstrumentDtls)
    throws AppException, InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = PAYMENTRECEIVEDINSTRUMENT.INSERT_PAYMENTRECEIVEDINSTRUMENT.eventClass;
    synchronizeEventsDetails.eventKey.eventType = PAYMENTRECEIVEDINSTRUMENT.INSERT_PAYMENTRECEIVEDINSTRUMENT.eventType;
    synchronizeEventsDetails.primaryEventData = paymentReceivedInstrumentDtls.pmtRecInstrumentID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }
}
