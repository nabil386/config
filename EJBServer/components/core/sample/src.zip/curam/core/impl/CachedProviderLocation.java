/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.ProviderLocationDtls;
import curam.core.struct.ProviderLocationKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedProviderLocation
 */
public abstract class CachedProviderLocation extends curam.core.base.CachedProviderLocation {

  protected static ThreadLocal cachedProviderLocationDtls = new ThreadLocal();

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // __________________________________________________________________________
  // static to hold the cachingEnabled environment variable
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);
  }

  // ___________________________________________________________________________
  /**
   * class to hold the cached ProviderLocationDtls
   */
  protected class ProviderLocationDtlsCacheRecord {

    int transactionID = 0;

    ProviderLocationDtls providerLocationDtls = new ProviderLocationDtls();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ProviderLocationDtls read(ProviderLocationKey key)
    throws AppException, InformationalException {

    // return provider Location Dtls variable
    ProviderLocationDtls providerLocationDtlsReturn = new ProviderLocationDtls();

    final TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    ProviderLocationDtlsCacheRecord providerLocationDtlsCacheRecord = (ProviderLocationDtlsCacheRecord) cachedProviderLocationDtls.get();

    boolean reloadCache = true;

    if (providerLocationDtlsCacheRecord != null) {

      // If this is a batch transaction or deferred processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch)
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
          && providerLocationDtlsCacheRecord.providerLocationDtls != null
          && providerLocationDtlsCacheRecord.providerLocationDtls.providerLocationID
            == key.providerLocationID) {

        providerLocationDtlsReturn.assign(
          providerLocationDtlsCacheRecord.providerLocationDtls);
        reloadCache = false;
      }

      // if this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (!reloadCache && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
        != providerLocationDtlsCacheRecord.transactionID) {

        reloadCache = true;
      }
    }

    if (reloadCache) {

      // Otherwise we need to read the ProviderLocation data
      final curam.core.intf.ProviderLocation providerLocationObj = curam.core.fact.ProviderLocationFactory.newInstance();

      // assign to local providerLocationDtlsReturn variable
      providerLocationDtlsReturn = providerLocationObj.read(key);

      // If this was a cache miss (and caching is enabled), refresh the cache
      if (transactionType.equals(TransactionType.kBatch)
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled) {

        providerLocationDtlsCacheRecord = new ProviderLocationDtlsCacheRecord();

        // assign to static ProviderLocationDtls
        providerLocationDtlsCacheRecord.providerLocationDtls.assign(
          providerLocationDtlsReturn);
        providerLocationDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

        cachedProviderLocationDtls.set(providerLocationDtlsCacheRecord);
      }
    }
    return providerLocationDtlsReturn;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void clearCache() throws AppException, InformationalException {

    cachedProviderLocationDtls.set(null);
  }

}
