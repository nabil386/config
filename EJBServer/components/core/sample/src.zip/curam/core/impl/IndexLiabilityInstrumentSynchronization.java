/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.LIABILITYINSTRUMENT;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.LIAmountPeriodEffectDate;
import curam.core.struct.LiabilityInstrumentDtls;
import curam.core.struct.LiabilityInstrumentKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Raises events to create/modify indexes as a result of all LiabilityInstrument
 * entity updates.
 *
 * These indexes can then be used with the Lucene Search engine.
 *
 */
public abstract class IndexLiabilityInstrumentSynchronization extends curam.core.base.IndexLiabilityInstrumentSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the liability instrument entity insert
   * operation
   *
   * @param liabilityInstrumentDtls - Liability Instrument entity details
   * struct.
   */
  @Override
  public void insert(final LiabilityInstrumentDtls liabilityInstrumentDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00091575, CPD
    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = LIABILITYINSTRUMENT.INSERT_LIABILITYISSUED.eventClass;
    synchronizeEventsDetails.eventKey.eventType = LIABILITYINSTRUMENT.INSERT_LIABILITYISSUED.eventType;
    synchronizeEventsDetails.primaryEventData = liabilityInstrumentDtls.liabInstrumentID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091575

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the liability instrument entity modify
   * amount period effect date operation
   *
   * @param liabilityInstrumentKey The liability instrument key
   * @param liAmountPeriodEffectDate The liability instrument amount period
   * effect date
   */
  @Override
  public void modifyAmountPeriodEffectDate(
    final LiabilityInstrumentKey liabilityInstrumentKey,
    final LIAmountPeriodEffectDate liAmountPeriodEffectDate)
    throws AppException, InformationalException {

    // BEGIN, CR00091575, CPD
    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = LIABILITYINSTRUMENT.MODIFY_LIABILITYISSUED.eventClass;
    synchronizeEventsDetails.eventKey.eventType = LIABILITYINSTRUMENT.MODIFY_LIABILITYISSUED.eventType;
    synchronizeEventsDetails.primaryEventData = liabilityInstrumentKey.liabInstrumentID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091575
  }

}
