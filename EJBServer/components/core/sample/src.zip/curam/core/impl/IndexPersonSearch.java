/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.codetable.TERMTYPE;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.PhoneticEncoderFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.fact.SearchServiceFactory;
import curam.core.impl.util.CuramDocToResultStruct;
import curam.core.intf.ConcernRole;
import curam.core.intf.PhoneticEncoder;
import curam.core.intf.ProspectPerson;
import curam.core.sl.fact.IndexParticipantSearchFactory;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.infrastructure.impl.IndexSearchConst;
import curam.core.sl.intf.IndexParticipantSearch;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.sl.struct.TextFieldDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.core.struct.CuramDocument;
import curam.core.struct.CuramField;
import curam.core.struct.CuramQuery;
import curam.core.struct.CuramTerm;
import curam.core.struct.DisableLinkIndicatorDetails;
import curam.core.struct.PersonSearchDetails;
import curam.core.struct.PersonSearchDtls;
import curam.core.struct.PersonSearchDtls1;
import curam.core.struct.PersonSearchKey;
import curam.core.struct.PersonSearchKey1;
import curam.core.struct.PersonSearchResult;
import curam.core.struct.PersonSearchResult1;
import curam.core.struct.PhoneticEncoderDetails;
import curam.core.struct.PhoneticEncoderKey;
import curam.core.struct.ProspectPersonDtls;
import curam.core.struct.ProspectPersonKey;
import curam.core.struct.SearchServerResults;
import curam.core.struct.SearchServiceKey;
import curam.message.BPOPARTICIPANTSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.transaction.TransactionInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * This class creates the search query and performs the search for
 * Person lucene index search
 */
public abstract class IndexPersonSearch extends curam.core.base.IndexPersonSearch {

  // dictionary used for matching the entity attribute names
  // with the return struct name for output display
  protected final static HashMap<String, String> dictionary = new HashMap<String, String>();
  // BEGIN, CR00085608 SK
  static {
    dictionary.put(IndexSearchConst.kSex, IndexSearchConst.kGender);
    dictionary.put(IndexSearchConst.kForename, IndexSearchConst.kFirstForename);
    dictionary.put(IndexSearchConst.kAddress, IndexSearchConst.kAddressLine1);
    dictionary.put(IndexSearchConst.kReferenceNumber,
      IndexSearchConst.kPrimaryAlternateID);
    dictionary.put(IndexSearchConst.kPersonFullName, IndexSearchConst.kFullname);
    dictionary.put(IndexSearchConst.kBirthSurname,
      IndexSearchConst.kPersonBirthName);
    dictionary.put(IndexSearchConst.kMotherSurname,
      IndexSearchConst.kMotherBirthSurname);
  }

  // END, CR00085608 SK

  // BEGIN, CR00222456 ZV
  protected final static HashMap<String, String> dictionary1 = new HashMap<String, String>();
  static {
    dictionary1.put(IndexSearchConst.kAddress, IndexSearchConst.kAddressData);
    dictionary1.put(IndexSearchConst.kPrimaryConcernRoleName,
      IndexSearchConst.kConcernRoleName);
    dictionary1.put(IndexSearchConst.kConcernRoleName,
      IndexSearchConst.kFullName);
  }

  // END, CR00222456

  // ___________________________________________________________________________
  /**
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} This method has
   * been deprecated to introduce new person search
   * enhancements.
   *
   * Performs an index search for persons using the specified search
   * criteria, or performs a database read if the alternate ID is specified.
   */
  @Override
  @Deprecated
  public PersonSearchResult search(final PersonSearchKey key)
    throws AppException, InformationalException {

    final PersonSearchResult result = new PersonSearchResult();
    final CuramQuery curamQuery = new CuramQuery();
    final LuceneHelper luceneHelper = new LuceneHelper();

    // add the terms to the curam query if they exist
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kFirstForename,
      key.forename, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kSurname, key.surname,
      true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createDateTerm(IndexSearchConst.kDateOfBirth,
      key.dateOfBirth),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kAddressLine1,
      key.address, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kCity, key.city, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kGender, key.sex, false),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kPersonBirthName,
      key.birthSurname, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kMotherBirthSurname,
      key.motherSurname, true),
      curamQuery);
    addTermIfExists(
      luceneHelper.createStandardTerm(IndexSearchConst.kPrimaryAlternateID,
      key.referenceNumber, true),
      curamQuery);

    final SearchServiceKey searchServiceKey = new SearchServiceKey();

    searchServiceKey.searchServiceId = IndexSearchConst.kPersonSearch;
    // BEGIN, CR00112556, CW
    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;
    // END, CR00112556

    // add field data to the search query
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kPrimaryAlternateID));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kFirstForename));
    curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kSurname));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kDateOfBirth));
    curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kGender));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kAddressLine1));
    curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kCity));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kPersonBirthName));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kMotherBirthSurname));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kAddressData));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kSensitivity));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kPhoneticEncoding));
    curamQuery.fields.dtls.addRef(createResultField(IndexSearchConst.kFullName));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kConcernRoleID));
    // BEGIN, CR00104332, CW
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kStatusCode));
    curamQuery.fields.dtls.addRef(
      createResultField(IndexSearchConst.kOriginalConcernRoleID));
    // END, CR00104332

    final SearchServerResults searchResults = SearchServiceConnector.search(
      curamQuery);

    // For each field in the CuramDocument, the method attempts
    // to find an attribute in the struct of the same name and data type
    // A dictionary is passed to resolve attribute names that do not match
    // A struct containing all mapped values is returned.
    for (int i = 0; i < searchResults.documents.dtls.size(); i++) {
      PersonSearchDtls personSearchDtls = new PersonSearchDtls();
      final CuramDocument document = searchResults.documents.dtls.item(i);

      personSearchDtls = (PersonSearchDtls) CuramDocToResultStruct.convert(
        document, personSearchDtls, dictionary);

      // BEGIN, CR00104332, CW
      if (personSearchDtls.originalConcernRoleID != 0) {

        // This record has a duplicate participant

        // Read the duplicate status
        final CuramField field = findField(document,
          IndexSearchConst.kStatusCode);

        // Set the duplicate flag if the duplicate status is 'marked'
        personSearchDtls.duplicateInd = field.value.equalsIgnoreCase(
          curam.codetable.DUPLICATESTATUS.MARKED);
      }
      // END, CR00104332
      restrictResults(personSearchDtls);

      // BEGIN, CR00219873, ELG
      if (personSearchDtls.referenceNumber != null) {
        result.details.dtls.addRef(personSearchDtls);
      } else {
        result.result.numRecordsFound = result.result.numRecordsFound - 1;
      }
      // END, CR00219873

    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Adds a term to the curam query if the term exists
   *
   * @param term the curam term type
   * @param curamQuery the curam query
   */
  // BEGIN, CR00198672, VK
  protected void addTermIfExists(final CuramTerm term,
    final CuramQuery curamQuery) {

    // END, CR00198672
    if (term.termType.equals(TERMTYPE.STANDARD)) {
      if (term.stdTerm.value.length() > 0) {
        curamQuery.terms.dtls.addRef(term);
      }
    } else if (term.termType.equals(TERMTYPE.DATE)) {
      if (!term.dtTerm.value.isZero()) {
        curamQuery.terms.dtls.addRef(term);
      }
    }
  }

  // BEGIN, CR00104332, CW
  // ___________________________________________________________________________
  /**
   * Finds a field with the specified name in the document and returns it to
   * the caller.
   *
   * @param document The document containing the search results
   * @param field The name of the field
   *
   * @return The <code>CuramField</code> with the specified name
   */
  // BEGIN, CR00198672, VK
  protected CuramField findField(final CuramDocument document,
    final String field) {

    // END, CR00198672
    for (int i = 0; i < document.fields.dtls.size(); i++) {
      final CuramField current = document.fields.dtls.item(i);

      if (current.name.equals(field)) {
        return current;
      }
    }
    return null;
  }

  // END, CR00104332

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Creates a result field for the curam query
   *
   * @param field the field name
   *
   * @return CuramField the curam field
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link curam.core.impl.LuceneHelper#createResultField()}
   */
  // BEGIN, CR00198672, VK
  @Deprecated
  protected CuramField createResultField(final String field) {

    // END, CR00198672
    final LuceneHelper luceneHelper = new LuceneHelper();

    return luceneHelper.createResultField(field);
  }

  // END, CR00257963

  // BEGIN, CR00222456, ZV
  // ___________________________________________________________________________
  /**
   * Performs an index search for persons using the specified search criteria.
   *
   * @param key data on which the person search will be based
   *
   * @return The details of any records found
   */
  @Override
  public PersonSearchResult1 search1(PersonSearchKey1 key)
    throws AppException, InformationalException {

    // BEGIN, CR00257963, ZV
    final CuramQuery curamQuery = createSearchQuery(key);

    final SearchServerResults searchResults = executeQuery(curamQuery);

    final PersonSearchResult1 result = processSearchQueryResults(searchResults,
      key);

    // END, CR00257963

    return result;
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for person lucene index search for the specified search
   * criteria.
   *
   * @param key data on which the query will be based
   *
   * @return The Curam query for person lucene index search
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #createSearchQuery()}
   */
  @Deprecated
  public CuramQuery createQuery(PersonSearchKey1 key) throws AppException,
      InformationalException {

    return createSearchQuery(key);

  }

  // END, CR00257963

  // ___________________________________________________________________________
  /**
   * Executes a lucene index search query
   *
   * @param curamQuery Query to execute
   *
   * @return The lucene index search query results
   */
  protected SearchServerResults executeQuery(CuramQuery curamQuery)
    throws AppException, InformationalException {

    return SearchServiceConnector.search(curamQuery);
  }

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Method to process person search query results.
   *
   * @param searchServerResults Lucene index search query results
   * @param key data on which the search was based
   *
   * @return The details of any person records found
   *
   * @throws AppException
   * {@link BPOPARTICIPANTSEARCH#ERR_PARTICIPANTSEARCH_XRV_MAXIMUM} -
   * If search results exceeds participant search maximum value.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #processSearchQueryResults()}
   */
  @Deprecated
  public PersonSearchResult1 processQueryResults(
    SearchServerResults searchServerResults, PersonSearchKey1 key)
    throws AppException, InformationalException {

    return processSearchQueryResults(searchServerResults, key);

  }

  // END, CR00257963
  // END, CR00222456

  // BEGIN, CR00257963, ZV
  // ___________________________________________________________________________
  /**
   * Crates query for person lucene index search for the specified search
   * criteria.
   *
   * @param key data on which the query will be based
   *
   * @return The Curam query for person lucene index search
   */
  public static CuramQuery createSearchQuery(PersonSearchKey1 key)
    throws AppException, InformationalException {

    final CuramQuery curamQuery = new CuramQuery();
    final SearchServiceKey searchServiceKey = new SearchServiceKey();
    final LuceneHelper luceneHelper = new LuceneHelper();
    final IndexParticipantSearch indexParticipantSearchObj = IndexParticipantSearchFactory.newInstance();
    final TextFieldDetails textFieldDetails = new TextFieldDetails();

    searchServiceKey.searchServiceId = IndexSearchConst.kParticipantSearch;

    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

    // Add the fields which will be used to store the results to the query
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kPrimaryAlternateID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleName));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kAddressData));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kDateOfBirth));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kOriginalConcernRoleID));

    curamQuery.text = "(" + IndexSearchConst.kConcernRoleType
      + CuramConst.gkColon + CONCERNROLETYPE.PERSON;

    curamQuery.text += IndexSearchConst.kORString;
    curamQuery.text += IndexSearchConst.kConcernRoleType + CuramConst.gkColon
      + CONCERNROLETYPE.PROSPECTPERSON + ")";

    if (!key.dateOfBirth.isZero()) {
      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kDateOfBirth + CuramConst.gkColon
        + Locale.getFormattedDate(key.dateOfBirth, Locale.Date_ymd);
    }

    if (key.gender.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kGender + CuramConst.gkColon
        + key.gender;
    }

    if (key.birthSurname.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kPersonBirthName;
      textFieldDetails.fieldValue = key.birthSurname;
      // BEGIN, CR00338327, ZV
      if (key.birthSurname.length() > 1) {
        textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
      }
      // END, CR00338327
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }

    if (key.referenceNumber.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kAlternateIDList;
      // BEGIN, CR00379119, SS
      final ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
      final SearchCriteriaString referenceKeyvalue = new SearchCriteriaString();

      referenceKeyvalue.string = key.referenceNumber;
      textFieldDetails.fieldValue = participantSearchObj.formatReferenceFieldValue(referenceKeyvalue).fieldValue;
      // END, CR00379119
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }

    if (key.forename.length() > 0 || key.surname.length() > 0
      || key.addressDtls.addressLine1.length() > 0
      || key.addressDtls.addressLine2.length() > 0
      || key.addressDtls.city.length() > 0) {

      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
        + IndexSearchConst.kIndexFalseInd;

      if (key.forename.length() > 0 || key.surname.length() > 0) {

        curamQuery.fields.dtls.addRef(
          luceneHelper.createResultField(IndexSearchConst.kFullName));

        if (key.forename.length() > 0) {
          curamQuery.text += IndexSearchConst.kANDString;
          textFieldDetails.fieldName = IndexSearchConst.kFirstForename;
          textFieldDetails.fieldValue = key.forename;
          // BEGIN, CR00338327, ZV
          if (key.forename.length() > 1 || !key.surname.isEmpty()) {
            textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
          }
          // END, CR00338327

          curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
        }

        if (key.surname.length() > 0) {

          if (key.soundsLikeInd) {
            final PhoneticEncoder phoneticEncoderObj = PhoneticEncoderFactory.newInstance();

            final PhoneticEncoderKey phoneticEncoderKey = new PhoneticEncoderKey();
            PhoneticEncoderDetails phoneticEncoderDetails = new PhoneticEncoderDetails();

            phoneticEncoderKey.surname = key.surname.toUpperCase();
            phoneticEncoderDetails = phoneticEncoderObj.encode(
              phoneticEncoderKey);

            curamQuery.text += IndexSearchConst.kANDString;
            curamQuery.text += IndexSearchConst.kPhoneticEncoding
              + CuramConst.gkColon
              + phoneticEncoderDetails.phoneticEncodingCode;
          } else {

            curamQuery.text += IndexSearchConst.kANDString;
            textFieldDetails.fieldName = IndexSearchConst.kSurname;
            textFieldDetails.fieldValue = key.surname;
            // BEGIN, CR00338327, ZV
            if (key.surname.length() > 1) {
              textFieldDetails.fieldValue += CuramConst.gkWildcardSearch;
            }
            // END, CR00338327
            curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;

          }
        }
      }

      curamQuery.text += indexParticipantSearchObj.createQueryAddressSearch(key.addressDtls).statement;

    } else {
      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
        + IndexSearchConst.kIndexTrueInd;
    }

    return curamQuery;
  }

  // ___________________________________________________________________________
  /**
   * Method to process person search query results.
   *
   * @param searchServerResults Lucene index search query results
   * @param key data on which the search was based
   *
   * @return The details of any person records found
   *
   * @throws AppException
   * {@link BPOPARTICIPANTSEARCH#ERR_PARTICIPANTSEARCH_XRV_MAXIMUM} -
   * If search results exceeds participant search maximum value.
   */
  public static PersonSearchResult1 processSearchQueryResults(
    SearchServerResults searchServerResults, PersonSearchKey1 key)
    throws AppException, InformationalException {

    final PersonSearchResult1 result = new PersonSearchResult1();
    final List<Long> concernRoleIDList = new ArrayList<Long>();

    int searchMaximum = CuramConst.gkZero;

    if (Configuration.getIntProperty(EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM)
      != null) {
      searchMaximum = Configuration.getIntProperty(
        EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM);
    } else {
      searchMaximum = EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM_DEFAULT;
    }

    if (searchServerResults.documents.dtls.size() > searchMaximum) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        BPOPARTICIPANTSEARCH.ERR_PARTICIPANTSEARCH_XRV_MAXIMUM);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();

    } else {

      final DisableLinkIndicatorDetails disableLinkIndicatorDetails = new DisableLinkIndicatorDetails();

      disableLinkIndicatorDetails.disableLinkInd = key.disableLinkInd;

      // Convert the results into the result structure.
      for (int i = 0; i < searchServerResults.documents.dtls.size(); i++) {

        PersonSearchDtls1 personSearchDtls = new PersonSearchDtls1();

        final CuramDocument document = searchServerResults.documents.dtls.item(
          i);

        personSearchDtls = (PersonSearchDtls1) CuramDocToResultStruct.convert(
          document, personSearchDtls, dictionary1);

        if (personSearchDtls.originalConcernRoleID != CuramConst.gkZero) {
          final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
          final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

          concernRoleKey.concernRoleID = personSearchDtls.originalConcernRoleID;

          final ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
            concernRoleKey);

          personSearchDtls.originalConcernRoleName = concernRoleNameAndAlternateID.concernRoleName;
          personSearchDtls.originalPrimaryAlternateID = concernRoleNameAndAlternateID.primaryAlternateID;
        }

        // set alternate id to input key
        // this is to set correct alternate id in the case when
        // it does not match primary alternate id
        if (key.referenceNumber.length() > 0) {
          personSearchDtls.alternateID = key.referenceNumber;
        }

        final curam.core.intf.PersonSearch personSearchObj = curam.core.fact.PersonSearchFactory.newInstance();

        final PersonSearchDetails personSearchDetails = personSearchObj.processSearchDetails(
          personSearchDtls, disableLinkIndicatorDetails);

        // BEGIN, CR00362049, ZV
        if (personSearchDetails != null
          && !concernRoleIDList.contains(personSearchDetails.concernRoleID)) {
          // END, CR00362049

          // BEGIN, CR00256231, ZV
          boolean prospectRegisteredInd = false;

          if (personSearchDtls.concernRoleType.equals(
            CONCERNROLETYPE.PROSPECTPERSON)) {

            final ProspectPerson prospectPersonObj = ProspectPersonFactory.newInstance();
            final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

            prospectPersonKey.concernRoleID = personSearchDtls.concernRoleID;
            final ProspectPersonDtls prospectPersonDtls = prospectPersonObj.read(
              prospectPersonKey);

            prospectRegisteredInd = prospectPersonDtls.personConcernRoleID != 0;

          }

          if (!prospectRegisteredInd) {
            result.dtlsList.addRef(personSearchDetails);
            concernRoleIDList.add(personSearchDetails.concernRoleID);
          }
          // END, CR00256231
        }

      }
    }

    return result;
  }
  // END, CR00257963

}
