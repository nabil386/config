/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.InformationProviderFactory;
import curam.core.struct.InformationProviderDatabaseSearchKey;
import curam.core.struct.InformationProviderDtls;
import curam.core.struct.InformationProviderKey;
import curam.core.struct.ReadInformationProviderSummaryKey;
import curam.core.struct.SearchAllInformationProvidersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Information Provider Definition: A Concern whose only interaction with the
 * organization is in supplying information in relation to other Concerns.
 *
 */
public abstract class InformationProvider extends curam.core.base.InformationProvider {

  // __________________________________________________________________________
  /**
   * Sets up details for the read to ensure the correct details are always
   * returned
   *
   * @param key details for the read
   */
  @Override
  protected void prereadSummaryDetails(ReadInformationProviderSummaryKey key)
    throws AppException, InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // __________________________________________________________________________
  /**
   * Sets up details for the search to ensure the correct details are always
   * returned
   *
   * @param key details for the search
   */
  @Override
  protected void presearchAllInformationProviders(
    SearchAllInformationProvidersKey key) throws AppException,
      InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // __________________________________________________________________________
  /**
   * Sets up details for the search to ensure the correct details are always
   * returned
   *
   * @param key details for the search
   */
  @Override
  protected void presearchByNameOrAddress(
    InformationProviderDatabaseSearchKey key) throws AppException,
      InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchByNameOrAddress
   */
  @Override
  public curam.core.struct.InformationProviderSummaryDetailsList search(
    curam.core.struct.InformationProviderDatabaseSearchKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return InformationProviderFactory.newInstance().searchByNameOrAddress(key);
  }

  // _____________________________________________________________________________
  /**
   * Sets up details for the read to ensure the correct details are always
   * returned
   *
   * @param key details for the read
   */
  @Override
  protected void prereadSummaryDetailsByReferenceNumber(
    ReadInformationProviderSummaryKey key) throws AppException,
      InformationalException {

    key.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
    key.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;
  }

  // BEGIN, CR00076104, PMD
  // ___________________________________________________________________________
  /**
   * Called before the insert operation.
   *
   * @param details The details for the new information provider record
   */
  @Override
  protected void preinsert(InformationProviderDtls details)
    throws AppException, InformationalException {

    // Convert the information provider details to upper case
    convertDetailsToUpper(details);
  }

  // ___________________________________________________________________________
  /**
   * Called before the modification operation.
   *
   * @param key The key of the information provider being modified
   * @param details The new details for the information provider
   */
  @Override
  protected void premodify(InformationProviderKey key,
    InformationProviderDtls details) throws AppException,
      InformationalException {

    // Convert the information provider details to upper case
    convertDetailsToUpper(details);
  }

  // ___________________________________________________________________________
  /**
   * Method to convert the information provider details to upper case
   *
   * @param details the information provider details
   */
  @Override
  public void convertDetailsToUpper(InformationProviderDtls details)
    throws AppException, InformationalException {

    // Convert the name field to upper case
    details.upperName = details.name.toUpperCase();
  }
  // END, CR00076104
}
