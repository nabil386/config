/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.CaseHeaderFactory;
import curam.core.struct.CaseKey;
import curam.core.struct.DetermineCaseTypeDtls;
import curam.core.struct.DetermineCaseTypeKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class is used to determine the type of a case.
 *
 */
public abstract class DetermineCaseType extends curam.core.base.DetermineCaseType {

  // ___________________________________________________________________________
  /**
   * This method determines the type of a case given its caseID.
   *
   * @param key The ID of the case
   *
   * @return The type code for this case
   */
  @Override
  public DetermineCaseTypeDtls getCaseType(DetermineCaseTypeKey key)
    throws AppException, InformationalException {

    // determineCaseTypeDtls variable
    final DetermineCaseTypeDtls determineCaseTypeDtls = new DetermineCaseTypeDtls();

    // caseKey manipulation variable
    final CaseKey caseKey = new CaseKey();

    // read the caseID into manipulation variable
    caseKey.caseID = key.caseID;

    // read caseTypeCode from caseKey
    determineCaseTypeDtls.caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey).caseTypeCode;

    return determineCaseTypeDtls;
  }

}
