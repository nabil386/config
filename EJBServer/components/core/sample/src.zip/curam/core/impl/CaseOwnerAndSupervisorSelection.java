/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.ORGSTRUCTURESTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionHolderLinkFactory;
import curam.core.sl.entity.intf.OrganisationStructure;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.struct.ListOrganisationStructureKey;
import curam.core.sl.entity.struct.OrgStructureUserDateAndStatusKey;
import curam.core.sl.entity.struct.OrganisationStructureID;
import curam.core.sl.entity.struct.OrganisationStructureIDAndNameKey;
import curam.core.sl.entity.struct.OrganisationStructureIDList;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.core.sl.entity.struct.OrganisationUnitDtlsStruct1;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.OrganisationUnitNameList;
import curam.core.sl.entity.struct.PositionHolderLinkIndexStruct3;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.AdminConcernRoleRMDetailsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.GetCurrentOwnerKey;
import curam.core.struct.GetOwnerAndSupervisorForAutomaticResult;
import curam.core.struct.GetOwnerAndSupervisorForManualResult;
import curam.core.struct.GetOwnerAndSupervisorKey;
import curam.core.struct.MaintainAdminConcernRoleRMDtlsList;
import curam.core.struct.ManagerUserName;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserNameAndIDStruct;
import curam.core.struct.UsersKey;
import curam.message.BPOCASEUSERROLE;
import curam.message.BPOORGANISATIONSTRUCTURE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * Methods used to set case owner and supervisor on Case creation.
 */
public abstract class CaseOwnerAndSupervisorSelection extends curam.core.base.CaseOwnerAndSupervisorSelection {

  /**
   * Operation to return case owner and supervisor for manual case creation.
   *
   * @param key Key struct
   *
   * @return owner ID and supervisor ID
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GetOwnerAndSupervisorForManualResult getOwnerAndSupervisorForManual(
    GetOwnerAndSupervisorKey key) throws AppException, InformationalException {

    // output structure containing case owner ID and supervisor ID
    final GetOwnerAndSupervisorForManualResult getOwnerAndSupervisorForManualResult = new GetOwnerAndSupervisorForManualResult();

    // users entity, key and details
    final ManagerUserName managerUserName = new ManagerUserName();

    // administration concern role entity and details list
    final curam.core.intf.AdministrationConcernRole administrationConcernRoleObj = curam.core.fact.AdministrationConcernRoleFactory.newInstance();

    // key struct for getting case current owner
    final GetCurrentOwnerKey getCurrentOwnerKey = new GetCurrentOwnerKey();

    final OrganisationStructureIDAndNameKey organisationStructureIDAndNameKey = new OrganisationStructureIDAndNameKey();
    final ListOrganisationStructureKey listOrganisationStructureKey = new ListOrganisationStructureKey();
    // organization structure object
    final curam.core.sl.entity.intf.OrganisationStructure organisationStructureObj = curam.core.sl.entity.fact.OrganisationStructureFactory.newInstance();
    OrganisationStructureIDList organisationStructureIDList;

    // BEGIN, CR00208059, DJ
    OrganisationStructureID organisationStructureID = new OrganisationStructureID();
    final OrgStructureUserDateAndStatusKey orgStructureUserDateAndStatusKey = new OrgStructureUserDateAndStatusKey();
    RecordCount recordCount = new RecordCount();
    final CaseHeaderKey caseHeaderKey1 = new CaseHeaderKey();
    final CaseUserRole CaseUserRoleObj = CaseUserRoleFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    final OrganisationUnitName orgUnitName = new OrganisationUnitName();
    final PositionHolderLinkIndexStruct3 positionHolderLinkIndexStruct3 = new PositionHolderLinkIndexStruct3();
    final OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();
    final curam.core.sl.entity.intf.PositionHolderLink positionHolderLinkObj = PositionHolderLinkFactory.newInstance();
    final OrganisationStructure organisationStructure = OrganisationStructureFactory.newInstance();
    final OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final OrganisationUnitDtlsStruct1 organisationUnitDtlsStruct1 = new OrganisationUnitDtlsStruct1();
    // END, CR00208059

    // BEGIN, CR00060051, PMD
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // If there is a related case use the owner of that case.
    if (key.relatedCaseID != 0) {

      // Set the case header key to be the related case id
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.relatedCaseID;

      // Read case owner
      final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
        caseHeaderKey);

      // BEGIN, CR00208059, DJ
      caseHeaderKey1.caseID = key.caseID;
      CaseHeaderDtls caseHeaderDtls = CaseUserRoleObj.readCaseHeader(
        caseHeaderKey1);

      caseHeaderDtls = CaseUserRoleObj.readCaseHeader(caseHeaderKey1);
      caseHeaderKey.caseID = caseHeaderDtls.integratedCaseID;

      // Checks if the case owner of the related case is of type user and if so
      // it will check the case owner has active positions. If active positions
      // are there, it will set him as the case owner, else it will try to set
      // the supervisor of the related case as the case owner. But if the
      // supervisor, doesn't have active position or if no supervisor is there,
      // organization unit is set as the case owner. If the related case owner
      // is of other type, it will assign that object as the owner.

      if (ORGOBJECTTYPE.USER.equals(caseOwnerDetails.orgObjectType)) {
        orgStructureUserDateAndStatusKey.userName = caseOwnerDetails.userName;
        orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

        organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
          organisationStructureStatus);
        orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

        recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
          orgStructureUserDateAndStatusKey);

        // Check if the user has an active positions. If so assign him as the
        // case owner. Else, get the supervisor of the case.
        if (0 != recordCount.count) {
          caseOwnerDetails.userName = orgStructureUserDateAndStatusKey.userName;
          usersKey.userName = caseOwnerDetails.userName;
          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;

          caseOwnerDetails.userFullName = userAccessObj.getFullName(usersKey).fullname;
        } else {
          // Get the case supervisor who is assigned manually and if he is not
          // found get the dynamically assigned supervisor.
          organisationStructureIDAndNameKey.name = orgStructureUserDateAndStatusKey.userName;
          organisationStructureIDAndNameKey.organisationStructureID = organisationStructureID.organisationStructureID;
          organisationStructureIDAndNameKey.recordStatus = ORGSTRUCTURESTATUS.ACTIVE;
          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;

          caseOwnerDetails.userFullName = CaseUserRoleObj.readSupervisor(caseHeaderKey).fullName;
          caseOwnerDetails.userName = CaseUserRoleObj.readSupervisor(caseHeaderKey).userName;

          // Check if the supervisor is there or not.If the supervisor is not
          // there, it will try to set the organization unit as the case owner.
          // If the supervisor is there, it will check if he has active
          // positions or not. If he has active positions, he will be set as the
          // case owner. Else, organization unit will be set.
          if (!caseOwnerDetails.userFullName.equals(CuramConst.gkEmpty)) {
            orgStructureUserDateAndStatusKey.userName = caseOwnerDetails.userName;
            orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
            orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

            organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
              organisationStructureStatus);
            orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

            recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
              orgStructureUserDateAndStatusKey);

            if (0 != recordCount.count) {
              caseOwnerDetails.userName = orgStructureUserDateAndStatusKey.userName;
              usersKey.userName = caseOwnerDetails.userName;

              caseOwnerDetails.userFullName = userAccessObj.getFullName(usersKey).fullname;
              caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;
            } else {
              positionHolderLinkIndexStruct3.userName = organisationStructureIDAndNameKey.name;
              // BEGIN, CR00228558, DJ
              positionHolderLinkIndexStruct3.recordStatus = RECORDSTATUS.NORMAL;
              OrganisationUnitNameList organisationUnitNameList = new OrganisationUnitNameList();

              organisationUnitNameList = organisationUnitObj.searchNameByUser(
                positionHolderLinkIndexStruct3);

              orgUnitName.name = organisationUnitNameList.dtls.item(0).name;
              // END, CR00228558
              caseOwnerDetails.userName = orgUnitName.name;
              caseOwnerDetails.userFullName = orgUnitName.name;
              caseOwnerDetails.orgObjectReferenceName = orgUnitName.name;
              caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.ORGUNIT;

              organisationUnitDtlsStruct1.organisationUnitID = organisationUnitObj.readOrgUnitID(orgUnitName).organisationUnitID;
              caseOwnerDetails.orgObjectReference = organisationUnitDtlsStruct1.organisationUnitID;
            }
          } else {
            positionHolderLinkIndexStruct3.userName = organisationStructureIDAndNameKey.name;
            // BEGIN, CR00228558, DJ
            positionHolderLinkIndexStruct3.recordStatus = RECORDSTATUS.NORMAL;
            OrganisationUnitNameList organisationUnitNameList = new OrganisationUnitNameList();

            organisationUnitNameList = organisationUnitObj.searchNameByUser(
              positionHolderLinkIndexStruct3);

            orgUnitName.name = organisationUnitNameList.dtls.item(0).name;
            // END, CR00228558
            caseOwnerDetails.userName = orgUnitName.name;
            caseOwnerDetails.userFullName = orgUnitName.name;
            caseOwnerDetails.orgObjectReferenceName = orgUnitName.name;
            caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.ORGUNIT;

            organisationUnitDtlsStruct1.organisationUnitID = organisationUnitObj.readOrgUnitID(orgUnitName).organisationUnitID;
            caseOwnerDetails.orgObjectReference = organisationUnitDtlsStruct1.organisationUnitID;
          }
          // END, CR00228558
        }
      }
      // END, CR00208059

      getOwnerAndSupervisorForManualResult.owner.orgObjectReference = caseOwnerDetails.orgObjectReference;
      getOwnerAndSupervisorForManualResult.owner.orgObjectType = caseOwnerDetails.orgObjectType;
      getOwnerAndSupervisorForManualResult.owner.userName = caseOwnerDetails.userName;

    } else {

      // Get the ConcernRole owner.
      getCurrentOwnerKey.concernRoleID = key.clientID;
      getCurrentOwnerKey.currentDate = curam.util.type.Date.getCurrentDate();

      // BEGIN, CR00176534, RPB
      // New code after the upgrade of concern role ownership.
      final AdminConcernRoleRMDetailsList adminConcernRoleRMDetailsList = administrationConcernRoleObj.searchCurrentAdministrator(
        getCurrentOwnerKey);

      if (!adminConcernRoleRMDetailsList.dtls.isEmpty()) {
        getOwnerAndSupervisorForManualResult.owner.userName = adminConcernRoleRMDetailsList.dtls.item(0).userName;
        getOwnerAndSupervisorForManualResult.owner.orgObjectType = adminConcernRoleRMDetailsList.dtls.item(0).orgObjectType;
        getOwnerAndSupervisorForManualResult.owner.orgObjectReference = adminConcernRoleRMDetailsList.dtls.item(0).orgObjectReference;

        // BEGIN, CR00208059, DJ
        // Checks if the object type of the concern role admin is a user and
        // if so , checks if the concern role administrator has an active
        // position.If the concern role admin does not have an active position,
        // it will assign the logged in user as the case owner.
        if (ORGOBJECTTYPE.USER.equals(
          getOwnerAndSupervisorForManualResult.owner.orgObjectType)) {
          orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;
          orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForManualResult.owner.userName;
          orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
          orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

          recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
            orgStructureUserDateAndStatusKey);

          if (recordCount.count == 0) {
            getOwnerAndSupervisorForManualResult.owner.userName = TransactionInfo.getProgramUser();
            getOwnerAndSupervisorForManualResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();

            // BEGIN, CR00216755, DJ
            orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForManualResult.owner.userName;
            orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
            orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

            try {
              organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
                organisationStructureStatus);
            } catch (final RecordNotFoundException e) {
              throw new AppException(
                BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
            }
            orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

            recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
              orgStructureUserDateAndStatusKey);
            if (recordCount.count == 0) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                new AppException(
                  BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_CASEOWNER_NOT_SET),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  1);
            }
            // END, CR00216755
          }
        }
        // END, CR00208059
      }

      // To support the existing data after the upgrade.
      MaintainAdminConcernRoleRMDtlsList maintainAdminConcernRoleRMDtlsList = new MaintainAdminConcernRoleRMDtlsList();

      if (adminConcernRoleRMDetailsList.dtls.isEmpty()) {
        maintainAdminConcernRoleRMDtlsList = administrationConcernRoleObj.searchCurrentOwner(
          getCurrentOwnerKey);
        if (!maintainAdminConcernRoleRMDtlsList.dtls.isEmpty()) {
          getOwnerAndSupervisorForManualResult.owner.userName = maintainAdminConcernRoleRMDtlsList.dtls.item(0).userName;
          getOwnerAndSupervisorForManualResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();

          // BEGIN, CR00208059, DJ
          // Checks if the object type of the concern role admin is a user and
          // if so , checks if the concern role administrator has an active
          // position.If the concern role admin does not have an active
          // position, it will assign the logged in user as the case owner.
          if (ORGOBJECTTYPE.USER.equals(
            getOwnerAndSupervisorForManualResult.owner.orgObjectType)) {
            orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;
            orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForManualResult.owner.userName;
            orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
            orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

            recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
              orgStructureUserDateAndStatusKey);

            if (recordCount.count == 0) {
              getOwnerAndSupervisorForManualResult.owner.userName = TransactionInfo.getProgramUser();
              getOwnerAndSupervisorForManualResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();

              // BEGIN, CR00216755, DJ
              orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForManualResult.owner.userName;
              orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
              orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

              try {
                organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
                  organisationStructureStatus);
              } catch (final RecordNotFoundException e) {
                throw new AppException(
                  BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
              }
              orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

              recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
                orgStructureUserDateAndStatusKey);
              if (recordCount.count == 0) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                  new AppException(
                    BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_CASEOWNER_NOT_SET),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                    3);
              }
              // END, CR00216755
            }
          }
          // END, CR00208059
        }
      }

      // If there is no current Owner, use the currently logged in user.
      if (adminConcernRoleRMDetailsList.dtls.isEmpty()
        && maintainAdminConcernRoleRMDtlsList.dtls.isEmpty()) {
        getOwnerAndSupervisorForManualResult.owner.userName = TransactionInfo.getProgramUser();
        getOwnerAndSupervisorForManualResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();

        // BEGIN, CR00216755, DJ
        orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForManualResult.owner.userName;
        orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

        try {
          organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
            organisationStructureStatus);
        } catch (final RecordNotFoundException e) {
          throw new AppException(
            BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
        }
        orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

        recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
          orgStructureUserDateAndStatusKey);
        if (recordCount.count == 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_CASEOWNER_NOT_SET),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
        // END, CR00216755

      }
    }
    // END, CR00176534

    // retrieve the Users organization unit manager
    // Admin user business process object
    final curam.core.intf.AdminUser adminUserObj = curam.core.fact.AdminUserFactory.newInstance();
    // create struct for readSupervisor
    UserNameAndIDStruct userNameAndIDStruct;

    // populate key
    organisationStructureIDAndNameKey.name = getOwnerAndSupervisorForManualResult.owner.userName;

    // Get the active organization Structure and pass it in.
    // As only want to get supervisor for this user in the active
    // organization structure.
    listOrganisationStructureKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;

    // search active organization structure record by status code
    organisationStructureIDList = organisationStructureObj.searchIDByStatusCode(
      listOrganisationStructureKey);

    if (organisationStructureIDList.dtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    // Always only ever be one active organization structure.
    organisationStructureIDAndNameKey.organisationStructureID = organisationStructureIDList.dtls.item(0).organisationStructureID;

    userNameAndIDStruct = adminUserObj.getSupervisor(
      organisationStructureIDAndNameKey);

    if (userNameAndIDStruct == null || userNameAndIDStruct.userName == null) {

      // if no manager found set manager name to self
      managerUserName.managerUserName = getOwnerAndSupervisorForManualResult.owner.userName;

    } else {

      // get manager
      managerUserName.managerUserName = userNameAndIDStruct.userName;

    }
    // END, CR00060051

    // returning supervisor
    getOwnerAndSupervisorForManualResult.supervisor.supervisorID = managerUserName.managerUserName;

    return getOwnerAndSupervisorForManualResult;
  }

  /**
   * Operation to return case owner and supervisor for automatic case creation
   *
   * @param key
   * Key struct
   *
   * @return owner ID and supervisor ID
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public GetOwnerAndSupervisorForAutomaticResult getOwnerAndSupervisorForAutomatic(GetOwnerAndSupervisorKey key)
    throws AppException, InformationalException {

    // output structure containing owner ID and supervisor ID
    final GetOwnerAndSupervisorForAutomaticResult getOwnerAndSupervisorForAutomaticResult = new GetOwnerAndSupervisorForAutomaticResult();

    final ManagerUserName managerUserName = new ManagerUserName();

    // administration concern role entity, key and details list
    final curam.core.intf.AdministrationConcernRole administrationConcernRoleObj = curam.core.fact.AdministrationConcernRoleFactory.newInstance();
    final GetCurrentOwnerKey getCurrentOwnerKey = new GetCurrentOwnerKey();

    // system user entity and details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    final OrganisationStructureIDAndNameKey organisationStructureIDAndNameKey = new OrganisationStructureIDAndNameKey();
    final ListOrganisationStructureKey listOrganisationStructureKey = new ListOrganisationStructureKey();
    // organization structure object
    final curam.core.sl.entity.intf.OrganisationStructure organisationStructureObj = curam.core.sl.entity.fact.OrganisationStructureFactory.newInstance();
    OrganisationStructureIDList organisationStructureIDList;

    // BEGIN, CR00208059, DJ
    OrganisationStructureID organisationStructureID = new OrganisationStructureID();
    final OrgStructureUserDateAndStatusKey orgStructureUserDateAndStatusKey = new OrgStructureUserDateAndStatusKey();
    RecordCount recordCount = new RecordCount();
    final CaseHeaderKey caseHeaderKey1 = new CaseHeaderKey();
    final CaseUserRole CaseUserRoleObj = CaseUserRoleFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    final OrganisationUnitName orgUnitName = new OrganisationUnitName();
    final PositionHolderLinkIndexStruct3 positionHolderLinkIndexStruct3 = new PositionHolderLinkIndexStruct3();
    final OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();
    final curam.core.sl.entity.intf.PositionHolderLink positionHolderLinkObj = PositionHolderLinkFactory.newInstance();
    final OrganisationStructure organisationStructure = OrganisationStructureFactory.newInstance();
    final OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final OrganisationUnitDtlsStruct1 organisationUnitDtlsStruct1 = new OrganisationUnitDtlsStruct1();
    // END, CR00208059

    // BEGIN, CR00060051, PMD
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // If there is a related case use the owner of that case.
    if (key.relatedCaseID != 0) {

      // Set the case header key to be the related case id
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.relatedCaseID;

      // Read case owner
      final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
        caseHeaderKey);

      // BEGIN, CR00208059, DJ
      CaseHeaderDtls caseHeaderDtls = CaseUserRoleObj.readCaseHeader(
        caseHeaderKey1);

      caseHeaderKey1.caseID = key.caseID;
      caseHeaderDtls = CaseUserRoleObj.readCaseHeader(caseHeaderKey1);
      caseHeaderKey.caseID = caseHeaderDtls.integratedCaseID;

      // Checks if the case owner of the related case is of type user and if so
      // it will check the case owner has active positions. If active positions
      // are there, it will set him as the case owner, else it will try to set
      // the supervisor of the related case as the case owner. But if the
      // supervisor, doesn't have active position or if no supervisor is there,
      // organization unit is set as the case owner. If the related case owner
      // is of other type,it will assign that object as the owner.

      if (ORGOBJECTTYPE.USER.equals(caseOwnerDetails.orgObjectType)) {
        orgStructureUserDateAndStatusKey.userName = caseOwnerDetails.userName;
        orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

        organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
          organisationStructureStatus);
        orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

        recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
          orgStructureUserDateAndStatusKey);

        // Check if the user has an active positions. If so assign him as the
        // case owner. Else, get the supervisor of the case.
        if (0 != recordCount.count) {
          caseOwnerDetails.userName = orgStructureUserDateAndStatusKey.userName;
          usersKey.userName = caseOwnerDetails.userName;
          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;

          caseOwnerDetails.userFullName = userAccessObj.getFullName(usersKey).fullname;
        } else {
          // Get the case supervisor who is assigned manually and if he is not
          // found get the dynamically assigned supervisor.
          organisationStructureIDAndNameKey.name = orgStructureUserDateAndStatusKey.userName;
          organisationStructureIDAndNameKey.organisationStructureID = organisationStructureID.organisationStructureID;
          organisationStructureIDAndNameKey.recordStatus = ORGSTRUCTURESTATUS.ACTIVE;
          caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;

          caseOwnerDetails.userFullName = CaseUserRoleObj.readSupervisor(caseHeaderKey).fullName;
          caseOwnerDetails.userName = CaseUserRoleObj.readSupervisor(caseHeaderKey).userName;

          // Check if the supervisor is there or not.If the supervisor is not
          // there, it will try to set the organization unit as the case owner.
          // If the supervisor is there, it will check if he has active
          // positions or not. If he has active positions, he will be set as the
          // case owner.
          // Else, organization unit will be set.
          if (!caseOwnerDetails.userFullName.equals(CuramConst.gkEmpty)) {
            orgStructureUserDateAndStatusKey.userName = caseOwnerDetails.userName;
            orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
            orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

            organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
              organisationStructureStatus);
            orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

            recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
              orgStructureUserDateAndStatusKey);

            if (0 != recordCount.count) {
              caseOwnerDetails.userName = orgStructureUserDateAndStatusKey.userName;
              usersKey.userName = caseOwnerDetails.userName;

              caseOwnerDetails.userFullName = userAccessObj.getFullName(usersKey).fullname;
              caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.USER;
            } else {
              positionHolderLinkIndexStruct3.userName = organisationStructureIDAndNameKey.name;
              // BEGIN, CR00228558, DJ
              positionHolderLinkIndexStruct3.recordStatus = RECORDSTATUS.NORMAL;
              OrganisationUnitNameList organisationUnitNameList = new OrganisationUnitNameList();

              organisationUnitNameList = organisationUnitObj.searchNameByUser(
                positionHolderLinkIndexStruct3);

              orgUnitName.name = organisationUnitNameList.dtls.item(0).name;
              // END, CR00228558
              caseOwnerDetails.userName = orgUnitName.name;
              caseOwnerDetails.userFullName = orgUnitName.name;
              caseOwnerDetails.orgObjectReferenceName = orgUnitName.name;
              caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.ORGUNIT;

              organisationUnitDtlsStruct1.organisationUnitID = organisationUnitObj.readOrgUnitID(orgUnitName).organisationUnitID;
              caseOwnerDetails.orgObjectReference = organisationUnitDtlsStruct1.organisationUnitID;
            }
          } else {
            positionHolderLinkIndexStruct3.userName = organisationStructureIDAndNameKey.name;
            // BEGIN, CR00228558, DJ
            positionHolderLinkIndexStruct3.recordStatus = RECORDSTATUS.NORMAL;
            OrganisationUnitNameList organisationUnitNameList = new OrganisationUnitNameList();

            organisationUnitNameList = organisationUnitObj.searchNameByUser(
              positionHolderLinkIndexStruct3);

            orgUnitName.name = organisationUnitNameList.dtls.item(0).name;
            // END, CR00228558
            caseOwnerDetails.userName = orgUnitName.name;
            caseOwnerDetails.userFullName = orgUnitName.name;
            caseOwnerDetails.orgObjectReferenceName = orgUnitName.name;
            caseOwnerDetails.orgObjectType = ORGOBJECTTYPE.ORGUNIT;

            organisationUnitDtlsStruct1.organisationUnitID = organisationUnitObj.readOrgUnitID(orgUnitName).organisationUnitID;
            caseOwnerDetails.orgObjectReference = organisationUnitDtlsStruct1.organisationUnitID;
          }
        }
      }
      // END, CR00208059

      // the case owner can be
      getOwnerAndSupervisorForAutomaticResult.owner.orgObjectReference = caseOwnerDetails.orgObjectReference;
      getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType = caseOwnerDetails.orgObjectType;
      getOwnerAndSupervisorForAutomaticResult.owner.userName = caseOwnerDetails.userName;

    } else {

      // Get the ConcernRole owner.
      getCurrentOwnerKey.concernRoleID = key.clientID;
      getCurrentOwnerKey.currentDate = curam.util.type.Date.getCurrentDate();

      // BEGIN, CR00176534, RPB
      // New code after the upgrade of concern role ownership.
      final AdminConcernRoleRMDetailsList adminConcernRoleRMDetailsList = administrationConcernRoleObj.searchCurrentAdministrator(
        getCurrentOwnerKey);

      if (!adminConcernRoleRMDetailsList.dtls.isEmpty()) {
        getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType = adminConcernRoleRMDetailsList.dtls.item(0).orgObjectType;
        getOwnerAndSupervisorForAutomaticResult.owner.userName = adminConcernRoleRMDetailsList.dtls.item(0).userName;
        getOwnerAndSupervisorForAutomaticResult.owner.orgObjectReference = adminConcernRoleRMDetailsList.dtls.item(0).orgObjectReference;

        // BEGIN, CR00208059, DJ
        // Checks if the object type of the concern role admin is a user and
        // if so , checks if the concern role administrator has an active
        // position.If the concern role admin does not have an active position,
        // it will assign the logged in user as the case owner.
        if (ORGOBJECTTYPE.USER.equals(
          getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType)) {
          orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;
          orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForAutomaticResult.owner.userName;
          orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
          orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

          recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
            orgStructureUserDateAndStatusKey);

          if (recordCount.count == 0) {
            getOwnerAndSupervisorForAutomaticResult.owner.userName = TransactionInfo.getProgramUser();
            getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();

            // BEGIN, CR00216755, DJ
            orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForAutomaticResult.owner.userName;
            orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
            orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

            try {
              organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
                organisationStructureStatus);
            } catch (final RecordNotFoundException e) {
              throw new AppException(
                BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
            }
            orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

            recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
              orgStructureUserDateAndStatusKey);
            if (recordCount.count == 0) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                new AppException(
                  BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_CASEOWNER_NOT_SET),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  5);
            }
            // END, CR00216755
          }
        }
        // END, CR00208059
      }

      // To support the existing data after the upgrade.
      MaintainAdminConcernRoleRMDtlsList maintainAdminConcernRoleRMDtlsList = new MaintainAdminConcernRoleRMDtlsList();

      ;
      if (adminConcernRoleRMDetailsList.dtls.isEmpty()) {
        maintainAdminConcernRoleRMDtlsList = administrationConcernRoleObj.searchCurrentOwner(
          getCurrentOwnerKey);
        if (!maintainAdminConcernRoleRMDtlsList.dtls.isEmpty()) {
          getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();
          getOwnerAndSupervisorForAutomaticResult.owner.userName = maintainAdminConcernRoleRMDtlsList.dtls.item(0).userName;

          // BEGIN, CR00208059, DJ
          // Checks if the object type of the concern role admin is a user and
          // if so , checks if the concern role administrator has an active
          // position.If the concern role admin does not have an active
          // position,it will assign the logged in user as the case owner.
          if (ORGOBJECTTYPE.USER.equals(
            getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType)) {
            orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;
            orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForAutomaticResult.owner.userName;
            orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
            orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

            recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
              orgStructureUserDateAndStatusKey);

            if (recordCount.count == 0) {
              getOwnerAndSupervisorForAutomaticResult.owner.userName = TransactionInfo.getProgramUser();
              getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();

              // BEGIN, CR00216755, DJ
              orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForAutomaticResult.owner.userName;
              orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
              orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

              try {
                organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
                  organisationStructureStatus);
              } catch (final RecordNotFoundException e) {
                throw new AppException(
                  BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
              }
              orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

              recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
                orgStructureUserDateAndStatusKey);
              if (recordCount.count == 0) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                  new AppException(
                    BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_CASEOWNER_NOT_SET),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                    4);
              }
              // END, CR00216755
            }
          }
          // END, CR00208059

        }
      }

      // If there is no current Owner, use the currently logged in user.
      if (adminConcernRoleRMDetailsList.dtls.isEmpty()
        && maintainAdminConcernRoleRMDtlsList.dtls.isEmpty()) {
        systemUserDtls = systemUserObj.getUserDetails();
        getOwnerAndSupervisorForAutomaticResult.owner.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();
        getOwnerAndSupervisorForAutomaticResult.owner.userName = systemUserDtls.userName;

        // BEGIN, CR00216755, DJ
        orgStructureUserDateAndStatusKey.userName = getOwnerAndSupervisorForAutomaticResult.owner.userName;
        orgStructureUserDateAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        orgStructureUserDateAndStatusKey.effectiveDate = Date.getCurrentDate();

        try {
          organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
            organisationStructureStatus);
        } catch (final RecordNotFoundException e) {
          throw new AppException(
            BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
        }
        orgStructureUserDateAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;

        recordCount = positionHolderLinkObj.countByOrgStructureUserDateAndStatus(
          orgStructureUserDateAndStatusKey);
        if (recordCount.count == 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_CASEOWNER_NOT_SET),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
        }
        // END, CR00216755
      }
    }
    // END, CR00176534

    // retrieve the Users organization unit manager
    final curam.core.intf.AdminUser adminUserObj = curam.core.fact.AdminUserFactory.newInstance();
    // create struct for readSupervisor
    UserNameAndIDStruct userNameAndIDStruct;

    // populate key
    organisationStructureIDAndNameKey.name = getOwnerAndSupervisorForAutomaticResult.owner.userName;

    // Get the active organization Structure and pass it in.
    // As only want to get supervisor for this user in the active
    // organization structure.
    listOrganisationStructureKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;

    // search active organization structure record by status code
    organisationStructureIDList = organisationStructureObj.searchIDByStatusCode(
      listOrganisationStructureKey);

    if (organisationStructureIDList.dtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    // Always only ever be one active organization structure.
    organisationStructureIDAndNameKey.organisationStructureID = organisationStructureIDList.dtls.item(0).organisationStructureID;

    userNameAndIDStruct = adminUserObj.getSupervisor(
      organisationStructureIDAndNameKey);

    if (userNameAndIDStruct == null || userNameAndIDStruct.userName == null) {
      // if no manager found set manager name to self
      managerUserName.managerUserName = getOwnerAndSupervisorForAutomaticResult.owner.userName;

    } else {

      // get manager
      managerUserName.managerUserName = userNameAndIDStruct.userName;

    }
    // END, CR00060051

    getOwnerAndSupervisorForAutomaticResult.supervisor.supervisorID = managerUserName.managerUserName;

    return getOwnerAndSupervisorForAutomaticResult;
  }

}
