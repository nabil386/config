/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.sl.fact.FinancialComponentProcessingFactory;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.intf.FinancialComponentProcessing;
import curam.message.BPOFINANCIALHOOKREGISTRAR;
import curam.util.exception.AppException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import java.lang.reflect.Method;


/**
 * Central class to handle the creation of financial hook(s) based on a
 * particular product type.
 */
public final class FinancialHookManager {

  /**
   * Retrieves the map containing a subclass of the FinancialComponentProcessing
   * class for each product type.
   *
   * @return The map containing a subclass of the FinancialComponentProcessing
   * class for each product type.
   */
  public static FinancialHookRegistrar.HookMap getHookMap() {

    return hookMap;
  }

  /**
   * The map containing a subclass of the FinancialComponentProcessing class for
   * each product type.
   */
  // BEGIN, CR00198200, GYH
  protected static FinancialHookRegistrar.HookMap hookMap = GuiceWrapper.getInjector().getInstance(
    FinancialHookRegistrar.HookMap.class);
  // END, CR00198200

  // Static initialization of Financial Hook Map
  static {

    // Get the value of the financial hook registrars environment variable
    final String registrarsString = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_REGISTRARS_LIST);

    if (null != registrarsString) {

      // Get comma-separated list of registrar factory class names
      // BEGIN, CR00072832, GM
      final String registrarFactoryNames[] = registrarsString.split(
        CuramConst.gkComma);

      // END, CR00072832

      for (int i = 0; i < registrarFactoryNames.length; i++) {

        final String registrarFactoryName = registrarFactoryNames[i];

        try {
          final Class registrarFactoryClass = Class.forName(
            registrarFactoryName);
          // BEGIN, CR00023618, SK
          final Method newInstance = registrarFactoryClass.getMethod(
            ReflectionConst.kNewInstance, new Class[0]);
          // END, CR00023618
          final Object registrar = newInstance.invoke(null, new Object[0]);
          final FinancialHookRegistrar financialHookRegistrar = (FinancialHookRegistrar) registrar;

          // Register the Halt Payment Hook Class
          financialHookRegistrar.registerFinancialHooks();

        } catch (final Exception e) {

          final AppException ae = new AppException(
            BPOFINANCIALHOOKREGISTRAR.ERR_REGISTRAR_ISSUE);

          // BEGIN, CR00155681, GYH
          ae.initCause(e);
          // END, CR00155681
          throw new RuntimeException(ae);
        }

      }

    }

  }

  /**
   * Gets the implementation subclass of the FinancialComponentProcessing class
   * for the specified product type.
   *
   * @param productType The type of product
   *
   * @return The implementation subclass of the FinancialComponentProcessing
   * class for the specified product type.
   *
   * @deprecated
   */
  @Deprecated
  public FinancialComponentProcessing getHook(final String productType)
    throws AppException {

    FinancialComponentProcessing result = (FinancialComponentProcessing) hookMap.createHookInstance(
      productType, FinancialComponentProcessing.class);

    if (null == result) {
      result = FinancialComponentProcessingFactory.newInstance();
    }

    return result;
  }

}
