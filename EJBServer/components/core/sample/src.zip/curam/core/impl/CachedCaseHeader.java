/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2020. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.impl;

import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderReadByICKey;
import curam.core.struct.CaseHeaderReadmultiDetails1List;
import curam.core.struct.CaseHeaderReadmultiKey1;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CaseTypeDetails_eo;
import curam.core.struct.CaseTypeStartDateEndDateExpectedEndDateList;
import curam.core.struct.IntegratedCaseKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;
import org.apache.logging.log4j.Logger;


/**
 * @see curam.core.intf.CachedCaseHeader;
 */
public abstract class CachedCaseHeader extends curam.core.base.CachedCaseHeader {

  protected static ThreadLocal<CaseHeaderCached> cachedCaseHeaderThreadLocal = new ThreadLocal<CaseHeaderCached>();

  // ___________________________________________________________________________
  // BEGIN, CR00069782, GSP
  protected static ThreadLocal<IntegratedCaseHeaderCached> integCachedCaseHeaderThreadLocal = new ThreadLocal<IntegratedCaseHeaderCached>();

  // END, CR00069782

  // BEGIN, CR00023323, SK
  // 258085, BEGIN, BD
  public static final Logger kBatchLauncherCacheLogger = Trace.getLogger(
    ExtensionConst.kBatchCachingCategory);
  // 258085, END

  // END, CR0002332

  public static final boolean logging;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // BEGIN, CR00052232, GSP
  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;
  // END, CR00052232

  // ___________________________________________________________________________
  // static to hold the logging_enabled environmental Variable
  static {

    cachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    // BEGIN, CR00052232, GSP
    onlineCachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);
    // END, CR00052232

    String logging_enabled = Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }
  }

  // ___________________________________________________________________________
  /**
   * class used to cache the CaseHeader details
   *
   */
  class CaseHeaderCached {

    CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    int transactionID = 0;
  }


  // BEGIN, CR00069782, GSP
  // ___________________________________________________________________________
  /**
   * class used to cache the details of the cases corresponding to an
   * IntegratedCase
   *
   */
  class IntegratedCaseHeaderCached {

    IntegratedCaseKey integCasekey = new IntegratedCaseKey();

    CaseHeaderReadmultiDetails1List caseHeaderRdmultiDtls1Lst = new CaseHeaderReadmultiDetails1List();

    CaseTypeStartDateEndDateExpectedEndDateList caseTypStDtEndDtExpEndDtLst = new CaseTypeStartDateEndDateExpectedEndDateList();

    int transactionID = 0;

  }

  // END, CR00069782

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseHeaderDtls read(CaseHeaderKey key) throws AppException,
      InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {
      // BEGIN, CR00052232, GSP
      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        reloadCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if ((transactionType.equals(TransactionType.kDeferred)
          || transactionType.equals(TransactionType.kOnline))
            // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    if (reloadCache) {

      // Otherwise we need to read the CaseHeader data
      caseHeaderCached = new CaseHeaderCached();
      caseHeaderCached.caseHeaderDtls = reloadCache(key);

    }
    // BEGIN, CR00284485, ZV
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    return caseHeaderDtls.assign(caseHeaderCached.caseHeaderDtls);
    // END, CR00284485
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void clearCache() throws AppException, InformationalException {

    cachedCaseHeaderThreadLocal.set(null);
    // BEGIN, CR00069782, GSP
    integCachedCaseHeaderThreadLocal.set(null);
    // END, CR00069782
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(CaseHeaderKey key, CaseHeaderDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00052232, GSP
    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();
    // END, CR00052232
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseHeaderObj.modify(key, dtls);
    // BEGIN, CR00052232, GSP
    // If this is a batch transaction or deferred or online processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {
      // END, CR00052232
      final CaseHeaderCached caseHeaderCached = new CaseHeaderCached();

      // BEGIN, CR00069782, GSP
      caseHeaderCached.caseHeaderDtls.assign(dtls);
      // END, CR00069782
      caseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedCaseHeaderThreadLocal.set(caseHeaderCached);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseKey readIntegratedCaseIDByCaseID(CaseKey key)
    throws AppException, InformationalException {

    final IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {
      // BEGIN, CR00052232, GSP
      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)
            // END, CR00052232
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        integratedCaseKey.integratedCaseID = caseHeaderCached.caseHeaderDtls.integratedCaseID;
        reloadCache = false;

        // BEGIN, CR00052232, GSP
        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline)) // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      // BEGIN, CR00279909, SG
      final CaseHeaderDtls caseHeaderDtls = reloadCache(caseHeaderKey);

      // END, CR00279909
      integratedCaseKey.integratedCaseID = caseHeaderDtls.integratedCaseID;
    }

    return integratedCaseKey;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseTypeDetails_eo readType(CaseHeaderKey key) throws AppException,
      InformationalException {

    final CaseTypeDetails_eo caseTypeDetails_eo = new CaseTypeDetails_eo();

    final CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {

      // variable to hold transaction type
      final TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

      // BEGIN, CR00052232, GSP
      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled) // END,
            // CR00052232
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        caseTypeDetails_eo.caseTypeCode = caseHeaderCached.caseHeaderDtls.caseTypeCode;
        caseTypeDetails_eo.versionNo = caseHeaderCached.caseHeaderDtls.versionNo;

        reloadCache = false;

        // BEGIN, CR00052232, GSP
        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline)) // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      // BEGIN, CR00279909, SG
      final CaseHeaderDtls caseHeaderDtls = reloadCache(caseHeaderKey);

      // END, CR00279909
      caseTypeDetails_eo.caseTypeCode = caseHeaderDtls.caseTypeCode;
      caseTypeDetails_eo.versionNo = caseHeaderDtls.versionNo;
    }

    return caseTypeDetails_eo;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseHeaderDtls reloadCache(CaseHeaderKey key) throws AppException,
      InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderDtls caseHeaderDtls;
    final CaseHeaderCached caseHeaderCached = new CaseHeaderCached();

    // Read the case header details
    caseHeaderDtls = caseHeaderObj.read(key);
    // BEGIN, CR00052232, GSP
    // If this was a cache miss (and caching is enabled), refresh the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {
      // END, CR00052232

      // BEGIN, CR00069782, GSP
      caseHeaderCached.caseHeaderDtls.assign(caseHeaderDtls);
      // END, CR00069782
      caseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the cache
      cachedCaseHeaderThreadLocal.set(caseHeaderCached);
    }

    return caseHeaderDtls;
  }

  // BEGIN, CR00069782, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseHeaderReadmultiDetails1List reloadCaseDtlsByICCache(
    CaseHeaderReadmultiKey1 key) throws AppException, InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderReadmultiDetails1List caseHeaderRdMultiDtlsLst;
    final IntegratedCaseHeaderCached integCaseHeaderCached = new IntegratedCaseHeaderCached();

    // Search by Integrated Case
    caseHeaderRdMultiDtlsLst = caseHeaderObj.searchByIntegratedCaseID(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      integCaseHeaderCached.integCasekey.integratedCaseID = key.integratedCaseID;
      integCaseHeaderCached.caseHeaderRdmultiDtls1Lst.assign(
        caseHeaderRdMultiDtlsLst);
      integCaseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the integrated cache
      integCachedCaseHeaderThreadLocal.set(integCaseHeaderCached);
    }

    return caseHeaderRdMultiDtlsLst;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseTypeStartDateEndDateExpectedEndDateList reloadCaseTypStEndExpEndDtDtlsCache(CaseHeaderReadByICKey key)
    throws AppException, InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseTypeStartDateEndDateExpectedEndDateList caseTypStDtEndDtExpEndDtLst;
    final IntegratedCaseHeaderCached integCaseHeaderCached = new IntegratedCaseHeaderCached();

    // Search by Integrated Case
    caseTypStDtEndDtExpEndDtLst = caseHeaderObj.searchCaseTypeStartEndAndExpectedEndDatesByIntegratedCase(
      key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      integCaseHeaderCached.integCasekey.integratedCaseID = key.integratedCaseID;
      integCaseHeaderCached.caseTypStDtEndDtExpEndDtLst.assign(
        caseTypStDtEndDtExpEndDtLst);
      integCaseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the integrated cache
      integCachedCaseHeaderThreadLocal.set(integCaseHeaderCached);
    }

    return caseTypStDtEndDtExpEndDtLst;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseHeaderReadmultiDetails1List searchByIntegratedCaseID(
    CaseHeaderReadmultiKey1 key) throws AppException, InformationalException {

    final CaseHeaderReadmultiDetails1List caseHeaderRdmultiDtlsLst = new CaseHeaderReadmultiDetails1List();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final IntegratedCaseHeaderCached integCaseHeaderCached = integCachedCaseHeaderThreadLocal.get();

    boolean reloadIntegCache = true;

    if (integCaseHeaderCached != null) {

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)
            && integCaseHeaderCached.caseHeaderRdmultiDtls1Lst != null
            && integCaseHeaderCached.integCasekey.integratedCaseID
              == key.integratedCaseID) {

        caseHeaderRdmultiDtlsLst.assign(
          integCaseHeaderCached.caseHeaderRdmultiDtls1Lst);

        reloadIntegCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadIntegCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != integCaseHeaderCached.transactionID) {

          reloadIntegCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadIntegCache) {
      caseHeaderRdmultiDtlsLst.assign(reloadCaseDtlsByICCache(key));
    }

    return caseHeaderRdmultiDtlsLst;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseTypeStartDateEndDateExpectedEndDateList searchCaseTypeStartEndAndExpectedEndDatesByIntegratedCase(
    CaseHeaderReadByICKey key) throws AppException, InformationalException {

    final CaseTypeStartDateEndDateExpectedEndDateList caseTypStDtEndDtExpEndDtLst = new CaseTypeStartDateEndDateExpectedEndDateList();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final IntegratedCaseHeaderCached integCaseHeaderCached = integCachedCaseHeaderThreadLocal.get();

    boolean reloadIntegCache = true;

    if (integCaseHeaderCached != null) {

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)
            && integCaseHeaderCached.caseTypStDtEndDtExpEndDtLst != null
            && integCaseHeaderCached.integCasekey.integratedCaseID
              == key.integratedCaseID) {

        caseTypStDtEndDtExpEndDtLst.assign(
          integCaseHeaderCached.caseTypStDtEndDtExpEndDtLst);

        reloadIntegCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadIntegCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != integCaseHeaderCached.transactionID) {

          reloadIntegCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadIntegCache) {
      caseTypStDtEndDtExpEndDtLst.assign(
        reloadCaseTypStEndExpEndDtDtlsCache(key));
    }

    return caseTypStDtEndDtExpEndDtLst;
  }

  // END, CR00069782
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseHeaderDtls getCachedDtls() {

    // Create the return object
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    // Read the cached details
    CaseHeaderCached caseHeaderCached = new CaseHeaderCached();

    caseHeaderCached = cachedCaseHeaderThreadLocal.get();
    // BEGIN, SPMP-14584, BD.
    if (caseHeaderCached == null) {
      return caseHeaderDtls;
    }
    // END, SPMP-14584

    if (caseHeaderCached.caseHeaderDtls == null) {
      // BEGIN, SPMP-14584, BD.
      caseHeaderCached.caseHeaderDtls = caseHeaderDtls;
      // END, SPMP-14584
    }

    return caseHeaderDtls.assign(caseHeaderCached.caseHeaderDtls);
  }

  // BEGIN, CR00052232, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseTypeCode readCaseTypeCode(CaseKey key) throws AppException,
      InformationalException {

    final CaseTypeCode caseTypeCode = new CaseTypeCode();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    final CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        caseTypeCode.caseTypeCode = caseHeaderCached.caseHeaderDtls.caseTypeCode;
        reloadCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      // BEGIN, CR00279909, SG
      final CaseHeaderDtls caseHeaderDtls = reloadCache(caseHeaderKey);

      // END, CR00279909
      caseTypeCode.caseTypeCode = caseHeaderDtls.caseTypeCode;
    }

    return caseTypeCode;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseStartDate readStartDate(CaseHeaderKey key) throws AppException,
      InformationalException {

    final CaseStartDate caseStartDate = new CaseStartDate();

    final CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {

      // variable to hold transaction type
      final TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled
        || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
        || transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        caseStartDate.startDate = caseHeaderCached.caseHeaderDtls.startDate;

        reloadCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {
      // BEGIN, CR00279909, SG
      final CaseHeaderDtls caseHeaderDtls = reloadCache(key);

      // END, CR00279909
      caseStartDate.startDate = caseHeaderDtls.startDate;
    }

    return caseStartDate;
  }
  // END, CR00052232
}
