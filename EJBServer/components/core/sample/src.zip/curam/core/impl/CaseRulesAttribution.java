/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.LookupRulesForCaseKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class represents a hook which can be overridden by custom code.
 * This hook is called when the application wishes to determine what
 * date a rule set becomes active on for a given case.
 */
public abstract class CaseRulesAttribution extends curam.core.base.CaseRulesAttribution {

  /**
   * This method is called when determining the rules which should be used
   * for a given case on a given date. The default implementation does not
   * modify the values passed in any way, however custom code may wish to
   * modify the date passed in, e.g. in order to ensure that the rules
   * used on a particular day line up with the payment date for the case.
   *
   * @param lookupRulesForCaseKey The key which will be used to retrieve
   * the rules for the case.
   *
   * @return The attributed values for the key.
   */
  @Override
  public LookupRulesForCaseKey attributeRules(
    final LookupRulesForCaseKey lookupRulesForCaseKey) throws AppException,
      InformationalException {

    return lookupRulesForCaseKey;
  }

}
