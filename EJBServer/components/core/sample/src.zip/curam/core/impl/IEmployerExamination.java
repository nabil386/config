/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerKey;


/**
 * Acts as a hook during insert or modify of an Employer record. Classes which
 * implement this interface can implement their own validation code. <br/>
 * Listeners are registered in the <code>EMPLOYEREXAMINATIONCLASS</code>
 * codetable. This codetable is intended only to be modified at
 * development time.
 */
public interface IEmployerExamination {

  // ___________________________________________________________________________
  /**
   * Operation to allow components to perform additional processing during an
   * insert on the Employer table. Components may choose not to implement this
   * operation.
   *
   * @param dtls Employer entity details
   */
  void examineEmployerInsert(EmployerDtls dtls);

  /**
   * Operation to allow components to perform additional processing during an
   * a modify operation on the Employer table. Components may choose not to
   * implement this operation.
   *
   * @param key Employer entity key
   * @param dtls Employer entity details
   */
  void examineEmployerModify(EmployerKey key, EmployerDtls dtls);

}
