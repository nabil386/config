/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.AllocationDtlsCaptured;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CreditAllocateKey;
import curam.core.struct.DAamount;
import curam.core.struct.DAcreditILIidDebitILIidStatus;
import curam.core.struct.DebitsOutstanding;
import curam.core.struct.DebitsOutstandingList;
import curam.core.struct.DraftAllocationLineDtls;
import curam.core.struct.DraftAllocationLineKey;
import curam.core.struct.FinInstructionID;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.LiabilityInstrumentID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code for retrieving draft allocation lines and outstanding debits in
 * the allocation process.
 */
public abstract class AllocateCreditTransactionAssistant extends curam.core.base.AllocateCreditTransactionAssistant {

  // ___________________________________________________________________________
  /**
   * To create a new DraftAllocationLine record or update an existing
   * DraftAllocationLine record (if the allocation existed previously).
   *
   * @param allocDtlsCaptured allocation captured details
   */
  @Override
  public void addAllocationDetails(AllocationDtlsCaptured allocDtlsCaptured)
    throws AppException, InformationalException {

    // based on domain CURAM_AMOUNT
    final curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

    // Draft allocation search key and details
    final DAcreditILIidDebitILIidStatus draftAllocKey = new DAcreditILIidDebitILIidStatus();
    final curam.core.intf.DraftAllocationLine draftAllocationLineObj = curam.core.fact.DraftAllocationLineFactory.newInstance();
    DraftAllocationLineDtls draftAllocDtls;

    draftAllocKey.assign(allocDtlsCaptured);
    draftAllocKey.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

    try {
      draftAllocDtls = draftAllocationLineObj.readBycreditILIdebitILIstatus(
        draftAllocKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      draftAllocDtls = null;
    }

    if (draftAllocDtls == null) {

      // Draft allocation line details
      final DraftAllocationLineDtls draftAllocationLineDtls = new DraftAllocationLineDtls();

      draftAllocationLineDtls.draftAllocationLineID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
      draftAllocationLineDtls.assign(allocDtlsCaptured);
      draftAllocationLineDtls.allocationDate = curam.util.type.Date.getCurrentDate();
      draftAllocationLineDtls.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

      // insert draftAllocationLine
      draftAllocationLineObj.insert(draftAllocationLineDtls);

    } else {

      final DraftAllocationLineKey draftAllocationLineKey = new DraftAllocationLineKey();

      if (allocDtlsCaptured.amount.getValue() <= zeroAmount.getValue()) {

        // the draftAllocationLine exists but it is being modified to zero
        // (deallocated), this is an invalid allocation, so remove it rather
        // than storing the allocation of zero
        draftAllocationLineKey.draftAllocationLineID = draftAllocDtls.draftAllocationLineID;

        try {
          draftAllocationLineObj.remove(draftAllocationLineKey);

        } catch (final curam.util.exception.RecordNotFoundException e) {// ignore
          // exception
          // of this
          // type - we
          // were trying
          // to remove
          // it so it
          // doesn't exist, the same objective exists
        }

      } else {

        // Draft allocation line key and amount details
        final DAamount daAmount = new DAamount();

        draftAllocationLineKey.draftAllocationLineID = draftAllocDtls.draftAllocationLineID;

        daAmount.amount = allocDtlsCaptured.amount;
        daAmount.versionNo = draftAllocDtls.versionNo;

        // modify draftAllocationLine with new amount
        draftAllocationLineObj.modifyAmount(draftAllocationLineKey, daAmount);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * To populate the output struct with all available debits for allocation.
   *
   * @param creditAllocateKey Credit allocate key
   * @param instructionLineItemDtls Instruction Line Item details
   * @param debitsOutstandingList Debits outstanding list
   *
   * @return DraftAllocationLineDtls - draft allocation details
   */
  @Override
  public DraftAllocationLineDtls viewOutstandingDebits(
    CreditAllocateKey creditAllocateKey,
    InstructionLineItemDtls instructionLineItemDtls,
    DebitsOutstandingList debitsOutstandingList) throws AppException,
      InformationalException {

    DraftAllocationLineDtls draftAllocDtls;
    // Draft allocation search key and details
    final DAcreditILIidDebitILIidStatus draftAllocKey = new DAcreditILIidDebitILIidStatus();
    final curam.core.intf.DraftAllocationLine draftAllocationLineObj = curam.core.fact.DraftAllocationLineFactory.newInstance();
    final curam.core.intf.LiabilityInstrument liabilityInstrumentObj = curam.core.fact.LiabilityInstrumentFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    final curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

    draftAllocKey.creditInstructionLineItemID = creditAllocateKey.instructionLineItemID;
    draftAllocKey.debitInstructionLineItemID = instructionLineItemDtls.instructLineItemID;
    draftAllocKey.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

    try {
      draftAllocDtls = draftAllocationLineObj.readBycreditILIdebitILIstatus(
        draftAllocKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // this is the output from this routing, if it is set here
      // the calling method will get garbage data with the exception
      // of that set in the next line
      draftAllocDtls = new DraftAllocationLineDtls();
      draftAllocDtls.amount = zeroAmount;
    }

    // Debits outstanding details

    final DebitsOutstanding debitsOutstanding = new DebitsOutstanding();

    // Populate a struct for the output list
    debitsOutstanding.currencyType = instructionLineItemDtls.currencyTypeCode;
    debitsOutstanding.debitILIid = instructionLineItemDtls.instructLineItemID;
    debitsOutstanding.debitCategory = instructionLineItemDtls.instructLineItemCategory;
    debitsOutstanding.debitType = instructionLineItemDtls.instructionLineItemType;
    debitsOutstanding.debitFinInstructionID = instructionLineItemDtls.finInstructionID;
    debitsOutstanding.debitCaseID = instructionLineItemDtls.caseID;
    debitsOutstanding.effectiveDate = instructionLineItemDtls.effectiveDate;
    debitsOutstanding.debitTotalAmount = instructionLineItemDtls.amount;
    debitsOutstanding.debitOutstandingAmount = new curam.util.type.Money(
      instructionLineItemDtls.unprocessedAmount.getValue()
        - draftAllocDtls.amount.getValue());

    // set case reference to be returned
    caseSearchKey.caseID = instructionLineItemDtls.caseID;
    debitsOutstanding.debitCaseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference;

    if (instructionLineItemDtls.instructLineItemCategory.equals(
      curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION)) {

      // set Liability Instrument ID to be returned
      final FinInstructionID finInstructionID = new FinInstructionID();

      finInstructionID.finInstructionID = instructionLineItemDtls.finInstructionID;

      final LiabilityInstrumentID liabilityInstrumentID = liabilityInstrumentObj.readLiabInstrumentIDByFinInstructionID(
        finInstructionID);

      debitsOutstanding.liabilityInstrumentID = liabilityInstrumentID.liabInstrumentID;
    }

    debitsOutstanding.debitAllocatedAmount = draftAllocDtls.amount;

    debitsOutstandingList.dtls.addRef(debitsOutstanding);

    return draftAllocDtls;
  }

}
