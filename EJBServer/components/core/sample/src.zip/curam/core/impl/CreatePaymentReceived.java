/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.intf.ClientInteraction;
import curam.core.struct.CashReceivedDtls;
import curam.core.struct.ChequeReceivedDtls;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.core.struct.PaymentReceivedInstructionDtls;
import curam.core.struct.PaymentReceivedInstrumentDtls;
import curam.core.struct.PmtReceivedInstructionDetails;
import curam.core.struct.PmtReceivedInstrumentDetails;
import curam.core.struct.StandingOrderDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Code for creating a payments received plan.
 *
 */
public abstract class CreatePaymentReceived extends curam.core.base.CreatePaymentReceived {

  // ___________________________________________________________________________
  /**
   * This method creates the payment received instruction.
   *
   * @param pmtRecvInstructionDetails Payment received instruction details
   *
   * @return The created financial instruction identifier
   */
  @Override
  public FinancialInstructionDtls createPaymentReceivedInstruction(
    PmtReceivedInstructionDetails pmtRecvInstructionDetails)
    throws AppException, InformationalException {

    // financialInstructionDtls variable
    final FinancialInstructionDtls financialInstructionDtls = new FinancialInstructionDtls();

    // financialInstructionDtls variable
    final curam.core.intf.FinancialInstructionStatus financialInstructionStatusObj = curam.core.fact.FinancialInstructionStatusFactory.newInstance();
    // Financial instruction status details
    final FinancialInstructionStatusDtls financialInstructionStatusDtls = new FinancialInstructionStatusDtls();

    // paymentReceivedInstruction manipulation variables
    final curam.core.intf.PaymentReceivedInstruction paymentReceivedInstructionObj = curam.core.fact.PaymentReceivedInstructionFactory.newInstance();
    final PaymentReceivedInstructionDtls paymentReceivedInstructionDtls = new PaymentReceivedInstructionDtls();

    // paymentReceivedInstruction identifier
    long pmtRecvInstructionID = 0;

    // financialInstructionStatus identifier
    long finInstructionStatusID = 0;

    // create the payment received financial instruction
    createPaymentReceivedFinInstruction(pmtRecvInstructionDetails,
      financialInstructionDtls);

    // generate the unique id for the paymentReceivedInstruction
    pmtRecvInstructionID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // map the details to paymentReceivedInstructionDtls for insert
    paymentReceivedInstructionDtls.assign(pmtRecvInstructionDetails);
    paymentReceivedInstructionDtls.pmtRecInstructionID = pmtRecvInstructionID;
    paymentReceivedInstructionDtls.finInstructionID = financialInstructionDtls.finInstructionID;

    // insert the paymentReceivedInstruction
    paymentReceivedInstructionObj.insert(paymentReceivedInstructionDtls);

    // generate the unique id for the financialInstructionStatus
    finInstructionStatusID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // map the details to finInstructionStatusDtls for insert
    financialInstructionStatusDtls.finInstructionID = financialInstructionDtls.finInstructionID;
    financialInstructionStatusDtls.statusCode = curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    financialInstructionStatusDtls.statusDate = curam.util.transaction.TransactionInfo.getSystemDate();
    financialInstructionStatusDtls.finInstructionStatusID = finInstructionStatusID;

    // insert financialInstructionStatus
    financialInstructionStatusObj.insert(financialInstructionStatusDtls);

    // BEGIN CR00074870, FOD: create a ClientInteraction of type Liability
    // Issued
    String createClientInteraction = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_INTERACTION_FOR_PAYMENT_RECEIVED_FINANCIAL_INSTRUCTION);

    if (createClientInteraction == null) {

      createClientInteraction = EnvVars.ENV_INTERACTION_FOR_PAYMENT_RECEIVED_FINANCIAL_INSTRUCTION_DEFAULT;
    }
    if (createClientInteraction.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      // BEGIN, CR00192165, VM
      final ClientInteractionDtls clientInteractionDtls = new ClientInteractionDtls();
      final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();

      // END, CR00192165

      clientInteractionDtls.concernRoleID = pmtRecvInstructionDetails.concernRoleID;
      clientInteractionDtls.description = // BEGIN, CR00163471, JC
        curam.message.BPOCREATEPAYMENTS.INF_PAYMENT.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
      clientInteractionDtls.interactionDateTime = curam.util.type.DateTime.getCurrentDateTime();
      clientInteractionDtls.interactionTypeCode = curam.codetable.INTERACTIONTYPE.PAYMENTRECEIVED;
      clientInteractionDtls.relatedID = financialInstructionDtls.finInstructionID;
      clientInteractionDtls.relatedType = curam.codetable.RELATEDINTERACTIONTYPE.PAYMENT;

      // BEGIN, CR00192165, VM
      clientInteractionObj.recordClientInteraction(clientInteractionDtls);
      // END, CR00192165
    }
    // END CR00074870

    return financialInstructionDtls;

  }

  // ___________________________________________________________________________
  /**
   * This method creates the Payment Received Instrument.
   *
   * @param pmtRecvInstrumentDetails Payment received instrument details
   *
   * @return Payment received instrument details
   */
  @Override
  public PaymentReceivedInstrumentDtls createPaymentReceivedInstrument(
    PmtReceivedInstrumentDetails pmtRecvInstrumentDetails)
    throws AppException, InformationalException {

    // paymentReceivedInstrumentDtls variable
    final PaymentReceivedInstrumentDtls paymentReceivedInstrumentDtls = new PaymentReceivedInstrumentDtls();
    final curam.core.intf.PaymentReceivedInstrument paymentReceivedInstrumentObj = curam.core.fact.PaymentReceivedInstrumentFactory.newInstance();

    // payment received identifier
    long pmtReceivedID = 0;

    // Map the attributes one to one
    paymentReceivedInstrumentDtls.assign(pmtRecvInstrumentDetails);

    // generate a uniqueID for the paymentReceivedInstrument
    pmtReceivedID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // set remaining paymentReceivedInstrumentDtls
    paymentReceivedInstrumentDtls.pmtRecInstrumentID = pmtReceivedID;
    paymentReceivedInstrumentDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // insert paymentReceivedInstrument
    paymentReceivedInstrumentObj.insert(paymentReceivedInstrumentDtls);

    // creating the paymentReceivedInstrument type (Check, Cash, SO)
    if (pmtRecvInstrumentDetails.receiptMethodCode.equals(
      curam.codetable.METHODOFRECEIPT.GIRO)) {

      // standingOrder variable
      final StandingOrderDtls standingOrderDtls = new StandingOrderDtls();
      final curam.core.intf.StandingOrder standingOrderObj = curam.core.fact.StandingOrderFactory.newInstance();

      // assign standingOrder details for insert
      standingOrderDtls.assign(pmtRecvInstrumentDetails);
      // BEGIN, CR00407584, SS
      standingOrderDtls.originIBAN = pmtRecvInstrumentDetails.originIBANOpt;
      standingOrderDtls.originBIC = pmtRecvInstrumentDetails.originBICOpt;
      standingOrderDtls.destIBAN = pmtRecvInstrumentDetails.destIBANOpt;
      standingOrderDtls.destBIC = pmtRecvInstrumentDetails.destBICOpt;
      // END, CR00407584
      standingOrderDtls.pmtRecInstrumentID = pmtReceivedID;

      // insert standingOrder
      standingOrderObj.insert(standingOrderDtls);

    } else {

      if (pmtRecvInstrumentDetails.receiptMethodCode.equals(
        curam.codetable.METHODOFRECEIPT.CHEQUE)) {

        // chequeReceived manipulation variables
        final ChequeReceivedDtls chequeReceivedDtls = new ChequeReceivedDtls();
        final curam.core.intf.ChequeReceived chequeReceivedObj = curam.core.fact.ChequeReceivedFactory.newInstance();

        // set chequeReceivedDtls for insert
        chequeReceivedDtls.pmtRecInstrumentID = pmtReceivedID;
        chequeReceivedDtls.chequeNumber = pmtRecvInstrumentDetails.chequeNumber;
        chequeReceivedDtls.amount = pmtRecvInstrumentDetails.amount;

        // insert chequeReceived
        chequeReceivedObj.insert(chequeReceivedDtls);

      } else {

        if (pmtRecvInstrumentDetails.receiptMethodCode.equals(
          curam.codetable.METHODOFRECEIPT.CASH)) {

          // cashReceived manipulation variables
          final CashReceivedDtls cashReceivedDtls = new CashReceivedDtls();
          final curam.core.intf.CashReceived cashReceivedObj = curam.core.fact.CashReceivedFactory.newInstance();

          // set cashReceivedDtls for insert
          cashReceivedDtls.pmtRecInstrumentID = pmtReceivedID;
          cashReceivedDtls.ledgerNumber = pmtRecvInstrumentDetails.ledgerNumber;
          cashReceivedDtls.amount = pmtRecvInstrumentDetails.amount;

          // insert cashReceived
          cashReceivedObj.insert(cashReceivedDtls);

        } else {

          final AppException e = new AppException(
            curam.message.GENERALFINANCE.ERR_PMTRECEIVEDINSTRUMENT_FV_METHOD_INVALID);

          e.arg(pmtRecvInstrumentDetails.receiptMethodCode);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
        }

      }

    }

    return paymentReceivedInstrumentDtls;
  }

  // ___________________________________________________________________________
  /**
   * To create a Financial Instruction record for the payment received
   *
   * @param pmtRecvInstructionDetails Payment received instruction details
   * @param finInstructionDtls Financial instruction details
   */
  @Override
  public void createPaymentReceivedFinInstruction(
    PmtReceivedInstructionDetails pmtRecvInstructionDetails,
    FinancialInstructionDtls finInstructionDtls) throws AppException,
      InformationalException {

    // financialInstruction object
    final curam.core.intf.FinancialInstruction financialInstructionObj = curam.core.fact.FinancialInstructionFactory.newInstance();

    // financial instruction identifier
    long financialInstructionID = 0;

    // generate uniqueID for financialInstruction
    financialInstructionID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // set details for financialInstruction insert
    finInstructionDtls.finInstructionID = financialInstructionID;
    finInstructionDtls.typeCode = curam.codetable.FINANCIALINSTRUCTION.PAYMENTRECEIVED;
    finInstructionDtls.concernRoleID = pmtRecvInstructionDetails.concernRoleID;
    finInstructionDtls.statusCode = curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    finInstructionDtls.amount = pmtRecvInstructionDetails.amount;
    finInstructionDtls.effectiveDate = pmtRecvInstructionDetails.effectiveDate;
    finInstructionDtls.postingDate = curam.util.type.Date.getCurrentDate();
    finInstructionDtls.creditDebitType = curam.codetable.CREDITDEBIT.CREDIT;
    finInstructionDtls.currencyTypeCode = pmtRecvInstructionDetails.currencyTypeCode;
    finInstructionDtls.currencyExchangeID = pmtRecvInstructionDetails.currencyExchangeID;
    finInstructionDtls.instrumentGenInd = pmtRecvInstructionDetails.instrumentGenInd;
    finInstructionDtls.comments = pmtRecvInstructionDetails.comments;

    // insert financialInstruction
    financialInstructionObj.insert(finInstructionDtls);

  }

}
