/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code for controlling receipt number.
 */

public abstract class ControlReceiptNumber extends curam.core.base.ControlReceiptNumber {

  // ___________________________________________________________________________
  /**
   * To look up the receiptNumber table and from it determine the next
   * available receipt number.
   *
   * @return The next receipt number.
   */
  @Override
  public long getNextReceiptNumber() throws AppException,
      InformationalException {

    return getNextReceiptNumberFromKeySet();

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the next ReceiptNumber from the ReceiptNumber key set.
   * This number is generated sequentially, however the number can be "lost" if
   * the surrounding transaction is rolled back after the number has been
   * generated.
   *
   * @return The next receipt number.
   */
  @Override
  protected long getNextReceiptNumberFromKeySet() throws AppException,
      InformationalException {

    // uniqueID manipulation variables
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();
    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    // get unique identifier
    uniqueIDKeySet.keySetName = KeySets.KEY_SET_RECEIPTNUMBER;
    return uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet);
  }

}
