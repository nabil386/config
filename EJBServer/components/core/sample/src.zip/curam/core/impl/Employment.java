/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2003, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.OCCUPATIONTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.events.EMPLOYMENT;
import curam.core.fact.EmploymentFactory;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmploymentAndIndustryTypeDetailsList;
import curam.core.struct.EmploymentAndStatusReadMultiKey;
import curam.core.struct.EmploymentDtls;
import curam.core.struct.EmploymentKey;
import curam.core.struct.EmploymentSnapshotDtls;
import curam.core.struct.EmploymentSnapshotKey;
import curam.message.SUMMARYDETAILS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * A person employment record.
 *
 */
public abstract class Employment extends curam.core.base.Employment implements
  ParticipantEvidenceInterface {

  protected class EmploymentCache {

    public EmploymentCache() {

      map = new HashMap<Long, EmploymentDtls>();
      transactionID = 0;
    }

    HashMap<Long, EmploymentDtls> map;

    int transactionID;
  }

  protected static ThreadLocal<EmploymentCache> cachedReadDetailsTL = new ThreadLocal<EmploymentCache>();

  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls of entity to remove
   */
  @Override
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    final EmploymentKey employmentKey = new EmploymentKey();

    // Set entity key for modify
    employmentKey.employmentID = key.evidenceID;

    // Modify details
    modify(employmentKey, (EmploymentDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Inserts employment evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((EmploymentDtls) dtls);

    eiEvidenceKey.evidenceID = ((EmploymentDtls) dtls).employmentID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYMENT;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * reads all Employment Entities by its Parent ID
   *
   * @param key EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  @Override
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey EIEvidenceKey
   * @param evKeyList EIEvidenceKeyList
   * @param mode Validate Mode
   */
  @Override
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadDetailsTL
   */
  protected void clearCaches() {

    EmploymentCache cache = cachedReadDetailsTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new EmploymentCache();
      cachedReadDetailsTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param caseKey
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the AttributedDateDetails
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    final AttributedDateDetails retAttributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final EmploymentDtls employmentDtls = read(evKey);

    // END, CR00240667

    retAttributedDateDetails.fromDate = employmentDtls.fromDate;
    retAttributedDateDetails.toDate = employmentDtls.toDate;

    return retAttributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected EmploymentDtls read(EIEvidenceKey key) throws AppException,
      InformationalException {

    final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();

    final EmploymentKey employmentKey = new EmploymentKey();
    EmploymentDtls employmentDtls = new EmploymentDtls();

    employmentKey.employmentID = key.evidenceID;

    // BEGIN, CR00067890, POH
    // read employment details
    try {
      employmentDtls = employmentObj.read(employmentKey);
    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot employment entity
      final EmploymentSnapshotKey employmentSnapshotKey = new EmploymentSnapshotKey();

      final curam.core.intf.EmploymentSnapshot employmentSnapshotObj = curam.core.fact.EmploymentSnapshotFactory.newInstance();

      // populate the employment snapshot key with
      // passed in parameter
      employmentSnapshotKey.employmentSnapshotID = key.evidenceID;

      // read employment snapshot details
      final EmploymentSnapshotDtls employmentSnapshotDtls = employmentSnapshotObj.read(
        employmentSnapshotKey);

      employmentDtls.assign(employmentSnapshotDtls);
    }
    // END, CR00067890
    return employmentDtls;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return Evidence details to be displayed on the list page
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00142957, MC
    // ConcernRole variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // END, CR00142957

    // BEGIN, CR00060473, MMC
    // manipulation variables
    try {
      // Employment entity key
      final EmploymentKey employmentKey = new EmploymentKey();

      // Read the Employment entity to get display details
      employmentKey.employmentID = key.evidenceID;

      final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();
      final EmploymentDtls employmentDtls = employmentObj.read(employmentKey);

      // Set the start / end dates
      eiFieldsForListDisplayDtls.startDate = employmentDtls.fromDate;
      eiFieldsForListDisplayDtls.endDate = employmentDtls.toDate;

      // BEGIN, CR00142957, MC
      // ConcernRole variables
      concernRoleKey.concernRoleID = employmentDtls.employerConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      // END, CR00142957

      // Set the summary details.
      // BEGIN, CR00241068, CD
      final LocalisableString message = new LocalisableString(
        SUMMARYDETAILS.EMPLOYMENT);

      message.arg(concernRoleDtls.concernRoleName);
      message.arg(
        CodeTable.getOneItem(OCCUPATIONTYPE.TABLENAME,
        employmentDtls.occupationType));

      eiFieldsForListDisplayDtls.summary = message.getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00241068
    } // If the Employment record is not found, then the ID passed in must
    // belong to an EmploymentSnapshot record
    catch (final RecordNotFoundException rnfe) {

      // Read the EmploymentSnapshot details
      final curam.core.struct.EmploymentSnapshotKey employmentSnapshotKey = new curam.core.struct.EmploymentSnapshotKey();

      employmentSnapshotKey.employmentSnapshotID = key.evidenceID;
      final curam.core.struct.EmploymentSnapshotDtls employmentSnapshotDtls = curam.core.fact.EmploymentSnapshotFactory.newInstance().read(
        employmentSnapshotKey);

      // Set the start/end dates
      eiFieldsForListDisplayDtls.startDate = employmentSnapshotDtls.fromDate;
      eiFieldsForListDisplayDtls.endDate = employmentSnapshotDtls.toDate;

      // BEGIN, CR00142957, MC
      // ConcernRole variables
      concernRoleKey.concernRoleID = employmentSnapshotDtls.employerConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      // END, CR00142957

      // Set the summary details.
      // BEGIN, CR00241068, CD
      final LocalisableString message = new LocalisableString(
        SUMMARYDETAILS.EMPLOYMENT);

      message.arg(concernRoleDtls.concernRoleName);
      message.arg(
        CodeTable.getOneItem(OCCUPATIONTYPE.TABLENAME,
        employmentSnapshotDtls.occupationType));

      eiFieldsForListDisplayDtls.summary = message.getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00241068
    }

    // END, CR00060473

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey Key for parent
   *
   * @return eiEvidenceKey - key for inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((EmploymentDtls) dtls);

    eiEvidenceKey.evidenceID = ((EmploymentDtls) dtls).employmentID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYMENT;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls Object containing details of entity
   */
  @Override
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Employment entity key
    final EmploymentKey employmentKey = new EmploymentKey();

    // Set entity key for modify
    employmentKey.employmentID = key.evidenceID;

    // Modify details
    modify(employmentKey, (EmploymentDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract
   * method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return the Object with the readEvidence details
   */
  @Override
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // employment object
    final curam.core.intf.EmploymentSnapshot employmentSnapshotObj = curam.core.fact.EmploymentSnapshotFactory.newInstance();

    final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();
    EmploymentDtls employmentDtls = new EmploymentDtls();

    // BEGIN, CR00060473, MMC
    // Attempt to read the record using the evidenceID passed in, if a record is
    // found
    // return the details as an object.
    // If no record is found attempt to read the snapshot record using the
    // passed in
    // evidenceID.
    // If a record is found return the details as an object.

    try {
      final EmploymentKey employmentKey = new EmploymentKey();

      employmentKey.employmentID = key.evidenceID;
      employmentDtls = employmentObj.read(employmentKey);

      return employmentDtls;
    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot employment entity
      final curam.core.struct.EmploymentSnapshotKey employmentSnapshotKey = new curam.core.struct.EmploymentSnapshotKey();

      employmentSnapshotKey.employmentSnapshotID = key.evidenceID;

      final curam.core.struct.EmploymentSnapshotDtls employmentSnapshotDtls = employmentSnapshotObj.read(
        employmentSnapshotKey);

      employmentDtls.assign(employmentSnapshotDtls);
      return employmentDtls;
    }
    // END, CR00060473

  }

  // __________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details Contains entity details
   */
  @Override
  public void insert(EmploymentDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // __________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key Contains key to access entity details
   * @param details Contains details to modify
   */
  @Override
  public void modify(EmploymentKey key, EmploymentDtls details)
    throws AppException, InformationalException {

    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // __________________________________________________________________________
  /**
   * Sets up details for the search to ensure the correct details are always
   * returned
   *
   * @param key details for the search
   */
  @Override
  protected void presearchActiveEmploymentsByConcernRole(
    EmploymentAndStatusReadMultiKey key) throws AppException,
      InformationalException {

    key.status = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchEmploymentsAndIndustryByConcernRoleID
   */
  @Override
  public EmploymentAndIndustryTypeDetailsList readEmploymentsAndIndustryByConcernRoleID(
    curam.core.struct.EmploymentReadMultiKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return EmploymentFactory.newInstance().searchEmploymentsAndIndustryByConcernRoleID(
      key);
  }

  // __________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details details for the employment record.
   */
  @Override
  protected void postinsert(EmploymentDtls details) throws AppException,
      InformationalException {

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = EMPLOYMENT.INSERT_EMPLOYMENT;
    // END, CR00047242

    event.primaryEventData = details.employmentID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // __________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key employment key to modify
   * @param details details for the employment record.
   */
  @Override
  protected void postmodify(EmploymentKey key, EmploymentDtls details)
    throws AppException, InformationalException {

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = EMPLOYMENT.MODIFY_EMPLOYMENT;
    // END, CR00047242

    event.primaryEventData = key.employmentID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the employment entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param key the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  @Override
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    final EIEvidenceKey retEIEvidenceKey = new EIEvidenceKey();
    final curam.core.intf.EmploymentSnapshot employmentSnapshotObj = curam.core.fact.EmploymentSnapshotFactory.newInstance();

    final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();

    final EmploymentKey employmentKey = new EmploymentKey();

    employmentKey.employmentID = key.evidenceID;
    final EmploymentDtls employmentDtls = employmentObj.read(employmentKey);
    final EmploymentSnapshotDtls employmentSnapshotDtls = new EmploymentSnapshotDtls();

    employmentSnapshotDtls.assign(employmentDtls);
    employmentSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    employmentSnapshotObj.insert(employmentSnapshotDtls);

    retEIEvidenceKey.evidenceID = employmentSnapshotDtls.employmentSnapshotID;
    retEIEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYMENT;

    return retEIEvidenceKey;

  }

  // __________________________________________________________________________
  /**
   * Raise a post remove event
   *
   * @param key employment key to remove
   */
  @Override
  protected void postremove(EmploymentKey key) throws AppException,
      InformationalException {

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = EMPLOYMENT.REMOVE_EMPLOYMENT;
    // END, CR00047242

    event.primaryEventData = key.employmentID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // BEGIN, CR00059697, SK

  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing a
   * evidenceID/evidenceType pair.
   */
  @Override
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060375, MMC
    // return struct
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;

    // BEGIN, CR00065999, JPG
    final EmploymentAndStatusReadMultiKey employmentAndStatusReadMultiKey = new EmploymentAndStatusReadMultiKey();

    final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();

    // populate the employment key with passed in parameter
    employmentAndStatusReadMultiKey.concernRoleID = key.concernRoleID;
    employmentAndStatusReadMultiKey.status = RECORDSTATUS.NORMAL;

    // read list of employment records for concernRole
    final curam.core.struct.EmploymentReadMultiDtlsList employmentReadMultiDtlsList = employmentObj.searchActiveEmploymentsByConcernRole(
      employmentAndStatusReadMultiKey);

    // END, CR00065999

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < employmentReadMultiDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = employmentReadMultiDtlsList.dtls.item(i).employmentID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.EMPLOYMENT;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    return eiEvidenceKeyList;
    // END, CR00060375, MMC
  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute
   * that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the
   * attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  @Override
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key,
    Object dtls) throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    final ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create EmploymentDtls structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    EmploymentDtls employmentCompareDtls1 = new EmploymentDtls();
    final EmploymentDtls employmentCompareDtls2 = new EmploymentDtls();

    try {

      final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();

      final EmploymentKey employmentKey = new EmploymentKey();

      employmentKey.employmentID = key.evidenceID;

      // read Employment details
      employmentCompareDtls1 = employmentObj.read(employmentKey);

      // Populate the Employment struct that will be compared against
      employmentCompareDtls2.assign((EmploymentDtls) dtls);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot Employment entity
      final curam.core.intf.EmploymentSnapshot employmentSnapshotObj = curam.core.fact.EmploymentSnapshotFactory.newInstance();

      final EmploymentSnapshotKey employmentSnapshotKey = new EmploymentSnapshotKey();

      // populate the Employment snapshot key with passed in parameter
      employmentSnapshotKey.employmentSnapshotID = key.evidenceID;

      // Read the Employment snapshot details
      employmentCompareDtls2.assign(
        employmentSnapshotObj.read(employmentSnapshotKey));

      // Populate the Employment struct that will be compared against
      employmentCompareDtls1.assign((EmploymentDtls) dtls);
    }

    if (employmentCompareDtls1.employmentID
      != employmentCompareDtls2.employmentID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.EMPLOYMENTID);
    }
    if (employmentCompareDtls1.concernRoleID
      != employmentCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!employmentCompareDtls1.fromDate.equals(employmentCompareDtls2.fromDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.FROMDATE);
    }
    if (!employmentCompareDtls1.toDate.equals(employmentCompareDtls2.toDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TODATE);
    }
    if (employmentCompareDtls1.employerConcernRoleID
      != employmentCompareDtls2.employerConcernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.EMPLOYERCONCERNROLEID);
    }
    if (!employmentCompareDtls1.status.equals(employmentCompareDtls2.status)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUS);
    }
    if (!employmentCompareDtls1.occupationType.equals(
      employmentCompareDtls2.occupationType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.OCCUPATIONTYPE);
    }
    if (employmentCompareDtls1.primaryCurrentInd
      != employmentCompareDtls2.primaryCurrentInd) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYCURRENTIND);
    }
    if (!employmentCompareDtls1.comments.equals(employmentCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of
   * an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  @Override
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set a indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // END, CR00069014
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return read(evKey).toDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return read(evKey).fromDate;
    // END, CR00240667
  }
  // END, CR002204022
}
