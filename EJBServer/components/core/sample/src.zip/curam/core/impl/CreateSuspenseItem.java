/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.SuspenseAccountDtls;
import curam.core.struct.SuspenseItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code for creating suspense item.
 *
 */
public abstract class CreateSuspenseItem extends curam.core.base.CreateSuspenseItem {

  // ___________________________________________________________________________
  /**
   * To add an item onto the SuspenseAccount based on the details specified on
   * input.
   *
   * @param suspenseItemDtls Suspense item details
   */
  @Override
  public void createSuspenseAccountItem(SuspenseItemDetails suspenseItemDtls)
    throws AppException, InformationalException {

    // suspenseAccount manipulation variables
    final SuspenseAccountDtls suspenseAccountDtls = new SuspenseAccountDtls();
    final curam.core.intf.SuspenseAccount suspenseAccountObj = curam.core.fact.SuspenseAccountFactory.newInstance();

    // set suspenseAccountDtls
    suspenseAccountDtls.suspenseAccountID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
    suspenseAccountDtls.assign(suspenseItemDtls);
    // BEGIN, CR00407584, SS
    suspenseAccountDtls.originIBAN = suspenseItemDtls.originIBANOpt;
    suspenseAccountDtls.originBIC = suspenseItemDtls.originBICOpt;
    suspenseAccountDtls.destIBAN = suspenseItemDtls.destIBANOpt;
    suspenseAccountDtls.destBIC = suspenseItemDtls.destBICOpt;
    // END, CR00407584
    suspenseAccountDtls.pmtRecInstrumentID = 0;
    suspenseAccountDtls.concernRoleID = 0;
    // BEGIN ,hARP 48658, KH
    suspenseAccountDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // set datePosted to blank date
    suspenseAccountDtls.datePosted = curam.util.type.Date.kZeroDate;
    suspenseAccountDtls.statusCode = curam.codetable.SUSPENSEITEMSTATUS.UNASSIGNED;

    // insert suspenseAccount
    suspenseAccountObj.insert(suspenseAccountDtls);

  }

}
