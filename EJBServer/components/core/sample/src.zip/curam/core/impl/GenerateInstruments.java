/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.BATCHPROCESSNAME;
import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.sl.infrastructure.propagator.impl.CERMetaDataLoadUtility;
import curam.core.struct.BatchProcessChunkDtlsList;
import curam.core.struct.BatchProcessDtls;
import curam.core.struct.BatchProcessStreamKey;
import curam.core.struct.BatchProcessingIDList;
import curam.core.struct.BatchProcessingResult;
import curam.core.struct.ChunkMainParameters;
import curam.core.struct.GenerateInstrumentsKey;
import curam.core.struct.GetDetailsForGenerateInstrumentsKey;
import curam.core.struct.ProcessILIsKey;
import curam.core.struct.ProcessPRVCategoryCounters;
import curam.core.struct.ProcessProdDeliveryCounters;
import curam.core.struct.ProcessTaxCounters;
import curam.core.struct.ProcessThirdPartyDedCounters;
import curam.core.struct.ProcessUtilityCounters;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.type.Blob;
import java.util.StringTokenizer;


/**
 * Batch module to select unprocessed ILIs and process each one accordingly.
 *
 */
public abstract class GenerateInstruments extends curam.core.base.GenerateInstruments {

  /**
   * The initial value used for the keySet used for the chunks
   */
  protected static final int kFirstKeyValue = 1;

  protected static final int kChunkSize;

  protected static final boolean kDontRunStream;

  protected static final int kChunkKeyReadWait;

  protected static final int kUnProcessedChunkReadWait;

  protected static final boolean kProcessUnProcessedChunks;

  // BEGIN, CR00071077, GM
  protected static String eRPAdapterEnabledErrMsg = CuramConst.gkEmpty;
  // END, CR00071077

  // ___________________________________________________________________________
  /**
   * Static initialization which looks up the Batch Process Read Wait
   * and sets the static member used to control the processing
   */
  static {

    // Get the value of the GenerateInstruments Chunk Size environment variable
    final String chunkSize = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENERATEINSTRUMENTS_CHUNK_SIZE);

    // If it's not set, use the default
    if (chunkSize == null) {

      kChunkSize = EnvVars.ENV_GENERATEINSTRUMENTS_CHUNK_SIZE_DEFAULT;

    } else {

      // Convert string value to integer
      kChunkSize = Integer.parseInt(chunkSize);

    }

    // Get the value of the GenerateInstruments Don't Run Stream environment
    // variable
    kDontRunStream = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_GENERATEINSTRUMENTS_DONT_RUN_STREAM);

    // Get the value of the GenerateInstruments Chunk Key read wait environment
    // variable
    final String chunkKeyReadWait = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENERATEINSTRUMENTS_CHUNK_KEY_WAIT_INTERVAL);

    // If it's not set, use the default
    if (chunkKeyReadWait == null) {

      kChunkKeyReadWait = EnvVars.ENV_GENERATEINSTRUMENTS_CHUNK_KEY_WAIT_INTERVAL_DEFAULT;

    } else {

      // Convert string value to integer
      kChunkKeyReadWait = Integer.parseInt(chunkKeyReadWait);

    }

    // Get the value of the GenerateInstruments UnProcessed Chunk read wait
    // environment variable
    final String unProcessedChunkReadWait = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENERATEINSTRUMENTS_UNPROCESSED_CHUNK_WAIT_INTERVAL);

    // If it's not set, use the default
    if (unProcessedChunkReadWait == null) {

      kUnProcessedChunkReadWait = EnvVars.ENV_GENERATEINSTRUMENTS_UNPROCESSED_CHUNK_WAIT_INTERVAL_DEFAULT;

    } else {

      // Convert string value to integer
      kUnProcessedChunkReadWait = Integer.parseInt(unProcessedChunkReadWait);

    }

    // Get the value of the GenerateInstruments process unprocessed Chunks
    // environment variable
    kProcessUnProcessedChunks = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_GENERATEINSTRUMENTS_PROCESS_UNPROCESSED_CHUNKS);

  }

  // ___________________________________________________________________________
  /**
   * To select unprocessed ILIs and process each one accordingly.
   */
  @Override
  public void processInstructionLineItemsDue(
    GenerateInstrumentsKey generateInstrumentsKey) throws AppException,
      InformationalException {

    // BEGIN, CR00073939, JI

    // If the ERP Adapter is enabled do not execute the batch job
    // and write an error message into the log file
    // BEGIN, CR00080249, CW
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()) {
      // END, CR00080249

      final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

      curamBatchObj.setStartTime();
      // BEGIN, CR00077050, CW
      // Construct the error message
      eRPAdapterEnabledErrMsg = // BEGIN, CR00163471, JC
        curam.message.EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_ENABLED_BATCH_JOB.getMessageText(
        ProgramLocale.getDefaultServerLocale())
          // END, CR00163471, JC
          + CuramConst.gkNewLine
          + CuramConst.gkNewLine;
      // END, CR00076996
      // END, CR00077050
      final BatchProcessDtls batchProcessDtls = new BatchProcessDtls();
      final BatchProcessChunkDtlsList chunkDtlsList = new BatchProcessChunkDtlsList();

      batchProcessDtls.startDateTime = curamBatchObj.startTime;
      // BEGIN, CR00071077, GM
      sendBatchReport(CuramConst.gkStringZero, batchProcessDtls, chunkDtlsList,
        chunkDtlsList);
      // END, CR00071077

      // If the ERP Adapter is not enabled run the batch job
    } else {
      // END, CR00073939

      // BEGIN, CR00390475, SD
      final CERMetaDataLoadUtility loadObj = new CERMetaDataLoadUtility();

      loadObj.loadCERRuleSetCache();
      // END, CR00390475

      final BatchStreamHelper batchStreamHelper = new BatchStreamHelper();
      BatchProcessingIDList batchProcessingIDList;
      final ChunkMainParameters chunkMainParameters = new ChunkMainParameters();
      final curam.core.intf.GenerateInstrumentsStream generateInstrumentsStreamObj = curam.core.fact.GenerateInstrumentsStreamFactory.newInstance();
      final GenerateInstrumentsStreamWrapper generateInstrumentsStreamWrapper = new GenerateInstrumentsStreamWrapper(
        generateInstrumentsStreamObj);
      final GenerateInstrumentsWrapper generateInstrumentsWrapper = new GenerateInstrumentsWrapper(
        this);
      final curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
      final GetDetailsForGenerateInstrumentsKey getDetailsForGenerateInstrumentsKey = new GetDetailsForGenerateInstrumentsKey();

      // register the security implementation
      SecurityImplementationFactory.register();

      // Set the start time of the batch main
      batchStreamHelper.setStartTime();

      if (generateInstrumentsKey.instanceID.length() == 0) {

        generateInstrumentsKey.instanceID = BATCHPROCESSNAME.GENERATE_INSTRUMENTS;

      }

      // identify records to process
      batchProcessingIDList = instructionLineItemObj.getDetailsForGenerateInstruments(
        getDetailsForGenerateInstrumentsKey);

      chunkMainParameters.chunkSize = kChunkSize;
      chunkMainParameters.dontRunStream = kDontRunStream;
      chunkMainParameters.processUnProcessedChunks = kProcessUnProcessedChunks;
      chunkMainParameters.startChunkKey = kFirstKeyValue;
      chunkMainParameters.unProcessedChunkReadWait = kUnProcessedChunkReadWait;

      batchStreamHelper.runChunkMain(generateInstrumentsKey.instanceID,
        generateInstrumentsKey, generateInstrumentsWrapper,
        batchProcessingIDList, chunkMainParameters,
        generateInstrumentsStreamWrapper);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method takes string form of the result of the processing and turns it
   * back into a struct
   *
   * @param resultString The results as a string
   *
   * @return The struct form of the results
   */
  @Override
  public ProcessProdDeliveryCounters decodeProcessChunkResult(
    String resultString) throws AppException, InformationalException {

    final ProcessProdDeliveryCounters processProdDeliveryCounters = new ProcessProdDeliveryCounters();

    final StringTokenizer st = new StringTokenizer(resultString);
    int elementNumber = 0;

    while (st.hasMoreTokens()) {

      elementNumber++;
      switch (elementNumber) {
      case 1:
        processProdDeliveryCounters.countILIsProcessed = Integer.parseInt(
          st.nextToken());
        break;

      case 2:
        processProdDeliveryCounters.countIntILIsCreated = Integer.parseInt(
          st.nextToken());
        break;

      case 3:
        processProdDeliveryCounters.countLbyInstrumentsCreated = Integer.parseInt(
          st.nextToken());
        break;

      case 4:
        processProdDeliveryCounters.countPmtInstructionsCreated = Integer.parseInt(
          st.nextToken());
        break;

      case 5:
        processProdDeliveryCounters.countPmtInstrumentsCreated = Integer.parseInt(
          st.nextToken());
        break;

      case 6:
        processProdDeliveryCounters.countPmtRecvdInstructionsCreated = Integer.parseInt(
          st.nextToken());
        break;

      case 7:
        processProdDeliveryCounters.countSurILIsCreated = Integer.parseInt(
          st.nextToken());
        break;

      case 9:
        processProdDeliveryCounters.casesSkippedCount = Integer.parseInt(
          st.nextToken());
        break;

      default:
        st.nextToken();
        break;
      }

    }

    return processProdDeliveryCounters;
  }

  // ___________________________________________________________________________
  /**
   * This method composes and sends the batch report for this batch program.
   *
   * @param instanceID
   * @param batchProcessDtls
   * @param processedBatchProcessChunkDtlsList
   * @param unprocessedBatchProcessChunkDtlsList
   */
  @Override
  public void sendBatchReport(String instanceID,
    BatchProcessDtls batchProcessDtls,
    BatchProcessChunkDtlsList processedBatchProcessChunkDtlsList,
    BatchProcessChunkDtlsList unprocessedBatchProcessChunkDtlsList)
    throws AppException, InformationalException {

    // curamBatch manipulation variable
    final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

    ProcessProdDeliveryCounters processProdDeliveryCounters;

    // emailMessage stringBuffer variables
    final int kReasonableMessageLength = 4096;
    final StringBuffer emailMessage = new StringBuffer(kReasonableMessageLength);

    // BEGIN, CR00073939, JI
    // If the ERP Adapter is enabled it will append an error message
    emailMessage.append(eRPAdapterEnabledErrMsg);
    // END, CR00073939

    // variables to keep totals of instructions/instruments/ILIs created
    int totalPmtInstructionsCreated = 0;
    int totalSurILIsCreated = 0;
    int totalIntILIsCreated = 0;
    int totalLbyInstrumentsCreated = 0;
    int totalPmtInstrumentsCreated = 0;
    int totalPmtRecvdInstructionsCreated = 0;
    int totalILIsProcessed = 0;
    int totalNomineesSkipped = 0;
    final long totalNumberOfUnprocessedChunks = unprocessedBatchProcessChunkDtlsList.dtls.size();

    // For each processed chunk, gather the stats
    for (int i = 0; i < processedBatchProcessChunkDtlsList.dtls.size(); i++) {

      processProdDeliveryCounters = decodeProcessChunkResult(
        processedBatchProcessChunkDtlsList.dtls.item(i).resultSummary);
      totalPmtInstructionsCreated += processProdDeliveryCounters.countPmtInstructionsCreated;
      totalSurILIsCreated += processProdDeliveryCounters.countSurILIsCreated;
      totalIntILIsCreated += processProdDeliveryCounters.countIntILIsCreated;
      totalLbyInstrumentsCreated += processProdDeliveryCounters.countLbyInstrumentsCreated;
      totalPmtInstrumentsCreated += processProdDeliveryCounters.countPmtInstrumentsCreated;
      totalPmtRecvdInstructionsCreated += processProdDeliveryCounters.countPmtRecvdInstructionsCreated;
      totalILIsProcessed += processProdDeliveryCounters.countILIsProcessed;
      totalNomineesSkipped += processProdDeliveryCounters.casesSkippedCount;

    }

    if (totalNumberOfUnprocessedChunks > 0) {

      final AppException errChunksSkippedText = new AppException(
        curam.message.BPOGENERATEINSTRUMENTS.ERR_CHUNKS_SKIPPED);

      errChunksSkippedText.arg(totalNumberOfUnprocessedChunks);
      errChunksSkippedText.arg(totalNumberOfUnprocessedChunks * kChunkSize);

      // BEGIN, CR00163236, CL
      // append to StringBuffer
      emailMessage.append(CuramConst.gkNewLine).append(errChunksSkippedText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

    }

    if (totalNomineesSkipped > 0) {

      final AppException infTotalSkippedNomineeText = new AppException(
        curam.message.BPOGENERATEINSTRUMENTS.INF_NOMINEE_RECORDS_SKIPPED);

      infTotalSkippedNomineeText.arg(totalNomineesSkipped);

      // BEGIN, CR00163236, CL
      // append to StringBuffer
      emailMessage.append(CuramConst.gkNewLine).append(infTotalSkippedNomineeText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

    }

    // Create the text strings to send to the email report
    final AppException infTotalILIText = new AppException(
      curam.message.BPOGENERATEINSTRUMENTS.INF_ILI_RECORDS_PROCESSED);

    infTotalILIText.arg(totalILIsProcessed);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalILIText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalNewSurILIText = new AppException(
      curam.message.BPOGENERATEINSTRUMENTS.INF_NEWSURILI_RECORDS_CREATED);

    infTotalNewSurILIText.arg(totalSurILIsCreated);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalNewSurILIText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalInterestILIText = new AppException(
      curam.message.BPOGENERATEINSTRUMENTS.INF_NEWINTERESTILI_RECORDS_CREATED);

    infTotalInterestILIText.arg(totalIntILIsCreated);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalInterestILIText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalPmtInstrctionText = new AppException(
      curam.message.BPOGENERATEINSTRUMENTS.INF_TOTAL_PMTINSTRUCTIONS_CREATED);

    infTotalPmtInstrctionText.arg(totalPmtInstructionsCreated);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalPmtInstrctionText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalPmtText = new AppException(
      curam.message.BPOGENERATEINSTRUMENTS.INF_TOTAL_PMTINSTRUMENTS_CREATED);

    infTotalPmtText.arg(totalPmtInstrumentsCreated);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalPmtText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalPmtRecvdText = new AppException(
      curam.message.GENERALBATCH.INF_TOTAL_PMTRECVDINSTRUCTIONS_CREATED);

    infTotalPmtRecvdText.arg(totalPmtRecvdInstructionsCreated);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalPmtRecvdText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalLbyText = new AppException(
      curam.message.BPOGENERATEINSTRUMENTS.INF_TOTAL_LBYINSTRUMENTS_CREATED);

    infTotalLbyText.arg(totalLbyInstrumentsCreated);

    // BEGIN, CR00163236, CL
    // append to buffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalLbyText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    curamBatchObj.emailMessage = emailMessage.toString();

    // constructing the Email Subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOGENERATEINSTRUMENTS.INF_GENERATEINSTRUMENTS_SUB);

    // set output file id
    curamBatchObj.outputFileID = // BEGIN, CR00163471, JC
      curam.message.BPOGENERATEINSTRUMENTS.INF_GEN_INSTRUMENTS_ID.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163471, JC

    // set the elapsed time
    curamBatchObj.setStartTime(batchProcessDtls.startDateTime);
    curamBatchObj.setEndTime();

    // send email
    curamBatchObj.sendEmail();

  }

  // ___________________________________________________________________________
  /**
   * Do the additional processing as part of the main batch program. This
   * processes payments due to utilities & payments received.
   *
   * @param batchProcessStreamKey The key for this processing
   * @param batchProcessParameters Details of the parameters passed into this
   * batch program
   *
   * @return The details of the records processed
   */
  @Override
  public BatchProcessingResult doExtraProcessing(
    BatchProcessStreamKey batchProcessStreamKey, Blob batchProcessParameters)
    throws AppException, InformationalException {

    final curam.core.intf.ProcessInstructionLineItem processInstructionLineItemObj = curam.core.fact.ProcessInstructionLineItemFactory.newInstance();
    final BatchProcessingResult batchProcessingResult = new BatchProcessingResult();
    final ProcessProdDeliveryCounters processProdDeliveryCounters = new ProcessProdDeliveryCounters();
    final curam.core.intf.GenerateInstrumentsStream generateInstrumentsStreamObj = curam.core.fact.GenerateInstrumentsStreamFactory.newInstance();

    // process Utility ILIs due
    final ProcessUtilityCounters processUtilityCounters = new ProcessUtilityCounters();

    processInstructionLineItemObj.processUtilityILIsDue(processUtilityCounters);

    // Convert the results into the correct format
    processProdDeliveryCounters.countILIsProcessed = processUtilityCounters.countILIsProcessed;
    processProdDeliveryCounters.countPmtInstructionsCreated = processUtilityCounters.countPmtInstructionsCreated;

    // process Payment Received Category ILIs
    final ProcessPRVCategoryCounters processPRVCategoryCounters = new ProcessPRVCategoryCounters();

    processInstructionLineItemObj.processPRVCategoryILI(
      processPRVCategoryCounters);

    // increment counters
    processProdDeliveryCounters.countPmtRecvdInstructionsCreated += processPRVCategoryCounters.countPmtRecvdInstructionsCreated;
    processProdDeliveryCounters.countILIsProcessed += processPRVCategoryCounters.countILIsProcessed;

    final ProcessThirdPartyDedCounters processThirdPartyDedCounters = new ProcessThirdPartyDedCounters();

    // Process Third Party Deduction ILIs due
    processInstructionLineItemObj.processThirdPartyDedILIsDue(
      processThirdPartyDedCounters);

    // Increment counters
    processProdDeliveryCounters.countILIsProcessed = processThirdPartyDedCounters.countILIsProcessed;
    processProdDeliveryCounters.countPmtInstructionsCreated = processThirdPartyDedCounters.countPmtInstructionsCreated;

    // BEGIN, CR00091298, PMD
    final ProcessTaxCounters processTaxCounters = new ProcessTaxCounters();

    // Process Tax ILIs due
    processInstructionLineItemObj.processTaxILIsDue(new ProcessILIsKey(),
      processTaxCounters);

    // Include the totals for Tax ILIs
    processProdDeliveryCounters.countILIsProcessed += processTaxCounters.countILIsProcessed;
    processProdDeliveryCounters.countPmtInstructionsCreated += processTaxCounters.countPmtInstructionsCreated;
    // END, CR00091298

    batchProcessingResult.result = generateInstrumentsStreamObj.stringizeProcessProdDeliveryCounters(
      processProdDeliveryCounters);

    return batchProcessingResult;
  }

}
