/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.AlternateNameDtls;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.CustomerLoginDetails;
import curam.core.struct.CustomerValidDetails;
import curam.core.struct.PersonAltSearchKey;
import curam.core.struct.PersonDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Implements the customer's login.
 *
 */
public abstract class CustomerLogin extends curam.core.base.CustomerLogin {

  // ___________________________________________________________________________
  /**
   * This process validates the information provided by the customer and
   * returns the customer's name and concernRoleID.
   *
   * @param loginDetails Reference number and PIN
   *
   * @return Returned reference number and full name
   */
  @Override
  public CustomerValidDetails validateCustomer(
    CustomerLoginDetails loginDetails) throws AppException,
      InformationalException {

    // customerValidDetails variable
    final CustomerValidDetails customerValidDetails = new CustomerValidDetails();

    // person manipulation variables
    final curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();
    final PersonAltSearchKey personAltSearchKey = new PersonAltSearchKey();
    PersonDtls personDtls;

    // alternateName manipulation variables
    final curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();
    AlternateNameDtls alternateNameDtls;
    final AlternateNameKey alternateNameKey = new AlternateNameKey();

    // get customer information from database
    personAltSearchKey.assign(loginDetails);

    // read person by alternateID
    personDtls = personObj.readByAlternateID(personAltSearchKey);

    // return concern role ID and Full name if correct PIN entered
    // otherwise throw an error
    if (!personDtls.pinNumber.equals(loginDetails.pinNumber)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERALCONCERN.ERR_PERSON_XRV_PIN_INCORRECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);

    } else {

      // set key to read alternateName
      alternateNameKey.alternateNameID = personDtls.primaryAlternateNameID;

      // do the alternate name read
      alternateNameDtls = alternateNameObj.read(alternateNameKey);

      customerValidDetails.assign(personDtls);
      customerValidDetails.assign(alternateNameDtls);
    }

    return customerValidDetails;
  }

}
