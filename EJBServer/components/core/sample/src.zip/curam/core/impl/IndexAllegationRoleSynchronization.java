/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.ALLEGATIONROLE;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.entity.struct.AllegationRoleDtls;
import curam.core.sl.entity.struct.AllegationRoleKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when
 * modifications are made to the Allegation Role entity
 */
public abstract class IndexAllegationRoleSynchronization extends curam.core.base.IndexAllegationRoleSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the allegation role entity insert operation
   *
   * @param dtls allegation role details
   */
  @Override
  public void insert(final AllegationRoleDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALLEGATIONROLE.INSERT_ALLEGATION_ROLE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALLEGATIONROLE.INSERT_ALLEGATION_ROLE.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.allegationRoleID;
    // BEGIN, CR00221505, ZV
    synchronizeEventsDetails.secondaryEventData = dtls.allegationID;
    // END, CR00221505

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the allegation role entity modify operation
   *
   * @param key allegation role identifier
   * @param dtls allegation role details
   */
  @Override
  public void modify(final AllegationRoleKey key,
    final AllegationRoleDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALLEGATIONROLE.MODIFY_ALLEGATION_ROLE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALLEGATIONROLE.MODIFY_ALLEGATION_ROLE.eventType;
    synchronizeEventsDetails.primaryEventData = key.allegationRoleID;
    // BEGIN, CR00221505, ZV
    synchronizeEventsDetails.secondaryEventData = dtls.allegationID;
    // END, CR00221505

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // BEGIN, CR00221505, ZV
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the allegation role entity remove operation
   *
   * @param key allegation role identifier
   * @param dtls allegation role details
   */
  @Override
  public void remove(final AllegationRoleKey key,
    final AllegationRoleDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = ALLEGATIONROLE.REMOVE_ALLEGATION_ROLE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = ALLEGATIONROLE.REMOVE_ALLEGATION_ROLE.eventType;
    synchronizeEventsDetails.primaryEventData = key.allegationRoleID;
    synchronizeEventsDetails.secondaryEventData = dtls.allegationID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }
  // END, CR00221505

}
