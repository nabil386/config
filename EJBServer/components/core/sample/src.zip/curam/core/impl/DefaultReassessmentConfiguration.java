/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.ProductDtls;


/**
 * The default implementation of the Reassessment configuration.
 */
public class DefaultReassessmentConfiguration implements
  IReassessmentConfiguration {

  // ___________________________________________________________________________
  /**
   * This implementation assumes that the reassessment processing for cases
   * based
   * on most products will not require access to the previous decisions on the
   * case
   * and therefore will not require to be reassessed forward.
   *
   * @param caseHeaderDtls The details of the case which is being reassessed.
   *
   * @return <code>false</code>
   */
  @Override
  public boolean isReassessToLastActiveDecisionEnabled(
    final CaseHeaderDtls caseHeaderDtls, final ProductDtls productDtls) {

    // The default implementation will not reassess forward..
    return false;
  }

}
