/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2003, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.CASECOMMUNICATIONTYPE;
import curam.codetable.CASESUSPENDREASON;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUNSUSPENDREASON;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.sl.entity.fact.LanguageLocaleMapFactory;
import curam.core.sl.entity.struct.LanguageLocaleMapDtls;
import curam.core.sl.entity.struct.LanguageLocaleMapKey;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AlternateIDAddressNameAndTypeDetails;
import curam.core.struct.CaseContractContentsDtlsList;
import curam.core.struct.CaseContractDocumentKey;
import curam.core.struct.CaseContractTaskDtls;
import curam.core.struct.CaseEventCaseIDAndTypeKey;
import curam.core.struct.CaseEventDtlsList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReactivationDtls;
import curam.core.struct.CaseReactivationKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleDocumentDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ContentsByContractIDKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.GetCaseClosureSupplierKey;
import curam.core.struct.GetCaseEventData;
import curam.core.struct.GetResourcesDetails;
import curam.core.struct.LocationDtls;
import curam.core.struct.LocationKey;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ProFormaDocumentData;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.ReadCaseClosureKey;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataDtlsList;
import curam.core.struct.WMInstanceDataSearchByCaseIDIn;
import curam.message.BPOREFLECTION;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.internal.xml.impl.XMLPrintStreamConstants;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.type.CodeTable;
import curam.util.type.DateTime;
import curam.util.type.NotFoundIndicator;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;
import curam.util.xml.impl.XMLPrintStream;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * This process class contains IDL off functions from ConcernRoleDocuments.
 *
 */
public abstract class ConcernRoleDocumentGeneration extends curam.core.base.ConcernRoleDocumentGeneration {

  // BEGIN, CR00295922, CD
  @Inject
  private CMISAccessInterface cmisAccess;

  // END, CR00295922

  // BEGIN, CR00296459, CD
  /**
   * Add injection.
   */
  protected ConcernRoleDocumentGeneration() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00296459

  // BEGIN, CR00164008, JMA
  // ___________________________________________________________________________
  /**
   * Generates an XML document from the specified XSL template and previews that
   * document.
   *
   * @param details
   * details of the document to be used
   * @param data
   * the data to be entered into the document
   *
   * @return the document details to be previewed
   */
  @Override
  public ProFormaReturnDocDetails generateAndPreviewXMLDocument(
    ConcernRoleDocumentDetails details, ProFormaDocumentData data)
    throws AppException, InformationalException {

    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Return type
    final ProFormaReturnDocDetails proFormaReturnDocDetails = new ProFormaReturnDocDetails();

    // Create Preview Stream
    final ByteArrayOutputStream previewStream = new java.io.ByteArrayOutputStream();

    // Create XMLPrintStream object
    // BEGIN, CR00306943, KRK
    final XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00306943
    final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = new curam.util.administration.struct.XSLTemplateInstanceKey();

    // Set up XSL template instance
    xslTemplateInstanceKey.templateID = details.documentID;
    xslTemplateInstanceKey.templateVersion = details.versionNo;

    xslTemplateInstanceKey.locale = details.localeIdentifier;

    // BEGIN, CR00408760, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS,
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {

      if (data.printerName.length() > 0) {

        final String printerName = data.printerName;

        printStreamObj.setPrinterName(printerName);
      }

      printStreamObj.setPreviewStream(previewStream);
      printStreamObj.setJobType(XMLPrintStreamConstants.kJobTypePDF);

      try {
        // BEGIN, CR00306943, KRK
        printStreamObj.open(xslTemplateInstanceKey);
        // END, CR00306943

      } catch (final AppException ex) {

        // an error occurred - was the document not in valid XML format?
        if (ex.getCatEntry().equals(
          curam.util.message.CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {

          // the pro-forma form is not a valid XML document -
          // convert this to a more meaningful message for the user
          throw new AppException(
            curam.message.BPOCONCERNROLEDOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE,
            ex);

        } else {

          // we can't do anything with it -
          // just pass it on up to the calling method
          throw ex;
        }
      }

      // BGIN, CR00335810, MV
      final XMLDocument documentObj = new XMLDocument(
        printStreamObj.getStream(), XMLEncodingConstants.kEncodeUTF8);
      // END, CR00335810

      // Set data to print the document
      String userName = CuramConst.gkEmpty;

      if (data.caseClosureDate != null) {
        systemUserDtls = getLoggedInUser(data);
        userName = systemUserDtls.userName;
      } else {
        systemUserDtls = systemUserObj.getUserDetails();
        userName = systemUserDtls.userName;
      }

      final String generatedDate = Locale.getFormattedTime(
        DateTime.getCurrentDateTime());

      final String versionNo = String.valueOf(details.versionNo);
      final String comments = details.comments;

      // Open document
      documentObj.open(userName, generatedDate, versionNo, comments);

      // Add data to document
      documentObj.add(data);

      // Close document and print stream objects
      documentObj.close();
      printStreamObj.close();
    }
    // END, CR00408760

    proFormaReturnDocDetails.fileName = CuramConst.kProFormaDocumentPreview;
    proFormaReturnDocDetails.fileDate = new Blob(previewStream.toByteArray());

    return proFormaReturnDocDetails;
  }

  // END, CR00164008

  // ___________________________________________________________________________
  /**
   * Generates an XML document from the specified XSL template and prints that
   * document.
   *
   * @param details
   * details of the document to be used
   * @param data
   * the data to be entered into the document
   */
  @Override
  public void generateAndPrintXMLDocument(ConcernRoleDocumentDetails details,
    ProFormaDocumentData data) throws AppException, InformationalException {

    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Create XMLPrintStream object
    // BEGIN, CR00103465, ZV
    final XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00103465

    final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = new curam.util.administration.struct.XSLTemplateInstanceKey();

    // Set up XSL template instance
    xslTemplateInstanceKey.templateID = details.documentID;
    xslTemplateInstanceKey.templateVersion = details.versionNo;
    // BEGIN, CR00145315, SK
    xslTemplateInstanceKey.locale = details.localeIdentifier;
    // END, CR00145315

    // BEGIN, CR00408760, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS,
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      // Set printer name (if already defined)
      if (data.printerName.length() > 0) {
        final String printerName = data.printerName;

        printStreamObj.setPrinterName(printerName);
      }

      // open the print stream
      try {

        // BEGIN, CR00103465, ZV
        printStreamObj.open(xslTemplateInstanceKey);
        // END, CR00103465

      } catch (final AppException ex) {

        // an error occurred - was the document not in valid XML format?
        if (ex.getCatEntry().equals(
          curam.util.message.CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {

          // the pro-forma form is not a valid XML document -
          // convert this to a more meaningful message for the user
          throw new AppException(
            curam.message.BPOCONCERNROLEDOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE,
            ex);

        } else {

          // we can't do anything with it -
          // just pass it on up to the calling method
          throw ex;

        }

      }

      final XMLDocument documentObj = new XMLDocument(
        printStreamObj.getStream(), XMLEncodingConstants.kEncodeUTF8);

      // Set data to print the document
      // BEGIN , CR00003578, RV
      String userName = CuramConst.gkEmpty;

      if (data.caseClosureDate != null) {
        systemUserDtls = getLoggedInUser(data);
        userName = systemUserDtls.userName;
      } else {
        systemUserDtls = systemUserObj.getUserDetails();
        userName = systemUserDtls.userName;
      }
      // END, CR00003578
      // BEGIN, CR00086110, POB
      final String generatedDate = Locale.getFormattedTime(
        DateTime.getCurrentDateTime());
      // END, CR00086110
      final String versionNo = String.valueOf(details.versionNo);
      final String comments = details.comments;

      // Open document
      documentObj.open(userName, generatedDate, versionNo, comments);

      // Add data to document
      documentObj.add(data);

      // Close document and print stream objects
      documentObj.close();
      printStreamObj.close();
    }
    // END, CR00408760
  }

  // ___________________________________________________________________________
  /**
   * Generates an XML document from the specified XSL template and prints and
   * previews that document.
   *
   * @param details
   * details of the document to be used
   * @param data
   * the data to be entered into the document
   *
   * @return the document details to be previewed
   */
  @Override
  public ProFormaReturnDocDetails generatePrintAndPreviewXMLDocument(
    ConcernRoleDocumentDetails details, ProFormaDocumentData data)
    throws AppException, InformationalException {

    // BEGIN, CR00290871, CD
    generateAndPrintXMLDocument(details, data);
    return generateAndPreviewXMLDocument(details, data);
    // END, CR00290871
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the user data from the server that will be entered into pro forma
   * documents. Note that this retrieves the data used in all documents, and not
   * just the data specific to a particular document.
   *
   * @param documentData
   * the data to be entered into the document
   */
  @Override
  public void getUserData(ProFormaDocumentData documentData)
    throws AppException, InformationalException {

    // Address object and access structures
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls;
    final OtherAddressData otherAddressData = new OtherAddressData();

    // Users object and access structures
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UsersDtls usersDtls;

    // Location object and access structures
    final curam.core.intf.Location locationObj = curam.core.fact.LocationFactory.newInstance();
    final LocationKey locationKey = new LocationKey();
    LocationDtls locationDtls;

    OrganisationID organisationID = new OrganisationID();
    OrganisationNameAndAddressDetails organisationNameAndAddressDetails;

    // Organization object and access structures
    final curam.core.intf.Organisation organisationObj = curam.core.fact.OrganisationFactory.newInstance();
    final OrganisationKey organisationKey = new OrganisationKey();

    // AdminUser object and access structures
    final curam.core.intf.AdminUserAssistant adminUserAssistantObj = curam.core.fact.AdminUserAssistantFactory.newInstance();
    final UserKeyStruct userKeyStruct = new UserKeyStruct();
    GetResourcesDetails getResourcesDetails;

    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    final CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    // Case Header Key
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // END, CR00060051

    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Set current date
    documentData.currentDate = curam.util.type.Date.getCurrentDate();

    // Set event date
    documentData.eventDate = curam.util.type.Date.getCurrentDate();

    // if the system is in deferred processing or in batch mode assume the
    // case
    // owner to be the user.
    // BEGIN , CR00003578, RV
    if (curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kDeferred)
        && documentData.caseID != 0
        && documentData.caseClosureDate == null) {
      // END, CR00003578

      // BEGIN, CR00060051, PMD
      // Set the case header key
      caseHeaderKey.caseID = documentData.caseID;

      // Read the case owner
      final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
        caseHeaderKey);

      // BEGIN, CR00075368, SPD
      // If the owner is a user, get the users details
      if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

        // set userName
        usersKey.userName = caseOwnerDetails.userName;
      } else if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.POSITION)) {

        // Position manipulation variables
        final curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
        final curam.core.sl.entity.struct.PositionKey positionKey = new curam.core.sl.entity.struct.PositionKey();
        curam.core.sl.entity.struct.PositionName positionName = new curam.core.sl.entity.struct.PositionName();

        // populate key for read
        positionKey.positionID = caseOwnerDetails.orgObjectReference;

        // read back Position name
        positionName = positionObj.readPositionName(positionKey);

        // set name to be Position name
        documentData.userFullName = positionName.name;
      } else if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.ORGUNIT)) {

        // OrgUnit manipulation variables
        final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
        final curam.core.sl.entity.struct.OrganisationUnitKey organisationUnitKey = new curam.core.sl.entity.struct.OrganisationUnitKey();
        curam.core.sl.entity.struct.OrganisationUnitName organisationUnitName = new curam.core.sl.entity.struct.OrganisationUnitName();

        // populate key for read
        organisationUnitKey.organisationUnitID = caseOwnerDetails.orgObjectReference;

        // read back OrgUnit name
        organisationUnitName = organisationUnitObj.readOrgUnitName(
          organisationUnitKey);

        // set name to be OrgUnit name
        documentData.userFullName = organisationUnitName.name;
      } else if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.WORKQUEUE)) {

        // OrgUnit manipulation variables
        final curam.core.sl.entity.intf.WorkQueue workQueueObj = curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
        final curam.core.sl.entity.struct.WorkQueueKey workQueueKey = new curam.core.sl.entity.struct.WorkQueueKey();
        curam.core.sl.entity.struct.WorkQueueNameDetails workQueueNameDetails = new curam.core.sl.entity.struct.WorkQueueNameDetails();

        // populate key for read
        workQueueKey.workQueueID = caseOwnerDetails.orgObjectReference;

        // read back OrgUnit name
        workQueueNameDetails = workQueueObj.readWorkQueueName(workQueueKey);

        // set name to be OrgUnit name
        documentData.userFullName = workQueueNameDetails.name;
      }
      // END, CR00075368
      // BEGIN , CR00003578, RV
    } else if (curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kDeferred)
        && documentData.caseID != 0
        && documentData.caseClosureDate != null) {
      systemUserDtls = getLoggedInUser(documentData);
      usersKey.userName = systemUserDtls.userName;
      // END, CR00003578
    } else {

      // Set user key from audit information
      systemUserDtls = systemUserObj.getUserDetails();

      usersKey.userName = systemUserDtls.userName;
    }

    // Read user information
    usersDtls = usersObj.read(usersKey);

    documentData.userFullName = usersDtls.fullName;

    // Ensure that the user's default printer is available
    userKeyStruct.userName = usersKey.userName;

    // Get the default printer information
    getResourcesDetails = adminUserAssistantObj.getUserDefaultPrinter(
      userKeyStruct);

    if (getResourcesDetails.resourceID != 0) {
      documentData.printerName = getResourcesDetails.name;
    }

    // Set location key from user information
    locationKey.locationID = usersDtls.locationID;

    // Read location information
    locationDtls = locationObj.read(locationKey);

    // Set address key from location information
    addressKey.addressID = locationDtls.addressID;

    // Read address information for current user
    addressDtls = addressObj.read(addressKey);

    // Copy user address information to document data
    otherAddressData.addressData = addressDtls.addressData;

    addressObj.getLongFormat(otherAddressData);

    documentData.userAddress = otherAddressData.addressData;

    organisationID = organisationObj.readOrganisationID();

    organisationKey.organisationID = organisationID.organisationID;

    organisationNameAndAddressDetails = organisationObj.readNameAndAddress(
      organisationKey);

    // Copy organization information to document data
    documentData.organisationName = organisationNameAndAddressDetails.name;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the concern role data from the server that will be entered into
   * pro forma documents. Note that this retrieves the data used in all
   * documents, and not just the data specific to a particular document.
   *
   * @param key
   * contains the concern role ID of the client
   * @param documentData
   * the data to be entered into the document
   */
  @Override
  public void getConcernRoleData(ConcernRoleKey key,
    ProFormaDocumentData documentData) throws AppException,
      InformationalException {

    // Concern role object and access structures
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;

    // Address object and access structures
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls;
    final OtherAddressData otherAddressData = new OtherAddressData();

    // Read the concern role information
    concernRoleDtls = concernRoleObj.read(key);

    // Copy concern role information to document data
    documentData.assign(concernRoleDtls);

    // Copy the concern role type description to document data
    documentData.concernRoleTypeDesc = curam.util.type.CodeTable.getOneItem(
      curam.codetable.CONCERNROLETYPE.TABLENAME,
      concernRoleDtls.concernRoleType);

    // Set address key from concern role
    addressKey.addressID = concernRoleDtls.primaryAddressID;

    // Read address information for concern role
    addressDtls = addressObj.read(addressKey);

    // Copy concern role address information to document data
    otherAddressData.addressData = addressDtls.addressData;
    addressObj.getLongFormat(otherAddressData);
    documentData.concernRoleAddress = otherAddressData.addressData;

    // is the concern role type service supplier
    if (concernRoleDtls.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.SERVICESUPPLIER)) {

      documentData.supplierConcernRoleAddress = documentData.concernRoleAddress;
      documentData.supplierConcernRoleName = documentData.concernRoleName;
    }

  }

  // ___________________________________________________________________________
  /**
   * Get product type, reason and client data.
   *
   * @param key
   * contains caseID
   * @param documentData
   * ProFormaDocumentData for printing communications
   */
  @Override
  public void getCaseClosureClientData(GetCaseClosureSupplierKey key,
    ProFormaDocumentData documentData) throws AppException,
      InformationalException {

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component
    // installation
    // setting. If the Environment variable is present, run the Reflection
    // code
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

      // Case type variables
      final CaseKey caseKey = new CaseKey();
      final curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      // Read case type
      caseKey.caseID = key.caseID;
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // If its an Appeal case, handle here, else ignore
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
        // BEGIN, CR00023618, SK
        final String className = ReflectionConst.concernRoleDocumentGenerationFactoryClassName;
        final String methodName = ReflectionConst.getCaseClosureClientDataMethodName;
        // END, CR00023618
        // Set the arguments to pass through
        final Object[] arguments = new Object[] { key, documentData };

        // Set the passed class types to the method
        final Class[] parameterTypes = new Class[] {
          GetCaseClosureSupplierKey.class,
          ProFormaDocumentData.class };

        performReflection(className, methodName, arguments, parameterTypes);

        return;
      }

    }

    // Populate the product information (if the case has a product
    // e.g. product delivery cases, liability cases

    // read the case header information to find the case type
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey,
      false);

    // does this case type have a product?
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
        || caseTypeCode.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY)) {

      // read product delivery details to find the product
      final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      productDeliveryKey.caseID = key.caseID;
      final ProductDeliveryDtls productDeliveryDtls = productDeliveryObj.read(
        productDeliveryKey);

      // read the product details
      final curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
      final ProductKey productKey = new ProductKey();

      productKey.productID = productDeliveryDtls.productID;
      final ProductDtls productDtls = productObj.read(productKey);

      // populate the description of the product in the document
      documentData.productType = curam.util.type.CodeTable.getOneItem(
        curam.codetable.PRODUCTTYPE.TABLENAME, productDtls.typeCode);

    }

    //
    // Get the case status
    //

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = key.caseID;

    // maintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    final CaseIDKey caseIDKey = new CaseIDKey();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;

    // set key to read maintainCase
    caseIDKey.caseID = key.caseID;

    // read maintainCase
    caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
      caseIDKey);

    CaseStatusDtls caseStatusDtls;

    try {
      // BEGIN, CR00224271, ZV
      caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
        currentCaseStatusKey);
      // END, CR00224271

    } catch (final curam.util.exception.RecordNotFoundException e) {

      final AppException ae = new AppException(
        curam.message.GENERALCASE.ERR_CASESTATUS_RNFE_CASE);

      ae.arg(caseReferenceProductNameConcernRoleName.caseReference);

      throw ae;
    }

    // is the case closed or pending closure?
    if (caseStatusDtls.statusCode.equals(
      curam.codetable.CASESTATUS.PENDINGCLOSURE)
        || caseStatusDtls.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      // get the closure details
      final curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
      final ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();

      readCaseClosureKey.caseID = key.caseID;
      final ClosureDtls closureDtls = maintainCaseClosureObj.readCaseClosure(
        readCaseClosureKey);

      // return case closure reason or its code if description is
      // unavailable
      documentData.caseClosureReason = curam.util.type.CodeTable.getOneItem(
        curam.codetable.CASECLOSEREASON.TABLENAME, closureDtls.reasonCode);

      // default the reason if none exists
      if (documentData.caseClosureReason == null) {

        documentData.caseClosureReason = closureDtls.reasonCode;

      }

      // populate the case closure reason
      documentData.caseClosureDate = closureDtls.closureDate;

      // or is the case open?
    } else if (caseStatusDtls.statusCode.equals(curam.codetable.CASESTATUS.OPEN)) {

      // get the list of events for the case
      final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
      final CaseEventCaseIDAndTypeKey caseEventCaseIDAndTypeKey = new CaseEventCaseIDAndTypeKey();

      caseEventCaseIDAndTypeKey.caseID = key.caseID;
      caseEventCaseIDAndTypeKey.eventTypeCode = curam.codetable.CASEEVENTTYPE.CASEREACTIVATION;
      final CaseEventDtlsList caseEventDtlsList = caseEventObj.searchByCaseIDAndType(
        caseEventCaseIDAndTypeKey);

      // loop variables
      final curam.core.intf.CaseReactivation caseReactivationObj = curam.core.fact.CaseReactivationFactory.newInstance();
      final CaseReactivationKey caseReactivationKey = new CaseReactivationKey();
      CaseReactivationDtls caseReactivationDtls;
      boolean caseEventRecordFound = false;

      // loop through all the case events
      for (int i = 0; i < caseEventDtlsList.dtls.size(); i++) {

        // does this event have a status other than CLOSED
        if (!caseEventDtlsList.dtls.item(i).statusCode.equals(
          curam.codetable.CASEEVENTSTATUS.CLOSED)) {

          caseEventRecordFound = true;

          caseReactivationKey.caseReactivationID = caseEventDtlsList.dtls.item(i).relatedID;

          break;

        }

      }

      // does a case event exist with a non-CLOSED status?
      if (!caseEventRecordFound) {

        // no, throw an exception
        final AppException e = new AppException(
          curam.message.GENERALCASE.ERR_CASEEVENT_RNFE_CASE);

        e.arg(caseReferenceProductNameConcernRoleName.caseReference);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

      // read CaseReactivation from database
      caseReactivationDtls = caseReactivationObj.read(caseReactivationKey);

      // populate the case reactivation details
      documentData.caseReactivationDate = caseReactivationDtls.reactivationDate;
      documentData.caseReactivationReason = curam.util.type.CodeTable.getOneItem(
        curam.codetable.CASEREACTIVATEREASON.TABLENAME,
        caseReactivationDtls.reasonCode);

      // default the case reactivation reason if none exists
      if (documentData.caseReactivationReason == null) {

        documentData.caseReactivationReason = caseReactivationDtls.reasonCode;

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * get supplier name and supplier address
   *
   * @param key
   * contains ConcernRole ID
   * @param documentData
   * curam.core.struct.ProFormaDocumentData for printing communications
   */
  @Override
  public void getCaseClosureSupplierData(
    curam.core.struct.GetCaseClosureSupplierKey key,
    curam.core.struct.ProFormaDocumentData documentData) throws AppException,
      InformationalException {

    // Address object and access structures
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final curam.core.struct.AddressKey addressKey = new curam.core.struct.AddressKey();
    curam.core.struct.AddressDtls addressDtls;
    final curam.core.struct.OtherAddressData otherAddressData = new curam.core.struct.OtherAddressData();

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final curam.core.struct.ConcernRoleKey concernRoleKey = new curam.core.struct.ConcernRoleKey();
    curam.core.struct.ConcernRoleDtls concernRoleDtls;

    // read ConcernRole from database
    concernRoleKey.concernRoleID = key.supplierID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Copy concern role name information to document data
    documentData.supplierConcernRoleName = concernRoleDtls.concernRoleName;

    // Set address key from concern role
    addressKey.addressID = concernRoleDtls.primaryAddressID;

    // Read address information for concern role
    addressDtls = addressObj.read(addressKey);

    // Copy concern role address information to document data
    otherAddressData.addressData = addressDtls.addressData;

    addressObj.getAddressStrings(otherAddressData);

    documentData.supplierConcernRoleAddress = otherAddressData.addressData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieve the data needed to print a communication
   *
   * @param key
   * contains ConcernRole ID & caseID
   * @param documentData
   * ProFormaDocumentData for printing communications
   */
  @Override
  public void getCaseEventData(GetCaseEventData key,
    ProFormaDocumentData documentData) throws AppException,
      InformationalException {

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component
    // installation
    // setting. If the Environment variable is present, run the Reflection
    // code
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

      // Case type variables
      final CaseKey caseKey = new CaseKey();
      final curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      // Read case type
      caseKey.caseID = key.caseID;
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // If its an appeal case, handle here, else ignore.
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
        // BEGIN, CR00023618, SK
        final String className = ReflectionConst.concernRoleDocumentGenerationFactoryClassName;
        final String methodName = ReflectionConst.getCaseEventDataMethodName;
        // END, CR00023618
        // Set the arguments to pass through
        final Object[] arguments = new Object[] { key, documentData };

        // Set the passed class types to the method
        final Class[] parameterTypes = new Class[] {
          GetCaseEventData.class,
          ProFormaDocumentData.class };

        performReflection(className, methodName, arguments, parameterTypes);

        return;
      }

    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

    // struct for document generation
    final ConcernRoleDocumentDetails concernRoleDocumentDetails = new ConcernRoleDocumentDetails();

    // Concern role object and access structures
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    AlternateIDAddressNameAndTypeDetails alternateIDAddressNameAndTypeDetails;

    // variables, used to read address information
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls;
    final OtherAddressData otherAddressData = new OtherAddressData();

    // unique ID generation variable
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // variables for insert of Concern Role Communication record
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();

    final ConcernRoleCommunicationDtls concernRoleCommDtls = new ConcernRoleCommunicationDtls();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryTypeDetails productDeliveryTypeDetails;

    // XSL details for printing templates
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // read ProductDelivery from database, so that we can get
    // back the productID
    productDeliveryKey.caseID = key.caseID;
    productDeliveryTypeDetails = productDeliveryObj.readProductType(
      productDeliveryKey);

    // get description of product type, which will be printed on the
    // case communication
    documentData.productType = curam.util.type.CodeTable.getOneItem(
      curam.codetable.PRODUCTTYPE.TABLENAME,
      productDeliveryTypeDetails.productType);

    // pass in the correct date
    documentData.eventDate = key.eventDate;

    // set the caseID so that the correct user info is retrieved
    documentData.caseID = key.caseID;

    // read case Reference
    final CaseSearchKey caseSearchKey = new CaseSearchKey();
    CaseReference caseReferenceStruct = new CaseReference();

    caseSearchKey.caseID = key.caseID;

    caseReferenceStruct = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    documentData.caseReference = caseReferenceStruct.caseReference;

    // if case is being suspended or unsuspended set the
    // appropriate reason value
    if (documentData.reason.length() > 0) {

      documentData.caseSuspendReason = CodeTable.getOneItem(
        CASESUSPENDREASON.TABLENAME, documentData.reason);

      if (documentData.caseSuspendReason.length() == 0) {

        documentData.caseUnsuspendReason = CodeTable.getOneItem(
          CASEUNSUSPENDREASON.TABLENAME, documentData.reason);

      } else {
        // BEGIN, CR00049218, GM
        documentData.caseUnsuspendReason = CuramConst.gkEmpty;
        // END, CR00049218
      }
    }

    // if there is a concernroleID, get the concern role information
    if (key.concernRoleID != 0) {

      concernRoleKey.concernRoleID = key.concernRoleID;

    } else {

      // Read CaseHeader from database
      caseHeaderKey.caseID = key.caseID;
      readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
        caseHeaderKey);

      concernRoleKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    // populate the user information
    getUserData(documentData);

    // Read the concern role information
    alternateIDAddressNameAndTypeDetails = concernRoleObj.readNameAlternateIDAddressAndType(
      concernRoleKey);

    // Copy concern role information to document data
    documentData.alternateID = alternateIDAddressNameAndTypeDetails.primaryAlternateID;
    documentData.concernRoleName = alternateIDAddressNameAndTypeDetails.concernRoleName;

    // Copy the concern role type description to document data
    documentData.concernRoleTypeDesc = CodeTable.getOneItem(
      CONCERNROLETYPE.TABLENAME,
      alternateIDAddressNameAndTypeDetails.concernRoleType);

    // read address information
    addressKey.addressID = alternateIDAddressNameAndTypeDetails.primaryAddressID;
    addressDtls = addressObj.read(addressKey);

    otherAddressData.addressData = addressDtls.addressData;

    addressObj.getLongFormat(otherAddressData);

    documentData.concernRoleAddress = otherAddressData.addressData;

    // depending on the communication type, print the related template
    if (key.caseCommunicationType.equals(CASECOMMUNICATIONTYPE.CASECREATED)) {

      xslTemplateIDCodeKey.templateIDCode = TEMPLATEIDCODE.CASECREATEDCLIENTCOMMUNICATION;

    } else {

      if (key.caseCommunicationType.equals(CASECOMMUNICATIONTYPE.CASESUSPENDED)) {

        xslTemplateIDCodeKey.templateIDCode = TEMPLATEIDCODE.CASESUSPENDEDCLIENTCOMMUNICATION;

      } else {

        if (key.caseCommunicationType.equals(
          CASECOMMUNICATIONTYPE.CASEUNSUSPENDED)) {

          xslTemplateIDCodeKey.templateIDCode = TEMPLATEIDCODE.CASEUNSUSPENDEDCLIENTCOMMUNICATION;
        }
      }
    }

    // Get the templateID and templateVersion for printDocument
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();
    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();
    // BEGIN, CR00246527, AK
    final LanguageLocaleMapKey langMapKey = new LanguageLocaleMapKey();

    langMapKey.languageCode = concernRoleObj.read(concernRoleKey).preferredLanguage;
    final NotFoundIndicator nfInd = new NotFoundIndicator();
    final LanguageLocaleMapDtls langMapDtls = LanguageLocaleMapFactory.newInstance().read(
      nfInd, langMapKey);

    if (nfInd.isNotFound()) {
      xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();
    } else {
      xslTemplateIDCodeKey.localeIdentifier = langMapDtls.localeIdentifier;
    }
    // END, CR00246527
    // END, CR00146472

    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      // BEGIN, CR00246527, AK
      try {
        xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();
        xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
          xslTemplateIDCodeKey);
      } catch (final curam.util.exception.RecordNotFoundException rnfe) {
        final AppException ae = new AppException(
          curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

        ae.arg(xslTemplateIDCodeKey.templateIDCode);
        throw ae;
      }
      // END, CR00246527
    }

    // pass in the template id and version number
    concernRoleDocumentDetails.documentID = xslTemplateInstanceKey.templateID;
    concernRoleDocumentDetails.versionNo = xslTemplateInstanceKey.templateVersion;
    // BEGIN, CR00146472, SK
    // BEGIN, CR00146487, SK
    concernRoleDocumentDetails.localeIdentifier = xslTemplateInstanceKey.locale;
    // END, CR00146487

    // BEGIN, CR00295922, CD
    // print the communication
    final ProFormaReturnDocDetails proFormaDtls = generatePrintAndPreviewXMLDocument(
      concernRoleDocumentDetails, documentData);

    // END, CR00295922

    // Generate unique id for ConcernRoleCommunication
    concernRoleCommDtls.communicationID = uniqueIDObj.getNextID();

    // set the communication details
    concernRoleCommDtls.caseID = key.caseID;
    concernRoleCommDtls.correspondentConcernRoleID = concernRoleKey.concernRoleID;

    concernRoleCommDtls.typeCode = curam.codetable.COMMUNICATIONTYPE.LETTER;

    concernRoleCommDtls.methodTypeCode = curam.codetable.COMMUNICATIONMETHOD.HARDCOPY;

    concernRoleCommDtls.communicationDate = curam.util.type.Date.getCurrentDate();

    concernRoleCommDtls.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    concernRoleCommDtls.correspondentName = documentData.concernRoleName;
    concernRoleCommDtls.addressID = alternateIDAddressNameAndTypeDetails.primaryAddressID;
    concernRoleCommDtls.proFormaInd = true;

    concernRoleCommDtls.proFormaID = xslTemplateInstanceKey.templateID;
    concernRoleCommDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;

    // insert a subject.
    // populate the template name
    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateObj = curam.core.fact.MaintainXSLTemplateFactory.newInstance();

    final curam.core.struct.XSLTemplateIn xslTemplateIn = new curam.core.struct.XSLTemplateIn();

    xslTemplateIn.templateID = xslTemplateInstanceKey.templateID;
    // BEGIN, CR00146472, SK
    // BEGIN, CR00146487, SK
    xslTemplateIn.localeIdentifier = xslTemplateInstanceKey.locale;
    // END, CR00146487

    // BEGIN, CR00279987, KRK
    concernRoleCommDtls.subjectText = maintainXSLTemplateObj.readXSLTemplateDetails(xslTemplateIn).templateName;
    // END, CR00279987

    // insert a communicationFormat.
    concernRoleCommDtls.communicationFormat = curam.codetable.COMMUNICATIONFORMAT.PROFORMA;

    // populate the concern role id
    concernRoleCommDtls.concernRoleID = concernRoleKey.concernRoleID;

    concernRoleCommDtls.communicationStatus = curam.codetable.COMMUNICATIONSTATUS.SENT;

    systemUserDtls = systemUserObj.getUserDetails();
    concernRoleCommDtls.userName = systemUserDtls.userName;

    // write a record to the communications table for history purposes
    concernRoleCommunicationObj.insert(concernRoleCommDtls);

    // BEGIN, CR00295922, CD
    // BEGIN, CR00296459, CD
    if (cmisAccess.isCMISEnabledFor(
      CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {
      // END, CR00296459

      // save the contents to the content management system
      cmisAccess.create(concernRoleCommDtls.communicationID,
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
        proFormaDtls.fileDate.copyBytes(), proFormaDtls.fileName,
        CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);

    }
    // END, CR00295922
  }

  // ___________________________________________________________________________
  /**
   * Returns the data required for the contract.
   *
   * @param key
   * contains concernRoleID, caseID, documentID, caseContractID
   *
   * @return document data
   */
  @Override
  public ProFormaDocumentData getCaseContractData(CaseContractDocumentKey key) throws AppException,
      InformationalException {

    final ProFormaDocumentData documentData = new ProFormaDocumentData();

    // case contract contents variables
    final curam.core.intf.CaseContractContents caseContractContentsObj = curam.core.fact.CaseContractContentsFactory.newInstance();
    final ContentsByContractIDKey contentsByContractIDKey = new ContentsByContractIDKey();

    CaseContractTaskDtls caseContractTaskDtls;

    CaseContractContentsDtlsList caseContractContentsDtlsList;

    // Set the key to read the Case Contract Tasks
    contentsByContractIDKey.caseContractID = key.caseContractID;

    caseContractContentsDtlsList = caseContractContentsObj.searchByContractID(
      contentsByContractIDKey);

    for (int i = 0; i < caseContractContentsDtlsList.dtls.size(); i++) {

      caseContractTaskDtls = new CaseContractTaskDtls();

      caseContractTaskDtls.assign(caseContractContentsDtlsList.dtls.item(i));

      documentData.dtls.addRef(caseContractTaskDtls);

    }

    return documentData;
  }

  // ___________________________________________________________________________
  /**
   * Execute reflection on the Argument Class and Method, using argument
   * Parameters.
   *
   * @param className
   * Class name to instantiate
   * @param methodName
   * Method to be run
   * @param arguments
   * Arguments to be passed to Method
   * @param parameterTypes
   * Class Types of Parameters used
   */
  // BEGIN, CR00198672, VK
  protected void performReflection(String className, String methodName,
    Object[] arguments, Class[] parameterTypes) throws AppException,
      InformationalException {

    // END, CR00198672
    // Setup, instantiation and execution of alternative
    // modifyUserActivityIgnoreConflict within AppealMaintainUserActivity
    // process, via reflection
    Class cls = null;

    try {
      // Load the class
      cls = Class.forName(className);

      // Create a method for the static newInstance constructor
      // BEGIN, CR00023618, SK
      final Method constructorMethod = cls.getMethod(
        ReflectionConst.kNewInstance);
      // END, CR00023618
      final Object classObj = constructorMethod.invoke(cls);

      // Define the method modifyUserActivityIgnoreConflict
      // BEGIN, CR00142355, CD
      final Method method = classObj.getClass().getMethod(methodName,
        parameterTypes);

      // END, CR00142355

      // Now invoke the method
      method.invoke(classObj, arguments);

    } catch (final IllegalAccessException e) {// ignore - biz methods MUST be
      // public
    } catch (final ClassNotFoundException e) {

      final AppException ae = new AppException(
        BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

      ae.arg(className);
      ae.arg(getClass().toString());
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL));

      throw new RuntimeException(ae);

    } catch (final NoSuchMethodException e) {

      final AppException ae = new AppException(
        BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

      ae.arg(className);

      // BEGIN, CR00049218, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00049218

      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL));

      throw new RuntimeException(ae);

    } catch (final IllegalArgumentException e) {

      final AppException ae = new AppException(
        BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);

      // BEGIN, CR00049218, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00049218

      ae.arg(className);
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL));

      throw new RuntimeException(ae);

    } catch (final InvocationTargetException e) {

      final AppException exc = new AppException(
        BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

      exc.arg(e.getTargetException().getMessage());
      throw exc;
    }
  }

  // BEGIN, CR00003578, RV
  // ___________________________________________________________________________
  /**
   * Returns logged in user for deferred process.
   *
   * @param key
   * contains documentData
   *
   * @return SystemUserDtls
   */
  @Override
  public SystemUserDtls getLoggedInUser(ProFormaDocumentData documentData)
    throws AppException, InformationalException {

    final SystemUserDtls systemUserDtls = new SystemUserDtls();
    final curam.core.intf.WMInstanceData wmInstanceDataObj = curam.core.fact.WMInstanceDataFactory.newInstance();
    WMInstanceDataDtls wmInstanceDataDtls;
    WMInstanceDataDtlsList wmInstanceDataDtlsList;
    final WMInstanceDataSearchByCaseIDIn wmInstanceDataSearchByCaseIDIn = new WMInstanceDataSearchByCaseIDIn();

    wmInstanceDataSearchByCaseIDIn.caseID = documentData.caseID;
    wmInstanceDataDtlsList = wmInstanceDataObj.searchByCaseID(
      wmInstanceDataSearchByCaseIDIn);
    for (int i = 0; i < wmInstanceDataDtlsList.dtls.size(); i++) {
      wmInstanceDataDtls = wmInstanceDataDtlsList.dtls.item(i);
      // BEGIN, CR00440719, MV
      if (!wmInstanceDataDtls.closureDate.isZero()) {
        // END, CR00440719
        systemUserDtls.userName = wmInstanceDataDtls.enteredByID;
        break;
      } else {
        continue;
      }
    }
    return systemUserDtls;
  }

  // END, CR00003578

  // BEGIN, CR00146629, SK
  // ________________________________________________________________________
  /**
   * This method will take processed and non processed messages for batch
   * processing and will store in the facade level object.
   *
   * @param concernRoleDtls details of a Concern Role.
   * @param xslTemplateMessage Processed and non processed message details
   * of batch.
   * @param scopeName Scope of the call whether the call is from
   * processed batch or non processed batch.
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected void storeBatchLog(ConcernRoleDtls concernRoleDtls,
    LocalisableString xslTemplateMessage, String scopeName)
    throws AppException, InformationalException {

    // END, CR00198672
    final ArrayList<LocalisableString> xslTemplateProcessList = new ArrayList<LocalisableString>();
    HashMap<Long, ArrayList<LocalisableString>> xslTemplateProcessMap = new HashMap<Long, ArrayList<LocalisableString>>();

    if (TransactionInfo.getFacadeScopeObject(scopeName) != null) {
      // Get list from scope.
      xslTemplateProcessMap = (HashMap) TransactionInfo.getFacadeScopeObject(
        scopeName);
      if (xslTemplateProcessMap.containsKey(concernRoleDtls.concernRoleID)) {
        // Get list from hash map
        final ArrayList<LocalisableString> list = xslTemplateProcessMap.get(
          concernRoleDtls.concernRoleID);

        xslTemplateProcessList.add(xslTemplateMessage);
        list.add(xslTemplateMessage);
        xslTemplateProcessMap.put(concernRoleDtls.concernRoleID, list);

      } else {
        xslTemplateProcessList.add(xslTemplateMessage);
        xslTemplateProcessMap.put(concernRoleDtls.concernRoleID,
          xslTemplateProcessList);
      }
    } else {
      // add new list to scope.
      xslTemplateProcessList.add(xslTemplateMessage);
      xslTemplateProcessMap.put(concernRoleDtls.concernRoleID,
        xslTemplateProcessList);
    }
    TransactionInfo.setFacadeScopeObject(scopeName, xslTemplateProcessMap);
  }
  // END, CR00146629
}
