/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.sl.infrastructure.impl.FormatDateConst;
import curam.core.struct.FDDate;
import curam.core.struct.FDMonthDtls;
import curam.core.struct.FormatDateAsStringDtls;
import curam.core.struct.FormatDateAsStringKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.EnvironmentConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * This class is used to format a date as a string where it will be embedded
 * in a larger text string and pass to the client. i.e. where it has to be
 * localized on the server, rather than by the client.
 *
 */
public abstract class FormatDate extends curam.core.base.FormatDate {

  // BEGIN, CR00053248, GM
  // Constant values used to store the allowable values
  protected static final String kYMDFormat = FormatDateConst.kYMDFormat;

  protected static final String kDMYFormatLower = FormatDateConst.kDMYFormatLower;

  protected static final String kYMD_extFormat = FormatDateConst.kYMD_extFormat;

  protected static final String kDMY_extFormat = FormatDateConst.kDMY_extFormat;

  protected static final String kMDYFormat = FormatDateConst.kMDYFormat;

  protected static final String kMDY_extFormat = FormatDateConst.kMDY_extFormat;

  // Following String is temporary fix, until this string literal is defined in
  // Locale class
  protected static final String kMM_dd_yyyy = FormatDateConst.kMM_dd_yyyy;

  protected static final String kISO8601_completeFormat = FormatDateConst.kISO8601_completeFormat;

  protected static final String kDMYFormatUpper = FormatDateConst.kDMYFormatUpper;

  protected static final String kTime_ISOFormat = FormatDateConst.kTime_ISOFormat;

  protected static final String kTime_ISO_extFormat = FormatDateConst.kTime_ISO_extFormat;

  protected static final String kTime_ISO_AMPMFormat = FormatDateConst.kTime_ISO_AMPMFormat;

  // END, CR00053248

  // Global variables used to cache format on a session basis.

  // Deviating from standard EJB 103 (static fields must be initialized)
  // Architect Approval from PF
  // Format properties are "lazy loaded" from properties file
  // when (if) required

  protected static String stDateFormat;

  protected static boolean stDateFormatLoaded = false;

  protected static String stTimeFormat;

  protected static boolean stTimeFormatLoaded = false;

  // ___________________________________________________________________________
  /**
   * @param key The date to format
   *
   * @return The date output as a string
   * @deprecated Since Curam 6.0.5 curam.util.type.Date.toString(Locale locale)
   * should be used instead.
   * This method takes a date and returns a formatted string based on the
   * Default formatting for server localized strings as specified in the
   * database.
   */
  @Override
  @Deprecated
  public FormatDateAsStringDtls formatDateAsString(FormatDateAsStringKey key)
    throws AppException, InformationalException {

    final FormatDateAsStringDtls dtls = new FormatDateAsStringDtls();

    if (!stDateFormatLoaded) {
      // Get Server default format
      getDateFormat();
    }

    dtls.stringDate = curam.util.resources.Locale.getFormattedDateTime(
      key.inputDate, stDateFormat);

    return dtls;
  }

  // ___________________________________________________________________________
  /**
   * @param key The date to format
   *
   * @return The date output as a string
   * should be used instead.
   * This method takes a date-time and returns a formatted string based on the
   * Default formatting for server localized strings as specified in the
   * database. If this is not specified then a dd-MMM-yyyy hh:mm:ss
   * format is used.
   */
  @Override
  public FormatDateAsStringDtls formatDateTimeAsString(
    FormatDateAsStringKey key) throws AppException, InformationalException {

    final FormatDateAsStringDtls dtls = new FormatDateAsStringDtls();

    if (!stTimeFormatLoaded) {
      // Get Server default time format
      getTimeFormat();
    }

    final Date date = new Date(key.inputDate);

    // Get the date portion as a string
    final String dateString = date.toString(TransactionInfo.getProgramLocale());

    dtls.stringDate = dateString + CuramConst.gkSpace
      + curam.util.resources.Locale.getFormattedDateTime(key.inputDate,
      stTimeFormat);

    return dtls;
  }

  // ___________________________________________________________________________
  /**
   * @param key The date to format
   *
   * @return The date output as a string
   * This method takes a time and returns a formatted string based on the
   * Default formatting for server localized strings as specified in the
   * database. If this is not specified then a hh:mm:ss format is
   * used.
   */
  @Override
  public FormatDateAsStringDtls formatTimeAsString(FormatDateAsStringKey key)
    throws AppException, InformationalException {

    final FormatDateAsStringDtls dtls = new FormatDateAsStringDtls();

    if (!stTimeFormatLoaded) {
      // Get Server default format
      getTimeFormat();
    }

    dtls.stringDate = curam.util.resources.Locale.getFormattedDateTime(
      key.inputDate, stTimeFormat);

    return dtls;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since Curam 6.0.5
   * This method is used internally by other methods of this BPO to retrieve
   * the date format from the database, if required. If this is not
   * specified then a dd-MMM-yyyy format is used.
   */
  @Override
  @Deprecated
  public void getDateFormat() throws AppException, InformationalException {

    // Order of locale resolution:
    // 1) Attempt to read environment setting using property name from EnvVars
    // 2) Attempt to resolve default value as specified in EnvVars
    // 3) Resort to coded default in curam.util.resources.Locale class

    String defaultDateFormat = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_DEFAULT_DATE_FORMAT);

    if (defaultDateFormat == null || defaultDateFormat.length() == 0) {

      defaultDateFormat = EnvVars.ENV_DEFAULT_DATE_FORMAT_DEFAULT;

    }

    if (defaultDateFormat.equals(kYMDFormat)) {

      stDateFormat = curam.util.resources.Locale.Date_ymd;

    } else {

      if (defaultDateFormat.equals(kDMYFormatLower)) {

        stDateFormat = curam.util.resources.Locale.Date_dmy;

      } else {

        if (defaultDateFormat.equals(kYMD_extFormat)) {

          stDateFormat = curam.util.resources.Locale.Date_ymd_ext;

        } else {

          if (defaultDateFormat.equals(kDMY_extFormat)) {

            stDateFormat = curam.util.resources.Locale.Date_dmy_ext;

          } else {

            if (defaultDateFormat.equals(kISO8601_completeFormat)) {

              stDateFormat = curam.util.resources.Locale.Date_ISO8601_complete;

            } else {

              if (defaultDateFormat.equals(kDMYFormatUpper)) {

                stDateFormat = curam.util.resources.Locale.Date_DMY;

              } else {

                if (defaultDateFormat.equals(kMDYFormat)) {

                  stDateFormat = curam.util.resources.Locale.Date_mdy;

                } else {

                  if (defaultDateFormat.equals(kMDY_extFormat)) {

                    // Setting stDateFormat to static String of this class is
                    // temporary fix. Should reference a String yet to be
                    // defined in Locale class.
                    stDateFormat = kMM_dd_yyyy;

                  } else {

                    stDateFormat = curam.util.resources.Locale.defaultDateFormat;

                  }

                }
              }

            }

          }

        }

      }

    }

    // BEGIN, CR00050108, RPM
    // BEGIN, HARP 64096, GYH
    // BEGIN, CR00085608 SK
    final String sep = Configuration.getStaticProperty(
      EnvironmentConstants.Environment.kDefaultDateSeparator);

    // END, CR00085608 SK
    if (sep != null && sep.length() != 0) {
      // BEGIN, CR00053248, GM
      stDateFormat = stDateFormat.replaceAll(CuramConst.gkDash, sep);
      // END, CR00053248
    }
    // END, HARP 64096
    // END, CR00050108
    stDateFormatLoaded = true;

  }

  // ___________________________________________________________________________
  /**
   * This method is used internally by other methods of this BPO to retrieve
   * the time format from the database, if required. If this is not
   * specified then a hh::mm::ss format is used.
   */
  @Override
  public void getTimeFormat() throws AppException, InformationalException {

    // Order of locale resolution:
    // 1) Attempt to read environment setting using property name from EnvVars
    // 2) Attempt to resolve default value as specified in EnvVars
    // 3) Resort to coded default in curam.util.resources.Locale class

    String defaultTimeFormat = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_DEFAULT_TIME_FORMAT);

    if (defaultTimeFormat == null || defaultTimeFormat.length() == 0) {

      defaultTimeFormat = EnvVars.ENV_DEFAULT_TIME_FORMAT_DEFAULT;

    }

    if (defaultTimeFormat.equals(kTime_ISOFormat)) {

      stTimeFormat = curam.util.resources.Locale.Time_ISO;

    } else {

      if (defaultTimeFormat.equals(kTime_ISO_extFormat)) {

        stTimeFormat = curam.util.resources.Locale.Time_ISO_ext;

      } else {

        if (defaultTimeFormat.equals(kTime_ISO_AMPMFormat)) {

          stTimeFormat = curam.util.resources.Locale.Time_ISO_AMPM;

        } else {

          stTimeFormat = curam.util.resources.Locale.defaultTimeFormat;
        }

      }

    }

    stTimeFormatLoaded = true;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to determine the last day of the month of an input
   * date
   *
   * @param fdDate input date
   *
   * @return output to contain the last date of the month
   */
  @Override
  public FDMonthDtls getLastDateOfMonth(FDDate fdDate) throws AppException,
      InformationalException {

    final FDMonthDtls fdMonthDtls = new FDMonthDtls();

    switch (fdDate.date.getCalendar().get(java.util.Calendar.MONTH) + 1) {

    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12: {
      fdMonthDtls.lastDayOfMonth = 31;
      break;
    }

    case 4:
    case 6:
    case 9:
    case 11: {
      fdMonthDtls.lastDayOfMonth = 30;
      break;
    }

    case 2: {
      // input date's year
      final int year = fdDate.date.getCalendar().get(java.util.Calendar.YEAR);

      // If year is divisible by 4 it _MAY_ be a leap year
      if (year % 4 == 0) {

        // Only centenary years that are divisible by 400 are leap years
        if (year % 100 == 0 && year % 400 != 0) {

          fdMonthDtls.lastDayOfMonth = 28;

        } else {

          fdMonthDtls.lastDayOfMonth = 29;
        }
        // If year is not divisible by 4 it is not a leap year
      } else {

        fdMonthDtls.lastDayOfMonth = 28;
      }

      break;
    }

    default: { // Only to disable warning :
      // warning C4715: 'getLastDayOfMonth' : not all control paths
      // return a value
      fdMonthDtls.lastDayOfMonth = 0;
      break;
    }

    }

    return fdMonthDtls;
  }

}
