/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004, 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.BatchProcessChunkDtlsList;
import curam.core.struct.BatchProcessDtls;
import curam.core.struct.BatchProcessStreamKey;
import curam.core.struct.BatchProcessingResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Blob;


/**
 * This wrapper is used to allow the batch streaming infrastructure to invoke
 * the reporting for the GenerateinstructionLineItems batch program.
 */
public class GenerateinstructionLineItemsWrapper implements BatchMain {

  protected curam.core.intf.GenerateInstructionLineItems generateInstructionLineItemsObj;

  // ___________________________________________________________________________
  /**
   * Constructor, takes an instance of the class implementing the
   * GenerateinstructionLineItems batch program
   */
  public GenerateinstructionLineItemsWrapper(
    curam.core.intf.GenerateInstructionLineItems generateInstructionLineItems) {

    generateInstructionLineItemsObj = generateInstructionLineItems;

  }

  // ___________________________________________________________________________
  /**
   * Call the reporting method of the GenerateinstructionLineItems batch program
   */
  @Override
  public void sendBatchReport(String instanceID,
    BatchProcessDtls batchProcessDtls,
    BatchProcessChunkDtlsList processedBatchProcessChunkDtlsList,
    BatchProcessChunkDtlsList unprocessedBatchProcessChunkDtlsList)
    throws AppException, InformationalException {

    generateInstructionLineItemsObj.sendBatchReport(instanceID,
      batchProcessDtls, processedBatchProcessChunkDtlsList,
      unprocessedBatchProcessChunkDtlsList);

  }

  // ___________________________________________________________________________
  /**
   * No extra processing exists for this program, so this method is
   * unimplemented.
   */
  @Override
  public BatchProcessingResult doExtraProcessing(
    BatchProcessStreamKey batchProcessStreamKey, Blob batchProcessParameters)
    throws AppException, InformationalException {

    return null;
  }

}
