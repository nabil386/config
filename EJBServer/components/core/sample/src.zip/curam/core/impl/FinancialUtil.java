/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.impl.PRODUCTTYPEEntry;
import curam.message.BPOFINANCIALFLOW;
import curam.piwrapper.caseheader.impl.ProductDelivery;
import curam.piwrapper.caseheader.impl.ProductDeliveryDAO;
import curam.util.exception.AppException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import java.lang.reflect.Method;


/**
 * This is additional utility class for financial. This class defines utility
 * methods that has a common functionality across different financial classes.
 *
 */
public class FinancialUtil {

  /**
   * Instance of ProductDelivery.
   */
  @Inject
  protected ProductDeliveryDAO productDeliveryDAO;

  /**
   * Bootstrap dependency injection for this class.
   */
  public FinancialUtil() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /*
   * This method gets the resolver class object for the financial classes if the
   * appropriate property is defined.
   */
  public static Object getResolverClassName(String financialResolverName,
    long caseID) throws AppException {

    Object financialResolverObject = null;

    // Only if the product types property is set, the check for availability
    // of the subclass is done and appropriate method is invoked.
    final String productTypes = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_ALTERNATIVEIMPL_PRODUCT_TYPES);

    if (null != productTypes && CuramConst.gkZero != productTypes.length()) {

      final FinancialUtil financialUtil = new FinancialUtil();

      // If caseID is passed as input, then check if the product type obtained
      // using the caseID is in the list of product types, if caseID is not
      // passed then ignore the product type validation check.
      if (CuramConst.gkZero == caseID
        || checkIfValidProductType(
          financialUtil.getProductTypeForCaseID(caseID).getCode())) {

        if (null != financialResolverName) {
          // Create class instance for input string.
          try {
            final Class financialResolverNameClass = Class.forName(
              financialResolverName);
            final Method newInstanceMethod = financialResolverNameClass.getMethod(
              CuramConst.gkNewInstance);

            financialResolverObject = newInstanceMethod.invoke(
              financialResolverNameClass);
          } catch (final Exception e) {
            final AppException ae = new AppException(
              BPOFINANCIALFLOW.ERR_FINANCIAL_HOOK_ISSUE);

            throw ae.arg(financialResolverName);
          }
        }
      }
    }
    return financialResolverObject;
  }

  /**
   * This method is used to find the appropriate product type for the give
   * product delivery caseID.
   *
   * @param caseID
   * @return
   * @throws AppException
   */
  public PRODUCTTYPEEntry getProductTypeForCaseID(long caseID)
    throws AppException {

    final ProductDelivery productDelivery = productDeliveryDAO.get(caseID);

    return productDelivery.getProductType();
  }

  /*
   * This method is used for checking if the given product type is a expected
   * product type or not. If so, the the alternative method for the financial
   * class is invoked.
   */
  public static boolean checkIfValidProductType(String productType)
    throws AppException {

    boolean isValid = false;
    final String productTypes = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_ALTERNATIVEIMPL_PRODUCT_TYPES);
    final String products[] = productTypes.split(CuramConst.gkComma);

    for (final String product : products) {
      if (product.trim().equals(productType)) {
        isValid = true;
        break;
      }
    }

    return isValid;
  }
}
