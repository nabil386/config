/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002,2020. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CONTRIBRECORDSTATUS;
import curam.codetable.CREDITDEBIT;
import curam.codetable.DEDUCTIONCATEGORYCODE;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.FINCOMPONENTTYPE;
import curam.codetable.FININSTRUCTIONSTATUS;
import curam.codetable.ILIRELATIONSHIP;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.PMTRECONCILIATIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REGENERATIONOUTCOME;
import curam.codetable.TRANSLATEILITYPE;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.ILISTATUSEntry;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseDecisionFinancialCompFactory;
import curam.core.fact.CaseDeductionItemFCLinkFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.CreateReversalFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.FinancialInstructionFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.MaintainFinInstructionFactory;
import curam.core.fact.MaintainInstructionLineItemFactory;
import curam.core.fact.MaintainPlannedItemFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.PaymentCancellationRequestFactory;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.fact.PaymentRegenerationRequestFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProductDeliveryPatternInfoFactory;
import curam.core.fact.ReassessmentBalanceInfoFactory;
import curam.core.fact.RegeneratePaymentFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.UsersFactory;
import curam.core.intf.CaseDecisionFinancialComp;
import curam.core.intf.CaseHeader;
import curam.core.intf.CreateReversal;
import curam.core.intf.FinancialComponent;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.Notification;
import curam.core.intf.PaymentInstruction;
import curam.core.intf.PaymentInstrument;
import curam.core.intf.PaymentRegenerationRequest;
import curam.core.intf.ProductDeliveryPatternInfo;
import curam.core.intf.ReassessmentBalanceInfo;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.CaseNomineeFactory;
import curam.core.sl.entity.fact.CaseNomineeObjectiveFactory;
import curam.core.sl.entity.fact.CaseNomineeProdDelPatternFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.CaseNomineeObjective;
import curam.core.sl.entity.intf.CaseNomineeProdDelPattern;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.CaseNomineeDtls;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetailsList;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.CaseNomineeObjectiveDtls;
import curam.core.sl.entity.struct.CaseNomineeObjectiveDtlsList;
import curam.core.sl.entity.struct.CaseNomineeObjectiveKey;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternDtls;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternKey;
import curam.core.sl.entity.struct.CaseNomineeViewKey;
import curam.core.sl.entity.struct.CaseObjectiveKey;
import curam.core.sl.entity.struct.DefaultCaseNomineeDetails;
import curam.core.sl.entity.struct.DefaultCaseNomineeKey;
import curam.core.sl.entity.struct.DefaultNomineeKey;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.PrimaryClientIDNomineeParticipantRoleIDDetails;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.event.impl.PaymentInstrumentEvent;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineEntity;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.CaseIDAndParticipantRoleIDKey;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseNomObjDetails;
import curam.core.sl.struct.CaseNomineeCaseIDKey;
import curam.core.sl.struct.CaseNomineeCreationDetails;
import curam.core.sl.struct.CaseNomineeDetails;
import curam.core.sl.struct.CaseNomineeDetailsList;
import curam.core.sl.struct.CaseNomineeViewDetails;
import curam.core.sl.struct.CaseParticipantRoleIDStruct;
import curam.core.struct.CancelOrInvalidatePmtDetails;
import curam.core.struct.CancelRegenerateOrInvalidatePmtDetails;
import curam.core.struct.CancelRegenerateSummary;
import curam.core.struct.CaseDecisionFinancialCompDtls;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemFCLinkDtls;
import curam.core.struct.CaseDeductionItemFinCompID;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseNomineeID;
import curam.core.struct.CaseNomineeIDKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameTypeDateDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DateOfDeathDetails;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.DeliveryMethodType;
import curam.core.struct.FinCompCoverPeriod;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinInstructionIDConcernRoleIDList;
import curam.core.struct.FinInstructionIDStatus;
import curam.core.struct.FinancialCompIDKey;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.FinancialComponentKey;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.ILICaseFinancialDtls;
import curam.core.struct.ILICaseFinancialDtlsList;
import curam.core.struct.ILICaseIDCoverPeriod;
import curam.core.struct.ILICaseIDList;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.IsPaymentCancelledResult;
import curam.core.struct.IsPaymentInvalidatedKey;
import curam.core.struct.IsPaymentInvalidatedResult;
import curam.core.struct.IsPaymentRegeneratedResult;
import curam.core.struct.NomineeOverUnderPaymentDtlsList;
import curam.core.struct.OwnerID;
import curam.core.struct.PDPIByProdDelPatIDStatusAndDateKey;
import curam.core.struct.PIInvalidatedVersionNo;
import curam.core.struct.PIReconcilStatusCode;
import curam.core.struct.PIReconcilStatusCodeInvalidatedVersionNo;
import curam.core.struct.PaymentCancellationRequestDtls;
import curam.core.struct.PaymentCancellationRequestKey;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstructionKey;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.PaymentRegenerationRequestDtls;
import curam.core.struct.PaymentRegenerationRequestKey;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ReadmultiBalanceKey;
import curam.core.struct.ReassessmentBalanceInfoDtlsList;
import curam.core.struct.RegenFinInstructIDKey;
import curam.core.struct.RegeneratePaymentForNewNomineeDetails;
import curam.core.struct.RelatedILIDetailsList;
import curam.core.struct.RelatedILIidentifier;
import curam.core.struct.ReverseFinInstructionSummary;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.events.INSTRUCTIONLINEITEM;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOCREATECANCELLATION;
import curam.message.GENERALCASE;
import curam.message.GENERALFINANCE;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * To cancel a Payment Instrument and associated Instruction Line Items.
 *
 */
public abstract class CreateCancellation
  extends curam.core.base.CreateCancellation {

  // BEGIN, CR00140552, KH
  /**
   * Holds the value {@value} . This constant is not used in core code.
   */
  protected static final int kOneInstruction = 1;

  // END, CR00140552

  // BEGIN CR00109704, MR
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  /**
   * Add injection for using the new CaseTransactionLog API.
   */
  public CreateCancellation() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END CR00109704

  // BEGIN, CR00211744, VM
  @Inject
  AssessmentEngineEntity assessmentEngineEntity;

  // END, CR00211744

  // BEGIN, CR00226887, RK
  @Inject
  protected EventDispatcherFactory<PaymentInstrumentEvent> paymentInstrumentEventsDispatcher;

  // END, CR00226887

  // BEGIN, CR00130020, KH
  // BEGIN, CR00002146, KH
  // ___________________________________________________________________________
  /**
   * This method cancels a financial instruction via the payment instruction.
   *
   * @param finInstructionID Financial Instruction ID.
   * @param cancelRegenerateSummary Cancel Regenerate Summary.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelFinInstruction(final FinInstructionID finInstructionID,
    final CancelRegenerateSummary cancelRegenerateSummary)
    throws AppException, InformationalException {

    // BEGIN, CR00130842, KH
    performSecurityChecks(finInstructionID);
    // END, CR00130842

    final PaymentInstrumentKey paymentInstrumentKey =
      validateRolledUpInstruction(finInstructionID);

    // Cancel the financial instruction.
    cancelFinancialInstruction(finInstructionID, cancelRegenerateSummary);

    // Create a payment cancellation request.
    createPaymentCancellationRequest(paymentInstrumentKey,
      cancelRegenerateSummary);

    if (cancelRegenerateSummary.invalidateInd) {

      // paymentInstrument manipulation variables.
      final PaymentInstrument paymentInstrumentObj =
        PaymentInstrumentFactory.newInstance();

      validateInvalidatePayment(finInstructionID);

      // Setting the status of the payment instrument to canceled
      // and marking it as invalidated.
      final PaymentInstrumentDtls paymentInstrumentDtls =
        paymentInstrumentObj.read(paymentInstrumentKey);

      final PIReconcilStatusCodeInvalidatedVersionNo piStatusCodeInvalidatedVerNo =
        new PIReconcilStatusCodeInvalidatedVersionNo();

      piStatusCodeInvalidatedVerNo.reconcilStatusCode =
        PMTRECONCILIATIONSTATUS.CANCELLED;
      piStatusCodeInvalidatedVerNo.invalidatedInd = true;
      piStatusCodeInvalidatedVerNo.versionNo =
        paymentInstrumentDtls.versionNo;

      paymentInstrumentKey.pmtInstrumentID =
        paymentInstrumentDtls.pmtInstrumentID;

      paymentInstrumentObj.modifyReconcilStatusCodeInvalidatedInd(
        paymentInstrumentKey, piStatusCodeInvalidatedVerNo);

      checkRolledUpInvalidatedPayment(finInstructionID);
    }

    // Cancel the payment instrument.
    cancelPaymentInstrumentStatus(paymentInstrumentKey);

    // Should the instruction be regenerated?
    if (cancelRegenerateSummary.regenerateInd) {
      // BEGIN, CR00265470, ZV
      regeneratePayment(finInstructionID);
      // END, CR00265470
      // END, CR00198173
    }

    // BEGIN CR00052856, GSP
    // BEGIN CR00053182, GSP
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;
    final InstructionLineItemDtlsList instructionLineItemDtlsList =
      InstructionLineItemFactory.newInstance()
        .searchByFinInstructID(iliFinInstructID);

    // END CR00053182

    // BEGIN, CR00077580, CW
    // Update planned item actual cost for the cancelled ILIs.
    MaintainPlannedItemFactory.newInstance()
      .updatePlannedItemCostsForCancelledILIs(instructionLineItemDtlsList);
    // END, CR00077580
    // END, CR00052856
  }

  // ___________________________________________________________________________
  /**
   * Checks if the payment being invalidated is rolled across cases. If it is
   * then an informational is returned to the client.
   *
   * @param finInstructID The financial instruction ID of the payment to be
   * invalidated.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void
    checkRolledUpInvalidatedPayment(final FinInstructionID finInstructID)
      throws AppException, InformationalException {

    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructID.finInstructionID;

    final ILICaseIDList iliCaseIDList = InstructionLineItemFactory
      .newInstance().searchForCaseIDByFinInstructID(iliFinInstructID);

    long lastCaseID = 0;
    int caseIDCount = 0;

    for (int i = 0; i < iliCaseIDList.dtls.size(); i++) {

      if (iliCaseIDList.dtls.item(i).caseID != lastCaseID) {

        caseIDCount++;
        lastCaseID = iliCaseIDList.dtls.item(i).caseID;
      }

      if (caseIDCount > 1) {

        // If the payment being invalidated is rolled across multiple cases,
        // an informational needs to be returned to the client
        final AppException e = new AppException(
          BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_XRV_MULTIPLE_CASES);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(e.arg(true),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
        break;
      }
    } // end for i

    sendNotification(finInstructID);
  }

  // END, CR00002146

  // ___________________________________________________________________________
  /**
   * To validate the details of the payment to be canceled.
   *
   * @param finInstructionID The financial instruction ID of the payment to be
   * cancelled.
   * @param cancelRegenerateSummary payment instruction details
   *
   * @return The payment instruction details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PaymentInstructionDtls validateCancelFinInstruction(
    final FinInstructionID finInstructionID,
    final CancelRegenerateSummary cancelRegenerateSummary)
    throws AppException, InformationalException {

    // Reason code for cancellation/regeneration must be specified
    if (cancelRegenerateSummary.reasonCode.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_PMTCANCELLATION_FV_REASONCODE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Checking to see if payment instruction exists
    final PaymentInstructionDtls paymentInstructionDtls =
      PaymentInstructionFactory.newInstance()
        .readByFinInstructionID(finInstructionID);

    // Only allowed to cancel/regenerate payments of type Check
    if (!paymentInstructionDtls.deliveryMethodType
      .equals(METHODOFDELIVERY.CHEQUE)
      && !paymentInstructionDtls.deliveryMethodType
        .equals(METHODOFDELIVERY.EFT)
      && !paymentInstructionDtls.deliveryMethodType
        .equals(METHODOFDELIVERY.VOUCHER)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(new AppException(
          BPOCREATECANCELLATION.ERR_FININSTRUCTION_DELIVERYMETHOD_FV_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Read financial instruction entity
    final FinancialInstructionKey financialInstructionKey =
      new FinancialInstructionKey();

    financialInstructionKey.finInstructionID =
      finInstructionID.finInstructionID;

    final FinancialInstructionDtls financialInstructionDtls =
      FinancialInstructionFactory.newInstance().read(financialInstructionKey);

    // Cannot cancel a payment that is already cancelled or reversed
    if (financialInstructionDtls.statusCode
      .equals(FININSTRUCTIONSTATUS.REVERSED)
      || financialInstructionDtls.statusCode
        .equals(FININSTRUCTIONSTATUS.CANCELLED)) {

      final AppException e = new AppException(
        BPOCREATECANCELLATION.ERR_FININSTRUCTION_FV_FININSTRUCTIONSTATUS_CANCELLED);

      e.arg(financialInstructionKey.finInstructionID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Cannot cancel a payment that has been expired
    if (financialInstructionDtls.statusCode
      .equals(FININSTRUCTIONSTATUS.EXPIRED)) {

      final AppException e = new AppException(
        BPOCREATECANCELLATION.ERR_FININSTRUCTION_FV_FININSTRUCTIONSTATUS_EXPIRED);

      e.arg(financialInstructionKey.finInstructionID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Read the payment instrument entity
    final PaymentInstrumentKey paymentInstrumentKey =
      new PaymentInstrumentKey();

    paymentInstrumentKey.pmtInstrumentID =
      paymentInstructionDtls.pmtInstrumentID;

    final PaymentInstrumentDtls paymentInstrumentDtls =
      PaymentInstrumentFactory.newInstance().read(paymentInstrumentKey);

    // Cannot cancel a payment that has been reconciled
    if (paymentInstrumentDtls.reconcilStatusCode
      .equals(ILISTATUS.RECONCILED)) {

      final AppException e = new AppException(
        BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_FV_RECONCILESTATUS_RECONCILED);

      e.arg(financialInstructionKey.finInstructionID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00000539, SPD
    // Amount must not be a negative value
    if (financialInstructionDtls.amount.getValue() < Money.kZeroMoney
      .getValue()) {

      final AppException e =
        new AppException(GENERALFINANCE.ERR_FININSTRUCTION_AMT_NEGATIVE);

      e.arg(financialInstructionDtls.amount);
      e.arg(financialInstructionKey.finInstructionID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
    // END, CR00000539

    return paymentInstructionDtls;
  }

  // ___________________________________________________________________________
  /**
   * To regenerate Instruction Line Items for a canceled payment and roll this
   * into a financial instruction.
   *
   * @param finInstructionID The financial instruction ID of the payment to be
   * regenerated.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void regeneratePayment(final FinInstructionID finInstructionID)
    throws AppException, InformationalException {

    // BEGIN, CR00130842, KH
    performSecurityChecks(finInstructionID);
    // END, CR00130842

    validateFinancialInstruction(finInstructionID);

    // Find all the ILIs for this financial instruction
    final InstructionLineItem iliObj =
      InstructionLineItemFactory.newInstance();
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    final InstructionLineItemDtlsList originalILIDtlsList =
      iliObj.searchByFinInstructID(iliFinInstructID);

    for (int i = 0; i < originalILIDtlsList.dtls.size(); i++) {

      validateCaseStatus(originalILIDtlsList.dtls.item(i));

      if (!originalILIDtlsList.dtls.item(i).instructionLineItemType
        .equals(ILITYPE.TAXPAYMENT)) {

        // Need to update the delivery method on the instruction line item
        // in case it has changed since cancellation
        final DeliveryMethodType deliveryMethodType =
          getCurrentDeliveryMethod(originalILIDtlsList.dtls.item(i));

        originalILIDtlsList.dtls.item(i).deliveryMethodType =
          deliveryMethodType.deliveryMethodType;

        // BEGIN, CR00080034, BD
        // Regenerate with the latest delivery method
        MaintainInstructionLineItemFactory.newInstance()
          .regenerateILI(originalILIDtlsList.dtls.item(i));
        // END, CR00080034
      }
    } // end for i

    // Create a payment regeneration request
    final PaymentInstructionDtls paymentInstructionDtls =
      PaymentInstructionFactory.newInstance()
        .readByFinInstructionID(finInstructionID);

    createPaymentRegenerationRequest(paymentInstructionDtls);
  }

  // ___________________________________________________________________________
  /**
   * Regenerate Instruction Line Items for a canceled payment and roll these
   * into a payment. Typically this will be done a newly specified nominee.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void regeneratePaymentForNewNominee(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails)
    throws AppException, InformationalException {

    final FinInstructionID finInstructionID = new FinInstructionID();

    finInstructionID.finInstructionID =
      regenerateForNewNomineeDetails.finInstructionID;

    // BEGIN, CR00130842, KH
    performSecurityChecks(finInstructionID);
    // END, CR00130842

    validateFinancialInstruction(finInstructionID);

    validateDateOfDeath(regenerateForNewNomineeDetails);

    regenerateAllPaymentDetails(regenerateForNewNomineeDetails);

    // Create a payment regeneration request
    final PaymentInstructionDtls paymentInstructionDtls =
      PaymentInstructionFactory.newInstance()
        .readByFinInstructionID(finInstructionID);

    // BEGIN, 178020, CSH
    PaymentRegenerationRequestKey paymentRegenerationRequestKey =
      new PaymentRegenerationRequestKey();

    paymentRegenerationRequestKey =
      createPaymentRegenerationRequest(paymentInstructionDtls);

    // BEGIN, CR00211893, KH
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID =
      regenerateForNewNomineeDetails.finInstructionID;

    // BEGIN, CR00399253, KRK
    /*
     * All ILIs being re-issued to a new nominee must be marked so that the
     * next reassessment which spans the period of the cancelled and re-issued
     * payment can use these ILIs to adjust the reassessment amounts.
     */
    final InstructionLineItem instructionLineItemObj =
      InstructionLineItemFactory.newInstance();

    final InstructionLineItemDtlsList instructionLineItemDtlsList =
      instructionLineItemObj.searchByFinInstructionID(iliFinInstructID);

    // Set a flag to see if we mark any of the ILIs for adjustment
    boolean markedILIForAdjustment = false;

    for (final InstructionLineItemDtls instructionLineItemDtls : instructionLineItemDtlsList.dtls
      .items()) {

      final InstructionLineItemKey instructionLineItemKey =
        new InstructionLineItemKey();

      /*
       * We don't mark the ILI if no reassessments have occurred in the period
       */
      if (considerILIForReassessmentAdjustment(instructionLineItemDtls,
        regenerateForNewNomineeDetails)) {

        instructionLineItemKey.instructLineItemID =
          instructionLineItemDtls.instructLineItemID;
        instructionLineItemDtls.adjustReassessmentInd = true;

        markedILIForAdjustment = true;

        instructionLineItemObj.modify(instructionLineItemKey,
          instructionLineItemDtls);
      }
    }
    // Check if we are regenerating back to the original Nominee
    // and if so remove unnecessary adjustment indicators
    checkForRegenerationToOriginalNominee(regenerateForNewNomineeDetails,
      paymentRegenerationRequestKey, markedILIForAdjustment);
    // END, 178020
    // END, CR00399253
    // END, CR00211893
  }

  // BEGIN, 178020, CSH
  // ___________________________________________________________________________
  /**
   * Checks if the payment being regenerated is being assigned back to the
   * original nominee. If this is the case we need to ensure that any
   * adjustment indicators are reset as they are no longer required.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param paymentRegenerationRequestKey The key containing the id of the
   * PaymentRegenerationRequest created.
   * @param markedILIForAdjustment A boolean indicating if the ILI has
   * bee marked for adjustment during the current transaction.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  protected void checkForRegenerationToOriginalNominee(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final PaymentRegenerationRequestKey paymentRegenerationRequestKey,
    final boolean markedILIForAdjustment)
    throws AppException, InformationalException {

    // If we are not marking the current ILI for adjustment, perform an
    // additional check for any previous marked ILIs which we now want to reset
    if (!markedILIForAdjustment) {

      final InstructionLineItem instructionLineItemObj =
        InstructionLineItemFactory.newInstance();

      // Get the financialInstructionID from the cancelled payment to get
      // the the list of ILIs that were previously marked for adjustment
      PaymentRegenerationRequestDtls paymentRegenerationRequestDtls =
        new PaymentRegenerationRequestDtls();

      paymentRegenerationRequestDtls = PaymentRegenerationRequestFactory
        .newInstance().read(paymentRegenerationRequestKey);

      final PaymentInstructionKey paymentInstructionKey =
        new PaymentInstructionKey();
      paymentInstructionKey.pmtInstructionID =
        paymentRegenerationRequestDtls.pmtInstructionID;

      // Get the Payment Instruction details from the regeneration request
      // record
      final PaymentInstructionDtls prrPymentInstructionDtls =
        PaymentInstructionFactory.newInstance().read(paymentInstructionKey);

      final ILIFinInstructID prrILIFinInstructID = new ILIFinInstructID();

      // Get the financialInstructionID from the PaymentInstruction record
      prrILIFinInstructID.finInstructionID =
        prrPymentInstructionDtls.finInstructionID;

      final RegenFinInstructIDKey regeneFinInstructIDKey =
        new RegenFinInstructIDKey();
      regeneFinInstructIDKey.regenFinInstructID =
        prrILIFinInstructID.finInstructionID;

      final NotFoundIndicator nfIndicator = new NotFoundIndicator();
      PaymentInstructionKey cancelledPaymentInstructionKey =
        new PaymentInstructionKey();

      cancelledPaymentInstructionKey =
        PaymentRegenerationRequestFactory.newInstance()
          .readByRegenFinInstructID(nfIndicator, regeneFinInstructIDKey);

      if (!nfIndicator.isNotFound()) {

        PaymentInstructionDtls cancelledPaymentInstructionDtls =
          new PaymentInstructionDtls();
        final ILIFinInstructID cancelledILIFinInstructID =
          new ILIFinInstructID();

        // Get the original nominee from the previously cancelled Payment
        // Instruction
        cancelledPaymentInstructionDtls = PaymentInstructionFactory
          .newInstance().read(cancelledPaymentInstructionKey);

        // Check if the payment is being regenerated back to the original
        // nominee, if so we don't need to adjust any longer
        if (regenerateForNewNomineeDetails.caseNomineeID == cancelledPaymentInstructionDtls.caseNomineeID) {

          cancelledILIFinInstructID.finInstructionID =
            cancelledPaymentInstructionDtls.finInstructionID;

          final InstructionLineItemDtlsList cancelledInstructionLineItemDtlsList =
            instructionLineItemObj
              .searchByFinInstructID(cancelledILIFinInstructID);

          for (int i = 0; i < cancelledInstructionLineItemDtlsList.dtls
            .size(); i++) {

            final InstructionLineItemKey instructionLineItemKey =
              new InstructionLineItemKey();

            instructionLineItemKey.instructLineItemID =
              cancelledInstructionLineItemDtlsList.dtls
                .item(i).instructLineItemID;
            final InstructionLineItemDtls cancelledILIDtls =
              instructionLineItemObj.read(instructionLineItemKey);

            // Check if the ILI indicator has already been unset
            if (cancelledILIDtls.adjustReassessmentInd) {

              // Set the ILI so we won't consider it again
              cancelledILIDtls.adjustReassessmentInd = false;
              instructionLineItemObj.modify(instructionLineItemKey,
                cancelledILIDtls);
            }
          }
        }
      }
    }
  }

  // END, 178020

  // ___________________________________________________________________________
  /**
   * Validates that the financial instruction has been cancelled. Only cancelled
   * instructions can be regenerated.
   *
   * @param finInstructionID Contains the financial instruction ID for the
   * payment to be regenerated.
   *
   * @throws AppException
   * {@link BPOCREATECANCELLATION#ERR_PMTINSTRUMENT_FV_MUST_BE_CANCELLED
   * ERR_PMTINSTRUMENT_FV_MUST_BE_CANCELLED} - if the payment being
   * regenerated has not yet been cancelled.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void
    validateFinancialInstruction(final FinInstructionID finInstructionID)
      throws AppException, InformationalException {

    final FinancialInstructionKey key = new FinancialInstructionKey();

    key.finInstructionID = finInstructionID.finInstructionID;

    final FinancialInstructionDtls financialInstructionDtls =
      FinancialInstructionFactory.newInstance().read(key);

    if (!financialInstructionDtls.statusCode
      .equals(FININSTRUCTIONSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_FV_MUST_BE_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that the payment instrument has not been invalidated.
   * Invalidated payments can not be regenerated.
   *
   * @param paymentInstructionDtls Contains the payment instruction relating to
   * the payment being regenerated.
   *
   * @throws AppException
   * {@link BPOCREATECANCELLATION#ERR_PMTINSTRUMENT_RV_REGENERATE_INVALID
   * ERR_PMTINSTRUMENT_RV_REGENERATE_INVALID} - if the payment being
   * regenerated has already been invalidated.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void validatePaymentInstrument(
    final PaymentInstructionDtls paymentInstructionDtls)
    throws AppException, InformationalException {

    final IsPaymentInvalidatedKey isPaymentInvalidatedKey =
      new IsPaymentInvalidatedKey();

    isPaymentInvalidatedKey.key.pmtInstrumentID =
      paymentInstructionDtls.pmtInstrumentID;

    if (isPaymentInvalidated(isPaymentInvalidatedKey).result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_REGENERATE_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that the nominees 'date of death' has not been specified or that
   * the death has not been confirmed.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   *
   * @throws AppException
   * {@link BPOCREATECANCELLATION#ERR_CASENOMINEE_RV_DECEASED
   * ERR_CASENOMINEE_RV_DECEASED} - if the case nominee is confirmed to be
   * deceased.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void validateDateOfDeath(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails)
    throws AppException, InformationalException {

    final CaseNomineeViewKey caseNomineeViewKey = new CaseNomineeViewKey();

    caseNomineeViewKey.caseNomineeID =
      regenerateForNewNomineeDetails.caseNomineeID;

    // Use the concern role ID of the nominee to get the concern type
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = CaseNomineeFactory.newInstance()
      .readCaseNomineeDetails(caseNomineeViewKey).concernRoleID;

    final ConcernRoleNameTypeDateDetails concernRoleNameTypeDateDetails =
      ConcernRoleFactory.newInstance().readNameTypeAndDate(concernRoleKey);

    if (concernRoleNameTypeDateDetails.concernRoleType
      .equals(CONCERNROLETYPE.PERSON)) {

      // Read nominees date of death details
      final CaseNomineeIDKey caseNomineeIDKey = new CaseNomineeIDKey();

      caseNomineeIDKey.caseNomineeID =
        regenerateForNewNomineeDetails.caseNomineeID;

      final DateOfDeathDetails dateOfDeathDetails = PersonFactory
        .newInstance().readDateOfDeathByCaseNomineeID(caseNomineeIDKey);

      // If the nominee is verified as deceased
      if (!dateOfDeathDetails.dateOfDeath.isZero()
        && dateOfDeathDetails.dateOfDeathVerInd) {

        final AppException e =
          new AppException(BPOCREATECANCELLATION.ERR_CASENOMINEE_RV_DECEASED);

        e.arg(dateOfDeathDetails.dateOfDeath);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(e,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // BEGIN, CR00358063, KRK
  /**
   * Validates that the case has a valid status for payment regeneration.
   *
   * @param iliDtls Contains the case identifier.
   *
   * @throws AppException
   * @throws AppException
   * {@link BPOCREATECANCELLATION#ERR_PMTINSTRUMENT_RV_REGENERATE_ACTIVECLOSEDCASES_ONLY
   * ERR_PMTINSTRUMENT_RV_REGENERATE_ACTIVECLOSEDCASES_ONLY} - if the case is
   * not
   * in a active, closed or pending closure state for payment regeneration.
   * @throws AppException
   * {@link BPOCREATECANCELLATION#ERR_PMTINSTRUMENT_RV_GENPAYMENT_ACTIVESUSPENDEDCASES_ONLY
   * ERR_PMTINSTRUMENT_RV_GENPAYMENT_ACTIVESUSPENDEDCASES_ONLY} - if the case is
   * not
   * in a active, suspended, pending closure state for payment regeneration.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void validateCaseStatus(final InstructionLineItemDtls iliDtls)
    throws AppException, InformationalException {

    // No financial components should be processed if the case status
    // is suspended and the curam.miscapp.payuptosuspendeddate property
    // is set to NO.
    final Boolean issuePaymentToSuspendDate = Configuration
      .getBooleanProperty(EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE,
        Configuration.getBooleanProperty(
          EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE_DEFAULT));

    // No financial components should be processed if the case status
    // is closed and the curam.miscapp.payuptocloseddate property
    // is set to NO.
    final Boolean issuePaymentToClosedDate = Configuration.getBooleanProperty(
      EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE,
      Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE_DEFAULT));

    // END, CR00358063

    // Only check the case status if the caseID is set. Third party payment
    // ILIs, for example, will not have a caseID.
    if (iliDtls.caseID != 0) {

      final CaseHeaderKey key = new CaseHeaderKey();

      key.caseID = iliDtls.caseID;

      final CaseStatusCode status =
        CaseHeaderFactory.newInstance().readCaseStatus(key);

      // BEGIN, CR00358063, KRK
      if (!issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

        if (!CASESTATUSEntry.ACTIVE.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.PENDINGCLOSURE.getCode()
            .equals(status.statusCode)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .throwWithLookup(new AppException(
              BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_REGENERATE_INVALIDCASESTATUS),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      } else if (issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

        if (!CASESTATUSEntry.ACTIVE.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.SUSPENDED.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.PENDINGCLOSURE.getCode()
            .equals(status.statusCode)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .throwWithLookup(new AppException(
              BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_GENPAYMENT_ACTIVESUSPENDEDCASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      } else if (!issuePaymentToSuspendDate && issuePaymentToClosedDate) {

        if (!CASESTATUSEntry.ACTIVE.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.CLOSED.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.PENDINGCLOSURE.getCode()
            .equals(status.statusCode)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .throwWithLookup(new AppException(
              BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_REGENERATE_ACTIVECLOSEDCASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      } else {
        if (!CASESTATUSEntry.ACTIVE.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.SUSPENDED.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.CLOSED.getCode().equals(status.statusCode)
          && !CASESTATUSEntry.PENDINGCLOSURE.getCode()
            .equals(status.statusCode)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .throwWithLookup(new AppException(
              BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_REGENERATE_ACTIVESUSPENDEDCLOSEDCASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
      // END, CR00358063
    }
  }

  // ___________________________________________________________________________
  /**
   * Regenerate all payment information to the new nominee specified. This
   * includes instruction line items, financial components and case nominee
   * objectives.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void regenerateAllPaymentDetails(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails)
    throws AppException, InformationalException {

    // Populate concernRoleIDOpt if it isn't already populated
    if (regenerateForNewNomineeDetails.caseNomineeID != 0
      && regenerateForNewNomineeDetails.concernRoleIDOpt == 0) {

      final CaseNomineeViewKey caseNomineeViewKey = new CaseNomineeViewKey();
      caseNomineeViewKey.caseNomineeID =
        regenerateForNewNomineeDetails.caseNomineeID;

      final curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails =
        CaseNomineeFactory.newInstance()
          .readCaseNomineeDetails(caseNomineeViewKey);

      regenerateForNewNomineeDetails.concernRoleIDOpt =
        caseNomineeDetails.concernRoleID;
    }

    // Return struct. Stores the new instruction line items
    final InstructionLineItemDtlsList newInstructionLineItemDtlsList =
      new InstructionLineItemDtlsList();

    final FinancialComponent financialComponentObj =
      FinancialComponentFactory.newInstance();

    /*
     * Holds IDs of all the rules objectives that have been regenerated. This
     * is used to updated the case nominee objectives to reflect the fact that
     * a new nominee was receiving that component for that period.
     */
    final ArrayList<String> rulesObjectiveIDList = new ArrayList<String>();

    // Holds the ID of the original financial component
    final FinancialComponentKey originalFCKey = new FinancialComponentKey();

    // Holds the regenerated FC details along with the original FC ID
    final HashMap<Long, FinancialComponentDtls> regeneratedFCMap =
      new HashMap<Long, FinancialComponentDtls>();

    /*
     * Read the current instruction line items based on the financial
     * instruction identifier passed in
     */
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID =
      regenerateForNewNomineeDetails.finInstructionID;

    final InstructionLineItemDtlsList originalILIDtlsList =
      InstructionLineItemFactory.newInstance()
        .searchByFinInstructionID(iliFinInstructID);

    Long replacementCaseNomineeID = 0L;

    for (int i = 0; i < originalILIDtlsList.dtls.size(); i++) {

      validateCaseStatus(originalILIDtlsList.dtls.item(i));

      if (!originalILIDtlsList.dtls.item(i).instructionLineItemType
        .equals(ILITYPE.TAXPAYMENT)) {

        final ProductDeliveryPatternInfoDtls newNomProdDelPatternInfoDtls =
          compareNomineeDeliveryPattern(regenerateForNewNomineeDetails,
            originalILIDtlsList.dtls.item(i));

        /*
         * Get the delivery method type for new case nominee (in case it is
         * different from the original nominee) and use it on newly generated
         * instruction line items
         */
        final DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

        deliveryMethodKey.deliveryMethodID =
          newNomProdDelPatternInfoDtls.deliveryMethodID;
        final DeliveryMethodDtls deliveryMethodDtls =
          DeliveryMethodFactory.newInstance().read(deliveryMethodKey);

        // BEGIN, CR00314367, SG
        final CaseNomineeCaseIDKey caseNomineeCaseIDKey =
          new CaseNomineeCaseIDKey();

        caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID =
          originalILIDtlsList.dtls.item(i).caseID;
        final CaseNomineeDetailsList caseNomineeDetailsList =
          curam.core.sl.fact.CaseNomineeFactory.newInstance()
            .listCaseNominee(caseNomineeCaseIDKey);

        // END, CR00314367

        // If this ILI belongs with a new FC that we have already copied we
        // only need to extend the new FC end date to include these dates
        if (originalFCKey.financialCompID == originalILIDtlsList.dtls
          .item(i).financialCompID) {

          regeneratedFCMap.get(originalFCKey.financialCompID).endDate =
            originalILIDtlsList.dtls.item(i).coverPeriodTo;

        } else { // We need a new FC before we can create the new ILIs for it

          // Read the FC for the original nominee
          originalFCKey.financialCompID =
            originalILIDtlsList.dtls.item(i).financialCompID;
          final FinancialComponentDtls regeneratedFCDtls =
            financialComponentObj.read(originalFCKey);

          // Update the FC values to refer to the new nominee
          regeneratedFCDtls.financialCompID =
            UniqueIDFactory.newInstance().getNextID();
          regeneratedFCDtls.startDate =
            originalILIDtlsList.dtls.item(i).coverPeriodFrom;
          regeneratedFCDtls.endDate =
            originalILIDtlsList.dtls.item(i).coverPeriodTo;

          replacementCaseNomineeID = getReplacementCaseNomineeID(
            caseNomineeDetailsList, regenerateForNewNomineeDetails);

          if (replacementCaseNomineeID != 0L) {
            regeneratedFCDtls.caseNomineeID = replacementCaseNomineeID;
          }

          regeneratedFCDtls.nomineeDelivMethod = deliveryMethodDtls.name;
          regeneratedFCDtls.statusCode = FINCOMPONENTSTATUS.CLOSED_OUTOFDATE;

          regeneratedFCMap.put(originalFCKey.financialCompID,
            regeneratedFCDtls);
        }

        // Copy the old instruction line item and update the values
        InstructionLineItemDtls newInstructionLineItemDtls =
          new InstructionLineItemDtls();

        newInstructionLineItemDtls = originalILIDtlsList.dtls.item(i);
        newInstructionLineItemDtls.financialCompID =
          regeneratedFCMap.get(originalFCKey.financialCompID).financialCompID;
        newInstructionLineItemDtls.finInstructionID = 0;

        // BEGIN, CR00314367, SG
        if (replacementCaseNomineeID != 0) {
          newInstructionLineItemDtls.caseNomineeID = replacementCaseNomineeID;
        }
        // END, CR00314367

        newInstructionLineItemDtls.deliveryMethodType =
          deliveryMethodDtls.name;

        // Add to the list of copied instruction line items
        newInstructionLineItemDtlsList.dtls
          .addRef(newInstructionLineItemDtls);

        // If the objective is specified but not already in our list add it
        if (!regeneratedFCMap.get(originalFCKey.financialCompID).categoryCode
          .equals(FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM)
          && !rulesObjectiveIDList.contains(regeneratedFCMap
            .get(originalFCKey.financialCompID).rulesObjectiveID)
          && regeneratedFCMap
            .get(originalFCKey.financialCompID).rulesObjectiveID
              .length() != 0) {

          rulesObjectiveIDList.add(regeneratedFCMap
            .get(originalFCKey.financialCompID).rulesObjectiveID);
        }
      } // end if !ILITYPE.TAXPAYMENT
    } // end for i

    // BEGIN, CR00189791, KH
    /*
     * Used to insert a link record between the regenerated financial component
     * and the original case decision.
     */
    final CaseDecisionFinancialComp caseDecisionFinancialCompObj =
      CaseDecisionFinancialCompFactory.newInstance();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    final FinancialCompIDKey fcLinkKey = new FinancialCompIDKey();

    // END, CR00189791

    // Insert the regenerated FCs. The FCs must be inserted before the ILIs
    for (final Iterator<Long> j = regeneratedFCMap.keySet().iterator(); j
      .hasNext();) {
      final Long mapKey = j.next();

      FinancialComponentFactory.newInstance()
        .insert(regeneratedFCMap.get(mapKey));

      // BEGIN, CR00189791, KH
      /*
       * Get the link record for the original financial component and use this
       * as the template for the new link to the regenerated financial component
       */
      fcLinkKey.financialCompID = mapKey;

      final CaseDecisionFinancialCompDtls linkDtls =
        caseDecisionFinancialCompObj.readByFinancialCompID(nfIndicator,
          fcLinkKey);

      if (!nfIndicator.isNotFound()) {
        linkDtls.caseDecisionFinCompID =
          UniqueIDFactory.newInstance().getNextID();
        linkDtls.financialCompID =
          regeneratedFCMap.get(mapKey).financialCompID;
        linkDtls.versionNo = 0; // Reset this
        caseDecisionFinancialCompObj.insert(linkDtls);
      }
      // END, CR00189791

      // BEGIN, CR00148291, KH
      /*
       * Perform validation on the case nominee objective assignment. This must
       * be done while we have access to the FC details because the validation
       * needs access to the rule set and if this is an underpayment on an
       * original benefit case we cannot use the rule set for the case, we need
       * the underpayment rule set. We use the FC details to find this.
       */
      if (regeneratedFCMap.get(mapKey).rulesObjectiveID.trim()
        .length() != 0) {
        final FinancialCompIDKey finCompIDKey = new FinancialCompIDKey();

        finCompIDKey.financialCompID = mapKey;

        final CaseNomObjDetails caseNomineeObjDetails =
          new CaseNomObjDetails();

        // BEGIN, CR00263690, CW
        // Validate against the primary case nominee on the case of the
        // regenerated FC.
        // This will ensure the correct rule set for that case is used for
        // validation.
        final DefaultCaseNomineeKey defaultCaseNomineeKey =
          new DefaultCaseNomineeKey();

        defaultCaseNomineeKey.caseID = regeneratedFCMap.get(mapKey).caseID;
        defaultCaseNomineeKey.defaultNomInd = true;

        final DefaultCaseNomineeDetails defaultCaseNomineeDetails =
          CaseNomineeFactory.newInstance()
            .readDefaultCaseNominee(defaultCaseNomineeKey);

        caseNomineeObjDetails.dtls.caseNomineeID =
          defaultCaseNomineeDetails.caseNomineeID;
        // END, CR00263690

        caseNomineeObjDetails.dtls.rulesObjectiveID =
          regeneratedFCMap.get(mapKey).rulesObjectiveID.trim();

        curam.core.sl.fact.CaseNomineeFactory.newInstance()
          .validateCaseNomineeObjective(caseNomineeObjDetails, finCompIDKey);
      }
      // END, CR00148291

      final FinancialComponentKey fcKey = new FinancialComponentKey();

      fcKey.financialCompID = mapKey;

      linkDeductionFinancialComponent(fcKey, regeneratedFCMap.get(mapKey));
    } // end for j

    // Insert the regenerated ILIs
    for (int k = 0; k < newInstructionLineItemDtlsList.dtls.size(); k++) {

      MaintainInstructionLineItemFactory.newInstance()
        .regenerateILI(newInstructionLineItemDtlsList.dtls.item(k));
    } // end for k

    // BEGIN, CR00139636, KH
    final FinCompCoverPeriod coverPeriod = new FinCompCoverPeriod();

    for (int m = 0; m < rulesObjectiveIDList.size(); m++) {

      /*
       * We need to process the cover period of each ILI individually. The cover
       * period of a payment runs from the earliest ILI from date to the latest
       * ILI to date, but this full cover period could in fact contain 'blanks',
       * i.e. dates for which this nominee was not paid and no ILI exists. If
       * we use the full payment cover period we risk reassigning these 'blank'
       * periods by mistake.
       */
      for (int n = 0; n < originalILIDtlsList.dtls.size(); n++) {

        // BEGIN, CR00139716, CR00141807, CR00175205, KH
        if (!originalILIDtlsList.dtls.item(n).instructionLineItemType
          .equals(ILITYPE.TAXPAYMENT)
          && !originalILIDtlsList.dtls.item(n).instructionLineItemType
            .equals(ILITYPE.DEDUCTIONITEM)
          && !originalILIDtlsList.dtls.item(n).instructionLineItemType
            .equals(ILITYPE.BENEFITUNDERPAYMENT)) {
          // END, CR00141807, CR00175205

          // Only process the ILI if it matches the current objective
          originalFCKey.financialCompID =
            originalILIDtlsList.dtls.item(n).financialCompID;

          if (financialComponentObj.read(originalFCKey).rulesObjectiveID
            .equals(rulesObjectiveIDList.get(m))) {

            // Set cover period based on current ILI
            coverPeriod.coverPeriodFrom =
              originalILIDtlsList.dtls.item(n).coverPeriodFrom;
            coverPeriod.coverPeriodTo =
              originalILIDtlsList.dtls.item(n).coverPeriodTo;

            final CaseObjectiveKey caseObjectiveKey = new CaseObjectiveKey();

            caseObjectiveKey.caseID = originalILIDtlsList.dtls.item(n).caseID;
            caseObjectiveKey.rulesObjectiveID = rulesObjectiveIDList.get(m);

            regenerateCaseNomineeObjectives(regenerateForNewNomineeDetails,
              coverPeriod, caseObjectiveKey);
          }
        } // end if !TAXPAYMENT
        // END, CR00139716
      } // end for n
    } // end for m
    // END, CR00139636
  }

  /**
   * Finds the replacement caseNomineeID for the regenerated payment.
   * <p>
   * It is actually possible for this API to return a replacement case nominee
   * identifier of zero. This can happen in the scenario where a payment is
   * <p>
   * <ul>
   * <li>rolled up across two cases, A & B, say
   * <li>a new case nominee has been added to one of the cases (A, for example)
   * <li>the payment is canceled and regenerated to the new case nominee
   * </ul>
   * <p>
   * In the above scenario, the case nominee to whom the payment is being
   * regenerated won't exist on case B, which will result in this API returning
   * zero.
   *
   * @param list List of case nominees that exist on a case
   * @param details Regenerate payment details, including the case nominee to
   * whom the payment is being regenerated
   *
   * @return Replacement case nominee identifier
   */
  Long getReplacementCaseNomineeID(final CaseNomineeDetailsList list,
    final RegeneratePaymentForNewNomineeDetails details) {

    Long replacementCaseNomineeID = 0L;

    // Try to match on caseNomineeID first
    for (final CaseNomineeDetails caseNomineeDetails : list.caseNomineeDetailsList
      .items()) {
      if (caseNomineeDetails.caseNomineeID == details.caseNomineeID) {
        replacementCaseNomineeID = details.caseNomineeID;
        break;
      }
    }

    // If no match is found then try to match on concernRoleID, as we may be
    // dealing with a payment that is rolled up across cases
    if (replacementCaseNomineeID == 0L) {
      for (final CaseNomineeDetails caseNomineeDetails : list.caseNomineeDetailsList
        .items()) {
        if (caseNomineeDetails.concernRoleID == details.concernRoleIDOpt) {
          replacementCaseNomineeID = caseNomineeDetails.caseNomineeID;
          break;
        }
      }
    }

    return replacementCaseNomineeID;
  }

  /**
   * Clones the case nominee details on the target case.
   *
   * @param details Regenerate payment case nominee details
   * @param lineItem Target case identifier
   *
   * @throws AppException Generic Exception Message
   * @throws InformationalException Generic Exception Message
   */
  Long cloneCaseNominee(final RegeneratePaymentForNewNomineeDetails details,
    final InstructionLineItemDtls lineItem)
    throws AppException, InformationalException {

    // Read the details of the replacement case nominee
    final CaseNomineeKey replacementCaseNomineeKey = new CaseNomineeKey();
    replacementCaseNomineeKey.caseNomineeID = details.caseNomineeID;

    final CaseNomineeDtls replacementCaseNomineeDtls =
      CaseNomineeFactory.newInstance().read(replacementCaseNomineeKey);

    // Find the concernRoleID of the original caseNomineeID
    final curam.core.sl.struct.CaseNomineeViewKey caseNomineeViewKey =
      new curam.core.sl.struct.CaseNomineeViewKey();
    caseNomineeViewKey.caseNomineeViewKey.caseNomineeID =
      lineItem.caseNomineeID;

    final CaseNomineeViewDetails caseNomineeViewDetails =
      curam.core.sl.fact.CaseNomineeFactory.newInstance()
        .viewCaseNomineeDetails(caseNomineeViewKey);

    final CaseNomineeCreationDetails caseNomineeCreationDetails =
      new CaseNomineeCreationDetails();
    caseNomineeCreationDetails.caseNomineeCreationDetails.caseID =
      lineItem.caseID;
    caseNomineeCreationDetails.caseNomineeCreationDetails.concernRoleID =
      details.concernRoleIDOpt;
    caseNomineeCreationDetails.caseNomineeDtls.caseNomineeID =
      UniqueIDFactory.newInstance().getNextID();
    caseNomineeCreationDetails.caseNomineeDtls.currencyType =
      replacementCaseNomineeDtls.currencyType;
    caseNomineeCreationDetails.caseNomineeDtls.nomineeRelationship =
      replacementCaseNomineeDtls.nomineeRelationship;

    curam.core.sl.fact.CaseNomineeFactory.newInstance()
      .createCaseNominee(caseNomineeCreationDetails);

    return caseNomineeCreationDetails.caseNomineeDtls.caseNomineeID;
  }

  // ___________________________________________________________________________
  /**
   * Regenerates any deduction ILIs that were contained in the payment being
   * regenerated.
   *
   * @param originalILIDtlsList The list of ILIs which comprise the original
   * payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void regenerateDeductions(
    final InstructionLineItemDtlsList originalILIDtlsList)
    throws AppException, InformationalException {

    final InstructionLineItemDtlsList deductionILIDtlsList =
      getRelatedDeductions(originalILIDtlsList);

    for (int i = 0; i < deductionILIDtlsList.dtls.size(); i++) {

      deductionILIDtlsList.dtls.item(i).unprocessedAmount =
        deductionILIDtlsList.dtls.item(i).amount;

      MaintainInstructionLineItemFactory.newInstance()
        .regenerateILI(deductionILIDtlsList.dtls.item(i));
    }
  }

  // ___________________________________________________________________________
  /**
   * Compares the current product delivery pattern info details for the new
   * nominee and the nominee who was originally paid. Both need to have the
   * same delivery frequency for payment regeneration to be possible. If the
   * delivery pattern of the new nominee starts later than the cover period of
   * the payment being regenerated their delivery pattern will be extended.
   *
   * @param regenerateForNewNomineeDetails Contains the new nominee ID.
   * @param instructionLineItemDtls Contains the original nominee ID.
   *
   * @return The product delivery patten info for the new nominee.
   *
   * @throws AppException
   * {@link BPOCREATECANCELLATION#ERR_DELIVERYFREQUENCY_XRV_MUST_BE_THE_SAME
   * ERR_DELIVERYFREQUENCY_XRV_MUST_BE_THE_SAME} - if the delivery frequency
   * of the new nominee is not the same as that of the original nominee.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected ProductDeliveryPatternInfoDtls compareNomineeDeliveryPattern(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    final CaseNomineeProdDelPattern caseNomineeProdDelPatternObj =
      CaseNomineeProdDelPatternFactory.newInstance();
    final ProductDeliveryPatternInfo productDeliveryPatternInfoObj =
      ProductDeliveryPatternInfoFactory.newInstance();

    // Read NEW case nominee product delivery pattern details
    final ReadEffectiveByDateKey readEffectiveByDateKey =
      new ReadEffectiveByDateKey();

    readEffectiveByDateKey.caseNomineeID =
      regenerateForNewNomineeDetails.caseNomineeID;
    // BEGIN, CR00165991
    readEffectiveByDateKey.effectiveDate =
      instructionLineItemDtls.coverPeriodFrom;
    // END, CR00165991
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;

    // BEGIN, CR00165991, KH
    // BEGIN, CR00211744, VM
    CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls =
      assessmentEngineEntity
        .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);

    // END, CR00211744

    // If the new nominee's delivery pattern starts later than the cover
    // period of the ILI, we need to extend the from date of the earliest
    // delivery pattern for that nominee
    if (caseNomineeProdDelPatternDtls == null) {

      // BEGIN, CR00211744, VM
      final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

      caseNomineeKey.caseNomineeID =
        regenerateForNewNomineeDetails.caseNomineeID;

      caseNomineeProdDelPatternDtls =
        assessmentEngineEntity.getEarliestCaseNomineePattern(caseNomineeKey);
      // END, CR00211744

      final CaseNomineeProdDelPatternKey caseNomineeProdDelPatternKey =
        new CaseNomineeProdDelPatternKey();

      caseNomineeProdDelPatternKey.caseNomineeProdDelPatternID =
        caseNomineeProdDelPatternDtls.caseNomineeProdDelPatternID;

      // The from date should be taken from the ILI being regenerated
      caseNomineeProdDelPatternDtls.fromDate =
        instructionLineItemDtls.coverPeriodFrom;

      caseNomineeProdDelPatternObj.modify(caseNomineeProdDelPatternKey,
        caseNomineeProdDelPatternDtls);
    }
    // END, CR00165991

    // Read nearest product delivery pattern info details for NEW nominee
    final PDPIByProdDelPatIDStatusAndDateKey pDPIByProdDelPatIDStatusAndDateKey =
      new PDPIByProdDelPatIDStatusAndDateKey();

    pDPIByProdDelPatIDStatusAndDateKey.productDeliveryPatternID =
      caseNomineeProdDelPatternDtls.productDeliveryPatternID;
    // BEGIN, CR00165991, KH
    pDPIByProdDelPatIDStatusAndDateKey.effectiveDate =
      instructionLineItemDtls.coverPeriodFrom;
    // END, CR00165991
    pDPIByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;

    final ProductDeliveryPatternInfoDtls newNomProdDelPatternInfoDtls =
      productDeliveryPatternInfoObj
        .readNearestProdDelPatInfo(pDPIByProdDelPatIDStatusAndDateKey);

    // Read ORIGINAL case nominee product delivery pattern details
    readEffectiveByDateKey.caseNomineeID =
      instructionLineItemDtls.caseNomineeID;
    // BEGIN, CR00165991, KH
    readEffectiveByDateKey.effectiveDate =
      instructionLineItemDtls.coverPeriodFrom;
    // END, CR00165991
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;

    // BEGIN, CR00211744, VM
    caseNomineeProdDelPatternDtls = assessmentEngineEntity
      .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
    // END, CR00211744

    // Read nearest product delivery pattern info details for ORIGINAL nominee
    pDPIByProdDelPatIDStatusAndDateKey.productDeliveryPatternID =
      caseNomineeProdDelPatternDtls.productDeliveryPatternID;
    // BEGIN, CR00165991, KH
    pDPIByProdDelPatIDStatusAndDateKey.effectiveDate =
      instructionLineItemDtls.coverPeriodFrom;
    // END, CR00165991
    pDPIByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;

    final ProductDeliveryPatternInfoDtls currentNomProdDelPatternInfoDtls =
      productDeliveryPatternInfoObj
        .readNearestProdDelPatInfo(pDPIByProdDelPatIDStatusAndDateKey);

    // If the delivery frequency of the original and the new nominee do not
    // match the regeneration cannot continue
    if (!currentNomProdDelPatternInfoDtls.deliveryFrequency
      .equals(newNomProdDelPatternInfoDtls.deliveryFrequency)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_DELIVERYFREQUENCY_XRV_MUST_BE_THE_SAME),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return newNomProdDelPatternInfoDtls;
  }

  // ___________________________________________________________________________
  /**
   * For a deduction financial component (FC) this method sets up a link between
   * the deduction FC and the corresponding case deduction item.
   *
   * @param originalFCKey The ID of the original FC.
   * @param newFCDtls The new FC ID to be linked to the case deduction item.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void linkDeductionFinancialComponent(
    final FinancialComponentKey originalFCKey,
    final FinancialComponentDtls newFCDtls)
    throws AppException, InformationalException {

    // If this is a deduction FC read the case deduction item ID for use when
    // regenerating the CDI/FC link
    if (newFCDtls.typeCode.equals(FINCOMPONENTTYPE.DEDUCTIONPAYMENT)) {

      final CaseDeductionItemFinCompID caseDeductionItemFinCompID =
        new CaseDeductionItemFinCompID();

      caseDeductionItemFinCompID.financialCompID =
        originalFCKey.financialCompID;

      // BEGIN, CR00165445, KH
      try {
        final CaseDeductionItemDtls caseDeductionItemDtls =
          CaseDeductionItemFactory.newInstance()
            .readByFinancialCompID(caseDeductionItemFinCompID);

        final CaseDeductionItemFCLinkDtls caseDeductionItemFCLinkDtls =
          new CaseDeductionItemFCLinkDtls();

        caseDeductionItemFCLinkDtls.caseDeductionItemFCLinkID =
          UniqueIDFactory.newInstance().getNextID();
        caseDeductionItemFCLinkDtls.financialComponentID =
          newFCDtls.financialCompID;
        caseDeductionItemFCLinkDtls.caseDeductionItemID =
          caseDeductionItemDtls.caseDeductionItemID;

        CaseDeductionItemFCLinkFactory.newInstance()
          .insert(caseDeductionItemFCLinkDtls);
      } catch (final RecordNotFoundException rnfe) {// If we cannot find the
        // original
        // case deduction item, we must be
        // regenerating a payment with a migrated deduction ILI. In this case
        // we won't be able to create a link. This won't affect any
        // functionality it just means that some traceability is lost.
      }
      // END, CR00165445
    }
  }

  // ___________________________________________________________________________
  /**
   * Updates the case nominee objective records to reflect the fact that the
   * nominee receiving this component has changed for this period because the
   * initial payment has been regenerated to a new nominee.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void regenerateCaseNomineeObjectives(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey)
    throws AppException, InformationalException {

    final CaseNomineeObjective caseNomineeObjectiveObj =
      CaseNomineeObjectiveFactory.newInstance();

    // When searching, extend the payment cover period by one day at the start
    // and end to return 'adjacent' existing records which might be relevant.
    caseObjectiveKey.fromDate = coverPeriod.coverPeriodFrom.addDays(-1);
    caseObjectiveKey.toDate = coverPeriod.coverPeriodTo.addDays(1);
    caseObjectiveKey.statusCode = CONTRIBRECORDSTATUS.NORMAL;

    final CaseNomineeObjectiveDtlsList caseNomineeObjectiveDtlsList =
      caseNomineeObjectiveObj
        .searchOverlappingObjectiveByCoverPeriod(caseObjectiveKey);

    if (caseNomineeObjectiveDtlsList.dtls.size() == 0) {
      // No overlapping case nominee objective found, add a new one

      createRegeneratedCaseNomineeObjective(regenerateForNewNomineeDetails,
        coverPeriod, caseObjectiveKey);

    } else if (caseNomineeObjectiveDtlsList.dtls.size() == 1) {
      // The existing case nominee objective record either overlaps with the
      // cover period of the regenerated payment or is adjacent to it.

      final CaseNomineeObjectiveDtls objectiveDtls =
        caseNomineeObjectiveDtlsList.dtls.item(0);

      if (objectiveDtls.fromDate.equals(coverPeriod.coverPeriodFrom)
        && objectiveDtls.toDate.equals(coverPeriod.coverPeriodTo)) {

        // The existing record is an exact match
        processMatchingObjective(regenerateForNewNomineeDetails, coverPeriod,
          caseObjectiveKey, objectiveDtls);

        // BEGIN, CR00130842, CR00139636, KH
      } else if (!objectiveDtls.fromDate.after(coverPeriod.coverPeriodTo)
        && (!objectiveDtls.toDate.before(coverPeriod.coverPeriodFrom)
          || objectiveDtls.toDate.isZero())) {
        // END, CR00130842, CR00139636

        // The existing record overlaps
        processOverlappingObjective(regenerateForNewNomineeDetails,
          coverPeriod, caseObjectiveKey, objectiveDtls);

      } else {
        // There is no overlap, the cover period of the regenerated payment is
        // adjacent to an existing record, this record may need to be modified
        processAdjacentObjective(regenerateForNewNomineeDetails, coverPeriod,
          caseObjectiveKey, objectiveDtls);
      }

    } else if (caseNomineeObjectiveDtlsList.dtls.size() == 2) {
      // The existing case nominee objective record overlaps with the cover
      // period of the regenerated payment and there is an additional adjacent
      // objective record OR there are two adjacent case nominee objectives
      // records (in the situation where the objective was previously assigned
      // to the default nominee for the cover period of the regenerated payment)

      if (caseNomineeObjectiveDtlsList.dtls.item(0).toDate.equals(
        caseNomineeObjectiveDtlsList.dtls.item(1).fromDate.addDays(-1))) {

        // One overlapping record and one adjacent record exist
        processOverlappingPlusAdjacentObjective(
          regenerateForNewNomineeDetails, coverPeriod, caseObjectiveKey,
          caseNomineeObjectiveDtlsList);

      } else {
        // Two adjacent case nominee objectives records exist
        processTwoAdjacentObjectives(regenerateForNewNomineeDetails,
          coverPeriod, caseObjectiveKey, caseNomineeObjectiveDtlsList);
      }

    } else if (caseNomineeObjectiveDtlsList.dtls.size() == 3) {
      // Two adjacent case nominee objectives records exist as well as an exact
      // match for the period being regenerated

      // The middle record is the exact match and must be replaced during the
      // payment regeneration process (since the payment is being regenerated to
      // a different nominee). Once cancelled, remove it from the list to leave
      // only the two adjacent objective records.
      final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

      key.caseNomineeObjectiveID =
        caseNomineeObjectiveDtlsList.dtls.item(1).caseNomineeObjectiveID;
      caseNomineeObjectiveDtlsList.dtls.item(1).statusCode =
        RECORDSTATUS.CANCELLED;
      caseNomineeObjectiveObj.modify(key,
        caseNomineeObjectiveDtlsList.dtls.item(1));

      caseNomineeObjectiveDtlsList.dtls.remove(1);

      processTwoAdjacentObjectives(regenerateForNewNomineeDetails,
        coverPeriod, caseObjectiveKey, caseNomineeObjectiveDtlsList);

    } else {// If more than 3 existing case nominee objective records are found
      // then
      // the payment being regenerated must have been made to more than a single
      // nominee. This should be impossible.
    }
  }

  // ___________________________________________________________________________
  /**
   * Cancels an existing case nominee objective record and replaces it with a
   * new one to cover the period of the regenerated payment.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   * @param details The case nominee objective details which overlap with the
   * cover period of the regenerated payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void processMatchingObjective(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey,
    final CaseNomineeObjectiveDtls details)
    throws AppException, InformationalException {

    final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

    key.caseNomineeObjectiveID = details.caseNomineeObjectiveID;

    details.statusCode = RECORDSTATUS.CANCELLED;
    CaseNomineeObjectiveFactory.newInstance().modify(key, details);

    createRegeneratedCaseNomineeObjective(regenerateForNewNomineeDetails,
      coverPeriod, caseObjectiveKey);
  }

  // ___________________________________________________________________________
  /**
   * Updates the cover period of the existing case nominee objective record
   * which overlaps with the cover period of the regenerated payment. A new case
   * nominee objective record may be inserted if the existing overlapping record
   * is for a different nominee to the regenerated payment.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   * @param details The case nominee objective details which overlap with the
   * cover period of the regenerated payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void processOverlappingObjective(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey,
    final CaseNomineeObjectiveDtls details)
    throws AppException, InformationalException {

    final CaseNomineeObjective caseNomineeObjectiveObj =
      CaseNomineeObjectiveFactory.newInstance();

    if (regenerateForNewNomineeDetails.caseNomineeID == details.caseNomineeID) {

      // The nominees are the same so the case nominee objective should be
      // extended to have the earliest from date and the latest to date
      if (coverPeriod.coverPeriodFrom.before(details.fromDate)) {
        details.fromDate = coverPeriod.coverPeriodFrom;
      }
      if (coverPeriod.coverPeriodTo.after(details.toDate)) {
        details.toDate = coverPeriod.coverPeriodTo;
      }
    } else {
      // The nominees are different so the existing record needs to be
      // broken up and a new one entered.

      // BEGIN, CR00130842, CR00139636, KH
      // The regenerated payment is completely inside the existing case nominee
      // objective period, split the existing record into two, to leave space
      // for the new case nominee objective record.
      if (details.fromDate.before(coverPeriod.coverPeriodFrom)
        && (details.toDate.after(coverPeriod.coverPeriodTo)
          || details.toDate.isZero())) {
        // END, CR00130842, CR00139636

        // Copy the details of the existing case nominee objective
        final CaseNomineeObjectiveDtls newObjectivedetails =
          new CaseNomineeObjectiveDtls();

        newObjectivedetails.assign(details);

        // Update the new record to start immediately after the regenerated
        // payment period (and have a unique ID) and insert it.
        newObjectivedetails.caseNomineeObjectiveID =
          UniqueIDFactory.newInstance().getNextID();
        newObjectivedetails.fromDate = coverPeriod.coverPeriodTo.addDays(1);

        CaseNomineeObjectiveFactory.newInstance().insert(newObjectivedetails);

        // Update the existing record to end immediately before the regenerated
        // payment period
        details.toDate = coverPeriod.coverPeriodFrom.addDays(-1);

      } else {
        // We only need to modify from/to date of the existing record
        if (details.fromDate.before(coverPeriod.coverPeriodFrom)) {
          details.toDate = coverPeriod.coverPeriodFrom.addDays(-1);
        }
        // BEGIN, CR00139636, KH
        if (details.toDate.after(coverPeriod.coverPeriodTo)
          || details.toDate.isZero()) {
          // END, CR00139636

          details.fromDate = coverPeriod.coverPeriodTo.addDays(1);
        }
      }

      // Create the new record to cover regenerated payment period
      createRegeneratedCaseNomineeObjective(regenerateForNewNomineeDetails,
        coverPeriod, caseObjectiveKey);
    }

    final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

    key.caseNomineeObjectiveID = details.caseNomineeObjectiveID;

    caseNomineeObjectiveObj.modify(key, details);
  }

  // ___________________________________________________________________________
  /**
   * Updates the cover period of the existing case nominee objective record
   * which is adjacent to the cover period of the regenerated payment if they
   * both refer to the same nominee, otherwise a new case nominee objective
   * record is added for the nominee receiving the regenerated payment.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   * @param details The case nominee objective details adjacent to the cover
   * period of the regenerated payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void processAdjacentObjective(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey,
    final CaseNomineeObjectiveDtls details)
    throws AppException, InformationalException {

    // If the adjacent record is for a different nominee then ignore the
    // adjacent record and insert a new record for the new nominee.
    if (regenerateForNewNomineeDetails.caseNomineeID != details.caseNomineeID) {

      createRegeneratedCaseNomineeObjective(regenerateForNewNomineeDetails,
        coverPeriod, caseObjectiveKey);
      return;
    }

    // Otherwise it's the same nominee so extend the adjacent record
    if (coverPeriod.coverPeriodTo.equals(details.fromDate.addDays(-1))) {
      details.fromDate = coverPeriod.coverPeriodFrom;
    } else if (details.toDate
      .equals(coverPeriod.coverPeriodFrom.addDays(-1))) {
      details.toDate = coverPeriod.coverPeriodTo;
    }

    final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

    key.caseNomineeObjectiveID = details.caseNomineeObjectiveID;
    CaseNomineeObjectiveFactory.newInstance().modify(key, details);
  }

  // ___________________________________________________________________________
  /**
   * Updates the cover period of the existing case nominee objective records
   * which is adjacent to the cover period of the regenerated payment if it
   * refers to the same nominee. Updates the cover period of the existing case
   * nominee objective record which overlaps with the cover period of the
   * regenerated payment. A new case nominee objective record may be inserted
   * if the existing records are for a different nominee to the regenerated
   * payment.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   * @param list The relevant case nominee objective details including any which
   * are adjacent to the cover period of the regenerated payment, ordered by
   * from date ascending.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void processOverlappingPlusAdjacentObjective(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey,
    final CaseNomineeObjectiveDtlsList list)
    throws AppException, InformationalException {

    final CaseNomineeObjective caseNomineeObjectiveObj =
      CaseNomineeObjectiveFactory.newInstance();
    final CaseNomineeObjectiveDtls firstObjectiveDtls = list.dtls.item(0);
    final CaseNomineeObjectiveDtls secondObjectiveDtls = list.dtls.item(1);

    if (firstObjectiveDtls.fromDate.equals(coverPeriod.coverPeriodFrom)
      && firstObjectiveDtls.toDate.equals(coverPeriod.coverPeriodTo)) {

      // The first objective is an exact match, cancel it and process the
      // second objective as an adjacent
      final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

      key.caseNomineeObjectiveID = firstObjectiveDtls.caseNomineeObjectiveID;

      firstObjectiveDtls.statusCode = RECORDSTATUS.CANCELLED;
      caseNomineeObjectiveObj.modify(key, firstObjectiveDtls);

      processAdjacentObjective(regenerateForNewNomineeDetails, coverPeriod,
        caseObjectiveKey, secondObjectiveDtls);

      // BEGIN, CR00130842, CR00139636, KH
    } else if (!firstObjectiveDtls.fromDate.after(coverPeriod.coverPeriodTo)
      && (!firstObjectiveDtls.toDate.before(coverPeriod.coverPeriodFrom)
        || firstObjectiveDtls.toDate.isZero())) {
      // END, CR00130842, CR00139636

      // The first record overlaps, modify it and process the second
      // objective as an adjacent
      if (firstObjectiveDtls.fromDate.before(coverPeriod.coverPeriodFrom)) {
        firstObjectiveDtls.toDate = coverPeriod.coverPeriodFrom.addDays(-1);
      }
      // BEGIN, CR00139636, KH
      if (firstObjectiveDtls.toDate.after(coverPeriod.coverPeriodTo)
        || firstObjectiveDtls.toDate.isZero()) {
        // END, CR00139636

        firstObjectiveDtls.fromDate = coverPeriod.coverPeriodTo.addDays(1);
      }

      final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

      key.caseNomineeObjectiveID = firstObjectiveDtls.caseNomineeObjectiveID;
      caseNomineeObjectiveObj.modify(key, firstObjectiveDtls);

      processAdjacentObjective(regenerateForNewNomineeDetails, coverPeriod,
        caseObjectiveKey, secondObjectiveDtls);

    } else if (secondObjectiveDtls.fromDate
      .equals(coverPeriod.coverPeriodFrom)
      && secondObjectiveDtls.toDate.equals(coverPeriod.coverPeriodTo)) {

      // The second objective is an exact match, cancel it and process the
      // first objective as an adjacent
      final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

      key.caseNomineeObjectiveID = secondObjectiveDtls.caseNomineeObjectiveID;

      secondObjectiveDtls.statusCode = RECORDSTATUS.CANCELLED;
      caseNomineeObjectiveObj.modify(key, secondObjectiveDtls);

      processAdjacentObjective(regenerateForNewNomineeDetails, coverPeriod,
        caseObjectiveKey, firstObjectiveDtls);

      // BEGIN, CR00130842, CR00139636, KH
    } else if (!secondObjectiveDtls.fromDate.after(coverPeriod.coverPeriodTo)
      && (!secondObjectiveDtls.toDate.before(coverPeriod.coverPeriodFrom)
        || secondObjectiveDtls.toDate.isZero())) {
      // END, CR00130842, CR00139636

      // The second record overlaps, modify it and process the first
      // objective as an adjacent
      if (secondObjectiveDtls.fromDate.before(coverPeriod.coverPeriodFrom)) {
        secondObjectiveDtls.toDate = coverPeriod.coverPeriodFrom.addDays(-1);
      }
      // BEGIN, CR00139636, CR00139716, KH
      if (secondObjectiveDtls.toDate.after(coverPeriod.coverPeriodTo)
        || secondObjectiveDtls.toDate.isZero()) {
        // END, CR00139636, CR00139716

        secondObjectiveDtls.fromDate = coverPeriod.coverPeriodTo.addDays(1);
      }

      final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

      key.caseNomineeObjectiveID = secondObjectiveDtls.caseNomineeObjectiveID;
      caseNomineeObjectiveObj.modify(key, secondObjectiveDtls);

      processAdjacentObjective(regenerateForNewNomineeDetails, coverPeriod,
        caseObjectiveKey, firstObjectiveDtls);
    }
  }

  // ___________________________________________________________________________
  /**
   * Updates the cover period of the existing case nominee objective records
   * which are adjacent to the cover period of the regenerated payment if they
   * all refer to the same nominee, otherwise a new case nominee objective
   * record is added for the nominee receiving the regenerated payment.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   * @param list The relevant case nominee objective details including any which
   * are adjacent to the cover period of the regenerated payment, ordered by
   * from date ascending.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void processTwoAdjacentObjectives(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey,
    final CaseNomineeObjectiveDtlsList list)
    throws AppException, InformationalException {

    // If the new nominee is different to both adjacent nominees ignore the
    // adjacent records and insert a new record for the new nominee.
    if (regenerateForNewNomineeDetails.caseNomineeID != list.dtls
      .item(0).caseNomineeID
      && regenerateForNewNomineeDetails.caseNomineeID != list.dtls
        .item(1).caseNomineeID) {

      createRegeneratedCaseNomineeObjective(regenerateForNewNomineeDetails,
        coverPeriod, caseObjectiveKey);
      return;
    }

    // If the nominee's are all the same extend one record to cover the full
    // cover period and cancel the other
    if (regenerateForNewNomineeDetails.caseNomineeID == list.dtls
      .item(0).caseNomineeID
      && regenerateForNewNomineeDetails.caseNomineeID == list.dtls
        .item(1).caseNomineeID) {

      // Give the first record the earliest from date
      if (list.dtls.item(1).fromDate.before(list.dtls.item(0).fromDate)) {
        list.dtls.item(0).fromDate = list.dtls.item(1).fromDate;
      }

      // BEGIN, CR00139636, KH
      // Give the first record the latest to date
      if (list.dtls.item(1).toDate.after(list.dtls.item(0).toDate)
        || list.dtls.item(1).toDate.isZero()) {
        // END, CR00139636
        list.dtls.item(0).toDate = list.dtls.item(1).toDate;
      }

      // Update the first record with the new cover period
      final CaseNomineeObjectiveKey key = new CaseNomineeObjectiveKey();

      key.caseNomineeObjectiveID = list.dtls.item(0).caseNomineeObjectiveID;
      CaseNomineeObjectiveFactory.newInstance().modify(key,
        list.dtls.item(0));

      // Cancel the second record
      key.caseNomineeObjectiveID = list.dtls.item(1).caseNomineeObjectiveID;
      list.dtls.item(1).statusCode = RECORDSTATUS.CANCELLED;
      CaseNomineeObjectiveFactory.newInstance().modify(key,
        list.dtls.item(1));

      return;
    }

    // Otherwise extend which ever existing record has the same nominee and
    // ignore the other
    for (int i = 0; i < list.dtls.size(); i++) {

      if (regenerateForNewNomineeDetails.caseNomineeID == list.dtls
        .item(i).caseNomineeID) {

        processAdjacentObjective(regenerateForNewNomineeDetails, coverPeriod,
          caseObjectiveKey, list.dtls.item(i));
      }
    } // end for i
  }

  // ___________________________________________________________________________
  /**
   * Creates a case nominee objective record for the nominee who is receiving
   * the regenerated payment. If the new nominee is the default nominee for the
   * case there is no need to insert a record.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment.
   * @param coverPeriod The full cover period of the payment being regenerated.
   * @param caseObjectiveKey Contains the rules objective ID of the component.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void createRegeneratedCaseNomineeObjective(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final FinCompCoverPeriod coverPeriod,
    final CaseObjectiveKey caseObjectiveKey)
    throws AppException, InformationalException {

    // If the new nominee is the default nominee then we don't insert any case
    // nominee objective record
    final DefaultNomineeKey key = new DefaultNomineeKey();

    key.caseNomineeID = regenerateForNewNomineeDetails.caseNomineeID;

    if (CaseNomineeFactory.newInstance()
      .isDefaultNominee(key).defaultNomInd) {
      return;
    }

    // Populate the details struct
    final CaseNomineeObjectiveDtls caseNomineeObjectiveDtls =
      new CaseNomineeObjectiveDtls();

    // BEGIN, CR00295441, CW
    // Identify the case nominee ID for insertion of the objective
    final CaseNomineeID caseNomineeID = getCaseNomineeForObjective(
      regenerateForNewNomineeDetails, caseObjectiveKey);

    caseNomineeObjectiveDtls.caseNomineeID = caseNomineeID.caseNomineeID;
    // END, CR00295441
    caseNomineeObjectiveDtls.caseNomineeObjectiveID =
      UniqueIDFactory.newInstance().getNextID();
    caseNomineeObjectiveDtls.rulesObjectiveID =
      caseObjectiveKey.rulesObjectiveID;
    caseNomineeObjectiveDtls.fromDate = coverPeriod.coverPeriodFrom;
    caseNomineeObjectiveDtls.toDate = coverPeriod.coverPeriodTo;
    caseNomineeObjectiveDtls.statusCode = RECORDSTATUS.NORMAL;

    CaseNomineeObjectiveFactory.newInstance()
      .insert(caseNomineeObjectiveDtls);
  }

  // BEGIN, CR00295441, CW
  // ___________________________________________________________________________
  /**
   * Gets the case nominee ID for insertion of an objective when
   * regenerating a payment to a new nominee. In the case of rolled up payments,
   * the case nominee for the new objective will have a different case nominee
   * ID to that on the RegeneratePaymentForNewNomineeDetails structure.
   * The case nominee ID for the objective is identified by case ID
   * and participantRoleID.
   *
   * @param regenerateForNewNomineeDetails Contains the financial
   * instruction ID for the payment to be regenerated and the case nominee ID
   * for the nominee who is receiving the new payment. For rolled up payments,
   * this case nominee ID is not the case nominee ID used for insertion
   * of the objective.
   * @param caseObjectiveKey Contains the case ID of the component. The case
   * nominee of the new objective inserted when regenerating a payment
   * is for this case ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected CaseNomineeID getCaseNomineeForObjective(
    final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails,
    final CaseObjectiveKey caseObjectiveKey)
    throws AppException, InformationalException {

    // Initialize the return struct
    final CaseNomineeID caseNomineeID = new CaseNomineeID();

    // Default the case nominee ID to that of the regenerated payment
    caseNomineeID.caseNomineeID =
      regenerateForNewNomineeDetails.caseNomineeID;

    // Read the case ID for the given case nominee
    final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    caseNomineeKey.caseNomineeID =
      regenerateForNewNomineeDetails.caseNomineeID;
    final curam.core.sl.entity.struct.CaseIDAndCaseStartDateDetails caseIDDtls =
      CaseNomineeFactory.newInstance().readCaseIDAndStartDate(caseNomineeKey);

    // Check whether this case ID the same as the case ID for the financial
    // component
    if (caseIDDtls.caseID != caseObjectiveKey.caseID) {

      //
      // The case ID for the case nominee is not the same as the case ID for the
      // financial component.
      // We need to identify the case nominee ID for the financial component
      // case ID
      //
      final CaseNomineeViewKey caseNomineeViewKey = new CaseNomineeViewKey();

      caseNomineeViewKey.caseNomineeID =
        regenerateForNewNomineeDetails.caseNomineeID;

      // Read the participant role for the case nominee
      final PrimaryClientIDNomineeParticipantRoleIDDetails nomineeParticipantDtls =
        CaseNomineeFactory.newInstance()
          .readPrimaryClientIDAndNomineeParticipantRoleID(caseNomineeViewKey);

      final CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey =
        new CaseIDAndParticipantRoleIDKey();

      caseIDAndParticipantRoleIDKey.caseID = caseObjectiveKey.caseID;
      caseIDAndParticipantRoleIDKey.participantRoleID =
        nomineeParticipantDtls.nomineeParticipantRoleID;
      final CaseParticipantRoleIDStruct caseParticipantRoleIDStruct =
        CaseParticipantRoleFactory.newInstance()
          .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(
            caseIDAndParticipantRoleIDKey);

      // Read the case nominee for the financial component case ID and
      // given case participant role
      final CaseParticipantRoleIDKey caseParticipantRoleIDKey =
        new CaseParticipantRoleIDKey();

      caseParticipantRoleIDKey.caseParticipantRoleID =
        caseParticipantRoleIDStruct.caseParticipantRoleID;
      final CaseNomineeForCaseDetailsList caseNomineeForCaseDetailsList =
        CaseNomineeFactory.newInstance()
          .searchByCaseParticipantRoleID(caseParticipantRoleIDKey);

      if (!caseNomineeForCaseDetailsList.dtls.isEmpty()) {

        // Set the caseNomineeID on the return struct to the correct case
        // nominee
        caseNomineeID.caseNomineeID =
          caseNomineeForCaseDetailsList.dtls.get(0).caseNomineeID;
      }
    }

    return caseNomineeID;
  }

  // END, CR00295441

  // ___________________________________________________________________________
  /**
   * Utility method for retrieving the case owner.
   *
   * @param key Contains the case identifier.
   *
   * @return Case owner.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public OwnerID getCaseOwner(final CaseIDKey key)
    throws AppException, InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    return CaseHeaderFactory.newInstance().readCaseOwner(caseHeaderKey);
  }

  // ___________________________________________________________________________
  /**
   * Checks to see if a payment has been canceled.
   *
   * @param finInstructionID Contains a financial instruction identifier.
   *
   * @return Flag to indicate if the payment has been canceled or not.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public IsPaymentCancelledResult
    isPaymentCancelled(final FinInstructionID finInstructionID)
      throws AppException, InformationalException {

    // Create return object
    final IsPaymentCancelledResult isPaymentCancelledResult =
      new IsPaymentCancelledResult();

    // Initialize flag
    isPaymentCancelledResult.result = false;

    // Read financial instruction entity
    final FinancialInstructionKey financialInstructionKey =
      new FinancialInstructionKey();

    financialInstructionKey.finInstructionID =
      finInstructionID.finInstructionID;

    final FinancialInstructionDtls financialInstructionDtls =
      curam.core.fact.FinancialInstructionFactory.newInstance()
        .read(financialInstructionKey);

    if (financialInstructionDtls.statusCode
      .equals(curam.codetable.FININSTRUCTIONSTATUS.REVERSED)
      || financialInstructionDtls.statusCode
        .equals(curam.codetable.FININSTRUCTIONSTATUS.CANCELLED)) {

      isPaymentCancelledResult.result = true;
    }

    return isPaymentCancelledResult;
  }

  // ___________________________________________________________________________
  /**
   * Checks to see if a payment has been regenerated.
   *
   * @param finInstructionID Contains a financial instruction identifier.
   *
   * @return Flag to indicate if the payment has been canceled or not.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public IsPaymentRegeneratedResult
    isPaymentRegenerated(final FinInstructionID finInstructionID)
      throws AppException, InformationalException {

    // Create return object
    final IsPaymentRegeneratedResult isPaymentRegeneratedResult =
      new IsPaymentRegeneratedResult();

    // Read PaymentInstruction based on input finInstructionID
    final PaymentInstructionDtls paymentInstructionDtls =
      PaymentInstructionFactory.newInstance()
        .readByFinInstructionID(finInstructionID);

    // BEGIN, CR00077944, CW
    // Ensure the instruction id field is populated
    if (paymentInstructionDtls.pmtInstructionID != 0) {
      // END, CR00077944

      // Check to see if a PaymentRegenerationRequest record exists - this
      // indicates if the payment has been regenerated or not
      final PaymentInstructionKey paymentInstructionKey =
        new PaymentInstructionKey();

      paymentInstructionKey.pmtInstructionID =
        paymentInstructionDtls.pmtInstructionID;

      try {
        PaymentRegenerationRequestFactory.newInstance()
          .readByPmtInstructionID(paymentInstructionKey);

        isPaymentRegeneratedResult.result = true;

      } catch (final RecordNotFoundException e) {
        isPaymentRegeneratedResult.result = false;
      }
    }
    return isPaymentRegeneratedResult;
  }

  // BEGIN, CR00002146, KH
  // ___________________________________________________________________________
  /**
   * This method cancels a payment instrument and any associated payment
   * instructions, financial instructions and instruction line items.
   *
   * @param paymentInstrumentKey Contains a payment instrument identifier.
   * @param cancelRegenerateSummary Contains cancellation details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelPaymentInstrument(
    final PaymentInstrumentKey paymentInstrumentKey,
    final CancelRegenerateSummary cancelRegenerateSummary)
    throws AppException, InformationalException {

    final FinInstructionID finInstructionID = new FinInstructionID();

    // Find all instructions associated with the instrument
    final FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList =
      PaymentInstructionFactory.newInstance()
        .searchByPmtInstrumentID(paymentInstrumentKey);

    // Cancel each financial instruction in turn
    for (int i = 0; i < finInstructionIDConcernRoleIDList.dtls.size(); i++) {

      finInstructionID.finInstructionID =
        finInstructionIDConcernRoleIDList.dtls.item(i).finInstructionID;

      cancelFinancialInstruction(finInstructionID, cancelRegenerateSummary);
    } // end for i

    createPaymentCancellationRequest(paymentInstrumentKey,
      cancelRegenerateSummary);

    // Cancel the payment instrument
    cancelPaymentInstrumentStatus(paymentInstrumentKey);

    // Should the payment instrument be regenerated?
    if (cancelRegenerateSummary.regenerateInd) {

      regeneratePaymentInstrument(paymentInstrumentKey);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method regenerates a payment instrument and any associated payment
   * instructions, financial instructions and instruction line items.
   *
   * @param paymentInstrumentKey Contains a payment instrument identifier.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void regeneratePaymentInstrument(
    final PaymentInstrumentKey paymentInstrumentKey)
    throws AppException, InformationalException {

    final FinInstructionID finInstructionID = new FinInstructionID();

    // Find all instructions associated with the instrument.
    final FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList =
      PaymentInstructionFactory.newInstance()
        .searchByPmtInstrumentID(paymentInstrumentKey);

    // BEGIN, CR00198173, SS
    // Initially assigning createCancellationObj to the present class and
    // this might be assigned to a subclass of CreateCancellation, if it is
    // defined in the property.
    curam.core.intf.CreateCancellation createCancellationObj = this;

    // Read the class name from property file.
    final String financialResolverName = Configuration
      .getProperty(EnvVars.ENV_FINANCIAL_HOOK_CREATECANCELLATION_CLASS);

    // BEGIN, CR00206354, SS
    final Object obj =
      FinancialUtil.getResolverClassName(financialResolverName,
        this.getCaseIDForFinInstructionId(finInstructionID.finInstructionID));

    if (null != obj) {
      createCancellationObj = (curam.core.intf.CreateCancellation) obj;
    }
    // END, CR00206354

    // Regenerate each financial instruction in turn.
    for (int i = 0; i < finInstructionIDConcernRoleIDList.dtls.size(); i++) {

      finInstructionID.finInstructionID =
        finInstructionIDConcernRoleIDList.dtls.item(i).finInstructionID;

      createCancellationObj.regeneratePayment(finInstructionID);
    } // end for i
  }

  // ___________________________________________________________________________
  /**
   * To cancel a financial instruction and all associated instruction line
   * items and create the relevant reversal financial instruction.
   *
   * @param finInstructionID Financial Instruction ID.
   * @param cancelRegenerateSummary Cancel Regenerate Summary.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void cancelFinancialInstruction(
    final FinInstructionID finInstructionID,
    final CancelRegenerateSummary cancelRegenerateSummary)
    throws AppException, InformationalException {

    // BEGIN, CR00130842, KH
    performSecurityChecks(finInstructionID);
    // END, CR00130842

    // instructionLineItem manipulation variables
    final InstructionLineItem instructionLineItemObj =
      InstructionLineItemFactory.newInstance();
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();
    InstructionLineItemDtlsList instructionLineItemDtlsList;

    // financialInstructionStatus manipulation variables
    final FinInstructionIDStatus finInstructionIDStatus =
      new FinInstructionIDStatus();

    // createReversal manipulation variables
    final ReverseFinInstructionSummary revFinInstructionSummary =
      new ReverseFinInstructionSummary();
    final CreateReversal createReversalObj =
      CreateReversalFactory.newInstance();

    validateCancelFinInstruction(finInstructionID, cancelRegenerateSummary);

    // Validation method to check our payment
    revFinInstructionSummary.finInstructionID =
      finInstructionID.finInstructionID;
    revFinInstructionSummary.reversalAmount = Money.kZeroMoney;
    revFinInstructionSummary.reversalReasonCode =
      cancelRegenerateSummary.reasonCode;
    revFinInstructionSummary.reversalComments =
      cancelRegenerateSummary.reasonText;

    // Create reversal
    createReversalObj.reverseFinInstruction(revFinInstructionSummary);

    // Find all the ILIs contained in this financial instruction
    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    instructionLineItemDtlsList =
      instructionLineItemObj.searchByFinInstructID(iliFinInstructID);

    // BEGIN, CR00053019, MC
    instructionLineItemDtlsList.dtls
      .addAll(getRelatedDeductions(instructionLineItemDtlsList).dtls);
    // END, CR00053019

    long lastCaseID = 0;

    // Cancel each ILI
    for (int i = 0; i < instructionLineItemDtlsList.dtls.size(); i++) {

      // BEGIN, CR00077580, CW
      // Set the status of the payment ILI to indicate it is cancelled
      MaintainInstructionLineItemFactory.newInstance()
        .setCancelledILIStatus(instructionLineItemDtlsList.dtls.item(i));
      // END, CR00077580

      // BEGIN, CR00100004, VM
      // Raise an event for each case constituting the payment, signifying the
      // fact that the ILIs on the case are canceled
      if (instructionLineItemDtlsList.dtls.item(i).caseID != lastCaseID) {

        lastCaseID = instructionLineItemDtlsList.dtls.item(i).caseID;

        final Event event = new Event();

        event.eventKey = INSTRUCTIONLINEITEM.ILIS_CANCELED_ON_CASE;
        event.primaryEventData = lastCaseID;

        EventService.raiseEvent(event);
      }
      // END, CR00100004
    }

    // Cancel the financial instruction
    finInstructionIDStatus.finInstructionID =
      finInstructionID.finInstructionID;
    finInstructionIDStatus.statusCode = FININSTRUCTIONSTATUS.CANCELLED;

    MaintainFinInstructionFactory.newInstance()
      .updateFinInstructionStatus(finInstructionIDStatus);
  }

  // ___________________________________________________________________________
  /**
   * Checks if this financial instruction was rolled up with other instructions
   * into one payment instrument. Rolled up instructions must be cancelled via
   * the instrument. This validation returns the payment instrument ID.
   *
   * @param finInstructionID Financial Instruction ID.
   *
   * @return The ID of the payment instrument.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected PaymentInstrumentKey
    validateRolledUpInstruction(final FinInstructionID finInstructionID)
      throws AppException, InformationalException {

    final PaymentInstruction paymentInstructionObj =
      PaymentInstructionFactory.newInstance();

    // Get the payment instruction details
    final PaymentInstructionDtls paymentInstructionDtls =
      paymentInstructionObj.readByFinInstructionID(finInstructionID);

    // Read all financial instructions associated with this payment instrument
    final PaymentInstrumentKey paymentInstrumentKey =
      new PaymentInstrumentKey();

    paymentInstrumentKey.pmtInstrumentID =
      paymentInstructionDtls.pmtInstrumentID;

    final FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList =
      paymentInstructionObj.searchByPmtInstrumentID(paymentInstrumentKey);

    if (!finInstructionIDConcernRoleIDList.dtls.isEmpty()) {

      // If this payment instructions was rolled up with other instructions into
      // one payment instrument then the instrument needs to be canceled first
      if (finInstructionIDConcernRoleIDList.dtls.size() > 1) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(new AppException(
            BPOCREATECANCELLATION.ERR_MULTIPLE_INSTRUCTIONS_ON_PAYMENT_INSTRUMENT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(BPOCREATECANCELLATION.ERR_PAYMENT_NOT_ISSUED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return paymentInstrumentKey;
  }

  // ___________________________________________________________________________
  /**
   * This method creates a payment cancellation request for the payment
   * instrument that is being canceled.
   *
   * @param paymentInstrumentKey Contains a payment instrument identifier.
   * @param cancelRegenerateSummary Cancel Regenerate Summary.
   *
   * @return The ID of the Payment Cancellation Request created.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PaymentCancellationRequestKey createPaymentCancellationRequest(
    final PaymentInstrumentKey paymentInstrumentKey,
    final CancelRegenerateSummary cancelRegenerateSummary)
    throws AppException, InformationalException {

    // BEGIN, CR00077323, CW
    // Initialize the return struct
    final PaymentCancellationRequestKey paymentCancellationRequestKey =
      new PaymentCancellationRequestKey();
    // END, CR00077323

    // Set up payment cancellation request details
    final PaymentCancellationRequestDtls paymentCancellationRequestDtls =
      new PaymentCancellationRequestDtls();

    paymentCancellationRequestDtls.pmtCancellationID =
      UniqueIDFactory.newInstance().getNextID();
    paymentCancellationRequestDtls.reasonText =
      cancelRegenerateSummary.reasonText;
    paymentCancellationRequestDtls.pmtInstrumentID =
      paymentInstrumentKey.pmtInstrumentID;
    paymentCancellationRequestDtls.creationDate =
      TransactionInfo.getSystemDate();
    paymentCancellationRequestDtls.typeCode =
      cancelRegenerateSummary.reasonCode;

    PaymentCancellationRequestFactory.newInstance()
      .insert(paymentCancellationRequestDtls);

    // BEGIN, CR00077323, CW
    // Populate the key with the paymentRegenerationRequest id
    paymentCancellationRequestKey.pmtCancellationID =
      paymentCancellationRequestDtls.pmtCancellationID;

    return paymentCancellationRequestKey;
    // END, CR00077323
  }

  // ___________________________________________________________________________
  /**
   * This method creates a payment regeneration request for the payment
   * instruction and then processes the regenerated instruction.
   *
   * @param paymentInstructionDtls Contains a payment instrument identifier
   *
   * @return PaymentRegenerationRequestKey the key containing the id of the
   * PaymentRegenerationRequest created.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PaymentRegenerationRequestKey createPaymentRegenerationRequest(
    final PaymentInstructionDtls paymentInstructionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00077323, CW
    // Initialize the return struct
    final PaymentRegenerationRequestKey paymentRegenerationRequestKey =
      new PaymentRegenerationRequestKey();

    // END, CR00077323

    // BEGIN, CR00077944, CW
    // Ensure the instruction id field is populated
    if (paymentInstructionDtls.pmtInstructionID != 0) {
      // END, CR00077944

      validatePaymentInstrument(paymentInstructionDtls);

      // PaymentRegenerationRequest manipulation variables
      final PaymentRegenerationRequest paymentRegenerationRequestObj =
        PaymentRegenerationRequestFactory.newInstance();
      PaymentRegenerationRequestDtls paymentRegenerationRequestDtls =
        new PaymentRegenerationRequestDtls();
      final PaymentInstructionKey pmtInstructionKey =
        new PaymentInstructionKey();

      // Flag to indicate that the payment has already been regenerated
      boolean alreadyRegenerated = true;

      // Set key to search for existing payment regeneration requests
      pmtInstructionKey.pmtInstructionID =
        paymentInstructionDtls.pmtInstructionID;

      try {
        paymentRegenerationRequestDtls = paymentRegenerationRequestObj
          .readByPmtInstructionID(pmtInstructionKey);

      } catch (final RecordNotFoundException e) {

        // No payment regeneration request found
        alreadyRegenerated = false;

        // Get current user details
        final SystemUserDtls systemUserDtls =
          SystemUserFactory.newInstance().getUserDetails();

        // Set up payment regeneration request details
        paymentRegenerationRequestDtls.pmtRegenerationID =
          UniqueIDFactory.newInstance().getNextID();
        paymentRegenerationRequestDtls.pmtInstructionID =
          paymentInstructionDtls.pmtInstructionID;
        paymentRegenerationRequestDtls.requestDate = Date.getCurrentDate();
        paymentRegenerationRequestDtls.requestedBy = systemUserDtls.userName;
        paymentRegenerationRequestDtls.regenFinInstructID =
          paymentInstructionDtls.finInstructionID;
        paymentRegenerationRequestDtls.outcomeCode =
          REGENERATIONOUTCOME.ACCEPTED;

        paymentRegenerationRequestObj.insert(paymentRegenerationRequestDtls);

        // Process the regenerated payment
        final FinInstructionID finInstructionID = new FinInstructionID();

        finInstructionID.finInstructionID =
          paymentInstructionDtls.finInstructionID;

        RegeneratePaymentFactory.newInstance()
          .processRegeneratedPayment(finInstructionID);
      }

      // This payment has already been regenerated
      if (alreadyRegenerated) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOCREATECANCELLATION.ERR_CANCELED_PAYMENT_AREADY_REGENERATED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // BEGIN, CR00077323, CW
      // Populate the key with the paymentRegenerationRequest id
      paymentRegenerationRequestKey.pmtRegenerationID =
        paymentRegenerationRequestDtls.pmtRegenerationID;
    }

    return paymentRegenerationRequestKey;
    // END, CR00077323
  }

  // ___________________________________________________________________________
  /**
   * This method sets the reconciliation status of the a payment instrument
   * to canceled.
   *
   * @param paymentInstrumentKey Contains a payment instrument identifier.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void cancelPaymentInstrumentStatus(
    final PaymentInstrumentKey paymentInstrumentKey)
    throws AppException, InformationalException {

    final PaymentInstrument paymentInstrumentObj =
      PaymentInstrumentFactory.newInstance();

    // Read paymentInstrument entity
    final PaymentInstrumentDtls paymentInstrumentDtls =
      paymentInstrumentObj.read(paymentInstrumentKey);

    // Set status of payment instrument to canceled
    final PIReconcilStatusCode piStatusCodeVersionNo =
      new PIReconcilStatusCode();

    piStatusCodeVersionNo.reconcilStatusCode =
      PMTRECONCILIATIONSTATUS.CANCELLED;
    piStatusCodeVersionNo.versionNo = paymentInstrumentDtls.versionNo;

    // Modify paymentInstrument record
    paymentInstrumentObj.modifyReconcilStatusCode(paymentInstrumentKey,
      piStatusCodeVersionNo);

    // BEGIN, CR00246982, RK
    paymentInstrumentEventsDispatcher.get(PaymentInstrumentEvent.class)
      .paymentCancelled(paymentInstrumentKey);
    // END, CR00246982
  }

  // ___________________________________________________________________________
  /**
   * This method finds the current delivery method for a concern or nominee
   * using their instruction line item details.
   *
   * @param iliDtls Contains details of the instruction line item.
   *
   * @return DeliveryMethodType The current delivery method.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public DeliveryMethodType
    getCurrentDeliveryMethod(final InstructionLineItemDtls iliDtls)
      throws AppException, InformationalException {

    // Set up return object
    final DeliveryMethodType deliveryMethodType = new DeliveryMethodType();

    if (iliDtls.instructionLineItemType.equals(ILITYPE.DEDUCTIONPAYMENT)) {

      // Find current delivery method for the concern
      final ConcernRoleID concernRoleID = new ConcernRoleID();

      concernRoleID.concernRoleID = iliDtls.concernRoleID;

      deliveryMethodType.deliveryMethodType =
        MaintainInstructionLineItemFactory.newInstance()
          .getDeliveryMethodForConcernRole(concernRoleID).deliveryMethodType;

    } else { // Find current delivery method for the nominee

      // Read case nominee product delivery pattern details
      final ReadEffectiveByDateKey readEffectiveByDateKey =
        new ReadEffectiveByDateKey();

      readEffectiveByDateKey.caseNomineeID = iliDtls.caseNomineeID;
      readEffectiveByDateKey.effectiveDate = iliDtls.creationDate;
      readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;

      // BEGIN, CR00211744, VM
      final CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls =
        assessmentEngineEntity
          .getCaseNomineePatternByEffectiveDate(readEffectiveByDateKey);
      // END, CR00211744

      // Set key to instruction line item creation date
      final PDPIByProdDelPatIDStatusAndDateKey pDPIByProdDelPatIDStatusAndDateKey =
        new PDPIByProdDelPatIDStatusAndDateKey();

      pDPIByProdDelPatIDStatusAndDateKey.productDeliveryPatternID =
        caseNomineeProdDelPatternDtls.productDeliveryPatternID;
      pDPIByProdDelPatIDStatusAndDateKey.effectiveDate = iliDtls.creationDate;
      pDPIByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;

      // Read the nearest product delivery pattern info record
      final ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls =
        ProductDeliveryPatternInfoFactory.newInstance()
          .readNearestProdDelPatInfo(pDPIByProdDelPatIDStatusAndDateKey);

      // Get the delivery method type for case nominee (in case it has changed)
      // and set on new generated instruction line item.
      final DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

      deliveryMethodKey.deliveryMethodID =
        productDeliveryPatternInfoDtls.deliveryMethodID;

      final DeliveryMethodDtls deliveryMethodDtls =
        DeliveryMethodFactory.newInstance().read(deliveryMethodKey);

      deliveryMethodType.deliveryMethodType = deliveryMethodDtls.name;
    }

    return deliveryMethodType;
  }

  // END, CR00002146

  // BEGIN, CR00003380, SD
  // ___________________________________________________________________________
  /**
   * @param details Details to cancel and regenerate or cancel and invalidate
   * a payment.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, Replaced by
   * cancelRegenerateOrInvalidatePayment(). To incorporate the ability to
   * cancel, invalidate and regenerate a payment to the existing or a new
   * nominee.
   *
   * Method which decides whether a payment is being canceled and regenerated
   * or canceled and invalidated.
   */
  @Override
  @Deprecated
  public void
    cancelOrInvalidatePayment(final CancelOrInvalidatePmtDetails details)
      throws AppException, InformationalException {

    final CancelRegenerateOrInvalidatePmtDetails cancelRegenerateOrInvalidatePmtDetails =
      new CancelRegenerateOrInvalidatePmtDetails();

    cancelRegenerateOrInvalidatePmtDetails.assign(details);
    // cancelRegenerateOrInvalidatePmtDetails.caseNomineeID = 0;

    cancelRegenerateOrInvalidatePayment(
      cancelRegenerateOrInvalidatePmtDetails);
  }

  // BEGIN, CR00172652 ,MC
  // ___________________________________________________________________________
  /**
   * Cancels and invalidates or regenerates a payment instruction.
   *
   * @param details Details to cancel and regenerate or cancel and invalidate
   * a payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelRegenerateOrInvalidatePayment(
    final CancelRegenerateOrInvalidatePmtDetails details)
    throws AppException, InformationalException {

    final CancelOrInvalidatePmtDetails cancelOrInvalidatePmtDetails =
      new CancelOrInvalidatePmtDetails();

    cancelOrInvalidatePmtDetails.assign(details);

    // Cancel payment summary details.
    final CancelRegenerateSummary cancelRegenerateSummary =
      new CancelRegenerateSummary();

    // Call local validate method to ensure both regeneration and invalidation
    // of the payment has not been selected.
    validateCancelOrInvalidatePayment(cancelOrInvalidatePmtDetails);

    // Check if the payment has been canceled already.
    final FinInstructionID finInstructionID = new FinInstructionID();

    finInstructionID.finInstructionID = details.finInstructionID;

    final IsPaymentCancelledResult isPaymentCancelledResult =
      isPaymentCancelled(finInstructionID);

    // If the payment has been canceled, check if it has been regenerated.
    if (isPaymentCancelledResult.result) {

      // If the payment has been regenerated and the user opted to
      // invalidate, throw an exception - payment cannot be invalidated
      // if it has been regenerated.
      if (isPaymentRegenerated(finInstructionID).result
        && details.invalidateInd) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(new AppException(
            BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_INVALIDATION_INVALID),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // If neither option (regeneration or invalidation) has been selected, then
    // we're only canceling the payment.
    if (!(details.invalidateInd || details.regenerateInd)) {

      cancelRegenerateSummary.assign(cancelOrInvalidatePmtDetails);
      cancelFinInstruction(finInstructionID, cancelRegenerateSummary);
    }

    // If the payment has not been canceled already and invalidate has been
    // selected or, regeneration has been selected, we cancel the payment.
    if (!isPaymentCancelledResult.result && details.invalidateInd
      || details.regenerateInd) {

      cancelRegenerateSummary.assign(cancelOrInvalidatePmtDetails);

      if (details.caseNomineeID != 0) {

        // Regenerate the payment to the new nominee after it has been canceled.
        cancelRegenerateSummary.regenerateInd = false;
        cancelFinInstruction(finInstructionID, cancelRegenerateSummary);

        // BEGIN, CR00358036, GA
        final PaymentInstructionDtls paymentInstructionDtls =
          PaymentInstructionFactory.newInstance()
            .readByFinInstructionID(finInstructionID);

        final PaymentInstrumentKey paymentInstrumentKey =
          new PaymentInstrumentKey();

        paymentInstrumentKey.pmtInstrumentID =
          paymentInstructionDtls.pmtInstrumentID;

        final PaymentInstrumentDtls paymentInstrumentDtls =
          PaymentInstrumentFactory.newInstance().read(paymentInstrumentKey);

        if (0 == paymentInstrumentDtls.caseNomineeID) {
          ValidationManagerFactory.getManager()
            .throwWithLookup(new AppException(
              BPOCREATECANCELLATION.ERR_REGENERATING_THIRD_PARTY_PAYMENT_DIFFERENT_NOMINEE),
              ValidationManagerConst.kSetOne, 0);
        }
        // END, CR00358036

        // Now set up the details to regenerate the payment
        final RegeneratePaymentForNewNomineeDetails regenerateForNewNomineeDetails =
          new RegeneratePaymentForNewNomineeDetails();

        regenerateForNewNomineeDetails.caseNomineeID = details.caseNomineeID;
        regenerateForNewNomineeDetails.finInstructionID =
          details.finInstructionID;

        // BEGIN, CR00314367, SG
        if (0 < details.caseNomineeConcernRoleIDOpt.length()) {
          final String[] ids =
            details.caseNomineeConcernRoleIDOpt.split(CuramConst.gkComma);

          regenerateForNewNomineeDetails.concernRoleIDOpt =
            Long.parseLong(ids[1]);
        }
        // END, CR00314367

        // BEGIN, CR00222906, KH
        // BEGIN, CR00265470, ZV
        regeneratePaymentForNewNominee(regenerateForNewNomineeDetails);
        // END, CR00265470
        // END, CR00222906
      } else {
        // Regenerate to the current nominee.
        cancelFinInstruction(finInstructionID, cancelRegenerateSummary);
      }

    }

    // If the payment has been canceled already and the user opted to
    // invalidate it, then we mark it as invalidated.
    if (isPaymentCancelledResult.result && details.invalidateInd) {
      invalidatePayment(finInstructionID);
    }

    // BEGIN, CR00045872, AK
    final ILIFinInstructID instructID = new ILIFinInstructID();

    instructID.finInstructionID = finInstructionID.finInstructionID;

    final ILICaseIDList caseIDList = InstructionLineItemFactory.newInstance()
      .searchForCaseIDByFinInstructID(instructID);

    // Find the first actual case ID and log the transaction details for it.
    for (int i = 0; i < caseIDList.dtls.size(); i++) {

      // BEGIN, CR00022728, RR
      if (caseIDList.dtls.item(i).caseID != 0) {

        // Log Transaction Details.
        // BEGIN CR00109704, MR
        final PaymentInstructionDtls paymentInstructionDtls =
          PaymentInstructionFactory.newInstance()
            .readByFinInstructionID(finInstructionID);

        final LocalisableString description =
          new LocalisableString(BPOCASEEVENTS.PAYMENTS_CANCELED)
            .arg(paymentInstructionDtls.creationDate);

        caseTransactionLogProvider.get().recordCaseTransaction(
          CASETRANSACTIONEVENTS.PAYMENTS_CANCEL, description,
          caseIDList.dtls.item(i).caseID, details.finInstructionID);
        // END CR00109704
        break;
      }
      // END, CR00022728
    } // end for i
  }

  // END, CR00172652

  // ___________________________________________________________________________
  /**
   * Validates if a payment is being canceled and regenerated or canceled and
   * invalidated.
   *
   * @param details Details to cancel and regenerate or cancel and invalidate a
   * payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void validateCancelOrInvalidatePayment(
    final CancelOrInvalidatePmtDetails details)
    throws AppException, InformationalException {

    if (details.regenerateInd && details.invalidateInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(new AppException(
          BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_REGENERATE_OR_INVALIDATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }

  // ___________________________________________________________________________
  /**
   * Marks the payment as being invalidated.
   *
   * @param finInstructionID Contains the financial instruction identifier.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void invalidatePayment(final FinInstructionID finInstructionID)
    throws AppException, InformationalException {

    // BEGIN, CR00130842, KH
    performSecurityChecks(finInstructionID);
    // END, CR00130842

    // Validate the invalidation of the payment
    validateInvalidatePayment(finInstructionID);

    // PaymentInstrument manipulation variables
    final PaymentInstrument paymentInstrumentObj =
      PaymentInstrumentFactory.newInstance();

    // Read PaymentInstruction
    final PaymentInstructionDtls paymentInstructionDtls =
      PaymentInstructionFactory.newInstance()
        .readByFinInstructionID(finInstructionID);

    // Read payment instrument details
    final PaymentInstrumentKey paymentInstrumentKey =
      new PaymentInstrumentKey();

    paymentInstrumentKey.pmtInstrumentID =
      paymentInstructionDtls.pmtInstrumentID;

    final PaymentInstrumentDtls paymentInstrumentDtls =
      paymentInstrumentObj.read(paymentInstrumentKey);

    // Mark payment instrument as invalidated
    final PIInvalidatedVersionNo piInvalidatedVersionNo =
      new PIInvalidatedVersionNo();

    piInvalidatedVersionNo.invalidatedInd = true;
    piInvalidatedVersionNo.versionNo = paymentInstrumentDtls.versionNo;

    paymentInstrumentObj.modifyInvalidatedInd(paymentInstrumentKey,
      piInvalidatedVersionNo);

    // InstructionLineItem manipulation variables
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    final ILICaseIDList iliCaseIDList = InstructionLineItemFactory
      .newInstance().searchForCaseIDByFinInstructID(iliFinInstructID);

    long lastCaseID = 0;
    int caseIDCount = 0;

    for (int i = 0; i < iliCaseIDList.dtls.size(); i++) {

      if (iliCaseIDList.dtls.item(i).caseID != lastCaseID) {

        caseIDCount++;
        lastCaseID = iliCaseIDList.dtls.item(i).caseID;
      }

      if (caseIDCount > 1) {
        // If the payment being invalidated is rolled across multiple cases, an
        // informational needs to be returned to the client

        final AppException e = new AppException(
          BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_XRV_MULTIPLE_CASES);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(e.arg(true),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
        break;
      }
    } // end for i

    sendNotification(finInstructionID);
  }

  // ___________________________________________________________________________
  /**
   * Validates the invalidation of a payment.
   *
   * @param finInstructionID The Financial Instruction Identifier.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void
    validateInvalidatePayment(final FinInstructionID finInstructionID)
      throws AppException, InformationalException {

    // Read PaymentInstruction
    final PaymentInstructionDtls paymentInstructionDtls =
      PaymentInstructionFactory.newInstance()
        .readByFinInstructionID(finInstructionID);

    // Read payment instrument entity
    final PaymentInstrumentKey paymentInstrumentKey =
      new PaymentInstrumentKey();

    paymentInstrumentKey.pmtInstrumentID =
      paymentInstructionDtls.pmtInstrumentID;

    final PaymentInstrumentDtls paymentInstrumentDtls =
      PaymentInstrumentFactory.newInstance().read(paymentInstrumentKey);

    // Has the payment been invalidated already?
    if (paymentInstrumentDtls.invalidatedInd) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_INVALIDATED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00018487, SPD
    // Payment cannot be invalidated if it is part of a rolled up payment
    if (paymentInstrumentDtls.caseNomineeID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_INVALIDATING_THIRD_PARTY_PAYMENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00018487

    // Retrieve list of ILIs that comprise the payment
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    final InstructionLineItemDtlsList instructionLineItemDtlsList =
      InstructionLineItemFactory.newInstance()
        .searchByFinInstructionID(iliFinInstructID);

    // Check if the payment comprises an underpayment line item. It is not
    // possible to invalidate a payment which contains an underpayment ILI.
    for (int i = 0; i < instructionLineItemDtlsList.dtls.size(); i++) {

      if (instructionLineItemDtlsList.dtls.item(i).instructionLineItemType
        .equals(ILITYPE.BENEFITUNDERPAYMENT)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(new AppException(
            BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_COMPRISES_UNDERPAYMENT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } // end for i

    // BEGIN, CR00096557, GM
    // BEGIN, CR00129930, KH
    // Check if a reassessment has occurred for the period covered by the
    // payment. If it has, then we can't allow the invalidate to take place
    boolean previousReassessmentFound = false;
    Date fromDate = Date.kZeroDate;
    Date toDate = Date.kZeroDate;

    // Set fromDate to the earliest cover period from date in the payment.
    // Set toDate to the latest cover period to date in the payment.
    for (int j = 0; j < instructionLineItemDtlsList.dtls.size(); j++) {

      if (instructionLineItemDtlsList.dtls.item(j).coverPeriodFrom
        .after(fromDate)) {
        fromDate = instructionLineItemDtlsList.dtls.item(j).coverPeriodFrom;
      }
      if (toDate.isZero()
        || instructionLineItemDtlsList.dtls.item(j).coverPeriodTo
          .before(toDate)) {
        toDate = instructionLineItemDtlsList.dtls.item(j).coverPeriodTo;
      }
    } // end for j

    // ReassessmentBalanceInfo manipulation variables
    final ReassessmentBalanceInfo reassessmentBalanceInfoObj =
      ReassessmentBalanceInfoFactory.newInstance();
    final ReadmultiBalanceKey readMultiBalanceKey = new ReadmultiBalanceKey();

    for (int k = 0; k < instructionLineItemDtlsList.dtls.size(); k++) {

      readMultiBalanceKey.caseNomineeID =
        instructionLineItemDtlsList.dtls.item(k).caseNomineeID;

      // Get all reassessments for this nominee
      final ReassessmentBalanceInfoDtlsList reassessmentBalanceInfoDtlsList =
        reassessmentBalanceInfoObj
          .searchReassessmentsForNominee(readMultiBalanceKey);

      for (int l = 0; l < reassessmentBalanceInfoDtlsList.dtls.size(); l++) {

        // Does any of the previous reassessments overlap with our payment?
        if (!reassessmentBalanceInfoDtlsList.dtls.item(l).coverPeriodFrom
          .after(toDate)
          && !reassessmentBalanceInfoDtlsList.dtls.item(l).coverPeriodTo
            .before(fromDate)) {

          previousReassessmentFound = true;
          break;
        }
      } // end for i

      if (previousReassessmentFound) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(new AppException(
            BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_XRV_REASSESSMENT_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } // end for k
    // END, CR00129930
    // END, CR00096557
  }

  // ___________________________________________________________________________
  /**
   * Method which checks if a payment has been invalidated or not.
   *
   * @param key Contains a payment instrument identifier.
   *
   * @return Flag to indicate if the payment has been invalidated or not.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public IsPaymentInvalidatedResult
    isPaymentInvalidated(final IsPaymentInvalidatedKey key)
      throws AppException, InformationalException {

    // Create return object
    final IsPaymentInvalidatedResult isPaymentInvalidatedResult =
      new IsPaymentInvalidatedResult();

    isPaymentInvalidatedResult.result = PaymentInstrumentFactory.newInstance()
      .readInvalidatedInd(key.key).invalidatedInd;

    return isPaymentInvalidatedResult;
  }

  // ___________________________________________________________________________
  /**
   * Notify case user(s) that a payment has been invalidated.
   *
   * @param finInstructionID Contains the financial instruction identifier of
   * the payment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void sendNotification(final FinInstructionID finInstructionID)
    throws AppException, InformationalException {

    // Retrieve the cases which comprise the payment
    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    final ILICaseIDList iliCaseIDList = InstructionLineItemFactory
      .newInstance().searchForCaseIDByFinInstructID(iliFinInstructID);

    if (!iliCaseIDList.dtls.isEmpty()) {

      final ArrayList<Long> caseIDList = new ArrayList<Long>();

      // Find distinct cases only
      for (int i = 0; i < iliCaseIDList.dtls.size(); i++) {

        if (!caseIDList
          .contains(new Long(iliCaseIDList.dtls.item(i).caseID))) {

          caseIDList.add(new Long(iliCaseIDList.dtls.item(i).caseID));
        }
      } // end for i

      // Notification manipulation variables
      final Notification notificationObj = NotificationFactory.newInstance();
      StandardManualTaskDtls standardManualTaskDtls;
      final CaseIDKey caseIDKey = new CaseIDKey();

      for (int j = 0; j < caseIDList.size(); j++) {

        caseIDKey.caseID = caseIDList.get(j).longValue();

        standardManualTaskDtls = setNotificationDetails(caseIDKey);
        // BEGIN, CR00079597, RCB
        notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
        // END, CR00079597
      } // end for j
    }
  }

  // ___________________________________________________________________________
  /**
   * Sets the details for creating a notification.
   *
   * @param key Contains a case identifier.
   *
   * @return standardManualDtls Notification details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public StandardManualTaskDtls setNotificationDetails(final CaseIDKey key)
    throws AppException, InformationalException {

    // Create return object
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // BEGIN, CR00234114, AK
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    final OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();
    OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final Users userObj = UsersFactory.newInstance();
    final UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale;

    caseHeaderKey.caseID = key.caseID;
    orgObjectLinkKey.orgObjectLinkID =
      caseHeaderObj.readCaseOwner(caseHeaderKey).ownerOrgObjectLinkID;
    orgObjectLinkDtls = orgObjectLinkObj.read(orgObjectLinkKey);
    userKey.userName = orgObjectLinkDtls.userName;
    usersDtls = userObj.read(nfIndicator, userKey);
    if (!nfIndicator.isNotFound()) {
      userLocale = usersDtls.defaultLocale;
    } else {
      userLocale = TransactionInfo.getProgramLocale();
    }

    // Call BPO to retrieve case, concernRole and product details
    final CaseReferenceProductNameConcernRoleName caseRefProductNameConcernRoleName =
      MaintainCaseFactory.newInstance()
        .readCaseReferenceConcernRoleNameProductNameByCaseIDAndLocale(key,
          userLocale);

    // Set notification details
    final AppException comments = new AppException(
      BPOCREATECANCELLATION.INF_PAYMENT_INVALIDATED_CHANGE_OF_CIRC_REQUIRED);

    comments.arg(caseRefProductNameConcernRoleName.caseReference);
    comments.arg(caseRefProductNameConcernRoleName.productName);
    comments.arg(caseRefProductNameConcernRoleName.concernRoleName);

    // BEGIN, CR00163236, CL
    standardManualTaskDtls.dtls.taskDtls.comments =
      comments.getMessage(userLocale);
    // END, CR00163236
    // END, CR00234114
    final AppException subject =
      new AppException(BPOCREATECANCELLATION.INF_PAYMENT_INVALIDATED);

    subject.arg(caseRefProductNameConcernRoleName.caseReference);
    subject.arg(caseRefProductNameConcernRoleName.productName);
    subject.arg(caseRefProductNameConcernRoleName.concernRoleName);

    // BEGIN, CR00213430, AK
    // BEGIN, CR00163236, CL
    standardManualTaskDtls.dtls.taskDtls.subject =
      subject.getMessage(userLocale);
    // END, CR00163236
    // END, CR00213430
    standardManualTaskDtls.dtls.concerningDtls.caseID = key.caseID;
    // BEGIN, CR00023618, SK
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
      TaskDefinitionIDConst.invalidatePaymentTaskDefinitionID;
    // END, CR00023618

    return standardManualTaskDtls;
  }

  // END, CR00003380

  // BEGIN, CR00053019, MC
  // ___________________________________________________________________________
  /**
   * Get all related deduction ILI for the list of instructions.
   *
   * @param instructionLineItemDtlsList Contains the list financial instruction
   * identifier of the payment.
   *
   * @return The list of related deduction ILIs.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InstructionLineItemDtlsList getRelatedDeductions(
    final InstructionLineItemDtlsList instructionLineItemDtlsList)
    throws AppException, InformationalException {

    // Return struct
    final InstructionLineItemDtlsList deductionILIDtlsList =
      new InstructionLineItemDtlsList();

    final RelatedILIidentifier relatedILIidentifier =
      new RelatedILIidentifier();
    final InstructionLineItem instructionLineItemObj =
      InstructionLineItemFactory.newInstance();

    for (int i = 0; i < instructionLineItemDtlsList.dtls.size(); i++) {

      relatedILIidentifier.instructLineItemID =
        instructionLineItemDtlsList.dtls.item(i).instructLineItemID;
      relatedILIidentifier.type = ILIRELATIONSHIP.DEDUCTIONPAYMENT;

      // Read instruction line item entity
      final RelatedILIDetailsList relatedILIDetailsList =
        instructionLineItemObj
          .searchRelatedILIByInstrLineItemIDType(relatedILIidentifier);

      if (relatedILIDetailsList.dtls != null
        && relatedILIDetailsList.dtls.size() > 0) {

        for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

          // BEGIN, CR00096588, GM
          final InstructionLineItemKey instructionLineItemKey =
            new InstructionLineItemKey();

          instructionLineItemKey.instructLineItemID =
            relatedILIDetailsList.dtls.item(j).instructLineItemID;

          final CaseDeductionItemFinCompID caseDeductionItemFinCompID =
            new CaseDeductionItemFinCompID();

          caseDeductionItemFinCompID.financialCompID = instructionLineItemObj
            .read(instructionLineItemKey).financialCompID;

          CaseDeductionItemDtls caseDeductionItemDtls = null;

          // Get current case deduction item details
          try {
            caseDeductionItemDtls = CaseDeductionItemFactory.newInstance()
              .readByFinancialCompID(caseDeductionItemFinCompID);
          } catch (final RecordNotFoundException rnfe) {
            continue;
          }

          if (caseDeductionItemDtls.category
            .equals(DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION)) {

            final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

            iliFinInstructID.finInstructionID =
              relatedILIDetailsList.dtls.item(j).finInstructionID;

            deductionILIDtlsList.dtls.addAll(instructionLineItemObj
              .searchByFinInstructID(iliFinInstructID).dtls);
          }
          // END, CR00096588
        } // end for j
      }
    } // end for i

    return deductionILIDtlsList;
  }

  // END, CR00053019
  // END, CR00130020

  // BEGIN, CR00130842, KH
  // ___________________________________________________________________________
  /**
   * Performs the location and case security checks.
   *
   * @param finInstructionID The ID of the financial instruction being processed
   * (either cancelled, regenerated, invalidated or a combination of these).
   * This ID is used to identify the relevant case for which the security
   * checks will be performed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void
    performSecurityChecks(final FinInstructionID finInstructionID)
      throws AppException, InformationalException {

    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    final InstructionLineItemDtlsList originalILIDtlsList =
      InstructionLineItemFactory.newInstance()
        .searchByFinInstructID(iliFinInstructID);
    DataBasedSecurityResult dataBasedSecurityResult =
      new DataBasedSecurityResult();

    // BEGIN, CR00140793, CW
    // Case id for the financial instruction
    long finInstructionCaseID = 0;

    // Loop through the ILI list to find the first non zero case id
    // BEGIN, CR00306824, KRK
    for (final InstructionLineItemDtls instructionLineItemDtls : originalILIDtlsList.dtls
      .items()) {

      if (CuramConst.gkZero != instructionLineItemDtls.caseID) {
        finInstructionCaseID = instructionLineItemDtls.caseID;
      }

      if (CuramConst.gkZero != finInstructionCaseID) {

        final CaseSecurityCheckKey caseSecurityCheckKey =
          new CaseSecurityCheckKey();

        caseSecurityCheckKey.caseID = finInstructionCaseID;
        caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

        final DataBasedSecurity dataBasedSecurity =
          SecurityImplementationFactory.get();

        dataBasedSecurityResult =
          dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);
        if (dataBasedSecurityResult.result) {
          break;
        }
      }
    }
    // END, CR00306824
    // BEGIN, CR00226315, PM
    if (CuramConst.gkZero != finInstructionCaseID) {
      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
        } else {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }
    }
    // END, CR00226315
    // END, CR00140793
  }

  // END, CR00130842

  // BEGIN, CR00265418, ZV
  /**
   * This method returns the appropriate caseID for the given finInstructionID.
   *
   * @param finInstructionID
   *
   * @return Associated caseID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public long getCaseIDForFinInstructionId(final long finInstructionID)
    throws AppException, InformationalException {

    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID;

    final InstructionLineItemDtlsList originalILIDtlsList =
      InstructionLineItemFactory.newInstance()
        .searchByFinInstructID(iliFinInstructID);
    long finInstructionCaseID = 0;

    // Loop through the ILI list to find the first non zero case id
    for (int i = 0; i < originalILIDtlsList.dtls.size(); i++) {
      if (originalILIDtlsList.dtls.item(i).caseID != 0) {
        finInstructionCaseID = originalILIDtlsList.dtls.item(i).caseID;
        break;
      }
    }
    return finInstructionCaseID;
  }

  // END, CR00265418

  // BEGIN, CR00399253, KRK
  /**
   * This function needs to determine if there is one or more existing line
   * items for the new nominee for the payment period.
   *
   * @param instructionLineItemDtls Instruction Line Item details
   * @param regeneratePaymentForNewNomineeDetails Regenerate payment details of
   * a new nominee
   *
   * @return flag to indicate if the line item should be marked so that its
   * value is used to
   * readjust the amount displayed on the benefit statement
   */
  protected boolean considerILIForReassessmentAdjustment(
    final InstructionLineItemDtls instructionLineItemDtls,
    final RegeneratePaymentForNewNomineeDetails regeneratePaymentForNewNomineeDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00479278, JD
    // First determine if the iliType is appropriate for inclusion in
    // reassessment
    if (!checkILITypeForReassessmentAdjustment(instructionLineItemDtls,
      regeneratePaymentForNewNomineeDetails)) {

      return false;
    }
    // END, CR00479278, JD

    final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    caseNomineeKey.caseNomineeID = instructionLineItemDtls.caseNomineeID;

    // Get all reassessments for the nominee.
    final NomineeOverUnderPaymentDtlsList allNomineeOverUnderPayments =
      assessmentEngineEntity
        .getOverUnderPaymentsByCaseNomineeID(caseNomineeKey);
    final ILICaseIDCoverPeriod iliCaseIDCoverPeriod =
      new ILICaseIDCoverPeriod();

    iliCaseIDCoverPeriod.caseID = instructionLineItemDtls.caseID;
    iliCaseIDCoverPeriod.coverPeriodFrom =
      instructionLineItemDtls.coverPeriodFrom;
    iliCaseIDCoverPeriod.coverPeriodTo =
      instructionLineItemDtls.coverPeriodTo;

    // Get all the ILIs which has the same cover period.
    final ILICaseFinancialDtlsList iliCaseFinancialDtlsList =
      InstructionLineItemFactory.newInstance()
        .searchByCaseIDCoverPeriod(iliCaseIDCoverPeriod);

    for (final ILICaseFinancialDtls iliCaseFinancialDtls : iliCaseFinancialDtlsList.dtls
      .items()) {

      if (allNomineeOverUnderPayments.dtls.isEmpty()
        || iliCaseFinancialDtls.caseNomineeID == regeneratePaymentForNewNomineeDetails.caseNomineeID
          && ILISTATUSEntry.CANCELLED.getCode()
            .equals(iliCaseFinancialDtls.statusCode)) {
        return false;
      }
    }
    return true;
  }

  // END, CR00388608

  // BEGIN, CR00479278, JD
  /**
   * Additional checks to consider ILI for ReassessmentAdjustment.
   * If the ILI is not of the appropriate type, it will no
   * longer be considered for inclusion in the reassessment
   * adjustment calculations.
   *
   * @param instructionLineItemDtls Instruction Line Item details
   * @param regeneratePaymentForNewNomineeDetails Regenerate payment details for
   * a new nominee
   * @return
   */
  protected boolean checkILITypeForReassessmentAdjustment(
    final InstructionLineItemDtls instructionLineItemDtls,
    final RegeneratePaymentForNewNomineeDetails regeneratePaymentForNewNomineeDetails)
    throws AppException, InformationalException {

    boolean considerILI = true;

    // Deduction ILIs should be filtered out
    if (CREDITDEBIT.CREDIT.equals(instructionLineItemDtls.creditDebitType)) {

      considerILI = false;

    } else if (instructionLineItemDtls.financialCompID == 0
      || instructionLineItemDtls.caseID == 0) {

      // Refunds and third party payments should always be filtered out
      considerILI = false;

    } else {

      // Check if ILI type is present in TRANSLATEILIType code table
      final String codetableDesc =
        CodeTable.getOneItem(TRANSLATEILITYPE.TABLENAME,
          instructionLineItemDtls.instructionLineItemType);

      considerILI = codetableDesc != null && !codetableDesc.isEmpty();
    }

    return considerILI;
  }
  // END, CR00479278, JD
}
