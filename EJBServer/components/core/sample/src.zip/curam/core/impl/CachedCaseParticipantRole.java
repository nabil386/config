/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2020. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.impl;


import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullNameDetails;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;
import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.Logger;


/**
 * @see curam.core.intf.CachedCaseParticipantRole
 */
public abstract class CachedCaseParticipantRole extends curam.core.base.CachedCaseParticipantRole {

  protected static ThreadLocal<ReadCaseParticipantRoleDtlsCacheRecord> cachedCaseParticipantRoleDtls = new ThreadLocal<ReadCaseParticipantRoleDtlsCacheRecord>();

  // BEGIN, CR00069782, GSP
  protected static ThreadLocal<CaseParticipantRoleIDCache> cachedCaseParticipantRoleID = new ThreadLocal<CaseParticipantRoleIDCache>();

  protected static ThreadLocal<ReadCaseParticipantRoleDtlsListCacheRecord> cachedCaseParticipantRoleDtlsList = new ThreadLocal<ReadCaseParticipantRoleDtlsListCacheRecord>();

  // END, CR00069782

  // BEGIN, CR00052232, GSP
  protected static ThreadLocal<ReadFullNameDtlsCacheRecord> cachedFullNameDtls = new ThreadLocal<ReadFullNameDtlsCacheRecord>();

  // END, CR00052232
  // ___________________________________________________________________________

  // BEGIN, CR00023323, CR00051622, SK
  // Logger for the caching output
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;

  // 258085, BEGIN, BD
  public static final Logger kBatchLauncherCacheLogger = Trace.getLogger(
    kBatchCachingCategory);
  // 258085, END

  // END, CR00023323,CR00051622

  public static final boolean logging;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // BEGIN, CR00052232, GSP
  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;
  // END, CR00052232

  // ___________________________________________________________________________
  // static to hold the logging_enabled environmental Variable
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);
    // BEGIN, CR00052232, GSP
    onlineCachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);
    // END, CR00052232

    String logging_enabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }
  }

  // ___________________________________________________________________________
  /**
   * Class to hold the cached CaseParticipantRoleDtls
   */
  protected class ReadCaseParticipantRoleDtlsCacheRecord {

    public CaseParticipantRoleDtls caseParticipantRoleDtls = new CaseParticipantRoleDtls();

    public int transactionID = 0;
  }


  // BEGIN, CR00052232, GSP
  // ___________________________________________________________________________
  /**
   * Class to hold the cached CaseParticipantFullNameDtls
   */
  protected class ReadFullNameDtlsCacheRecord {

    public CaseParticipantRole_eoFullNameDetails caseParticipantRole_eoFullNameDetails = new CaseParticipantRole_eoFullNameDetails();

    public int transactionID = 0;
  }


  // END, CR00052232

  // BEGIN, CR00069782, GSP
  /**
   * Class to hold the cached List containing CaseParticipantRoleDtls
   */
  protected class ReadCaseParticipantRoleDtlsListCacheRecord {

    public CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = new CaseParticipantRoleDtlsList();

    public int transactionID = 0;
  }


  // BEGIN, CR00052822, MC
  /**
   * Class to hold the cached List containing CaseParticipantRoleID
   */
  protected class CaseParticipantRoleIDCache {

    public Map<String, CaseParticipantRole_eoCaseParticipantRoleID> caseParticipantRoleIDMap = new HashMap<String, CaseParticipantRole_eoCaseParticipantRoleID>();

    // key is the combination of caseID and participantRoleID

    public int transactionID = 0;
  }


  // END CR00052822

  /**
   * Class to hold the cached List containing CaseParticipantRoleID
   */
  protected class ReadCaseParticipantRoleIDCacheRecord {

    public CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRole_eoCaseParticipantRoleID = new CaseParticipantRole_eoCaseParticipantRoleID();

    public int transactionID = 0;
  }

  // END, CR00069782

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtls read(CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    final CaseParticipantRoleDtls result = new CaseParticipantRoleDtls();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    // BEGIN, CR00052232, GSP
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {
      // END, CR00052232

      final ReadCaseParticipantRoleDtlsCacheRecord readCaseParticipantRoleDtlsCacheRecord = cachedCaseParticipantRoleDtls.get();

      if (readCaseParticipantRoleDtlsCacheRecord != null) {

        CaseParticipantRoleDtls caseParticipantRoleDtls = readCaseParticipantRoleDtlsCacheRecord.caseParticipantRoleDtls;

        if (caseParticipantRoleDtls != null
          && caseParticipantRoleDtls.caseParticipantRoleID
            == key.caseParticipantRoleID) {

          // if this is a deferred transaction, we must also check
          // that the transaction numbers match
          // BEGIN, CR00052232, GSP
          if ((transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
              // END, CR00052232
              && TransactionInfo.getIdentifierForThisThread()
                != readCaseParticipantRoleDtlsCacheRecord.transactionID) {

            caseParticipantRoleDtls = reloadDtlsCache(key);
          }
          return result.assign(caseParticipantRoleDtls);
        }
      }
    }

    return result.assign(reloadDtlsCache(key));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void clearCache() throws AppException, InformationalException {

    cachedCaseParticipantRoleDtls.set(null);
    // BEGIN, CR00069782, GSP
    cachedCaseParticipantRoleDtlsList.set(null);
    cachedCaseParticipantRoleID.set(null);
    // END, CR00069782
  }

  // ___________________________________________________________________________
  /**
   * This method is used to clear the CaseParticipantRoleIDCache.
   *
   */
  public void clearCaseParticipantRoleIDCache() throws AppException,
      InformationalException {

    // BEGIN, CR00052822, MC
    cachedCaseParticipantRoleID.set(null);
    // END CR00052822
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseIDAndParticipantRoleIDDetails readCaseIDAndParticipantRoleIDDetails(CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    final CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails = new CaseIDAndParticipantRoleIDDetails();

    CaseParticipantRoleDtls caseParticipantRoleDtls;

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    // BEGIN, CR00052232, GSP
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {
      // END, CR00052232
      final ReadCaseParticipantRoleDtlsCacheRecord readCaseParticipantRoleDtlsCacheRecord = cachedCaseParticipantRoleDtls.get();

      if (readCaseParticipantRoleDtlsCacheRecord != null) {

        caseParticipantRoleDtls = readCaseParticipantRoleDtlsCacheRecord.caseParticipantRoleDtls;

        // if this is a deferred transaction, we must also check that
        // the transaction numbers match
        if (caseParticipantRoleDtls != null
          // BEGIN, CR00052232, GSP
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline)) // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != readCaseParticipantRoleDtlsCacheRecord.transactionID) {

          caseParticipantRoleDtls = null;
        }

        if (caseParticipantRoleDtls != null
          && caseParticipantRoleDtls.caseParticipantRoleID
            == key.caseParticipantRoleID) {

          caseIDAndParticipantRoleIDDetails.caseID = caseParticipantRoleDtls.caseID;
          caseIDAndParticipantRoleIDDetails.participantRoleID = caseParticipantRoleDtls.participantRoleID;

          return caseIDAndParticipantRoleIDDetails;
        }
      }
    }

    // Otherwise we need to read the CaseParticipantRole data
    caseParticipantRoleDtls = reloadDtlsCache(key);

    caseIDAndParticipantRoleIDDetails.caseID = caseParticipantRoleDtls.caseID;
    caseIDAndParticipantRoleIDDetails.participantRoleID = caseParticipantRoleDtls.participantRoleID;

    return caseIDAndParticipantRoleIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtls reloadDtlsCache(CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseParticipantRoleDtls caseParticipantRoleDtls;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    caseParticipantRoleDtls = caseParticipantRoleObj.read(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    // BEGIN, CR00052232, GSP
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {
      // END CR00052232

      final ReadCaseParticipantRoleDtlsCacheRecord readCaseParticipantRoleDtlsCacheRecord = new ReadCaseParticipantRoleDtlsCacheRecord();

      readCaseParticipantRoleDtlsCacheRecord.caseParticipantRoleDtls = caseParticipantRoleDtls;
      readCaseParticipantRoleDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedCaseParticipantRoleDtls.set(readCaseParticipantRoleDtlsCacheRecord);
    }

    return caseParticipantRoleDtls;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtls getCachedDtls() {

    final ReadCaseParticipantRoleDtlsCacheRecord readCaseParticipantRoleDtlsCacheRecord = cachedCaseParticipantRoleDtls.get();

    if (readCaseParticipantRoleDtlsCacheRecord.caseParticipantRoleDtls != null) {

      return readCaseParticipantRoleDtlsCacheRecord.caseParticipantRoleDtls;
    }
    return null;

  }

  // BEGIN, CR00052232, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRole_eoCaseParticipantRoleID readCaseParticipantRoleID(CaseIDParticipantRoleKey key)
    throws AppException, InformationalException {

    final CaseParticipantRole_eoCaseParticipantRoleID result = new CaseParticipantRole_eoCaseParticipantRoleID();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      // BEGIN, CR00052822, MC
      final StringBuffer caseParticipantRoleIDKeyString = new StringBuffer();
      final CaseParticipantRoleIDCache caseParticipantRoleIDCache = cachedCaseParticipantRoleID.get();

      if (caseParticipantRoleIDCache != null
        && TransactionInfo.getIdentifierForThisThread()
          == caseParticipantRoleIDCache.transactionID) {

        // Appending caseID and participantRoleID to form a key to get the
        // records from cache memory
        caseParticipantRoleIDKeyString.append(key.caseID);
        caseParticipantRoleIDKeyString.append(key.participantRoleID);

        final CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleID = caseParticipantRoleIDCache.caseParticipantRoleIDMap.get(
          caseParticipantRoleIDKeyString.toString());

        if (caseParticipantRoleID == null) {
          return result.assign(reloadCaseParticipantRoleIDCache(key)); // cache
          // miss
        } else {
          return result.assign(caseParticipantRoleID);
        }

      } else { // cache is not initialized or different transaction
        clearCaseParticipantRoleIDCache();
      }
    }

    return result.assign(reloadCaseParticipantRoleIDCache(key));
    // END CR00052822
  }

  // BEGIN, CR00069782, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseParticipantRole_eoCaseParticipantRoleID reloadCaseParticipantRoleIDCache(CaseIDParticipantRoleKey key)
    throws AppException, InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRole_eoCaseParticipantRoleID;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    caseParticipantRole_eoCaseParticipantRoleID = caseParticipantRoleObj.readCaseParticipantRoleID(
      key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      // BEGIN, CR00052822, MC
      final CaseParticipantRoleIDCache casePartcipantRoleIDCache = new CaseParticipantRoleIDCache();

      // Appending caseID and participantRoleID to form a key to put the records
      // in to cache memory
      final StringBuffer caseParticipantRoleIDKeyString = new StringBuffer();

      caseParticipantRoleIDKeyString.append(key.caseID);
      caseParticipantRoleIDKeyString.append(key.participantRoleID);

      casePartcipantRoleIDCache.caseParticipantRoleIDMap.put(
        caseParticipantRoleIDKeyString.toString(),
        caseParticipantRole_eoCaseParticipantRoleID);

      casePartcipantRoleIDCache.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedCaseParticipantRoleID.set(casePartcipantRoleIDCache);
      // END CR00052822
    }

    return caseParticipantRole_eoCaseParticipantRoleID;
  }

  // END, CR00069782

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRole_eoFullNameDetails readFullName(
    CaseParticipantRoleKey key) throws AppException, InformationalException {

    CaseParticipantRole_eoFullNameDetails caseParticipantRole_eoFullNameDetails = new CaseParticipantRole_eoFullNameDetails();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    boolean reloadCache = true;

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      final ReadFullNameDtlsCacheRecord readFullNameDtlsCacheRecord = cachedFullNameDtls.get();

      if (readFullNameDtlsCacheRecord != null) {
        // BEGIN, CR00069782, GSP
        caseParticipantRole_eoFullNameDetails.assign(
          readFullNameDtlsCacheRecord.caseParticipantRole_eoFullNameDetails);
        // END, CR00069782
        reloadCache = false;

        // if this is a deferred transaction, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionInfo.TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != readFullNameDtlsCacheRecord.transactionID) {

          reloadCache = true;
        }
      }
    }
    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {
      caseParticipantRole_eoFullNameDetails = reloadFullNameDtlsCache(key);
    }

    return caseParticipantRole_eoFullNameDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to reload the cache when a cache miss is identified
   *
   * @param key The key for the Case Participant Full Name details record
   * @return The details of the Case Participant Full Name details
   */
  protected CaseParticipantRole_eoFullNameDetails reloadFullNameDtlsCache(
    CaseParticipantRoleKey key) throws AppException, InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseParticipantRole_eoFullNameDetails caseParticipantRole_eoFullNameDetails;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    caseParticipantRole_eoFullNameDetails = caseParticipantRoleObj.readFullName(
      key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      final ReadFullNameDtlsCacheRecord readFullNameDtlsCacheRecord = new ReadFullNameDtlsCacheRecord();

      // BEGIN, CR00069782, GSP
      readFullNameDtlsCacheRecord.caseParticipantRole_eoFullNameDetails.assign(
        caseParticipantRole_eoFullNameDetails);
      // END, CR00069782
      readFullNameDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();
      // BEGIN, CR00069782, GSP
      cachedFullNameDtls.set(readFullNameDtlsCacheRecord);
      // END, CR00069782
    }

    return caseParticipantRole_eoFullNameDetails;
  }

  // END CR00052232

  // BEGIN, CR00069782, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtlsList reloadByPartRoleAndCaseCache(
    CaseIDParticipantRoleKey key) throws AppException, InformationalException {

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseParticipantRoleDtlsList caseParticipantRoleDtlsList;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    caseParticipantRoleDtlsList = caseParticipantRoleObj.searchByParticipantRoleAndCase(
      key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      final ReadCaseParticipantRoleDtlsListCacheRecord casePartRoleDtlsListCacheRecord = new ReadCaseParticipantRoleDtlsListCacheRecord();

      casePartRoleDtlsListCacheRecord.caseParticipantRoleDtlsList.assign(
        caseParticipantRoleDtlsList);

      casePartRoleDtlsListCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();
      cachedCaseParticipantRoleDtlsList.set(casePartRoleDtlsListCacheRecord);
    }

    return caseParticipantRoleDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtlsList searchByParticipantRoleAndCase(
    CaseIDParticipantRoleKey key) throws AppException, InformationalException {

    final CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = new CaseParticipantRoleDtlsList();

    // variable to hold transaction type
    final TransactionType transactionType = TransactionInfo.getTransactionType();

    boolean reloadCache = true;

    // If this is a batch transaction or deferred processing (and caching is
    // enabled), and we've hit the cache we do not need to reload the cache
    if (transactionType.equals(TransactionType.kBatch) && cachingEnabled
      || transactionType.equals(TransactionType.kDeferred) && cachingEnabled
      || transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled) {

      final ReadCaseParticipantRoleDtlsListCacheRecord casePartRoleDtlsListCacheRecord = cachedCaseParticipantRoleDtlsList.get();

      if (casePartRoleDtlsListCacheRecord != null) {

        caseParticipantRoleDtlsList.assign(
          casePartRoleDtlsListCacheRecord.caseParticipantRoleDtlsList);

        reloadCache = false;

        // if this is a deferred transaction, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionInfo.TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != casePartRoleDtlsListCacheRecord.transactionID) {

          reloadCache = true;
        }
      }
    }
    // Otherwise we need to read the CaseParticipantRole data
    if (reloadCache) {
      caseParticipantRoleDtlsList.assign(reloadByPartRoleAndCaseCache(key));
    }

    return caseParticipantRoleDtlsList;

  }
  // END, CR00069782
}
