/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007, 2010, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.fact.AddressFactory;
import curam.core.intf.Address;
import curam.core.sl.fact.ParticipantTabFactory;
import curam.core.sl.intf.ParticipantTab;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.ConcernRoleIDType;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DisableLinkIndicatorDetails;
import curam.core.struct.EmployerReadDtls;
import curam.core.struct.EmployerReadDtlsList;
import curam.core.struct.EmployerSearchDetails;
import curam.core.struct.EmployerSearchDtls;
import curam.core.struct.EmployerSearchDtls1;
import curam.core.struct.EmployerSearchKey;
import curam.core.struct.EmployerSearchKey1;
import curam.core.struct.EmployerSearchResult;
import curam.core.struct.EmployerSearchResult1;
import curam.core.struct.OtherAddressData;
import curam.message.BPOEMPLOYERSEARCH;
import curam.message.BPOPARTICIPANT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;


/**
 * Employer search interface for the Curam Application
 *
 */
public abstract class EmployerSearch extends curam.core.base.EmployerSearch {

  /**
   * @param employerSearchKey data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Method to perform an employer search
   */
  @Override
  @Deprecated
  public EmployerSearchResult search(EmployerSearchKey employerSearchKey)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
      new AppException(
        curam.message.BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_UNIMPLEMENTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        2);
    // Should not reach this point without throwing a validation
    return null;

  }

  /**
   * Method to perform an employer search, based solely on the employer
   * reference number
   *
   * @param alternateIDSearchKey employer reference number
   *
   * @return Employer details
   */
  @Override
  public EmployerReadDtlsList searchByReferenceNumber(
    AlternateIDSearchKey alternateIDSearchKey) throws AppException,
      InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
      new AppException(
        curam.message.BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_UNIMPLEMENTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    // Should not reach this point without throwing a validation
    return null;
  }

  /**
   * Method to perform an employer search, based solely on the employer
   * reference number
   *
   * @param alternateIDSearchKey employer reference number
   *
   * @return Employer details
   * @deprecated Since Curam 6.0.5.3, replaced by
   * {@link #searchByReferenceNumber()}
   */
  @Deprecated
  @Override
  public EmployerReadDtls readByReferenceNumber(
    AlternateIDSearchKey alternateIDSearchKey) throws AppException,
      InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
      new AppException(
        curam.message.BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_UNIMPLEMENTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    // Should not reach this point without throwing a validation
    return null;

  }

  /**
   * @param employerSearchDtls employer search details
   *
   * @deprecated Since Curam 6.0, replaced by {@link #restrictResults1()}
   *
   * Method to perform an employer search, based solely on the employer
   * reference number
   */
  @Override
  @Deprecated
  public void restrictResults(EmployerSearchDtls employerSearchDtls)
    throws AppException, InformationalException {

    // security details
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    // BEGIN, CR00226315, PM
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = employerSearchDtls.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    // BEGIN, CR00227859, PM
    if (!dataBasedSecurityResult.result && dataBasedSecurityResult.restricted) {
      // END, CR00227859
      // Return no details to client if User does not have access
      employerSearchDtls.tradingName = CuramConst.gkRestricted;
      employerSearchDtls.businessAddress = CuramConst.gkRestricted;
      employerSearchDtls.businessCity = CuramConst.gkRestricted;
      employerSearchDtls.registeredName = CuramConst.gkRestricted;
      employerSearchDtls.restricted = true;
      return;
    }

    // If the location data security is on then access denied
    if (!dataBasedSecurityResult.result) {
      employerSearchDtls.referenceNumber = null;
    }
    // END, CR00226315
  }

  // BEGIN, CR00257963, ZV
  // BEGIN, CR00218664, ZV
  /**
   * Method to apply common logic to employer search details.
   *
   * @param details The employer search result details
   * @param disableLinkIndicatorDetails Indicates if employer details hyperlink
   * should be disabled
   *
   * @return employer search details for display
   */
  @Override
  public EmployerSearchDetails processSearchDetails(
    EmployerSearchDtls1 details,
    DisableLinkIndicatorDetails disableLinkIndicatorDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00242606, RCB
    final EmployerSearchDetails employerSearchDetails = new EmployerSearchDetails();

    employerSearchDetails.assign(details);

    final ParticipantTab participantTabObj = ParticipantTabFactory.newInstance();
    final ConcernRoleIDType concernRoleIDType = new ConcernRoleIDType();

    concernRoleIDType.concernRoleID = details.concernRoleID;
    concernRoleIDType.concernRoleType = details.concernRoleType;

    employerSearchDetails.employerTabDetailsURL = participantTabObj.resolveParticipantTabPageURL(concernRoleIDType).pageURL;
    restrictResults1(details);
    // END, CR00242606

    if (details.tradingName == null) {
      return null;
    }

    if (!details.restricted) {

      final Address addressObj = AddressFactory.newInstance();

      final OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = details.businessAddress;

      if (addressObj.isEmpty(otherAddressData).emptyInd) {
        otherAddressData.addressData = details.primaryBusinessAddress;
      }

      employerSearchDetails.formattedBusinessAddress = ParticipantFactory.newInstance().displaySingleLineAddress(otherAddressData).addressString;

      if (details.tradingName.length() > CuramConst.gkZero) {
        employerSearchDetails.concernRoleName = details.tradingName;
        employerSearchDetails.xmlTradingNameData = getEmployerPrimaryNameDetails(details, disableLinkIndicatorDetails).toString();
        employerSearchDetails.xmlRegisteredNameData = getEmployerSecondaryNameDetails(details, details.registeredName).toString();
      } else {
        employerSearchDetails.concernRoleName = details.registeredName;
        employerSearchDetails.xmlRegisteredNameData = getEmployerPrimaryNameDetails(details, disableLinkIndicatorDetails).toString();
        employerSearchDetails.xmlTradingNameData = getEmployerSecondaryNameDetails(details, details.tradingName).toString();
      }

    } else {
      employerSearchDetails.formattedBusinessAddress = CuramConst.gkRestricted;
      employerSearchDetails.tradingName = CuramConst.gkRestricted;
      employerSearchDetails.registeredName = CuramConst.gkRestricted;
      employerSearchDetails.xmlTradingNameData = curam.core.sl.impl.ParticipantTab.getRestrictedDetails().toString();
      employerSearchDetails.xmlRegisteredNameData = curam.core.sl.impl.ParticipantTab.getRestrictedDetails().toString();
      // BEGIN, CR00295753, ZV
      employerSearchDetails.restrictedIndOpt = true;
      // END, CR00295753
    }

    return employerSearchDetails;
  }

  // END, CR00257963

  /**
   * Method to apply security restrictions to employer search results.
   *
   * @param result employer search details
   */
  @Override
  public void restrictResults1(EmployerSearchDtls1 result)
    throws AppException, InformationalException {

    // security details
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    // BEGIN, CR00226315, PM
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = result.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    // BEGIN, CR00227859, PM
    if (!dataBasedSecurityResult.result && dataBasedSecurityResult.restricted) {
      // END, CR00227859
      // Return no details to client if User does not have access
      result.restricted = true;
      return;
    }

    // If the location data security is on then access denied
    if (!dataBasedSecurityResult.result) {
      result.tradingName = null;
    }
    // END, CR00226315
  }

  /**
   * Method to perform an employer search
   *
   * @param key data on which the searched will be based
   *
   * @return The details of any employer records found
   */
  @Override
  public EmployerSearchResult1 search1(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
      new AppException(
        curam.message.BPOEMPLOYERSEARCH.ERR_EMPLOYERSEARCH_UNIMPLEMENTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        1);
    // Should not reach this point without throwing a validation
    return null;

  }

  /**
   * Format the XML data for an employer primary name details.
   *
   * @param details Employer details.
   * @param disableLinkIndicatorDetails Indicates if employer details hyperlink
   * should be disabled
   *
   * @return ContentPanelBuilder.
   */
  public static ContentPanelBuilder getEmployerPrimaryNameDetails(
    EmployerSearchDtls1 details,
    DisableLinkIndicatorDetails disableLinkIndicatorDetails)
    throws AppException, InformationalException {

    final ContentPanelBuilder employerNameDetails = ContentPanelBuilder.createPanel(
      CuramConst.gkContentPanel);

    final LocalisableString localisableEmployerName = new LocalisableString(
      BPOPARTICIPANT.INF_PARTICIPANT_DETAILS);

    String employerName = new String();

    if (details.tradingName.length() > 0) {
      employerName = details.tradingName;
    } else {
      employerName = details.registeredName;
    }

    localisableEmployerName.arg(employerName);

    if (details.alternateID.length() > 0) {
      localisableEmployerName.arg(details.alternateID);
    } else {
      localisableEmployerName.arg(details.primaryAlternateID);
    }

    if (disableLinkIndicatorDetails.disableLinkInd) {
      employerNameDetails.addlocalisableStringItem(
        localisableEmployerName.toClientFormattedText());
    } else {
      LinkBuilder linkBuilder;

      if (details.concernRoleType.equals(CONCERNROLETYPE.PROSPECTEMPLOYER)) {
        linkBuilder = LinkBuilder.createLocalizableLink(
          localisableEmployerName.toClientFormattedText(),
          CuramConst.gkProspectEmployerHomePage);
      } else {
        linkBuilder = LinkBuilder.createLocalizableLink(
          localisableEmployerName.toClientFormattedText(),
          CuramConst.gkEmployerHomePage);
      }
      linkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
        String.valueOf(details.concernRoleID));

      employerNameDetails.addLinkItem(linkBuilder);
    }

    if (details.concernRoleType.equals(CONCERNROLETYPE.PROSPECTEMPLOYER)) {

      final ImageBuilder imageBuilder = ImageBuilder.createImage(
        CuramConst.gkIcoProspectEmployer, CuramConst.gkEmpty);
      // BEGIN, CR00245752, PDN
      // Add prospect employer alternative text
      final String prospectText = new LocalisableString(BPOEMPLOYERSEARCH.INF_PROSPECT_EMPLOYER).toClientFormattedText();

      imageBuilder.setImageAltText(prospectText);
      // END, CR00245752
      imageBuilder.setImageResource(CuramConst.gkRendererImages);

      employerNameDetails.addImageItem(imageBuilder);

    }

    return employerNameDetails;
  }

  // END, CR00218664

  // BEGIN, CR00219812, ZV
  /**
   * Format the XML data for an employer secondary name details.
   *
   * @param details Employer details.
   * @param employerName Employer name
   *
   * @return ContentPanelBuilder.
   */
  public static ContentPanelBuilder getEmployerSecondaryNameDetails(
    EmployerSearchDtls1 details, String employerName) throws AppException,
      InformationalException {

    final ContentPanelBuilder employerNameDetails = ContentPanelBuilder.createPanel(
      CuramConst.gkContentPanel);

    LocalisableString localisableEmployerName = null;

    if (employerName.length() == 0) {
      localisableEmployerName = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);
      employerNameDetails.addlocalisableStringItem(
        localisableEmployerName.toClientFormattedText());
    } else {
      employerNameDetails.addStringItem(employerName);
    }

    return employerNameDetails;
  }
  // END, CR00219812

}
