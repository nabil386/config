/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import com.google.inject.Inject;
import curam.codetable.impl.WAITLISTENTRYSTATUSEntry;
import curam.core.struct.BatchProcessingDate;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;
import java.util.Set;


public abstract class ExpireWaitListEntry extends curam.core.base.ExpireWaitListEntry {

  @Inject
  protected WaitListEntryDAO waitListEntryDAO;

  // __________________________________________________________________________
  /**
   * Default constructor for expiring wait list.
   */
  public ExpireWaitListEntry() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // __________________________________________________________________________
  /**
   * Expires the wait list entry if the client is not allocated a resource, or
   * not removed from the list before the expiry date is reached. The
   * processing date is optional and if not mentioned, the current date is
   * considered for processing.
   *
   * @param processingDate
   * The business date for which the batch process will be run. If
   * this is set, this is the date that will be returned by
   * 'getCurrentDate'.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void expireWaitListEntry(BatchProcessingDate processingDate)
    throws AppException, InformationalException {

    // if processing date not set, then set the processing date to current date
    // else the processing date would be blank and the search query would not
    // retrieve any results.
    if (processingDate.processingDate.equals(Date.kZeroDate)) {
      processingDate.processingDate = Date.getCurrentDate();
    }

    // searches all open wait list entries and expires them individually
    final Set<WaitListEntry> waitListEntries = waitListEntryDAO.searchByExpiryDateAndStatus(
      processingDate.processingDate, WAITLISTENTRYSTATUSEntry.OPEN);

    for (final WaitListEntry waitListEntry : waitListEntries) {
      waitListEntry.expire(waitListEntry.getVersionNo());
    }

  }

}
