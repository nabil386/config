/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.codetable.BATCHPROCESSNAME;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.sl.entity.struct.CaseNomineeDetails;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.propagator.impl.CERMetaDataLoadUtility;
import curam.core.struct.BatchProcessStreamKey;
import curam.core.struct.BatchProcessingID;
import curam.core.struct.BatchProcessingSkippedRecord;
import curam.core.struct.BatchProcessingSkippedRecordList;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.core.struct.GenerateInstrumentsKey;
import curam.core.struct.ProcessILIsDueForParticipantKey;
import curam.core.struct.ProcessProdDeliveryCounters;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * To identify InstructionLineItems that are to be processed, to roll up
 * instruction line items into instructions and, where appropriate, create
 * an instrument.
 */
public abstract class GenerateInstrumentsStream extends curam.core.base.GenerateInstrumentsStream {

  protected static final ProcessProdDeliveryCounters totalProcessProdDeliveryCounters = new ProcessProdDeliveryCounters();

  // ___________________________________________________________________________
  /**
   * This method is the driver for this processing. It looks up the current
   * instance of the batch program and processes chunks of data until no
   * further chunks exist to be processed.
   *
   * @param batchProcessStreamKey The identifier for the
   * instance of the batch program (if any)
   */
  @Override
  public void process(BatchProcessStreamKey batchProcessStreamKey)
    throws AppException, InformationalException {

    // BEGIN, CR00390475, SD
    final CERMetaDataLoadUtility loadObj = new CERMetaDataLoadUtility();

    loadObj.loadCERRuleSetCache();
    // END, CR00390475

    final BatchStreamHelper batchStreamHelper = new BatchStreamHelper();
    final GenerateInstrumentsStreamWrapper generateInstrumentsStreamWrapper = new GenerateInstrumentsStreamWrapper(
      this);

    // register the security implementation
    SecurityImplementationFactory.register();

    if (batchProcessStreamKey.instanceID.length() == 0) {

      batchProcessStreamKey.instanceID = BATCHPROCESSNAME.GENERATE_INSTRUMENTS;

    }

    batchStreamHelper.runStream(batchProcessStreamKey,
      generateInstrumentsStreamWrapper);

  }

  // ___________________________________________________________________________
  /**
   * This method takes the result of the processing and turns it into a string
   *
   * @param skippedCasesCount The number of cases skipped in this chunk
   */
  @Override
  public String getChunkResult(int skippedCasesCount) throws AppException,
      InformationalException {

    totalProcessProdDeliveryCounters.casesSkippedCount += skippedCasesCount;

    return stringizeProcessProdDeliveryCounters(
      totalProcessProdDeliveryCounters);
  }

  // ___________________________________________________________________________
  /**
   * This method takes an instance of ProcessProdDeliveryCounters and turns it
   * into a string
   *
   * @param processProdDeliveryCounters The results to be turned into a string
   */
  @Override
  public String stringizeProcessProdDeliveryCounters(
    ProcessProdDeliveryCounters processProdDeliveryCounters) {

    final StringBuffer result = new StringBuffer();

    result.append(processProdDeliveryCounters.countILIsProcessed);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.countIntILIsCreated);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.countLbyInstrumentsCreated);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.countPmtInstructionsCreated);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.countPmtInstrumentsCreated);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.countPmtRecvdInstructionsCreated);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.countSurILIsCreated);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(processProdDeliveryCounters.casesSkippedCount);

    // reset the values in processProdDeliveryCounters
    processProdDeliveryCounters.countILIsProcessed = 0;
    processProdDeliveryCounters.countIntILIsCreated = 0;
    processProdDeliveryCounters.countLbyInstrumentsCreated = 0;
    processProdDeliveryCounters.countPmtInstructionsCreated = 0;
    processProdDeliveryCounters.countPmtInstrumentsCreated = 0;
    processProdDeliveryCounters.countPmtRecvdInstructionsCreated = 0;
    processProdDeliveryCounters.countSurILIsCreated = 0;
    processProdDeliveryCounters.casesSkippedCount = 0;

    return result.toString();

  }

  // ___________________________________________________________________________
  /**
   * This method generates all the instruments for the given nominee
   *
   * @param batchProcessingID The details of the case to be processed
   * @param generateInstrumentsKey The key for this batch program
   */
  @Override
  public BatchProcessingSkippedRecord processRecord(
    BatchProcessingID batchProcessingID,
    GenerateInstrumentsKey generateInstrumentsKey) throws AppException,
      InformationalException {

    ProcessProdDeliveryCounters processProdDeliveryCounters;
    final curam.core.intf.ProcessInstructionLineItem processInstructionLineItemObj = curam.core.fact.ProcessInstructionLineItemFactory.newInstance();
    // BEGIN, CR00021385, SP
    // BEGIN, HARP 64318, TV
    final ProcessILIsDueForParticipantKey processILIsDueForParticipantKey = new ProcessILIsDueForParticipantKey();

    processILIsDueForParticipantKey.participantRoleID = batchProcessingID.recordID;

    processProdDeliveryCounters = processInstructionLineItemObj.processILIsDueForParticipantRoleID(
      processILIsDueForParticipantKey);
    // END, HARP 64318
    // END, CR00021385
    storeResults(processProdDeliveryCounters);

    return null;

  }

  // ___________________________________________________________________________
  /**
   * Aggregate the results of processing a single chunk into the running total
   *
   * @param processProdDeliveryCounters The results of processing the current
   * chunk
   */
  @Override
  public void storeResults(
    ProcessProdDeliveryCounters processProdDeliveryCounters) {

    totalProcessProdDeliveryCounters.casesSkippedCount += processProdDeliveryCounters.casesSkippedCount;
    totalProcessProdDeliveryCounters.countILIsProcessed += processProdDeliveryCounters.countILIsProcessed;
    totalProcessProdDeliveryCounters.countIntILIsCreated += processProdDeliveryCounters.countIntILIsCreated;
    totalProcessProdDeliveryCounters.countLbyInstrumentsCreated += processProdDeliveryCounters.countLbyInstrumentsCreated;
    totalProcessProdDeliveryCounters.countPmtInstructionsCreated += processProdDeliveryCounters.countPmtInstructionsCreated;
    totalProcessProdDeliveryCounters.countPmtInstrumentsCreated += processProdDeliveryCounters.countPmtInstrumentsCreated;
    totalProcessProdDeliveryCounters.countPmtRecvdInstructionsCreated += processProdDeliveryCounters.countPmtRecvdInstructionsCreated;
    totalProcessProdDeliveryCounters.countSurILIsCreated += processProdDeliveryCounters.countSurILIsCreated;
  }

  // ___________________________________________________________________________
  /**
   * This method processes the case nominees skipped by the processing to
   * generate instruments. The case owner of the affected cases will be
   * informed of the issue.
   *
   * @param batchProcessingSkippedRecordList The list of cases skipped during
   * instrument generation
   */
  @Override
  public void processSkippedCases(
    BatchProcessingSkippedRecordList batchProcessingSkippedRecordList)
    throws AppException, InformationalException {

    // For each case
    for (int i = 0; i < batchProcessingSkippedRecordList.dtls.size(); i++) {

      // BEGIN, CR00098601, SD
      // create a task
      createTask(batchProcessingSkippedRecordList.dtls.item(i),
        new CaseNomineeDetails());
      // END, CR00098601
    }

  }

  // ___________________________________________________________________________
  /**
   * This method creates the task to notify the case owner that the financial
   * processing for this case failed and it needs to be investigated.
   *
   * @param batchProcessingSkippedRecord The record ID of the case which could
   * not be processed and the associated error message
   * @param caseNomineeDetails The details of the nominee
   */
  @Override
  public void createTask(
    BatchProcessingSkippedRecord batchProcessingSkippedRecord,
    CaseNomineeDetails caseNomineeDetails) throws AppException,
      InformationalException {

    // BEGIN, CR00098601, SD
    // Override with create concern task as case nominee details are no longer
    // available
    createConcernTask(batchProcessingSkippedRecord);
    // END, CR00098601
  }

  // BEGIN, CR00098601, SD
  // ___________________________________________________________________________
  /**
   * This method creates the task to notify the concern administrator that the
   * financial processing for this concern failed and it needs to be
   * investigated.
   *
   * @param batchProcessingSkippedRecord The record ID of the case which could
   * not be processed and the associated error message
   */
  @Override
  public void createConcernTask(
    BatchProcessingSkippedRecord batchProcessingSkippedRecord)
    throws AppException, InformationalException {

    // Concern Role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // notification manipulation variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

    // check the environment variable
    String genIntrumentsFailure = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENINSTRUMENTSFAILURETICKET);

    if (genIntrumentsFailure == null) {

      genIntrumentsFailure = EnvVars.ENV_GENINSTRUMENTSFAILURETICKET_DEFAULT;
    }

    if (genIntrumentsFailure.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }

    // set key to read concern role
    concernRoleKey.concernRoleID = batchProcessingSkippedRecord.recordID;

    // read concern role name and reference
    final ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
      concernRoleKey);

    final AppException subjectMsg = new AppException(
      curam.message.BPOGENERATEINSTRUMENTSSTREAM.INF_GENERATE_CONCERN_INSTRUMENTS_FAILURE_SUB);

    subjectMsg.arg(concernRoleNameAndAlternateID.concernRoleName);
    subjectMsg.arg(concernRoleNameAndAlternateID.primaryAlternateID);

    final AppException reasonMsg = new AppException(
      curam.message.BPOGENERATEINSTRUMENTSSTREAM.INF_GENERATE_INSTRUMENTS_FAILURE_TXT);

    reasonMsg.arg(batchProcessingSkippedRecord.errorMessage);

    // BEGIN, CR00163236, CL
    // set notification details
    standardManualTaskDtls.dtls.taskDtls.subject = subjectMsg.getMessage(
      TransactionInfo.getProgramLocale());
    standardManualTaskDtls.dtls.taskDtls.comments = reasonMsg.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.generateFinancialsTaskDefinitionID;

    // Set concerning details
    standardManualTaskDtls.dtls.concerningDtls.participantRoleID = batchProcessingSkippedRecord.recordID;

    // create notification
    notificationObj.sendConcernAdministratorNotification(standardManualTaskDtls);

  }
  // END, CR00098601

}
