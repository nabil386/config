/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005,2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.codetable.CASESTATUS;
import curam.core.fact.FinancialComponentFactory;
import curam.core.struct.BatchProcessingIDList;
import curam.core.struct.FCCaseIDDateRangeStatusMOD;
import curam.core.struct.FCCaseIDDateRangeStatusMODCaseStatusCode;
import curam.core.struct.FCCaseIDDateRangeStatusMODMultipleCaseStatusCode;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.GetDetailsForGenerateILIsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * The custom methods for the FinancialComponent entity
 */
public abstract class FinancialComponent extends curam.core.base.FinancialComponent {

  // ___________________________________________________________________________
  /**
   * Set the indicators, to search by delivery method, processing from date
   * or productID as appropriate
   *
   * @param key The key for this operation
   */
  @Override
  protected void presearchDetailsForGenerateILIs(
    GetDetailsForGenerateILIsKey key) throws AppException,
      InformationalException {

    if (key.deliveryMethod.length() == 0) {

      key.searchByDeliveryMethod = false;

    } else {

      key.searchByDeliveryMethod = true;

    }

    if (key.processingDateFrom.isZero()) {

      key.searchByProcessingDateFrom = false;

    } else {

      key.searchByProcessingDateFrom = true;

    }

    if (key.productID == 0) {

      key.searchByProductID = false;

    } else {

      key.searchByProductID = true;

    }
  }

  // ___________________________________________________________________________
  /**
   * Set the status code field
   *
   * @param fcCaseIDDateRangeStatusMOD The key for this operation
   */
  @Override
  protected void presearchByCaseIDStatusDateRangeMOD(
    FCCaseIDDateRangeStatusMOD fcCaseIDDateRangeStatusMOD)
    throws AppException, InformationalException {

    fcCaseIDDateRangeStatusMOD.statusCode = curam.codetable.FINCOMPONENTSTATUS.LIVE;

  }

  // ___________________________________________________________________________
  /**
   * Set the status code field
   *
   * @param fcCaseIDDateRangeStatusMOD The key for this operation
   */
  @Override
  protected void presearchByCaseIDStatusDate(
    FCCaseIDDateRangeStatusMOD fcCaseIDDateRangeStatusMOD)
    throws AppException, InformationalException {

    fcCaseIDDateRangeStatusMOD.statusCode = curam.codetable.FINCOMPONENTSTATUS.LIVE;

  }

  // ___________________________________________________________________________
  /**
   * Set the status code field
   *
   * @param fcCaseIDDateRangeStatusMOD The key for this operation
   */
  @Override
  protected void presearchByCaseIDStatusDateMOD(
    FCCaseIDDateRangeStatusMOD fcCaseIDDateRangeStatusMOD)
    throws AppException, InformationalException {

    fcCaseIDDateRangeStatusMOD.statusCode = curam.codetable.FINCOMPONENTSTATUS.LIVE;

  }

  // ___________________________________________________________________________
  /**
   * Set the status code field
   *
   * @param fcCaseIDDateRangeStatusMOD The key for this operation
   */
  @Override
  protected void presearchByCaseIDStatusDateRange(
    FCCaseIDDateRangeStatusMOD fcCaseIDDateRangeStatusMOD)
    throws AppException, InformationalException {

    fcCaseIDDateRangeStatusMOD.statusCode = curam.codetable.FINCOMPONENTSTATUS.LIVE;

  }

  // ___________________________________________________________________________
  /**
   * This method is used to get the list of FCs to be processed for a given
   * case, this always filters on a date and status, and can (optionally) filter
   * on delivery method and a date range.
   *
   * @param fcCaseIDDateRangeStatusMOD The key for this operation
   */
  @Override
  public FinancialComponentDtlsList getDetailsForGenerateILIsCase(
    FCCaseIDDateRangeStatusMOD fcCaseIDDateRangeStatusMOD)
    throws AppException, InformationalException {

    boolean deliveryMethodSupplied = true;
    boolean fromDateSupplied = true;

    if (fcCaseIDDateRangeStatusMOD.nomineeDelivMethod.length() == 0) {

      deliveryMethodSupplied = false;

    }

    if (fcCaseIDDateRangeStatusMOD.processingDateFrom.isZero()) {

      fromDateSupplied = false;

    }

    // BEGIN, CR00102570, CW

    // Check if the curam.miscapp.payuptosuspendeddate environment variable is
    // set to NO.
    // If it is, then we need to perform a search that will filter out any FCs
    // that belong to a case
    // that is suspended. This overcomes the issue of once-off FCs being
    // realized into line items
    // when the case is suspended

    // If the environment variable is set to YES, then its ok for once-off FCs
    // such as
    // Benefit Underpayments to be processed as the case is paying up to the
    // date of
    // suspension.

    // When the case has a status of suspended, the invocation of reassessment
    // will not
    // result in the regeneration of financials, hence, no once-off FCs will be
    // created when
    // the case is suspended. This is why the above check suffices.

    final Boolean issuePaymentToSuspendDate = Configuration.getBooleanProperty(
      EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE,
      Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE_DEFAULT));

    // Check if the curam.miscapp.payuptocloseddate environment variable is set
    // to NO.
    // If it is, then we need to perform a search that will filter out any FCs
    // that belong to a case
    // that is closed. This overcomes the issue of once-off FCs being realized
    // into line items
    // when the case is closed

    // If the environment variable is set to YES, then its ok for once-off FCs
    // such as
    // Benefit Underpayments to be processed as the case is paying up to the
    // date of
    // closure.

    // When the case has a status of closed, the invocation of reassessment will
    // not
    // result in the regeneration of financials, hence, no once-off FCs will be
    // created when
    // the case is closed. This is why the above check suffices.

    final Boolean issuePaymentToClosedDate = Configuration.getBooleanProperty(
      EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE,
      Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE_DEFAULT));

    if (!issuePaymentToSuspendDate && issuePaymentToClosedDate) {

      // Filter out any Financial Components that belong to a case that is
      // suspended

      final FCCaseIDDateRangeStatusMODCaseStatusCode fcCaseIDDateRangeStatusMODCaseStatusCode = new FCCaseIDDateRangeStatusMODCaseStatusCode();

      fcCaseIDDateRangeStatusMODCaseStatusCode.assign(
        fcCaseIDDateRangeStatusMOD);
      fcCaseIDDateRangeStatusMODCaseStatusCode.caseStatusCode = CASESTATUS.SUSPENDED;

      if (deliveryMethodSupplied && fromDateSupplied) {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDateRangeMOD(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      } else if (fromDateSupplied) {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDateRange(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      } else if (deliveryMethodSupplied) {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDateMOD(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      } else {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDate(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      }

    } else if (issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

      // Filter out any Financial Components that belong to a case that is
      // closed

      final FCCaseIDDateRangeStatusMODCaseStatusCode fcCaseIDDateRangeStatusMODCaseStatusCode = new FCCaseIDDateRangeStatusMODCaseStatusCode();

      fcCaseIDDateRangeStatusMODCaseStatusCode.assign(
        fcCaseIDDateRangeStatusMOD);
      fcCaseIDDateRangeStatusMODCaseStatusCode.caseStatusCode = CASESTATUS.CLOSED;

      if (deliveryMethodSupplied && fromDateSupplied) {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDateRangeMOD(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      } else if (fromDateSupplied) {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDateRange(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      } else if (deliveryMethodSupplied) {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDateMOD(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      } else {

        return this.searchByCaseIDAndCaseStatusAndFCStatusDate(
          fcCaseIDDateRangeStatusMODCaseStatusCode);

      }

    } else if (!issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

      // Filter out any Financial Components that belong to a case that is
      // suspended or closed

      final FCCaseIDDateRangeStatusMODMultipleCaseStatusCode fcCaseIDDateRangeStatusMODMultipleCaseStatusCode = new FCCaseIDDateRangeStatusMODMultipleCaseStatusCode();

      fcCaseIDDateRangeStatusMODMultipleCaseStatusCode.assign(
        fcCaseIDDateRangeStatusMOD);
      fcCaseIDDateRangeStatusMODMultipleCaseStatusCode.caseStatusCode1 = CASESTATUS.SUSPENDED;
      fcCaseIDDateRangeStatusMODMultipleCaseStatusCode.caseStatusCode2 = CASESTATUS.CLOSED;

      if (deliveryMethodSupplied && fromDateSupplied) {

        return this.searchByCaseIDAndMultipleCaseStatusAndFCStatusDateRangeMOD(
          fcCaseIDDateRangeStatusMODMultipleCaseStatusCode);

      } else if (fromDateSupplied) {

        return this.searchByCaseIDAndMultipleCaseStatusAndFCStatusDateRange(
          fcCaseIDDateRangeStatusMODMultipleCaseStatusCode);

      } else if (deliveryMethodSupplied) {

        return this.searchByCaseIDAndMultipleCaseStatusAndFCStatusDateMOD(
          fcCaseIDDateRangeStatusMODMultipleCaseStatusCode);

      } else {

        return this.searchByCaseIDAndMultipleCaseStatusAndFCStatusDate(
          fcCaseIDDateRangeStatusMODMultipleCaseStatusCode);

      }

    }
    // END, CR00102570

    if (deliveryMethodSupplied && fromDateSupplied) {

      return searchByCaseIDStatusDateRangeMOD(fcCaseIDDateRangeStatusMOD);

    } else if (fromDateSupplied) {

      return searchByCaseIDStatusDateRange(fcCaseIDDateRangeStatusMOD);

    } else if (deliveryMethodSupplied) {

      return searchByCaseIDStatusDateMOD(fcCaseIDDateRangeStatusMOD);

    } else {

      return searchByCaseIDStatusDate(fcCaseIDDateRangeStatusMOD);

    }

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchDetailsForGenerateILIs
   */
  @Override
  public BatchProcessingIDList getDetailsForGenerateILIs(
    curam.core.struct.GetDetailsForGenerateILIsKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    return FinancialComponentFactory.newInstance().searchDetailsForGenerateILIs(
      key);
  }

}
