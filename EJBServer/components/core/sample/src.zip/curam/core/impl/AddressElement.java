/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.IndexAddressSynchronizationFactory;
import curam.core.struct.AddressElementDtls;
import curam.core.struct.AddressKeyStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTableItemIdentifier;


/**
 * This process class provides the functionality to manipulate
 * address elements.
 */
public abstract class AddressElement extends curam.core.base.AddressElement {

  // BEGIN, CR00076104, PMD
  // ___________________________________________________________________________
  /**
   * Method to convert the address element details to upper case
   *
   * @param details the address element details
   */
  @Override
  protected void convertDetailsToUpper(AddressElementDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00190252, NP
    validateAddressElementLimit(details);
    // END, CR00190252
    // Convert the element value field to upper case
    details.upperElementValue = details.elementValue.toUpperCase();
  }

  // ___________________________________________________________________________
  // BEGIN, CR00190252, NP
  /**
   * Validates the Address Element details limits
   *
   * @param AddressElementDtls
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected void validateAddressElementLimit(AddressElementDtls details)
    throws AppException, InformationalException {

    // END, CR00198672
    if (details.elementValue.toUpperCase().length()
      > CuramConst.kUpperADDRESSELEMENTVALUE) {

      final CodeTableItemIdentifier elementTypeIdentifier = new CodeTableItemIdentifier(
        curam.codetable.ADDRESSELEMENTTYPE.TABLENAME, details.elementType);

      final AppException e = new AppException(
        curam.message.BPOADDRESS.ERR_FV_UPPER_ADDRESSELEMENT_EXCEEDED_LIMIT);

      e.arg(elementTypeIdentifier);
      e.arg(
        details.elementValue.toUpperCase().length()
          - CuramConst.kUpperADDRESSELEMENTVALUE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
  }

  // END, CR00190252

  // ___________________________________________________________________________
  /**
   * Called before the insert operation.
   *
   * @param details The details for the new address element record
   */
  @Override
  protected void preinsert(AddressElementDtls details) throws AppException,
      InformationalException {

    // Convert address element details to upper case
    convertDetailsToUpper(details);
  }

  // END, CR00076104

  // ___________________________________________________________________________
  // BEGIN, CR00078922, CC
  /**
   * Called after the insert operation.
   *
   * @param details The details for the new address element record
   */
  @Override
  protected void postinsert(AddressElementDtls details) throws AppException,
      InformationalException {

    // Synchronize the indexed staging database with the update to the address
    // element entity.
    final curam.core.intf.IndexAddressSynchronization addressSynchronizationObj = IndexAddressSynchronizationFactory.newInstance();

    addressSynchronizationObj.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Called before the remove address by addressID
   *
   * @param addressID Address unique identifier
   */
  @Override
  protected void preremoveByAddressID(AddressKeyStruct addressID)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the address
    // element entity.
    final curam.core.intf.IndexAddressSynchronization addressSynchronizationObj = IndexAddressSynchronizationFactory.newInstance();

    addressSynchronizationObj.removeByAddressID(addressID);
  }
  // END, CR00078922, CC

}
