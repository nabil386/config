/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2006, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


/**
 * Constants for Key Set.
 *
 */
public abstract class KeySets extends curam.util.resources.KeySet {

  public static final String KEY_SET_CASE = "CASE";

  public static final String KEY_SET_LIABILITY = "LIABILITY";

  public static final String KEY_SET_ASSESSMENT = "ASSESSMENT";

  public static final String KEY_SET_PERSON = "PERSON";

  public static final String KEY_SET_EMPLOYER = "EMPLOYER";

  public static final String KEY_SET_UTILITY = "UTILITY";

  public static final String KEY_SET_PRODUCTPROVIDER = "PRODPROVDR";

  public static final String KEY_SET_SERVICESUPPLIER = "SERVSUPPLR";

  public static final String KEY_SET_INFORMATIONPROVIDER = "INFOPROVDR";

  public static final String KEY_SET_REPRESENTATIVE = "REPRESENT";

  public static final String KEY_SET_RECEIPTNUMBER = "RECNUMBER";

  public static final String KEY_SET_WORKFLOW = "WORKFLOW";

  public static final String KEY_SET_EVIDENCEINSTANCE = "EVIDINST";

  public static final String KEY_SET_EVIDENCESUCCESSION = "EVIDSUCN";

  public static final String KEY_SET_AUDITPLAN = "AUDITPLAN";

  public static final String KEY_SET_CASEAUDITSEQNUM = "CASEAUDSEQ";

  public static final String KEY_SET_AUDITPLANSEQNUM = "AUDPLANSEQ";

  // BEGIN, CR00272939, KRK
  public static final String KEY_SET_EXTERNALPARTY = "EXTPARTY";

  // END, CR00272939

  // BEGIN, CR00260946, MR
  /**
   * Key set constant for an assessment product business object.
   */
  public static final String KEY_SET_ASSMENTBO = "ASSMENTBO";

  /**
   * Key set constant for an admin integrated case business object.
   */
  public static final String KEY_SET_ADMINICBO = "ADMINICBO";

  // END, CR00260946

  // BEGIN, CR00260989, MR
  /**
   * Key set constant for working pattern entity.
   */
  public static final String KEY_SET_WORKGPATRN = "WORKGPATRN";

  /**
   * Key set constant for location holiday entity.
   */
  public static final String KEY_SET_LOCATONHDY = "LOCATONHDY";

  /**
   * Key set constant for resources entity.
   */
  public static final String KEY_SET_RESOURCES = "RESOURCES";

  /**
   * Key set constant for an user business object.
   */
  public static final String KEY_SET_USERBO = "USERBO";

  /**
   * Key set constant for milestone waiver approval check entity.
   */
  public static final String KEY_SET_MSWRAPPCHK = "MSWRAPPCHK";

  /**
   * Key set constant for product business object.
   */
  public static final String KEY_SET_PRODUCTBO = "PRODUCTBO";

  /**
   * Key set constant for location structure business object.
   */
  public static final String KEY_SET_LOCNSTREBO = "LOCNSTREBO";

  /**
   * Key set constant for phone number entity.
   */
  public static final String KEY_SET_PHONENMBER = "PHONENMBER";

  /**
   * Key set constant for an email address entity.
   */
  public static final String KEY_SET_EMAILADDSS = "EMAILADDSS";

  // END, CR00260989

  /**
   * Key set constant for an assessment product business object.
   */
  public static final String KEY_SET_FINANCIALCALENDAR = "FACAL";

  // BEGIN, CR00296670, ZV
  /**
   * Key set constant for prospect person.
   */
  public static final String KEY_SET_PROSPECT_PERSON = "PRPERSON";

  /**
   * Key set constant for prospect employer.
   */
  public static final String KEY_SET_PROSPECT_EMPLOYER = "PREMPLOYER";

  // END, CR00296670

  // BEGIN, CR00293207, SS
  /**
   * Key set constant for Address entity.
   */
  public static final String KEY_SET_ADDRESS = "RAKSADD";

  /**
   * Key set constant for Activity entity.
   */
  public static final String KEY_SET_ACTIVITY = "RAKSACT";

  /**
   * Key set constant for ActivityRecurrence entity.
   */
  public static final String KEY_SET_ACTIVITYRECURRENCE = "RAKSACTREC";

  // END, CR00293207

  // BEGIN, CR00471408, SH
  /**
   * Key set constant for ReassessmentQueue entity.
   */
  public static final String KEY_SET_REASSESSMENT_AGGREGATION = "REASSQ";
  // END, CR00471408

}
