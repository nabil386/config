/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.struct.OverpmtEvidenceDetails;
import curam.core.struct.AutomatedCreateCaseDetails;
import curam.core.struct.BeneficiaryDetails;
import curam.core.struct.NewCreatedCaseDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Methods to create a new overpayment case or send a ticket to the case
 * owner letting them know that an overpayment case is required.
 */
public abstract class AutomatedCaseCreation extends curam.core.base.AutomatedCaseCreation {

  protected static final int kOneElement = 1;

  // ___________________________________________________________________________
  /**
   * Method to automatically create a new overpayment case.
   * This method is a place holder for an implementation to be provided to
   * match a customers specific requirements in this area.
   *
   * @param details details of the original case, the type of case required and
   * the amount
   * @param beneficiaryDetails details of the beneficiary
   *
   * @return the caseID of the new case
   */
  @Override
  public NewCreatedCaseDetails createAutomatedCase(AutomatedCreateCaseDetails details,
    BeneficiaryDetails beneficiaryDetails) throws AppException,
      InformationalException {

    final NewCreatedCaseDetails newCreatedCaseDetails = new NewCreatedCaseDetails();

    final NewCreatedCaseDetails createdCaseDetails = ReassessmentProductFactory.newInstance().createBenefitOverpaymentProduct(
      details, beneficiaryDetails);

    newCreatedCaseDetails.caseID = createdCaseDetails.caseID;

    createEvidenceForNewCase(newCreatedCaseDetails, details);
    createTicketForNewCase(newCreatedCaseDetails, details);

    return newCreatedCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates a ticket for the newly created case.
   *
   * @param newDetails details of the original case, the type of case required
   * and the amount
   * @param details the caseID of the new case
   */
  @Override
  public void createTicketForNewCase(NewCreatedCaseDetails newDetails,
    AutomatedCreateCaseDetails details) throws AppException,
      InformationalException {

    ReassessmentProductFactory.newInstance().createTicketForBenefitOverpayment(
      newDetails, details);
  }

  // ___________________________________________________________________________
  /**
   * Creates evidence for the new overpayment case. This method is a place
   * holder for an implementation to be provided to match a customers specific
   * requirements in this area.
   *
   * @param newCreatedCaseDetails The caseID of the new case
   * @param details Details of the original case, the type of case required and
   * the amount
   */
  @Override
  public void createEvidenceForNewCase(
    NewCreatedCaseDetails newCreatedCaseDetails,
    AutomatedCreateCaseDetails details) throws AppException,
      InformationalException {

    final OverpmtEvidenceDetails overpmtEvidenceDetails = new OverpmtEvidenceDetails();

    overpmtEvidenceDetails.caseID = newCreatedCaseDetails.caseID;
    overpmtEvidenceDetails.fromDate = details.fromDate;
    overpmtEvidenceDetails.toDate = details.toDate;
    overpmtEvidenceDetails.amount = details.amount;
    overpmtEvidenceDetails.relatedCaseID = details.caseID;
    overpmtEvidenceDetails.type = details.caseType;

    ReassessmentProductFactory.newInstance().createOverpaymentEvidence(
      overpmtEvidenceDetails);
  }

}
