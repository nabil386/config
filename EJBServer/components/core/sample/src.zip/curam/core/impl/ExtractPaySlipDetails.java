/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2006, 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CURRENCY;
import curam.codetable.ILITYPE;
import curam.codetable.PAYSLIPINSTRUCTIONSTATUS;
import curam.codetable.PAYSLIPRECIPIENT;
import curam.codetable.PMTRECONCILIATIONSTATUS;
import curam.codetable.PRODUCTTYPE;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.fact.PayslipFactory;
import curam.core.fact.PayslipInstructionFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.intf.Address;
import curam.core.intf.Payslip;
import curam.core.intf.PayslipInstruction;
import curam.core.sl.entity.fact.CaseNomineeFactory;
import curam.core.sl.entity.struct.CaseNomineeDetails;
import curam.core.sl.entity.struct.CaseNomineeViewKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemFinCompID;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ILIPayslipDetails;
import curam.core.struct.ILIPayslipInstructionID;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PIPslipInstructionID;
import curam.core.struct.PSIStatusCode;
import curam.core.struct.PSStatusCodeIssueDate;
import curam.core.struct.PayslipDetailsExtractLines;
import curam.core.struct.PayslipDtls;
import curam.core.struct.PayslipInstructionKey;
import curam.core.struct.PayslipKey;
import curam.core.struct.PmtReconcilStatusCodeStruct;
import curam.core.struct.ProcessedPaySlipCounters;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.message.BPOGENERATEPAYSLIPS;
import curam.message.GENERALFINANCE;
import curam.util.dataaccess.ReadmultiOperation;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This class provides a method to extract pay slip details in string
 * form, that are suitable for writing the record to a file.
 *
 */
public abstract class ExtractPaySlipDetails extends curam.core.base.ExtractPaySlipDetails {

  PayslipInstruction payslipInstructionObj = PayslipInstructionFactory.newInstance();

  Payslip payslipObj = PayslipFactory.newInstance();

  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * batch process.
   */
  static class RetrieveILIDetails extends ReadmultiOperation {

    // _________________________________________________________________________
    /**
     * PaySlipDetail is used to store the data of the payslip before it is
     * converted into a printable format.
     */
    protected static class PaySlipDetail {

      protected static final int kBufferCapacity = 256;

      protected long oldCaseID;

      boolean headerCreated;

      int payslipCount;

      StringBuffer strBuff;

      PaySlipDetail() {

        payslipCount = 0;
        oldCaseID = 0;
        headerCreated = false;

        reset();
      }

      // _______________________________________________________________________
      /**
       * Resets the counters in the PaySlipDetail. This allows subsequent sets
       * of results to be processed.
       */
      void reset() {

        strBuff = new StringBuffer(kBufferCapacity);
      }

      // _______________________________________________________________________
      /**
       * Determines if the caseID provided represents a new case for this
       * payslip.
       *
       * @param caseID The new case to compare against those already in the
       * payslip.
       *
       * @return <code>true</code> if the case represented by the caseID is
       * not the current one in the payslip.
       */
      boolean isNewCase(final long caseID) {

        if (oldCaseID == caseID) {
          return false;
        }

        oldCaseID = caseID;

        return true;
      }

      // _______________________________________________________________________
      /**
       * Determines if the payslip needs a header. If a header has already been
       * generated for the payslip, then this returns <code>false</code>.
       *
       * As every payslip can only have one header, the payslip counter is also
       * updated by this call.
       *
       * @return <code>true</code> indicates that a header is required for this
       * payslip.
       */
      boolean needsHeader() {

        if (headerCreated) {
          return false;
        }

        // Mark the payslip as having a header
        headerCreated = true;

        // Increment the count of payslips for this type.
        payslipCount++;

        return true;
      }
    }

    // BEGIN, CR00049218, GM
    protected static String stPrimaryAlternateID = CuramConst.gkEmpty;

    protected static String stPrimaryClientAlternateID = CuramConst.gkEmpty;

    protected static String stConcernRoleName = CuramConst.gkEmpty;

    protected static String stRecipientName = CuramConst.gkEmpty;

    protected static String stAddressStr = CuramConst.gkEmpty;

    // END, CR00049218

    protected static PaySlipDetail stClientPaySlipDetail = new PaySlipDetail();

    protected static PaySlipDetail stNomineePaySlipDetail = new PaySlipDetail();

    protected static PaySlipDetail stThirdPartyPaySlipDetail = new PaySlipDetail();

    protected static PaySlipDetail stUtilityPaySlipDetail = new PaySlipDetail();

    protected static PaySlipDetail stParticipantPaySlipDetail = new PaySlipDetail();

    // _________________________________________________________________________
    /**
     * Populates the address string for use in the payslips.
     *
     * @param addressStr The address string to set.
     */
    public static void setAddressString(final String addressStr) {

      stAddressStr = addressStr;
    }

    // _________________________________________________________________________
    /**
     * RetrieveILIDetails read multi operation.
     *
     * @param objDtls Payslip instruction line item details.
     *
     * @return A flag indicating whether the readmulti should continue.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public boolean operation(final Object objDtls) throws AppException,
        InformationalException {

      final ILIPayslipDetails iliPayslipDetails = (ILIPayslipDetails) objDtls;

      // BEGIN, CR00049218, GM
      String name = CuramConst.gkEmpty;

      // END, CR00049218

      if (iliPayslipDetails.recipientTypeCode.equals(PAYSLIPRECIPIENT.RECIPIENT)
        || iliPayslipDetails.recipientTypeCode.equals(
          PAYSLIPRECIPIENT.THIRDPARTY)
          || iliPayslipDetails.recipientTypeCode.equals(
            PAYSLIPRECIPIENT.UTILITY)
            || iliPayslipDetails.recipientTypeCode.equals(
              PAYSLIPRECIPIENT.PARTICIPANT)) {

        // set key to read concernRole entity
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = iliPayslipDetails.concernRoleID;

        // read concernRole entity
        final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
          concernRoleKey);

        stPrimaryAlternateID = concernRoleDtls.primaryAlternateID;
        name = concernRoleDtls.concernRoleName;
      }

      if (iliPayslipDetails.recipientTypeCode.equals(PAYSLIPRECIPIENT.NOMINEE)) {

        final CaseNomineeDetails caseNomineeDetails = getCaseNomineeDetails(
          iliPayslipDetails);

        if (caseNomineeDetails.concernRoleID != 0) {
          stPrimaryAlternateID = caseNomineeDetails.alternateID;
        } else {
          stPrimaryAlternateID = CuramConst.gkStringZero;
        }

        if (iliPayslipDetails.primaryClientID != 0) {

          // set key to read concernRole entity
          final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

          concernRoleKey.concernRoleID = iliPayslipDetails.primaryClientID;

          // read concernRole entity
          final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
            concernRoleKey);

          stPrimaryClientAlternateID = concernRoleDtls.primaryAlternateID;
          name = concernRoleDtls.concernRoleName;

        } else {
          stPrimaryClientAlternateID = CuramConst.gkStringZero;
          name = CuramConst.gkEmpty;
        }
      }

      if (iliPayslipDetails.recipientTypeCode.equals(PAYSLIPRECIPIENT.UTILITY)
        || iliPayslipDetails.recipientTypeCode.equals(
          PAYSLIPRECIPIENT.THIRDPARTY)
          || iliPayslipDetails.recipientTypeCode.equals(
            PAYSLIPRECIPIENT.PARTICIPANT)) {

        if (iliPayslipDetails.primaryClientID != 0) {

          // Set key to read ConcernRole
          final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

          concernRoleKey.concernRoleID = iliPayslipDetails.primaryClientID;

          // Read ConcernRole
          final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
            concernRoleKey);

          stPrimaryClientAlternateID = concernRoleDtls.primaryAlternateID;
          name = concernRoleDtls.concernRoleName;

        } else {

          stPrimaryClientAlternateID = CuramConst.gkStringZero;
          // BEGIN, CR00049218, GM
          name = CuramConst.gkEmpty;
          // END, CR00049218
        }
      }

      if (iliPayslipDetails.recipientTypeCode.equals(PAYSLIPRECIPIENT.NOMINEE)) {

        buildNomineePayslip(iliPayslipDetails, name);

      } else if (iliPayslipDetails.recipientTypeCode.equals(
        PAYSLIPRECIPIENT.THIRDPARTY)) {

        buildThirdPartyPayslip(iliPayslipDetails, name);

      } else if (iliPayslipDetails.recipientTypeCode.equals(
        PAYSLIPRECIPIENT.UTILITY)) {

        buildUtilityPayslip(iliPayslipDetails, name);

      } else if (iliPayslipDetails.recipientTypeCode.equals(
        PAYSLIPRECIPIENT.PARTICIPANT)) {

        buildParticipantPayslip(iliPayslipDetails, name);
      } else {

        buildClientPayslip(iliPayslipDetails);
      }

      // BEGIN, CR00163236, CL
      GeneratePayslips.incrementCommitCount();

      return true;
    }

    // _________________________________________________________________________
    /**
     * This method builds and writes a nominee payslip.
     *
     * @param iliPayslipDetails The payslip details.
     * @param name The name to be included in the payslip.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected void buildNomineePayslip(
      final ILIPayslipDetails iliPayslipDetails, final String name)
      throws AppException, InformationalException {

      final int kStringBufferSize = 4096;
      final StringBuffer dtlID = new StringBuffer(kStringBufferSize);
      final StringBuffer hdrID = new StringBuffer(kStringBufferSize);

      if (stNomineePaySlipDetail.needsHeader()) {

        // Constructing Nominee Header Detail
        hdrID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_NOMINEE_NAME).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.recipientName.trim()).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_NOMINEE_ADDRESS).getMessage()).append(CuramConst.gkColonSpace).append(stAddressStr).append(CuramConst.gkNewLine).append(
          CuramConst.gkNewLine);

        if (!stPrimaryAlternateID.equals(CuramConst.gkStringZero)) {

          hdrID.append(new AppException(BPOGENERATEPAYSLIPS.INF_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryAlternateID).append(
            CuramConst.gkNewLine);
        }

        // Writing Nominee Header Detail
        stNomineePaySlipDetail.strBuff.append(hdrID.toString());
        stNomineePaySlipDetail.strBuff.append(CuramConst.gkNewLine);
        stNomineePaySlipDetail.strBuff.append(CuramConst.gkNewLine);
      }

      // Constructing Nominee Detail Line
      if (stNomineePaySlipDetail.isNewCase(iliPayslipDetails.caseID)) {

        dtlID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CASE_REFERENCE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.caseReference).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PRODUCT).getMessage()).append(CuramConst.gkColonSpace).append(getProductTypeDesc(iliPayslipDetails)).append(CuramConst.gkNewLine).append(
          CuramConst.gkLineSeparator);
      }

      dtlID.append(CuramConst.gkNewLine).append(new AppException(GENERALFINANCE.INF_CLIENT_NAME).getMessage()).append(CuramConst.gkColonSpace).append(name).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryClientAlternateID).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COMPONENT_TYPE).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(ILITYPE.TABLENAME, iliPayslipDetails.instructionLineItemType)).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CURRENCY).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(CURRENCY.TABLENAME, iliPayslipDetails.currencyTypeCode)).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_AMOUNT).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.amount.toString()).append(CuramConst.gkTabDelimiter).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_FROM).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodFrom.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_TO).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodTo.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_EFFECTIVE_DATE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.effectiveDate.toString()).append(
        CuramConst.gkNewLine);

      // Writing Nominee Detail Line
      stNomineePaySlipDetail.strBuff.append(dtlID.toString());
      stNomineePaySlipDetail.strBuff.append(CuramConst.gkNewLine);
    }

    // _________________________________________________________________________
    /**
     * This method builds and writes a third party payslip.
     *
     * @param iliPayslipDetails The payslip details.
     * @param name The name to be included in the payslip.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected void buildThirdPartyPayslip(
      final ILIPayslipDetails iliPayslipDetails, final String name)
      throws AppException, InformationalException {

      final int kStringBufferSize = 4096;
      final StringBuffer dtlID = new StringBuffer(kStringBufferSize);
      final StringBuffer hdrID = new StringBuffer(kStringBufferSize);

      if (stThirdPartyPaySlipDetail.needsHeader()) {

        // Constructing Third Party Header Detail
        hdrID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_THIRD_PARTY_NAME).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.recipientName.trim()).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_THIRD_PARTY_ADDRESS).getMessage()).append(CuramConst.gkColonSpace).append(stAddressStr).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryAlternateID).append(
          CuramConst.gkNewLine);

        // Writing Third Party Header Detail
        stThirdPartyPaySlipDetail.strBuff.append(hdrID.toString());
        stThirdPartyPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
        stThirdPartyPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
      }

      // Constructing Third Party Detail Line
      dtlID.append(CuramConst.gkNewLine).append(new AppException(GENERALFINANCE.INF_CLIENT_NAME).getMessage()).append(CuramConst.gkColonSpace).append(name).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryClientAlternateID).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COMPONENT_TYPE).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(ILITYPE.TABLENAME, iliPayslipDetails.instructionLineItemType)).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CURRENCY).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(CURRENCY.TABLENAME, iliPayslipDetails.currencyTypeCode)).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_AMOUNT).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.amount.toString()).append(CuramConst.gkTabDelimiter).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_FROM).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodFrom.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_TO).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodTo.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_EFFECTIVE_DATE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.effectiveDate.toString()).append(
        CuramConst.gkNewLine);

      // Writing Third Party Detail Line
      stThirdPartyPaySlipDetail.strBuff.append(dtlID.toString());
      stThirdPartyPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
    }

    // _________________________________________________________________________
    /**
     * This method builds and writes a utility payslip.
     *
     * @param iliPayslipDetails The payslip details.
     * @param name The name to be included in the payslip.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected void buildUtilityPayslip(
      final ILIPayslipDetails iliPayslipDetails, final String name)
      throws AppException, InformationalException {

      final int kStringBufferSize = 4096;
      final StringBuffer dtlID = new StringBuffer(kStringBufferSize);
      final StringBuffer hdrID = new StringBuffer(kStringBufferSize);

      if (stUtilityPaySlipDetail.needsHeader()) {

        // Constructing Utility Header Detail
        hdrID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_UTILITY_NAME).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.recipientName.trim()).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_UTILITY_ADDRESS).getMessage()).append(CuramConst.gkColonSpace).append(stAddressStr).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryAlternateID).append(
          CuramConst.gkNewLine);

        // Writing Utility Header Detail
        stUtilityPaySlipDetail.strBuff.append(hdrID.toString());
        stUtilityPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
        stUtilityPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
      }

      final CaseDeductionItemDtls budgetDtls = getDeductionDetails(
        iliPayslipDetails);

      // Constructing Utility Detail Line
      dtlID.append(CuramConst.gkNewLine).append(new AppException(GENERALFINANCE.INF_CLIENT_NAME).getMessage()).append(CuramConst.gkColonSpace).append(name).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryClientAlternateID).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CUSTOMER_ACC_NAME).getMessage()).append(CuramConst.gkColonSpace).append(budgetDtls.customerAccName).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CUSTOMER_ACC_NUMBER).getMessage()).append(CuramConst.gkColonSpace).append(budgetDtls.customerAccNumber).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COMPONENT_TYPE).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(ILITYPE.TABLENAME, iliPayslipDetails.instructionLineItemType)).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_AMOUNT).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.amount.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CURRENCY).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(CURRENCY.TABLENAME, iliPayslipDetails.currencyTypeCode)).append(CuramConst.gkTabDelimiter).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_FROM).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodFrom.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_TO).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodTo.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_EFFECTIVE_DATE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.effectiveDate.toString()).append(
        CuramConst.gkNewLine);

      // Writing Utility Detail Line
      stUtilityPaySlipDetail.strBuff.append(dtlID.toString());
      stUtilityPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
    }

    // _________________________________________________________________________
    /**
     * This method builds and writes a participant payslip.
     *
     * @param iliPayslipDetails The payslip details.
     * @param name The name to be included in the payslip.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected void buildParticipantPayslip(
      final ILIPayslipDetails iliPayslipDetails, final String name)
      throws AppException, InformationalException {

      final int kStringBufferSize = 4096;
      final StringBuffer dtlID = new StringBuffer(kStringBufferSize);
      final StringBuffer hdrID = new StringBuffer(kStringBufferSize);

      if (stParticipantPaySlipDetail.needsHeader()) {

        // Constructing Participant Header Detail
        hdrID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PARTICIPANT_NAME).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.recipientName.trim()).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PARTICIPANT_ADDRESS).getMessage()).append(CuramConst.gkColonSpace).append(stAddressStr).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryAlternateID).append(
          CuramConst.gkNewLine);

        // Writing Participant Header Detail
        stParticipantPaySlipDetail.strBuff.append(hdrID.toString());
        stParticipantPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
        stParticipantPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
      }

      final CaseDeductionItemDtls budgetDtls = getDeductionDetails(
        iliPayslipDetails);

      // Constructing Participant Detail Line
      dtlID.append(CuramConst.gkNewLine).append(new AppException(GENERALFINANCE.INF_CLIENT_NAME).getMessage()).append(CuramConst.gkColonSpace).append(name).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryClientAlternateID).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CUSTOMER_ACC_NAME).getMessage()).append(CuramConst.gkColonSpace).append(budgetDtls.customerAccName).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CUSTOMER_ACC_NUMBER).getMessage()).append(CuramConst.gkColonSpace).append(budgetDtls.customerAccNumber).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COMPONENT_TYPE).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(ILITYPE.TABLENAME, iliPayslipDetails.instructionLineItemType)).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_AMOUNT).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.amount.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CURRENCY).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(CURRENCY.TABLENAME, iliPayslipDetails.currencyTypeCode)).append(CuramConst.gkTabDelimiter).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_FROM).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodFrom.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_TO).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodTo.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_EFFECTIVE_DATE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.effectiveDate.toString()).append(
        CuramConst.gkNewLine);

      // Writing Participant Detail Line
      stParticipantPaySlipDetail.strBuff.append(dtlID.toString());
      stParticipantPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
    }

    // _________________________________________________________________________
    /**
     * This method returns the details of the case deduction item associated
     * with the payslip.
     *
     * @param iliPayslipDetails The payslip details.
     *
     * @return The case deduction item details.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected CaseDeductionItemDtls getDeductionDetails(
      final ILIPayslipDetails iliPayslipDetails) throws AppException,
        InformationalException {

      // BEGIN, CR00165445, KH
      final CaseDeductionItemFinCompID fcID = new CaseDeductionItemFinCompID();

      fcID.financialCompID = iliPayslipDetails.financialComponentID;

      CaseDeductionItemDtls budgetDtls = new CaseDeductionItemDtls();

      try {
        budgetDtls = CaseDeductionItemFactory.newInstance().readByFinancialCompID(
          fcID);
      } catch (final RecordNotFoundException rnfe) {// If we cannot find the
        // case
        // deduction item, we must be
        // processing a migrated deduction ILI. In this case we won't be
        // able to obtain the third party name and account number.
      }
      // END, CR00165445

      return budgetDtls;
    }

    // _________________________________________________________________________
    /**
     * This method builds and writes a client payslip.
     *
     * @param iliPayslipDetails The payslip details.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected void buildClientPayslip(
      final ILIPayslipDetails iliPayslipDetails) throws AppException,
        InformationalException {

      final int kStringBufferSize = 4096;
      final StringBuffer dtlID = new StringBuffer(kStringBufferSize);
      final StringBuffer hdrID = new StringBuffer(kStringBufferSize);

      if (stClientPaySlipDetail.needsHeader()) {

        // Constructing Client Header Detail
        hdrID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(GENERALFINANCE.INF_CLIENT_NAME).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.recipientName.trim()).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_ADDRESS).getMessage()).append(CuramConst.gkColonSpace).append(stAddressStr).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PRIMARY_ALT_ID).getMessage()).append(CuramConst.gkColonSpace).append(stPrimaryAlternateID).append(
          CuramConst.gkNewLine);

        // Writing Client Header Detail
        stClientPaySlipDetail.strBuff.append(hdrID.toString());
        stClientPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
        stClientPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
      }

      // Constructing Client Detail Line
      if (stClientPaySlipDetail.isNewCase(iliPayslipDetails.caseID)) {

        dtlID.append(CuramConst.gkLineSeparator).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CASE_REFERENCE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.caseReference).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PRODUCT).getMessage()).append(CuramConst.gkColonSpace).append(getProductTypeDesc(iliPayslipDetails)).append(CuramConst.gkNewLine).append(
          CuramConst.gkLineSeparator);
      }

      dtlID.append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_NOMINEE_NAME).getMessage()).append(CuramConst.gkColonSpace).append(getCaseNomineeDetails(iliPayslipDetails).concernRoleName).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COMPONENT_TYPE).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(ILITYPE.TABLENAME, iliPayslipDetails.instructionLineItemType)).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_CURRENCY).getMessage()).append(CuramConst.gkColonSpace).append(CodeTable.getOneItem(CURRENCY.TABLENAME, iliPayslipDetails.currencyTypeCode)).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_AMOUNT).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.amount.toString()).append(CuramConst.gkTabDelimiter).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_FROM).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodFrom.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(BPOGENERATEPAYSLIPS.INF_COVER_PERIOD_TO).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.coverPeriodTo.toString()).append(CuramConst.gkTabDelimiter).append(new AppException(GENERALFINANCE.INF_EFFECTIVE_DATE).getMessage()).append(CuramConst.gkColonSpace).append(iliPayslipDetails.effectiveDate.toString()).append(
        CuramConst.gkNewLine);

      // Writing Client Detail Line
      stClientPaySlipDetail.strBuff.append(dtlID.toString());
      stClientPaySlipDetail.strBuff.append(CuramConst.gkNewLine);
    }

    // _________________________________________________________________________
    /**
     * This method returns the case nominee details or an empty struct if a
     * nominee is not associated with the specified payslip.
     *
     * @param iliPayslipDetails The payslip details.
     *
     * @return The case nominee details.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected CaseNomineeDetails getCaseNomineeDetails(
      final ILIPayslipDetails iliPayslipDetails) throws AppException,
        InformationalException {

      CaseNomineeDetails caseNomineeDetails = new CaseNomineeDetails();

      if (iliPayslipDetails.caseNomineeID != 0) {

        // set key to read caseNominee
        final CaseNomineeViewKey caseNomineeViewKey = new CaseNomineeViewKey();

        caseNomineeViewKey.caseNomineeID = iliPayslipDetails.caseNomineeID;

        // read nomineeCaseLink entity
        caseNomineeDetails = CaseNomineeFactory.newInstance().readCaseNomineeDetails(
          caseNomineeViewKey);
      }

      return caseNomineeDetails;
    }

    // _________________________________________________________________________
    /**
     * This method returns the code table description of the product being
     * delivered or an empty string if the specified payslip is not associated
     * with a product delivery case.
     *
     * @param iliPayslipDetails The payslip details.
     *
     * @return The code table description of the product, or an empty string if
     * this payslip is not associated with a product delivery case.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    protected String getProductTypeDesc(
      final ILIPayslipDetails iliPayslipDetails) throws AppException,
        InformationalException {

      String productTypeDesc = CuramConst.gkEmpty;

      if (iliPayslipDetails.caseID != 0) {

        // set key to read productDelivery entity
        final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

        productDeliveryKey.caseID = iliPayslipDetails.caseID;

        // read productDelivery entity
        final ProductDeliveryDtls productDeliveryDtls = ProductDeliveryFactory.newInstance().read(
          productDeliveryKey);

        // Converting codes /types to descriptions
        productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
          productDeliveryDtls.productType);
      }

      return productTypeDesc;
    }

    // _________________________________________________________________________
    /**
     * This method is used to reset the string buffers.
     */
    protected static void resetBuffers() {

      // setLength(0) will result in a new buffer with initial capacity of 16.
      // So we'll use new instead.
      stClientPaySlipDetail.reset();
      stNomineePaySlipDetail.reset();
      stThirdPartyPaySlipDetail.reset();
      stUtilityPaySlipDetail.reset();
      stParticipantPaySlipDetail.reset();
    }

    // _________________________________________________________________________
    /**
     * Returns the a copy of the current value of the nominee details.
     *
     * @return the result of the getMessage() call.
     */
    public static String getClientDetailsAsString() {

      return stClientPaySlipDetail.strBuff.toString();
    }

    // _________________________________________________________________________
    /**
     * Returns the a copy of the current value of the nominee details.
     *
     * @return the result of the getMessage() call.
     */
    public static String getNomineeDetailsAsString() {

      return stNomineePaySlipDetail.strBuff.toString();
    }

    // _________________________________________________________________________
    /**
     * Returns the a copy of the current value of the third party details.
     *
     * @return the result of the toString() call.
     */
    public static String getThirdPartyDetailsAsString() {

      return stThirdPartyPaySlipDetail.strBuff.toString();
    }

    // _________________________________________________________________________
    /**
     * Returns the a copy of the current value of the utility details.
     *
     * @return the result of the getMessage() call.
     */
    public static String getUtilityDetailsAsString() {

      return stUtilityPaySlipDetail.strBuff.toString();
    }

    // _________________________________________________________________________
    /**
     * Returns the a copy of the current value of the participant details.
     *
     * @return the result of the getMessage() call.
     */
    public static String getParticipantDetailsAsString() {

      return stParticipantPaySlipDetail.strBuff.toString();
    }

    // _________________________________________________________________________
    /**
     * pre() operation for the RetrieveILIDetails read multi operation. This is
     * called directly before the main operation. This method initializes flags
     * to indicate that the pay slip header(s) have been created to FALSE.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public void pre() throws AppException, InformationalException {

      stNomineePaySlipDetail.headerCreated = false;
      stClientPaySlipDetail.headerCreated = false;
      stThirdPartyPaySlipDetail.headerCreated = false;
      stUtilityPaySlipDetail.headerCreated = false;
      stParticipantPaySlipDetail.headerCreated = false;
    }

    // _________________________________________________________________________
    /**
     * post() operation for the RetrieveILIDetails read multi operation.This is
     * called directly after the main operation. This method reinitializes
     * global variables.
     *
     * @throws AppException Generic Exception Signature.
     * @throws InformationalException Generic Exception Signature.
     */
    @Override
    public void post() throws AppException, InformationalException {

      // reinitialize global variables

      // BEGIN, CR00049218, GM
      stRecipientName = CuramConst.gkEmpty;
      stAddressStr = CuramConst.gkEmpty;
      stPrimaryAlternateID = CuramConst.gkEmpty;
      stPrimaryClientAlternateID = CuramConst.gkEmpty;
      stConcernRoleName = CuramConst.gkEmpty;
      // END, CR00049218
    }
  }

  // __________________________________________________________________________
  /**
   * Given a pay slip details object this method will return extract lines for
   * writing to a file.
   *
   * @param payslipDtls Details of the pay slip for which a line is
   * to be extracted.
   *
   * @return The extract lines to be written to the output file.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public PayslipDetailsExtractLines extractDetails(
    final PayslipDtls payslipDtls) throws AppException,
      InformationalException {

    final PayslipDetailsExtractLines payslipDetailsExtractLines = new PayslipDetailsExtractLines();

    RetrieveILIDetails.resetBuffers();

    // Indicates whether the payslip has been processed
    boolean processPayslip = true;

    final PIPslipInstructionID piPslipInstructionID = new PIPslipInstructionID();

    piPslipInstructionID.pslipInstructionID = payslipDtls.paySlipInstructionID;

    try {
      final PmtReconcilStatusCodeStruct pmtReconcilStatusCodeStruct = PaymentInstrumentFactory.newInstance().readReconcilStatusByPslipInstructionID(
        piPslipInstructionID);

      // Check to see if the payment instrument has a status of 'Processed'
      // If it doesn't, then no payslip should be processed for it
      if (!pmtReconcilStatusCodeStruct.reconcilStatusCode.equals(
        PMTRECONCILIATIONSTATUS.PROCESSED)) {

        processPayslip = false;
      }

    } catch (final RecordNotFoundException e) {// Ignore exception. This means
      // that
      // the instrument is a Liability -
      // instruments of this type are always processed
    }

    if (processPayslip) {

      // Read address entity
      final Address addressObj = AddressFactory.newInstance();

      final AddressKey addressKey = new AddressKey();

      addressKey.addressID = payslipDtls.addressID;

      final AddressDtls addressDtls = addressObj.read(addressKey);

      final OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = addressDtls.addressData;

      addressObj.getOneLineAddressString(otherAddressData);

      RetrieveILIDetails.setAddressString(otherAddressData.addressData);

      // Update status and issue date on payslip
      final PayslipKey payslipKey = new PayslipKey();

      payslipKey.payslipID = payslipDtls.payslipID;

      final PSStatusCodeIssueDate psStatusCodeIssueDate = new PSStatusCodeIssueDate();

      psStatusCodeIssueDate.statusCode = PAYSLIPINSTRUCTIONSTATUS.ISSUE;
      psStatusCodeIssueDate.issueDate = TransactionInfo.getSystemDate();
      psStatusCodeIssueDate.versionNo = payslipDtls.versionNo;

      PayslipFactory.newInstance().modifyStatusCodeIssueDate(payslipKey,
        psStatusCodeIssueDate);

      // Update status on the payslip instruction
      final PayslipInstructionKey psiKey = new PayslipInstructionKey();

      psiKey.pslipInstructionID = payslipDtls.paySlipInstructionID;

      final PSIStatusCode psiStatusCode = new PSIStatusCode();

      psiStatusCode.versionNo = PayslipInstructionFactory.newInstance().read(psiKey).versionNo;
      psiStatusCode.statusCode = PAYSLIPINSTRUCTIONSTATUS.ISSUE;

      PayslipInstructionFactory.newInstance().modifyStatusCode(psiKey,
        psiStatusCode);

      // Retrieve the pay slip details from the InstructionLineItem using
      // the RetrieveILIDetails read multi operation
      final ILIPayslipInstructionID iliPayslipInstructionID = new ILIPayslipInstructionID();

      iliPayslipInstructionID.payslipInstructionID = payslipDtls.paySlipInstructionID;

      // Instance of read multi operation
      final RetrieveILIDetails retrieveILIDetails = new RetrieveILIDetails();

      // Calling read multi operation
      InstructionLineItemFactory.newInstance().searchByPayslipInstructionID(
        iliPayslipInstructionID, retrieveILIDetails);

      payslipDetailsExtractLines.clientDetails = RetrieveILIDetails.getClientDetailsAsString();
      payslipDetailsExtractLines.nomineeDetails = RetrieveILIDetails.getNomineeDetailsAsString();
      payslipDetailsExtractLines.utilityDetails = RetrieveILIDetails.getUtilityDetailsAsString();
      payslipDetailsExtractLines.thirdPartyDetails = RetrieveILIDetails.getThirdPartyDetailsAsString();
      payslipDetailsExtractLines.participantDetails = RetrieveILIDetails.getParticipantDetailsAsString();
    }

    return payslipDetailsExtractLines;
  }

  // __________________________________________________________________________
  /**
   * Returns the individual number of payslip records processed for each
   * pay slip type.
   *
   * @return pay slip counters for each pay slip type.
   */
  @Override
  public ProcessedPaySlipCounters getProcessedPaySlipCounters() {

    final ProcessedPaySlipCounters processedPaySlipCounters = new ProcessedPaySlipCounters();

    processedPaySlipCounters.utilityCount = RetrieveILIDetails.stUtilityPaySlipDetail.payslipCount;
    processedPaySlipCounters.thirdPartyCount = RetrieveILIDetails.stThirdPartyPaySlipDetail.payslipCount;
    processedPaySlipCounters.clientCount = RetrieveILIDetails.stClientPaySlipDetail.payslipCount;
    processedPaySlipCounters.nomineeCount = RetrieveILIDetails.stNomineePaySlipDetail.payslipCount;
    processedPaySlipCounters.participantCount = RetrieveILIDetails.stParticipantPaySlipDetail.payslipCount;
    return processedPaySlipCounters;
  }

}
