/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2015. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2004, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.GetLatestReassessmentDatesDetails;
import curam.core.struct.GetLatestReassessmentDatesKey;
import curam.core.struct.GetOverUnderPaymentDetailsByNomineeKey;
import curam.core.struct.GetOverUnderPaymentsKey;
import curam.core.struct.GetReassessmentPeriodsKey;
import curam.core.struct.GetReassessmentPeriodsResult;
import curam.core.struct.OverUnderPaymentHeaderDateDetails;
import curam.core.struct.ReadmultiByNomineeOverUnderPaymentIDKey;
import curam.core.struct.ReassessmentAmountInfoDtlsList;
import curam.core.struct.ReassessmentAmountInformationKey;
import curam.core.struct.ReassessmentInfoDtls;
import curam.core.struct.ReassessmentInfoDtlsList;
import curam.core.struct.ViewOverUnderPaymentResultDetails;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * code to get overpayment or underpayment result.
 */
public abstract class GetOverUnderPaymentResult extends curam.core.base.GetOverUnderPaymentResult {

  protected static final String kDataStart = ViewOverUnderPaymentResult.kDataStart;

  protected static final String kDataEnd = ViewOverUnderPaymentResult.kDataEnd;

  protected static final String kRowStart = ViewOverUnderPaymentResult.kRowStart;

  protected static final String kRowEnd = ViewOverUnderPaymentResult.kRowEnd;

  // ____________________________________________________________________________
  /**
   * Description:
   * Returns the from and to dates of the cover period the latest reassessment
   * on a case effects
   *
   * @param key contains the caseID
   *
   * @return the output including from and to dates
   */
  @Override
  public GetLatestReassessmentDatesDetails getLatestReassessmentCoverPeriod(
    GetLatestReassessmentDatesKey key) throws AppException,
      InformationalException {

    final GetLatestReassessmentDatesDetails dtls = new GetLatestReassessmentDatesDetails();

    // OverUnderPaymentHeader entity, key, and dtls.
    final curam.core.intf.OverUnderPaymentHeader overUnderPaymentHdrObj = curam.core.fact.OverUnderPaymentHeaderFactory.newInstance();
    final GetOverUnderPaymentsKey getOverUnderPaymentsKey = new GetOverUnderPaymentsKey();

    OverUnderPaymentHeaderDateDetails overUnderPaymentHdrDtls;

    // Assign the key - caseID
    getOverUnderPaymentsKey.caseID = key.caseID;

    overUnderPaymentHdrDtls = overUnderPaymentHdrObj.getLatestReassessmentCoverPeriodFrom(
      getOverUnderPaymentsKey);

    // Map to output structure fromDate
    dtls.fromDate = overUnderPaymentHdrDtls.date;

    getOverUnderPaymentsKey.caseID = key.caseID;

    // Clear the structure before reusing the output
    overUnderPaymentHdrDtls.date = curam.util.type.Date.kZeroDate;

    overUnderPaymentHdrDtls = overUnderPaymentHdrObj.getLatestReassessmentCoverPeriodTo(
      getOverUnderPaymentsKey);

    // Map to output structure fromDate
    dtls.toDate = overUnderPaymentHdrDtls.date;

    return dtls;
  }

  // ___________________________________________________________________________
  /**
   * Description:
   * Returns over/under payment information for Normal Reassessment in
   * a tabbed delimited string
   *
   * @param key contains the caseID and nomineeOverUnderPaymentID
   *
   * @return contains the output tabbed delimited text string
   */
  @Override
  public ViewOverUnderPaymentResultDetails getReassessmentResults(
    GetOverUnderPaymentDetailsByNomineeKey key) throws AppException,
      InformationalException {

    final ViewOverUnderPaymentResultDetails dtls = new ViewOverUnderPaymentResultDetails();

    // Entity and structures for reassessment info.
    final curam.core.intf.ReassessmentInfo reassessmentInfoObj = curam.core.fact.ReassessmentInfoFactory.newInstance();

    ReassessmentInfoDtlsList reassessInfoDtlsList;

    final ReadmultiByNomineeOverUnderPaymentIDKey readmultiByNomineeOverUnderPaymentIDKey = new ReadmultiByNomineeOverUnderPaymentIDKey();

    String eventTypeDescription;

    final ReassessmentAmountInformationKey reassessAmountInfoKey = new ReassessmentAmountInformationKey();

    ReassessmentAmountInfoDtlsList reassessAmountDtlsList;

    // Reassessment amount info entity.
    final curam.core.intf.ReassessmentAmountInfo reassessAmountInfoObj = curam.core.fact.ReassessmentAmountInfoFactory.newInstance();

    // Deduction sums
    double totalGrossAmount = 0;
    double totalTaxDeduction = 0;
    double totalUtilityDeduction = 0;
    double totalLiabilityDeduction = 0;
    double totalNetAmount = 0;

    // The format of the tab string is:
    // DATA_START, numberOfRows, ROW_START, reassessmentInfoID, fromDate,
    // toDate, numberOfItems (on the row), amountType, amount, amount,
    // amount, ROW_END
    // totalGrossAmount, totalTaxDeduction, totalUtilityDeduction,
    // totalLiabilityDeduction, totalNetAmount, DATA_END

    /*
     * curam.core.intf.FormatDate formatDateObj =
     * curam.core.fact.FormatDateFactory.newInstance();
     */

    // BEGIN, CR00070542, "PA"
    /*
     * FormatDateAsStringKey formatDateAsStringKey = new
     * FormatDateAsStringKey();
     *
     * FormatDateAsStringDtls formatDateAsStringDtls;
     */
    // END, CR00070542

    final StringBuffer resultText = new StringBuffer();

    resultText.append(kDataStart);
    resultText.append(CuramConst.gkTabDelimiter);

    // Need to retrieve the reassessment periods
    final GetReassessmentPeriodsKey getReassessmentPeriodsKey = new GetReassessmentPeriodsKey();

    // Set key to call local business layer operation
    getReassessmentPeriodsKey.nomineeOverUnderPaymentID = key.nomineeOverUnderPaymentID;

    // Get latest details by nominee
    reassessInfoDtlsList = reassessmentInfoObj.searchByNomineeOverUnderPaymentID(
      readmultiByNomineeOverUnderPaymentIDKey);

    // Retrieve reassessment periods
    reassessInfoDtlsList = getReassessmentPeriods(getReassessmentPeriodsKey).dtlsList;

    // add the number of rows
    resultText.append(String.valueOf(reassessInfoDtlsList.dtls.size()));
    resultText.append(CuramConst.gkTabDelimiter);

    for (int i = 0; i < reassessInfoDtlsList.dtls.size(); i++) {

      resultText.append(kRowStart);
      resultText.append(CuramConst.gkTabDelimiter);

      resultText.append(
        String.valueOf(reassessInfoDtlsList.dtls.item(i).reassessmentInfoID));
      resultText.append(CuramConst.gkTabDelimiter);

      // BEGIN, CR00086110, POB
      resultText.append(reassessInfoDtlsList.dtls.item(i).fromDate.toString());
      resultText.append(CuramConst.gkTabDelimiter);

      resultText.append(reassessInfoDtlsList.dtls.item(i).toDate.toString());
      resultText.append(CuramConst.gkTabDelimiter);
      // END< CR00086110

      // Set the key for reassess amount info readmulti
      reassessAmountInfoKey.reassessmentInfoID = reassessInfoDtlsList.dtls.item(i).reassessmentInfoID;

      reassessAmountDtlsList = reassessAmountInfoObj.searchByReassessInfoID(
        reassessAmountInfoKey);

      // Add "number of items" field for each row.
      resultText.append(String.valueOf(reassessAmountDtlsList.dtls.size()));
      resultText.append(CuramConst.gkTabDelimiter);

      for (int j = 0; j < reassessAmountDtlsList.dtls.size(); j++) {

        eventTypeDescription = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          curam.codetable.REASSESSMENT_AMOUNT.TABLENAME,
          reassessAmountDtlsList.dtls.item(j).amountType,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        resultText.append(eventTypeDescription);
        resultText.append(CuramConst.gkTabDelimiter);

        final double actualAmount = reassessAmountDtlsList.dtls.item(j).actualAmount.getValue();
        final double reassessedAmount = reassessAmountDtlsList.dtls.item(j).reassessedAmount.getValue();

        resultText.append(Double.toString(actualAmount));
        resultText.append(CuramConst.gkTabDelimiter);
        resultText.append(Double.toString(reassessedAmount));
        resultText.append(CuramConst.gkTabDelimiter);

        final double deduction = reassessedAmount - actualAmount;

        resultText.append(Double.toString(deduction));
        resultText.append(CuramConst.gkTabDelimiter);

        final String amountType = reassessAmountDtlsList.dtls.item(j).amountType;

        if (curam.codetable.REASSESSMENT_AMOUNT.GROSS.equals(amountType)) {

          totalGrossAmount = totalGrossAmount + deduction;

        } else if (curam.codetable.REASSESSMENT_AMOUNT.TAX.equals(amountType)) {

          totalTaxDeduction = totalTaxDeduction + deduction;

        } else if (curam.codetable.REASSESSMENT_AMOUNT.UTILITY.equals(
          amountType)) {

          totalUtilityDeduction = totalUtilityDeduction + deduction;

        } else if (curam.codetable.REASSESSMENT_AMOUNT.LIABILITY.equals(
          amountType)
            || curam.codetable.REASSESSMENT_AMOUNT.DEDUCTION.equals(amountType)) {

          totalLiabilityDeduction = totalLiabilityDeduction + deduction;

        } else if (curam.codetable.REASSESSMENT_AMOUNT.NET.equals(amountType)) {

          totalNetAmount = totalNetAmount + deduction;

        }

      }

      resultText.append(kRowEnd);
      resultText.append(CuramConst.gkTabDelimiter);
    }

    resultText.append(Double.toString(totalGrossAmount));
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(Double.toString(totalTaxDeduction));
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(Double.toString(totalUtilityDeduction));
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(Double.toString(totalLiabilityDeduction));
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(Double.toString(totalNetAmount));
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(kDataEnd);
    dtls.benefitReassessmentText = resultText.toString();

    return dtls;
  }

  // ___________________________________________________________________________
  /**
   * Description:
   * Returns over/under payment information for Liability Reconciliation in
   * a tabbed delimited string
   *
   * @param key contains the caseID and nomineeOverUnderPaymentID
   *
   * @return contains the output tabbed delimited text string
   */
  @Override
  public ViewOverUnderPaymentResultDetails getReconciliationResults(
    GetOverUnderPaymentDetailsByNomineeKey key) throws AppException,
      InformationalException {

    final ViewOverUnderPaymentResultDetails dtls = new ViewOverUnderPaymentResultDetails();

    // Reassessment amount entity and structures
    final curam.core.intf.ReassessmentInfo reassessmentInfoObj = curam.core.fact.ReassessmentInfoFactory.newInstance();
    final ReadmultiByNomineeOverUnderPaymentIDKey readmultiByNomineeOverUnderPaymentIDKey = new ReadmultiByNomineeOverUnderPaymentIDKey();

    ReassessmentInfoDtlsList reassessmentInfoDtlsList;

    // Reassessment amount info entity, key and list
    final curam.core.intf.ReassessmentAmountInfo reassessmentAmountInfo = curam.core.fact.ReassessmentAmountInfoFactory.newInstance();
    final ReassessmentAmountInformationKey reassessmentAmountInformationKey = new ReassessmentAmountInformationKey();

    ReassessmentAmountInfoDtlsList reassessmentAmountInfoDtlsList;

    // Set the key of query by nomineeOverUnderPaymentID
    readmultiByNomineeOverUnderPaymentIDKey.nomineeOverUnderPaymentID = key.nomineeOverUnderPaymentID;

    // Readmulti by nominee
    reassessmentInfoDtlsList = reassessmentInfoObj.searchByNomineeOverUnderPaymentID(
      readmultiByNomineeOverUnderPaymentIDKey);

    // Totals
    double totalOverUnderPaymentAmount = 0;
    double iterationTotal = 0;
    // BEGIN, CR00070545, "PA"
    /*
     * curam.core.intf.FormatDate formatDateObj =
     * curam.core.fact.FormatDateFactory.newInstance();
     * FormatDateAsStringKey formatDateAsStringKey = new
     * FormatDateAsStringKey();
     *
     * FormatDateAsStringDtls formatDateAsStringDtls;
     */

    final StringBuffer resultText = new StringBuffer();

    // Start forming output string
    resultText.append(kDataStart);
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(String.valueOf(reassessmentInfoDtlsList.dtls.size()));
    resultText.append(CuramConst.gkTabDelimiter);

    // Iterate through all returned reassessment records
    for (int i = 0; i < reassessmentInfoDtlsList.dtls.size(); i++) {

      resultText.append(kRowStart);
      resultText.append(CuramConst.gkTabDelimiter);

      // insert the reassessment info ID
      resultText.append(
        String.valueOf(reassessmentInfoDtlsList.dtls.item(i).reassessmentInfoID));
      resultText.append(CuramConst.gkTabDelimiter);

      // BEGIN, CR00086110, POB
      resultText.append(
        reassessmentInfoDtlsList.dtls.item(i).fromDate.toString());
      resultText.append(CuramConst.gkTabDelimiter);

      resultText.append(reassessmentInfoDtlsList.dtls.item(i).toDate.toString());
      resultText.append(CuramConst.gkTabDelimiter);
      // END, CR00086110

      // Set the key to each iterated record
      reassessmentAmountInformationKey.reassessmentInfoID = reassessmentInfoDtlsList.dtls.item(i).reassessmentInfoID;

      // Read multi by reassessmentInfoID
      reassessmentAmountInfoDtlsList = reassessmentAmountInfo.searchByReassessInfoID(
        reassessmentAmountInformationKey);

      resultText.append(
        String.valueOf(reassessmentAmountInfoDtlsList.dtls.size()));
      resultText.append(CuramConst.gkTabDelimiter);

      // Iterate through returned details list
      for (int j = 0; j < reassessmentAmountInfoDtlsList.dtls.size(); j++) {

        String eventTypeDescription;

        eventTypeDescription = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          curam.codetable.REASSESSMENT_AMOUNT.TABLENAME,
          reassessmentAmountInfoDtlsList.dtls.item(j).amountType,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        resultText.append(eventTypeDescription);
        resultText.append(CuramConst.gkTabDelimiter);

        final double actualAmount = reassessmentAmountInfoDtlsList.dtls.item(j).actualAmount.getValue();
        final double reassessedAmount = reassessmentAmountInfoDtlsList.dtls.item(j).reassessedAmount.getValue();
        final double receivedAmount = reassessmentAmountInfoDtlsList.dtls.item(j).receivedAmount.getValue();

        resultText.append(Double.toString(actualAmount));
        resultText.append(CuramConst.gkTabDelimiter);
        resultText.append(Double.toString(reassessedAmount));
        resultText.append(CuramConst.gkTabDelimiter);
        resultText.append(Double.toString(receivedAmount));
        resultText.append(CuramConst.gkTabDelimiter);

        iterationTotal = reassessmentAmountInfoDtlsList.dtls.item(j).actualAmount.getValue()
          - (reassessmentAmountInfoDtlsList.dtls.item(j).reassessedAmount.getValue()
            - reassessmentAmountInfoDtlsList.dtls.item(j).receivedAmount.getValue());

        resultText.append(Double.toString(iterationTotal));
        resultText.append(CuramConst.gkTabDelimiter);

        // Sum up differences
        if (!reassessmentAmountInfoDtlsList.dtls.item(j).amountType.equals(
          curam.codetable.REASSESSMENT_AMOUNT.TOTALBILL)) {

          totalOverUnderPaymentAmount = totalOverUnderPaymentAmount
            + iterationTotal;
        }

      }

      resultText.append(kRowEnd);
      resultText.append(CuramConst.gkTabDelimiter);

    }

    resultText.append(Double.toString(totalOverUnderPaymentAmount));
    resultText.append(CuramConst.gkTabDelimiter);

    resultText.append(kDataEnd);

    dtls.liabilityReassessmentText = resultText.toString();

    return dtls;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the reassessment periods for a specified reassessment
   *
   * @param key Key to retrieve the reassessment periods
   *
   * @return The reassessment periods
   */
  @Override
  public GetReassessmentPeriodsResult getReassessmentPeriods(
    GetReassessmentPeriodsKey key) throws AppException,
      InformationalException {

    // Create return object
    final GetReassessmentPeriodsResult getReassessmentPeriodsResult = new GetReassessmentPeriodsResult();

    ReassessmentInfoDtlsList reassessmentInfoDtlsList = new ReassessmentInfoDtlsList();

    final StringBuffer selectBuffer = new StringBuffer();

    selectBuffer.append("SELECT DISTINCT RI.REASSESSMENTINFOID, ");
    selectBuffer.append("RI.NOMINEEOVERUNDERPAYMENTID,");
    selectBuffer.append("RI.FROMDATE, ");
    selectBuffer.append("RI.TODATE, ");
    selectBuffer.append("RI.VERSIONNO ");

    final StringBuffer intoBuffer = new StringBuffer();

    intoBuffer.append("INTO :REASSESSMENTINFOID, ");
    intoBuffer.append(":NOMINEEOVERUNDERPAYMENTID, ");
    intoBuffer.append(":FROMDATE, ");
    intoBuffer.append(":TODATE, ");
    intoBuffer.append(":VERSIONNO ");

    final StringBuffer fromBuffer = new StringBuffer();

    fromBuffer.append("FROM ");
    fromBuffer.append("REASSESSMENTINFO RI, ");
    fromBuffer.append("REASSESSMENTAMOUNTINFO RAI ");

    final StringBuffer whereBuffer = new StringBuffer();

    whereBuffer.append("WHERE ");
    whereBuffer.append(
      "RI.NOMINEEOVERUNDERPAYMENTID = :nomineeOverUnderPaymentID ");
    whereBuffer.append("AND RAI.REASSESSMENTINFOID = RI.REASSESSMENTINFOID ");
    whereBuffer.append(
      "AND RAI.ACTUALAMOUNT <> RAI.REASSESSEDAMOUNT ORDER BY RI.FROMDATE");

    final StringBuffer finalQuery = new StringBuffer();

    finalQuery.append(selectBuffer);
    finalQuery.append(intoBuffer);
    finalQuery.append(fromBuffer);
    finalQuery.append(whereBuffer);

    // Call dynamic SQL API to execute SQL.
    final CuramValueList<ReassessmentInfoDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      ReassessmentInfoDtls.class, key, false, false, finalQuery.toString());

    reassessmentInfoDtlsList = new ReassessmentInfoDtlsList();
    reassessmentInfoDtlsList.dtls.addAll(curamValueList);

    // Assign list to return object
    getReassessmentPeriodsResult.dtlsList = reassessmentInfoDtlsList;

    return getReassessmentPeriodsResult;
  }

}
