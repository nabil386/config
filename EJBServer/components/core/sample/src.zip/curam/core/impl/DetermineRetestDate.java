/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CaseDetailsForDateDeterminationDtls;
import curam.core.struct.DetermineRetestDateKey;
import curam.core.struct.DetermineRetestDateResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to determine the next retest date for a given Case.
 *
 */
public abstract class DetermineRetestDate extends curam.core.base.DetermineRetestDate {

  // ___________________________________________________________________________
  /**
   * This method determines the next date on which the Rules Engine should be
   * called, based on an input date and the Re-rate Frequency for the Product.
   *
   * @param determineRetestDateKey Input date
   * @param caseDetailsForDateDeterminationDtls Case details
   *
   * @return The next retest date
   */
  @Override
  public DetermineRetestDateResult determineNextRetestDate(
    DetermineRetestDateKey determineRetestDateKey,
    CaseDetailsForDateDeterminationDtls caseDetailsForDateDeterminationDtls)
    throws AppException, InformationalException {

    // determineRetestDateResult variable
    final DetermineRetestDateResult determineRetestDateResult = new DetermineRetestDateResult();

    // re-rate frequency pattern
    final String reratePattern = caseDetailsForDateDeterminationDtls.reratePattern;

    // calculate date based on pattern
    determineRetestDateResult.retestDate = new curam.util.type.FrequencyPattern(reratePattern).getNextOccurrence(
      determineRetestDateKey.dateOfCalculation);

    return determineRetestDateResult;
  }

}
