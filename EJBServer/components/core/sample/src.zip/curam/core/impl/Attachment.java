/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.DOCUMENTTYPE;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.codetable.impl.CMSMETADATACLASSTYPEEntry;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseAttachmentDetails;
import curam.core.struct.ReadCaseAttachmentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Blob;
import curam.util.type.CodeTable;


/**
 * A file that can be associated with a communication or a case. An attachment
 * is stored as a binary large object (BLOB) in the database. Any file format
 * can be stored as an attachment. Many types of Curam entities can have a
 * related attachment; logically these entities have an 'attachment' attribute
 * which is a 'complex data type'. Physically however each of these entities has
 * an attachment attribute which relates to a row on the attachment table.
 */
public abstract class Attachment extends curam.core.base.Attachment {

  @Inject
  private CMISAccessInterface cmisAccess;

  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00354960

  protected Attachment() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Override
  protected void postread(curam.core.struct.AttachmentKey key,
    curam.core.struct.AttachmentDtls details) throws AppException,
      InformationalException {

    // BEGIN CR00347000, JAF
    // if CMIS is enabled for attachments and if content exists on the CMS for
    // the record in question, call the CMIS API to fetch the content
    if (cmisAccess.isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.ATTACHMENT)
      && cmisAccess.contentExists(key.attachmentID,
      CMSLINKRELATEDTYPEEntry.ATTACHMENT)) {

      details.attachmentContents = cmisAccess.read(key.attachmentID, CMSLINKRELATEDTYPEEntry.ATTACHMENT).fileContent;
    }
    // END CR00347000, JAF
  }

  @Override
  public void insert(AttachmentDtls details) throws AppException,
      InformationalException {

    if (cmisAccess.isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.ATTACHMENT)
      && details.attachmentContents.length() != 0) {

      // save and blank out the contents which were getting inserted to the DB
      final byte[] attachmentContents = details.attachmentContents.copyBytes();

      details.attachmentContents = new Blob(CuramConst.gkEmpty.getBytes());

      super.insert(details);

      // BEGIN, CR00354960, CD
      // populate meta data
      GuiceWrapper.getInjector().injectMembers(this);
      final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      final String documentTypeDescription = CodeTable.getOneItem(
        DOCUMENTTYPE.TABLENAME, details.documentType);

      if (!documentTypeDescription.isEmpty()) {
        cmsMetadata.add(CMSMetadataConst.kDocumentTypeCode,
          details.documentType);
        cmsMetadata.add(CMSMetadataConst.kDocumentType, documentTypeDescription);
      }
      cmsMetadata.add(CMSMetadataConst.kDocumentReceiptDate,
        details.receiptDate);
      // END, CR00354960

      // BEGIN CR00347000, JAF
      // save the contents to the content management system
      cmisAccess.create(details.attachmentID,
        CMSLINKRELATEDTYPEEntry.ATTACHMENT, attachmentContents,
        details.attachmentName, CMISNAMINGTYPEEntry.ATTACHMENT, null,
        CMSMETADATACLASSTYPEEntry.ATTACHMENT);
      // END CR00347000, JAF

    } else {

      super.insert(details);

    }

  }

  @Override
  public void modify(AttachmentKey key, AttachmentDtls details)
    throws AppException, InformationalException {

    // if enabled, call the CMIS API to fetch the content by it's unique ID
    if (cmisAccess.isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.ATTACHMENT)) {

      // save and blank out the contents which were getting inserted to the DB
      final byte[] attachmentContents = details.attachmentContents.copyBytes();

      details.attachmentContents = new Blob(CuramConst.gkEmpty.getBytes());

      super.modify(key, details);

      // BEGIN, CR00354960, CD
      // populate meta data
      GuiceWrapper.getInjector().injectMembers(this);
      final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      final String documentTypeDescription = CodeTable.getOneItem(
        DOCUMENTTYPE.TABLENAME, details.documentType);

      if (!documentTypeDescription.isEmpty()) {
        cmsMetadata.add(CMSMetadataConst.kDocumentTypeCode,
          details.documentType);
        cmsMetadata.add(CMSMetadataConst.kDocumentType, documentTypeDescription);
      }
      cmsMetadata.add(CMSMetadataConst.kDocumentReceiptDate,
        details.receiptDate);
      // END, CR00354960

      // BEGIN CR00347000, JAF
      // if content exists on the CMS for the record in question
      if (cmisAccess.contentExists(key.attachmentID,
        CMSLINKRELATEDTYPEEntry.ATTACHMENT)
        == true) {
        // modify the contents on the content management system
        // BEGIN CR00347760 JAF
        cmisAccess.modify(key.attachmentID, CMSLINKRELATEDTYPEEntry.ATTACHMENT,
          attachmentContents, details.attachmentName,
          CMSMETADATACLASSTYPEEntry.ATTACHMENT);
        // END CR00347760 JAF

      } else {
        // create the contents on the content management system
        cmisAccess.create(key.attachmentID, CMSLINKRELATEDTYPEEntry.ATTACHMENT,
          attachmentContents, details.attachmentName,
          CMISNAMINGTYPEEntry.ATTACHMENT, null,
          CMSMETADATACLASSTYPEEntry.ATTACHMENT);
      }
      // END CR00347000, JAF
    } else {

      super.modify(key, details);
    }

  }

  @Override
  public CaseAttachmentDetails readCaseAttachment(ReadCaseAttachmentKey key)
    throws AppException, InformationalException {

    final CaseAttachmentDetails details = super.readCaseAttachment(key);

    // BEGIN CR00347000, JAF
    // if CMIS is enabled for attachments and if content exists on the CMS for
    // the record in question, call the CMIS API to fetch the content
    if (cmisAccess.isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.ATTACHMENT)
      && cmisAccess.contentExists(key.attachmentID,
      CMSLINKRELATEDTYPEEntry.ATTACHMENT)) {

      details.attachmentContents = cmisAccess.read(key.attachmentID, CMSLINKRELATEDTYPEEntry.ATTACHMENT).fileContent;
    }
    // END CR00347000, JAF
    return details;
  }

}
