/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASETYPECODE;
import curam.core.intf.CaseRulesAttribution;
import curam.core.sl.entity.struct.AssessmentDeliveryDtls;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.struct.AssessmentRulesLinkByAssessmentConfigAndDateKey;
import curam.core.struct.AssessmentRulesLinkDtls;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.LookupRulesForCaseDetails;
import curam.core.struct.LookupRulesForCaseKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.ProductRulesLinkByProdAndDates;
import curam.core.struct.ProductRulesLinkDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Case rule link manipulation methods
 */
public abstract class CaseRulesLink extends curam.core.base.CaseRulesLink {

  // ___________________________________________________________________________
  /**
   * Method to look up RuleSet ID for the case
   *
   * @param key Identifies case we are interested in
   *
   * @return LookupRulesForCaseDetails - ruleSetID found
   */
  @Override
  public LookupRulesForCaseDetails lookupRulesForCase(
    LookupRulesForCaseKey key) throws AppException, InformationalException {

    final LookupRulesForCaseDetails dtls = new LookupRulesForCaseDetails();

    // Product Rules Link manipulation variables
    final curam.core.intf.CachedProductRulesLink cachedProductRulesLinkObj = curam.core.fact.CachedProductRulesLinkFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode;

    caseKey.caseID = key.caseID;

    // read case type code
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case is an assessment case use the assessment delivery to get the
    // ruleSetID. otherwise use the product delivery.
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

      // call the rules engine to read the rules
      // read in the assessment delivery object
      final curam.core.sl.entity.intf.AssessmentDelivery assessmentDeliveryObj = curam.core.sl.entity.fact.AssessmentDeliveryFactory.newInstance();
      final AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();

      assessmentDeliveryKey.caseID = key.caseID;

      // objects to read the assessment rules link
      final curam.core.intf.AssessmentRulesLink assessmentRulesLinkObj = curam.core.fact.AssessmentRulesLinkFactory.newInstance();

      final AssessmentRulesLinkByAssessmentConfigAndDateKey assessmentRulesLinkByAssessmentConfigAndDateKey = new AssessmentRulesLinkByAssessmentConfigAndDateKey();

      AssessmentRulesLinkDtls assessmentRulesLinkDtls;

      // Read the Assessment Delivery
      final AssessmentDeliveryDtls assessmentDeliveryDtls = assessmentDeliveryObj.read(
        assessmentDeliveryKey);

      assessmentRulesLinkByAssessmentConfigAndDateKey.assessmentConfigurationID = assessmentDeliveryDtls.assessmentConfigurationID;
      assessmentRulesLinkByAssessmentConfigAndDateKey.dateOfCalculation = key.date;
      // BEGIN, CR00100337, VM
      assessmentRulesLinkByAssessmentConfigAndDateKey.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
      // END, CR00100337

      // Get RuleSet ID
      assessmentRulesLinkDtls = assessmentRulesLinkObj.readByAssessmentConfigIDAndDate(
        assessmentRulesLinkByAssessmentConfigAndDateKey);

      dtls.ruleSetID = assessmentRulesLinkDtls.ruleSetID;

    } else {

      final ProductRulesLinkByProdAndDates productRulesLinkByProdAndDates = new ProductRulesLinkByProdAndDates();
      ProductRulesLinkDtls productRulesLinkDtls;

      // Product Delivery manipulation variables
      final curam.core.intf.CachedProductDelivery cachedProductDeliveryObj = curam.core.fact.CachedProductDeliveryFactory.newInstance();
      ProductDeliveryDtls productDeliveryDtls;
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      final curam.core.intf.CachedProduct cachedProductObj = curam.core.fact.CachedProductFactory.newInstance();
      ProductDtls productDtls;
      final ProductKey productKey = new ProductKey();

      // First, read the Product Delivery
      productDeliveryKey.caseID = key.caseID;
      productDeliveryDtls = cachedProductDeliveryObj.read(productDeliveryKey);

      productKey.productID = productDeliveryDtls.productID;
      productDtls = cachedProductObj.read(productKey);

      final ProductHookManager productHookManager = new ProductHookManager();
      final CaseRulesAttribution caseRulesAttributionObj = productHookManager.getCaseRulesAttributionHook(
        productDtls.typeCode);

      // Allow custom code to override the "actual" effective date of the
      // rule set based on the details of the case and the product level
      // date of the rule set.
      key = caseRulesAttributionObj.attributeRules(key);

      // Get RuleSet ID
      productRulesLinkByProdAndDates.productID = productDeliveryDtls.productID;
      productRulesLinkByProdAndDates.dateOfCalculation = key.date;

      productRulesLinkDtls = cachedProductRulesLinkObj.readByProductAndDate(
        productRulesLinkByProdAndDates);

      dtls.ruleSetID = productRulesLinkDtls.ruleSetID;

    }

    return dtls;
  }

}
