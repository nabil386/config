/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2018. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import com.google.inject.Inject;
import curam.codetable.CASESTATUS;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.PRODUCTADMINCATEGORY;
import curam.core.fact.CachedProductFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIdentifier;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.ExclusionDtlsList;
import curam.core.struct.FCcaseIDCategoryStatusDate;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductIDDetails;
import curam.core.struct.ProductKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.message.BPOGENERATELIABILITY;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.KeySet;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.UniqueID;

/**
 * Code to create a liability in a front office environment.
 *
 */
public abstract class GenerateLiability
  extends curam.core.base.GenerateLiability {

  // BEGIN, CR00264219, KH
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;

  // ___________________________________________________________________________
  /**
   * Constructor.
   */
  public GenerateLiability() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00264219

  // ___________________________________________________________________________
  /**
   * To generate a liability online.
   *
   * @param caseIdentifier The case ID used to generate the liability.
   */
  @Override
  public void
    generateInteractiveLiability(final CaseIdentifier caseIdentifier)
      throws AppException, InformationalException {

    // DPEnactmentService variable
    final curam.util.intf.DeferredProcessing dpEnactmentServiceObj =
      curam.util.fact.DeferredProcessingFactory.newInstance();

    // WMInstanceData manipulation variables
    final curam.core.intf.WMInstanceData wmInstanceDataObj =
      curam.core.fact.WMInstanceDataFactory.newInstance();
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    // BEGIN, CR00103023, CW
    // caseHeader manipulation variables
    final curam.core.intf.CachedCaseHeader cachedCaseHeader =
      curam.core.fact.CachedCaseHeaderFactory.newInstance();
    // END, CR00103023
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Security Variables
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();

    // productDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj =
      curam.core.fact.ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductIDDetails productIDDetails;

    // product manipulation variables
    final ProductKey productKey = new ProductKey();

    // financialComponent manipulation variables
    final curam.core.intf.FinancialComponent financialComponentObj =
      curam.core.fact.FinancialComponentFactory.newInstance();
    final FCcaseIDCategoryStatusDate fcCaseIDCategoryStatusDate =
      new FCcaseIDCategoryStatusDate();
    FinancialComponentDtlsList financialComponentDtlsList;

    // caseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj =
      curam.core.fact.CaseStatusFactory.newInstance();
    CaseStatusDtls caseStatusDtls;
    final CaseStatusKey caseStatusKey = new CaseStatusKey();
    final CurrentCaseStatusKey currentCaseStatusKey =
      new CurrentCaseStatusKey();

    // Set key to read caseHeader entity
    caseHeaderKey.caseID = caseIdentifier.caseID;

    // BEGIN, CR00103023, CW
    // Read caseHeader entity from the cache
    // BEGIN, CR00279909, SG
    final CaseHeaderDtls caseHeaderDtls =
      cachedCaseHeader.read(caseHeaderKey);
    // END, CR00279909
    // END, CR00103023

    // BEGIN, CR00102570, CW
    // No financial components should be processed if the case status
    // is suspended and the curam.miscapp.payuptosuspendeddate property
    // is set to NO.
    final Boolean issuePaymentToSuspendDate = Configuration
      .getBooleanProperty(EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE,
        Configuration.getBooleanProperty(
          EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE_DEFAULT));

    // No financial components should be processed if the case status
    // is closed and the curam.miscapp.payuptocloseddate property
    // is set to NO.
    final Boolean issuePaymentToClosedDate = Configuration.getBooleanProperty(
      EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE,
      Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE_DEFAULT));

    // If the property that indicates whether or not a suspended case should
    // be paid up to the suspension date is not true AND the property indicating
    // whether or not a closed case should be paid up to closure date is not
    // true
    // then we only pay active and pending closure cases.

    if (!issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOGENERATELIABILITY.ERR_GENLIABILITY_INVALID_SUSPENDSTATUS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    } else if (issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

      // If the property that indicates whether or not a suspended case should
      // be paid up to the suspension date is true AND the property indicating
      // whether or not a closed case should be paid up to closure date is not
      // true
      // then we only pay active, suspended and pending closure cases.

      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.SUSPENDED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOGENERATELIABILITY.ERR_GENLIABILITY_INVALID_CASESTATUS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    } else if (!issuePaymentToSuspendDate && issuePaymentToClosedDate) {

      // If the property that indicates whether or not a suspended case should
      // be paid up to the suspension date is not true AND the property
      // indicating
      // whether or not a closed case should be paid up to closure date is true
      // then we only pay active, closed and pending closure cases.

      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOGENERATELIABILITY.ERR_GENLIABILITY_INVALID_CLOSEDSTATUS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    } else {

      // If the property that indicates whether or not a suspended case should
      // be paid up to the suspension date is true AND the property indicating
      // whether or not a closed case should be paid up to closure date is true
      // then we only pay active, suspended, closed and pending closure cases.

      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.SUSPENDED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOGENERATELIABILITY.ERR_GENLIABILITY_INVALID_ALL_CASESTATUS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00102570

    // Set up key for security check
    caseSecurityCheckKey.caseID = caseIdentifier.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    // BEGIN, CR00226619, PM
    // Call security check
    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    // If the result is false, it means the user does not have access to
    // read this case
    if (!dataBasedSecurityResult.result) {
      throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
    }
    // END, CR00226619

    //
    // Before generating the liability we need to set the
    // case status to Delayed Processing Pending
    //

    // Read CaseStatus information
    currentCaseStatusKey.caseID = caseIdentifier.caseID;
    // BEGIN, CR00224271, ZV
    caseStatusDtls =
      caseStatusObj.readCurrentStatusByCaseID1(currentCaseStatusKey);
    // END, CR00224271

    // Set key to modify end date on existing caseStatus
    caseStatusKey.caseStatusID = caseStatusDtls.caseStatusID;
    caseStatusDtls.endDate = Date.getCurrentDate();
    // BEGIN, CR00162569, PDN
    caseStatusDtls.endDateTime = TransactionInfo.getSystemDateTime();
    // END, CR00162569

    // Modify end date on existing CaseStatus
    caseStatusObj.modify(caseStatusKey, caseStatusDtls);

    // Set key for CaseStatus insert operation
    caseStatusDtls.caseStatusID = UniqueIDFactory.newInstance().getNextID();
    caseStatusDtls.caseID = caseIdentifier.caseID;
    caseStatusDtls.statusCode = CASESTATUS.DELAYEDPROC;
    caseStatusDtls.startDate = Date.getCurrentDate();
    caseStatusDtls.endDate = Date.kZeroDate;
    // BEGIN, 198649, ZV
    caseStatusDtls.startDateTime = DateTime.getCurrentDateTime();
    caseStatusDtls.endDateTime = DateTime.kZeroDateTime;
    // END, 198649

    // BEGIN, CR00150402, PDN
    // Set the user name
    final curam.core.intf.SystemUser systemUserObj =
      curam.core.fact.SystemUserFactory.newInstance();

    caseStatusDtls.userName = systemUserObj.getUserDetails().userName;
    // END, CR0015040

    // Insert new 'Delayed Processing Pending' CaseStatus
    caseStatusObj.insert(caseStatusDtls);

    // Set key to modify CaseHeader
    caseHeaderDtls.statusCode = CASESTATUS.DELAYEDPROC;

    // BEGIN, CR00103023, CW
    // Update CaseHeader with new case status
    cachedCaseHeader.modify(caseHeaderKey, caseHeaderDtls);
    // END, CR00103023

    // Set key to read productDelivery entity
    productDeliveryKey.caseID = caseIdentifier.caseID;

    // Read productID from productDelivery entity
    productIDDetails = productDeliveryObj.readProductID(productDeliveryKey);

    // Set key to read product entity
    productKey.productID = productIDDetails.productID;

    // BEGIN, CR00209539, CW
    // Read the product cache to determine if this is a benefit product
    final ProductDtls productDtls =
      CachedProductFactory.newInstance().read(productKey);

    // BEGIN, CR00264219, KH
    /*
     * This processing should only be used by liability cases or by overpayment
     * style payment correction cases.
     */
    if (productDtls.adminCategory.equals(PRODUCTADMINCATEGORY.BENEFIT)
      || productDtls.adminCategory.equals(PRODUCTADMINCATEGORY.CORRECTION)
        && !paymentCorrection.isOverPaymentPaymentCorrection(caseHeaderKey)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOGENERATELIABILITY.ERR_GENLIABILITY_LIABILITYPRODUCTS_ONLY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00209539, CR00264219

    // Check financial calendar for exclusion dates
    final curam.core.intf.MaintainFinancialCalendar maintainFinancialCalendarObj =
      curam.core.fact.MaintainFinancialCalendarFactory.newInstance();

    final ExclusionDtlsList exclusionDtlsList =
      maintainFinancialCalendarObj.getExclusionDatesForAllMethods();

    // Set financial component next processing date
    if (!exclusionDtlsList.dtls.isEmpty()) {

      final int lastRecordPos = exclusionDtlsList.dtls.size() - 1;

      fcCaseIDCategoryStatusDate.nextProcessingDate =
        exclusionDtlsList.dtls.item(lastRecordPos).exclusionDate;

    } else {

      fcCaseIDCategoryStatusDate.nextProcessingDate = Date.getCurrentDate();
    }

    // Set financial component search details
    fcCaseIDCategoryStatusDate.caseID = caseIdentifier.caseID;
    fcCaseIDCategoryStatusDate.categoryCode = FINCOMPONENTCATEGORY.LIABILITY;
    fcCaseIDCategoryStatusDate.statusCode = FINCOMPONENTSTATUS.LIVE;

    // Search the FinancialComponent entity for all possible FCs that could be
    // eligible for processing
    financialComponentDtlsList = financialComponentObj
      .searchByCaseIDCategoryStatusDate(fcCaseIDCategoryStatusDate);

    if (!financialComponentDtlsList.dtls.isEmpty()) {

      // Check the FC delivery methods are valid for on-line generation
      for (int i = 0; i < financialComponentDtlsList.dtls.size(); i++) {

        if (!financialComponentDtlsList.dtls.item(i).nomineeDelivMethod
          .equals(METHODOFDELIVERY.INVOICE)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                BPOGENERATELIABILITY.ERR_GENLIABILITY_INVALID_DELIVERYMETHOD),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }

      } // end for i

    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOGENERATELIABILITY.ERR_GENLIABILITY_NOT_DUE_TODAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Read first record from the list and store the delivery method code in
    // wmInstanceDataDtls struct
    wmInstanceDataDtls.wm_instDataID =
      UniqueID.nextUniqueID(KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.enteredByID = TransactionInfo.getProgramUser();
    wmInstanceDataDtls.eligibilityAssFromDate = Date.getCurrentDate();
    wmInstanceDataDtls.caseID = caseIdentifier.caseID;
    wmInstanceDataDtls.caseStatus = caseStatusDtls.statusCode;

    // Insert wmInstanceData record
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    // Start delayed process
    dpEnactmentServiceObj.startProcess(DP_const.DP_PROCESS_LIABILITY,
      wmInstanceDataDtls.wm_instDataID);

    //
    // Inform the user that this liability has been queued for generation
    //

    // Create an informational manager
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // Add the message to the informational manager
    final AppException e = new AppException(
      BPOGENERATELIABILITY.INF_GENLIABILITY_QUEUED_FOR_GENERATION);

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
      .addInfoMgrExceptionWithLookup(e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
  }

}
