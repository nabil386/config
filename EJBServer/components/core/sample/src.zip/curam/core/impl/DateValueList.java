/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.util.type.Date;


// BEGIN, CR00232051, GD
public class DateValueList extends curam.util.type.ValueList<Date> {

  public DateValueList(Date[] dates) {

    super(Date.class);

    if (dates == null) {
      return;
    }
    ensureCapacity(dates.length);
    for (int i = 0; i < dates.length; i++) {
      add(dates[i]);
    }
  }

  public DateValueList() {

    super(Date.class);
  }

  public DateValueList(int initialCapacity) {

    super(Date.class, initialCapacity);
  }

  @Override
  public void addRef(Date s) {

    add(s);
  }

  @Override
  public Date item(int indx) {

    return get(indx);
  }

  @Override
  public Date[] items() {

    final Date[] result = new Date[size()];

    toArray(result);
    return result;
  }

}
// END, CR00232051
