/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012-2016. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import com.google.inject.Inject;
import curam.codetable.CASETYPECODE;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.struct.DecisionDateDetails;
import curam.core.sl.struct.IsEventDateListEnabledDetailsKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseTypeDetails_eo;
import curam.core.struct.ClosureDtls;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataKey;
import curam.dependency.impl.DependencyManagerLogger;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;

/**
 * Delayed processing code for case closure.
 * 
 */
public abstract class DelayedCaseClosure extends
  curam.core.base.DelayedCaseClosure {

  // BEGIN, CR00211744, VM
  @Inject
  protected AssessmentEngine assessmentEngine;

  // ___________________________________________________________________________
  /**
   * Add injection.
   */
  public DelayedCaseClosure() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00211744

  // ___________________________________________________________________________
  /**
   * Delayed process for closing cases.
   * 
   * @param ticketID ticket that started process.
   * @param inst_data_id id for retrieving data needed for case closure
   * @param flag whether ticket closing is deferred
   */
  @Override
  public void closeCase(final long ticketID, final long inst_data_id,
    final boolean flag) throws AppException, InformationalException {

    // wMInstance manipulation variables
    final curam.core.intf.WMInstanceData wmInstanceDataObj =
      curam.core.fact.WMInstanceDataFactory.newInstance();
    final WMInstanceDataKey wmInstanceDataKey = new WMInstanceDataKey();
    WMInstanceDataDtls wmInstanceDataDtls;

    // closeCase manipulation variables
    final curam.core.intf.CloseCase closeCaseObj =
      curam.core.fact.CloseCaseFactory.newInstance();
    final ClosureDtls closureDtls = new ClosureDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // assign key value
    wmInstanceDataKey.wm_instDataID = inst_data_id;

    // read data needed for case closure
    wmInstanceDataDtls = wmInstanceDataObj.read(wmInstanceDataKey);

    // BEGIN, 161598, SH
    // capture some dependency manager info.
    TransactionInfo.setFacadeScopeObject(DependencyManagerLogger.kTicketID,
      ticketID);
    TransactionInfo.setFacadeScopeObject(DependencyManagerLogger.kInstDataID,
      inst_data_id);
    TransactionInfo.setFacadeScopeObject(
      DependencyManagerLogger.kDependencyCaseID, wmInstanceDataDtls.caseID);
    // END, 161598

    // copy all the relevant data
    closureDtls.assign(wmInstanceDataDtls);

    // close case
    closeCaseObj.closeCase(closureDtls);

    // If the event based date list is being used by the Assessment Engine
    // add a date to the event date list
    final curam.core.sl.intf.CaseEligibilityDates caseEligibilityDatesObj =
      curam.core.sl.fact.CaseEligibilityDatesFactory.newInstance();

    final IsEventDateListEnabledDetailsKey isEventDateListEnabledDetailsKey =
      new IsEventDateListEnabledDetailsKey();

    isEventDateListEnabledDetailsKey.caseID = closureDtls.caseID;

    if (caseEligibilityDatesObj
      .isEventDateListEnabled(isEventDateListEnabledDetailsKey).result
      && !closureDtls.closureDate.isZero()) {

      final curam.core.intf.CaseHeader caseHeaderObj =
        curam.core.fact.CaseHeaderFactory.newInstance();

      // Create and populate the case header key
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = closureDtls.caseID;

      // Read the case type code
      final CaseTypeDetails_eo caseTypeDetails =
        caseHeaderObj.readType(caseHeaderKey);

      // Only add a date to the date list if closing a product delivery case
      if (caseTypeDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

        // BEGIN, CR00211744, VM
        // Add a date to the date list
        final DecisionDateDetails dateDetails = new DecisionDateDetails();

        dateDetails.caseID = closureDtls.caseID;
        dateDetails.decisionDate = closureDtls.closureDate;

        assessmentEngine.addDecisionDate(dateDetails);
        // END, CR00211744
      }

    }

  }

}
