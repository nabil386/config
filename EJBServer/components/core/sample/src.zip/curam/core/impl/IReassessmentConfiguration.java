/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.ProductDtls;


/**
 * Acts as a hook during Reassessment processing. Classes which implement
 * this interface return information which is used to direct the flow of
 * the Reassessment processing. For example, only cases based on certain
 * products require to be able to access the results of previous rule
 * executions during processing. The assessment engine will call out to
 * all registered listeners in turn to determine if any listener knows
 * if the previous decisions are required for the specified product. <br/>
 * Listeners are registered in the <code>REASSESSMENTCONFIGURATIONCLASS</code>
 * codetable. This codetable is intended only to be modified at
 * development time.
 */
public interface IReassessmentConfiguration {

  // ___________________________________________________________________________
  /**
   * Specific implementations of this interface should determine based on
   * the case details supplied. If cases are dependent on the previous decisions
   * and therefore require to be reassessed forward to the last active decision
   * on the case should a change be detected during reassessment processing.
   *
   * @param caseHeaderDtls The details of the case
   *
   * @return true if and only if the case requires access to the previous
   * decisions and therefore must be reassessed forward to the
   * end of the last active decision if a change is detected.
   */
  boolean isReassessToLastActiveDecisionEnabled(
    CaseHeaderDtls caseHeaderDtls, ProductDtls productDtls);

}
