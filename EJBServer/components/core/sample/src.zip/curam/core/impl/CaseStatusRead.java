/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusDetails;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusID;
import curam.core.struct.CaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Methods used to read case status
 *
 */
public abstract class CaseStatusRead extends curam.core.base.CaseStatusRead {

  /**
   * Operation to read back Case Status records
   *
   * @param caseStatusID caseStatusID
   *
   * @return contains case status details
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS
   * ERR_CASESECURITY_CHECK_READONLY_RIGHTS}-if user doesn't have maintain
   * rights(LBS). {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS
   * ERR_CASESECURITY_CHECK_ACCESS_RIGHTS}-if user doesn't have access rights.
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS
   * ERR_CASESECURITY_CHECK_RIGHTS}-if user doesn't have maintain rights(DBS).
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseStatusDetails viewCaseStatusDtls(CaseStatusID caseStatusID)
    throws AppException, InformationalException {

    final CaseStatusDetails caseStatusDetails = new CaseStatusDetails();

    // Case Status entity, key and details.
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final CaseStatusKey caseStatusKey = new CaseStatusKey();
    CaseStatusDtls caseStatusDtls;

    // Accept CaseStatusID as input parameter
    caseStatusKey.caseStatusID = caseStatusID.caseStatusID;
    // Read CaseStatus table using CaseStatusKey returning CaseStatusDtls
    caseStatusDtls = caseStatusObj.read(caseStatusKey);

    // BEGIN, CR00226315, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = caseStatusDtls.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00226315

    // Map attributes from CaseStatusDtls to output struct CaseStatusDetails
    caseStatusDetails.assign(caseStatusDtls);

    return caseStatusDetails;
  }

}
