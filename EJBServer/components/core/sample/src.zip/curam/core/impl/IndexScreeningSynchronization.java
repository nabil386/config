/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.entity.struct.ScreeningDtls;
import curam.core.struct.SynchronizeEventsDetails;
import curam.events.SCREENING;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class publishes events about the creation and modification of
 * Screening Cases so that interested parties can intercept and take
 * appropriate action.
 */
public abstract class IndexScreeningSynchronization extends curam.core.base.IndexScreeningSynchronization {

  // ___________________________________________________________________________
  /**
   * Publishes an event that a Screening Case was inserted. This method uses
   * the central method SynchronizationEvents.raiseEvent which checks to
   * see if the synchronization events have been enabled before actually raising
   * the event.
   *
   * @param details The details of the Screening Case that was inserted.
   */
  @Override
  public void insert(final ScreeningDtls details) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = SCREENING.INSERT.eventClass;
    synchronizeEventsDetails.eventKey.eventType = SCREENING.INSERT.eventType;
    synchronizeEventsDetails.primaryEventData = details.caseID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

}
