/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.COURSETYPE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.QUALIFICATION;
import curam.codetable.RECORDSTATUS;
import curam.core.intf.EducationSnapshot;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EducationDtls;
import curam.core.struct.EducationKey;
import curam.core.struct.EducationSnapshotDtls;
import curam.core.struct.EducationSnapshotKey;
import curam.core.struct.PersonDtls;
import curam.core.struct.PersonKey;
import curam.core.struct.ProspectPersonDtls;
import curam.core.struct.ProspectPersonKey;
import curam.message.SUMMARYDETAILS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * This entity will record education details for a person.
 *
 */
public abstract class Education extends curam.core.base.Education implements
  ParticipantEvidenceInterface {

  protected class EducationCache {

    public EducationCache() {

      map = new HashMap<Long, EducationDtls>();
      transactionID = 0;
    }

    HashMap<Long, EducationDtls> map;

    int transactionID;
  }

  protected static ThreadLocal<EducationCache> cachedReadDetailsTL = new ThreadLocal<EducationCache>();

  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the education entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param key the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  @Override
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    final EIEvidenceKey retEIEvidenceKey = new EIEvidenceKey();
    final curam.core.intf.EducationSnapshot educationSnapshotObj = curam.core.fact.EducationSnapshotFactory.newInstance();

    final curam.core.intf.Education educationObj = curam.core.fact.EducationFactory.newInstance();

    final EducationKey educationKey = new EducationKey();

    educationKey.educationID = key.evidenceID;

    // copy the entity details to the snapshot
    final EducationDtls educationDtls = educationObj.read(educationKey);
    final EducationSnapshotDtls educationSnapshotDtls = new EducationSnapshotDtls();

    educationSnapshotDtls.assign(educationDtls);

    educationSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    educationSnapshotObj.insert(educationSnapshotDtls);

    retEIEvidenceKey.evidenceID = educationSnapshotDtls.educationSnapshotID;
    retEIEvidenceKey.evidenceType = CASEEVIDENCE.EDUCATION;

    return retEIEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadDetailsTL
   */
  protected void clearCaches() {

    EducationCache cache = cachedReadDetailsTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new EducationCache();
      cachedReadDetailsTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Inserts Education evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((EducationDtls) dtls);

    eiEvidenceKey.evidenceID = ((EducationDtls) dtls).educationID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EDUCATION;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * reads all Education Entities by its Parent ID
   *
   * @param key EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  @Override
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey EIEvidenceKey
   * @param evKeyList EIEvidenceKeyList
   * @param mode Validate Mode
   */
  @Override
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls of entity to remove
   */
  @Override
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    final EducationKey educationKey = new EducationKey();

    // Set entity key for modify
    educationKey.educationID = key.evidenceID;

    // Modify details
    modify(educationKey, (EducationDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param caseKey
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return AttributedDateDetails
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    final AttributedDateDetails retAttributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final EducationDtls educationDtls = read(evKey);

    // END, CR00240667

    retAttributedDateDetails.fromDate = educationDtls.fromDate;
    retAttributedDateDetails.toDate = educationDtls.toDate;
    return retAttributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected EducationDtls read(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Education object
    final curam.core.intf.Education educationObj = curam.core.fact.EducationFactory.newInstance();
    final EducationKey educationKey = new EducationKey();

    educationKey.educationID = key.evidenceID;
    EducationDtls educationDtls = new EducationDtls();

    // BEGIN, CR00067890, POH
    // read education details
    try {
      educationDtls = educationObj.read(educationKey);
    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot education entity
      final EducationSnapshotKey educationSnapshotKey = new EducationSnapshotKey();

      final curam.core.intf.EducationSnapshot educationSnapshotObj = curam.core.fact.EducationSnapshotFactory.newInstance();

      // populate education snapshot key with passed in parameter
      educationSnapshotKey.educationSnapshotID = key.evidenceID;

      // read education snapshot details
      final EducationSnapshotDtls educationSnapshotDtls = educationSnapshotObj.read(
        educationSnapshotKey);

      educationSnapshotDtls.assign(educationSnapshotDtls);
    }
    // END, CR00067890
    return educationDtls;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return Evidence details to be displayed on the list page
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    final EducationDtls educationDtls = read(key);

    // END, CR00240667

    // Set the start / end dates
    eiFieldsForListDisplayDtls.startDate = educationDtls.fromDate;
    eiFieldsForListDisplayDtls.endDate = educationDtls.toDate;

    // Set the summary details.
    // BEGIN, CR00241068, CD
    final LocalisableString message = new LocalisableString(
      SUMMARYDETAILS.EDUCATION);

    message.arg(
      CodeTable.getOneItem(COURSETYPE.TABLENAME, educationDtls.courseType));
    message.arg(
      CodeTable.getOneItem(QUALIFICATION.TABLENAME, educationDtls.qualification));

    message.arg(educationDtls.institution);

    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey Key for parent
   *
   * @return eiEvidenceKey - key for inserted evidence
   */
  @Override
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((EducationDtls) dtls);

    eiEvidenceKey.evidenceID = ((EducationDtls) dtls).educationID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.EDUCATION;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls Object containing details of entity
   */
  @Override
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Education entity key
    final EducationKey educationKey = new EducationKey();

    // Set entity key for modify
    educationKey.educationID = key.evidenceID;

    // Modify details
    modify(educationKey, (EducationDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract
   * method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   *
   * @return the Object with the readEvidence details
   */
  @Override
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // BEGIN, HARP CR00060424, PCAL
    EducationDtls educationDtls = new EducationDtls();

    try {
      final curam.core.intf.Education educationObj = curam.core.fact.EducationFactory.newInstance();
      final EducationKey educationKey = new EducationKey();

      educationKey.educationID = key.evidenceID;
      educationDtls = educationObj.read(educationKey);

      return educationDtls;

    } catch (final RecordNotFoundException rnfe) {

      final EducationSnapshot educationSnapshotObj = curam.core.fact.EducationSnapshotFactory.newInstance();
      final curam.core.struct.EducationSnapshotKey educationSnapshotKey = new curam.core.struct.EducationSnapshotKey();

      educationSnapshotKey.educationSnapshotID = key.evidenceID;
      final curam.core.struct.EducationSnapshotDtls educationSnapshotDtls = educationSnapshotObj.read(
        educationSnapshotKey);

      educationDtls.assign(educationSnapshotDtls);
      return educationDtls;
    }
    // END, HARP CR00060424
  }

  // __________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details Contains entity details
   */
  @Override
  public void insert(EducationDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // __________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key Contains key to access entity details
   * @param details Contains details to modify
   */
  @Override
  public void modify(EducationKey key, EducationDtls details)
    throws AppException, InformationalException {

    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * This method will perform validation on the education record.
   *
   * @param details Education details
   */
  @Override
  protected void autovalidate(EducationDtls details) throws AppException,
      InformationalException {

    // person manipulation variables
    final curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();
    final PersonKey personKey = new PersonKey();
    PersonDtls personDtls;

    // BEGIN, CR00020851, NH
    // prospect person manipulation variables
    final curam.core.intf.ProspectPerson prospectPersonObj = curam.core.fact.ProspectPersonFactory.newInstance();
    final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();
    ProspectPersonDtls prospectPersonDtls;

    // Concern Role information manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls = null;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // END, CR00020851

    // check that start date is not empty
    if (details.fromDate.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.GENERAL.ERR_GENERAL_FV_START_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 12);
    }

    // check that the end date is not earlier than the start date
    if (!details.toDate.isZero() && details.toDate.before(details.fromDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERAL.ERR_GENERAL_XFV_START_DATE_END_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          17);
    }

    // check that a course type has been entered, either full or part-time
    if (details.courseType.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEDUCATION.ERR_EDUCATION_FV_COURSETYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // check that the institution name has been entered
    if (details.institution.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEDUCATION.ERR_EDUCATION_FV_INSTITUTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // check that the qualification name has been entered
    if (details.qualification.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEDUCATION.ERR_EDUCATION_FV_QUALIFICATION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00020851 , NH
    curam.util.type.Date dateOfBirth = curam.util.type.Date.kZeroDate;
    curam.util.type.Date dateOfDeath = curam.util.type.Date.kZeroDate;

    concernRoleKey.concernRoleID = details.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    if (concernRoleDtls != null) {
      if (concernRoleDtls.concernRoleType.equals(
        curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {

        // set key to read prospect person
        prospectPersonKey.concernRoleID = details.concernRoleID;

        // read prospect person
        prospectPersonDtls = prospectPersonObj.read(prospectPersonKey);

        dateOfBirth = prospectPersonDtls.dateOfBirth;
        dateOfDeath = prospectPersonDtls.dateOfDeath;

      } else if (concernRoleDtls.concernRoleType.equals(
        curam.codetable.CONCERNROLETYPE.PERSON)) {

        // set key to read person
        personKey.concernRoleID = details.concernRoleID;

        // read person
        personDtls = personObj.read(personKey);

        dateOfBirth = personDtls.dateOfBirth;
        dateOfDeath = personDtls.dateOfDeath;
      }
    }
    // END, CR00020851

    // if the from date is less than the person's date of birth, throw an error
    if (details.fromDate.before(dateOfBirth)) {

      final AppException e = new AppException(
        curam.message.BPOEDUCATION.ERR_EDUCATION_XRV_FROM_DATE_DOB);

      e.arg(dateOfBirth);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // if the from date is greater than the person's date of death and the
    // date of death is not empty, throw an error
    // BEGIN, CR00030317,NG
    if (details.fromDate.after(dateOfDeath) && !dateOfDeath.isZero()) {

      final AppException e = new AppException(
        curam.message.BPOEDUCATION.ERR_EDUCATION_XRV_FROM_DATE_DOD);

      e.arg(dateOfDeath);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00030317
    // if the to date is greater than the person's date of death, and the
    // date of death is not empty, throw an error
    if (details.toDate.after(dateOfDeath) && !dateOfDeath.isZero()) {

      final AppException e = new AppException(
        curam.message.BPOEDUCATION.ERR_EDUCATION_XRV_TO_DATE_DOD);

      e.arg(dateOfDeath);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing a
   * evidenceID/evidenceType pair.
   */
  @Override
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060375, MMC
    // return struct
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;

    // BEGIN, CR00065999, JPG
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();
    final curam.core.intf.Education educationObj = curam.core.fact.EducationFactory.newInstance();

    // populate the education key with passed in parameter
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of education records for concernRole
    final curam.core.struct.EducationDtlsList educationDtlsList = educationObj.searchByConcernRoleIDAndStatus(
      concernRoleIDStatusCodeKey);

    // END, CR00065999

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < educationDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = educationDtlsList.dtls.item(i).educationID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.EDUCATION;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    return eiEvidenceKeyList;
    // END, CR00060375, MMC

  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute
   * that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the
   * attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  @Override
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key,
    Object dtls) throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    final ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create EducationDtls structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    EducationDtls educationCompareDtls1 = new EducationDtls();
    final EducationDtls educationCompareDtls2 = new EducationDtls();

    try {

      final curam.core.intf.Education educationObj = curam.core.fact.EducationFactory.newInstance();

      final EducationKey educationKey = new EducationKey();

      educationKey.educationID = key.evidenceID;

      // read Education details
      educationCompareDtls1 = educationObj.read(educationKey);

      // Populate the Education struct that will be compared against
      educationCompareDtls2.assign((EducationDtls) dtls);

    } catch (final RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot Education entity
      final curam.core.intf.EducationSnapshot educationSnapshotObj = curam.core.fact.EducationSnapshotFactory.newInstance();

      final EducationSnapshotKey educationSnapshotKey = new EducationSnapshotKey();

      // populate the Education snapshot key with passed in parameter
      educationSnapshotKey.educationSnapshotID = key.evidenceID;

      // Read the Education snapshot details
      educationCompareDtls2.assign(
        educationSnapshotObj.read(educationSnapshotKey));

      // Populate the Education struct that will be compared against
      educationCompareDtls1.assign((EducationDtls) dtls);
    }

    if (educationCompareDtls1.educationID != educationCompareDtls2.educationID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.EDUCATIONID);
    }
    if (educationCompareDtls1.concernRoleID
      != educationCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!educationCompareDtls1.fromDate.equals(educationCompareDtls2.fromDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.FROMDATE);
    }
    if (!educationCompareDtls1.toDate.equals(educationCompareDtls2.toDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TODATE);
    }
    if (!educationCompareDtls1.courseType.equals(
      educationCompareDtls2.courseType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COURSETYPE);
    }
    if (!educationCompareDtls1.qualification.equals(
      educationCompareDtls2.qualification)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.QUALIFICATION);
    }
    if (!educationCompareDtls1.institution.equals(
      educationCompareDtls2.institution)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.INSTITUTION);
    }
    if (!educationCompareDtls1.statusCode.equals(
      educationCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (educationCompareDtls1.addressID != educationCompareDtls2.addressID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ADDRESSID);
    }
    if (!educationCompareDtls1.comments.equals(educationCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of
   * an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  @Override
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set an indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // END, CR00069014
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return read(evKey).toDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // BEGIN, CR00240667, CD
    return read(evKey).fromDate;
    // END, CR00240667
  }
  // END, CR002204022
}
