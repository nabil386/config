/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.impl;


import curam.core.struct.CaseEventByCaseIDStatusKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

public abstract class CaseEvent extends curam.core.base.CaseEvent {

  @Override
  protected void presearchNonCanceledByCaseID(CaseEventByCaseIDStatusKey key)
    throws AppException, InformationalException {

    // set the key to ignore closed (canceled) records
    key.statusCode = curam.codetable.CASEEVENTSTATUS.CLOSED;

  }

}
