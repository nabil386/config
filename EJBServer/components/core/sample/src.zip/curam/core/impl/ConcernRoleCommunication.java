/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2015. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.events.CONCERNROLEACOMMUNICATION;
import curam.core.struct.CommStatusAndRecordStatusDetails;
import curam.core.struct.CommStatusDetails;
import curam.core.struct.ConcernRoleCommCancelDetails;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleCommunicationKey;
import curam.util.events.impl.EventService;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Concern Role Communication entity operations
 */
public abstract class ConcernRoleCommunication extends curam.core.base.ConcernRoleCommunication {

  // __________________________________________________________________________
  /*
   * Cancels a concern role communication.
   *
   * @param key Contains the concern role communication identifier.
   *
   * @param details Cancellation details.
   */
  @Override
  protected void precancel(ConcernRoleCommunicationKey key,
    ConcernRoleCommCancelDetails details) throws AppException,
      InformationalException {

    validateCancel(key);

    details.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
  }

  // ___________________________________________________________________________
  /*
   * Validates the cancellation of a concern role communication.
   *
   * @param key Contains the concern role communication identifier.
   */
  @Override
  public void validateCancel(ConcernRoleCommunicationKey key)
    throws AppException, InformationalException {

    CommStatusAndRecordStatusDetails commStatusAndRecordStatusDetails;

    commStatusAndRecordStatusDetails = readCommStatusAndRecordStatus(key);

    if (commStatusAndRecordStatusDetails.statusCode.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCOMMUNICATION.ERR_CONCERN_ROLE_COMM_RV_CANCELED_ALREADY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (!commStatusAndRecordStatusDetails.communicationStatus.equals(
      curam.codetable.COMMUNICATIONSTATUS.DRAFT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCOMMUNICATION.ERR_CONCERN_ROLE_COMM_RV_NOT_DRAFT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // __________________________________________________________________________
  /*
   * Modifies a communication as being sent.
   *
   * @param key Contains the concern role communication identifier.
   *
   * @param details Details to mark the communication as being sent.
   */
  @Override
  protected void premodifyCommAsSent(ConcernRoleCommunicationKey key,
    CommStatusDetails details) throws AppException, InformationalException {

    validateSend(key);

    details.communicationStatus = curam.codetable.COMMUNICATIONSTATUS.SENT;
  }

  // ___________________________________________________________________________
  /*
   * Validates the marking of a communication as being sent.
   *
   * @param key Contains the concern role communication identifier.
   */
  @Override
  public void validateSend(ConcernRoleCommunicationKey key)
    throws AppException, InformationalException {

    CommStatusAndRecordStatusDetails commStatusAndRecordStatusDetails;

    commStatusAndRecordStatusDetails = readCommStatusAndRecordStatus(key);

    if (commStatusAndRecordStatusDetails.statusCode.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCOMMUNICATION.ERR_CONCERN_ROLE_COMM_RV_CANCELED_CANT_SEND),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (commStatusAndRecordStatusDetails.communicationStatus.equals(
      curam.codetable.COMMUNICATIONSTATUS.SENT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCOMMUNICATION.ERR_CONCERN_ROLE_COMM_RV_ALREADY_SENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // BEGIN, CR00467223, MV
  /*
   * Method to raise an event when the communication got created.
   *
   * @param details Contains the concern role communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void postinsert(final ConcernRoleCommunicationDtls details)
    throws AppException, InformationalException {

    final curam.util.events.struct.Event communicatinEvent = new curam.util.events.struct.Event();

    communicatinEvent.eventKey.eventClass = CONCERNROLEACOMMUNICATION.INSERT_CONCERN_ROLE_COMMUNICATION.eventClass;
    communicatinEvent.eventKey.eventType = CONCERNROLEACOMMUNICATION.INSERT_CONCERN_ROLE_COMMUNICATION.eventType;

    communicatinEvent.primaryEventData = details.communicationID;

    EventService.raiseEvent(communicatinEvent);
  }

  /*
   * Method to raise an event when the communication got modified.
   *
   * @key concern role communication id.
   *
   * @param details Contains the concern role communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void postmodify(final ConcernRoleCommunicationKey key,
    final ConcernRoleCommunicationDtls details) throws AppException,
      InformationalException {

    final curam.util.events.struct.Event communicatinEvent = new curam.util.events.struct.Event();

    communicatinEvent.eventKey.eventClass = CONCERNROLEACOMMUNICATION.MODIFY_CONCERN_ROLE_COMMUNICATION.eventClass;
    communicatinEvent.eventKey.eventType = CONCERNROLEACOMMUNICATION.MODIFY_CONCERN_ROLE_COMMUNICATION.eventType;

    communicatinEvent.primaryEventData = details.communicationID;

    EventService.raiseEvent(communicatinEvent);
  }
  // END, CR00467223
}
