/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.EDUCATIONALINSTITUTE;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.EducationalInstituteDtls;
import curam.core.struct.EducationalInstituteKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when
 * modifications are made to the educational institute entity
 */
public abstract class IndexEducationalInstituteSynchronization extends curam.core.base.IndexEducationalInstituteSynchronization {

  // ___________________________________________________________________________
  /**
   * Post an event indicating that the educational institute has been updated
   *
   * @param dtls The details of the educational institute that was inserted.
   */
  @Override
  public void insert(final EducationalInstituteDtls dtls)
    throws AppException, InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = EDUCATIONALINSTITUTE.INSERT_EDUCATIONAL_INSTITUTE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = EDUCATIONALINSTITUTE.INSERT_EDUCATIONAL_INSTITUTE.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Post an event indicating that the specific educational institute has been
   * updated
   *
   * @param key Identifies the educational institute that was modified.
   * @param dtls The details of the educational institute that was modified.
   */
  @Override
  public void modify(final EducationalInstituteKey key,
    final EducationalInstituteDtls dtls) throws AppException,
      InformationalException {

    final SynchronizeEvents synchronizeEventsObj = SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails = new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = EDUCATIONALINSTITUTE.MODIFY_EDUCATIONAL_INSTITUTE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = EDUCATIONALINSTITUTE.MODIFY_EDUCATIONAL_INSTITUTE.eventType;
    synchronizeEventsDetails.primaryEventData = key.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

}
