/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.hook.task.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Implementable;


/**
 * Contains a number of hook points which allow for custom specific processing
 * of task reservation and work queue subscription.
 */
@Implementable
@ImplementedBy(InboxActionsImpl.class)
public interface InboxActions {

  /**
   * Gets the next task available for the specified user and adds it to the
   * <code>My Tasks</code> list for that user. The default implementation
   * class defines what the <code>next</code> task is.
   *
   * @param userName The name of the user.
   *
   * @return The identifier of the next task.
   */
  public long getNextTask(final String userName) throws AppException,
      InformationalException;

  /**
   * Gets the next task from the specified work queue which the specified
   * user is subscribed to and adds it to the <code>My Tasks</code> list for
   * that user. The default implementation class defines what the
   * <code>next</code> task is.
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the work queue in which to get the
   * next task
   *
   * @return The identifier of the next task.
   */
  public long getNextTaskFromWorkQueue(final String userName,
    final long workQueueID) throws AppException, InformationalException;

  /**
   * Gets the next task from the user's preferred work queue and adds it to
   * the <code>My Tasks</code> list for that user. The default implementation
   * class defines what the <code>next</code> task is.
   *
   * @param userName The name of the user.
   *
   * @return The identifier of the next task.
   */
  public long getNextTaskFromPreferredWorkQueue(final String userName)
    throws AppException, InformationalException;

  /**
   * Gets the next task from the user's preferred organization unit and adds
   * it to the <code>My Tasks</code> list for that user. The default
   * implementation class defines what the <code>next</code> task is.
   *
   * @param userName The name of the user.
   *
   * @return The identifier of the next task.
   */
  public long getNextTaskFromPreferredOrgUnit(final String userName)
    throws AppException, InformationalException;

  /**
   * Subscribes the specified user to the specified work queue.
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the work queue that the use is
   * subscribing to.
   */
  public void subscribeUserToWorkQueue(final String userName,
    final long workQueueID) throws AppException, InformationalException;

  /**
   * Un-subscribes the specified user from the specified work queue.
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the work queue that the use is
   * un-subscribing from.
   */
  public void unsubscribeUserFromWorkQueue(final String userName,
    final long workQueueID) throws AppException, InformationalException;
}
