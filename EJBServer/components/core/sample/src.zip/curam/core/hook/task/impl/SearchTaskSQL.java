/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.hook.task.impl;


import com.google.inject.ImplementedBy;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Implementable;


/**
 * Contains the methods required to generate dynamic SQL to search for
 * tasks. By default there are three types of task search functionality which
 * functions in this class may be used for:
 *
 * <ul>
 * <li>curam.core.facade.impl.TaskQuery</li>
 * <li>curam.core.facade.impl.Inbox.searchAvailableTasks()</li>
 * <li>curam.core.facade.impl.Inbox.searchForTasks(TaskQueryKey)</li>
 * </ul>
 */
@Implementable
@ImplementedBy(SearchTaskSQLImpl.class)
public interface SearchTaskSQL {

  /**
   * Returns the SQL select query used to return tasks satisfying the
   * specified criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the select query.
   */
  public String getSQLStatement(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Returns the SQL select query used to count the number of tasks satisfying
   * the specified criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the count query.
   */
  public String getCountSQLStatement(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Returns the SQL <code>SELECT</code> clause of the query.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL <code>SELECT</code> clause.
   */
  public String getSelectClause(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Returns the SQL <code>FROM</code> clause of the query.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL <code>FROM</code> clause.
   */
  public String getFromClause(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Returns the SQL <code>WHERE</code> clause of the query.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL where clause.
   */
  public String getWhereClause(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the organization objects that tasks may be assigned
   * to and selected by the user as search criteria. An organizational object
   * may be an organizational unit, position or job that the current user is
   * a member of or a work queue that the user is subscribed to.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select the organization objects.
   */
  public String getOrgObjectSQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the task <code>status<code> selected by the user.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by
   * <code>status</code>.
   */
  public String getStatusSQL(TaskQueryCriteria criteria) throws AppException,
      InformationalException;

  /**
   * Generates the SQL for the task identifier selected by the user to be used
   * as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by their identifier.
   */
  public String getTaskIDSQL(TaskQueryCriteria criteria) throws AppException,
      InformationalException;

  /**
   * Generates the <code>reserved by</code> SQL selected by the user.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by the
   * <code>reserved by</code> field.
   */
  public String getReservedBySQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the task <code>priority</code> selected by the user
   * to be used as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by
   * <code>priority</code>.
   */
  public String getPrioritySQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the task <code>deadline</code> selected by the user
   * to be used as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by
   * <code>deadline</code>.
   */
  public String getDeadlineSQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the <code>creation date</code> selected by the user
   * to be used as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by
   * <code>creation date</code>.
   */
  public String getCreationDateSQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the <code>restart date</code> selected by the user
   * to be used as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by
   * <code>restart date</code>.
   */
  public String getRestartDateSQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL <code>order by</code> clause.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing SQL <code>order by</code> clause.
   */
  public String getOrderBySQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the associated <code>business object</code> selected
   * by the user to be used as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by associated
   * <code>business object</code>.
   */
  public String getBusinessObjectTypeSQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;

  /**
   * Generates the SQL for the <code>category</code> selected by the user to
   * be used as a search criteria.
   *
   * @param criteria The search criteria from which to generate the SQL.
   *
   * @return A string representing the SQL to select tasks by
   * <code>category</code>.
   */
  public String getCategorySQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException;
}
