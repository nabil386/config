/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.hook.task.impl;


import com.google.inject.ImplementedBy;
import curam.core.sl.entity.struct.QueryKey;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.TaskQueryDetails;
import curam.core.sl.struct.TaskQueryResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Implementable;


/**
 * Contains a number of hook points which allow for custom specific processing
 * of task query actions.
 */
@Implementable
@ImplementedBy(TaskQueryImpl.class)
public interface TaskQuery {

  /**
   * Creates a task query.
   *
   * @param details The task query criteria for a query.
   *
   * @return The identifier of the new query.
   */
  public long createTaskQuery(TaskQueryDetails details) throws AppException,
      InformationalException;

  /**
   * Modifies a task query's criteria.
   *
   * @param details The task query criteria to replace the existing criteria.
   *
   * @return The identifier of the modified query.
   */
  public long modifyTaskQuery(TaskQueryDetails details) throws AppException,
      InformationalException;

  /**
   * Runs a task query that has been previously saved.
   *
   * @param key The identifier of the task query.
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of tasks that satisfy the query's criteria.
   */
  public TaskQueryResult runTaskQuery(QueryKey key,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException;

  /**
   * Runs a task query using the criteria details as entered by the user.
   *
   * @param details The task query criteria.
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of tasks that satisfy the query criteria.
   */
  public TaskQueryResult runTaskQuery(TaskQueryDetails details,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException;

  /**
   * Validates the task query criteria before performing a search.
   *
   * @param details The task query criteria.
   */
  public void validateTaskQuery(TaskQueryDetails details)
    throws AppException, InformationalException;
}
