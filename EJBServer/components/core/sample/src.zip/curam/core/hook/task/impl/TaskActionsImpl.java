/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.hook.task.impl;


import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.ORGSTRUCTURESTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKCHANGETYPE;
import curam.codetable.TASKSTATUS;
import curam.codetable.WQSUBSORGOBJECTTYPE;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.JobFactory;
import curam.core.sl.entity.fact.OrgUnitPositionLinkFactory;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.fact.TaskAssignmentFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.Job;
import curam.core.sl.entity.intf.OrgUnitPositionLink;
import curam.core.sl.entity.intf.OrganisationStructure;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.TaskAssignment;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrgStructurePositionAndStatusKey;
import curam.core.sl.entity.struct.OrgUnitPositionLinkDetails;
import curam.core.sl.entity.struct.OrganisationStructureID;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.TaskAssignmentDtls;
import curam.core.sl.entity.struct.TaskAssignmentDtlsList;
import curam.core.sl.entity.struct.TaskAssignmentNameDetailsList;
import curam.core.sl.entity.struct.TaskIDAndUserNameKey;
import curam.core.sl.entity.struct.TaskIDRelatedIDAndTypeKey;
import curam.core.sl.entity.struct.TaskRedirectionOrAllocationBlockingPeriodDetails;
import curam.core.sl.entity.struct.Task_waKey;
import curam.core.sl.entity.struct.UserNameAndDateTimeKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.OrganisationUnitFactory;
import curam.core.sl.fact.PositionFactory;
import curam.core.sl.fact.TaskManagementUtilityFactory;
import curam.core.sl.fact.TaskRedirectionFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.fact.WorkResolverFactory;
import curam.core.sl.impl.DefaultWorkResolverAdapter;
import curam.core.sl.impl.DefaultWorkResolverHelper;
import curam.core.sl.infrastructure.impl.WorkAllocationConst;
import curam.core.sl.intf.OrganisationUnit;
import curam.core.sl.intf.TaskManagementUtility;
import curam.core.sl.intf.TaskRedirection;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.intf.WorkResolver;
import curam.core.sl.struct.AllocationTargetDetails;
import curam.core.sl.struct.AllocationTargetList;
import curam.core.sl.struct.BooleanIndicator;
import curam.core.sl.struct.DateTimeInSecondsKey;
import curam.core.sl.struct.DeadlineDuration;
import curam.core.sl.struct.JobDetails;
import curam.core.sl.struct.JobKey;
import curam.core.sl.struct.OrgStructureAndOrgUnitKey;
import curam.core.sl.struct.OrgStructureAndPositionKey;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.ReadWorkQueueDetails;
import curam.core.sl.struct.TaskAndUserNameKey;
import curam.core.sl.struct.TaskCreateDetails;
import curam.core.sl.struct.TaskForwardedTo;
import curam.core.sl.struct.TaskManagementTaskKey;
import curam.core.sl.struct.TimeOnTaskHoursAndMinsStruct;
import curam.core.sl.struct.TotalTimeWorked;
import curam.core.sl.struct.ViewOrgUnitDetails;
import curam.core.sl.struct.ViewPositionDetails;
import curam.core.sl.struct.WorkResolverTaskKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.Count;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.events.TASK;
import curam.message.BPOORGANISATIONSTRUCTURE;
import curam.message.BPOTASKMANAGEMENT;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.events.TASKLIFECYCLE;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.workflow.fact.BusinessObjectAssociationAdminFactory;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.fact.TaskHistoryAdminFactory;
import curam.util.workflow.fact.WorkflowDeadlineAdminFactory;
import curam.util.workflow.impl.TaskAllocationAdmin;
import curam.util.workflow.intf.BusinessObjectAssociationAdmin;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.intf.TaskHistoryAdmin;
import curam.util.workflow.intf.WorkflowDeadlineAdmin;
import curam.util.workflow.struct.BizObjectAssociationDetails;
import curam.util.workflow.struct.BizObjectAssociationDetailsList;
import curam.util.workflow.struct.TaskDetails;
import curam.util.workflow.struct.TaskDetailsWithDueDate;
import curam.util.workflow.struct.TaskDetailsWithSnapshot;
import curam.util.workflow.struct.TaskDetailsWithoutSnapshot;
import curam.util.workflow.struct.TaskKey;
import curam.util.workflow.struct.TaskOptimisticLockingDetails;
import curam.util.workflow.struct.WorkflowDeadlineInfo;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


/**
 * Default implementation of {@link TaskActions}.
 */
public class TaskActionsImpl implements TaskActions {

  /**
   * The name of the manual workflow process definition.
   */
  protected static final String kManual = WorkAllocationConst.kManual;

  /**
   * The name of the manual case workflow process definition.
   */
  protected static final String kManualCase = WorkAllocationConst.kManualCase;

  /**
   * The name of the manual participant workflow process definition.
   */
  protected static final String kManualParticipant = WorkAllocationConst.kManualParticipant;

  /**
   * The name of the manual participant case workflow process definition.
   */
  protected static final String kManualParticipantCase = WorkAllocationConst.kManualParticipantCase;

  /**
   * A constant for zero.
   */
  protected final int kZero = 0;

  /**
   * A constant for sixty.
   */
  protected final int kSixty = 60;

  /**
   * Adds a comment to a task by inserting a record into the task history
   * table. A task does not have to be included in the <code>My Tasks</code>
   * list for a user to comment on it. This allows users to comment on tasks
   * that are included in the <code>My Tasks</code> lists of other users. A
   * task life cycle event <code>TASKLIFECYCLE.COMMENTADDED</code> is raised
   * when a comment is added to a task.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is closed</li>
   * </ul>
   *
   * @param taskID The identifier of the task which the comment is being added.
   * @param comment The comment to be added as a task history record.
   */
  @Override
  public void addComment(final long taskID, final String comment)
    throws AppException, InformationalException {

    // Call validate method
    validateAddComment(taskID);

    // BEGIN, CR00246088, PM
    checkMaintainSecurity(taskID);
    // END, CR00246088

    // Get the Current Date and Time
    final DateTime currentDateTime = DateTime.getCurrentDateTime();

    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    // Insert the record
    taskHistoryAdminObj.create(taskID, currentDateTime,
      curam.codetable.TASKCHANGETYPE.COMMENTADDED, comment,
      curam.core.impl.CuramConst.gkEmpty, curam.core.impl.CuramConst.gkEmpty,
      curam.util.transaction.TransactionInfo.getProgramUser());

    // Raise the comment added task life cycle event. The associated event
    // handler will determine if the task is associated with a case and if so
    // will log a case transaction log entry.
    final Event taskCommentAddedLifeCycleEvent = new Event();

    taskCommentAddedLifeCycleEvent.eventKey.eventClass = TASKLIFECYCLE.COMMENTADDED.eventClass;
    taskCommentAddedLifeCycleEvent.eventKey.eventType = TASKLIFECYCLE.COMMENTADDED.eventType;
    taskCommentAddedLifeCycleEvent.primaryEventData = taskID;
    EventService.raiseEvent(taskCommentAddedLifeCycleEvent);
  }

  /**
   * Closes the task by raising the <code>TASK.CLOSED</code> event.
   * <P>
   * An exception is thrown in the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task being closed is part of the My Tasks list of another user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be closed.
   */
  @Override
  public void close(final long taskID) throws AppException,
      InformationalException {

    // Validate close
    validateClose(taskID);

    final Event closeTaskEvent = new Event();

    closeTaskEvent.eventKey.eventClass = TASK.CLOSED.eventClass;
    closeTaskEvent.eventKey.eventType = TASK.CLOSED.eventType;

    closeTaskEvent.primaryEventData = taskID;

    EventService.raiseEvent(closeTaskEvent);

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskDetailsWithoutSnapshot taskStatusDetails = taskAdminObj.readDetails(
      taskID);

    if (!curam.codetable.TASKSTATUS.CLOSED.equals(taskStatusDetails.status)) {
      final AppException e = new AppException(
        BPOTASKMANAGEMENT.ERR_TASK_CANNONT_BE_CLOSED_FROM_THIS_PAGE);

      e.arg(taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
  }

  /**
   * Creates a new task by enacting a workflow process. The workflow process
   * enacted depends on the input criteria specified to create the task.
   * <ul>
   * <li>If both the <code>participantRoleID</code> and <code>caseID</code>
   * input fields have not been specified, then the <code>MANUAL</code> workflow
   * process is enacted.</li>
   * <li>If the <code>participantRoleID</code> input field has been populated
   * and the <code>caseID</code> input field has not, then the
   * <code>MANUALPARTICIPANT</code> workflow process is enacted.</li>
   * <li>If the <code>participantRoleID</code> input field has not been
   * populated and the <code>caseID</code> input field has been populated, then
   * the <code>MANUALCASE</code> workflow process is enacted.</li>
   * <li>Otherwise the default workflow process that is enacted is the
   * <code>MANUALPARTICIPANTCASE</code>.</li>
   * </ul>
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the priority field is empty.</li>
   * <li>If the subject field is empty.</li>
   * <li>If the deadline field contains a date time that is in the past.</li>
   * <li>If neither the <code>addToMyTasksInd</code> field nor the
   * <code>assignedTo</code> field are set.</li>
   * <li>If both the <code>addToMyTasksInd</code> and <code>assignedTo</code>
   * fields are set.</li>
   * <li>If the <code>addToMyTasksInd</code> field has been set and the
   * specified user has an active task redirection or allocation blocking period
   * specified for them.</li>
   * <li>If the assignee name does not match the assignee type.</li>
   * </ul>
   *
   * @param subject The task subject.
   * @param priority The task priority.
   * @param assignedTo The name of the organization object, user or work queue
   * to which the task will be made available to.
   * @param assigneeType The type of the organization object.
   * @param deadlineDateTime The task deadline.
   * @param participantRoleID The participant role identifier.
   * @param participantType The participant type.
   * @param caseID The case identifier.
   * @param addToMyTasksInd Indicates whether the task should be added to the
   * users task list.
   * @param comment The task comment.
   */
  @Override
  public void create(final String subject, final String priority,
    final String assignedTo, final String assigneeType,
    final DateTime deadlineDateTime, final long participantRoleID,
    final String participantType, final long caseID,
    final boolean addToMyTasksInd, final String comment) throws AppException,
      InformationalException {

    final TaskCreateDetails taskCreateDetail = new TaskCreateDetails();

    taskCreateDetail.subject = subject;
    taskCreateDetail.priority = priority;
    taskCreateDetail.assignedTo = assignedTo;
    taskCreateDetail.assigneeType = assigneeType;
    taskCreateDetail.deadlineDateTime = deadlineDateTime;
    taskCreateDetail.participantRoleID = participantRoleID;
    taskCreateDetail.participantType = participantType;
    taskCreateDetail.caseID = caseID;
    taskCreateDetail.reserveToMeInd = addToMyTasksInd;
    taskCreateDetail.comments = comment;

    validateCreate(taskCreateDetail);

    final String kWorkflowProcess;

    // Create the list we will pass to the enactment service.
    final List<Object> enactmentStructs = new ArrayList<Object>();

    final DeadlineDuration deadlineDuration = new DeadlineDuration();

    if (participantRoleID == 0 && caseID == 0) {
      kWorkflowProcess = kManual;
    } else if (participantRoleID != 0 && caseID == 0) {
      kWorkflowProcess = kManualParticipant;
    } else if (participantRoleID == 0 && caseID != 0) {
      kWorkflowProcess = kManualCase;
    } else {
      kWorkflowProcess = kManualParticipantCase;
    }

    if (addToMyTasksInd) {
      taskCreateDetail.assignedTo = curam.util.transaction.TransactionInfo.getProgramUser();
      taskCreateDetail.assigneeType = curam.codetable.ASSIGNEETYPE.USER;
    }

    final TaskRedirection taskRedirection = TaskRedirectionFactory.newInstance();
    final UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

    userNameAndDateTimeKey.userName = taskCreateDetail.assignedTo;
    userNameAndDateTimeKey.currentDateTime = curam.util.type.DateTime.getCurrentDateTime();

    // If there is an active task redirection period in place, then retrieve
    // the name of the user to whom the tasks will be redirected to.
    final TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails = taskRedirection.readTaskRedirectionOrAllocationBlockingPeriodForUser(
      userNameAndDateTimeKey);

    // check for active redirection
    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails != null) {
      // get assignee type (which could be one of - Job or Position or User
      // or WorkQueue or OrgUnit)
      taskCreateDetail.assigneeType = activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType;
      // if assignee type is user then pass user name
      if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType.equals(
        TARGETITEMTYPE.USER)) {
        taskCreateDetail.assignedTo = activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName;
      } else {
        // if assignee type is job, position or org unit then pass their ID
        taskCreateDetail.assignedTo = new Long(activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectID).toString();
      }
    }

    final DateTimeInSecondsKey dateTimeInSecondsKey = new DateTimeInSecondsKey();

    dateTimeInSecondsKey.dateTime = deadlineDateTime;

    final TaskManagementUtility taskManagementUtilityObj = TaskManagementUtilityFactory.newInstance();

    deadlineDuration.deadlineDuration = taskManagementUtilityObj.convertDateTimeToSeconds(dateTimeInSecondsKey).seconds;
    enactmentStructs.add(taskCreateDetail);
    enactmentStructs.add(deadlineDuration);

    // Get the value of the enactworkflow.disabled environment variable
    String workflowDisabled = Configuration.getProperty(
      EnvVars.ENV_ENACT_WORKFLOW_PROCESS_DISABLED);

    // If it's not disabled, enact the workflow process
    if (workflowDisabled == null) {
      workflowDisabled = EnvVars.ENV_ENACT_WORKFLOW_PROCESS_DISABLED_DEFAULT;
    }

    if (workflowDisabled.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      // Always use synchronous mode, for batch and online tasks
      curam.util.workflow.impl.EnactmentService.startProcessInV3CompatibilityMode(
        kWorkflowProcess, enactmentStructs);
    }

  }

  /**
   * Defers a task until a later date.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already deferred.</li>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * <li>If the restart date is today or earlier.</li>
   * <li>If the restart date is after the task deadline.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be deferred.
   * @param restartDate The date the task is to be restarted.
   * @param comment A comment that indicates why the task is being deferred.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void defer(final long taskID, final Date restartDate,
    final String comment, final int versionNo) throws AppException,
      InformationalException {

    final String userName = TransactionInfo.getProgramUser();

    validateDefer(taskID, userName, restartDate);

    // If the restartDate field is blank, set the default value of "0001-01-01"
    // to empty
    String newValue = CuramConst.gkEmpty;

    if (!restartDate.isZero()) {
      // Set the restartDate to the restart date entered by the user
      newValue = Long.toString(restartDate.asLong());
    }

    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      curam.codetable.TASKCHANGETYPE.DEFERRED, comment, newValue,
      CuramConst.gkEmpty, userName);

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    taskAdminObj.modifyStatus(taskID, curam.codetable.TASKSTATUS.DEFERRED,
      versionNo);

    final TaskOptimisticLockingDetails taskOptimisticLockingDetails = taskAdminObj.readOptimisticLockingVersionNo(
      taskID);

    taskAdminObj.modifyRestartTime(taskID, restartDate.getDateTime(),
      taskOptimisticLockingDetails.versionNo);
  }

  /**
   * Restarts a task that had been previously deferred.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is not deferred.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be restarted.
   * @param comments A comment that indicates why the task is being restarted.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void restart(final long taskID, final String comments,
    final int versionNo) throws AppException, InformationalException {

    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskKey taskKey = new TaskKey();
    final TaskAndUserNameKey taskAndUserNameKey = new TaskAndUserNameKey();

    taskKey.taskID = taskID;

    final String userName = TransactionInfo.getProgramUser();

    taskAndUserNameKey.taskID = taskID;
    taskAndUserNameKey.userName = userName;

    validateRestart(taskAndUserNameKey);

    // Restart the task.
    taskAdminObj.modifyStatus(taskID, curam.codetable.TASKSTATUS.NOTSTARTED,
      versionNo);

    // Add a task history record.
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      TASKCHANGETYPE.RESTARTED, comments, CuramConst.gkEmpty,
      CuramConst.gkEmpty, userName);
  }

  /**
   * Forwards a task to a job, position, organization unit, user, work queue
   * or allocation target. A task history record is inserted for the task being
   * forwarded. All of the previous task assignment records specified for the
   * task are removed and new assignment records created.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.
   * <li>
   * <li>If a user is being forwarded the task and they have an active
   * allocation blocking period specified for them.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be forwarded.
   * @param forwardToID The identifier of the object who the task is being
   * forwarded.
   * @param forwardToType The type of the object who the task is being
   * forwarded.
   * @param comment A comment indicating why the task is being forwarded.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void forward(final long taskID, final String forwardToID,
    final String forwardToType, final String comment, final int versionNo)
    throws AppException, InformationalException {

    // The objects required for task manipulation.
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskKey taskKey = new TaskKey();

    taskKey.taskID = taskID;

    final TaskDetailsWithoutSnapshot taskReservedByDetails = taskAdminObj.readDetails(
      taskID);

    // Validate that the task can be forwarded. It must not be closed and it
    // must be reserved by the user
    validateForward(taskID, taskReservedByDetails.reservedBy, forwardToID,
      forwardToType);

    // Add a task history record for the forward operation.
    addTaskHistoryRecordForForwardTask(taskID, forwardToID, forwardToType,
      comment, taskReservedByDetails.reservedBy);

    // Update the reserved by and assigned fields for the task.
    taskAdminObj.modifyReservedBy(taskID, curam.core.impl.CuramConst.gkEmpty,
      curam.util.type.DateTime.getCurrentDateTime(), versionNo);

    // Remove all task assignment and task work queue assignment records
    final WorkResolver workResolverObj = WorkResolverFactory.newInstance();
    final WorkResolverTaskKey workResolverTaskKey = new WorkResolverTaskKey();

    workResolverTaskKey.taskID = taskID;

    workResolverObj.removeExistingTaskAssignments(workResolverTaskKey);

    // The objects required to resolve the work for the new allocation target.
    final DefaultWorkResolverAdapter workResolverAdapterObj = DefaultWorkResolverHelper.instantiateDefaultWorkResolverAdapter();

    final AllocationTargetList allocationTargets = new AllocationTargetList();
    final AllocationTargetDetails taskAllocationDetails = new AllocationTargetDetails();

    taskAllocationDetails.name = forwardToID;
    taskAllocationDetails.type = forwardToType;

    // Add the allocation details to the list
    allocationTargets.dtls.addRef(taskAllocationDetails);

    final TaskDetails taskDetails = new TaskDetails();

    taskDetails.taskID = taskID;

    // Resolve work allocation
    workResolverAdapterObj.resolveWork(taskDetails, allocationTargets, true);
  }

  /**
   * Modifies the total time worked on the specified task. The time worked
   * in this default implementation is passed in as a date time (in the
   * <code>totalTimeWorked</code> argument). The hours and minutes of this
   * date time are extracted from the specified date time and converted to
   * seconds. The time worked on for the task is thus stored in seconds.
   * <p>
   * A task history record is created containing the details of the
   * modification.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * <li>If the number of hours or minutes worked is less than 0</li>
   * <li>If the number of minutes worked is greater or equal to 60</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be modified.
   * @param totalTimeWorked The total time worked expressed as a date time.
   * @param timeHoursWorked The number of hours worked. This is not populated
   * in the default implementation but may be used in the future.
   * @param timeMinutesWorked The number of minutes worked. This is not
   * populated in the default implementation but may be used in the future.
   * @param comment A comment to be added.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void modifyTimeWorked(final long taskID,
    final DateTime totalTimeWorked, final long timeHoursWorked,
    final long timeMinutesWorked, final String comment, final int versionNo)
    throws AppException, InformationalException {

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();
    final WorkAllocationTask workAllocationTaskObj = WorkAllocationTaskFactory.newInstance();
    final TotalTimeWorked totalTimeWorkedForTask = new TotalTimeWorked();
    Calendar calendarObj = java.util.Calendar.getInstance();
    // Read existing task details
    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    // Convert old time worked to string value to be used in task history
    totalTimeWorkedForTask.totalTimeWorkedOnTask = taskDtls.totalTimeWorked;

    final TimeOnTaskHoursAndMinsStruct previousTotalTimeWorked = workAllocationTaskObj.convertTimeWorkedToHoursAndMins(
      totalTimeWorkedForTask);

    calendarObj = totalTimeWorked.getCalendar();

    final int hoursWorked = calendarObj.get(Calendar.HOUR_OF_DAY);
    final int minutesWorked = calendarObj.get(Calendar.MINUTE);

    // Validate the details about to be updated.
    validateModifyTimeWorked(taskID, hoursWorked, minutesWorked);

    // Get seconds value for total time worked
    final int hoursWorkedInSeconds = (int) (hoursWorked
      * curam.core.impl.CuramConst.gkNumberOfSecondsInHour);
    final int minutesWorkedInSeconds = (int) (minutesWorked
      * curam.core.impl.CuramConst.gkNumberOfSecondsInMinute);

    final int totalTime = hoursWorkedInSeconds + minutesWorkedInSeconds;

    taskAdminObj.modifyTotalTimeWorked(taskID, totalTime, taskDtls.versionNo);

    // Convert new time worked to string value to used in task history
    totalTimeWorkedForTask.totalTimeWorkedOnTask = totalTime;

    final TimeOnTaskHoursAndMinsStruct newTotalTimeWorked = workAllocationTaskObj.convertTimeWorkedToHoursAndMins(
      totalTimeWorkedForTask);

    // Create message string for time
    final AppException e1 = new AppException(
      curam.message.BPOTASKMANAGEMENT.INF_TIME_WORKED_ON_TASK);

    e1.arg(previousTotalTimeWorked.hours);
    e1.arg(previousTotalTimeWorked.minutes);

    // Create message string for time
    final AppException e2 = new AppException(
      curam.message.BPOTASKMANAGEMENT.INF_TIME_WORKED_ON_TASK);

    e2.arg(newTotalTimeWorked.hours);
    e2.arg(newTotalTimeWorked.minutes);

    // Insert the record
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      curam.codetable.TASKCHANGETYPE.TIMEWORKEDCHANGED, comment,
      e2.getMessage(ProgramLocale.getDefaultServerLocale()),
      e1.getMessage(ProgramLocale.getDefaultServerLocale()),
      TransactionInfo.getProgramUser());
  }

  /**
   * Modifies the priority of the specified task. A task history record is
   * created containing the details of the modification.
   * <P>
   * Exceptions are thrown under the following circumstances.
   * <ul>
   * <li>If the priority has not been specified.</li>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task whose priority will be updated.
   * @param priority The priority that the task will be updated to.
   * @param comments The comments associated with the priority modification
   * action. These will be stored in the associated task history record
   * written as a result of this action.
   * @param versionNo The optimistic locking version number of the task whose
   * priority is being updated.
   */
  @Override
  public void modifyPriority(final long taskID, final String priority,
    final String comments, final int versionNo) throws AppException,
      InformationalException {

    final String userName = TransactionInfo.getProgramUser();

    // Validate the priority details.
    validateModifyPriority(taskID, userName, priority);

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();
    final TaskKey taskKey = new TaskKey();

    taskKey.taskID = taskID;
    final TaskDetailsWithSnapshot taskDtls = taskAdminObj.readDetailsWithSnapshot(
      taskID);

    // Store the original priority as this is written in the task history
    // record.
    final String originalPriority = taskDtls.priority;

    taskDtls.priority = priority;
    taskDtls.versionNo = versionNo;
    taskAdminObj.modify(taskID, taskDtls.administrationSID,
      taskDtls.allowForwardInd, taskDtls.assignedDateTime, taskDtls.category,
      taskDtls.creationTime, taskDtls.deadTimeOverInd, taskDtls.overflowInd,
      taskDtls.priority, taskDtls.reservedBy, taskDtls.restartTime,
      taskDtls.status, taskDtls.totalTimeWorked, taskDtls.wdoSnapshot,
      taskDtls.versionNo);

    // Add the Task History record to record this action.
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      TASKCHANGETYPE.PRIORITYCHANGED, comments, priority, originalPriority,
      userName);
  }

  /**
   * Modifies the deadline of the specified task. If no deadline exists for the
   * task record, then an exception is thrown stating that this function cannot
   * be used to insert a new deadline. Otherwise the existing deadline details
   * are updated. A task history record is created containing the details of
   * the modification.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the deadline has not been specified.</li>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task whose deadline will be updated.
   * @param deadline The date and time that the task deadline will be
   * updated to.
   * @param comments The comments associated with the deadline modification
   * action. These will be stored in the associated task history record
   * written as a result of this action.
   * @param versionNo The optimistic locking version number of the deadline
   * record associated with the task.
   */
  @Override
  public void modifyDeadline(final long taskID, final DateTime deadline,
    final String comments, final int versionNo) throws AppException,
      InformationalException {

    final String userName = TransactionInfo.getProgramUser();

    // Validate the deadline details.
    validateModifyDeadline(taskID, userName, deadline);

    final WorkflowDeadlineAdmin workflowDeadlineAdminObj = WorkflowDeadlineAdminFactory.newInstance();
    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();
    WorkflowDeadlineInfo workflowDeadlineDtls = new WorkflowDeadlineInfo();

    // Store the original value of the deadline as this will be used in the
    // task history record that is created as a result of this action.
    DateTime originalDeadline = DateTime.kZeroDateTime;

    try {
      workflowDeadlineDtls = workflowDeadlineAdminObj.readDeadlineDetailsByTaskID(
        taskID);

      // Modify the existing record.
      originalDeadline = workflowDeadlineDtls.deadlineTime;
      // This is an existing record so just update the details.
      workflowDeadlineAdminObj.modifyDeadline(taskID, deadline,
        workflowDeadlineDtls.versionNo);
    } catch (final AppException e) {
      // If there is no deadline specified for this task, then throw the
      // appropriate exception as this function cannot be used to create a new
      // deadline.
      throw new AppException(
        BPOTASKMANAGEMENT.ERR_TASK_NO_DEADLINE_CANNOT_CREATE_NEW_DEADLINE);
    }

    // Add the Task History record to record this action.
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      TASKCHANGETYPE.DEADLINECHANGED, comments,
      Long.toString(deadline.asLong()),
      originalDeadline.equals(DateTime.kZeroDateTime)
      ? CuramConst.gkEmpty
      : Long.toString(originalDeadline.asLong()),
      userName);
  }

  /**
   * Reallocates a task. Reallocation of a task invokes the tasks initial
   * allocation strategy. This results in the task being made available to the
   * organizational objects, users or work queues to which it was originally
   * available to. A task history record is created containing the details of
   * the task reallocation.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be reallocated.
   * @param comment A comment to be added.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void reallocate(final long taskID, final String comment,
    final int versionNo) throws AppException, InformationalException {

    // Task object
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    // Task Key
    final TaskKey taskKey = new TaskKey();

    // Objects used for inserting a task history record.
    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    taskKey.taskID = taskID;
    final TaskDetailsWithoutSnapshot taskReservedByDetails = taskAdminObj.readDetails(
      taskID);

    // Validate reallocate
    validateReallocate(taskID, taskReservedByDetails.reservedBy);

    // Add a task history record outlining the details of the
    // task reallocation.
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      TASKCHANGETYPE.REALLOCATION, comment, CuramConst.gkEmpty,
      taskReservedByDetails.reservedBy, TransactionInfo.getProgramUser());

    // Reallocate the task.
    TaskAllocationAdmin.reallocateTask(taskKey);
  }

  /**
   * Adds the task to the user's <code>My Tasks</code> list. A task history
   * record is created containing the details of the action.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is already contained in the My Tasks list of the specified
   * user or the My Tasks list of some other user.</li>
   * <li>If the task is not available to the user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be added to the My Tasks
   * list.
   * @param comment A comment to be added.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void getTask(final long taskID, final String comment,
    final int versionNo) throws AppException, InformationalException {

    final UsersKey usersKey = new UsersKey();

    final String userName = TransactionInfo.getProgramUser();

    validateAddToUserTaskList(taskID, userName);

    // Assign user name key to read user full name
    usersKey.userName = userName;

    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      curam.codetable.TASKCHANGETYPE.RESERVED, comment, userName,
      CuramConst.gkEmpty, userName);

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    taskAdminObj.modifyReservedBy(taskID, userName,
      DateTime.getCurrentDateTime(), versionNo);
  }

  /**
   * Makes the specified task available to the organization object, user or work
   * queue that it was previously available to. A task history record is created
   * for the action.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be made available.
   * @param comment A comment to be added indicating why the task is being made
   * available.
   * @param versionNo The optimistic locking version number of the task.
   */
  @Override
  public void makeAvailable(final long taskID, final String comment,
    final int versionNo) throws AppException, InformationalException {

    final String userName = TransactionInfo.getProgramUser();

    validateMakeAvailable(taskID, userName);

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    final String previousReservedBy = taskDtls.reservedBy;

    taskAdminObj.modifyReservedBy(taskID, CuramConst.gkEmpty,
      DateTime.getCurrentDateTime(), versionNo);

    TaskOptimisticLockingDetails taskOptimisticLockingDetails = taskAdminObj.readOptimisticLockingVersionNo(
      taskID);

    taskAdminObj.modifyRestartTime(taskID, DateTime.kZeroDateTime,
      taskOptimisticLockingDetails.versionNo);

    if (curam.codetable.TASKSTATUS.DEFERRED.equals(taskDtls.status)) {

      taskOptimisticLockingDetails = taskAdminObj.readOptimisticLockingVersionNo(
        taskID);
      taskAdminObj.modifyStatus(taskID, curam.codetable.TASKSTATUS.NOTSTARTED,
        taskOptimisticLockingDetails.versionNo);
    }

    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      curam.codetable.TASKCHANGETYPE.UNRESERVED, comment, CuramConst.gkEmpty,
      previousReservedBy, userName);

  }

  /**
   * Executes the validations required before a comment is added to a task.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is closed</li>
   * </ul>
   *
   * @param taskID The identifier of the task which the comment is being added.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateAddComment(final long taskID) throws AppException,
      InformationalException {

    checkMaintainSecurity(taskID);

    // Create the task BPO
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskDetailsWithoutSnapshot taskStatusDetails = taskAdminObj.readDetails(
      taskID);

    // Check to see if the task status is set to closed
    if (taskStatusDetails.status.equals(TASKSTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_XRV_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Executes the validations required before a task is closed.
   * <P>
   * An exception is thrown in the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task being closed is part of the My Tasks list of another user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be closed.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateClose(final long taskID) throws AppException,
      InformationalException {

    final TaskAdmin taskObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    final TaskDetailsWithoutSnapshot taskDtls = taskObj.readDetails(taskID);

    if (taskDtls.status.equals(TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_ALREADY_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (!taskDtls.reservedBy.equals(TransactionInfo.getProgramUser())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_NOTRESERVED_BY_USER),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Executes the validations required before a task is created.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the priority field is empty.</li>
   * <li>If the subject field is empty.</li>
   * <li>If the deadline field contains a date time that is in the past.</li>
   * <li>If neither the <code>addToMyTasksInd</code> field nor the
   * <code>assignedTo</code> field are set.</li>
   * <li>If both the <code>addToMyTasksInd</code> and <code>assignedTo</code>
   * fields are set.</li>
   * <li>If the <code>addToMyTasksInd</code> field has been set and the
   * specified user has an active task redirection or allocation blocking period
   * specified for them.</li>
   * <li>If the assignee name does not match the assignee type.</li>
   * </ul>
   *
   * @param taskCreateDetails The new task details to be validated before
   * creating.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateCreate(final TaskCreateDetails taskCreateDetails)
    throws AppException, InformationalException {

    if (taskCreateDetails.priority.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_FV_PRIORITY_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (taskCreateDetails.subject.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_FV_SUBJECT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    if (!taskCreateDetails.deadlineDateTime.isZero()
      && !taskCreateDetails.deadlineDateTime.after(
        DateTime.getCurrentDateTime())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_FV_DEADLINE_NOT_FUTURE_DATE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // One of the add to my tasks or assigned to fields must be selected.
    if (!taskCreateDetails.reserveToMeInd
      && taskCreateDetails.assignedTo.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_XRV_MUST_BE_RESERVED_ASSIGNED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The add to my tasks and assigned to fields cannot both be populated
    // at the same time.
    if (taskCreateDetails.reserveToMeInd
      && taskCreateDetails.assignedTo.length() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_XRV_MUST_BE_RESERVED_ASSIGNED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Validate that if the add to my tasks indicator is set to true, than that
    // user must not have an active task redirection or task allocation
    // blocking period set up.
    if (taskCreateDetails.reserveToMeInd) {
      validateUserHasActiveTaskRedirectionOrBlockingPeriod();
    }

    // BEGIN, CR00091394, JM
    if (taskCreateDetails.assigneeType.equals(TARGETITEMTYPE.USER)
      && taskCreateDetails.assignedTo.length() != 0) {

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = taskCreateDetails.assignedTo;

      // Check to see that the user name entered is user
      final UserFullname userFullName = userAccessObj.getFullName(usersKey);

      if (StringUtil.isNullOrEmpty(userFullName.fullname)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            2);
      }

      validateUserHasActiveTaskBlockingPeriod(taskCreateDetails.assignedTo);

    } else if (taskCreateDetails.assigneeType.equals(
      TARGETITEMTYPE.EXTERNALUSER)
        && taskCreateDetails.assignedTo.length() != 0) {

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = taskCreateDetails.assignedTo;

      // Check to see that the user name entered is user.
      final UserFullname userFullName = userAccessObj.getFullName(usersKey);

      if (StringUtil.isNullOrEmpty(userFullName.fullname)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }

    } else if (taskCreateDetails.assigneeType.equals(TARGETITEMTYPE.ORGUNIT)
      && taskCreateDetails.assignedTo.length() != 0) {

      // Check to see if the assignee name value is an organization unit
      final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
      final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

      try {
        // try parse the assignedTo value, if this throws an error it means a
        // user name string value like 'superuser' has been passed down
        organisationUnitKey.organisationUnitID = Long.parseLong(
          taskCreateDetails.assignedTo);
      } catch (final NumberFormatException e) {
        // Not an organization unit so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }

      try {
        organisationUnitObj.read(organisationUnitKey);

      } catch (final RecordNotFoundException e) {

        // Not an organization unit so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }

    } else if (taskCreateDetails.assigneeType.equals(TARGETITEMTYPE.POSITION)
      && taskCreateDetails.assignedTo.length() != 0) {

      final Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
      final PositionKey positionKey = new PositionKey();

      try {
        // try parse the assignedTo value, if this throws an error it means a
        // user name string value like 'superuser' has been passed down
        positionKey.positionID = Long.parseLong(taskCreateDetails.assignedTo);
      } catch (final NumberFormatException e) {
        // Not a position so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }

      try {
        positionObj.read(positionKey);
      } catch (final RecordNotFoundException e) {
        // Not a position so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }

    } else if (taskCreateDetails.assigneeType.equals(TARGETITEMTYPE.JOB)
      && taskCreateDetails.assignedTo.length() != 0) {

      final Job jobObj = JobFactory.newInstance();
      final curam.core.sl.entity.struct.JobKey jobKey = new curam.core.sl.entity.struct.JobKey();

      try {

        // try parse the assignedTo value, if this throws an error it means
        // a user name string value like 'superuser' has been passed down
        jobKey.jobID = Long.parseLong(taskCreateDetails.assignedTo);
      } catch (final NumberFormatException e) {
        // Not a position so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }

      try {
        jobObj.read(jobKey);

      } catch (final RecordNotFoundException e) {

        // Not a position so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }

    } else if (taskCreateDetails.assigneeType.equals(TARGETITEMTYPE.WORKQUEUE)
      && taskCreateDetails.assignedTo.length() != 0) {

      final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
      final WorkQueueKey workQueueKey = new WorkQueueKey();

      try {

        // try parse the assignedTo value, if this throws an error it means a
        // user name string value like 'superuser' has been passed down
        workQueueKey.workQueueID = Long.parseLong(taskCreateDetails.assignedTo);

      } catch (final NumberFormatException e) {

        // Not a work queue so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);

      }

      try {
        workQueueObj.read(workQueueKey);

      } catch (final RecordNotFoundException e) {

        // Not a work queue so throw an exception
        throw new AppException(BPOTASKMANAGEMENT.ERR_TASK_ASSIGNTO_INVALID_TYPE);
      }
    }
  }

  /**
   * Checks if the supplied user has an active task allocation blocking period
   * and if so throws the appropriate exception.
   *
   * @param userName The name of the user to check for an active allocation
   * blocking period.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateUserHasActiveTaskBlockingPeriod(final String userName)
    throws AppException, InformationalException {

    /*
     * If there is an active task blocking period in place for this user,
     * then throw the appropriate exception.
     */

    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    final TaskRedirection taskRedirection = TaskRedirectionFactory.newInstance();
    final UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

    userNameAndDateTimeKey.userName = userName;
    userNameAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();

    final TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails = taskRedirection.readTaskRedirectionOrAllocationBlockingPeriodForUser(
      userNameAndDateTimeKey);

    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails == null) {
      // No active task redirection or task allocation blocking period.
      return;
    }

    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.blockTaskAllocation) {
      final AppException appExp = new AppException(
        BPOTASKMANAGEMENT.ERR_CREATE_TASK_SET_ACTIVE_TASK_ALLOCATION_BLOCKING_PERIOD);

      usersKey.userName = userName;
      appExp.arg(usersObj.readUserFullname(usersKey).fullname);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        appExp,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Checks if the supplied user has an active task redirection
   * or task allocation blocking period and if so throws the appropriate
   * exception.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateUserHasActiveTaskRedirectionOrBlockingPeriod()
    throws AppException, InformationalException {

    // If there is an active task redirection period in place for this user,
    // then throw the appropriate exception.

    final TaskRedirection taskRedirection = TaskRedirectionFactory.newInstance();
    final UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

    userNameAndDateTimeKey.userName = TransactionInfo.getProgramUser();
    userNameAndDateTimeKey.currentDateTime = curam.util.type.DateTime.getCurrentDateTime();

    final TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails = taskRedirection.readTaskRedirectionOrAllocationBlockingPeriodForUser(
      userNameAndDateTimeKey);

    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails == null) {
      // No active task redirection or task allocation blocking period.
      return;
    }

    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.blockTaskAllocation) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_CREATE_TASK_RESERVE_TO_ME_SET_ACTIVE_TASK_ALLOCATION_BLOCKING_PERIOD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_CREATE_TASK_RESERVE_TO_ME_SET_ACTIVE_TASK_REDIRECTION_PERIOD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Executes the validations required before a task is deferred.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already deferred.</li>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * <li>If the restart date is today or earlier.</li>
   * <li>If the restart date is after the task deadline.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be deferred.
   * @param userName The name of the user.
   * @param restartDate The date the task is to be restarted.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateDefer(final long taskID, final String userName,
    final Date restartDate) throws AppException, InformationalException {

    checkMaintainSecurity(taskID);

    final TaskAdmin taskObj = TaskAdminFactory.newInstance();

    final TaskDetailsWithDueDate taskFullDtlsWithDueDate = taskObj.readTaskDetailsWithDueDate(
      taskID);

    if (TASKSTATUS.DEFERRED.equals(taskFullDtlsWithDueDate.status)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_ALREADY_DEFERRED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (TASKSTATUS.CLOSED.equals(taskFullDtlsWithDueDate.status)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_CLOSED_CANNOT_BE_DEFERRED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The task must be part of the users task list before this action
    // is allowed.
    if (!taskFullDtlsWithDueDate.reservedBy.equals(userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_MUST_BE_RESERVED_TO_YOU),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // restart time where populated must not be later than the
    // current date
    if (!restartDate.isZero()) { // is the restart time populated
      // is the restart date before the current date.
      if (restartDate.before(Date.getCurrentDate())
        || restartDate.equals(Date.getCurrentDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOTASKMANAGEMENT.ERR_RESTART_DATE_MUST_BE_LATER_THAN_CURRENT_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // does the task have a deadline time
      if (!taskFullDtlsWithDueDate.dueDateTime.isZero()) {

        // if it does, then check if the restart date is before the tasks
        // deadline date.
        if (restartDate.getDateTime().after(taskFullDtlsWithDueDate.dueDateTime)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOTASKMANAGEMENT.ERR_RESTART_DATE_MUST_BE_EARLIER_THAN_TASK_DEADLINE),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Executes the validations required before a task is restarted.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is not deferred.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskAndUserNameKey task details to be validated
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateRestart(TaskAndUserNameKey taskAndUserNameKey)
    throws AppException, InformationalException {

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskAndUserNameKey.taskID);

    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(
      taskAndUserNameKey.taskID);

    if (!TASKSTATUS.DEFERRED.equals(taskDtls.status)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_NOT_DEFERRED_AND_CANNOT_BE_RESTARTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (!taskAndUserNameKey.userName.equals(taskDtls.reservedBy)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_NOT_RESERVED_BY_YOU_CANNOT_BE_RESTARTED_BY_YOU),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Executes the validations required before a task is forwarded. These
   * validations include:
   * <ul>
   * <li>The task cannot be closed.
   * <li>The task must be part of the users task list before forwarding it is
   * allowed.
   * <li>The task cannot be forward to a user if there is a task allocation
   * blocking period currently active for that user.
   * </ul>
   *
   * @param taskID The identifier of the task to be forwarded.
   * @param userName The name of the user.
   * @param forwardToID The identifier of the object who the task is being
   * forwarded.
   * @param forwardToType The type of the object who the task is being
   * forwarded.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateForward(final long taskID, final String userName,
    final String forwardToID, final String forwardToType)
    throws AppException, InformationalException {

    // The objects required to read the task status.
    final TaskAdmin taskObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    final TaskDetailsWithoutSnapshot taskStatusDetails = taskObj.readDetails(
      taskID);

    // The task must not be closed.
    if (taskStatusDetails.status.equals(TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_XRV_FORWARD_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The task must be part of the users task list before this action
    // is allowed.
    if (!userName.equals(
      curam.util.transaction.TransactionInfo.getProgramUser())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_CANNOT_BE_FORWARDED_BY_YOU),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // If the Target User has enabled Task allocation blocking entry
    // then task cannot be forwarded.
    if (TARGETITEMTYPE.USER.equals(forwardToType)) {

      final TaskRedirection taskRedirectionObj = TaskRedirectionFactory.newInstance();

      final UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

      userNameAndDateTimeKey.userName = forwardToID;
      userNameAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();

      final TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails = taskRedirectionObj.readTaskRedirectionOrAllocationBlockingPeriodForUser(
        userNameAndDateTimeKey);

      if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails != null
        && activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.blockTaskAllocation) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOTASKMANAGEMENT.ERR_TASK_FORWARD_ALLOCATION_BLOCKED_FOR_USER),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  /**
   * Executes the validations required before the time worked on a task
   * can be modified.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * <li>If the number of hours or minutes worked is less than 0</li>
   * <li>If the number of minutes worked is greater or equal to 60</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be modified.
   * @param timeHoursWorked The number of hours worked.
   * @param timeMinutesWorked The number of minutes worked.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateModifyTimeWorked(final long taskID,
    final long timeHoursWorked, final long timeMinutesWorked)
    throws AppException, InformationalException {

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    if (taskDtls.status.equals(curam.codetable.TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOTASKMANAGEMENT.ERR_TASK_CLOSED_TIME_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The task must be part of the users task list before this action
    // is allowed.
    if (!taskDtls.reservedBy.equals(
      curam.util.transaction.TransactionInfo.getProgramUser())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOTASKMANAGEMENT.ERR_TASK_NOT_RESERVED_BY_USER_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (timeHoursWorked < kZero) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOTASKMANAGEMENT.ERR_TASK_TIMEWORKED_HOURS_LESS_THAN_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (timeMinutesWorked < kZero) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOTASKMANAGEMENT.ERR_TASK_TIMEWORKED_MINS_LESS_THAN_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (timeMinutesWorked >= kSixty) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOTASKMANAGEMENT.ERR_TASK_TIMEWORKED_MINS_GREATER_THAN_SIXTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Executes the validations required before a task's priority can be modified.
   * <P>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>If the priority has not been specified.</li>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task whose priority will be updated.
   * @param userName The name of the user who is updating the priority.
   * @param priority The priority that the task will be updated to.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateModifyPriority(final long taskID,
    final String userName, final String priority) throws AppException,
      InformationalException {

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    // The priority must be specified.
    if (StringUtil.isNullOrEmpty(priority)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_FV_PRIORITY_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    // The priority of a closed task cannot be modified.
    if (TASKSTATUS.CLOSED.equals(taskDtls.status)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_CANNOT_MODIFY_PRIORITY_CLOSED_TASK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The priority of a task cannot be modified if the task is not part of the
    // users task list before this action
    if (!taskDtls.reservedBy.equals(userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_CANNOT_MODIFY_PRIORITY_NOT_RESERVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Executes the validations required before a task's deadline can be modified.
   * <P>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>If the deadline has not been specified.</li>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task whose deadline will be updated.
   * @param userName The name of the user who is updating the deadline.
   * @param deadline The deadline that the task will be updated to.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateModifyDeadline(final long taskID,
    final String userName, final DateTime deadline) throws AppException,
      InformationalException {

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    // The deadline must be specified.
    if (deadline == null || deadline.equals(DateTime.kZeroDateTime)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_FV_DEADLINE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    // The deadline of a task cannot be modified if the task is closed.
    if (TASKSTATUS.CLOSED.equals(taskDtls.status)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_CANNOT_MODIFY_DEADLINE_CLOSED_TASK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The task must be part of the users task list before it's deadline
    // can be modified.
    if (!taskDtls.reservedBy.equals(userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_CANNOT_MODIFY_DEADLINE_NOT_RESERVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The deadline date time must be a date time in the future.
    if (deadline.before(DateTime.getCurrentDateTime())
      || deadline.equals(DateTime.getCurrentDateTime())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_FV_DEADLINE_NOT_FUTURE_DATE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
  }

  /**
   * Executes the validations required before a task can be reallocated.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be reallocated.
   * @param userName The name of the user.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateReallocate(final long taskID, final String userName)
    throws AppException, InformationalException {

    // Task object
    final TaskAdmin taskObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    final TaskDetailsWithoutSnapshot taskStatusDetails = taskObj.readDetails(
      taskID);

    // Task must not be closed.
    if (taskStatusDetails.status.equals(TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_XRV_REALLOCATE_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The task must be part of the users task list before this action
    // is allowed.
    if (!userName.equals(
      curam.util.transaction.TransactionInfo.getProgramUser())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_TASK_MUST_BE_RESERVED_TO_YOU_TO_REALLOCATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Executes the validations required before a task can be added to a user's
   * <code>My Tasks</code> list.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is already contained in the My Tasks list of the specified
   * user or the My Tasks list of some other user.</li>
   * <li>If the task is not available to the user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be added to the My Tasks
   * list.
   * @param userName The name of the user.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateAddToUserTaskList(final long taskID,
    final String userName) throws AppException, InformationalException {

    final TaskManagementTaskKey taskManagementTaskKey = new TaskManagementTaskKey();
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();
    final Task_waKey task_waKey = new Task_waKey();

    checkMaintainSecurity(taskID);

    taskManagementTaskKey.taskID = taskID;

    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    if (taskDtls.status.equals(TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_CANNOT_RESERVE_CLOSED_TASK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (taskDtls.reservedBy.length() != 0) {
      if (userName.equals(taskDtls.reservedBy)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOTASKMANAGEMENT.ERR_TASK_ALREADY_RESERVED_BY_YOU),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOTASKMANAGEMENT.ERR_TASK_ALREADY_RESERVED_BY_ANOTHER_USER),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    task_waKey.taskID = taskID;

    // Check that either the task is assigned to the current user or else
    // that the task is assigned to a work queue to which the current user
    // is subscribed. If neither, the exception below gets thrown.

    final TaskIDRelatedIDAndTypeKey taskIDRelatedIDAndTypeKey = new TaskIDRelatedIDAndTypeKey();

    taskIDRelatedIDAndTypeKey.relatedName = userName;
    taskIDRelatedIDAndTypeKey.assigneeType = TARGETITEMTYPE.USER;
    taskIDRelatedIDAndTypeKey.taskID = taskID;

    // To check whether a task is assigned to an user who is the current user.
    final TaskAssignmentNameDetailsList taskAssignmentNameDetailsList = taskAssignmentObj.searchUserAssignmentsWithNamesByTaskID(
      taskIDRelatedIDAndTypeKey);

    if (taskAssignmentNameDetailsList.dtls.size() > 0) {
      return;
    }

    final TaskIDAndUserNameKey taskIDAndUserNameKey = new TaskIDAndUserNameKey();

    taskIDAndUserNameKey.taskID = taskID;
    taskIDAndUserNameKey.userName = userName;

    if (isTaskAssignedToUser(taskIDAndUserNameKey).flag) {
      return;
    }

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
      new AppException(BPOTASKMANAGEMENT.ERR_TASK_MUST_BE_ASSIGNED_TO_YOU),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

  }

  /**
   * Executes the validations required before a task can be made available.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>If the task is already closed.</li>
   * <li>If the task is not in the My Tasks list for the specified user.</li>
   * </ul>
   *
   * @param taskID The identifier of the task to be made available.
   * @param userName The name of the user.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateMakeAvailable(final long taskID,
    final String userName) throws AppException, InformationalException {

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    checkMaintainSecurity(taskID);

    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(taskID);

    if (taskDtls.status.equals(TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOTASKMANAGEMENT.ERR_TASK_CLOSED_CANNOT_BE_UNRESERVED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!userName.equals(taskDtls.reservedBy)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOTASKMANAGEMENT.ERR_NOT_RESERVED_AND_CANNOT_BE_UNRESERVED_BY_YOU),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Resolves the name of the organization object to whom the task is being
   * forwarded.
   *
   * @param forwardToID The identifier of the object who the task is being
   * forwarded.
   * @param forwardToType The type of the object who the task is being
   * forwarded.
   *
   * @return The name of the organization object to whom the task is being
   * forwarded.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected TaskForwardedTo resolveTaskForwardedTo(final String forwardToID,
    final String forwardToType) throws AppException, InformationalException {

    // Needed for both position and organization unit task history.
    final OrganisationStructure organisationStructureObj = OrganisationStructureFactory.newInstance();
    final OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();
    OrganisationStructureID organisationStructureID = new OrganisationStructureID();

    // variable to store the name of the organization object to whom the task
    // is being forwarded
    final TaskForwardedTo taskForwardedTo = new TaskForwardedTo();

    organisationStructureStatus.statusCode = ORGSTRUCTURESTATUS.ACTIVE;

    if (forwardToType.equals(TARGETITEMTYPE.POSITION)
      || forwardToType.equals(TARGETITEMTYPE.ORGUNIT)) {
      try {
        organisationStructureID = organisationStructureObj.readActiveOrganisationStructureID(
          organisationStructureStatus);
      } catch (final RecordNotFoundException re) {
        throw new AppException(
          BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
      }
    }
    if (forwardToType.equals(TARGETITEMTYPE.WORKQUEUE)) {
      // Look up the work queue name for Task History
      final curam.core.sl.intf.WorkQueue workQueueObj = curam.core.sl.fact.WorkQueueFactory.newInstance();

      final curam.core.sl.struct.ReadWorkQueueKey readWorkQueueKey = new curam.core.sl.struct.ReadWorkQueueKey();

      // Set the Work Queue ID as the key
      readWorkQueueKey.key.workQueueID = Long.parseLong(forwardToID);
      final ReadWorkQueueDetails readWorkQueueDetails = workQueueObj.read(
        readWorkQueueKey);

      taskForwardedTo.forwardedToName = readWorkQueueDetails.dtls.name;
    } else if (forwardToType.equals(TARGETITEMTYPE.POSITION)) {

      final curam.core.sl.intf.Position positionObj = PositionFactory.newInstance();

      // entity layer object to read OrgUnitPositionLink details as we need
      // the organization Unit ID
      final OrgUnitPositionLink orgUnitPositionLink = OrgUnitPositionLinkFactory.newInstance();

      // key to read the Org Unit Position Link details
      final OrgStructurePositionAndStatusKey orgStructurePositionAndStatusKey = new OrgStructurePositionAndStatusKey();

      // assign the values for key
      orgStructurePositionAndStatusKey.organisationStructureID = organisationStructureID.organisationStructureID;
      orgStructurePositionAndStatusKey.positionID = Long.parseLong(forwardToID);
      orgStructurePositionAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;

      // variable to store the OrgUnitPositionLink record
      final OrgUnitPositionLinkDetails orgUnitPositionLinkDetails = orgUnitPositionLink.readByOrgStructurePositionAndStatus(
        orgStructurePositionAndStatusKey);

      final OrgStructureAndPositionKey orgStructAndPos = new OrgStructureAndPositionKey();

      orgStructAndPos.orgStructureAndPositionKey.organisationStructureID = organisationStructureID.organisationStructureID;
      orgStructAndPos.orgStructureAndPositionKey.positionID = Long.parseLong(
        forwardToID);
      // assign the organization unit to input key of viewPosition method
      orgStructAndPos.orgStructureAndPositionKey.organisationUnitID = orgUnitPositionLinkDetails.organisationUnitID;

      final ViewPositionDetails positionDetails = positionObj.viewPosition(
        orgStructAndPos);

      taskForwardedTo.forwardedToName = positionDetails.viewPositionDetails.positionName;

    } else if (forwardToType.equals(TARGETITEMTYPE.JOB)) {
      final curam.core.sl.intf.Job jobObj = curam.core.sl.fact.JobFactory.newInstance();
      final JobKey jobKey = new JobKey();

      jobKey.jobKey.jobID = Long.valueOf(forwardToID).longValue();
      final JobDetails jobDetails = jobObj.viewJob(jobKey);

      taskForwardedTo.forwardedToName = jobDetails.jobDtls.name;
    } else if (forwardToType.equals(TARGETITEMTYPE.ORGUNIT)) {

      final OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new OrgStructureAndOrgUnitKey();

      orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = Long.valueOf(forwardToID).longValue();
      orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = organisationStructureID.organisationStructureID;

      final OrganisationUnit organisationUnit = OrganisationUnitFactory.newInstance();
      final ViewOrgUnitDetails viewOrgUnitDetails = organisationUnit.viewOrganisationUnit(
        orgStructureAndOrgUnitKey);

      taskForwardedTo.forwardedToName = viewOrgUnitDetails.organisationUnitDetails.name;
    } else {
      taskForwardedTo.forwardedToName = forwardToID;
    }
    return taskForwardedTo;
  }

  /**
   * Determines whether a task is assigned to a user either directly or
   * indirectly via an organizational object or a work queue.
   * There are few scenarios through which the user is indirectly assigned to
   * the task:
   * (1) The task is assigned to the work queue and the user subscribes to
   * that work queue.
   * (2) The task is assigned to any organization object(job, organization unit
   * and position) and the user subscribes to one of the organization units.
   * (3) The task is assigned to the work queue. And the user is assigned to one
   * of the organization units. And one of the organization units subscribes to
   * that work queue.
   *
   * @param key key The task identifier and user name.
   *
   * @return A flag that indicates whether the task is assigned to a user.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected BooleanIndicator isTaskAssignedToUser(
    final TaskIDAndUserNameKey key) throws AppException,
      InformationalException {

    // Find whether any task is assigned

    // Create a return object
    final BooleanIndicator indicator = new BooleanIndicator();

    // User work queue tasks
    int count = countTaskAssignmentForUserWorkQueueByTaskID(key).numberOfRecords;

    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // User job tasks
    count = countTaskAssignmentForUserJobByTaskID(key).numberOfRecords;
    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // User position tasks
    count = countTaskAssignmentForUserPositionByTaskID(key).numberOfRecords;
    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // User org unit tasks
    count = countTaskAssignmentForUserOrgUnitByTaskID(key).numberOfRecords;
    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // User WorkQueue organization unit tasks
    count = countTaskAssignmentForWorkQueueOrgObjectByTaskID(key, WQSUBSORGOBJECTTYPE.ORGUNIT).numberOfRecords;
    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // User WorkQueue position tasks
    count = countTaskAssignmentForWorkQueueOrgObjectByTaskID(key, WQSUBSORGOBJECTTYPE.POSITION).numberOfRecords;
    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // User WorkQueue job tasks
    count = countTaskAssignmentForWorkQueueOrgObjectByTaskID(key, WQSUBSORGOBJECTTYPE.JOB).numberOfRecords;
    if (count > 0) {
      indicator.flag = true;
      return indicator;
    }

    // No indirect assignment
    return indicator;
  }

  /**
   * Adds a task history record containing the details of a task
   * forwarding operation.
   *
   * @param taskID The identifier of the task to be forwarded.
   * @param forwardToID The identifier of the object who the task is being
   * forwarded.
   * @param forwardToType The type of the object who the task is being
   * forwarded.
   * @param comment A comment indicating why the task is being forwarded.
   * @param reservedBy The name of the user, if any, who has reserved the
   * task.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void addTaskHistoryRecordForForwardTask(final long taskID,
    final String forwardToID, final String forwardToType,
    final String comment, final String reservedBy) throws AppException,
      InformationalException {

    // The objects required to insert a task history record.
    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    // Resolve the name of the organization object to which task is being
    // forwarded and add to taskHistoryDetails record
    final TaskForwardedTo taskForwardedTo = resolveTaskForwardedTo(forwardToID,
      forwardToType);

    // Insert the task history
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      TASKCHANGETYPE.FORWARDED, comment, taskForwardedTo.forwardedToName,
      reservedBy, TransactionInfo.getProgramUser());
  }

  /**
   * Returns the count of assigned tasks for the organizational unit assignee
   * type and by task ID and user name.
   *
   * @param key The task identifier and user name.
   *
   * @return A count of assigned tasks for the organizational unit assignee
   * type and by task identifier and user name.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected Count countTaskAssignmentForUserOrgUnitByTaskID(
    final TaskIDAndUserNameKey key) throws AppException,
      InformationalException {

    // Create an instance of the entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // Populate the required fields
    key.assigneeType = TARGETITEMTYPE.ORGUNIT;
    key.currentDate = Date.getCurrentDate();
    key.recordStatus = RECORDSTATUS.NORMAL;

    return taskAssignmentObj.countTaskAssignmentForUserOrgUnitByTaskID(key);
  }

  /**
   * Returns the count of assigned tasks for the work queue assignee
   * type, the subscriber type and by task ID and user name.
   *
   * @param key The task identifier and user name.
   * @param subsriberType It is position, org unit or jopb.
   *
   * @return A count of assigned tasks for the work queue assignee
   * type and by task identifier and user name.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected Count countTaskAssignmentForWorkQueueOrgObjectByTaskID(
    final TaskIDAndUserNameKey key, String subsriberType)
    throws AppException, InformationalException {

    // Create an instance of the entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // Populate the required fields
    key.assigneeType = TARGETITEMTYPE.WORKQUEUE;
    key.currentDate = Date.getCurrentDate();
    key.recordStatus = RECORDSTATUS.NORMAL;
    key.subscriberType = subsriberType;

    if (subsriberType.equals(WQSUBSORGOBJECTTYPE.ORGUNIT)) {
      return taskAssignmentObj.countTaskAssignmentForWorkQueueOrgUnitByTaskID(
        key);
    } else if (subsriberType.equals(WQSUBSORGOBJECTTYPE.JOB)) {
      return taskAssignmentObj.countTaskAssignmentForWorkQueueJobByTaskID(key);
    } else if (subsriberType.equals(WQSUBSORGOBJECTTYPE.POSITION)) {
      return taskAssignmentObj.countTaskAssignmentForWorkQueuePositionByTaskID(
        key);
    }
    final Count ct = new Count();

    return ct;
  }

  /**
   * Returns the count of assigned tasks for a work queue assignee type by
   * task identifier and user name.
   *
   * @param key The task identifier and user name.
   *
   * @return A count of assigned tasks for the work queue assignee type
   * and by task identifier and user name.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected Count countTaskAssignmentForUserWorkQueueByTaskID(
    final TaskIDAndUserNameKey key) throws AppException,
      InformationalException {

    // Create an instance of the entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // Populate the required fields
    key.assigneeType = TARGETITEMTYPE.WORKQUEUE;
    key.currentDate = Date.getCurrentDate();
    key.recordStatus = RECORDSTATUS.NORMAL;
    key.subscriberType = TARGETITEMTYPE.USER;

    return taskAssignmentObj.countTaskAssignmentForUserWorkQueueByTaskID(key);
  }

  /**
   * Returns the count of assigned tasks for a position assignee type by
   * task identifier and user name.
   *
   * @param key The task identifier and user name.
   *
   * @return A count of assigned tasks for the position assignee type
   * and by task identifier and user name.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected Count countTaskAssignmentForUserPositionByTaskID(
    final TaskIDAndUserNameKey key) throws AppException,
      InformationalException {

    // Create an instance of the entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // Populate the required fields
    key.assigneeType = TARGETITEMTYPE.POSITION;
    key.currentDate = Date.getCurrentDate();
    key.recordStatus = RECORDSTATUS.NORMAL;

    return taskAssignmentObj.countTaskAssignmentForUserPositionByTaskID(key);
  }

  /**
   * Returns the count of assigned tasks for a job assignee type by
   * task identifier and user name.
   *
   * @param key The task identifier and user name.
   *
   * @return A count of assigned tasks for the job assignee type
   * and by task identifier and user name.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected Count countTaskAssignmentForUserJobByTaskID(
    final TaskIDAndUserNameKey key) throws AppException,
      InformationalException {

    // Create an instance of the entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // Populate the required fields
    key.assigneeType = TARGETITEMTYPE.JOB;
    key.currentDate = Date.getCurrentDate();
    key.recordStatus = RECORDSTATUS.NORMAL;

    return taskAssignmentObj.countTaskAssignmentForUserJobByTaskID(key);
  }

  /**
   * Checks if the user has maintain rights for the task being processed.
   *
   * @param taskId The task identifier for which maintain rights is being
   * checked.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void checkMaintainSecurity(long taskId) throws AppException,
      InformationalException {

    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();
    final ParticipantSecurityCheckKey participantKey = new ParticipantSecurityCheckKey();
    // getting Case ID
    final BusinessObjectAssociationAdmin bizObjAssociationAdminObj = BusinessObjectAssociationAdminFactory.newInstance();

    final BizObjectAssociationDetailsList bizObjAssociationDtlsList = bizObjAssociationAdminObj.searchByTaskID(
      taskId);

    for (final BizObjectAssociationDetails bizObjAssociationDtls : bizObjAssociationDtlsList.dtls.items()) {
      if (bizObjAssociationDtls.bizObjectType.equals(BUSINESSOBJECTTYPE.CASE)) {

        // Check security on this case (linkedID)
        caseSecurityCheckKey.caseID = bizObjAssociationDtls.bizObjectID;

        // BEGIN, CR00291090, SG
      } else if (BUSINESSOBJECTTYPE.PERSON.equals(
        bizObjAssociationDtls.bizObjectType)) {
        // END, CR00291090
        participantKey.participantID = bizObjAssociationDtls.bizObjectID;
      }
    }

    // Security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();
    final curam.core.sl.entity.struct.TaskKey taskIDKey = new curam.core.sl.entity.struct.TaskKey();

    taskIDKey.taskID = taskId;
    boolean isTaskUser = false;
    final TaskAssignmentDtlsList taskAssignmentDtlsList = taskAssignmentObj.searchAssignmentsByTaskID(
      taskIDKey);

    for (final TaskAssignmentDtls taskAssignmentDtls : taskAssignmentDtlsList.dtls.items()) {

      if (systemUserDtls.userName.equals(taskAssignmentDtls.relatedName)) {
        isTaskUser = true;
        break;
      }
    }

    if (!isTaskUser) {

      if (CuramConst.gkZero != caseSecurityCheckKey.caseID) {
        dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
          caseSecurityCheckKey);

        if (!dataBasedSecurityResult.result) {
          if (dataBasedSecurityResult.readOnly) {
            throw new AppException(
              GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
          } else if (dataBasedSecurityResult.restricted) {
            throw new AppException(
              curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
          } else {
            throw new AppException(
              GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
          }
        }
      } else {
        if (CuramConst.gkZero != participantKey.participantID) {
          participantKey.type = LOCATIONACCESSTYPE.MAINTAIN;
          dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
            participantKey);

          if (!dataBasedSecurityResult.result) {
            throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
          }
        }
      }
    }
  }
}
