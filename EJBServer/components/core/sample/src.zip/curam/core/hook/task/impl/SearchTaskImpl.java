/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.hook.task.impl;


import com.google.inject.Inject;
import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.USERSEARCHTYPE;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.TaskAssignmentFactory;
import curam.core.sl.fact.UserSearchFilterFactory;
import curam.core.sl.impl.InboxListSize;
import curam.core.sl.impl.TaskSort;
import curam.core.sl.struct.BusinessObjectKey;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.TaskAssigneeTypeKey;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskQueryKey;
import curam.core.sl.struct.TaskQueryResultDetails;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.sl.struct.UserNameAndUserSearchTypeDetails;
import curam.core.sl.struct.UserSearchFilterData;
import curam.core.sl.struct.UserSearchFilterDataList;
import curam.core.struct.AvailableTaskSearchResult;
import curam.core.struct.Count;
import curam.core.struct.OrganisationObjectDetails;
import curam.core.struct.PriorityCodeDetails;
import curam.message.BPOINBOX;
import curam.message.BPOTASKSEARCH;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DataAccess;
import curam.util.dataaccess.DataAccessFactory;
import curam.util.dataaccess.DatabaseMetaData;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.dataaccess.ReadmultiOperation;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.ReadmultiMaxException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.DateTime;
import curam.util.workflow.impl.LocalizableStringResolver;
import curam.util.workflow.struct.TaskWDOSnapshotDetails;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


/**
 * Default implementation of {@link SearchTask}. The default algorithms used
 * for the various search hook points are defined here.
 *
 * See the following classes for more details:
 * <ul>
 * <li>curam.core.facade.impl.Inbox#searchAvailableTasks()</li>
 * <li>curam.core.facade.impl.Inbox#searchForTasks(TaskQueryKey)</li>
 * </ul>
 */
public class SearchTaskImpl implements SearchTask {

  /**
   * The task sort hook.
   */
  @Inject
  protected TaskSort taskSort;

  /**
   * The task search SQL hook.
   */
  @Inject
  protected SearchTaskSQL searchTaskSQL;

  /**
   * Constructor.
   */
  public SearchTaskImpl() {

    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Search for tasks using the specified search criteria. This method limits
   * the number of tasks that are returned to the client.
   *
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. The sort order can be changed by using Guice
   * to bind {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * <b>This method should not be executed without first validating the search
   * criteria, to prevent inefficient searches that will affect the performance
   * of the server.</b>
   *
   * @param criteria The search criteria that has been previously validated,
   * thus preventing inefficient searches that will affect the performance
   * of the server.
   * @param readMultiDetails Specifies the maximum size of the return list.
   * If the number of records exceeds the specified maximum value then an
   * informational message is displayed (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records
   * exist.
   *
   * @return A list of tasks satisfying the search criteria.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected TaskQueryResultDetailsList searchTask(TaskQueryCriteria criteria,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException {

    // variables used to return results
    final TaskQueryResultDetailsList searchedTaskDetailsList = new TaskQueryResultDetailsList();

    searchedTaskDetailsList.taskDetailsList.addAll(
      performSearch(criteria, readMultiDetails));

    // throw an informational for the number of records found.
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // size of records
    final int searchSize = searchedTaskDetailsList.taskDetailsList.size();

    if (searchSize > 0) {
      for (int i = 0; i < searchSize; i++) {

        final TaskWDOSnapshotDetails taskWDOSnapshotDetails = new TaskWDOSnapshotDetails();

        taskWDOSnapshotDetails.taskID = searchedTaskDetailsList.taskDetailsList.item(i).taskID;
        taskWDOSnapshotDetails.wdoSnapshot = searchedTaskDetailsList.taskDetailsList.item(i).subject;

        searchedTaskDetailsList.taskDetailsList.item(i).subject = LocalizableStringResolver.getTaskStringResolver().getSubjectForTask(
          taskWDOSnapshotDetails);
      }
    } else {
      final AppException e = new AppException(
        curam.message.BPOINBOX.INF_TASK_XFV_MATCHED_RESULTS_FOUND);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(searchedTaskDetailsList.taskDetailsList.size()),
        curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    return searchedTaskDetailsList;
  }

  /**
   * Returns a list of task details using the specified search criteria.
   *
   * <P>
   * The number of tasks that returned may be limited. This may be changed by
   * altering the {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE
   * ENV_INBOX_MAX_TASK_LIST_SIZE} application property. The default is 100. If
   * the number of records exceeds the specified maximum value then an
   * informational message is returned (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   * <P>
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. The sort order can be changed by using Guice
   * to bind {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param searchTaskKey The criteria to be used in the search.
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of tasks satisfying the search criteria.
   *
   * @see #validateSearchTask(TaskQueryKey)
   * @see #countTasks(TaskQueryCriteria)
   */
  @Override
  public TaskQueryResultDetailsList searchTask(
    final TaskQueryKey searchTaskKey,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException {

    validateSearchTask(searchTaskKey);

    TransactionInfo.getInformationalManager().failOperation();

    // Deadline time as search criteria
    searchTaskKey.searchDateTime = searchTaskKey.deadlineTime;

    final TaskQueryCriteria taskQueryCriteria = new TaskQueryCriteria();

    taskQueryCriteria.assign(searchTaskKey);

    // The criteria struct is also used for the saved task queries, so we must
    // set the creation last number of days and weeks attribute to the sentinel
    // value of -1, otherwise they will default to 0 and show in the SQL query
    // which would be incorrect.
    taskQueryCriteria.creationLastNumberOfDays = -1;
    taskQueryCriteria.creationLastNumberOfWeeks = -1;

    return searchTask(taskQueryCriteria, readMultiDetails);
  }

  /**
   * Search for tasks using the specified search criteria. This method limits
   * the number of tasks that are returned to the client.
   *
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. This can be changed by using Guice to bind
   * {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param criteria
   * The search criteria.
   * @param readMultiDetails
   * Specifies the maximum size of the return list. If the number of
   * records exceeds the specified maximum value then an information
   * message is displayed (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records
   * exist.
   *
   * @return A list of tasks satisfying the search criteria.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected List<TaskQueryResultDetails> performSearch(
    TaskQueryCriteria criteria, ReadMultiOperationDetails readMultiDetails)
    throws AppException, InformationalException {

    final InboxListSize<TaskQueryResultDetails> rmop = new InboxListSize<TaskQueryResultDetails>(
      readMultiDetails.maxListSize,
      new TaskQueryResultDetailsList().taskDetailsList);

    final Set<TaskQueryResultDetails> resultList = new TreeSet<TaskQueryResultDetails>(
      new Comparator<TaskQueryResultDetails>() {

      @Override
      public int compare(TaskQueryResultDetails o1,
        TaskQueryResultDetails o2) {

        return Long.valueOf(o1.taskID).compareTo(o2.taskID);
      }
    });

    int maxListSize = readMultiDetails.maxListSize;

    if (maxListSize == 0) {
      maxListSize = Integer.MAX_VALUE;
    }

    try {
      // All the criteria must be bound to struct attributes before the search.
      // This means all the selected org objects and priority lists must be
      // flattened and each criteria in the flattened list must be searched
      // separately in a loop.
      final Iterator<PriorityCodeDetails> priorityIter = SearchTaskUtilities.getTaskPriorityCodes(criteria.selectedPriorities).iterator();
      final List<OrganisationObjectDetails> orgObjectList = SearchTaskUtilities.getSelectedOrgObjects(
        criteria);

      // Priority is an optional search criteria, so it doesn't have to exist in
      // the criteria, however we still need to search for the org objects which
      // will exist.
      do {
        if (priorityIter.hasNext()) {
          criteria.priority = priorityIter.next().code;
        }
        final Iterator<OrganisationObjectDetails> orgObjectIter = orgObjectList.iterator();

        while (orgObjectIter.hasNext()) {
          SearchTaskUtilities.setAssigneeCriteria(criteria,
            orgObjectIter.next());
          // Call dynamic SQL API to execute SQL
          final String sql = searchTaskSQL.getSQLStatement(criteria);

          executeSQL(TaskQueryResultDetails.class, criteria, rmop, sql);
          final Iterator<TaskQueryResultDetails> iter = rmop.getResult().iterator();

          while (iter.hasNext() && resultList.size() < maxListSize) {
            // Add to the result list until the max list size is reached
            resultList.add(iter.next());
          }
          if (iter.hasNext()) {
            throw new ReadmultiMaxException();
          }
        }
      } while (priorityIter.hasNext());
    } catch (final ReadmultiMaxException e) {
      // if the read multi max was reached on the any query then save the result
      resultList.addAll(rmop.getResult().subList(0, maxListSize));
      final Count count = countTasks(criteria);
      final LocalisableString str = new LocalisableString(
        BPOINBOX.INF_READMULTI_MAX_EXCEEDED);

      str.arg(rmop.getMaximum());
      str.arg(count.numberOfRecords);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        str, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Checking the reserving user to ensure the correct options are presented
    // on each task
    final Iterator<TaskQueryResultDetails> iter = resultList.iterator();

    while (iter.hasNext()) {
      final TaskQueryResultDetails nextResult = iter.next();

      // Check if the task is reserved by the user
      if (nextResult.reservedBy.trim().equalsIgnoreCase(
        TransactionInfo.getProgramUser().trim())) {
        nextResult.isReservedByUser = true;
      } else {
        nextResult.isReservedByUser = false;
      }

      nextResult.isOverdue = SearchTaskUtilities.isOverdue(
        nextResult.deadlineDateTime);
    }
    final List<TaskQueryResultDetails> result = new ArrayList<TaskQueryResultDetails>();

    result.addAll(resultList);
    taskSort.sort(result);
    return result;
  }

  /**
   * Returns a list of available tasks for the currently logged in user using
   * the search criteria stored for the user in the database.
   *
   * The criteria that can be selected by the user and used in the search can
   * be a combination of the following:
   * <ul>
   * <li>Zero or more organization objects who the currently logged on user is a
   * member of</li>
   * <li>Zero or more Task Priorities</li>
   * <li>Zero or more task Deadline Due ranges</li>
   * </ul>
   * <P>
   * The user preferences of type <code>USERSEARCHTYPE.TASK</code> are queried
   * to determine if the specified user had previously completed an available
   * task search. If such a search had been executed, then the criteria used is
   * read from the preferences and used for this search function. If no search
   * had been executed, the default criteria to use is to search for available
   * tasks assigned directly to that user and tasks assigned to the position(s)
   * that the user is a member of. Tasks of all due dates and all priorities are
   * included when this scenario occurs.
   * <P>
   * The number of tasks that returned may be limited. This may be changed by
   * altering the {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE
   * ENV_INBOX_MAX_TASK_LIST_SIZE} application property. The default is 100. If
   * the number of records exceeds the specified maximum value then an
   * informational message is returned (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   * <P>
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. The sort order can be changed by using Guice
   * to bind {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of available tasks for the currently logged in user.
   *
   * @see #countAvailableTasks()
   */
  @Override
  public AvailableTaskSearchResult searchAvailableTasks(
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException {

    final UserNameAndUserSearchTypeDetails taskFilterKey = new UserNameAndUserSearchTypeDetails();

    taskFilterKey.userName = TransactionInfo.getProgramUser();
    taskFilterKey.userSearchType = USERSEARCHTYPE.TASK;

    final UserSearchFilterDataList taskFilterList = UserSearchFilterFactory.newInstance().read(
      taskFilterKey);

    final AvailableTaskSearchResult searchResult = new AvailableTaskSearchResult();

    for (int i = 0; i < taskFilterList.dtlsList.size(); i++) {

      final UserSearchFilterData nextTaskFilter = taskFilterList.dtlsList.item(
        i);

      if (nextTaskFilter.userSearchFilterType.equals(
        CuramConst.ORG_OBJECT_LIST_USER_FILTER)) {
        searchResult.orgObjectList.selectedValues = nextTaskFilter.userSearchFilterValue;
      } else if (nextTaskFilter.userSearchFilterType.equals(
        CuramConst.PRIORITY_LIST_USER_FILTER)) {
        searchResult.priorityList.selectedCodes = nextTaskFilter.userSearchFilterValue;
      } else if (nextTaskFilter.userSearchFilterType.equals(
        CuramConst.DEADLINE_DUE_USER_FILTER)) {
        searchResult.dueList.selectedCodes = nextTaskFilter.userSearchFilterValue;
      }
    }
    // Populate the multiple select fields
    searchResult.dueList.dtls.addAll(SearchTaskUtilities.getDeadlineDueCodes());
    searchResult.priorityList.dtls.addAll(
      SearchTaskUtilities.getTaskPriorityCodes());
    searchResult.orgObjectList.dtls.addAll(
      SearchTaskUtilities.getAllUserOrgObjects());

    final TaskQueryCriteria searchCriteria = new TaskQueryCriteria();

    // If there was no criteria in the database for the user then this means
    // that the user is running the search for the first time. In this case
    // the default search is by tasks assigned to the user or the user's
    // position
    if (taskFilterList.dtlsList.size() == 0) {
      // There was no data in the database, so use the default
      final String defaultOrgObjects = SearchTaskUtilities.getDefaultOrgObjects();

      searchCriteria.selectedOrgObjects = defaultOrgObjects;
      searchResult.orgObjectList.selectedValues = defaultOrgObjects;
    } else if (searchResult.orgObjectList.selectedValues.length() != 0) {
      // The user has previously selected organization objects.
      searchCriteria.selectedOrgObjects = searchResult.orgObjectList.selectedValues;
    } else {
      // There was criteria in the database but the organization objects were
      // not selected, this means use all the organization objects.
      searchCriteria.selectedOrgObjects = SearchTaskUtilities.getOrgObjectsTabList(
        SearchTaskUtilities.getAllUserOrgObjects());
    }

    searchCriteria.selectedPriorities = searchResult.priorityList.selectedCodes;
    searchCriteria.selectedDeadline = searchResult.dueList.selectedCodes;

    // The criteria struct is also used for the saved task queries, so we must
    // set the creation last number of days and weeks attribute to the sentinel
    // value of -1, otherwise they will default to 0 and show in the SQL query
    // which would be incorrect.
    searchCriteria.creationLastNumberOfDays = -1;
    searchCriteria.creationLastNumberOfWeeks = -1;
    searchCriteria.isAvailableTaskSearch = true;
    searchResult.criteriaText = SearchTaskUtilities.getCriteriaText(
      searchCriteria);
    searchResult.resultList = searchTask(searchCriteria, readMultiDetails);
    return searchResult;
  }

  /**
   * Returns a count of the available tasks for the currently logged in user
   * using the search criteria stored for the user in the database.
   * <P>
   * The user preferences of type <code>USERSEARCHTYPE.TASK</code> are queried
   * to determine if the specified user had previously completed an available
   * task search. If such a search had been executed, then the criteria used is
   * read from the preferences and used for this count function. If no search
   * had been executed, the default criteria to use is to count tasks assigned
   * directly to that user and tasks assigned to the position(s) that the user
   * is a member of.
   *
   * @return The number of tasks available to the user.
   */
  @Override
  public Count countAvailableTasks() throws AppException,
      InformationalException {

    final UserNameAndUserSearchTypeDetails taskFilterKey = new UserNameAndUserSearchTypeDetails();

    taskFilterKey.userName = TransactionInfo.getProgramUser();
    taskFilterKey.userSearchType = USERSEARCHTYPE.TASK;

    final UserSearchFilterDataList taskFilterList = UserSearchFilterFactory.newInstance().read(
      taskFilterKey);

    final AvailableTaskSearchResult searchResult = new AvailableTaskSearchResult();

    for (int i = 0; i < taskFilterList.dtlsList.size(); i++) {

      final UserSearchFilterData nextTaskFilter = taskFilterList.dtlsList.item(
        i);

      if (nextTaskFilter.userSearchFilterType.equals(
        CuramConst.ORG_OBJECT_LIST_USER_FILTER)) {
        searchResult.orgObjectList.selectedValues = nextTaskFilter.userSearchFilterValue;
      } else if (nextTaskFilter.userSearchFilterType.equals(
        CuramConst.PRIORITY_LIST_USER_FILTER)) {
        searchResult.priorityList.selectedCodes = nextTaskFilter.userSearchFilterValue;
      } else if (nextTaskFilter.userSearchFilterType.equals(
        CuramConst.DEADLINE_DUE_USER_FILTER)) {
        searchResult.dueList.selectedCodes = nextTaskFilter.userSearchFilterValue;
      }
    }

    final TaskQueryCriteria searchCriteria = new TaskQueryCriteria();

    // If there was no criteria in the database for the user then this means
    // that the user is running the search for the first time. In this case
    // the default search is by tasks assigned to the user or the user's
    // position
    if (taskFilterList.dtlsList.size() == 0) {
      // There was no data in the database, so use the default
      searchCriteria.selectedOrgObjects = SearchTaskUtilities.getDefaultOrgObjects();
    } else if (searchResult.orgObjectList.selectedValues.length() != 0) {
      // The user has previously selected organization objects.
      searchCriteria.selectedOrgObjects = searchResult.orgObjectList.selectedValues;
    } else {
      // There was criteria in the database but the organization objects were
      // not selected, this means use all the organization objects.
      searchCriteria.selectedOrgObjects = SearchTaskUtilities.getOrgObjectsTabList(
        SearchTaskUtilities.getAllUserOrgObjects());
    }

    searchCriteria.selectedPriorities = searchResult.priorityList.selectedCodes;
    searchCriteria.selectedDeadline = searchResult.dueList.selectedCodes;

    // The criteria struct is also used for the saved task queries, so we must
    // set the creation last number of days and weeks attribute to the sentinel
    // value of -1, otherwise they will default to 0 and show in the SQL query
    // which would be incorrect.
    searchCriteria.creationLastNumberOfDays = -1;
    searchCriteria.creationLastNumberOfWeeks = -1;
    searchCriteria.isAvailableTaskSearch = true;
    return countTasks(searchCriteria);
  }

  /**
   * Returns a count of the tasks satisfying the specified search criteria.
   * The criteria that may be specified includes what the tasks are assigned to
   * (user, work queue, organization unit, position or job), the due date
   * of the tasks and/or the priority of the tasks.
   *
   * @param criteria The search criteria.
   *
   * @return The number of tasks satisfying the search criteria.
   *
   * @see #searchTask(TaskQueryKey, ReadMultiOperationDetails)
   */
  @Override
  public Count countTasks(TaskQueryCriteria criteria) throws AppException,
      InformationalException {

    int count = 0;
    // All the criteria must be bound to struct attributes before the search.
    // This means all the selected org objects and priority lists must be
    // flattened and each criteria in the flattened list must be searched
    // separately in a loop.
    final Iterator<PriorityCodeDetails> priorityIter = SearchTaskUtilities.getTaskPriorityCodes(criteria.selectedPriorities).iterator();
    final List<OrganisationObjectDetails> orgObjectList = SearchTaskUtilities.getSelectedOrgObjects(
      criteria);

    // Priority is an optional search criteria, so it doesn't have to exist in
    // the criteria, however we still need to search for the org objects which
    // will exist.
    do {
      if (priorityIter.hasNext()) {
        criteria.priority = priorityIter.next().code;
      }
      final Iterator<OrganisationObjectDetails> orgObjectIter = orgObjectList.iterator();

      while (orgObjectIter.hasNext()) {
        SearchTaskUtilities.setAssigneeCriteria(criteria, orgObjectIter.next());
        final String sql = searchTaskSQL.getCountSQLStatement(criteria);

        count = count
          + ((Count) DynamicDataAccess.executeNs(Count.class, criteria, false, sql)).numberOfRecords;
      }
    } while (priorityIter.hasNext());
    final Count returnCount = new Count();

    returnCount.numberOfRecords = count;
    return returnCount;
  }

  /**
   * Validates search details before performing a search. The validations that
   * are executed are the following:
   * <ul>
   * <li>At least one search criteria must be entered.</li>
   * <li>If the user is searching using a task identifier then all other fields
   * must be empty.</li>
   * <li>If the user does not supply a task identifier than either the assigned
   * to or the business object type search parameters must be populated.</li>
   * <li>If the assigned to field is populated, the selected assignee's
   * identifier must match the assignee type in the drop down list.</li>
   * <li>If the business object type is selected, the selected business object
   * identifier must match the business object type in the drop down list.</li>
   * </ul>
   *
   * @param searchTaskKey The task search criteria key.
   */
  @Override
  public void validateSearchTask(final TaskQueryKey searchTaskKey)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    boolean criteriaEntered = true;

    if ("".equals(searchTaskKey.businessObjectType)
      && searchTaskKey.businessObjectID == 0
      && searchTaskKey.deadlineTime.equals(DateTime.kZeroDateTime)
      && "".equals(searchTaskKey.priority) && "".equals(searchTaskKey.status)
      && "".equals(searchTaskKey.assigneeType)
      && "".equals(searchTaskKey.relatedName)
      && "".equals(searchTaskKey.assignedToID)) {
      criteriaEntered = false;
    }

    // The user must enter some criteria if the task ID field is empty
    if (searchTaskKey.taskID == 0 && !criteriaEntered) {
      final AppException appEx = new AppException(
        curam.message.BPOINBOX.ERR_TASK_SEARCH_NO_CRITERIA);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else if (searchTaskKey.taskID != 0 && criteriaEntered) {
      // The user cannot supply a task ID and other criteria together
      final AppException appEx = new AppException(
        curam.message.BPOINBOX.ERR_TASK_SEARCH_BY_TASKID_ONLY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else if (!"".equals(searchTaskKey.assigneeType)
      && "".equals(searchTaskKey.assignedToID)
        || !"".equals(searchTaskKey.assignedToID)
          && "".equals(searchTaskKey.assigneeType)) {
      // Ensure that both the assignee type and assignee name are both populated
      // or both empty
      final AppException appEx = new AppException(
        BPOINBOX.ERR_TASK_ASSIGNED_TO_NOT_SELECTED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else if (!"".equals(searchTaskKey.businessObjectType)
      && searchTaskKey.businessObjectID == 0
        || searchTaskKey.businessObjectID != 0
          && "".equals(searchTaskKey.businessObjectType)) {
      // Ensure that both the business object type and business object name are
      // both populated or both empty
      final AppException appEx = new AppException(
        BPOINBOX.ERR_TASK_BUSINESS_OBJECT_TYPE_NOT_SELECTED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else if (searchTaskKey.taskID == 0
      && searchTaskKey.assigneeType.length() == 0
      && searchTaskKey.businessObjectType.length() == 0) {
      // One of assigned to or business object type must be selected.
      final AppException appEx = new AppException(
        BPOINBOX.ERR_TASK_SEARCH_MINIMUM_CRITERIA);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else {
      // Ensure the selected assignee's type matches the assignee type in the
      // drop down list. An exception will be thrown if this not is the case.
      try {
        final TaskAssigneeTypeKey assigneeTypeKey = new TaskAssigneeTypeKey();

        assigneeTypeKey.assigneeType = searchTaskKey.assigneeType;
        assigneeTypeKey.assignedToID = searchTaskKey.assignedToID;
        TaskAssignmentFactory.newInstance().getAssigneeName(assigneeTypeKey);
      } catch (final Exception e) {
        final AppException appEx = new AppException(
          BPOTASKSEARCH.ERR_ASSIGNEE_TYPE_MISMATCH);

        appEx.arg(
          new CodeTableItemIdentifier(curam.codetable.TARGETITEMTYPE.TABLENAME,
          searchTaskKey.assigneeType));
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appEx, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      // Ensure the selected business object's type matches the business object
      // type in the drop down list. An exception will be thrown if this not is
      // the case.
      try {
        final BusinessObjectKey busObjKey = new BusinessObjectKey();

        busObjKey.businessObjectID = searchTaskKey.businessObjectID;
        busObjKey.businessObjectType = searchTaskKey.businessObjectType;
        SearchTaskUtilities.getBusinessObjectName(busObjKey);
      } catch (final Exception e) {
        final AppException appEx = new AppException(
          BPOTASKSEARCH.ERR_BUSINESS_OBJECT_TYPE_MISMATCH);

        appEx.arg(
          new CodeTableItemIdentifier(BUSINESSOBJECTTYPE.TABLENAME,
          searchTaskKey.businessObjectType));
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appEx, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }
  }

  /**
   * Executes a SQL statement which will return a list of result records. The
   * size of the list is governed by the read multi operation
   * <code>readmultiOperation</code>. The SQL statement result is returned as a
   * {@link CuramValueList} populated with the results of the dynamic data
   * access SQL as a list of details objects, the type of which are specified as
   * an input parameter.
   *
   * There is no validation of the SQL before execution.
   *
   * @param <T> The details Struct Type.
   * @param dtlsClass The type of the objects to be contained in the
   * returned list.
   * @param key The class of the argument that will be passed to make up the
   * dynamicSQL statement. <code>null</code> should be passed in if a
   * key is not to be used.
   * @param readmultiOperation The read multi operation which governs the size
   * of the returned list plus whether any exceptions should be thrown if the
   * number of records exceeds the maximum allowed.
   * @param dynamicSQL A valid SQL statement to be executed against the
   * database.
   *
   * @return The {@link CuramValueList} populated with the results of the
   * dynamic data access SQL as a list of details objects, the type of
   * which are specified as an input parameter. The size of the list
   * depends on the <code>readmultiOperation</code> setting.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected static final <T> CuramValueList<T> executeSQL(
    final Class<T> dtlsClass, final Object key,
    final ReadmultiOperation<?> readmultiOperation, final String dynamicSQL)
    throws AppException, InformationalException {

    // The Class of the String.
    Class<?> keyClass = null;

    if (key != null) {
      keyClass = key.getClass();
    }

    final DatabaseMetaData dbmd = new DatabaseMetaData(dtlsClass, keyClass,
      curam.util.dataaccess.DataAccess.kNoArg2Class,
      curam.util.dataaccess.DataAccess.kNsMulti, "DynamicSQL", "dynamicSQL",
      false, dynamicSQL);

    final DataAccess ns = DataAccessFactory.newInstance(dbmd);

    final CuramValueList<T> results = new CuramValueList<T>(dtlsClass);

    ns.execute(null, key, readmultiOperation, false);

    return results;
  }
}
