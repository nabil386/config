/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.hook.task.impl;

import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKDEADLINEDUE;
import curam.codetable.TASKPRIORITY;
import curam.codetable.USERSEARCHTYPE;
import curam.common.util.xml.dom.DOMException;
import curam.common.util.xml.dom.Text;
import curam.common.util.xml.dom.input.SAXBuilder;
import curam.common.util.xml.dom.xpath.XPath;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.JobFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.struct.JobDtlsList;
import curam.core.sl.entity.struct.JobKey;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.QueryDtls;
import curam.core.sl.entity.struct.WorkQueueDetailsList;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.UserSearchFilterFactory;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.struct.BusinessObjectKey;
import curam.core.sl.struct.BusinessObjectName;
import curam.core.sl.struct.ListUserOrgUnitDetails;
import curam.core.sl.struct.ListUserPositionDetails;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.sl.struct.UserSearchFilterData;
import curam.core.sl.struct.UserSearchFilterDetails;
import curam.core.struct.AvailableTaskSearchCriteria;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.DeadlineCodeDetails;
import curam.core.struct.OrgObjectNames;
import curam.core.struct.OrgObjectTabList;
import curam.core.struct.OrganisationObjectDetails;
import curam.core.struct.OrganisationObjectDetailsList;
import curam.core.struct.PriorityCodeDetails;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.message.BPOQUERY;
import curam.message.BPOTASKSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.resources.XMLParserCache;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.xml.sax.InputSource;


/**
 * This class contains utility methods used by the task search classes.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class SearchTaskUtilities {

  /**
   * The XPath search separator.
   */
  protected static final String XPATH_NODE_SEPARATOR = "/";

  /**
   * The XPath search start text.
   */
  protected static final String XPATH_START = "//";

  /**
   * The XPath restart to date node.
   */
  protected static final String RESTARTTODATE = "RestartToDate";

  /**
   * The XPath restart from date node.
   */
  protected static final String RESTARTFROMDATE = "RestartFromDate";

  /**
   * The XPath last number of weeks node.
   */
  protected static final String LASTNUMBEROFWEEKS = "CreationLastNumberOfWeeks";

  /**
   * The XPath last number of days node.
   */
  protected static final String LASTNUMBEROFDAYS = "CreationLastNumberOfDays";

  /**
   * The XPath creation to date node.
   */
  protected static final String CREATIONTODATE = "CreationToDate";

  /**
   * The XPath creation from date node.
   */
  protected static final String CREATIONFROMDATE = "CreationFromDate";

  /**
   * The XPath task category node.
   */
  protected static final String TASKCATEGORY = "TaskCategory";

  /**
   * The XPath deadline to date node.
   */
  protected static final String DEADLINETODATE = "DeadlineToDate";

  /**
   * The XPath deadline from date node.
   */
  protected static final String DEADLINEFROMDATE = "DeadlineFromDate";

  /**
   * The XPath deadline due node.
   */
  protected static final String DEADLINEDUE = "DeadlineDue";

  /**
   * The XPath status node.
   */
  protected static final String STATUS = "Status";

  /**
   * The XPath business object type node.
   */
  protected static final String BUSOBJECTTYPE = "BusinessObjectType";

  /**
   * The XPath business object ID node.
   */
  protected static final String BUSOBJECTID = "BusinessObjectID";

  /**
   * The XPath select organization object node.
   */
  protected static final String SELECTEDORGOBJECTS = "SelectedOrgObjects";

  /**
   * The XPath from my tasks only node.
   */
  protected static final String FROMMYTASKSONLY = "FromMyTasksOnly";

  /**
   * The XPath query element.
   */
  protected static final String QUERY = "Query";

  /**
   * The XPath text method.
   */
  protected static final String XPATH_TEXT = "text()";

  /**
   * The XPath Priority Node
   */
  protected static final String PRIORITY = "Priority";

  /**
   * Get the first day of next month.
   *
   * @return The first day of next month.
   */
  public static DateTime getFirstDayOfNextMonth() {

    // Get the current date
    final Calendar cal = Date.getCurrentDate().getCalendar();

    // Set the date to be the last day of the month
    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
    // Add 1 day, to get the first day of next month
    cal.add(Calendar.DAY_OF_MONTH, 1);
    return new Date(cal).getDateTime();
  }

  /**
   * Get the first day of this month.
   *
   * @return The first day of this month.
   */
  public static DateTime getFirstDayOfThisMonth() {

    // Get the current date
    final Calendar cal = Date.getCurrentDate().getCalendar();

    // Set the date to be the first day of the month
    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
    return new Date(cal).getDateTime();
  }

  /**
   * Get the first day of this week. The JVM locale decides whether the first
   * day of the week is Sunday or Monday.
   *
   * @return The first day of this week.
   */
  public static DateTime getFirstDayOfThisWeek() {

    // Get the current date
    final Calendar cal = Date.getCurrentDate().getCalendar();
    final int diff = cal.getActualMinimum(Calendar.DAY_OF_WEEK)
      - cal.get(Calendar.DAY_OF_WEEK);

    cal.add(Calendar.DAY_OF_MONTH, diff);
    return new Date(cal).getDateTime();
  }

  /**
   * Get the first day of next week. The JVM locale decides whether the first
   * day of the week is Sunday or Monday.
   *
   * @return The first day of next week.
   */
  public static DateTime getFirstDayOfNextWeek() {

    return getFirstDayOfThisWeek().addTime(24 * 7, 0, 0);
  }

  /**
   * Get midnight tomorrow.
   *
   * @return Midnight tomorrow.
   */
  public static DateTime getMidnightTomorrow() {

    // Get midnight today
    final Calendar cal = Date.getCurrentDate().getCalendar();

    // Add 1 day, to get midnight tomorrow
    cal.add(Calendar.DAY_OF_MONTH, 1);
    return new Date(cal).getDateTime();
  }

  /**
   * Gets the date corresponding to today minus the specified number of days.
   *
   * @param numDays
   * The number of days to subtract from today.
   *
   * @return The date corresponding to today minus the specified number of days.
   */
  public static DateTime getDaysAgo(int numDays) {

    // Get midnight today
    final Calendar cal = Date.getCurrentDate().getCalendar();

    cal.add(Calendar.DAY_OF_MONTH, numDays * -1);
    return new Date(cal).getDateTime();
  }

  /**
   * Gets the date corresponding to midnight today minus the specified number of
   * weeks.
   *
   * @param numWeeks
   * The number of weeks to subtract from midnight today.
   *
   * @return The date corresponding to midnight today minus the specified number
   * of weeks.
   */
  public static DateTime getWeeksAgo(int numWeeks) {

    // Get midnight today
    final Calendar cal = Date.getCurrentDate().getCalendar();

    cal.add(Calendar.WEEK_OF_YEAR, numWeeks * -1);
    return new Date(cal).getDateTime();
  }

  /**
   * Search for tasks using the specified search criteria. This method limits
   * the number of tasks that are returned to the client.
   *
   * <b>This method should not be executed without first validating the search
   * criteria, to prevent inefficient searches that will affect the performance
   * of the server.</b>
   *
   * @param criteria
   * Search criteria that has been previously validated, thus
   * preventing inefficient searches that will affect the performance
   * of the server.
   * @param readMultiDetails
   * Specifies the maximum size of the return list. If the number of
   * records exceeds the specified maximum value then an information
   * message is displayed (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records
   * exist.
   *
   * @return A list of tasks satisfying the search criteria.
   *
   * @see {@link curam.core.hook.task.impl.SearchTaskImpl#searchTask(TaskQueryCriteria, ReadMultiOperationDetails)}
   */
  public static TaskQueryResultDetailsList searchTask(
    TaskQueryCriteria criteria, ReadMultiOperationDetails readMultiDetails)
    throws AppException, InformationalException {

    return new SearchTaskImpl().searchTask(criteria, readMultiDetails);
  }

  /**
   * This method stores the available task search criteria selected by the
   * currently logged on user into the database. The criteria that can be stored
   * can be a combination of the following:
   * <ul>
   * <li>Zero or more organization objects who the currently logged on user is a
   * member of</li>
   * <li>Zero or more Task Priorities</li>
   * <li>Zero or more task Deadline Due ranges</li>
   * </ul>
   *
   * @param criteria
   * The available task search criteria.
   */
  public static void storeAvailableTaskSearch(
    AvailableTaskSearchCriteria criteria) throws AppException,
      InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager.failOperation();

    final UserSearchFilterDetails filterDetails = new UserSearchFilterDetails();

    filterDetails.userName = TransactionInfo.getProgramUser();
    filterDetails.userSearchType = USERSEARCHTYPE.TASK;

    UserSearchFilterData filterData = new UserSearchFilterData();

    filterData.userSearchFilterType = CuramConst.ORG_OBJECT_LIST_USER_FILTER;
    filterData.userSearchFilterValue = criteria.selectedOrgObjects;
    filterDetails.filterDetails.dtlsList.addRef(filterData);

    filterData = new UserSearchFilterData();
    filterData.userSearchFilterType = CuramConst.PRIORITY_LIST_USER_FILTER;
    filterData.userSearchFilterValue = criteria.selectedPriorities;
    filterDetails.filterDetails.dtlsList.addRef(filterData);

    filterData = new UserSearchFilterData();
    filterData.userSearchFilterType = CuramConst.DEADLINE_DUE_USER_FILTER;
    filterData.userSearchFilterValue = criteria.selectedDeadline;
    filterDetails.filterDetails.dtlsList.addRef(filterData);

    UserSearchFilterFactory.newInstance().createOrModify(filterDetails);
  }

  /**
   * This method converts the query criteria into an XML string which represents
   * the query criteria in the database.
   *
   * @param details
   * The task query criteria.
   *
   * @return An XML string representation of the query criteria.
   */
  public static String formatXMLQueryCriteria(TaskQueryCriteria details)
    throws AppException {

    final XMLBuilder xmlBuilder = new XMLBuilder(QUERY);

    if (details.searchMyTasksOnly) {
      xmlBuilder.createTag(FROMMYTASKSONLY);
      xmlBuilder.addTagData(Boolean.toString(details.searchMyTasksOnly));
      xmlBuilder.closeTag();
    }

    if (details.selectedOrgObjects.trim().length() != 0) {
      xmlBuilder.createTag(SELECTEDORGOBJECTS);
      xmlBuilder.addTagData(details.selectedOrgObjects);
      xmlBuilder.closeTag();
    }

    if (details.businessObjectID != 0) {
      xmlBuilder.createTag(BUSOBJECTID);
      xmlBuilder.addTagData(Long.toString(details.businessObjectID));
      xmlBuilder.closeTag();
    }

    if (details.businessObjectType.trim().length() != 0) {
      xmlBuilder.createTag(BUSOBJECTTYPE);
      xmlBuilder.addTagData(details.businessObjectType);
      xmlBuilder.closeTag();
    }

    if (details.status.trim().length() != 0) {
      xmlBuilder.createTag(STATUS);
      xmlBuilder.addTagData(details.status);
      xmlBuilder.closeTag();
    }

    if (details.deadlineDue.trim().length() != 0) {
      xmlBuilder.createTag(DEADLINEDUE);
      xmlBuilder.addTagData(details.deadlineDue);
      xmlBuilder.closeTag();
    }

    if (!details.deadlineFromDate.isZero()) {
      xmlBuilder.createTag(DEADLINEFROMDATE);
      xmlBuilder.addTagData(Long.toString(details.deadlineFromDate.asLong()));
      xmlBuilder.closeTag();
    }

    if (!details.deadlineToDate.isZero()) {
      xmlBuilder.createTag(DEADLINETODATE);
      xmlBuilder.addTagData(Long.toString(details.deadlineToDate.asLong()));
      xmlBuilder.closeTag();
    }

    if (details.taskCategory.trim().length() != 0) {
      xmlBuilder.createTag(TASKCATEGORY);
      xmlBuilder.addTagData(details.taskCategory);
      xmlBuilder.closeTag();
    }

    if (!details.creationFromDate.isZero()) {
      xmlBuilder.createTag(CREATIONFROMDATE);
      xmlBuilder.addTagData(Long.toString(details.creationFromDate.asLong()));
      xmlBuilder.closeTag();
    }

    if (!details.creationToDate.isZero()) {
      xmlBuilder.createTag(CREATIONTODATE);
      xmlBuilder.addTagData(Long.toString(details.creationToDate.asLong()));
      xmlBuilder.closeTag();
    }

    if (details.creationLastNumberOfDays != -1) {
      xmlBuilder.createTag(LASTNUMBEROFDAYS);
      xmlBuilder.addTagData(Integer.toString(details.creationLastNumberOfDays));
      xmlBuilder.closeTag();
    }

    if (details.creationLastNumberOfWeeks != -1) {
      xmlBuilder.createTag(LASTNUMBEROFWEEKS);
      xmlBuilder.addTagData(Integer.toString(details.creationLastNumberOfWeeks));
      xmlBuilder.closeTag();
    }

    if (!details.restartFromDate.isZero()) {
      xmlBuilder.createTag(RESTARTFROMDATE);
      xmlBuilder.addTagData(Long.toString(details.restartFromDate.asLong()));
      xmlBuilder.closeTag();
    }

    if (!details.restartToDate.isZero()) {
      xmlBuilder.createTag(RESTARTTODATE);
      xmlBuilder.addTagData(Long.toString(details.restartToDate.asLong()));
      xmlBuilder.closeTag();
    }

    if (details.priority.trim().length() != 0) {
      xmlBuilder.createTag(PRIORITY);
      xmlBuilder.addTagData(details.priority);
      xmlBuilder.closeTag();
    }

    return xmlBuilder.getXmlString();
  }

  /**
   * Gets the current user and current user's organization objects. An
   * organizational object can be an organizational unit, position or job that
   * the current user is a member of, or a work queue that the user is
   * subscribed to.
   *
   * @return The current user and current user's organization objects.
   */
  public static List<OrganisationObjectDetails> getAllUserOrgObjects()
    throws AppException, InformationalException {

    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    orgObjects.add(SearchTaskUtilities.getUser());
    orgObjects.addAll(SearchTaskUtilities.getUserOrgUnits());
    orgObjects.addAll(SearchTaskUtilities.getUserPositions());
    orgObjects.addAll(SearchTaskUtilities.getUserJobs());
    orgObjects.addAll(SearchTaskUtilities.getUserWorkQueues());

    return orgObjects;
  }

  /**
   * This method gets the business object name from the business object type and
   * business object ID. A business object can either be a case or a person.
   *
   * @param key
   * The business object identifier and type. The type can be either a
   * case or a person.
   *
   * @return The case ID if the business object is a case or a person's full
   * name if the business object is a person.
   */
  public static BusinessObjectName getBusinessObjectName(BusinessObjectKey key) throws AppException,
      InformationalException {

    String answer = CuramConst.gkEmpty;

    if (key.businessObjectType.length() != 0 && key.businessObjectID != 0) {
      if (key.businessObjectType.equals(BUSINESSOBJECTTYPE.PERSON)) {
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
        ConcernRoleNameDetails concernRoleNameDetails;

        concernRoleKey.concernRoleID = key.businessObjectID;
        concernRoleNameDetails = concernRoleObj.readConcernRoleName(
          concernRoleKey);

        answer = concernRoleNameDetails.concernRoleName;
      } else if (key.businessObjectType.equals(BUSINESSOBJECTTYPE.CASE)) {
        final CaseSearchKey caseSearchKey = new CaseSearchKey();

        caseSearchKey.caseID = key.businessObjectID;
        // read the case to ensure the ID is valid, a record not found exception
        // will be thrown if it is not.
        final CaseReference caseReference = CaseHeaderFactory.newInstance().readCaseReferenceByCaseID(
          caseSearchKey);

        answer = caseReference.caseReference;

      }
    }
    final BusinessObjectName businessObjectName = new BusinessObjectName();

    businessObjectName.businessObjectName = answer;
    return businessObjectName;
  }

  /**
   * Returns the available task search criteria in a localizable human readable
   * text.
   *
   * @param details
   * The search criteria.
   *
   * @return Case search criteria text value.
   */
  public static String getCriteriaText(TaskQueryCriteria details)
    throws AppException, InformationalException {

    // BEGIN CR00327929, ZV
    String listSeparator = Configuration.getProperty(EnvVars.ENV_LIST_SEPARATOR);

    if (listSeparator == null) {
      listSeparator = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_LIST_SEPARATOR_DEFAULT);
    }

    final String ownerList = SearchTaskUtilities.getOrgObjectNames(
      SearchTaskUtilities.getOrgObjects(details.selectedOrgObjects),
      listSeparator);

    final List<PriorityCodeDetails> selectedPriorities = SearchTaskUtilities.getTaskPriorityCodes(
      details.selectedPriorities);

    final List<DeadlineCodeDetails> selectedDeadlines = SearchTaskUtilities.getDeadlineDueCodes(
      details.selectedDeadline);

    final String priorityNameList = SearchTaskUtilities.getPriorityNames(
      selectedPriorities, listSeparator);

    final boolean isPrioritySelected = selectedPriorities.size() != 0;
    final boolean isDeadlineSelected = selectedDeadlines.size() != 0;

    final boolean allPrioritiesSelected = SearchTaskUtilities.getTaskPriorityCodes().size()
      == selectedPriorities.size();

    final boolean allDeadlinesSelected = SearchTaskUtilities.getDeadlineDueCodes().size()
      == selectedDeadlines.size();

    final String deadlineNames = SearchTaskUtilities.getDeadlineNames(
      selectedDeadlines, listSeparator);

    // BEGIN CR00331517, ZV
    LocalisableString localisableString = null;

    if (!isPrioritySelected && allDeadlinesSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_AND_ANY_DEADLINE);
      localisableString.arg(ownerList);
    } else if (allPrioritiesSelected && allDeadlinesSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_ANY_PRIORITY_AND_ANY_DEADLINE);
      localisableString.arg(ownerList);
    } else if (allPrioritiesSelected && !isDeadlineSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_ANY_PRIORITY);
      localisableString.arg(ownerList);
    } else if (isPrioritySelected && !allPrioritiesSelected
      && allDeadlinesSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_PRIORITY_AND_ANY_DEADLINE);
      localisableString.arg(ownerList);
      localisableString.arg(priorityNameList);
    } else if (allPrioritiesSelected && isDeadlineSelected
      && !allDeadlinesSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_ANY_PRIORITY_AND_DEADLINE);
      localisableString.arg(ownerList);
      localisableString.arg(deadlineNames);
    } else if (!isPrioritySelected && !isDeadlineSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_ONLY);
      localisableString.arg(ownerList);
    } else if (!isPrioritySelected && isDeadlineSelected
      && !allDeadlinesSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_AND_DEADLINE);
      localisableString.arg(ownerList);
      localisableString.arg(deadlineNames);
    } else if (isPrioritySelected && !allPrioritiesSelected
      && !allDeadlinesSelected && !isDeadlineSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_AND_PRIORITY);
      localisableString.arg(ownerList);
      localisableString.arg(priorityNameList);
    } else if (isPrioritySelected && !allPrioritiesSelected
      && isDeadlineSelected && !allDeadlinesSelected) {
      localisableString = new LocalisableString(
        BPOTASKSEARCH.INF_AVAILABLE_TASK_CRITERIA_WITH_ASSIGNED_PRIORITY_AND_DEADLINE);
      localisableString.arg(ownerList);
      localisableString.arg(priorityNameList);
      localisableString.arg(deadlineNames);
    }

    return localisableString.getMessage(TransactionInfo.getProgramLocale());
    // END CR00331517
    // END CR00327929
  }

  /**
   * Gets all the task deadline due code table values in a list.
   *
   * @return The list of task deadline due code table values.
   */
  public static List<DeadlineCodeDetails> getDeadlineDueCodes()
    throws AppException, InformationalException {

    // Get case search status filter options for locale value and codetable
    final java.util.LinkedHashMap<String, String> deadlineDueCodes = CodeTable.getAllEnabledItems(
      TASKDEADLINEDUE.TABLENAME, TransactionInfo.getProgramLocale());

    final List<DeadlineCodeDetails> answer = new ArrayList<DeadlineCodeDetails>();

    if (!deadlineDueCodes.isEmpty()) {

      final Set<String> keys = deadlineDueCodes.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        final DeadlineCodeDetails deadlineDueDetails = new DeadlineCodeDetails();

        deadlineDueDetails.code = itr.next();
        answer.add(deadlineDueDetails);
      }
    }

    return answer;
  }

  /**
   * Converts a tab delimited list of task deadline due code table values into a
   * list of structs.
   *
   * @param deadlineTabList
   * The tabbed delimited list of task deadline due code table values.
   *
   * @return A list of task deadline due code table values.
   */
  public static List<DeadlineCodeDetails> getDeadlineDueCodes(
    String deadlineTabList) throws AppException, InformationalException {

    final StringList deadlineList = StringUtil.tabText2StringListWithTrim(
      deadlineTabList);

    final List<DeadlineCodeDetails> answer = new ArrayList<DeadlineCodeDetails>();

    for (int i = 0; i < deadlineList.size(); i++) {
      final DeadlineCodeDetails deadlineDetails = new DeadlineCodeDetails();

      deadlineDetails.code = deadlineList.item(i);
      answer.add(deadlineDetails);
    }

    return answer;
  }

  /**
   * Converts a list of task deadline due code table values objects into a
   * delimited list of task deadline due code descriptions.
   *
   * @param deadlineCodes
   * The list of task deadline due code table values
   * @param delimiter
   * The delimiter character (e.g. comma).
   *
   * @return A delimited list of task deadline due code descriptions.
   */
  public static String getDeadlineNames(
    List<DeadlineCodeDetails> deadlineCodes, String delimiter)
    throws AppException, InformationalException {

    // If the entire list of deadline due code table items are selected then
    // there is no need to output any text
    final StringBuffer deadlineListString = new StringBuffer();

    final Iterator<DeadlineCodeDetails> iter = deadlineCodes.iterator();

    while (iter.hasNext()) {
      deadlineListString.append(
        CodeTable.getOneItem(TASKDEADLINEDUE.TABLENAME, iter.next().code));
      if (iter.hasNext()) {
        deadlineListString.append(delimiter + CuramConst.gkSpace);
      } else {
        deadlineListString.append(CuramConst.gkSpace);
      }
    }

    return deadlineListString.toString().trim();
  }

  /**
   * If there is no search criteria stored in the database for the currently
   * logged in user, then the search criteria will default to the user and
   * user's position organization objects.
   *
   * @return The tabbed delimited list. The format of the tabbed delimited list
   * is "OrgObjectType|OrgObjectID    OrgObjectType|OrgObjectID" where
   * each type and ID pair is separated by the pipe character e.g.
   * "RL9|userName    RL21|15    RL20|25".
   */
  public static String getDefaultOrgObjects() throws AppException,
      InformationalException {

    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    orgObjects.add(SearchTaskUtilities.getUser());
    orgObjects.addAll(SearchTaskUtilities.getUserPositions());
    return SearchTaskUtilities.getOrgObjectsTabList(orgObjects);
  }

  /**
   * This method retrieves the task query criteria for an individual criteria
   * entry from the query XML.
   *
   * @param doc
   * The XML query criteria.
   *
   * @param xpathString
   * The XPath string to search the XML for an individual criteria
   * entry.
   *
   * @return The value stored for the individual criteria entry.
   *
   * @throws DOMException
   * If an exception occurs reading the XML.
   */
  public static String getNodeText(
    final curam.common.util.xml.dom.Document doc, final String xpathString)
    throws DOMException {

    final XPath xpath = new XPath(xpathString);
    curam.common.util.xml.dom.Text text =
      (curam.common.util.xml.dom.Text) xpath
        .selectSingleDOMNode(doc.getRootElement());

    if (text == null) {
      text = new Text("");
    }
    return text.getText();
  }

  /**
   * Converts a list of organization objects into a delimited list of
   * organization object names.
   *
   * @param orgObjects
   * The list of organization objects.
   * @param delimiter
   * The delimiter character (e.g. comma).
   *
   * @return A delimited list of organization object names.
   */
  public static String getOrgObjectNames(
    List<OrganisationObjectDetails> orgObjects, String delimiter)
    throws AppException, InformationalException {

    final StringBuffer ownerListString = new StringBuffer();

    if (orgObjects.size() != 0) {
      final Iterator<OrganisationObjectDetails> iter = orgObjects.iterator();

      while (iter.hasNext()) {
        ownerListString.append(iter.next().name);
        if (iter.hasNext()) {
          ownerListString.append(delimiter + CuramConst.gkSpace);
        } else {
          ownerListString.append(CuramConst.gkSpace);
        }
      }
    }
    return ownerListString.toString().trim();
  }

  /**
   * Converts a tab delimited list or organization units into a list of structs.
   *
   * @param orgObjectTabList
   * The tabbed delimited list of organization objects. The format must
   * be "OrgObjectType|OrgObjectID    OrgObjectType|OrgObjectID" each
   * type and ID pair must be separated by the pipe character e.g.
   * "RL9|userName    RL21|15    RL20|25"
   *
   * @return A list of organization object structs.
   */
  public static List<OrganisationObjectDetails> getOrgObjects(
    String orgObjectTabList) throws AppException, InformationalException {

    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    final StringList orgObjectList = StringUtil.tabText2StringListWithTrim(
      orgObjectTabList);

    for (int i = 0; i < orgObjectList.size(); i++) {

      final StringList orgObjectTypeOwner = StringUtil.delimitedText2StringListWithTrim(
        orgObjectList.item(i), CuramConst.gkPipeDelimiterChar);

      final String orgObjectType = orgObjectTypeOwner.item(0);

      if (orgObjectType.equals(TARGETITEMTYPE.USER)) {
        // Get user
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = orgObjectTypeOwner.item(1);
        final OrganisationObjectDetails userDetails = new OrganisationObjectDetails();

        userDetails.value = orgObjectList.item(i);
        userDetails.name = UserAccessFactory.newInstance().getFullName(usersKey).fullname;
        orgObjects.add(userDetails);
      } else if (orgObjectType.equals(TARGETITEMTYPE.POSITION)) {
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = Long.parseLong(orgObjectTypeOwner.item(1));
        final OrganisationObjectDetails positionDetails = new OrganisationObjectDetails();

        positionDetails.value = orgObjectList.item(i);
        positionDetails.name = PositionFactory.newInstance().readPositionName(positionKey).name;
        orgObjects.add(positionDetails);
      } else if (orgObjectType.equals(TARGETITEMTYPE.ORGUNIT)) {
        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = Long.parseLong(
          orgObjectTypeOwner.item(1));
        final OrganisationObjectDetails orgUnitDetails = new OrganisationObjectDetails();

        orgUnitDetails.value = orgObjectList.item(i);
        orgUnitDetails.name = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance().readOrgUnitName(organisationUnitKey).name;
        orgObjects.add(orgUnitDetails);
      } else if (orgObjectType.equals(TARGETITEMTYPE.WORKQUEUE)) {
        final WorkQueueKey workQueueKey = new WorkQueueKey();

        workQueueKey.workQueueID = Long.parseLong(orgObjectTypeOwner.item(1));
        final OrganisationObjectDetails workQueueDetails = new OrganisationObjectDetails();

        workQueueDetails.value = orgObjectList.item(i);
        workQueueDetails.name = curam.core.sl.entity.fact.WorkQueueFactory.newInstance().readWorkQueueName(workQueueKey).name;
        orgObjects.add(workQueueDetails);
      } else if (orgObjectType.equals(TARGETITEMTYPE.JOB)) {
        final JobKey jobKey = new JobKey();

        jobKey.jobID = Long.parseLong(orgObjectTypeOwner.item(1));
        final OrganisationObjectDetails jobDetails = new OrganisationObjectDetails();

        jobDetails.value = orgObjectList.item(i);
        jobDetails.name = JobFactory.newInstance().readJobName(jobKey).name;
        orgObjects.add(jobDetails);
      }
    }
    return orgObjects;
  }

  /**
   * Converts a list of organization objects into a tabbed delimited list. The
   * format of the tabbed delimited list is
   * "OrgObjectType|OrgObjectID    OrgObjectType|OrgObjectID" where each type
   * and ID pair is separated by the pipe character e.g.
   * "RL9|userName    RL21|15    RL20|25".
   *
   * @param orgObjects
   * A list of organization objects.
   *
   * @return The tabbed delimited list.
   */
  public static String getOrgObjectsTabList(
    List<OrganisationObjectDetails> orgObjects) throws AppException,
      InformationalException {

    final StringBuffer answer = new StringBuffer();

    for (final OrganisationObjectDetails nextOrgObject : orgObjects) {
      answer.append(nextOrgObject.value + CuramConst.gkTabDelimiter);
    }
    return answer.toString().trim();
  }

  /**
   * Converts a list of task priority code table values objects into a delimited
   * list of task priority code descriptions.
   *
   * @param priorityCodes
   * The list of task priority code table values.
   * @param delimiter
   * The delimiter character (e.g. comma).
   *
   * @return A delimited list of task priority code descriptions.
   */
  public static String getPriorityNames(
    List<PriorityCodeDetails> priorityCodes, String delimiter)
    throws AppException, InformationalException {

    // If the entire list of priorities code table items are selected then there
    // is no need to output any text
    final StringBuffer priorityListString = new StringBuffer();

    final Iterator<PriorityCodeDetails> iter = priorityCodes.iterator();

    while (iter.hasNext()) {
      priorityListString.append(
        CodeTable.getOneItem(TASKPRIORITY.TABLENAME, iter.next().code));
      if (iter.hasNext()) {
        priorityListString.append(delimiter + CuramConst.gkSpace);
      } else {
        priorityListString.append(CuramConst.gkSpace);
      }
    }

    return priorityListString.toString().trim();
  }

  /**
   * Return a comma delimited list of the organization objects names that the
   * current user is a member of or subscribed to.
   *
   * @param selectedOrgObjects
   * The selected organization objects.
   *
   * @return A comma delimited list of the organization objects names.
   */
  public static OrgObjectNames getSelectedOrgObjectNames(
    OrgObjectTabList selectedOrgObjects) throws AppException,
      InformationalException {

    // BEGIN CR00327929, ZV
    String listSeparator = Configuration.getProperty(EnvVars.ENV_LIST_SEPARATOR);

    if (listSeparator == null) {
      listSeparator = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_LIST_SEPARATOR_DEFAULT);
    }

    final OrgObjectNames orgObjectNames = new OrgObjectNames();

    orgObjectNames.names = getOrgObjectNames(
      getOrgObjects(selectedOrgObjects.orgObjects), listSeparator);
    // END, CR00327929
    return orgObjectNames;
  }

  /**
   * Get the organization objects selected by the user. The objects selected are
   * converted from a tab delimited string into a list of structs.
   *
   * @param key
   * The query criteria.
   *
   * @return A list of selected organization objects. If organization object is
   * not part of the search then this method returns a list containing a
   * single uninitialized organization object struct.
   */
  public static List<OrganisationObjectDetails> getSelectedOrgObjects(
    TaskQueryCriteria key) throws AppException, InformationalException {

    List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    if (key.selectedOrgObjects.length() != 0) {
      // The org objects are in a tab delimited list
      orgObjects = convertTabListToOrgObjectList(key.selectedOrgObjects);
    } else if (key.assigneeType.length() != 0) {
      // An organization object was selected through a search popup
      final OrganisationObjectDetails orgObject = new OrganisationObjectDetails();

      orgObject.value = key.assigneeType;
      orgObject.name = key.assignedToID;
      orgObjects.add(orgObject);
    } else {
      // The search is not by organization object, i.e. business object is being
      // used. Therefore create an empty organization object details
      orgObjects.add(new OrganisationObjectDetails());
    }
    return orgObjects;
  }

  /**
   * Gets all the task priority code table values in a list.
   *
   * @return The list of priority code table values.
   */
  public static List<PriorityCodeDetails> getTaskPriorityCodes()
    throws AppException, InformationalException {

    // Get case search status filter options for locale value and codetable
    final java.util.LinkedHashMap<String, String> priorities = CodeTable.getAllEnabledItems(
      TASKPRIORITY.TABLENAME, TransactionInfo.getProgramLocale());

    final List<PriorityCodeDetails> answer = new ArrayList<PriorityCodeDetails>();

    if (!priorities.isEmpty()) {

      final Set<String> keys = priorities.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        final PriorityCodeDetails priorityDetails = new PriorityCodeDetails();

        priorityDetails.code = itr.next();
        answer.add(priorityDetails);
      }
    }

    return answer;
  }

  /**
   * Converts a tab delimited list of task priority code table values into a
   * list.
   *
   * @param priorityTabList
   * The tabbed delimited list of task priority code table values.
   *
   * @return A list of task priority code table values.
   */
  public static List<PriorityCodeDetails> getTaskPriorityCodes(
    String priorityTabList) throws AppException, InformationalException {

    final StringList priorityList = StringUtil.tabText2StringListWithTrim(
      priorityTabList);

    final List<PriorityCodeDetails> answer = new ArrayList<PriorityCodeDetails>();

    for (int i = 0; i < priorityList.size(); i++) {
      final PriorityCodeDetails priorityDetails = new PriorityCodeDetails();

      priorityDetails.code = priorityList.item(i);
      answer.add(priorityDetails);
    }

    return answer;
  }

  /**
   * This method gets the task query criteria from the Query entity.
   *
   * @param details
   * The entity details.
   *
   * @return The task query criteria.
   */
  public static TaskQueryCriteria getTaskQueryCriteria(QueryDtls details)
    throws AppException, InformationalException {

    final TaskQueryCriteria taskQueryCriteria = SearchTaskUtilities.parseXMLQueryCriteria(
      details.query);

    taskQueryCriteria.queryName = details.queryName;
    return taskQueryCriteria;
  }

  /**
   * Gets the user object organization object for the currently logged in user.
   *
   * @return The user organization object.
   */
  public static OrganisationObjectDetails getUser() throws AppException,
      InformationalException {

    // Get user
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = TransactionInfo.getProgramUser();

    final OrganisationObjectDetails userDetails = new OrganisationObjectDetails();

    userDetails.value = TARGETITEMTYPE.USER + CuramConst.gkPipeDelimiter
      + usersKey.userName;
    userDetails.name = UserAccessFactory.newInstance().getFullName(usersKey).fullname
      + CuramConst.gkSpace + GeneralConst.gkLeftSquareBracket
      + CodeTable.getOneItem(TARGETITEMTYPE.TABLENAME, TARGETITEMTYPE.USER)
      + GeneralConst.gkRightSquareBracket;
    return userDetails;
  }

  /**
   * Gets the jobs that the currently logged in user is a member of.
   *
   * @return The jobs that the currently logged in user is a member of.
   */
  public static List<OrganisationObjectDetails> getUserJobs()
    throws AppException, InformationalException {

    // Get Jobs
    final JobDtlsList jobs = curam.core.sl.fact.JobFactory.newInstance().getJobsForUser();

    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    for (int i = 0; i < jobs.dtls.size(); i++) {
      final OrganisationObjectDetails jobDetails = new OrganisationObjectDetails();

      jobDetails.value = TARGETITEMTYPE.JOB + CuramConst.gkPipeDelimiter
        + jobs.dtls.item(i).jobID;
      jobDetails.name = jobs.dtls.item(i).name + CuramConst.gkSpace
        + GeneralConst.gkLeftSquareBracket
        + CodeTable.getOneItem(TARGETITEMTYPE.TABLENAME, TARGETITEMTYPE.JOB)
        + GeneralConst.gkRightSquareBracket;

      orgObjects.add(jobDetails);
    }

    return orgObjects;
  }

  /**
   * Gets the current user's organization objects. An organization object can be
   * a user, an organization unit, a position, a job or a work queue.
   *
   * @return The current user's organization objects.
   */
  public static OrganisationObjectDetailsList getUserOrgObjects()
    throws AppException, InformationalException {

    final OrganisationObjectDetailsList returnList = new OrganisationObjectDetailsList();

    returnList.dtls.addAll(getAllUserOrgObjects());
    returnList.selectedValues = getOrgObjectsTabList(returnList.dtls);
    return returnList;
  }

  /**
   * Gets the organization units that the currently logged in user is a member
   * of.
   *
   * @return The organization units that the currently logged in user is a
   * member of.
   */
  public static List<OrganisationObjectDetails> getUserOrgUnits()
    throws AppException, InformationalException {

    // Get org units
    final ListUserOrgUnitDetails listUserOrgUnitDetails = curam.core.sl.fact.OrganisationUnitFactory.newInstance().getOrgUnitsForUser();
    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    for (int i = 0; i < listUserOrgUnitDetails.dtlsList.dtls.size(); i++) {
      final OrganisationObjectDetails orgUnitDetails = new OrganisationObjectDetails();

      orgUnitDetails.value = TARGETITEMTYPE.ORGUNIT
        + CuramConst.gkPipeDelimiter
        + listUserOrgUnitDetails.dtlsList.dtls.item(i).organisationUnitID;
      orgUnitDetails.name = listUserOrgUnitDetails.dtlsList.dtls.item(i).name
        + CuramConst.gkSpace + GeneralConst.gkLeftSquareBracket
        + CodeTable.getOneItem(TARGETITEMTYPE.TABLENAME, TARGETITEMTYPE.ORGUNIT)
        + GeneralConst.gkRightSquareBracket;
      orgObjects.add(orgUnitDetails);
    }
    return orgObjects;
  }

  /**
   * Gets the positions that the currently logged in user is a member of.
   *
   * @return The positions that the currently logged in user is a member of.
   */
  public static List<OrganisationObjectDetails> getUserPositions()
    throws AppException, InformationalException {

    // Get positions
    final ListUserPositionDetails listUserPositionDetails = curam.core.sl.fact.PositionFactory.newInstance().getPositionsForUser();

    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    for (int i = 0; i < listUserPositionDetails.dtlsList.dtls.size(); i++) {
      final OrganisationObjectDetails positionDetails = new OrganisationObjectDetails();

      positionDetails.value = TARGETITEMTYPE.POSITION
        + CuramConst.gkPipeDelimiter
        + listUserPositionDetails.dtlsList.dtls.item(i).positionID;
      positionDetails.name = listUserPositionDetails.dtlsList.dtls.item(i).positionName
        + CuramConst.gkSpace + GeneralConst.gkLeftSquareBracket
        + CodeTable.getOneItem(TARGETITEMTYPE.TABLENAME,
        TARGETITEMTYPE.POSITION)
        + GeneralConst.gkRightSquareBracket;

      orgObjects.add(positionDetails);
    }
    return orgObjects;
  }

  /**
   * Gets the work queues that the currently logged in user is subscribed to.
   *
   * @return The work queues that the currently logged in user is subscribed to.
   */
  public static List<OrganisationObjectDetails> getUserWorkQueues()
    throws AppException, InformationalException {

    // Get work queues
    final UserNameKey key = new UserNameKey();

    key.userName = TransactionInfo.getProgramUser();

    final List<OrganisationObjectDetails> orgObjects = new ArrayList<OrganisationObjectDetails>();

    final WorkQueueDetailsList subscribedWorkQueueList = InboxFactory.newInstance().getWorkQueueForUser(
      key);

    for (int i = 0; i < subscribedWorkQueueList.dtls.size(); i++) {
      final OrganisationObjectDetails workQueueDetails = new OrganisationObjectDetails();

      workQueueDetails.value = TARGETITEMTYPE.WORKQUEUE
        + CuramConst.gkPipeDelimiter
        + subscribedWorkQueueList.dtls.item(i).workQueueID;
      workQueueDetails.name = subscribedWorkQueueList.dtls.item(i).name
        + CuramConst.gkSpace + GeneralConst.gkLeftSquareBracket
        + CodeTable.getOneItem(TARGETITEMTYPE.TABLENAME,
        TARGETITEMTYPE.WORKQUEUE)
        + GeneralConst.gkRightSquareBracket;

      orgObjects.add(workQueueDetails);
    }

    return orgObjects;
  }

  /**
   * This method converts the XML string representation of a query into the task
   * query criteria struct.
   *
   * @param xmlCriteria
   * The task query criteria XML string.
   *
   * @return The task query criteria struct.
   */
  public static TaskQueryCriteria parseXMLQueryCriteria(String xmlCriteria)
    throws AppException, InformationalException {

    // throw an informational for the number of records found.
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final TaskQueryCriteria criteria = new TaskQueryCriteria();

    try {

      final SAXBuilder sb = XMLParserCache.getSAXBuilderDisallowAllDTD();
      final curam.common.util.xml.dom.Document doc =
        sb.build(new InputSource(new StringReader(xmlCriteria)));

      criteria.searchMyTasksOnly = Boolean.valueOf(
        getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + FROMMYTASKSONLY
        + XPATH_NODE_SEPARATOR + XPATH_TEXT));
      criteria.selectedOrgObjects = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + SELECTEDORGOBJECTS
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      final OrgObjectTabList selectedOrgObjects = new OrgObjectTabList();

      selectedOrgObjects.orgObjects = criteria.selectedOrgObjects;
      final OrgObjectNames orgObjectNames = getSelectedOrgObjectNames(
        selectedOrgObjects);

      criteria.selectedOrgObjectNames = orgObjectNames.names;

      final String busObjIDString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + BUSOBJECTID
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (busObjIDString.trim().length() != 0) {
        criteria.businessObjectID = Long.valueOf(busObjIDString);
      }
      criteria.businessObjectType = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + BUSOBJECTTYPE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      final BusinessObjectKey busObjKey = new BusinessObjectKey();

      busObjKey.businessObjectID = criteria.businessObjectID;
      busObjKey.businessObjectType = criteria.businessObjectType;
      criteria.businessObjectName = getBusinessObjectName(busObjKey).businessObjectName;

      criteria.status = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + STATUS
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);
      criteria.deadlineDue = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + DEADLINEDUE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      final String deadlineFromString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + DEADLINEFROMDATE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (deadlineFromString.trim().length() != 0) {
        criteria.deadlineFromDate = new Date(
          Long.valueOf(deadlineFromString).longValue());
      }

      final String deadlineToString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + DEADLINETODATE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (deadlineToString.trim().length() != 0) {
        criteria.deadlineToDate = new Date(
          Long.valueOf(deadlineToString).longValue());
      }
      criteria.taskCategory = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + TASKCATEGORY
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      final String creationFromString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + CREATIONFROMDATE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (creationFromString.trim().length() != 0) {
        criteria.creationFromDate = new Date(
          Long.valueOf(creationFromString).longValue());
      }

      final String creationToString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + CREATIONTODATE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (creationToString.trim().length() != 0) {
        criteria.creationToDate = new Date(
          Long.valueOf(creationToString).longValue());
      }

      final String creationLastNumDaysString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + LASTNUMBEROFDAYS
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (creationLastNumDaysString.trim().length() != 0) {
        criteria.creationLastNumberOfDays = Integer.valueOf(
          creationLastNumDaysString);
      } else {
        criteria.creationLastNumberOfDays = -1;
      }

      final String creationLastNumWeeksString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + LASTNUMBEROFWEEKS
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (creationLastNumWeeksString.trim().length() != 0) {
        criteria.creationLastNumberOfWeeks = Integer.valueOf(
          creationLastNumWeeksString);
      } else {
        criteria.creationLastNumberOfWeeks = -1;
      }

      final String restartFromString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + RESTARTFROMDATE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (restartFromString.trim().length() != 0) {
        criteria.restartFromDate = new Date(
          Long.valueOf(restartFromString).longValue());
      }

      final String restartToString = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + RESTARTTODATE
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

      if (restartToString.trim().length() != 0) {
        criteria.restartToDate = new Date(
          Long.valueOf(restartToString).longValue());
      }
      criteria.priority = getNodeText(doc,
        XPATH_START + QUERY + XPATH_NODE_SEPARATOR + PRIORITY
        + XPATH_NODE_SEPARATOR + XPATH_TEXT);

    } catch (final Exception e) {
      final AppException appEx = new AppException(
        BPOQUERY.ERR_QUERY_FAILED_TO_PARSE_SAVED_QUERY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    return criteria;
  }

  /**
   * Converts the a tab delimited string of organization objects to a list of
   * organization object details. The format of the tabbed delimited string is
   * "OrgObjectType|OrgObjectID    OrgObjectType|OrgObjectID" where each type
   * and ID pair is separated by the pipe character e.g.
   * "RL9|userName    RL21|15    RL20|25".
   *
   * @param tabList
   * A tab delimited string of organization objects.
   *
   * @return A list of organization object details.
   */
  public static List<OrganisationObjectDetails> convertTabListToOrgObjectList(String tabList) throws AppException,
      InformationalException {

    final List<OrganisationObjectDetails> answer = new ArrayList<OrganisationObjectDetails>();

    if (tabList.length() != 0) {
      final StringList orgObjects = StringUtil.tabText2StringListWithTrim(
        tabList);

      final Iterator<String> iter = orgObjects.iterator();

      while (iter.hasNext()) {
        final StringList orgObjectStringList = StringUtil.delimitedText2StringListWithTrim(
          iter.next(), CuramConst.gkPipeDelimiterChar);

        final OrganisationObjectDetails nextOrgObject = new OrganisationObjectDetails();

        nextOrgObject.value = orgObjectStringList.item(0);
        nextOrgObject.name = orgObjectStringList.item(1);
        answer.add(nextOrgObject);
      }
    }
    return answer;
  }

  /**
   * Sets the assignee search criteria for the current search when searching by
   * organization object.
   *
   * @param key The search criteria.
   * @param orgObject The organization object details to be searched.
   */
  public static void setAssigneeCriteria(TaskQueryCriteria key,
    OrganisationObjectDetails orgObject) {

    key.assigneeType = orgObject.value;
    if (key.assigneeType.equals(TARGETITEMTYPE.USER)
      || key.assigneeType.equals(TARGETITEMTYPE.EXTERNALUSER)) {
      key.relatedName = orgObject.name;
      key.relatedID = 0;
    } else if (key.assigneeType.length() != 0) {
      key.relatedID = Long.parseLong(orgObject.name);
      key.relatedName = curam.util.resources.GeneralConstants.kEmpty;
    }
  }

  /**
   * Indicates whether the specified date time is in the past or not.
   *
   * @param dateTime
   * A date time.
   *
   * @return true if the specified date time is in the past, false otherwise.
   */
  public static boolean isOverdue(DateTime dateTime) {

    boolean answer = false;

    if (!dateTime.equals(DateTime.kZeroDateTime)
      && dateTime.before(DateTime.getCurrentDateTime())) {
      answer = true;
    }
    return answer;
  }
}
