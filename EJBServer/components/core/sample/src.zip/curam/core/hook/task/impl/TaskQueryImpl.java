/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.hook.task.impl;


import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.QUERYTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.QueryFactory;
import curam.core.sl.entity.struct.QueryDtls;
import curam.core.sl.entity.struct.QueryKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.intf.Query;
import curam.core.sl.struct.BusinessObjectKey;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskQueryDetails;
import curam.core.sl.struct.TaskQueryResult;
import curam.message.BPOINBOX;
import curam.message.BPOTASKSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;


/**
 * Default implementation of {@link TaskQuery}.
 */
public class TaskQueryImpl implements TaskQuery {

  /**
   * Creates a task query.
   *
   * @param details The task query criteria for a query.
   *
   * @return The identifier of the new query.
   *
   * @see #validateTaskQuery(TaskQueryDetails)
   */
  @Override
  public long createTaskQuery(TaskQueryDetails details) throws AppException,
      InformationalException {

    final QueryDtls queryDetails = details.queryDtls;

    queryDetails.query = SearchTaskUtilities.formatXMLQueryCriteria(
      details.criteria);
    queryDetails.queryName = details.criteria.queryName;
    queryDetails.queryType = QUERYTYPE.TASKQUERY;
    queryDetails.statusCode = RECORDSTATUS.NORMAL;
    queryDetails.userName = UserAccessFactory.newInstance().getUserDetails().userName;

    validateTaskQuery(details);

    TransactionInfo.getInformationalManager().failOperation();

    return QueryFactory.newInstance().create(queryDetails).queryID;
  }

  /**
   * Modifies a task query's criteria.
   *
   * @param details The task query criteria to replace the existing criteria.
   *
   * @return The identifier of the modified query.
   *
   * @see #validateTaskQuery(TaskQueryDetails)
   */
  @Override
  public long modifyTaskQuery(TaskQueryDetails details) throws AppException,
      InformationalException {

    final QueryDtls queryDetails = details.queryDtls;

    queryDetails.query = SearchTaskUtilities.formatXMLQueryCriteria(
      details.criteria);
    queryDetails.queryName = details.criteria.queryName;
    queryDetails.queryType = QUERYTYPE.TASKQUERY;
    queryDetails.statusCode = RECORDSTATUS.NORMAL;
    queryDetails.userName = UserAccessFactory.newInstance().getUserDetails().userName;

    validateTaskQuery(details);

    TransactionInfo.getInformationalManager().failOperation();

    return QueryFactory.newInstance().modify(queryDetails).queryID;
  }

  /**
   * Runs a task query that has been previously saved.
   *
   * <P>
   * The number of tasks that returned may be limited. This may be changed by
   * altering the {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE
   * ENV_INBOX_MAX_TASK_LIST_SIZE} application property. The default is 100. If
   * the number of records exceeds the specified maximum value then an
   * informational message is returned (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   * <P>
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. The sort order can be changed by using Guice
   * to bind {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param key The identifier of the task query.
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of tasks that satisfy the query's criteria.
   */
  @Override
  public TaskQueryResult runTaskQuery(QueryKey key,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException {

    final QueryDtls details = QueryFactory.newInstance().read(key);
    final TaskQueryDetails taskQueryDetails = new TaskQueryDetails();

    taskQueryDetails.actionIDProperty = ClientActionConst.kRun_Query;
    taskQueryDetails.criteria = SearchTaskUtilities.getTaskQueryCriteria(
      details);
    taskQueryDetails.queryDtls = details;

    return runTaskQuery(taskQueryDetails, readMultiDetails);
  }

  /**
   * Runs a task query using the criteria details as entered by the user.
   *
   * <P>
   * The number of tasks that returned may be limited. This may be changed by
   * altering the {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE
   * ENV_INBOX_MAX_TASK_LIST_SIZE} application property. The default is 100. If
   * the number of records exceeds the specified maximum value then an
   * informational message is returned (
   * {@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   * <P>
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. The sort order can be changed by using Guice
   * to bind {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param details The identifier of the task query.
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of tasks that satisfy the query's criteria.
   */
  @Override
  public TaskQueryResult runTaskQuery(TaskQueryDetails details,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException {

    final TaskQueryResult result = new TaskQueryResult();

    details.criteria.isTaskQuery = true;
    result.queryID = details.queryDtls.queryID;
    result.criteria = details.criteria;
    if (details.queryDtls.queryName.length() == 0) {
      details.queryDtls.queryName = result.criteria.queryName;
    }

    validateTaskQuery(details);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager.failOperation();

    if (informationalManager.obtainInformationalAsString().length == 0) {
      result.resultList = SearchTaskUtilities.searchTask(details.criteria,
        readMultiDetails);
      final BusinessObjectKey busObjKey = new BusinessObjectKey();

      busObjKey.businessObjectID = details.criteria.businessObjectID;
      busObjKey.businessObjectType = details.criteria.businessObjectType;
      result.criteria.businessObjectName = SearchTaskUtilities.getBusinessObjectName(busObjKey).businessObjectName;

      // Don't update the run frequency on creation of the query
      if (details.queryDtls.queryID != 0) {
        final Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();
        final QueryKey key = new QueryKey();

        key.queryID = details.queryDtls.queryID;
        queryObj.modifyQueryRunFrequency(key);
      }
    }
    return result;
  }

  /**
   * Validates the task query criteria before performing a search.
   * <P>
   * The validations executed are:
   * <ul>
   * <li>A query name uniquely identifying the query must be supplied</li>
   * <li>A query name must not already exist in the users previously stored task
   * queries</li>
   * <li>The deadline due field must be blank if either the deadline from or to
   * date fields are filled.</li>
   * <li>The creation from and to date fields must be blank if either the last
   * number of days or last number of weeks fields are filled</li>
   * <li>The creation time last number of days field must be blank if the last
   * number of weeks field is filled</li>
   * <li>Creation from date must be before creation to date</li>
   * <li>Restart from date must be before restart to date</li>
   * <li>Deadline from date must be before deadline to date</li>
   * </ul>
   *
   * @param details The task query criteria.
   *
   * @see #modifyTaskQuery(TaskQueryDetails)
   * @see #createTaskQuery(TaskQueryDetails)
   */
  @Override
  public void validateTaskQuery(TaskQueryDetails details)
    throws AppException, InformationalException {

    final TaskQueryCriteria criteria = details.criteria;

    // throw an informational for the number of records found.
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (!details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {
      QueryFactory.newInstance().validate(details.queryDtls);
    }
    // Ensure at at least 1 search criteria is entered
    if (!criteria.searchMyTasksOnly
      && criteria.selectedOrgObjects.length() == 0
      && criteria.businessObjectType.length() == 0
      && criteria.businessObjectID == 0 && criteria.status.length() == 0
      && criteria.creationFromDate.isZero()
      && criteria.creationLastNumberOfDays == -1
      && criteria.creationLastNumberOfWeeks == -1
      && criteria.creationToDate.isZero() && criteria.deadlineDue.length() == 0
      && criteria.deadlineFromDate.isZero() && criteria.deadlineToDate.isZero()
      && criteria.restartFromDate.isZero() && criteria.restartToDate.isZero()
      && criteria.taskCategory.length() == 0 && criteria.priority.length() == 0) {
      final AppException appEx = new AppException(
        BPOINBOX.ERR_TASK_SEARCH_NO_CRITERIA);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    } else if (criteria.selectedOrgObjects.length() == 0
      && criteria.businessObjectType.length() == 0
      && !criteria.searchMyTasksOnly) {
      // One of assigned to or business object type or my tasks only must be
      // selected.
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_MINIMUM_CRITERIA_NOT_ENTERED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Ensure that both the business object type and business object name are
    // both populated or both empty
    if (!"".equals(criteria.businessObjectType)
      && criteria.businessObjectID == 0
        || criteria.businessObjectID != 0
          && "".equals(criteria.businessObjectType)) {
      final AppException appEx = new AppException(
        BPOINBOX.ERR_TASK_BUSINESS_OBJECT_TYPE_NOT_SELECTED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Ensure the selected business object's type matches the business object
    // type in the drop down list. An exception will be thrown if this not is
    // the case.
    try {
      final BusinessObjectKey busObjKey = new BusinessObjectKey();

      busObjKey.businessObjectID = criteria.businessObjectID;
      busObjKey.businessObjectType = criteria.businessObjectType;
      SearchTaskUtilities.getBusinessObjectName(busObjKey);
    } catch (final Exception e) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_BUSINESS_OBJECT_TYPE_MISMATCH);

      appEx.arg(
        new CodeTableItemIdentifier(BUSINESSOBJECTTYPE.TABLENAME,
        criteria.businessObjectType));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (criteria.selectedOrgObjects.length() != 0 && criteria.searchMyTasksOnly) {
      // My tasks only and assignee type cannot be selected together
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_USER_TASKS_ONLY_AND_ASSIGNEE_MUTUALLY_EXCLUSIVE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The deadline due value is mutually exclusive with the deadline from and
    // to dates
    if (criteria.deadlineDue.length() != 0
      && (!criteria.deadlineFromDate.isZero()
        || !criteria.deadlineToDate.isZero())) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_DEADLINE_DUE_MUTUALLY_EXCLUSIVE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Creation from date must be before creation to date
    if (!criteria.creationToDate.isZero()
      && criteria.creationFromDate.after(criteria.creationToDate)) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_CREATION_FROM_BEFORE_CREATION_TO);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Restart from date must be before restart to date
    if (!criteria.restartToDate.isZero()
      && criteria.restartFromDate.after(criteria.restartToDate)) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_RESTART_FROM_BEFORE_RESTART_TO);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Deadline from date must be before deadline to date
    if (!criteria.deadlineToDate.isZero()
      && criteria.deadlineFromDate.after(criteria.deadlineToDate)) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_DEADLINE_FROM_BEFORE_DEADLINE_TO);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Creation from date is mutually exclusive with the last number of days and
    // last number of weeks
    if (!criteria.creationFromDate.isZero()
      && (criteria.creationLastNumberOfDays != -1
        || criteria.creationLastNumberOfWeeks != -1)) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_CREATION_DATE_MUTUALLY_EXCLUSIVE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Creation to date is mutually exclusive with the last number of days and
    // last number of weeks
    if (!criteria.creationToDate.isZero()
      && (criteria.creationLastNumberOfDays != -1
        || criteria.creationLastNumberOfWeeks != -1)) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_CREATION_DATE_MUTUALLY_EXCLUSIVE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Last number of days field is mutually exclusive with last number of weeks
    // field
    if (criteria.creationLastNumberOfDays != -1
      && criteria.creationLastNumberOfWeeks != -1) {
      final AppException appEx = new AppException(
        BPOTASKSEARCH.ERR_CREATION_DATE_NUMBER_DAYS_AND_WEEKS_MUTUALLY_EXCLUSIVE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appEx, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
}
