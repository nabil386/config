/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;


import curam.core.facade.fact.RulesEditorFactory;
import curam.core.facade.intf.RulesEditor;
import curam.core.facade.struct.ObjectiveGroupSummaryDetails;
import curam.core.facade.struct.ObjectiveListGroupSummaryDtls;
import curam.core.facade.struct.ReadDataAssignmentDetails;
import curam.core.facade.struct.ReadXMLStringDetails;
import curam.core.facade.struct.RuleGroupSummaryDetails;
import curam.core.facade.struct.RuleSetIDStruct;
import curam.core.facade.struct.RuleSetNodeKey;
import curam.core.facade.struct.RuleSetType;
import curam.core.facade.struct.RuleSummaryDetail;
import curam.core.facade.struct.RulesListGroupSummaryDetails;
import curam.core.facade.struct.WorkAllocationObjectiveAndTagDetails;
import curam.core.facade.struct.WorkAllocationRuleSetSummaryDtls;
import curam.core.sl.infrastructure.impl.XmlTreeConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.common.util.xml.dom.Element;


/**
 * This class builds the WorkAllocationRuleset tree in XML format.
 *
 */
public abstract class WorkAllocationRuleSetTreeView extends curam.core.facade.base.WorkAllocationRuleSetTreeView {

  /**
   * Fetches the WorkAllocation RuleSet data and builds tree in XML format
   *
   * @param ruleSetIDStruct identifies the RuleSetID
   *
   * @return XML Data.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ReadXMLStringDetails buildWorkAllocationRuleSetTree(
    RuleSetIDStruct ruleSetIDStruct) throws AppException,
      InformationalException {

    curam.core.facade.struct.ReadXMLStringDetails readXMLDetails = new curam.core.facade.struct.ReadXMLStringDetails();

    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    final RuleSetType ruleSetType = new RuleSetType();

    ruleSetType.ruleSetType = XmlTreeConst.kWorkAllocationRuleSetTreeName;

    readXMLDetails = rulesEditor.createRulesTree(ruleSetIDStruct, ruleSetType);

    return readXMLDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates all NodeTypes allowed in the Rules tree
   *
   * @return All Rules NodeTypes
   */
  protected static Element createNodeTypesXML() {

    // BEGIN, CR00023323, SK
    final Element nodeTypesElement = new Element(XmlTreeConst.kNodeTypes,
      XmlTreeConst.kNamespace);
    Element nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    // Build Work allocation Rule Set node type
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kWARuleSet);
    Element actionsElement = new Element(XmlTreeConst.kActions,
      XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    Element actionElement = new Element(XmlTreeConst.kAction,
      XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    Element paramElement = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);

    // Build Rule Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID1 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID1);
    paramElementforNodeID1.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kObjectiveGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID2 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID2);
    paramElementforNodeID2.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kObjective);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID3 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID3);
    paramElementforNodeID3.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective List Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kObjectiveListGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID4 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID4);
    paramElementforNodeID4.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Rule List Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kRuleListGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID5 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID5);
    paramElementforNodeID5.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Rule node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRule);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID6 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID6);
    paramElementforNodeID6.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Data Item Assignment node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kDataItemAssignment);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID7 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID7);
    paramElementforNodeID7.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // END, CR00023323
    return nodeTypesElement;

  }

  // ___________________________________________________________________________
  /**
   * Constructs Work allocation RuleSet Node
   *
   * @param ruleSetIDStruct identifies WARuleSet.
   *
   * @return NodeSetElement with all nodes.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createWorkAllocationRuleSetXML(
    RuleSetIDStruct ruleSetIDStruct) throws AppException,
      InformationalException {

    // END, CR00198672
    // Work allocation RuleSetSummary variables
    WorkAllocationRuleSetSummaryDtls workAllocationRuleSetSummaryDtls = new WorkAllocationRuleSetSummaryDtls();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    final String ruleSetID = ruleSetIDStruct.ruleSetID;
    final TreeXMLNodeDetails treeXMLNodeDetails = TreeXMLNodeCache.getInstance().getTreeXMLNodeDetails(
      ruleSetID);

    // Get Work allocation Rule Set details
    workAllocationRuleSetSummaryDtls = rulesEditor.readWorkAllocationRuleSetSummary(
      ruleSetIDStruct);
    // BEGIN, CR00023323, SK
    final Element nodeSetElement = new Element(XmlTreeConst.kNodeSet,
      XmlTreeConst.kNamespace);
    final String wARuleSetName = workAllocationRuleSetSummaryDtls.workAllocRuleSetDtls.ruleSetName;
    final String wARuleSetNodeID = workAllocationRuleSetSummaryDtls.workAllocRuleSetDtls.ruleSetID;

    final Element workAllocationRuleSetNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    nodeSetElement.addContent(workAllocationRuleSetNode);

    workAllocationRuleSetNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + wARuleSetNodeID);

    final String stStartNodeId = XmlTreeConst.kRuleIDPrefix
      + treeXMLNodeDetails.getStLastAccessedNodeId();

    nodeSetElement.setAttribute(XmlTreeConst.kStartNode, stStartNodeId);

    workAllocationRuleSetNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kWARuleSet);

    final Element wARuleSetTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    workAllocationRuleSetNode.addContent(wARuleSetTitleElement);
    wARuleSetTitleElement.setText(wARuleSetName);

    final Element wARuleSetParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    workAllocationRuleSetNode.addContent(wARuleSetParamValueElement);
    wARuleSetParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      wARuleSetNodeID);
    // END, CR00023323
    for (int i = 0; i
      < workAllocationRuleSetSummaryDtls.childDtls.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID = workAllocationRuleSetSummaryDtls.workAllocRuleSetDtls.ruleSetID;
      ruleSetNodeKey.nodeID = workAllocationRuleSetSummaryDtls.childDtls.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      // create different nodes depending on the node type
      if (workAllocationRuleSetSummaryDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // Rule Group
        workAllocationRuleSetNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (workAllocationRuleSetSummaryDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOG)) { // Objective
        // Group
        workAllocationRuleSetNode.addContent(
          createObjectiveGroupXML(ruleSetNodeKey));
      } else if (workAllocationRuleSetSummaryDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOLG)) { // Objective
        // List Group
        workAllocationRuleSetNode.addContent(
          createObjectiveListGroupXML(ruleSetNodeKey));
      } // END, CR00023323
      else { // RuleListGroup
        workAllocationRuleSetNode.addContent(
          createRuleListGroupXML(ruleSetNodeKey));
      }
    }

    return nodeSetElement;
  }

  // ___________________________________________________________________________
  /**
   * Constructs ObjectiveGroup Node
   *
   * @param ruleSetNodeKey identifies the Objective Group in the Rule Set.
   *
   * @return ObjectiveGroupNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createObjectiveGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    // Objective Group Summary variables
    ObjectiveGroupSummaryDetails objectiveGroupSummary = new ObjectiveGroupSummaryDetails();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // read objective group details
    objectiveGroupSummary = rulesEditor.readObjectiveGroupSummary(
      ruleSetNodeKey);
    final String objectiveGroupName = objectiveGroupSummary.objectiveGroupDtls.name;

    final String objectiveGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    final Element objectiveGroupNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    objectiveGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + objectiveGroupNodeID);
    objectiveGroupNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kObjectiveGroup);

    final Element objectiveGroupTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    objectiveGroupNode.addContent(objectiveGroupTitleElement);
    objectiveGroupTitleElement.setText(objectiveGroupName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      objectiveGroupNodeID);
    // END, CR00023323
    for (int i = 0; i < objectiveGroupSummary.childItemList.nodeDetails.size(); i++) {

      ruleSetNodeKey.nodeID = objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        objectiveGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOG)) { // ObjectiveGroup
        objectiveGroupNode.addContent(createObjectiveGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOLG)) { // ObjectiveListGroup
        objectiveGroupNode.addContent(
          createObjectiveListGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        objectiveGroupNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      } // END, CR00023323
      else {
        objectiveGroupNode.addContent(createObjectivesXML(ruleSetNodeKey));
      }

    }

    return objectiveGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs ObjectiveListGroup Node
   *
   * @param ruleSetNodeKey identifies the Objective List Group in the RuleSet
   *
   * @return ObjectiveListGroupNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createObjectiveListGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    ObjectiveListGroupSummaryDtls objectiveListGroupSummaryDtls = new ObjectiveListGroupSummaryDtls();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Read Objective List Group details
    objectiveListGroupSummaryDtls = rulesEditor.readObjectiveListGroupSummary(
      ruleSetNodeKey);

    final String objectiveListGroupName = objectiveListGroupSummaryDtls.summaryDtls.name;
    final String objectiveListGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    final Element objectiveListGroupNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    objectiveListGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + objectiveListGroupNodeID);
    objectiveListGroupNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kObjectiveListGroup);

    final Element objectiveListGroupTitleElement = new Element(
      XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    objectiveListGroupNode.addContent(objectiveListGroupTitleElement);
    objectiveListGroupTitleElement.setText(objectiveListGroupName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveListGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveListGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      objectiveListGroupNodeID);
    // END, CR00023323
    for (int i = 0; i
      < objectiveListGroupSummaryDtls.nodeItems.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID = objectiveListGroupSummaryDtls.summaryDtls.ruleSetID;
      ruleSetNodeKey.nodeID = objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        objectiveListGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOG)) { // Objective Group
        objectiveListGroupNode.addContent(
          createObjectiveGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOLG)) { // Objective List Group
        objectiveListGroupNode.addContent(
          createObjectiveListGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        objectiveListGroupNode.addContent(
          createRuleListGroupXML(ruleSetNodeKey));
      } // END, CR00023323
      else {
        objectiveListGroupNode.addContent(createObjectivesXML(ruleSetNodeKey));
      }

    }
    return objectiveListGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs RuleListGroup Node
   *
   * @param ruleSetNodeKey identifies the Rule List Group in the RuleSet.
   *
   * @return RuleListGroupNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createRuleListGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    RulesListGroupSummaryDetails rulesListGroupSummaryDetails = new RulesListGroupSummaryDetails();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Read Rule List Group details
    rulesListGroupSummaryDetails = rulesEditor.readRuleListGroupSummary(
      ruleSetNodeKey);

    final String rulesListGroupName = rulesListGroupSummaryDetails.summaryDtls.name;
    final String ruleListGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    final Element ruleListGroupNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    ruleListGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + ruleListGroupNodeID);
    ruleListGroupNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kRuleListGroup);

    final Element ruleListGroupTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    ruleListGroupNode.addContent(ruleListGroupTitleElement);
    ruleListGroupTitleElement.setText(rulesListGroupName);
    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleListGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleListGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      ruleListGroupNodeID);
    // END, CR00023323
    for (int i = 0; i
      < rulesListGroupSummaryDetails.childItemList.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID = rulesListGroupSummaryDetails.summaryDtls.ruleSetID;
      ruleSetNodeKey.nodeID = rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        ruleListGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kR)) { // Rule
        ruleListGroupNode.addContent(createRuleXML(ruleSetNodeKey));
      } else if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        ruleListGroupNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      } // END, CR00023323
      else {
        ruleListGroupNode.addContent(
          createDataItemAssignmentXML(ruleSetNodeKey));
      }

    }

    return ruleListGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs RuleGroup Node
   *
   * @param ruleSetNodeKey RuleSetID.
   *
   * @return RuleGroupNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createRuleGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    RuleGroupSummaryDetails ruleGroupSummaryDetails = new RuleGroupSummaryDetails();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Reads Rule Group details
    ruleGroupSummaryDetails = rulesEditor.readRuleGroupSummary(ruleSetNodeKey);

    final String ruleGroupName = ruleGroupSummaryDetails.ruleGroupDtls.name;

    final String ruleGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    final Element ruleGroupNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    ruleGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + ruleGroupNodeID);
    ruleGroupNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kRuleGroup);
    final Element ruleGroupTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    ruleGroupNode.addContent(ruleGroupTitleElement);
    ruleGroupTitleElement.setText(ruleGroupName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      ruleGroupNodeID);
    // END, CR00023323
    for (int i = 0; i
      < ruleGroupSummaryDetails.childItemDtls.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID = ruleGroupSummaryDetails.ruleGroupDtls.ruleSetID;
      ruleSetNodeKey.nodeID = ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        ruleGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kR)) { // Rule
        ruleGroupNode.addContent(createRuleXML(ruleSetNodeKey));
      } else if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        ruleGroupNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      } // END, CR00023323
      else {
        ruleGroupNode.addContent(createDataItemAssignmentXML(ruleSetNodeKey));
      }

    }

    return ruleGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs Objective Node
   *
   * @param ruleSetNodeKey identifies the Objectives inside the RuleSet
   *
   * @return ObjectiveNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createObjectivesXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    WorkAllocationObjectiveAndTagDetails workAllocationObjectiveAndTagDetails = new WorkAllocationObjectiveAndTagDetails();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Reads objective details
    workAllocationObjectiveAndTagDetails = rulesEditor.readWAObjectiveSummary(
      ruleSetNodeKey);
    final String objectiveNodeID = Long.toString(ruleSetNodeKey.nodeID);
    final String objectiveName = workAllocationObjectiveAndTagDetails.summaryDetails.objectiveDtls.name;
    // BEGIN, CR00023323, SK
    final Element objectiveNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    objectiveNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + objectiveNodeID);
    objectiveNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kObjective);

    final Element objectiveTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    objectiveNode.addContent(objectiveTitleElement);
    objectiveTitleElement.setText(objectiveName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      objectiveNodeID);
    // END, CR00023323
    for (int i = 0; i
      < workAllocationObjectiveAndTagDetails.summaryDetails.childItemDtls.childDtls.nodeDetails.size(); i++) {

      ruleSetNodeKey.nodeID = workAllocationObjectiveAndTagDetails.summaryDetails.childItemDtls.childDtls.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (workAllocationObjectiveAndTagDetails.summaryDetails.childItemDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        objectiveNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      }
      if (workAllocationObjectiveAndTagDetails.summaryDetails.childItemDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        objectiveNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      }
      // END, CR00023323

    }

    return objectiveNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs Rule Node
   *
   * @param ruleSetNodeKey identifies the Rule inside the RuleSet.
   *
   * @return RuleNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createRuleXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    RuleSummaryDetail ruleSummaryDetail = new RuleSummaryDetail();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Reads Rule details
    ruleSummaryDetail = rulesEditor.readRuleSummary(ruleSetNodeKey);

    final String ruleName = ruleSummaryDetail.ruleDataDtls.ruleName;
    final String ruleNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    final Element ruleNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    ruleNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + ruleNodeID);
    ruleNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kRule);

    final Element ruleTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    ruleNode.addContent(ruleTitleElement);
    ruleTitleElement.setText(ruleName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      ruleNodeID);
    // END, CR00023323
    return ruleNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs DataItemAssignment Node
   *
   * @param ruleSetNodeKey identifies the Data Item Assignment inside the
   * RuleSet.
   *
   * @return DataItemAssignmentNodeElementDetails.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createDataItemAssignmentXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    // END, CR00198672
    ReadDataAssignmentDetails readDataAssignmentDetails = new ReadDataAssignmentDetails();
    final RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    readDataAssignmentDetails = rulesEditor.readDataAssignment(ruleSetNodeKey);
    final String dataAssignmentName = readDataAssignmentDetails.formulaString;

    final String dataItemNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    final Element dataItemAssignmentNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    dataItemAssignmentNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + dataItemNodeID);
    dataItemAssignmentNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kDataItemAssignment);

    final Element dataItemTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    dataItemAssignmentNode.addContent(dataItemTitleElement);
    dataItemTitleElement.setText(dataAssignmentName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    dataItemAssignmentNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    dataItemAssignmentNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      dataItemNodeID);
    // END, CR00023323
    return dataItemAssignmentNode;
  }
}
