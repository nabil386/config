/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2003,2019
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office
 */

package curam.core.facade.impl;

import curam.codetable.ORGOBJECTTYPE;
import curam.core.facade.struct.CaseMemberTaskSearchKey;
import curam.core.facade.struct.CaseTaskSearchKey;
import curam.core.facade.struct.CloseTaskKey_eo;
import curam.core.facade.struct.ConcernTaskSearchKey;
import curam.core.facade.struct.CreateAllocationTargetDetails;
import curam.core.facade.struct.CreateAllocationTargetItemDetails;
import curam.core.facade.struct.CreateTaskDefinitionDetails;
import curam.core.facade.struct.CreateWorkAllocationFunctionDetails;
import curam.core.facade.struct.CreateWorkQueueDetails;
import curam.core.facade.struct.DeleteAllocationTargetItemKey;
import curam.core.facade.struct.DeleteAllocationTargetKey;
import curam.core.facade.struct.DeleteTaskDefinitionKey;
import curam.core.facade.struct.DeleteWorkAllocationFunctionKey;
import curam.core.facade.struct.DeleteWorkQueueKey;
import curam.core.facade.struct.DeleteWorkQueueSubscriptionKey;
import curam.core.facade.struct.ForwardTaskDetails;
import curam.core.facade.struct.ListAllocationTargetDetails;
import curam.core.facade.struct.ListAvailableWorkQueuesForCurrentUserDetails;
import curam.core.facade.struct.ListCaseByCurrentUserDetails;
import curam.core.facade.struct.ListDeadlineFunctionDetails;
import curam.core.facade.struct.ListInitialAllocationFunctionDetails;
import curam.core.facade.struct.ListReservedTasksForCurrentUser;
import curam.core.facade.struct.ListTaskDefinitionDetails;
import curam.core.facade.struct.ListTaskHistoryDetails;
import curam.core.facade.struct.ListTaskHistoryKey;
import curam.core.facade.struct.ListUnreservedTasksForCurrentUserDetails;
import curam.core.facade.struct.ListUnreservedWorkQueueTasksDetails;
import curam.core.facade.struct.ListUnreservedWorkQueueTasksKey;
import curam.core.facade.struct.ListUserOrgObjectWorkQueueDetails;
import curam.core.facade.struct.ListWorkAllocationFunctionDetails;
import curam.core.facade.struct.ListWorkQueueDetails;
import curam.core.facade.struct.ListWorkQueueSubsrciptionsKey;
import curam.core.facade.struct.ModifyAllocationTargetDetails;
import curam.core.facade.struct.ModifyTaskDefinitionDetails;
import curam.core.facade.struct.ModifyWATaskDetails;
import curam.core.facade.struct.ModifyWorkAllocationFunctionKey;
import curam.core.facade.struct.ModifyWorkQueueDetails;
import curam.core.facade.struct.ReadActionPageDetails;
import curam.core.facade.struct.ReadActionPageDetailsKey;
import curam.core.facade.struct.ReadAllocationTargetDetails;
import curam.core.facade.struct.ReadAllocationTargetKey;
import curam.core.facade.struct.ReadAllocationTargetSummaryDetails;
import curam.core.facade.struct.ReadAllocationTargetSummaryDetailsKey;
import curam.core.facade.struct.ReadAllocationTargetSummaryDtls;
import curam.core.facade.struct.ReadTaskDefinitionDetails;
import curam.core.facade.struct.ReadTaskDefinitionForModificationDetails;
import curam.core.facade.struct.ReadTaskDefinitionForModificationDetailsKey;
import curam.core.facade.struct.ReadTaskDefinitionKey;
import curam.core.facade.struct.ReadTaskForModificationDetails;
import curam.core.facade.struct.ReadTaskForModificationKey;
import curam.core.facade.struct.ReadTaskSummaryDetails;
import curam.core.facade.struct.ReadTaskSummaryDetailsKey;
import curam.core.facade.struct.ReadWorkAllocationFunctionDetails;
import curam.core.facade.struct.ReadWorkAllocationFunctionKey;
import curam.core.facade.struct.ReadWorkQueueDetails;
import curam.core.facade.struct.ReadWorkQueueKey;
import curam.core.facade.struct.ReallocateTaskKey_eo;
import curam.core.facade.struct.ReserveTaskKey_eo;
import curam.core.facade.struct.SearchTasksForConcernAndCaseDetails;
import curam.core.facade.struct.SearchWorkQueueDetailsList;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.facade.struct.SubscribeCurrentUserToWorkQueueKey;
import curam.core.facade.struct.SubscribeUserWorkQueueKey;
import curam.core.facade.struct.SubscribeWorkQueueInput;
import curam.core.facade.struct.UnreserveTaskKey_eo;
import curam.core.facade.struct.UnsubscribeCurrentUserFromWorkQueueKey;
import curam.core.facade.struct.WorkAllocationTaskAndActivityForUserDetails;
import curam.core.facade.struct.WorkQueueDetailsAndSubscriberList;
import curam.core.facade.struct.WorkQueueSearchInd;
import curam.core.facade.struct.WorkQueueSearchKey;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails;
import curam.core.sl.entity.struct.CatStatusRefUserType;
import curam.core.sl.entity.struct.JobKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.TaskUnreservedDetailsList;
import curam.core.sl.entity.struct.WorkQueueDetailsList;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueNameDetails;
import curam.core.sl.entity.struct.WorkQueueSubscriptionFullDetailsList;
import curam.core.sl.fact.DatabaseWorkQueueSearchFactory;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.OrgObjectLinkFactory;
import curam.core.sl.fact.TaskAssignmentFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.WorkQueueFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.infrastructure.impl.WorkAllocationConst;
import curam.core.sl.intf.OrgObjectLink;
import curam.core.sl.intf.TaskAssignment;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.WorkQueue;
import curam.core.sl.struct.CreateTaskDefinition;
import curam.core.sl.struct.ListAvailableWorkQueueForUserNameKey;
import curam.core.sl.struct.ListReservedTasksForUserKey;
import curam.core.sl.struct.ListUnreservedTasksForUserKey;
import curam.core.sl.struct.ListUserWorkQueueDetailsKey;
import curam.core.sl.struct.ListWorkQueueSubscriptions;
import curam.core.sl.struct.ListWorkQueueSubscriptionsKey;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.SubscribeUserToWorkQueueKey;
import curam.core.sl.struct.UnsubscribeUserFromWorkQueueKey;
import curam.core.sl.struct.WorkAllocationFunctionListByTypeKey_bo;
import curam.core.sl.struct.WorkQueueSubscriptionDetails;
import curam.core.struct.ActivityIntervalDetails;
import curam.core.struct.ActivityRelatedDetails;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.SearchUserByDateRangeResult;
import curam.core.struct.UserActivitySearchKey;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.message.BPOQUERY;
import curam.message.BPOTASKDEFINITION;
import curam.message.BPOWORKALLOCATION;
import curam.message.BPOWORKQUEUE;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringList;
import curam.util.workflow.fact.TaskHistoryAdminFactory;
import curam.util.workflow.intf.TaskHistoryAdmin;
import curam.util.workflow.struct.TaskHistoryInfoList;
import java.util.Calendar;
import java.util.Iterator;

/**
 * This process class provides the functionality for the Work Allocation
 * presentation layer.
 *
 */
public abstract class WorkAllocation
  extends curam.core.facade.base.WorkAllocation {

  protected static final short kDaysInWeek = 7;

  // BEGIN, CR00023312, GM
  protected static final String kManual = WorkAllocationConst.kManual;

  protected static final String kManualCase = WorkAllocationConst.kManualCase;

  protected static final String kManualParticipant =
    WorkAllocationConst.kManualParticipant;

  protected static final String kManualParticipantCase =
    WorkAllocationConst.kManualParticipantCase;

  // END, CR00023312

  // BEGIN, CR00161962, KY
  // __________________________________________________________________________
  /**
   * Lists tasks assigned to the specified Job.
   *
   * @param jobKey
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public TaskUnreservedDetailsList listJobTasks(final JobKey jobKey)
    throws AppException, InformationalException {

    final TaskAssignment taskAssignmentObj =
      TaskAssignmentFactory.newInstance();

    return taskAssignmentObj.listJobTasks(jobKey);
  }

  // END, CR00161962

  // BEGIN, CR00161962, KY
  /**
   * Lists tasks assigned to the specified Position.
   *
   * @param positionKey
   * @return UnreservedTaskDetailsList
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public TaskUnreservedDetailsList
    listPositionTasks(final PositionKey positionKey)
      throws AppException, InformationalException {

    final TaskAssignment taskAssignmentObj =
      TaskAssignmentFactory.newInstance();

    return taskAssignmentObj.listPositionTasks(positionKey);
  }

  // END, CR00161962

  /**
   * Creates a task definition.
   *
   * @param details
   * Task definition details.
   */
  @Override
  public void createTaskDefinition(final CreateTaskDefinitionDetails details)
    throws AppException, InformationalException {

    // Task Definition service layer objects
    final curam.core.sl.intf.TaskDefinition taskDefinitionObj =
      curam.core.sl.fact.TaskDefinitionFactory.newInstance();
    final CreateTaskDefinition createTaskDefinition =
      new CreateTaskDefinition();

    // Assign details to create task definition record
    createTaskDefinition.dtls.assign(details.dtls.dtls);

    createTaskDefinition.additionalDtls.deadLineTimeoutDays =
      details.dtls.additionalDtls.deadLineTimeoutDays;
    createTaskDefinition.additionalDtls.deadLineTimeoutHours =
      details.dtls.additionalDtls.deadLineTimeoutHours;
    createTaskDefinition.additionalDtls.deadLineTimeoutMinutes =
      details.dtls.additionalDtls.deadLineTimeoutMinutes;

    createTaskDefinition.additionalDtls.allocationFunctionID =
      details.dtls.additionalDtls.allocationFunctionID;
    createTaskDefinition.additionalDtls.allocationRuleSetID =
      details.dtls.additionalDtls.allocationRuleSetID;
    createTaskDefinition.additionalDtls.allocationTargetID =
      details.dtls.additionalDtls.allocationTargetID;

    // Call BPO to create task definition
    taskDefinitionObj.create(createTaskDefinition);
  }

  // __________________________________________________________________________
  /**
   * Creates a work allocation function.
   *
   * @param details
   * Work Allocation Function details.
   */
  @Override
  public void createWorkAllocationFunction(
    final CreateWorkAllocationFunctionDetails details)
    throws AppException, InformationalException {

    // Allocation Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();

    // Call BPO to create a work allocation function
    allocatorFunctionObj.create(details.createDtls);
  }

  // __________________________________________________________________________
  /**
   * Creates a work queue.
   *
   * @param details
   * Details to create a work queue.
   */
  @Override
  public void createWorkQueue(final CreateWorkQueueDetails details)
    throws AppException, InformationalException {

    // Work Queue service layer objects
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    // Call BPO to create work queue
    workQueueObj.create(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Creates a work queue subscription.
   *
   * @param details
   * Contains details to create a work queue subscription.
   */
  @Override
  public void
    createWorkQueueSubscription(final WorkQueueSubscriptionDetails details)
      throws AppException, InformationalException {

    // Work Queue Subscription service layer object
    final curam.core.sl.intf.WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.fact.WorkQueueSubscriptionFactory.newInstance();

    // Call BPO to create a work queue subscription
    workQueueSubscriptionObj.create(details);
  }

  // __________________________________________________________________________
  /**
   * Creates a work queue subscription.
   *
   * @param details
   * Contains details to create a work queue subscription.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #createWorkQueueSubscription(WorkQueueSubscriptionDetails)} See
   * release note CR00242506.
   */
  @Override
  @Deprecated
  public void createWorkQueueSubsrciption(
    final curam.core.facade.struct.CreateWorkQueueSubsrciptionDetails details)
    throws AppException, InformationalException {

    // Work Queue Subscription service layer object
    final curam.core.sl.intf.WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.fact.WorkQueueSubscriptionFactory.newInstance();

    // Call BPO to create a work queue subscription
    workQueueSubscriptionObj.create(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Removes a task definition.
   *
   * @param key
   * Key to delete a task definition.
   */
  @Override
  public void deleteTaskDefinition(final DeleteTaskDefinitionKey key)
    throws AppException, InformationalException {

    // Task Definition service layer object
    final curam.core.sl.intf.TaskDefinition taskDefinitionObj =
      curam.core.sl.fact.TaskDefinitionFactory.newInstance();

    // Call BPO to delete a task definition
    taskDefinitionObj.delete(key.key);
  }

  // __________________________________________________________________________
  /**
   * Deletes a work allocation function.
   *
   * @param key
   * Key to delete a work allocation function.
   */
  @Override
  public void
    deleteWorkAllocationFunction(final DeleteWorkAllocationFunctionKey key)
      throws AppException, InformationalException {

    // Allocation Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();

    // Call BPO to delete work allocation function
    allocatorFunctionObj.delete(key.key);
  }

  // __________________________________________________________________________
  /**
   * Removes a work queue.
   *
   * @param key
   * Key details to remove a work queue.
   */
  @Override
  public void deleteWorkQueue(final DeleteWorkQueueKey key)
    throws AppException, InformationalException {

    // Work Queue service layer object
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    // Call BPO to delete a work queue
    workQueueObj.delete(key.dtls);
  }

  // __________________________________________________________________________
  /**
   * Returns a list of allocation target details
   *
   * @return List of allocation target details
   */
  @Override
  public ListAllocationTargetDetails listAllocationTarget()
    throws AppException, InformationalException {

    // Create return object
    final ListAllocationTargetDetails listAllocationTargetDetails =
      new ListAllocationTargetDetails();

    // Allocation Target service layer object
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // Call BPO to return list of allocation target details
    listAllocationTargetDetails.dtls = allocationTargetObj.list();

    return listAllocationTargetDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of deadline work allocation function details.
   *
   * @return List of deadline work allocation function details.
   */
  @Override
  public ListDeadlineFunctionDetails listDeadlineFunction()
    throws AppException, InformationalException {

    // Create return object
    final ListDeadlineFunctionDetails listDeadlineFunctionDetails =
      new ListDeadlineFunctionDetails();

    // Allocation Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();
    final WorkAllocationFunctionListByTypeKey_bo workAllocationFunctionListByTypeKey =
      new WorkAllocationFunctionListByTypeKey_bo();

    // Set type for read
    workAllocationFunctionListByTypeKey.typeKey.type =
      curam.codetable.WORKALLOCATIONFUNCTION.DEADLINE;

    // Call BPO to return list of deadline work allocation function details
    listDeadlineFunctionDetails.readByTypeDtls =
      allocatorFunctionObj.listByType(workAllocationFunctionListByTypeKey);

    return listDeadlineFunctionDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of initial work allocation function details.
   *
   * @return List of work allocation function details.
   */
  @Override
  public ListInitialAllocationFunctionDetails listInitialAllocationFunction()
    throws AppException, InformationalException {

    // Create return object
    final ListInitialAllocationFunctionDetails listInitialAllocationFunctionDetails =
      new ListInitialAllocationFunctionDetails();

    // Allocator Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();
    final WorkAllocationFunctionListByTypeKey_bo workAllocationFunctionListByTypeKey =
      new WorkAllocationFunctionListByTypeKey_bo();

    // Set type for read
    workAllocationFunctionListByTypeKey.typeKey.type =
      curam.codetable.WORKALLOCATIONFUNCTION.ALLOCATION;

    // Call BPO to return list of initial work allocation functions
    listInitialAllocationFunctionDetails.dtls =
      allocatorFunctionObj.listByType(workAllocationFunctionListByTypeKey);

    return listInitialAllocationFunctionDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of task definitions.
   *
   * @return List of task definition details.
   */
  @Override
  public ListTaskDefinitionDetails listTaskDefinition()
    throws AppException, InformationalException {

    // Create return object
    final ListTaskDefinitionDetails listTaskDefinitionDetails =
      new ListTaskDefinitionDetails();

    // Task Definition service layer objects
    final curam.core.sl.intf.TaskDefinition taskDefinitionObj =
      curam.core.sl.fact.TaskDefinitionFactory.newInstance();

    // Call BPO to return a list of task definition details
    listTaskDefinitionDetails.details = taskDefinitionObj.list();

    return listTaskDefinitionDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of work allocation function details.
   *
   * @return List of work allocation function details.
   */
  @Override
  public ListWorkAllocationFunctionDetails listWorkAllocationFunction()
    throws AppException, InformationalException {

    // Create return object
    final ListWorkAllocationFunctionDetails listWorkAllocationFunctionDetails =
      new ListWorkAllocationFunctionDetails();

    // Allocation Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();

    // Call BPO to return list of work allocation functions
    listWorkAllocationFunctionDetails.details =
      allocatorFunctionObj.listAll();

    return listWorkAllocationFunctionDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of work queue details.
   *
   * @return List of work queue details.
   */
  @Override
  public ListWorkQueueDetails listWorkQueue()
    throws AppException, InformationalException {

    // Create return object
    final ListWorkQueueDetails listWorkQueueDetails =
      new ListWorkQueueDetails();

    // Work Queue service layer object
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    listWorkQueueDetails.dtls = workQueueObj.list();

    return listWorkQueueDetails;
  }

  // BEGIN, CR00161962, KY
  // ___________________________________________________________________________
  /**
   * Method returns the list of work queues subscribed by the user and user's
   * organization objects. The List will contain unique work queues.
   *
   * @return WorkQueueDetailsList list of work queues subscribed user and his
   * organization objects
   *
   * @throws AppException
   * e1
   * @throws InformationalException
   * e2
   */
  @Override
  public WorkQueueDetailsList listWorkQueueForUser()
    throws AppException, InformationalException {

    // Return Object
    WorkQueueDetailsList userWorkQueueDetailsList =
      new WorkQueueDetailsList();

    // Get SL Layer Object
    final curam.core.sl.intf.Inbox inboxObj = InboxFactory.newInstance();

    // Current user
    final UserNameKey key = new UserNameKey();

    key.userName = TransactionInfo.getProgramUser();

    // Call SL method to populate the list of users work queues
    userWorkQueueDetailsList = inboxObj.getWorkQueueForUser(key);

    return userWorkQueueDetailsList;
  }

  // END, CR00161962

  // BEGIN, CR00225579, LP
  // __________________________________________________________________________
  /**
   * Returns a list of work queue subscription details for a given work queue.
   * This list contains all the subscriptions, viz subscriptions by users,
   * organization units, jobs and positions. The returned list contains two
   * lists-
   * <li>Users subscriptions for Work Queue.
   * <li>Organization object
   * subscriptions for Work Queue.
   *
   * @param key
   * identifies the work queue for which subscription details
   * should be fetched
   * @return List of work queue subscription details.
   * @deprecated Since Curam 6.0, replaced with
   * {@link WorkAllocation#listAllWorkQueueSubscriptions(ListWorkQueueSubsrciptionsKey)}
   * . In addition to the current functionality, the new method
   * return struct
   * curam.core.sl.struct.ListWorkQueueSubscriptionsDtls, which
   * aggregates struct
   * curam.core.sl.entity.struct.WorkQueueSubscriptionFullDetailsList
   * , which further aggregates struct
   * curam.core.sl.entity.struct.
   * WorkQueueSubscriptionFullDetails, and this struct has all the
   * fields of WorkQueueSubscriptionDetails along with fields
   * subscriberID, subscriberName, subscriberType,
   * unsubscribePageText, pageTitle, organisationUnitID,
   * organisationStructureID and objectType. See release note :
   * <CR00225579>
   */

  @Override
  // BEGIN, CR00161962, KY
  @Deprecated
  public curam.core.facade.struct.ListWorkQueueSubscriptionsDetails
    listWorkQueueSubsrciptions(final ListWorkQueueSubsrciptionsKey key)
      throws AppException, InformationalException {

    // Create return object
    final curam.core.facade.struct.ListWorkQueueSubscriptionsDetails listWorkQueueSubscriptionsDetails =
      new curam.core.facade.struct.ListWorkQueueSubscriptionsDetails();

    final ListWorkQueueSubscriptionsKey subscriptionKey =
      new ListWorkQueueSubscriptionsKey();

    subscriptionKey.key.workQueueID = key.key.key.workQueueID;
    final ListWorkQueueSubscriptions allWQSubsList =
      listAllWorkQueueSubscriptions(subscriptionKey);

    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.key.key.workQueueID;
    final curam.core.sl.entity.intf.WorkQueue workQueue =
      curam.core.sl.entity.fact.WorkQueueFactory.newInstance();

    listWorkQueueSubscriptionsDetails.dtls.workQueueName.name =
      workQueue.readWorkQueueName(workQueueKey).name;

    final curam.core.sl.entity.struct.WorkQueueSubscriptionDetailsList wqSubsDetailsList =
      new curam.core.sl.entity.struct.WorkQueueSubscriptionDetailsList();

    final WorkQueueSubscriptionFullDetailsList wqSubsFullDtlsList =
      allWQSubsList.userSubscriptionList;

    final Iterator itr = wqSubsFullDtlsList.dtls.iterator();

    while (itr.hasNext()) {
      final curam.core.sl.entity.struct.WorkQueueSubscriptionFullDetails wqsubsFullDetails =
        (curam.core.sl.entity.struct.WorkQueueSubscriptionFullDetails) itr
          .next();

      final curam.core.sl.entity.struct.WorkQueueSubscriptionDetails wqsubsDetails =
        new curam.core.sl.entity.struct.WorkQueueSubscriptionDetails();

      wqsubsDetails.subscriptionDateTime =
        wqsubsFullDetails.subscriptionDateTime;
      wqsubsDetails.workQueueSubscriptionID =
        wqsubsFullDetails.workQueueSubscriptionID;
      wqsubsDetails.userName = wqsubsFullDetails.userName;

      wqSubsDetailsList.dtls.add(wqsubsDetails);
    }
    listWorkQueueSubscriptionsDetails.dtls.dtls = wqSubsDetailsList;

    return listWorkQueueSubscriptionsDetails;
  }

  // END, CR00161962
  // END, CR00225579

  // __________________________________________________________________________
  /**
   * Modifies task definition details.
   *
   * @param details
   * Modified task definition details.
   */
  @Override
  public void modifyTaskDefinition(final ModifyTaskDefinitionDetails details)
    throws AppException, InformationalException {

    // Task Definition service layer object
    final curam.core.sl.intf.TaskDefinition taskDefinitionObj =
      curam.core.sl.fact.TaskDefinitionFactory.newInstance();

    // Call BPO to modify a task definition
    taskDefinitionObj.modify(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Modifies work allocation function details.
   *
   * @param key
   * Key containing modified work allocation function details.
   */
  @Override
  public void
    modifyWorkAllocationFunction(final ModifyWorkAllocationFunctionKey key)
      throws AppException, InformationalException {

    // Allocation Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();

    // Call BPO to modify work allocation function details
    allocatorFunctionObj.modify(key.details);
  }

  // __________________________________________________________________________
  /**
   * Modifies work queue details.
   *
   * @param details
   * Modifies work queue details.
   */
  @Override
  public void modifyWorkQueue(final ModifyWorkQueueDetails details)
    throws AppException, InformationalException {

    // Work Queue service layer object
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    // Call BPO to modify work queue details
    workQueueObj.modify(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Reads allocation target details.
   *
   * @param key
   * Key to read allocation target details.
   *
   * @return Allocation target details.
   */
  @Override
  public ReadAllocationTargetDetails
    readAllocationTarget(final ReadAllocationTargetKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadAllocationTargetDetails readAllocationTargetDetails =
      new ReadAllocationTargetDetails();

    // Allocation Target service layer object
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // Call BPO to read allocation target details
    readAllocationTargetDetails.dtls =
      allocationTargetObj.readAllocationTarget(key.dtls);

    return readAllocationTargetDetails;
  }

  // __________________________________________________________________________
  /**
   * Reads allocation target summary details
   *
   * @param key
   * Contains key details to read allocation target summary details
   *
   * @return Allocation Target Summary Details
   */
  @Override
  public ReadAllocationTargetSummaryDetails
    readAllocationTargetSummaryDetails(
      final ReadAllocationTargetSummaryDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadAllocationTargetSummaryDetails readAllocationTargetSummaryDetails =
      new ReadAllocationTargetSummaryDetails();

    // Allocation Target service layer objects
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // Call BPO to read allocation target summary details
    readAllocationTargetSummaryDetails.dtls =
      allocationTargetObj.readAllocationTargetSummaryDetails(key.key);

    return readAllocationTargetSummaryDetails;
  }

  // __________________________________________________________________________
  /**
   * Reads task definition details.
   *
   * @param key
   * Key to read task definition details.
   *
   * @return Task definition details.
   */
  @Override
  public ReadTaskDefinitionDetails
    readTaskDefinitionDetails(final ReadTaskDefinitionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadTaskDefinitionDetails readTaskDefinitionDetails =
      new ReadTaskDefinitionDetails();

    // Task Definition service layer object
    final curam.core.sl.intf.TaskDefinition taskDefinitionObj =
      curam.core.sl.fact.TaskDefinitionFactory.newInstance();

    // Call service layer method to read task definition details
    readTaskDefinitionDetails.dtls = taskDefinitionObj.read(key.dtls);

    return readTaskDefinitionDetails;
  }

  // __________________________________________________________________________
  /**
   * Reads task definition details for modification.
   *
   * @param key
   * Key to read task definition details for modification.
   *
   * @return Task definition details for modification
   */
  @Override
  public ReadTaskDefinitionForModificationDetails
    readTaskDefinitionForModificationDetails(
      final ReadTaskDefinitionForModificationDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadTaskDefinitionForModificationDetails readTaskDefinitionForModificationDetails =
      new ReadTaskDefinitionForModificationDetails();

    // Task Definition service layer object
    final curam.core.sl.intf.TaskDefinition taskDefinitionObj =
      curam.core.sl.fact.TaskDefinitionFactory.newInstance();

    readTaskDefinitionForModificationDetails.modifyDtls =
      taskDefinitionObj.readForModify(key.key);

    return readTaskDefinitionForModificationDetails;
  }

  // __________________________________________________________________________
  /**
   * Reads work allocation function details
   *
   * @param key
   * Key to read work allocation function details.
   *
   * @return Work Allocation Function details.
   */
  @Override
  public ReadWorkAllocationFunctionDetails
    readWorkAllocationFunction(final ReadWorkAllocationFunctionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadWorkAllocationFunctionDetails readWorkAllocationFunctionDetails =
      new ReadWorkAllocationFunctionDetails();

    // Allocation Function service layer objects
    final curam.core.sl.intf.AllocatorFunction allocatorFunctionObj =
      curam.core.sl.fact.AllocatorFunctionFactory.newInstance();

    // Call BPO to read work allocation function details
    readWorkAllocationFunctionDetails.dtls =
      allocatorFunctionObj.read(key.key);

    return readWorkAllocationFunctionDetails;
  }

  // BEGIN, CR00021555, SP
  // BEGIN, HARP 63952, CB.
  // __________________________________________________________________________
  /**
   * Reads allocation target summary details
   *
   * @param key
   * Contains key details to read allocation target summary details
   *
   * @return Allocation Target Summary Details
   */
  @Override
  public ReadAllocationTargetSummaryDtls readAllocationTargetSummaryDtls(
    final ReadAllocationTargetSummaryDetailsKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadAllocationTargetSummaryDtls readAllocationTargetSummaryDtls =
      new ReadAllocationTargetSummaryDtls();

    // Allocation Target service layer objects
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // BEGIN, HARP 48162, SD
    // register the security implementation
    SecurityImplementationFactory.register();
    // END, HARP 48162

    // Call BPO to read allocation target summary details
    readAllocationTargetSummaryDtls.dtls =
      allocationTargetObj.readAllocationTargetSummaryDtls(key.key);

    return readAllocationTargetSummaryDtls;
  }

  // END, HARP 63952
  // END, CR00021555

  // __________________________________________________________________________
  /**
   * Reads work queue details.
   *
   * @param key
   * Key to read work queue details.
   *
   * @return Work queue details.
   */
  @Override
  public ReadWorkQueueDetails readWorkQueue(final ReadWorkQueueKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadWorkQueueDetails readWorkQueueDetails =
      new ReadWorkQueueDetails();

    // Work Queue service layer objects
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    // Call BPO to read work queue details
    readWorkQueueDetails.dtls = workQueueObj.read(key.key);

    return readWorkQueueDetails;
  }

  // __________________________________________________________________________
  /**
   * Removes a work queue subscription.
   *
   * @param key
   * Key details to remove a work queue subscription.
   */
  @Override
  public void
    removeWorkQueueSubscription(final DeleteWorkQueueSubscriptionKey key)
      throws AppException, InformationalException {

    // Work Queue Subscription service layer objects
    final curam.core.sl.entity.intf.WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.entity.fact.WorkQueueSubscriptionFactory.newInstance();

    // Call BPO to remove a work queue subscription
    workQueueSubscriptionObj.remove(key.key.key);
  }

  // __________________________________________________________________________
  /**
   * Creates an allocation target.
   *
   * @param details
   * Details to create an allocation target.
   */
  @Override
  public void
    createAllocationTarget(final CreateAllocationTargetDetails details)
      throws AppException, InformationalException {

    // Allocation Target service layer objects
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // Call BPO to create an allocation target
    allocationTargetObj.create(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Creates an allocation target item.
   *
   * @param key
   * Contains details to create an allocation target item.
   */
  @Override
  public void
    createAllocationTargetItem(final CreateAllocationTargetItemDetails key)
      throws AppException, InformationalException {

    // Allocation Target Item service layer objects
    final curam.core.sl.intf.AllocationTargetItem allocationTargetItemObj =
      curam.core.sl.fact.AllocationTargetItemFactory.newInstance();

    // Call BPO to create an allocation target item
    allocationTargetItemObj.create(key.dtls);
  }

  // __________________________________________________________________________
  /**
   * Removes an allocation target.
   *
   * @param key
   * Key to delete a work allocation.
   */
  @Override
  public void deleteAllocationTarget(final DeleteAllocationTargetKey key)
    throws AppException, InformationalException {

    // Allocation Target service layer objects
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // Call BPO to delete allocation target record
    allocationTargetObj.remove(key.dtls);
  }

  // __________________________________________________________________________
  /**
   * Modifies allocation target details.
   *
   * @param details
   * Modified allocation target details.
   */
  @Override
  public void
    modifyAllocationTarget(final ModifyAllocationTargetDetails details)
      throws AppException, InformationalException {

    // Allocation Target service layer objects
    final curam.core.sl.intf.AllocationTarget allocationTargetObj =
      curam.core.sl.fact.AllocationTargetFactory.newInstance();

    // Call BPO to modify allocation target details
    allocationTargetObj.modify(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Removes an allocation target item.
   *
   * @param key
   * Key details to remove an allocation target item.
   */
  @Override
  public void
    removeAllocationTargetItem(final DeleteAllocationTargetItemKey key)
      throws AppException, InformationalException {

    // Allocation Target Item service layer objects
    final curam.core.sl.intf.AllocationTargetItem allocationTargetItemObj =
      curam.core.sl.fact.AllocationTargetItemFactory.newInstance();

    // Call BPO to remove allocation target item
    allocationTargetItemObj.remove(key.dtls);
  }

  // __________________________________________________________________________
  /**
   * Closes a task
   *
   * @param key
   * The taskID and version number of the task to close.
   */
  @Override
  public void closeTask(final CloseTaskKey_eo key)
    throws AppException, InformationalException {

    // Task Association service layer object
    final curam.core.sl.intf.TaskAssignment taskAssignmentObj =
      curam.core.sl.fact.TaskAssignmentFactory.newInstance();

    taskAssignmentObj.closeTask(key.key);

  }

  // __________________________________________________________________________
  /**
   * Forwards a task.
   *
   * @param details
   * Forward task details.
   */
  @Override
  public void forwardTask(final ForwardTaskDetails details)
    throws AppException, InformationalException {

    // Call BPO to forward task
    curam.core.sl.fact.TaskAssignmentFactory.newInstance()
      .forwardTask(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * Returns a list of available work queues for the current user.
   *
   * @param ListAvailableWorkQueueForUserNameKey key a name of the work queue.
   *
   * @return List of available work queues for the current user.
   */
  @Override
  public ListAvailableWorkQueuesForCurrentUserDetails
    listAvailableWorkQueuesForCurrentUser(
      final ListAvailableWorkQueueForUserNameKey key)
      throws AppException, InformationalException {

    // Work Queue Subscription service layer object
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Return information
    final ListAvailableWorkQueuesForCurrentUserDetails listAvailableWorkQueuesForCurrentUserDetails =
      new ListAvailableWorkQueuesForCurrentUserDetails();

    // setup the user name key to the current user
    key.key.userName = userAccessObj.getUserDetails().userName;

    // list the available work queues
    listAvailableWorkQueuesForCurrentUserDetails.dtls =
      workQueueObj.listAvailableWorkQueueForUser(key);

    return listAvailableWorkQueuesForCurrentUserDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of available work queues for the current user if the action
   * type is
   * SEARCH or subscribes a list of work queues to the current use if the action
   * type is
   * SUBCRIBE.
   *
   * @param SubscribeWorkQueueInput input it contains the name or a part
   * of the work queue name for searching
   * , the action type and the list of selected
   * work queue IDs.
   * @return List of available work queues for the current user.
   */
  @Override
  public ListAvailableWorkQueuesForCurrentUserDetails
    searchOrSubscribeWorkQueue(final SubscribeWorkQueueInput input)
      throws AppException, InformationalException {

    if (input != null
      && input.actionIDProperty.equals(ClientActionConst.kSearchActionID)) {
      if (input.dtls.key.workQueueName.equals(CuramConst.gkEmpty)) {
        input.dtls.key.workQueueName = CuramConst.gkPercentage;
      }
      final ListAvailableWorkQueuesForCurrentUserDetails returnWorkQueueList =
        this.listAvailableWorkQueuesForCurrentUser(input.dtls);

      return returnWorkQueueList;
    } else if (input != null && input.actionIDProperty
      .equals(ClientActionConst.kSubscribeActionID)) {
      if (!input.name.equals(CuramConst.gkEmpty)) {
        final curam.core.facade.intf.Inbox inboxObj =
          curam.core.facade.fact.InboxFactory.newInstance();
        final String queueIDs = input.name;
        // Parse tab delimited list of selected work queue id into list.
        final StringList workQueueIDNameList =
          StringUtil.tabText2StringListWithTrim(queueIDs);
        final int size = workQueueIDNameList.size();

        for (int i = 0; i < size; i++) {
          final String id = workQueueIDNameList.get(i);
          final SubscribeUserWorkQueueKey key =
            new SubscribeUserWorkQueueKey();

          key.subscribeUserWorkQueue.key.workQueueID = Long.valueOf(id);
          inboxObj.subscribeUserWorkQueue(key);
        }
      } else {
        // BEGIN, 198146, AA
        throw new AppException(
          BPOWORKQUEUE.ERR_WORK_QUEUE_MUST_BE_SELECTED_FOR_USER_HAS_TO_SUBSCRIBE_TO);
        // END, 198146, AA
      }
    } else {
      final AppException e =
        new AppException(BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(input.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    return new ListAvailableWorkQueuesForCurrentUserDetails();
  }

  // __________________________________________________________________________
  /**
   * Lists the Work Queues that the current user is subscribed to.
   *
   * @return List of work queues the current user is subscribed to.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #listUserOrgObjectWorkQueues()}. See release note
   * CR00230325
   */
  @Override
  @Deprecated
  public curam.core.facade.struct.ListCurrentUserWorkQueueDetails
    listCurrentUserWorkQueues() throws AppException, InformationalException {

    // Return variable
    final curam.core.facade.struct.ListCurrentUserWorkQueueDetails listCurrentUserWorkQueueDetails =
      new curam.core.facade.struct.ListCurrentUserWorkQueueDetails();

    final ListUserOrgObjectWorkQueueDetails workQueues =
      listUserOrgObjectWorkQueues();

    listCurrentUserWorkQueueDetails.dtls.userFullName =
      workQueues.workQueueDetailsList.userFullName;

    for (final curam.core.sl.entity.struct.ListUserOrgObjectWorkQueueDetails nextQueue : workQueues.workQueueDetailsList.dtlsList) {
      final curam.core.sl.entity.struct.ListUserWorkQueueDetails s =
        new curam.core.sl.entity.struct.ListUserWorkQueueDetails();

      s.name = nextQueue.workQueueName;
      s.numberOfItemsInQueue = nextQueue.numberOfItemsInQueue;
      s.subscriptionDateTime = nextQueue.subscriptionDateTime;
      s.workQueueID = nextQueue.workQueueID;
      listCurrentUserWorkQueueDetails.dtls.dtlsList.add(s);
    }
    return listCurrentUserWorkQueueDetails;
  }

  // __________________________________________________________________________
  /**
   * Lists the Work Queues that the current user is subscribed to. This list
   * contains WorkQueues subscribed by the user as well as that are subscribed
   * by the user's organization objects.
   *
   * @return List of work queues the current user is subscribed to.
   */
  @Override
  public ListUserOrgObjectWorkQueueDetails listUserOrgObjectWorkQueues()
    throws AppException, InformationalException {

    // Work Queue service layer object
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    // System user maintenance object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Return variable
    final ListUserOrgObjectWorkQueueDetails listCurrentUserWorkQueueDetails =
      new ListUserOrgObjectWorkQueueDetails();

    // Service layer method key
    final ListUserWorkQueueDetailsKey listUserWorkQueueDetailsKey =
      new ListUserWorkQueueDetailsKey();

    // set the name to the current user.
    listUserWorkQueueDetailsKey.nameKey.userName =
      userAccessObj.getUserDetails().userName;

    listCurrentUserWorkQueueDetails.workQueueDetailsList =
      workQueueObj.searchUserWorkQueues(listUserWorkQueueDetailsKey);

    return listCurrentUserWorkQueueDetails;
  }

  // __________________________________________________________________________
  /**
   * Lists un-reserved work queue tasks.
   *
   * @return List of un-reserved work queue tasks.
   */
  @Override
  public ListUnreservedWorkQueueTasksDetails
    listUnreservedWorkQueueTasks(final ListUnreservedWorkQueueTasksKey key)
      throws AppException, InformationalException {

    // Work Queue service layer object
    final curam.core.sl.intf.WorkQueue workQueueObj =
      curam.core.sl.fact.WorkQueueFactory.newInstance();

    final ListUnreservedWorkQueueTasksDetails listUnreservedWorkQueueTasksDetails =
      new ListUnreservedWorkQueueTasksDetails();

    listUnreservedWorkQueueTasksDetails.dtls =
      workQueueObj.listUnreservedWorkQueueTasks(key.key);

    return listUnreservedWorkQueueTasksDetails;
  }

  // __________________________________________________________________________
  /**
   * Modifies task details.
   *
   * @param details
   * Modified task details.
   */
  @Override
  public void modifyTask(final ModifyWATaskDetails details)
    throws AppException, InformationalException {

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    // Call BPO to modify task details
    workAllocationTaskObj.modifyTask(details.details);
  }

  // __________________________________________________________________________
  /**
   * Returns action page details.
   *
   * @param key
   * Key to read action page details.
   *
   * @return details Action page details.
   */
  @Override
  public ReadActionPageDetails
    readActionPageDetails(final ReadActionPageDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadActionPageDetails readActionPageDetails =
      new ReadActionPageDetails();

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    // Call BPO to read action page details
    readActionPageDetails.details =
      workAllocationTaskObj.readActionPageDetails(key.dtls);

    return readActionPageDetails;
  }

  // __________________________________________________________________________
  /**
   * Reads task details for modification.
   *
   * @param key
   * Key to read details for modification.
   *
   * @return Task details for modification.
   */
  @Override
  public ReadTaskForModificationDetails
    readTaskForModification(final ReadTaskForModificationKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadTaskForModificationDetails readTaskForModificationDetails =
      new ReadTaskForModificationDetails();

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    readTaskForModificationDetails.details =
      workAllocationTaskObj.readTaskForModification(key.dtls);

    return readTaskForModificationDetails;
  }

  // __________________________________________________________________________
  /**
   * Reads the task summary details.
   *
   * @param key
   * Key to read the task summary details.
   *
   * @return Task summary details.
   */
  @Override
  public ReadTaskSummaryDetails
    readTaskSummaryDetails(final ReadTaskSummaryDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadTaskSummaryDetails readTaskSummaryDetails =
      new ReadTaskSummaryDetails();

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    // Call BPO to read task summary details
    readTaskSummaryDetails.details =
      workAllocationTaskObj.readTaskSummaryDetails(key.dtls);

    return readTaskSummaryDetails;
  }

  // __________________________________________________________________________
  /**
   * Re-allocates a task.
   *
   * @param key
   * Key to re-allocate a task.
   */
  @Override
  public void reallocateTask(final ReallocateTaskKey_eo key)
    throws AppException, InformationalException {

    // TaskAssignment manipulation variables
    final curam.core.sl.intf.TaskAssignment taskAssignmentObj =
      curam.core.sl.fact.TaskAssignmentFactory.newInstance();

    // Call BPO to re-allocate task
    taskAssignmentObj.reallocateTask(key.key);
  }

  // __________________________________________________________________________
  /**
   * Subscribes the current user to the work queue.
   *
   * @param key
   * Key to subscribe the current user to the work queue.
   */
  @Override
  public void subscribeCurrentUserToWorkQueue(
    final SubscribeCurrentUserToWorkQueueKey key)
    throws AppException, InformationalException {

    // Work Queue Subscription service layer objects
    final curam.core.sl.intf.WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.fact.WorkQueueSubscriptionFactory.newInstance();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Service layer method key
    final SubscribeUserToWorkQueueKey subscribeUserToWorkQueueKey =
      new SubscribeUserToWorkQueueKey();

    // set up the current user name
    subscribeUserToWorkQueueKey.userName =
      userAccessObj.getUserDetails().userName;

    // set up the work queue id
    subscribeUserToWorkQueueKey.key.workQueueID = key.workQueueID;

    // subscribe the user;
    workQueueSubscriptionObj.subscribeUser(subscribeUserToWorkQueueKey);
  }

  // __________________________________________________________________________
  /**
   * Un-reserves a task.
   *
   * @param key
   * Key to un-reserve a task.
   */
  @Override
  public void unreserveTask(final UnreserveTaskKey_eo key)
    throws AppException, InformationalException {

    // Task Association service layer object
    final curam.core.sl.intf.TaskAssignment taskAssignmentObj =
      curam.core.sl.fact.TaskAssignmentFactory.newInstance();

    taskAssignmentObj.unreserveTask(key.key);
  }

  // __________________________________________________________________________
  /**
   * Reserves a task.
   *
   * @param key
   * Key to reserve a task.
   */
  @Override
  public void reserveTask(final ReserveTaskKey_eo key)
    throws AppException, InformationalException {

    // Task Association service layer object
    final curam.core.sl.intf.TaskAssignment taskAssignmentObj =
      curam.core.sl.fact.TaskAssignmentFactory.newInstance();

    taskAssignmentObj.reserveTask(key.key);
  }

  // __________________________________________________________________________
  /**
   * Un-subscribes a current user from the work queue.
   *
   * @param key
   * Key to un-subscribe the current user from the work queue.
   */
  @Override
  public void unsubscribeCurrentUserFromWorkQueue(
    final UnsubscribeCurrentUserFromWorkQueueKey key)
    throws AppException, InformationalException {

    // Work Queue Subscription service layer objects
    final curam.core.sl.intf.WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.fact.WorkQueueSubscriptionFactory.newInstance();

    // Work Queue Subscription service layer objects
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Service layer method key
    final UnsubscribeUserFromWorkQueueKey unsubscribeUserFromWorkQueueKey =
      new UnsubscribeUserFromWorkQueueKey();

    // set up the work queue id and the user un-subscribe
    unsubscribeUserFromWorkQueueKey.key.workQueueID = key.workQueueID;
    unsubscribeUserFromWorkQueueKey.userName =
      userAccessObj.getUserDetails().userName;

    workQueueSubscriptionObj
      .unsubscribeUserFromWorkQueue(unsubscribeUserFromWorkQueueKey);
  }

  // __________________________________________________________________________
  /**
   * Returns a list of reserved tasks for the current user.
   *
   * @return List of reserved tasks for the current user.
   */
  @Override
  public ListReservedTasksForCurrentUser listReservedTasksForCurrentUser()
    throws AppException, InformationalException {

    // Task In box service layer object
    final curam.core.sl.intf.TaskInbox taskInboxObj =
      curam.core.sl.fact.TaskInboxFactory.newInstance();

    // System user maintenance object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final ListReservedTasksForCurrentUser listReservedTasksForCurrentUser =
      new ListReservedTasksForCurrentUser();

    final ListReservedTasksForUserKey listReservedTasksForUserKey =
      new ListReservedTasksForUserKey();

    listReservedTasksForUserKey.userName =
      userAccessObj.getUserDetails().userName;

    listReservedTasksForCurrentUser.dtls =
      taskInboxObj.listReservedTasksForUser(listReservedTasksForUserKey);

    return listReservedTasksForCurrentUser;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of task histories.
   *
   * @param key
   * Key to return a list of task histories.
   *
   * @return List of task history details.
   */
  @Override
  public ListTaskHistoryDetails listTaskHistory(final ListTaskHistoryKey key)
    throws AppException, InformationalException {

    // BEGIN HARP 50770 CC
    // Create return object
    final ListTaskHistoryDetails listTaskHistoryDetails =
      new ListTaskHistoryDetails();

    final TaskHistoryAdmin taskHistoryAdminObj =
      TaskHistoryAdminFactory.newInstance();
    final curam.util.workflow.struct.TaskKey newTaskKey =
      new curam.util.workflow.struct.TaskKey();

    newTaskKey.taskID = key.key.key.taskID;

    final TaskHistoryInfoList taskHistoryDtlsList = taskHistoryAdminObj
      .searchByTaskIDOrderByChangeDateTimeFirst(key.key.key.taskID);

    listTaskHistoryDetails.dtls.dtlsList
      .ensureCapacity(taskHistoryDtlsList.dtls.size());

    final curam.core.sl.struct.TaskHistoryDetails taskHistoryDetails =
      new curam.core.sl.struct.TaskHistoryDetails();

    // User object and key.
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    for (int i = 0; i < taskHistoryDtlsList.dtls.size(); i++) {

      taskHistoryDetails.changeDateTime =
        taskHistoryDtlsList.dtls.item(i).changeDateTime;
      taskHistoryDetails.changeType =
        taskHistoryDtlsList.dtls.item(i).changeType;
      taskHistoryDetails.newValue = taskHistoryDtlsList.dtls.item(i).newValue;
      taskHistoryDetails.oldValue = taskHistoryDtlsList.dtls.item(i).oldValue;
      taskHistoryDetails.taskID = taskHistoryDtlsList.dtls.item(i).taskID;
      taskHistoryDetails.userName = taskHistoryDtlsList.dtls.item(i).userName;

      usersKey.userName = taskHistoryDtlsList.dtls.item(i).userName;
      taskHistoryDetails.userFullName =
        userAccessObj.getFullName(usersKey).fullname;

      listTaskHistoryDetails.dtls.dtlsList.addRef(taskHistoryDetails);
    }
    // END HARP 50770

    return listTaskHistoryDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of un-reserved tasks for the current user.
   *
   * @return List of un-reserved tasks for the current user.
   */
  @Override
  public ListUnreservedTasksForCurrentUserDetails
    listUnreservedTasksForCurrentUser()
      throws AppException, InformationalException {

    // Task Association service layer object
    final curam.core.sl.intf.TaskInbox taskInboxObj =
      curam.core.sl.fact.TaskInboxFactory.newInstance();

    // System user maintenance object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final ListUnreservedTasksForCurrentUserDetails listUnreservedTasksForCurrentUserDetails =
      new ListUnreservedTasksForCurrentUserDetails();

    final ListUnreservedTasksForUserKey listUnreservedTasksForUserKey =
      new ListUnreservedTasksForUserKey();

    listUnreservedTasksForUserKey.userName =
      userAccessObj.getUserDetails().userName;

    listUnreservedTasksForCurrentUserDetails.dtls =
      taskInboxObj.listUnreservedTasksForUser(listUnreservedTasksForUserKey);

    return listUnreservedTasksForCurrentUserDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of task details based on the key data specified.
   *
   * @param key
   * Key to search for tasks.
   *
   * @return List of task details.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link curam.core.intf.TaskSearchRouter#searchTask(curam.core.sl.struct.TaskQueryCriteria)}
   * because the task search functionality has been enhanced for
   * Curam 6.0. See release notes CR00230325.
   */
  @Override
  @Deprecated
  public curam.core.facade.struct.TaskSearchResult
    taskSearch(final curam.core.facade.struct.TaskSearchKey key)
      throws AppException, InformationalException {

    // Task Search object.
    final curam.core.intf.TaskSearchRouter taskSearchRouterObj =
      curam.core.fact.TaskSearchRouterFactory.newInstance();

    // Details to be returned.
    final curam.core.facade.struct.TaskSearchResult taskSearchResult =
      new curam.core.facade.struct.TaskSearchResult();

    // Call the search.
    taskSearchResult.dtls = taskSearchRouterObj.taskSearch(key.key);

    // Return the details.
    return taskSearchResult;
  }

  // __________________________________________________________________________
  /**
   * Create a manual task.
   *
   * @param dtls
   * Details to create a manual task.
   *
   * @return Identifier of the task that has been created.
   */
  @Override
  public ReadTaskSummaryDetailsKey
    createManualTask(final StandardManualTaskDtls dtls)
      throws AppException, InformationalException {

    // Create return object
    final ReadTaskSummaryDetailsKey readTaskSummaryDetailsKey =
      new ReadTaskSummaryDetailsKey();

    // WorkAllocationTask service layer object
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = dtls.dtls.concerningDtls.caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {

      // BEGIN, CR00021250, TV
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END, CR00021250

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey =
          new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory
          .register();

        // set the key
        servicePlanSecurityKey.caseID = dtls.dtls.concerningDtls.caseID;
        servicePlanSecurityKey.securityCheckType =
          curam.serviceplans.sl.impl.ServicePlanSecurity.kCreateSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // BEGIN, CR00002484, CM

    // Check to ensure that the process definition exists.
    // If so set it and if not return error to user that a manual task
    // can not be created unless a process definition of type manual exists.
    curam.core.intf.CachedCaseParticipantRole cachedCaseParticipantRole_eoObj;
    curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRole_eoKey;
    curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;

    // The name of the process definition to be used for creating the manual
    // task.
    String processDefinitionName = GeneralConstants.kEmpty;

    // Get the correct process definition
    if (dtls.dtls.concerningDtls.participantRoleID == 0
      && dtls.dtls.concerningDtls.caseID == 0
      && dtls.dtls.concerningDtls.caseParticipantRoleID == 0) {

      processDefinitionName = kManual;

    } else if (dtls.dtls.concerningDtls.participantRoleID != 0
      && dtls.dtls.concerningDtls.caseID == 0
      && dtls.dtls.concerningDtls.caseParticipantRoleID == 0) {

      processDefinitionName = kManualParticipant;

      dtls.dtls.concerningDtls.caseParticipantRoleID =
        dtls.dtls.concerningDtls.participantRoleID;

    } else if (dtls.dtls.concerningDtls.participantRoleID == 0
      && dtls.dtls.concerningDtls.caseParticipantRoleID == 0
      && dtls.dtls.concerningDtls.caseID != 0) {

      // we only want to created a biz object association record for a
      // case

      processDefinitionName = kManualCase;

    } else if (dtls.dtls.concerningDtls.participantRoleID == 0
      && dtls.dtls.concerningDtls.caseParticipantRoleID != 0
      && dtls.dtls.concerningDtls.caseID != 0) {

      cachedCaseParticipantRole_eoObj =
        curam.core.fact.CachedCaseParticipantRoleFactory.newInstance();
      caseParticipantRole_eoKey =
        new curam.core.sl.entity.struct.CaseParticipantRoleKey();
      caseParticipantRole_eoKey.caseParticipantRoleID =
        dtls.dtls.concerningDtls.caseParticipantRoleID;

      // if only the case participant role is supplied
      // we need to get the case he/she belongs to
      caseIDAndParticipantRoleIDDetails = cachedCaseParticipantRole_eoObj
        .readCaseIDAndParticipantRoleIDDetails(caseParticipantRole_eoKey);

      // Set up participant id
      dtls.dtls.concerningDtls.participantRoleID =
        caseIDAndParticipantRoleIDDetails.participantRoleID;

      // we have been passed a case id and case participant role id

      processDefinitionName = kManualParticipantCase;

    } else if (dtls.dtls.concerningDtls.participantRoleID != 0
      && dtls.dtls.concerningDtls.caseParticipantRoleID == 0
      && dtls.dtls.concerningDtls.caseID != 0) {

      // we have been passed a case id and participant role id

      processDefinitionName = kManualParticipantCase;

      dtls.dtls.concerningDtls.caseParticipantRoleID =
        dtls.dtls.concerningDtls.participantRoleID;
    } else if (dtls.dtls.concerningDtls.participantRoleID == 0
      && dtls.dtls.concerningDtls.caseParticipantRoleID != 0
      && dtls.dtls.concerningDtls.caseID == 0) {

      cachedCaseParticipantRole_eoObj =
        curam.core.fact.CachedCaseParticipantRoleFactory.newInstance();
      caseParticipantRole_eoKey =
        new curam.core.sl.entity.struct.CaseParticipantRoleKey();
      caseParticipantRole_eoKey.caseParticipantRoleID =
        dtls.dtls.concerningDtls.caseParticipantRoleID;

      // if only the case participant role is supplied
      // we need to get the case he/she belongs to
      caseIDAndParticipantRoleIDDetails = cachedCaseParticipantRole_eoObj
        .readCaseIDAndParticipantRoleIDDetails(caseParticipantRole_eoKey);

      // Set up participant and case id
      dtls.dtls.concerningDtls.caseID =
        caseIDAndParticipantRoleIDDetails.caseID;
      dtls.dtls.concerningDtls.participantRoleID =
        caseIDAndParticipantRoleIDDetails.participantRoleID;

      // we have been passed a case id and participant role id

      processDefinitionName = kManualParticipantCase;
    }

    dtls.dtls.taskDtls.taskDefinitionID = processDefinitionName;

    if (kManualParticipantCase.equals(processDefinitionName)) {

      // retrieve the participant type.

      final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey =
        new curam.core.sl.entity.struct.CaseParticipantRoleKey();
      final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj =
        curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

      caseParticipantRoleKey.caseParticipantRoleID =
        dtls.dtls.concerningDtls.caseParticipantRoleID;

      // read CaseParticipantRole details
      final CaseParticipantConcernRoleDetails caseParticipantConcernRoleDetails =
        caseParticipantRoleObj
          .readParticipantRoleDetails(caseParticipantRoleKey);

      dtls.dtls.concerningDtls.participantType =
        caseParticipantConcernRoleDetails.concernRoleType;

    } else if (kManualParticipant.equals(processDefinitionName)) {

      // Instance of Concern Role Key
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // Concern Role Maintenance Object
      final curam.core.intf.ConcernRole concernRoleObj =
        curam.core.fact.ConcernRoleFactory.newInstance();

      // Set the Concern Role ID
      concernRoleKey.concernRoleID =
        dtls.dtls.concerningDtls.participantRoleID;

      // retrieve the participant type.
      final ConcernRoleTypeDetails concernRoleTypeDtls =
        concernRoleObj.readConcernRoleType(concernRoleKey);

      dtls.dtls.concerningDtls.participantType =
        concernRoleTypeDtls.concernRoleType;
    }

    // If the process definition cannot be found, then throw a meaningful
    // exception.
    // TODO: Interim fix: Rather than catching an exception here, we should
    // have an API to check if the workflow exists and call it here. For
    // now, the enactment service throws a run time exception when the
    // process
    // definition cannot be found so check for that here. -- FG.
    try {
      workAllocationTaskObj.createManualTask(dtls);
    } catch (final AppException ae) {
      if (ae.getNestedThrowable() instanceof AppRuntimeException) {
        throw new AppException(
          BPOTASKDEFINITION.ERR_TASK_XFV_DEFINITION_TYPE_NOT_EXIST, ae);
      } else {
        throw ae;
      }
    }
    return readTaskSummaryDetailsKey;
  }

  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'
   */
  @Override
  public SearchTasksForConcernAndCaseDetails
    listCaseMemberTasks(final CaseMemberTaskSearchKey key)
      throws AppException, InformationalException {

    throw new curam.util.exception.UnimplementedException();
  }

  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'
   */
  @Override
  public SearchTasksForConcernAndCaseDetails listCaseTasks(
    final CaseTaskSearchKey key) throws AppException, InformationalException {

    throw new curam.util.exception.UnimplementedException();
  }

  // __________________________________________________________________________
  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * Key to read a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   */
  @Override
  public SearchTasksForConcernAndCaseDetails
    listParticipantTasks(final ConcernTaskSearchKey key)
      throws AppException, InformationalException {

    // Create return object
    final SearchTasksForConcernAndCaseDetails searchTasksForConcernAndCaseDetails =
      new SearchTasksForConcernAndCaseDetails();

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey =
      new SearchTaskForConcernOrCaseKey();

    searchTaskForConcernOrCaseKey.details.linkedID = key.concernRoleID;
    searchTaskForConcernOrCaseKey.details.linkedTypeCode =
      curam.codetable.TASKLINKTYPE.PARTICIPANTROLE;

    // Call BPO to return the list of participant tasks
    searchTasksForConcernAndCaseDetails.dtls = workAllocationTaskObj
      .listConcernRoleTasks(searchTaskForConcernOrCaseKey);

    return searchTasksForConcernAndCaseDetails;
  }

  // __________________________________________________________________________
  /**
   * List the tasks and activities for the current user based on the
   * environment variable specifying the date range.
   *
   * @return = List of tasks and activities within the application property
   * specified date range.
   */
  @Override
  public WorkAllocationTaskAndActivityForUserDetails
    listTaskAndActivitiesForCurrentUser()
      throws AppException, InformationalException {

    // Task Inbox service layer object
    final curam.core.sl.intf.TaskInbox taskInboxObj =
      curam.core.sl.fact.TaskInboxFactory.newInstance();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Create return object
    final WorkAllocationTaskAndActivityForUserDetails workAllocationTaskAndActivityForUserDetails =
      new WorkAllocationTaskAndActivityForUserDetails();

    // set up key to read the reserved tasks
    final ListReservedTasksForUserKey listReservedTasksForUserKey =
      new ListReservedTasksForUserKey();

    listReservedTasksForUserKey.userName =
      userAccessObj.getUserDetails().userName;

    // BEGIN, CR00145544, SS
    // get the current user reserved Tasks
    workAllocationTaskAndActivityForUserDetails.reservedTasks =
      taskInboxObj.getReservedTasksForUser(listReservedTasksForUserKey);
    // END, CR00145544

    // Set the current date
    final curam.util.type.Date currentDate =
      curam.util.type.Date.getCurrentDate();

    // Holds the number of days prior to current date to retrieve
    // activities from
    final int kDaysPriorToCurrentDate = 2;

    // - Activities -
    // The activities of the current user must be retrieved and filtered
    // also

    // MaintainUserActivity manipulation variables
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj =
      curam.core.fact.MaintainUserActivityFactory.newInstance();
    SearchUserByDateRangeResult searchUserByDateRangeResult;
    final UserActivitySearchKey userActivitySearchKey =
      new UserActivitySearchKey();

    // BEGIN, CR00226381, GSP
    // Set end date for reading the activities.
    final Date activitySearchEndDate = currentDate.addDays(kDaysInWeek);

    // Get the current time and add it to start date and end date.
    final Calendar calendar = Calendar.getInstance();

    userActivitySearchKey.startDateTime =
      currentDate.addDays(-kDaysPriorToCurrentDate).getDateTime().addTime(
        calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE),
        calendar.get(Calendar.SECOND));

    userActivitySearchKey.endDateTime = activitySearchEndDate.getDateTime()
      .addTime(calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
    // END, CR00226381

    // Set endDate for reading the activities
    final curam.util.type.Date activitySearchEndDateTime =
      currentDate.addDays(kDaysInWeek);

    // Set key to retrieve the list of activities for the specified date
    // range
    userActivitySearchKey.startDateTime =
      currentDate.addDays(-kDaysPriorToCurrentDate).getDateTime();
    userActivitySearchKey.endDateTime =
      activitySearchEndDateTime.getDateTime();
    userActivitySearchKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();
    userActivitySearchKey.viewingUserName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // Call MaintainUserActivity BPO to retrieve the list of activities for
    // the
    // logged in user over the specified date range
    searchUserByDateRangeResult =
      maintainUserActivityObj.searchUserByDateRange(userActivitySearchKey);

    // Iterate through the ActivityIntervalDetails list and assign details
    // to return object
    workAllocationTaskAndActivityForUserDetails.intervalDetailsList
      .ensureCapacity(searchUserByDateRangeResult.detailsList.dtls.size());

    for (int j = 0; j < searchUserByDateRangeResult.detailsList.dtls
      .size(); j++) {

      final ActivityIntervalDetails activityIntervalDetails =
        new ActivityIntervalDetails();

      activityIntervalDetails
        .assign(searchUserByDateRangeResult.detailsList.dtls.item(j));

      // Add to return object
      workAllocationTaskAndActivityForUserDetails.intervalDetailsList
        .addRef(activityIntervalDetails);
    }

    // Iterate through the ActivityRelatedDetails list and assign details
    // to return object
    workAllocationTaskAndActivityForUserDetails.relatedDetailsList
      .ensureCapacity(searchUserByDateRangeResult.detailsList.dtls.size());

    for (int k = 0; k < searchUserByDateRangeResult.detailsList.dtls
      .size(); k++) {

      final ActivityRelatedDetails activityRelatedDetails =
        new ActivityRelatedDetails();

      activityRelatedDetails
        .assign(searchUserByDateRangeResult.relatedDetailsList.dtls.item(k));

      // Add to return object
      workAllocationTaskAndActivityForUserDetails.relatedDetailsList
        .addRef(activityRelatedDetails);
    }

    return workAllocationTaskAndActivityForUserDetails;

  }

  // BEGIN, CR00059312, CM
  // ___________________________________________________________________________
  /**
   * Method to search for a work queue.
   *
   * @param key
   * Work Queue name
   *
   * @return Searches for the work queue details list
   */
  @Override
  public SearchWorkQueueDetailsList
    searchWorkQueue(final WorkQueueNameDetails key)
      throws AppException, InformationalException {

    // Work queue business process object
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    // Return variable for work queue details list
    final SearchWorkQueueDetailsList searchWorkQueueDetailsList =
      new SearchWorkQueueDetailsList();

    // search the list of work queues with the name entered
    searchWorkQueueDetailsList.dtlsList = workQueueObj.search(key);

    // Return work queue details list
    return searchWorkQueueDetailsList;

  }

  // END, CR00059312

  // BEGIN, CR00066883, SPD
  // ___________________________________________________________________________
  /**
   * @return list of case details
   * @deprecated Since Curam 6.0, replaced by
   * {@link Case#caseDefaultSearchByOwner()}. Method to search for
   * all filtered cases for a work queue. New method performs a
   * case search based on search criteria which includes owner
   * list passed as tab delimited string. Owner can be any
   * organizational object.
   */
  @Override
  @Deprecated
  public ListCaseByCurrentUserDetails
    listCasesForWorkQueueOwner(final CatStatusRefUserType key)
      throws AppException, InformationalException {

    // caseOrgObjectLink manipulation variables
    final OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();

    // informationalManager manipulation variables
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // return struct
    final ListCaseByCurrentUserDetails listCaseByCurrentUserDetails =
      new ListCaseByCurrentUserDetails();

    // populate key with specific type
    key.type = ORGOBJECTTYPE.WORKQUEUE;
    key.isOrgObjectRefNull = false;

    // search for cases
    listCaseByCurrentUserDetails.getCasesByOwnerResult =
      orgObjectLinkObj.listCasesForOrgObject(key);

    // populate informational manager
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      listCaseByCurrentUserDetails.messageList.informationalMsgDtlsList.dtls
        .addRef(informationalMsgDtls);
    }

    return listCaseByCurrentUserDetails;
  }

  // END, CR00066883

  // BEGIN, CR00175274, ZV
  // BEGIN, CR00143146, ZV
  // ___________________________________________________________________________
  /**
   * Method to return work queue details and users subscribed to it details
   * list.
   *
   * @return Work queue details and users subscribed to it details list.
   */
  @Override
  public WorkQueueDetailsAndSubscriberList
    readWorkQueueDetailsAndSubscriberList(final WorkQueueKey key)
      throws AppException, InformationalException {

    final WorkQueueDetailsAndSubscriberList workQueueDetailsAndSubscriberList =
      new WorkQueueDetailsAndSubscriberList();

    workQueueDetailsAndSubscriberList.dtls = WorkQueueFactory.newInstance()
      .readWorkQueueDetailsAndSubscriberList(key);

    return workQueueDetailsAndSubscriberList;
  }

  // END, CR00143146
  // END, CR00175274

  // BEGIN, CR00225579, LP
  /**
   * Returns a list of work queue subscription details for a given work queue.
   * This list contains all the subscriptions, viz subscriptions by users,
   * organization units, jobs and positions. The returned list contains two
   * lists-
   * <li>Users subscriptions for Work Queue.
   * <li>Organization object
   * subscriptions for Work Queue.
   *
   * @param key
   * identifies the work queue for which subscription details
   * should be fetched
   *
   * @return List of work queue subscription details.
   */
  @Override
  public ListWorkQueueSubscriptions
    listAllWorkQueueSubscriptions(final ListWorkQueueSubscriptionsKey key)
      throws AppException, InformationalException {

    // Work Queue Subscription service layer objects
    final curam.core.sl.intf.WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.fact.WorkQueueSubscriptionFactory.newInstance();

    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.key.workQueueID;
    return workQueueSubscriptionObj
      .listAllSubscriptionsForWorkQueue(workQueueKey);

  }

  // END, CR00225579
  // BEGIN, CR00385998, AC
  /**
   * Retrieves a list of workQueue with a given search criteria.
   *
   * @param workQueueSearchKey
   * search criteria to search the work queue.
   *
   * @return A list of work queue.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListWorkQueueDetails
    searchWorkQueueList(final WorkQueueSearchKey workQueueSearchkey)
      throws AppException, InformationalException {

    final ListWorkQueueDetails listWorkQueueDetails =
      new ListWorkQueueDetails();

    if (CuramConst.gkEmpty
      .equals(workQueueSearchkey.dtls.administratorFirstName)
      && CuramConst.gkEmpty
        .equals(workQueueSearchkey.dtls.administratorLastName)
      && CuramConst.gkEmpty.equals(workQueueSearchkey.dtls.name)) {
      throw new AppException(
        BPOWORKALLOCATION.INF_WORK_ALLOCATION_SEARCH_NOT_FOUND);
    }
    listWorkQueueDetails.dtls = DatabaseWorkQueueSearchFactory.newInstance()
      .searchWorkQueue(workQueueSearchkey.dtls);
    if (CuramConst.gkZero == listWorkQueueDetails.dtls.dtls.dtls.size()) {
      final AppException e = new AppException(
        BPOWORKALLOCATION.INF_WORK_ALLOCATION_NO_MATCH_FOUND);
    }
    return listWorkQueueDetails;

  }

  /**
   * Method to find if the work queue search is enabled.
   *
   * @return result true if the work queue search is enabled else false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  @Override
  public WorkQueueSearchInd isWorkQueueSearchEnabled()
    throws AppException, InformationalException {

    final WorkQueueSearchInd workQueueSearchInd = new WorkQueueSearchInd();
    final String workQueueSearch = curam.util.resources.Configuration
      .getProperty(EnvVars.ENV_WORKQUEUE_SEARCH_ENABLED);

    if (workQueueSearch.equalsIgnoreCase(CuramConst.gkYes)) {
      workQueueSearchInd.workQueueSearchInd = true;
    } else {
      workQueueSearchInd.workQueueSearchInd = false;
    }
    return workQueueSearchInd;
  }
  // END, CR00385998
}
