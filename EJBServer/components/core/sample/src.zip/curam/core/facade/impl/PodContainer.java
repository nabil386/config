/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.cefwidgets.facade.struct.PageID1;
import curam.cefwidgets.facade.struct.PodConfigData1;
import curam.cefwidgets.facade.struct.PodContainerData1;
import curam.cefwidgets.pods.podContainer.impl.PodContainerManager;


/**
 * Handle incoming requests related to a Pod Container.
 *
 */
public abstract class PodContainer extends curam.core.facade.base.PodContainer {

  // ____________________________________________________________________________
  /**
   * Load the data for the Pod Container
   *
   * @param key the UIM page ID
   */
  @Override
  public PodContainerData1 loadData(PageID1 key) {

    // Return struct
    final PodContainerData1 details = new PodContainerData1();

    // PageLoader Object
    final PodContainerManager podContainer = new PodContainerManager();

    final PageID1 pageID = new PageID1();

    pageID.pageID = key.pageID;

    // Retrieve all relevant data to render up Case Home page Pods
    // (configuration and application data)
    final PodContainerData1 podContainerData = podContainer.loadContent(pageID);

    details.XMLData = podContainerData.XMLData;

    return details;
  }

  // ____________________________________________________________________________
  /**
   * <p>
   * Save the changes made to the Pod Container.
   * </p>
   *
   * <p>
   * Handles page saves, local pod saves and reset requests.
   * </p>
   *
   * @param pageID the UIM pageID
   * @param podContainerData the data received from the page.
   */
  @Override
  public void saveChanges(PageID1 pageID, PodContainerData1 podContainerData) {

    if ("reset".equals(podContainerData.XMLData)) {
      resetToDefault(pageID);
    } else {
      // Set Caseworker_customHome preferences for user
      final PodContainerManager podContainer = new PodContainerManager();

      podContainer.updateUserConfigs(pageID.pageID, podContainerData.XMLData);
    }
  }

  // ____________________________________________________________________________
  /**
   * <p>
   * Reset the page to the default setting
   * </p>
   *
   * @param pageID the pageID of the UIM
   */
  @Override
  public void resetToDefault(PageID1 pageID) {

    // Reset Caseworker_customHome preferences for user
    final PodContainerManager podContainer = new PodContainerManager();

    podContainer.resetToDefault(pageID.pageID);
  }

  // ____________________________________________________________________________
  /**
   * <p>
   * Save new Pod Positions.
   * </p>
   *
   * @param pageID the pageID of the UIM
   * @param newPodPositions the new positions of all Pods in the container.
   */
  @Override
  public void savePodPositions(PageID1 pageID, PodConfigData1 newPodPositions) {

    final PodContainerManager podContainer = new PodContainerManager();

    podContainer.saveNewPodPositions(pageID.pageID, newPodPositions.XMLData);
  }
}
