/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.fact.WMCaseAuditInstanceDataFactory;
import curam.caseaudit.entity.intf.WMCaseAuditInstanceData;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.WMCaseAuditInstanceDataDtls;
import curam.caseaudit.generator.impl.ExternalServiceCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.FixedQueryCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.ICCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.InvestigationCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.LiabilityCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.PDCaseAuditCriteriaXMLHelper;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.CaseAuditDAO;
import curam.caseaudit.impl.CaseAuditQueryManagement;
import curam.caseaudit.impl.ExternalCaseAuditData;
import curam.caseaudit.impl.ExternalCaseAuditDataDAO;
import curam.caseaudit.impl.ExternalCaseAuditDataItem;
import curam.codetable.CASESEARCHFILTER;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.impl.CASESEARCHFILTEREntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.codetable.impl.SELECTIONQUERYTYPEEntry;
import curam.core.facade.struct.AlgorithmParameters;
import curam.core.facade.struct.AuditPlanAndExternalCaseAuditDataKey;
import curam.core.facade.struct.AuditPlanAndRandInd;
import curam.core.facade.struct.AuditPlanAndSelectedCases;
import curam.core.facade.struct.CaseAndCaseAuditList;
import curam.core.facade.struct.CaseLoadDetails;
import curam.core.facade.struct.CaseOwnerAndType;
import curam.core.facade.struct.CaseSampleKey;
import curam.core.facade.struct.CaseSampleSearchFilterOptions;
import curam.core.facade.struct.CaseSampleSize;
import curam.core.facade.struct.CaseSearchDetailsList;
import curam.core.facade.struct.CaseSearchList1;
import curam.core.facade.struct.CommonICSearchCriteria;
import curam.core.facade.struct.CommonInvestigationCaseSearchCriteria;
import curam.core.facade.struct.CommonLPDSearchCriteria;
import curam.core.facade.struct.CommonPDSearchCriteria;
import curam.core.facade.struct.DynamicSearchPageName;
import curam.core.facade.struct.ExternalCaseAuditDataDetails;
import curam.core.facade.struct.ExternalCaseAuditDataDetailsList;
import curam.core.facade.struct.NumberAndPercentageOfCases;
import curam.core.facade.struct.ProduceCaseSamplePageName;
import curam.core.facade.struct.SearchOrSelectCasesKey;
import curam.core.facade.struct.SelectionQueryAndExternalCaseAuditDataKey;
import curam.core.facade.struct.WizardProperties;
import curam.core.facade.struct.WizardStartPageKey;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DP_const;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.struct.CaseFilterOptionDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.Count;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.FACADEAUDITCASESAMPLE;
import curam.message.impl.FACADEAUDITCASESAMPLEExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.selectionquery.entity.struct.SelectionQueryKey;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.fact.DeferredProcessingFactory;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.KeySet;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.type.CodeTable;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;


/**
 * Facade Class for the AuditCaseSample implementation.
 *
 */
public abstract class AuditCaseSample extends curam.core.facade.base.AuditCaseSample {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  @Inject
  protected ExternalCaseAuditDataDAO externalCaseAuditDataDAO;

  @Inject
  protected ICCaseAuditCriteriaXMLHelper icCaseAuditCriteriaXMLHelper;

  @Inject
  protected PDCaseAuditCriteriaXMLHelper pdCaseAuditCriteriaXMLHelper;

  @Inject
  protected LiabilityCaseAuditCriteriaXMLHelper liabilityCaseAuditCriteriaXMLHelper;

  @Inject
  protected InvestigationCaseAuditCriteriaXMLHelper invCaseAuditCriteriaXMLHelper;

  @Inject
  protected FixedQueryCaseAuditCriteriaXMLHelper fixedCaseAuditCriteriaXMLHelper;

  @Inject
  protected ExternalServiceCaseAuditCriteriaXMLHelper extCaseAuditCriteriaXMLHelper;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public AuditCaseSample() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Invokes a Deferred Process to generate the sample list of integrated cases
   * for audit based on the supplied search criteria. Case audits are then
   * created from the relevant cases.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generateICCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
    final WMCaseAuditInstanceData wmInstanceDataObj = WMCaseAuditInstanceDataFactory.newInstance();
    final WMCaseAuditInstanceDataDtls wmInstanceDataDtls = new WMCaseAuditInstanceDataDtls();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    auditPlan.delayedProcessingPending(auditPlan.getVersionNo());

    // Build the XML representation of the search criteria
    final String criteriaXML = icCaseAuditCriteriaXMLHelper.buildCriteria(key);

    wmInstanceDataDtls.wmInstDataID = curam.util.type.UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.caseType = CASETYPECODEEntry.INTEGRATEDCASE.getCode();
    wmInstanceDataDtls.genCaseAuditXML = new Blob(criteriaXML.getBytes());
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    deferredProcessingObj.startProcess(DP_const.DP_GEN_CASE_AUDITS,
      wmInstanceDataDtls.wmInstDataID);
  }

  // ___________________________________________________________________________
  /**
   * Invokes a Deferred Process to generate the sample list of investigation
   * cases for audit based on the supplied search criteria. Case audits are
   * then created from the relevant cases.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generateInvestigationCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
    final WMCaseAuditInstanceData wmInstanceDataObj = WMCaseAuditInstanceDataFactory.newInstance();
    final WMCaseAuditInstanceDataDtls wmInstanceDataDtls = new WMCaseAuditInstanceDataDtls();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    auditPlan.delayedProcessingPending(auditPlan.getVersionNo());

    // Build the XML representation of the search criteria
    final String criteriaXML = invCaseAuditCriteriaXMLHelper.buildCriteria(key);

    wmInstanceDataDtls.wmInstDataID = curam.util.type.UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.caseType = CASETYPECODEEntry.INVESTIGATIONCASE.getCode();
    wmInstanceDataDtls.genCaseAuditXML = new Blob(criteriaXML.getBytes());
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    deferredProcessingObj.startProcess(DP_const.DP_GEN_CASE_AUDITS,
      wmInstanceDataDtls.wmInstDataID);
  }

  // ___________________________________________________________________________
  /**
   * Invokes a Deferred Process to generate the sample list of product delivery
   * cases for audit based on the supplied search criteria. Case audits are
   * then created from the relevant cases.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generatePDCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
    final WMCaseAuditInstanceData wmInstanceDataObj = WMCaseAuditInstanceDataFactory.newInstance();
    final WMCaseAuditInstanceDataDtls wmInstanceDataDtls = new WMCaseAuditInstanceDataDtls();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    auditPlan.delayedProcessingPending(auditPlan.getVersionNo());

    // Build the XML representation of the search criteria
    final String criteriaXML = pdCaseAuditCriteriaXMLHelper.buildCriteria(key);

    wmInstanceDataDtls.wmInstDataID = curam.util.type.UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.caseType = CASETYPECODEEntry.PRODUCTDELIVERY.getCode();
    wmInstanceDataDtls.genCaseAuditXML = new Blob(criteriaXML.getBytes());
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    deferredProcessingObj.startProcess(DP_const.DP_GEN_CASE_AUDITS,
      wmInstanceDataDtls.wmInstDataID);
  }

  // ___________________________________________________________________________
  /**
   * Invokes a Deferred Process to generate the sample list of liability product
   * delivery cases for audit, based on the supplied search criteria. Case
   * audits are then created from the relevant cases.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generateLPDCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
    final WMCaseAuditInstanceData wmInstanceDataObj = WMCaseAuditInstanceDataFactory.newInstance();
    final WMCaseAuditInstanceDataDtls wmInstanceDataDtls = new WMCaseAuditInstanceDataDtls();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    auditPlan.delayedProcessingPending(auditPlan.getVersionNo());

    // Build the XML representation of the search criteria
    final String criteriaXML = liabilityCaseAuditCriteriaXMLHelper.buildCriteria(
      key);

    wmInstanceDataDtls.wmInstDataID = curam.util.type.UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.caseType = CASETYPECODEEntry.LIABILITY.getCode();
    wmInstanceDataDtls.genCaseAuditXML = new Blob(criteriaXML.getBytes());
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    deferredProcessingObj.startProcess(DP_const.DP_GEN_CASE_AUDITS,
      wmInstanceDataDtls.wmInstDataID);
  }

  // ___________________________________________________________________________
  /**
   * Returns the size of the sample list of cases for audit based on the
   * supplied search criteria.
   *
   * @param key The search criteria entered by the user.
   *
   * @return The size of the sample list of cases for audit.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSize generateICCaseSampleSize(
    final CommonICSearchCriteria key) throws AppException,
      InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    if (key.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.searchWithIssues = true;
          continue;
        }
      }
    }

    key.caseTypeCode = CASETYPECODEEntry.INTEGRATEDCASE.getCode();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    key.category = auditPlan.getAuditCaseConfig().getCaseCategory().getCode();

    // BEGIN, CR00290965, IBM
    final Count count = caseHeaderDAO.countCaseByCommonICCriteria(key);

    if (null != count) {
      caseSampleSize.count = count.numberOfRecords;
    }
    // END, CR00290965

    return caseSampleSize;
  }

  // ___________________________________________________________________________
  /**
   * Returns the size of the sample list of investigation cases for audit based
   * on the supplied search criteria.
   *
   * @param key The search criteria entered by the user.
   *
   * @return The size of the sample list of investigation cases for audit.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSize generateInvestigationCaseSampleSize(
    final CommonInvestigationCaseSearchCriteria key) throws AppException,
      InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    if (key.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.searchWithIssues = true;
          continue;
        }
      }
    }

    key.caseTypeCode = CASETYPECODEEntry.INVESTIGATIONCASE.getCode();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    key.category = auditPlan.getAuditCaseConfig().getCaseCategory().getCode();

    // BEGIN, CR00290965, IBM
    final Count count = caseHeaderDAO.countCaseByCommonInvestigationCaseCriteria(
      key);

    if (null != count) {
      caseSampleSize.count = count.numberOfRecords;
    }
    // END, CR00290965

    return caseSampleSize;
  }

  // ___________________________________________________________________________
  /**
   * Returns the size of the sample list of product delivery cases for audit
   * based on the supplied search criteria.
   *
   * @param key The search criteria entered by the user.
   *
   * @return The size of the sample list of cases for audit.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSize generatePDCaseSampleSize(
    final CommonPDSearchCriteria key) throws AppException,
      InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    if (key.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.searchWithIssues = true;
          continue;
        }
      }
    }

    key.caseTypeCode = CASETYPECODEEntry.PRODUCTDELIVERY.getCode();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    key.category = auditPlan.getAuditCaseConfig().getCaseCategory().getCode();

    // BEGIN, CR00290965, IBM
    final Count count = caseHeaderDAO.countCaseByCommonPDCriteria(key);

    if (null != count) {
      caseSampleSize.count = count.numberOfRecords;
    }
    // END, CR00290965

    return caseSampleSize;
  }

  // ___________________________________________________________________________
  /**
   * Returns the size of the sample list of liability product delivery cases for
   * audit based on the supplied search criteria.
   *
   * @param key The search criteria entered by the user.
   *
   * @return The size of the sample list of cases for audit.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSize generateLPDCaseSampleSize(
    final CommonLPDSearchCriteria key) throws AppException,
      InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    if (key.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.searchWithIssues = true;
          continue;
        }
      }
    }

    key.caseTypeCode = CASETYPECODEEntry.LIABILITY.getCode();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    key.category = auditPlan.getAuditCaseConfig().getCaseCategory().getCode();

    // BEGIN, CR00290965, IBM
    final Count count = caseHeaderDAO.countCaseByCommonLPDCriteria(key);

    if (null != count) {
      caseSampleSize.count = count.numberOfRecords;
    }
    // END, CR00290965

    return caseSampleSize;
  }

  // ___________________________________________________________________________
  /**
   * Returns the number and percentage of cases as passed in by the client.
   *
   * @param key The number and percentage of cases
   *
   * @return The passed in number and percentage details
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public NumberAndPercentageOfCases getNumberAndPercentageOfCases(
    final NumberAndPercentageOfCases key) throws AppException,
      InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the IC case sample generation.
   *
   * @return The wizard details for the IC case sample generation.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WizardProperties getICCaseSampleWizard() throws AppException,
      InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaseAuditSampleICWizardProperties;
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the investigation case sample
   * generation.
   *
   * @return The wizard details for the investigation case sample generation.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WizardProperties getInvestigationCaseSampleWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaseAuditSampleInvestigationCaseWizardProperties;
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the PD case sample generation.
   *
   * @return The wizard details for the IC case sample generation.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WizardProperties getPDCaseSampleWizard() throws AppException,
      InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaseAuditSamplePDWizardProperties;
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the Liability PD case sample
   * generation.
   *
   * @return The wizard details for the IC case sample generation.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WizardProperties getLPDCaseSampleWizard() throws AppException,
      InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaseAuditSampleLPDWizardProperties;
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Method to get the search filter options for the sample search screens.
   *
   * @param key the case type that the search is based on.
   *
   * @return Search filter options.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSearchFilterOptions getCaseSampleSearchFilterOptions(
    final CaseTypeCode key) throws AppException, InformationalException {

    final CaseSampleSearchFilterOptions caseSampleSearchFilterOptions = new CaseSampleSearchFilterOptions();

    // Get search filter options for locale value and codetable
    final LinkedHashMap<String, String> filterOptionList = CodeTable.getAllEnabledItems(
      CASESEARCHFILTER.TABLENAME, TransactionInfo.getProgramLocale());

    CaseFilterOptionDetails caseFilterOptionDetails;

    if (!filterOptionList.isEmpty()) {

      final Set<String> keys = filterOptionList.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        caseFilterOptionDetails = new CaseFilterOptionDetails();

        caseFilterOptionDetails.filterOption = itr.next().toString();

        if (!caseFilterOptionDetails.filterOption.equals(
          CASESEARCHFILTEREntry.INVESTIGATIONS.getCode())
            && !caseFilterOptionDetails.filterOption.equals(
              CASESEARCHFILTEREntry.SERVICEPLANS.getCode())) {

          caseFilterOptionDetails.filterOptionDescription = filterOptionList.get(caseFilterOptionDetails.filterOption).toString();
          caseSampleSearchFilterOptions.filterOptions.addRef(
            caseFilterOptionDetails);
        }
      }
    }

    return caseSampleSearchFilterOptions;
  }

  // ___________________________________________________________________________
  /**
   * Returns the IC Case Sample search criteria as passed in by the client.
   *
   * @param key The IC Case Sample search criteria.
   *
   * @return The passed in IC Case Sample search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonICSearchCriteria getICSearchCriteria(
    final CommonICSearchCriteria key) throws AppException,
      InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Investigation Case Sample search criteria as passed in by the
   * client.
   *
   * @param key The Investigation Case Sample search criteria.
   *
   * @return The passed in Investigation Case Sample search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonInvestigationCaseSearchCriteria getInvestigationCaseSearchCriteria(
    final CommonInvestigationCaseSearchCriteria key) throws AppException,
      InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Returns the PD Case Sample search criteria as passed in by the client.
   *
   * @param key The PD Case Sample search criteria.
   *
   * @return The passed in PD Case Sample search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonPDSearchCriteria getPDSearchCriteria(
    final CommonPDSearchCriteria key) throws AppException,
      InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Liability PD Case Sample search criteria as passed in by the
   * client.
   *
   * @param key The Liability PD Case Sample search criteria.
   *
   * @return The passed in Liability PD Case Sample search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonLPDSearchCriteria getLPDSearchCriteria(
    final CommonLPDSearchCriteria key) throws AppException,
      InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the number and percentage of cases to audit.
   *
   * @param key The number/percentage of cases entered by the user and the total
   * case sample size.
   *
   * @return The number/percentage of cases entered by the user and the total
   * case sample size.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleKey validateCaseSampleAmount(final CaseSampleKey key)
    throws AppException, InformationalException {

    if (key.numberOfCases == 0 && key.percentageOfCases == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_NUM_CASES_OR_PERCENTAGE_CASES_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (key.numberOfCases > 0 && key.percentageOfCases > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_NUM_CASES_AND_PERCENTAGE_CASES_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (key.numberOfCases > key.totalNumCases) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_NUM_CASES_EXCEEDS_TOTAL_CASES(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00238338, PF
    if (key.percentageOfCases > CuramConst.gkOneHundredPercent) {

      final AppException ae = new AppException(
        FACADEAUDITCASESAMPLE.ERR_XFV_PERCENTAGE_CASES_EXCEEDS_MAX);

      ae.arg(CuramConst.gkOneHundredPercent);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // BEGIN, CR00238338, PF

    ValidationHelper.failIfErrorsExist();

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the IC case sample search criteria entered.
   *
   * @param key The search criteria entered.
   *
   * @return The passed in search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonICSearchCriteria validateICSearchCriteria(
    final CommonICSearchCriteria key) throws AppException,
      InformationalException {

    // At least one criteria must be entered
    if (key.age == 0 && key.status.length() == 0 && key.startDateTo.isZero()
      && key.startDateFrom.isZero() && key.ownerLocation == 0
      && key.gender.length() == 0 && key.endDateTo.isZero()
      && key.endDateFrom.isZero() && key.caseOwner.length() == 0
      && !key.searchWithAppeals && !key.searchWithIssues) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_NO_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // If a to date is entered a from date must be entered
    if (!key.startDateTo.isZero() && key.startDateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_DATE_TO_NO_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.endDateTo.isZero() && key.endDateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_NO_END_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Validations to check if from date value is before to date value
    if (!key.startDateFrom.isZero() && !key.startDateTo.isZero()
      && key.startDateFrom.after(key.startDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_DATE_TO_BEFORE_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if (!key.endDateTo.isZero() && key.endDateFrom.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_END_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Validations to check if start date values are before end date values
    if (!key.startDateFrom.isZero() && !key.endDateFrom.isZero()
      && key.startDateFrom.after(key.endDateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_FROM_BEFORE_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if (!key.startDateTo.isZero() && !key.endDateTo.isZero()
      && key.startDateTo.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_START_DATE_TO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();

    // Validate that the case owner and case owner type are a
    // valid combination
    final CaseOwnerAndType caseOwnerAndType = new CaseOwnerAndType();

    caseOwnerAndType.caseOwner = key.caseOwner;
    caseOwnerAndType.orgObjectType = key.orgObjectType;
    validateCaseOwner(caseOwnerAndType);

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the PD case sample search criteria entered.
   *
   * @param key The search criteria entered.
   *
   * @return The passed in search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonPDSearchCriteria validatePDSearchCriteria(
    final CommonPDSearchCriteria key) throws AppException,
      InformationalException {

    // At least one criteria must be entered
    if (key.age == 0 && key.status.length() == 0 && key.startDateTo.isZero()
      && key.startDateFrom.isZero() && key.ownerLocation == 0
      && key.gender.length() == 0 && key.endDateTo.isZero()
      && key.endDateFrom.isZero() && key.caseOwner.length() == 0
      && key.decision.length() == 0 && key.certificationFromDate.isZero()
      && key.certificationToDate.isZero() && key.timePeriodFromDate.isZero()
      && key.timePeriodToDate.isZero() && !key.searchWithAppeals
      && !key.searchWithIssues) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_NO_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // If a to date is entered a from date must be entered
    if (!key.startDateTo.isZero() && key.startDateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_DATE_TO_NO_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if (!key.endDateTo.isZero() && key.endDateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_NO_END_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (!key.timePeriodToDate.isZero() && key.timePeriodFromDate.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_TIME_PERIOD_TO_NO_TIME_PERIOD_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.certificationToDate.isZero() && key.certificationFromDate.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_CERTIFICATION_DATE_TO_NO_CERTIFICATION_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Validations to check if from date value is before to date value
    if (!key.startDateFrom.isZero() && !key.startDateTo.isZero()
      && key.startDateFrom.after(key.startDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_DATE_TO_BEFORE_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.endDateTo.isZero() && key.endDateFrom.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_END_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if (!key.timePeriodFromDate.isZero() && !key.timePeriodToDate.isZero()
      && key.timePeriodFromDate.after(key.timePeriodToDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_TIME_PERIOD_TO_BEFORE_TIME_PERIOD_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.certificationFromDate.isZero()
      && !key.certificationToDate.isZero()
      && key.certificationFromDate.after(key.certificationToDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_CERTIFICATION_DATE_TO_BEFORE_CERTIFICATION_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Validations to check if start date values are after end date values
    if (!key.startDateFrom.isZero() && !key.endDateFrom.isZero()
      && key.startDateFrom.after(key.endDateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_FROM_BEFORE_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.startDateTo.isZero() && !key.endDateTo.isZero()
      && key.startDateTo.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_START_DATE_TO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (!key.timePeriodFromDate.isZero() && !key.endDateFrom.isZero()
      && key.timePeriodFromDate.after(key.endDateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_FROM_BEFORE_TIME_PERIOD_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.timePeriodToDate.isZero() && !key.endDateTo.isZero()
      && key.timePeriodToDate.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_TIME_PERIOD_TO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.certificationFromDate.isZero() && !key.endDateFrom.isZero()
      && key.certificationFromDate.after(key.endDateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_FROM_BEFORE_CERTIFICATION_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!key.certificationToDate.isZero() && !key.endDateTo.isZero()
      && key.certificationToDate.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_CERTIFICATION_DATE_TO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // If time period entered then either decision or status must be specified
    // Time period is not a selection criterion in its own right
    if ((!key.timePeriodFromDate.isZero() || !key.timePeriodToDate.isZero())
      && key.decision.length() == 0 && key.status.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_TIME_PERIOD_SET_STATUS_AND_DECISION_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();

    // Validate that the case owner and case owner type are a
    // valid combination
    final CaseOwnerAndType caseOwnerAndType = new CaseOwnerAndType();

    caseOwnerAndType.caseOwner = key.caseOwner;
    caseOwnerAndType.orgObjectType = key.orgObjectType;
    validateCaseOwner(caseOwnerAndType);

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the Liability PD case sample search criteria entered.
   *
   * @param key The search criteria entered.
   *
   * @return The passed in search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonLPDSearchCriteria validateLPDSearchCriteria(
    final CommonLPDSearchCriteria key) throws AppException,
      InformationalException {

    // The common liability product delivery search validation is currently
    // exactly the same search as the product delivery search validation. This
    // may not be the case in the future.

    // convert Common Liability PD Search Criteria key into Common PD
    // Search Criteria key
    CommonPDSearchCriteria commonPDSearchCriteria = new CommonPDSearchCriteria();

    commonPDSearchCriteria.assign(key);

    commonPDSearchCriteria = validatePDSearchCriteria(commonPDSearchCriteria);

    key.assign(commonPDSearchCriteria);

    return key;

  }

  // ___________________________________________________________________________
  /**
   * Method to validate the PD case sample search criteria entered.
   *
   * @param key The search criteria entered.
   *
   * @return The passed in search criteria.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CommonInvestigationCaseSearchCriteria validateInvestigationCaseSearchCriteria(
    final CommonInvestigationCaseSearchCriteria key) throws AppException,
      InformationalException {

    // At least one criteria must be entered
    if (key.age == 0 && key.status.length() == 0 && key.startDateTo.isZero()
      && key.startDateFrom.isZero() && key.ownerLocation == 0
      && key.gender.length() == 0 && key.endDateTo.isZero()
      && key.endDateFrom.isZero() && key.caseOwner.length() == 0
      && !key.searchWithIssues && key.investigationResolution.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_NO_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // If a to date is entered a from date must be entered
    if (!key.startDateTo.isZero() && key.startDateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_DATE_TO_NO_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (!key.endDateTo.isZero() && key.endDateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_NO_END_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // Validations to check if from date value is before to date value
    if (!key.startDateFrom.isZero() && !key.startDateTo.isZero()
      && key.startDateFrom.after(key.startDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_DATE_TO_BEFORE_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (!key.endDateTo.isZero() && key.endDateFrom.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_END_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Validations to check if start date values are after end date values
    if (!key.startDateFrom.isZero() && !key.endDateFrom.isZero()
      && key.startDateFrom.after(key.endDateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_FROM_BEFORE_START_DATE_FROM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if (!key.startDateTo.isZero() && !key.endDateTo.isZero()
      && key.startDateTo.after(key.endDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_END_DATE_TO_BEFORE_START_DATE_TO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    ValidationHelper.failIfErrorsExist();

    // Validate that the case owner and case owner type are a
    // valid combination
    final CaseOwnerAndType caseOwnerAndType = new CaseOwnerAndType();

    caseOwnerAndType.caseOwner = key.caseOwner;
    caseOwnerAndType.orgObjectType = key.orgObjectType;
    validateCaseOwner(caseOwnerAndType);

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the dynamic search page and query identifier for the case type
   * associated with this audit plan.
   *
   * @param key The audit plan and whether or not the user is manually
   * selecting cases.
   *
   * @return The name of the dynamic search page
   */
  @Override
  public DynamicSearchPageName resolveDynamicSearchDetails(
    final AuditPlanAndRandInd key) throws AppException,
      InformationalException {

    final DynamicSearchPageName dynamicSearchPageName = new DynamicSearchPageName();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    if (key.randomInd) {
      dynamicSearchPageName.pageName = auditCaseConfig.getDynamicQuery().getRandomPageName();
    } else {
      dynamicSearchPageName.pageName = auditCaseConfig.getDynamicQuery().getManualPageName();
    }

    if (dynamicSearchPageName.pageName.contains("Page.do?")) {
      dynamicSearchPageName.pageName = dynamicSearchPageName.pageName
        + "&auditPlanID=" + key.auditPlanID + "&queryID="
        + auditCaseConfig.getDynamicQuery().getID();
    } else {
      dynamicSearchPageName.pageName = dynamicSearchPageName.pageName
        + "?auditPlanID=" + key.auditPlanID + "&queryID="
        + auditCaseConfig.getDynamicQuery().getID();
    }

    return dynamicSearchPageName;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the page name to display and the query identifier when the user
   * chooses to produce a case sample.
   *
   * @param key The audit plan that the case sample is being produced for
   *
   * @return The name of the page to display
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ProduceCaseSamplePageName resolveProduceCaseSampleDetails(
    final AuditPlanKey key) throws AppException, InformationalException {

    final ProduceCaseSamplePageName produceCaseSamplePageName = new ProduceCaseSamplePageName();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    if (listExternalCaseAuditData().dtls.size() > 0) {
      produceCaseSamplePageName.pageName = UimConst.kListQueriesAndExternalServices
        + "?auditCaseConfigID=" + auditCaseConfig.getID() + "&auditPlanID="
        + auditPlan.getID() + "&randomInd=true";

    } else if (auditCaseConfig.getFixedQueries().size() > 0) {

      produceCaseSamplePageName.pageName = UimConst.kListQueriesForConfiguration
        + "?auditCaseConfigID=" + auditCaseConfig.getID() + "&auditPlanID="
        + auditPlan.getID() + "&randomInd=true";

    } else {

      final AuditPlanAndRandInd auditPlanAndRandInd = new AuditPlanAndRandInd();

      auditPlanAndRandInd.auditPlanID = key.auditPlanID;
      auditPlanAndRandInd.randomInd = true;

      produceCaseSamplePageName.pageName = resolveDynamicSearchDetails(auditPlanAndRandInd).pageName;
    }

    return produceCaseSamplePageName;
  }

  // ___________________________________________________________________________
  /**
   * Returns the algorithm configuration parameters as passed in by the client.
   *
   * @param key The algorithm configuration parameters
   *
   * @return The passed in algorithm configuration parameters
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AlgorithmParameters getAlgorithmParameters(
    final AlgorithmParameters key) throws AppException,
      InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the algorithm configuration parameters.
   *
   * @param key The algorithm configuration parameters.
   *
   * @return The algorithm configuration parameters entered by the user
   * and the total case sample size.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleKey validateAlgorithmParameters(final CaseSampleKey key)
    throws AppException, InformationalException {

    long numberOfCasesToProcess = 0;

    // BEGIN, CR00238338, PF
    if (key.numberOfCases > 0) {
      numberOfCasesToProcess = key.numberOfCases;
    } else if (key.percentageOfCases > 0) {
      numberOfCasesToProcess = Math.round(
        key.percentageOfCases / CuramConst.gkOneHundredPercent
        * key.totalNumCases);
    } else {
      numberOfCasesToProcess = key.totalNumCases;
    }
    // END, CR00238338

    if (key.details.startPoint > numberOfCasesToProcess) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_START_POINT_EXCEEDS_TOTAL_CASES(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (key.details.interval > numberOfCasesToProcess) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_INTERVAL_EXCEEDS_TOTAL_CASES(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate that the case owner and case owner type are a
   * valid combination.
   *
   * @param details The case owner and case owner type.
   */
  @Override
  protected void validateCaseOwner(final CaseOwnerAndType details)
    throws AppException, InformationalException {

    if (!StringHelper.isEmpty(details.caseOwner)
      && !details.orgObjectType.equals(
        ORGOBJECTTYPEEntry.NOT_SPECIFIED.getCode())) {

      if (details.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

        // check that the case owner name value is a user name
        // parsing the caseOwnerName value should throw an error if its not
        // a user name
        try {
          Long.parseLong(details.caseOwner);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        } catch (final NumberFormatException e) {// we weren't able to parse the
          // caseOwnerName value so this
          // implies that the caseOwnerName value is a user name. e.g.
          // 'superuser'
        }

      } else if (details.orgObjectType.equals(ORGOBJECTTYPE.ORGUNIT)) {

        final OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        // Check to see if the case owner name value is an organization unit
        try {
          // try parse the caseOwnerName value, if this throws an error it
          // means a user name string value like 'superuser' has been passed
          // down
          organisationUnitKey.organisationUnitID = Long.parseLong(
            details.caseOwner);
        } catch (final NumberFormatException e) {
          // Not an organization unit so throw an exception
          throw new AppException(
            curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        }

        try {
          organisationUnitObj.read(organisationUnitKey);
        } catch (final RecordNotFoundException e) {
          // Not an organization unit so throw an exception
          throw new AppException(
            curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        }

      } else if (details.orgObjectType.equals(ORGOBJECTTYPE.POSITION)) {

        final Position positionObj = PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        try {
          // try parse the caseOwnerName value, if this throws an error it
          // means a user name string value like 'superuser' has been passed
          // down
          positionKey.positionID = Long.parseLong(details.caseOwner);
        } catch (final NumberFormatException e) {
          // Not a position so throw an exception
          throw new AppException(
            curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        }

        try {
          positionObj.read(positionKey);
        } catch (final RecordNotFoundException e) {
          // Not a position so throw an exception
          throw new AppException(
            curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        }

      } else if (details.orgObjectType.equals(ORGOBJECTTYPE.WORKQUEUE)) {

        final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
        final WorkQueueKey workQueueKey = new WorkQueueKey();

        try {
          // try parse the caseOwnerName value, if this throws an error it
          // means a user name string value like 'superuser' has been passed
          // down
          workQueueKey.workQueueID = Long.parseLong(details.caseOwner);
        } catch (final NumberFormatException e) {
          // Not a work queue so throw an exception
          throw new AppException(
            curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        }

        try {
          workQueueObj.read(workQueueKey);
        } catch (final RecordNotFoundException e) {
          // Not a work queue so throw an exception
          throw new AppException(
            curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Invokes a Deferred Process to generate the sample list of cases for audit
   * using the supplied fixed query. Case audits are then created from the
   * relevant cases.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generateFixedQueryCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
    final WMCaseAuditInstanceData wmInstanceDataObj = WMCaseAuditInstanceDataFactory.newInstance();
    final WMCaseAuditInstanceDataDtls wmInstanceDataDtls = new WMCaseAuditInstanceDataDtls();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    auditPlan.delayedProcessingPending(auditPlan.getVersionNo());

    // Build the XML representation of the search criteria
    final String criteriaXML = fixedCaseAuditCriteriaXMLHelper.buildCriteria(
      key);

    wmInstanceDataDtls.wmInstDataID = curam.util.type.UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.fixedQueryInd = true;
    wmInstanceDataDtls.genCaseAuditXML = new Blob(criteriaXML.getBytes());
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    deferredProcessingObj.startProcess(DP_const.DP_GEN_CASE_AUDITS,
      wmInstanceDataDtls.wmInstDataID);
  }

  // BEGIN, CR00264606, GD
  // ___________________________________________________________________________
  /**
   * Returns the size of the sample list of cases for audit using the supplied
   * fixed query.
   *
   * @param key The fixed query.
   *
   * @return The size of the sample list of cases for audit.
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 SP1, replaced with
   * generateFixedQueryFilteredCaseSampleSize(). This method should not be used
   * as it is incorrectly returning cases of all case types. Only cases matching
   * the criteria specified in the query that are of the case type being audited
   * should be returned, see release note: <CR00264606>
   */
  @Override
  @Deprecated
  // END, CR00264606
  public CaseSampleSize generateFixedQueryCaseSampleSize(
    final SelectionQueryKey key) throws AppException,
      InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    final CaseAuditQueryManagement caseAuditQueryManagement = new CaseAuditQueryManagement();

    final List<CaseHeader> caseList = caseAuditQueryManagement.runFixedQueryCaseSearch(
      key.selectionQueryID);

    caseSampleSize.count = caseList.size();

    return caseSampleSize;
  }

  // BEGIN, CR00264606, GD
  // ___________________________________________________________________________
  /**
   * Returns the size of the sample list of cases for audit using the supplied
   * fixed query. Only cases matching the case type being audited are included
   * in the sample list.
   *
   * @param key the audit plan id and the selection query or external service
   * id used to generate the case sample.
   *
   * @return The size of the sample list of cases for audit.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSize generateFixedQueryFilteredCaseSampleSize(
    final CaseSampleKey key) throws AppException, InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    final CaseAuditQueryManagement caseAuditQueryManagement = new CaseAuditQueryManagement();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    final List<CaseHeader> caseList = caseAuditQueryManagement.runFixedQueryCaseSearch(
      key.selectionQueryID);

    // Filter the case list so only cases matching that are of the case type
    // being audited are included.
    final List<CaseHeader> filteredCaseList = filterCaseListByAuditPlan(
      caseList, auditPlan);

    caseSampleSize.count = filteredCaseList.size();

    return caseSampleSize;
  }

  // END, CR00264606

  // ___________________________________________________________________________
  /**
   * Retrieves the name of the wizard start page using the supplied query.
   *
   * @param key The selection query, external data and audit plan and an
   * indicator outlining if the user is randomly selecting cases.
   *
   * @return The name of the page to display
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ProduceCaseSamplePageName resolveWizardStartPage(
    final WizardStartPageKey key) throws AppException, InformationalException {

    final ProduceCaseSamplePageName produceCaseSamplePageName = new ProduceCaseSamplePageName();

    if (!key.randomInd) {

      if (key.selectionQueryID != 0) {

        final SelectionQuery selectionQuery = selectionQueryDAO.get(
          key.selectionQueryID);

        if (selectionQuery.getType().getCode().equals(
          SELECTIONQUERYTYPEEntry.DYNAMIC.getCode())
            || selectionQuery.getType().getCode().equals(
              SELECTIONQUERYTYPEEntry.PREDEFINED.getCode())) {

          produceCaseSamplePageName.pageName = selectionQuery.getManualPageName();

          if (produceCaseSamplePageName.pageName.contains("Page.do?")) {
            produceCaseSamplePageName.pageName = produceCaseSamplePageName.pageName
              + "&auditPlanID=" + key.auditPlanID + "&queryID="
              + key.selectionQueryID;
          } else {
            produceCaseSamplePageName.pageName = produceCaseSamplePageName.pageName
              + "?auditPlanID=" + key.auditPlanID + "&queryID="
              + key.selectionQueryID;
          }
        } else {
          produceCaseSamplePageName.pageName = UimConst.kManuallySearchAndSelectCasesPage
            + "?auditPlanID=" + key.auditPlanID + "&selectionQueryID="
            + key.selectionQueryID + "&externalCaseAuditDataID="
            + key.externalCaseAuditDataID;
        }
      } else {
        produceCaseSamplePageName.pageName = UimConst.kManuallySearchAndSelectCasesPage
          + "?auditPlanID=" + key.auditPlanID + "&selectionQueryID="
          + key.selectionQueryID + "&externalCaseAuditDataID="
          + key.externalCaseAuditDataID;
      }
    } else {

      if (key.externalCaseAuditDataID != 0) {

        produceCaseSamplePageName.pageName = UimConst.kExternalServiceWizardStartPage
          + "?auditPlanID=" + key.auditPlanID + "&numberOfCases="
          + "&percentageOfCases=" + "&startPoint=" + "&interval="
          + "&externalCaseAuditDataID=" + key.externalCaseAuditDataID;

      } else {

        final SelectionQuery selectionQuery = selectionQueryDAO.get(
          key.selectionQueryID);

        if (selectionQuery.getType().getCode().equals(
          SELECTIONQUERYTYPEEntry.FIXED.getCode())) {

          produceCaseSamplePageName.pageName = UimConst.kFixedQueryWizardStartPage
            + "?auditPlanID=" + key.auditPlanID + "&numberOfCases="
            + "&percentageOfCases=" + "&startPoint=" + "&interval="
            + "&queryID=" + key.selectionQueryID;

        } else {

          produceCaseSamplePageName.pageName = selectionQuery.getRandomPageName();

          if (produceCaseSamplePageName.pageName.contains("Page.do?")) {
            produceCaseSamplePageName.pageName = produceCaseSamplePageName.pageName
              + "&auditPlanID=" + key.auditPlanID + "&queryID="
              + key.selectionQueryID;
          } else {
            produceCaseSamplePageName.pageName = produceCaseSamplePageName.pageName
              + "?auditPlanID=" + key.auditPlanID + "&queryID="
              + key.selectionQueryID;
          }
        }
      }
    }
    return produceCaseSamplePageName;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the fixed query case
   * sample generation.
   *
   * @return The wizard details for the fixed query case sample generation.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WizardProperties getFixedQueryCaseSampleWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaseAuditFixedQueryWizardProperties;
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Method to resolve the page to display based on the types of queries
   * available to the coordinator.
   *
   * @param key The audit plan and whether or not the user is manually
   * selecting cases.
   *
   * @return The name of the page to display
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ProduceCaseSamplePageName resolveQuerySelection(
    final AuditPlanAndRandInd key) throws AppException,
      InformationalException {

    final ProduceCaseSamplePageName produceCaseSamplePageName = new ProduceCaseSamplePageName();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    if (listExternalCaseAuditData().dtls.size() > 0) {
      produceCaseSamplePageName.pageName = UimConst.kListQueriesAndExternalServices
        + "?auditCaseConfigID=" + auditCaseConfig.getID() + "&auditPlanID="
        + auditPlan.getID() + "&randomInd=" + key.randomInd;

    } else if (auditCaseConfig.getFixedQueries().size() > 0) {

      produceCaseSamplePageName.pageName = UimConst.kListQueriesForConfiguration
        + "?auditCaseConfigID=" + auditCaseConfig.getID() + "&auditPlanID="
        + auditPlan.getID() + "&randomInd=" + key.randomInd;

    } else {

      final DynamicSearchPageName dynamicSearchDetails = resolveDynamicSearchDetails(
        key);

      produceCaseSamplePageName.pageName = dynamicSearchDetails.pageName;
    }

    return produceCaseSamplePageName;
  }

  // ___________________________________________________________________________
  /**
   * Returns the selected query as passed in by the client.
   *
   * @param key The selected selection query.
   *
   * @return The passed in selection query.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SelectionQueryKey getSelectedQuery(final SelectionQueryKey key)
    throws AppException, InformationalException {

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Invokes a Deferred Process to generate the sample list of cases for audit
   * using a supplied external service. Case audits are then created from the
   * relevant cases.
   *
   * @param key The search criteria, percentage/number of cases to generate and
   * any algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void generateExternalCaseAuditData(final CaseSampleKey key)
    throws AppException, InformationalException {

    final curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
    final WMCaseAuditInstanceData wmInstanceDataObj = WMCaseAuditInstanceDataFactory.newInstance();
    final WMCaseAuditInstanceDataDtls wmInstanceDataDtls = new WMCaseAuditInstanceDataDtls();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    auditPlan.delayedProcessingPending(auditPlan.getVersionNo());

    // Build the XML representation of the search criteria
    final String criteriaXML = extCaseAuditCriteriaXMLHelper.buildCriteria(key);

    wmInstanceDataDtls.wmInstDataID = curam.util.type.UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.externalServiceInd = true;
    wmInstanceDataDtls.genCaseAuditXML = new Blob(criteriaXML.getBytes());
    wmInstanceDataObj.insert(wmInstanceDataDtls);

    deferredProcessingObj.startProcess(DP_const.DP_GEN_CASE_AUDITS,
      wmInstanceDataDtls.wmInstDataID);
  }

  // ___________________________________________________________________________
  /**
   * Returns the size of the list of cases for audit as supplied by an
   * external service.
   *
   * @param key The unique identifier representing the list of cases and the
   * audit plan identifier
   *
   * @return The size of the list of cases for audit as supplied by an
   * external service
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseSampleSize generateExternalCaseAuditDataSize(
    final AuditPlanAndExternalCaseAuditDataKey key) throws AppException,
      InformationalException {

    final CaseSampleSize caseSampleSize = new CaseSampleSize();

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    final ExternalCaseAuditData externalCaseAuditData = externalCaseAuditDataDAO.get(
      key.externalCaseAuditDataID);

    // BEGIN, CR00290965, IBM
    final Count count = externalCaseAuditData.countExternalCaseAuditDataItemsByType(
      CASETYPECODEEntry.get(auditCaseConfig.getCaseType().getCode()),
      auditCaseConfig.getCaseCategory());

    if (null != count) {
      caseSampleSize.count = count.numberOfRecords;
    }
    // END, CR00290965

    return caseSampleSize;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the wizard details for the external case audit data
   * case sample generation.
   *
   * @return The wizard details for the external case audit data
   * case sample generation.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WizardProperties getExternalCaseAuditDataWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaseAuditExternalServiceWizardProperties;
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all external case audit data.
   * This data is received via an external service.
   *
   * @return The list of all external case audit data.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ExternalCaseAuditDataDetailsList listExternalCaseAuditData()
    throws AppException, InformationalException {

    final ExternalCaseAuditDataDetailsList externalCaseAuditDataDetailsList = new ExternalCaseAuditDataDetailsList();

    final SortedSet<ExternalCaseAuditData> externalCaseAuditDataList = externalCaseAuditDataDAO.readAll();

    for (final ExternalCaseAuditData externalCaseAuditData : externalCaseAuditDataList) {

      final ExternalCaseAuditDataDetails externalCaseAuditDataDetails = new ExternalCaseAuditDataDetails();

      externalCaseAuditDataDetails.externalCaseAuditDataID = externalCaseAuditData.getID();
      externalCaseAuditDataDetails.name = externalCaseAuditData.getName();
      externalCaseAuditDataDetailsList.dtls.add(externalCaseAuditDataDetails);
    }

    return externalCaseAuditDataDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the selected query or external service.
   *
   * @param key The selected query or external service.
   * @return The selected query or external service.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SelectionQueryAndExternalCaseAuditDataKey validateSelectedQueryAndExternalService(
    SelectionQueryAndExternalCaseAuditDataKey key) throws AppException,
      InformationalException {

    if (key.selectionQueryID != 0 && key.externalCaseAuditDataID != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_QUERY_AND_EXTERNAL_SERVICE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (key.selectionQueryID == 0 && key.externalCaseAuditDataID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADEAUDITCASESAMPLEExceptionCreator.ERR_XFV_QUERY_OR_EXTERNAL_SERVICE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();
    return key;
  }

  // BEGIN, CR00264606, GD
  // ___________________________________________________________________________
  /**
   * Method to return a list of cases from either a selection query or
   * external service. Only cases matching the case type being audited are
   * included in the sample list.
   *
   * @param key the audit plan id and the selection query or external service
   * id used to generate the case sample.
   *
   * @return The list of cases returned from the selection query or
   * external service
   *
   * @throws AppException
   * @throws InformationalException
   */
  // END, CR00264606
  @Override
  public CaseAndCaseAuditList generateManuallySelectedCaseSample(
    final CaseSampleKey key) throws AppException, InformationalException {

    final CaseAndCaseAuditList caseAndCaseAuditList = new CaseAndCaseAuditList();
    final curam.core.facade.intf.CaseAudit caseAuditObj = curam.core.facade.fact.CaseAuditFactory.newInstance();

    final AuditPlanKey auditPlanKey = new AuditPlanKey();

    auditPlanKey.auditPlanID = key.auditPlanID;
    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    caseAndCaseAuditList.caseAuditDtlsList.assign(
      caseAuditObj.listAllCaseAuditsForAuditPlan(auditPlanKey));

    if (key.externalCaseAuditDataID != 0) {

      final ExternalCaseAuditData externalCaseAuditData = externalCaseAuditDataDAO.get(
        key.externalCaseAuditDataID);

      final List<ExternalCaseAuditDataItem> externalCaseAuditDataItems = externalCaseAuditData.getExternalCaseAuditDataItemsByType(
        CASETYPECODEEntry.get(auditCaseConfig.getCaseType().getCode()),
        auditCaseConfig.getCaseCategory());

      for (final ExternalCaseAuditDataItem externalCaseAuditDataItem : externalCaseAuditDataItems) {

        final CaseHeader caseHeader = externalCaseAuditDataItem.getCase();

        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = caseHeader.getID();

        final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

        resultDetails.caseID = caseHeader.getID();
        resultDetails.caseReference = caseHeader.getCaseReference();
        resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
        resultDetails.startDate = caseHeader.getStartDate();
        resultDetails.statusCode = caseHeader.getStatus().getCode();

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

        concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
        resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

        caseAndCaseAuditList.caseDtlsList.listDtls.searchDtls.addRef(
          resultDetails);

      }
    } else if (key.selectionQueryID != 0) {

      final CaseAuditQueryManagement caseAuditQueryManagement = new CaseAuditQueryManagement();
      final SelectionQuery selectionQuery = selectionQueryDAO.get(
        key.selectionQueryID);

      if (selectionQuery.getType().getCode().equals(
        SELECTIONQUERYTYPEEntry.FIXED.getCode())) {

        final List<CaseHeader> caseList = caseAuditQueryManagement.runFixedQueryCaseSearch(
          key.selectionQueryID);

        // BEGIN, CR00264606, GD
        // Filter the case list so only cases matching that are of the case type
        // being audited are included.
        final List<CaseHeader> filteredCaseList = filterCaseListByAuditPlan(
          caseList, auditPlan);

        for (final CaseHeader caseHeader : filteredCaseList) {
          // END, CR00264606

          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = caseHeader.getID();

          final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

          resultDetails.caseID = caseHeader.getID();
          resultDetails.caseReference = caseHeader.getCaseReference();
          resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
          resultDetails.startDate = caseHeader.getStartDate();
          resultDetails.statusCode = caseHeader.getStatus().getCode();

          final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
          final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

          concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
          resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

          caseAndCaseAuditList.caseDtlsList.listDtls.searchDtls.addRef(
            resultDetails);
        }
      }
    }

    // BEGIN, CR00290965, IBM
    collectInformationalMsgs(
      caseAndCaseAuditList.caseAuditDtlsList.informationalMsgDtlsList);
    // END, CR00290965

    return caseAndCaseAuditList;
  }

  // ___________________________________________________________________________
  /**
   * Method to create case audit records for the selected cases.
   *
   * @param key The audit plan identifier and the list of selected cases
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void manuallySelectCasesForAudit(final AuditPlanAndSelectedCases key)
    throws AppException, InformationalException {

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    // In the case of regeneration, remove selection criteria
    auditPlanObj.clearSelectionCriteria();

    String tabList = new String();

    tabList = key.caseIDList;

    // String list of Case IDs
    final StringList caseIDList = StringUtil.tabText2StringList(tabList);

    for (int i = 0; i < caseIDList.size(); i++) {

      final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.newInstance();

      final curam.piwrapper.caseheader.impl.CaseHeader caseHeaderObj = caseHeaderDAO.get(
        Long.parseLong(caseIDList.item(i)));

      caseAuditObj.setCase(caseHeaderObj);
      caseAuditObj.setAuditPlan(auditPlanObj);
      caseAuditObj.insert();
    }

    auditPlanObj.setCasesUserSelected(true);
    auditPlanObj.setNumberCases(CuramConst.gkZero);
    auditPlanObj.setPercentageCases(CuramConst.gkDoubleZero);
    auditPlanObj.modify(auditPlanObj.getVersionNo());
  }

  // BEGIN, CR00290965, IBM
  /**
   * Generates the sample list of integrated cases for audit based on the
   * supplied search criteria. The user can select cases from the resulting
   * list to be included in the audit plan.
   *
   * @param key The search criteria.
   *
   * @return The list of integrated cases for audit based on the
   * supplied search criteria.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#generateManualICCaseSampleList(CaseSampleKey)}
   *
   * This method is deprecated as informational messages are not returned.
   * This method is replaced by generateManualICCaseSampleList(CaseSampleKey)
   * which returns the informational message along with manual integrated case
   * sample details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 generateManualICCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    // END, CR00290965
    final CaseSearchList1 caseSearchList1 = new CaseSearchList1();

    if (key.icDtls.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.icDtls.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.icDtls.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.icDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    key.icDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    key.icDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<curam.piwrapper.caseheader.impl.CaseHeader> caseList = caseHeaderDAO.searchCommonICCriteria(
      key.icDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

      resultDetails.caseID = caseHeader.getID();
      resultDetails.caseReference = caseHeader.getCaseReference();
      resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.startDate = caseHeader.getStartDate();
      resultDetails.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchList1.listDtls.searchDtls.addRef(resultDetails);
    }

    return caseSearchList1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Generates the sample list of investigation cases for audit based on the
   * supplied search criteria. The user can select cases from the resulting
   * list to be included in the audit plan.
   *
   * @param key The search criteria.
   *
   * @return The list of investigation cases for audit based on the
   * supplied search criteria.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#generateManualInvestigationCaseSampleList(CaseSampleKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * searchOrSelectLPDCaseSampleList(SearchOrSelectCasesKey)
   * which returns the informational message along with investigation case
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 generateManualInvestigationCaseSample(
    final CaseSampleKey key) throws AppException, InformationalException {

    // END, CR00290965

    final CaseSearchList1 caseSearchList1 = new CaseSearchList1();

    if (key.investigationCaseDtls.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.investigationCaseDtls.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.investigationCaseDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    key.investigationCaseDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    key.investigationCaseDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<curam.piwrapper.caseheader.impl.CaseHeader> caseList = caseHeaderDAO.searchCommonInvestigationCaseCriteria(
      key.investigationCaseDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

      resultDetails.caseID = caseHeader.getID();
      resultDetails.caseReference = caseHeader.getCaseReference();
      resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.startDate = caseHeader.getStartDate();
      resultDetails.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchList1.listDtls.searchDtls.addRef(resultDetails);
    }

    return caseSearchList1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Generates the sample list of liability product delivery cases for audit
   * based on the supplied search criteria. The user select cases from the
   * resulting list to be included in the audit plan.
   *
   * @param key The search criteria.
   *
   * @return The list of liability product delivery cases for audit based on the
   * supplied search criteria.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#generateManualLPDCaseSampleList(CaseSampleKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by generateManualLPDCaseSampleList(CaseSampleKey)
   * which returns the informational message along with product delivery case
   * sample details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 generateManualLPDCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    // END, CR00290965

    final CaseSearchList1 caseSearchList1 = new CaseSearchList1();

    if (key.lpdDtls.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.lpdDtls.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.lpdDtls.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.lpdDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    key.lpdDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    key.lpdDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<curam.piwrapper.caseheader.impl.CaseHeader> caseList = caseHeaderDAO.searchCommonLPDCriteria(
      key.lpdDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

      resultDetails.caseID = caseHeader.getID();
      resultDetails.caseReference = caseHeader.getCaseReference();
      resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.startDate = caseHeader.getStartDate();
      resultDetails.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchList1.listDtls.searchDtls.addRef(resultDetails);
    }

    return caseSearchList1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Generates the sample list of product delivery cases for audit based on the
   * supplied search criteria. The user can select cases from the resulting list
   * to be included in the audit plan.
   *
   * @param key The search criteria.
   *
   * @return The list of product delivery cases for audit based on the
   * supplied search criteria.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#generateManualPDCaseSampleList(CaseSampleKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by generateManualPDCaseSampleList(CaseSampleKey)
   * which returns the informational message along with product delivery case
   * sample details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 generateManualPDCaseSample(final CaseSampleKey key)
    throws AppException, InformationalException {

    // END, CR00290965

    final CaseSearchList1 caseSearchList1 = new CaseSearchList1();

    if (key.pdDtls.filterOptionList.length() > 0) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.pdDtls.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        final String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.pdDtls.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.pdDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    key.pdDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    key.pdDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<curam.piwrapper.caseheader.impl.CaseHeader> caseList = caseHeaderDAO.searchCommonPDCriteria(
      key.pdDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

      resultDetails.caseID = caseHeader.getID();
      resultDetails.caseReference = caseHeader.getCaseReference();
      resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.startDate = caseHeader.getStartDate();
      resultDetails.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchList1.listDtls.searchDtls.addRef(resultDetails);
    }

    return caseSearchList1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Method to determine if the user is searching for integrated cases to audit
   * or adding integrated cases to the audit plan.
   *
   * @param key The search criteria, a list of selected cases and an action
   * identifier.
   *
   * @return The list of integrated cases matching the supplied search criteria,
   * if the action was a search.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#searchOrSelectICCaseSampleList(SearchOrSelectCasesKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * searchOrSelectICCaseSampleList(SearchOrSelectCasesKey)
   * which returns the informational message along with manual integrated case
   * sample details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 searchOrSelectICCaseSample(
    final SearchOrSelectCasesKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    CaseSearchList1 caseSearchList = new CaseSearchList1();

    if (key.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = key.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = key.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (key.actionIDProperty.equals(ClientActionConst.kSearchActionID)) {

      caseSearchList = generateManualICCaseSample(key.dtls);
    }

    return caseSearchList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Method to determine if the user is searching for investigation cases to
   * audit or adding investigation cases to the audit plan.
   *
   * @param key The search criteria, a list of selected cases and an action
   * identifier.
   *
   * @return The list of investigation cases matching the supplied search
   * criteria, if the action was a search.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#searchOrSelectInvestigationCaseSampleList(SearchOrSelectCasesKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * searchOrSelectInvestigationCaseSampleList(SearchOrSelectCasesKey)
   * which returns the informational message along with investigation case
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 searchOrSelectInvestigationCaseSample(
    final SearchOrSelectCasesKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    CaseSearchList1 caseSearchList = new CaseSearchList1();

    if (key.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = key.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = key.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (key.actionIDProperty.equals(ClientActionConst.kSearchActionID)) {

      caseSearchList = generateManualInvestigationCaseSample(key.dtls);
    }

    return caseSearchList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Method to determine if the user is searching for liability product delivery
   * cases to audit or adding liability product delivery cases to the
   * audit plan.
   *
   * @param key The search criteria, a list of selected cases and an action
   * identifier.
   *
   * @return The list of liability product delivery cases matching the supplied
   * search criteria, if the action was a search.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#searchOrSelectLPDCaseSampleList(SearchOrSelectCasesKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * searchOrSelectLPDCaseSampleList(SearchOrSelectCasesKey)
   * which returns the informational message along with product delivery case
   * sample details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 searchOrSelectLPDCaseSample(
    final SearchOrSelectCasesKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    CaseSearchList1 caseSearchList = new CaseSearchList1();

    if (key.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = key.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = key.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (key.actionIDProperty.equals(ClientActionConst.kSearchActionID)) {

      caseSearchList = generateManualLPDCaseSample(key.dtls);
    }

    return caseSearchList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Method to determine if the user is searching for product delivery cases to
   * audit or adding product delivery cases to the audit plan.
   *
   * @param key The search criteria, a list of selected cases and an action
   * identifier.
   *
   * @return The list of product delivery cases matching the supplied
   * search criteria, if the action was a search.
   *
   * @throws AppException
   *
   * @throws InformationalException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditCaseSample#searchOrSelectPDCaseSampleList(SearchOrSelectCasesKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * searchOrSelectPDCaseSampleList(SearchOrSelectCasesKey)
   * which returns the informational message along with product delivery case
   * sample details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 searchOrSelectPDCaseSample(
    final SearchOrSelectCasesKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    CaseSearchList1 caseSearchList = new CaseSearchList1();

    if (key.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = key.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = key.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (key.actionIDProperty.equals(ClientActionConst.kSearchActionID)) {

      caseSearchList = generateManualPDCaseSample(key.dtls);
    }

    return caseSearchList;
  }

  // ___________________________________________________________________________
  /**
   * Method to inform the user if they need to specify algorithm parameters.
   * If they have chosen to audit the entire case load, there is no need to
   * enter algorithm parameters.
   *
   * @param key The total case load and the amount selected for audit.
   *
   * @return An informational message informing the user if they are required
   * to enter algorithm parameters.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public InformationalMsgDtlsList determineFullCaseLoad(
    final CaseLoadDetails key) throws AppException, InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    final curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00238338, PF
    if (key.percentageOfCases == CuramConst.gkOneHundredPercent
      || key.numberOfCases == key.totalCases) {
      // END, CR00238338
      final AppException algorithmParamsNotRequired = new AppException(
        curam.message.FACADEAUDITCASESAMPLE.INF_NO_ALGORITHM_PARAMETERS_REQUIRED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        algorithmParamsNotRequired, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // obtain the informational(s) to be returned to the client
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; ++i) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
    }

    return informationalMsgDtlsList;
  }

  // BEGIN, CR00264606, GD
  // ___________________________________________________________________________
  /**
   * Filters a case header list so only cases matching that are of the case type
   * being audited are returned.
   *
   * @param caseList
   * List of case header records
   * @param auditPlan
   * Audit Plan that the case header list is being filtered against
   *
   * @return list of filtered case header records which match the case type of
   * the audit play.
   */
  protected List<CaseHeader> filterCaseListByAuditPlan(
    final List<CaseHeader> caseList, final AuditPlan auditPlan) {

    final List<CaseHeader> filteredCaseList = new ArrayList<CaseHeader>();
    final String auditCaseTypeCode = auditPlan.getAuditCaseConfig().getCaseType().getCode();
    final String auditCaseCategoryCode = auditPlan.getAuditCaseConfig().getCaseCategory().getCode();

    for (final CaseHeader caseHeader : caseList) {

      if (caseHeader.getCaseType().getCode().equals(auditCaseTypeCode)
        && caseHeader.getIntegratedCaseType().getCode().equals(
          auditCaseCategoryCode)) {
        filteredCaseList.add(caseHeader);
      }
    }

    return filteredCaseList;
  }

  // END, CR00264606

  // BEGIN, CR00290965, IBM
  /**
   * Generates the sample list of integrated cases for audit based on the
   * supplied search criteria. The user can select cases from the resulting
   * list to be included in the audit plan.
   *
   * @param caseSampleKey contains case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList generateManualICCaseSampleList(
    final CaseSampleKey caseSampleKey) throws AppException,
      InformationalException {

    final CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    if (0 < caseSampleKey.icDtls.filterOptionList.length()) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        caseSampleKey.icDtls.filterOptionList);

      for (final String filterCode : filterOptionList.items()) {

        if (CASESEARCHFILTER.APPEALS.equals(filterCode)) {
          caseSampleKey.icDtls.searchWithAppeals = true;
          continue;
        }
        if (CASESEARCHFILTER.ISSUES.equals(filterCode)) {
          caseSampleKey.icDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(caseSampleKey.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    caseSampleKey.icDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    caseSampleKey.icDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<CaseHeader> caseList = caseHeaderDAO.searchCommonICCriteria(
      caseSampleKey.icDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final CaseSearchDetails1 caseSearchDetails1 = new CaseSearchDetails1();

      caseSearchDetails1.caseID = caseHeader.getID();
      caseSearchDetails1.caseReference = caseHeader.getCaseReference();
      caseSearchDetails1.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.startDate = caseHeader.getStartDate();
      caseSearchDetails1.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchDetailsList.listDtls.searchDtls.addRef(caseSearchDetails1);
    }

    collectInformationalMsgs(caseSearchDetailsList.informationalMsgDtls);

    return caseSearchDetailsList;
  }

  /**
   * Determine if the user is searching for IC cases to audit or adding IC
   * cases to the audit plan.
   *
   * @param searchOrSelectCasesKey contains search case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList searchOrSelectICCaseSampleList(
    final SearchOrSelectCasesKey searchOrSelectCasesKey) throws AppException,
      InformationalException {

    CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();
    // BEGIN, CR00300253, MC
    final CommonICSearchCriteria commonICSearchCriteria = new CommonICSearchCriteria();

    commonICSearchCriteria.assign(searchOrSelectCasesKey.dtls.icDtls);

    validateICSearchCriteria(commonICSearchCriteria);
    // END, CR00300253

    if (ClientActionConst.kSelectActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = searchOrSelectCasesKey.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = searchOrSelectCasesKey.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (ClientActionConst.kSearchActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      caseSearchDetailsList = generateManualICCaseSampleList(
        searchOrSelectCasesKey.dtls);
    }

    return caseSearchDetailsList;
  }

  /**
   * Generates the sample list of liability product delivery cases for audit
   * based on the supplied search criteria. The user select cases from the
   * resulting list to be included in the audit plan.
   *
   * @param caseSampleKey contains case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList generateManualLPDCaseSampleList(
    final CaseSampleKey caseSampleKey) throws AppException,
      InformationalException {

    final CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    if (0 < caseSampleKey.lpdDtls.filterOptionList.length()) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        caseSampleKey.lpdDtls.filterOptionList);

      for (final String filterCode : filterOptionList.items()) {

        if (CASESEARCHFILTER.APPEALS.equals(filterCode)) {
          caseSampleKey.lpdDtls.searchWithAppeals = true;
          continue;
        }
        if (CASESEARCHFILTER.ISSUES.equals(filterCode)) {
          caseSampleKey.lpdDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(caseSampleKey.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    caseSampleKey.lpdDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    caseSampleKey.lpdDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<CaseHeader> caseList = caseHeaderDAO.searchCommonLPDCriteria(
      caseSampleKey.lpdDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final CaseSearchDetails1 caseSearchDetails1 = new curam.core.struct.CaseSearchDetails1();

      caseSearchDetails1.caseID = caseHeader.getID();
      caseSearchDetails1.caseReference = caseHeader.getCaseReference();
      caseSearchDetails1.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.startDate = caseHeader.getStartDate();
      caseSearchDetails1.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchDetailsList.listDtls.searchDtls.addRef(caseSearchDetails1);
    }

    collectInformationalMsgs(caseSearchDetailsList.informationalMsgDtls);

    return caseSearchDetailsList;
  }

  /**
   * Generates the sample list of product delivery cases for audit based on the
   * supplied search criteria. The user can select cases from the resulting list
   * to be included in the audit plan.
   *
   * @param caseSampleKey contains case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList generateManualPDCaseSampleList(
    final CaseSampleKey caseSampleKey) throws AppException,
      InformationalException {

    final CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    if (0 < caseSampleKey.pdDtls.filterOptionList.length()) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        caseSampleKey.pdDtls.filterOptionList);

      for (final String filterCode : filterOptionList.items()) {

        if (CASESEARCHFILTER.APPEALS.equals(filterCode)) {
          caseSampleKey.pdDtls.searchWithAppeals = true;
          continue;
        }
        if (CASESEARCHFILTER.ISSUES.equals(filterCode)) {
          caseSampleKey.pdDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(caseSampleKey.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    caseSampleKey.pdDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    caseSampleKey.pdDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<CaseHeader> caseList = caseHeaderDAO.searchCommonPDCriteria(
      caseSampleKey.pdDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final CaseSearchDetails1 caseSearchDetails1 = new CaseSearchDetails1();

      caseSearchDetails1.caseID = caseHeader.getID();
      caseSearchDetails1.caseReference = caseHeader.getCaseReference();
      caseSearchDetails1.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.startDate = caseHeader.getStartDate();
      caseSearchDetails1.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchDetailsList.listDtls.searchDtls.addRef(caseSearchDetails1);
    }

    collectInformationalMsgs(caseSearchDetailsList.informationalMsgDtls);

    return caseSearchDetailsList;
  }

  /**
   * Determine if the user is searching for liability product delivery
   * cases to audit or adding liability product delivery cases to the
   * audit plan.
   *
   * @param searchOrSelectCasesKey contains search case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList searchOrSelectLPDCaseSampleList(
    final SearchOrSelectCasesKey searchOrSelectCasesKey) throws AppException,
      InformationalException {

    CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    // BEGIN, CR00300253, MC
    final CommonICSearchCriteria commonICSearchCriteria = new CommonICSearchCriteria();

    commonICSearchCriteria.assign(searchOrSelectCasesKey.dtls.icDtls);

    validateICSearchCriteria(commonICSearchCriteria);
    // END, CR00300253

    if (ClientActionConst.kSelectActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = searchOrSelectCasesKey.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = searchOrSelectCasesKey.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (ClientActionConst.kSearchActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      caseSearchDetailsList = generateManualLPDCaseSampleList(
        searchOrSelectCasesKey.dtls);
    }

    return caseSearchDetailsList;
  }

  /**
   * Determine if the user is searching for product delivery cases to audit or
   * adding product delivery cases to the audit plan.
   *
   * @param searchOrSelectCasesKey contains search case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList searchOrSelectPDCaseSampleList(
    final SearchOrSelectCasesKey searchOrSelectCasesKey) throws AppException,
      InformationalException {

    CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    // BEGIN, CR00300253, MC
    final CommonICSearchCriteria commonICSearchCriteria = new CommonICSearchCriteria();

    commonICSearchCriteria.assign(searchOrSelectCasesKey.dtls.icDtls);

    validateICSearchCriteria(commonICSearchCriteria);
    // END, CR00300253

    if (ClientActionConst.kSelectActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = searchOrSelectCasesKey.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = searchOrSelectCasesKey.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (ClientActionConst.kSearchActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      caseSearchDetailsList = generateManualPDCaseSampleList(
        searchOrSelectCasesKey.dtls);
    }

    return caseSearchDetailsList;
  }

  /**
   * Generates the sample list of investigation cases for audit based on the
   * supplied search criteria. The user can select cases from the resulting
   * list to be included in the audit plan.
   *
   * @param caseSampleKey contains case sample key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList generateManualInvestigationCaseSampleList(
    final CaseSampleKey caseSampleKey) throws AppException,
      InformationalException {

    final CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    if (0 < caseSampleKey.investigationCaseDtls.filterOptionList.length()) {

      final StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        caseSampleKey.investigationCaseDtls.filterOptionList);

      for (final String filterCode : filterOptionList.items()) {

        if (CASESEARCHFILTER.ISSUES.equals(filterCode)) {
          caseSampleKey.investigationCaseDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    final AuditPlan auditPlan = auditPlanDAO.get(caseSampleKey.auditPlanID);
    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    caseSampleKey.investigationCaseDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    caseSampleKey.investigationCaseDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    final List<CaseHeader> caseList = caseHeaderDAO.searchCommonInvestigationCaseCriteria(
      caseSampleKey.investigationCaseDtls);

    for (final CaseHeader caseHeader : caseList) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseHeader.getID();

      final CaseSearchDetails1 caseSearchDetails1 = new CaseSearchDetails1();

      caseSearchDetails1.caseID = caseHeader.getID();
      caseSearchDetails1.caseReference = caseHeader.getCaseReference();
      caseSearchDetails1.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.startDate = caseHeader.getStartDate();
      caseSearchDetails1.statusCode = caseHeader.getStatus().getCode();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      caseSearchDetails1.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      caseSearchDetailsList.listDtls.searchDtls.addRef(caseSearchDetails1);
    }

    collectInformationalMsgs(caseSearchDetailsList.informationalMsgDtls);

    return caseSearchDetailsList;
  }

  /**
   * Determine if the user is searching for investigation cases to audit or
   * adding investigation cases to the audit plan.
   *
   * @param searchOrSelectCasesKey contains case key
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList searchOrSelectInvestigationCaseSampleList(
    final SearchOrSelectCasesKey searchOrSelectCasesKey) throws AppException,
      InformationalException {

    CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    // BEGIN, CR00300253, MC
    final CommonICSearchCriteria commonICSearchCriteria = new CommonICSearchCriteria();

    commonICSearchCriteria.assign(searchOrSelectCasesKey.dtls.icDtls);

    validateICSearchCriteria(commonICSearchCriteria);
    // END, CR00300253

    if (ClientActionConst.kSelectActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      final AuditPlanAndSelectedCases auditPlanAndSelectedCases = new AuditPlanAndSelectedCases();

      auditPlanAndSelectedCases.auditPlanID = searchOrSelectCasesKey.dtls.auditPlanID;
      auditPlanAndSelectedCases.caseIDList = searchOrSelectCasesKey.caseIDList;
      manuallySelectCasesForAudit(auditPlanAndSelectedCases);

    } else if (ClientActionConst.kSearchActionID.equals(
      searchOrSelectCasesKey.actionIDProperty)) {

      caseSearchDetailsList = generateManualInvestigationCaseSampleList(
        searchOrSelectCasesKey.dtls);
    }

    return caseSearchDetailsList;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList msgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00290965
}
