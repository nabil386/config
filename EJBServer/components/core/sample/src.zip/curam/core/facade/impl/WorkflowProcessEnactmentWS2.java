/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012,2017. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.UnimplementedException;
import curam.util.workflow.impl.EnactmentService;
import org.w3c.dom.Document;

/**
 * Message Style document oriented web service that allows the
 * enactment of workflow processes via web services.
 */
public abstract class WorkflowProcessEnactmentWS2 extends
  curam.core.facade.base.WorkflowProcessEnactmentWS2 {

  // ___________________________________________________________________________
  /**
   * Starts a new process instance based on data passed from web service.
   * 
   * @param xmlMessage The request message.
   * 
   * @return the response message.
   */
  @Override
  public Document startProcess(final Document xmlMessage)
    throws AppException, InformationalException {

    return EnactmentService.startProcess(xmlMessage);
  }

  // ___________________________________________________________________________
  /**
   * A place holder method so that the correct operations are generated into
   * the WSDL. This WSDL operation is intended to be implemented by the calling
   * BPEL process.
   * 
   * @param xmlMessage The request message.
   * 
   * @return the response message.
   */
  @Override
  public Document processCompleted(final Document xmlMessage)
    throws AppException, InformationalException {

    throw new UnimplementedException();
  }
}
