/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.TASKCHANGETYPE;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.TaskUserNameStatusAndRestartDateTimeKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.BatchProcessingDate;
import curam.message.BPORESTARTTASK;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.type.DateTime;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.fact.TaskHistoryAdminFactory;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.intf.TaskHistoryAdmin;
import curam.util.workflow.struct.TaskOptimisticLockingDetails;
import curam.util.workflow.struct.TaskRestartTimeDetails;


/**
 * Standard implementation of {@link curam.core.facade.intf.RestartTask}.
 */
public abstract class RestartTask extends curam.core.facade.base.RestartTask {

  protected static int stExpiryDaysForReport = 0;

  protected static int stTotalRecords = 0;

  protected static int stCommitCounter = 0;

  protected static boolean stFileOpen = false;

  // the batch log output stream
  protected static java.io.PrintStream stOutstream;

  protected static final int kProcessCommitCount;

  protected static final boolean kCommitCountEnabled;

  protected static String systemUserName;

  protected static String systemUserFullName;

  // ___________________________________________________________________________
  /**
   * Static initialization which looks up the commit count status from
   * the environment and sets the static members used to control the processing
   */
  static {

    // Get the value of the Commit Count Enabled environment variable
    String commitCountEnabled = curam.util.resources.Configuration.getProperty(
      curam.core.impl.EnvVars.ENV_RESTARTTASK_COMMITCOUNTENABLED);

    // If it's not set, use the default
    if (commitCountEnabled == null) {
      commitCountEnabled = curam.core.impl.EnvVars.ENV_RESTARTTASK_COMMITCOUNTENABLED_DEFAULT;
    }

    // If commit count processing is on, look up the commit count value
    // i.e. the number of records to be processed before the results are
    // committed to the database.
    if (commitCountEnabled.equals(curam.core.impl.EnvVars.ENV_VALUE_YES)) {

      kCommitCountEnabled = true;

      // Get the value of the Commit Count environment variable
      final String commitCount = curam.util.resources.Configuration.getProperty(
        curam.core.impl.EnvVars.ENV_RESTARTTASK_COMMITCOUNT);

      // If it's not set, use the default
      if (commitCount == null) {

        kProcessCommitCount = curam.core.impl.EnvVars.ENV_RESTARTTASK_COMMITCOUNT_DEFAULT;

      } else {

        // Convert string value to integer
        kProcessCommitCount = Integer.parseInt(commitCount);

      }
    } else {

      // Otherwise commit count processing is off
      kCommitCountEnabled = false;
      kProcessCommitCount = 0;
    }
  }

  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * <code>searchByStatusAndRstartDate()</code> nsmulti operation.
   */
  static class ProcessTasks extends curam.util.dataaccess.ReadmultiOperation {

    static protected TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    // task history object
    static protected TaskHistoryAdmin taskHistoryObj = TaskHistoryAdminFactory.newInstance();

    // variables to modify task details
    static protected TaskRestartTimeDetails taskRestartTimeDetails = new TaskRestartTimeDetails();

    // _________________________________________________________________________
    /**
     * This operation gets called for each record. It marks task as expired
     * and reassigns it to former assignee manager. If there are
     * any exceptions thrown during the processing they are written to the
     * batch log.
     *
     * @param objDtls A searchDueTaskDetails object containing details of
     * a due for restarting task.
     * @return true.
     */
    @Override
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      final curam.core.sl.entity.struct.TaskIDAndVersionNoDetails taskIDDetails = (curam.core.sl.entity.struct.TaskIDAndVersionNoDetails) objDtls;

      // Update the task status
      taskAdminObj.modifyStatus(taskIDDetails.taskID,
        curam.codetable.TASKSTATUS.NOTSTARTED, taskIDDetails.versionNo);

      // Update the task restart time
      TaskOptimisticLockingDetails taskOptimisticLockingDetails = new TaskOptimisticLockingDetails();

      taskOptimisticLockingDetails = taskAdminObj.readOptimisticLockingVersionNo(
        taskIDDetails.taskID);
      taskRestartTimeDetails.restartTime = curam.util.type.DateTime.kZeroDateTime;
      taskRestartTimeDetails.versionNo = taskOptimisticLockingDetails.versionNo;

      // modify task restart time
      taskAdminObj.modifyRestartTime(taskIDDetails.taskID,
        curam.util.type.DateTime.kZeroDateTime,
        taskOptimisticLockingDetails.versionNo);

      taskHistoryObj.create(taskIDDetails.taskID, DateTime.getCurrentDateTime(),
        TASKCHANGETYPE.RESTARTED, CuramConst.gkEmpty, CuramConst.gkEmpty,
        CuramConst.gkEmpty, systemUserName);

      // increasing counter and running totals
      if (kCommitCountEnabled) {

        stCommitCounter++;

      }

      stTotalRecords++;

      if (kCommitCountEnabled && stCommitCounter >= kProcessCommitCount) {

        return false;

      } else {

        return true;
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void restart(BatchProcessingDate processingDate)
    throws AppException, InformationalException {

    // system user entity object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // user maintenance business process object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // setup the batch output file name
    final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

    // system user Details
    curam.core.struct.SystemUserDtls systemUserDtls;

    // variables to read full system user name
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    curam.core.struct.UserFullname userFullName;

    // get system user name
    systemUserDtls = systemUserObj.getSystemUserDetails();
    systemUserName = systemUserDtls.userName;

    // assign user name key to read user full name
    usersKey.userName = systemUserName;

    // read user full name
    userFullName = userAccessObj.getFullName(usersKey);
    systemUserFullName = userFullName.fullname;

    curamBatchObj.outputFileID = // BEGIN, CR00163471, JC
      curam.message.BPORESTARTTASK.INF_BATCH_FILE_NAME.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163471, JC
    curamBatchObj.datFileExt = curam.core.impl.CuramConst.gkDataFileExt;
    curamBatchObj.setFileName();

    // open the batch output file
    try {
      stOutstream = new java.io.PrintStream(
        new java.io.FileOutputStream(curamBatchObj.outputFilename));

    } catch (final java.io.FileNotFoundException e) {

      throw new curam.util.exception.AppRuntimeException(e);

    }

    // check that the output file was opened correctly
    if (stOutstream.checkError()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPORESTARTTASK.ERR_RESTART_TASK_FILE_OPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    curamBatchObj.setStartTime(); // set start time for batch processing

    final ProcessTasks processTasks = new ProcessTasks();

    final TaskUserNameStatusAndRestartDateTimeKey taskStatusAndRestartDateTimeKey = new TaskUserNameStatusAndRestartDateTimeKey();

    // set key to search tasks by status and restart time
    taskStatusAndRestartDateTimeKey.status = curam.codetable.TASKSTATUS.DEFERRED;
    taskStatusAndRestartDateTimeKey.restartDateTime = curam.util.type.DateTime.getCurrentDateTime();

    do {

      stCommitCounter = 0;

      // BEGIN, CR00161962, KY
      // calling readmulti
      curam.core.sl.entity.fact.TaskAssignmentFactory.newInstance().searchTaskByStatusAndRestartTime(
        taskStatusAndRestartDateTimeKey, processTasks);
      // END, CR00161962

      curam.util.transaction.TransactionInfo.getInfo().commit();
      curam.util.transaction.TransactionInfo.getInfo().begin();

    } while (stCommitCounter > 0);

    curamBatchObj.setEndTime(); // set end time for batch processing

    final AppException msg = new AppException(
      BPORESTARTTASK.INF_TOTAL_RECORDS_PROCESSED);

    msg.arg(stTotalRecords);

    // BEGIN, CR00163236, CL
    // add informational to the batch process log
    stOutstream.print(msg.getMessage(ProgramLocale.getDefaultServerLocale()));
    // END, CR00163236

    // close the output stream.
    stOutstream.close();

    final int stringBufferZeroSize = 0;
    final int messageLength = 4096;
    final StringBuffer emailMessageString = new StringBuffer(messageLength);

    // reset string buffer to empty
    emailMessageString.setLength(stringBufferZeroSize);

    // BEGIN, CR00163236, CL
    emailMessageString.append(
      msg.getMessage(ProgramLocale.getDefaultServerLocale())
        + curam.core.impl.CuramConst.gkNewLine);
    // END, CR00163236

    curamBatchObj.emailMessage = emailMessageString.toString();

    // constructing the email subject
    curamBatchObj.setEmailSubject(
      curam.message.BPORESTARTTASK.INF_RESTART_TASK_SUBJECT);

    // sending the email
    curamBatchObj.sendEmail();
  }
}
