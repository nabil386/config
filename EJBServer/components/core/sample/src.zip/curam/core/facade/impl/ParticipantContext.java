/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.core.facade.struct.ContactContextDescriptionDetails;
import curam.core.facade.struct.ContactContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextDescriptionDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleContactKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameTypeAndAlternateID;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality to retrieve context
 * descriptions for a participant.
 *
 */
public abstract class ParticipantContext extends curam.core.facade.base.ParticipantContext {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.
   * getProgramLocale())}.
   * Constant for the separator used in the context description.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00023323
  // END, CR00222190
  // BEGIN, CR00098567, DJ
  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  // END, CR00098567
  // ___________________________________________________________________________
  /**
   * This method returns the concern role name and primary alternate ID,
   * separated by " - ", of a concern role as the participant context
   * description.
   *
   * @param key The concern role for which the description is retrieved
   *
   * @return The context description
   */
  @Override
  public ParticipantContextDescriptionDetails readContextDescription(
    ParticipantContextDescriptionKey key) throws AppException,
      InformationalException {

    // Concern Role object and key.
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    // Details returned from the concern role read.
    ConcernRoleNameTypeAndAlternateID concernRoleNameTypeAndAlternateID;

    // Details to be returned.
    final ParticipantContextDescriptionDetails participantContextDescriptionDetails = new ParticipantContextDescriptionDetails();

    // Get the concern role ID from the key.
    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read the concern role details.
    concernRoleNameTypeAndAlternateID = concernRoleObj.readConcernRoleNameTypeAndAlternateID(
      concernRoleKey);

    if (concernRoleNameTypeAndAlternateID.concernRoleType.equals(
      CONCERNROLETYPE.PROSPECTPERSON)) {
      // Set the context description for prospect.
      participantContextDescriptionDetails.description = concernRoleNameTypeAndAlternateID.concernRoleName;
    } else {

      if (concernRoleNameTypeAndAlternateID.primaryAlternateID.length() == 0) {

        // Set the context description without the primaryAlternateID.
        participantContextDescriptionDetails.description = concernRoleNameTypeAndAlternateID.concernRoleName;

      } else {

        // Set the context description.
        // BEGIN, CR00098567, DJ
        // Added kSpace
        // BEGIN, CR00222190, ELG
        participantContextDescriptionDetails.description = concernRoleNameTypeAndAlternateID.concernRoleName
          + kSpace
          + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
            TransactionInfo.getProgramLocale())
            + concernRoleNameTypeAndAlternateID.primaryAlternateID;
        // END, CR00222190
        // END, CR00098567
      }
    }

    // Return the details.
    return participantContextDescriptionDetails;

  }

  // ___________________________________________________________________________
  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param contactContextDescriptionKey The contact ID the context description
   * is returned for.
   *
   * @return The contact context description.
   */
  @Override
  public ContactContextDescriptionDetails readParticipantContactContextDescription(
    ContactContextDescriptionKey contactContextDescriptionKey)
    throws AppException, InformationalException {

    // Concern Role Contact Maintenance Object
    final curam.core.intf.ConcernRoleContact concernRoleContactObj = curam.core.fact.ConcernRoleContactFactory.newInstance();

    // Instance of Concern Role Contact Key
    final ConcernRoleContactKey concernRoleContactKey = new ConcernRoleContactKey();

    // Set the Contact ID
    concernRoleContactKey.contactID = contactContextDescriptionKey.contactID;

    // Read the Concern Role Contact Dtls
    final ConcernRoleContactDtls concernRoleContactDtls = concernRoleContactObj.read(
      concernRoleContactKey);

    // Concern Role Maintenance Object
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Instance of Concern Role Key
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set the Concern Role ID
    concernRoleKey.concernRoleID = concernRoleContactDtls.concernRoleID;

    // Read the Concern Role Dtls
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // The Object to be returned
    final ContactContextDescriptionDetails contactContextDescriptionDetails = new ContactContextDescriptionDetails();

    // Concatenate the String
    final StringBuffer buffer = new StringBuffer(concernRoleContactDtls.name);

    // BEGIN, CR00098942, SAI
    buffer.append(kSpace);
    // END, CR00098942
    // BEGIN, CR00222190, ELG
    buffer.append(
      SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
        TransactionInfo.getProgramLocale()));
    // END, CR00222190
    buffer.append(concernRoleDtls.concernRoleName);

    // Assign the String to the description
    contactContextDescriptionDetails.description = buffer.toString();

    // Return the Object
    return contactContextDescriptionDetails;
  }

}
