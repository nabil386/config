/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007, 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.codetable.SERVICETYPE;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.*;
import curam.core.fact.MaintainContractFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.MaintainContract;
import curam.core.sl.fact.ParticipantSearchRouterFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.ParticipantSearchRouter;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ContractConcernKey;
import curam.core.struct.ContractDetailsKey;
import curam.core.struct.ContractDtls;
import curam.core.struct.ContractIDKey;
import curam.core.struct.ContractKey;
import curam.core.struct.ContractServiceIDLinkTab;
import curam.core.struct.ContractServicesKey;
import curam.core.struct.GetOrderProduct;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ProductKeyStruct;
import curam.core.struct.ReadProductResult1;
import curam.core.struct.ReadSupplierReturnKey;
import curam.core.struct.ReadSupplierReturnLineItemKey;
import curam.core.struct.ServiceLinkKey;
import curam.core.struct.ServiceLinkRMDtlsList;
import curam.core.struct.ServiceSupplierDetails;
import curam.core.struct.ServiceSupplierHomePageReadResult;
import curam.core.struct.ServiceSupplierLinkAndStatusCodeRMKey;
import curam.core.struct.ServiceSupplierLinkDtls;
import curam.core.struct.ServiceSupplierLinkKey;
import curam.core.struct.ServicesDetailStructList;
import curam.core.struct.SupplierReturnHeaderDetails;
import curam.core.struct.SupplierReturnHeaderDtls;
import curam.core.struct.SupplierReturnHeaderKey;
import curam.core.struct.SupplierReturnLineItemDetails;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This process class provides the functionality for the Service Supplier
 * presentation layer.
 */
public abstract class ServiceSupplier extends curam.core.facade.base.ServiceSupplier {

  protected static final int kStringBufSize = 512;

  // BEGIN, CR00234280 , DJ
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  @Deprecated
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  /**
   * Constant for the minimum length of a Phone Number.
   */
  protected static final int kMinimumPhoneNumberLength = 3;

  protected static final String kCommaSpace = CuramConst.gkComma
    + CuramConst.gkSpace;

  // END, CR00234280
  // ___________________________________________________________________________
  /**
   * @param key The service supplier search details.
   *
   * @return details The service supplier details returned from the database.
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}.
   *
   * Searches for a service supplier record using specified search criteria.
   */
  @Override
  @Deprecated
  public SearchServiceSupplierDetails search(SearchServiceSupplierKey key)
    throws AppException, InformationalException {

    // Service Supplier search object
    final curam.core.intf.ServiceSupplierSearchRouter serviceSupplierSearchRouterObj = curam.core.fact.ServiceSupplierSearchRouterFactory.newInstance();

    // Details to be returned
    final SearchServiceSupplierDetails searchServiceSupplierDetails = new SearchServiceSupplierDetails();

    // Search for Service Supplier
    searchServiceSupplierDetails.serviceSupplierSearchResult = serviceSupplierSearchRouterObj.search(
      key.serviceSupplierSearchKey);

    // Return details
    return searchServiceSupplierDetails;
  }

  // ___________________________________________________________________________
  /**
   * Searches for a service supplier record using alternate reference number.
   *
   * @param key The service supplier alternate ID.
   *
   * @return details The service supplier details returned from the database.
   *
   * @deprecated Since Curam 6.0.
   */
  @Override
  @Deprecated
  public ReadServiceSupplierByRefNumDetails readByReferenceNumber(
    ReadServiceSupplierByRefNumKey key) throws AppException,
      InformationalException {

    // Service Supplier search object and key
    final curam.core.intf.ServiceSupplierSearchRouter serviceSupplierSearchRouterObj = curam.core.fact.ServiceSupplierSearchRouterFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierByRefNumDetails readServiceSupplierByRefNumDetails = new ReadServiceSupplierByRefNumDetails();

    // Search for Service Supplier
    readServiceSupplierByRefNumDetails.servSupplierReadDtls = serviceSupplierSearchRouterObj.readByReferenceNumber(
      key.alternateIDSearchKey);

    // Return details
    return readServiceSupplierByRefNumDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancel a service for a service supplier.
   *
   * @param key The ID of the service supplier being canceled.
   */
  @Override
  public void cancelServiceSupplierService(CancelServiceSupplierServiceKey key)
    throws AppException, InformationalException {

    // Service supplier maintenance object
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();

    // Cancel the service
    maintainServiceSupplierLinkObj.cancelServiceLink(key.cancelServiceLinkKey);
  }

  // ___________________________________________________________________________
  /**
   * Modify the details of a service for a service-supplier.
   *
   * @param details The service supplier details being modified.
   */
  @Override
  public void modifyServiceSupplierService(
    MaintainServiceSupplierServiceDetails details) throws AppException,
      InformationalException {

    // Service supplier maintenance object and key
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();
    final ServiceLinkKey serviceLinkKey = new ServiceLinkKey();

    // Get the service supplier link ID from key
    serviceLinkKey.serviceSupplierLinkID = details.serviceLink.serviceSupplierLinkID;

    // Modify the service details
    maintainServiceSupplierLinkObj.modifyServiceLink(serviceLinkKey,
      details.serviceLink);
  }

  // ___________________________________________________________________________
  /**
   * Read the details of a service for a service-supplier.
   *
   * @param key The service supplier service ID.
   *
   * @return details The service details returned from the database.
   */
  @Override
  public ReadServiceSupplierServiceDetails readServiceSupplierService(
    ReadServiceSupplierServiceKey key) throws AppException,
      InformationalException {

    // Service supplier maintenance object
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();

    // Service-supplier-Link object
    final curam.core.intf.ServiceSupplierLink serviceSupplierLinkObj = curam.core.fact.ServiceSupplierLinkFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierServiceDetails readServiceSupplierServiceDetails = new ReadServiceSupplierServiceDetails();

    // Context object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Key used to read service (-supplier-link) object
    final ServiceSupplierLinkKey serviceSupplierLinkKey = new ServiceSupplierLinkKey();

    // Build the ServiceSupplierLinkKey from the ID in the
    // ReadServiceSupplierServiceKey and use it to read the
    // service object.
    serviceSupplierLinkKey.serviceSupplierLinkID = key.serviceLinkKey.serviceSupplierLinkID;
    final ServiceSupplierLinkDtls serviceSupplierLinkDtls = serviceSupplierLinkObj.read(
      serviceSupplierLinkKey);

    // Build the ParticipantContextDescriptionKey using the data from the
    // above read.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = serviceSupplierLinkDtls.supplierConcernRoleID;

    // Read the service details
    readServiceSupplierServiceDetails.ServiceLinkReadDtls = maintainServiceSupplierLinkObj.readServiceLink(
      key.serviceLinkKey);

    // Read the context description
    readServiceSupplierServiceDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // BEGIN, CR00163098, JC
    // Retrieve the typeCode description
    readServiceSupplierServiceDetails.ServiceLinkReadDtls.serviceTypeCodeDescription = CodeTable.getOneItem(
      SERVICETYPE.TABLENAME,
      readServiceSupplierServiceDetails.ServiceLinkReadDtls.typeCode,
      TransactionInfo.getProgramLocale());
    // END, CR00163098, JC

    // Return details
    return readServiceSupplierServiceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieve a list of services for a service supplier.
   *
   * @param key The service supplier ID for which a list of services are
   * returned.
   *
   * @return details The list of service details returned from the database.
   */
  @Override
  public ReadServiceSupplierServiceList listServiceSupplierService(
    ReadServiceSupplierServiceListKey key) throws AppException,
      InformationalException {

    // Service supplier maintenance object
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierServiceList readServiceSupplierServiceList = new ReadServiceSupplierServiceList();

    // Context object and key
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read list of services
    readServiceSupplierServiceList.serviceLinkRMDtlsList = maintainServiceSupplierLinkObj.readAllSupplierServices(
      key.serviceLinkReadmultiKey);

    // Get concern role ID from key
    participantContextDescriptionKey.concernRoleID = key.serviceLinkReadmultiKey.supplierConcernRoleID;

    // Get the context description for the concern role
    readServiceSupplierServiceList.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readServiceSupplierServiceList;
  }

  // BEGIN, CR00219556, JF
  // ___________________________________________________________________________
  /**
   * Retrieve a list of services for a service supplier.
   *
   * @param key The service supplier ID for which a list of services are
   * returned.
   *
   * @return details The list of service details returned from the database.
   */
  @Override
  public ReadServiceSupplierServiceAndVersionNoList listServiceSupplierServiceAndVersionNo(
    ReadServiceSupplierServiceListKey key) throws AppException,
      InformationalException {

    // Service supplier maintenance object
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierServiceAndVersionNoList readServiceSupplierServiceAndVersionNoList = new ReadServiceSupplierServiceAndVersionNoList();

    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read list of services
    readServiceSupplierServiceAndVersionNoList.serviceLinkRMDtlsList = maintainServiceSupplierLinkObj.readAllSupplierServicesAndVersionNo(
      key.serviceLinkReadmultiKey);

    // Get concern role ID from key
    participantContextDescriptionKey.concernRoleID = key.serviceLinkReadmultiKey.supplierConcernRoleID;

    // Return details
    return readServiceSupplierServiceAndVersionNoList;
  }

  // END, CR00219556, JF

  // ___________________________________________________________________________
  /**
   * Create a new service for a service supplier.
   *
   * @param details The service supplier service details being entered.
   */
  @Override
  public void createServiceSupplierService(
    MaintainServiceSupplierServiceDetails details) throws AppException,
      InformationalException {

    // Service supplier maintenance object
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();

    // Create the service
    maintainServiceSupplierLinkObj.addServiceToSupplier(details.serviceLink);
  }

  // ___________________________________________________________________________
  /**
   * Retrieve a list of the services not currently supplied by a service
   * supplier to the SSA.
   *
   * @param key The service supplier concern role id.
   *
   * @return details The list of services not supplied.
   */
  @Override
  public ReadServiceSupplierServiceNotSuppliedList readServiceSupplierServiceNotSupplied(
    ReadServiceSupplierServiceNotSuppliedListKey key) throws AppException,
      InformationalException {

    // Service supplier maintenance object
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierServiceNotSuppliedList readServiceSupplierServiceNotSuppliedList = new ReadServiceSupplierServiceNotSuppliedList();

    // Context object and key
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read the list of services
    readServiceSupplierServiceNotSuppliedList.serviceNotSupplyRMDtlsList = maintainServiceSupplierLinkObj.readServiceNotSupplied(
      key.serviceLinkRMKey);

    // Get the concern role ID from key
    participantContextDescriptionKey.concernRoleID = key.serviceLinkRMKey.supplierConcernRoleID;

    // Get the context description for the concern role
    readServiceSupplierServiceNotSuppliedList.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readServiceSupplierServiceNotSuppliedList;
  }

  // ___________________________________________________________________________
  /**
   * Reads a Service Supplier home page details.
   *
   * @param key The service supplier ID.
   *
   * @return The service supplier home page details returned from the database.
   */
  @Override
  public ReadServiceSupplierHomePageDetails readHomePageDetails(
    ReadServiceSupplierHomeKey key) throws AppException,
      InformationalException {

    // Service Supplier Home Page object
    final curam.core.intf.ServiceSupplierHomePage serviceSupplierHomePageObj = curam.core.fact.ServiceSupplierHomePageFactory.newInstance();

    // Maintain Service Supplier object
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierHomePageDetails readServiceSupplierHomePageDetails = new ReadServiceSupplierHomePageDetails();

    // Struct returned from ServiceSupplierFurtherDetailsRead read
    ServiceSupplierDetails serviceSupplierDetails;

    // Struct returned from ServiceSupplierHomePage read
    ServiceSupplierHomePageReadResult serviceSupplierHomePageReadResult;

    // Key to read Service Supplier further details
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Perform Home Page read
    serviceSupplierHomePageReadResult = serviceSupplierHomePageObj.read(
      key.concernRoleHomePageKey);

    // Get the Concern Role ID from the Key
    maintainConcernRoleKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Perform Further Details read
    serviceSupplierDetails = maintainConcernRoleDetailsObj.readServiceSupplier(
      maintainConcernRoleKey);

    // Assign Details
    readServiceSupplierHomePageDetails.serviceSupplierHomeDetails.assign(
      serviceSupplierHomePageReadResult.servSuppHomePageDetails);
    readServiceSupplierHomePageDetails.informationalMsgDtlsList.assign(
      serviceSupplierHomePageReadResult.informationalMsgDtlsList);
    readServiceSupplierHomePageDetails.serviceSupplierHomeDetails.assign(
      serviceSupplierDetails);

    // Context object and key
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Populate context description key
    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Read the context description
    readServiceSupplierHomePageDetails.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readServiceSupplierHomePageDetails;
  }

  // BEGIN, CR00231961, ZV
  // ___________________________________________________________________________
  /**
   * Register a service supplier.
   *
   * @param details The register service supplier details
   *
   * @return details A list of informational messages.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #registerWithTextBankAccountSortCode()}.
   * See release note: CR00231961
   */
  @Override
  @Deprecated
  public ServiceSupplierRegistrationResult register(
    ServiceSupplierRegistrationDetails details) throws AppException,
      InformationalException {

    final ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails serviceSupplierRegistrationDetails = new ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails();

    serviceSupplierRegistrationDetails.servSuppRegistrationDetails.assign(
      details.servSuppRegistrationDetails);
    serviceSupplierRegistrationDetails.bankSortCode = details.servSuppRegistrationDetails.bankSortCode;

    return registerWithTextBankAccountSortCode(
      serviceSupplierRegistrationDetails);

  }

  // END, CR00231961

  // ___________________________________________________________________________
  /**
   * Cancel a contract for a service supplier.
   *
   * @param key The service supplier contract ID of the record being canceled.
   */
  @Override
  public void cancelContract(CancelServiceSupplierContractKey key)
    throws AppException, InformationalException {

    // Contract maintenance object
    final curam.core.intf.MaintainContract maintainContractObj = curam.core.fact.MaintainContractFactory.newInstance();

    // Cancel the contract
    maintainContractObj.cancelContract(key.cancelContractDetailsKey);
  }

  // BEGIN, CR00230239, ZV
  // ___________________________________________________________________________
  /**
   * Creates a new contract for a service supplier
   *
   * @param details The service supplier contract details being entered.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #createContract1()}.
   */
  @Override
  @Deprecated
  public void createContract(MaintainServiceSupplierContractDetails details)
    throws AppException, InformationalException {

    final MaintainServiceSupplierContractDetails1 maintainServiceSupplierContractDetails = new MaintainServiceSupplierContractDetails1();

    maintainServiceSupplierContractDetails.assign(details);

    createContract1(maintainServiceSupplierContractDetails);
  }

  // END, CR00230239

  // ___________________________________________________________________________
  /**
   * List the contracts for a service supplier.
   *
   * @param key The service supplier concern role ID.
   *
   * @return The service supplier contract list returned from the database.
   */
  @Override
  public ReadServiceSupplierContractList listContract(
    ReadServiceSupplierContractListKey key) throws AppException,
      InformationalException {

    // Contract maintenance object and key
    final curam.core.intf.MaintainContract maintainContractObj = curam.core.fact.MaintainContractFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierContractList readServiceSupplierContractList = new ReadServiceSupplierContractList();

    // Context object and key
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read list of contracts
    readServiceSupplierContractList.readMultiByConcRoleIDContractResult = maintainContractObj.readMultiByConcernRoleID(
      key.contractConcernKey);

    // Get the concern role ID from key
    participantContextDescriptionKey.concernRoleID = key.contractConcernKey.concernRoleID;

    // Get the context description for the concern role
    readServiceSupplierContractList.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readServiceSupplierContractList;
  }

  // BEGIN, CR00230239, ZV
  // ___________________________________________________________________________
  /**
   * Modify the contract details for a service supplier.
   *
   * @param details The service supplier contract details being modified.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #modifyContract1()}.
   */
  @Override
  @Deprecated
  public void modifyContract(MaintainServiceSupplierContractDetails details)
    throws AppException, InformationalException {

    final MaintainServiceSupplierContractDetails1 maintainServiceSupplierContractDetails = new MaintainServiceSupplierContractDetails1();

    maintainServiceSupplierContractDetails.assign(details);

    modifyContract1(maintainServiceSupplierContractDetails);
  }

  // END, CR00230239

  // ___________________________________________________________________________
  /**
   * Read the details of a contract for a service supplier.
   *
   * @param key The service supplier contract ID.
   *
   * @return The service supplier contract details returned from the database.
   */
  @Override
  public ReadServiceSupplierContractDetails readContract(
    ReadServiceSupplierContractKey key) throws AppException,
      InformationalException {

    // Contract maintenance object
    final curam.core.intf.MaintainContract maintainContractObj = curam.core.fact.MaintainContractFactory.newInstance();

    // Contract object
    final curam.core.intf.Contract contractObj = curam.core.fact.ContractFactory.newInstance();

    // Details to be returned
    final ReadServiceSupplierContractDetails readServiceSupplierContractDetails = new ReadServiceSupplierContractDetails();

    // Context object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Key used to read contract object
    final ContractKey contractKey = new ContractKey();

    // Build the ContractKey from the ID in the
    // ReadServiceSupplierContractKey and use it to read the
    // contract object.
    contractKey.contractID = key.contractDetailsKey.contractID;
    final ContractDtls contractDtls = contractObj.read(contractKey);

    // Build the ParticipantContextDescriptionKey using the data from the
    // above read.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = contractDtls.concernRoleID;

    // Read the contract details
    readServiceSupplierContractDetails.contractDetails = maintainContractObj.readServiceContract(
      key.contractDetailsKey);

    // Read the context description
    readServiceSupplierContractDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Instance of key passed into method to retrieve Service Details list
    final ReadServicesCoveredKey readServicesCoveredKey = new ReadServicesCoveredKey();

    // Return Details
    ReadServicesCoveredDetails readServicesCoveredDetails;

    // Assign ContractID
    readServicesCoveredKey.contractIDKey.contractID = key.contractDetailsKey.contractID;

    // Get Product Details List
    readServicesCoveredDetails = readServicesCovered(readServicesCoveredKey);

    readServiceSupplierContractDetails.servicesDetailStructList = readServicesCoveredDetails.servicesDetailStructList;

    // Return the details
    return readServiceSupplierContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to insert a supplier return header.
   *
   * @param details The service supplier return details being entered.
   */
  @Override
  public void createReturn(MaintainServiceSupplierReturnDetails details)
    throws AppException, InformationalException {

    // Service Supplier return maintenance object
    final curam.core.intf.MaintainServiceSupplierReturns maintainServiceSupplierReturnsObj = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Create Service Supplier Return Details
    maintainServiceSupplierReturnsObj.insertSupplierReturnHeader(
      details.supplierReturnHeaderDetails);

  }

  // ___________________________________________________________________________
  /**
   * modifies a supplier return header.
   *
   * @param details The service supplier return details being modified.
   */
  @Override
  public void modifyReturn(MaintainServiceSupplierReturnDetails details)
    throws AppException, InformationalException {

    // Create a MaintainServiceSupplierReturns Object
    final curam.core.intf.MaintainServiceSupplierReturns maintainServiceSupplierReturnsObj = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Create a SupplierReturnHeaderDetails object
    final SupplierReturnHeaderDetails supplierReturnHeaderDetails = details.supplierReturnHeaderDetails;

    // Create ReadSupplierReturnKey object
    final ReadSupplierReturnKey readSupplierReturnKey = new ReadSupplierReturnKey();

    // Get the Concern Role ID from the details.
    readSupplierReturnKey.returnID = supplierReturnHeaderDetails.supplierReturnID;

    // Modify the supplier return header
    maintainServiceSupplierReturnsObj.modifySupplierReturnHeader(
      supplierReturnHeaderDetails, readSupplierReturnKey);
  }

  // ___________________________________________________________________________
  /**
   * Process a supplier return.
   *
   * @param key The service supplier process return.
   *
   * @return A list of informational messages.
   */
  @Override
  public curam.core.facade.struct.ProcessReturnDetails processReturn(
    ProcessReturnKey key) throws AppException, InformationalException {

    // Maintain Service Supplier return object
    final curam.core.intf.MaintainServiceSupplierReturns maintainServiceSupplierReturnsObj = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Get instance of SupplierReturnHeader
    final curam.core.intf.SupplierReturnHeader supplierReturnHeaderObj = curam.core.fact.SupplierReturnHeaderFactory.newInstance();

    // Details to be returned
    final curam.core.facade.struct.ProcessReturnDetails processReturnDetails = new curam.core.facade.struct.ProcessReturnDetails();

    // Key used to read supply header return object
    final SupplierReturnHeaderKey supplierReturnHeaderKey = new SupplierReturnHeaderKey();

    // Build the ServiceSupplierLinkKey from the ID in the ProcessReturnKey
    // and use it to read the supply return header object.
    supplierReturnHeaderKey.supplierReturnID = key.readSupplierReturnKey.returnID;
    final SupplierReturnHeaderDtls supplierReturnHeaderDtls = supplierReturnHeaderObj.read(
      supplierReturnHeaderKey);

    // Build the ParticipantContextDescriptionKey using the data from the
    // above read.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = supplierReturnHeaderDtls.supplierConcernRoleID;

    // Get an instance of ParticipantContext
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Read the ParticipantContextDescriptionDetails from the
    // ParticipantContext instance
    processReturnDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Process the return
    processReturnDetails.supplierReturnProcessingMessageText = maintainServiceSupplierReturnsObj.processSupplierReturn(
      key.readSupplierReturnKey);

    // Return the details
    return processReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * List a Return Detail.
   *
   * @param key The service supplier concern role ID.
   *
   * @return details A list of service supplier returns.
   */
  @Override
  public ListReturnDetails listReturn(ListReturnKey key) throws AppException,
      InformationalException {

    // Create instance of ListReturnDetails
    final ListReturnDetails listReturnDetails = new ListReturnDetails();

    // Get instance of MaintainServiceSupplierReturns
    final curam.core.intf.MaintainServiceSupplierReturns maintainServiceSupplierReturns = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Read a supplierReturnHeaderDetailsList Object from the
    // MaintainServiceSupplierReturns instance
    listReturnDetails.supplierReturnHeaderDetailsList = maintainServiceSupplierReturns.readSupplierReturnsBySupplierID(
      key.supplierReturnHeaderBySupplierConcernRoleIDKey);

    // Build the ParticipantContextDescriptionKey using the data from the
    // ListReturnKey.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.supplierReturnHeaderBySupplierConcernRoleIDKey.supplierConcernRoleID;

    // Get an instance of ParticipantContext
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Read the ParticipantContextDescriptionDetails from the
    // ParticipantContext instance
    listReturnDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return listReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Read a Return Detail.
   *
   * @param key The service supplier return ID.
   *
   * @return The service supplier return details returned from the database.
   */
  @Override
  public ReadReturnDetails readReturn(ReadReturnKey key) throws AppException,
      InformationalException {

    // Create instance of ReadReturnDetails
    final ReadReturnDetails readReturnDetails = new ReadReturnDetails();

    // Get instance of MaintainServiceSupplierReturns
    final curam.core.intf.MaintainServiceSupplierReturns maintainServiceSupplierReturns = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Get instance of SupplierReturnHeader
    final curam.core.intf.SupplierReturnHeader supplierReturnHeaderObj = curam.core.fact.SupplierReturnHeaderFactory.newInstance();

    // Key used to read supply header return object
    final SupplierReturnHeaderKey supplierReturnHeaderKey = new SupplierReturnHeaderKey();

    // Build the ServiceSupplierLinkKey from the ID in the ReadReturnKey
    // and use it to read the supply return header object.
    supplierReturnHeaderKey.supplierReturnID = key.readSupplierReturnKey.returnID;
    final SupplierReturnHeaderDtls supplierReturnHeaderDtls = supplierReturnHeaderObj.read(
      supplierReturnHeaderKey);

    // Build the ParticipantContextDescriptionKey using the data from the
    // above read.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = supplierReturnHeaderDtls.supplierConcernRoleID;

    // Read a SupplierReturnHeaderDetails Object from the
    // MaintainServiceSupplierReturns instance
    readReturnDetails.supplierReturnHeaderDetails = maintainServiceSupplierReturns.readSupplierReturnHeader(
      key.readSupplierReturnKey);

    // Get an instance of ParticipantContext
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Read the ParticipantContextDescriptionDetails from the
    // ParticipantContext instance
    readReturnDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // BEGIN, CR00163098, JC
    readReturnDetails.supplierReturnHeaderDetails.productDescription = curam.util.type.CodeTable.getOneItem(
      curam.codetable.PRODUCTNAME.TABLENAME,
      readReturnDetails.supplierReturnHeaderDetails.productName,
      TransactionInfo.getProgramLocale());
    // END, CR00163098, JC

    // Return the details
    return readReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validate a service supplier return.
   *
   * @param key The service supplier return details being validated.
   *
   * @return details A list of informational messages.
   */
  @Override
  public ValidateReturnDetails validateReturn(ValidateReturnKey key)
    throws AppException, InformationalException {

    // Return maintenance object
    final curam.core.intf.MaintainServiceSupplierReturns maintainSSReturnsObj = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Get instance of SupplierReturnHeader
    final curam.core.intf.SupplierReturnHeader supplierReturnHeaderObj = curam.core.fact.SupplierReturnHeaderFactory.newInstance();

    // Context maintenance object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Details to be returned
    final ValidateReturnDetails validateReturnDetails = new ValidateReturnDetails();

    // Key used to read supply header return object
    final SupplierReturnHeaderKey supplierReturnHeaderKey = new SupplierReturnHeaderKey();

    // Build the ServiceSupplierLinkKey from the ID in the ValidateReturnKey
    // and use it to read the supply return header object.
    supplierReturnHeaderKey.supplierReturnID = key.readSupplierReturnKey.returnID;
    final SupplierReturnHeaderDtls supplierReturnHeaderDtls = supplierReturnHeaderObj.read(
      supplierReturnHeaderKey);

    // Build the ParticipantContextDescriptionKey using the data from the
    // above read.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = supplierReturnHeaderDtls.supplierConcernRoleID;

    // Validate the return
    validateReturnDetails.informationalMsgDtlsList = maintainSSReturnsObj.validateSupplierReturn(
      key.readSupplierReturnKey);

    // Read the context details
    validateReturnDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return validateReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates a service supplier with modified details.
   *
   * @param details The service supplier return details being modified.
   *
   * @return details A list of informational messages.
   */
  @Override
  public ModifyServiceSupplierReturnDetails modifyServiceSupplierDetails(
    ModifyServiceSupplierDetails details) throws AppException,
      InformationalException {

    // Get instance of maintenance object
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // The details to be returned
    final ModifyServiceSupplierReturnDetails modifyServiceSupplierReturnDetails = new ModifyServiceSupplierReturnDetails();

    // Create a key for modification
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = details.serviceSupplierDetails.concernRoleID;

    // Modify the service supplier details
    maintainConcernRoleDetailsObj.modifyServiceSupplier(maintainConcernRoleKey,
      details.serviceSupplierDetails);

    // BEGIN, CR00016578, SPD
    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      modifyServiceSupplierReturnDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00016578

    // Return the details
    return modifyServiceSupplierReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details about the specified service supplier.
   *
   * @param key The service supplier ID.
   *
   * @return The service supplier details returned from the database.
   */
  @Override
  public ReadServiceSupplierDetails readServiceSupplierDetails(
    ReadServiceSupplierDetailsKey key) throws AppException,
      InformationalException {

    // Get instance of maintenance object
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // Get instance of context maintenance object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // The details to be returned
    final ReadServiceSupplierDetails readServiceSupplierDetails = new ReadServiceSupplierDetails();

    // Read the service supplier details
    readServiceSupplierDetails.serviceSupplierDetails = maintainConcernRoleDetailsObj.readServiceSupplier(
      key.maintainConcernRoleKey);

    // Read the context details
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    readServiceSupplierDetails.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the object
    return readServiceSupplierDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to read the services covered by a service
   * supplier contract.
   *
   * @param key The contract ID.
   *
   * @return details The list of service returned from the database.
   */
  @Override
  public ReadServicesCoveredDetails readServicesCovered(
    ReadServicesCoveredKey key) throws AppException, InformationalException {

    // Maintain Contract Links object.
    final curam.core.intf.MaintainContractLinks maintainContractLinksObj = curam.core.fact.MaintainContractLinksFactory.newInstance();

    // The returned details
    final ReadServicesCoveredDetails readServicesCoveredDetails = new ReadServicesCoveredDetails();

    // Call the BPO method which returns a list of services.
    readServicesCoveredDetails.servicesDetailStructList = maintainContractLinksObj.readServicesCovered(
      key.contractIDKey);

    // return the list of covered services.
    return readServicesCoveredDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to add service to a contract.
   *
   * @param key The service ID of the record being added to the contract.
   */
  @Override
  public void addServiceToContract(
    curam.core.facade.struct.AddServiceToContractKey key)
    throws AppException, InformationalException {

    // Maintain Contract Object and Key.
    final curam.core.intf.MaintainContract maintainContractObj = curam.core.fact.MaintainContractFactory.newInstance();
    final ContractIDKey contractIDKey = new ContractIDKey();
    final ContractServiceIDLinkTab contractServiceIDLinkTab = new ContractServiceIDLinkTab();

    // Retrieve contractID
    contractIDKey.contractID = key.contractIDKey.contractID;

    // Retrieve Service List
    contractServiceIDLinkTab.serviceIDLinkList = key.contractServiceIDLinkTab.serviceIDLinkList;

    // Add Product to contract
    maintainContractObj.addServiceToContract(contractIDKey,
      contractServiceIDLinkTab);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to remove a service from a service supplier
   * contract.
   *
   * @param key The contract ID and product ID required to remove the product.
   */
  @Override
  public void removeServiceFromContract(
    curam.core.facade.struct.RemoveServiceFromContractKey key)
    throws AppException, InformationalException {

    // Maintain Contract Object and Key.
    final curam.core.intf.MaintainContract maintainContractObj = curam.core.fact.MaintainContractFactory.newInstance();

    // Call Method to remove the service.
    maintainContractObj.removeServiceFromContract(
      key.removeServiceFromContractKey);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to return a list of both services covered and
   * services not covered by the contract.
   *
   * @param key The contract ID for which a list of services is returned.
   */
  @Override
  public ListServicesCoveredDetails listServicesCovered(
    ListServicesCoveredKey key) throws AppException, InformationalException {

    // Maintain Contract Object and Key.
    final curam.core.intf.MaintainContract maintainContractObj = curam.core.fact.MaintainContractFactory.newInstance();
    final ContractServicesKey contractServicesKey = new ContractServicesKey();

    // Return Object.
    final ListServicesCoveredDetails listServicesCoveredDetails = new ListServicesCoveredDetails();

    // Retrieve contractID from services covered Key
    contractServicesKey.contractServicesReadKey.contractID = key.contractServicesKey.contractServicesReadKey.contractID;

    // Contract Object and Key and Details
    final curam.core.intf.Contract contractObj = curam.core.fact.ContractFactory.newInstance();

    final ContractKey contractKey = new ContractKey();
    ContractDtls contractDtls;

    // Get contractID for Key
    contractKey.contractID = key.contractServicesKey.contractServicesReadKey.contractID;

    // Retrieve concernRoleID for services not covered Key
    contractDtls = contractObj.read(contractKey);

    // Assign ConcernRoleID
    contractServicesKey.contractServicesReadKey.concernRoleID = contractDtls.concernRoleID;

    // Assign statusCode
    contractServicesKey.contractServicesReadKey.statusCode = contractDtls.statusCode;

    // Call method and retrieve Details
    listServicesCoveredDetails.contractServices = maintainContractObj.listContractServices(
      contractServicesKey);

    return listServicesCoveredDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to get order-type products.
   *
   * @return A list of order-type products.
   */
  @Override
  public GetOrderProductsDetails getOrderProducts() throws AppException,
      InformationalException {

    // Service Supplier return maintenance BPO
    final curam.core.intf.MaintainServiceSupplierReturns maintainServiceSupplierReturnsObj = curam.core.fact.MaintainServiceSupplierReturnsFactory.newInstance();

    // Create the return object
    final GetOrderProductsDetails getOrderProductsDetails = new GetOrderProductsDetails();

    // Perform the read
    getOrderProductsDetails.getOrderProductDetailsList = maintainServiceSupplierReturnsObj.getOrderProducts();

    // Get the description text for the product from the code table
    final GetOrderProduct[] getOrderProductArray = getOrderProductsDetails.getOrderProductDetailsList.dtls.items();

    for (int i = 0; i < getOrderProductArray.length; i++) {

      // BEGIN, CR00163098, JC
      getOrderProductArray[i].description = curam.util.type.CodeTable.getOneItem(
        curam.codetable.PRODUCTNAME.TABLENAME,
        getOrderProductArray[i].productName, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }

    return getOrderProductsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to cancel a return line item.
   *
   * @param key The ID of the line item to be canceled.
   */
  @Override
  public void cancelLineItem(CancelLineItemKey key) throws AppException,
      InformationalException {

    // Maintain Supplier Return LineItems Object
    final curam.core.intf.MaintainSupplierReturnLineItems maintainSupplierReturnLineItemsObj = curam.core.fact.MaintainSupplierReturnLineItemsFactory.newInstance();

    // Create the key for delete operation
    final SupplierReturnLineItemDetails supplierReturnLineItemDetails = new SupplierReturnLineItemDetails();

    supplierReturnLineItemDetails.lineItemID = key.lineItemDetails.lineItemID;
    supplierReturnLineItemDetails.versionNo = key.lineItemDetails.versionNo;

    // Perform the delete
    maintainSupplierReturnLineItemsObj.deleteLineItem(
      supplierReturnLineItemDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to create a line item.
   *
   * @param details Contains the details of the line item to be created.
   */
  @Override
  public void createLineItem(CreateLineItemDetails details)
    throws AppException, InformationalException {

    // Maintain Supplier Return LineItems Object
    final curam.core.intf.MaintainSupplierReturnLineItems maintainSupplierReturnLineItemsObj = curam.core.fact.MaintainSupplierReturnLineItemsFactory.newInstance();

    // Create the details object for the create operation
    final SupplierReturnLineItemDetails supplierReturnLineItemDetails = new SupplierReturnLineItemDetails();

    supplierReturnLineItemDetails.assign(details.lineItemDetails);

    // Perform the create operation
    maintainSupplierReturnLineItemsObj.insertReturnLineItem(
      supplierReturnLineItemDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to list line item returns.
   *
   * @param key Supplies the ID of the parent Supplier Return record.
   *
   * @return A list of line items associated with a Supplier Return record,
   * together with its context description and list header details.
   */
  @Override
  public ListLineItemDetails listLineItem(ListLineItemKey key)
    throws AppException, InformationalException {

    // Maintain Supplier Return LineItems Object
    final curam.core.intf.MaintainSupplierReturnLineItems maintainSupplierReturnLineItemsObj = curam.core.fact.MaintainSupplierReturnLineItemsFactory.newInstance();

    // Maintain Supplier Return Header Object
    final curam.core.intf.SupplierReturnHeader supplierReturnHeaderObj = curam.core.fact.SupplierReturnHeaderFactory.newInstance();

    // Context object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Admin Product Object
    final curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // Create the list return object
    final ListLineItemDetails listLineItemDetails = new ListLineItemDetails();

    // Fill the return object with the line item details
    listLineItemDetails.lineItemDetailsList.assign(
      maintainSupplierReturnLineItemsObj.searchBySupplierReturnID(
        key.processSupplierReturnLineItemsKey));

    // Create the key for the line item header details
    final SupplierReturnHeaderKey supplierReturnHeaderKey = new SupplierReturnHeaderKey();

    supplierReturnHeaderKey.supplierReturnID = key.processSupplierReturnLineItemsKey.returnID;

    // Read the line item header details and fill the return object
    final SupplierReturnHeaderDtls supplierReturnHeaderDtls = supplierReturnHeaderObj.read(
      supplierReturnHeaderKey);

    listLineItemDetails.listHeaderDetails.contactName = supplierReturnHeaderDtls.contactName;
    listLineItemDetails.listHeaderDetails.docReferenceNumber = supplierReturnHeaderDtls.docReferenceNumber;
    listLineItemDetails.listHeaderDetails.numberOfItems = supplierReturnHeaderDtls.numberOfItems;
    listLineItemDetails.listHeaderDetails.receiptDate = supplierReturnHeaderDtls.receiptDate;
    listLineItemDetails.listHeaderDetails.totalAmount = supplierReturnHeaderDtls.totalAmount;

    // Get the product name from the product ID and assign to the return object
    final ProductKeyStruct productKeyStruct = new ProductKeyStruct();

    productKeyStruct.productID = supplierReturnHeaderDtls.productID;

    // BEGIN, CR00173421, ZV
    final ReadProductResult1 readProductResult = adminProductObj.readProduct1(
      productKeyStruct);

    // END, CR00173421

    listLineItemDetails.listHeaderDetails.productName = readProductResult.dtls.name;

    // Create and fill the key that will allow us to retrieve the context
    // description.
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = supplierReturnHeaderDtls.supplierConcernRoleID;

    // Fill the return object with the participant context details
    listLineItemDetails.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    return listLineItemDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to modify a line item.
   *
   * @param details The details of the line item to be modified.
   */
  @Override
  public void modifyLineItem(ModifyLineItemDetails details)
    throws AppException, InformationalException {

    // Maintain Supplier Return LineItems Object
    final curam.core.intf.MaintainSupplierReturnLineItems maintainSupplierReturnLineItemsObj = curam.core.fact.MaintainSupplierReturnLineItemsFactory.newInstance();

    // Create the objects to be used in the modify and assign them their details
    final ReadSupplierReturnLineItemKey readSupplierReturnLineItemKey = new ReadSupplierReturnLineItemKey();

    readSupplierReturnLineItemKey.lineItemID = details.lineItemDetails.lineItemID;

    final SupplierReturnLineItemDetails supplierReturnLineItemDetails = new SupplierReturnLineItemDetails();

    supplierReturnLineItemDetails.assign(details.lineItemDetails);

    // Perform the modify
    maintainSupplierReturnLineItemsObj.modifyReturnLineItem(
      readSupplierReturnLineItemKey, supplierReturnLineItemDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to process a line item.
   *
   * @param key Contains the ID of the line item to be processed.
   */
  @Override
  public void processLineItem(ProcessLineItemKey key) throws AppException,
      InformationalException {

    // Maintain Supplier Return LineItems Object
    final curam.core.intf.MaintainSupplierReturnLineItems maintainSupplierReturnLineItemsObj = curam.core.fact.MaintainSupplierReturnLineItemsFactory.newInstance();

    // Process the line item
    maintainSupplierReturnLineItemsObj.processReturnLineItems(
      key.processSupplierReturnLineItemsKey);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the details of a line item.
   *
   * @param key Contains the ID of the line item to be read.
   */
  @Override
  public ReadLineItemDetails readLineItem(ReadLineItemKey key)
    throws AppException, InformationalException {

    // Maintain Supplier Return LineItems Object
    final curam.core.intf.MaintainSupplierReturnLineItems maintainSupplierReturnLineItemsObj = curam.core.fact.MaintainSupplierReturnLineItemsFactory.newInstance();

    // Create the return object and assign it the results of the read operation
    final ReadLineItemDetails readLineItemDetails = new ReadLineItemDetails();

    readLineItemDetails.lineItemDetails.assign(
      maintainSupplierReturnLineItemsObj.readReturnLineItem(
        key.readSupplierReturnLineItemKey));

    return readLineItemDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieve a list of active services for a service supplier.
   *
   * @param key The service supplier ID for which a list of services are
   * returned.
   *
   * @return details The list of active service details returned from the
   * database.
   */
  @Override
  public ReadServiceSupplierActiveServiceList listActiveService(
    ReadServiceSupplierServiceListKey key) throws AppException,
      InformationalException {

    // Service supplier maintenance object and key.
    final curam.core.intf.MaintainServiceSupplierLink maintainServiceSupplierLinkObj = curam.core.fact.MaintainServiceSupplierLinkFactory.newInstance();
    final ServiceSupplierLinkAndStatusCodeRMKey serviceSupplierLinkKey = new ServiceSupplierLinkAndStatusCodeRMKey();

    // Details to be returned
    final ReadServiceSupplierActiveServiceList readServiceSupplierActiveServiceList = new ReadServiceSupplierActiveServiceList();
    ActiveServiceDtls activeServiceDtls;

    serviceSupplierLinkKey.supplierConcernRoleID = key.serviceLinkReadmultiKey.supplierConcernRoleID;
    serviceSupplierLinkKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // Read the list of services
    ServiceLinkRMDtlsList serviceLinkRMDtlsList;

    serviceLinkRMDtlsList = maintainServiceSupplierLinkObj.readActiveService(
      serviceSupplierLinkKey);

    // Iterate through serviceList and assign the details to be returned.
    for (int i = 0; i < serviceLinkRMDtlsList.dtls.size(); i++) {

      activeServiceDtls = new ActiveServiceDtls();

      activeServiceDtls.assign(serviceLinkRMDtlsList.dtls.item(i));

      readServiceSupplierActiveServiceList.serviceDtls.addRef(activeServiceDtls);

    }

    // Return the list of active services.
    return readServiceSupplierActiveServiceList;
  }

  // BEGIN, CR00218851, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Searches for a Service Supplier by specified search criteria.
   *
   * @param key Service supplier search criteria
   *
   * @return Service supplier details found
   *
   * @throws AppException Application Exception
   *
   * @throws InformationalException Informational Exception
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ServiceSupplier#searchServiceSupplier(ParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchServiceSupplier(ParticipantSearchKey) which
   * returns the informational message along with service supplier
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public ParticipantSearchResult search1(ParticipantSearchKey key)
    throws AppException, InformationalException {

    // END, CR00290965
    final ParticipantSearchRouter participantSearchRouterObj = ParticipantSearchRouterFactory.newInstance();

    final ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    key.key.concernRoleType = CONCERNROLETYPE.SERVICESUPPLIER;

    participantSearchResult.dtls = participantSearchRouterObj.search(key.key);

    return participantSearchResult;
  }

  // END, CR00218851

  // BEGIN, CR00230239, ZV
  // ___________________________________________________________________________
  /**
   * Creates a new contract for a service supplier
   *
   * @param details The service supplier contract details being entered.
   */
  @Override
  public void createContract1(
    final MaintainServiceSupplierContractDetails1 details)
    throws AppException, InformationalException {

    // Contract maintenance object and key
    final MaintainContract maintainContractObj = MaintainContractFactory.newInstance();
    final ContractConcernKey contractConcernKey = new ContractConcernKey();

    // Get concern role ID from key
    contractConcernKey.concernRoleID = details.contractDetails.concernRoleID;

    // Create the contract
    maintainContractObj.createServiceContract1(contractConcernKey,
      details.contractDetails, details.contractServiceIDLinkTab);
  }

  // ___________________________________________________________________________
  /**
   * Modify the contract details for a service supplier.
   *
   * @param details The service supplier contract details being modified.
   */
  @Override
  public void modifyContract1(
    final MaintainServiceSupplierContractDetails1 details)
    throws AppException, InformationalException {

    // Contract maintenance object and key
    final MaintainContract maintainContractObj = MaintainContractFactory.newInstance();
    final ContractDetailsKey contractDetailsKey = new ContractDetailsKey();

    // Get the concern role ID from key
    contractDetailsKey.contractID = details.contractDetails.contractID;

    // Instance of key passed into method to retrieve Product Details list
    final ReadServicesCoveredKey readServicesCoveredKey = new ReadServicesCoveredKey();

    final ContractServiceIDLinkTab contractServiceIDLinkTab = new ContractServiceIDLinkTab();

    // Return Details
    ReadServicesCoveredDetails readServicesCoveredDetails;

    // Assign ContractID.
    readServicesCoveredKey.contractIDKey.contractID = details.contractDetails.contractID;

    // Get service details List
    readServicesCoveredDetails = readServicesCovered(readServicesCoveredKey);

    ServicesDetailStructList serviceDtlsStructList;

    serviceDtlsStructList = readServicesCoveredDetails.servicesDetailStructList;

    // StringBuffer variables
    final StringBuffer contractIDStringBuffer = new StringBuffer(kStringBufSize);

    // Build the list of services.
    for (int i = 0; i < serviceDtlsStructList.dtls.size() - 1; i++) {

      contractIDStringBuffer.append(serviceDtlsStructList.dtls.item(i).serviceID).append(
        CuramConst.gkTabDelimiter);
    }

    contractIDStringBuffer.append(serviceDtlsStructList.dtls.item(0).serviceID);

    // Set the list of services.
    contractServiceIDLinkTab.serviceIDLinkList = contractIDStringBuffer.toString();

    // Modify the contract
    maintainContractObj.modifyServiceContract1(contractDetailsKey,
      details.contractDetails, contractServiceIDLinkTab);
  }

  // END, CR00230239

  // BEGIN, CR00231961, ZV
  // ___________________________________________________________________________
  /**
   * Register a service supplier.
   *
   * @param details The register service supplier details
   *
   * @return details A list of informational messages.
   */
  @Override
  public ServiceSupplierRegistrationResult registerWithTextBankAccountSortCode(
    final ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails details)
    throws AppException, InformationalException {

    final curam.core.intf.ServiceSupplierRegistration serviceSupplierRegistrationObj = curam.core.fact.ServiceSupplierRegistrationFactory.newInstance();

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Read concern ID from ConcernRole, if necessary
    if (details.servSuppRegistrationDetails.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID = details.servSuppRegistrationDetails.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // Set concern ID in registration details
      details.servSuppRegistrationDetails.concernID = concernRoleDtls.concernID;
    }

    final ServiceSupplierRegistrationResult serviceSupplierRegistrationResult = new ServiceSupplierRegistrationResult();

    details.servSuppRegistrationDetails.bankSortCode = details.bankSortCode;
    // BEGIN, CR00371769, VT
    details.servSuppRegistrationDetails.bicOpt = details.bicOpt;
    // END, CR00371769

    // Register service supplier
    serviceSupplierRegistrationResult.registrationIDDetails = serviceSupplierRegistrationObj.registerServiceSupplier(
      details.servSuppRegistrationDetails);

    return serviceSupplierRegistrationResult;
  }

  // END, CR00231961

  // BEGIN, CR00234280, DJ
  /**
   * Cancels a concern role address record.
   *
   * @param key
   * contains the concern role address which is to be canceled
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAddress(key);
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * contains the concern role alternate id which is being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAlternateID(key);
  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * contains the key to cancel the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunication(key);
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * contains the ID of the communication exception being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunicationException(key);
  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * contains the contact ID for the record being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelContact(final CancelContactKey key) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelContact(key);
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * contains the ID of the email address being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelEmailAddress(key);
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * contains the details to create a participant note.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelNote(final CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelNote(details);
  }

  /**
   * Cancel a bank account for a participant.
   * This method handles the cancellation of normal bank account
   * as well as joint accounts.
   *
   * @param key contains the ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList cancelParticipantBankAccount(
    final CancelParticipantBankAccountKey key) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    final Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.cancelParticipantBankAccount(key);
    return informationMsgDtlsList;
  }

  /**
   * Cancels a phone number record.
   *
   * @param key
   * contains the concern role phone number ID of the phone record being
   * canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelPhoneNumber(key);
  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * contains the details of the web address to cancel
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelWebAddress(
    final CancelParticipantWebAddressDetails details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelWebAddress(details);
  }

  /**
   * Creates a concern role address record.
   *
   * @param details
   * contains the concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantAddressDetails createAddress(
    final MaintainParticipantAddressDetails details) throws AppException,
      InformationalException {

    CreateParticipantAddressDetails createParticipantAddressDetails = new CreateParticipantAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantAddressDetails = delegate.createAddress(details);
    return createParticipantAddressDetails;
  }

  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdministrator(participantAdministratorDetails);
  }

  /**
   * Create a new administrator for the concernRole supplied.
   *
   * @param details
   * contains the administrator role details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#createAdministrator(ParticipantAdministratorDetails)}
   */
  @Override
  @Deprecated
  public void createAdminRole(final CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdminRole(details);
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * contains the concern role ID and alternate id details being
   * entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantAlternateIDDetails createAlternateID(
    final MaintainParticipantAlternateIDDetails details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails = new CreateParticipantAlternateIDDetails();

    createParticipantAlternateIDDetails = delegate.createAlternateID(details);
    return createParticipantAlternateIDDetails;
  }

  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelBankAccount(CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    // BEGIN, CR00247430, MR
    delegate.cancelParticipantBankAccount(key);
    // END, CR00247430
  }

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * contains the concern role communication exception details being
   * entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createCommunicationException(details);
  }

  /**
   * Create a contact.
   *
   * @param details
   * contains the contact details being entered
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createContact(details);
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * contains the registration details for the contact
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createContactFromUnregisteredParticipant(
    final CreateContactFromUnregisteredParticipant details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createContactFromUnregisteredParticipant(details);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * contains the email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantEmailAddressDetails createEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails = new CreateParticipantEmailAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantEmailAddressDetails = delegate.createEmailAddress(details);
    return createParticipantEmailAddressDetails;
  }

  /**
   * Creates an email communication.
   *
   * @param details
   * contains the details to create the email communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Communication#createEmail(curam.core.facade.struct.CreateEmailCommDetails)}
   */
  @Override
  @Deprecated
  public void createEmailCommunication(
    final CreateEmailCommunicationDetails details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createEmailCommunication(details);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * contains the details to create the freeform communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void createFreeformCommunincation(
    final CreateFreeformCommunication details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createFreeformCommunincation(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createHomePhoneNumber(final CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createHomePhoneNumber(key);
  }

  /**
   * This method creates a mailing address for a participant.
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createMailingAddress(final CreateMailingAddress key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createMailingAddress(key);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * contains the participant note details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createNote(details);
  }

  /**
   * Creates a concern role phone number record.
   *
   * @param details
   * contains the concern role identifier & concern role phone number
   * details
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantPhoneDetails createPhoneNumber(
    final MaintainParticipantPhoneDetails details) throws AppException,
      InformationalException {

    CreateParticipantPhoneDetails createParticipantPhoneDetails = new CreateParticipantPhoneDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantPhoneDetails = delegate.createPhoneNumber(details);
    return createParticipantPhoneDetails;
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * contains the details to create the template communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void createTemplateCommunication(
    final CreateTemplateCommunication details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createTemplateCommunication(details);
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * contains the web address details being entered
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createWebAddress(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createWorkPhoneNumber(final CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createWorkPhoneNumber(key);
  }

  /**
   * Display the address given as a single line. The address is formatted base
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData The address formatted with its descriptors i.e.
   * ADD1=Line1, ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AddressString displaySingleLineAddress(
    final OtherAddressData otherAddressData) throws AppException,
      InformationalException {

    AddressString addressString = new AddressString();
    final Participant delegate = ParticipantFactory.newInstance();

    addressString = delegate.displaySingleLineAddress(otherAddressData);
    return addressString;
  }

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * Contains the concern role ID & the case ID
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.endDeduction(details);
  }

  /**
   * Formats the bank account details for a participant. The bank details
   * are formatted to display as a single line of text. The formatting is
   * decided by a system variable.
   *
   * @param bankAccountRMDtls bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public BankAccountString formatBankAcDetailsString(
    final BankAccountRMDtls bankAccountRMDtls) throws AppException,
      InformationalException {

    BankAccountString bankAccountString = new BankAccountString();
    final Participant delegate = ParticipantFactory.newInstance();

    bankAccountString = delegate.formatBankAcDetailsString(bankAccountRMDtls);
    return bankAccountString;
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void insertPrimaryResidenceAddress(final InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.insertPrimaryResidenceAddress(key);
  }

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantActiveAddressList listActiveAddresses(
    final ReadParticipantAddressListKey key) throws AppException,
      InformationalException {

    final ReadParticipantActiveAddressList readParticipantActiveAddressList = new ReadParticipantActiveAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveAddresses(key);
    return readParticipantActiveAddressList;
  }

  /**
   * Method to list all active bank accounts for a Case Nominee.
   *
   * @param key
   * contains the concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadActiveBankAccountList listActiveBankAccount(
    final ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    final ReadActiveBankAccountList readActiveBankAccountList = new ReadActiveBankAccountList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveBankAccount(key);
    return readActiveBankAccountList;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam V6.0. This method is replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Override
  @Deprecated
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection(
    final ParticipantBankAccountRedirectionKey key) throws AppException,
      InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection1(
    ParticipantBankAccountRedirectionKey1 key) throws AppException,
      InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection1(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAddressList listAddress(
    final ReadParticipantAddressListKey key) throws AppException,
      InformationalException {

    ReadParticipantAddressList readParticipantAddressList = new ReadParticipantAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressList = delegate.listAddress(key);
    return readParticipantAddressList;
  }

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key contains the Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadAddressHistoryList listAddressHistory(
    final ReadAddressHistoryListKey key) throws AppException,
      InformationalException {

    ReadAddressHistoryList readAddressHistoryList = new ReadAddressHistoryList();
    final Participant delegate = ParticipantFactory.newInstance();

    readAddressHistoryList = delegate.listAddressHistory(key);
    return readAddressHistoryList;
  }

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantAddressStringList listAddressString(
    final ReadParticipantAddressListKey key) throws AppException,
      InformationalException {

    final ParticipantAddressStringList participantAddressStringList = new ParticipantAddressStringList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listAddressString(key);
    return participantAddressStringList;
  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantAdministratorDetailsList listAdministrators(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministrators(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned
   *
   * @return The list of administrators for the duplicate concern role
   * specified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public ParticipantAdministratorDetailsList listAdministratorsForDuplicateParticipant(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministratorsForDuplicateParticipant(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministrators(ReadParticipantAdminRoleListKey)}
   */
  @Override
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRole(
    final ReadParticipantAdminRoleListKey key) throws AppException,
      InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAdminRoleList = delegate.listAdminRole(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministratorsForDuplicateParticipant(ReadParticipantAdminRoleListKey)}
   */
  @Override
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRoleForDuplicate(
    final ReadParticipantAdminRoleListKey key) throws AppException,
      InformationalException {

    final ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listAdminRoleForDuplicate(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAlternateIDList listAlternateID(
    final ReadParticipantAlternateIDListKey key) throws AppException,
      InformationalException {

    ReadParticipantAlternateIDList readParticipantAlternateIDList = new ReadParticipantAlternateIDList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDList = delegate.listAlternateID(key);
    return readParticipantAlternateIDList;
  }

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the alternateID of the AlternateID record the snapshots
   * are associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAltIDHistoryList listAlternateIDHistory(
    final ReadParticipantAltIDHistoryListKey key) throws AppException,
      InformationalException {

    ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList = new ReadParticipantAltIDHistoryList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAltIDHistoryList = delegate.listAlternateIDHistory(key);
    return readParticipantAltIDHistoryList;
  }

  /**
   * Method returns a list of Assessments for the participant.
   *
   * @param concernRoleKey contains the concern role that the assessments were
   * created for.
   *
   * @return The list of Assessments for the concern role.
   */
  @Override
  public ParticipantAssessmentsList listAssessments(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    ParticipantAssessmentsList participantAssessmentsList = new ParticipantAssessmentsList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantAssessmentsList = delegate.listAssessments(concernRoleKey);
    return participantAssessmentsList;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of bank accounts is
   * returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAccountList listBankAccount(
    ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    ReadParticipantBankAccountList readParticipantBankAccountList = new ReadParticipantBankAccountList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountList = delegate.listBankAccount(key);
    return readParticipantBankAccountList;
  }

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAcHistoryList listBankAccountHistory(
    ReadParticipantBankAcHistoryListKey key) throws AppException,
      InformationalException {

    ReadParticipantBankAcHistoryList readParticipantBankAcHistoryList = new ReadParticipantBankAcHistoryList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAcHistoryList = delegate.listBankAccountHistory(key);
    return readParticipantBankAcHistoryList;
  }

  /**
   * Lists the formatted bank account details. The bank details
   * are formatted to display as a single line of text.
   *
   * @param key concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantBankAccountStringList listBankAccountString(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    ParticipantBankAccountStringList participantBankAccountStringList = new ParticipantBankAccountStringList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantBankAccountStringList = delegate.listBankAccountString(key);
    return participantBankAccountStringList;
  }

  /**
   * Lists all communications by case ID.
   *
   * @param key Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CommunicationDetailList listCommunication(
    ParticipantCommunicationKey key) throws AppException,
      InformationalException {

    CommunicationDetailList communicationDetailList = new CommunicationDetailList();
    final Participant delegate = ParticipantFactory.newInstance();

    communicationDetailList = delegate.listCommunication(key);
    return communicationDetailList;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of communication
   * exceptions are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    ReadParticipantCommunicationExceptionListKey key) throws AppException,
      InformationalException {

    ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList = new ReadParticipantCommunicationExceptionList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantCommunicationExceptionList = delegate.listCommunicationException(
      key);
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantConcernRoleList listConcernRole(
    ReadParticipantConcernRoleKey key) throws AppException,
      InformationalException {

    ReadParticipantConcernRoleList readParticipantConcernRoleList = new ReadParticipantConcernRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantConcernRoleList = delegate.listConcernRole(key);
    return readParticipantConcernRoleList;
  }

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadDuplicateParticipantConcernRoleList listConcernRoleForDuplicate(
    ReadParticipantConcernRoleKey key) throws AppException,
      InformationalException {

    ReadDuplicateParticipantConcernRoleList readDuplicateParticipantConcernRoleList = new ReadDuplicateParticipantConcernRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantConcernRoleList = delegate.listConcernRoleForDuplicate(
      key);
    return readDuplicateParticipantConcernRoleList;
  }

  // BEGIN, CR00294967, MV
  /**
   * A list of contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #listConcernContact()}.
   * The
   * return struct of the current method listContact has an
   * aggregation to the struct ConcernContactRMDtls, the attribute
   * statusCode in the struct ConcernContactRMDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ListConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public ListContactDetails listContact(ListContactKey key)
    throws AppException, InformationalException {

    ListContactDetails listContactDetails = new ListContactDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listContactDetails = delegate.listContact(key);
    return listContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Lists the contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListConcernContactDetails listConcernContact(final ListContactKey key) throws AppException,
      InformationalException {

    ListConcernContactDetails listConcernContactDetails = new ListConcernContactDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listConcernContactDetails = delegate.listConcernContact(key);
    return listConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public ReadParticipantDeductionList listDeduction(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList readParticipantDeductionList = new ReadParticipantDeductionList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList = delegate.listDeduction(key);
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantDeductionList1 listDeduction1(ConcernRoleKeyStruct key) throws AppException,
      InformationalException {

    ReadParticipantDeductionList1 readParticipantDeductionList1 = new ReadParticipantDeductionList1();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList1 = delegate.listDeduction1(key);
    return readParticipantDeductionList1;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadDuplicateParticipantDeductionList listDeductionForDuplicate(
    final ConcernRoleKeyStruct key) throws AppException,
      InformationalException {

    ReadDuplicateParticipantDeductionList readDuplicateParticipantDeductionList = new ReadDuplicateParticipantDeductionList();
    final Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantDeductionList = delegate.listDeductionForDuplicate(
      key);
    return readDuplicateParticipantDeductionList;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of email addresses
   * is returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantEmailAddressList listEmailAddress(
    ReadParticipantEmailAddressListKey key) throws AppException,
      InformationalException {

    ReadParticipantEmailAddressList readParticipantEmailAddressList = new ReadParticipantEmailAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressList = delegate.listEmailAddress(key);
    return readParticipantEmailAddressList;
  }

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FormattedAddressList listFormattedAddress(
    ReadParticipantFormattedAddressListKey readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    FormattedAddressList formattedAddressList = new FormattedAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    formattedAddressList = delegate.listFormattedAddress(
      readParticipantFormattedAddressListKey);
    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FormattedBankAccountList listFormattedBankAccount(
    ReadParticipantFormattedBankAccountListKey readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    FormattedBankAccountList formattedBankAccountList = new FormattedBankAccountList();
    final Participant delegate = ParticipantFactory.newInstance();

    formattedBankAccountList = delegate.listFormattedBankAccount(
      readParticipantFormattedBankAccountListKey);
    return formattedBankAccountList;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListInteractionDetails listInteractionDetails = new ListInteractionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listInteractionDetails = delegate.listInteraction(key);
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantInteractionDetails listInteractionForDuplicate(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListDuplicateParticipantInteractionDetails listDuplicateParticipantInteractionDetails = new ListDuplicateParticipantInteractionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantInteractionDetails = delegate.listInteractionForDuplicate(
      key);
    return listDuplicateParticipantInteractionDetails;
  }

  /**
   * Method returns a list of Investigations for the participant.
   *
   * @param key contains the concern role that the investigations
   * were created for.
   *
   * @return The list of Investigations for the concern role.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantInvestigationList listInvestigations(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    ParticipantInvestigationList participantInvestigationList = new ParticipantInvestigationList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantInvestigationList = delegate.listInvestigations(key);
    return participantInvestigationList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListParticipantIssuedPaymentInstrument listIssuedPaymentInstrument(
    final ConcernRoleKeyStruct key) throws AppException,
      InformationalException {

    ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument = new ListParticipantIssuedPaymentInstrument();
    final Participant delegate = ParticipantFactory.newInstance();

    listParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrument(
      key);
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantIssuedPaymentInstrument listIssuedPaymentInstrumentForDuplicate(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPaymentInstrument = new ListDuplicateParticipantIssuedPaymentInstrument();
    final Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrumentForDuplicate(
      key);
    return listDuplicateParticipantIssuedPaymentInstrument;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listNote1()}
   */
  @Override
  @Deprecated
  public ParticipantNoteList listNote(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList participantNoteList = new ParticipantNoteList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote(key);
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantNoteList1 listNote1(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList1 participantNoteList = new ParticipantNoteList1();
    final Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote1(key);
    return participantNoteList;
  }

  // END, CR00231506

  /**
   * @param key
   * contains the key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listParticipantFinancial1()}.
   * Returns a list of financials for a participant.
   */
  @Override
  @Deprecated
  public ListParticipantFinancials listParticipantFinancial(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {

    ListParticipantFinancials listParticipantFinancials = new ListParticipantFinancials();
    final Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials = delegate.listParticipantFinancial(key);
    return listParticipantFinancials;
  }

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListParticipantFinancials1 listParticipantFinancial1(
    ListParticipantFinancialsKey key) throws AppException,
      InformationalException {

    ListParticipantFinancials1 listParticipantFinancials1 = new ListParticipantFinancials1();
    final Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials1 = delegate.listParticipantFinancial1(key);
    return listParticipantFinancials1;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantFinancials listParticipantFinancialForDuplicate(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {

    ListDuplicateParticipantFinancials listDuplicateParticipantFinancials = new ListDuplicateParticipantFinancials();
    final Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantFinancials = delegate.listParticipantFinancialForDuplicate(
      key);
    return listDuplicateParticipantFinancials;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * contains the key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public TasksForConcernAndCaseDetails listParticipantTask(
    final ListParticipantTaskKey_eo key) throws AppException,
      InformationalException {

    TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails = new TasksForConcernAndCaseDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    tasksForConcernAndCaseDetails = delegate.listParticipantTask(key);
    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public TasksForDuplicateConcernAndCaseDetails listParticipantTaskForDuplicate(final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForDuplicateConcernAndCaseDetails tasksForDuplicateConcernAndCaseDetails = new TasksForDuplicateConcernAndCaseDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    tasksForDuplicateConcernAndCaseDetails = delegate.listParticipantTaskForDuplicate(
      key);
    return tasksForDuplicateConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role.
   *
   * @param key
   * contains the concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantPhoneNumberList listPhoneNumber(
    final ReadParticipantPhoneNumberListKey key) throws AppException,
      InformationalException {

    ReadParticipantPhoneNumberList readParticipantPhoneNumberList = new ReadParticipantPhoneNumberList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberList = delegate.listPhoneNumber(key);
    return readParticipantPhoneNumberList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   */
  @Override
  public ParticipantScreeningList listScreeningCases(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    ParticipantScreeningList participantScreeningList = new ParticipantScreeningList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantScreeningList = delegate.listScreeningCases(key);
    return participantScreeningList;
  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * contains the key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key) throws AppException,
      InformationalException {

    ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant = new ListTemplateByTypeAndParticpant();
    final Participant delegate = ParticipantFactory.newInstance();

    listTemplateByTypeAndParticpant = delegate.listTemplateByTypeAndParticipant(
      key);
    return listTemplateByTypeAndParticpant;
  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of web addresses is
   * returned
   * @return The list of web addresses returned from the database
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantWebAddressList listWebAddress(
    final ParticipantWebAddressListKey key) throws AppException,
      InformationalException {

    ParticipantWebAddressList participantWebAddressList = new ParticipantWebAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantWebAddressList = delegate.listWebAddress(key);
    return participantWebAddressList;
  }

  /**
   * Modifies an address record for a concern role.
   *
   * @param details
   * contains the concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ModifiedAddressDetails modifyAddress(
    final MaintainParticipantAddressDetails details) throws AppException,
      InformationalException {

    ModifiedAddressDetails modifiedAddressDetails = new ModifiedAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    modifiedAddressDetails = delegate.modifyAddress(details);
    return modifiedAddressDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * contains the concern role ID and alternate id detail being
   * modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ModifiedAlternateIDDetails modifyAlternateID(
    final MaintainParticipantAlternateIDDetails details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ModifiedAlternateIDDetails modifiedAlternateIDDetails = new ModifiedAlternateIDDetails();

    modifiedAlternateIDDetails = delegate.modifyAlternateID(details);
    return modifiedAlternateIDDetails;
  }

  /**
   * @param details
   * contains the bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}.
   * Modify the bank account details for a participant.
   */
  @Override
  @Deprecated
  public InformationMsgDtlsList modifyBankAccount(
    final MaintainParticipantBankAccountDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    final Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccount(details);
    return informationMsgDtlsList;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * contains the details to modify the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunication(details);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * contains the concern role communication exception details being
   * modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunicationException(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #modifyConcernContact()}.
   * The parameter struct of the current method modifyContact has
   * an aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to have new parameter ModifyConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyContact(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyConcernContact(details);
  }

  // END, CR00294967

  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * contains the email address details being modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyEmailAddress(details);
  }

  // BEGIN, CR00231506, PDN
  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #modifyNote1()}
   */
  @Override
  @Deprecated
  public void modifyNote(final ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote(details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyNote1(final ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote1(details);
  }

  // END, CR00231506

  /**
   * Modifies a phone number record for a concern role.
   *
   * @param details
   * contains the concern role id and concern role phone number details
   * that will be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyPhoneNumber(details);
  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * contains the details of the sent communication to be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifySentCommunication(
    final ModifySentCommunicationDetails details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifySentCommunication(details);
  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * contains the web address details being modified
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyWebAddress(details);
  }

  /**
   * Prints a communication.
   *
   * @param details
   * contains details to print the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.printCommunication(details);
  }

  /**
   * Reads an address record for a concern role.
   *
   * @param key
   * contains the concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAddressDetails readAddress(
    final ReadParticipantAddressKey key) throws AppException,
      InformationalException {

    ReadParticipantAddressDetails readParticipantAddressDetails = new ReadParticipantAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressDetails = delegate.readAddress(key);
    return readParticipantAddressDetails;
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * contains the concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAlternateIDDetails readAlternateID(
    final ReadParticipantAlternateIDKey key) throws AppException,
      InformationalException {

    ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails = new ReadParticipantAlternateIDDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDDetails = delegate.readAlternateID(key);
    return readParticipantAlternateIDDetails;
  }

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * contains the bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAccountDetails readBankAccount(
    final ReadParticipantBankAccountKey key) throws AppException,
      InformationalException {

    ReadParticipantBankAccountDetails readParticipantBankAccountDetails = new ReadParticipantBankAccountDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountDetails = delegate.readBankAccount(key);
    return readParticipantBankAccountDetails;
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadCommDetails readCommDetails = new ReadCommDetails();

    readCommDetails = delegate.readCommunication(key);
    return readCommDetails;
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * contains the key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails = new ReadCommunicationAttachmentDetails();

    readCommunicationAttachmentDetails = delegate.readCommunicationAttachment(
      key);
    return readCommunicationAttachmentDetails;
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * contains the communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantCommunicationExceptionDetails readCommunicationException(
    final ReadParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails = new ReadParticipantCommunicationExceptionDetails();

    readParticipantCommunicationExceptionDetails = delegate.readCommunicationException(
      key);
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * contains the concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ConcernRoleTypeDetails readConcernRoleType(
    final ReadParticipantConcernRoleKey key) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

    concernRoleTypeDetails = delegate.readConcernRoleType(key);
    return concernRoleTypeDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link readConcernContact()}
   * .The return struct of the current method
   * readContact has an aggregation to the struct
   * ConcernContactDtls, the attribute statusCode in the struct
   * ConcernContactDtls is modeled with a domain of CONTACTSTATUS
   * code-table, but the corresponding entity attribute
   * ConcernRoleContactDtls.statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. So new method is introduced to return new
   * struct ReadConcernContactDetails which has an
   * aggregation to the new struct ConcernContactRMultiDtls where
   * the attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  @Override
  @Deprecated
  // END, CR00294967
  public ReadContactDetails readContact(final ReadContactKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadContactDetails readContactDetails = new ReadContactDetails();

    readContactDetails = delegate.readContact(key);
    return readContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadConcernContactDetails readConcernContact(final ReadContactKey key) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadConcernContactDetails readConcernContactDetails = new ReadConcernContactDetails();

    readConcernContactDetails = delegate.readConcernContact(key);
    return readConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * contains the concern role ID for which the description is
   * retrieved.
   *
   * @return The returned description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public ParticipantContextDetails readContextDescription(
    final ParticipantContextKey key) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    participantContextDetails = delegate.readContextDescription(key);
    return participantContextDetails;
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * contains the email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantEmailAddressDetails readEmailAddress(
    final ReadParticipantEmailAddressKey key) throws AppException,
      InformationalException {

    ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails = new ReadParticipantEmailAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressDetails = delegate.readEmailAddress(key);
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadInteractionDetails readInteraction(final ReadInteractionKey key)
    throws AppException, InformationalException {

    ReadInteractionDetails readInteractionDetails = new ReadInteractionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readInteractionDetails = delegate.readInteraction(key);
    return readInteractionDetails;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #readNote1()}
   */
  @Override
  @Deprecated
  public ReadParticipantNoteDetails readNote(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails readParticipantNoteDetails = new ReadParticipantNoteDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote(key);
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantNoteDetails1 readNote1(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails1 readParticipantNoteDetails = new ReadParticipantNoteDetails1();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote1(key);
    return readParticipantNoteDetails;
  }

  // END, CR00231506

  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * contains the contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ContactContextDescriptionDetails readParticipantContactContextDescription(
    final ContactContextDescriptionKey key) throws AppException,
      InformationalException {

    ContactContextDescriptionDetails contactContextDescriptionDetails = new ContactContextDescriptionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    contactContextDescriptionDetails = delegate.readParticipantContactContextDescription(
      key);
    return contactContextDescriptionDetails;
  }

  /**
   * Reads a phone number record for a concern role.
   *
   * @param key contains the concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantPhoneNumberDetails readPhoneNumber(
    final ReadParticipantPhoneNumberKey key) throws AppException,
      InformationalException {

    ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails = new ReadParticipantPhoneNumberDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberDetails = delegate.readPhoneNumber(key);
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * contains the web address ID of the record being read.
   *
   * @return The web address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantWebAddressDetails readWebAddress(
    final ParticipantWebAddressKey key) throws AppException,
      InformationalException {

    ReadParticipantWebAddressDetails readParticipantWebAddressDetails = new ReadParticipantWebAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantWebAddressDetails = delegate.readWebAddress(key);
    return readParticipantWebAddressDetails;
  }

  /**
   * Records an existing communication.
   *
   * @param details
   * contains the details of the existing communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.recordExistingCommunication(details);
  }

  /**
   * Removes an address record for a concern role.
   *
   * @param key contains the concern role address key
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.removeAddress(key);
  }

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key contains the concern Role ID of the record being read.
   *
   * @return The home page name.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantHomePageName resolveProspectHome(
    final ConcernRoleKeyStruct key) throws AppException,
      InformationalException {

    ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();
    final Participant delegate = ParticipantFactory.newInstance();

    participantHomePageName = delegate.resolveProspectHome(key);
    return participantHomePageName;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key Participant search criteria
   *
   * @return Participant details found
   *
   * @throws AppException Application Exception
   *
   * @throws InformationalException Informational Exception
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ServiceSupplier#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchParticipantDetails(AllParticipantSearchKey)
   * which returns the informational message along with participant details
   * as well. See release note: CS-09152/CR00290965
   */
  @Override
  @Deprecated
  public AllParticipantSearchResult searchParticipant(
    AllParticipantSearchKey key) throws AppException, InformationalException {

    // END, CR00290965
    AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();
    final Participant delegate = ParticipantFactory.newInstance();

    allParticipantSearchResult = delegate.searchParticipant(key);
    return allParticipantSearchResult;
  }

  /**
   * Sends an email communication.
   *
   * @Deprecated
   * @param details
   * contains the details to send the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.sendEmailCommunication(details);
  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * contains the concern role ID and the bank
   * account ID of the bank for which payment will now be made to.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void updateBankAccountPaymentDetails(
    final UpdateBankAccPaymentDtlsKey key) throws AppException,
      InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.updateBankAccountPaymentDetails(key);
  }

  /**
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}.
   * Create a new bank account for a participant.
   */
  @Override
  @Deprecated
  public CreateParticipantBankAccountDetails createBankAccount(
    MaintainParticipantBankAccountDetails details) throws AppException,
      InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccount(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantBankAccountDetails createBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccountWithTextSortCode(
      details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    final Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccountWithTextSortCode(details);
    return informationMsgDtlsList;
  }

  // END, CR00234280

  // BEGIN, CR00290965, IBM
  /**
   * Searches the service supplier details by specified search criteria.
   *
   * @param participantSearchKey contains service supplier search key
   *
   * @return participant search details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantSearchDetails searchServiceSupplier(
    final ParticipantSearchKey participantSearchKey) throws AppException,
      InformationalException {

    final ParticipantSearchRouter participantSearchRouter = ParticipantSearchRouterFactory.newInstance();

    final ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    participantSearchKey.key.concernRoleType = CONCERNROLETYPE.SERVICESUPPLIER;

    participantSearchDetails.dtls = participantSearchRouter.search(
      participantSearchKey.key);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      participantSearchDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return participantSearchDetails;
  }

  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey contains all participant search key
   *
   * @return participant search details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  @Override
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey)
    throws AppException, InformationalException {

    AllParticipantSearchDetails allParticipantSearchDetails = new AllParticipantSearchDetails();

    final Participant participant = ParticipantFactory.newInstance();

    allParticipantSearchDetails = participant.searchParticipantDetails(
      allParticipantSearchKey);

    return allParticipantSearchDetails;
  }
  // END, CR00290965
}
