/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.core.sl.fact.FinancialCaseTabFactory;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.struct.ActiveDeductionDetailList;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.OverpaymentCaseTabDetail;
import curam.core.sl.struct.PaymentCorrectionCaseTabDetail;
import curam.core.sl.struct.PaymentCorrectionCaseTabResult;
import curam.core.sl.struct.UnderpaymentCaseTabDetail;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.StatusCodeCurrentDateCaseIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * Facade interface for the Financial case tab details.
 */
public abstract class FinancialCaseTab extends curam.core.facade.base.FinancialCaseTab {

  // BEGIN, CR00209246, CW
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;

  // END, CR00209246

  /**
   * Add injection for using PI classes.
   */
  public FinancialCaseTab() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // __________________________________________________________________________
  /**
   * Read the details for the Overpayment case tab details panel.
   *
   * @param CaseIDKey The unique identifier for the overpayment case
   * @return OverpaymentCaseTabDetail overpayment case tab details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public OverpaymentCaseTabDetail readOverpaymentCaseTabDetail(
    CaseIDKey caseIDKey) throws AppException, InformationalException {

    return FinancialCaseTabFactory.newInstance().readOverpaymentCaseTabDetail(
      caseIDKey);
  }

  // __________________________________________________________________________
  /**
   * Read the details for the Underpayment case tab details panel.
   *
   * @param CaseIDKey The unique identifier for the Underpayment case
   * @return UnderpaymentCaseTabDetail Underpayment case tab details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public UnderpaymentCaseTabDetail readUnderpaymentCaseTabDetail(
    CaseIDKey caseIDKey) throws AppException, InformationalException {

    return FinancialCaseTabFactory.newInstance().readUnderpaymentCaseTabDetail(
      caseIDKey);
  }

  // BEGIN, CR00191614, MC
  // __________________________________________________________________________
  /**
   * Lists the details of the active deductions which apply to this Overpayment
   * case.
   *
   * @param statusDateCaseIDKey The unique identifier for the Overpayment case,
   * the current date and the record status of active.
   *
   * @return ActiveDeductionDetailList Underpayment case tab details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public ActiveDeductionDetailList listActiveDeduction(
    StatusCodeCurrentDateCaseIDKey statusDateCaseIDKey) throws AppException,
      InformationalException {

    return FinancialCaseTabFactory.newInstance().listActiveDeduction(
      statusDateCaseIDKey);
  }

  // END, CR00191614

  // BEGIN, CR00203103, CSH
  // BEGIN, CR00290965, IBM
  /**
   * Read the details for the Payment Correction case tab details panel.
   *
   * @param CaseIDKey The unique identifier for the Payment Correction case
   * @return PaymentCorrectionCaseTabDetail Payment Correction case tab details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link FinancialCaseTab#readPaymentCorrectionCaseTabResult(CaseIDKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by readPaymentCorrectionCaseTabResult(CaseIDKey)
   * which returns the informational message along with payment correction case
   * tab details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public PaymentCorrectionCaseTabDetail readPaymentCorrectionCaseTabDetail(
    CaseIDKey caseIDKey) throws AppException, InformationalException {

    // END, CR00290965
    PaymentCorrectionCaseTabDetail paymentCorrectionCaseTabDetail = new PaymentCorrectionCaseTabDetail();

    final curam.core.sl.intf.FinancialCaseTab financialCaseTabObj = curam.core.sl.fact.FinancialCaseTabFactory.newInstance();

    // BEGIN, CR00209246, CW
    // Check if the Payment Correction is an under or over payment
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDKey.caseID;

    if (paymentCorrection.isOverPaymentPaymentCorrection(caseHeaderKey)) {
      paymentCorrectionCaseTabDetail = financialCaseTabObj.readPaymentCorrectionOPCaseTabDetail(
        caseIDKey);
    } else if (paymentCorrection.isUnderPaymentPaymentCorrection(caseHeaderKey)) {
      paymentCorrectionCaseTabDetail = financialCaseTabObj.readPaymentCorrectionUPCaseTabDetail(
        caseIDKey);
    }
    // END, CR00209246

    return paymentCorrectionCaseTabDetail;
  }

  // END, CR00203103

  // BEGIN, CR00290965, IBM
  /**
   * Read the details for the payment correction case tab details panel.
   *
   * @param CaseIDKey the unique identifier for the payment correction case
   *
   * @return payment correction case tab details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public PaymentCorrectionCaseTabResult readPaymentCorrectionCaseTabResult(
    final CaseIDKey caseIDKey) throws AppException, InformationalException {

    final PaymentCorrectionCaseTabResult paymentCorrectionCaseTabResult = new PaymentCorrectionCaseTabResult();

    final curam.core.sl.intf.FinancialCaseTab financialCaseTabObj = FinancialCaseTabFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDKey.caseID;

    if (paymentCorrection.isOverPaymentPaymentCorrection(caseHeaderKey)) {
      paymentCorrectionCaseTabResult.dtls = financialCaseTabObj.readPaymentCorrectionOPCaseTabDetail(
        caseIDKey);
    } else if (paymentCorrection.isUnderPaymentPaymentCorrection(caseHeaderKey)) {
      paymentCorrectionCaseTabResult.dtls = financialCaseTabObj.readPaymentCorrectionUPCaseTabDetail(
        caseIDKey);
    }

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      paymentCorrectionCaseTabResult.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
    return paymentCorrectionCaseTabResult;
  }
  // END, CR00290965
}
