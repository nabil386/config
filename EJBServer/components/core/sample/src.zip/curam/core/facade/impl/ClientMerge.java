/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008,2021
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office
 */
package curam.core.facade.impl;


import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.INDIGENOUSGROUPCODE;
import curam.codetable.INDIGENOUSREGIONCODE;
import curam.codetable.MERGESTATUS;
import curam.codetable.RACECODE;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.fact.ProspectPersonFactory;
import curam.core.facade.infrastructure.struct.EvidenceTypeAndParticipantIDDetails;
import curam.core.facade.intf.ProspectPerson;
import curam.core.facade.struct.AddressMergeList;
import curam.core.facade.struct.AgendaDetails;
import curam.core.facade.struct.AlternativeIDMergeList;
import curam.core.facade.struct.AlternativeNameMergeList;
import curam.core.facade.struct.BankAccountMergeList;
import curam.core.facade.struct.CitizenshipMergeList;
import curam.core.facade.struct.ClientMergeAgendaKey;
import curam.core.facade.struct.ClientMergeParticipantKey;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.CommExceptionMergeList;
import curam.core.facade.struct.ConcernContactMergeList;
import curam.core.facade.struct.ConcernRoleDetailsForMerge;
import curam.core.facade.struct.ConcernRoleDuplicateMergeDetails;
import curam.core.facade.struct.ConcernRoleDuplicateMergeDtls;
import curam.core.facade.struct.ConcernRoleNameDtls;
import curam.core.facade.struct.ContactMergeList;
import curam.core.facade.struct.DuplicateConcernRoleDetails;
import curam.core.facade.struct.DuplicateForConcernRoleDetailsList;
import curam.core.facade.struct.DuplicatesConcernRoleDetailsList;
import curam.core.facade.struct.DuplicatesForConcernRoleDtlsList;
import curam.core.facade.struct.EducationMergeList;
import curam.core.facade.struct.EmailAddressMergeList;
import curam.core.facade.struct.EmploymentMergeList;
import curam.core.facade.struct.EndMergeKey;
import curam.core.facade.struct.EvidenceMergeList;
import curam.core.facade.struct.ForeignResidencyMergeList;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.MarkDuplicateCreateDetails;
import curam.core.facade.struct.MarkDuplicateDetails;
import curam.core.facade.struct.MergeDuplicateConcernRoleDetails;
import curam.core.facade.struct.NoteMergeList;
import curam.core.facade.struct.NoteMergeList1;
import curam.core.facade.struct.OrgUnitBreadCrumbDetails;
import curam.core.facade.struct.OriginalAndDuplicateDetails;
import curam.core.facade.struct.OriginalAndDuplicateDetails1;
import curam.core.facade.struct.OriginalAndDuplicateKey;
import curam.core.facade.struct.ParticipantContextDescriptionDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.PersonAndProspectPersonSearchResult;
import curam.core.facade.struct.PersonSearchDetailsResult;
import curam.core.facade.struct.PersonSearchResult1;
import curam.core.facade.struct.PhoneNumberMergeList;
import curam.core.facade.struct.ProspectPersonSearchKey;
import curam.core.facade.struct.ReadPersonDetails;
import curam.core.facade.struct.ReadPersonKey;
import curam.core.facade.struct.ReadProspectPersonDtls;
import curam.core.facade.struct.ReadProspectPersonKey;
import curam.core.facade.struct.RelationshipMergeList;
import curam.core.facade.struct.RendererXMLStruct;
import curam.core.facade.struct.SearchDisplayDetails;
import curam.core.facade.struct.SearchDisplayKey;
import curam.core.facade.struct.SearchNonDuplicatePersonKey;
import curam.core.facade.struct.SpecialCautionList;
import curam.core.facade.struct.UnmarkDuplicateDetails;
import curam.core.facade.struct.ViewDuplicateIndicators;
import curam.core.facade.struct.WebAddressMergeList;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainCitizenshipFactory;
import curam.core.fact.MaintainConcernRoleAddressFactory;
import curam.core.fact.MaintainConcernRoleAltIDFactory;
import curam.core.fact.MaintainConcernRoleBankAcFactory;
import curam.core.fact.MaintainConcernRoleCommExceptionFactory;
import curam.core.fact.MaintainConcernRoleEmailFactory;
import curam.core.fact.MaintainContactsFactory;
import curam.core.fact.MaintainForeignResidencyFactory;
import curam.core.fact.MaintainPersonEducationFactory;
import curam.core.fact.MaintainPersonEmploymentFactory;
import curam.core.fact.MaintainPersonNamesFactory;
import curam.core.fact.PersonSearchRouterFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainCitizenship;
import curam.core.intf.MaintainConcernRoleAddress;
import curam.core.intf.MaintainConcernRoleAltID;
import curam.core.intf.MaintainConcernRoleBankAc;
import curam.core.intf.MaintainConcernRoleCommException;
import curam.core.intf.MaintainConcernRoleEmail;
import curam.core.intf.MaintainContacts;
import curam.core.intf.MaintainForeignResidency;
import curam.core.intf.MaintainPersonEducation;
import curam.core.intf.MaintainPersonEmployment;
import curam.core.intf.MaintainPersonNames;
import curam.core.intf.PersonSearchRouter;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.fact.ConcernRoleMergeFactory;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.intf.ConcernRoleMerge;
import curam.core.sl.entity.struct.ConcernRoleDuplicateKey;
import curam.core.sl.entity.struct.ConcernRoleMergeDtls;
import curam.core.sl.entity.struct.ConcernRoleMergeDtlsList;
import curam.core.sl.entity.struct.ConcernRoleMergeKey;
import curam.core.sl.entity.struct.DuplicateForConcernRoleDetails;
import curam.core.sl.entity.struct.DuplicateForConcernRoleDtlsList;
import curam.core.sl.entity.struct.ReadByConcernRoleDuplicateIDKey;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.ParticipantNoteFactory;
import curam.sec.util.xml.agenda.impl.Agenda;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.EvidenceTypeWorkspaceKey;
import curam.core.sl.infrastructure.struct.EvidenceTypeWorkspaceListDetails;
import curam.core.sl.intf.ParticipantNote;
import curam.core.sl.struct.BooleanIndicator;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.ClientMergeEvidenceParticipantKey;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.sl.struct.MergeTabList;
import curam.core.sl.struct.ParticipantKey;
import curam.core.sl.struct.ProspectPersonHomeDetails;
import curam.core.sl.struct.SpecialCautionConcernKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleHomePageKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.ContactRMByConcernKey;
import curam.core.struct.CuramInd;
import curam.core.struct.EducationByConcernKey;
import curam.core.struct.EvidenceType;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.MaintainBankAccountKey;
import curam.core.struct.MaintainCitizenshipKey;
import curam.core.struct.MaintainCommExceptionKey;
import curam.core.struct.MaintainConcernRoleAltIDKey;
import curam.core.struct.MaintainEmailKey;
import curam.core.struct.MaintainForeignResidencyKey;
import curam.core.struct.MaintainPersonEmploymentKey;
import curam.core.struct.MaintainPersonNameKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.ReadPersonResult;
import curam.core.struct.RelationshipsByConcernRoleIDKey;
import curam.meetings.util.impl.AgendaHelper;
import curam.message.BPOCLIENTMERGE;
import curam.message.BPOINTEGRATEDCASE;
import curam.pdc.fact.ParticipantDataCaseFactory;
import curam.pdc.impl.PDCConst;
import curam.pdc.intf.ParticipantDataCase;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * This process class provides the functionality for the Client Merge facade.
 */
public abstract class ClientMerge extends curam.core.facade.base.ClientMerge {

  // ClientMerge service layer object
  curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

  // BEGIN, CR00278786, DJ
  /**
   * Define the Agenda page class for an agenda page.
   */
  public class AgendaPage {

    /**
     * A constant to describe the name of the page.
     */
    public String pageName;

    /**
     * A constant for description of the page.
     */
    public LocalisableString pageDescription;

    /**
     * A constant which indicates whether the SUMBIT action control will be
     * called on the page.
     */
    public boolean submitOnNext;

    /**
     * A constant which indicates whether this is the initial page of the
     * agenda.
     */
    public boolean isInitial;

    /**
     * Constructor for the AgendaPage inner class which initializes the agenda
     * page object.
     */
    public AgendaPage(String pageName, LocalisableString pageDescription,
      boolean submitOnNext, boolean isInitial) {

      this.pageName = pageName;
      this.pageDescription = pageDescription;
      this.submitOnNext = submitOnNext;
      this.isInitial = isInitial;
    }

    /**
     * Adds the agenda page to agenda.
     */
    public void addPageToAgenda(AgendaHelper helper) {

      helper.addPageToAgenda(
        helper.createPage(pageName, pageDescription, submitOnNext, isInitial));
    }
  }

  /**
   * Constant page description for address.
   */
  protected static final LocalisableString kMergeAddressesPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_ADDRESSES);

  /**
   * Constant page description for alternative ids.
   */
  protected static final LocalisableString kMergeAlternativeIDsPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_ALTERNATIVEIDS);

  /**
   * Constant page description for alternative name.
   */
  protected static final LocalisableString kMergeAlternativeNamesPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_ALTERNATIVENAMES);

  /**
   * Constant page description for bank accounts.
   */
  protected static final LocalisableString kMergeBankAccountsPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_BANKACCOUNTS);

  /**
   * Constant page description for citizenships.
   */
  protected static final LocalisableString kMergeCitizenshipsPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_CITIZENSHIPS);

  /**
   * Constant page description for communicationExceptions.
   */
  protected static final LocalisableString kMergeCommunicationExceptionsPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_COMMUNICATIONEXCEPTIONS);

  /**
   * Constant page description for contacts.
   */
  protected static final LocalisableString kMergeContactsPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_CONTACTS);

  /**
   * Constant page description for education.
   */
  protected static final LocalisableString kMergeEducationPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_EDUCATION);

  /**
   * Constant page description for emailAddresses.
   */
  protected static final LocalisableString kMergeEmailAddressesPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_EMAILADDRESSES);

  /**
   * Constant page description for employment.
   */
  protected static final LocalisableString kMergeEmploymentPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_EMPLOYMENT);

  /**
   * Constant page description for foreign residencies.
   */
  protected static final LocalisableString kMergeForeignResidencesPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_FOREIGNRESIDENCES);

  /**
   * Constant page description for notes.
   */
  protected static final LocalisableString kMergeNotesPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_NOTES);

  /**
   * Constant page description for phone numbers.
   */
  protected static final LocalisableString kMergePhoneNumbersPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_PHONENUMBERS);

  /**
   * Constant page description for relationships.
   */
  protected static final LocalisableString kMergeRelationshipsPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_RELATIONSHIPS);

  /**
   * Constant page description for WebAddresses.
   */
  protected static final LocalisableString kMergeWebAddressesPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_WEBADDRESSES);

  /**
   * Constant page description for summary page.
   */
  protected static final LocalisableString kMergeSummaryPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_SUMMARY);

  // BEGIN, CR00144945, SS
  /**
   * Constant page description for special cautions.
   */
  protected static final LocalisableString kMergeSpecialCautionPageDesc = new LocalisableString(
    BPOCLIENTMERGE.PAGE_DESC_SPECIALCAUTION);

  // END, CR00144945

  // BEGIN, CR00353792, ZV
  /**
   * A constant to describe the agenda page name for address.
   */
  protected AgendaPage participant_mergeAddressesPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergeAddressEvidencePage
      : CuramConst.kParticipant_mergeAddressesPage,
      kMergeAddressesPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kINITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for alternative ids.
   */
  protected AgendaPage participant_mergeAlternativeIDsPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergeAlternateIDEvidencePage
      : CuramConst.kParticipant_mergeAlternativeIDsPage,
      kMergeAlternativeIDsPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for alternative names.
   */
  protected AgendaPage participant_mergeAlternativeNamesPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergeAlternateNameEvidencePage
      : CuramConst.kParticipant_mergeAlternativeNamesPage,
      kMergeAlternativeNamesPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for bank accounts.
   */
  protected AgendaPage participant_mergeBankAccountsPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergeBankAccountEvidencePage
      : CuramConst.kParticipant_mergeBankAccountsPage,
      kMergeBankAccountsPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for citizenships.
   */
  protected AgendaPage participant_mergeCitizenshipsPage = new AgendaPage(
    CuramConst.kParticipant_mergeCitizenshipsPage, kMergeCitizenshipsPageDesc,
    CuramConst.kSUBMIT_ON_NEXT, CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for communication exceptions.
   */
  protected AgendaPage participant_mergeCommunicationExceptionsPage = new AgendaPage(
    CuramConst.kParticipant_mergeCommunicationExceptionsPage,
    kMergeCommunicationExceptionsPageDesc, CuramConst.kSUBMIT_ON_NEXT,
    CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for contacts.
   */
  protected AgendaPage participant_mergeContactsPage = new AgendaPage(
    CuramConst.kParticipant_mergeContactsPage, kMergeContactsPageDesc,
    CuramConst.kSUBMIT_ON_NEXT, CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for education.
   */
  protected AgendaPage participant_mergeEducationPage = new AgendaPage(
    CuramConst.kParticipant_mergeEducationPage, kMergeEducationPageDesc,
    CuramConst.kSUBMIT_ON_NEXT, CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for email addresses.
   */
  protected AgendaPage participant_mergeEmailAddressesPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergeEmailAddressEvidencePage
      : CuramConst.kParticipant_mergeEmailAddressesPage,
      kMergeEmailAddressesPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for employment.
   */
  protected AgendaPage participant_mergeEmploymentPage = new AgendaPage(
    CuramConst.kParticipant_mergeEmploymentPage, kMergeEmploymentPageDesc,
    CuramConst.kSUBMIT_ON_NEXT, CuramConst.kNON_INITIAL_PAGE);

  // BEGIN, CR00099404, CM
  /**
   * A constant to describe the agenda page name for foreign residencies.
   */
  protected AgendaPage participant_mergeForeignResidenciesPage = new AgendaPage(
    CuramConst.kParticipant_mergeForeignResidenciesPage,
    kMergeForeignResidencesPageDesc, CuramConst.kSUBMIT_ON_NEXT,
    CuramConst.kNON_INITIAL_PAGE);

  // END, CR00099404

  /**
   * A constant to describe the agenda page name for notes.
   */
  protected AgendaPage participant_mergeNotesPage = new AgendaPage(
    CuramConst.kParticipant_mergeNotesPage, kMergeNotesPageDesc,
    CuramConst.kSUBMIT_ON_NEXT, CuramConst.kNON_INITIAL_PAGE);

  /**
   * A constant to describe the agenda page name for phone numbers.
   */
  protected AgendaPage participant_mergePhoneNumbersPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergePhoneNumberEvidencePage
      : CuramConst.kParticipant_mergePhoneNumbersPage,
      kMergePhoneNumbersPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kNON_INITIAL_PAGE);

  // END, CR00353792

  /**
   * A constant to describe the agenda page name for relationships.
   */
  // BEGIN, CR00355808, ZV
  protected AgendaPage participant_mergeRelationshipsPage = new AgendaPage(
    pdcEnabledInd
      ? CuramConst.gkParticipant_mergeRelationshipEvidencePage
      : CuramConst.kParticipant_mergeRelationshipsPage,
      kMergeRelationshipsPageDesc,
      CuramConst.kSUBMIT_ON_NEXT,
      CuramConst.kNON_INITIAL_PAGE);

  // END, CR00355808

  /**
   * A constant to describe the agenda page name for web addresses.
   */
  protected AgendaPage participant_mergeWebAddressesPage = new AgendaPage(
    CuramConst.kParticipant_mergeWebAddressesPage, kMergeWebAddressesPageDesc,
    CuramConst.kSUBMIT_ON_NEXT, CuramConst.kNON_INITIAL_PAGE);

  // BEGIN, CR00144945, SS
  /**
   * A constant to describe the agenda page name for special cautions.
   */
  protected AgendaPage participant_mergeSpecialCautionPage = new AgendaPage(
    CuramConst.kParticipant_mergeSpecialCautionPage,
    kMergeSpecialCautionPageDesc, CuramConst.kSUBMIT_ON_NEXT,
    CuramConst.kNON_INITIAL_PAGE);

  // END, CR00144945, SS

  // BEGIN, CR00100109, PDN
  /**
   * A constant to describe the agenda page name for summary page.
   */
  protected String mergeAgendaSummaryPage = CuramConst.kParticipant_mergeSummaryPage;

  /**
   * A constant to describe the agenda page name for exit page.
   */
  protected String mergeAgendaExitPage = CuramConst.kParticipant_listDuplicates;

  // END, CR00100109
  // END, CR00278786

  // BEGIN, CR00102618, CSH
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypeDuplicatePerson = XmlMetaDataConst.kTypeDuplicatePerson;

  // END, CR00102618

  // BEGIN, CR00353792, ZV
  protected static final boolean pdcEnabledInd = Configuration.getBooleanProperty(
    EnvVars.ENV_PDC_ENABLED);

  // END, CR00353792

  /**
   * This method retrieves a list pages needed for a client merge
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   *
   * @return XML client data for the Agenda client
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AgendaDetails getAgenda(ClientMergeAgendaKey key)
    throws AppException, InformationalException {

    AgendaDetails retval = new AgendaDetails();

    // Decide if this is an existing client merge or a new client merge
    final ConcernRoleMerge concernRoleMergeObj = ConcernRoleMergeFactory.newInstance();
    final ReadByConcernRoleDuplicateIDKey readByConcernRoleDuplicateIDKey = new ReadByConcernRoleDuplicateIDKey();

    readByConcernRoleDuplicateIDKey.concernRoleDuplicateID = key.concernRoleDuplicateID;

    final ConcernRoleMergeDtlsList concernRoleMergeDtlsList = concernRoleMergeObj.searchByConcernRoleDuplicateID(
      readByConcernRoleDuplicateIDKey);

    if (concernRoleMergeDtlsList.dtls.size() == 0) {
      // Start a new client merge
      retval = startMerge(key);
    } else {
      // Continue an in progress client merge
      retval = continueInProgressMerge(key, concernRoleMergeDtlsList);
    }

    return retval;
  }

  /**
   * This method creates a Concern Role Merge entity for the client merge and
   * builds the agenda data xml for a new client merge
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   *
   * @return XML client data for the Agenda client
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected AgendaDetails startMerge(ClientMergeAgendaKey key)
    throws AppException, InformationalException {

    // END, CR00198672
    // Create a concern role merge record with the relevant details
    final ConcernRoleMerge concernRoleMerge = ConcernRoleMergeFactory.newInstance();

    final ConcernRoleMergeDtls concernRoleMergeDtls = new ConcernRoleMergeDtls();

    concernRoleMergeDtls.concernRoleDuplicateID = key.concernRoleDuplicateID;
    concernRoleMergeDtls.mergeStatus = MERGESTATUS.NOTMERGED;

    // System User Details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // BEGIN, CR00100431, CSH
    // Record the user who begins the merge process
    concernRoleMergeDtls.mergeStartedBy = systemUserObj.getUserDetails().userName;
    // END, CR00100431

    // BEGIN, CR00398053, MV
    concernRoleMergeDtls.mergeStartDate = DateTime.getCurrentDateTime();
    concernRoleMergeDtls.mergeStatus = MERGESTATUS.INMERGE;
    // END, CR00398053

    concernRoleMerge.insert(concernRoleMergeDtls);

    // Get the agenda xml details
    final AgendaDetails agendaDetails = getAgendaDetailsForAllPages(key,
      concernRoleMergeDtls);

    agendaDetails.concernRoleMergeID = concernRoleMergeDtls.concernRoleMergeID;

    return agendaDetails;
  }

  /**
   * This method builds the agenda data xml for an in progress client merge
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @param concernRoleMergeDtlsList
   * contains the details of the existing concern role merge in
   * progress.
   *
   * @return XML client data for the Agenda client
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected AgendaDetails continueInProgressMerge(ClientMergeAgendaKey key,
    ConcernRoleMergeDtlsList concernRoleMergeDtlsList) throws AppException,
      InformationalException {

    // END, CR00198672
    // Get the agenda xml details
    final AgendaDetails agendaDetails = getAgendaDetailsForAllPages(key,
      concernRoleMergeDtlsList.dtls.item(0));

    agendaDetails.concernRoleMergeID = concernRoleMergeDtlsList.dtls.item(0).concernRoleMergeID;

    return agendaDetails;
  }

  /**
   * This method gets the agenda xml details for all pages
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @param concernRoleMergeDtls
   * ConcernRoleMerge record details
   *
   * @return XML client data for the Agenda client
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected AgendaDetails getAgendaDetailsForAllPages(
    ClientMergeAgendaKey key, ConcernRoleMergeDtls concernRoleMergeDtls)
    throws AppException, InformationalException {

    // END, CR00198672
    final Agenda theAgenda = new Agenda();
    final AgendaHelper agendaBuilder = new AgendaHelper(theAgenda);
    final AgendaDetails retval = new AgendaDetails();

    // If there is the duplicate entity for the concern then add the page to
    // the agenda
    if (checkForClientAddresses(key.duplicateConcernRoleID)) {
      participant_mergeAddressesPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientAlternativeIDs(key.duplicateConcernRoleID)) {
      participant_mergeAlternativeIDsPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientAlternativeNames(key.duplicateConcernRoleID)) {
      participant_mergeAlternativeNamesPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientForBankAccounts(key.duplicateConcernRoleID)) {
      participant_mergeBankAccountsPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientCitizenships(key.duplicateConcernRoleID)) {
      participant_mergeCitizenshipsPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientCommunicationExceptions(key.duplicateConcernRoleID)) {
      participant_mergeCommunicationExceptionsPage.addPageToAgenda(
        agendaBuilder);
    }
    if (checkForClientContacts(key.duplicateConcernRoleID)) {
      participant_mergeContactsPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientEducation(key.duplicateConcernRoleID)) {
      participant_mergeEducationPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientEmailAddresses(key.duplicateConcernRoleID)) {
      participant_mergeEmailAddressesPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientEmployment(key.duplicateConcernRoleID)) {
      participant_mergeEmploymentPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientForeignResidences(key.duplicateConcernRoleID)) {
      // BEGIN, CR00099404, CM
      participant_mergeForeignResidenciesPage.addPageToAgenda(agendaBuilder);
      // END, CR00099404
    }
    if (checkForClientNotes(key.duplicateConcernRoleID)) {
      participant_mergeNotesPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientPhoneNumbers(key.duplicateConcernRoleID)) {
      participant_mergePhoneNumbersPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientRelationships(key.duplicateConcernRoleID)) {
      participant_mergeRelationshipsPage.addPageToAgenda(agendaBuilder);
    }
    if (checkForClientWebAddresses(key.duplicateConcernRoleID)) {
      participant_mergeWebAddressesPage.addPageToAgenda(agendaBuilder);
    }
    // BEGIN, CR00144945, SS
    if (checkForClientSpecialCaution(key.duplicateConcernRoleID)) {
      participant_mergeSpecialCautionPage.addPageToAgenda(agendaBuilder);
    }
    // END, CR00144945

    // Set the Participant_mergeSummaryPage as the summary page for client
    // merge.
    // BEGIN, CR00100109, PDN
    agendaBuilder.setAgendaSummary(mergeAgendaSummaryPage,
      kMergeSummaryPageDesc, true);
    // END, CR00100109

    // Find the context description for this concern role
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00100200, PDN
    concernRoleKey.concernRoleID = key.originalConcernRoleID;
    final ConcernRoleDtls originalConcernRoleDtls = concernRoleObj.read(
      concernRoleKey);

    concernRoleKey.concernRoleID = key.duplicateConcernRoleID;
    final ConcernRoleDtls duplicateConcernRoleDtls = concernRoleObj.read(
      concernRoleKey);

    final String contextDescription = duplicateConcernRoleDtls.concernRoleName
      + CuramConst.kSeparator + duplicateConcernRoleDtls.primaryAlternateID
      + CuramConst.gkStringTo + originalConcernRoleDtls.concernRoleName
      + CuramConst.kSeparator + originalConcernRoleDtls.primaryAlternateID;

    // END, CR00100200

    // Add the page parameters
    agendaBuilder.addParameterToAgenda(CuramConst.koriginalConcernRoleID,
      StringHelper.EMPTY_STRING + key.originalConcernRoleID);
    agendaBuilder.addParameterToAgenda(CuramConst.kduplicateConcernRoleID,
      StringHelper.EMPTY_STRING + key.duplicateConcernRoleID);
    agendaBuilder.addParameterToAgenda(CuramConst.kcontextDescription,
      StringHelper.EMPTY_STRING + contextDescription);
    agendaBuilder.addParameterToAgenda(CuramConst.kconcernRoleMergeID,
      StringHelper.EMPTY_STRING + concernRoleMergeDtls.concernRoleMergeID);
    agendaBuilder.addParameterToAgenda(CuramConst.kconcernRoleDuplicateID,
      StringHelper.EMPTY_STRING + concernRoleMergeDtls.concernRoleDuplicateID);

    // BEGIN, CR00100109, PDN
    // Specify the exit page and its parameters depending if this is
    // from the view page
    agendaBuilder.setAgendaExitPage(mergeAgendaExitPage);

    if (mergeAgendaExitPage.equals(CuramConst.kParticipant_viewDuplicate)) {
      agendaBuilder.addParameterToAgendaExitPage(
        CuramConst.kconcernRoleDuplicateID,
        StringHelper.EMPTY_STRING + key.concernRoleDuplicateID);
    } else {
      agendaBuilder.addParameterToAgendaExitPage(CuramConst.kconcernRoleID,
        StringHelper.EMPTY_STRING + key.originalConcernRoleID);
    }
    // END, CR00100109

    retval.agenda = agendaBuilder.getXml();

    return retval;

  }

  /**
   * This method ends the client merge by updating the concern role merge record
   * to status merge complete.
   *
   * @param key
   * concern role merge record ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void endMerge(EndMergeKey key) throws AppException,
      InformationalException {

    // Modify a concern role merge record to be complete
    final ConcernRoleMerge concernRoleMerge = ConcernRoleMergeFactory.newInstance();
    final ConcernRoleMergeKey concernRoleMergeKey = new ConcernRoleMergeKey();

    concernRoleMergeKey.concernRoleMergeID = key.concernRoleMergeID;

    ConcernRoleMergeDtls concernRoleMergeDtls = new ConcernRoleMergeDtls();

    concernRoleMergeDtls = concernRoleMerge.read(concernRoleMergeKey);

    // Set the end date of the merge and end status
    concernRoleMergeDtls.mergeEndDate = DateTime.getCurrentDateTime();
    concernRoleMergeDtls.mergeStatus = MERGESTATUS.MERGECOMPLETE;

    // BEGIN, CR00100431, CSH
    // Record the user who completes the merge process
    // System User Details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    concernRoleMergeDtls.mergeCompletedBy = systemUserObj.getUserDetails().userName;
    // END, CR00100431

    concernRoleMerge.modify(concernRoleMergeKey, concernRoleMergeDtls);

  }

  // BEGIN, CR00102593, PDN

  /**
   * This method ends the client merge by updating the concern role merge record
   * to status merge complete and checks relevant business rules.
   *
   * @param details
   * concern role merge record ID and original concern role id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void completeMerge(ConcernRoleDetailsForMerge details)
    throws AppException, InformationalException {

    clientMergeObj.completeMerge(details.dtls);

  }

  // END, CR00102593

  /**
   * This method fetches some concern role details for either a person or
   * prospect person whose concern role id is supplied.
   *
   * @param key
   * contains the person or prospect person concern role id.
   *
   * @return SearchDisplayDetails with details of the concern role.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public SearchDisplayDetails searchDuplicateDisplay(SearchDisplayKey key)
    throws AppException, InformationalException {

    final SearchDisplayDetails searchDisplayDetails = new SearchDisplayDetails();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Determine if this is a person or prospect person
    if (concernRoleDtls.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PERSON)) {
      final curam.core.facade.intf.Person personObj = PersonFactory.newInstance();
      final ReadPersonKey readPersonKey = new ReadPersonKey();

      readPersonKey.maintainConcernRoleKey.concernRoleID = key.concernRoleID;

      final ReadPersonDetails readPersonDetails = personObj.readPerson(
        readPersonKey);

      searchDisplayDetails.dateOfBirth = readPersonDetails.personFurtherDetails.dateOfBirth;
      searchDisplayDetails.firstName = readPersonDetails.personFurtherDetails.firstForename;
      searchDisplayDetails.lastName = readPersonDetails.personFurtherDetails.surname;
      searchDisplayDetails.gender = readPersonDetails.personFurtherDetails.sex;

    } else {
      final curam.core.facade.intf.ProspectPerson prospectPersonObj = ProspectPersonFactory.newInstance();
      final ReadProspectPersonKey readProspectPersonKey = new ReadProspectPersonKey();

      readProspectPersonKey.maintainConcernRoleKey.concernRoleID = key.concernRoleID;

      final ReadProspectPersonDtls readProspectPersonDtls = prospectPersonObj.readProspectPerson(
        readProspectPersonKey);

      searchDisplayDetails.dateOfBirth = readProspectPersonDtls.dtls.dateOfBirth;
      searchDisplayDetails.firstName = readProspectPersonDtls.dtls.firstForename;
      searchDisplayDetails.lastName = readProspectPersonDtls.dtls.surname;
      searchDisplayDetails.gender = readProspectPersonDtls.dtls.gender;

    }

    return searchDisplayDetails;

  }

  // BEGIN CR00232224, ZV
  /**
   * This method searches for duplicate persons and prospect persons and filters
   * the return list to remove any items that are already duplicates.
   *
   * @param key
   * contains the search criteria.
   *
   * @return PersonAndProspectPersonSearchResult list of persons and prospect
   * persons and some of their details for supplied search key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchNonDuplicatePerson()}. See release note:
   * CR00232224
   */
  @Override
  @Deprecated
  public PersonAndProspectPersonSearchResult searchDuplicate(
    ProspectPersonSearchKey key) throws AppException, InformationalException {

    final ProspectPerson ProspectPersonObj = ProspectPersonFactory.newInstance();

    // Client merge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // ConcernRole Key
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Search person and prospect person
    final PersonAndProspectPersonSearchResult personAndProspectPersonSearchResult = ProspectPersonObj.searchPersonsAndProspectPersons(
      key);

    // Filter the Person list for any duplicate persons
    for (int i = 0; i
      < personAndProspectPersonSearchResult.personAndProspectPersonSearchResult.pDetails.dtls.size(); i++) {

      concernRoleKey.concernRoleID = personAndProspectPersonSearchResult.personAndProspectPersonSearchResult.pDetails.dtls.item(i).concernRoleID;

      // If the person is a duplicate then remove it from the result
      if (clientMergeObj.isConcernRoleDuplicate(concernRoleKey).statusInd) {
        personAndProspectPersonSearchResult.personAndProspectPersonSearchResult.pDetails.dtls.remove(
          i);
        i--;
      }
    }

    // Filter the Prospect Person list for any duplicate prospect persons
    for (int i = 0; i
      < personAndProspectPersonSearchResult.personAndProspectPersonSearchResult.ppDetails.dtls.size(); i++) {

      concernRoleKey.concernRoleID = personAndProspectPersonSearchResult.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).concernRoleID;

      // If the prospect person is a duplicate then remove it from the result
      if (clientMergeObj.isConcernRoleDuplicate(concernRoleKey).statusInd) {
        personAndProspectPersonSearchResult.personAndProspectPersonSearchResult.ppDetails.dtls.remove(
          i);
        i--;
      }
    }

    return personAndProspectPersonSearchResult;
  }

  // END CR00232224

  /**
   * This method marks a concern role as a duplicate.
   *
   * @param details
   * the details of the duplicate concern role.
   *
   * @return MarkDuplicateDetails containing the Concern Roles and Concern Role
   * Duplicate record ID
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public MarkDuplicateDetails markDuplicate(MarkDuplicateCreateDetails details) throws AppException,
      InformationalException {

    final MarkDuplicateDetails markDuplicateDetails = new MarkDuplicateDetails();

    final curam.core.sl.intf.ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    markDuplicateDetails.markDuplicateDetails = clientMergeObj.markDuplicate(
      details.markDuplicateCreateDetails);

    return markDuplicateDetails;
  }

  // BEGIN, CR00225203, ZV
  /**
   * This method gets the details of the original concern role and duplicate
   * concern role.
   *
   * @param key
   * contains the original and duplicate concern role id's.
   *
   * @return OriginalAndDuplicateDetails containing details of the original and
   * duplicate concern roles.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #readOriginalAndDuplicateDetails1()}.
   */
  @Override
  @Deprecated
  public OriginalAndDuplicateDetails readOriginalAndDuplicateDetails(
    final OriginalAndDuplicateKey key) throws AppException,
      InformationalException {

    final OriginalAndDuplicateDetails originalAndDuplicateDetails = new OriginalAndDuplicateDetails();

    originalAndDuplicateDetails.assign(readOriginalAndDuplicateDetails1(key));

    return originalAndDuplicateDetails;
  }

  // END, CR00225203

  /**
   * This method retrieves a list of foreign residency details for both the
   * original and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of foreign residencies for both original and duplicate
   * participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ForeignResidencyMergeList listForeignResidenciesForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // Return struct
    final ForeignResidencyMergeList foreignResidencyMergeList = new ForeignResidencyMergeList();

    // Client Merge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // List foreign residency for merge
    foreignResidencyMergeList.dtlsList = clientMergeObj.listForeignResidenciesForMerge(
      key.key);

    return foreignResidencyMergeList;
  }

  // BEGIN, CR00231506, PDN
  /**
   * This method retrieves a list of participant note details for both the
   * original and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of participant notes for both original and duplicate
   * participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated - replaced by {@link #listNotesForMerge1()}
   * @deprecated -since Version 6.0
   */
  @Override
  @Deprecated
  public NoteMergeList listNotesForMerge(ClientMergeParticipantKey key)
    throws AppException, InformationalException {

    // Return struct
    final NoteMergeList noteMergeList = new NoteMergeList();

    // Client Merge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // List notes for merge
    noteMergeList.dtlsList = clientMergeObj.listNotesForMerge(key.key);

    return noteMergeList;
  }

  /**
   * This method retrieves a list of participant note details for both the
   * original and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of participant notes for both original and duplicate
   * participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public NoteMergeList1 listNotesForMerge1(ClientMergeParticipantKey key)
    throws AppException, InformationalException {

    // Return struct
    final NoteMergeList1 noteMergeList1 = new NoteMergeList1();

    // Client Merge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // List notes for merge
    noteMergeList1.dtlsList = clientMergeObj.listNotesForMerge1(key.key);

    return noteMergeList1;
  }

  // END, CR00231506

  /**
   * This method retrieves a list of phone number details for both the original
   * and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of phone numbers for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public PhoneNumberMergeList listPhoneNumbersForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // Return struct
    final PhoneNumberMergeList phoneNumberMergeList = new PhoneNumberMergeList();

    // Client Merge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // List phone numbers for merge
    phoneNumberMergeList.dtlsList = clientMergeObj.listPhoneNumbersForMerge(
      key.key);

    return phoneNumberMergeList;
  }

  /**
   * This method retrieves a list of relationship details for both the original
   * and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of relationships for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public RelationshipMergeList listRelationshipsForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // Return struct
    final RelationshipMergeList relationshipMergeList = new RelationshipMergeList();

    // Client Merge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // List relationships for merge
    relationshipMergeList.dtlsList = clientMergeObj.listRelationshipsForMerge(
      key.key);

    return relationshipMergeList;
  }

  /**
   * This method merges selected foreign residencies from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeForeignResidencies(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate foreign residencies with original participant's
    clientMergeObj.mergeForeignResidencies(details.dtls, tabList);
  }

  /**
   * This method merges selected participant notes from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeNotes(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate notes with original participant's
    clientMergeObj.mergeNotes(details.dtls, tabList);

  }

  /**
   * This method merges selected foreign residencies from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergePhoneNumbers(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate phone numbers with original participant's
    clientMergeObj.mergePhoneNumbers(details.dtls, tabList);

  }

  /**
   * This method merges selected relationships from the duplicate concernRole to
   * the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeRelationships(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate relationship with original participant's
    clientMergeObj.mergeRelationships(details.dtls, tabList);

  }

  /**
   * This method retrieves a list of web address details for both the original
   * and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of web addresses for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public WebAddressMergeList listWebAddressesForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // Return struct
    final WebAddressMergeList webAddressMergeList = new WebAddressMergeList();

    // Client Merge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // list web addresses for merge
    webAddressMergeList.dtlsList = clientMergeObj.listWebAddressForMerge(
      key.key);

    return webAddressMergeList;
  }

  /**
   * This method merges selected web addresses from the duplicate concernRole to
   * the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeWebAddress(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate web addresses with original participant's
    clientMergeObj.mergeWebAddresses(details.dtls, tabList);
  }

  /**
   * This method retrieves a list of address details for both the original and
   * duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of addresses for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AddressMergeList listAddressesForMerge(ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final AddressMergeList addressMergeList = new AddressMergeList();

    // return list of addresses for both the original and duplicate participants
    addressMergeList.dtlsList = clientMergeObj.listAddressesForMerge(key.key);

    // BEGIN, CR00102618, CSH
    // Inform the user that once they select next in the merge wizard,
    // any selected data will be merged
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final AppException e = new AppException(
      BPOCLIENTMERGE.INF_SELECTED_DATA_WILL_BE_MERGED);

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
      e.arg(true), CuramConst.gkEmpty,
      curam.util.exception.InformationalElement.InformationalType.kWarning,
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    // Obtain the informational(s) to be returned to the client
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      addressMergeList.dtlsList.origList.messages.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00102618

    return addressMergeList;
  }

  /**
   * This method merges selected addresses from the duplicate concernRole to the
   * original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeAddresses(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate addresses with original participant's
    clientMergeObj.mergeAddresses(details.dtls, tabList);
  }

  /**
   * Check if Address entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientAddresses(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleAddress manipulation variables
    final MaintainConcernRoleAddress maintainConcernRoleAddressObj = MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    // populate key for original concernRole
    maintainAddressKey.concernRoleID = concernRoleID;

    // BEGIN, CR00221607, MC
    // BEGIN, CR00353792, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCADDRESS;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_ADDRESSES);
    } else {
      // read back list of addresses for concernRole
      if (maintainConcernRoleAddressObj.readmultiByConcernRoleID(maintainAddressKey).details.dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_ADDRESSES)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00353792
    // END, CR00221607
  }

  /**
   * Check if AlternativeID entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientAlternativeIDs(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleAltID manipulation variables
    final MaintainConcernRoleAltID maintainConcernRoleAltIDObj = MaintainConcernRoleAltIDFactory.newInstance();
    final MaintainConcernRoleAltIDKey maintainConcernRoleAltIDKey = new MaintainConcernRoleAltIDKey();

    // populate key with the concernRole
    maintainConcernRoleAltIDKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // BEGIN, CR00353792, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCIDENTIFICATION;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_ALTERNATIVE_IDS);

    } else {
      // read back list of AlternativeIDs for concernRole
      if (maintainConcernRoleAltIDObj.readmultiByConcernRoleID(maintainConcernRoleAltIDKey).details.dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_ALTERNATIVE_IDS)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00353792
    // END, CR00221607
  }

  /**
   * Check if AlternativeName entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientAlternativeNames(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainPersonNames manipulation variables
    final MaintainPersonNames maintainPersonNamesObj = MaintainPersonNamesFactory.newInstance();
    final MaintainPersonNameKey maintainPersonNameKey = new MaintainPersonNameKey();

    // populate key with the concernRole
    maintainPersonNameKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // BEGIN, CR00353792, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCNAME;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_ALTERNATE_NAMES);

    } else {
      // read back list of AlternativeNames for concernRole
      if (maintainPersonNamesObj.readmultiByConcernRole(maintainPersonNameKey).dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_ALTERNATE_NAMES)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00353792
    // END, CR00221607
  }

  /**
   * Check if BankAccount entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientForBankAccounts(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleBankAc manipulation variables
    final MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = MaintainConcernRoleBankAcFactory.newInstance();
    final MaintainBankAccountKey maintainBankAccountOrigKey = new MaintainBankAccountKey();

    // populate key with the concernRole
    maintainBankAccountOrigKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // BEGIN, CR00353792, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCBANKACCOUNT;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_BANK_ACCOUNTS);

    } else {
      // read back list of BankAccount for concernRole
      if (maintainConcernRoleBankAcObj.readmultiByConcernRole(maintainBankAccountOrigKey).details.dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_BANK_ACCOUNTS)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00353792
    // END, CR00221607
  }

  /**
   * Check if Citizenship entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientCitizenships(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainCitizenship manipulation variables
    final MaintainCitizenship maintainCitizenshipObj = MaintainCitizenshipFactory.newInstance();
    final MaintainCitizenshipKey maintainCitizenshipKey = new MaintainCitizenshipKey();

    // populate key with the concernRole
    maintainCitizenshipKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of Citizenships for concernRole
    if (maintainCitizenshipObj.readmultiByConcernRole(maintainCitizenshipKey).dtls.size()
      != 0
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_CITIZENSHIPS)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if CommunicationException entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientCommunicationExceptions(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleCommException manipulation variables
    final MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = MaintainConcernRoleCommExceptionFactory.newInstance();
    final MaintainCommExceptionKey maintainCommExceptionKey = new MaintainCommExceptionKey();

    // populate key with the concernRole
    maintainCommExceptionKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of Communication for concernRole
    if (maintainConcernRoleCommExceptionObj.readmultiByConcernRole(maintainCommExceptionKey).dtls.size()
      != 0
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_COMMUNICATION_EXCEPTIONS)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if Contact entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientContacts(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleContact manipulation variables
    final MaintainContacts maintainContactsObj = MaintainContactsFactory.newInstance();
    final ContactRMByConcernKey contactRMByConcernKey = new ContactRMByConcernKey();

    // populate key with the concernRole
    contactRMByConcernKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of Contacts for concernRole
    // BEGIN, CR00294967, MV
    if (0
      != maintainContactsObj.readmultiConcernContactByConcernRoleID(contactRMByConcernKey).dtls.size()
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_CONTACTS)) {
      // END, CR00294967
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if Education entity has duplicates
   *
   * @param concernRoleID
   * Duplicate concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientEducation(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainPersonEducation manipulation variables
    final MaintainPersonEducation maintainPersonEducationObj = MaintainPersonEducationFactory.newInstance();
    final EducationByConcernKey educationByConcernKey = new EducationByConcernKey();

    // populate key with the concernRole
    educationByConcernKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of Education for concernRole
    if (maintainPersonEducationObj.readByConcernRole(educationByConcernKey).dtls.size()
      != 0
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_EDUCATION_DETAILS)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if EmailAddresses entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientEmailAddresses(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleEmail manipulation variables
    final MaintainConcernRoleEmail maintainConcernRoleEmailObj = MaintainConcernRoleEmailFactory.newInstance();
    final MaintainEmailKey maintainEmailKey = new MaintainEmailKey();

    // populate key with the concernRole
    maintainEmailKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // BEGIN, CR00353792, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCEMAILADDRESS;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_EMAIL_ADDRESSES);

    } else {
      // read back list of EmailAddresses for concernRole
      if (maintainConcernRoleEmailObj.readmultiByConcernRole(maintainEmailKey).details.dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_EMAIL_ADDRESSES)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00353792
    // END, CR00221607
  }

  /**
   * Check if Employment entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientEmployment(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainPersonEmployment manipulation variables
    final MaintainPersonEmployment maintainPersonEmploymentObj = MaintainPersonEmploymentFactory.newInstance();
    final MaintainPersonEmploymentKey maintainPersonEmploymentKey = new MaintainPersonEmploymentKey();

    // populate key with the concernRole
    maintainPersonEmploymentKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of Employment for concernRole
    if (maintainPersonEmploymentObj.readmultiByConcernRoleID(maintainPersonEmploymentKey).details.dtls.size()
      != 0
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_EMPLOYMENT_DETAILS)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if ForeignResidences entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientForeignResidences(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainForeignResidency manipulation variables
    final MaintainForeignResidency maintainForeignResidencyObj = MaintainForeignResidencyFactory.newInstance();
    final MaintainForeignResidencyKey maintainForeignResidencyKey = new MaintainForeignResidencyKey();

    // populate key with the concernRole
    maintainForeignResidencyKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of ForeignResidences for concernRole
    if (maintainForeignResidencyObj.readmultiByConcernRole(maintainForeignResidencyKey).dtls.size()
      != 0
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_FOREIGN_RESIDENCIES)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if Notes entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientNotes(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // ParticipantNote manipulation variables
    final ParticipantNote participantNoteObj = ParticipantNoteFactory.newInstance();
    final ParticipantKey participantKey = new ParticipantKey();

    // populate key with the concernRole
    participantKey.key.participantID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of Notes for concernRole
    if (participantNoteObj.list1(participantKey).details.size() != 0
      && Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_NOTES)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Check if the phone number entity has duplicates.
   *
   * @boread ConcernRole
   *
   * @boread ConcernRolePhone
   * @param concernRoleID Concern role identifier for the participant.
   *
   * @return True if there are duplicates for the concern role.
   */
  // BEGIN, CR00198672, VK
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public boolean checkForClientPhoneNumbers(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRolePhone object
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();

    // populate key with the concernRole
    maintainPhoneNumberKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // BEGIN, CR00353792, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCPHONENUMBER;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_PHONE_NUMBERS);

    } else {
      // read back list of PhoneNumbers for concernRole
      if (maintainConcernRolePhoneObj.readmultiByConcernRole(maintainPhoneNumberKey).details.dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_PHONE_NUMBERS)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00353792
    // END, CR00221607
  }

  /**
   * Check if the relationships entity has duplicates.
   *
   * @boread ConcernRole
   *
   * @boread ConcernRoleRelationship
   * @param concernRoleID Concern role identifier for the participant.
   *
   * @return True if there are duplicates for the concern role.
   */
  // BEGIN, CR00198672, VK
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public boolean checkForClientRelationships(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // MaintainConcernRoleRelationships Object
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();
    final RelationshipsByConcernRoleIDKey relationshipsByConcernRoleIDKey = new RelationshipsByConcernRoleIDKey();

    // populate key with the concernRole
    relationshipsByConcernRoleIDKey.concernRoleID = concernRoleID;

    // BEGIN, CR00221607, MC
    // BEGIN, CR00355808, ZV
    if (pdcEnabledInd) {
      final EvidenceTypeAndParticipantIDDetails evidenceTypeAndParticipantIDDetails = new EvidenceTypeAndParticipantIDDetails();

      evidenceTypeAndParticipantIDDetails.participantID = concernRoleID;
      evidenceTypeAndParticipantIDDetails.evidenceType = PDCConst.PDCRELATIONSHIPS;
      return checkForClientEvidence(evidenceTypeAndParticipantIDDetails).flag
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_RELATIONSHIPS);

    } else {
      // read back list of Relationships for concernRole
      if (maintainConcernRoleRelationshipsObj.readmultiByConcernRoleID(relationshipsByConcernRoleIDKey).dtls.size()
        != 0
          && Configuration.getBooleanProperty(
            EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_RELATIONSHIPS)) {
        return true;
      } else {
        return false;
      }
    }
    // END, CR00355808
    // END, CR00221607
  }

  /**
   * Check if WebAddresses entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected boolean checkForClientWebAddresses(long concernRoleID)
    throws AppException, InformationalException {

    // END, CR00198672
    // Web Address object
    final curam.core.sl.intf.WebAddress webAddressObj = curam.core.sl.fact.WebAddressFactory.newInstance();
    final ConcernRoleIDKey concernRoleIDKey = new ConcernRoleIDKey();

    // populate key with the concernRole
    concernRoleIDKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of WebAddresses for concernRole
    if (webAddressObj.list(concernRoleIDKey).details.size() != 0
      && Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_WEB_ADDRESSES)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * This method retrieves a list of communication exception details for both
   * the original and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of communication exceptions for both original and duplicate
   * participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CommExceptionMergeList listCommExceptionsForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // Return struct
    final CommExceptionMergeList commExceptionMergeList = new CommExceptionMergeList();

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Return list of addresses for both the original and
    // duplicate participants
    commExceptionMergeList.dtlsList = clientMergeObj.listCommExceptionsForMerge(
      key.key);

    return commExceptionMergeList;
  }

  /**
   * This method merges selected communication exceptions from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeCommExceptions(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Merge selected duplicate communication exceptions
    // with original participant's
    clientMergeObj.mergeCommExceptions(details.dtls, tabList);
  }

  /**
   * This method retrieves a list of alternativeID details for the specified
   * concern role.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   *
   * @return List of alternativeIDs for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AlternativeIDMergeList listAlternativeIDsForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final AlternativeIDMergeList alternativeIDMergeList = new AlternativeIDMergeList();

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // return list of citizenships for both the original and duplicate
    // participants
    alternativeIDMergeList.dtlsList = clientMergeObj.listAlternativeIDsForMerge(
      key.key);

    return alternativeIDMergeList;
  }

  /**
   * This method retrieves a list of alternative name details for both the
   * original and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of alternative names for both original and duplicate
   * participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AlternativeNameMergeList listAlternativeNamesForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final AlternativeNameMergeList alternativeNameMergeList = new AlternativeNameMergeList();

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // return list of alternativeNames for both the original and duplicate
    // participants
    alternativeNameMergeList.dtlsList = clientMergeObj.listAlternativeNamesForMerge(
      key.key);

    return alternativeNameMergeList;
  }

  /**
   * This method retrieves a list of bankAccount details for the specified
   * concern role.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   *
   * @return List of bankAccounts for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BankAccountMergeList listBankAccountsForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final BankAccountMergeList bankAccountMergeList = new BankAccountMergeList();

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // return list of bankAccounts for both the original and duplicate
    // participants
    bankAccountMergeList.dtlsList = clientMergeObj.listBankAccountsForMerge(
      key.key);

    return bankAccountMergeList;
  }

  /**
   * This method retrieves a list of citizenship details for both the original
   * and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of citizenships for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CitizenshipMergeList listCitizenshipsForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final CitizenshipMergeList citizenshipMergeList = new CitizenshipMergeList();

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // return list of citizenships for both the original and duplicate
    // participants
    citizenshipMergeList.dtlsList = clientMergeObj.listCitizenshipsForMerge(
      key.key);

    return citizenshipMergeList;
  }

  /**
   * This method merges selected alternativeIDs from the duplicate concernRole
   * to that of the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited alternativeIDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeAlternativeIDs(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate alternativeIDs with original participant's
    clientMergeObj.mergeAlternativeIDs(details.dtls, tabList);
  }

  /**
   * This method merges selected alternative names from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeAlternativeNames(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate alternativeNames with original participant's
    clientMergeObj.mergeAlternativeNames(details.dtls, tabList);
  }

  /**
   * This method merges selected bankAccounts from the duplicate concernRole to
   * that of the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited bankAccountIDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeBankAccounts(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate bankAccounts with original participant's
    clientMergeObj.mergeBankAccounts(details.dtls, tabList);
  }

  /**
   * This method merges selected citizenships from the duplicate concernRole to
   * the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeCitizenships(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate citizenships with original participant's
    clientMergeObj.mergeCitizenships(details.dtls, tabList);
  }

  // BEGIN, CR00294967, MV
  /**
   * This method retrieves a list of contact details for both the original and
   * duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of contacts for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #listConcernContactsForMerge()}. The return struct of
   * the current method listContactsForMerge has an aggregation to
   * the struct ConcernContactRMDtls, the attribute statusCode in
   * the struct ConcernContactRMDtls is modeled with a domain of
   * CONTACTSTATUS code-table, but the corresponding entity
   * attribute ConcernRoleContactDtls.statusCode is modeled with a
   * domain of RECORD_STATUS_CODE. So new method is introduced to
   * return new struct ConcernContactMergeList which has an
   * aggregation to the new struct ConcernContactRMultiDtls where
   * the attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  @Override
  @Deprecated
  // END, CR00294967
  public ContactMergeList listContactsForMerge(ClientMergeParticipantKey key)
    throws AppException, InformationalException {

    // Return struct
    final ContactMergeList contactMergeList = new ContactMergeList();

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Return list of contacts for both the original and
    // duplicate participants
    contactMergeList.dtlsList = clientMergeObj.listContactsForMerge(key.key);

    return contactMergeList;
  }

  // BEGIN, CR00294967, MV
  /**
   * This method retrieves a list of contact details for both the original and
   * duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of contacts for both original and duplicate participants
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ConcernContactMergeList listConcernContactsForMerge(
    final ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final ConcernContactMergeList contactMergeList = new ConcernContactMergeList();

    final curam.core.sl.intf.ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Return list of contacts for both the original and
    // duplicate participants
    contactMergeList.dtlsList = clientMergeObj.listConcernContactsForMerge(
      key.key);

    return contactMergeList;
  }

  // END, CR00294967

  /**
   * This method retrieves a list of education details for both the original and
   * duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of education for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EducationMergeList listEducationForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final EducationMergeList educationMergeList = new EducationMergeList();

    // return list of education records for both the original and
    // duplicate participants
    educationMergeList.dtlsList = clientMergeObj.listEducationForMerge(key.key);

    return educationMergeList;
  }

  /**
   * This method retrieves a list of email address details for both the original
   * and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of email addresses for both original and duplicate
   * participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmailAddressMergeList listEmailAddressesForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final EmailAddressMergeList emailAddressMergeList = new EmailAddressMergeList();

    // return list of email addresses for both the original and
    // duplicate participants
    emailAddressMergeList.dtlsList = clientMergeObj.listEmailAddressesForMerge(
      key.key);

    return emailAddressMergeList;
  }

  /**
   * This method retrieves a list of employment details for both the original
   * and duplicate concern roles.
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   * @return List of employment for both original and duplicate participants
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmploymentMergeList listEmploymentForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // return struct
    final EmploymentMergeList employmentMergeList = new EmploymentMergeList();

    // return list of employment for both the original and
    // duplicate participants
    employmentMergeList.dtlsList = clientMergeObj.listEmploymentForMerge(
      key.key);

    return employmentMergeList;
  }

  /**
   * This method merges selected contacts from the duplicate concernRole to the
   * original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeContacts(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Merge selected duplicate contacts with original participant's
    clientMergeObj.mergeContacts(details.dtls, tabList);
  }

  /**
   * This method merges selected education from the duplicate concernRole to the
   * original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeEducation(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate education with original participant's
    clientMergeObj.mergeEducation(details.dtls, tabList);

  }

  /**
   * This method merges selected email addresses from the duplicate concernRole
   * to the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeEmailAddresses(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate email addresses with original participant's
    clientMergeObj.mergeEmailAddresses(details.dtls, tabList);

  }

  /**
   * This method merges selected employment from the duplicate concernRole to
   * the original concernRole.
   *
   * @param details
   * Concern role identifier, Concern role merge identifier
   * @param tabList
   * A list of tab delimited concern role record IDs
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeEmployment(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // ClientMerge service layer object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate employment with original participant's
    clientMergeObj.mergeEmployment(details.dtls, tabList);

  }

  // BEGIN, CR00223827, MC
  // ___________________________________________________________________________
  /**
   * This method returns a list of duplicates created for a concern role.
   *
   * @param key
   * The original concern role id
   * @return The duplicate list
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listDuplicatesForConcernRole1()}. The new method
   * returns the details as they were returned from the previous
   * method but it also returns some indicators that will be used to
   * display the list row menu actions.
   */
  @Override
  @Deprecated
  public DuplicatesForConcernRoleDtlsList listDuplicatesForConcernRole(
    final ConcernRoleKey key) throws AppException, InformationalException {

    // Return struct
    final DuplicatesForConcernRoleDtlsList duplicatesForConcernRoleDtlsList = new DuplicatesForConcernRoleDtlsList();

    // ClientMerge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // ConcernRole object
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // CuramInd struct
    CuramInd curamInd = new CuramInd();

    // ConcernRole struct
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    // END, CR00099931

    // BEGIN, CR00169613, VK
    // ParticipantContext structs
    ParticipantContextDescriptionDetails participantContextDescriptionDetails = new ParticipantContextDescriptionDetails();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Participant Context Object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // END, CR00169613

    // returns a list of duplicates for the concern role
    duplicatesForConcernRoleDtlsList.dtlsList = clientMergeObj.listDuplicatesForConcernRole(
      key);

    // read concern role table
    concernRoleDtls = concernRoleObj.read(key);

    // Set the indicator to default to true so that the mark new duplicate
    // link is displayed
    duplicatesForConcernRoleDtlsList.markNewDuplicateInd = true;

    // Check if the concern role is a prospect, if so the mark new duplicate
    // link should not be displayed
    if (concernRoleDtls.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {

      duplicatesForConcernRoleDtlsList.markNewDuplicateInd = false;
    }

    // Check if the concern role is a duplicate person,
    // if so the mark new duplicate link should not be displayed
    curamInd = clientMergeObj.isConcernRoleDuplicate(key);

    if (curamInd.statusInd) {

      duplicatesForConcernRoleDtlsList.markNewDuplicateInd = false;
    }
    // BEGIN, CR00169613, VK
    // Set context key
    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // get the context description for the concern role
    participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // set the context description
    duplicatesForConcernRoleDtlsList.contextDescription.description = participantContextDescriptionDetails.description;
    // END, CR00169613

    return duplicatesForConcernRoleDtlsList;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00281651, KRK
  /**
   * This method returns a list of duplicates created for a concern role.
   *
   *
   * @param key
   * The original concern role id.
   *
   * @return The duplicate list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link ClientMerge# listDuplicatesForConcernRoleDetails(ConcernRoleKey concernRoleKey)}
   * .
   * The current method displays the fields mergeStartDate and mergeEndDate
   * in DATE format. The new method displays these fields in DATETIME format for
   * a list of duplicates created for a concern role. See release note :
   * CS-08572/CR00281651.
   */
  @Override
  @Deprecated
  public DuplicatesConcernRoleDetailsList listDuplicatesForConcernRole1(
    final ConcernRoleKey key) throws AppException, InformationalException {

    // END, CR00281651

    final DuplicatesConcernRoleDetailsList duplicatesConcernRoleDetailsList = new DuplicatesConcernRoleDetailsList();

    // returns a list of duplicates for the concern role
    final curam.core.sl.struct.DuplicateForConcernRoleDtlsList duplicatesForConcernRoleDtlsList = clientMergeObj.listDuplicatesForConcernRole(
      key);

    // Set the indicator to default to true so that the mark new duplicate
    // link is displayed
    CuramInd curamInd = new CuramInd();
    final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
      key);

    duplicatesConcernRoleDetailsList.markNewDuplicateInd = true;

    // Check if the concern role is a prospect, if so the mark new duplicate
    // link should not be displayed
    if (concernRoleDtls.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {

      duplicatesConcernRoleDetailsList.markNewDuplicateInd = false;
    }

    // Check if the concern role is a duplicate person,
    // if so the mark new duplicate link should not be displayed
    curamInd = clientMergeObj.isConcernRoleDuplicate(key);

    if (curamInd.statusInd) {
      duplicatesConcernRoleDetailsList.markNewDuplicateInd = false;
    }

    // Assign the details returned to a new details struct
    DuplicateConcernRoleDetails duplicateConcernRoleDetails;
    ConcernRoleDuplicateMergeDetails mergeDetails;
    ConcernRoleDuplicateKey concernRoleDuplicateKey;

    for (int i = 0; i < duplicatesForConcernRoleDtlsList.dtlsList.dtls.size(); i++) {
      duplicateConcernRoleDetails = new DuplicateConcernRoleDetails();
      duplicateConcernRoleDetails.assign(
        duplicatesForConcernRoleDtlsList.dtlsList.dtls.item(i));

      mergeDetails = new ConcernRoleDuplicateMergeDetails();
      concernRoleDuplicateKey = new ConcernRoleDuplicateKey();
      concernRoleDuplicateKey.concernRoleDuplicateID = duplicateConcernRoleDetails.concernRoleDuplicateID;

      mergeDetails.dtls.dtls = ConcernRoleDuplicateFactory.newInstance().readConcernRoleDuplicateMergeDetails(
        concernRoleDuplicateKey);

      duplicateConcernRoleDetails.displayIndicators = setClientMergeDisplayIndicators(
        mergeDetails);

      duplicatesConcernRoleDetailsList.dtlsList.addRef(
        duplicateConcernRoleDetails);
    }

    return duplicatesConcernRoleDetailsList;
  }

  // END, CR00223827
  // BEGIN, CR00099906, CSH
  // BEGIN, CR00281651, KRK
  /**
   * This method returns the details for a specified concern role duplicate.
   *
   * @param key
   * The concern role duplicate id.
   *
   * @return The duplicate details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link ClientMerge# readDuplicateByConcernRole(ConcernRoleDuplicateKey concernRoleDuplicateKey)}
   * .
   * The current method displays the fields mergeStartDate and mergeEndDate in
   * DATE format.
   * The new method displays these fields in DATETIME format for a specified
   * concern role duplicate. See release note : CS-08572/CR00281651.
   */
  @Override
  @Deprecated
  public ConcernRoleDuplicateMergeDetails readDuplicate(
    final ConcernRoleDuplicateKey key) throws AppException,
      InformationalException {

    // END, CR00281651

    // Return struct
    final ConcernRoleDuplicateMergeDetails details = new ConcernRoleDuplicateMergeDetails();

    // ClientMerge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Read the duplicate details for the specified concern role
    details.dtls = clientMergeObj.readDuplicate(key);

    // BEGIN, CR00223827, MC
    details.indicators = setClientMergeDisplayIndicators(details);
    // END, CR00223827

    // BEGIN, CR00103071, PDN
    // Find the context description for this concern role
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.dtls.dtls.originalConcernRoleID;
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    details.contextDescription.description = concernRoleDtls.concernRoleName
      + CuramConst.kSeparator + concernRoleDtls.primaryAlternateID;

    // END, CR00103071

    // Return the details
    return details;
  }

  // BEGIN, CR00281651, KRK
  /**
   * Retrieves the details for a specified concern role duplicate.
   *
   * @param concernRoleDuplicateKey
   * The concern role duplicate id.
   *
   * @return The duplicate merge details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ConcernRoleDuplicateMergeDtls readDuplicateByConcernRole(
    final ConcernRoleDuplicateKey concernRoleDuplicateKey)
    throws AppException, InformationalException {

    final ConcernRoleDuplicateMergeDtls concernRoleDuplicateMergeDtls = new ConcernRoleDuplicateMergeDtls();

    final curam.core.sl.intf.ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // BEGIN, CR00290962, KRK
    concernRoleDuplicateMergeDtls.dtls = clientMergeObj.readDuplicateByConcernRole(
      concernRoleDuplicateKey);
    // END, CR00290962

    if (0
      == DateTime.kZeroDateTime.compareTo(
        concernRoleDuplicateMergeDtls.dtls.dtls.unmarkDateTime)) {
      concernRoleDuplicateMergeDtls.dtls.dtls.unmarkDateTime = concernRoleDuplicateMergeDtls.dtls.dtls.unmarkDate.getDateTime();
    }
    if (0
      == DateTime.kZeroDateTime.compareTo(
        concernRoleDuplicateMergeDtls.dtls.dtls.duplicateDateTime)) {
      concernRoleDuplicateMergeDtls.dtls.dtls.duplicateDateTime = concernRoleDuplicateMergeDtls.dtls.dtls.duplicateDate.getDateTime();
    }

    concernRoleDuplicateMergeDtls.indicators = setClientMergeDisplayIndicators(
      concernRoleDuplicateMergeDtls);

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleDuplicateMergeDtls.dtls.dtls.originalConcernRoleID;
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    concernRoleDuplicateMergeDtls.contextDescription.description = concernRoleDtls.concernRoleName
      + CuramConst.kSeparator + concernRoleDtls.primaryAlternateID;

    return concernRoleDuplicateMergeDtls;
  }

  /**
   * Retrieves the client merge indicators to conditionally display the actions.
   *
   * @param concernRoleDuplicateMergeDtls
   * The details of the duplicate to merge.
   *
   * @return The list of client merge indicators.
   */
  protected ViewDuplicateIndicators setClientMergeDisplayIndicators(
    final ConcernRoleDuplicateMergeDtls concernRoleDuplicateMergeDtls) {

    if (!MERGESTATUS.INMERGE.equals(
      concernRoleDuplicateMergeDtls.dtls.dtls.mergeStatus)
        || !MERGESTATUS.MERGECOMPLETE.equals(
          concernRoleDuplicateMergeDtls.dtls.dtls.mergeStatus)
          || !MERGESTATUS.NOTMERGED.equals(
            concernRoleDuplicateMergeDtls.dtls.dtls.mergeStatus)) {
      concernRoleDuplicateMergeDtls.indicators.notMergedInd = true;
    }

    if (MERGESTATUS.NOTMERGED.equals(
      concernRoleDuplicateMergeDtls.dtls.dtls.mergeStatus)) {
      concernRoleDuplicateMergeDtls.indicators.notMergedInd = true;

    } else if (MERGESTATUS.INMERGE.equals(
      concernRoleDuplicateMergeDtls.dtls.dtls.mergeStatus)) {

      concernRoleDuplicateMergeDtls.indicators.inMergeInd = true;
      concernRoleDuplicateMergeDtls.indicators.notMergedInd = false;

    } else if (MERGESTATUS.MERGECOMPLETE.equals(
      concernRoleDuplicateMergeDtls.dtls.dtls.mergeStatus)) {

      concernRoleDuplicateMergeDtls.indicators.inMergeInd = false;
      concernRoleDuplicateMergeDtls.indicators.notMergedInd = false;
    }

    if (concernRoleDuplicateMergeDtls.dtls.dtls.unmarkDate.isZero()) {
      concernRoleDuplicateMergeDtls.indicators.markedInd = true;
    } else {

      concernRoleDuplicateMergeDtls.indicators.inMergeInd = false;
      concernRoleDuplicateMergeDtls.indicators.notMergedInd = false;
    }

    return concernRoleDuplicateMergeDtls.indicators;
  }

  // END, CR00281651

  // END, CR00099906

  // BEGIN, CR00223827, MC
  // ___________________________________________________________________________

  // BEGIN, CR00281651, KRK
  /**
   * Set the client merge indicators to conditionally display the actions.
   *
   * @param details
   * The details of the duplicate to merge.
   * @return
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link #setClientMergeDisplayIndicators()}. The new method Sets
   * the client merge indicators to conditionally display the
   * actions. See release note : CS-08572/CR00281651.
   */
  @Deprecated
  protected ViewDuplicateIndicators setClientMergeDisplayIndicators(
    final ConcernRoleDuplicateMergeDetails details) {

    // END, CR00281651
    // Check merge status to set display indicators

    // If a ConcernRoleMerge record has not yet been created
    // the following condition will evaluate to true
    if (!details.dtls.dtls.mergeStatus.equals(MERGESTATUS.INMERGE)
      || !details.dtls.dtls.mergeStatus.equals(MERGESTATUS.MERGECOMPLETE)
      || !details.dtls.dtls.mergeStatus.equals(MERGESTATUS.NOTMERGED)) {

      details.indicators.notMergedInd = true;
    }

    // If a ConcernRoleMerge record has been created, check the status
    if (details.dtls.dtls.mergeStatus.equals(MERGESTATUS.NOTMERGED)) {

      // The start option should be enabled
      details.indicators.notMergedInd = true;

    } else if (details.dtls.dtls.mergeStatus.equals(MERGESTATUS.INMERGE)) {

      // The start option should be disabled and the
      // resume option should be enabled
      details.indicators.inMergeInd = true;
      details.indicators.notMergedInd = false;

    } else if (details.dtls.dtls.mergeStatus.equals(MERGESTATUS.MERGECOMPLETE)) {

      // The start and resume options should be disabled
      details.indicators.inMergeInd = false;
      details.indicators.notMergedInd = false;
    }

    // Check if unmark data has been populated
    if (details.dtls.dtls.unmarkDate.isZero()) {

      details.indicators.markedInd = true;

    } else {

      // If the person has been unmarked then the start
      // and resume merge options should be disabled
      details.indicators.inMergeInd = false;
      details.indicators.notMergedInd = false;
    }

    return details.indicators;
  }

  // END, CR00223827

  // END, CR00281651
  /**
   * This method reads the concern role names for the original and duplicate
   * Concern Role.
   *
   * @param key
   * The original concern role key and the duplicate concern role id
   *
   * @return The concernRoleName for original and duplicate concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ConcernRoleNameDtls readConcernRoleNames(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    // Return struct
    final ConcernRoleNameDtls concernRoleNameDtls = new ConcernRoleNameDtls();

    // ClientMerge object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Read concernRoleName
    concernRoleNameDtls.dtls = clientMergeObj.readConcernRoleNames(key.key);

    return concernRoleNameDtls;
  }

  /**
   * Method to unmark a client as a duplicate
   *
   * @param details
   * The unmark duplicate details
   * @return an informational informing the user that any merged data needs to
   * be tidied up
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList unmarkDuplicate(UnmarkDuplicateDetails details) throws AppException,
      InformationalException {

    // Return struct
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // ClientMerge Object
    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Unmark duplicate
    clientMergeObj.unmarkDuplicate(details.dtls);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // BEGIN, CR00100109, PDN
  // ___________________________________________________________________________
  /**
   * This method retrieves a list pages needed for a client merge
   *
   * @param key
   * Concern role identifiers for original and duplicate participants
   *
   * @return XML client data for the Agenda client and returns to the view
   * duplicate page.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AgendaDetails getAgendaForViewDuplicate(
    final ClientMergeAgendaKey key) throws AppException,
      InformationalException {

    AgendaDetails retval = new AgendaDetails();

    mergeAgendaSummaryPage = CuramConst.kParticipant_mergeSummaryForViewDuplicate;
    mergeAgendaExitPage = CuramConst.kParticipant_listDuplicates;

    // Decide if this is an existing client merge or a new client merge
    final ConcernRoleMerge concernRoleMergeObj = ConcernRoleMergeFactory.newInstance();
    final ReadByConcernRoleDuplicateIDKey readByConcernRoleDuplicateIDKey = new ReadByConcernRoleDuplicateIDKey();

    readByConcernRoleDuplicateIDKey.concernRoleDuplicateID = key.concernRoleDuplicateID;

    final ConcernRoleMergeDtlsList concernRoleMergeDtlsList = concernRoleMergeObj.searchByConcernRoleDuplicateID(
      readByConcernRoleDuplicateIDKey);

    if (concernRoleMergeDtlsList.dtls.size() == 0) {
      // Start a new client merge
      retval = startMerge(key);
    } else {
      // Continue an in progress client merge
      retval = continueInProgressMerge(key, concernRoleMergeDtlsList);
    }

    return retval;
  }

  // END, CR00100109

  // BEGIN, CR00102618, CSH

  /**
   * Generates the menu data for listing the interactions of a person and any
   * duplicates they may have.
   *
   * @param key
   * Contains the concern role details.
   *
   * @return Menu data for listing the interactions.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public OrgUnitBreadCrumbDetails getDuplicateMenuData(ConcernRoleKey key,
    ClientPageLink dupPageIdentifier, ClientPageLink origPageIdentifier)
    throws AppException, InformationalException {

    // Create return struct
    final OrgUnitBreadCrumbDetails orgUnitBreadCrumbDetails = new OrgUnitBreadCrumbDetails();

    // Menu navigation variables
    final Element navigationMenuElement = new Element(kNavigationMenu);
    Element linkElement = new Element(kItem);
    Element paramElement = new Element(kParam);

    // ConcernRole object manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = new ConcernRoleNameAndAlternateID();
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    // Set the concern role key
    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read client's name and alt ID details
    concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
      concernRoleKey);

    // DuplicateConcernRole manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    DuplicateForConcernRoleDtlsList duplicateForConcernRoleDtlsList = new DuplicateForConcernRoleDtlsList();

    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Create a case tab bar for any duplicates that exist
    duplicateForConcernRoleDtlsList = concernRoleDuplicateObj.searchByOriginalConcernRoleIDNotStatus(
      concernRoleIDStatusCodeKey);

    // check if any duplicates exist, if not there is no need to display
    // dynamic menu
    if (!duplicateForConcernRoleDtlsList.dtls.isEmpty()) {

      // We need to display the master client case list first and then each
      // subsequent duplicate listing

      // Create Child Node
      linkElement = new Element(kItem);

      final LocalisableString description = new LocalisableString(
        BPOINTEGRATEDCASE.INF_CR_DUP_MENU_DESCRIPTION);

      // set the description
      description.arg(concernRoleNameAndAlternateID.concernRoleName);
      description.arg(concernRoleNameAndAlternateID.primaryAlternateID);

      linkElement.setAttribute(kPageID, origPageIdentifier.pageIdentifier);
      linkElement.setAttribute(kDesc, description.toClientFormattedText());
      linkElement.setAttribute(kType, XmlMetaDataConst.kTypePerson);

      // Add the child node to the root node
      navigationMenuElement.addContent(linkElement);

      // Create parameter element
      paramElement = new Element(kParam);

      // Set the parameter elements
      // Set the parameters name and value
      paramElement.setAttribute(kName, kParamConcernRoleID);
      paramElement.setAttribute(kValue,
        Long.toString(concernRoleKey.concernRoleID));

      // Add the parameter elements to the child node
      linkElement.addContent(paramElement);

      for (int i = 0; i < duplicateForConcernRoleDtlsList.dtls.size(); i++) {

        // Create Child Node
        linkElement = new Element(kItem);

        final LocalisableString duplicateDescription = new LocalisableString(
          BPOINTEGRATEDCASE.INF_CR_DUP_MENU_DESCRIPTION);

        // Get the duplicates name and alt ID details
        concernRoleKey.concernRoleID = duplicateForConcernRoleDtlsList.dtls.item(i).duplicateConcernRoleID;

        concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
          concernRoleKey);

        duplicateDescription.arg(concernRoleNameAndAlternateID.concernRoleName);
        duplicateDescription.arg(
          concernRoleNameAndAlternateID.primaryAlternateID);

        linkElement.setAttribute(kPageID, dupPageIdentifier.pageIdentifier);
        linkElement.setAttribute(kDesc,
          duplicateDescription.toClientFormattedText());
        linkElement.setAttribute(kType, kTypeDuplicatePerson);

        // Add the child node to the root node
        navigationMenuElement.addContent(linkElement);

        // Create parameter element
        paramElement = new Element(kParam);

        // Set the parameter elements
        // Set the parameters name and value
        paramElement.setAttribute(kName, kParamConcernRoleID);
        paramElement.setAttribute(kValue,
          Long.toString(
          duplicateForConcernRoleDtlsList.dtls.item(i).duplicateConcernRoleID));

        // Add the parameter elements to the child node
        linkElement.addContent(paramElement);
      }
    }

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    orgUnitBreadCrumbDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return orgUnitBreadCrumbDetails;
  }

  // END, CR00102618

  // BEGIN, CR00102900, CSH

  /**
   * Generates the menu data for tabs for the listings of a person and any
   * duplicates they may have.
   *
   * @param originalKey
   * Contains the concern role id for the original client.
   * @param currentKey
   * Contains the concern role id for the selected client.
   * @param dupPageIdentifier
   * Contains the page to link to for the duplicate client's listings.
   *
   * @param origPageIdentifier
   * Contains the page to link to for the original client's listings.
   * @return Menu data for the client listings.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public RendererXMLStruct getDuplicateMenuRendererData(
    ConcernRoleKey originalKey, ConcernRoleKey currentKey,
    ClientPageLink dupPageIdentifier, ClientPageLink origPageIdentifier)
    throws AppException, InformationalException {

    // Return struct
    final RendererXMLStruct rendererXMLStruct = new RendererXMLStruct();

    // Instance of helper class to build the XML
    final XMLBuilder xmlBuilder = new XMLBuilder();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = new ConcernRoleNameAndAlternateID();

    // DuplicateConcernRole manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    DuplicateForConcernRoleDtlsList duplicateForConcernRoleDtlsList = new DuplicateForConcernRoleDtlsList();

    // Read original client's name and alt ID details
    concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
      originalKey);

    // Set the data values for the original concern
    final String tabName = concernRoleNameAndAlternateID.concernRoleName
      + CuramConst.gkSpace + CuramConst.gkDashChar + CuramConst.gkSpace
      + concernRoleNameAndAlternateID.primaryAlternateID;
    final String url = origPageIdentifier.pageIdentifier
      + CuramConst.kPageSuffix + originalKey.concernRoleID;
    final String image = CuramConst.kConcernImage;

    // Add the original concern data
    xmlBuilder.createTag(kItem);
    xmlBuilder.addAttribute(CuramConst.kURL, url);
    xmlBuilder.addAttribute(CuramConst.kTabName, tabName);
    xmlBuilder.addAttribute(CuramConst.kTabImage, image);

    // Check the currently selected concern to set focus
    if (originalKey.concernRoleID == currentKey.concernRoleID) {
      xmlBuilder.addAttribute(CuramConst.kFocus, CuramConst.kFront);
    } else {
      xmlBuilder.addAttribute(CuramConst.kFocus, CuramConst.kBack);
    }
    xmlBuilder.closeTag();

    // Read all the active duplicates for the original concern role
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    concernRoleIDStatusCodeKey.concernRoleID = originalKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    duplicateForConcernRoleDtlsList = concernRoleDuplicateObj.searchByOriginalConcernRoleIDNotStatus(
      concernRoleIDStatusCodeKey);

    final ConcernRoleKey duplicateConcernRoleKey = new ConcernRoleKey();

    // Go through all the duplicates for the original and add a tab for each
    for (int i = 0; i < duplicateForConcernRoleDtlsList.dtls.size(); i++) {

      // Get the duplicates name and alt ID details
      duplicateConcernRoleKey.concernRoleID = duplicateForConcernRoleDtlsList.dtls.item(i).duplicateConcernRoleID;

      concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
        duplicateConcernRoleKey);

      // Set the data for the duplicate concern
      final String duplicateTabName = concernRoleNameAndAlternateID.concernRoleName
        + CuramConst.gkSpace + CuramConst.gkDashChar + CuramConst.gkSpace
        + concernRoleNameAndAlternateID.primaryAlternateID;
      final String dupUrl = dupPageIdentifier.pageIdentifier
        + CuramConst.kPageSuffix + duplicateConcernRoleKey.concernRoleID;
      final String dupImage = CuramConst.kDuplicateImage;

      // Add the duplicate concern data
      xmlBuilder.createTag(kItem);
      xmlBuilder.addAttribute(CuramConst.kURL, dupUrl);
      xmlBuilder.addAttribute(CuramConst.kTabName, duplicateTabName);
      xmlBuilder.addAttribute(CuramConst.kTabImage, dupImage);

      // Check the currently selected concern to set focus
      if (duplicateConcernRoleKey.concernRoleID == currentKey.concernRoleID) {

        xmlBuilder.addAttribute(CuramConst.kFocus, CuramConst.kFront);
      } else {

        xmlBuilder.addAttribute(CuramConst.kFocus, CuramConst.kBack);
      }

      xmlBuilder.closeTag();
    }

    // Return the xml data blob
    rendererXMLStruct.data = xmlBuilder.getBlob();
    return rendererXMLStruct;
  }

  // END, CR00102900

  // BEGIN, CR00144945, SS
  /**
   * Method to display two special caution lists. The first list displays a list
   * of special caution which are associated with the original concern role. The
   * second list displays a list of special caution which are currently
   * associated with the duplicate concern role.
   *
   * @param key
   * contains original and duplicate client concern role ID.
   * @return list of special caution of both original and duplicate client.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public SpecialCautionList listSpecialCautionForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final SpecialCautionList specialCautionList = new SpecialCautionList();

    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // return list of special caution for both the original and duplicate
    // participants
    specialCautionList.dtlsList = clientMergeObj.listSpecialCautionForMerge(
      key.key);

    return specialCautionList;
  }

  /**
   * Merges the special caution record(s) selected by the user for the duplicate
   * concern role and to associates them with the original concern role.
   *
   * @param details
   * contains Concern role identifier, Concern role merge identifier.
   * @param tabList
   * contains A list of tab delimited concern role special caution IDs.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void mergeSpecialCaution(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // merge selected duplicate special caution with original participant's
    clientMergeObj.mergeSpecialCaution(details.dtls, tabList);

  }

  /**
   * Check if Special Caution entity has duplicates
   *
   * @param concernRoleID
   * Concern role identifiers for the participant.
   *
   * @return boolean, true if there are duplicates for the concern role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean checkForClientSpecialCaution(long concernRoleID)
    throws AppException, InformationalException {

    final curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();
    final SpecialCautionConcernKey specialCautionKey = new SpecialCautionConcernKey();

    specialCautionKey.concernRoleID = concernRoleID;
    // BEGIN, CR00221607, MC
    // read back list of special caution for concernRole
    if (specialCautionObj.listSpecialCautions(specialCautionKey).list.size()
      != 0
        && Configuration.getBooleanProperty(
          EnvVars.ENV_PARTICIPANT_CLIENTMERGE_MERGE_SPECIAL_CAUTIONS)) {
      return true;
    } else {
      return false;
    }
    // END, CR00221607
  }

  /**
   * Get indigenous group details
   *
   * @param indigenousGroupCode
   * Contains codetable code of indigenous group
   * @return description of codetable code
   * @throws InformationalException
   * @throws AppException
   */
  protected String getIndigenousGroup(String indigenousGroupCode)
    throws AppException, InformationalException {

    final StringBuffer stringTypeCode = new StringBuffer();
    String regionDescription = null;
    StringList indigenousTabList;
    String groupDescription = null;

    // Check whether this prospect person associated with a Indigenous Group
    if (!indigenousGroupCode.equalsIgnoreCase(CuramConst.gkEmpty)) {

      indigenousTabList = StringUtil.delimitedText2StringListWithTrim(
        indigenousGroupCode, CuramConst.gkTabDelimiterChar);
      // Appending region description with group description separating by dash
      // for an Indigenous Group
      for (int j = 0; j < indigenousTabList.size(); j++) {

        if (!indigenousTabList.item(j).equalsIgnoreCase(CuramConst.gkEmpty)) {
          // BEGIN, CR00163098, JC
          regionDescription = CodeTable.getOneItem(
            INDIGENOUSREGIONCODE.TABLENAME,
            CodeTable.getParentCode(INDIGENOUSGROUPCODE.TABLENAME,
            indigenousTabList.item(j)),
            TransactionInfo.getProgramLocale());

          groupDescription = CodeTable.getOneItem(INDIGENOUSGROUPCODE.TABLENAME,
            indigenousTabList.item(j), TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

          stringTypeCode.append(regionDescription);
          stringTypeCode.append(CuramConst.gkDash);
          stringTypeCode.append(groupDescription);

          if (j < indigenousTabList.size() - 1) {
            stringTypeCode.append(CuramConst.gkComma);
          }
        }
      }

    }
    return stringTypeCode.toString();
  }

  /**
   * Get race details
   *
   * @param raceCode
   * contains concatenated code of Race codetable.
   * @return description of all individual code separated by a comma.
   * @throws InformationalException
   * @throws AppException
   */
  protected String getRaceDetails(String raceCode) throws AppException,
      InformationalException {

    final StringBuffer stringTypeCode = new StringBuffer();

    StringList raceTypeTabList;

    raceTypeTabList = StringUtil.delimitedText2StringListWithTrim(raceCode,
      CuramConst.gkTabDelimiterChar);
    // Appending all the races description and separating with Comma
    for (int j = 0; j < raceTypeTabList.size(); j++) {
      // BEGIN, CR00163098, JC
      stringTypeCode.append(
        CodeTable.getOneItem(RACECODE.TABLENAME, raceTypeTabList.item(j),
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC
      if (j < raceTypeTabList.size() - 1) {
        stringTypeCode.append(CuramConst.gkComma);
      }
    }
    return stringTypeCode.toString();

  }

  // END, CR00144945

  // BEGIN, CR00225203, ZV
  /**
   * This method gets the details of the original concern role and duplicate
   * concern role.
   *
   * @param key
   * contains the original and duplicate concern role id's.
   *
   * @return OriginalAndDuplicateDetails containing details of the original and
   * duplicate concern roles.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public OriginalAndDuplicateDetails1 readOriginalAndDuplicateDetails1(
    final OriginalAndDuplicateKey key) throws AppException,
      InformationalException {

    final OriginalAndDuplicateDetails1 originalAndDuplicateDetails = new OriginalAndDuplicateDetails1();

    // Determine if the duplicate concern is a person or prospect person
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey duplicateConcernRolekey = new ConcernRoleKey();
    ConcernRoleTypeDetails duplicateConcernRoleTypeDetails = new ConcernRoleTypeDetails();

    duplicateConcernRolekey.concernRoleID = key.duplicateConcernRoleID;
    duplicateConcernRoleTypeDetails = concernRoleObj.readConcernRoleType(
      duplicateConcernRolekey);

    final ConcernRoleKey originalConcernRolekey = new ConcernRoleKey();
    ConcernRoleDtls originalConcernRoleDtls = new ConcernRoleDtls();

    originalConcernRolekey.concernRoleID = key.originalConcernRoleID;
    originalConcernRoleDtls = concernRoleObj.read(originalConcernRolekey);

    // Person Home Page object.
    final curam.core.intf.PersonHomePage personHomePageObj = curam.core.fact.PersonHomePageFactory.newInstance();

    // Key to read original details.
    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    // BEGIN, CR00100101, CM
    // BEGIN, CR00169613, VK
    // Participant Context Description structs
    ParticipantContextDescriptionDetails participantContextDescriptionDetails = new ParticipantContextDescriptionDetails();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Participant Context Object
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // END, CR00169613

    // END, CR00100101

    // Decide if the duplicate is a person or a prospect person and
    // read the details
    if (originalConcernRoleDtls.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PERSON)) {
      concernRoleHomePageKey.concernRoleID = key.originalConcernRoleID;

      // Read the original Person Home Page details
      originalAndDuplicateDetails.originalDtls = personHomePageObj.read(concernRoleHomePageKey).details;
      // BEGIN, CR00144945, SS
      originalAndDuplicateDetails.originalDtls.race = getRaceDetails(
        originalAndDuplicateDetails.originalDtls.race);
      originalAndDuplicateDetails.originalDtls.indigenousGroupCode = getIndigenousGroup(
        originalAndDuplicateDetails.originalDtls.indigenousGroupCode);
      // END, CR00144945
    }

    // Decide if the duplicate is a person or a prospect person and
    // read the details
    if (duplicateConcernRoleTypeDetails.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PERSON)) {
      concernRoleHomePageKey.concernRoleID = key.duplicateConcernRoleID;
      final ReadPersonResult readPersonResult = personHomePageObj.read(
        concernRoleHomePageKey);

      originalAndDuplicateDetails.duplicateDtls.address = readPersonResult.details.formattedAddressData;
      originalAndDuplicateDetails.duplicateDtls.countryOfBirth = readPersonResult.details.birthCountry;
      originalAndDuplicateDetails.duplicateDtls.dateOfBirth = readPersonResult.details.dateOfBirth;
      originalAndDuplicateDetails.duplicateDtls.firstName = readPersonResult.details.firstForename;
      originalAndDuplicateDetails.duplicateDtls.lastName = readPersonResult.details.surname;
      originalAndDuplicateDetails.duplicateDtls.maritalStatus = readPersonResult.details.maritalStatus;
      originalAndDuplicateDetails.duplicateDtls.mothersName = readPersonResult.details.motherBirthSurname;
      originalAndDuplicateDetails.duplicateDtls.nationality = readPersonResult.details.nationality;
      originalAndDuplicateDetails.duplicateDtls.phoneNumber = readPersonResult.details.phoneNumber;
      // BEGIN, CR00146028, SS
      originalAndDuplicateDetails.duplicateDtls.ethnicOrigin = readPersonResult.details.ethnicOriginCode;
      originalAndDuplicateDetails.duplicateDtls.race = getRaceDetails(
        readPersonResult.details.race);
      originalAndDuplicateDetails.duplicateDtls.indigenousGroup = getIndigenousGroup(
        readPersonResult.details.indigenousGroupCode);
      // END, CR00146028

      originalAndDuplicateDetails.duplicateDtls.status = readPersonResult.details.statusCode;
      originalAndDuplicateDetails.duplicateDtls.gender = readPersonResult.details.sex;

    } else if (duplicateConcernRoleTypeDetails.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {
      // Prospect Person Home Page object.
      final curam.core.sl.intf.ProspectPersonHome prospectPersonHomeObj = curam.core.sl.fact.ProspectPersonHomeFactory.newInstance();

      // Key to read prospect person details
      concernRoleHomePageKey.concernRoleID = key.duplicateConcernRoleID;

      // Struct returned from ProspectPersonHomePage read.
      ProspectPersonHomeDetails prospectPersonHomeDetails;

      // Read the Person Home Page details
      prospectPersonHomeDetails = prospectPersonHomeObj.read(
        concernRoleHomePageKey);

      originalAndDuplicateDetails.duplicateDtls.address = prospectPersonHomeDetails.dtls.formattedAddressData;
      originalAndDuplicateDetails.duplicateDtls.countryOfBirth = prospectPersonHomeDetails.dtls.countryOfBirth;
      originalAndDuplicateDetails.duplicateDtls.dateOfBirth = prospectPersonHomeDetails.dtls.dateOfBirth;
      originalAndDuplicateDetails.duplicateDtls.firstName = prospectPersonHomeDetails.dtls.firstForename;
      originalAndDuplicateDetails.duplicateDtls.lastName = prospectPersonHomeDetails.dtls.surname;
      originalAndDuplicateDetails.duplicateDtls.maritalStatus = prospectPersonHomeDetails.dtls.maritalStatusCode;
      originalAndDuplicateDetails.duplicateDtls.mothersName = prospectPersonHomeDetails.dtls.motherBirthSurname;
      originalAndDuplicateDetails.duplicateDtls.nationality = prospectPersonHomeDetails.dtls.nationalityCode;
      originalAndDuplicateDetails.duplicateDtls.phoneNumber = prospectPersonHomeDetails.dtls.phoneNumber;

      // BEGIN, CR00144945, SS
      originalAndDuplicateDetails.duplicateDtls.ethnicOrigin = prospectPersonHomeDetails.dtls.ethnicOriginCode;
      // END, CR00144945
      originalAndDuplicateDetails.duplicateDtls.status = prospectPersonHomeDetails.dtls.statusCode;
      originalAndDuplicateDetails.duplicateDtls.gender = prospectPersonHomeDetails.dtls.gender;

      // BEGIN, CR00144945, SS
      originalAndDuplicateDetails.duplicateDtls.race = getRaceDetails(
        prospectPersonHomeDetails.dtls.race);
      originalAndDuplicateDetails.duplicateDtls.indigenousGroup = getIndigenousGroup(
        prospectPersonHomeDetails.dtls.indigenousGroupCode);
      // END, CR00144945
    }

    // BEGIN, CR00100101, CM
    // BEGIN, CR00169613, VK
    // Set context description key
    participantContextDescriptionKey.concernRoleID = key.originalConcernRoleID;

    // get the context description for the concern role
    participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);
    // set the context description
    originalAndDuplicateDetails.contextDescription.description = participantContextDescriptionDetails.description;
    // END, CR00100101
    // END, CR00169613

    return originalAndDuplicateDetails;
  }

  // END, CR00225203

  // BEGIN CR00232224, ZV
  // BEGIN, CR00282028, IBM
  /**
   * This method searches for persons and prospect persons and filters the
   * return list to remove any items that are already duplicates.
   *
   * @param key
   * contains the search criteria.
   *
   * @return PersonAndProspectPersonSearchResult list of persons and prospect
   * persons and some of their details for supplied search key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ClientMerge#searchNonDuplicatePersonDetails(SearchNonDuplicatePersonKey)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchNonDuplicatePersonDetails(SearchNonDuplicatePersonKey) which
   * returns the informational message along with person details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Override
  @Deprecated
  public PersonSearchResult1 searchNonDuplicatePerson(
    final SearchNonDuplicatePersonKey key) throws AppException,
      InformationalException {

    // END, CR00282028
    final PersonSearchResult1 personSearchResult = new PersonSearchResult1();

    final PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    key.personSearchKey.disableLinkInd = true;

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      key.personSearchKey);

    // Filter the Person list for any duplicate persons
    for (int i = 0; i < personSearchResult.personSearchResult.dtlsList.size(); i++) {

      concernRoleKey.concernRoleID = personSearchResult.personSearchResult.dtlsList.item(i).concernRoleID;

      // If the person is a duplicate then remove it from the result
      if (clientMergeObj.isConcernRoleDuplicate(concernRoleKey).statusInd
        || concernRoleKey.concernRoleID == key.originalConcernRoleID) {
        personSearchResult.personSearchResult.dtlsList.remove(i);
        i--;
      }
    }

    return personSearchResult;
  }

  // END CR00232224

  // BEGIN, CR00282028, IBM
  /**
   * Search for persons and prospect persons and filters the return list to
   * remove any items that are already duplicates.
   *
   * @param searchNonDuplicatePersonKey
   * contains the search criteria.
   *
   * @return person details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public PersonSearchDetailsResult searchNonDuplicatePersonDetails(
    final SearchNonDuplicatePersonKey searchNonDuplicatePersonKey)
    throws AppException, InformationalException {

    final PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();

    final PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    final curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    searchNonDuplicatePersonKey.personSearchKey.disableLinkInd = true;

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      searchNonDuplicatePersonKey.personSearchKey);

    // Filter the Person list for any duplicate persons
    for (int i = 0; i < personSearchResult.personSearchResult.dtlsList.size(); i++) {

      concernRoleKey.concernRoleID = personSearchResult.personSearchResult.dtlsList.item(i).concernRoleID;

      // If the person is a duplicate then remove it from the result
      if (clientMergeObj.isConcernRoleDuplicate(concernRoleKey).statusInd
        || concernRoleKey.concernRoleID
          == searchNonDuplicatePersonKey.originalConcernRoleID) {
        personSearchResult.personSearchResult.dtlsList.remove(i);
        i--;
      }
    }
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      personSearchResult.informationalMsgDtls.dtls.addRef(informationalMsgDtls);
    }

    return personSearchResult;
  }

  // END, CR00282028
  // BEGIN, CR00281651, KRK
  /**
   * Retrieves a list of duplicates created for a concern role.
   *
   * @param concernRoleKey
   * The concern role id.
   *
   * @return The duplicate concern role list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public DuplicateForConcernRoleDetailsList listDuplicatesForConcernRoleDetails(final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    final DuplicateForConcernRoleDetailsList duplicateForConcernRoleDetailsList = new DuplicateForConcernRoleDetailsList();

    duplicateForConcernRoleDetailsList.detailsList = clientMergeObj.listDuplicatesForConcernRoleDetails(
      concernRoleKey);

    // Set the indicator to default to true so that the mark new duplicate
    // link is displayed
    CuramInd curamInd = new CuramInd();

    for (final DuplicateForConcernRoleDetails duplicateForConcernRoleDetails : duplicateForConcernRoleDetailsList.detailsList.dtlsList.dtls) {

      if (0
        == DateTime.kZeroDateTime.compareTo(
          duplicateForConcernRoleDetails.duplicateDateTime)) {

        duplicateForConcernRoleDetails.duplicateDateTime = duplicateForConcernRoleDetails.duplicateDate.getDateTime();
      }
      if (0
        == DateTime.kZeroDateTime.compareTo(
          duplicateForConcernRoleDetails.unmarkDateTime)) {

        duplicateForConcernRoleDetails.unmarkDateTime = duplicateForConcernRoleDetails.unmarkDate.getDateTime();
      }
    }

    final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
      concernRoleKey);

    duplicateForConcernRoleDetailsList.markNewDuplicateInd = true;

    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {

      duplicateForConcernRoleDetailsList.markNewDuplicateInd = false;
    }

    curamInd = clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

    if (curamInd.statusInd) {
      duplicateForConcernRoleDetailsList.markNewDuplicateInd = false;
    }

    MergeDuplicateConcernRoleDetails mergeDuplicateConcernRoleDetails;
    ConcernRoleDuplicateMergeDtls concernRoleDuplicateMergeDtls;
    ConcernRoleDuplicateKey concernRoleDuplicateKey;

    for (final DuplicateForConcernRoleDetails duplicateForConcernRoleDetails : duplicateForConcernRoleDetailsList.detailsList.dtlsList.dtls.items()) {

      mergeDuplicateConcernRoleDetails = new MergeDuplicateConcernRoleDetails();

      mergeDuplicateConcernRoleDetails.assign(duplicateForConcernRoleDetails);

      concernRoleDuplicateMergeDtls = new ConcernRoleDuplicateMergeDtls();
      concernRoleDuplicateKey = new ConcernRoleDuplicateKey();
      concernRoleDuplicateKey.concernRoleDuplicateID = mergeDuplicateConcernRoleDetails.concernRoleDuplicateID;

      concernRoleDuplicateMergeDtls.dtls.dtls = ConcernRoleDuplicateFactory.newInstance().readDuplicateMergeDetailsByConcernRole(
        concernRoleDuplicateKey);

      mergeDuplicateConcernRoleDetails.displayIndicators = setClientMergeDisplayIndicators(
        concernRoleDuplicateMergeDtls);

      duplicateForConcernRoleDetailsList.duplicateDetailsList.addRef(
        mergeDuplicateConcernRoleDetails);
    }

    return duplicateForConcernRoleDetailsList;
  }

  // END, CR00281651

  // BEGIN, CR00353792, ZV
  /**
   * This method retrieves a list of address evidence details for both the
   * original
   * and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of address evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listAddressEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();
    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCADDRESS;

    // return list of addresses for both the original and duplicate participants
    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    // Inform the user that once they select next in the merge wizard,
    // any selected data will be merged
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final AppException e = new AppException(
      BPOCLIENTMERGE.INF_SELECTED_DATA_WILL_BE_MERGED);

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
      e.arg(true), CuramConst.gkEmpty,
      curam.util.exception.InformationalElement.InformationalType.kWarning,
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    // Obtain the informational(s) to be returned to the client
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      evidenceMergeList.messageList.dtls.addRef(informationalMsgDtls);
    }
    // END, CR00102618

    return evidenceMergeList;
  }

  /**
   * This method retrieves a list of alternate ID evidence details for both the
   * original
   * and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of alternate ID evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listAlternateIDEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();

    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCIDENTIFICATION;

    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    return evidenceMergeList;
  }

  /**
   * This method retrieves a list of alternate name evidence details for both
   * the original
   * and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of alternate name evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listAlternateNameEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();

    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCNAME;

    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    return evidenceMergeList;
  }

  /**
   * This method retrieves a list of bank account evidence details for both the
   * original
   * and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of bank account evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listBankAccountEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();

    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCBANKACCOUNT;

    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    return evidenceMergeList;
  }

  /**
   * This method retrieves a list of email address evidence details for both the
   * original and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of email address evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listEmailAddressEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();

    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCEMAILADDRESS;

    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    return evidenceMergeList;
  }

  /**
   * This method retrieves a list of phone number evidence details for both the
   * original
   * and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of phone number evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listPhoneNumberEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();

    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCPHONENUMBER;

    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    return evidenceMergeList;
  }

  /**
   * Check if participant has evidence recorded.
   *
   * @param key Contains concern role identifier and evidence type code.
   *
   * @return boolean, true if there exists evidence for the concern role.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  protected BooleanIndicator checkForClientEvidence(
    EvidenceTypeAndParticipantIDDetails key) throws AppException,
      InformationalException {

    final BooleanIndicator indicator = new BooleanIndicator();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.participantID;

    final ParticipantDataCase participantDataCaseObj = ParticipantDataCaseFactory.newInstance();

    final CaseIDKey pdcCaseKey = participantDataCaseObj.getParticipantDataCase(
      concernRoleKey);

    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceTypeWorkspaceKey evidenceTypeWorkspaceKey = new EvidenceTypeWorkspaceKey();

    evidenceTypeWorkspaceKey.evidenceType = key.evidenceType;
    evidenceTypeWorkspaceKey.showCancelledEvidence = false;
    evidenceTypeWorkspaceKey.participantID = key.participantID;
    evidenceTypeWorkspaceKey.caseID = pdcCaseKey.caseID;

    final EvidenceTypeWorkspaceListDetails evidenceListDetails = evidenceControllerObj.listEvidenceTypes(
      evidenceTypeWorkspaceKey);

    indicator.flag = !evidenceListDetails.list.isEmpty();

    return indicator;
  }

  /**
   * This method merges selected address evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergeAddressEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final EvidenceType evidenceType = new EvidenceType();

    evidenceType.evidenceType = PDCConst.PDCADDRESS;
    clientMergeObj.mergeEvidence(details.dtls, tabList, evidenceType);
  }

  /**
   * This method merges selected alternate ID evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergeAlternateIDEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final EvidenceType evidenceType = new EvidenceType();

    evidenceType.evidenceType = PDCConst.PDCIDENTIFICATION;
    clientMergeObj.mergeEvidence(details.dtls, tabList, evidenceType);
  }

  /**
   * This method merges selected alternate name evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergeAlternateNameEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    // BEGIN, CR00360982, ZV
    clientMergeObj.mergeAlternateNameEvidence(details.dtls, tabList);
    // END, CR00360982
  }

  /**
   * This method merges selected bank account evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergeBankAccountEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final EvidenceType evidenceType = new EvidenceType();

    evidenceType.evidenceType = PDCConst.PDCBANKACCOUNT;
    clientMergeObj.mergeEvidence(details.dtls, tabList, evidenceType);
  }

  /**
   * This method merges selected email address evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergeEmailAddressEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final EvidenceType evidenceType = new EvidenceType();

    evidenceType.evidenceType = PDCConst.PDCEMAILADDRESS;
    clientMergeObj.mergeEvidence(details.dtls, tabList, evidenceType);
  }

  /**
   * This method merges selected phone number evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergePhoneNumberEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final EvidenceType evidenceType = new EvidenceType();

    evidenceType.evidenceType = PDCConst.PDCPHONENUMBER;
    clientMergeObj.mergeEvidence(details.dtls, tabList, evidenceType);
  }

  // END, CR00353792

  // BEGIN, CR00355808, ZV
  /**
   * This method retrieves a list of relationship evidence details for both the
   * original
   * and duplicate concern roles.
   *
   * @param key Concern role identifiers for original and duplicate participants
   * @return List of relationship evidence for both original and duplicate
   * participants
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EvidenceMergeList listRelationshipEvidenceForMerge(
    ClientMergeParticipantKey key) throws AppException,
      InformationalException {

    final EvidenceMergeList evidenceMergeList = new EvidenceMergeList();

    final ClientMergeEvidenceParticipantKey clientMergeEvidenceParticipantKey = new ClientMergeEvidenceParticipantKey();

    clientMergeEvidenceParticipantKey.assign(key.key);
    clientMergeEvidenceParticipantKey.evidenceType = PDCConst.PDCRELATIONSHIPS;

    evidenceMergeList.evidenceList = clientMergeObj.listEvidenceForMerge(
      clientMergeEvidenceParticipantKey);

    return evidenceMergeList;
  }

  /**
   * This method merges selected relationship evidence from the duplicate
   * concernRole to the original concernRole.
   *
   * @param details Concern role identifier, Concern role merge identifier
   * @param tabList A list of tab delimited evidence record IDs
   *
   * @throws InformationalException* Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void mergeRelationshipEvidence(ConcernRoleDetailsForMerge details,
    MergeTabList tabList) throws AppException, InformationalException {

    final EvidenceType evidenceType = new EvidenceType();

    evidenceType.evidenceType = PDCConst.PDCRELATIONSHIPS;
    clientMergeObj.mergeEvidence(details.dtls, tabList, evidenceType);
  }
  // END, CR00355808
}
