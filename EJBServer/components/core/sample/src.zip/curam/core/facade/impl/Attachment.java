/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012-2018. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import com.google.inject.Inject;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.CancelAttachmentKey;
import curam.codetable.RECORDSTATUS;
import curam.core.struct.AttachmentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;

/**
 * This process class provides the functionality for the Attachment facade
 * layer.
 */
public abstract class Attachment extends curam.core.facade.base.Attachment {

  // Add injection for using the new API
  public Attachment() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // BEGIN, CR00146458, VR
  @Inject
  protected curam.attachment.impl.Attachment attachment;

  // END, CR00146458

  // ___________________________________________________________________________
  /**
   * Method to set an Attachment status to Cancelled
   *
   * @param key Contains attachment link id and attachment version no
   */
  @Override
  public void cancelAttachment(final CancelAttachmentKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00375285, BL
    // Get a reference to the link for this attachment and pass the attachment
    // link version number into the attachmentLink cancel method
    final AttachmentLink attachmentLinkObj =
      attachmentLinkDAO.get(key.attachmentLinkKey);

    attachmentLinkObj.cancel(attachmentLinkObj.getVersionNo());
    // END, CR00375285, BL

  }

  // ___________________________________________________________________________
  /**
   * Method to update attachment details.
   *
   * @param details Contains attachment link details
   */
  @Override
  public void modifyAttachment(final AttachmentLinkDetails details)
    throws AppException, InformationalException {

    attachmentLinkDAO.get(details.attachmentLinkDtls.attachmentLinkID)
      .modify(details);

  }

  // ___________________________________________________________________________
  /**
   * Method to read attachment content.
   *
   * @param key Contains attachment link id
   *
   * @return The attachment file name and document data
   */
  @Override
  public AttachmentLinkDetails readAttachment(final AttachmentLinkKey key)
    throws AppException, InformationalException {

    final AttachmentLink attachmentLink =
      attachmentLinkDAO.get(key.attachmentLinkID);

    final AttachmentLinkDetails attachmentLinkDetails =
      new AttachmentLinkDetails();

    final AttachmentKey attachmentKey = new AttachmentKey();

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID =
      attachmentLink.getID();
    attachmentLinkDetails.attachmentLinkDtls.attachmentID =
      attachmentLink.getAttachmentID();
    attachmentLinkDetails.attachmentLinkDtls.description =
      attachmentLink.getDescription();
    attachmentLinkDetails.attachmentLinkDtls.sensitivityCode =
      attachmentLink.getSensitivityCode().getCode();
    attachmentLinkDetails.attachmentLinkDtls.recordStatus =
      attachmentLink.getLifecycleState().getCode();
    attachmentLinkDetails.attachmentLinkDtls.relatedObjectID =
      attachmentLink.getRelatedObjectID();
    attachmentLinkDetails.attachmentLinkDtls.relatedObjectType =
      attachmentLink.getRelatedObjectType().getCode();
    attachmentLinkDetails.attachmentLinkDtls.participantRoleID =
      attachmentLink.getParticipantRoleID();
    attachmentLinkDetails.attachmentLinkDtls.versionNo =
      attachmentLink.getVersionNo();
    attachmentLinkDetails.attachmentLinkDtls.creatorUserName =
      attachmentLink.getCreator();

    attachmentLink.checkSensitivity();

    attachmentKey.attachmentID =
      attachmentLinkDetails.attachmentLinkDtls.attachmentID;
    // BEGIN, CR00146458, VR
    attachmentLinkDetails.attachmentDtls = attachment.read(attachmentKey);
    // END, CR00146458

    // BEGIN, 213970, MD
    if (attachmentLinkDetails.attachmentLinkDtls.recordStatus
      .equalsIgnoreCase(RECORDSTATUS.CANCELLED)) {
      attachmentLinkDetails.cancelledInd = true;
    }
    // END, 213970
    return attachmentLinkDetails;
  }
}
