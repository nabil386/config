/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.CancelProspectPersonRelationshipDetailsKey;
import curam.core.facade.struct.CreateCitizenshipDetails;
import curam.core.facade.struct.CreateEmploymentDetails;
import curam.core.facade.struct.CreateForeignResidencyDetails;
import curam.core.facade.struct.CreatedForeignResidencyDetails;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.InformationalMsgDetailsList;
import curam.core.facade.struct.ListCitizenshipDetails;
import curam.core.facade.struct.ListCitizenshipKey;
import curam.core.facade.struct.ListEmploymentDetails;
import curam.core.facade.struct.ListEmploymentKey;
import curam.core.facade.struct.ListForeignResidencyDetails;
import curam.core.facade.struct.ListForeignResidencyKey;
import curam.core.facade.struct.MaintainProspectPersonDetails;
import curam.core.facade.struct.MaintainProspectPersonRelationships;
import curam.core.facade.struct.ModifedEmploymentDetails;
import curam.core.facade.struct.ModifiedForeignResidencyDetails;
import curam.core.facade.struct.ModifyCitizenshipDetails;
import curam.core.facade.struct.ModifyEmploymentDetails;
import curam.core.facade.struct.ModifyForeignResidencyDetails;
import curam.core.facade.struct.ModifyProspectPersonDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ProspectCancelCitizenshipKey;
import curam.core.facade.struct.ProspectCancelEmploymentKey;
import curam.core.facade.struct.ProspectPersonRegistrationIDDetails;
import curam.core.facade.struct.ProspectReadCitizenshipDetails;
import curam.core.facade.struct.ProspectReadCitizenshipKey;
import curam.core.facade.struct.ProspectReadEmploymentDetails;
import curam.core.facade.struct.ProspectReadEmploymentKey;
import curam.core.facade.struct.ReadForeignResidencyDetails;
import curam.core.facade.struct.ReadProspectPersonDetails;
import curam.core.facade.struct.ReadProspectPersonDetailsList;
import curam.core.facade.struct.ReadProspectPersonHomePageDetails;
import curam.core.facade.struct.ReadProspectPersonHomePageKey;
import curam.core.facade.struct.ReadProspectPersonListKey;
import curam.core.facade.struct.ReadProspectPersonRelationshipDetails;
import curam.core.facade.struct.ReadProspectPersonRelationshipDetailsKey;
import curam.core.facade.struct.ReadProspectPersonRelationshipList;
import curam.core.facade.struct.ReadProspectPersonRelationshipListKey;
import curam.core.facade.struct.RegisterPersonFromProspectKey;
import curam.core.facade.struct.RegisterProspectPersonDetails;
import curam.core.facade.struct.RemoveEmploymentKey;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.struct.CitizenshipDtls;
import curam.core.struct.CitizenshipKey;
import curam.core.struct.ConcernRoleAlternateReadKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleRelationshipDtls;
import curam.core.struct.ConcernRoleRelationshipKey;
import curam.core.struct.EmploymentDtls;
import curam.core.struct.EmploymentKey;
import curam.core.struct.ForeignResidencyDtls;
import curam.core.struct.ForeignResidencyKey;
import curam.core.struct.MaintainCitizenshipKey;
import curam.core.struct.MaintainConcernRoleRelationshipDetails;
import curam.core.struct.MaintainConcernRoleRelationshipKey;
import curam.core.struct.MaintainForeignResidencyKey;
import curam.core.struct.MaintainProspectPersonEmploymentKey;
import curam.core.struct.MaintainProspectPersonNameKey;
import curam.core.struct.ProspectPersonFurtherDetails;
import curam.core.struct.ReadProspectPersonResult;
import curam.core.struct.RelationshipsByConcernRoleIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


// ___________________________________________________________________________
/**
 * This process class provides the functionality for the Prospect presentation
 * layer.
 *
 * @deprecated Since Curam 6.0.5.0 replaced with {@link ProspectPerson}.
 * This class is deprecated because
 * Prospect participant type is no longer in use. See release note : CR00348318.
 */
@Deprecated
public abstract class Prospect extends curam.core.facade.base.Prospect {

  // ___________________________________________________________________________
  /**
   * Reads a prospect person's home page details and further details.
   *
   * @param key
   * Concern role id of the prospect person
   *
   * @return Prospect person home page details
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#readProspectPerson(curam.core.facade.struct.ReadProspectPersonKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to read the prospect person home page details.
   * See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ReadProspectPersonHomePageDetails readProspectPersonHomePage(
    ReadProspectPersonHomePageKey key) throws AppException,
      InformationalException {

    // Prospect Person Home Page object.
    final curam.core.intf.ProspectPersonHomePage prospectPersonHomePageObj = curam.core.fact.ProspectPersonHomePageFactory.newInstance();

    // Maintain Prospect Person object.
    final curam.core.intf.MaintainProspectPerson maintainProspectPersonObj = curam.core.fact.MaintainProspectPersonFactory.newInstance();

    // Details to be returned.
    final ReadProspectPersonHomePageDetails readProspectPersonHomePageDetails = new ReadProspectPersonHomePageDetails();

    // Struct returned from the Home Page read.
    ReadProspectPersonResult readProspectPersonResult;

    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Struct returned from the Prospect Person Further Details read.
    ProspectPersonFurtherDetails prospectPersonFurtherDetails;

    // Read the Prospect Person Home Page details.
    readProspectPersonResult = prospectPersonHomePageObj.read(
      key.concernRoleHomePageKey);

    // Get the Concern Role ID from the key.
    maintainConcernRoleKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Read the Prospect Person further details.
    prospectPersonFurtherDetails = maintainProspectPersonObj.readFurtherDetails(
      maintainConcernRoleKey);

    // Context object and key.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Get the Concern Role ID from the key.
    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Get the context description for the concern role.
    readProspectPersonHomePageDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Get prospect person data from record to details structure.
    readProspectPersonHomePageDetails.prospectPersonHomePageDetails.assign(
      prospectPersonFurtherDetails);

    readProspectPersonHomePageDetails.prospectPersonHomePageDetails.assign(
      readProspectPersonResult.details);

    readProspectPersonHomePageDetails.informationalMsgDtlsList = readProspectPersonResult.messages;

    // Return the Prospect Person Home page details.
    return readProspectPersonHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Registers a prospect person.
   *
   * @param details
   * prospect person's registration details
   *
   * @return Prospect person registration details
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#registerProspectPerson(curam.core.facade.struct.ProspectPersonRegistrationDetails)
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to register a prospect person. See release note
   * : CR00348318.
   */
  @Override
  @Deprecated
  public ProspectPersonRegistrationIDDetails registerProspectPerson(
    RegisterProspectPersonDetails details) throws AppException,
      InformationalException {

    // Prospect Person Registration object.
    final curam.core.intf.ProspectPersonRegistration prospectPersonRegistrationObj = curam.core.fact.ProspectPersonRegistrationFactory.newInstance();

    // Details to be returned.
    final ProspectPersonRegistrationIDDetails prospectPersonRegistrationIDDetails = new ProspectPersonRegistrationIDDetails();

    // Register the Prospect Person.
    prospectPersonRegistrationIDDetails.registrationIDDetails = prospectPersonRegistrationObj.registerProspectPerson(
      details.prospectPersonRegistrationDetails);

    // BEGIN, CR00078486, POH
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      prospectPersonRegistrationIDDetails.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    // Return the details.
    return prospectPersonRegistrationIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Sets citizenship record status to canceled.
   *
   * @param key
   * Prospect person alternate name id and version No
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#cancelAlternativeName(curam.core.facade.struct.CancelPersonNameKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to cancel prospect person's name. See release
   * note : CR00348318.
   */
  @Override
  @Deprecated
  public void cancelProspectPersonName(
    curam.core.facade.struct.CancelProspectPersonNameKey key)
    throws AppException, InformationalException {

    // Maintain Prospect Person object.
    final curam.core.intf.MaintainProspectPersonNames maintainProspectPersonNamesObj = curam.core.fact.MaintainProspectPersonNamesFactory.newInstance();

    // Cancel the Prospect Person Name.
    maintainProspectPersonNamesObj.cancelName(key.cancelProspectPersonNameKey);
  }

  // ___________________________________________________________________________
  /**
   * Creates a new Prospect Person Name record for the specified person.
   *
   * @param details
   * Prospect person name details being entered
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#createAlternativeName(curam.core.facade.struct.MaintainPersonAlternativeNameDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to create prospect person's name. See release
   * note : CR00348318.
   */
  @Override
  @Deprecated
  public void createProspectPersonName(MaintainProspectPersonDetails details)
    throws AppException, InformationalException {

    // Maintain Prospect Person Name object and key.
    final curam.core.intf.MaintainProspectPersonNames maintainProspectPersonNamesObj = curam.core.fact.MaintainProspectPersonNamesFactory.newInstance();
    final MaintainProspectPersonNameKey maintainProspectPersonNameKey = new MaintainProspectPersonNameKey();

    // Get the Concern Role ID from the key.
    maintainProspectPersonNameKey.concernRoleID = details.nameDetails.concernRoleID;

    // Create the Prospect Person Name.
    maintainProspectPersonNamesObj.createName(maintainProspectPersonNameKey,
      details.nameDetails);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of Prospect Name details.
   *
   * @param key
   * Prospect person concern role ID
   *
   * @return List of prospect person names returned from the database
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#listAlternativeName(curam.core.facade.struct.ReadPersonAlternativeNameListKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to list prospect person's name details. See
   * release note : CR00348318.
   */
  @Override
  @Deprecated
  public ReadProspectPersonDetailsList listProspectPersonNameDetails(
    ReadProspectPersonListKey key) throws AppException,
      InformationalException {

    // Maintain ProspectPersonName object
    final curam.core.intf.MaintainProspectPersonNames maintainProspectPersonNamesObj = curam.core.fact.MaintainProspectPersonNamesFactory.newInstance();

    // Details to be returned
    final ReadProspectPersonDetailsList readProspectPersonDetailsList = new ReadProspectPersonDetailsList();

    // Context object and key
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read the list of Prospect Person Names
    readProspectPersonDetailsList.nameRMDtlsList = maintainProspectPersonNamesObj.readmultiByConcernRole(
      key.maintainProspectPersonNameKey);

    // Get the Concern Role ID from the key
    participantContextDescriptionKey.concernRoleID = key.maintainProspectPersonNameKey.concernRoleID;

    // Get the context description for the concern role
    readProspectPersonDetailsList.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the Prospect Person Name details
    return readProspectPersonDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies Prospect Person Name details.
   *
   * @param details
   * Prospect person name details being modified
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#modifyAlternativeName(curam.core.facade.struct.MaintainPersonAlternativeNameDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to modify prospect person's name. See release
   * note : CR00348318.
   */
  @Override
  @Deprecated
  public void modifyProspectPersonName(MaintainProspectPersonDetails details)
    throws AppException, InformationalException {

    // Maintain ProspectPersonNames object and key.
    final curam.core.intf.MaintainProspectPersonNames maintainProspectPersonNamesObj = curam.core.fact.MaintainProspectPersonNamesFactory.newInstance();
    final MaintainProspectPersonNameKey maintainProspectPersonNameKey = new MaintainProspectPersonNameKey();

    // Get the Concern Role ID from the key.
    maintainProspectPersonNameKey.concernRoleID = details.nameDetails.concernRoleID;

    // Modify the Prospect Person Name.
    maintainProspectPersonNamesObj.modifyName(maintainProspectPersonNameKey,
      details.nameDetails);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves Prospect Person Name details.
   *
   * @param key
   * Prospect person alternate name ID
   *
   * @return Prospect person alternate name details returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#readAlternativeName(curam.core.facade.struct.ReadPersonNameKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to read prospect person's name details. See
   * release note : CR00348318.
   */
  @Override
  @Deprecated
  public ReadProspectPersonDetails readProspectPersonNameDetails(
    curam.core.facade.struct.ReadProspectPersonNameKey key)
    throws AppException, InformationalException {

    // Maintain ProspectPersonNames object and key.
    final curam.core.intf.MaintainProspectPersonNames maintainProspectPersonNamesObj = curam.core.fact.MaintainProspectPersonNamesFactory.newInstance();
    final curam.core.struct.ReadProspectPersonNameKey readProspectPersonNameKey = new curam.core.struct.ReadProspectPersonNameKey();

    // Details to be returned.
    final ReadProspectPersonDetails readProspectPersonDetails = new ReadProspectPersonDetails();

    // Get the Alternate Name ID from the key.
    readProspectPersonNameKey.alternateNameID = key.readProspectPersonNameKey.alternateNameID;

    // Context object and key.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read the Prospect Person Name details.
    readProspectPersonDetails.nameDetails = maintainProspectPersonNamesObj.readName(
      readProspectPersonNameKey);

    // Get the Concern Role ID from the key.
    participantContextDescriptionKey.concernRoleID = readProspectPersonDetails.nameDetails.concernRoleID;

    // Get the context description for the concern role.
    readProspectPersonDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the Prospect Person Names details.
    return readProspectPersonDetails;
  }

  // ___________________________________________________________________________
  /**
   * Sets citizenship record status to canceled.
   *
   * @param key
   * Prospect person citizenship Id and version No
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#cancelCitizenship(curam.core.facade.struct.CancelCitizenshipKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to cancel citizenship of a prospect person. See
   * release note : CR00348318.
   */
  @Override
  @Deprecated
  public void cancelCitizenship(ProspectCancelCitizenshipKey key)
    throws AppException, InformationalException {

    // Maintain Citizenship object.
    final curam.core.intf.MaintainProspectPersonCitizenship maintainProspectPersonCitizenshipObj = curam.core.fact.MaintainProspectPersonCitizenshipFactory.newInstance();

    // Cancel the citizenship.
    maintainProspectPersonCitizenshipObj.cancelCitizenship(
      key.cancelCitizenshipKey);
  }

  // ___________________________________________________________________________
  /**
   * Creates a new citizenship record for the specified prospect person.
   *
   * @param details
   * Prospect person citizenship details being entered
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#createCitizenship(curam.core.facade.struct.MaintainCitizenshipDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to create citizenship for a prospect person. See
   * release note : CR00348318.
   */
  @Override
  @Deprecated
  public void createCitizenship(CreateCitizenshipDetails details)
    throws AppException, InformationalException {

    // Maintain Citizenship object and key.
    final curam.core.intf.MaintainProspectPersonCitizenship maintainProspectPersonCitizenshipObj = curam.core.fact.MaintainProspectPersonCitizenshipFactory.newInstance();

    final MaintainCitizenshipKey maintainCitizenshipKey = new MaintainCitizenshipKey();

    // Get the Concern Role ID from the key.
    maintainCitizenshipKey.concernRoleID = details.citizenshipDetails.concernRoleID;

    // Create the citizenship record.
    maintainProspectPersonCitizenshipObj.createCitizenship(
      maintainCitizenshipKey, details.citizenshipDetails);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of citizenship details.
   *
   * @param key
   * Prospect person concern role ID
   *
   * @return List of prospect person citizenships returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#listCitizenship(curam.core.facade.struct.ReadCitizenshipListKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to list citizenship details of a prospect
   * person. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ListCitizenshipDetails listCitizenship(ListCitizenshipKey key)
    throws AppException, InformationalException {

    // Maintain Citizenship object.
    final curam.core.intf.MaintainProspectPersonCitizenship maintainProspectPersonCitizenshipObj = curam.core.fact.MaintainProspectPersonCitizenshipFactory.newInstance();

    // Details to be returned.
    final ListCitizenshipDetails listCitizenshipDetails = new ListCitizenshipDetails();

    // Context object and key.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read the list of citizenship records.
    listCitizenshipDetails.citizenshipRMDtlsList = maintainProspectPersonCitizenshipObj.readmultiByConcernRole(
      key.maintainCitizenshipKey);

    // Get the Concern Role ID from the key.
    participantContextDescriptionKey.concernRoleID = key.maintainCitizenshipKey.concernRoleID;

    // Read context description.
    listCitizenshipDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return listCitizenshipDetails;

  }

  // ___________________________________________________________________________
  /**
   * Modifies citizenship details.
   *
   * @param details
   * Prospect person citizenship details being modified
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#modifyCitizenship(curam.core.facade.struct.MaintainCitizenshipDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to modify citizenship of a prospect person. See
   * release note : CR00348318.
   */
  @Override
  @Deprecated
  public void modifyCitizenship(ModifyCitizenshipDetails details)
    throws AppException, InformationalException {

    // Maintain Prospect Citizenship object and key.
    final curam.core.intf.MaintainProspectPersonCitizenship maintainProspectPersonCitizenshipObj = curam.core.fact.MaintainProspectPersonCitizenshipFactory.newInstance();
    final MaintainCitizenshipKey maintainCitizenshipKey = new MaintainCitizenshipKey();

    // Get the concern role ID from the key.
    maintainCitizenshipKey.concernRoleID = details.citizenshipDetails.concernRoleID;

    // Modify the citizenship record.
    maintainProspectPersonCitizenshipObj.modifyCitizenship(
      maintainCitizenshipKey, details.citizenshipDetails);

  }

  // ___________________________________________________________________________
  /**
   * Reads citizenship details.
   *
   * @param key
   * Prospect person citizenship ID
   *
   * @return Prospect person citizenship details returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#readCitizenship(curam.core.facade.struct.ReadCitizenshipKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to read citizenship details for a prospect
   * person. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ProspectReadCitizenshipDetails readCitizenship(
    ProspectReadCitizenshipKey key) throws AppException,
      InformationalException {

    // Maintain Prospect Citizenship object.
    final curam.core.intf.MaintainProspectPersonCitizenship maintainProspectPersonCitizenshipObj = curam.core.fact.MaintainProspectPersonCitizenshipFactory.newInstance();

    // Details to be returned.
    final ProspectReadCitizenshipDetails prospectReadCitizenshipDetails = new ProspectReadCitizenshipDetails();

    // Participant Context Description object
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Concern Role object and key.
    final curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();

    final CitizenshipKey citizenshipKey = new CitizenshipKey();

    // Get the citizenship ID from the key.
    citizenshipKey.citizenshipID = key.readCitizenshipKey.citizenshipID;

    // Citizenship Details object
    CitizenshipDtls citizenshipDtls;

    // Call read and put the return value into the citizenshipDtls struct
    citizenshipDtls = citizenshipObj.read(citizenshipKey);

    // copy key value passed in to key value in above struct
    participantContextDescriptionKey.concernRoleID = citizenshipDtls.concernRoleID;

    // Context object.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Read the citizenship details.
    prospectReadCitizenshipDetails.citizenshipDetails = maintainProspectPersonCitizenshipObj.readCitizenship(
      key.readCitizenshipKey);

    // Read context description.
    prospectReadCitizenshipDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return prospectReadCitizenshipDetails;
  }

  // ___________________________________________________________________________
  /**
   * Sets Foreign Residency status to canceled.
   *
   * @param key
   * Prospect person foreign residency ID and version No
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#cancelForeignResidency(curam.core.facade.struct.CancelPersonForeignResidencyKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used to cancel foreign residency . See release note :
   * CR00348318.
   */
  @Override
  @Deprecated
  public void cancelForeignResidency(
    curam.core.facade.struct.CancelForeignResidencyKey key)
    throws AppException, InformationalException {

    // Maintain Prospect Foreign Residency object.
    final curam.core.intf.MaintainProspectPersonForeignResidency maintainProspectPersonForeignResidencyObj = curam.core.fact.MaintainProspectPersonForeignResidencyFactory.newInstance();

    // Cancel the Foreign Residency.
    maintainProspectPersonForeignResidencyObj.cancelForeignResidency(
      key.cancelForeignResidencyKey);

  }

  // BEGIN, CR00077847, POH
  // ___________________________________________________________________________
  /**
   * Creates a new Foreign Residency record for the specified person.
   *
   * @param details
   * Prospect person foreign residency details being entered
   * @return CreatedForeignResidencyDetails
   * List of informationals - if any exist - to be displayed to user
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#createForeignResidency(curam.core.facade.struct.MaintainPersonForeignResidencyDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public CreatedForeignResidencyDetails createForeignResidency(
    CreateForeignResidencyDetails details) throws AppException,
      InformationalException {

    // return struct
    final CreatedForeignResidencyDetails createdForeignResidencyDetails = new CreatedForeignResidencyDetails();
    // Maintain Prospect Foreign Residency object and key.
    final curam.core.intf.MaintainProspectPersonForeignResidency maintainProspectPersonForeignResidencyObj = curam.core.fact.MaintainProspectPersonForeignResidencyFactory.newInstance();

    final MaintainForeignResidencyKey maintainForeignResidencyKey = new MaintainForeignResidencyKey();

    // Get the Concern Role ID from the key.
    maintainForeignResidencyKey.concernRoleID = details.foreignResidencyDetails.concernRoleID;

    // Create the Foreign Residency record.
    maintainProspectPersonForeignResidencyObj.createForeignResidency(
      maintainForeignResidencyKey, details.foreignResidencyDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdForeignResidencyDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdForeignResidencyDetails;
    // END, CR00077847
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of Foreign Residency details.
   *
   * @param key
   * Prospect person concern role ID
   *
   * @return List of prospect person foreign residencies returned from the
   * database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#listForeignResidency(curam.core.facade.struct.ReadPersonForeignResidencyListKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ListForeignResidencyDetails listForeignResidency(
    ListForeignResidencyKey key) throws AppException, InformationalException {

    // Maintain Prospect Foreign Residency object.
    final curam.core.intf.MaintainProspectPersonForeignResidency maintainProspectPersonForeignResidencyObj = curam.core.fact.MaintainProspectPersonForeignResidencyFactory.newInstance();

    // Details to be returned.
    final ListForeignResidencyDetails listForeignResidencyDetails = new ListForeignResidencyDetails();

    // Context object and key.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read the list of Foreign Residency records.
    listForeignResidencyDetails.foreignResidencyRMDtlsList = maintainProspectPersonForeignResidencyObj.readmultiByConcernRole(
      key.maintainForeignResidencyKey);

    // Get the Concern Role ID from the key.
    participantContextDescriptionKey.concernRoleID = key.maintainForeignResidencyKey.concernRoleID;

    // Read context description.
    listForeignResidencyDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return listForeignResidencyDetails;

  }

  // BEGIN, CR00077847
  // ___________________________________________________________________________
  /**
   * Modifies Foreign Residency details.
   *
   * @param details
   * Prospect person foreign residency details being modified
   * @return
   * List of informationals - if any exist - to be displayed to user
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#modifyForeignResidency(curam.core.facade.struct.MaintainPersonForeignResidencyDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ModifiedForeignResidencyDetails modifyForeignResidency(
    ModifyForeignResidencyDetails details) throws AppException,
      InformationalException {

    // return struct
    final ModifiedForeignResidencyDetails modifiedForeignResidencyDetails = new ModifiedForeignResidencyDetails();

    // Maintain Prospect Foreign Residency object and key.
    final curam.core.intf.MaintainProspectPersonForeignResidency maintainProspectPersonForeignResidencyObj = curam.core.fact.MaintainProspectPersonForeignResidencyFactory.newInstance();

    final MaintainForeignResidencyKey maintainForeignResidencyKey = new MaintainForeignResidencyKey();

    // Get the concern role ID from the key.
    maintainForeignResidencyKey.concernRoleID = details.foreignResidencyDetails.concernRoleID;

    // Modify the Foreign Residency record.
    maintainProspectPersonForeignResidencyObj.modifyForeignResidency(
      maintainForeignResidencyKey, details.foreignResidencyDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedForeignResidencyDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedForeignResidencyDetails;
  }

  // END, CR00077847

  // ___________________________________________________________________________
  /**
   * Reads Foreign Residency details.
   *
   * @param key
   * Prospect person foreign residency ID
   *
   * @return Prospect person foreign residency details returned from the
   * database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#readForeignResidency(curam.core.facade.struct.ReadPersonForeignResidencyKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ReadForeignResidencyDetails readForeignResidency(
    curam.core.facade.struct.ReadForeignResidencyKey key)
    throws AppException, InformationalException {

    // Maintain Prospect Foreign Residency object.
    final curam.core.intf.MaintainProspectPersonForeignResidency maintainProspectPersonForeignResidencyObj = curam.core.fact.MaintainProspectPersonForeignResidencyFactory.newInstance();

    // Details to be returned.
    final ReadForeignResidencyDetails readForeignResidencyDetails = new ReadForeignResidencyDetails();

    // Participant Context Description object
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Concern Role object and key.
    final curam.core.intf.ForeignResidency foreignResidencyObj = curam.core.fact.ForeignResidencyFactory.newInstance();

    final ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

    // Get the foreignResidency ID from the key.
    foreignResidencyKey.foreignResidencyID = key.readForeignResidencyKey.foreignResidencyID;

    // Foreign Residency Details object
    ForeignResidencyDtls foreignResidencyDtls;

    // Call read and put the return value into the alternateNameDtls struct
    foreignResidencyDtls = foreignResidencyObj.read(foreignResidencyKey);

    // Copy key value passed in to key value in above struct
    participantContextDescriptionKey.concernRoleID = foreignResidencyDtls.concernRoleID;

    // Context object.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Read the Foreign Residency details.
    readForeignResidencyDetails.foreignResidencyDetails = maintainProspectPersonForeignResidencyObj.readForeignResidency(
      key.readForeignResidencyKey);

    // Read context description.
    readForeignResidencyDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readForeignResidencyDetails;

  }

  // ___________________________________________________________________________
  /**
   * Sets prospect person employment record status of the Employment from
   * "Active" to "canceled"
   *
   * @param key
   * Prospect person employment ID and version No
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#cancelEmployment(curam.core.facade.struct.CancelEmploymentKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public void cancelEmployment(ProspectCancelEmploymentKey key)
    throws AppException, InformationalException {

    // Maintain Prospect Person Employment object.
    final curam.core.intf.MaintainProspectPersonEmployment maintainProspectPersonEmploymentObj = curam.core.fact.MaintainProspectPersonEmploymentFactory.newInstance();

    // Cancel the Employment
    maintainProspectPersonEmploymentObj.cancelEmployment(
      key.cancelEmploymentKey);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new employment record for the specified prospect person.
   *
   * @param details
   * Prospect person employment details being entered
   *
   * @return Informational returned on employment creation
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#createEmployment(curam.core.facade.struct.MaintainPersonEmploymentDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public InformationMsgDtlsList createEmployment(
    CreateEmploymentDetails details) throws AppException,
      InformationalException {

    // Maintain Prospect Person Employment object and key.
    final curam.core.intf.MaintainProspectPersonEmployment maintainProspectPersonEmploymentObj = curam.core.fact.MaintainProspectPersonEmploymentFactory.newInstance();

    final MaintainProspectPersonEmploymentKey maintainProspectPersonEmploymentKey = new MaintainProspectPersonEmploymentKey();

    // Details to be returned.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Employment details
    final curam.core.struct.EmploymentDetails employmentDetails = new curam.core.struct.EmploymentDetails();

    // Concern role entity objects
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Assign employment details
    employmentDetails.assign(details.prospectEmploymentDetails);

    // Get the employer concern role id from the key
    concernRoleKey.concernRoleID = details.prospectEmploymentDetails.employerConcernRoleID;

    if (concernRoleKey.concernRoleID != 0) {
      // Read primary alternate ID from ConcernRole
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      employmentDetails.employerAlternateID = concernRoleDtls.primaryAlternateID;
    }

    // Get the Concern Role ID from the details.
    maintainProspectPersonEmploymentKey.concernRoleID = details.prospectEmploymentDetails.concernRoleID;

    // Create the Employment Record
    informationMsgDtlsList.informationalMsgDtlsList = maintainProspectPersonEmploymentObj.createEmployment(
      maintainProspectPersonEmploymentKey, employmentDetails);

    // Return the details.
    return informationMsgDtlsList;
  }

  // BEGIN, CR00077847
  // ___________________________________________________________________________
  /**
   * Modifies an existing employment of the prospect person.
   *
   * @param details
   * Prospect person employment details being modified
   * @return
   * List of informationals - if any exist - to be displayed to user
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#modifyEmployment(curam.core.facade.struct.MaintainPersonEmploymentDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ModifedEmploymentDetails modifyEmployment(
    ModifyEmploymentDetails details) throws AppException,
      InformationalException {

    // return struct
    final ModifedEmploymentDetails modifedEmploymentDetails = new ModifedEmploymentDetails();

    // Maintain Person Employment object and key.
    final curam.core.intf.MaintainProspectPersonEmployment maintainProspectPersonEmploymentObj = curam.core.fact.MaintainProspectPersonEmploymentFactory.newInstance();

    final MaintainProspectPersonEmploymentKey maintainProspectPersonEmploymentKey = new MaintainProspectPersonEmploymentKey();

    // Employment details
    final curam.core.struct.EmploymentDetails employmentDetails = new curam.core.struct.EmploymentDetails();

    // Concern role entity objects
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Assign employment details
    employmentDetails.assign(details.prospectEmploymentDetails);

    // Get the employer concern role id from the key
    concernRoleKey.concernRoleID = details.prospectEmploymentDetails.employerConcernRoleID;

    // Read primary alternate ID from ConcernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    employmentDetails.employerAlternateID = concernRoleDtls.primaryAlternateID;

    // Get the Concern Role ID from the details.
    maintainProspectPersonEmploymentKey.concernRoleID = details.prospectEmploymentDetails.concernRoleID;

    // Modify the Employment Record
    maintainProspectPersonEmploymentObj.modifyEmployment(
      maintainProspectPersonEmploymentKey, employmentDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifedEmploymentDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifedEmploymentDetails;
    // END, CR00077847

  }

  // ___________________________________________________________________________
  /**
   * Reads a list of existing employments for the prospect person.
   *
   * @param key
   * Prospect person concern role ID
   *
   * @return List of prospect person employments returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#listEmployment(curam.core.facade.struct.ReadPersonEmploymentListKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ListEmploymentDetails listEmployment(ListEmploymentKey key)
    throws AppException, InformationalException {

    // Maintain Person Employment object.
    final curam.core.intf.MaintainProspectPersonEmployment maintainProspectPersonEmploymentObj = curam.core.fact.MaintainProspectPersonEmploymentFactory.newInstance();

    // Details to be returned.
    final ListEmploymentDetails listEmploymentDetails = new ListEmploymentDetails();

    // Context object and key.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read list of employments.
    listEmploymentDetails.readmultiByConcernRoleIDResult = maintainProspectPersonEmploymentObj.readmultiByConcernRoleID(
      key.maintainProspectPersonEmploymentKey);

    // Set context read key
    participantContextDescriptionKey.concernRoleID = key.maintainProspectPersonEmploymentKey.concernRoleID;

    // Get the context description for the concern role.
    listEmploymentDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return listEmploymentDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads an existing employment for the prospect person.
   *
   * @param key
   * Prospect person employment ID
   *
   * @return Prospect person employment details returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#readEmployment(curam.core.facade.struct.ReadEmploymentKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ProspectReadEmploymentDetails readEmployment(
    ProspectReadEmploymentKey key) throws AppException,
      InformationalException {

    // Maintain Person Employment object.
    final curam.core.intf.MaintainProspectPersonEmployment maintainProspectPersonEmploymentObj = curam.core.fact.MaintainProspectPersonEmploymentFactory.newInstance();

    // Details to be returned.
    final ProspectReadEmploymentDetails prospectReadEmploymentDetails = new ProspectReadEmploymentDetails();

    // Participant Context Description object
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Employment object and key.
    final curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();

    final EmploymentKey employmentKey = new EmploymentKey();

    // Get the employment ID from the key.
    employmentKey.employmentID = key.readEmploymentKey.employmentID;

    // Employment Details object
    EmploymentDtls employmentDtls;

    // call read and put the return value into the EmploymentDtls struct
    employmentDtls = employmentObj.read(employmentKey);

    // copy key value passed in to key value in above struct
    participantContextDescriptionKey.concernRoleID = employmentDtls.concernRoleID;

    // Context object.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Employment Details
    curam.core.struct.EmploymentDetails employmentDetails;

    // Concern role entity objects
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleAlternateReadKey concernRoleAlternateReadKey = new ConcernRoleAlternateReadKey();
    ConcernRoleDtls concernRoleDtls;

    // Read the employment details.
    employmentDetails = maintainProspectPersonEmploymentObj.readEmployment(
      key.readEmploymentKey);

    // Read the concern role
    concernRoleAlternateReadKey.primaryAlternateID = employmentDetails.employerAlternateID;

    concernRoleAlternateReadKey.statusCode = curam.codetable.CONCERNROLESTATUS.CURRENT;

    concernRoleDtls = concernRoleObj.readByAlternateID(
      concernRoleAlternateReadKey);

    // Assign the employment details to the output
    prospectReadEmploymentDetails.prospectEmploymentDetails.assign(
      employmentDetails);

    // Set the employer concern role ID
    prospectReadEmploymentDetails.prospectEmploymentDetails.employerConcernRoleID = concernRoleDtls.concernRoleID;

    // Get the context description for the concern role.
    prospectReadEmploymentDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return prospectReadEmploymentDetails;

  }

  // ___________________________________________________________________________
  /**
   * Sets Prospect Relationship status to canceled.
   *
   * @param key
   * Prospect person relationship ID and version No
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#cancelRelationship(curam.core.facade.struct.CancelPersonRelationshipDetailsKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public void cancelRelationship(
    CancelProspectPersonRelationshipDetailsKey key) throws AppException,
      InformationalException {

    // Maintain Concern Role Relationships object.
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Cancel the Person Relationship.
    maintainConcernRoleRelationshipsObj.cancelRelationship(
      key.cancelRelationshipDetailsKey);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new Person Relationship record for the specified person.
   *
   * @param details
   * Prospect person relationship details being entered
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#createRelationship(curam.core.facade.struct.MaintainProspectPersonRelationshipDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public void createRelationship(MaintainProspectPersonRelationships details)
    throws AppException, InformationalException {

    // Maintain Concern Role Relationships object and key.
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    final RelationshipsByConcernRoleIDKey relationshipsByConcernRoleIDKey = new RelationshipsByConcernRoleIDKey();

    final MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails = new MaintainConcernRoleRelationshipDetails();

    // Get the Concern Role ID from the key.
    relationshipsByConcernRoleIDKey.concernRoleID = details.personRelationshipDetails.concernRoleID;

    maintainConcernRoleRelationshipDetails.assign(
      details.personRelationshipDetails);

    // Create the Relationship record.
    maintainConcernRoleRelationshipsObj.createRelationshipByAltID(
      maintainConcernRoleRelationshipDetails);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of Person Relationship details.
   *
   * @param key
   * Prospect person concern role ID
   *
   * @return List of prospect person relationships returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#listRelationship(curam.core.facade.struct.ReadPersonRelationshipListKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ReadProspectPersonRelationshipList listRelationship(
    ReadProspectPersonRelationshipListKey key) throws AppException,
      InformationalException {

    // Maintain Concern Role Relationships object.
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned.
    final ReadProspectPersonRelationshipList readProspectPersonRelationshipList = new ReadProspectPersonRelationshipList();

    // Context object and key.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Read the list of Person Relationship records.
    readProspectPersonRelationshipList.maintainConcernRoleRelationshipList = maintainConcernRoleRelationshipsObj.readmultiByConcernRoleID(
      key.relationshipsByConcernRoleIDKey);

    // Get the Concern Role ID from the key.
    participantContextDescriptionKey.concernRoleID = key.relationshipsByConcernRoleIDKey.concernRoleID;

    // Read context description.
    readProspectPersonRelationshipList.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readProspectPersonRelationshipList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies Prospect Person Relationship details.
   *
   * @param details
   * Prospect person relationship details being modified
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#modifyRelationship(curam.core.facade.struct.MaintainProspectPersonRelationshipDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public void modifyRelationship(MaintainProspectPersonRelationships details)
    throws AppException, InformationalException {

    // Maintain Concern Role Relationships object.
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();
    final MaintainConcernRoleRelationshipKey maintainConcernRoleRelationshipKey = new MaintainConcernRoleRelationshipKey();

    final MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails = new MaintainConcernRoleRelationshipDetails();

    maintainConcernRoleRelationshipDetails.assign(
      details.personRelationshipDetails);

    // Get the concern role ID from the key.
    maintainConcernRoleRelationshipKey.concernRoleRelationshipID = details.personRelationshipDetails.concernRoleRelationshipID;

    // Modify the Relationship record.
    maintainConcernRoleRelationshipsObj.modifyRelationshipByAltID(
      maintainConcernRoleRelationshipKey,
      maintainConcernRoleRelationshipDetails);
  }

  /**
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#cancelEmployment(curam.core.facade.struct.CancelEmploymentKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public void removeEmployment(RemoveEmploymentKey key) throws AppException,
      InformationalException {//
  }

  // ___________________________________________________________________________
  /**
   * Modifies a prospect person.
   *
   * @param details
   * Prospect person details being modified
   *
   * @return Informational returned on modification
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#modifyProspectPerson(curam.core.facade.struct.MaintainProspectPersonDtls)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public InformationalMsgDetailsList modifyProspectPerson(
    ModifyProspectPersonDetails details) throws AppException,
      InformationalException {

    // Maintain Prospect Person object.
    final curam.core.intf.MaintainProspectPerson maintainProspectPersonObj = curam.core.fact.MaintainProspectPersonFactory.newInstance();

    // Details to be returned.
    final InformationalMsgDetailsList informationalMsgDetailsList = new InformationalMsgDetailsList();

    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Get the Concern Role ID from the details.
    maintainConcernRoleKey.concernRoleID = details.prospectPersonModifyDetails.concernRoleID;

    // Modify the Prospect Person
    maintainProspectPersonObj.modifyProspectPerson(maintainConcernRoleKey,
      details.prospectPersonModifyDetails);

    return informationalMsgDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies Prospect Person Relationship details.
   *
   * @param key
   * Prospect person relationship ID
   *
   * @return Prospect person relationship details returned from the database
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#readRelationship(curam.core.facade.struct.ReadPersonRelationshipDetailsKey)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ReadProspectPersonRelationshipDetails readRelationship(
    ReadProspectPersonRelationshipDetailsKey key) throws AppException,
      InformationalException {

    // Maintain Concern Role Relationship object.
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned.
    final ReadProspectPersonRelationshipDetails readProspectPersonRelationshipDetails = new ReadProspectPersonRelationshipDetails();

    // Participant Context Description object
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Concern Role object and key.
    final curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();

    final ConcernRoleRelationshipKey concernRoleRelationshpKey = new ConcernRoleRelationshipKey();

    // Get the concernRole Relationship ID from the key.
    concernRoleRelationshpKey.concernRoleRelationshipID = key.maintainConcernRoleRelationshipKey.concernRoleRelationshipID;

    // Concern Role Relationship Details object
    ConcernRoleRelationshipDtls concernRoleRelationshipDtls;

    // call read and put the return value into the alternateNameDtls struct
    concernRoleRelationshipDtls = concernRoleRelationshipObj.read(
      concernRoleRelationshpKey);

    // copy key value passed in to key value in above struct
    participantContextDescriptionKey.concernRoleID = concernRoleRelationshipDtls.concernRoleID;

    // Context object.
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails;

    // Read the Relationship details.
    maintainConcernRoleRelationshipDetails = maintainConcernRoleRelationshipsObj.readRelationship(
      key.maintainConcernRoleRelationshipKey);

    // Assign relationship details to output
    readProspectPersonRelationshipDetails.personRelationshipDetails.assign(
      maintainConcernRoleRelationshipDetails);

    // Read context description.
    readProspectPersonRelationshipDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readProspectPersonRelationshipDetails;
  }

  // BEGIN, CR00078486, POH
  // ___________________________________________________________________________
  /**
   * Registers a person from prospect details.
   *
   * @param key
   * Concern role ID
   * @return ProspectPersonRegistrationIDDetails
   * List of informationals - if any exist - to be displayed to user
   *
   * @deprecated Since Curam 6.0.5.0 replaced with
   * {@link ProspectPerson#registerProspectPersonAsPerson(curam.core.facade.struct.ReadProspectPersonKey, curam.core.facade.struct.ProspectPersonRegistrationDetails)}
   * .
   * This method is deprecated because
   * Prospect participant type is no longer in use. Equivalent method from
   * ProspectPerson can be used instead. See release note : CR00348318.
   */
  @Override
  @Deprecated
  public ProspectPersonRegistrationIDDetails registerPersonFromProspect(
    RegisterPersonFromProspectKey key) throws AppException,
      InformationalException {

    // return struct
    final ProspectPersonRegistrationIDDetails prospectPersonRegistrationIDDetails = new ProspectPersonRegistrationIDDetails();

    // Maintain Prospect Person object.
    final curam.core.intf.MaintainProspectPerson maintainProspectPersonObj = curam.core.fact.MaintainProspectPersonFactory.newInstance();

    // Details to get prospect details for registration.
    curam.core.struct.PersonRegistrationDetails personRegistrationDetails;
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // read the prospect details.
    maintainConcernRoleKey.concernRoleID = key.key.concernRoleID;
    personRegistrationDetails = maintainProspectPersonObj.readDetailsForConversion(
      maintainConcernRoleKey);

    // convert the prospect to person.
    maintainProspectPersonObj.convertProspectPersonToPerson(key.key,
      personRegistrationDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      prospectPersonRegistrationIDDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return prospectPersonRegistrationIDDetails;
  }
  // END, CR00078486
}
