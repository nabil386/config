/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012-2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.BookmarkDetailsStructList;
import curam.core.facade.struct.ListCaseBookmarkDetails;
import curam.core.sl.entity.struct.BookmarkKey;
import curam.core.sl.fact.BookmarkFactory;
import curam.core.sl.struct.ListBookmarkKey;
import curam.core.struct.CaseID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Bookmark facade
 * methods.
 */
public abstract class Bookmark extends curam.core.facade.base.Bookmark {

  // __________________________________________________________________________
  /**
   * @return List of details of cases that have been bookmarked by the user
   * @deprecated Since Curam 6.0, replaced by {@link #listBookmark()}. Current
   * method returns only case bookmarks, while new method returns bookmarks
   * based on bookmark type or all bookmarks.
   *
   * Counts how many active bookmarks a user has on a case
   */
  @Override
  @Deprecated
  public ListCaseBookmarkDetails listCaseBookmarks() throws AppException,
      InformationalException {

    // Return struct
    final ListCaseBookmarkDetails listCaseBookmarkDetails = new ListCaseBookmarkDetails();

    // Call service layer list method
    // BEGIN, CR00081565, SPD
    listCaseBookmarkDetails.dtls = BookmarkFactory.newInstance().listCaseBookmark(); // END, CR00081565

    // Return list
    return listCaseBookmarkDetails;
  }

  // __________________________________________________________________________
  /**
   * Adds a bookmark to a case for a user.
   *
   * @param details Details of the case user is bookmarking.
   */
  @Override
  public void addCaseBookmark(CaseID details) throws AppException,
      InformationalException {

    // creates the case bookmark
    BookmarkFactory.newInstance().createCaseBookmark(details);

  }

  // __________________________________________________________________________
  /**
   * Deletes the bookmark a user has on a case
   *
   * @param details details of case to be deleted.
   */
  @Override
  public void deleteCaseBookmark(CaseID details) throws AppException,
      InformationalException {

    // removes the case bookmark
    BookmarkFactory.newInstance().removeCaseBookmark(details);
  }

  // BEGIN, CR00165888, ZV
  // BEGIN, CR00166421, ZV
  // __________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #listCaseBookmarks()}
   * Reads bookmark details list by current user name and bookmark filter type.
   *
   * @param key contains current user name and bookmark filter type
   *
   * @return List of details of bookmarks
   */
  @Override
  public BookmarkDetailsStructList listBookmark(
    ListBookmarkKey listBookmarkKey) throws AppException,
      InformationalException {

    final BookmarkDetailsStructList bookmarkDetailsStructList = new BookmarkDetailsStructList();

    listBookmarkKey.userName = TransactionInfo.getProgramUser();

    bookmarkDetailsStructList.dtls = BookmarkFactory.newInstance().listBookmark(
      listBookmarkKey);

    return bookmarkDetailsStructList;
  }

  // END, CR00166421
  // BEGIN, 149247 
  /**
   * This method reads the bookmark id and deletes the bookmark if id is found else throws an error message
   */

  @Override
  public void deleteBookmark(BookmarkKey key) throws AppException,
      InformationalException {
((curam.core.sl.impl.Bookmark) BookmarkFactory.newInstance()).removeBookmark(key);
  }
}
  
 // END, 149247 
//END, CR00165888  
