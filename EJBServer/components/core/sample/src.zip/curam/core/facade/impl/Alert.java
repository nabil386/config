/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.core.facade.pdt.struct.WorkflowGraphDetails;
import curam.core.facade.struct.AlertContextDescription;
import curam.core.facade.struct.AlertContextKey;
import curam.core.facade.struct.AlertKey;
import curam.core.facade.struct.AlertMultiRemoveKey;
import curam.core.facade.struct.AlertSummaryDetailsList;
import curam.core.facade.struct.AlertWorkflowGraphDetails;
import curam.core.facade.struct.CreateAlertDetails;
import curam.core.facade.struct.ViewAlertDetails;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Standard implementation of {@link curam.core.facade.intf.Alert}.
 */
public abstract class Alert extends curam.core.facade.base.Alert {

  /**
   * {@inheritDoc}
   */
  @Override
  public void create(CreateAlertDetails createAlertDetails)
    throws AppException, InformationalException {

    // Alert object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    // Create new alert
    alertObj.create(createAlertDetails.details);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public AlertSummaryDetailsList list() throws AppException,
      InformationalException {

    // Create return object
    final AlertSummaryDetailsList alertDetailsList = new AlertSummaryDetailsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    final curam.core.sl.struct.SearchByUserNameKey searchByUserNameKey = new curam.core.sl.struct.SearchByUserNameKey();

    searchByUserNameKey.alertSearchKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Alert service layer object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    // Call BPO to return list of alert details
    alertDetailsList.dtls = alertObj.searchByUserName(searchByUserNameKey);

    final AlertContextKey alertContextKey = new AlertContextKey();

    alertContextKey.userName = searchByUserNameKey.alertSearchKey.userName;

    alertDetailsList.context = readContextDescription(alertContextKey);

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      alertDetailsList.informationalMsgDetailsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return alert details list
    return alertDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AlertSummaryDetailsList listAlerts() throws AppException,
      InformationalException {

    // Create return object
    final AlertSummaryDetailsList alertDetailsList = new AlertSummaryDetailsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    final curam.core.sl.struct.SearchByUserNameKey searchByUserNameKey = new curam.core.sl.struct.SearchByUserNameKey();

    searchByUserNameKey.alertSearchKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Alert service layer object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    final ReadMultiOperationDetails readMulti = getNotificationReadMultiDetails();

    // Call BPO to return list of alert details
    alertDetailsList.dtls = alertObj.searchByUserName(searchByUserNameKey,
      readMulti);

    final AlertContextKey alertContextKey = new AlertContextKey();

    alertContextKey.userName = searchByUserNameKey.alertSearchKey.userName;

    alertDetailsList.context = readContextDescription(alertContextKey);

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      alertDetailsList.informationalMsgDetailsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return alert details list
    return alertDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AlertContextDescription readContextDescription(
    AlertContextKey alertContextKey) throws AppException,
      InformationalException {

    final AlertContextDescription alertContextDescription = new AlertContextDescription();

    // User object and key
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    UserFullname userFullname;
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = alertContextKey.userName;
    userFullname = userAccessObj.getFullName(usersKey);

    alertContextDescription.userFullName = userFullname.fullname;

    // Return the details
    return alertContextDescription;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void remove(AlertKey alertKey) throws AppException,
      InformationalException {

    // Alert object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    // Remove alert
    alertObj.remove(alertKey.key);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AlertMultiRemoveKey getAlertIDsForRemoval(
    AlertMultiRemoveKey alertMultiRemoveKey) throws AppException,
      InformationalException {

    final String idsString = alertMultiRemoveKey.key.alertMultiRemoveKey;

    alertMultiRemoveKey.key.alertMultiRemoveKey = idsString.replace(
      GeneralConstants.kTabCharacter, GeneralConstants.kCommaChar);

    return alertMultiRemoveKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void removeSelected(AlertMultiRemoveKey alertMultiRemoveKey)
    throws AppException, InformationalException {

    // Alert object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    // Remove alerts
    alertObj.removeSelected(alertMultiRemoveKey.key);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ViewAlertDetails view(AlertKey alertKey) throws AppException,
      InformationalException {

    // Create return object
    final ViewAlertDetails viewAlertDetails = new ViewAlertDetails();

    // Alert service layer object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    // Read alert details
    viewAlertDetails.details = alertObj.view(alertKey.key);

    // Return alert details
    return viewAlertDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public WorkflowGraphDetails visualiseProcessInstanceForAlert(
    AlertKey alertKey) throws AppException, InformationalException {

    // Create return object
    final WorkflowGraphDetails workflowGraphDetails = new WorkflowGraphDetails();

    final curam.util.workflow.struct.WorkflowGraphDetails result = getWorkflowGraphXMLDetails(
      alertKey);

    workflowGraphDetails.name = result.name;
    workflowGraphDetails.workflowGraphXML = result.workflowGraphXML;

    return workflowGraphDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AlertWorkflowGraphDetails viewProcessInstanceForAlert(
    AlertKey alertKey) throws AppException, InformationalException {

    // Create Return object
    final AlertWorkflowGraphDetails alertWorkflowGraphDetails = new AlertWorkflowGraphDetails();

    final curam.util.workflow.struct.WorkflowGraphDetails result = getWorkflowGraphXMLDetails(
      alertKey);

    alertWorkflowGraphDetails.name = result.name;
    alertWorkflowGraphDetails.workflowGraphXML = result.workflowGraphXML;

    return alertWorkflowGraphDetails;
  }

  /**
   * Returns the read multi details for notification searches. The read multi
   * details consist of the maximum notification list size (which is read from
   * the {@link EnvVars#ENV_NOTIFICATION_MAX_LIST_SIZE} environment
   * variable) and a boolean indicator specifying that an informational message
   * must be returned to the user.
   *
   * @return The Inbox read multi details for task list searches.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected ReadMultiOperationDetails getNotificationReadMultiDetails() {

    Integer maxListSize = Configuration.getIntProperty(
      EnvVars.ENV_NOTIFICATION_MAX_LIST_SIZE);

    if (maxListSize == null) {
      maxListSize = EnvVars.ENV_NOTIFICATION_MAX_LIST_SIZE_DEFAULT;
    }
    final ReadMultiOperationDetails answer = new ReadMultiOperationDetails();

    answer.maxListSize = maxListSize.intValue();
    return answer;
  }

  /**
   * Returns the XML representing the graphical view of a workflow process
   * instance associated with an alert.
   *
   * @param alertKey The unique identifier of the alert.
   *
   * @return An XML representation of a workflow process instance associated
   * with an alert.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected curam.util.workflow.struct.WorkflowGraphDetails getWorkflowGraphXMLDetails(final AlertKey alertKey) throws AppException,
      InformationalException {

    curam.util.workflow.struct.WorkflowGraphDetails result = new curam.util.workflow.struct.WorkflowGraphDetails();

    // Alert service layer object
    final curam.core.sl.intf.Alert alertObj = curam.core.sl.fact.AlertFactory.newInstance();

    // Retrieve the process instance and activity identifier associated with
    // this alert.
    final curam.core.sl.struct.AlertProcessDetails alertProcessDetails = alertObj.readProcessInstanceAndActivityForAlert(
      alertKey.key);

    // Generate the graph data for this process instance.
    final curam.util.workflow.struct.ProcessInstanceID processInstanceKey = new curam.util.workflow.struct.ProcessInstanceID();

    final curam.util.workflow.struct.ActivityAlertDetails activityAlertDetails = new curam.util.workflow.struct.ActivityAlertDetails();

    processInstanceKey.processInstanceID = alertProcessDetails.processInstanceID;

    activityAlertDetails.activityID = alertProcessDetails.activityID;
    activityAlertDetails.alertID = alertKey.key.alertID;

    result = curam.util.workflow.impl.ProcessInstanceAdmin.getInstanceGraph(
      processInstanceKey, activityAlertDetails);
    return result;
  }
}
