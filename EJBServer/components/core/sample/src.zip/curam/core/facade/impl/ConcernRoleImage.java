/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2020. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.facade.impl;


import curam.core.impl.CuramConst;
import curam.core.sl.fact.ConcernRoleImageFactory;
import curam.core.struct.ConcernRoleImageDtls;
import curam.core.struct.ConcernRoleImageKey;
import curam.message.BPOCONCERNROLEIMAGE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the ConcernRoleImage
 * facade.
 */
public abstract class ConcernRoleImage extends curam.core.facade.base.ConcernRoleImage {

  /**
   * adds a ConcernRoleImage
   * dtls
   *
   * @param dtls - the image blob & concernRoleID
   * @return Concern Role Image identifier of the record created
   */
  @Override
  public ConcernRoleImageKey addImage(ConcernRoleImageDtls dtls)
    throws AppException, InformationalException {

    final curam.core.sl.intf.ConcernRoleImage concernRoleImageObj = ConcernRoleImageFactory.newInstance();

    return concernRoleImageObj.addImage(dtls);
  }

  /**
   * read a ConcernRoleImage
   *
   * @param key - the imageID
   * @return ConcernRoleImageDtls - the read image details
   */
  @Override
  public ConcernRoleImageDtls readImage(ConcernRoleImageKey key)
    throws AppException, InformationalException {

    // ConcernRoleImage instance
    final curam.core.intf.ConcernRoleImage concernRoleImage = curam.core.fact.ConcernRoleImageFactory.newInstance();

    // call the read
    return concernRoleImage.read(key);
  }

  /**
   * removes a ConcernRoleImage - physical delete
   *
   * @param key - the imageID
   */
  @Override
  public void removeImage(ConcernRoleImageKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ConcernRoleImage concernRoleImageObj = ConcernRoleImageFactory.newInstance();

    concernRoleImageObj.removeImage(key);
  }

  /**
   * validates the uploaded image
   *
   * @param details - the image to be validated
   */
  @Override
  public void validateImage(ConcernRoleImageDtls details)
    throws AppException, InformationalException {

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // BEGIN, CR00052924, GM
    final String kEmptyString = CuramConst.gkEmpty;
    // END, CR00052924

    final AppException ae = new AppException(
      BPOCONCERNROLEIMAGE.ERR_NO_IMAGE_SPECIFIED);

    if (details.imageBlob.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, kEmptyString, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    informationalManager.failOperation();
  }

}
