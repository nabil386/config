/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.core.facade.struct.MWRequestDetails;
import curam.core.facade.struct.MilestoneWaiverRequestDetails;
import curam.core.facade.struct.WaiverApprovalDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.entity.struct.MilestoneWaiverApprovalRequestDtls;
import curam.core.sl.entity.struct.MilestoneWaiverApprovalRequestKey;
import curam.core.sl.entity.struct.ReadMilestoneDeliveryDetails;
import curam.core.sl.entity.struct.RejectionReasonAndCommentsDetails;
import curam.core.sl.fact.MilestoneDeliveryFactory;
import curam.core.sl.intf.MilestoneDelivery;
import curam.milestonewaiver.impl.MilestoneWaiverApprovalRequest;
import curam.milestonewaiver.impl.MilestoneWaiverApprovalRequestDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This facade layer class manages all operations related to the maintenance of
 * Milestone Waiver Approval Request. This class allows the user to create a
 * waiver request, view the waiver request, approve, modify and approve,
 * reject the waiver the request.
 *
 */
public abstract class MaintainWaiverApprovalRequest extends curam.core.facade.base.MaintainWaiverApprovalRequest {

  @Inject
  protected MilestoneWaiverApprovalRequestDAO milestoneWaiverApprovalRequestDAO;

  public MaintainWaiverApprovalRequest() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * This method read the milestone details such as expected start date and end
   * date configured for the milestone administratively.
   *
   * @param key
   * @return details
   * @throws AppException, InformationalException
   */
  @Override
  public ReadMilestoneDeliveryDetails readMilestoneDeliveryDetails(
    MilestoneDeliveryKey key) throws AppException, InformationalException {

    final ReadMilestoneDeliveryDetails readMilestoneDeliveryDetails = new ReadMilestoneDeliveryDetails();

    // BEGIN, CR00146068, SAI
    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();

    final curam.core.sl.struct.ReadMilestoneDeliveryDetails readMilestoneDeliveryDtls = milestoneDeliveryObj.read(
      key);

    readMilestoneDeliveryDetails.assign(readMilestoneDeliveryDtls.readDetails);
    // END, CR00146068

    return readMilestoneDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the user to create a waiver request for a milestone and
   * submit it for the approval. It also checks whether the manual approval
   * is required or not based on case supervisor or milestone approval checks.
   * If not required it approves the waiver request automatically.
   *
   * @param key - details of waiver request requested by the user.
   *
   * @throws AppException, InformationalException
   */
  @Override
  public void createWaiverApprovalRequest(
    MilestoneWaiverApprovalRequestDtls key) throws AppException,
      InformationalException {

    final MilestoneWaiverApprovalRequest milestoneWaiverApprovalRequest = milestoneWaiverApprovalRequestDAO.newInstance();

    milestoneWaiverApprovalRequest.createWaiverRequest(key);

  }

  // ___________________________________________________________________________
  /**
   * This method lists all the waivers requested for a milestone along with the
   * status whether it is in submit status or approved or rejected.
   *
   * @param key - Identifies the milestone ID
   * @return returns the details of waiver requested.
   * @throws AppException, InformationalException
   */
  @Override
  public MWRequestDetails listMilestoneWaiverRequests(MilestoneDeliveryKey key)
    throws AppException, InformationalException {

    final MWRequestDetails mWRequestDetails = milestoneWaiverApprovalRequestDAO.searchByMilestoneDeliveryID(
      key);

    return mWRequestDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method reads the details of waiver request.
   *
   * @param key - Identifies the milestone waiver request ID
   * @return details - returns the waiver request details.
   * @throws AppException, InformationalException
   */
  @Override
  public MilestoneWaiverRequestDetails readMilestoneWaiverRequests(
    MilestoneWaiverApprovalRequestKey key) throws AppException,
      InformationalException {

    final MilestoneWaiverRequestDetails milestoneWaiverRequestDetails = milestoneWaiverApprovalRequestDAO.readMilestoneWaiverRequests(
      key);

    return milestoneWaiverRequestDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method allows to approve the waiver request. It also checks the date
   * validations and whether the approver has the supervisor privilege to
   * approve the waiver or checks he approval check for a user or for user
   * belonging to a organization and which has approval check.
   *
   * @param key - Identifies the milestone waiver request ID
   * @throws AppException, InformationalException
   */
  @Override
  public void approveWaiver(MilestoneWaiverApprovalRequestKey key)
    throws AppException, InformationalException {

    final MilestoneWaiverApprovalRequest milestoneWaiverApprovalRequest = milestoneWaiverApprovalRequestDAO.newInstance();

    milestoneWaiverApprovalRequest.approve(key.waiverApprovalRequestID, false);

  }

  // ___________________________________________________________________________
  /**
   * This method allows system to modify the waiver request details and approve
   * the waiver request. It also checks the date validations and whether the
   * approver has the supervisor privilege to approve the waiver or checks he
   * approval check for a user or for user belonging to a organization and which
   * has approval check.
   *
   * @param key - Identifies the milestone waiver request ID
   * @throws AppException, InformationalException
   */
  @Override
  public void modifyAndApprove(MilestoneWaiverApprovalRequestKey key,
    WaiverApprovalDetails details) throws AppException,
      InformationalException {

    final MilestoneWaiverApprovalRequest milestoneWaiverApprovalRequest = milestoneWaiverApprovalRequestDAO.newInstance();

    milestoneWaiverApprovalRequest.modifyAndApprove(key.waiverApprovalRequestID,
      details);

  }

  // ___________________________________________________________________________
  /**
   * This method allows to reject the waiver request. It also checks the date
   * validations and whether the logged in user has the supervisor privilege to
   * reject the waiver.
   *
   * @param key - Identifies the milestone waiver request ID
   * @throws AppException, InformationalException
   */
  @Override
  public void rejectWaiver(MilestoneWaiverApprovalRequestKey key,
    RejectionReasonAndCommentsDetails details) throws AppException,
      InformationalException {

    final MilestoneWaiverApprovalRequest milestoneWaiverApprovalRequest = milestoneWaiverApprovalRequestDAO.newInstance();

    milestoneWaiverApprovalRequest.reject(key.waiverApprovalRequestID, details);

  }

  // ___________________________________________________________________________
  /**
   * This method reads the expected start date and end date of a waiver request.
   *
   * @param key - Identifies the milestone waiver request ID
   * @return details - returns the approval expected start and end date.
   * @throws AppException, InformationalException
   */
  @Override
  public WaiverApprovalDetails readExpStartAndEndDate(
    MilestoneWaiverApprovalRequestKey key) throws AppException,
      InformationalException {

    final WaiverApprovalDetails waiverApprovalDetails = new WaiverApprovalDetails();

    final MilestoneWaiverApprovalRequest milestoneWaiverApprovalRequest = milestoneWaiverApprovalRequestDAO.get(
      key.waiverApprovalRequestID);

    waiverApprovalDetails.expectedStartDate = milestoneWaiverApprovalRequest.getRequestedExpStartDate();
    waiverApprovalDetails.expectedEndDate = milestoneWaiverApprovalRequest.getRequestedExpEndDate();
    waiverApprovalDetails.versionNo = milestoneWaiverApprovalRequest.getVersionNo();

    return waiverApprovalDetails;
  }

}
