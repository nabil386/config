/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.struct.BatchProcessingDate;
import curam.message.BPOSCANTASKDEADLINES;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;


/**
 * Standard implementation of {@link curam.core.facade.intf.ScanTaskDeadlines}.
 */
public abstract class ScanTaskDeadlines extends curam.core.facade.base.ScanTaskDeadlines {

  // the batch log output stream
  protected static java.io.PrintStream stOutstream;

  /**
   * {@inheritDoc}
   */
  @Override
  public void scanDeadlines(BatchProcessingDate processingDate)
    throws AppException, InformationalException {

    if (StringUtil.isNullOrEmpty(TransactionInfo.getProgramUser())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSCANTASKDEADLINES.ERR_BATCH_USERNAME_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // setup the batch output file name
    final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

    curamBatchObj.outputFileID = BPOSCANTASKDEADLINES.INF_BATCH_FILE_NAME.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    curamBatchObj.datFileExt = curam.core.impl.CuramConst.gkDataFileExt;
    curamBatchObj.setFileName();

    // open the batch output file
    try {
      stOutstream = new java.io.PrintStream(
        new java.io.FileOutputStream(curamBatchObj.outputFilename));

    } catch (final java.io.FileNotFoundException e) {

      throw new curam.util.exception.AppRuntimeException(e);

    }

    // check that the output file was opened correctly
    if (stOutstream.checkError()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSCANTASKDEADLINES.ERR_SCAN_DEADLINES_FILE_OPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    curamBatchObj.setStartTime(); // set start time for batch processing

    // call workflow method to scan task deadlines
    curam.util.workflow.impl.DeadlineScanner.scanDeadlines();

    curamBatchObj.setEndTime(); // set end time for batch processing

    // close the output stream.
    stOutstream.close();

    final int stringBufferZeroSize = 0;
    final int messageLength = 4096;
    final StringBuffer emailMessageString = new StringBuffer(messageLength);

    // reset string buffer to empty
    emailMessageString.setLength(stringBufferZeroSize);

    curamBatchObj.emailMessage = emailMessageString.toString();

    // constructing the email subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOSCANTASKDEADLINES.INF_SCAN_DEADLINES_SUBJECT);

    // sending the email
    curamBatchObj.sendEmail();
  }
}
