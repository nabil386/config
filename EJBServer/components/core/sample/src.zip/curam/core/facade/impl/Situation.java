/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.core.facade.struct.AllegationIDSituationIDKey;
import curam.core.facade.struct.AssociateActionWithSituationDtls;
import curam.core.facade.struct.ListMemberDetails;
import curam.core.facade.struct.MemberDetails;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.intf.Person;
import curam.core.intf.ProspectPerson;
import curam.core.sl.entity.fact.RepresentativeFactory;
import curam.core.sl.entity.fact.SituationConcernFactory;
import curam.core.sl.entity.intf.Representative;
import curam.core.sl.entity.struct.ActionIDActionDtlsList;
import curam.core.sl.entity.struct.ActionPlanKey;
import curam.core.sl.entity.struct.ActionPlanSituationKey;
import curam.core.sl.entity.struct.ActionSituationLinkDtls;
import curam.core.sl.entity.struct.AllegationDtlsList;
import curam.core.sl.entity.struct.SituationConcernDtls;
import curam.core.sl.entity.struct.SituationConcernDtlsList;
import curam.core.sl.entity.struct.SituationDtlsList;
import curam.core.sl.entity.struct.SituationIDAndRecordStatusDtls;
import curam.core.sl.entity.struct.SituationKey;
import curam.core.sl.fact.ActionFactory;
import curam.core.sl.fact.SituationFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.intf.Action;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.ActionIDSituationIDKey;
import curam.core.sl.struct.CalculationEndDate;
import curam.core.sl.struct.CalculationStartDate;
import curam.core.sl.struct.CaseIDSituationIDKey;
import curam.core.sl.struct.CaseParticipantTabList;
import curam.core.sl.struct.SituationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.PersonKey;
import curam.core.struct.ProspectPersonKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.type.Date;
import curam.util.type.StringList;


/**
 * This process class provides the functionality for the Situation facade layer.
 */

public class Situation extends curam.core.facade.base.Situation {

  // BEGIN, CR00179058, AK
  /**
   * Method to associate actions with the Situation. Associates the list of
   * existing actions and also if a new action has to be associated, creates the
   * new action record and then links it with the situation.
   *
   * @param associateWithSituationDetails
   * Contains the details of the selected Actions and Action to be
   * created and associated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void associateAction(
    AssociateActionWithSituationDtls associateWithSituationDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    final Action actionobj = ActionFactory.newInstance();
    ActionSituationLinkDtls dtls;

    // BEGIN, CR00226282, AK
    if (ClientActionConst.kAssociateNew.equals(
      associateWithSituationDetails.clientActionID)) {
      // BEGIN, CR00208312, AK
      if (!CuramConst.gkEmpty.equals(
        associateWithSituationDetails.newActionDtls.actionDetails.dtls.action)
          || !CuramConst.gkEmpty.equals(
            associateWithSituationDetails.newActionDtls.caseParticipantsTabList)
            || !CuramConst.gkEmpty.equals(
              associateWithSituationDetails.newActionDtls.userOwner)) {
        // END, CR00208312
        dtls = new ActionSituationLinkDtls();
        dtls.actionID = actionobj.createAction(associateWithSituationDetails.newActionDtls).actionID;
        dtls.situationID = associateWithSituationDetails.situationID;
        situationObj.associateActionAndSituation(dtls);
      }
    } else if (ClientActionConst.kAssociateExisting.equals(
      associateWithSituationDetails.clientActionID)) {
      final StringList actionStringList = StringUtil.tabText2StringListWithTrim(
        associateWithSituationDetails.actionList);

      for (int i = 0; i < actionStringList.size(); i++) {
        dtls = new ActionSituationLinkDtls();
        dtls.actionID = Long.parseLong(actionStringList.item(i));
        dtls.situationID = associateWithSituationDetails.situationID;
        situationObj.associateActionAndSituation(dtls);
      }
    }
    // END, CR00226282
  }

  // END, CR00179058

  /**
   * Method to create a Situation.
   *
   * @param createSituationDetails
   * Contains the Situation details.
   *
   * @return The Situation key for the created Situation.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public SituationKey createSituation(SituationDetails createSituationDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    final SituationKey situationKey = situationObj.create(
      createSituationDetails);

    return situationKey;
  }

  /**
   * Method to cancel a Situation.
   *
   * @param situationKey
   * Contains the Situation ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelSituation(SituationKey situationKey) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();

    situationObj.cancel(situationKey);
  }

  /**
   * Method to modify a Situation.
   *
   * @param situationDtls
   * Contains the details of the situation to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifySituation(SituationDetails situationDtls)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();

    situationObj.modify(situationDtls);
  }

  /**
   * Method to remove a Action Situation Association.
   *
   * @param actionIDSituationIDKey
   * Contains the IDs of the action and situation to be dissociated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void removeAction(ActionIDSituationIDKey actionIDSituationIDKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();

    situationObj.removeActionAssociation(actionIDSituationIDKey);
  }

  /**
   * Method to read a Situation.
   *
   * @param situationKey
   * Contains the Situation ID
   *
   * @return The Details of the Situation read.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public SituationDetails viewSituation(SituationKey situationKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    final SituationDetails situationDetails = situationObj.view(situationKey);

    return situationDetails;
  }

  /**
   * Method to list the Actions that can be Associated with the Situation.
   *
   * @param actionPlanSituationkey
   * Contains the Action Plan ID and Situation ID
   *
   * @return The list of details of the Actions that can be associated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ActionIDActionDtlsList listActionsforAssociation(
    ActionPlanSituationKey actionPlanSituationkey) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    final ActionIDActionDtlsList actionList = situationObj.listActionsForAssociation(
      actionPlanSituationkey);

    return actionList;
  }

  /**
   * Method to list the Situations for an ActionPlan.
   *
   * @param actionPlanKey
   * Contains the Action Plan ID.
   *
   * @return The list of Situations.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public SituationDtlsList listSituations(ActionPlanKey actionPlanKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    final SituationDtlsList situationList = situationObj.list(actionPlanKey);

    return situationList;
  }

  // BEGIN, CR00179058, AK
  /**
   * Method to list the case participants of the associated case who can be
   * chosen as Situation concerns.
   *
   * @param caseIDSituationIDKey
   * Contains the Case ID and the Situation ID.
   *
   * @return The tab delimited list of case participants.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CaseParticipantTabList getSituationConcernTabList(
    CaseIDSituationIDKey caseIDSituationIDKey) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    final CaseParticipantTabList situationList = situationObj.getSituationConcernTabList(
      caseIDSituationIDKey);

    return situationList;
  }

  /**
   * Method to list the Actions associated with the Situation.
   *
   * @param situationKey
   * Contains the Situation ID.
   *
   * @return The list of action ID and action description details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ActionIDActionDtlsList listAssociatedActions(
    SituationKey situationKey) throws AppException, InformationalException {

    return SituationFactory.newInstance().listAssociatedActions(situationKey);
  }

  /**
   * Method to list of the participants whom the Situation concerns about.
   * The list elements comprises of the Situation Concern name along with age
   * in brackets and the ConcernRole ID.
   *
   * @param situationKey
   * Contains the Situation ID.
   *
   * @return the list of Situation Concerns.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListMemberDetails getSituationConcernList(SituationKey situationKey)
    throws AppException, InformationalException {

    final ListMemberDetails situationConcernDetailsList = new ListMemberDetails();
    SituationConcernDtlsList situationConcernList = new SituationConcernDtlsList();
    final SituationIDAndRecordStatusDtls situationIDAndRecordStatusDtls = new SituationIDAndRecordStatusDtls();
    MemberDetails situationConcernDetails;
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey;
    PersonKey personKey;
    final Person personObj = PersonFactory.newInstance();
    // BEGIN, CR00214099, AK
    final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    final CalculationEndDate endDate = new CalculationEndDate();
    final CalculationStartDate startDate = new CalculationStartDate();

    // END, CR00214099

    situationIDAndRecordStatusDtls.situationID = situationKey.situationID;
    situationConcernList = SituationConcernFactory.newInstance().searchBySituationID(
      situationIDAndRecordStatusDtls);
    for (final SituationConcernDtls situationConcernDtls : situationConcernList.dtls.items()) {
      concernRoleKey = new ConcernRoleKey();
      situationConcernDetails = new MemberDetails();
      situationConcernDetails.participantRoleID = situationConcernDtls.concernRoleID;
      // BEGIN, CR00235689, AK
      concernRoleKey.concernRoleID = situationConcernDtls.concernRoleID;
      situationConcernDetails.name = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
        concernRoleKey);

      if (CONCERNROLETYPE.PERSON.equals(concernRoleTypeDetails.concernRoleType)) {
        personKey = new PersonKey();
        personKey.concernRoleID = situationConcernDtls.concernRoleID;
        startDate.startDate = personObj.readDateOfBirth(personKey).dateOfBirth;
      }
      if (CONCERNROLETYPE.REPRESENTATIVE.equals(
        concernRoleTypeDetails.concernRoleType)) {
        final Representative representativeObj = RepresentativeFactory.newInstance();

        startDate.startDate = representativeObj.readRepresentativeDetails(concernRoleKey).dateOfBirth;
      }
      if (CONCERNROLETYPE.PROSPECTPERSON.equals(
        concernRoleTypeDetails.concernRoleType)) {
        final ProspectPerson prospectPersonObj = ProspectPersonFactory.newInstance();
        final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

        prospectPersonKey.concernRoleID = situationConcernDtls.concernRoleID;
        startDate.startDate = prospectPersonObj.readProspectPersonDOB(prospectPersonKey).dateOfBirth;
      }
      // Build the name to display along with age in brackets.
      if (!Date.kZeroDate.equals(startDate.startDate)) {
        endDate.endDate = Date.getCurrentDate();
        situationConcernDetails.name = situationConcernDetails.name.concat(GeneralConstants.kSpace).concat(GeneralConstants.kOpenBracket).concat(String.valueOf(tabDetailFormatterObj.calculateAge(startDate, endDate).ageYears)).concat(
          GeneralConstants.kCloseBracket);
      }
      // END, CR00235689
      situationConcernDetailsList.memberDetailsList.dtls.addRef(
        situationConcernDetails);
    }
    return situationConcernDetailsList;
  }

  /**
   * Method to list the Allegations associated with the Situation.
   *
   * @param situationKey
   * Contains the Situation ID.
   *
   * @return The details list of Allegations
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AllegationDtlsList listAssociatedAllegations(
    SituationKey situationKey) throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();

    return situationObj.listAssociatedAllegations(situationKey);

  }

  // END, CR00179058

  // BEGIN, CR00206887, AK
  /**
   * Method to remove an Allegation-Situation association.
   *
   * @param allegationSituationKey
   * Contains the Allegation ID and the Situation ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void removeAllegationAssociation(
    AllegationIDSituationIDKey allegationSituationKey) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();

    situationObj.removeAllegationAssociation(allegationSituationKey);
  }
  // END, CR00206887
}
