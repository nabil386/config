/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditCaseConfigKey;
import curam.caseaudit.entity.struct.AuditCaseTypeAndCategory;
import curam.caseaudit.entity.struct.CaseTypeKey;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditCaseConfigDAO;
import curam.caseaudit.impl.AuditCaseFocusArea;
import curam.caseaudit.impl.AuditCaseFocusAreaDAO;
import curam.caseaudit.impl.AuditCaseSelectionQuery;
import curam.caseaudit.impl.AuditCaseSelectionQueryDAO;
import curam.codetable.AUDITCASEFOCUSAREA;
import curam.codetable.AUDITCASETYPECODE;
import curam.codetable.CASECATTYPECODE;
import curam.codetable.SECURITYIDENTIFIERTYPE;
import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.codetable.impl.AUDITCASETYPECODEEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.codetable.impl.SELECTIONQUERYCATEGORYEntry;
import curam.core.facade.struct.AuditCaseConfigDetails;
import curam.core.facade.struct.AuditCaseConfigListDetails;
import curam.core.facade.struct.AuditCaseConfigListDetailsList;
import curam.core.facade.struct.AvailableFocusAreasAndQueries;
import curam.core.facade.struct.CaseAuditType;
import curam.core.facade.struct.CaseTypeAndCatTypeName;
import curam.core.facade.struct.CreateAuditCaseConfigDetails;
import curam.core.facade.struct.FocusArea;
import curam.core.facade.struct.FocusAreaList;
import curam.core.facade.struct.FocusAreasAndQueryList;
import curam.core.facade.struct.ModifyAuditCaseConfigDetails;
import curam.core.facade.struct.SecurityIDList;
import curam.core.facade.struct.SelectedFixedQueries;
import curam.core.facade.struct.SelectedFocusAreas;
import curam.core.facade.struct.SelectionQueryListDetails;
import curam.core.facade.struct.SelectionQueryListDetailsList;
import curam.core.facade.struct.ViewAuditCaseConfigDetails;
import curam.core.fact.SecurityLinkFactory;
import curam.core.impl.CuramConst;
import curam.core.struct.SIDTypeKey;
import curam.message.ENTAUDITCASECONFIG;
import curam.message.ENTAUDITCASEFOCUSAREA;
import curam.message.FACADECASEAUDITCONFIGURATION;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.StringList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;


/**
 * Facade Class for the CaseAuditConfiguration implementation.
 *
 */
public abstract class CaseAuditConfiguration extends curam.core.facade.base.CaseAuditConfiguration {

  @Inject
  protected AuditCaseConfigDAO auditCaseConfigDAO;

  @Inject
  protected AuditCaseFocusAreaDAO auditCaseFocusAreaDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  @Inject
  protected AuditCaseSelectionQueryDAO auditCaseSelectionQueryDAO;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public CaseAuditConfiguration() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Method to list all audit case configurations on the system.
   *
   * @return List of all audit case configurations on the system
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AuditCaseConfigListDetailsList listCaseAuditConfigurations()
    throws AppException, InformationalException {

    final AuditCaseConfigListDetailsList auditCaseConfigListDetailsList = new AuditCaseConfigListDetailsList();
    AuditCaseConfigListDetails auditCaseConfigListDetails;

    final List<AuditCaseConfig> auditCaseConfigList = auditCaseConfigDAO.readAll();

    for (final AuditCaseConfig auditCaseConfig : auditCaseConfigList) {

      auditCaseConfigListDetails = new AuditCaseConfigListDetails();

      auditCaseConfigListDetails.dtls.auditCaseConfigID = auditCaseConfig.getID();
      auditCaseConfigListDetails.dtls.caseType = auditCaseConfig.getCaseType().getCode();
      auditCaseConfigListDetails.dtls.caseCategory = auditCaseConfig.getCaseCategory().getCode();
      auditCaseConfigListDetails.dtls.auditAlgorithm = auditCaseConfig.getAuditAlgorithm().getCode();
      auditCaseConfigListDetails.dtls.caseAuditTypeSID = auditCaseConfig.getCaseAuditTypeSID();
      auditCaseConfigListDetails.categoryName = curam.util.type.CodeTable.getOneItem(
        CASECATTYPECODE.TABLENAME, auditCaseConfigListDetails.dtls.caseCategory);

      if (auditCaseConfig.getDynamicQuery() != null) {
        auditCaseConfigListDetails.dynamicQueryName = auditCaseConfig.getDynamicQuery().getName();
      }

      auditCaseConfigListDetailsList.dtls.addRef(auditCaseConfigListDetails);
    }

    return auditCaseConfigListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to view the details of an Audit Case configuration.
   *
   * @param key The unique identifier of the Audit Case configuration record
   *
   * @return The audit case configuration details
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ViewAuditCaseConfigDetails viewAuditCaseConfiguration(
    final AuditCaseConfigKey key) throws AppException, InformationalException {

    final ViewAuditCaseConfigDetails viewAuditCaseConfigDetails = new ViewAuditCaseConfigDetails();
    FocusArea focusArea;

    // Get the basic configuration details
    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      key.auditCaseConfigID);

    viewAuditCaseConfigDetails.configDtls.dtls.auditCaseConfigID = auditCaseConfigObj.getID();
    viewAuditCaseConfigDetails.configDtls.dtls.caseType = auditCaseConfigObj.getCaseType().getCode();
    viewAuditCaseConfigDetails.configDtls.dtls.caseCategory = auditCaseConfigObj.getCaseCategory().getCode();
    viewAuditCaseConfigDetails.configDtls.dtls.manCaseSelectInd = auditCaseConfigObj.isManualCaseSelectionAllowed();
    viewAuditCaseConfigDetails.configDtls.dtls.auditAlgorithm = auditCaseConfigObj.getAuditAlgorithm().getCode();
    viewAuditCaseConfigDetails.configDtls.dtls.caseAuditTypeSID = auditCaseConfigObj.getCaseAuditTypeSID();
    viewAuditCaseConfigDetails.configDtls.dtls.versionNo = auditCaseConfigObj.getVersionNo();

    viewAuditCaseConfigDetails.configDtls.categoryName = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME, auditCaseConfigObj.getCaseCategory().getCode());

    // Get the list of selected focus areas
    final Set<AuditCaseFocusArea> focusAreaSet = auditCaseConfigObj.getSelectedFocusAreas();

    // Only display the focus areas cluster if there is something to display
    if (focusAreaSet.size() > 0) {
      viewAuditCaseConfigDetails.displayFocusAreas = true;
    }

    for (final AuditCaseFocusArea auditCaseFocusArea : focusAreaSet) {

      focusArea = new FocusArea();
      focusArea.focusAreaCode = auditCaseFocusArea.getFocusArea().getCode();
      viewAuditCaseConfigDetails.focusAreas.focusAreas.addRef(focusArea);
    }

    if (auditCaseConfigObj.getDynamicQuery() != null) {
      viewAuditCaseConfigDetails.dynamicQueryName = auditCaseConfigObj.getDynamicQuery().getName();
    }

    // Get the list of selected fixed queries
    final List<curam.selectionquery.impl.SelectionQuery> fixedQueries = auditCaseConfigObj.getFixedQueries();

    // Only display the fixed queries cluster if there is something to display
    if (fixedQueries.size() > 0) {
      viewAuditCaseConfigDetails.displayFixedQueries = true;
    }

    for (final curam.selectionquery.impl.SelectionQuery selectionQuery : fixedQueries) {

      final SelectionQueryListDetails selectionQueryListDetails = new SelectionQueryListDetails();

      selectionQueryListDetails.queryID = selectionQuery.getID();
      selectionQueryListDetails.queryName = selectionQuery.getName();

      viewAuditCaseConfigDetails.fixedQueries.dtls.addRef(
        selectionQueryListDetails);
    }

    return viewAuditCaseConfigDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to create an audit case configuration.
   * This includes the insertion of any selected focus areas.
   *
   * @param details the audit case configuration details.
   *
   * @return The unique identifier of the case audit configuration record
   * created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AuditCaseConfigKey createAuditCaseConfiguration(
    final CreateAuditCaseConfigDetails details) throws AppException,
      InformationalException {

    // Create the audit case config record
    final AuditCaseConfigKey auditCaseConfigKey = createAuditCaseConfig(
      details.configDtls);

    // Create the focus area links
    createFocusAreaLinks(auditCaseConfigKey, details);

    // Create the selection query links
    createQueryLinks(auditCaseConfigKey, details);

    return auditCaseConfigKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify an audit case configuration.
   *
   * @param details Details of the audit case configuration to modify
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyAuditCaseConfiguration(
    final ModifyAuditCaseConfigDetails details) throws AppException,
      InformationalException {

    // Modify the main audit case configuration record
    modifyAuditCaseConfig(details.configDtls);

    final AuditCaseConfigKey auditCaseConfigKey = new AuditCaseConfigKey();

    auditCaseConfigKey.auditCaseConfigID = details.configDtls.dtls.auditCaseConfigID;

    // Update the focus areas
    modifyFocusAreaLinks(auditCaseConfigKey, details);

    // Update the queries
    modifyQueryLinks(auditCaseConfigKey, details);
  }

  // ___________________________________________________________________________
  /**
   * Method to list all selected and available focus areas and queries.
   *
   * @param key the audit case type and category
   *
   * @return list of all selected and available focus areas and queries.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FocusAreasAndQueryList populateFocusAreasAndQueries(
    final AuditCaseTypeAndCategory key) throws AppException,
      InformationalException {

    final FocusAreasAndQueryList focusAreasAndQueryList = new FocusAreasAndQueryList();

    final CaseTypeKey auditCaseType = new CaseTypeKey();

    auditCaseType.caseType = key.caseType;

    final AuditCaseConfig auditCaseConfig = auditCaseConfigDAO.readByCaseTypeAndCategory(
      AUDITCASETYPECODEEntry.get(key.caseType),
      CASECATTYPECODEEntry.get(key.caseCategory));

    focusAreasAndQueryList.dtls.dtls.manCaseSelectInd = auditCaseConfig.isManualCaseSelectionAllowed();
    focusAreasAndQueryList.dtls.dtls.auditCaseConfigID = auditCaseConfig.getID();
    focusAreasAndQueryList.dtls.dtls.auditAlgorithm = auditCaseConfig.getAuditAlgorithm().getCode();
    focusAreasAndQueryList.dtls.dtls.caseAuditTypeSID = auditCaseConfig.getCaseAuditTypeSID();
    focusAreasAndQueryList.dtls.dtls.versionNo = auditCaseConfig.getVersionNo();

    focusAreasAndQueryList.availableFocusAreas = getAvailableFocusAreas();
    focusAreasAndQueryList.selectedFocusAreas = getSelectedFocusAreas(key).selectedFocusAreas;

    focusAreasAndQueryList.availableFixedQueries = getAvailableFixedQueries();
    focusAreasAndQueryList.selectedFixedQueries = getSelectedFixedQueries(key).selectedFixedQueries;

    // Only display fixed queries cluster if there is something to display
    if (focusAreasAndQueryList.availableFixedQueries.dtls.size() > 0) {
      focusAreasAndQueryList.displayFixedQueries = true;
    }

    focusAreasAndQueryList.availableDynamicQueries = getAvailableDynamicQueries();
    focusAreasAndQueryList.selectedDynamicQueryID = auditCaseConfig.getDynamicQuery().getID();

    focusAreasAndQueryList.selectedCaseType = curam.util.type.CodeTable.getOneItem(
      AUDITCASETYPECODE.TABLENAME, key.caseType);
    focusAreasAndQueryList.selectedCategory = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME, key.caseCategory);

    return focusAreasAndQueryList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all selected focus areas.
   *
   * @param key the audit case type and category
   *
   * @return list of all selected focus areas in a String format.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected SelectedFocusAreas getSelectedFocusAreas(
    final AuditCaseTypeAndCategory key) throws AppException,
      InformationalException {

    final SelectedFocusAreas selectedFocusAreas = new SelectedFocusAreas();

    // Get the list of selected focus areas for the case type
    // and category specified.
    final AuditCaseConfig auditCaseConfig = auditCaseConfigDAO.readByCaseTypeAndCategory(
      AUDITCASETYPECODEEntry.get(key.caseType),
      CASECATTYPECODEEntry.get(key.caseCategory));

    if (auditCaseConfig != null) {

      final Set<AuditCaseFocusArea> selectedSet = auditCaseConfig.getSelectedFocusAreas();

      int counter = 0;

      // construct tab-separated focus area string like "100\t101\t102"
      if (!selectedSet.isEmpty()) {

        final Iterator<AuditCaseFocusArea> auditCaseFocusAreaIterator = selectedSet.iterator();

        while (auditCaseFocusAreaIterator.hasNext()) {

          if (counter != 0) {
            selectedFocusAreas.selectedFocusAreas += CuramConst.gkTabDelimiter;
          }

          selectedFocusAreas.selectedFocusAreas += auditCaseFocusAreaIterator.next().getFocusArea();

          counter++;
        }
      }
    }

    return selectedFocusAreas;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all available focus areas.
   *
   * @return list of all available focus areas
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FocusAreaList getAvailableFocusAreas() throws AppException,
      InformationalException {

    final FocusAreaList focusAreaList = new FocusAreaList();
    FocusArea focusArea;

    final LinkedHashMap<String, String> focusAreaHashMap = CodeTable.getAllEnabledItems(
      AUDITCASEFOCUSAREA.TABLENAME, TransactionInfo.getProgramLocale());

    if (!focusAreaHashMap.isEmpty()) {

      final Set<String> keys = focusAreaHashMap.keySet();
      final Iterator<String> itr = keys.iterator();

      while (itr.hasNext()) {
        final String focusAreaKey = itr.next().toString();

        focusArea = new FocusArea();
        focusArea.focusAreaCode = focusAreaKey;
        focusAreaList.focusAreas.addRef(focusArea);
      }
    }

    return focusAreaList;
  }

  // ___________________________________________________________________________
  /**
   * Method to insert an Audit Case Config record.
   *
   * @param details Details of the Audit Case configuration to insert
   *
   * @return The audit case configuration key created
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected AuditCaseConfigKey createAuditCaseConfig(
    final AuditCaseConfigDetails details) throws AppException,
      InformationalException {

    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.newInstance();

    auditCaseConfigObj.setAuditAlgorithm(
      SAMPLINGSTRATEGYEntry.get(details.dtls.auditAlgorithm));
    auditCaseConfigObj.setCaseAuditTypeSID(details.dtls.caseAuditTypeSID);
    auditCaseConfigObj.setCaseType(
      AUDITCASETYPECODEEntry.get(details.dtls.caseType));
    auditCaseConfigObj.setCaseCategory(
      CASECATTYPECODEEntry.get(details.dtls.caseCategory));
    auditCaseConfigObj.setManualCaseSelectionInd(details.dtls.manCaseSelectInd);

    auditCaseConfigObj.insert();

    final AuditCaseConfigKey auditCaseConfigKey = new AuditCaseConfigKey();

    auditCaseConfigKey.auditCaseConfigID = auditCaseConfigObj.getID();

    return auditCaseConfigKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify an Audit Case Config record.
   *
   * @param details the modified configuration details
   *
   * @return the unique identifier of the audit case configuration
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected AuditCaseConfigKey modifyAuditCaseConfig(
    final AuditCaseConfigDetails details) throws AppException,
      InformationalException {

    final AuditCaseConfigKey auditCaseConfigKey = new AuditCaseConfigKey();

    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      details.dtls.auditCaseConfigID);

    auditCaseConfigObj.setManualCaseSelectionInd(details.dtls.manCaseSelectInd);
    auditCaseConfigObj.setAuditAlgorithm(
      SAMPLINGSTRATEGYEntry.get(details.dtls.auditAlgorithm));
    auditCaseConfigObj.setCaseAuditTypeSID(details.dtls.caseAuditTypeSID);

    auditCaseConfigObj.modify(details.dtls.versionNo);

    auditCaseConfigKey.auditCaseConfigID = auditCaseConfigObj.getID();

    return auditCaseConfigKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to associate focus areas to a specific case audit configuration.
   *
   * @param key the audit case configuration unique identifier.
   * @param details the audit case configuration details.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void createFocusAreaLinks(final AuditCaseConfigKey key,
    final CreateAuditCaseConfigDetails details) throws AppException,
      InformationalException {

    // Validate the focus areas
    validateFocusAreas(details);

    // Manipulation variables to add focus areas
    final StringList focusAreasList = StringUtil.tabText2StringListWithTrim(
      details.selectedFocusAreas);
    final int focusAreaSize = focusAreasList.size();

    // Insert new focus area selections into database.
    for (int i = 0; i < focusAreaSize; i++) {

      final String focusArea = focusAreasList.item(i);
      final AuditCaseFocusArea auditCaseFocusAreaObj = auditCaseFocusAreaDAO.newInstance();

      auditCaseFocusAreaObj.setAuditCaseConfig(
        auditCaseConfigDAO.get(key.auditCaseConfigID));
      auditCaseFocusAreaObj.setFocusArea(AUDITCASEFOCUSAREAEntry.get(focusArea));

      auditCaseFocusAreaObj.insert();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to allow an administrator to modify the configured focus areas
   * for a specified case type and category.
   *
   * @param key the key of the configuration that is being updated
   * @param details the modified configuration details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void modifyFocusAreaLinks(final AuditCaseConfigKey key,
    final ModifyAuditCaseConfigDetails details) throws AppException,
      InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Manipulation variables to add/remove focus areas
    final StringList initialFocusAreasList = StringUtil.tabText2StringListWithTrim(
      details.initialFocusAreas);
    final StringList updatedFocusAreasList = StringUtil.tabText2StringListWithTrim(
      details.updatedFocusAreas);
    final int initialFocusAreaSize = initialFocusAreasList.size();
    final int updatedFocusAreaSize = updatedFocusAreasList.size();

    if (updatedFocusAreaSize == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          ENTAUDITCASEFOCUSAREA.ERR_FV_MANDATORY_FOCUS_AREA_NOT_SET),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
      informationalManager.failOperation();
    }

    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      key.auditCaseConfigID);

    // Insert new focus area selections into database.
    for (int i = 0; i < updatedFocusAreaSize; i++) {

      final String focusArea = updatedFocusAreasList.item(i);

      // If the selected focus area is not already selected
      // insert the record into database.
      if (!initialFocusAreasList.contains(focusArea)) {

        final AuditCaseFocusArea auditCaseFocusAreaObj = auditCaseFocusAreaDAO.newInstance();

        auditCaseFocusAreaObj.setAuditCaseConfig(auditCaseConfigObj);
        auditCaseFocusAreaObj.setFocusArea(
          AUDITCASEFOCUSAREAEntry.get(focusArea));

        auditCaseFocusAreaObj.insert();
      }
    }

    // Remove focus area selections from the database.
    for (int i = 0; i < initialFocusAreaSize; i++) {

      final String focusArea = initialFocusAreasList.item(i);

      // If the original focus area selection is not in the updated list,
      // delete the record
      if (!updatedFocusAreasList.contains(focusArea)) {

        final Set<AuditCaseFocusArea> auditCaseFocusArea = auditCaseFocusAreaDAO.searchByAuditCaseConfigAndFocusArea(
          auditCaseConfigObj, AUDITCASEFOCUSAREAEntry.get(focusArea));

        final Iterator<AuditCaseFocusArea> auditCaseFocusAreaIterator = auditCaseFocusArea.iterator();

        while (auditCaseFocusAreaIterator.hasNext()) {

          final AuditCaseFocusArea auditCaseFocusAreaObj = auditCaseFocusAreaDAO.get(
            auditCaseFocusAreaIterator.next().getID());

          auditCaseFocusAreaObj.remove();
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to validate that the correct focus area information
   * has been entered.
   *
   * @param details the audit case configuration details.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void validateFocusAreas(final CreateAuditCaseConfigDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final StringList focusAreasList = StringUtil.tabText2StringListWithTrim(
      details.selectedFocusAreas);
    final int focusAreaSize = focusAreasList.size();

    if (focusAreaSize == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          ENTAUDITCASEFOCUSAREA.ERR_FV_MANDATORY_FOCUS_AREA_NOT_SET),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      informationalManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to check that the configuration can be created.
   *
   * @param key the audit case type and category
   *
   * @return The audit case type and category passed in.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseTypeAndCatTypeName validateConfiguration(
    final CaseTypeAndCatTypeName key) throws AppException,
      InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (key.caseType.length() == 0 || key.catTypeName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          ENTAUDITCASECONFIG.ERR_FV_MANDATORY_CASE_AUDIT_TYPE_NOT_SET),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

      informationalManager.failOperation();
    }

    // Check if the configuration already exists
    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.readByCaseTypeAndCategory(
      AUDITCASETYPECODEEntry.get(key.caseType),
      CASECATTYPECODEEntry.get(key.catTypeName));

    if (auditCaseConfigObj != null) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(ENTAUDITCASECONFIG.ERR_RV_CONFIGURATION_ALREADY_EXISTS),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      informationalManager.failOperation();
    }

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all available focus areas, queries and the selected case
   * type and category.
   *
   * @param key the selected case type and category
   *
   * @return list of all available focus areas, queries and the selected case
   * type and category
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AvailableFocusAreasAndQueries getAvailableFocusAreasAndQueries(
    final AuditCaseTypeAndCategory key) throws AppException,
      InformationalException {

    final AvailableFocusAreasAndQueries availableFocusAreasAndQueries = new AvailableFocusAreasAndQueries();

    availableFocusAreasAndQueries.focusAreaList = getAvailableFocusAreas();

    availableFocusAreasAndQueries.availableFixedQueries = getAvailableFixedQueries();

    // Only display fixed queries cluster if there is something to display
    if (availableFocusAreasAndQueries.availableFixedQueries.dtls.size() > 0) {
      availableFocusAreasAndQueries.displayFixedQueries = true;
    }

    availableFocusAreasAndQueries.availableDynamicQueries = getAvailableDynamicQueries();

    availableFocusAreasAndQueries.caseType = curam.util.type.CodeTable.getOneItem(
      AUDITCASETYPECODE.TABLENAME, key.caseType);

    availableFocusAreasAndQueries.caseCategory = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME, key.caseCategory);

    return availableFocusAreasAndQueries;
  }

  // ___________________________________________________________________________
  /**
   * Method to associate queries to a specific case audit configuration.
   *
   * @param key the audit case configuration unique identifier.
   * @param details the audit case configuration details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void createQueryLinks(final AuditCaseConfigKey key,
    final CreateAuditCaseConfigDetails details) throws AppException,
      InformationalException {

    // Validate the query information
    validateQueries(details);

    // Add the dynamic query
    final curam.selectionquery.impl.SelectionQuery dynamicQuery = selectionQueryDAO.get(
      details.dynamicQueryID);

    AuditCaseSelectionQuery auditCaseSelectionQueryObj = auditCaseSelectionQueryDAO.newInstance();

    auditCaseSelectionQueryObj.setAuditCaseConfig(
      auditCaseConfigDAO.get(key.auditCaseConfigID));
    auditCaseSelectionQueryObj.setSelectionQuery(dynamicQuery);

    auditCaseSelectionQueryObj.insert();

    // Manipulation variables to add fixed queries
    final StringList fixedQueryList = StringUtil.tabText2StringListWithTrim(
      details.selectedFixedQueries);
    final int fixedQueryListSize = fixedQueryList.size();

    // Insert new query selections into database.
    for (int i = 0; i < fixedQueryListSize; i++) {

      final curam.selectionquery.impl.SelectionQuery fixedQuery = selectionQueryDAO.get(
        Long.parseLong(fixedQueryList.item(i)));

      auditCaseSelectionQueryObj = auditCaseSelectionQueryDAO.newInstance();

      auditCaseSelectionQueryObj.setAuditCaseConfig(
        auditCaseConfigDAO.get(key.auditCaseConfigID));
      auditCaseSelectionQueryObj.setSelectionQuery(fixedQuery);

      auditCaseSelectionQueryObj.insert();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to allow an administrator to modify the configured queries
   * for a specified case type and category.
   *
   * @param key the key of the configuration that is being updated
   * @param details the modified configuration details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void modifyQueryLinks(final AuditCaseConfigKey key,
    final ModifyAuditCaseConfigDetails details) throws AppException,
      InformationalException {

    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      key.auditCaseConfigID);

    // Modify the dynamic query
    final curam.selectionquery.impl.SelectionQuery currentDynamicQuery = auditCaseConfigObj.getDynamicQuery();

    if (currentDynamicQuery.getID() != details.dynamicQueryID) {

      final List<AuditCaseSelectionQuery> auditCaseSelectionQuery = auditCaseSelectionQueryDAO.searchByAuditCaseConfigAndSelectionQuery(
        auditCaseConfigObj, currentDynamicQuery);

      final Iterator<AuditCaseSelectionQuery> auditCaseSelectionQueryIterator = auditCaseSelectionQuery.iterator();

      while (auditCaseSelectionQueryIterator.hasNext()) {

        final AuditCaseSelectionQuery auditCaseSelectionQueryObj = auditCaseSelectionQueryDAO.get(
          auditCaseSelectionQueryIterator.next().getID());

        auditCaseSelectionQueryObj.remove();
      }

      // insert the new dynamic query link
      final curam.selectionquery.impl.SelectionQuery selectionQuery = selectionQueryDAO.get(
        details.dynamicQueryID);

      final AuditCaseSelectionQuery auditCaseSelectionQueryObj = auditCaseSelectionQueryDAO.newInstance();

      auditCaseSelectionQueryObj.setAuditCaseConfig(auditCaseConfigObj);
      auditCaseSelectionQueryObj.setSelectionQuery(selectionQuery);
      auditCaseSelectionQueryObj.insert();
    }

    // Manipulation variables to add/remove queries
    final StringList initialFixedQueryList = StringUtil.tabText2StringListWithTrim(
      details.initialFixedQueries);
    final StringList updatedFixedQueryList = StringUtil.tabText2StringListWithTrim(
      details.updatedFixedQueries);
    final int initialFixedQueriesSize = initialFixedQueryList.size();
    final int updatedFixedQueriesSize = updatedFixedQueryList.size();

    // Insert new fixed query selections into database.
    for (int i = 0; i < updatedFixedQueriesSize; i++) {

      final String fixedQuery = updatedFixedQueryList.item(i);

      // If the selected fixed query is not already selected
      // insert the record into database.
      if (!initialFixedQueryList.contains(fixedQuery)) {

        final curam.selectionquery.impl.SelectionQuery selectionQuery = selectionQueryDAO.get(
          Long.parseLong(fixedQuery));

        final AuditCaseSelectionQuery auditCaseSelectionQueryObj = auditCaseSelectionQueryDAO.newInstance();

        auditCaseSelectionQueryObj.setAuditCaseConfig(auditCaseConfigObj);
        auditCaseSelectionQueryObj.setSelectionQuery(selectionQuery);
        auditCaseSelectionQueryObj.insert();
      }
    }

    // Remove fixed query selections from the database.
    for (int i = 0; i < initialFixedQueriesSize; i++) {

      final String fixedQuery = initialFixedQueryList.item(i);

      final curam.selectionquery.impl.SelectionQuery selectionQuery = selectionQueryDAO.get(
        Long.parseLong(fixedQuery));

      // If the original fixed query selection is not in the updated list,
      // delete the record
      if (!updatedFixedQueryList.contains(fixedQuery)) {

        final List<AuditCaseSelectionQuery> auditCaseSelectionQuery = auditCaseSelectionQueryDAO.searchByAuditCaseConfigAndSelectionQuery(
          auditCaseConfigObj, selectionQuery);

        final Iterator<AuditCaseSelectionQuery> auditCaseSelectionQueryIterator = auditCaseSelectionQuery.iterator();

        while (auditCaseSelectionQueryIterator.hasNext()) {

          final AuditCaseSelectionQuery auditCaseSelectionQueryObj = auditCaseSelectionQueryDAO.get(
            auditCaseSelectionQueryIterator.next().getID());

          auditCaseSelectionQueryObj.remove();
        }
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to list all available dynamic queries.
   *
   * @return list of all available dynamic queries.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SelectionQueryListDetailsList getAvailableDynamicQueries()
    throws AppException, InformationalException {

    final SelectionQueryListDetailsList selectionQueryListDetailsList = new SelectionQueryListDetailsList();

    final List<curam.selectionquery.impl.SelectionQuery> dynamicQueries = selectionQueryDAO.searchPublishedDynamicByCategory(
      SELECTIONQUERYCATEGORYEntry.CASE);

    for (final curam.selectionquery.impl.SelectionQuery selectionQuery : dynamicQueries) {

      final SelectionQueryListDetails selectionQueryListDetails = new SelectionQueryListDetails();

      selectionQueryListDetails.queryID = selectionQuery.getID();
      selectionQueryListDetails.queryCategory = selectionQuery.getCategory().getCode();
      selectionQueryListDetails.queryType = selectionQuery.getType().getCode();
      selectionQueryListDetails.queryName = selectionQuery.getName();
      selectionQueryListDetails.queryStatus = selectionQuery.getLifecycleState().getCode();
      selectionQueryListDetails.versionNo = selectionQuery.getVersionNo();
      selectionQueryListDetailsList.dtls.addRef(selectionQueryListDetails);
    }

    return selectionQueryListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all available fixed queries.
   *
   * @return list of all available fixed queries.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SelectionQueryListDetailsList getAvailableFixedQueries()
    throws AppException, InformationalException {

    final SelectionQueryListDetailsList selectionQueryListDetailsList = new SelectionQueryListDetailsList();

    final List<curam.selectionquery.impl.SelectionQuery> fixedQueries = selectionQueryDAO.searchPublishedFixedByCategory(
      SELECTIONQUERYCATEGORYEntry.CASE);

    for (final curam.selectionquery.impl.SelectionQuery selectionQuery : fixedQueries) {

      final SelectionQueryListDetails selectionQueryListDetails = new SelectionQueryListDetails();

      selectionQueryListDetails.queryID = selectionQuery.getID();
      selectionQueryListDetails.queryCategory = selectionQuery.getCategory().getCode();
      selectionQueryListDetails.queryType = selectionQuery.getType().getCode();
      selectionQueryListDetails.queryName = selectionQuery.getName();
      selectionQueryListDetails.queryStatus = selectionQuery.getLifecycleState().getCode();
      selectionQueryListDetails.versionNo = selectionQuery.getVersionNo();
      selectionQueryListDetailsList.dtls.addRef(selectionQueryListDetails);
    }

    return selectionQueryListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all selected fixed queries for a case type and category.
   * Called during case audit configuration by an administrator.
   *
   * @param key the audit case type and category
   *
   * @return list of all selected fixed queries in a String format.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SelectedFixedQueries getSelectedFixedQueries(
    final AuditCaseTypeAndCategory key) throws AppException,
      InformationalException {

    final SelectedFixedQueries selectedFixedQueries = new SelectedFixedQueries();

    // Get the list of selected fixed for the case type
    // and category specified.
    final AuditCaseConfig auditCaseConfig = auditCaseConfigDAO.readByCaseTypeAndCategory(
      AUDITCASETYPECODEEntry.get(key.caseType),
      CASECATTYPECODEEntry.get(key.caseCategory));

    if (auditCaseConfig != null) {

      final List<curam.selectionquery.impl.SelectionQuery> fixedQueries = auditCaseConfig.getFixedQueries();

      int counter = 0;

      // construct tab-separated focus area string like "100\t101\t102"
      if (!fixedQueries.isEmpty()) {

        final Iterator<curam.selectionquery.impl.SelectionQuery> selectionQueryIterator = fixedQueries.iterator();

        while (selectionQueryIterator.hasNext()) {

          if (counter != 0) {
            selectedFixedQueries.selectedFixedQueries += CuramConst.gkTabDelimiter;
          }

          selectedFixedQueries.selectedFixedQueries += selectionQueryIterator.next().getID();

          counter++;
        }
      }
    }

    return selectedFixedQueries;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate that the correct query information
   * has been entered.
   *
   * @param details the audit case configuration details.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void validateQueries(final CreateAuditCaseConfigDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (details.dynamicQueryID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDITCONFIGURATION.ERR_FV_MANDATORY_DYNAMIC_QUERY_NOT_SET),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * Lists Case Audit Type SIDS.
   *
   * @return List of Case Audit Type SIDs
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SecurityIDList listCaseAuditTypeSIDs() throws AppException,
      InformationalException {

    final SecurityIDList securityIDListRet = new SecurityIDList();

    final SIDTypeKey sIDTypeKey = new SIDTypeKey();

    sIDTypeKey.sidType = SECURITYIDENTIFIERTYPE.CASEAUDITTYPE;

    securityIDListRet.securityIDList = SecurityLinkFactory.newInstance().getSidsByType(
      sIDTypeKey);

    return securityIDListRet;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all queries available to the audit plan.
   * Any of these queries can be selected to generate a case sample.
   *
   * @param key the id of the configuration associated with the audit plan
   *
   * @return list of queries available to the audit plan
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SelectionQueryListDetailsList listQueriesForConfiguration(
    final AuditCaseConfigKey key) throws AppException, InformationalException {

    final SelectionQueryListDetailsList selectionQueryListDetailsList = new SelectionQueryListDetailsList();

    final AuditCaseConfig auditCaseConfig = auditCaseConfigDAO.get(
      key.auditCaseConfigID);

    final List<curam.selectionquery.impl.SelectionQuery> fixedQueries = auditCaseConfig.getFixedQueries();

    for (final curam.selectionquery.impl.SelectionQuery selectionQuery : fixedQueries) {

      final SelectionQueryListDetails selectionQueryListDetails = new SelectionQueryListDetails();

      selectionQueryListDetails.queryID = selectionQuery.getID();
      selectionQueryListDetails.queryCategory = selectionQuery.getCategory().getCode();
      selectionQueryListDetails.queryType = selectionQuery.getType().getCode();
      selectionQueryListDetails.queryName = selectionQuery.getName();
      selectionQueryListDetails.queryStatus = selectionQuery.getLifecycleState().getCode();
      selectionQueryListDetails.versionNo = selectionQuery.getVersionNo();
      selectionQueryListDetailsList.dtls.addRef(selectionQueryListDetails);
    }

    final curam.selectionquery.impl.SelectionQuery dynamicQuery = auditCaseConfig.getDynamicQuery();
    final SelectionQueryListDetails selectionQueryListDetails = new SelectionQueryListDetails();

    selectionQueryListDetails.queryID = dynamicQuery.getID();
    selectionQueryListDetails.queryCategory = dynamicQuery.getCategory().getCode();
    selectionQueryListDetails.queryType = dynamicQuery.getType().getCode();
    selectionQueryListDetails.queryName = dynamicQuery.getName();
    selectionQueryListDetails.queryStatus = dynamicQuery.getLifecycleState().getCode();
    selectionQueryListDetails.versionNo = dynamicQuery.getVersionNo();
    selectionQueryListDetailsList.dtls.addRef(selectionQueryListDetails);

    return selectionQueryListDetailsList;
  }

  // BEGIN, CR00266606, PMD
  // ___________________________________________________________________________
  /**
   * Method to read the case audit type for the tab title on the View Case Audit
   * Configuration screen.
   *
   * @param key The unique identifier of the Audit Case configuration record.
   *
   * @return The case audit type being configured.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseAuditType readCaseAuditType(final AuditCaseConfigKey key)
    throws AppException, InformationalException {

    final CaseAuditType caseAuditType = new CaseAuditType();
    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      key.auditCaseConfigID);

    caseAuditType.caseAuditType = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME, auditCaseConfigObj.getCaseCategory().getCode());

    return caseAuditType;
  }
  // END, CR00266606
}
