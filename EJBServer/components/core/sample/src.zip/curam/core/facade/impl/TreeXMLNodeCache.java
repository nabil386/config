/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.Hashtable;
import java.util.Map;


/**
 * This class stores the last accessed node for
 * the XML Tree Widget for Rules components.
 *
 */
public final class TreeXMLNodeCache {

  /**
   * Single instance of the TreeXMLNodeCache class.
   */
  protected static TreeXMLNodeCache treeXMLNodeCache;

  /**
   * Synchronized collection to store the Node objects.
   */
  protected final Map<String, TreeXMLNodeDetails> lastAccessedNodeCache = new Hashtable<String, TreeXMLNodeDetails>();

  /**
   * Protected constructor ensures that this class can not be
   * instantiated.
   */
  protected TreeXMLNodeCache() {// Empty Protected Constructor
  }

  /**
   * Get the only instance of this class.
   *
   * @return the only instance of TreeXMLNodeCache. Create the instance
   * if it does not exist.
   */
  public static TreeXMLNodeCache getInstance() {

    if (treeXMLNodeCache == null) {
      treeXMLNodeCache = new TreeXMLNodeCache();
    }
    return treeXMLNodeCache;
  }

  /**
   * Gets the TreeNodeDetails from cache or creates a new object if it does not
   * exist in cache.
   *
   * @param ruleSetID RuleSetID.
   *
   * @return TreeXMLNodeDetails object
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public TreeXMLNodeDetails getTreeXMLNodeDetails(final String ruleSetID)
    throws AppException, InformationalException {

    TreeXMLNodeDetails nodeDetails = lastAccessedNodeCache.get(ruleSetID);

    if (nodeDetails == null) {
      nodeDetails = new TreeXMLNodeDetails();
      lastAccessedNodeCache.put(ruleSetID, nodeDetails);
    }

    return nodeDetails;
  }

}
