/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.facade.impl;

import curam.codetable.ASSESSMENTNAME;
import curam.codetable.LOCALE;
import curam.codetable.PRODUCTNAME;
import curam.codetable.RULESCOMPONENTTYPE;
import curam.codetable.RULESDATAOBJECTTYPE;
import curam.codetable.RULESTAGTYPE;
import curam.common.util.xml.dom.Document;
import curam.common.util.xml.dom.Element;
import curam.core.facade.struct.*;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.struct.RulesSimulationDtls;
import curam.core.sl.entity.struct.RulesSimulationKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.RulesEditorConst;
import curam.core.sl.infrastructure.impl.UtilCuramConst;
import curam.core.sl.infrastructure.impl.XmlTreeConst;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.EvaluateClaimResults;
import curam.core.struct.RulesResultItem;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.message.BPORULESEDITOR;
import curam.message.ENTRULESTRANSLATION;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.internal.rules.fact.RuleSetInformationFactory;
import curam.util.internal.rules.intf.RuleSetInformation;
import curam.util.internal.rules.struct.RuleSetInformationNoDefinitionDetails;
import curam.util.internal.rules.struct.RuleSetInformationReadKey;
import curam.util.message.INFRASTRUCTURE;
import curam.util.resources.Configuration;
import curam.util.resources.XMLUtil;
import curam.util.rules.EvidenceTextDecoder;
import curam.util.rules.ExternalAccess;
import curam.util.rules.FixedNumericFormatConversion;
import curam.util.rules.Interrule;
import curam.util.rules.ResultBuffer;
import curam.util.rules.ResultTextDecoder;
import curam.util.rules.RuleSetAccessFactory;
import curam.util.rules.RulesObjectiveResult;
import curam.util.rules.TagResult;
import curam.util.rules.editor.Editor;
import curam.util.rules.editor.Simulator;
import curam.util.rules.editor.data.DataItem;
import curam.util.rules.editor.data.RDO;
import curam.util.rules.editor.data.RDOGroup;
import curam.util.rules.editor.model.DataItemAssignment;
import curam.util.rules.editor.model.Eligibility;
import curam.util.rules.editor.model.GenericRuleSet;
import curam.util.rules.editor.model.LocaleList;
import curam.util.rules.editor.model.NodeIDAndType;
import curam.util.rules.editor.model.Objective;
import curam.util.rules.editor.model.ObjectiveGroup;
import curam.util.rules.editor.model.ObjectiveListGroup;
import curam.util.rules.editor.model.ObjectiveTag;
import curam.util.rules.editor.model.Rule;
import curam.util.rules.editor.model.RuleGroup;
import curam.util.rules.editor.model.RuleListGroup;
import curam.util.rules.editor.model.RuleSetIdAndName;
import curam.util.rules.editor.model.SubRuleSet;
import curam.util.rules.editor.model.SubRuleSetLink;
import curam.util.rules.editor.model.Text;
import curam.util.rules.editor.model.Translation;
import curam.util.rules.editor.model.ValidationInformation;
import curam.util.rules.editor.model.tree.RuleChild;
import curam.util.rules.evidence.EvidenceList;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.FrequencyPattern;
import curam.util.type.UniqueID;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;


/**
 * Facade class containing all of the RuleEditor manipulation functions.
 *
 */
public abstract class RulesEditor extends curam.core.facade.base.RulesEditor {

  // BEGIN, CR00052324, AK
  protected static final String kBlankString = CuramConst.gkEmpty;

  // END, CR00052324
  protected static final String kOtf = CuramConst.kOtf;

  // BEGIN, CR00021717, KY
  /**
   * This method checks if the rulesetID is alphanumeric. This is invoked while
   * creating and modifying the sub rule set.
   *
   * @param ruleSetDetails identifies the rule set
   *
   * @return true if rule set ID is alphanumeric
   */
  @Override
  public AlphaNumericDetails isRuleSetIDAlphaNumeric(
    RuleSetIDStruct ruleSetDetails) throws AppException,
      InformationalException {

    final AlphaNumericDetails alphaNumericDetails = new AlphaNumericDetails();

    // check for alpha numeric character

    // BEGIN, CR00052324, AK
    java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
      RulesEditorConst.kAlphaNumericRegExp);
    // END, CR00052324

    java.util.regex.Matcher matcher = pattern.matcher(ruleSetDetails.ruleSetID);
    final boolean isNumeric = matcher.matches();

    // BEGIN, CR00052324, AK
    pattern = java.util.regex.Pattern.compile(RulesEditorConst.kPattren);
    // END, CR00052324

    matcher = pattern.matcher(ruleSetDetails.ruleSetID);
    final boolean isAlphaNumeric = matcher.matches();

    if (isAlphaNumeric || isNumeric) {
      alphaNumericDetails.alphaNumericIndicator = true;
    }

    return alphaNumericDetails;
  }

  // END, CR00021717

  // ___________________________________________________________________________
  /**
   * Adds a rules data object to a specified rule set.
   *
   * @param createDtls Contains details to add the data object to the rule set
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void addRulesDataObjectToRuleSet(CreateRulesDataObjectDtls createDtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // BEGIN, CR00023231, KY
    // RuleSet Node key
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // END, CR00023231

    // If the system is live, an RDO may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_RDO);
    }

    Editor.addRulesDataObjectToRuleSet(createDtls.ruleSetID,
      createDtls.versionNo, createDtls.rulesDataObjectID,
      createDtls.rulesDataObjectFinal);

    // BEGIN, CR00023231, KY
    ruleSetNodeKey.nodeID = 0;
    ruleSetNodeKey.ruleSetID = createDtls.ruleSetID;
    postUpdate(ruleSetNodeKey);
    // END, CR00023231
  }

  // ___________________________________________________________________________
  /**
   * Adds a sub rule set to a rule set.
   *
   * @param subRuleSetToRuleSetKey Contains details to add the sub rule set to
   * the rule set
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct addSubRuleSetToRuleSet(
    SubRuleSetToRuleSetKey subRuleSetToRuleSetKey) throws AppException,
      InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, a sub rule set may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SUB_RULES_SET);
    }

    final NodeIDStruct result = new NodeIDStruct();

    result.nodeID = Editor.createSubRuleSetLink(
      subRuleSetToRuleSetKey.ruleSetID, subRuleSetToRuleSetKey.versionNo,
      subRuleSetToRuleSetKey.parentNodeID, subRuleSetToRuleSetKey.subRuleSetID);

    if (subRuleSetToRuleSetKey.ruleSetID != null
      && subRuleSetToRuleSetKey.ruleSetID.length() > 0) {
      if (subRuleSetToRuleSetKey.subRuleSetID != null
        && subRuleSetToRuleSetKey.subRuleSetID.length() > 0) {
        ruleSetNodeKey.nodeID = result.nodeID;
        ruleSetNodeKey.ruleSetID = subRuleSetToRuleSetKey.ruleSetID;
        postUpdate(ruleSetNodeKey);
      }
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Clones a rule set
   *
   * @param cloneRuleSetKey Contains details to clone a rule set
   *
   * @return Contains the rule set identifier of the cloned rule set
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetIDStruct cloneRuleSet(CloneRuleSetKey cloneRuleSetKey)
    throws AppException, InformationalException {

    Editor.cloneRuleSet(cloneRuleSetKey.ruleSetID, cloneRuleSetKey.newRuleSetID,
      cloneRuleSetKey.name);

    final RuleSetIDStruct result = new RuleSetIDStruct();

    result.ruleSetID = cloneRuleSetKey.newRuleSetID;

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates an eligibility rule set.
   *
   * @param ruleSetDetails Contains details to create an eligibility rule set
   *
   * @return Eligibility rule set identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetIDStruct createEligibiltyRuleSet(RuleSetDetails ruleSetDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00021753, KY
    // check if rulesetID is alpha numeric, if not throw exception
    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    ruleSetIDStruct.ruleSetID = ruleSetDetails.ruleSetID;
    if (!isRuleSetIDAlphaNumeric(ruleSetIDStruct).alphaNumericIndicator) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_NOT_ALPHANUMERIC);
    }
    // END, CR00021753

    Editor.createEligibilityRuleSet(ruleSetDetails.ruleSetID,
      ruleSetDetails.ruleSetName, ruleSetDetails.highLightInd,
      ruleSetDetails.legislationBase, ruleSetDetails.legislationID,
      ruleSetDetails.comments, ruleSetDetails.ruleSetCategory,
      ruleSetDetails.successText, ruleSetDetails.failureText);

    final RuleSetIDStruct result = new RuleSetIDStruct();

    result.ruleSetID = ruleSetDetails.ruleSetID;
    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates the failure text.
   *
   * @param failureTextDtls Contains the failure text details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createFailureText(SuccessFailureTextDtls failureTextDtls)
    throws AppException, InformationalException {

    Editor.addOrModifyFailureText(failureTextDtls.ruleSetID,
      failureTextDtls.versionNo, failureTextDtls.nodeID,
      failureTextDtls.languageCode, failureTextDtls.text);

  }

  // ___________________________________________________________________________
  /**
   * Creates an objective group.
   *
   * @param details Details to create an objective group.
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createObjectiveGroup(ObjectiveGroupDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, an Objective Group may not be added to the
    // Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_OBJECTIVE_GROUP);
    }

    final NodeIDStruct result = new NodeIDStruct();
    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    ruleSetIDStruct.ruleSetID = details.ruleSetID;
    final NodeIDAndType nodeIDAndType = Editor.getRuleSetTypeInformation(
      ruleSetIDStruct.ruleSetID);

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      details.ruleSetID);
    // BEGIN, CR00052324, AK
    if (nodeIDAndType.getType().equals(XmlTreeConst.kSRS)) {
      // END, CR00052324
      try {
        result.nodeID = Editor.createObjectiveGroup(details.ruleSetID,
          versionNo, details.nodeID, details.priority, details.highLightInd,
          details.legislationID, details.comments, details.name,
          codeIn(details.conjunctionCode), details.successText,
          details.failureText, details.ruleID);
      } catch (final AppException ex) {
        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_ONE_OBJECTIVE_GROUP_AT_ROOT_LEVEL);
      }
      if (result.nodeID != 0) {
        validateTopLevelNode(ruleSetIDStruct);
      }

    } else {
      result.nodeID = Editor.createObjectiveGroup(details.ruleSetID, versionNo,
        details.nodeID, details.priority, details.highLightInd,
        details.legislationID, details.comments, details.name,
        codeIn(details.conjunctionCode), details.successText,
        details.failureText, details.ruleID);
    }
    // END, CR00023363, KY

    if (details.ruleSetID != null && details.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = details.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates an objective list group.
   *
   * @param details Details to create an objective list group
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createObjectiveListGroup(
    ObjectiveListGroupDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, an Objective List Group may not be added to the
    // Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_OBJECTIVE_LIST_GROUP);
    }

    final NodeIDStruct result = new NodeIDStruct();

    // BEGIN, HARP-46955, ZZ
    // BEGIN, HARP-38584, ZZ
    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    ruleSetIDStruct.ruleSetID = details.ruleSetID;
    final NodeIDAndType nodeIDAndType = Editor.getRuleSetTypeInformation(
      ruleSetIDStruct.ruleSetID);

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      details.ruleSetID);
    // BEGIN, CR00052324, AK
    if (nodeIDAndType.getType().equals(XmlTreeConst.kSRS)) {
      // END, CR00052324
      try {
        result.nodeID = Editor.createObjectiveListGroup(details.ruleSetID,
          versionNo, details.nodeID, details.priority, details.highLightInd,
          details.legislationID, details.comments, details.name,
          codeIn(details.conjunctionCode), details.successText,
          details.failureText, details.listRulesDataObjectID, details.ruleID);
      } catch (final AppException ex) {
        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_ONE_OBJECTIVE_LIST_GROUP_AT_ROOT_LEVEL);
      }
      if (result.nodeID != 0) {
        validateTopLevelNode(ruleSetIDStruct);
      }

    } else {
      result.nodeID = Editor.createObjectiveListGroup(details.ruleSetID,
        versionNo, details.nodeID, details.priority, details.highLightInd,
        details.legislationID, details.comments, details.name,
        codeIn(details.conjunctionCode), details.successText,
        details.failureText, details.listRulesDataObjectID, details.ruleID);
    }
    // END, CR00023363
    // END, HARP-38584
    // END, HARP-46955

    if (details.ruleSetID != null && details.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = details.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates an objective tag.
   *
   * @param dtls Objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  // BEGIN, HARP-39217, ZZ
  @Override
  public void createObjectiveTag(ObjectiveTagDetails dtls)
    throws AppException, InformationalException {

    // END, HARP-39217

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an objective tag set may not be added to the
    // Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_OBJECTIVE_TAG);
    }

    Editor.createObjectiveTag(dtls.ruleSetID, dtls.versionNo, dtls.nodeID,
      dtls.name, dtls.tagType, dtls.value, dtls.frequency, dtls.comments);
  }

  // ___________________________________________________________________________
  /**
   * Creates a rule.
   *
   * @param ruleDetails Details to create a rule.
   *
   * @return Node identifier.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createRule(RuleDetails ruleDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, a rule may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_RULE);
    }

    final NodeIDStruct result = new NodeIDStruct();

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      ruleDetails.ruleSetID);

    result.nodeID = Editor.createRule(ruleDetails.ruleSetID, versionNo,
      ruleDetails.nodeID, ruleDetails.highlightID, ruleDetails.legislationID,
      ruleDetails.ruleName, ruleDetails.summaryInd,
      ruleDetails.excludeFromSimulationInd,
      ruleDetails.excludeFromReassessmentInd, ruleDetails.successText,
      ruleDetails.failureText, ruleDetails.ruleID, ruleDetails.expressionText);

    // END, CR00023363

    if (ruleDetails.ruleSetID != null && ruleDetails.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = ruleDetails.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates a rule group.
   *
   * @param createRuleGroupDtls Details to create a rule group.
   *
   * @return Node identifier.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createRuleGroup(RuleGroupDetails createRuleGroupDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, a rule group may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_RULE_GROUP);
    }

    final NodeIDStruct result = new NodeIDStruct();

    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    ruleSetIDStruct.ruleSetID = createRuleGroupDtls.ruleSetID;
    final NodeIDAndType nodeIDAndType = Editor.getRuleSetTypeInformation(
      ruleSetIDStruct.ruleSetID);

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      createRuleGroupDtls.ruleSetID);
    // BEGIN, CR00052324, AK
    if (nodeIDAndType.getType().equals(XmlTreeConst.kSRS)) {
      // END, CR00052324
      try {
        result.nodeID = Editor.createRuleGroup(createRuleGroupDtls.ruleSetID,
          versionNo, createRuleGroupDtls.nodeID,
          createRuleGroupDtls.highlightInd, createRuleGroupDtls.legislationID,
          createRuleGroupDtls.name, codeIn(createRuleGroupDtls.conjunctionCode),
          codeIn(createRuleGroupDtls.executionModeCode),
          createRuleGroupDtls.summaryInd,
          codeIn(createRuleGroupDtls.assessmentQueryModeCode),
          createRuleGroupDtls.successText, createRuleGroupDtls.failureText,
          createRuleGroupDtls.ruleID);
      } catch (final AppException ex) {
        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_ONE_RULE_GROUP_AT_ROOT_LEVEL);
      }
      if (result.nodeID != 0) {
        validateTopLevelNode(ruleSetIDStruct);
      }

    } else {
      result.nodeID = Editor.createRuleGroup(createRuleGroupDtls.ruleSetID,
        versionNo, createRuleGroupDtls.nodeID, createRuleGroupDtls.highlightInd,
        createRuleGroupDtls.legislationID, createRuleGroupDtls.name,
        codeIn(createRuleGroupDtls.conjunctionCode),
        codeIn(createRuleGroupDtls.executionModeCode),
        createRuleGroupDtls.summaryInd,
        codeIn(createRuleGroupDtls.assessmentQueryModeCode),
        createRuleGroupDtls.successText, createRuleGroupDtls.failureText,
        createRuleGroupDtls.ruleID);
    }
    // END, CR00023363

    if (createRuleGroupDtls.ruleSetID != null
      && createRuleGroupDtls.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = createRuleGroupDtls.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

    return result;
  }

  /**
   * Perform post update maintenance.
   *
   * @param ruleSetNodeKey RuleSetID and NodeID Details.
   *
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void postUpdate(RuleSetNodeKey ruleSetNodeKey) throws AppException,
      InformationalException {

    if (ruleSetNodeKey.ruleSetID != null
      && ruleSetNodeKey.ruleSetID.trim().length() > 0) {

      final TreeXMLNodeDetails lastAccessedNode = TreeXMLNodeCache.getInstance().getTreeXMLNodeDetails(
        ruleSetNodeKey.ruleSetID);

      lastAccessedNode.setStLastAccessedNodeId(ruleSetNodeKey.nodeID);
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates a rule list group.
   *
   * @param ruleListGroupDetails Contains details to create a rule list group
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createRuleListGroup(
    RulesListGroupDetails ruleListGroupDetails) throws AppException,
      InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, a rule list group may not be added to the
    // Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_RULE_LIST_GROUP);
    }

    final NodeIDStruct result = new NodeIDStruct();

    // BEGIN, HARP-46955, ZZ
    // BEGIN, HARP-38584, ZZ

    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    ruleSetIDStruct.ruleSetID = ruleListGroupDetails.ruleSetID;
    final NodeIDAndType nodeIDAndType = Editor.getRuleSetTypeInformation(
      ruleSetIDStruct.ruleSetID);

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      ruleListGroupDetails.ruleSetID);
    // BEGIN, CR00052324, AK
    if (nodeIDAndType.getType().equals(XmlTreeConst.kSRS)) {
      // END, CR00052324
      try {
        result.nodeID = Editor.createRuleListGroup(
          ruleListGroupDetails.ruleSetID, versionNo,
          ruleListGroupDetails.nodeID, ruleListGroupDetails.highlightInd,
          ruleListGroupDetails.legislationID, ruleListGroupDetails.name,
          codeIn(ruleListGroupDetails.conjunctionCode),
          codeIn(ruleListGroupDetails.executionModeCode),
          ruleListGroupDetails.summaryInd,
          codeIn(ruleListGroupDetails.assessmentQueryModeCode),
          ruleListGroupDetails.successText, ruleListGroupDetails.failureText,
          codeIn(ruleListGroupDetails.loopExecutionMode),
          ruleListGroupDetails.listRulesDataObjectID,
          ruleListGroupDetails.ruleID);
      } catch (final AppException ex) {
        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_ONE_RULE_LIST_GROUP_AT_ROOT_LEVEL);
      }
      if (result.nodeID != 0) {
        validateTopLevelNode(ruleSetIDStruct);
      }

    } else {
      result.nodeID = Editor.createRuleListGroup(ruleListGroupDetails.ruleSetID,
        versionNo, ruleListGroupDetails.nodeID,
        ruleListGroupDetails.highlightInd, ruleListGroupDetails.legislationID,
        ruleListGroupDetails.name, codeIn(ruleListGroupDetails.conjunctionCode),
        codeIn(ruleListGroupDetails.executionModeCode),
        ruleListGroupDetails.summaryInd,
        codeIn(ruleListGroupDetails.assessmentQueryModeCode),
        ruleListGroupDetails.successText, ruleListGroupDetails.failureText,
        codeIn(ruleListGroupDetails.loopExecutionMode),
        ruleListGroupDetails.listRulesDataObjectID, ruleListGroupDetails.ruleID);
    }
    // END, CR00023363

    // END, HARP-38584
    // END, HARP-46955

    if (ruleListGroupDetails.ruleSetID != null
      && ruleListGroupDetails.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = ruleListGroupDetails.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates a sub rule set.
   *
   * @param ruleSetDetails Details to create a sub rule set.
   *
   * @return Rule set identifier.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetIDStruct createSubRuleSet(CreateSubRuleSetDtls ruleSetDetails)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, a sub rule set may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SUB_RULE_SET);
    }

    // BEGIN, CR00021717, KY
    // check if rulesetID is alpha numeric, if not throw exception
    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    ruleSetIDStruct.ruleSetID = ruleSetDetails.ruleSetID;
    if (!isRuleSetIDAlphaNumeric(ruleSetIDStruct).alphaNumericIndicator) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_NOT_ALPHANUMERIC);
    }
    // END, CR00021717

    // BEGIN, CR00022750, LP
    Editor.createSubRuleSet(ruleSetDetails.ruleSetID, // BEGIN, CR00052814, AK
      ruleSetDetails.highlightOnFailureInd, CuramConst.gkEmpty, // legislation link, not used in this context
      // END, CR00052814
      ruleSetDetails.ruleSetName, ruleSetDetails.comments,
      ruleSetDetails.successText, ruleSetDetails.failureText);

    final RuleSetIDStruct result = new RuleSetIDStruct();

    result.ruleSetID = ruleSetDetails.ruleSetID;

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates the success text.
   *
   * @param successTextDtls Contains success text details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createSuccessText(SuccessFailureTextDtls successTextDtls)
    throws AppException, InformationalException {

    Editor.addOrModifySuccessText(successTextDtls.ruleSetID,
      successTextDtls.versionNo, successTextDtls.nodeID,
      successTextDtls.languageCode, successTextDtls.text);

  }

  // BEGIN, HARP-40911, ZZ
  // ___________________________________________________________________________
  /**
   * Creates the rule name.
   *
   * @param ruleNameDtls Contains rule name details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createRuleName(RuleNameDtls ruleNameDtls) throws AppException,
      InformationalException {

    Editor.addOrModifyRuleName(ruleNameDtls.ruleSetID, ruleNameDtls.versionNo,
      ruleNameDtls.nodeID, ruleNameDtls.languageCode, ruleNameDtls.text);

  }

  // ___________________________________________________________________________
  /**
   * Modifies rule name.
   *
   * @param ruleNameDtls rule name details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyRuleName(RuleNameDtls ruleNameDtls) throws AppException,
      InformationalException {

    Editor.addOrModifyRuleName(ruleNameDtls.ruleSetID, ruleNameDtls.versionNo,
      ruleNameDtls.nodeID, ruleNameDtls.languageCode, ruleNameDtls.text);
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of rule names.
   *
   * @param listRuleNameKey Key to list the rule name.
   * @return rule name list.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ListRuleNameDtls listRuleName(RuleSetNodeKey listRuleNameKey)
    throws AppException, InformationalException {

    final Text text[] = Editor.listRuleNames(listRuleNameKey.ruleSetID,
      listRuleNameKey.nodeID);

    final ListRuleNameDtls result = new ListRuleNameDtls();

    result.nodeName = text[0].getName();
    result.versionNo = text[0].getRuleSetVersion();

    for (int i = 0; i < text.length; i++) {

      final Text t = text[i];

      final RuleNameListDtls ruleNameListDtls = new RuleNameListDtls();

      ruleNameListDtls.languageCode = t.getLocale();
      ruleNameListDtls.text = t.getValue();

      result.textList.readTextDtls.addRef(ruleNameListDtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads the rule name.
   *
   * @param readTextKey Key to read the rule name.
   *
   * @return rule name.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleNameReadDtls readRuleName(ReadRuleNameKey readTextKey)
    throws AppException, InformationalException {

    final Text text[] = Editor.listRuleNames(readTextKey.ruleSetID,
      readTextKey.nodeID);

    for (int i = 0; i < text.length; i++) {

      final Text t = text[i];

      if (t.getLocale().equals(readTextKey.languageCode)) {

        final RuleNameReadDtls result = new RuleNameReadDtls();

        result.languageCode = t.getLocale();
        result.text = t.getValue();
        result.versionNo = t.getRuleSetVersion();

        return result;
      }
    }

    // Should never reach here
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Deletes the rule name.
   *
   * @param deleteTextKey Contains key to delete the rule name.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteRuleName(DeleteRuleNameKey deleteTextKey)
    throws AppException, InformationalException {

    Editor.deleteRuleName(deleteTextKey.ruleSetID, deleteTextKey.versionNo,
      deleteTextKey.nodeID, deleteTextKey.languageCode);
  }

  // END, HARP-40911

  // ___________________________________________________________________________
  /**
   * Deletes the failure text.
   *
   * @param deletTextKey Contains key to delete the failure text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteFailureText(DeleteSuccessFailureTextKey deletTextKey)
    throws AppException, InformationalException {

    Editor.deleteFailureText(deletTextKey.ruleSetID, deletTextKey.versionNo,
      deletTextKey.nodeID, deletTextKey.languageCode);
  }

  // ___________________________________________________________________________
  /**
   * Deletes a node.
   *
   * @param deleteNodeKey Contains key to delete a node.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteNode(RuleSetNodeVersionKey deleteNodeKey)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, this node cannot be deleted from the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE_NODE);
    }

    final NodeIDAndType nodeIDAndType = Editor.getParentNodeInformation(
      deleteNodeKey.ruleSetID, deleteNodeKey.nodeID);

    Editor.deleteNode(deleteNodeKey.ruleSetID, deleteNodeKey.versionNo,
      deleteNodeKey.nodeID);

    if (deleteNodeKey.ruleSetID != null && deleteNodeKey.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = nodeIDAndType.getNodeID();
      ruleSetNodeKey.ruleSetID = deleteNodeKey.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }
  }

  // ___________________________________________________________________________
  /**
   * Deletes a rule set.
   *
   * @param deleteRuleSetKey Contains a key to delete a rule set.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteRuleSet(RuleSetVersionNoKey deleteRuleSetKey)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, a Rule Set may not be deleted
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE);
    }

    Editor.deleteRuleSet(deleteRuleSetKey.ruleSetID);
  }

  // BEGIN, HARP-47115, ZZ

  // ___________________________________________________________________________
  /**
   * Deletes a sub rule set.
   *
   * @param deleteRuleSetKey Contains a key to delete a sub rule set.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteSubRuleSet(RuleSetVersionNoKey deleteRuleSetKey)
    throws AppException, InformationalException {

    final int kBufSize = 500;
    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    curam.core.facade.struct.RuleSetSummaryDetails ruleSetSummaryDetails = new RuleSetSummaryDetails();
    final RuleSetIDStruct ruleSetIDStruct = new RuleSetIDStruct();

    final StringBuffer formatBuffer = new StringBuffer(kBufSize);

    // If the system is live, a sub rule set may not be deleted
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE);
    }

    final String ruleSetArray[] = Editor.listRuleSetsUsingTheSubRuleSet(
      deleteRuleSetKey.ruleSetID);

    for (int i = 0; i < ruleSetArray.length; i++) {
      ruleSetIDStruct.ruleSetID = ruleSetArray[i];
      ruleSetSummaryDetails = viewRuleSetSummary(ruleSetIDStruct);
      formatBuffer.append(ruleSetSummaryDetails.ruleSetDetails.ruleSetName);
      formatBuffer.append(CuramConst.gkNewLineChar);
    }

    // BEGIN, CR00124828, SAI
    if (ruleSetArray.length != 0) {
      // END, CR00124828
      throw new AppException(curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_SUB_RULE_SET_REFERENCED_IN_OTHER_RULESET).arg(
        formatBuffer.toString());
    }

    Editor.deleteSubRuleSet(deleteRuleSetKey.ruleSetID);
  }

  // END, HARP-47115

  // ___________________________________________________________________________
  /**
   * Deletes the success text.
   *
   * @param deleteTextKey Contains key to delete the success text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteSuccessText(DeleteSuccessFailureTextKey deleteTextKey)
    throws AppException, InformationalException {

    Editor.deleteSuccessText(deleteTextKey.ruleSetID, deleteTextKey.versionNo,
      deleteTextKey.nodeID, deleteTextKey.languageCode);
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of data objective attributes.
   *
   * @param listDataObjectsKey Key to return list of data objective attributes
   *
   * @return List of data objective attributes.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public DataObjectAttributesList listDataObjectAttributes(
    ListDataObjectsKey listDataObjectsKey) throws AppException,
      InformationalException {

    final RDO rdo = Editor.getRulesDataObject(
      listDataObjectsKey.rulesDataObjectID);
    final DataObjectAttributesList result = new DataObjectAttributesList();
    final DataItem dataItems[] = rdo.getItems();

    for (int i = 0; i < dataItems.length; i++) {

      final DataItem item = dataItems[i];

      final DataObjectAttributeDetails attr = new DataObjectAttributeDetails();

      attr.attributeDomainName = item.getType();
      attr.attributeID = item.getQualifiedName();
      attr.attributeName = item.getDescription();

      result.dataObjectAttributeDtls.addRef(attr);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of eligibility rule sets
   *
   * @return List of eligibility rule sets.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetDetailsList listEligibilityRuleSet() throws AppException,
      InformationalException {

    final RuleSetDetailsList result = new RuleSetDetailsList();
    final RuleSetIdAndName apiResult[] = Editor.listEligibilityRuleSets();

    for (int i = 0; i < apiResult.length; i++) {

      final RuleSetIdAndName ruleSetIdAndName = apiResult[i];

      if (ruleSetIdAndName != null) {

        final RuleSetListDetails item = new RuleSetListDetails();

        item.ruleSetID = ruleSetIdAndName.getRuleSetID();
        item.ruleSetName = ruleSetIdAndName.getName();

        result.ruleSetDtls.addRef(item);
      }

    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of 'list' rules data objects.
   *
   * @return List of 'list' rules data objects.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ListRulesDataObjectList listListRulesDataObjects()
    throws AppException, InformationalException {

    final ListRulesDataObjectList result = new ListRulesDataObjectList();
    final RDO rdos[] = Editor.listRulesListDataObjects();

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      final ListRulesDataObjectDtls dtls = new ListRulesDataObjectDtls();

      dtls.listRulesDataObjectID = rdo.getName();
      dtls.listRulesDataObjectName = rdo.getDisplayName();
      // BEGIN, HARP-35962, CP
      dtls.listRulesDataObjectGroupID = rdo.getRDOGroupName();
      // END, HARP-35962
      result.listRulesDataObjectDtls.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of rules data objects for a specified rule set and node
   *
   * @param listRulesDataObjectKey Key to return list of rules data objects for
   * specified rule set and node.
   *
   * @return List of rules data objects for specified rule set and node
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectList listRulesDataObjectForRuleSetAndNode(
    RuleSetNodeKey listRulesDataObjectKey) throws AppException,
      InformationalException {

    final RDO rdos[] = Editor.listRulesDataObjectsForRuleSet(
      listRulesDataObjectKey.ruleSetID);
    final RulesDataObjectList result = new RulesDataObjectList();

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      final RulesDataObjectDtls dtls = new RulesDataObjectDtls();

      dtls.rulesDataObjectID = rdo.getName();
      dtls.rulesDataObjectName = rdo.getDisplayName();

      if (rdo.isListGroup()) {
        dtls.rulesDataObjectType = RULESDATAOBJECTTYPE.LIST;
      } else {
        dtls.rulesDataObjectType = RULESDATAOBJECTTYPE.SINGLE;
      }

      result.rulesDataObjectDtls.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of rules data object groups.
   *
   * @return List of rules data object groups.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectGroupList listRulesDataObjectGroups()
    throws AppException, InformationalException {

    final RDOGroup rdoGroups[] = Editor.listRuleDataObjectGroups();
    final RulesDataObjectGroupList result = new RulesDataObjectGroupList();

    for (int i = 0; i < rdoGroups.length; i++) {

      final RDOGroup grp = rdoGroups[i];

      final RulesDataObjectGroupListDtls dtls = new RulesDataObjectGroupListDtls();

      dtls.rulesDataObjectGroupID = grp.getName();
      dtls.rulesDataObjectGroupName = grp.getName();

      result.rdoGroupDtls.addRef(dtls);
    }

    return result;
  }

  // BEGIN, HARP-35962, CP
  // ___________________________________________________________________________
  /**
   * Returns the complete list of rules data objects, i.e. all singleton and
   * list Rules Data Objects.
   *
   * @return List of rules data objects.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectAndGroupList listAllRulesDataObjects()
    throws AppException, InformationalException {

    RulesDataObjectAndGroupList rulesDataObjectAndGroupList;
    ListRulesDataObjectList listRulesDataObjectList;

    // loading all singleton RDOs
    rulesDataObjectAndGroupList = listRulesDataObjects();

    // loading all the list RDOs
    listRulesDataObjectList = listListRulesDataObjects();

    // The list of 'list' is added to the result object.
    final int listSize = listRulesDataObjectList.listRulesDataObjectDtls.size();

    for (int i = 0; i < listSize; i++) {

      final ListRulesDataObjectDtls listRulesDataObjectDtls = listRulesDataObjectList.listRulesDataObjectDtls.item(
        i);
      final RulesDataObjectAndGroupDtls rulesDataObjectAndGroupDtls = new RulesDataObjectAndGroupDtls();

      rulesDataObjectAndGroupDtls.rulesDataObjectID = listRulesDataObjectDtls.listRulesDataObjectID;
      rulesDataObjectAndGroupDtls.rulesDataObjectName = listRulesDataObjectDtls.listRulesDataObjectName;
      rulesDataObjectAndGroupDtls.rulesDataObjectGroupID = listRulesDataObjectDtls.listRulesDataObjectGroupID;
      rulesDataObjectAndGroupDtls.rulesDataObjectGroupName = listRulesDataObjectDtls.listRulesDataObjectGroupID;

      rulesDataObjectAndGroupList.rdoAndGroupDtls.addRef(
        rulesDataObjectAndGroupDtls);
    }

    return rulesDataObjectAndGroupList;
  }

  // END, HARP-35962

  // ___________________________________________________________________________
  /**
   * Returns a list of rules data objects.
   *
   * @return List of rules data objects.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectAndGroupList listRulesDataObjects()
    throws AppException, InformationalException {

    final RulesDataObjectAndGroupList result = new RulesDataObjectAndGroupList();
    final RDO rdos[] = Editor.listRulesDataObjects();

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      final RulesDataObjectAndGroupDtls dtls = new RulesDataObjectAndGroupDtls();

      dtls.rulesDataObjectID = rdo.getName();
      dtls.rulesDataObjectName = rdo.getDisplayName();
      dtls.rulesDataObjectGroupID = rdo.getRDOGroupName();
      dtls.rulesDataObjectGroupName = rdo.getRDOGroupName();

      result.rdoAndGroupDtls.addRef(dtls);
    }

    return result;
  }

  // BEGIN, HARP-36901, CP
  // ___________________________________________________________________________
  /**
   * Returns a list of 'list' rules data objects for a specified rule set.
   *
   * @param ruleSetKey Key to return list of 'list' rules data objects for the
   * specified rule set.
   *
   * @return List of 'list' rules data objects for a specified rule set.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectForRuleSetDtls listListRulesDataObjectsForRuleSet(
    RuleSetIDStruct ruleSetKey) throws AppException, InformationalException {

    final RDO rdos[] = Editor.listRulesDataObjectsForRuleSet(
      ruleSetKey.ruleSetID);
    final RulesDataObjectForRuleSetDtls rulesDataObjectForRuleSetDtls = new RulesDataObjectForRuleSetDtls();

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      if (rdo.isListGroup()) {
        final RulesDataObjectsInGroupDtls rulesDataObjectsInGroupDtls = new RulesDataObjectsInGroupDtls();

        rulesDataObjectsInGroupDtls.rulesDataObjectID = rdo.getName();
        rulesDataObjectsInGroupDtls.rulesDataObjectName = rdo.getDisplayName();

        rulesDataObjectForRuleSetDtls.rdoDtls.rdoDtls.addRef(
          rulesDataObjectsInGroupDtls);
      }
    }

    // Have to delve into rules internals to get rule set name and version
    final ExternalAccess externalAccess = RuleSetAccessFactory.createRuleSetAccess();

    rulesDataObjectForRuleSetDtls.ruleSetName = externalAccess.getRuleSetName(
      ruleSetKey.ruleSetID);
    rulesDataObjectForRuleSetDtls.versionNo = externalAccess.getRuleSet(ruleSetKey.ruleSetID).getVersionNo();

    return rulesDataObjectForRuleSetDtls;
  }

  // END, HARP-36901

  // ___________________________________________________________________________
  /**
   * Returns a list of rules data objects for a specified rule set.
   *
   * @param ruleSetKey Key to return list of rules data objects for the
   * specified rule set.
   *
   * @return List of rules data objects for a specified rule set.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectForRuleSetDtls listRulesDataObjectsForRuleSet(
    RuleSetIDStruct ruleSetKey) throws AppException, InformationalException {

    final RDO rdos[] = Editor.listRulesDataObjectsForRuleSet(
      ruleSetKey.ruleSetID);
    final RulesDataObjectForRuleSetDtls result = new RulesDataObjectForRuleSetDtls();

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      final RulesDataObjectsInGroupDtls dtls = new RulesDataObjectsInGroupDtls();

      dtls.rulesDataObjectID = rdo.getName();
      dtls.rulesDataObjectName = rdo.getDisplayName();
      dtls.rulesDataObjectFinal = rdo.isFinal();
      dtls.rulesDataObjectQualifier = rdo.getQualifier();
      if (rdo.isListGroup()) {
        dtls.rulesDataObjectType = RULESDATAOBJECTTYPE.LIST;
      } else {
        dtls.rulesDataObjectType = RULESDATAOBJECTTYPE.SINGLE;
      }
      result.rdoDtls.rdoDtls.addRef(dtls);
    }

    // Have to delve into rules internals to get rule set name and version
    final ExternalAccess access = RuleSetAccessFactory.createRuleSetAccess();

    result.ruleSetName = access.getRuleSetName(ruleSetKey.ruleSetID);
    result.versionNo = access.getRuleSet(ruleSetKey.ruleSetID).getVersionNo();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of rules data objects in a specified group.
   *
   * @param listRDOInGroupKey Key to return the list of rules data objects in
   * a specified group.
   *
   * @return List of rules data objects in the specified group.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectsInGroupList listRulesDataObjectsInGroup(
    RulesDataObjectGroupIDKey listRDOInGroupKey) throws AppException,
      InformationalException {

    final RDO rdos[] = Editor.viewRuleDataObjectGroup(
      listRDOInGroupKey.rulesDataObjectGroupID);

    final RulesDataObjectsInGroupList result = new RulesDataObjectsInGroupList();

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      final RulesDataObjectsInGroupDtls dtls = new RulesDataObjectsInGroupDtls();

      dtls.rulesDataObjectID = rdo.getName();
      dtls.rulesDataObjectName = rdo.getDisplayName();

      result.rdoDtls.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of sub rule sets.
   *
   * @return List of sub rule sets.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetDetailsList listSubRuleSet() throws AppException,
      InformationalException {

    final RuleSetIdAndName ruleSetIdAndName[] = Editor.listSubRuleSets();
    final RuleSetDetailsList result = new RuleSetDetailsList();

    for (int i = 0; i < ruleSetIdAndName.length; i++) {

      final RuleSetIdAndName item = ruleSetIdAndName[i];

      final RuleSetListDetails ruleSetListDetails = new RuleSetListDetails();

      ruleSetListDetails.ruleSetID = item.getRuleSetID();
      ruleSetListDetails.ruleSetName = item.getName();

      result.ruleSetDtls.addRef(ruleSetListDetails);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of success text.
   *
   * @return Success text list.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ListSuccessFailureTextDtls listSuccessText(
    RuleSetNodeKey listSuccessTextKey) throws AppException,
      InformationalException {

    final Text text[] = Editor.listSuccessText(listSuccessTextKey.ruleSetID,
      listSuccessTextKey.nodeID);

    final ListSuccessFailureTextDtls result = new ListSuccessFailureTextDtls();

    // BEGIN, HARP-40911, ZZ

    // Text objects have node name and version, but we only need the first
    if (text.length == 0) {

      final RuleSetInformation ruleSetInformationObj = RuleSetInformationFactory.newInstance();
      final RuleSetInformationReadKey key = new RuleSetInformationReadKey();

      key.ruleSetID = listSuccessTextKey.ruleSetID;
      final RuleSetInformationNoDefinitionDetails dtls = ruleSetInformationObj.readDetailsWithoutDefinition(
        key);

      result.versionNo = dtls.versionNo;

      // BEGIN, CR00052814, AK
      result.nodeName = CuramConst.gkEmpty;
      // END, CR00052814

    } else {
      result.nodeName = text[0].getName();
      result.versionNo = text[0].getRuleSetVersion();
    }

    // END, HARP-40911

    for (int i = 0; i < text.length; i++) {

      final Text t = text[i];

      final SuccessFailTextListDtls successFailTextListDtls = new SuccessFailTextListDtls();

      successFailTextListDtls.languageCode = t.getLocale();
      successFailTextListDtls.text = t.getValue();

      result.textList.readTextDtls.addRef(successFailTextListDtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * List of work allocation rule sets.
   *
   * @return List of work allocation rule sets.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetDetailsList listWorkAllocationRuleSet() throws AppException,
      InformationalException {

    final RuleSetIdAndName ruleSets[] = Editor.listGenericRuleSets();

    final RuleSetDetailsList result = new RuleSetDetailsList();

    for (int i = 0; i < ruleSets.length; i++) {

      final RuleSetIdAndName r = ruleSets[i];

      final RuleSetListDetails dtls = new RuleSetListDetails();

      dtls.ruleSetID = r.getRuleSetID();
      dtls.ruleSetName = r.getName();

      result.ruleSetDtls.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a data assignment.
   *
   * @param modifyDataAssignmentDetails Modified data assignment details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyDataAssignment(
    DataAssignmentModifyDetails modifyDataAssignmentDetails)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, data assignments on the Rule Set cannot be
    // modified
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_DATA_ASSIGNMENT);
    }

    Editor.modifyDataItemAssignment(modifyDataAssignmentDetails.ruleSetID,
      modifyDataAssignmentDetails.versionNo, modifyDataAssignmentDetails.nodeID,
      modifyDataAssignmentDetails.dataItemID,
      modifyDataAssignmentDetails.formulaString,
      modifyDataAssignmentDetails.loadTarget);
  }

  // ___________________________________________________________________________
  /**
   * Modifies failure text.
   *
   * @param modifyTextDtls Modified failure text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyFailureText(SuccessFailureTextDtls modifyTextDtls)
    throws AppException, InformationalException {

    Editor.addOrModifyFailureText(modifyTextDtls.ruleSetID,
      modifyTextDtls.versionNo, modifyTextDtls.nodeID,
      modifyTextDtls.languageCode, modifyTextDtls.text);
  }

  // ___________________________________________________________________________
  /**
   * Modifies objective details.
   *
   * @param modifyDetails Modified objective details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyObjective(ObjectiveDetails modifyDetails)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, some objective details may not be modified
    // on the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      // Need to read the details of the objective back from the database
      // and see if the non-modifiable elements have been modified
      final Objective obj = Editor.getObjective(modifyDetails.ruleSetID,
        modifyDetails.nodeID);

      final ObjectiveReadDetails result = new ObjectiveReadDetails();

      result.financialComponentType = obj.getRateFcType();
      result.priority = obj.getPriority();
      result.targetCode = obj.getRateTarget();
      result.targetIdentifier = obj.getTargetId();
      result.typeCode = obj.getRateType();
      result.ruleID = obj.getRuleID();
      result.relatedReference = obj.getRelatedReference();

      // Financial Component Type cannot be modified
      if (!result.financialComponentType.equals(
        modifyDetails.financialComponentType)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_FC_TYPE);
      }

      // Priority cannot be modified
      if (result.priority != modifyDetails.priority) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_PRIORITY);

      }

      // Type cannot be modified
      if (!result.typeCode.equals(modifyDetails.typeCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_TYPE);
      }

      // Target cannot be modified
      if (!result.targetCode.equals(modifyDetails.targetCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_TARGET);
      }

      // Target identifier cannot be modified
      if (!result.targetIdentifier.equals(modifyDetails.targetIdentifier)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_TARGET_IDENTIFIER);
      }

    }

    final Objective objective = Editor.getObjective(modifyDetails.ruleSetID,
      modifyDetails.nodeID);

    Editor.modifyObjective(modifyDetails.ruleSetID, modifyDetails.versionNo,
      modifyDetails.nodeID, modifyDetails.highLightInd,
      modifyDetails.legislationID, modifyDetails.comments, modifyDetails.name,
      modifyDetails.successText, modifyDetails.failureText, // BEGIN, CR00052814, AK
      modifyDetails.deductionsAllowedInd, CuramConst.gkEmpty, // description not used in this context
      // END, CR00052814
      modifyDetails.targetCode, modifyDetails.financialComponentType,
      modifyDetails.typeCode, modifyDetails.targetIdentifier,
      modifyDetails.priority, objective.getObjectiveRecordID(),
      modifyDetails.ruleID, modifyDetails.relatedReference);
    // END HARP 34202

  }

  // ___________________________________________________________________________
  /**
   * Modifies objective group details.
   *
   * @param details Modified objective group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyObjectiveGroup(ObjectiveGroupDetails details)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      // Need to read the details of the objective group back from the database
      // and see if the non-modifiable elements have been modified
      final ObjectiveGroupReadDetails result = new ObjectiveGroupReadDetails();

      final ObjectiveGroup objectiveGroup = Editor.getObjectiveGroup(
        details.ruleSetID, details.nodeID);

      result.conjunctionCode = codeOut(objectiveGroup.getConjunction());
      result.priority = objectiveGroup.getPriority();
      result.ruleID = objectiveGroup.getRuleID();

      // The conjunction cannot be modified
      if (!result.conjunctionCode.equals(details.conjunctionCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_CONJUNCTION);
      }

      // The priority cannot be modified
      if (result.priority != details.priority) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_PRIORITY);
      }

    }

    Editor.modifyObjectiveGroup(details.ruleSetID, details.versionNo,
      details.nodeID, details.priority, details.highLightInd,
      details.legislationID, details.comments, details.name,
      codeIn(details.conjunctionCode), details.successText, details.failureText,
      details.ruleID);
  }

  // ___________________________________________________________________________
  /**
   * Modifies objective list group details.
   *
   * @param details Modified objective list group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyObjectiveListGroup(ObjectiveListGroupModifyDetails details)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      // Need to read the details of the objective list group back from the
      // database and see if the non-modifiable elements have been modified
      final ObjectiveListGroupViewDetails result = new ObjectiveListGroupViewDetails();

      final ObjectiveListGroup objectiveListGroup = Editor.getObjectiveListGroup(
        details.dtls.ruleSetID, details.dtls.nodeID);

      result.conjunctionCode = codeOut(objectiveListGroup.getConjunction());
      result.listRulesDataObjectID = objectiveListGroup.getListGroup();
      result.priority = objectiveListGroup.getPriority();
      result.ruleID = objectiveListGroup.getRuleID();

      // The conjunction cannot be modified
      if (!result.conjunctionCode.equals(details.conjunctionCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_CONJUNCTION);
      }

      // The priority cannot be modified
      if (result.priority != details.priority) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_PRIORITY);
      }

      // The priority cannot be modified
      if (!result.listRulesDataObjectID.equals(details.listRulesDataObjectID)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_LIST_RULES_DATA_OBJECT);
      }

    }

    // BEGIN, HARP-46955, ZZ
    // BEGIN, HARP-38584, ZZ

    Editor.modifyObjectiveListGroup(details.dtls.ruleSetID, details.versionNo,
      details.dtls.nodeID, details.priority, details.highLightInd,
      details.legislationID, details.comments, details.name,
      codeIn(details.conjunctionCode), details.successText, details.failureText,
      details.listRulesDataObjectID, details.ruleID);
    // END, HARP-38584
    // END, HARP-46955

  }

  // ___________________________________________________________________________
  /**
   * Modifies objective tag details.
   *
   * @param dtls Modified objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyObjectiveTag(ObjectiveTagDetails dtls)
    throws AppException, InformationalException {

    // END, HARP-39217

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, certain objective tag details cannot be modified
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      final ObjectiveTagReadDetails result = new ObjectiveTagReadDetails();

      final ObjectiveTag tag = Editor.getObjectiveTag(dtls.ruleSetID,
        dtls.nodeID);

      result.frequency = tag.getPattern();
      result.tagType = tag.getType();
      result.value = tag.getValue();

      // Frequency cannot be modified
      if (result.frequency.equals(dtls.frequency)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_FREQUENCY);
      }

      // Type cannot be modified
      if (result.tagType.equals(dtls.tagType)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_TYPE);
      }

      // Type cannot be modified
      if (result.value.equals(dtls.value)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_VALUE);
      }

    }

    final ObjectiveTag tag = Editor.getObjectiveTag(dtls.ruleSetID, dtls.nodeID);

    // now update the rule set
    Editor.modifyObjectiveTag(dtls.ruleSetID, dtls.versionNo, dtls.nodeID,
      dtls.name, dtls.tagType, dtls.value, dtls.frequency, dtls.comments,
      tag.getTagRecordId());
  }

  // ___________________________________________________________________________
  /**
   * Modifies rule details.
   *
   * @param modifyRuleDtls Modified rule details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyRule(RuleModifyDetails modifyRuleDtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, certain details of a rule cannot be modified
    // on the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      final RuleDetails result = new RuleDetails();

      final Rule rule = Editor.getRule(modifyRuleDtls.ruleSetID,
        modifyRuleDtls.nodeID);

      result.excludeFromReassessmentInd = rule.isExcludedFromReassessment();
      result.ruleID = rule.getRuleID();

      if (result.excludeFromReassessmentInd
        != modifyRuleDtls.excludeFromReassessmentInd) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_REASSESSMENT_IND);
      }

    }

    Editor.modifyRule(modifyRuleDtls.ruleSetID, modifyRuleDtls.versionNo,
      modifyRuleDtls.nodeID, modifyRuleDtls.highlightID,
      modifyRuleDtls.legislationID, modifyRuleDtls.ruleName,
      modifyRuleDtls.summaryInd, modifyRuleDtls.excludeFromSimulationInd,
      modifyRuleDtls.excludeFromReassessmentInd, modifyRuleDtls.successText,
      modifyRuleDtls.failureText, modifyRuleDtls.ruleID,
      modifyRuleDtls.expressionText);
  }

  // ___________________________________________________________________________
  /**
   * Modifies rule group details.
   *
   * @param ruleGroupModifyDtls Modified rule group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyRuleGroup(RuleGroupDetails ruleGroupModifyDtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      final RuleGroup ruleGroup = Editor.getRuleGroup(
        ruleGroupModifyDtls.ruleSetID, ruleGroupModifyDtls.nodeID);

      final RuleGroupDetails result = new RuleGroupDetails();

      result.assessmentQueryModeCode = codeOut(
        ruleGroup.getAssessmentQueryMode());
      result.conjunctionCode = codeOut(ruleGroup.getOperation());
      result.executionModeCode = codeOut(ruleGroup.getExecutionMode());
      result.ruleID = ruleGroup.getRuleID();

      if (!result.assessmentQueryModeCode.equals(
        ruleGroupModifyDtls.assessmentQueryModeCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_QUERY_MODE);
      }

      if (!result.conjunctionCode.equals(ruleGroupModifyDtls.conjunctionCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_CONJUNCTION);
      }

      if (!result.executionModeCode.equals(
        ruleGroupModifyDtls.executionModeCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_EXECUTION_MODE);
      }

    }

    Editor.modifyRuleGroup(ruleGroupModifyDtls.ruleSetID,
      ruleGroupModifyDtls.versionNo, ruleGroupModifyDtls.nodeID,
      ruleGroupModifyDtls.highlightInd, ruleGroupModifyDtls.legislationID,
      ruleGroupModifyDtls.name, codeIn(ruleGroupModifyDtls.conjunctionCode),
      codeIn(ruleGroupModifyDtls.executionModeCode),
      ruleGroupModifyDtls.summaryInd,
      codeIn(ruleGroupModifyDtls.assessmentQueryModeCode),
      ruleGroupModifyDtls.successText, ruleGroupModifyDtls.failureText,
      ruleGroupModifyDtls.ruleID);

  }

  // ___________________________________________________________________________
  /**
   * Modifies rule list group details.
   *
   * @param modifyRuleListGroupDtls Modified rule list group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyRuleListGroup(
    RulesListGroupDetails modifyRuleListGroupDtls) throws AppException,
      InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      final RulesListGroupReadDetails result = new RulesListGroupReadDetails();

      final RuleListGroup listGroup = Editor.getRuleListGroup(
        modifyRuleListGroupDtls.ruleSetID, modifyRuleListGroupDtls.nodeID);

      result.assessmentQueryModeCode = codeOut(
        listGroup.getAssessmentQueryMode());
      result.conjunctionCode = codeOut(listGroup.getOperation());
      result.executionModeCode = codeOut(listGroup.getExecutionMode());
      result.listRulesDataObjectID = listGroup.getListGroup();
      result.loopExecutionMode = codeOut(listGroup.getLoopExecutionMode());
      result.ruleID = listGroup.getRuleID();

      // Assessment Query Mode cannot be modified
      if (!result.assessmentQueryModeCode.equals(
        modifyRuleListGroupDtls.assessmentQueryModeCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_QUERY_MODE);
      }

      // Conjunction Mode cannot be modified
      if (!result.conjunctionCode.equals(
        modifyRuleListGroupDtls.conjunctionCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_CONJUNCTION);
      }

      // Execution Mode cannot be modified
      if (!result.executionModeCode.equals(
        modifyRuleListGroupDtls.executionModeCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_EXECUTION_MODE);
      }

      // Loop Execution Mode cannot be modified
      if (!result.loopExecutionMode.equals(
        modifyRuleListGroupDtls.loopExecutionMode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_LOOP_EXECUTION_MODE);
      }

      // List Rules Data Object
      if (!result.listRulesDataObjectID.equals(
        modifyRuleListGroupDtls.listRulesDataObjectID)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_LIST_RULES_DATA_OBJECT);
      }

    }

    // BEGIN, HARP-46955, ZZ
    // BEGIN, HARP-38584, ZZ

    Editor.modifyRuleListGroup(modifyRuleListGroupDtls.ruleSetID,
      modifyRuleListGroupDtls.versionNo, modifyRuleListGroupDtls.nodeID,
      modifyRuleListGroupDtls.highlightInd,
      modifyRuleListGroupDtls.legislationID, modifyRuleListGroupDtls.name,
      codeIn(modifyRuleListGroupDtls.conjunctionCode),
      codeIn(modifyRuleListGroupDtls.executionModeCode),
      modifyRuleListGroupDtls.summaryInd,
      codeIn(modifyRuleListGroupDtls.assessmentQueryModeCode),
      modifyRuleListGroupDtls.successText, modifyRuleListGroupDtls.failureText,
      codeIn(modifyRuleListGroupDtls.loopExecutionMode),
      modifyRuleListGroupDtls.listRulesDataObjectID,
      modifyRuleListGroupDtls.ruleID);

    // END, HARP-38584
    // END, HARP-46955

  }

  // ___________________________________________________________________________
  /**
   * Modifies rule set details.
   *
   * @param ruleSetModifyDtls Modified rule set details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyRuleSet(RuleSetStructDtls ruleSetModifyDtls)
    throws AppException, InformationalException {

    Editor.modifyEligibilityRuleSet(ruleSetModifyDtls.ruleSetID,
      ruleSetModifyDtls.versionNo, ruleSetModifyDtls.ruleSetName,
      ruleSetModifyDtls.highLightInd, ruleSetModifyDtls.legislationBase,
      ruleSetModifyDtls.legislationID, ruleSetModifyDtls.comments,
      ruleSetModifyDtls.ruleSetCategory, ruleSetModifyDtls.successText,
      ruleSetModifyDtls.failureText);
  }

  // ___________________________________________________________________________
  /**
   * Modifies sub rule set details.
   *
   * @param ruleSetDetails Modified sub rule set details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifySubRuleSet(ModifySubRuleSetDtls ruleSetDetails)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, a rule may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_SUB_RULE_SETS);
    }

    // BEGIN, CR00022750, LP
    Editor.modifySubRuleSet(ruleSetDetails.ruleSetID, ruleSetDetails.versionNo,
      ruleSetDetails.highlightOnFailureInd, ruleSetDetails.legislationID,
      ruleSetDetails.legislationBase, ruleSetDetails.ruleSetName,
      ruleSetDetails.comments, ruleSetDetails.successText,
      ruleSetDetails.failureText);
    // END, CR00022750, LP
  }

  // ___________________________________________________________________________
  /**
   * Modifies success text.
   *
   * @param successTextDtls Modified success text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifySuccessText(SuccessFailureTextDtls successTextDtls)
    throws AppException, InformationalException {

    Editor.addOrModifySuccessText(successTextDtls.ruleSetID,
      successTextDtls.versionNo, successTextDtls.nodeID,
      successTextDtls.languageCode, successTextDtls.text);
  }

  // ___________________________________________________________________________
  /**
   * Moves an item down the execution order.
   *
   * @param nodeDtlsKey Key to move item down the execution order.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void moveItemDownExecutionOrder(RuleSetNodeVersionKey nodeDtlsKey)
    throws AppException, InformationalException {

    Editor.moveItemDownExecutionOrder(nodeDtlsKey.ruleSetID,
      nodeDtlsKey.versionNo, nodeDtlsKey.nodeID);

    // BEGIN, CR00051866, "PA"
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    if (nodeDtlsKey.ruleSetID != null && nodeDtlsKey.ruleSetID.length() > 0) {

      // BEGIN, CR00051913, "PA"
      ruleSetNodeKey.nodeID = nodeDtlsKey.parentNodeID;
      // END, CR00051913
      ruleSetNodeKey.ruleSetID = nodeDtlsKey.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }
    // END, CR00051866

  }

  // ___________________________________________________________________________
  /**
   * Moves an item up the execution order.
   *
   * @param moveItemUpKey Key to move item up the execution order.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void moveItemUpExecutionOrder(RuleSetNodeVersionKey moveItemUpKey)
    throws AppException, InformationalException {

    Editor.moveItemUpExecutionOrder(moveItemUpKey.ruleSetID,
      moveItemUpKey.versionNo, moveItemUpKey.nodeID);

    // BEGIN, CR00051866, "PA"
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    if (moveItemUpKey.ruleSetID != null && moveItemUpKey.ruleSetID.length() > 0) {
      // BEGIN, CR00051913, "PA"
      ruleSetNodeKey.nodeID = moveItemUpKey.parentNodeID;
      // END, CR00051913
      ruleSetNodeKey.ruleSetID = moveItemUpKey.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }
    // END, CR00051866

  }

  // ___________________________________________________________________________
  /**
   * Reads data assignment details.
   *
   * @param rulesSetNodeKey Key to read data assignment details.
   *
   * @return Data assignment details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ReadDataAssignmentDetails readDataAssignment(
    RuleSetNodeKey rulesSetNodeKey) throws AppException,
      InformationalException {

    final ReadDataAssignmentDetails result = new ReadDataAssignmentDetails();

    final DataItemAssignment di = Editor.getDataItemAssignment(
      rulesSetNodeKey.ruleSetID, rulesSetNodeKey.nodeID);

    result.dataItemID = di.getDataItem();
    result.dateItemName = di.getDataItemDescription();
    result.formulaString = di.getValue();
    result.versionNo = di.getRuleSetVersion();
    result.loadTarget = di.getLoadTarget();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      rulesSetNodeKey.ruleSetID, rulesSetNodeKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads the failure text.
   *
   * @param readTextKey Key to read the failure text
   *
   * @return Failure text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public SuccessFailureTextReadDtls readFailureText(
    ReadSuccessFailureTextKey readTextKey) throws AppException,
      InformationalException {

    final Text text[] = Editor.listFailureText(readTextKey.ruleSetID,
      readTextKey.nodeID);

    for (int i = 0; i < text.length; i++) {

      final Text t = text[i];

      if (t.getLocale().equals(readTextKey.languageCode)) {

        final SuccessFailureTextReadDtls result = new SuccessFailureTextReadDtls();

        result.languageCode = t.getLocale();
        result.text = t.getValue();
        result.versionNo = t.getRuleSetVersion();
        return result;
      }

    }

    // Should never reach here
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective details.
   *
   * @param readObjectiveKey Key to read the objective details.
   *
   * @return Objective details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveReadDetails readObjective(RuleSetNodeKey readObjectiveKey)
    throws AppException, InformationalException {

    final Objective obj = Editor.getObjective(readObjectiveKey.ruleSetID,
      readObjectiveKey.nodeID);

    final ObjectiveReadDetails result = new ObjectiveReadDetails();

    result.comments = obj.getComment();
    result.deductionsAllowedInd = obj.isDeductionAllowable();
    result.failureText = obj.getFailureText();
    result.financialComponentType = obj.getRateFcType();
    result.highLightInd = obj.isHighlightOnFailure();
    result.legislationID = obj.getLegislationLink();
    result.name = obj.getName();
    result.priority = obj.getPriority();
    result.successText = obj.getSuccessText();
    result.targetCode = obj.getRateTarget();
    result.targetIdentifier = obj.getTargetId();
    result.targetIdentifierName = obj.getTargetDescription();
    result.typeCode = obj.getRateType();
    result.versionNo = obj.getRuleSetVersion();
    result.rulesObjectiveID = obj.getObjectiveRecordID();
    result.relatedReference = obj.getRelatedReference();
    result.ruleID = obj.getRuleID();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      readObjectiveKey.ruleSetID, readObjectiveKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective group details.
   *
   * @param ruleSetNodeKey Key to read the objective group details.
   *
   * @return Objective group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveGroupReadDetails readObjectiveGroup(
    RuleSetNodeKey ruleSetNodeKey) throws AppException,
      InformationalException {

    final ObjectiveGroupReadDetails result = new ObjectiveGroupReadDetails();

    final ObjectiveGroup objectiveGroup = Editor.getObjectiveGroup(
      ruleSetNodeKey.ruleSetID, ruleSetNodeKey.nodeID);

    result.comments = objectiveGroup.getComment();
    result.conjunctionCode = codeOut(objectiveGroup.getConjunction());
    result.failureText = objectiveGroup.getFailureText();
    result.highLightInd = objectiveGroup.isHighlightOnFailure();
    result.legislationID = objectiveGroup.getLegislationLink();
    result.name = objectiveGroup.getName();
    result.priority = objectiveGroup.getPriority();
    result.successText = objectiveGroup.getSuccessText();
    result.versionNo = objectiveGroup.getRuleSetVersion();
    result.ruleID = objectiveGroup.getRuleID();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      ruleSetNodeKey.ruleSetID, ruleSetNodeKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective group summary details.
   *
   * @param readObjectiveGrpSummaryKey Key to read the objective group summary
   * details.
   *
   * @return Objective group summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveGroupSummaryDetails readObjectiveGroupSummary(
    RuleSetNodeKey readObjectiveGrpSummaryKey) throws AppException,
      InformationalException {

    final ObjectiveGroupSummaryDetails result = new ObjectiveGroupSummaryDetails();

    final ObjectiveGroup objectiveGroup = Editor.getObjectiveGroup(
      readObjectiveGrpSummaryKey.ruleSetID, readObjectiveGrpSummaryKey.nodeID);

    result.objectiveGroupDtls = readObjectiveGroup(readObjectiveGrpSummaryKey);
    copyRuleChildren(objectiveGroup.getChildren(), result.childItemList);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective list group details.
   *
   * @param readObjectListGroupKey Key to read the objective list group details
   *
   * @return Objective group list details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveListGroupViewDetails readObjectiveListGroup(
    RuleSetNodeKey readObjectListGroupKey) throws AppException,
      InformationalException {

    final ObjectiveListGroupViewDetails result = new ObjectiveListGroupViewDetails();

    final ObjectiveListGroup objectiveListGroup = Editor.getObjectiveListGroup(
      readObjectListGroupKey.ruleSetID, readObjectListGroupKey.nodeID);

    result.comments = objectiveListGroup.getComment();
    result.conjunctionCode = codeOut(objectiveListGroup.getConjunction());
    result.failureText = objectiveListGroup.getFailureText();
    result.highLightInd = objectiveListGroup.isHighlightOnFailure();
    result.legislationID = objectiveListGroup.getLegislationLink();
    result.listRulesDataObjectID = objectiveListGroup.getListGroup();
    result.listRulesDataObjectName = objectiveListGroup.getListGroupDisplayName();
    result.name = objectiveListGroup.getName();
    result.nodeID = objectiveListGroup.getNodeId();
    result.priority = objectiveListGroup.getPriority();
    result.ruleSetID = readObjectListGroupKey.ruleSetID;
    result.successText = objectiveListGroup.getSuccessText();
    result.versionNo = objectiveListGroup.getRuleSetVersion();
    result.ruleID = objectiveListGroup.getRuleID();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      readObjectListGroupKey.ruleSetID, readObjectListGroupKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective list group summary.
   *
   * @param readSummaryKey Key to read the objective list group summary.
   *
   * @return Objective list group summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveListGroupSummaryDtls readObjectiveListGroupSummary(
    RuleSetNodeKey readSummaryKey) throws AppException,
      InformationalException {

    final ObjectiveListGroupSummaryDtls result = new ObjectiveListGroupSummaryDtls();

    result.summaryDtls = readObjectiveListGroup(readSummaryKey);

    final ObjectiveListGroup objectiveListGroup = Editor.getObjectiveListGroup(
      readSummaryKey.ruleSetID, readSummaryKey.nodeID);

    copyRuleChildren(objectiveListGroup.getChildren(), result.nodeItems);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective summary details.
   *
   * @param key Key to read the objective summary details.
   *
   * @return Objective summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveSummaryDetails readObjectiveSummary(RuleSetNodeKey key)
    throws AppException, InformationalException {

    final ObjectiveSummaryDetails result = new ObjectiveSummaryDetails();

    result.objectiveDtls = readObjective(key);

    final Objective obj = Editor.getObjective(key.ruleSetID, key.nodeID);

    final RuleChild children[] = obj.getChildren();

    for (int i = 0; i < children.length; i++) {

      final RuleChild child = children[i];

      final ChildItemListDetails dtls = new ChildItemListDetails();

      dtls.nodeID = child.getNodeID();
      dtls.nodeName = child.getDisplayName();
      dtls.nodeType = child.getType();

      result.childItemDtls.childDtls.nodeDetails.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads objective tag details.
   *
   * @param readObjectiveTagKey Key to read objective tag details.
   *
   * @return Objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ObjectiveTagReadDetails readObjectiveTag(
    RuleSetNodeKey readObjectiveTagKey) throws AppException,
      InformationalException {

    final ObjectiveTagReadDetails result = new ObjectiveTagReadDetails();

    final ObjectiveTag tag = Editor.getObjectiveTag(
      readObjectiveTagKey.ruleSetID, readObjectiveTagKey.nodeID);

    result.comments = tag.getComment();
    result.frequency = tag.getPattern();
    result.name = tag.getName();
    result.tagType = tag.getType();
    result.value = tag.getValue();
    result.versionNo = tag.getRuleSetVersion();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      readObjectiveTagKey.ruleSetID, readObjectiveTagKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule details.
   *
   * @param readRuleKey Key to read rule details.
   *
   * @return Rule details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleDetails readRule(RuleSetNodeKey readRuleKey)
    throws AppException, InformationalException {

    final RuleDetails result = new RuleDetails();

    final Rule rule = Editor.getRule(readRuleKey.ruleSetID, readRuleKey.nodeID);

    result.excludeFromReassessmentInd = rule.isExcludedFromReassessment();
    result.excludeFromSimulationInd = rule.isExcludedFromSimulation();
    result.failureText = rule.getFailureText();
    result.highlightID = rule.isHighlightOnFailure();
    result.legislationID = rule.getLegislationLink();
    result.nodeID = rule.getNodeId();
    result.ruleName = rule.getName();
    result.ruleSetID = readRuleKey.ruleSetID;
    result.successText = rule.getSuccessText();
    result.summaryInd = rule.isSummaryItem();
    result.versionNo = rule.getRuleSetVersion();
    result.expressionText = rule.getExpression();
    result.ruleID = rule.getRuleID();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      readRuleKey.ruleSetID, readRuleKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule group details.
   *
   * @param readRuleGroupKey Key to read rule group details.
   *
   * @return Rule group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleGroupDetails readRuleGroup(RuleSetNodeKey readRuleGroupKey)
    throws AppException, InformationalException {

    final RuleGroup ruleGroup = Editor.getRuleGroup(readRuleGroupKey.ruleSetID,
      readRuleGroupKey.nodeID);

    final RuleGroupDetails result = new RuleGroupDetails();

    result.assessmentQueryModeCode = codeOut(ruleGroup.getAssessmentQueryMode());
    result.conjunctionCode = codeOut(ruleGroup.getOperation());
    result.executionModeCode = codeOut(ruleGroup.getExecutionMode());
    result.failureText = ruleGroup.getFailureText();
    result.highlightInd = ruleGroup.isHighlightOnFailure();
    result.legislationID = ruleGroup.getLegislationLink();
    result.name = ruleGroup.getName();
    result.nodeID = ruleGroup.getNodeId();
    result.ruleSetID = readRuleGroupKey.ruleSetID;
    result.successText = ruleGroup.getSuccessText();
    result.summaryInd = ruleGroup.isSummaryItem();
    result.versionNo = ruleGroup.getRuleSetVersion();
    result.ruleID = ruleGroup.getRuleID();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      readRuleGroupKey.ruleSetID, readRuleGroupKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule group summary details.
   *
   * @param readSummaryKey Key to read rule group summary details.
   *
   * @return Rule group summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleGroupSummaryDetails readRuleGroupSummary(
    RuleSetNodeKey readSummaryKey) throws AppException,
      InformationalException {

    final RuleGroup ruleGroup = Editor.getRuleGroup(readSummaryKey.ruleSetID,
      readSummaryKey.nodeID);

    final RuleGroupSummaryDetails result = new RuleGroupSummaryDetails();

    result.ruleGroupDtls = readRuleGroup(readSummaryKey);
    copyRuleChildren(ruleGroup.getChildren(), result.childItemDtls);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule list group details.
   *
   * @param readRuleListGroupKey Key to read rule list group details.
   *
   * @return Rule list group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesListGroupReadDetails readRuleListGroup(
    RuleSetNodeKey readRuleListGroupKey) throws AppException,
      InformationalException {

    final RulesListGroupReadDetails result = new RulesListGroupReadDetails();

    final RuleListGroup listGroup = Editor.getRuleListGroup(
      readRuleListGroupKey.ruleSetID, readRuleListGroupKey.nodeID);

    result.assessmentQueryModeCode = codeOut(listGroup.getAssessmentQueryMode());
    result.conjunctionCode = codeOut(listGroup.getOperation());
    result.executionModeCode = codeOut(listGroup.getExecutionMode());
    result.failureText = listGroup.getFailureText();
    result.highlightInd = listGroup.isHighlightOnFailure();
    result.legislationID = listGroup.getLegislationLink();
    result.listRulesDataObjectID = listGroup.getListGroup();
    result.listRulesDataObjectName = listGroup.getListGroupDisplayName();
    result.loopExecutionMode = codeOut(listGroup.getLoopExecutionMode());
    result.name = listGroup.getName();
    result.nodeID = listGroup.getNodeId();
    result.ruleSetID = readRuleListGroupKey.ruleSetID;
    result.successText = listGroup.getSuccessText();
    result.summaryInd = listGroup.isSummaryItem();
    result.versionNo = listGroup.getRuleSetVersion();
    result.ruleID = listGroup.getRuleID();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      readRuleListGroupKey.ruleSetID, readRuleListGroupKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule list group summary details.
   *
   * @param readRuleListGroupSummaryKey Key to read rule list group summary
   * details.
   *
   * @return Rule list group summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesListGroupSummaryDetails readRuleListGroupSummary(
    RuleSetNodeKey readRuleListGroupSummaryKey) throws AppException,
      InformationalException {

    final RulesListGroupSummaryDetails result = new RulesListGroupSummaryDetails();

    result.summaryDtls = readRuleListGroup(readRuleListGroupSummaryKey);

    final RuleListGroup listGroup = Editor.getRuleListGroup(
      readRuleListGroupSummaryKey.ruleSetID, readRuleListGroupSummaryKey.nodeID);

    copyRuleChildren(listGroup.getChildren(), result.childItemList);
    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads sub rule set details.
   *
   * @param readSubRuleSetKey Key to read sub rule set details.
   *
   * @return Sub rule set details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetReadDtls readSubRuleSet(RuleSetIDStruct readSubRuleSetKey)
    throws AppException, InformationalException {

    final RuleSetReadDtls result = new RuleSetReadDtls();
    final SubRuleSet e = Editor.getSubRuleSet(readSubRuleSetKey.ruleSetID);

    result.comments = e.getComment();
    result.failureText = e.getFailureText();
    result.ruleSetName = e.getName();
    result.successText = e.getSuccessText();
    result.versionNo = e.getRuleSetVersion();
    result.highlightOnFailureInd = e.isHighlightOnFailure();
    result.nodeID = 0;
    result.highlightOnFailureInd = e.isHighlightOnFailure();
    result.ruleSetID = readSubRuleSetKey.ruleSetID;
    if (e.getLegislationBase() != null) {
      result.legislationBase = e.getLegislationBase();
    }
    result.legislationID = e.getLegislationLink();
    return result;

  }

  // ___________________________________________________________________________
  /**
   * Reads sub rule set summary details.
   *
   * @param subRuleSetSummaryReadkey Key to read sub rule set summary details.
   *
   * @return Sub rule set summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public SubRuleSetSummaryDtls readSubRuleSetSummary(
    RuleSetIDStruct subRuleSetSummaryReadkey) throws AppException,
      InformationalException {

    final SubRuleSetSummaryDtls result = new SubRuleSetSummaryDtls();

    result.subRuleSetDtls = readSubRuleSet(subRuleSetSummaryReadkey);
    final SubRuleSet e = Editor.getSubRuleSet(
      subRuleSetSummaryReadkey.ruleSetID);

    copyRuleChildren(e.getChildren(), result.childItemDtls);
    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads the success text.
   *
   * @param readTextKey Key to read the success text.
   *
   * @return Success text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public SuccessFailureTextReadDtls readSuccessText(
    ReadSuccessFailureTextKey readTextKey) throws AppException,
      InformationalException {

    final Text text[] = Editor.listSuccessText(readTextKey.ruleSetID,
      readTextKey.nodeID);

    for (int i = 0; i < text.length; i++) {

      final Text t = text[i];

      if (t.getLocale().equals(readTextKey.languageCode)) {

        final SuccessFailureTextReadDtls result = new SuccessFailureTextReadDtls();

        result.languageCode = t.getLocale();
        result.text = t.getValue();
        result.versionNo = t.getRuleSetVersion();

        return result;
      }
    }

    // Should never reach here
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Removes rules data objects.
   *
   * @param removeKey Key to remove rules data objects.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void removeRulesDataObjects(RulesDataObjectKey removeKey)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an RDO may not be removed from a Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE_RULES_DATA_OBJECTS);
    }

    Editor.removeRulesDataObjectFromRuleSet(removeKey.ruleSetID,
      removeKey.versionNo, removeKey.rulesDataObjectID);

  }

  // ___________________________________________________________________________
  /**
   * Removes sub rule set link.
   *
   * @param removeSubRuleSetKey Key to remove a sub rule set link.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void removeSubRuleSetLink(RuleSetNodeVersionKey removeSubRuleSetKey)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, a sub rule set link may not be removed
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE_RULES_DATA_OBJECTS);
    }

    final NodeIDAndType nodeIDAndType = Editor.getParentNodeInformation(
      removeSubRuleSetKey.ruleSetID, removeSubRuleSetKey.nodeID);

    final SubRuleSetLink subRuleSetLink = Editor.getSubRuleSetLink(
      removeSubRuleSetKey.ruleSetID, removeSubRuleSetKey.nodeID);

    removeSubRuleSetKey.versionNo = subRuleSetLink.getRuleSetVersion();

    Editor.deleteNode(removeSubRuleSetKey.ruleSetID,
      removeSubRuleSetKey.versionNo, removeSubRuleSetKey.nodeID);

    if (removeSubRuleSetKey.ruleSetID != null
      && removeSubRuleSetKey.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = nodeIDAndType.getNodeID();
      ruleSetNodeKey.ruleSetID = removeSubRuleSetKey.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads rule set details.
   *
   * @param ruleSetIDKey Key to read rule set details.
   *
   * @return Rule set details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetStructDtls viewRuleSet(RuleSetIDStruct ruleSetIDKey)
    throws AppException, InformationalException {

    final RuleSetStructDtls result = new RuleSetStructDtls();

    final Eligibility e = Editor.getEligibilityRuleSet(ruleSetIDKey.ruleSetID);

    result.ruleSetID = ruleSetIDKey.ruleSetID;
    result.comments = e.getComment();
    result.failureText = e.getFailureText();
    result.highLightInd = e.isHighlightOnFailure();
    result.legislationID = e.getLegislationLink();
    result.legislationBase = e.getLegislationBase();
    result.ruleSetCategory = e.getProductType();
    result.ruleSetName = e.getName();
    result.successText = e.getSuccessText();
    result.versionNo = e.getRuleSetVersion();
    result.nodeID = 0; // required by client for adding sub-nodes

    if (e.getProductType() == null) {
      // can't be null so set to blank string.

      result.ruleSetCategory = kBlankString;

    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule set summary details.
   *
   * @param key Key to read rule set summary details.
   *
   * @return Rule set summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetSummaryDetails viewRuleSetSummary(RuleSetIDStruct key)
    throws AppException, InformationalException {

    final curam.core.facade.struct.RuleSetSummaryDetails result = new RuleSetSummaryDetails();

    result.ruleSetDetails = viewRuleSet(key);

    final Eligibility e = Editor.getEligibilityRuleSet(key.ruleSetID);

    copyRuleChildren(e.getChildren(), result.childItemDtls);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads sub rule set link details.
   *
   * @param ruleSetNodeKey Key to read sub rule set summary details.
   *
   * @return Sub rule set summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetIDAndNameDtls viewSubRuleSetLink(RuleSetNodeKey ruleSetNodeKey) throws AppException,
      InformationalException {

    final RuleSetIDAndNameDtls result = new RuleSetIDAndNameDtls();

    final SubRuleSetLink subRuleSetLink = Editor.getSubRuleSetLink(
      ruleSetNodeKey.ruleSetID, ruleSetNodeKey.nodeID);

    result.ruleSetID = subRuleSetLink.getSubRuleSetId();
    result.ruleSetName = subRuleSetLink.getSubRuleSetName();

    final NodeIDAndType n = Editor.getParentNodeInformation(
      ruleSetNodeKey.ruleSetID, ruleSetNodeKey.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates a data assignment.
   *
   * @param details Details to create a data assignment.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createDataAssignment(DataAssignmentDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, a data assignment cannot be created on the
    // Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_DATA_ASSIGNMENT);
    }

    final NodeIDStruct result = new NodeIDStruct();

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      details.ruleSetID);

    result.nodeID = Editor.createDataItemAssignment(details.ruleSetID,
      versionNo, details.nodeID, details.dataItemID, details.formulaText,
      details.loadTarget);
    // END, CR00023363

    if (details.ruleSetID != null && details.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = details.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates an objective.
   *
   * @param details Details to create an objective.
   *
   * @return Node identifier.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createObjective(ObjectiveDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00023363, KY
    int versionNo;
    // END, CR00023363

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // If the system is live, an objective cannot be created on the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_OBJECTIVE);
    }

    final NodeIDStruct result = new NodeIDStruct();

    // BEGIN, CR00023363, KY
    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      details.ruleSetID);

    result.nodeID = Editor.createObjective(details.ruleSetID, versionNo,
      details.nodeID, details.highLightInd, details.legislationID,
      details.comments, details.name, details.successText, details.failureText,
      // BEGIN, CR00052814, AK
      details.deductionsAllowedInd, CuramConst.gkEmpty, // description not used in this context
      // END, CR00052814
      details.typeCode, details.financialComponentType, details.targetCode,
      details.targetIdentifier, details.priority, details.rulesObjectiveID,
      details.ruleID, details.relatedReference);
    // END, CR00023363, KY

    if (details.ruleSetID != null && details.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = result.nodeID;
      ruleSetNodeKey.ruleSetID = details.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule summary details.
   *
   * @param key Key to read rule summary details.
   *
   * @return Rule summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSummaryDetail readRuleSummary(RuleSetNodeKey key)
    throws AppException, InformationalException {

    final RuleSummaryDetail result = new RuleSummaryDetail();

    result.ruleDataDtls = readRule(key);

    final Rule rule = Editor.getRule(key.ruleSetID, key.nodeID);

    final RuleChild children[] = rule.getChildren();

    for (int i = 0; i < children.length; i++) {

      final RuleChild child = children[i];

      final ConditionReadListDtls dtls = new ConditionReadListDtls();

      dtls.conditionDescription = child.getDisplayName();
      dtls.conditionNodeID = child.getNodeID();
      dtls.conditionType = child.getType();

      result.conditionListDtls.conditionDtls.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates an assessment objective tag.
   *
   * @param dtls Details to create an assessment objective tag.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createAssessmentObjectiveTag(AssessmentObjectiveTagDetails dtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an assessment objective tag cannot be created
    // on the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_ASSESSMENT_OBJECTIVE_TAG);
    }

    final ObjectiveTagDetails altDtls = new ObjectiveTagDetails();

    // END, HARP-39217
    altDtls.comments = dtls.comments;
    // BEGIN, CR00052324, AK
    altDtls.frequency = FrequencyPattern.kZeroFrequencyPattern.toString();
    // END, CR00052324
    altDtls.name = dtls.name;
    altDtls.nodeID = dtls.nodeID;
    altDtls.ruleSetID = dtls.ruleSetID;
    altDtls.tagType = RULESTAGTYPE.ASSESSMENT;
    altDtls.value = dtls.valueCode;
    altDtls.versionNo = dtls.versionNo;

    createObjectiveTag(altDtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates a product objective tag.
   *
   * @param dtls Details to create a product objective tag.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createProductObjectiveTag(ProductObjectiveTagDetails dtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, a product objective tag cannot be created
    // on the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_PRODUCT_OBJECTIVE_TAG);
    }

    final ObjectiveTagDetails altDtls = new ObjectiveTagDetails();

    altDtls.comments = dtls.comments;
    // BEGIN, CR00052324, AK
    altDtls.frequency = FrequencyPattern.kZeroFrequencyPattern.toString();
    // END, CR00052324
    altDtls.name = dtls.name;
    altDtls.nodeID = dtls.nodeID;
    altDtls.ruleSetID = dtls.ruleSetID;
    altDtls.tagType = RULESTAGTYPE.PRODUCTDELIVERY;
    altDtls.value = dtls.valueCode;
    altDtls.versionNo = dtls.versionNo;

    createObjectiveTag(altDtls);
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of failure text.
   *
   * @param listTextKey Key to return a list of failure text.
   *
   * @return List of failure text.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ListSuccessFailureTextDtls listFailureText(RuleSetNodeKey listTextKey) throws AppException,
      InformationalException {

    final Text text[] = Editor.listFailureText(listTextKey.ruleSetID,
      listTextKey.nodeID);

    final ListSuccessFailureTextDtls result = new ListSuccessFailureTextDtls();

    // BEGIN, HARP-40911, ZZ

    // Text objects have node name and version, but we only need the first
    if (text.length == 0) {
      final RuleSetInformation ruleSetInformationObj = RuleSetInformationFactory.newInstance();
      final RuleSetInformationReadKey key = new RuleSetInformationReadKey();

      key.ruleSetID = listTextKey.ruleSetID;
      final RuleSetInformationNoDefinitionDetails dtls = ruleSetInformationObj.readDetailsWithoutDefinition(
        key);

      result.versionNo = dtls.versionNo;
      // BEGIN, CR00052814, AK
      result.nodeName = CuramConst.gkEmpty;
      // END, CR00052814

    } else {
      result.nodeName = text[0].getName();
      result.versionNo = text[0].getRuleSetVersion();
    }

    // END, HARP-40911

    for (int i = 0; i < text.length; i++) {

      final Text t = text[i];

      final SuccessFailTextListDtls successFailTextListDtls = new SuccessFailTextListDtls();

      successFailTextListDtls.languageCode = t.getLocale();
      successFailTextListDtls.text = t.getValue();

      result.textList.readTextDtls.addRef(successFailTextListDtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an assessment objective tag.
   *
   * @param dtls Modified assessment objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyAssessmentObjectiveTag(AssessmentObjectiveTagDetails dtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an RDO may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      final ObjectiveTag tag = Editor.getObjectiveTag(dtls.ruleSetID,
        dtls.nodeID);

      final ProductObjectiveTagDetails result = new ProductObjectiveTagDetails();

      result.valueCode = tag.getValue();

      // Value cannot be modified
      if (!result.valueCode.equals(dtls.valueCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_VALUE);
      }

    }

    final ObjectiveTagDetails altDtls = new ObjectiveTagDetails();

    altDtls.comments = dtls.comments;
    // BEGIN, CR00052324, AK
    altDtls.frequency = FrequencyPattern.kZeroFrequencyPattern.toString();
    // END, CR00052324
    altDtls.name = dtls.name;
    altDtls.nodeID = dtls.nodeID;
    altDtls.ruleSetID = dtls.ruleSetID;
    altDtls.tagType = RULESTAGTYPE.ASSESSMENT;
    altDtls.value = dtls.valueCode;
    altDtls.versionNo = dtls.versionNo;

    modifyObjectiveTag(altDtls);
  }

  // ___________________________________________________________________________
  /**
   * Modifies a product objective tag.
   *
   * @param dtls Modified product objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyProductObjectiveTag(ProductObjectiveTagDetails dtls)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an RDO may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      final ObjectiveTag tag = Editor.getObjectiveTag(dtls.ruleSetID,
        dtls.nodeID);

      final ProductObjectiveTagDetails result = new ProductObjectiveTagDetails();

      result.valueCode = tag.getValue();

      // Value cannot be modified
      if (!result.valueCode.equals(dtls.valueCode)) {

        throw new AppException(
          curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_MODIFY_VALUE);
      }
    }

    final ObjectiveTagDetails altDtls = new ObjectiveTagDetails();

    altDtls.comments = dtls.comments;
    // BEGIN, CR00052324, AK
    altDtls.frequency = FrequencyPattern.kZeroFrequencyPattern.toString();
    // END, CR00052324
    altDtls.name = dtls.name;
    altDtls.nodeID = dtls.nodeID;
    altDtls.ruleSetID = dtls.ruleSetID;
    altDtls.tagType = RULESTAGTYPE.PRODUCTDELIVERY;
    altDtls.value = dtls.valueCode;
    altDtls.versionNo = dtls.versionNo;

    modifyObjectiveTag(altDtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads an assessment objective tag.
   *
   * @param key Key to read assessment objective tag details.
   *
   * @return Assessment objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public AssessmentObjectiveTagDetails readAssessmentObjectiveTag(
    RuleSetNodeKey key) throws AppException, InformationalException {

    final ObjectiveTag tag = Editor.getObjectiveTag(key.ruleSetID, key.nodeID);

    final AssessmentObjectiveTagDetails result = new AssessmentObjectiveTagDetails();

    result.comments = tag.getComment();
    result.name = tag.getName();
    result.nodeID = tag.getNodeId();
    result.ruleSetID = key.ruleSetID;
    result.valueCode = tag.getValue();
    result.versionNo = tag.getRuleSetVersion();

    final NodeIDAndType n = Editor.getParentNodeInformation(key.ruleSetID,
      key.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads a product assessment objective tag.
   *
   * @param key Key to read product objective tag details.
   *
   * @return Product objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ProductObjectiveTagDetails readProductObjectiveTag(RuleSetNodeKey key) throws AppException,
      InformationalException {

    final ObjectiveTag tag = Editor.getObjectiveTag(key.ruleSetID, key.nodeID);

    final ProductObjectiveTagDetails result = new ProductObjectiveTagDetails();

    result.comments = tag.getComment();
    result.name = tag.getName();
    result.nodeID = tag.getNodeId();
    result.ruleSetID = key.ruleSetID;
    result.valueCode = tag.getValue();
    result.versionNo = tag.getRuleSetVersion();

    final NodeIDAndType n = Editor.getParentNodeInformation(key.ruleSetID,
      key.nodeID);

    result.parentNodeID = n.getNodeID();
    result.parentNodeType = n.getType();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rule group details.
   *
   * @param key Key to read rule group details.
   *
   * @return Rule group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleGroupDetails viewRuleGroup(RuleSetNodeKey key)
    throws AppException, InformationalException {

    return readRuleGroup(key);
  }

  // ___________________________________________________________________________
  /**
   * Reads rules data object details.
   *
   * @param key Key to read rules data object details.
   *
   * @return Rules data object details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectSummaryDtls viewRulesDataObject(
    RulesDataObjectIDKey key) throws AppException, InformationalException {

    final RulesDataObjectSummaryDtls result = new RulesDataObjectSummaryDtls();

    final RDO rdo = Editor.getRulesDataObject(key.rulesDataObjectID);

    result.nameAndTypeDtls.rulesDataObjectName = rdo.getDisplayName();
    result.nameAndTypeDtls.rulesDataObjectFinal = rdo.isFinal();
    if (rdo.isListGroup()) {
      result.nameAndTypeDtls.rulesDataObjectType = RULESDATAOBJECTTYPE.LIST;
    } else {
      result.nameAndTypeDtls.rulesDataObjectType = RULESDATAOBJECTTYPE.SINGLE;
    }

    final DataItem dataItems[] = rdo.getItems();

    for (int i = 0; i < dataItems.length; i++) {

      final DataItem dataItem = dataItems[i];

      final AttributeDtls attr = new AttributeDtls();

      // BEGIN , CR00125464, DJ
      attr.attributeName = dataItem.getShortName();
      // END, CR00125464
      attr.attributeType = dataItem.getType();

      result.attributeDtls.attibuteDtls.addRef(attr);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads rules data object group details.
   *
   * @param rulesDataObjectGroupKey Key to read rules data object group details.
   *
   * @return Rules data object group details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RulesDataObjectViewDtls viewRulesDataObjectGroup(
    RulesDataObjectGroupIDKey rulesDataObjectGroupKey) throws AppException,
      InformationalException {

    final RDO rdos[] = Editor.viewRuleDataObjectGroup(
      rulesDataObjectGroupKey.rulesDataObjectGroupID);
    final RulesDataObjectViewDtls result = new RulesDataObjectViewDtls();

    result.name = rulesDataObjectGroupKey.rulesDataObjectGroupID;

    for (int i = 0; i < rdos.length; i++) {

      final RDO rdo = rdos[i];

      final RulesDataObjectsInGroupDtls dtls = new RulesDataObjectsInGroupDtls();

      dtls.rulesDataObjectID = rdo.getName();
      dtls.rulesDataObjectName = rdo.getDisplayName();

      result.rdoListDtls.rdoDtls.addRef(dtls);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Deletes an objective.
   *
   * @param key Key to delete an objective.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteObjective(RuleSetNodeVersionKey key) throws AppException,
      InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an objective may not be deleted
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE_OBJECTIVE);
    }

    deleteNode(key);
  }

  // ___________________________________________________________________________
  /**
   * Deletes an objective tag.
   *
   * @param key Key to delete an objective tag.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteObjectiveTag(RuleSetNodeVersionKey key)
    throws AppException, InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an objective tag may not be deleted
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_DELETE_OBJECTIVE_TAG);
    }

    deleteNode(key);
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation rule set.
   *
   * @param createDtls Details to create a work allocation rule set.
   *
   * @return Rule set identifier.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetIDStruct createWorkAllocationRuleSet(
    CreateWorkAllocationRuleSet createDtls) throws AppException,
      InformationalException {

    Editor.createGenericRuleSet(createDtls.ruleSetID, createDtls.ruleSetName,
      false, // highlight flag not provided in this context
      // BEGIN, CR00052814, AK
      CuramConst.gkEmpty, CuramConst.gkEmpty, // legislation base and link not provided in this context
      // END, CR00052814
      createDtls.comments, createDtls.ruleSetName, // Default success text to the rule set name
      createDtls.ruleSetName// Default failure text to the rule set name
      );

    final RuleSetIDStruct result = new RuleSetIDStruct();

    result.ruleSetID = createDtls.ruleSetID;
    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads work allocation rule set details.
   *
   * @param key Key to read work allocation rule set details.
   *
   * @return Work allocation rule set details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ReadWorkAllocationRuleSetDtls readWorkAllocationRuleSet(
    RuleSetIDStruct key) throws AppException, InformationalException {

    final ReadWorkAllocationRuleSetDtls result = new ReadWorkAllocationRuleSetDtls();
    final GenericRuleSet e = Editor.getGenericRuleSet(key.ruleSetID);

    result.comments = e.getComment();
    result.failureText = e.getFailureText();
    result.ruleSetName = e.getName();
    result.successText = e.getSuccessText();
    result.versionNo = e.getRuleSetVersion();
    result.nodeID = 0;
    result.ruleSetID = key.ruleSetID;

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Validates a rule set.
   *
   * @param key Key to validate a rule set.
   *
   * @return Valid rule set list.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ValidateRuleSetDtlsList validateRuleSet(RuleSetIDStruct key)
    throws AppException, InformationalException {

    final ValidateRuleSetDtlsList result = new ValidateRuleSetDtlsList();
    final ValidationInformation vals[] = Editor.validateRuleSet(key.ruleSetID);

    for (int i = 0; i < vals.length; i++) {

      final ValidationInformation val = vals[i];

      final ValidateRuleSetDtls item = new ValidateRuleSetDtls();

      item.nodeID = val.getNodeID();
      item.nodeName = val.getNodeName();
      item.nodeType = val.getNodeType();
      item.problemText = val.getMessage();

      result.dtls.addRef(item);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Views a rule tree.
   *
   * @param key Key to view a rule tree.
   *
   * @return Rule tree details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleTreeResultDtls viewRuleTree(RuleSetIDStruct key)
    throws AppException, InformationalException {

    final RuleTreeResultDtls result = new RuleTreeResultDtls();

    result.resultText = Editor.getTreeViewInformation(key.ruleSetID);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Common functionality for copying rule children from rule set to standard
   * output struct which contains these.
   */
  protected void copyRuleChildren(RuleChild children[],
    ChildItemNodeList copyTo) {

    for (int i = 0; i < children.length; i++) {

      final RuleChild child = children[i];

      if (child != null) {

        final ChildItemListDetails childItemListDetails = new ChildItemListDetails();

        childItemListDetails.nodeID = child.getNodeID();
        childItemListDetails.nodeName = child.getDisplayName();
        childItemListDetails.nodeType = child.getType();

        copyTo.nodeDetails.addRef(childItemListDetails);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Writes rules information.
   *
   * @param creoleRuleSetID Rule set identifier
   * @param ruleSetName Name of the rule set
   * @param comments Comments
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  protected void writeRulesInformation(String ruleSetId, String ruleSetName,
    String comments) throws AppException, InformationalException {//
  }

  // ___________________________________________________________________________
  /**
   * Reads the rules information identifier.
   *
   * @param creoleRuleSetID Rule set identifier.
   * @throws InformationalException If error occurs.
   *
   * @throws AppException If error occurs.
   */
  protected long getRulesInformationID(String ruleSetId) throws AppException,
      InformationalException {

    final long l = 200;

    return l;
  }

  // ___________________________________________________________________________
  /**
   * Hash table used for translating common codes from their
   * "front end" representation to the format required by the
   * rules editor. Codes shorter than 10 characters do not
   * need translation since the codetable values used are
   * appropriate for direct use with the editor. The keys in the list
   * of key values below MUST be unique. The values in the list
   * of values must ALSO be unique since a reverse translation is
   * also done.
   */
  static java.util.Hashtable<String, String> codeHash = new java.util.Hashtable<String, String>();

  static java.util.Hashtable<String, String> codeUnhash = new java.util.Hashtable<String, String>();
  static {
    // BEGIN, CR00052324, AK
    codeHash.put(RulesEditorConst.kExecall, RulesEditorConst.kExecuteall);
    codeHash.put(RulesEditorConst.kStoponres, RulesEditorConst.kStoponresult);
    codeHash.put(RulesEditorConst.kQsingle, RulesEditorConst.kQuerysingleitem);
    codeHash.put(RulesEditorConst.kQall, RulesEditorConst.kQueryallitems);
    codeHash.put(RulesEditorConst.kSucall, RulesEditorConst.kSucceedall);
    codeHash.put(RulesEditorConst.kSucone, RulesEditorConst.kSucceedone);
    codeHash.put(RulesEditorConst.kSucallstop, RulesEditorConst.kSucceedallstop);
    codeHash.put(RulesEditorConst.kSuconestop, RulesEditorConst.kSucceedonestop);
    codeHash.put(RulesEditorConst.kHighval, RulesEditorConst.kHighestvalue);
    codeHash.put(RulesEditorConst.kHighpri, RulesEditorConst.kHighestpriority);
    codeHash.put(RulesEditorConst.kEmptString, RulesEditorConst.kEmptyString);
    // END, CR00052324
  }

  static {

    // Produce the reverse hash
    final java.util.Iterator i = codeHash.keySet().iterator();

    while (i.hasNext()) {
      final String key = (String) i.next();

      codeUnhash.put(codeHash.get(key), key);
    }
  }

  static String codeIn(String code) {

    // return translation if there is one, otherwise return original code
    final String result = codeHash.get(code);

    if (result == null) {
      return code;
    } else {
      return result;
    }
  }

  static String codeOut(String code) {

    // return translation if there is one, otherwise return original code
    final String result = codeUnhash.get(code);

    if (result == null) {
      return code;
    } else {
      return result;
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads work allocation rule set summary details.
   *
   * @param key Key to read work allocation rule set summary details.
   *
   * return Work allocation rule set summary details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public WorkAllocationRuleSetSummaryDtls readWorkAllocationRuleSetSummary(
    RuleSetIDStruct key) throws AppException, InformationalException {

    final WorkAllocationRuleSetSummaryDtls result = new WorkAllocationRuleSetSummaryDtls();

    result.workAllocRuleSetDtls = readWorkAllocationRuleSet(key);

    final GenericRuleSet e = Editor.getGenericRuleSet(key.ruleSetID);

    copyRuleChildren(e.getChildren(), result.childDtls);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation objective.
   *
   * @param dtls Details to create a work allocation objective.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createWorkAllocationObjective(WorkAllocationObjective dtls)
    throws AppException, InformationalException {

    final NodeIDStruct obj = new NodeIDStruct();

    // First we create the objective
    obj.nodeID = Editor.createObjective(dtls.ruleSetID, dtls.versionNo,
      dtls.nodeID, false, // highlight ind defaulted to false
      // BEGIN, CR00052814, AK
      CuramConst.gkEmpty, // legislation ID not required
      dtls.comments, dtls.name, dtls.name, // Set the success text to the name
      dtls.name, // Set the failure text to the name
      false, // deduction allowed ind defaulted to false
      CuramConst.gkEmpty, // description not used in this context
      CuramConst.gkEmpty, // objective type code not required
      CuramConst.gkEmpty, // financialComponentType not required
      CuramConst.gkEmpty, // targetCode not required
      CuramConst.gkEmpty, // targetIdentifier not required
      // END, CR00052814
      dtls.priority, dtls.rulesObjectiveID, dtls.ruleID, dtls.relatedReference);

    // Have to delve into rules internals to get rule version
    final ExternalAccess access = RuleSetAccessFactory.createRuleSetAccess();
    final int versionNo = access.getRuleSet(dtls.ruleSetID).getVersionNo();

    // now we create the objective tag added to the objective
    final NodeIDStruct result = new NodeIDStruct();

    result.nodeID = Editor.createObjectiveTag(dtls.ruleSetID, versionNo,
      obj.nodeID,
      // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(
      curam.codetable.TARGETITEMTYPE.TABLENAME, dtls.typeCode,
      TransactionInfo.getProgramLocale()),
      // END, CR00163098, JC
      dtls.typeCode,
      dtls.value,
      // BEGIN, CR00052324, AK
      FrequencyPattern.kZeroFrequencyPattern.toString(),
      // END, CR00052324
      // BEGIN, CR00052814, AK
      CuramConst.gkEmpty// No comments
      // END, CR00052814
      );
  }

  // ___________________________________________________________________________
  /**
   * Reads rule set type details.
   *
   * @param key Key to read rule set type details.
   *
   * @return Rule set type details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RuleSetType readRuleSetType(RuleSetIDStruct key)
    throws AppException, InformationalException {

    final RuleSetType ruleSetType = new RuleSetType();

    final NodeIDAndType nodeIDAndType = Editor.getRuleSetTypeInformation(
      key.ruleSetID);

    ruleSetType.ruleSetType = nodeIDAndType.getType();

    return ruleSetType;
  }

  // ___________________________________________________________________________
  /**
   * Reads work allocation objective tag details.
   *
   * @param key Key to read work allocation objective tag details.
   *
   * @return Work allocation objective tag details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public WorkAllocationObjectiveTagDetails readWorkAllocationObjectiveTag(
    RuleSetNodeKey key) throws AppException, InformationalException {

    final WorkAllocationObjectiveTagDetails result = new WorkAllocationObjectiveTagDetails();

    final ObjectiveTag tag = Editor.getObjectiveTag(key.ruleSetID, key.nodeID);

    result.name = tag.getName();
    result.value = tag.getValue();
    result.typeCode = tag.getType();

    if (tag.getType().equals(curam.codetable.TARGETITEMTYPE.USER)) {

      // Users manipulation variables
      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      // Set key to read user name
      usersKey.userName = tag.getValue();

      // Read the user's full details
      // BEGIN, CR00017977, CD
      final UserFullname userFullname = userAccessObj.getFullName(usersKey);

      // END, CR00017977

      // Set full name in object
      result.description = userFullname.fullname;

    } else if (tag.getType().equals(curam.codetable.TARGETITEMTYPE.WORKQUEUE)) {

      // WorkQueue manipulation variables
      final curam.core.sl.entity.intf.WorkQueue workQueueObj = curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
      final WorkQueueKey workQueueKey = new WorkQueueKey();

      // Set key for read
      workQueueKey.workQueueID = Long.parseLong(tag.getValue());

      // Read work queue name
      final curam.core.sl.entity.struct.ReadWorkQueueDetails readWorkQueueDetails = workQueueObj.readWorkQueueDetails(
        workQueueKey);

      // Set full name in object
      result.description = readWorkQueueDetails.name;

    } else if (tag.getType().equals(curam.codetable.TARGETITEMTYPE.JOB)) {

      // Job manipulation variables
      final curam.core.sl.entity.intf.Job jobObj = curam.core.sl.entity.fact.JobFactory.newInstance();
      final curam.core.sl.entity.struct.JobKey jobKey = new curam.core.sl.entity.struct.JobKey();

      // Set key for read
      jobKey.jobID = Long.parseLong(tag.getValue());

      // Read work queue name
      final curam.core.sl.entity.struct.JobName jobName = jobObj.readJobName(
        jobKey);

      // Set full name in object
      result.description = jobName.name;

    } else if (tag.getType().equals(curam.codetable.TARGETITEMTYPE.ORGUNIT)) {

      // OrganizationUnit manipulation variables
      final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
      final curam.core.sl.entity.struct.OrganisationUnitKey organisationUnitKey = new curam.core.sl.entity.struct.OrganisationUnitKey();

      // Set key for read
      organisationUnitKey.organisationUnitID = Long.parseLong(tag.getValue());

      // Read work queue name
      final curam.core.sl.entity.struct.OrganisationUnitName organisationUnitName = organisationUnitObj.readOrgUnitName(
        organisationUnitKey);

      // Set full name in object
      result.description = organisationUnitName.name;

    } else if (tag.getType().equals(curam.codetable.TARGETITEMTYPE.POSITION)) {

      // Position manipulation variables
      final curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
      final curam.core.sl.entity.struct.PositionKey positionKey = new curam.core.sl.entity.struct.PositionKey();

      // Set key for read
      positionKey.positionID = Long.parseLong(tag.getValue());

      // Read work queue name
      final curam.core.sl.entity.struct.PositionName positionName = positionObj.readPositionName(
        positionKey);

      // Set full name in object
      result.description = positionName.name;
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation objective group.
   *
   * @param details Work allocation objective group details
   *
   * @return Node Identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createWAObjectiveGroup(WAObjectiveGroupDetails details)
    throws AppException, InformationalException {

    // Create return object
    NodeIDStruct NodeIDStruct;

    // ObjectiveGroupDetails object
    final ObjectiveGroupDetails objectiveGroupDetails = new ObjectiveGroupDetails();

    // Assign details to create objective group
    objectiveGroupDetails.assign(details);
    objectiveGroupDetails.successText = details.name;
    objectiveGroupDetails.failureText = details.name;

    // Call local facade method to create objective group
    NodeIDStruct = createObjectiveGroup(objectiveGroupDetails);

    return NodeIDStruct;
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation objective list group
   *
   * @param details Work allocation objective list group details
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createWAObjectiveListGroup(
    WAObjectiveListGroupDetails details) throws AppException,
      InformationalException {

    // Create return object
    NodeIDStruct NodeIDStruct;

    // ObjectiveListGroupDetails object
    final ObjectiveListGroupDetails objectiveListGroupDetails = new ObjectiveListGroupDetails();

    // Assign details to create objective list group
    objectiveListGroupDetails.assign(details);
    objectiveListGroupDetails.successText = details.name;
    objectiveListGroupDetails.failureText = details.name;

    // Call local facade method to create objective list group
    NodeIDStruct = createObjectiveListGroup(objectiveListGroupDetails);

    return NodeIDStruct;
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation rule.
   *
   * @param details Work allocation rule details
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createWARule(WARuleDetails details)
    throws AppException, InformationalException {

    // Create return object
    NodeIDStruct NodeIDStruct;

    // RuleDetails object
    final RuleDetails ruleDetails = new RuleDetails();

    // Assign details to create rule
    ruleDetails.assign(details);
    ruleDetails.successText = details.ruleName;
    ruleDetails.failureText = details.ruleName;
    ruleDetails.expressionText = details.expressionText;

    // Call local facade method to create rule
    NodeIDStruct = createRule(ruleDetails);

    return NodeIDStruct;
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation rule group.
   *
   * @param details Work allocation rule group details
   *
   * return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createWARuleGroup(WARuleGroupDetails details)
    throws AppException, InformationalException {

    // Create return object
    NodeIDStruct NodeIDStruct;

    // RuleGroupDetails object
    final RuleGroupDetails ruleGroupDetails = new RuleGroupDetails();

    // Assign details to create work allocation rule group
    ruleGroupDetails.assign(details);
    ruleGroupDetails.successText = details.name;
    ruleGroupDetails.failureText = details.name;

    // Call local facade method to create rule group
    NodeIDStruct = createRuleGroup(ruleGroupDetails);

    return NodeIDStruct;
  }

  // ___________________________________________________________________________
  /**
   * Creates a work allocation rule list group.
   *
   * @param details Work allocation list rule group details
   *
   * @return Node identifier
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public NodeIDStruct createWARuleListGroup(WARuleListGroupDetails details)
    throws AppException, InformationalException {

    // Create return object
    NodeIDStruct NodeIDStruct;

    // RulesListGroupDetails
    final RulesListGroupDetails rulesListGroupDetails = new RulesListGroupDetails();

    // Assign details to create rule list group
    rulesListGroupDetails.assign(details);
    rulesListGroupDetails.successText = details.name;
    rulesListGroupDetails.failureText = details.name;

    // Call local facade method to create rule list group
    NodeIDStruct = createRuleListGroup(rulesListGroupDetails);

    return NodeIDStruct;
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation objective details.
   *
   * @param details Modified work allocation objective details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWAObjective(WorkAllocationObjective details)
    throws AppException, InformationalException {

    final Objective objective = Editor.getObjective(details.ruleSetID,
      details.nodeID);

    // First we modify the objective
    // BEGIN, CR00052814, AK
    Editor.modifyObjective(details.ruleSetID, details.versionNo, details.nodeID,
      false, // highlight ind defaulted to false
      CuramConst.gkEmpty, // legislation ID not required
      details.comments, details.name, details.name, // Set the success text to the name
      details.name, // Set the failure text to the name
      false, // deduction allowed ind defaulted to false
      CuramConst.gkEmpty, // description not used in this context
      CuramConst.gkEmpty, // objective type code not required
      CuramConst.gkEmpty, // financialComponentType not required
      CuramConst.gkEmpty, // targetCode not required
      CuramConst.gkEmpty, // targetIdentifier not required
      // END, CR00052814
      details.priority, objective.getObjectiveRecordID(), details.ruleID,
      details.relatedReference);

    long nodeID = -1;

    final RuleChild children[] = objective.getChildren();

    for (int i = 0; i < children.length; i++) {
      if (children[i].getType().equals(kOtf)) {
        nodeID = children[i].getNodeID();
        break;
      }
    }

    final ExternalAccess access = RuleSetAccessFactory.createRuleSetAccess();
    final int versionNo = access.getRuleSet(details.ruleSetID).getVersionNo();

    Editor.modifyObjectiveTag(details.ruleSetID, versionNo, nodeID,
      // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(
      curam.codetable.TARGETITEMTYPE.TABLENAME, details.typeCode,
      TransactionInfo.getProgramLocale()),
      // END, CR00163098, JC
      details.typeCode,
      details.value,
      FrequencyPattern.kZeroFrequencyPattern.toString(),
      CuramConst.gkEmpty,
      UniqueID.nextUniqueID());
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation objective group details.
   *
   * @param details Modified work allocation objective group details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWAObjectiveGroup(WAObjectiveGroupDetails details)
    throws AppException, InformationalException {

    // ObjectiveGroupDetails object
    final ObjectiveGroupDetails objectiveGroupDetails = new ObjectiveGroupDetails();

    // Assign details to modify objective group
    objectiveGroupDetails.assign(details);
    objectiveGroupDetails.successText = details.name;
    objectiveGroupDetails.failureText = details.name;

    // Call local facade method to modify objective group
    modifyObjectiveGroup(objectiveGroupDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation objective list group details.
   *
   * @param details Modified work allocation objective list group details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWAObjectiveListGroup(WAObjectiveListGroupDetails details)
    throws AppException, InformationalException {

    // ObjectiveListGroupModifyDetails object
    final ObjectiveListGroupModifyDetails objectiveListGroupModifyDetails = new ObjectiveListGroupModifyDetails();

    // Assign details to modify objective list group
    objectiveListGroupModifyDetails.assign(details);
    objectiveListGroupModifyDetails.successText = details.name;
    objectiveListGroupModifyDetails.failureText = details.name;
    objectiveListGroupModifyDetails.dtls.nodeID = details.nodeID;
    objectiveListGroupModifyDetails.dtls.ruleSetID = details.ruleSetID;

    // Call local facade method to modify objective list group
    modifyObjectiveListGroup(objectiveListGroupModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation rule details.
   *
   * @param details Modified work allocation rule details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWARule(WARuleDetails details) throws AppException,
      InformationalException {

    // ruleModifyDetails object
    final RuleModifyDetails ruleModifyDetails = new RuleModifyDetails();

    // Assign details to modify work allocation rule
    ruleModifyDetails.assign(details);
    ruleModifyDetails.successText = details.ruleName;
    ruleModifyDetails.failureText = details.ruleName;
    ruleModifyDetails.expressionText = details.expressionText;

    // Call local facade method to modify work allocation rule
    modifyRule(ruleModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation rule group details.
   *
   * @param details Modified work allocation rule group details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWARuleGroup(WARuleGroupDetails details)
    throws AppException, InformationalException {

    // RuleGroupDetails object
    final RuleGroupDetails ruleGroupDetails = new RuleGroupDetails();

    // Assign details to modify work allocation rule group
    ruleGroupDetails.assign(details);
    ruleGroupDetails.successText = details.name;
    ruleGroupDetails.failureText = details.name;

    // Call local facade method to modify work allocation rule group
    modifyRuleGroup(ruleGroupDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation rule list group details
   *
   * @param details Modified work allocation rule list group details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWARuleListGroup(WARuleListGroupDetails details)
    throws AppException, InformationalException {

    // RulesListGroupDetails object
    final RulesListGroupDetails rulesListGroupDetails = new RulesListGroupDetails();

    // Assign details to modify work allocation rule list group
    rulesListGroupDetails.assign(details);
    rulesListGroupDetails.successText = details.name;
    rulesListGroupDetails.failureText = details.name;

    // Call local facade method to
    modifyRuleListGroup(rulesListGroupDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies work allocation rule set details
   *
   * @param details Modified work allocation rule set details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyWorkAllocationRuleSet(WorkAllocationRuleSetDtls details)
    throws AppException, InformationalException {

    Editor.modifyGenericRuleSet(details.ruleSetID, details.versionNo,
      details.ruleSetName, false, // Highlight not used
      // BEGIN, CR00052814, AK
      CuramConst.gkEmpty, // legislation base not used
      CuramConst.gkEmpty, // legislation link not used in this context
      // END, CR0052814
      details.comments, details.ruleSetName, details.ruleSetName);

  }

  // ___________________________________________________________________________
  /**
   * Reads work allocation rule set objective and tag details.
   *
   * @param key Key to read work allocation rule set objective and tag details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public WorkAllocationObjectiveAndTagDetails readWAObjectiveSummary(
    RuleSetNodeKey key) throws AppException, InformationalException {

    final WorkAllocationObjectiveAndTagDetails result = new WorkAllocationObjectiveAndTagDetails();

    result.summaryDetails = readObjectiveSummary(key);

    final Iterator detailsIter = result.summaryDetails.childItemDtls.childDtls.nodeDetails.iterator();

    ChildItemListDetails itemDetails = null;

    final RuleSetNodeKey objTagsNodeKey = new RuleSetNodeKey();

    while (detailsIter.hasNext()) {
      itemDetails = (ChildItemListDetails) detailsIter.next();
      if (itemDetails.nodeType.equals(kOtf)) {
        objTagsNodeKey.nodeID = itemDetails.nodeID;
        break;
      }
    }

    objTagsNodeKey.ruleSetID = key.ruleSetID;
    result.tagDetails = readWorkAllocationObjectiveTag(objTagsNodeKey);

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Reads work allocation rule set objective and tag details.
   *
   * @param key Key to read work allocation rule set objective and tag details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public WorkAllocationObjectiveAndTagDetails readWAObjectiveChildList(
    RuleSetNodeKey key) throws AppException, InformationalException {

    final WorkAllocationObjectiveAndTagDetails result = new WorkAllocationObjectiveAndTagDetails();

    result.summaryDetails.objectiveDtls = readObjective(key);

    final Objective obj = Editor.getObjective(key.ruleSetID, key.nodeID);

    final RuleChild children[] = obj.getChildren();

    for (int i = 0; i < children.length; i++) {

      final RuleChild child = children[i];

      final ChildItemListDetails dtls = new ChildItemListDetails();

      dtls.nodeID = child.getNodeID();
      dtls.nodeName = child.getDisplayName();
      dtls.nodeType = child.getType();

      if (!dtls.nodeType.equals(kOtf)) {
        result.summaryDetails.childItemDtls.childDtls.nodeDetails.addRef(dtls);
      }
    }
    return result;
  }

  // ___________________________________________________________________________
  /**
   * Get simulation meta data.
   *
   * @param key Key to retrieve the simulation meta data.
   *
   * @return Simulation meta data
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public GetSimulationMetaDataResult getSimulationMetaData(
    GetSimulationMetaDataKey key) throws AppException, InformationalException {

    // Create return object
    final GetSimulationMetaDataResult getSimulationMetaDataResult = new GetSimulationMetaDataResult();

    // Call API
    getSimulationMetaDataResult.result = Simulator.getSimulationMetaData(
      key.ruleSetID);

    return getSimulationMetaDataResult;
  }

  // ___________________________________________________________________________
  /**
   * Run the rules simulation and return the result of this
   *
   * @param input Input data to run the rules simulator.
   *
   * @return The result of rule simulation.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RunRulesSimulationResult runRulesSimulation(RunRulesSimulation input) throws AppException,
      InformationalException {

    // Create return object
    final RunRulesSimulationResult runRulesSimulationResult = new RunRulesSimulationResult();

    // Rules formatting manipulation variables
    curam.core.impl.RulesObjectiveResultList rulesObjectiveList = new curam.core.impl.RulesObjectiveResultList();
    curam.core.impl.RulesTagResultList rulesTagList = new curam.core.impl.RulesTagResultList();
    RulesResultItem rulesResultItem;
    curam.util.rules.RulesResult rulesResult;

    final EvaluateClaimResults evaluateClaimResults = new EvaluateClaimResults();
    curam.util.type.Money tempValue = curam.util.type.Money.kZeroMoney;

    EvidenceList evidenceList = Simulator.convertDataToEvidenceList(
      input.inputData);

    // Invoke the Rules Engine with the converted evidence
    rulesResult = Interrule.executeDynamicRules(input.ruleSetID, evidenceList,
      curam.util.rules.RulesEngine.kSimulation, null);

    // Set initial rules data in return object

    evidenceList = EvidenceTextDecoder.getEvidenceList(input.ruleSetID,
      rulesResult.getCompressedTextOfEvidenceUsed());

    final ResultBuffer resultBuffer = ResultTextDecoder.decode(input.ruleSetID,
      rulesResult.getFlowBits(), rulesResult.getResultBits(), evidenceList,
      curam.util.rules.RulesEngine.kSimulation);

    runRulesSimulationResult.result.evaluateClaimResults.resultText = resultBuffer.getResultAsXML();

    runRulesSimulationResult.result.evaluateClaimResults.decision = rulesResult.getDecision();

    rulesObjectiveList = new curam.core.impl.RulesObjectiveResultList(
      rulesResult.getRulesObjectiveResultList());
    rulesTagList = new curam.core.impl.RulesTagResultList(
      rulesResult.getTagResultList());

    RulesObjectiveResult rulesObjectiveResult;
    TagResult tagResult;

    // Compose rules output list
    for (int i = 0; i < rulesObjectiveList.size(); i++) {

      // BEGIN, CR00135603, SK
      // convert value from string to money
      tempValue = FixedNumericFormatConversion.convertEnglishFormatToMoney(
        rulesObjectiveList.item(i).getValue().toString());
      // END, CR00135603

      // process objective information if non zero
      if (!tempValue.isZero()) {

        rulesResultItem = new RulesResultItem();

        rulesObjectiveResult = Interrule.getDynamicObjective(input.ruleSetID,
          rulesObjectiveList.item(i).getObjectiveID());

        // BEGIN, CR00163098, JC
        // Copy rulesResultItem to return list
        rulesResultItem.name = CodeTable.getOneItem(
          RULESCOMPONENTTYPE.TABLENAME, rulesObjectiveResult.getType(),
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        rulesResultItem.value = rulesObjectiveResult.getValue();
        rulesResultItem.type = curam.codetable.RULESTAGTYPE.MONEY;

        // Add objective to list.
        evaluateClaimResults.dtls.dtls.addRef(rulesResultItem);

        tempValue = new curam.util.type.Money(rulesResultItem.value);

        // Add value to total value.
        evaluateClaimResults.componentTotalValue = new curam.util.type.Money(
          evaluateClaimResults.componentTotalValue.getValue()
            + tempValue.getValue());
      }
    }

    for (int j = 0; j < rulesTagList.size(); j++) {

      // process tag information only if product or assessment
      if (rulesTagList.item(j).getType().equals(RULESTAGTYPE.PRODUCTDELIVERY)
        || rulesTagList.item(j).getType().equals(RULESTAGTYPE.ASSESSMENT)) {

        rulesResultItem = new RulesResultItem();

        tagResult = Interrule.getDynamicTag(input.ruleSetID,
          rulesTagList.item(j).getTagID());

        rulesResultItem.name = tagResult.getDescription();
        rulesResultItem.type = tagResult.getType();

        // get value depending on type
        if (tagResult.getType().equals(RULESTAGTYPE.ASSESSMENT)) {
          // BEGIN, CR00163098, JC
          rulesResultItem.value = CodeTable.getOneItem(ASSESSMENTNAME.TABLENAME,
            tagResult.getValue(), TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

        } else {

          if (tagResult.getType().equals(RULESTAGTYPE.PRODUCTDELIVERY)) {
            // BEGIN, CR00163098, JC
            rulesResultItem.value = CodeTable.getOneItem(PRODUCTNAME.TABLENAME,
              tagResult.getValue(), TransactionInfo.getProgramLocale());
            // END, CR00163098, JC
          }
        }

        // Add tag to list
        evaluateClaimResults.dtls.dtls.addRef(rulesResultItem);
      }

    }

    // Set formatted data in return object
    runRulesSimulationResult.result.evaluateClaimResults.dtls.dtls.addAll(
      evaluateClaimResults.dtls.dtls);
    runRulesSimulationResult.result.evaluateClaimResults.componentTotalValue = evaluateClaimResults.componentTotalValue;

    return runRulesSimulationResult;
  }

  // ___________________________________________________________________________
  /**
   * Clones an existing rules simulation.
   *
   * @param key Key to clone an existing rules simulation.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public CloneRulesSimulationResult cloneRulesSimulation(
    CloneRulesSimulationKey key) throws AppException, InformationalException {

    // Create return object
    final CloneRulesSimulationResult cloneRulesSimulationResult = new CloneRulesSimulationResult();

    // RulesSimulation business object
    final curam.core.sl.intf.RulesSimulation rulesSimulationObj = curam.core.sl.fact.RulesSimulationFactory.newInstance();

    // Call business operation to clone rules simulation
    cloneRulesSimulationResult.result = rulesSimulationObj.cloneRulesSimulation(
      key.key);

    return cloneRulesSimulationResult;
  }

  // ___________________________________________________________________________
  /**
   * Run a saved rules simulation.
   *
   * @param key Key to run a saved Rules Simulation.
   *
   * @return Results of running a saved Rules Simulation.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RunRulesSimulationResult runSavedRulesSimulation(
    RunSavedRulesSimulationKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00070778, "PA"
    // Create return object
    final RunRulesSimulationResult runRulesSimulationResult = new RunRulesSimulationResult();

    // RulesSimulation entity object
    final curam.core.sl.entity.intf.RulesSimulation rulesSimulationObj = curam.core.sl.entity.fact.RulesSimulationFactory.newInstance();
    final RulesSimulationKey rulesSimulationKey = new RulesSimulationKey();
    RulesSimulationDtls rulesSimulationDtls;

    // Rules formatting manipulation variables
    curam.core.impl.RulesObjectiveResultList rulesObjectiveList = new curam.core.impl.RulesObjectiveResultList();
    curam.core.impl.RulesTagResultList rulesTagList = new curam.core.impl.RulesTagResultList();
    RulesResultItem rulesResultItem;
    curam.util.rules.RulesResult rulesResult;

    final EvaluateClaimResults evaluateClaimResults = new EvaluateClaimResults();
    curam.util.type.Money tempValue = curam.util.type.Money.kZeroMoney;

    // Set key to read rulesSimulation
    rulesSimulationKey.rulesSimulationID = key.rulesSimulationID;

    // Read rules simulation
    rulesSimulationDtls = rulesSimulationObj.read(rulesSimulationKey);

    // Invoke the Rules Engine with the converted evidence
    EvidenceList evidenceList = Simulator.convertDataToEvidenceList(
      rulesSimulationDtls.simulationData);

    try {
      rulesResult = Interrule.executeDynamicRules(rulesSimulationDtls.ruleSetID,
        evidenceList, curam.util.rules.RulesEngine.kSimulation, null);

    } catch (final AppRuntimeException e) {
      // Begin CR00049853 LP
      if (INFRASTRUCTURE.RUN_ID_RUNTIME.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_RUN_ID_DATAITEM_FINAL);
      }
      // End CR00049853 LP
      if (INFRASTRUCTURE.RUN_ID_DATE_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_DATEFORMAT);
      }
      if (INFRASTRUCTURE.RUN_ID_DATETIME_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_DATETIMEFORMAT);
      }
      if (INFRASTRUCTURE.RUN_ID_FREQUENCY_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_FREQUENCYPATTERN);
      }
      if (INFRASTRUCTURE.RUN_ID_BOOLEAN_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_BOOLEAN);
      }
      if (INFRASTRUCTURE.RUN_ID_NUMBER_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_NUMBER);
      }
      if (INFRASTRUCTURE.RUN_ID_MONEY_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_MONEY);
      }
      throw e;
    } catch (final NullPointerException npe) {
      throw new AppException(
        BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_NOVALUE);
    }

    // Set initial rules data in return object

    evidenceList = EvidenceTextDecoder.getEvidenceList(
      rulesSimulationDtls.ruleSetID,
      rulesResult.getCompressedTextOfEvidenceUsed());

    final ResultBuffer resultBuffer = ResultTextDecoder.decode(
      rulesSimulationDtls.ruleSetID, rulesResult.getFlowBits(),
      rulesResult.getResultBits(), evidenceList,
      curam.util.rules.RulesEngine.kSimulation);

    runRulesSimulationResult.result.evaluateClaimResults.resultText = resultBuffer.getResultAsXML();

    runRulesSimulationResult.result.evaluateClaimResults.decision = rulesResult.getDecision();

    rulesObjectiveList = new curam.core.impl.RulesObjectiveResultList(
      rulesResult.getRulesObjectiveResultList());
    rulesTagList = new curam.core.impl.RulesTagResultList(
      rulesResult.getTagResultList());

    RulesObjectiveResult rulesObjectiveResult;
    TagResult tagResult;

    // Compose rules output list
    for (int i = 0; i < rulesObjectiveList.size(); i++) {

      // BEGIN, CR00123018, SK
      // convert value from string to money
      tempValue = FixedNumericFormatConversion.convertEnglishFormatToMoney(
        rulesObjectiveList.item(i).getValue().toString());
      // END, CR00123018

      // process objective information if non zero
      if (!tempValue.isZero()) {

        rulesResultItem = new RulesResultItem();

        rulesObjectiveResult = Interrule.getDynamicObjective(
          rulesSimulationDtls.ruleSetID,
          rulesObjectiveList.item(i).getObjectiveID());

        // BEGIN, CR00163098, JC
        // Copy rulesResultItem to return list
        rulesResultItem.name = CodeTable.getOneItem(
          RULESCOMPONENTTYPE.TABLENAME, rulesObjectiveResult.getType(),
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        rulesResultItem.value = rulesObjectiveList.item(i).getValue();
        rulesResultItem.type = curam.codetable.RULESTAGTYPE.MONEY;

        // Add objective to list.
        evaluateClaimResults.dtls.dtls.addRef(rulesResultItem);

        tempValue = new curam.util.type.Money(rulesResultItem.value);

        // Add value to total value.
        evaluateClaimResults.componentTotalValue = new curam.util.type.Money(
          evaluateClaimResults.componentTotalValue.getValue()
            + tempValue.getValue());
      }
    }

    for (int j = 0; j < rulesTagList.size(); j++) {

      // process tag information only if product or assessment
      if (rulesTagList.item(j).getType().equals(RULESTAGTYPE.PRODUCTDELIVERY)
        || rulesTagList.item(j).getType().equals(RULESTAGTYPE.ASSESSMENT)) {

        rulesResultItem = new RulesResultItem();

        tagResult = Interrule.getDynamicTag(rulesSimulationDtls.ruleSetID,
          rulesTagList.item(j).getTagID());

        rulesResultItem.name = tagResult.getDescription();
        rulesResultItem.type = tagResult.getType();

        // get value depending on type
        if (tagResult.getType().equals(RULESTAGTYPE.ASSESSMENT)) {
          // BEGIN, CR00163098, JC
          rulesResultItem.value = CodeTable.getOneItem(ASSESSMENTNAME.TABLENAME,
            tagResult.getValue(), TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

        } else {

          if (tagResult.getType().equals(RULESTAGTYPE.PRODUCTDELIVERY)) {
            // BEGIN, CR00163098, JC
            rulesResultItem.value = CodeTable.getOneItem(PRODUCTNAME.TABLENAME,
              tagResult.getValue(), TransactionInfo.getProgramLocale());
            // END, CR00163098, JC
          }
        }

        // Add tag to list
        evaluateClaimResults.dtls.dtls.addRef(rulesResultItem);
      }

    }

    // Set formatted data in return object
    runRulesSimulationResult.result.evaluateClaimResults.dtls.dtls.addAll(
      evaluateClaimResults.dtls.dtls);
    runRulesSimulationResult.result.evaluateClaimResults.componentTotalValue = evaluateClaimResults.componentTotalValue;
    // END, CR00070778
    return runRulesSimulationResult;

  }

  // ___________________________________________________________________________
  /**
   * Run an unsaved rules simulation.
   *
   * @param key Key to run an unsaved Rules Simulation.
   *
   * @return Results of running a saved Rules Simulation.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public RunRulesSimulationResult runUnsavedRulesSimulation(
    RunUnsavedRulesSimulationKey key) throws AppException,
      InformationalException {

    // Create return object
    final RunRulesSimulationResult runRulesSimulationResult = new RunRulesSimulationResult();

    // Rules formatting manipulation variables
    curam.core.impl.RulesObjectiveResultList rulesObjectiveList = new curam.core.impl.RulesObjectiveResultList();
    curam.core.impl.RulesTagResultList rulesTagList = new curam.core.impl.RulesTagResultList();
    RulesResultItem rulesResultItem;
    curam.util.rules.RulesResult rulesResult;

    final EvaluateClaimResults evaluateClaimResults = new EvaluateClaimResults();
    curam.util.type.Money tempValue = curam.util.type.Money.kZeroMoney;

    EvidenceList evidenceList = Simulator.convertDataToEvidenceList(
      key.simulationData);

    try {
      // Invoke the Rules Engine with the converted evidence
      rulesResult = Interrule.executeDynamicRules(key.ruleSetID, evidenceList,
        curam.util.rules.RulesEngine.kSimulation, null);

    } catch (final AppRuntimeException e) {

      if (INFRASTRUCTURE.RUN_ID_DATE_CONVERSION.equals(
        e.getAppException().getCatEntry())) {

        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_DATEFORMAT);
      }
      if (INFRASTRUCTURE.RUN_ID_DATETIME_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_DATETIMEFORMAT);
      }
      if (INFRASTRUCTURE.RUN_ID_FREQUENCY_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_FREQUENCYPATTERN);
      }
      if (INFRASTRUCTURE.RUN_ID_BOOLEAN_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_BOOLEAN);
      }
      if (INFRASTRUCTURE.RUN_ID_NUMBER_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_NUMBER);
      }
      if (INFRASTRUCTURE.RUN_ID_MONEY_CONVERSION.equals(
        e.getAppException().getCatEntry())) {
        throw new AppException(
          BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_INCORRECT_MONEY);
      }
      throw e;
    } catch (final NullPointerException npe) {
      throw new AppException(
        BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_SIMULATION_WITH_NOVALUE);
    }

    // Set initial rules data in return object
    evidenceList = EvidenceTextDecoder.getEvidenceList(key.ruleSetID,
      rulesResult.getCompressedTextOfEvidenceUsed());

    // Set initial rules data in return object
    evidenceList = EvidenceTextDecoder.getEvidenceList(key.ruleSetID,
      rulesResult.getCompressedTextOfEvidenceUsed());

    final ResultBuffer resultBuffer = ResultTextDecoder.decode(key.ruleSetID,
      rulesResult.getFlowBits(), rulesResult.getResultBits(), evidenceList,
      curam.util.rules.RulesEngine.kSimulation);

    runRulesSimulationResult.result.evaluateClaimResults.resultText = resultBuffer.getResultAsXML();

    runRulesSimulationResult.result.evaluateClaimResults.decision = rulesResult.getDecision();

    rulesObjectiveList = new curam.core.impl.RulesObjectiveResultList(
      rulesResult.getRulesObjectiveResultList());
    rulesTagList = new curam.core.impl.RulesTagResultList(
      rulesResult.getTagResultList());

    RulesObjectiveResult rulesObjectiveResult;
    TagResult tagResult;

    // Compose rules output list
    for (int i = 0; i < rulesObjectiveList.size(); i++) {

      // BEGIN, CR00123018, SK
      // convert value from string to money
      tempValue = FixedNumericFormatConversion.convertEnglishFormatToMoney(
        rulesObjectiveList.item(i).getValue().toString());
      // END, CR00123018

      // process objective information if non zero
      if (!tempValue.isZero()) {

        rulesResultItem = new RulesResultItem();

        rulesObjectiveResult = Interrule.getDynamicObjective(key.ruleSetID,
          rulesObjectiveList.item(i).getObjectiveID());

        // BEGIN, CR00163098, JC
        // Copy rulesResultItem to return list
        rulesResultItem.name = CodeTable.getOneItem(
          RULESCOMPONENTTYPE.TABLENAME, rulesObjectiveResult.getType(),
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        rulesResultItem.value = rulesObjectiveResult.getValue();
        rulesResultItem.type = curam.codetable.RULESTAGTYPE.MONEY; //

        // Add objective to list.
        evaluateClaimResults.dtls.dtls.addRef(rulesResultItem);

        tempValue = new curam.util.type.Money(rulesResultItem.value);

        // Add value to total value.
        evaluateClaimResults.componentTotalValue = new curam.util.type.Money(
          evaluateClaimResults.componentTotalValue.getValue()
            + tempValue.getValue());
      }
    }

    for (int j = 0; j < rulesTagList.size(); j++) {

      // process tag information only if product or assessment
      if (rulesTagList.item(j).getType().equals(RULESTAGTYPE.PRODUCTDELIVERY)
        || rulesTagList.item(j).getType().equals(RULESTAGTYPE.ASSESSMENT)) {

        rulesResultItem = new RulesResultItem();

        tagResult = Interrule.getDynamicTag(key.ruleSetID,
          rulesTagList.item(j).getTagID());

        rulesResultItem.name = tagResult.getDescription();
        rulesResultItem.type = tagResult.getType();

        // get value depending on type
        if (tagResult.getType().equals(RULESTAGTYPE.ASSESSMENT)) {
          // BEGIN, CR00163098, JC
          rulesResultItem.value = CodeTable.getOneItem(ASSESSMENTNAME.TABLENAME,
            tagResult.getValue(), TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

        } else {

          if (tagResult.getType().equals(RULESTAGTYPE.PRODUCTDELIVERY)) {
            // BEGIN, CR00163098, JC
            rulesResultItem.value = CodeTable.getOneItem(PRODUCTNAME.TABLENAME,
              tagResult.getValue(), TransactionInfo.getProgramLocale());
            // END, CR00163098, JC
          }
        }

        // Add tag to list
        evaluateClaimResults.dtls.dtls.addRef(rulesResultItem);
      }

    }

    // Set formatted data in return object
    runRulesSimulationResult.result.evaluateClaimResults.dtls.dtls.addAll(
      evaluateClaimResults.dtls.dtls);
    runRulesSimulationResult.result.evaluateClaimResults.componentTotalValue = evaluateClaimResults.componentTotalValue;

    return runRulesSimulationResult;
  }

  // ___________________________________________________________________________
  /**
   * Creates a rules simulation.
   *
   * @param details Rules Simulation details.
   *
   * @return CreateRulesSimulationResult Identifier of the rules simulation
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public CreateRulesSimulationResult createRulesSimulation(
    CreateRulesSimulationDetails details) throws AppException,
      InformationalException {

    // Create return object
    final CreateRulesSimulationResult createRulesSimulationResult = new CreateRulesSimulationResult();

    // RulesSimulation business object
    final curam.core.sl.intf.RulesSimulation rulesSimulationObj = curam.core.sl.fact.RulesSimulationFactory.newInstance();

    // Call business operation to create Rules Simulation
    rulesSimulationObj.createRulesSimulation(details.details);

    // Set identifier in return object
    createRulesSimulationResult.result.rulesSimulationID = details.details.dtls.rulesSimulationID;

    return createRulesSimulationResult;
  }

  // ___________________________________________________________________________
  /**
   * Deletes a rules simulation.
   *
   * @param key Key to delete the rules simulation.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteRulesSimulation(DeleteRulesSimulationKey key)
    throws AppException, InformationalException {

    // RulesSimulation business object
    final curam.core.sl.intf.RulesSimulation rulesSimulationObj = curam.core.sl.fact.RulesSimulationFactory.newInstance();

    // Call business operation to delete Rules Simulation
    rulesSimulationObj.deleteRulesSimulation(key.key);
  }

  // ___________________________________________________________________________
  /**
   * Modifies rules simulation details.
   *
   * @param details Modifies rules simulation details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyRulesSimulation(ModifyRulesSimulationDetails details)
    throws AppException, InformationalException {

    // RulesSimulation business object
    final curam.core.sl.intf.RulesSimulation rulesSimulationObj = curam.core.sl.fact.RulesSimulationFactory.newInstance();

    // Call business operation to modify Rules Simulation
    rulesSimulationObj.modifyRulesSimulation(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Reads rules simulation details.
   *
   * @param key Key to read rules simulation details.
   *
   * @return ReadRulesSimulationDetails Rules simulation details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ReadRulesSimulationDetails readRulesSimulation(
    ReadRulesSimulationKey key) throws AppException, InformationalException {

    // Create return object
    final ReadRulesSimulationDetails readRulesSimulationDetails = new ReadRulesSimulationDetails();

    // RulesSimulation business object
    final curam.core.sl.intf.RulesSimulation rulesSimulationObj = curam.core.sl.fact.RulesSimulationFactory.newInstance();

    // Call entity operation to run rules simulation
    readRulesSimulationDetails.details = rulesSimulationObj.readRulesSimulation(
      key.key);

    return readRulesSimulationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of rules simulations.
   *
   * @param key Key to return list of rules simulations.
   *
   * @return ListRulesSimulationResult List of rules simulations details
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ListRulesSimulationResult listRulesSimulation(
    ListRulesSimulationKey key) throws AppException, InformationalException {

    // Create return object
    final ListRulesSimulationResult listRulesSimulationResult = new ListRulesSimulationResult();

    // RulesSimulation business object
    final curam.core.sl.intf.RulesSimulation rulesSimulationObj = curam.core.sl.fact.RulesSimulationFactory.newInstance();

    // Call business process to return list of rules simulations
    listRulesSimulationResult.result = rulesSimulationObj.list(key.key);

    return listRulesSimulationResult;
  }

  // ___________________________________________________________________________
  /**
   * Checks the setting of the rule set environment variable.
   *
   * @return Rule set environment setting
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  protected RuleSetEnvSetting checkEnvironmentSetting() throws AppException,
      InformationalException {

    // Create return object
    final RuleSetEnvSetting ruleSetEnvSetting = new RuleSetEnvSetting();

    // Need to check the environment setting to see if the system
    // is live
    ruleSetEnvSetting.ruleSetLiveStr = Configuration.getProperty(
      EnvVars.ENV_RULE_SETS_LIVE);

    if (ruleSetEnvSetting.ruleSetLiveStr == null) {

      ruleSetEnvSetting.ruleSetLiveStr = EnvVars.ENV_RULE_SETS_LIVE_DEFAULT;
    }

    return ruleSetEnvSetting;
  }

  // ___________________________________________________________________________
  /**
   * Publishes rule set changes.
   *
   * @param key Contains ruleSetID to publish changes.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void publish(PublishKey key) throws AppException,
      InformationalException {

    final curam.util.administration.intf.CacheAdmin cacheAdminObj = curam.util.administration.fact.CacheAdminFactory.newInstance();

    // BEGIN, CR00023363, KY
    // RuleSet Node key
    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // END, CR00023363

    cacheAdminObj.removeRuleSetFromCache(key.ruleSetID);

    // BEGIN, CR00023363, KY
    // make rule set node as selection node
    ruleSetNodeKey.nodeID = 0;
    ruleSetNodeKey.ruleSetID = key.ruleSetID;
    postUpdate(ruleSetNodeKey);
    // END, CR00023363
  }

  // ___________________________________________________________________________
  /**
   * This method creates translation record for a rule component.
   *
   * @param details contains translation details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void createTranslation(TranslationDetails details)
    throws AppException, InformationalException {

    int versionNo;

    final ReadRuleNameKey readRuleNameKey = new ReadRuleNameKey();

    readRuleNameKey.languageCode = details.languageCode;
    readRuleNameKey.nodeID = details.nodeID;
    readRuleNameKey.ruleSetID = details.ruleSetID;

    validateTranslation(readRuleNameKey);

    versionNo = RuleSetAccessFactory.createRuleSetAccess().getVersionNo(
      details.ruleSetID);

    Editor.addOrModifyTranslation(details.ruleSetID, versionNo, details.nodeID,
      details.languageCode, details.ruleName, details.successText,
      details.failureText);

    // BEGIN, CR00051866, "PA"

    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    if (details.ruleSetID != null && details.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = details.nodeID;
      ruleSetNodeKey.ruleSetID = details.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }
    // END, CR00051866
  }

  // ___________________________________________________________________________
  /**
   * This method deletes translation for a rule component.
   *
   * @param details identifies the translation record to be deleted.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void deleteTranslation(DeleteTranslationKey details)
    throws AppException, InformationalException {

    ReadTranslationDetails readTranslationDetails = new ReadTranslationDetails();

    final ReadTranslationKey readTranslationKey = new ReadTranslationKey();

    readTranslationKey.languageCode = details.languageCode;
    readTranslationKey.nodeID = details.nodeID;
    readTranslationKey.ruleSetID = details.ruleSetID;

    readTranslationDetails = readTranslation(readTranslationKey);

    Editor.deleteTranslation(details.ruleSetID,
      readTranslationDetails.versionNo, details.nodeID, details.languageCode);

  }

  // ___________________________________________________________________________
  /**
   * Lists translation for a rule component.
   *
   * @param details identifies a rule node. This contains RuleSetID and NodeID
   * details.
   *
   * @return translation details list.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public TranslationDetailsList listTranslation(RuleSetNodeKey details)
    throws AppException, InformationalException {

    final TranslationDetailsList translationDetailsList = new TranslationDetailsList();
    TranslationListDetails translationListDetails;
    List list = new ArrayList();

    final LocaleList localeList = Editor.listTranslationLocales(
      details.ruleSetID, details.nodeID);

    list = localeList.getLocaleList();

    final Iterator iter = list.iterator();

    while (iter.hasNext()) {
      translationListDetails = new TranslationListDetails();
      translationListDetails.languageCode = iter.next().toString();
      translationDetailsList.translationDtls.addRef(translationListDetails);
    }

    return translationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method modifies translation for a rule component.
   *
   * @param dtls contains translation details.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public void modifyTranslation(TranslationDetails dtls) throws AppException,
      InformationalException {

    final ReadRuleNameKey readRuleNameKey = new ReadRuleNameKey();

    readRuleNameKey.languageCode = dtls.languageCode;
    readRuleNameKey.nodeID = dtls.nodeID;
    readRuleNameKey.ruleSetID = dtls.ruleSetID;

    // validateTranslation(readRuleNameKey);

    ReadTranslationDetails readTranslationDetails = new ReadTranslationDetails();

    final ReadTranslationKey readTranslationKey = new ReadTranslationKey();

    readTranslationKey.languageCode = dtls.languageCode;
    readTranslationKey.nodeID = dtls.nodeID;
    readTranslationKey.ruleSetID = dtls.ruleSetID;

    readTranslationDetails = readTranslation(readTranslationKey);

    Editor.addOrModifyTranslation(dtls.ruleSetID,
      readTranslationDetails.versionNo, dtls.nodeID, dtls.languageCode,
      dtls.ruleName, dtls.successText, dtls.failureText);

    // BEGIN, CR00051866, "PA"

    final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    if (dtls.ruleSetID != null && dtls.ruleSetID.length() > 0) {
      ruleSetNodeKey.nodeID = dtls.nodeID;
      ruleSetNodeKey.ruleSetID = dtls.ruleSetID;
      postUpdate(ruleSetNodeKey);
    }
    // END, CR00051866

  }

  // ___________________________________________________________________________
  /**
   * Read translation for a rule component.
   *
   * @param details contains translation details.
   * @return translation details for a rule component.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ReadTranslationDetails readTranslation(ReadTranslationKey details)
    throws AppException, InformationalException {

    final ReadTranslationDetails readTranslationDetails = new ReadTranslationDetails();
    final Translation translation = Editor.readTranslation(details.ruleSetID,
      details.nodeID, details.languageCode);

    readTranslationDetails.ruleName = translation.getRuleName();

    readTranslationDetails.successText = translation.getSuccessText();

    readTranslationDetails.failureText = translation.getFailureText();

    readTranslationDetails.languageCode = translation.getLocale();

    readTranslationDetails.versionNo = translation.getRuleSetVersion();

    return readTranslationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validates translation for a particular node and language.
   *
   * @param readTextKey Identifies the rule component. Contains RuleSetID and
   * LanguageCode Details.
   * @throws InformationalException If error occurs.
   *
   * @throws AppException If error occurs.
   */
  @Override
  public void validateTranslation(ReadRuleNameKey readTextKey)
    throws AppException, InformationalException {

    // InformationalManager variable
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    AppException appException = null;
    String nodeType = null;

    final String languageCodeDescription = readCodeTableItemDescription(
      readTextKey.languageCode, LOCALE.TABLENAME);

    try {

      TranslationDetailsList translationDetailsList = new TranslationDetailsList();
      final RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

      ruleSetNodeKey.nodeID = readTextKey.nodeID;
      ruleSetNodeKey.ruleSetID = readTextKey.ruleSetID;

      translationDetailsList = listTranslation(ruleSetNodeKey);

      for (int i = 0; i < translationDetailsList.translationDtls.size(); i++) {

        if (translationDetailsList.translationDtls.item(i).languageCode.equalsIgnoreCase(
          readTextKey.languageCode)) {

          if (readTextKey.nodeID == 0) {
            final NodeIDAndType nodeIDAndType = Editor.getRuleSetTypeInformation(
              readTextKey.ruleSetID);

            // BEGIN, CR00052324, AK
            if (nodeIDAndType.getType().equals(XmlTreeConst.kSRS)) {
              // END, CR00052324
              appException = new AppException(
                ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_SUBRULESET_AND_LANGUAGE);

            } else {
              appException = new AppException(
                ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_ELIGIBILITY_RULESET_AND_LANGUAGE);
            }
            appException.arg(languageCodeDescription);

            // BEGIN, CR00052814, AK
            informationalManager.addInformationalMsg(appException,
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
            // END, CR00052814

          }
          nodeType = Editor.getNodeType(readTextKey.ruleSetID,
            readTextKey.nodeID);

          // if already exists, throw exception
          // BEGIN, CR00052324, AK
          // BEGIN, CR00090864, CM
          if (nodeType.equals(XmlTreeConst.kO)) {
            // END, CR00090864
            // END, CR00052324
            appException = new AppException(
              ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_OBJECTIVE_AND_LANGUAGE);

          } // BEGIN, CR00052324, AK
          // BEGIN, CR00090864, CM
          else if (nodeType.equals(XmlTreeConst.kR)) {
            // END, CR00090864
            // END, CR00052324
            appException = new AppException(
              ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_RULE_AND_LANGUAGE);
          } // BEGIN, CR00052324, AK
          // BEGIN, CR00090864, CM
          else if (nodeType.equals(XmlTreeConst.kRG)) {
            // END, CR00090864
            // END, CR00052324
            appException = new AppException(
              ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_RULE_GROUP_AND_LANGUAGE);
          } // BEGIN, CR00052324, AK
          // BEGIN, CR00090864, CM
          else if (nodeType.equals(XmlTreeConst.kRLG)) {
            // END, CR00090864
            // END, CR00052324
            appException = new AppException(
              ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_RULE_LIST_GROUP_AND_LANGUAGE);
          } // BEGIN, CR00052324, AK
          // BEGIN, CR00090864, CM
          else if (nodeType.equals(XmlTreeConst.kOG)) {
            // END, CR00090864
            // END, CR00052324
            appException = new AppException(
              ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_OBJECTIVE_GROUP_AND_LANGUAGE);
          } // BEGIN, CR00052324, AK
          // BEGIN, CR00090864, CM
          else if (nodeType.equals(XmlTreeConst.kOLG)) {
            // END, CR00090864
            // END, CR00052324
            appException = new AppException(
              ENTRULESTRANSLATION.ERR_TRANSLATION_XRV_EXISTS_FOR_OBJECTIVE_LIST_GROUP_AND_LANGUAGE);
          }

          appException.arg(languageCodeDescription);
          // BEGIN, CR00052814, AK
          informationalManager.addInformationalMsg(appException,
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
          // END, CR00052814

        }

      }

    } catch (final Exception ex) {// do nothing
    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * This readCodeTableItemDescription method reads the description of code
   * table code.
   *
   * @param codeName code table code.
   * @param codeTablelName code table name.
   * @return code item description.
   * @throws InformationalException If error occurs.
   *
   * @throws AppException If error occurs.
   */
  public String readCodeTableItemDescription(String codeName,
    String codeTablelName) throws AppException, InformationalException {

    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface = CodeTableFactory.newInstance();

    ctitemKey.code = codeName;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = codeTablelName;

    ctitem = codeTableInterface.getOneItem(ctitemKey);

    return ctitem.description;
  }

  // ___________________________________________________________________________
  /**
   * This method checks The top-level node of a Sub Rule Set.
   *
   * @param ruleSetIDKey ruleSetIdentifier
   * @throws InformationalException If error occurs.
   *
   * @throws AppException If error occurs.
   */
  public void validateTopLevelNode(RuleSetIDStruct ruleSetIDKey)
    throws AppException, InformationalException {

    final SubRuleSet e = Editor.getSubRuleSet(ruleSetIDKey.ruleSetID);
    final RuleChild children[] = e.getChildren();

    // if it has more than one child throw error
    if (children.length > 1) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_ONLY_ONE_TOP_LEVEL_NODE_FOR_SUB_RULE_SET);
    }

  }

  // BEGIN, CR00021982, LP
  // ___________________________________________________________________________
  /**
   * This method adds RDO to Sub RuleSet.
   *
   * @param createDtls contains details about RDO
   */
  @Override
  public void addRulesDataObjectToSubRuleSet(
    CreateRDOForSubRuleSetDtls createDtls) throws AppException,
      InformationalException {

    final RuleSetEnvSetting ruleSetEnvSetting = checkEnvironmentSetting();

    // If the system is live, an RDO may not be added to the Rule Set
    if (ruleSetEnvSetting.ruleSetLiveStr.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      throw new AppException(
        curam.message.BPORULESEDITOR.ERR_RULES_EDITOR_XRV_CANT_ADD_RDO);
    }

    Editor.addRulesDataObjectToRuleSet(createDtls.createRDODtls.ruleSetID,
      createDtls.createRDODtls.versionNo,
      createDtls.createRDODtls.rulesDataObjectID,
      createDtls.createRDODtls.rulesDataObjectFinal, createDtls.qualifier);

  }

  // END, CR00021982

  // BEGIN, CR00021982, LP
  // ___________________________________________________________________________
  /**
   * Reads RDO details for sub rule set
   *
   * @param key identifies the RDO
   *
   * @return RDO summary details
   */
  @Override
  public RulesDataObjectSummaryDtls viewRulesDataObjectForSubRuleSet(
    ViewSubRuleSetRDOKey key) throws AppException, InformationalException {

    final RulesDataObjectSummaryDtls result = new RulesDataObjectSummaryDtls();

    final RDO rdo = Editor.getRulesDataObject(key.rulesDataObjectID);

    result.nameAndTypeDtls.rulesDataObjectName = rdo.getDisplayName();
    result.nameAndTypeDtls.rulesDataObjectFinal = key.rulesDataObjectFinal;
    result.nameAndTypeDtls.rulesDataObjectQualifier = key.rulesDataObjectQualifier;

    if (rdo.isListGroup()) {
      result.nameAndTypeDtls.rulesDataObjectType = RULESDATAOBJECTTYPE.LIST;
    } else {
      result.nameAndTypeDtls.rulesDataObjectType = RULESDATAOBJECTTYPE.SINGLE;
    }

    final DataItem dataItems[] = rdo.getItems();

    for (int i = 0; i < dataItems.length; i++) {

      final DataItem dataItem = dataItems[i];

      final AttributeDtls attr = new AttributeDtls();

      attr.attributeName = dataItem.getDescription();
      attr.attributeType = dataItem.getType();

      result.attributeDtls.attibuteDtls.addRef(attr);
    }

    return result;
  }

  // END, CR00021982

  // ___________________________________________________________________________
  /**
   * Fetches the RuleSet data and builds tree in XML format
   *
   * @param ruleSetIDStruct identifies the RuleSetID
   * @param ruleSetType identifies the type of the rule set -
   * Eligibility Rule Set, Sub Rule Set, Work Allocation Rule Set
   *
   * @return XML Data.
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  @Override
  public ReadXMLStringDetails createRulesTree(
    RuleSetIDStruct ruleSetIDStruct, RuleSetType ruleSetType)
    throws AppException, InformationalException {

    final curam.core.facade.struct.ReadXMLStringDetails readXMLDetails = new curam.core.facade.struct.ReadXMLStringDetails();

    final Element mainElement = new Element(XmlTreeConst.kNodeInfo,
      XmlTreeConst.kNamespace);

    mainElement.setAttribute(XmlTreeConst.kName, ruleSetType.ruleSetType);

    // Add NodeTypes Element
    mainElement.addContent(createNodeTypesXML(ruleSetType));

    // Add NodeSet Element
    mainElement.addContent(constructTree(ruleSetIDStruct, ruleSetType));

    final Document document = new Document(mainElement);

    readXMLDetails.XMLData = XMLUtil.getAsString(document);

    return readXMLDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates all NodeTypes allowed in the Rules tree
   *
   * @param ruleSetType identifies the type of the rule set -
   * Eligibility Rule Set, Sub Rule Set, Work Allocation Rule Set
   *
   * @return Element All Rules NodeTypes
   */
  protected static Element createNodeTypesXML(RuleSetType ruleSetType) {

    final Element nodeTypesElement = new Element(XmlTreeConst.kNodeTypes,
      XmlTreeConst.kNamespace);
    Element nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    // Build node Set type

    if (ruleSetType.ruleSetType.equals(XmlTreeConst.kRuleSetTreeName)) {

      nodeTypeElement.setAttribute(XmlTreeConst.kName,
        XmlTreeConst.kEligibilityRuleSet);
    } else if (ruleSetType.ruleSetType.equals(
      XmlTreeConst.kWorkAllocationRuleSetTreeName)) {

      nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kWARuleSet);
    } else if (ruleSetType.ruleSetType.equals(
      XmlTreeConst.kSubRuleSetTreeViewName)) {

      nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kSubRuleSet);
    }

    Element actionsElement = new Element(XmlTreeConst.kActions,
      XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    Element actionElement = new Element(XmlTreeConst.kAction,
      XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    Element paramElement = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);

    // Build Rule Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID1 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID1);

    paramElementforNodeID1.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kObjectiveGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID2 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID2);

    paramElementforNodeID2.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kObjective);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID3 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID3);

    paramElementforNodeID3.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective List Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kObjectiveListGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID4 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID4);

    paramElementforNodeID4.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Rule List Group node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kRuleListGroup);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID5 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID5);

    paramElementforNodeID5.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Rule node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRule);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID6 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID6);

    paramElementforNodeID6.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Data Item Assignment node type
    nodeTypeElement = new Element(XmlTreeConst.kNodeType,
      XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kDataItemAssignment);
    actionsElement = new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);

    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);

    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);

    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    final Element paramElementforNodeID7 = new Element(XmlTreeConst.kKey,
      XmlTreeConst.kNamespace);

    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kDataItemAssignment);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    actionElement.addContent(paramElementforNodeID7);
    paramElementforNodeID7.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    if (!ruleSetType.ruleSetType.equals(
      XmlTreeConst.kWorkAllocationRuleSetTreeName)) {

      // Build SubRuleSet Link node type
      nodeTypeElement = new Element(XmlTreeConst.kNodeType,
        XmlTreeConst.kNamespace);
      nodeTypesElement.addContent(nodeTypeElement);
      nodeTypeElement.setAttribute(XmlTreeConst.kName,
        XmlTreeConst.kSubRuleSetLink);
      actionsElement = new Element(XmlTreeConst.kActions,
        XmlTreeConst.kNamespace);
      nodeTypeElement.addContent(actionsElement);
      actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
      actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
      actionsElement.addContent(actionElement);
      actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
      paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
      actionElement.addContent(paramElement);
      paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
      final Element paramElementforNodeID8 = new Element(XmlTreeConst.kKey,
        XmlTreeConst.kNamespace);

      actionElement.addContent(paramElementforNodeID8);
      paramElementforNodeID8.setAttribute(XmlTreeConst.kName,
        XmlTreeConst.kNodeID);
    }

    return nodeTypesElement;

  }

  // ___________________________________________________________________________
  /**
   * Constructs the XML tree for the given rule set
   *
   * @param ruleSetIDStruct identifies the RuleSetID
   * @param ruleSetType identifies the type of the rule set -
   * Eligibility Rule Set, Sub Rule Set, Work Allocation Rule Set
   *
   * @return Element The complete rule set tree
   */
  protected Element constructTree(RuleSetIDStruct ruleSetIDStruct,
    RuleSetType ruleSetType) throws AppException, InformationalException {

    String eligibilityNodeID = null;

    // Get the complete rule set document by using the API
    final ExternalAccess access = RuleSetAccessFactory.createRuleSetAccess();
    final Document xmlDocument = access.getRuleSet(ruleSetIDStruct.ruleSetID).getDocument();

    // Get the product element from the rule set document
    String filter = null;
    // BEGIN, CR00144157, SS
    final Hashtable<String, String> subRuleSetNames =
      new Hashtable<String, String>();

    // END, CR00144157

    // if sub rule set then search for the sub rule set node
    // else search for product node
    if (ruleSetType.ruleSetType
      .equals(XmlTreeConst.kSubRuleSetTreeViewName)) {

      filter = XmlTreeConst.kSubRuleSetNode;
    } else if (ruleSetType.ruleSetType
      .equals(XmlTreeConst.kWorkAllocationRuleSetTreeName)) {
      // BEGIN, CR00085608 SK
      filter = XmlTreeConst.kGenericRuleSet;
      // END, CR00085608 SK
    } else {

      filter = XmlTreeConst.kProduct;
    }

    final List elementList = xmlDocument.getElements(filter);
    final Element productElement = (Element) elementList.get(0);

    // Obtain the node id for the rule set
    eligibilityNodeID = productElement.getAttributeValue(XmlTreeConst.kID);

    // BEGIN, CR00125057, SK
    // Get rule set name
    final List ruleSet = productElement.getChild(XmlTreeConst.kLabel)
      .getChild(XmlTreeConst.kRuleName).getChildren();
    final String ruleSetName = getNodeNameForClientLocale(ruleSet);
    // END, CR00125057

    // Create root element node
    final Element nodeSetElement = createRootElement(ruleSetIDStruct,
      ruleSetType, eligibilityNodeID, ruleSetName);

    final Element mainElement = nodeSetElement;
    // The editor list stores the list of nodes fetched using the API
    final List editorList = new ArrayList();
    // The final list stores the list of nodes that will be displayed as rules
    // tree
    final List finalList = new ArrayList();

    // The current element is an intermediate element that helps in building the
    // final tree structure.
    Element currentElement = mainElement;

    // The editor element acts like an iterator pointing to the node being
    // currently inspected.
    Element editorElement = productElement;

    // Get list of all product elements content
    List list = productElement.getContent();

    // Iterate till all the nodes in the editor list have been reviewed.
    while (true) {

      for (int i = 0; i < list.size(); i++) {

        final Object obj = list.get(i);
        Element element = null;

        // Ensure that the node is of type element and not a comment.
        if (obj instanceof Element) {

          element = (Element) obj;

          // The element name gives the rule type
          final String elementName = element.getName();

          // Check if it is a valid rule type.
          if (elementName.equalsIgnoreCase(XmlTreeConst.kDataItemAssignment)
            || elementName.equalsIgnoreCase(XmlTreeConst.kSubRuleSetLink)
            || elementName.equalsIgnoreCase(XmlTreeConst.kRule)
            || elementName.equalsIgnoreCase(XmlTreeConst.kRuleGroup)
            || elementName.equalsIgnoreCase(XmlTreeConst.kRuleListGroup)
            || elementName.equalsIgnoreCase(XmlTreeConst.kObjective)
            || elementName.equalsIgnoreCase(XmlTreeConst.kObjectiveGroup)
            || elementName.equalsIgnoreCase(XmlTreeConst.kObjectiveListGroup)) {

            // Fetch the node id
            final String nodeID = element.getAttributeValue(XmlTreeConst.kID);

            // Construct node type. A node type is obtained from the element
            // name.
            // Element name is same as node type, with first character as upper
            // case.
            final StringBuffer nodeType = new StringBuffer();

            final String firstCharacter = new String(CuramConst.gkEmpty + elementName.charAt(0)).toLowerCase();

            nodeType.append(firstCharacter);
            nodeType.append(elementName.substring(1));

            String nodeName = null;

            if (elementName.equalsIgnoreCase(XmlTreeConst.kDataItemAssignment)) {
              // Get the value attribute for the data item assignment
              nodeName = element.getAttributeValue(XmlTreeConst.kValue);
            } else if (elementName.equalsIgnoreCase(
              XmlTreeConst.kSubRuleSetLink)) {

              // Get the name attribute for the sub rule set link
              // nodeName = element.getAttributeValue(XmlTreeConst.kName);
              // BEGIN, CR00144157, SS
              final String subID = element.getAttributeValue(
                XmlTreeConst.kSubRuleSetId);

              nodeName = subRuleSetNames.get(subID);
              if (nodeName == null) {
                nodeName = getSubRuleSetName(
                  access.getRuleSet(subID).getDocument());
                subRuleSetNames.put(subID, nodeName);
              }
              // END, CR00144157
            } else {
              // BEGIN, CR00125057, SK
              // Get the value attribute
              final List children = element.getChild(XmlTreeConst.kLabel).getChild(XmlTreeConst.kRuleName).getChildren();

              nodeName = getNodeNameForClientLocale(children);
              // END, CR00125057
            }
            // Create node element
            final Element nodeElement = createNodeElement(
              ruleSetIDStruct.ruleSetID, nodeName, nodeID, nodeType.toString());

            editorList.add(element);
            finalList.add(nodeElement);

            final List allDescendantsList = currentElement.getDescendants();

            boolean nodeFound = false;

            for (final Object object : allDescendantsList) {

              // BEGIN, CR00091205, CM
              if (!currentElement.equals(mainElement)
                // END, CR00091205l
                && currentElement.getAttributeValue(XmlTreeConst.kType)
                  .equalsIgnoreCase(editorElement.getName())) {

                break;
              }

              if (object instanceof Element
                && ((Element) object).getName().equals(XmlTreeConst.kNode)) {

                ((Element) object).addContent(nodeElement);
                nodeFound = true;
                break;
              }
            }

            if (!nodeFound) {

              currentElement.addContent(nodeElement);
            }
          }
        }
      }

      if (editorList.size() == 0) {
        break;
      }

      currentElement = (Element) finalList.get(0);
      editorElement = (Element) editorList.get(0);

      list = editorElement.getContent();

      editorList.remove(0);
      finalList.remove(0);
    }

    return nodeSetElement;
  }

  // ___________________________________________________________________________
  /**
   * Constructs the XML tree for the given rule set
   *
   * @param ruleSetIDStruct identifies the RuleSetID
   * @param nodeName identifies the name of the XML node element
   * @param nodeID identifier for the node element
   * @param nodeType identifies the node type
   *
   * @return Element The complete rule set tree
   */

  protected Element createNodeElement(String ruleSetID, String nodeName,
    String nodeID, String nodeType) {

    final Element nodeElement = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    nodeElement.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + nodeID);
    nodeElement.setAttribute(XmlTreeConst.kType, nodeType);

    final Element nodeTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    nodeElement.addContent(nodeTitleElement);
    nodeTitleElement.setText(nodeName);

    final Element ruleSetIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    nodeElement.addContent(ruleSetIDParamValueElement);

    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetID);

    final Element nodeIDParamValueElement = new Element(
      XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    nodeElement.addContent(nodeIDParamValueElement);

    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      nodeID);

    return nodeElement;
  }

  // ___________________________________________________________________________
  /**
   * Create root element node
   *
   * @param ruleSetIDStruct identifies the RuleSetID
   * @param ruleSetType identifies the type of the rule set -
   * Eligibility Rule Set, Sub Rule Set, Work Allocation Rule Set
   * @param nodeID identifier for the node element
   * @param ruleSetName name of the rule set
   *
   * @return Element The node element created
   */

  protected Element createRootElement(RuleSetIDStruct ruleSetIDStruct,
    RuleSetType ruleSetType, String nodeID, String ruleSetName)
    throws AppException, InformationalException {

    // RuleSetSummary variables
    final String ruleSetID = ruleSetIDStruct.ruleSetID;
    final TreeXMLNodeDetails treeXMLNodeDetails = TreeXMLNodeCache.getInstance().getTreeXMLNodeDetails(
      ruleSetID);

    final Element nodeSetElement = new Element(XmlTreeConst.kNodeSet,
      XmlTreeConst.kNamespace);

    final Element rootNode = new Element(XmlTreeConst.kNode,
      XmlTreeConst.kNamespace);

    nodeSetElement.addContent(rootNode);

    rootNode.setAttribute(XmlTreeConst.kID, XmlTreeConst.kRuleIDPrefix + nodeID);

    final String stStartNodeId = XmlTreeConst.kRuleIDPrefix
      + treeXMLNodeDetails.getStLastAccessedNodeId();

    nodeSetElement.setAttribute(XmlTreeConst.kStartNode, stStartNodeId);

    if (ruleSetType.ruleSetType.equals(XmlTreeConst.kRuleSetTreeName)) {

      rootNode.setAttribute(XmlTreeConst.kType,
        XmlTreeConst.kEligibilityRuleSet);
    } else if (ruleSetType.ruleSetType.equals(
      XmlTreeConst.kWorkAllocationRuleSetTreeName)) {

      rootNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kWARuleSet);
    } else if (ruleSetType.ruleSetType.equals(
      XmlTreeConst.kSubRuleSetTreeViewName)) {

      rootNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kSubRuleSet);
    }

    final Element rootTitleElement = new Element(XmlTreeConst.kTitle,
      XmlTreeConst.kNamespace);

    rootNode.addContent(rootTitleElement);
    rootTitleElement.setText(ruleSetName);

    final Element rootParamValueElement = new Element(XmlTreeConst.kParamValue,
      XmlTreeConst.kNamespace);

    rootNode.addContent(rootParamValueElement);

    rootParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      nodeID);

    return nodeSetElement;

  }

  // __________________________________________________________
  /**
   * Get node name respective to locale
   *
   * @param children List
   *
   * @return node name respective to locale
   */
  // BEGIN, CR00125057, SK
  protected String getNodeNameForClientLocale(List children) {

    final int size = children.size();
    String nodeName = CuramConst.gkEmpty;
    String nodeNameDefault = CuramConst.gkEmpty;
    String locale = CuramConst.gkEmpty;
    final String clientLocale = TransactionInfo.getProgramLocale();

    for (int i = 0; i < size; i++) {
      nodeName = ((Element) children.get(i)).getAttributeValue(
        XmlTreeConst.kValue);
      locale = ((Element) children.get(i)).getAttributeValue(
        XmlTreeConst.kLocale);
      // if locale is "en" or "en_US" or "en_GB" ,
      // then display node in english ("en_US") as default
      if (locale.equals(UtilCuramConst.LOCALE_EN)
        || locale.equals(UtilCuramConst.LOCALE_GB)
        || locale.equals(UtilCuramConst.LOCALE_US)) {
        nodeNameDefault = nodeName;
      }
      if (locale.equals(clientLocale)) {
        return nodeName;
      }
    }
    return nodeNameDefault;
  }

  // END, CR00125057
  // BEGIN, CR00144157, SS
  /**
   * Returns the sub rule set name.
   *
   * @param subRuleSetDoc sub rule set document.
   *
   * @return sub rule set name.
   */
  protected String getSubRuleSetName(final Document subRuleSetDoc) {

    final List subList =
      subRuleSetDoc.getElements(XmlTreeConst.kSubRuleSetNode);

    final Element subRuleSetElement = (Element) subList.get(0);

    // Get rule set name
    final List ruleNames = subRuleSetElement.getChild(XmlTreeConst.kLabel)
      .getChild(XmlTreeConst.kRuleName).getChildren();

    return getNodeNameForClientLocale(ruleNames);
  }
  // END CR00144157
}
