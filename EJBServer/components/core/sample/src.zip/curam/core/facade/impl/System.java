/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006-2018. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2013 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.LANGUAGE;
import curam.codetable.MSWORDTEMPLATETYPE;
import curam.codetable.XSLTEMPLATETYPE;
import curam.core.facade.struct.*;
import curam.core.fact.MaintainXSLTemplateFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.MaintainXSLTemplate;
import curam.core.sl.entity.struct.NicknameDtls;
import curam.core.sl.entity.struct.NicknameDtlsList;
import curam.core.sl.entity.struct.NicknameKey;
import curam.core.sl.fact.DocumentTemplateFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.sl.intf.DocumentTemplate;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.ModifyXSLTemplateDetails;
import curam.core.struct.RoleNameWrapperIdx;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UpperRoleNameWrapperStruct;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.core.struct.XSLTemplateIn;
import curam.core.struct.XSLTemplateModifyDetails;
import curam.core.struct.XSLTemplateReadDetails;
import curam.core.struct.XSLTemplateViewDetails;
import curam.message.BPOSYSTEM;
import curam.util.administration.fact.CodeTableAdminFactory;
import curam.util.administration.fact.XSLTemplateAdminFactory;
import curam.util.administration.intf.CodeTableAdmin;
import curam.util.administration.intf.XSLTemplateAdmin;
import curam.util.administration.struct.AddTemplateDtls;
import curam.util.administration.struct.BatchErrorCodesDetails;
import curam.util.administration.struct.BatchErrorCodesDetailsList;
import curam.util.administration.struct.BatchProcessSearchKey;
import curam.util.administration.struct.BatchRequestProcessDetailsList;
import curam.util.administration.struct.CTDisplayNameDetails;
import curam.util.administration.struct.CTDisplayNameDetailsList;
import curam.util.administration.struct.CTItemCommonCodeKey;
import curam.util.administration.struct.CTTranslationSearchKey;
import curam.util.administration.struct.CTTranslationTextDetailsIn;
import curam.util.administration.struct.CheckInTemplateDtls;
import curam.util.administration.struct.CheckOutTemplateDtls;
import curam.util.administration.struct.CodeTableHeaderDetails;
import curam.util.administration.struct.CodeTableHeaderDetailsList;
import curam.util.administration.struct.CodeTableHierarchyDetails;
import curam.util.administration.struct.CodeTableHierarchyList;
import curam.util.administration.struct.CodeTableInHierarchyDetailsList;
import curam.util.administration.struct.CodeTableItemAndDisplayDtlsList;
import curam.util.administration.struct.CodeTableItemDetailsList;
import curam.util.administration.struct.CodeTableItemUniqueKey;
import curam.util.administration.struct.SecurityIdentifierDetailsList;
import curam.util.administration.struct.SecurityIdentifierNameDescription;
import curam.util.administration.struct.UndoCheckOutTemplateDtls;
import curam.util.administration.struct.XSLGetTemplateDetails;
import curam.util.administration.struct.XSLTemplateDetailsList;
import curam.util.administration.struct.XSLTemplateID;
import curam.util.administration.struct.XSLTemplateInstDetails;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.administration.struct.XSLTemplateVersionSearchDtlsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.message.INFRASTRUCTURE;
import curam.util.resources.GeneralConstants;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;


/**
 * @see curam.core.facade.intf.System
 */
public abstract class System extends curam.core.facade.base.System {

  // BEGIN, CR00146011, GSP
  // BEGIN, CR00096373, GM
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListSelectedFieldsDocumentTemplateDetails readAllWithoutContent()
    throws AppException, InformationalException {

    // create a return object
    final ListSelectedFieldsDocumentTemplateDetails listSelectedFieldsDocumentTemplateDetails = new ListSelectedFieldsDocumentTemplateDetails();

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // list document template details
    listSelectedFieldsDocumentTemplateDetails.dtls = documentTemplateObj.listSelectedFields();

    return listSelectedFieldsDocumentTemplateDetails;
  }

  // BEGIN, CR00207573, PB
  /**
   * {@inheritDoc}
   */

  @Override
  public LanguageDetailsList readLanguageDetails() throws AppException,
      InformationalException {

    final LanguageDetailsList languageDetailsList = new LanguageDetailsList();

    LinkedHashMap<String, String> codeTableItemList = new LinkedHashMap<String, String>();

    // Get the list of all Response types.
    codeTableItemList = CodeTable.getAllEnabledItems(LANGUAGE.TABLENAME,
      TransactionInfo.getProgramLocale());
    final Set<String> lanugageKeySet = codeTableItemList.keySet();
    final Iterator<String> languageIterator = lanugageKeySet.iterator();

    while (languageIterator.hasNext()) {
      final curam.core.sl.struct.LanguageLocaleDetails languageLocaleDetails = new curam.core.sl.struct.LanguageLocaleDetails();

      languageLocaleDetails.languageCode = languageIterator.next().toString();
      languageLocaleDetails.localeIdentifier = CodeTable.getOneItem(
        LANGUAGE.TABLENAME, languageLocaleDetails.languageCode,
        TransactionInfo.getProgramLocale());
      languageDetailsList.dtls.add(languageLocaleDetails);
    }

    return languageDetailsList;
  }

  // END, CR00207573

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public CodeTableName createCodeTable(CodeTableName details)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Details to be returned
    final CodeTableName codeTableName = new CodeTableName();

    // Check that a table name has been entered
    if (details.name.length() == 0) {

      throw new AppException(curam.message.BPOSYSTEM.ERR_CODETABLE_FV_ID_EMPTY);
    }

    // Create new codetable
    if (details.functionalName.isEmpty()) {
      codeTableAdminObj.addEmptyCodeTable(details.name, null);
    } else {
      codeTableAdminObj.addEmptyCTDisplayName(details.name, null,
        details.functionalName);
    }

    // Prepare return details
    codeTableName.name = details.name;

    // Return details
    return codeTableName;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createCodeTableItem(MaintainCodeTableItem details)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableItemUniqueKey key = new CodeTableItemUniqueKey();

    key.code = details.code;
    key.tableName = details.name;
    key.locale = details.languageCode;
    try {
      final curam.util.administration.struct.CodeTableItemDetails itemDetails = codeTableAdminObj.readCodeTableItemDetails(
        key);

      if (itemDetails != null) {
        throw new AppException(
          curam.message.BPOSYSTEM.ERR_TRANSLATION_ALREADY_EXISTS);
      }

    } catch (final RecordNotFoundException re) {// do nothing.
    } catch (final AppException appe) {
      if (!INFRASTRUCTURE.ID_READ_CODETABLEITEM_NOTFOUND.equals(
        appe.getCatEntry())) {
        throw appe;
      }
    }

    // Check that a codetable code has been entered
    if (details.code.length() > 10) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_CODETABLE_FV_CODE_TOO_LONG);
    }

    // Prepare details
    final curam.util.administration.struct.CodeTableItemDetails codeTableItemDtls = new curam.util.administration.struct.CodeTableItemDetails();

    codeTableItemDtls.annotation = details.annotation;
    codeTableItemDtls.code = details.code;
    codeTableItemDtls.description = details.description;
    codeTableItemDtls.isEnabled = true;
    codeTableItemDtls.tableName = details.name;
    codeTableItemDtls.locale = details.languageCode.isEmpty()
      ? TransactionInfo.getProgramLocale()
      : details.languageCode;
    codeTableItemDtls.sortOrder = details.sortOrder;

    // Add codetable item
    codeTableAdminObj.addItem(codeTableItemDtls);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListCodeTable listCodeTable() throws AppException,
      InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Details to be returned
    final ListCodeTable listCodeTable = new ListCodeTable();

    // Retrieve the list of codetables
    final curam.util.administration.struct.CodeTableAdminListAllTablesOut codeTableAdminList = codeTableAdminObj.listAllTables();

    // Copy list to return object
    for (int i = 0; i < codeTableAdminList.dtls.size(); i++) {

      final CodeTableDetails codeTableDetails = new CodeTableDetails();

      codeTableDetails.defaultCode = codeTableAdminList.dtls.item(i).defaultCode;
      codeTableDetails.lastModifiedTimeStamp = codeTableAdminList.dtls.item(i).timestamp;
      codeTableDetails.name = codeTableAdminList.dtls.item(i).tableName;
      codeTableDetails.versionNo = codeTableAdminList.dtls.item(i).versionNo;

      listCodeTable.codeTableDetails.addRef(codeTableDetails);
    }

    // Return details
    return listCodeTable;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public LocalizableDescTxtDtls searchByKeyAndLocale(
    final LocalizableDescTxtDtls searchKey) throws AppException,
      InformationalException {

    // Codetable maintenance business process object
    final CodeTableAdmin translationHandlerObj = CodeTableAdminFactory.newInstance();

    final CTTranslationSearchKey key = new CTTranslationSearchKey();

    key.tableName = searchKey.displayNameId;
    key.localeId = searchKey.LocaleCode;

    // Retrieve the list of codetables
    final CTDisplayNameDetails translationTextDetails = translationHandlerObj.searchTableNameByLocale(
      key);

    final LocalizableDescTxtDtls returnDtls = new LocalizableDescTxtDtls();

    if (translationTextDetails != null) {
      returnDtls.displayNameId = translationTextDetails.tableName;
      returnDtls.LocaleCode = translationTextDetails.localeIdentifier;
      returnDtls.translationText = translationTextDetails.text;
    }

    return returnDtls;
  }

  public CodeTableItemDetailsList searchByCodeTableItemDescription(
    final String tableName, final String description) throws AppException,
      InformationalException {

    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableItemDetailsList list = codeTableAdminObj.searchByCodeTableItemDescription(
      tableName, description);

    return list;
  }

  /**
   * {@inheritDoc}
   */
  // END, CR00146011

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyTextTranslation(final AddTranslationDtls translationDtls)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final CTTranslationTextDetailsIn detailsIn = new CTTranslationTextDetailsIn();

    detailsIn.tableName = translationDtls.displayNameId;
    detailsIn.localeCode = translationDtls.localeCode;
    detailsIn.text = translationDtls.descText;
    final CodeTableAdmin adminObj = CodeTableAdminFactory.newInstance();

    // Retrieve the list of codetables
    adminObj.modifyTableNameTranslation(detailsIn);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeTextTranslation(final LocalizableDescTxtDtls descDtls)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final CodeTableAdmin adminObj = CodeTableAdminFactory.newInstance();
    final CTTranslationTextDetailsIn localizationKey = new CTTranslationTextDetailsIn();

    localizationKey.tableName = descDtls.displayNameId;
    localizationKey.localeCode = descDtls.LocaleCode;

    // Retrieve the list of codetables
    adminObj.removeTableNameTranslation(localizationKey);

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011

  // BEGIN, CR00221799, JF
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CodeTableSearchResults searchCodeTables(CodeTableSearchKey key)
    throws AppException, InformationalException {

    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableSearchResults codeTableDisplayNameSearchResults = new CodeTableSearchResults();

    final curam.util.administration.struct.CTNameDisplayNameDetailsList codeTableDisplayNameSearchResultsList = codeTableAdminObj.searchByCodeTableNameAndItemDescription(
      key.codeTableSearchKey, key.codeTableItemSearchKey);

    // codeTableAdminObj.searchByCodeTableDisplayName(key.codeTableSearchKey);
    CodeTableDetails codeTableDtls;

    for (int i = 0; i < codeTableDisplayNameSearchResultsList.dtls.size(); i++) {

      codeTableDtls = new CodeTableDetails();

      if (!codeTableDisplayNameSearchResultsList.dtls.item(i).defaultCode.isEmpty()) {

        final ReadCodeTableItemKey CTItemKey = new ReadCodeTableItemKey();

        CTItemKey.code = codeTableDisplayNameSearchResultsList.dtls.item(i).defaultCode;
        CTItemKey.languageCode = TransactionInfo.getProgramLocale();
        CTItemKey.name = codeTableDisplayNameSearchResultsList.dtls.item(i).tableName;

        codeTableDtls.defaultCodeDesc = readCodeTableItem(CTItemKey).description;
      }

      codeTableDtls.defaultCode = codeTableDisplayNameSearchResultsList.dtls.item(i).defaultCode;

      codeTableDtls.functionalName = codeTableDisplayNameSearchResultsList.dtls.item(i).displayName.isEmpty()
        ? codeTableDisplayNameSearchResultsList.dtls.item(i).tableName
        : codeTableDisplayNameSearchResultsList.dtls.item(i).displayName;

      codeTableDtls.lastModifiedTimeStamp = codeTableDisplayNameSearchResultsList.dtls.item(i).timestamp;
      codeTableDtls.name = codeTableDisplayNameSearchResultsList.dtls.item(i).tableName;
      codeTableDtls.displayNameId = codeTableDisplayNameSearchResultsList.dtls.item(i).tableName;

      codeTableDisplayNameSearchResults.codeTableDetails.addRef(codeTableDtls);

    }

    return codeTableDisplayNameSearchResults;
  }

  // END, CR00221799, JF

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListItemsInCodeTable listItemsInCodeTable(CodeTableName key)
    throws AppException, InformationalException {

    // Details to be returned
    final ListItemsInCodeTable listItemsInCodeTable = new ListItemsInCodeTable();

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // CodeTableItemDetails struct
    CodeTableItemDetails codeTableItemDetails;

    // Retrieve the list of items in the codetable
    final curam.util.administration.struct.CodeTableAdminListAllItemsAndDefaultOut codeTableItemList = // BEGIN,
      // CR00124504
      // ,
      // GSP
      codeTableAdminObj.listEnabledItems(
      key.name);

    // END, CR00124504
    // Copy list to return object
    for (int i = 0; i < codeTableItemList.dtls.size(); i++) {

      codeTableItemDetails = new CodeTableItemDetails();

      codeTableItemDetails.annotation = codeTableItemList.dtls.item(i).annotation;
      codeTableItemDetails.code = codeTableItemList.dtls.item(i).code;
      codeTableItemDetails.description = codeTableItemList.dtls.item(i).description;
      codeTableItemDetails.selectableInd = codeTableItemList.dtls.item(i).isEnabled;
      codeTableItemDetails.languageCode = codeTableItemList.dtls.item(i).locale;
      codeTableItemDetails.sortOrder = codeTableItemList.dtls.item(i).sortOrder;
      codeTableItemDetails.versionNo = codeTableItemList.dtls.item(i).versionNo;

      listItemsInCodeTable.codeTableItemDetails.addRef(codeTableItemDetails);
    }

    // Retrieve the default code for the table
    listItemsInCodeTable.defaultCodeDetails.defaultCode = codeTableItemList.defaultCode;
    // Retrieve the version number for the code table
    listItemsInCodeTable.defaultCodeDetails.versionNo = codeTableItemList.codeTableVersionNo;

    return listItemsInCodeTable;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Modify the default code for a codetable.
   *
   * @param details
   * Details of the default code for a specified codetable.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public void modifyCodeTableDefault(ModifyCodeTableDefault details)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Set the default code for the codetable
    try {
      codeTableAdminObj.setTableDefaultCode(details.name, details.defaultCode,
        details.versionNo);
    } catch (final AppException e) {

      if (!INFRASTRUCTURE.ID_SETDEFAULTCODE_ITEMNOTFOUND.equals(e.getCatEntry())) {
        throw e;
      }

    }
  }

  // BEGIN, CR00146011, GSP
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public CodeTableDetails readCodeTable(CodeTableName codeTableName)
    throws AppException, InformationalException {

    // Maintain codetable business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Details to be returned
    CodeTableHeaderDetails codeTableHeaderDetails = new CodeTableHeaderDetails();

    // Read the codetable details
    codeTableHeaderDetails = codeTableAdminObj.readCodeTableHeaderDetails(
      codeTableName.name);

    // Copy details to return object
    final CodeTableDetails codeTableDetails = new CodeTableDetails();

    codeTableDetails.defaultCode = codeTableHeaderDetails.defaultCode;
    codeTableDetails.versionNo = codeTableHeaderDetails.versionNo;
    codeTableDetails.lastModifiedTimeStamp = codeTableHeaderDetails.timestamp;
    codeTableDetails.name = codeTableHeaderDetails.tableName;
    codeTableDetails.displayNameId = codeTableHeaderDetails.tableName;

    final CTTranslationSearchKey key = new CTTranslationSearchKey();

    key.localeId = TransactionInfo.getProgramLocale();
    key.tableName = codeTableName.name;

    final CTDisplayNameDetails displayNameDetails = codeTableAdminObj.searchTableNameByLocale(
      key);

    if (displayNameDetails != null) {
      codeTableDetails.functionalName = displayNameDetails.text;
    }

    // Return details
    return codeTableDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public MaintainCodeTableItem readCodeTableItem(ReadCodeTableItemKey key)
    throws AppException, InformationalException {

    // Maintain codetable business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Details to be returned
    final MaintainCodeTableItem maintainCodeTableItem = new MaintainCodeTableItem();

    // Key to read codetable item details
    final CodeTableItemUniqueKey codeTableItemKey = new CodeTableItemUniqueKey();
    // BEGIN, CR00335654, GA
    final curam.util.administration.struct.CodeTableItemDetails codeTableItemDetails = new curam.util.administration.struct.CodeTableItemDetails();

    // Set key to read codetable
    codeTableItemKey.code = key.code;
    codeTableItemKey.tableName = key.name;
    codeTableItemKey.locale = key.languageCode;

    // Read the codetable item details
    final curam.util.administration.struct.CodeTableItemDetails codeTableItemDtls = codeTableAdminObj.readCodeTableItemDetailsForSearch(
      codeTableItemKey);

    // Copy details to return object
    maintainCodeTableItem.annotation = codeTableItemDtls.annotation;
    maintainCodeTableItem.code = codeTableItemDtls.code;
    maintainCodeTableItem.description = codeTableItemDtls.description;
    maintainCodeTableItem.isEnabled = codeTableItemDtls.isEnabled;
    maintainCodeTableItem.name = codeTableItemDtls.tableName;
    maintainCodeTableItem.languageCode = codeTableItemDtls.locale;
    maintainCodeTableItem.sortOrder = codeTableItemDtls.sortOrder;
    maintainCodeTableItem.versionNo = codeTableItemDtls.versionNo;

    // Return details
    return maintainCodeTableItem;
  }

  @Override
  public CodeTableItemsDetailsList listCodeTableItemTranslations(
    final CodeTableItemCommonCode key) throws AppException,
      InformationalException {

    final CodeTableAdmin ctAdminObj = CodeTableAdminFactory.newInstance();
    final CTItemCommonCodeKey adminKey = new CTItemCommonCodeKey();

    adminKey.code = key.code;
    adminKey.tableName = key.tableName;
    final CodeTableItemDetailsList itemDtlsList = ctAdminObj.listAllItemsCommonCode(
      adminKey);

    final CodeTableItemsDetailsList returnList = new CodeTableItemsDetailsList();
    CodeTableItemDetails itemDtls;

    for (int curItem = 0; curItem < itemDtlsList.dtls.size(); curItem++) {
      itemDtls = new CodeTableItemDetails();

      itemDtls.code = itemDtlsList.dtls.item(curItem).code;
      itemDtls.languageCode = itemDtlsList.dtls.item(curItem).locale;
      itemDtls.description = itemDtlsList.dtls.item(curItem).description;

      returnList.dtls.addRef(itemDtls);

    }

    return returnList;
  }

  @Override
  public void toggleCodeTableItem(
    curam.core.facade.struct.ToggleCodeTableItemKey key) throws AppException,
      InformationalException {

    // Maintain codetable business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Details to be returned
    final MaintainCodeTableItem maintainCodeTableItem = new MaintainCodeTableItem();

    // Key to read codetable item details
    final CodeTableItemUniqueKey codeTableItemKey = new CodeTableItemUniqueKey();

    // Set key to read codetable
    codeTableItemKey.code = key.code;
    codeTableItemKey.tableName = key.name;
    codeTableItemKey.locale = key.languageCode;

    // Read the codetable item details
    final curam.util.administration.struct.CodeTableItemDetails codeTableItemDtls = codeTableAdminObj.readCodeTableItemDetails(
      codeTableItemKey);

    // Only the enabled value should change
    maintainCodeTableItem.isEnabled = key.enabled;

    // These values do not change
    maintainCodeTableItem.annotation = codeTableItemDtls.annotation;
    maintainCodeTableItem.code = codeTableItemDtls.code;
    maintainCodeTableItem.description = codeTableItemDtls.description;
    maintainCodeTableItem.name = codeTableItemDtls.tableName;
    maintainCodeTableItem.languageCode = codeTableItemDtls.locale;
    maintainCodeTableItem.sortOrder = codeTableItemDtls.sortOrder;
    maintainCodeTableItem.versionNo = codeTableItemDtls.versionNo;
    maintainCodeTableItem.oldCode = codeTableItemDtls.code;
    maintainCodeTableItem.oldLanguageCode = codeTableItemDtls.locale;

    modifyCodeTableItem(maintainCodeTableItem);

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyCodeTableItem(MaintainCodeTableItem details)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // CodeTableItemUniqueKey struct
    final curam.util.administration.struct.CodeTableItemUniqueKey codeTableItemKey = new curam.util.administration.struct.CodeTableItemUniqueKey();

    // Set codeTableItemKey
    codeTableItemKey.code = details.oldCode;
    codeTableItemKey.tableName = details.name;
    codeTableItemKey.locale = details.oldLanguageCode;

    final CodeTableItemUniqueKey key = new CodeTableItemUniqueKey();

    key.code = details.oldCode;
    key.tableName = details.name;
    key.locale = details.oldLanguageCode;
    final curam.util.administration.struct.CodeTableItemDetails itemDetails = codeTableAdminObj.readCodeTableItemDetails(
      key);
    // TODO Get from UI.
    int oldVersion = details.versionNo;

    if (itemDetails != null && oldVersion < itemDetails.versionNo) {
      oldVersion = itemDetails.versionNo;
    }

    // Prepare details struct
    final curam.util.administration.struct.CodeTableItemDetails codeTableItemDtls = new curam.util.administration.struct.CodeTableItemDetails();

    codeTableItemDtls.annotation = details.annotation;
    codeTableItemDtls.code = details.code;
    codeTableItemDtls.description = details.description;
    codeTableItemDtls.isEnabled = details.isEnabled;
    codeTableItemDtls.tableName = details.name;
    codeTableItemDtls.locale = details.languageCode;
    codeTableItemDtls.sortOrder = details.sortOrder;
    codeTableItemDtls.versionNo = oldVersion;

    // Modify the codetable details
    codeTableAdminObj.changeItem(codeTableItemKey, codeTableItemDtls);

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyCodeTableName(ModifyCodeTableName details)
    throws AppException, InformationalException {

    final String userLocale = TransactionInfo.getProgramLocale();

    if (!details.oldDisplayName.equals(details.newDisplayName)) {
      final CodeTableAdmin ctAdminObj = CodeTableAdminFactory.newInstance();
      final CTTranslationSearchKey key = new CTTranslationSearchKey();

      key.localeId = userLocale;
      key.tableName = details.displayNameId;
      final CTDisplayNameDetails displayNameDetails = ctAdminObj.searchTableNameByLocale(
        key);

      if (displayNameDetails == null) {
        final AddTranslationDtls translationDtls = new AddTranslationDtls();

        translationDtls.localeCode = userLocale;
        translationDtls.displayNameId = details.displayNameId;
        translationDtls.descText = details.newDisplayName;
        translationDtls.codeTableName = details.oldName;
        addTranslationDescriptionText(translationDtls);
      } else {
        final AddTranslationDtls translationDtls = new AddTranslationDtls();

        translationDtls.localeCode = userLocale;
        translationDtls.displayNameId = details.displayNameId;
        translationDtls.descText = details.newDisplayName;
        modifyTextTranslation(translationDtls);
      }
    }
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void publishCodeTableChanges() throws AppException,
      InformationalException {

    // Cache maintenance business process object
    final curam.util.administration.intf.CacheAdmin reloadCacheObj = curam.util.administration.fact.CacheAdminFactory.newInstance();

    // Publish the changes to the codetable
    reloadCacheObj.reloadCodetableCache();
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeCodeTable(CodeTableName key) throws AppException,
      InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Remove the codetable
    codeTableAdminObj.deleteCodeTable(key.name);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeCodeTableItem(RemoveCodeTableItem key)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // Prepare key for deletion
    final curam.util.administration.struct.CodeTableItemUniqueKey codeTableItemKey = new curam.util.administration.struct.CodeTableItemUniqueKey();

    codeTableItemKey.code = key.code;
    codeTableItemKey.tableName = key.name;
    codeTableItemKey.locale = key.languageCode;

    // Remove the codetable item
    codeTableAdminObj.deleteItem(codeTableItemKey);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListHierarchyDetails listHierarchies() throws AppException,
      InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableHierarchyList list = codeTableAdminObj.listCodeTableHierarchies();

    final ListHierarchyDetails returnList = new ListHierarchyDetails();

    // Copy list to return object
    for (int i = 0; i < list.dtls.size(); i++) {

      final HierarchyDetails details = new HierarchyDetails();

      details.codetable = list.dtls.item(i).codetable;
      details.description = list.dtls.item(i).description;
      details.name = list.dtls.item(i).hierarchyName;

      returnList.hierarchyDetails.addRef(details);
    }

    return returnList;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListCodetableInHierarchy listCodetablesInHierarchy(
    HierarchyName hierarchyName) throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableHeaderDetailsList list = codeTableAdminObj.listCodeTablesInHierarchy(
      hierarchyName.name);
    final ListCodetableInHierarchy returnList = new ListCodetableInHierarchy();

    // Copy list to return object
    for (int i = 0; i < list.dtls.size(); i++) {

      final CodetableInHierarchy details = new CodetableInHierarchy();

      details.name = list.dtls.item(i).tableName;
      details.parent = list.dtls.item(i).parentCodetable;
      if (i + 1 < list.dtls.size()) {
        details.child = list.dtls.item(i + 1).tableName;
      }

      returnList.codetableInHierarchy.addRef(details);
    }

    return returnList;

  }

  // BEGIN, CR00390134, JC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListCodeTableWithDisplayInHierarchy listCodetablesWithDisplayInHierarchy(HierarchyName hierarchyName)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();
    final CodeTableInHierarchyDetailsList list = codeTableAdminObj.listCodeTableDisplayDtlsInHierarchy(
      hierarchyName.name);
    final ListCodeTableWithDisplayInHierarchy returnList = new ListCodeTableWithDisplayInHierarchy();

    // Copy list to return object
    for (int i = 0; i < list.dtls.size(); i++) {
      final CodeTableWithDisplayInHierarchy details = new CodeTableWithDisplayInHierarchy();

      details.tableName = list.dtls.get(i).tableName;
      details.tableDisplay = list.dtls.get(i).displayName;
      details.parent = list.dtls.get(i).parentCodeTableName;
      details.parentDisplay = list.dtls.get(i).parentDisplay;
      details.child = list.dtls.get(i).childCodeTableName;
      details.childDisplay = list.dtls.get(i).childDisplay;

      returnList.codeTableWithDisplayInHierarchy.addRef(details);
    }

    return returnList;
  }

  // END, CR00390134

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public CodetableInHierarchy readCodetableHierarchyDetails(
    CodeTableName codetableName) throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodetableInHierarchy details = new CodetableInHierarchy();

    CodeTableHeaderDetails dtls = codeTableAdminObj.readCodeTableHeaderDetails(
      codetableName.name);

    details.name = dtls.tableName;
    details.parent = dtls.parentCodetable;

    try {
      dtls = codeTableAdminObj.readChildCodeTable(codetableName.name);
    } catch (final AppException e) {
      if (e.getCatEntry().equals(
        INFRASTRUCTURE.ID_READ_CODETABLE_CHILD_NOTFOUND)) {
        dtls.tableName = CuramConst.gkEmpty;
      } else {
        throw e;
      }
    }

    details.child = dtls.tableName;

    return details;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public HierarchyDetails readHierarchyDetails(HierarchyName name)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final HierarchyDetails details = new HierarchyDetails();

    final CodeTableHierarchyDetails dtls = codeTableAdminObj.readCodeTableHierarchyDetails(
      name.name);

    details.name = dtls.hierarchyName;
    details.description = dtls.description;
    details.codetable = dtls.codetable;

    return details;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListCodeDetails listCodes(CodeTableName codetableName)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // BEGIN - CR00368646 - get details for the logged in users locale.
    final CodeTableItemDetailsList list = codeTableAdminObj.listAllItemsForLocaleAndLanguage(
      codetableName.name, TransactionInfo.getProgramLocale());
    // END CR00368646
    final ListCodeDetails returnList = new ListCodeDetails();

    // BEGIN, CR00104811, CD
    final String parentCodetable = codeTableAdminObj.readCodeTableHeaderDetails(codetableName.name).parentCodetable;

    // Copy list to return object
    for (int i = 0; i < list.dtls.size(); i++) {

      final CodeDetails details = new CodeDetails();

      details.code = list.dtls.item(i).code;
      details.description = list.dtls.item(i).description;
      details.codetable = list.dtls.item(i).tableName;

      // the parent code description is needed
      final CodeTableItemUniqueKey key = new CodeTableItemUniqueKey();

      key.code = list.dtls.item(i).parentCode;
      key.tableName = parentCodetable;
      key.locale = list.dtls.item(i).locale;

      if (!(key.code.equals(CuramConst.gkEmpty)
        || key.tableName.equals(CuramConst.gkEmpty))) {

        try {
          final curam.util.administration.struct.CodeTableItemDetails itemDetails = codeTableAdminObj.readCodeTableItemDetails(
            key);

          details.parentCode = itemDetails.description;
        } catch (final AppException e) {
          if (e.getCatEntry().equals(
            INFRASTRUCTURE.ID_READ_CODETABLEITEM_NOTFOUND)) {
            details.parentCode = CuramConst.gkEmpty;
          } else {
            throw e;
          }
        }

      }
      // END, CR00104811

      returnList.codeDetails.addRef(details);
    }

    return returnList;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public CodeDetails readCodeDetails(ReadCodeTableItemKey key)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    uniqueKey.tableName = key.name;
    uniqueKey.locale = TransactionInfo.getProgramLocale();

    final curam.util.administration.struct.CodeTableItemDetails dtls = codeTableAdminObj.readCodeTableItemDetailsForSearch(
      uniqueKey);

    final CodeDetails details = new CodeDetails();

    details.code = dtls.code;
    details.codetable = dtls.tableName;
    details.description = dtls.description;
    details.parentCode = dtls.parentCode;

    return details;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public CodeDetails readParentCode(ReadCodeTableItemKey key)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeDetails details = new CodeDetails();

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    uniqueKey.tableName = key.name;
    // BEGIN - CR00368646 - this should be using the logged in users locale, not
    // the server default locale.
    uniqueKey.locale = TransactionInfo.getProgramLocale();
    // END - CR00368646

    curam.util.administration.struct.CodeTableItemDetails dtls = codeTableAdminObj.readCodeTableItemDetailsForSearch(
      uniqueKey);

    if (dtls.parentCode == null
      || dtls.parentCode.trim().equals(CuramConst.gkEmpty)) {
      return details;
    }

    uniqueKey.code = dtls.parentCode;
    uniqueKey.tableName = codeTableAdminObj.readCodeTableHeaderDetails(key.name).parentCodetable;

    dtls = codeTableAdminObj.readCodeTableItemDetailsForSearch(uniqueKey);

    details.code = dtls.code;
    details.codetable = dtls.tableName;
    details.description = dtls.description;
    details.parentCode = dtls.parentCode;

    return details;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public HierarchyIndicator isTopLevel(CodeTableName name)
    throws AppException, InformationalException {

    final HierarchyIndicator result = new HierarchyIndicator();

    result.ind = false;

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableHeaderDetails dtls = codeTableAdminObj.readCodeTableHeaderDetails(
      name.name);

    if (dtls.parentCodetable == null
      || dtls.parentCodetable.trim().equals(CuramConst.gkEmpty)) {
      result.ind = true;
    }

    return result;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public HierarchyIndicator isBottomLevel(CodeTableName name)
    throws AppException, InformationalException {

    final HierarchyIndicator result = new HierarchyIndicator();

    result.ind = false;

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    try {
      codeTableAdminObj.readChildCodeTable(name.name);
    } catch (final AppException e) {
      if (e.getCatEntry().equals(
        INFRASTRUCTURE.ID_READ_CODETABLE_CHILD_NOTFOUND)) {
        result.ind = true;
      } else {
        throw e;
      }
    }

    return result;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListCodeDetails listChildrenCodes(ReadCodeTableItemKey key)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final ListCodeDetails returnList = new ListCodeDetails();

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    // BEGIN - CR00368646 - this should be using the logged in users locale, not
    // the server default locale.
    uniqueKey.locale = TransactionInfo.getProgramLocale();
    // END - CR00368646
    uniqueKey.tableName = key.name;

    final CodeTableItemDetailsList list = codeTableAdminObj.listChildrenCodesForLocaleAndLanguage(
      uniqueKey);

    // Copy list to return object
    for (int i = 0; i < list.dtls.size(); i++) {
      final CodeDetails details = new CodeDetails();

      details.code = list.dtls.item(i).code;
      details.description = list.dtls.item(i).description;
      details.codetable = list.dtls.item(i).tableName;

      returnList.codeDetails.addRef(details);
    }

    return returnList;
  }

  // BEGIN, CR00392403, JC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListCodeDetailsAndDisplayName listChildrenCodesAndDisplayName(
    ReadCodeTableItemKey key) throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final ListCodeDetailsAndDisplayName returnList = new ListCodeDetailsAndDisplayName();

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    uniqueKey.locale = TransactionInfo.getProgramLocale();
    uniqueKey.tableName = key.name;

    final CodeTableItemAndDisplayDtlsList list = codeTableAdminObj.listChildrenCodesWithDisplayNameForLocale(
      uniqueKey);

    // Copy list to return object
    for (int i = 0; i < list.dtls.size(); i++) {
      final CodeDetailsAndDisplayName details = new CodeDetailsAndDisplayName();

      details.code = list.dtls.item(i).code;
      details.description = list.dtls.item(i).description;
      details.codetable = list.dtls.item(i).tableName;
      details.displayName = list.dtls.item(i).displayName;

      returnList.codeDetailsAndDisplayName.addRef(details);
    }

    return returnList;
  }

  // END, CR00392403

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListSelectedCodes listChildrenCodesForModification(
    ReadCodeTableItemKey key) throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // BEGIN - CR00368646
    final CodeTableItemDetailsList listUnlinked = codeTableAdminObj.listUnlinkedCodesForLocaleAndLanguage(
      key.name, TransactionInfo.getProgramLocale());
    // END - CR00368646

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    uniqueKey.tableName = key.name;
    // BEGIN - CR00368646
    uniqueKey.locale = TransactionInfo.getProgramLocale();

    final CodeTableItemDetailsList listCurrentChildren = codeTableAdminObj.listChildrenCodesForLocaleAndLanguage(
      uniqueKey);
    // END - CR00368646
    String initial = CuramConst.gkEmpty;

    final ListSelectedCodes tempList = new ListSelectedCodes();
    CodeDetails details = null;
    final TreeSet<String> values = new TreeSet<String>();

    for (int i = 0; i < listUnlinked.dtls.size(); i++) {
      details = new CodeDetails();
      details.description = listUnlinked.dtls.item(i).description;
      details.code = listUnlinked.dtls.item(i).code;

      tempList.codeDetails.addRef(details);
      values.add(details.code);
    }

    for (int i = 0; i < listCurrentChildren.dtls.size(); i++) {
      details = new CodeDetails();
      details.description = listCurrentChildren.dtls.item(i).description;
      details.code = listCurrentChildren.dtls.item(i).code;
      if (!initial.equals(CuramConst.gkEmpty)) {
        initial += GeneralConstants.kTab;
      }
      initial += details.code;

      tempList.codeDetails.addRef(details);
      values.add(details.code);
    }

    // sort
    final ListSelectedCodes returnList = new ListSelectedCodes();

    for (final Iterator<String> iter = values.iterator(); iter.hasNext();) {
      final String val = iter.next();

      for (int i = 0; i < tempList.codeDetails.size(); i++) {
        details = tempList.codeDetails.item(i);
        if (details.code.equals(val)) {
          returnList.codeDetails.addRef(details);
        }
      }

    }

    returnList.initialString = initial;

    return returnList;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public PopupParams modifyChildrenCodes(ReadCodeTableItemKey key,
    TabDelimitedString initialStr, TabDelimitedString newStr,
    PopupParams popupParams) throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    uniqueKey.tableName = key.name;
    uniqueKey.locale = ProgramLocale.getDefaultServerLocale();

    final String[] initial = initialStr.string.split(GeneralConstants.kTab);
    final String[] modified = newStr.string.split(GeneralConstants.kTab);

    final ArrayList<String> result = new ArrayList<String>();

    // BEGIN, CR00148823, SR
    // iterate through the new list, if an item in the new list is not
    // in the existing list, then add to the resulting list.
    for (int i = 0; i < modified.length; i++) {
      boolean found = false;

      for (int j = 0; j < initial.length; j++) {
        if (modified[i].equalsIgnoreCase(initial[j])) {
          found = true;
          break;
        }
      }
      if (!found) {
        // add to resulting list
        result.add(modified[i]);
      }
    } // end iterating through the new list

    // iterate through the existing list, if an item in the existing list is
    // not in the new list, then add to the resulting list.
    for (int i = 0; i < initial.length; i++) {
      boolean found = false;

      for (int j = 0; j < modified.length; j++) {
        if (initial[i].equalsIgnoreCase(modified[j])) {
          found = true;
          break;
        }
      }
      if (!found) {
        result.add(initial[i]);
      }
    } // end iterating through the existing list.
    // END, CR00148823, SR

    // Update the child codes with any new codes and delete codes that may
    // have been removed.
    for (int i = 0; i < result.size(); i++) {
      codeTableAdminObj.modifyChildCode(uniqueKey, result.get(i));
    }

    return popupParams;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public PopupParams modifyParentCode(ReadCodeTableItemKey key,
    CodeDetails newParentCode, PopupParams popupParams) throws AppException,
      InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    final CodeTableItemUniqueKey uniqueKey = new CodeTableItemUniqueKey();

    uniqueKey.code = key.code;
    uniqueKey.tableName = key.name;
    uniqueKey.locale = ProgramLocale.getDefaultServerLocale();

    codeTableAdminObj.modifyParentCode(uniqueKey, newParentCode.code);

    return popupParams;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListCodeDetails listPotentialParentCodes(CodeTableName name)
    throws AppException, InformationalException {

    // Codetable maintenance business process object
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    // BEGIN - CR00368646
    // changing to get details for the logged in users locale as opposed to the
    // server default locale.
    final CodeTableItemDetailsList list = codeTableAdminObj.listAllItemsForLocaleAndLanguage(
      name.name, TransactionInfo.getProgramLocale());
    // END - CR00368646

    final ListCodeDetails returnList = new ListCodeDetails();

    for (int i = 0; i < list.dtls.size(); i++) {
      final CodeDetails details = new CodeDetails();

      details.code = list.dtls.item(i).code;
      details.description = list.dtls.item(i).description;

      returnList.codeDetails.addRef(details);
    }

    return returnList;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public SecurityRoleKey createSecurityRole(CreateSecurityRoleDetails details)
    throws AppException, InformationalException {

    if (details.roleName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYROLE_FV_NAME_EMPTY);
    }
    // BEGIN, CR00190252, NP
    validateSecurityRoleName(details.roleName.trim());
    // END, CR00190252

    // Create the return object
    final SecurityRoleKey securityRoleKey = new SecurityRoleKey();

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create the new security role
    securityRoleKey.roleID = securityAdministrationObj.createSecurityRole(
      details.roleName);

    return securityRoleKey;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListSecurityRoleDetails listSecurityRole() throws AppException,
      InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // The object to be returned
    final ListSecurityRoleDetails listSecurityRoleDetails = new ListSecurityRoleDetails();

    // SecurityRoleDetails object
    SecurityRoleDetails securityRoleDetails;

    // Add list to return object
    for (int i = 0; i
      < securityAdministrationObj.listAllSecurityRoles().dtls.size(); i++) {

      // Instance of security role object
      securityRoleDetails = new SecurityRoleDetails();

      // Assign the relevant values
      securityRoleDetails.roleID = securityAdministrationObj.listAllSecurityRoles().dtls.item(i).roleID;
      securityRoleDetails.roleName = securityAdministrationObj.listAllSecurityRoles().dtls.item(i).roleName;
      securityRoleDetails.versionNo = securityAdministrationObj.listAllSecurityRoles().dtls.item(i).versionNo;

      // Add details to list
      listSecurityRoleDetails.securityRoleListDetails.addRef(
        securityRoleDetails);
    }

    return listSecurityRoleDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifySecurityRole(SecurityRoleDetails details)
    throws AppException, InformationalException {

    if (details.roleName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYROLE_FV_NAME_EMPTY);
    }
    // BEGIN, CR00190252, NP
    validateSecurityRoleName(details.roleName.trim());
    // END, CR00190252

    // SecurityAdministration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create an instance of the SecurityRoleDetails object
    final curam.util.administration.struct.SecurityRoleDetails securityRoleDetails = new curam.util.administration.struct.SecurityRoleDetails();

    // Assign security role details
    securityRoleDetails.roleID = details.roleID;
    securityRoleDetails.roleName = details.roleName;
    securityRoleDetails.versionNo = details.versionNo;

    // BEGIN, CR00442409, MP
    // Modify the security role
    securityAdministrationObj.modifySecurityRole(securityRoleDetails);
    final RoleNameWrapperIdx roleName = new RoleNameWrapperIdx();
    final UpperRoleNameWrapperStruct upperRoleName = new UpperRoleNameWrapperStruct();

    roleName.roleName = details.roleName;
    upperRoleName.upperRoleName = details.roleName.toUpperCase();
    
    //BEGIN, WI226406, YF
    //Try to find and modify role name in existing user records
    try{
      UsersFactory.newInstance().modifySecurityUpperRoleNames(roleName,
        upperRoleName);
      
    } catch (RecordNotFoundException e){
      
      //Continue if no user records were found
    }
    //END, WI226406, YF
   

    // END, CR00442409
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadSecurityRoleForModify readSecurityRoleForModify(
    SecurityRoleKey key) throws AppException, InformationalException {

    // Create the object to be returned
    final ReadSecurityRoleForModify readSecurityRoleForModify = new ReadSecurityRoleForModify();

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create SecurityRoleGroupDetails object
    curam.util.administration.struct.SecurityRoleGroupDetails securityRoleGroupDetails;

    // Read the security role details
    securityRoleGroupDetails = securityAdministrationObj.readSecurityRoleDetails(
      key.roleID);

    // Assign the security role details to the return object
    readSecurityRoleForModify.securityRoleDetails.roleID = securityRoleGroupDetails.securityRoleDetails.roleID;
    readSecurityRoleForModify.securityRoleDetails.roleName = securityRoleGroupDetails.securityRoleDetails.roleName;
    readSecurityRoleForModify.securityRoleDetails.versionNo = securityRoleGroupDetails.securityRoleDetails.versionNo;

    return readSecurityRoleForModify;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeGroupFromRole(RemoveGroupFromRole key)
    throws AppException, InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Remove the group from the role
    securityAdministrationObj.removeGroupFromRole(key.roleID, key.groupID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadSecurityRole readSecurityRole(SecurityRoleKey key)
    throws AppException, InformationalException {

    // Create the return object
    final ReadSecurityRole readSecurityRole = new ReadSecurityRole();

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create the SecurityRoleGroupDetails object
    curam.util.administration.struct.SecurityRoleGroupDetails securityRoleGroupDetails;

    // Read the security role details
    securityRoleGroupDetails = securityAdministrationObj.readSecurityRoleDetails(
      key.roleID);

    // Add security role details
    readSecurityRole.securityRoleDetails.roleID = securityRoleGroupDetails.securityRoleDetails.roleID;
    readSecurityRole.securityRoleDetails.roleName = securityRoleGroupDetails.securityRoleDetails.roleName;
    readSecurityRole.securityRoleDetails.versionNo = securityRoleGroupDetails.securityRoleDetails.versionNo;

    // Security group details facade object reference
    SecurityGroupDetails securityGroupDetails;

    // Add list of groups in role
    curam.util.administration.struct.SecurityGroupDetailsList securityGroupDetailsList = securityRoleGroupDetails.securityGroupDetailsList;

    for (int i = 0; i < securityGroupDetailsList.dtls.size(); i++) {

      // new instance of security group details facade object
      securityGroupDetails = new SecurityGroupDetails();

      securityGroupDetails.groupID = securityGroupDetailsList.dtls.item(i).groupID;
      securityGroupDetails.groupName = securityGroupDetailsList.dtls.item(i).groupName;
      securityGroupDetails.groupDescription = securityGroupDetailsList.dtls.item(i).description;
      securityGroupDetails.versionNo = securityGroupDetailsList.dtls.item(i).versionNo;

      readSecurityRole.listGroupsInRole.securityGroupDetails.addRef(
        securityGroupDetails);
    }

    // Add list of groups not in role
    securityGroupDetailsList = securityAdministrationObj.listGroupsNotInRole(
      key.roleID);

    for (int i = 0; i < securityGroupDetailsList.dtls.size(); i++) {

      // new instance of security group details facade object
      securityGroupDetails = new SecurityGroupDetails();

      securityGroupDetails.groupID = securityGroupDetailsList.dtls.item(i).groupID;
      securityGroupDetails.groupName = securityGroupDetailsList.dtls.item(i).groupName;
      securityGroupDetails.groupDescription = securityGroupDetailsList.dtls.item(i).description;
      securityGroupDetails.versionNo = securityGroupDetailsList.dtls.item(i).versionNo;

      readSecurityRole.listGroupsNotInRole.securityGroupDetails.addRef(
        securityGroupDetails);
    }

    return readSecurityRole;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void addGroupsToRole(AddGroupsToRole details) throws AppException,
      InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Add the group(s) to the role
    securityAdministrationObj.addGroupsToRole(details.securityRoleKey.roleID,
      details.groupTabList.groupTabList);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeSecurityRole(RemoveSecurityRole key) throws AppException,
      InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Delete the security role
    securityAdministrationObj.deleteSecurityRole(key.roleID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public SecurityGroupKey createSecurityGroup(SecurityGroupDetails details)
    throws AppException, InformationalException {

    if (details.groupName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYGROUP_FV_NAME_EMPTY);
    }

    // Create a SecurityGroupKey return object
    final SecurityGroupKey securityGroupKey = new SecurityGroupKey();

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create NewSecurityGroupDetails object
    final curam.util.administration.struct.NewSecurityGroupDetails newSecurityGroupDetails = new curam.util.administration.struct.NewSecurityGroupDetails();

    // Set groupName and groupDescription to create security group
    newSecurityGroupDetails.groupName = details.groupName;
    newSecurityGroupDetails.description = details.groupDescription;

    // Create the new security group
    securityGroupKey.groupID = securityAdministrationObj.createSecurityGroup(
      newSecurityGroupDetails);

    return securityGroupKey;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListSecurityGroupDetails listSecurityGroup() throws AppException,
      InformationalException {

    // Create return object
    final ListSecurityGroupDetails listSecurityGroupDetails = new ListSecurityGroupDetails();

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create a SecurityGroupDetailsList object
    curam.util.administration.struct.SecurityGroupDetailsList securityGroupDetailsList;

    // Create a SecurityGroupDetails object
    SecurityGroupDetails securityGroupDetails;

    // Retrieve the list of group names
    securityGroupDetailsList = securityAdministrationObj.listAllSecurityGroups();

    // Copy list to return object
    for (int i = 0; i < securityGroupDetailsList.dtls.size(); i++) {

      securityGroupDetails = new SecurityGroupDetails();

      securityGroupDetails.groupID = securityGroupDetailsList.dtls.item(i).groupID;
      securityGroupDetails.groupName = securityGroupDetailsList.dtls.item(i).groupName;
      securityGroupDetails.groupDescription = securityGroupDetailsList.dtls.item(i).description;

      listSecurityGroupDetails.securityGroupDetails.addRef(securityGroupDetails);
    }

    return listSecurityGroupDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifySecurityGroup(SecurityGroupDetails details)
    throws AppException, InformationalException {

    if (details.groupName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYGROUP_FV_NAME_EMPTY);
    }

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create a NewSecurityGroupDetails object
    final curam.util.administration.struct.NewSecurityGroupDetails newSecurityGroupDetails = new curam.util.administration.struct.NewSecurityGroupDetails();

    // Map the new security group details into the NewSecurityGroupDetails
    // object
    newSecurityGroupDetails.description = details.groupDescription;
    newSecurityGroupDetails.groupName = details.groupName;
    newSecurityGroupDetails.versionNo = details.versionNo;

    // Modify security group details
    securityAdministrationObj.modifySecurityGroup(details.groupID,
      newSecurityGroupDetails);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadSecurityGroupForModify readSecurityGroupForModify(
    SecurityGroupKey key) throws AppException, InformationalException {

    // Create a return object
    final ReadSecurityGroupForModify readSecurityGroupForModify = new ReadSecurityGroupForModify();

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create a SecurityGroupSIDDetails object
    curam.util.administration.struct.SecurityGroupSIDDetails securityGroupSIDDetails;

    // Read the security group details into the SecurityGroupSIDDetails
    // object
    securityGroupSIDDetails = securityAdministrationObj.readSecurityGroupDetails(
      key.groupID);

    // Read the security group details into the return object
    readSecurityGroupForModify.securityGroupDetails.groupID = securityGroupSIDDetails.securityGroupDetails.groupID;
    readSecurityGroupForModify.securityGroupDetails.groupName = securityGroupSIDDetails.securityGroupDetails.groupName;
    readSecurityGroupForModify.securityGroupDetails.groupDescription = securityGroupSIDDetails.securityGroupDetails.description;
    readSecurityGroupForModify.securityGroupDetails.versionNo = securityGroupSIDDetails.securityGroupDetails.versionNo;

    return readSecurityGroupForModify;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeSIDFromGroup(RemoveSIDFromGroup key) throws AppException,
      InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Remove the security identifier from the group
    securityAdministrationObj.removeSIDFromGroup(key.groupID,
      key.securityIdentifierID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeSecurityGroup(RemoveSecurityGroup key)
    throws AppException, InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Remove the security group
    securityAdministrationObj.deleteSecurityGroup(key.groupID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadSecurityGroup readSecurityGroup(SecurityGroupKey key)
    throws AppException, InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Create a ReadSecurityGroup return object
    final ReadSecurityGroup readSecurityGroup = new ReadSecurityGroup();

    // Add the groupID to the return object
    readSecurityGroup.securityGroupDetails.groupID = key.groupID;

    // Create a SecurityIdentifierDetailsList object
    curam.util.administration.struct.SecurityIdentifierDetailsList securityIdenifierDetailsList;

    // Create a SecurityGroupSIDDetails object
    curam.util.administration.struct.SecurityGroupSIDDetails securityGroupSIDDetails;

    // Create a SecurityIdentifierDetails object
    SecurityIdentifierDetails securityIdentifierDetails;

    // Read the security group details
    securityGroupSIDDetails = securityAdministrationObj.readSecurityGroupDetails(
      key.groupID);

    // Map securityGroupDetails to output struct
    readSecurityGroup.securityGroupDetails.groupID = securityGroupSIDDetails.securityGroupDetails.groupID;
    readSecurityGroup.securityGroupDetails.groupName = securityGroupSIDDetails.securityGroupDetails.groupName;
    readSecurityGroup.securityGroupDetails.groupDescription = securityGroupSIDDetails.securityGroupDetails.description;

    // Copy list of security identifiers in the group to return object
    for (int i = 0; i
      < securityGroupSIDDetails.securityIdentifierDetailsList.dtls.size(); i++) {

      securityIdentifierDetails = new SecurityIdentifierDetails();

      securityIdentifierDetails.securityIdentifierID = securityGroupSIDDetails.securityIdentifierDetailsList.dtls.item(i).securityIdentifierID;
      securityIdentifierDetails.sidName = securityGroupSIDDetails.securityIdentifierDetailsList.dtls.item(i).securityIdentifierName;
      securityIdentifierDetails.sidDescription = securityGroupSIDDetails.securityIdentifierDetailsList.dtls.item(i).description;
      securityIdentifierDetails.sidType = securityGroupSIDDetails.securityIdentifierDetailsList.dtls.item(i).type;

      readSecurityGroup.listSecurityIdentifiersInGroup.securityIdentifierDetails.addRef(
        securityIdentifierDetails);
    }

    // Read the SID's not in the group
    securityIdenifierDetailsList = securityAdministrationObj.listSIDsNotInGroup(
      key.groupID);

    // Copy list of security identifiers not in the group to return object
    for (int i = 0; i < securityIdenifierDetailsList.dtls.size(); i++) {

      securityIdentifierDetails = new SecurityIdentifierDetails();

      securityIdentifierDetails.securityIdentifierID = securityIdenifierDetailsList.dtls.item(i).securityIdentifierID;
      securityIdentifierDetails.sidName = securityIdenifierDetailsList.dtls.item(i).securityIdentifierName;
      securityIdentifierDetails.sidDescription = securityIdenifierDetailsList.dtls.item(i).description;
      securityIdentifierDetails.sidType = securityIdenifierDetailsList.dtls.item(i).type;

      readSecurityGroup.listSecurityIdentifiersNotInGroup.securityIdentifierDetails.addRef(
        securityIdentifierDetails);
    }

    return readSecurityGroup;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createSecurityIdentifier(CreateSecurityIdentifier details)
    throws AppException, InformationalException {

    if (details.sidName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYIDENTIFIER_FV_NAME_EMPTY);
    }

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Struct passed to SecurityAdministration createSecurityIdentifier
    final curam.util.administration.struct.NewSecurityIdentifierDetails newSecurityIdentifierDetails = new curam.util.administration.struct.NewSecurityIdentifierDetails();

    // Setup key for createSecurityIdentifier operation
    newSecurityIdentifierDetails.securityIdentifierName = details.sidName;
    newSecurityIdentifierDetails.type = details.sidType;
    newSecurityIdentifierDetails.description = details.sidDescription;

    // The security identifier key returned from the create.
    final SecurityIdentifierKey securityIdentifierKey = new SecurityIdentifierKey();

    // Create Security Identifier
    securityIdentifierKey.securityIdentifierID = securityAdministrationObj.createSecurityIdentifier(
      newSecurityIdentifierDetails);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListSecurityIdentifierDetails listSecurityIdentifier()
    throws AppException, InformationalException {

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Details to be returned
    final ListSecurityIdentifierDetails listSecurityIdentifierDetails = new ListSecurityIdentifierDetails();

    // Retrieve list of security identifiers
    curam.util.administration.struct.SecurityIdentifierDetailsList securityIdentifierDetailsList;

    securityIdentifierDetailsList = securityAdministrationObj.listAllSecurityIdentifiers();

    // Copy list to return object
    for (int i = 0; i < securityIdentifierDetailsList.dtls.size(); i++) {

      final SecurityIdentifierDetails securityIdentifierDetails = new SecurityIdentifierDetails();

      securityIdentifierDetails.securityIdentifierID = securityIdentifierDetailsList.dtls.item(i).securityIdentifierID;
      securityIdentifierDetails.sidName = securityIdentifierDetailsList.dtls.item(i).securityIdentifierName;
      securityIdentifierDetails.sidDescription = securityIdentifierDetailsList.dtls.item(i).description;
      securityIdentifierDetails.sidType = securityIdentifierDetailsList.dtls.item(i).type;

      listSecurityIdentifierDetails.securityIdenfifierDetails.addRef(
        securityIdentifierDetails);
    }

    // Return details
    return listSecurityIdentifierDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifySecurityIdentifier(ModifySecurityIdentifier details)
    throws AppException, InformationalException {

    if (details.sidName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYIDENTIFIER_FV_NAME_EMPTY);
    }

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Struct passed to SecurityAdministration changeIdentifier
    final curam.util.administration.struct.SecurityIdentifierNameDescription securityIdentifierNameDescription = new curam.util.administration.struct.SecurityIdentifierNameDescription();

    // Setup key for changeIndentifier operation
    securityIdentifierNameDescription.versionNo = details.versionNo;
    securityIdentifierNameDescription.securityIdentifierName = details.sidName;
    securityIdentifierNameDescription.description = details.sidDescription;

    // Modify security identifier
    securityAdministrationObj.modifySecurityIdentifier(
      details.securityIdentifierID, securityIdentifierNameDescription);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadSecurityIdentfier readSecurityIdentifier(
    SecurityIdentifierKey key) throws AppException, InformationalException {

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Details to be returned
    final ReadSecurityIdentfier readSecurityIdentfier = new ReadSecurityIdentfier();

    // Details returned from readSecurityIdentifier operation
    curam.util.administration.struct.SecurityIdentifierWithFIDDetails securityIdentifierWithFIDDetails;

    // Read security identifier details
    securityIdentifierWithFIDDetails = securityAdministrationObj.readSecurityIdentifier(
      key.securityIdentifierID);

    // Assign details to return struct
    readSecurityIdentfier.sidName = securityIdentifierWithFIDDetails.securityIdentifierName;
    readSecurityIdentfier.sidType = securityIdentifierWithFIDDetails.type;
    readSecurityIdentfier.sidDescription = securityIdentifierWithFIDDetails.description;
    readSecurityIdentfier.versionNo = securityIdentifierWithFIDDetails.versionNo;
    if (securityIdentifierWithFIDDetails.functionIdentifier != null) {
      readSecurityIdentfier.functionIdentifier = securityIdentifierWithFIDDetails.functionIdentifier;
    }

    // Return Details
    return readSecurityIdentfier;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * This method removes a security identifier
   *
   * @param key
   * Key of public office to be removed
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public void removeSecurityIdentifier(SecurityIdentifierKey key)
    throws AppException, InformationalException {

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Delete the security identifier

    securityAdministrationObj.deleteSecurityIdentifier(key.securityIdentifierID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void addSIDsToGroup(AddSIDsToGroup details) throws AppException,
      InformationalException {

    // Security Administration BPO
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Add the security identifiers to the security group
    securityAdministrationObj.addSIDsToGroup(details.sidTabList.sidTabList,
      details.securityGroupKey.groupID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createFunctionSID(CreateFunctionSIDDetails details)
    throws AppException, InformationalException {

    if (details.sidName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYIDENTIFIER_FV_NAME_EMPTY);
    }

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Parameters passed to securityAdministrationObj::createFunctionSID
    String functionID;
    final curam.util.administration.struct.SecurityIdentifierNameDescription securityIdentifierNameDescription = new SecurityIdentifierNameDescription();

    // Begin CR00086631, MC
    if (details.functionIdentifierID.trim().length() == 0) {
      throw new AppException(
        curam.message.BPOSYSTEM.ERR_SECURITYIDENTIFIER_FV_FUNCTION_EMPTY);
    }
    // End CR00086631
    // Get the functionIdentifierID from the details
    functionID = details.functionIdentifierID;

    // Populate details for createFunctionSID operation
    securityIdentifierNameDescription.securityIdentifierName = details.sidName;
    securityIdentifierNameDescription.description = details.sidDescription;
    securityIdentifierNameDescription.versionNo = details.versionNo;

    // Create the Function Security Identifier
    securityAdministrationObj.createFunctionSID(functionID,
      securityIdentifierNameDescription);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void publishSecurityChanges() throws AppException,
      InformationalException {

    // reload cache business process object
    final curam.util.administration.intf.CacheAdmin reloadCacheObj = curam.util.administration.fact.CacheAdminFactory.newInstance();

    // reload security cache
    reloadCacheObj.reloadSecurityCache();
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void checkInTemplate(CheckInTemplateDetails details)
    throws AppException, InformationalException {

    // XSLTemplate server object.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    // Details passed to checkInTemplate.
    final CheckInTemplateDtls checkInTemplateDtls = new CheckInTemplateDtls();

    // Assign the check out details.
    checkInTemplateDtls.ciComment = details.checkInComment;
    checkInTemplateDtls.document = details.document;
    checkInTemplateDtls.override = details.override;
    checkInTemplateDtls.templateID = details.templateID;

    // BEGIN, CR00145315, SK
    checkInTemplateDtls.locale = details.localeIdentifier;
    // END, CR00145315
    // Call the check in template method.
    xslTemplateSCMObj.checkInTemplate(checkInTemplateDtls);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public GetTemplateDetails checkOutTemplate(CheckOutTemplateDetails details)
    throws AppException, InformationalException {

    // XSLTemplateSCM server object.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    // XSL template objects
    final XSLTemplateID xslTemplateKey = new XSLTemplateID();
    XSLGetTemplateDetails xslGetTemplateDetails;
    XSLTemplateInstDetails xslTemplateInstDetails;

    // Return object
    final GetTemplateDetails getTemplateDetails = new GetTemplateDetails();

    // Details passed to checkOutTemplate.
    final CheckOutTemplateDtls checkOutTemplateDtls = new CheckOutTemplateDtls();

    // Assign the check out details.
    checkOutTemplateDtls.coComment = details.checkOutComment;
    checkOutTemplateDtls.fileName = details.fileName;
    checkOutTemplateDtls.override = details.overrideInd;
    checkOutTemplateDtls.templateID = details.templateID;
    checkOutTemplateDtls.templateVersion = details.templateVersion;
    // BEGIN, CR00145315, SK
    checkOutTemplateDtls.locale = details.localeIdentifier;
    // END, CR00145315

    // Call the check out template method.
    xslTemplateInstDetails = xslTemplateSCMObj.checkOutTemplate(
      checkOutTemplateDtls);

    // Get the document contents
    getTemplateDetails.document = xslTemplateInstDetails.document;

    // Get the document name
    xslTemplateKey.templateID = details.templateID;
    // BEGIN, CR00145315, SK
    xslTemplateKey.locale = details.localeIdentifier;
    // END, CR00145315
    xslGetTemplateDetails = xslTemplateSCMObj.getTemplateDetails(xslTemplateKey);

    getTemplateDetails.templateName = xslGetTemplateDetails.fileName;

    return getTemplateDetails;

  }

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Inserts a new XSL template record onto the database.
   *
   * @param details
   * The template details being created.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSYSTEM#ERR_DESCRIPTION_FV_DETAILS_EMPTY
   * ERR_DESCRIPTION_FV_DETAILS_EMPTY}-if description is empty.
   * @throws AppException
   * {@link BPOSYSTEM#ERR_DOCUMENT_FV_DETAILS_EMPTY
   * ERR_DOCUMENT_FV_DETAILS_EMPTY}-if document details is empty.
   * @deprecated Since Curam 6.0, replaced by {@link #createTemplate1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public void createTemplate(CreateTemplateDetails details) throws AppException,
      InformationalException {

    final CreateTemplateDetails1 createTemplateDetails = new CreateTemplateDetails1();

    createTemplateDetails.assign(details);
    createTemplate1(createTemplateDetails);

  }

  // END, CR00240340

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Returns all the version numbers of a specified template.
   *
   * @param key
   * The template ID.
   *
   * @return The list of templates versions returned from the database.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #getTemplateVersions1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public ListTemplateVersions getTemplateVersions(
    curam.core.facade.struct.XSLTemplateKey key) throws AppException,
      InformationalException {

    final XSLTemplateKey1 xslTemplateKey = new XSLTemplateKey1();

    xslTemplateKey.assign(key);

    return getTemplateVersions1(xslTemplateKey);

  }

  // END, CR00240340

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Return details of all available XSL templates.
   *
   * @return The list of templates returned from the database.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #listTemplate1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public ListTemplateDetails listTemplate() throws AppException,
      InformationalException {

    final ListTemplateDetails listTemplateDetails = new ListTemplateDetails();

    listTemplateDetails.assign(listTemplate1());

    // Return the list of templates.
    return listTemplateDetails;
  }

  // END, CR00240340

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Modifies details of a template.
   *
   * @param details
   * The details of the template that are to be modified.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSYSTEM#ERR_DESCRIPTION_FV_DETAILS_EMPTY
   * ERR_DESCRIPTION_FV_DETAILS_EMPTY}-if description details is
   * empty.
   * @deprecated Since Curam 6.0, replaced by {@link #modifyTemplate1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public void modifyTemplate(ModifyTemplateDetails details) throws AppException,
      InformationalException {

    final ModifyTemplateDetails1 modifyTemplateDetails = new ModifyTemplateDetails1();

    modifyTemplateDetails.assign(details);

    modifyTemplate1(modifyTemplateDetails);

  }

  // END, CR00240340

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Returns details of an XSL template.
   *
   * @param key
   * Identifier of the template
   *
   * @return The XSL template details
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #readTemplate1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public ReadTemplateDetails readTemplate(XSLTemplateKey key) throws AppException,
      InformationalException {

    final ReadTemplateDetails readTemplateDetails = new ReadTemplateDetails();

    final XSLTemplateKey1 xslTemplateKey = new XSLTemplateKey1();

    xslTemplateKey.assign(key);
    readTemplateDetails.assign(readTemplate1(xslTemplateKey));

    // Return the template details.
    return readTemplateDetails;
  }

  // END, CR00240340

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void undoCheckOutTemplate(UndoCheckOutTemplate key)
    throws AppException, InformationalException {

    // XSLTemplate server object and key.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    // The undo template check out details.
    final UndoCheckOutTemplateDtls undoCheckOutTemplateDtls = new UndoCheckOutTemplateDtls();

    // Assign the details.
    undoCheckOutTemplateDtls.override = key.overrideInd;
    undoCheckOutTemplateDtls.templateID = key.templateID;
    // BEGIN, CR00145315, SK
    undoCheckOutTemplateDtls.locale = key.localeIdentifier;
    // END, CR00145315
    // Undo the template check out.
    xslTemplateSCMObj.undoCheckOutTemplate(undoCheckOutTemplateDtls);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListUnassignedFIDs listAllUnassignedFids() throws AppException,
      InformationalException {

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Details to be returned
    final ListUnassignedFIDs listUnassignedFIDs = new ListUnassignedFIDs();

    // Retrieve list of unassigned functions
    curam.util.administration.struct.FunctionIdentifierDetailsList functionIdentifierDetailsList;

    functionIdentifierDetailsList = securityAdministrationObj.listAvailableFIDs();

    // Copy list to return object
    for (int i = 0; i < functionIdentifierDetailsList.dtls.size(); i++) {

      final FIDName fidName = new FIDName();

      fidName.fidName = functionIdentifierDetailsList.dtls.item(i).functionName;

      listUnassignedFIDs.dtls.addRef(fidName);
    }

    // Return details
    return listUnassignedFIDs;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public BatchProcessDetails readBatchProcess(ReadBatchProcessKey key)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcReqInterfaceObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final BatchProcessDetails batchProcessDetails = new BatchProcessDetails();

    // Create a struct to contain batch process and parameter details
    curam.util.administration.struct.BatchProcessAndParamDetails batchProcessAndParamDetails;

    // Read the batch process details
    batchProcessAndParamDetails = batchProcReqInterfaceObj.getBatchProcessDetails(
      key.processDefName);

    // Copy details to return object
    batchProcessDetails.batchType = batchProcessAndParamDetails.batchType;
    batchProcessDetails.description = batchProcessAndParamDetails.description;
    batchProcessDetails.longName = batchProcessAndParamDetails.longName;
    batchProcessDetails.processDefName = batchProcessAndParamDetails.processDefName;
    batchProcessDetails.versionNo = batchProcessAndParamDetails.versionNo;

    // Return Details
    return batchProcessDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListProcessWithoutDesc listBatchProcessesWithoutDesc()
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListProcessWithoutDesc listProcessWithoutDesc = new ListProcessWithoutDesc();

    // Create batch parameter details list struct
    curam.util.administration.struct.BatchProcDetList batchProcDetList;

    // Retrieve the list of batch processes
    batchProcDetList = batchProcessModifyObj.getBatchProcessesWithoutDesc();

    if (batchProcDetList.dtls.size() <= 0) {
      final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        curam.message.BPOSYSTEM.IF_PROCDEF_FV_EXECUTABLE_EMPTY);

      informationalManager.addInformationalMsg(e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning);

      // Obtain the informational(s) to be returned to the client
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        listProcessWithoutDesc.InformationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);

      }

    }
    // Copy list to return object
    for (int i = 0; i < batchProcDetList.dtls.size(); i++) {

      final BatchProcessDefinitionName batchProcessDefinitionName = new BatchProcessDefinitionName();

      batchProcessDefinitionName.processDefName = batchProcDetList.dtls.item(i).processDefName;

      listProcessWithoutDesc.dtls.addRef(batchProcessDefinitionName);
    }

    // Return details
    return listProcessWithoutDesc;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListParameter listParameter(RetrieveProcessParametersKey key)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListParameter listParameter = new ListParameter();

    // Create batch parameter description list struct
    curam.util.administration.struct.BatchParamDescDetList batchParamDescDetList;

    // Retrieve the list of parameters
    batchParamDescDetList = batchProcessModifyObj.retrieveParamList(
      key.processDefName);

    // Copy list to return object
    for (int i = 0; i < batchParamDescDetList.dtls.size(); i++) {

      final ParameterDetails parameterDetails = new ParameterDetails();

      parameterDetails.defaultCode = batchParamDescDetList.dtls.item(i).defaultValue;
      parameterDetails.description = batchParamDescDetList.dtls.item(i).description;
      parameterDetails.paramName = batchParamDescDetList.dtls.item(i).paramName;
      parameterDetails.versionNo = batchParamDescDetList.dtls.item(i).versionNo;

      listParameter.parameterDetails.addRef(parameterDetails);
    }

    // Return details
    return listParameter;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ParameterDetails readBatchParameterDetails(ReadParameterDetails key)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ParameterDetails parameterDetails = new ParameterDetails();

    // Create struct for batch parameter description details
    curam.util.administration.struct.BatchParamDescriptionDetails batchParamDescDtls;

    // Read the parameter details
    batchParamDescDtls = batchProcessModifyObj.readParameterDetails(
      key.processDefName, key.paramName);

    // Copy details to return object
    parameterDetails.defaultCode = batchParamDescDtls.defaultValue;
    parameterDetails.description = batchParamDescDtls.description;
    parameterDetails.paramName = batchParamDescDtls.paramName;
    parameterDetails.versionNo = batchParamDescDtls.versionNo;
    parameterDetails.paramLongName = batchParamDescDtls.paramLongName;

    // Return details
    return parameterDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeProcessFromGroup(GroupProcessDetails key)
    throws AppException, InformationalException {

    // Batch group maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessGroupsObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Remove the batch process from the group
    batchProcessGroupsObj.removeProcessFromGroup(key.groupID,
      key.processDefName);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createBatchGroup(CreateBatchGroupDetails details)
    throws AppException, InformationalException {

    // Batch group maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessGroupsObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Create the batch group
    batchProcessGroupsObj.addGroup(details.groupName);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createBatchProcess(BatchProcessDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00049218, GM
    if (details.processDefName == null
      || details.processDefName.equals(CuramConst.gkEmpty)) {
      // END, CR00049218
      throw new AppException(
        curam.message.BPOSYSTEM.ERR_PROCDEF_FV_EXECUTABLE_NOT_SELECTED);
    }

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Add the batch process: pass 1 as a default value for the version no
    // as the process is being created rather than updated
    batchProcessModifyObj.modifyOrAddBatchProcDescription(
      details.processDefName, details.longName, details.description,
      details.batchType, 1);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createGroupProcess(GroupProcessDetails details)
    throws AppException, InformationalException {

    // Batch group maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessGroupsObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Create the group process
    batchProcessGroupsObj.addProcessToGroup(details.groupID,
      details.processDefName);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void executeBatchProcess(AddBatchRequestDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00073939, JI

    // BEGIN, CR00077050, CW
    // List of batch processes that should not be executed
    // if the ERP Adapter is enabled
    final String excludedBatchList = curam.message.EXTERNALERPVALIDATIONS.LIST_EXCLUDED_BATCH_JOBS.// BEGIN,
      // CR00163471,
      // JC
      getMessageText(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163471, JC

    // BEGIN, CR00069071, CW
    // List of batch processes that can only be executed if the ERP Adapter is
    // enabled
    final String erpExclusiveBatchList = curam.message.EXTERNALERPVALIDATIONS.LIST_ERP_EXCLUSIVE_BATCH_JOBS.// BEGIN,
      // CR00163471,
      // JC
      getMessageText(
      ProgramLocale.getDefaultServerLocale());

    // END, CR00163471, JC

    // END, CR00069071

    // If the ERP Adapter is enabled and the batch process is an
    // excluded batch process, throw an error
    // BEGIN, CR00080249, CW
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()
      && excludedBatchList.contains(details.processDefName)) {
      // END, CR00080249
      // END, CR00072947

      final AppException appException = new AppException(
        curam.message.EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_ENABLED_CANNOT_EXECUTE_BATCH_JOB);

      throw appException;
      // END, CR00073939

      // BEGIN, CR00069071, CW
      // BEGIN, CR00080249, CW
    } else if (!FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()
      && erpExclusiveBatchList.contains(details.processDefName)) {
      // END, CR00080249
      // If the ERP Adapter is not enabled and the batch process is
      // exclusive to ERP then throw an error
      final AppException appException = new AppException(
        curam.message.EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_NOT_ENABLED_CANNOT_EXECUTE_BATCH_JOB);

      throw appException;
    }
    // END, CR00069071
    // END, CR00077050

    // Batch process request business process object
    final curam.util.administration.intf.BatchAdmin batchProcReqInterfaceObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // System user maintenance object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Read the system user details
    final SystemUserDtls systemUserDtls = userAccessObj.getUserDetails();

    // Execute the batch process
    // passing an empty string as the last parameter as this argument is
    // marked for deprecation inside addBatchRequest and as such is not
    // used

    // BEGIN, CR00049218, GM
    batchProcReqInterfaceObj.addBatchRequest(details.processDefName,
      details.paramList, systemUserDtls.userName, CuramConst.gkEmpty);
    // END, CR00049218

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListBatchGroupDetails listBatchGroup() throws AppException,
      InformationalException {

    // Batch group request business process object
    final curam.util.administration.intf.BatchAdmin batchProcReqInterfaceObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchGroupDetails listBatchGroupDetails = new ListBatchGroupDetails();

    // Retrieve the list of batch groups
    final curam.util.administration.struct.BatchGroupDetList batchGroupDetList = batchProcReqInterfaceObj.getBatchGroups();

    // Copy list to return object
    for (int i = 0; i < batchGroupDetList.dtls.size(); i++) {

      final BatchGroupDetails batchGroupDetails = new BatchGroupDetails();

      batchGroupDetails.groupID = batchGroupDetList.dtls.item(i).groupId;
      batchGroupDetails.groupName = batchGroupDetList.dtls.item(i).groupName;

      listBatchGroupDetails.batchGroupDetails.addRef(batchGroupDetails);
    }

    // Return details
    return listBatchGroupDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListBatchGroupItem listBatchGroupItem(
    RetrieveItemsForBatchGroupKey key) throws AppException,
      InformationalException {

    // Batch group request business process object
    final curam.util.administration.intf.BatchAdmin batchProcReqInterfaceObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchGroupItem listBatchGroupItem = new ListBatchGroupItem();

    // Retrieve the list of batch group items
    final curam.util.administration.struct.BatchGroupItemList batchGroupItemList = batchProcReqInterfaceObj.getBatchGroupItems(
      key.groupID);

    // Copy list to return object
    for (int i = 0; i < batchGroupItemList.dtls.size(); i++) {

      final BatchGroupItemDetails batchGroupItemDetails = new BatchGroupItemDetails();

      batchGroupItemDetails.numberOfParams = batchGroupItemList.dtls.item(i).numberOfParams;
      batchGroupItemDetails.processDefName = batchGroupItemList.dtls.item(i).processDefName;
      batchGroupItemDetails.processLongName = batchGroupItemList.dtls.item(i).processLongName;
      if (batchGroupItemList.dtls.item(i).numberOfParams > 0) {
        batchGroupItemDetails.hasParam = true;
      } else {
        batchGroupItemDetails.hasParam = false;
      }
      listBatchGroupItem.batchGroupItemDetails.addRef(batchGroupItemDetails);
    }

    // Return details
    return listBatchGroupItem;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListBatchProcess listBatchProcess() throws AppException,
      InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchProcess listBatchProcess = new ListBatchProcess();

    // Retrieve the list of batch processes
    final curam.util.administration.struct.BatchProcDetList batchProcDetList = batchProcessModifyObj.getBatchProcessesWithDesc();

    // Copy list to return object
    for (int i = 0; i < batchProcDetList.dtls.size(); i++) {

      final BatchProcessDetails batchProcessDetails = new BatchProcessDetails();

      batchProcessDetails.batchType = batchProcDetList.dtls.item(i).batchType;
      batchProcessDetails.description = batchProcDetList.dtls.item(i).description;
      batchProcessDetails.longName = batchProcDetList.dtls.item(i).longName;
      batchProcessDetails.processDefName = batchProcDetList.dtls.item(i).processDefName;
      batchProcessDetails.versionNo = batchProcDetList.dtls.item(i).versionNo;

      listBatchProcess.batchProcessDetails.addRef(batchProcessDetails);
    }

    // Return details
    return listBatchProcess;
  }

  // BEGIN, CR, JF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListBatchProcessAndHasParam listBatchProcessAndHasParam()
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchProcessAndHasParam listBatchProcessAndHasParam = new ListBatchProcessAndHasParam();

    // Retrieve the list of batch processes
    final curam.util.administration.struct.BatchProcDetList batchProcDetList = batchProcessModifyObj.getBatchProcessesWithDesc();

    // Copy list to return object
    for (int i = 0; i < batchProcDetList.dtls.size(); i++) {

      final BatchProcessDetailsAndHasParam batchProcessDetailsAndHasParam = new BatchProcessDetailsAndHasParam();

      batchProcessDetailsAndHasParam.batchType = batchProcDetList.dtls.item(i).batchType;
      batchProcessDetailsAndHasParam.description = batchProcDetList.dtls.item(i).description;
      batchProcessDetailsAndHasParam.longName = batchProcDetList.dtls.item(i).longName;
      batchProcessDetailsAndHasParam.processDefName = batchProcDetList.dtls.item(i).processDefName;
      batchProcessDetailsAndHasParam.versionNo = batchProcDetList.dtls.item(i).versionNo;

      if (batchProcDetList.dtls.item(i).numberOfParams > 0) {
        batchProcessDetailsAndHasParam.hasParam = true;
      }

      listBatchProcessAndHasParam.batchProcessDetailsAndHasParam.addRef(
        batchProcessDetailsAndHasParam);
    }

    // Return details
    return listBatchProcessAndHasParam;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListBatchProcessAndHasParam searchBatchProcess(
    curam.core.facade.struct.SearchBatchKey searchBatchKey)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchProcessAndHasParam listBatchProcessAndHasParam = new ListBatchProcessAndHasParam();

    // Create the struct object used to pass into the search.
    final BatchProcessSearchKey batchProcessSearchKey = new BatchProcessSearchKey();

    batchProcessSearchKey.processDisplayName = searchBatchKey.nameOrDescription;
    batchProcessSearchKey.processDescription = searchBatchKey.nameOrDescription;
    batchProcessSearchKey.groupId = searchBatchKey.groupID;
    batchProcessSearchKey.userLocale = TransactionInfo.getProgramLocale();
    batchProcessSearchKey.processName = searchBatchKey.nameOrDescription;

    // Retrieve the list of batch processes
    final curam.util.administration.struct.BatchProcessDefDetailsList batchProcDetList = batchProcessModifyObj.searchBatchProcess(
      batchProcessSearchKey);

    // Copy list to return object
    for (int i = 0; i < batchProcDetList.dtls.size(); i++) {

      final BatchProcessDetailsAndHasParam batchProcessDetailsAndHasParam = new BatchProcessDetailsAndHasParam();

      batchProcessDetailsAndHasParam.batchType = batchProcDetList.dtls.item(i).batchType;
      batchProcessDetailsAndHasParam.description = batchProcDetList.dtls.item(i).description;
      batchProcessDetailsAndHasParam.longName = batchProcDetList.dtls.item(i).processDefDisplayName;
      batchProcessDetailsAndHasParam.processDefName = batchProcDetList.dtls.item(i).processDefName;
      batchProcessDetailsAndHasParam.versionNo = batchProcDetList.dtls.item(i).versionNo;

      if (batchProcDetList.dtls.item(i).numberOfParams > 0) {
        batchProcessDetailsAndHasParam.hasParam = true;
      }

      listBatchProcessAndHasParam.batchProcessDetailsAndHasParam.addRef(
        batchProcessDetailsAndHasParam);
    }

    // Return details
    return listBatchProcessAndHasParam;
  }

  // END, CR, JF

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListBatchProcessRequest listBatchProcessRequest()
    throws AppException, InformationalException {

    // Batch process request business process object
    final curam.util.administration.intf.BatchAdmin batchRequestProcessObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchProcessRequest listBatchProcessRequest = new ListBatchProcessRequest();

    // Retrieve the list of requests
    final curam.util.administration.struct.BatchRequestDetList batchRequestDetList = batchRequestProcessObj.getAllRequests();

    // Copy the list to the return object
    for (int i = 0; i < batchRequestDetList.dtls.size(); i++) {

      final BatchProcessRequestDetails batchProcessRequestDetails = new BatchProcessRequestDetails();

      batchProcessRequestDetails.priority = batchRequestDetList.dtls.item(i).priority;
      batchProcessRequestDetails.processDefinitionName = batchRequestDetList.dtls.item(i).processDefName;
      batchProcessRequestDetails.processRequestID = batchRequestDetList.dtls.item(i).processRequestId;
      batchProcessRequestDetails.timeRequested = batchRequestDetList.dtls.item(i).timeRequested;
      batchProcessRequestDetails.username = batchRequestDetList.dtls.item(i).username;

      listBatchProcessRequest.batchProcessRequestDetails.addRef(
        batchProcessRequestDetails);
    }

    // Return details
    return listBatchProcessRequest;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListBatchProcessRequest searchBatchProcessRequest(
    curam.core.facade.struct.SearchBatchKey searchBatchKey)
    throws AppException, InformationalException {

    // Batch process request business process object
    final curam.util.administration.intf.BatchAdmin batchRequestProcessObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchProcessRequest listBatchProcessRequest = new ListBatchProcessRequest();

    // Create the struct object used to pass into the search.
    final BatchProcessSearchKey batchProcessSearchKey = new BatchProcessSearchKey();

    batchProcessSearchKey.processDisplayName = searchBatchKey.nameOrDescription;
    batchProcessSearchKey.processDescription = searchBatchKey.nameOrDescription;
    batchProcessSearchKey.groupId = searchBatchKey.groupID;
    batchProcessSearchKey.processName = searchBatchKey.nameOrDescription;
    batchProcessSearchKey.userLocale = TransactionInfo.getProgramLocale();

    // Retrieve the list of requests
    final BatchRequestProcessDetailsList batchRequestDetList = batchRequestProcessObj.searchBatchRequest(
      batchProcessSearchKey);

    // Copy the list to the return object
    for (int i = 0; i < batchRequestDetList.dtls.size(); i++) {

      final BatchProcessRequestDetails batchProcessRequestDetails = new BatchProcessRequestDetails();

      batchProcessRequestDetails.priority = batchRequestDetList.dtls.item(i).priority;
      batchProcessRequestDetails.processDefinitionName = batchRequestDetList.dtls.item(i).processDefName;
      batchProcessRequestDetails.processRequestID = batchRequestDetList.dtls.item(i).processRequestId;
      batchProcessRequestDetails.timeRequested = batchRequestDetList.dtls.item(i).timeRequested;
      batchProcessRequestDetails.username = batchRequestDetList.dtls.item(i).username;
      batchProcessRequestDetails.longName = batchRequestDetList.dtls.item(i).processDefDisplayName;

      listBatchProcessRequest.batchProcessRequestDetails.addRef(
        batchProcessRequestDetails);
    }

    // Return details
    return listBatchProcessRequest;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListBatchGroupDetails listGroupsForProcess(
    RetrieveGroupsForProcessKey key) throws AppException,
      InformationalException {

    // Batch group maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessGroupsObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ListBatchGroupDetails listBatchGroupDetails = new ListBatchGroupDetails();

    // Create batch group list struct
    curam.util.administration.struct.BatchGroupDetList batchGroupDetList;

    // Retrieve the list of groups
    batchGroupDetList = batchProcessGroupsObj.getGroupsForProcess(
      key.processDefName);

    // Copy list to return object
    for (int i = 0; i < batchGroupDetList.dtls.size(); i++) {

      final BatchGroupDetails batchGroupDetails = new BatchGroupDetails();

      batchGroupDetails.groupID = batchGroupDetList.dtls.item(i).groupId;
      batchGroupDetails.groupName = batchGroupDetList.dtls.item(i).groupName;

      listBatchGroupDetails.batchGroupDetails.addRef(batchGroupDetails);
    }

    // Return details
    return listBatchGroupDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyBatchProcess(BatchProcessDetails details)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Modify the details for the batch process
    batchProcessModifyObj.modifyOrAddBatchProcDescription(
      details.processDefName, details.longName, details.description,
      details.batchType, details.versionNo);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyParameter(ModifyParamDetails details)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Modify the parameter
    batchProcessModifyObj.modifyBatchParamDesc(details.processDefName,
      details.paramName, details.description, details.defaultValue,
      details.versionNo);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeBatchGroup(RemoveBatchGroupKey key) throws AppException,
      InformationalException {

    // Batch group maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcessGroupsObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Remove the batch group
    batchProcessGroupsObj.removeGroup(key.groupID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeBatchProcess(RemoveBatchProcessKey key)
    throws AppException, InformationalException {

    // Batch process delete business process object
    final curam.util.administration.intf.BatchAdmin batchProcessDeleteObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Remove the batch process
    batchProcessDeleteObj.deleteBatchProcessDescription(key.processDefName);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeBatchProcessRequest(RemoveProcessRequestKey key)
    throws AppException, InformationalException {

    // Batch process delete business process object
    final curam.util.administration.intf.BatchAdmin batchProcessDeleteObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Remove the batch process request
    batchProcessDeleteObj.deleteProcessRequest(key.processRequestID);
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadBatchProcessAndParamDetails readBatchProcessAndParamDetails(
    ReadBatchProcessAndParamsKey key) throws AppException,
      InformationalException {

    // Batch process maintenance business process objects
    final curam.util.administration.intf.BatchAdmin batchProcessModifyObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    final curam.util.administration.intf.BatchAdmin batchProcReqInterfaceObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ReadBatchProcessAndParamDetails readBatchProcessAndParamDetails = new ReadBatchProcessAndParamDetails();

    // Retrieve the list of parameters for the batch process
    final curam.util.administration.struct.BatchParamDescDetList batchParamDescDetList = batchProcessModifyObj.retrieveParamList(
      key.processDefName);

    if (batchParamDescDetList.dtls.size() > 0) {
      readBatchProcessAndParamDetails.hasParam = true;
    } else {
      readBatchProcessAndParamDetails.hasParam = false;
    }

    // Copy list to return object
    for (int i = 0; i < batchParamDescDetList.dtls.size(); i++) {

      final ParameterDetails parameterDetails = new ParameterDetails();

      parameterDetails.defaultCode = batchParamDescDetList.dtls.item(i).defaultValue;
      parameterDetails.description = batchParamDescDetList.dtls.item(i).description;
      parameterDetails.paramName = batchParamDescDetList.dtls.item(i).paramName;
      parameterDetails.versionNo = batchParamDescDetList.dtls.item(i).versionNo;
      if (!StringUtil.isNullOrEmpty(
        batchParamDescDetList.dtls.item(i).paramLongName)) {
        parameterDetails.paramLongName = batchParamDescDetList.dtls.item(i).paramLongName;
      } else {
        parameterDetails.paramLongName = batchParamDescDetList.dtls.item(i).paramName;
      }

      readBatchProcessAndParamDetails.listParameter.parameterDetails.addRef(
        parameterDetails);
    }

    // Retrieve the details for the batch process
    final curam.util.administration.struct.BatchProcessAndParamDetails batchProcessAndParamDetails = batchProcReqInterfaceObj.getBatchProcessDetails(
      key.processDefName);

    // Copy details to return object
    readBatchProcessAndParamDetails.batchProcessDetails.batchType = batchProcessAndParamDetails.batchType;
    readBatchProcessAndParamDetails.batchProcessDetails.description = batchProcessAndParamDetails.description;
    readBatchProcessAndParamDetails.batchProcessDetails.longName = batchProcessAndParamDetails.longName;
    readBatchProcessAndParamDetails.batchProcessDetails.processDefName = batchProcessAndParamDetails.processDefName;
    readBatchProcessAndParamDetails.batchProcessDetails.versionNo = batchProcessAndParamDetails.versionNo;

    // Return details
    return readBatchProcessAndParamDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ReadBatchParametersList readBatchParameters(ReadBatchProcessKey key)
    throws AppException, InformationalException {

    // Batch process maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchProcReqInterfaceObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Details to be returned
    final ReadBatchParametersList readBatchParametersList = new ReadBatchParametersList();

    // Create a struct to contain batch process and parameter details
    curam.util.administration.struct.BatchProcessAndParamDetails batchProcessAndParamDetails;

    // Read the batch process details
    batchProcessAndParamDetails = batchProcReqInterfaceObj.getBatchProcessDetails(
      key.processDefName);

    // Copy details to return object
    readBatchParametersList.paramTabList = batchProcessAndParamDetails.paramList;

    // Return Details
    return readBatchParametersList;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public GetTemplateDetails getTemplate(GetTemplateVersionKey key)
    throws AppException, InformationalException {

    // XSLTemplateUtility server object.
    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    // XSLTemplateSCM server object.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    // XSL template objects
    final XSLTemplateID xslTemplateKey = new XSLTemplateID();
    XSLGetTemplateDetails xslGetTemplateDetails;
    final XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();
    XSLTemplateInstDetails xslTemplateInstDetails;

    // Return object
    final GetTemplateDetails getTemplateDetails = new GetTemplateDetails();

    // Populate key
    xslTemplateInstanceKey.templateID = key.templateID;
    xslTemplateInstanceKey.templateVersion = key.templateVersion;
    // BEGIN, CR00145315, SK
    xslTemplateInstanceKey.locale = key.localeIdentifier;
    // END, CR00145315

    // Get the template details
    xslTemplateInstDetails = xslTemplateUtilityObj.getTemplate(
      xslTemplateInstanceKey);

    // Get the document contents
    getTemplateDetails.document = xslTemplateInstDetails.document;

    // Get the document name
    xslTemplateKey.templateID = key.templateID;
    // BEGIN, CR00145315, SK
    xslTemplateKey.locale = key.localeIdentifier;
    // END, CR00145315
    xslGetTemplateDetails = xslTemplateSCMObj.getTemplateDetails(xslTemplateKey);
    // BEGIN, CR00023323, SK
    final String xslTemplateName = xslGetTemplateDetails.fileName.concat(
      ExtensionConst.kXmlFileNameExtension);

    // END, CR00023323
    getTemplateDetails.templateName = xslTemplateName;

    return getTemplateDetails;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to list all secured fields.
   *
   *
   * @return A list of secured fields.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public ListSecuredFieldsDetails listSecuredFields() throws AppException,
      InformationalException {

    return null;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to list all curam operations.
   *
   *
   * @return A list of available operations.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public ListOperationDetails listOperations() throws AppException,
      InformationalException {

    return null;

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to list returned fields for an operation.
   *
   * @param key
   * A struct Containing the operation name whose returned fields will
   * be displayed.
   *
   * @return A list of available operations.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListReturnedFieldDetails listReturnedFieldsByOperation(
    ListReturnedFieldKey key) throws AppException, InformationalException {

    return null;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to view the field level security for a return
   * field of an operation.
   *
   * @param key
   * A struct containing the operation name and field name for which
   * the SID will be displayed.
   *
   * @return Security level details for the operation name and field name.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public ViewFieldLevelSecurityDetails viewFieldLevelSecurity(
    ViewFieldLevelSecurityKey key) throws AppException,
      InformationalException {

    return null;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to create and a new field on a return interface.
   *
   * @param key
   * contains the operation name and the field name.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public void createFieldForInterface(CreateFieldForInterfaceKey key)
    throws AppException, InformationalException {//
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to create a SID for a returned field.
   *
   * @param key
   * contains the operation name, field name and the SID for that
   * field.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00146011
  @Override
  public void createSidForField(CreateSidForField key) throws AppException,
      InformationalException {//
  }

  // BEGIN, CR00146011, GSP
  /**
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @see curam.core.facade.intf.System#listWorkAllocationRuleSet()
   */
  // END, CR00146011
  @Override
  public ListWorkAllocationRuleSetDetails listWorkAllocationRuleSet()
    throws AppException, InformationalException {

    return null;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void cancelDocumentTemplate(
    curam.core.facade.struct.CancelDocumentTemplateKey key)
    throws AppException, InformationalException {

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // cancel document template
    documentTemplateObj.cancel(key.dtls);
  }

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to create a document template.
   *
   * @param key
   * A Struct containing the details of the document template to
   * create.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #createDocumentTemplate1()}
   * .
   */
  @Override
  // END, CR00146011
  @Deprecated
  public void createDocumentTemplate(
    curam.core.facade.struct.CreateDocumentTemplateDetails key)
    throws AppException, InformationalException {

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // create document template
    documentTemplateObj.create(key.key);
  }

  // END, CR00240340

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public curam.core.facade.struct.ListDocumentTemplateDetails listDocumentTemplates() throws AppException, InformationalException {

    // create a return object
    final curam.core.facade.struct.ListDocumentTemplateDetails listDocumentTemplateDetails = new curam.core.facade.struct.ListDocumentTemplateDetails();

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // list document template details
    listDocumentTemplateDetails.dtls = documentTemplateObj.list();

    return listDocumentTemplateDetails;
  }

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to read the details of a document template
   * record.
   *
   * @param key
   * A Struct containing the documentTemplateID.
   *
   * @return The details of the document template.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #listDocumentTemplates1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public curam.core.facade.struct.ReadDocumentTemplateDetails readDocumentTemplate(curam.core.facade.struct.ReadDocumentTemplateKey key)
    throws AppException, InformationalException {

    final curam.core.facade.struct.ReadDocumentTemplateDetails readDocumentTemplateDetails = new curam.core.facade.struct.ReadDocumentTemplateDetails();

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // read document template
    readDocumentTemplateDetails.dtls = documentTemplateObj.read(key.key);
    return readDocumentTemplateDetails;
  }

  // END, CR00240340

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Presentation layer method to update the document template details.
   *
   * @param key
   * A Struct containing the documentTemplateID.
   * @param details
   * A Struct containing the operation name, field name and the Sid for
   * that field.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #updateDocumentTemplate1()}
   * .
   */
  @Override
  // END, CR00146011
  @Deprecated
  public void updateDocumentTemplate(
    curam.core.facade.struct.ModifyDocumentTemplateKey key,
    curam.core.facade.struct.ModifyDocumentTemplateDetails details)
    throws AppException, InformationalException {

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // modify the template.
    documentTemplateObj.modify(key.key, details.dtls);
  }

  // END, CR00240340

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyDocumentTemplateContents(
    curam.core.facade.struct.ModifyDocumentTemplateKey key,
    curam.core.facade.struct.DocumentTemplateContentsAndVersion details)
    throws AppException, InformationalException {

    // Attachment manipulation variables
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    documentTemplateObj.modifyDocumentTemplateContents(key.key, details.dtls);

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public curam.core.facade.struct.DocumentTemplateWordContentsAndData getDocumentTemplateContents(
    curam.core.facade.struct.ReadDocumentTemplateKey key)
    throws AppException, InformationalException {

    // Attachment manipulation variables
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();
    final curam.core.facade.struct.DocumentTemplateWordContentsAndData documentTemplateWordContentsAndData = new curam.core.facade.struct.DocumentTemplateWordContentsAndData();

    curam.core.sl.struct.DocumentTemplateWordContentsAndData slDocumentTemplateWordContentsAndData;

    slDocumentTemplateWordContentsAndData = documentTemplateObj.getDocumentTemplateContents(
      key.key);

    documentTemplateWordContentsAndData.dtls = slDocumentTemplateWordContentsAndData;

    return documentTemplateWordContentsAndData;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void createBatchErrorCode(BatchErrorCodeDetails batchErrorCodeDetails)
    throws AppException, InformationalException {

    // BatchAdmin maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchAdminObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Ensure that the batch error code is positive and less than
    // the integer max size
    batchAdminObj.addBatchErrorCode(batchErrorCodeDetails.batchErrorCodeID,
      batchErrorCodeDetails.batchErrorCode);

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public ListBatchErrorCodeDetails listBatchErrorCode() throws AppException,
      InformationalException {

    // BatchAdmin maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchAdminObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    final ListBatchErrorCodeDetails listBatchErrorCodeDetails = new ListBatchErrorCodeDetails();

    BatchErrorCodesDetailsList batchErrorCodesDetailsList;

    batchErrorCodesDetailsList = batchAdminObj.getAllBatchErrorCodes();

    // Copy list to return object
    for (int i = 0; i < batchErrorCodesDetailsList.dtls.size(); i++) {

      final BatchErrorCodeDetails batchErrorCodeDetails = new BatchErrorCodeDetails();

      batchErrorCodeDetails.batchErrorCodeID = batchErrorCodesDetailsList.dtls.item(i).errorCodeID;
      batchErrorCodeDetails.batchErrorCode = batchErrorCodesDetailsList.dtls.item(i).errorCode;

      listBatchErrorCodeDetails.batchErrorCodeDetails.addRef(
        batchErrorCodeDetails);

    }

    return listBatchErrorCodeDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void modifyBatchErrorCode(
    ModifyBatchErrorCodeDetails modifyBatchErrorCodeDetails)
    throws AppException, InformationalException {

    // BatchAdmin maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchAdminObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    batchAdminObj.modifyBatchErrorCode(
      modifyBatchErrorCodeDetails.batchErrorCodeID,
      modifyBatchErrorCodeDetails.batchErrorCode,
      modifyBatchErrorCodeDetails.versionNo);

  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public BatchErrorCodeDetails readBatchErrorCode(
    ReadBatchErrorCodeKey readBatchErrorCodeKey) throws AppException,
      InformationalException {

    // BatchAdmin maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchAdminObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    // Admin Batch Error Code Details
    BatchErrorCodesDetails batchErrorCodesDetails = new BatchErrorCodesDetails();

    // Read the Batch Error Code based on the Batch Error Code ID submitted.
    batchErrorCodesDetails = batchAdminObj.getBatchErrorCode(
      readBatchErrorCodeKey.batchErrorCodeID);

    // Copy to Application Batch Error Code Details
    final BatchErrorCodeDetails batchErrorCodeDetails = new BatchErrorCodeDetails();

    batchErrorCodeDetails.batchErrorCode = batchErrorCodesDetails.errorCode;
    batchErrorCodeDetails.versionNo = batchErrorCodesDetails.versionNo;
    batchErrorCodeDetails.batchErrorCodeID = batchErrorCodesDetails.errorCodeID;

    return batchErrorCodeDetails;
  }

  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // END, CR00146011
  @Override
  public void removeBatchErrorCode(
    RemoveBatchErrorCodeKey removeBatchErrorCodeKey) throws AppException,
      InformationalException {

    // BatchAdmin maintenance business process object
    final curam.util.administration.intf.BatchAdmin batchAdminObj = curam.util.administration.fact.BatchAdminFactory.newInstance();

    batchAdminObj.removeBatchErrorCode(removeBatchErrorCodeKey.batchErrorCodeID);

  }

  // BEGIN, CR00100570, SD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelNickname(NicknameKey key) throws AppException,
      InformationalException {

    // Delete the nickname record from the table
    curam.core.sl.fact.NicknameFactory.newInstance().deleteNickname(key);

  }

  // ___________________________________________________________________________
  /**
   * List all nickname details.
   *
   * @return The full list of nickname details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public NicknameDtlsList listNickname() throws AppException,
      InformationalException {

    // Get the list of all nickname details from the table
    final NicknameDtlsList nicknameDtlsList = curam.core.sl.fact.NicknameFactory.newInstance().listNickname();

    return nicknameDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyNickname(NicknameKey key, NicknameDtls details)
    throws AppException, InformationalException {

    // Modify the nickname record
    curam.core.sl.fact.NicknameFactory.newInstance().modifyNickname(key,
      details);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public NicknameDtls readNickname(NicknameKey key) throws AppException,
      InformationalException {

    // Read and return the relevant nickname details
    final NicknameDtls nicknameDtls = curam.core.sl.fact.NicknameFactory.newInstance().readNickname(
      key);

    return nicknameDtls;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void createNickname(NicknameDtls details) throws AppException,
      InformationalException {

    // Insert the nickname details
    curam.core.sl.fact.NicknameFactory.newInstance().createNickname(details);

  }

  // END, CR00100570

  // BEGIN, CR00240340, ZV
  // BEGIN, CR00096284, SK
  // BEGIN, CR00146011, GSP
  // ___________________________________________________________________________
  /**
   * Retrieve a list of the list Active Document Template
   *
   * @return A list of Active Document Template
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listActiveDocumentTemplates1()}.
   */
  @Override
  // END, CR00146011
  @Deprecated
  public ListDocumentTemplateDetails listActiveDocumentTemplates()
    throws AppException, InformationalException {

    // document template Service layer object.

    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();
    final ListDocumentTemplateDetails listDocumentTemplateDetails = new ListDocumentTemplateDetails();

    listDocumentTemplateDetails.dtls = documentTemplateObj.listActiveDocumentTemplates();
    return listDocumentTemplateDetails;
  }

  /**
   * Retrieve a list of code table items associated with a given code table.
   * The list can be filtered to only return values that match a given string.
   *
   * @param Key Struct containing the name of the code table and and optional
   * string
   * value to filter the list.
   *
   * @return A list code table items associated with given code table.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListItemsInCodeTable filterListItemsInCodeTable(
    CodeTableItemFilter key) throws AppException, InformationalException {

    final CodeTableName nameKey = new CodeTableName();

    nameKey.name = key.codeTableName;
    final ListItemsInCodeTable completeList = listAllItemsInCodeTable(nameKey);

    // We want to always return the complete list of the codetable items in a
    // codetable.
    return completeList;

    // if (key.itemFilter.isEmpty()) {
    // return completeList;
    // } else { // we want to filter the results before returning them
    // ListItemsInCodeTable filteredList = new ListItemsInCodeTable();
    //
    // for (int loop = 0; loop < completeList.codeTableItemDetails.size();
    // loop++) {
    // if
    // (completeList.codeTableItemDetails.item(loop).description.toUpperCase().indexOf(
    // key.itemFilter.toUpperCase())
    // != -1) {
    // filteredList.codeTableItemDetails.addRef(
    // completeList.codeTableItemDetails.item(loop));
    // }
    // }
    // return filteredList;
    // }

  }

  // END, CR00240340

  // END, CR00096284
  // BEGIN, CR00139084, GSP
  // BEGIN, CR00146011, GSP
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListItemsInCodeTable listAllItemsInCodeTable(CodeTableName key)
    throws AppException, InformationalException {

    final ListItemsInCodeTable listItemsInCodeTable = new ListItemsInCodeTable();

    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    CodeTableItemDetails codeTableItemDetails;

    // TEC-13046 - code table fall back implementation.
    // Retrieve the list of items in the codetable. This will retrieve all items
    // for the logged in users locale. If no code table item is found for the
    // logged in users
    // locale, then this method will fall back to the en locale.
    final curam.util.administration.struct.CodeTableItemDetailsList ctDetailsList = codeTableAdminObj.listAllItemsForLocaleAndLanguage(
      key.name, TransactionInfo.getProgramLocale());

    String tablename = GeneralConstants.kEmpty;

    for (final curam.util.administration.struct.CodeTableItemDetails ctDetails : ctDetailsList.dtls.items()) {
      if (tablename.equals(GeneralConstants.kEmpty)) {
        tablename = ctDetails.tableName;
      }
      codeTableItemDetails = new CodeTableItemDetails();
      codeTableItemDetails.annotation = ctDetails.annotation;
      codeTableItemDetails.code = ctDetails.code;
      codeTableItemDetails.description = ctDetails.description;
      codeTableItemDetails.selectableInd = ctDetails.isEnabled;
      codeTableItemDetails.languageCode = ctDetails.locale;
      codeTableItemDetails.sortOrder = ctDetails.sortOrder;
      codeTableItemDetails.versionNo = ctDetails.versionNo;
      listItemsInCodeTable.codeTableItemDetails.addRef(codeTableItemDetails);
    }
    // need to read the default code and version no for the code table.
    final CodeTableHeaderDetails cthDetails = codeTableAdminObj.readCodeTableHeaderDetails(
      tablename);

    listItemsInCodeTable.defaultCodeDetails.defaultCode = cthDetails.defaultCode;
    listItemsInCodeTable.defaultCodeDetails.versionNo = cthDetails.versionNo;

    return listItemsInCodeTable;
  }

  // END, CR00146011
  // END, CR00139084

  // BEGIN, CR00339855, ELG
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListItemsInCodeTable listAllItemsInCodeTableForProgramLocale(
    final CodeTableName key) throws AppException, InformationalException {

    final ListItemsInCodeTable listItemsInCodeTable = new ListItemsInCodeTable();

    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();

    CodeTableItemDetails codeTableItemDetails;

    // Get the locale for the user
    final String locale = TransactionInfo.getProgramLocale();
    final curam.util.administration.struct.CodeTableItemDetailsList codeTableItemList = codeTableAdminObj.listAllItemsForLocaleAndLanguage(
      key.name, locale);
    // = codeTableAdminObj.listAllItemsOneLocale(key.name, locale);

    final curam.util.administration.struct.CodeTableHeaderDetails codeTableHeaderDetails = codeTableAdminObj.readCodeTableHeaderDetails(
      key.name);

    // Copy list to return object
    for (int i = 0; i < codeTableItemList.dtls.size(); i++) {

      codeTableItemDetails = new CodeTableItemDetails();

      codeTableItemDetails.annotation = codeTableItemList.dtls.item(i).annotation;
      codeTableItemDetails.code = codeTableItemList.dtls.item(i).code;
      codeTableItemDetails.description = codeTableItemList.dtls.item(i).description;
      codeTableItemDetails.selectableInd = codeTableItemList.dtls.item(i).isEnabled;
      codeTableItemDetails.languageCode = codeTableItemList.dtls.item(i).locale;
      codeTableItemDetails.sortOrder = codeTableItemList.dtls.item(i).sortOrder;
      codeTableItemDetails.versionNo = codeTableItemList.dtls.item(i).versionNo;

      listItemsInCodeTable.codeTableItemDetails.addRef(codeTableItemDetails);
    }

    listItemsInCodeTable.defaultCodeDetails.defaultCode = codeTableHeaderDetails.defaultCode;
    listItemsInCodeTable.defaultCodeDetails.versionNo = codeTableHeaderDetails.versionNo;

    return listItemsInCodeTable;

  }

  // END, CR00339855

  // BEGIN, CR00146629, SK
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public LanguageLocaleMapDetailsList listLanguageLocaleMap()
    throws AppException, InformationalException {

    final LanguageLocaleMapDetailsList languageLocaleMapDetailsList = new curam.core.facade.struct.LanguageLocaleMapDetailsList();
    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMap = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();

    languageLocaleMapDetailsList.list = languageLocaleMap.listLanguageLocaleMap();
    return languageLocaleMapDetailsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public LanguageLocaleDetails readLanguageLocaleMap(LanguageLocaleMapKey key) throws AppException,
      InformationalException {

    final curam.core.facade.struct.LanguageLocaleDetails languageLocaleDetails = new curam.core.facade.struct.LanguageLocaleDetails();
    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();

    languageLocaleDetails.dtls = languageLocaleMapObj.readLanguageLocaleMap(
      key.key);
    return languageLocaleDetails;
  }

  // __________________________________________________________________________
  /**
   * Create a new Language Locale Map item.
   *
   * @param details
   * of a new Language Locale Map item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createLanguageLocaleMap(LanguageLocaleMapDetails details)
    throws AppException, InformationalException {

    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();

    languageLocaleMapObj.createLanguageLocaleMap(details.dtls);
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void removeLanguageLocaleMap(LanguageLocaleMapKey key)
    throws AppException, InformationalException {

    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();

    languageLocaleMapObj.removeLanguageLocaleMap(key.key);
  }

  // __________________________________________________________________________
  /**
   * Read language and locale code with locale code list from code table.
   *
   * @param key
   * a Language Locale Map item.
   * @return details of language and locale code for a specific Language Locale
   * Map item with a locale code list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  @Override
  public ListItemsInLocaleCodeTable readLanguageLocaleDetails(
    LanguageLocaleMapKey key) throws AppException, InformationalException {

    final ListItemsInLocaleCodeTable listItemsInLocaleCodeTable = new ListItemsInLocaleCodeTable();

    ItemsInLocaleCodeTable itemsInLocaleCodeTable = new ItemsInLocaleCodeTable();

    final curam.core.facade.struct.LanguageLocaleDetails languageLocaleDetails = new curam.core.facade.struct.LanguageLocaleDetails();
    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();

    // check if it is called from a modify page,if it is,
    // then add language code and locale code value to the return struct
    if (key.key.key.languageCode != null
      && key.key.key.languageCode.length() != 0) {
      languageLocaleDetails.dtls = languageLocaleMapObj.readLanguageLocaleMap(
        key.key);
      listItemsInLocaleCodeTable.details.dtls.languageCode = languageLocaleDetails.dtls.languageCode;
      listItemsInLocaleCodeTable.details.dtls.localeIdentifier = languageLocaleDetails.dtls.localeIdentifier;
      listItemsInLocaleCodeTable.details.dtls.versionNo = languageLocaleDetails.dtls.versionNo;
    }
    // BEGIN, CR00335807, SSK
    final CodeTableName codeTableName = new CodeTableName();

    codeTableName.name = CuramConst.kCodeTableName_Locale;
    final CodetableCodeAndDescriptionList codetableCodeAndDescriptionList = listEnabledItemsInCodetableForLocale(
      codeTableName);

    for (final CodetableCodeAndDescription codetableCodeAndDescription : codetableCodeAndDescriptionList.codetableCodeAndDescription) {

      itemsInLocaleCodeTable = new ItemsInLocaleCodeTable();

      itemsInLocaleCodeTable.localeIdentifier = codetableCodeAndDescription.code;

      // END, CR00335807
      listItemsInLocaleCodeTable.dtls.add(itemsInLocaleCodeTable);

    }

    return listItemsInLocaleCodeTable;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyLanguageLocaleMap(LanguageLocaleMapKey key,
    LanguageLocaleMapDetails details) throws AppException,
      InformationalException {

    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();

    // modify the locale for a Language Locale Map item.
    languageLocaleMapObj.modifyLanguageLocaleMap(key.key, details.dtls);
  }

  // END, CR00146629

  // BEGIN, CR00172519, CL
  // __________________________________________________________________________
  /**
   * List all enabled codetable items for a specified locale.
   *
   * @param key
   * A codetable name.
   * @return List of codetable codes and their descriptions
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CodetableCodeAndDescriptionList listEnabledItemsInCodetableForLocale(CodeTableName key)
    throws AppException, InformationalException {

    // Details to be returned
    final CodetableCodeAndDescriptionList codetableCodeAndDescriptionList = new CodetableCodeAndDescriptionList();

    // Get the locale for the user
    final String locale = TransactionInfo.getProgramLocale();

    // Read all the enabled items for the locale
    final LinkedHashMap<String, String> codetableCodesHashMap = CodeTable.getAllEnabledItems(
      key.name, locale);

    CodetableCodeAndDescription codetableCodeAndDescription;

    if (!codetableCodesHashMap.isEmpty()) {

      final Set<Entry<String, String>> codeSet = codetableCodesHashMap.entrySet();

      final Iterator<Entry<String, String>> itr = codeSet.iterator();

      while (itr.hasNext()) {

        codetableCodeAndDescription = new CodetableCodeAndDescription();

        final Map.Entry entry = itr.next();

        codetableCodeAndDescription.code = entry.getKey().toString();
        codetableCodeAndDescription.description = entry.getValue().toString();

        codetableCodeAndDescriptionList.codetableCodeAndDescription.addRef(
          codetableCodeAndDescription);

      }

    }
    return codetableCodeAndDescriptionList;

  }

  // END, CR00172519

  // BEGIN, CR00149298, JMA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListSelectedFieldsDocumentTemplateDetails listDocumentTemplatesByRelatedID(SearchByRelatedIDKey key)
    throws AppException, InformationalException {

    // Return type
    final ListSelectedFieldsDocumentTemplateDetails listSelectedFieldsDocumentTemplateDetails = new ListSelectedFieldsDocumentTemplateDetails();

    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    listSelectedFieldsDocumentTemplateDetails.dtls = documentTemplateObj.listByRelatedID(
      key.SearchByRelatedIDKey);

    return listSelectedFieldsDocumentTemplateDetails;
  }

  // END, CR00149298

  // ___________________________________________________________________________
  // BEGIN, CR00190252, NP
  /**
   * Validate Security Role Name
   *
   * @param name
   * Security Role Name
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected void validateSecurityRoleName(String name)
    throws InformationalException {

    // END, CR00198672
    // Create an informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (name.toUpperCase().length() > CuramConst.kUpperROLENAME) {

      // create the warning string
      final curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOSYSTEM.ERR_SECURITYROLE_FV_UPPERNAME_EXCEEDED_LIMIT);

      infoMessage.arg(name.toUpperCase().length() - CuramConst.kUpperROLENAME);
      // add the string within the InformationalManager
      informationalManager.addInformationalMsg(infoMessage,
        curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);
    }
    informationalManager.failOperation();
  } // END, CR00190252

  // BEGIN, CR00219877, AC
  // BEGIN, CR00222960, JF - adding javadoc
  /**
   * {@inheritDoc}
   */
  // END, CR00222960, JF
  @Override
  public ListSelectedFieldsDocumentTemplateDetailsAndVersionNo readAllWithoutContentAndVersionNo() throws AppException,
      InformationalException {

    // create a return object
    final ListSelectedFieldsDocumentTemplateDetailsAndVersionNo listSelectedFieldsDocumentTemplateDetailsAndVersionNo = new ListSelectedFieldsDocumentTemplateDetailsAndVersionNo();

    // document template service layer class
    final curam.core.sl.intf.DocumentTemplate documentTemplateObj = curam.core.sl.fact.DocumentTemplateFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // list document template details
    listSelectedFieldsDocumentTemplateDetailsAndVersionNo.dtls = documentTemplateObj.listSelectedFieldsAndVersionNo();

    return listSelectedFieldsDocumentTemplateDetailsAndVersionNo;
  }

  // END, CR00219877, AC

  // BEGIN, CR00233006, JF
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SecurityIdentifierSearchResults searchSecurityIdentifiers(
    SecurityIdentifierSearchKey key) throws AppException,
      InformationalException {

    // Security maintenance business process object
    final curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    final SecurityIdentifierSearchResults securityIdentifiersSearchResults = new SecurityIdentifierSearchResults();

    final SecurityIdentifierDetailsList securityIdentifierSearchResultList = securityAdministrationObj.listAllMatchSecurityIdentifiers(
      key.securityIdentifierName);

    for (int i = 0; i < securityIdentifierSearchResultList.dtls.size(); i++) {
      final SecurityIdentifierDetails securityIdentifiersDetails = new SecurityIdentifierDetails();

      securityIdentifiersDetails.securityIdentifierID = securityIdentifierSearchResultList.dtls.item(i).securityIdentifierID;
      securityIdentifiersDetails.sidDescription = securityIdentifierSearchResultList.dtls.item(i).description;
      securityIdentifiersDetails.sidName = securityIdentifierSearchResultList.dtls.item(i).securityIdentifierName;
      securityIdentifiersDetails.sidType = securityIdentifierSearchResultList.dtls.item(i).type;
      securityIdentifiersDetails.versionNo = securityIdentifierSearchResultList.dtls.item(i).versionNo;

      securityIdentifiersSearchResults.dtls.add(securityIdentifiersDetails);
    }

    return securityIdentifiersSearchResults;
  }

  // END, CR00233006, JF

  // BEGIN, CR00240340, ZV

  // BEGIN, CR00279987, KRK
  // BEGIN, CR00292443, KRK
  /**
   * Inserts a new XSL template record onto the database.
   *
   * @param details
   * The template details being created.
   *
   * @throws AppException
   * {@link BPOSYSTEM#ERR_DOCUMENT_FV_DETAILS_EMPTY
   * ERR_DOCUMENT_FV_DETAILS_EMPTY}-if document details is empty.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSYSTEM#ERR_DESCRIPTION_FV_DETAILS_EMPTY
   * ERR_DESCRIPTION_FV_DETAILS_EMPTY}-if description is empty.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link System# createXSLTemplate(CreateXSLTemplateDetails)} as part of
   * adding a new field
   * TemplateIDCode while creating a XSL template. See release note :
   * CR00279987.
   */
  @Override
  @Deprecated
  public void createTemplate1(final CreateTemplateDetails1 details)
    throws AppException, InformationalException {

    // END, CR00279987
    // END, CR00292443
    // XSLTemplate server object.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    // The template details passed to addTemplate.
    final AddTemplateDtls addTemplateDtls = new AddTemplateDtls();

    // BEGIN, CR00149298, JMA
    if (details.relatesTo.length() == 0) {

      throw new AppException(curam.message.BPOSYSTEM.ERR_APPLIES_TO_EMPTY);

    }
    // END, CR00149298
    // Check that a description is entered
    if (details.templateName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_DESCRIPTION_FV_DETAILS_EMPTY);
    }
    // Check that a document file has been entered
    if (details.document.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_DOCUMENT_FV_DETAILS_EMPTY);
    }

    // Assign the template details.
    addTemplateDtls.document = details.document;
    addTemplateDtls.editable = details.editableInd;
    addTemplateDtls.relatesTo = details.relatesTo;
    addTemplateDtls.templateName = details.templateName;
    addTemplateDtls.templateType = details.templateType;
    // BEGIN, CR00145315, SK
    addTemplateDtls.locale = details.localeIdentifier;
    // END, CR00145315

    // Add the template.
    xslTemplateSCMObj.addTemplate(addTemplateDtls);
  }

  // BEGIN, CR00279987, KRK
  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyXSLTemplate(
    curam.core.facade.struct.ModifyXSLTemplateDetails details)
    throws AppException, InformationalException {

    final MaintainXSLTemplate maintainXSLTemplateOBJ = MaintainXSLTemplateFactory.newInstance();

    final ModifyXSLTemplateDetails xslTemplateModifyDetails = new ModifyXSLTemplateDetails();

    // Check that a description is entered.
    if (0 == details.templateName.trim().length()) {

      throw new AppException(BPOSYSTEM.ERR_DESCRIPTION_FV_DETAILS_EMPTY);
    }

    // Assign the template details.
    xslTemplateModifyDetails.templateID = details.templateID;
    xslTemplateModifyDetails.templateName = details.templateName;
    xslTemplateModifyDetails.templateRelatesTo = details.relatesTo;
    xslTemplateModifyDetails.templateType = details.templateType;
    xslTemplateModifyDetails.templateIDCode = details.templateIDCode;
    xslTemplateModifyDetails.localeIdentifier = details.localeIdentifier;

    // Call the modify template method.
    maintainXSLTemplateOBJ.modifyXSLTemplateDetails(xslTemplateModifyDetails);
  }

  // BEGIN, CR00292443, KRK
  /**
   * Modifies details of a template.
   *
   * @param details
   * The details of the template that are to be modified.
   * @throws AppException
   * {@link BPOSYSTEM#ERR_DESCRIPTION_FV_DETAILS_EMPTY
   * ERR_DESCRIPTION_FV_DETAILS_EMPTY}-if description details is
   * empty.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link System# modifyXSLTemplate(ModifyXSLTemplateDetails)} as part of
   * adding a new field
   * TemplateIDCode while creating a XSL template. See release note : CR00279987
   */
  @Override
  @Deprecated
  public void modifyTemplate1(final ModifyTemplateDetails1 details)
    throws AppException, InformationalException {

    // END, CR00279987
    // END, CR00292443

    // MaintainXSLTemplate server object.
    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateOBJ = curam.core.fact.MaintainXSLTemplateFactory.newInstance();

    // Details struct to be modified.
    final XSLTemplateModifyDetails xslTemplateModifyDetails = new XSLTemplateModifyDetails();

    // Check that a description is entered.
    if (details.templateName.trim().length() == 0) {

      throw new AppException(
        curam.message.BPOSYSTEM.ERR_DESCRIPTION_FV_DETAILS_EMPTY);
    }

    // Assign the template details.
    xslTemplateModifyDetails.templateID = details.templateID;
    xslTemplateModifyDetails.templateName = details.templateName;
    xslTemplateModifyDetails.templateRelatesTo = details.relatesTo;
    xslTemplateModifyDetails.templateType = details.templateType;
    // BEGIN, CR00096332, MR
    xslTemplateModifyDetails.localeIdentifier = details.localeIdentifier;
    // END CR00096332

    // Call the modify template method.
    maintainXSLTemplateOBJ.modifyTemplateDetails(xslTemplateModifyDetails);
  }

  // BEGIN, CR00279987, KRK
  /**
   * Reads details of an XSL template.
   *
   * @param key Identifier of the template.
   *
   * @return The XSL template details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadXSLTemplateDetails readXSLTemplate(XSLTemplateKey1 key)
    throws AppException, InformationalException {

    final MaintainXSLTemplate maintainXSLTemplateObj = MaintainXSLTemplateFactory.newInstance();
    final XSLTemplateIn xslTemplateIn = new XSLTemplateIn();

    final ReadXSLTemplateDetails readTemplateDetails = new ReadXSLTemplateDetails();
    XSLTemplateReadDetails xslTemplateViewDetails = new XSLTemplateReadDetails();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    xslTemplateIn.templateID = key.templateID;
    xslTemplateIn.localeIdentifier = key.localeIdentifier;

    // Read the template details.
    xslTemplateViewDetails = maintainXSLTemplateObj.readXSLTemplateDetails(
      xslTemplateIn);

    // Assign the templates details to the return struct.
    readTemplateDetails.checkedOutInd = xslTemplateViewDetails.checkedOutInd;
    readTemplateDetails.checkedOutTime = xslTemplateViewDetails.checkedOutTime;
    readTemplateDetails.checkedOutVersion = xslTemplateViewDetails.checkedOutVersion;
    readTemplateDetails.comments = xslTemplateViewDetails.comment;
    readTemplateDetails.latestVersion = xslTemplateViewDetails.latestVersion;
    readTemplateDetails.templateName = xslTemplateViewDetails.templateName;
    readTemplateDetails.templateType = xslTemplateViewDetails.templateType;
    readTemplateDetails.templateIDCode = xslTemplateViewDetails.templateIDCode;
    readTemplateDetails.localeIdentifier = key.localeIdentifier;

    final java.util.LinkedHashMap<String, String> templateTypeList = CodeTable.getAllItems(
      XSLTEMPLATETYPE.TABLENAME, TransactionInfo.getProgramLocale());

    if (templateTypeList.containsKey(xslTemplateViewDetails.relatesTo)) {
      readTemplateDetails.relatesTo = xslTemplateViewDetails.relatesTo;
    } else {
      readTemplateDetails.relatesTo = CuramConst.gkEmpty;
    }

    if (0 != xslTemplateViewDetails.createdBy.length()) {

      // Read the creation user's name.
      usersKey.userName = xslTemplateViewDetails.createdBy;
      final UserFullname userFullName = userAccessObj.getFullName(usersKey);

      readTemplateDetails.createdBy = userFullName.fullname;

    } else {
      readTemplateDetails.createdBy = CuramConst.gkEmpty;
    }

    if (0 != xslTemplateViewDetails.checkedOutBy.length()) {

      // Read the user's details.
      usersKey.userName = xslTemplateViewDetails.checkedOutBy;
      final UserFullname userFullName = userAccessObj.getFullName(usersKey);

      readTemplateDetails.checkedOutBy = userFullName.fullname;

    } else {
      readTemplateDetails.createdBy = CuramConst.gkEmpty;
    }

    return readTemplateDetails;
  }

  // BEGIN, CR00292443, KRK
  /**
   * Returns details of an XSL template.
   *
   * @param key
   * Identifier of the template
   *
   * @return The XSL template details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link System#readXSLTemplate(XSLTemplateKey)} as part of adding a new
   * field TemplateIDCode while
   * creating a XSL template. See release note : CR00279987.
   */
  @Override
  @Deprecated
  public ReadTemplateDetails1 readTemplate1(final XSLTemplateKey1 key)
    throws AppException, InformationalException {

    // END, CR00279987
    // END, CR00292443

    // MaintainXSLTemplate server object and key.
    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateOBJ = curam.core.fact.MaintainXSLTemplateFactory.newInstance();
    final XSLTemplateIn xslTemplateIn = new XSLTemplateIn();

    // The returned details.
    final ReadTemplateDetails1 readTemplateDetails = new ReadTemplateDetails1();
    XSLTemplateViewDetails xslTemplateViewDetails;

    // Users objects
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Set the template ID.
    xslTemplateIn.templateID = key.templateID;
    // BEGIN HARP 54155, HMB
    xslTemplateIn.localeIdentifier = key.localeIdentifier;
    // END HARP 54155

    // Read the template details.
    xslTemplateViewDetails = maintainXSLTemplateOBJ.readTemplateDetails(
      xslTemplateIn);

    // Assign the templates details to the return struct.
    readTemplateDetails.checkedOutInd = xslTemplateViewDetails.checkedOutInd;
    readTemplateDetails.checkedOutTime = xslTemplateViewDetails.checkedOutTime;
    readTemplateDetails.checkedOutVersion = xslTemplateViewDetails.checkedOutVersion;
    readTemplateDetails.comments = xslTemplateViewDetails.comment;
    readTemplateDetails.latestVersion = xslTemplateViewDetails.latestVersion;
    readTemplateDetails.templateName = xslTemplateViewDetails.templateName;
    readTemplateDetails.templateType = xslTemplateViewDetails.templateType;
    // BEGIN, CR00151394, ZV
    readTemplateDetails.localeIdentifier = key.localeIdentifier;
    // END, CR00151394

    // BEGIN, CR00241706, ZV
    final java.util.LinkedHashMap<String, String> templateTypeList = CodeTable.getAllItems(
      XSLTEMPLATETYPE.TABLENAME, TransactionInfo.getProgramLocale());

    if (templateTypeList.containsKey(xslTemplateViewDetails.relatesTo)) {
      readTemplateDetails.relatesTo = xslTemplateViewDetails.relatesTo;
    } else {
      readTemplateDetails.relatesTo = CuramConst.gkEmpty;
    }
    // END, CR00241706

    if (xslTemplateViewDetails.createdBy.length() > 0) {

      // Read the creation user's name
      usersKey.userName = xslTemplateViewDetails.createdBy;
      final UserFullname userFullName = userAccessObj.getFullName(usersKey);

      readTemplateDetails.createdBy = userFullName.fullname;

    } else {
      // BEGIN, CR00049218, GM
      readTemplateDetails.createdBy = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (xslTemplateViewDetails.checkedOutBy.length() > 0) {

      // Read the user's details
      usersKey.userName = xslTemplateViewDetails.checkedOutBy;
      final UserFullname userFullName = userAccessObj.getFullName(usersKey);

      readTemplateDetails.checkedOutBy = userFullName.fullname;

    } else {
      // BEGIN, CR00049218, GM
      readTemplateDetails.createdBy = CuramConst.gkEmpty;
      // END, CR00049218
    }

    // Return the template details.
    return readTemplateDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListTemplateDetails1 listTemplate1() throws AppException,
      InformationalException {

    // XSLTemplate server object and key.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    // The returned template list.
    final ListTemplateDetails1 listTemplateDetails = new ListTemplateDetails1();
    XSLTemplateDetailsList xslTemplateDetailsList;

    // Users objects
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey;

    // Get all templates
    xslTemplateDetailsList = xslTemplateSCMObj.getAllTemplates();

    // Check to see if any templates were returned
    if (!xslTemplateDetailsList.dtls.isEmpty()) {

      // BEGIN, CR00241706, ZV
      final java.util.LinkedHashMap<String, String> templateTypeList = CodeTable.getAllItems(
        XSLTEMPLATETYPE.TABLENAME, TransactionInfo.getProgramLocale());

      // END, CR00241706

      // Reserve space in the return object
      listTemplateDetails.templateDetails.ensureCapacity(
        xslTemplateDetailsList.dtls.size());

      TemplateDetails1 templateDetails;

      for (int i = 0; i < xslTemplateDetailsList.dtls.size(); i++) {

        templateDetails = new TemplateDetails1();

        usersKey = new UsersKey();

        // If the file is checked out, read the user's full name
        if (xslTemplateDetailsList.dtls.item(i).checkedOutBy.length() > 0) {

          // Read the user
          usersKey.userName = xslTemplateDetailsList.dtls.item(i).checkedOutBy;
          final UserFullname userFullName = userAccessObj.getFullName(usersKey);

          // Assign template details
          templateDetails.checkedOutBy = userFullName.fullname;

        } else {

          templateDetails.checkedOutBy = xslTemplateDetailsList.dtls.item(i).checkedOutBy;
        }

        templateDetails.templateID = xslTemplateDetailsList.dtls.item(i).templateID;
        templateDetails.templateName = xslTemplateDetailsList.dtls.item(i).templateName;
        templateDetails.templateType = xslTemplateDetailsList.dtls.item(i).templateType;
        // BEGIN HARP 54155, HMB
        templateDetails.localeIdentifier = xslTemplateDetailsList.dtls.item(i).locale;
        // END HARP 54155

        // BEGIN, CR00241706, ZV
        if (templateTypeList.containsKey(
          xslTemplateDetailsList.dtls.item(i).relatesTo)) {
          templateDetails.relatesTo = xslTemplateDetailsList.dtls.item(i).relatesTo;
        } else {
          templateDetails.relatesTo = CuramConst.gkEmpty;
        }
        // END, CR00241706

        // Add to return object
        listTemplateDetails.templateDetails.addRef(templateDetails);
      }

    }

    // Return the list of templates.
    return listTemplateDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListTemplateVersions getTemplateVersions1(XSLTemplateKey1 key)
    throws AppException, InformationalException {

    // XSLTemplate server object and key.
    final curam.util.administration.intf.XSLTemplateAdmin xslTemplateSCMObj = curam.util.administration.fact.XSLTemplateAdminFactory.newInstance();

    final XSLTemplateID xslTemplateKey = new XSLTemplateID();

    // The returned template versions list.
    final ListTemplateVersions listTemplateVersions = new ListTemplateVersions();

    // Set the template key.
    xslTemplateKey.templateID = key.templateID;
    // BEGIN, CR00145315, SK
    xslTemplateKey.locale = key.localeIdentifier;
    // END, CR00145315

    // Read the list of template versions.
    XSLTemplateVersionSearchDtlsList xslTemplateVersionSearchDtlsList;

    // BEGIN, CR00168253, VK
    xslTemplateVersionSearchDtlsList = xslTemplateSCMObj.getTemplateVersionsForSpecifiedTemplateID(
      xslTemplateKey);
    // END, CR00168253

    // Check to see if any templates were returned
    if (!xslTemplateVersionSearchDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listTemplateVersions.templateDetailsForCheckOut.ensureCapacity(
        xslTemplateVersionSearchDtlsList.dtls.size());

      TemplateDetailsForCheckOut templateDetailsForCheckOut;

      for (int i = 0; i < xslTemplateVersionSearchDtlsList.dtls.size(); i++) {

        templateDetailsForCheckOut = new TemplateDetailsForCheckOut();

        // Assign template details
        templateDetailsForCheckOut.checkInComment = xslTemplateVersionSearchDtlsList.dtls.item(i).ciComment;
        templateDetailsForCheckOut.createdBy = xslTemplateVersionSearchDtlsList.dtls.item(i).createdBy;
        templateDetailsForCheckOut.templateID = xslTemplateVersionSearchDtlsList.dtls.item(i).templateID;
        templateDetailsForCheckOut.templateVersion = xslTemplateVersionSearchDtlsList.dtls.item(i).templateVersion;
        templateDetailsForCheckOut.timestamp = xslTemplateVersionSearchDtlsList.dtls.item(i).timeStamp;

        // Add to return object
        listTemplateVersions.templateDetailsForCheckOut.addRef(
          templateDetailsForCheckOut);
      }

    }

    // Return the list of template versions.
    return listTemplateVersions;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void createDocumentTemplate1(
    final CreateDocumentTemplateDetails1 details) throws AppException,
      InformationalException {

    final DocumentTemplate documentTemplateObj = DocumentTemplateFactory.newInstance();

    details.dtls.categoryCode = details.categoryCode;

    documentTemplateObj.create(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadDocumentTemplateDetails1 readDocumentTemplate1(
    final ReadDocumentTemplateKey key) throws AppException,
      InformationalException {

    final ReadDocumentTemplateDetails1 readDocumentTemplateDetails = new ReadDocumentTemplateDetails1();

    final DocumentTemplate documentTemplateObj = DocumentTemplateFactory.newInstance();

    readDocumentTemplateDetails.dtls = documentTemplateObj.read(key.key);

    // BEGIN, CR00241706, ZV
    final java.util.LinkedHashMap<String, String> templateTypeList = CodeTable.getAllItems(
      MSWORDTEMPLATETYPE.TABLENAME, TransactionInfo.getProgramLocale());

    if (templateTypeList.containsKey(
      readDocumentTemplateDetails.dtls.categoryCode)) {
      readDocumentTemplateDetails.categoryCode = readDocumentTemplateDetails.dtls.categoryCode;
    } else {
      readDocumentTemplateDetails.dtls.categoryCode = CuramConst.gkEmpty;
      readDocumentTemplateDetails.categoryCode = CuramConst.gkEmpty;
    }
    // END, CR00241706

    return readDocumentTemplateDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void updateDocumentTemplate1(final ModifyDocumentTemplateKey key,
    final ModifyDocumentTemplateDetails1 details) throws AppException,
      InformationalException {

    final DocumentTemplate documentTemplateObj = DocumentTemplateFactory.newInstance();

    details.dtls.categoryCode = details.categoryCode;

    documentTemplateObj.modify(key.key, details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListDocumentTemplateDetails1 listActiveDocumentTemplates1()
    throws AppException, InformationalException {

    final DocumentTemplate documentTemplateObj = DocumentTemplateFactory.newInstance();

    final ListDocumentTemplateDetails1 listDocumentTemplateDetails = new ListDocumentTemplateDetails1();

    listDocumentTemplateDetails.dtls = documentTemplateObj.listActiveDocumentTemplates1();
    return listDocumentTemplateDetails;
  }

  // END, CR00240340

  // BEGIN, CR00279987, KRK
  /**
   * {@inheritDoc}
   */

  @Override
  public void createXSLTemplate(CreateXSLTemplateDetails details)
    throws AppException, InformationalException {

    boolean isTemplateNotFound = false;
    final XSLTemplateAdmin xslTemplateSCMObj = XSLTemplateAdminFactory.newInstance();

    final AddTemplateDtls addTemplateDtls = new AddTemplateDtls();
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();
    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    if (details.relatesTo.length() == 0) {

      throw new AppException(curam.message.BPOSYSTEM.ERR_APPLIES_TO_EMPTY);

    }

    // Check that a description is entered.
    if (0 == details.templateName.trim().length()) {

      throw new AppException(BPOSYSTEM.ERR_DESCRIPTION_FV_DETAILS_EMPTY);
    }
    // Check that a document file has been entered
    if (0 == details.document.trim().length()) {

      throw new AppException(BPOSYSTEM.ERR_DOCUMENT_FV_DETAILS_EMPTY);
    }

    // BEGIN, CR00279987, KRK
    // Check for duplicates.
    xslTemplateIDCodeKey.templateIDCode = details.templateIDCode;
    xslTemplateIDCodeKey.localeIdentifier = details.localeIdentifier;

    try {

      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);

    } catch (final RecordNotFoundException e) {
      isTemplateNotFound = true;
    }

    if (!details.localeIdentifier.equals(xslTemplateInstanceKey.locale)) {
      isTemplateNotFound = true;
    }
    if (!isTemplateNotFound) {
      throw new AppException(BPOSYSTEM.ERR_TEMPLATEID_FV_DUPLICATE);
    }
    // END, CR00279987

    // Assign the template details.
    addTemplateDtls.document = details.document;
    addTemplateDtls.editable = details.editableInd;
    addTemplateDtls.relatesTo = details.relatesTo;
    addTemplateDtls.templateName = details.templateName;
    addTemplateDtls.templateType = details.templateType;
    addTemplateDtls.locale = details.localeIdentifier;
    addTemplateDtls.templateIDCode = details.templateIDCode;

    // Add the template.
    xslTemplateSCMObj.addTemplate(addTemplateDtls);
  }

  // END, CR00279987

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public LocalizableDescTxtDtlsList listTranslationDescriptionText(
    final LocalizableDescTxtKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final CTTranslationSearchKey translationContentKey = new CTTranslationSearchKey();

    translationContentKey.tableName = key.displayNameId;

    final CodeTableAdmin ctAdminHandler = CodeTableAdminFactory.newInstance();

    final CTDisplayNameDetailsList translationTextDetailsList = ctAdminHandler.getTableNameTranslations(
      translationContentKey);

    final LocalizableDescTxtDtlsList descTxtDtlsList = new LocalizableDescTxtDtlsList();

    for (int loop = 0; loop < translationTextDetailsList.dtls.size(); loop++) {

      final LocalizableDescTxtDtls descTxtDtls = new LocalizableDescTxtDtls();

      descTxtDtls.displayNameId = translationTextDetailsList.dtls.item(loop).tableName;
      descTxtDtls.LocaleCode = translationTextDetailsList.dtls.item(loop).localeIdentifier;
      descTxtDtls.translationText = translationTextDetailsList.dtls.item(loop).text;

      descTxtDtlsList.translationTextdtls.addRef(descTxtDtls);

    }

    return descTxtDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public AddTranslationDtlsOut addTranslationDescriptionText(
    AddTranslationDtls translationDtls)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final AddTranslationDtlsOut result = new AddTranslationDtlsOut();

    final CTTranslationTextDetailsIn newTranslationDtls = new CTTranslationTextDetailsIn();

    newTranslationDtls.localeCode = translationDtls.localeCode;
    newTranslationDtls.tableName = translationDtls.displayNameId;
    newTranslationDtls.text = translationDtls.descText;

    final CodeTableAdmin ctAdminObj = CodeTableAdminFactory.newInstance();

    final CTTranslationSearchKey key = new CTTranslationSearchKey();

    key.localeId = translationDtls.localeCode;
    key.tableName = translationDtls.displayNameId;
    final CTDisplayNameDetails codetableDisplayNameDetails = ctAdminObj.searchTableNameByLocale(
      key);

    if (codetableDisplayNameDetails != null) {
      throw new AppException(
        curam.message.BPOSYSTEM.ERR_TRANSLATION_ALREADY_EXISTS);
    }

    ctAdminObj.addTableNameTranslation(newTranslationDtls);
    result.displayNameId = translationDtls.displayNameId;

    return result;
  }

}
