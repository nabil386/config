/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.ACTIONOWNERTYPE;
import curam.codetable.ACTIONPARENTTYPE;
import curam.codetable.CONCERNROLETYPE;
import curam.core.facade.struct.AssociateSituationWithActionDtls;
import curam.core.facade.struct.CreateActionDetails;
import curam.core.facade.struct.ListMemberDetails;
import curam.core.facade.struct.MemberDetails;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.intf.Person;
import curam.core.intf.ProspectPerson;
import curam.core.sl.entity.fact.ActionOwnerFactory;
import curam.core.sl.entity.fact.RepresentativeFactory;
import curam.core.sl.entity.intf.Representative;
import curam.core.sl.entity.struct.ActionChildLinkIDVersionNoDtls;
import curam.core.sl.entity.struct.ActionChildLinkKey;
import curam.core.sl.entity.struct.ActionDtls;
import curam.core.sl.entity.struct.ActionIDAndRecordStatusDtls;
import curam.core.sl.entity.struct.ActionKey;
import curam.core.sl.entity.struct.ActionOwnerDtls;
import curam.core.sl.entity.struct.ActionOwnerDtlsList;
import curam.core.sl.entity.struct.ActionParentLinkIDVersionNoDtls;
import curam.core.sl.entity.struct.ActionParentLinkKey;
import curam.core.sl.entity.struct.ActionPlanKey;
import curam.core.sl.entity.struct.ActionSituationLinkDtls;
import curam.core.sl.entity.struct.CaseIDAndParticipantIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.ParentLinkIDParentTypeDtls;
import curam.core.sl.entity.struct.SituationDtlsList;
import curam.core.sl.fact.ActionFactory;
import curam.core.sl.fact.SituationFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndVersionNo;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.ActionPlanActionRecordStatuskey;
import curam.core.sl.struct.CalculationEndDate;
import curam.core.sl.struct.CalculationStartDate;
import curam.core.sl.struct.CancelActionDetails;
import curam.core.sl.struct.CreateActionDetails1;
import curam.core.sl.struct.ParentActionDetailsList;
import curam.core.sl.struct.ReadActionDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.PersonKey;
import curam.core.struct.ProspectPersonKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.type.Date;
import curam.util.type.StringList;


/**
 * This process class provides the functionality for the Action facade layer.
 */
public abstract class Action extends curam.core.facade.base.Action {

  // BEGIN, CR00139151, GYH
  /**
   * Method to cancel an Action.
   *
   * @param details
   * Contains the Action ID and version No.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00139151
  @Override
  public void cancelAction(final CancelActionDetails details)
    throws AppException, InformationalException {

    // Action service object
    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    // cancel action details
    actionObj.cancel(details);
  }

  // BEGIN, CR00139151, GYH
  /**
   * Method to cancel an Action association to parent entity.
   *
   * @param details
   * Contains the Action ID and version No.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00139151
  @Override
  public void cancelActionParentAssociation(
    final ActionParentLinkIDVersionNoDtls details) throws AppException,
      InformationalException {

    // Action parent link entity object and variables
    final curam.core.sl.entity.intf.ActionParentLink actionParentLinkObj = curam.core.sl.entity.fact.ActionParentLinkFactory.newInstance();
    final ActionParentLinkKey actionParentLinkKey = new ActionParentLinkKey();
    final RecordStatusAndVersionNo recordStatusAndVersionNo = new RecordStatusAndVersionNo();

    // set action parent link key
    actionParentLinkKey.actionParentLinkID = details.actionParentLinkID;
    // set action parent link version no
    recordStatusAndVersionNo.versionNo = details.versionNo;
    // cancel action parent link
    actionParentLinkObj.cancel(actionParentLinkKey, recordStatusAndVersionNo);
  }

  // BEGIN, CR00139151, GYH
  /**
   * Method to cancel an Action association to child entity.
   *
   * @param details
   * Contains the Action Child Link ID and version No.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00139151
  @Override
  public void cancelActionChildAssociation(
    final ActionChildLinkIDVersionNoDtls details) throws AppException,
      InformationalException {

    // Action child link entity object and variables
    final curam.core.sl.entity.intf.ActionChildLink actionChildLinkObj = curam.core.sl.entity.fact.ActionChildLinkFactory.newInstance();
    final ActionChildLinkKey actionChildLinkKey = new ActionChildLinkKey();
    final RecordStatusAndVersionNo recordStatusAndVersionNo = new RecordStatusAndVersionNo();

    // set action child link key
    actionChildLinkKey.actionChildLinkID = details.actionChildLinkID;
    // set action child link version no
    recordStatusAndVersionNo.versionNo = details.versionNo;
    // cancel action child link
    actionChildLinkObj.cancel(actionChildLinkKey, recordStatusAndVersionNo);
  }

  // BEGIN, CR00139151, GYH
  /**
   * @param details
   * Contains the action details to be created.
   *
   * @return The Action key for the created Action.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, as part of the Action Plan Enhancement,
   * replaced by {@link #createAction1(CreateActionDetails1)}, as the situation
   * details are captured independent of the action.
   * See release note: <CEF-722> : ActionPlan Enhancement
   *
   * Method to create an Action.
   */
  @Override
  // END, CR00139151
  @Deprecated
  public ActionKey createAction(final CreateActionDetails details)
    throws AppException, InformationalException {

    // Action service object and return key
    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();
    final ActionKey actionKey = new ActionKey();

    // check if entered case participant role id
    if (details.caseParticipantRoleID != 0) {
      // case participant role entity object and key
      final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleKey participantKey = new CaseParticipantRoleKey();

      participantKey.caseParticipantRoleID = details.caseParticipantRoleID;
      // read concern role id
      final CaseIDAndParticipantIDDetails caseIDAndParticipantIDDetails = caseParticipantRoleObj.readCaseIDAndParticipantID(
        participantKey);

      details.actionDetails.dtls.ownerConcernRoleID = caseIDAndParticipantIDDetails.participantID;
    }
    // create action record
    actionObj.create(details.actionDetails);
    actionKey.actionID = details.actionDetails.dtls.actionID;
    return actionKey;
  }

  // BEGIN, CR00139151, GYH
  /**
   * Method to modify the Action details.
   *
   * @param details
   * Contains the action details to be updated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  // END, CR00139151
  @Deprecated
  public void modifyAction(final ActionDtls details) throws AppException,
      InformationalException {

    // BEGIN, CR00139151, GYH
    // Action service object and return key
    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    // create action record
    actionObj.modify(details);
    // END, CR00139151
  }

  // BEGIN, CR00139151, GYH
  /**
   * Method to read the Action details.
   *
   * @param key
   * Contains the action ID.
   *
   * @return The Action details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  // END, CR00139151
  @Deprecated
  public ReadActionDetails readAction(final ActionKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    return actionObj.read(key);
  }

  // BEGIN, CR00176835, AK
  /**
   * Method to create the Action record.
   *
   * @param createActionDetails
   * Contains the action details.
   *
   * @return The Action ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public ActionKey createAction1(
    final CreateActionDetails1 createActionDetails) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    return actionObj.createAction(createActionDetails);
  }

  /**
   * Method to modify the Action record.
   *
   * @param details
   * Contains the action details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public void modifyAction1(final CreateActionDetails1 details)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    actionObj.modifyAction(details);
  }

  // END, CR00176835

  // BEGIN, CR00177579, AK
  /**
   * Method to read the <code>Action</code> record.
   *
   * @param actionKey
   * Contains the actionID.
   * @return The details of the Action record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public CreateActionDetails1 readAction1(final ActionKey actionKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    return actionObj.readAction(actionKey);
  }

  /**
   * Method to list the situations that can be associated with the action.
   *
   * @param actionPlanActionkey
   * Contains the ActionPlan ID and Action ID.
   * @return The list of Situation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public SituationDtlsList listSituationsForAssociation(
    ActionPlanActionRecordStatuskey actionPlanActionkey) throws AppException,
      InformationalException {

    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    return actionObj.listSituationsForAssociation(actionPlanActionkey);
  }

  /**
   * Method to list the situations associated with the action.
   *
   * @param actionKey
   * Contains the action ID.
   * @return The list of Situation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public SituationDtlsList listAssociatedSituations(ActionKey actionKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Action actionObj = curam.core.sl.fact.ActionFactory.newInstance();

    return actionObj.listAssociatedSituations(actionKey);
  }

  /**
   * Method to associate situations with the action.
   * If it is a new situation, a <code> Situation</code> record is created and
   * associated with the action.
   *
   * @param associateSituationsDetails
   * Contains the action ID and the situation details to be associated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void associateSituations(
    AssociateSituationWithActionDtls associateSituationsDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Situation situationObj = SituationFactory.newInstance();
    ActionSituationLinkDtls actionSituationLinkDtls;

    // BEGIN, CR00226282, AK
    if (ClientActionConst.kAssociateNew.equals(
      associateSituationsDetails.clientActionID)) {
      // BEGIN, CR00208312, AK
      if (!CuramConst.gkEmpty.equals(
        associateSituationsDetails.newSituationDetails.situationdtls.situationRequiringAction)
          || !CuramConst.gkEmpty.equals(
            associateSituationsDetails.newSituationDetails.situationdtls.situationCategory)
            || !CuramConst.gkEmpty.equals(
              associateSituationsDetails.newSituationDetails.allegationIDTabList)
              || !CuramConst.gkEmpty.equals(
                associateSituationsDetails.newSituationDetails.concernCaseparticipantTabList)
                || // BEGIN, CR00216008, AK
                !Date.kZeroDate.equals(
                  associateSituationsDetails.newSituationDetails.situationdtls.actualEndDate)
                  || !Date.kZeroDate.equals(
                    associateSituationsDetails.newSituationDetails.situationdtls.expectedEndDate)
                    || // END, CR00216008
                    !CuramConst.gkEmpty.equals(
                      associateSituationsDetails.newSituationDetails.situationdtls.outcome)
                      || !CuramConst.gkEmpty.equals(
                        associateSituationsDetails.newSituationDetails.situationdtls.comments)) {
        // END, CR00208312
        actionSituationLinkDtls = new ActionSituationLinkDtls();
        actionSituationLinkDtls.actionID = associateSituationsDetails.actionID;
        actionSituationLinkDtls.situationID = situationObj.create(associateSituationsDetails.newSituationDetails).situationID;
        situationObj.associateActionAndSituation(actionSituationLinkDtls);
      }
    } else if (ClientActionConst.kAssociateExisting.equals(
      associateSituationsDetails.clientActionID)) {
      final StringList situationStringList = StringUtil.tabText2StringListWithTrim(
        associateSituationsDetails.situationTabList);

      for (final String situationID : situationStringList.items()) {
        actionSituationLinkDtls = new ActionSituationLinkDtls();
        actionSituationLinkDtls.situationID = Long.parseLong(situationID);
        actionSituationLinkDtls.actionID = associateSituationsDetails.actionID;
        situationObj.associateActionAndSituation(actionSituationLinkDtls);
      }
    }
    // END, CR00226282
  }

  /**
   * Method to get a list of actions associated with the specified
   * <code>ActionPlan</code>.
   *
   * @param actionPlanKey
   * Contains the actionPlanID.
   * @return Contains the list of Actions associated with the Action Plan.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ParentActionDetailsList listActions(ActionPlanKey actionPlanKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Action actionObj = ActionFactory.newInstance();
    final ParentLinkIDParentTypeDtls parentLinkIDParentTypeDtls = new ParentLinkIDParentTypeDtls();

    parentLinkIDParentTypeDtls.parentLinkID = actionPlanKey.actionPlanID;
    parentLinkIDParentTypeDtls.parentType = ACTIONPARENTTYPE.ACTIONPLAN;
    return actionObj.list(parentLinkIDParentTypeDtls);

  }

  /**
   * Method to get the details of the Action Owners of type
   * <code>ConcernRole</code> with the name appended with the age. The list
   * element comprises of the Concern Role ID, and the name appended with age of
   * the concern role in brackets.
   *
   * @param actionKey
   * Contains the actionID
   *
   * @return The details of the Concern Action Owners.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListMemberDetails getConcernRoleActionOwners(ActionKey actionKey)
    throws AppException, InformationalException {

    final curam.core.sl.entity.intf.ActionOwner actionOwnerObj = ActionOwnerFactory.newInstance();
    final ActionIDAndRecordStatusDtls actionIDAndRecordStatusDtls = new ActionIDAndRecordStatusDtls();
    final ConcernRole concernRoleobj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRolekey;
    final ListMemberDetails actionOwnerDetails = new ListMemberDetails();
    MemberDetails memberDetails;
    PersonKey personKey;
    final Person personObj = PersonFactory.newInstance();
    // BEGIN, CR00214099, AK
    final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    final CalculationEndDate endDate = new CalculationEndDate();
    final CalculationStartDate startDate = new CalculationStartDate();

    // END, CR00214099

    actionIDAndRecordStatusDtls.actionID = actionKey.actionID;
    final ActionOwnerDtlsList actionOwnerDtlsList = actionOwnerObj.searchByActionID(
      actionIDAndRecordStatusDtls);

    for (final ActionOwnerDtls dtls : actionOwnerDtlsList.dtls.items()) {
      if (ACTIONOWNERTYPE.CONCERNROLE.equals(dtls.ownerType)) {
        concernRolekey = new ConcernRoleKey();
        concernRolekey.concernRoleID = dtls.ownerConcernRoleID;
        final ConcernRoleDtls concernRoleDtls = concernRoleobj.read(
          concernRolekey);

        memberDetails = new MemberDetails();
        memberDetails.participantRoleID = concernRoleDtls.concernRoleID;
        // BEGIN, CR00235689, AK
        memberDetails.name = concernRoleDtls.concernRoleName;
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
          concernRolekey);

        if (CONCERNROLETYPE.PERSON.equals(
          concernRoleTypeDetails.concernRoleType)) {
          personKey = new PersonKey();
          personKey.concernRoleID = dtls.ownerConcernRoleID;
          startDate.startDate = personObj.readDateOfBirth(personKey).dateOfBirth;
        }
        if (CONCERNROLETYPE.REPRESENTATIVE.equals(
          concernRoleTypeDetails.concernRoleType)) {
          final Representative representativeObj = RepresentativeFactory.newInstance();

          startDate.startDate = representativeObj.readRepresentativeDetails(concernRolekey).dateOfBirth;
        }
        if (CONCERNROLETYPE.PROSPECTPERSON.equals(
          concernRoleTypeDetails.concernRoleType)) {
          final ProspectPerson prospectPersonObj = ProspectPersonFactory.newInstance();
          final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

          prospectPersonKey.concernRoleID = dtls.ownerConcernRoleID;
          startDate.startDate = prospectPersonObj.readProspectPersonDOB(prospectPersonKey).dateOfBirth;
        }
        if (!Date.kZeroDate.equals(startDate.startDate)) {
          endDate.endDate = Date.getCurrentDate();
          memberDetails.name = memberDetails.name.concat(GeneralConstants.kSpace).concat(GeneralConstants.kOpenBracket).concat(String.valueOf(tabDetailFormatterObj.calculateAge(startDate, endDate).ageYears)).concat(
            GeneralConstants.kCloseBracket);
        }
        // END, CR00235689
        actionOwnerDetails.memberDetailsList.dtls.addRef(memberDetails);
      }
    }
    return actionOwnerDetails;
  }
  // END, CR00177579
}
