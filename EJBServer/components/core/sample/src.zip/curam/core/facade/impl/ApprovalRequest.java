/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.approvalrequest.impl.ApprovalRequestHandlerDAO;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.core.facade.struct.ApprovalRequestAllocationDetails;
import curam.core.facade.struct.ApprovalRequestReadPageDetails;
import curam.core.facade.struct.ApprovalRequestReadPageKey;
import curam.core.sl.struct.AllocationTargetDetails;
import curam.core.sl.struct.AllocationTargetList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for the Approval Request facade
 * methods.
 */
public class ApprovalRequest extends curam.core.facade.base.ApprovalRequest {

  @Inject
  protected ApprovalRequestHandlerDAO approvalRequestHandlerDAO;

  /**
   * constructor for Guice.
   */
  protected ApprovalRequest() {

    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ApprovalRequestReadPageDetails readApprovalRequestApprovePage(
    ApprovalRequestReadPageKey key) throws AppException,
      InformationalException {

    final ApprovalRequestReadPageDetails approvalRequestReadPageDetails = new ApprovalRequestReadPageDetails();

    approvalRequestReadPageDetails.pageURI = approvalRequestHandlerDAO.get(APPROVALRELATEDTYPEEntry.get(key.relatedType)).getApproveClientURI(key.relatedID).getURI();
    return approvalRequestReadPageDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ApprovalRequestReadPageDetails readApprovalRequestRejectPage(
    ApprovalRequestReadPageKey key) throws AppException,
      InformationalException {

    final ApprovalRequestReadPageDetails approvalRequestReadPageDetails = new ApprovalRequestReadPageDetails();

    approvalRequestReadPageDetails.pageURI = approvalRequestHandlerDAO.get(APPROVALRELATEDTYPEEntry.get(key.relatedType)).getRejectClientURI(key.relatedID).getURI();
    return approvalRequestReadPageDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ApprovalRequestReadPageDetails readApprovalRequestHomePage(
    ApprovalRequestReadPageKey key) throws AppException,
      InformationalException {

    final ApprovalRequestReadPageDetails approvalRequestReadPageDetails = new ApprovalRequestReadPageDetails();

    approvalRequestReadPageDetails.pageURI = approvalRequestHandlerDAO.get(APPROVALRELATEDTYPEEntry.get(key.relatedType)).getHomeClientURI(key.relatedID).getURI();
    return approvalRequestReadPageDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AllocationTargetList manualAllocationStragegy(
    ApprovalRequestAllocationDetails key) throws AppException,
      InformationalException {

    final AllocationTargetList allocationTargetList = new AllocationTargetList();

    final AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    // Set the allocation name
    allocationTargetDetails.name = key.assignmentTo;

    // Set the allocation type
    allocationTargetDetails.type = key.assignType;

    allocationTargetList.dtls.addRef(allocationTargetDetails);

    // Return the allocation list
    return allocationTargetList;
  }

}
