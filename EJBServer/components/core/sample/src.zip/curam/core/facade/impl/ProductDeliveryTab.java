/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.sl.fact.ProductDeliveryTabFactory;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.ProductDeliveryTabDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * */
public class ProductDeliveryTab extends curam.core.facade.base.ProductDeliveryTab {

  // ___________________________________________________________________________
  /**
   * Read the details required for the Product Delivery tab details panel.
   *
   * @param key key required to read the product delivery case tab details.
   *
   * @return Details required for the Product Delivery Sample tab details
   * panel.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public ProductDeliveryTabDetails readProductDeliveryTabDetails(CaseIDKey key) throws AppException,
      InformationalException {

    return ProductDeliveryTabFactory.newInstance().readProductDeliveryTabDetails(
      key);
  }

}
