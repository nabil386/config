/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.QUERYTYPE;
import curam.core.facade.struct.CreateOrRunInvestigationQueryDetails;
import curam.core.facade.struct.CreateOrRunInvestigationQueryResult;
import curam.core.facade.struct.CreateOrRunInvestigationQueryResultStruct;
import curam.core.facade.struct.ListAndRunInvestigationQueryDetails;
import curam.core.facade.struct.ListAndRunInvestigationQueryDetailsStruct;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.QueryKey;
import curam.core.sl.entity.struct.QueryTypeKey;
import curam.core.sl.fact.InvestigationQueryFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.struct.InitialInvestigationQuerySearchCriteria;
import curam.core.sl.struct.InvestigationQueryDetails;
import curam.core.sl.struct.ListQueriesForUserResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.BPOQUERY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the
 * Investigation Query presentation layer.
 */
public abstract class InvestigationQuery extends curam.core.facade.base.InvestigationQuery {

  // _________________________________________________________________________
  /**
   * This method creates an investigation query.
   *
   * @param details The investigation query details.
   *
   * @return Created query id.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public QueryKey create(InvestigationQueryDetails details)
    throws AppException, InformationalException {

    final curam.core.sl.intf.InvestigationQuery investigationQueryObj = curam.core.sl.fact.InvestigationQueryFactory.newInstance();

    return investigationQueryObj.create(details);
  }

  // _________________________________________________________________________
  /**
   * @param details The investigation search criteria for a query.
   *
   * @return List of investigation that match the query and the query id.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #createOrRunWithMessages()}. This
   * method has been deprecated to introduce new message handling. See release
   * note: CR00283985.
   *
   * This method creates or runs an investigation search query.
   *
   * If the client action was saved and a non zero queryID was supplied,
   * then that query record will be modified. If the client action was run,
   * the query will be executed and the results returned.
   */
  @Override
  @Deprecated
  public CreateOrRunInvestigationQueryResult createOrRun(
    CreateOrRunInvestigationQueryDetails details) throws AppException,
      InformationalException {

    final CreateOrRunInvestigationQueryResult result = new CreateOrRunInvestigationQueryResult();

    final curam.core.sl.intf.InvestigationQuery investigationQueryObj = curam.core.sl.fact.InvestigationQueryFactory.newInstance();

    if (details.actionIDProperty.equals(ClientActionConst.kSave_Query)
      || details.actionIDProperty.equals(
        ClientActionConst.kSave_Query_From_List)) {

      result.queryKey = investigationQueryObj.create(details.dtls);

    } else if (details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {
      result.runResult = investigationQueryObj.run(details.dtls);
    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 11);
    }

    return result;
  }

  // BEGIN, CR00276230, ELG
  // _________________________________________________________________________
  /**
   * This method creates or runs an investigation search query.
   *
   * If the client action was saved and a non zero queryID was supplied,
   * then that query record will be modified. If the client action was run,
   * the query will be executed and the results returned.
   *
   * @param details The investigation search criteria for a query.
   *
   * @return List of investigation that match the query, query id and
   * informational message list.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateOrRunInvestigationQueryResultStruct createOrRunWithMessages(
    final CreateOrRunInvestigationQueryDetails details) throws AppException,
      InformationalException {

    final CreateOrRunInvestigationQueryResultStruct createOrRunInvestigationQueryResultStruct = new CreateOrRunInvestigationQueryResultStruct();

    final curam.core.sl.intf.InvestigationQuery investigationQueryObj = InvestigationQueryFactory.newInstance();

    if (details.actionIDProperty.equals(ClientActionConst.kSave_Query)
      || details.actionIDProperty.equals(
        ClientActionConst.kSave_Query_From_List)) {

      createOrRunInvestigationQueryResultStruct.queryKey = investigationQueryObj.create(
        details.dtls);

    } else if (details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {

      createOrRunInvestigationQueryResultStruct.runResult = investigationQueryObj.run(
        details.dtls);

    } else {

      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 10);

    }

    collectInformationals(createOrRunInvestigationQueryResultStruct.msgList);

    return createOrRunInvestigationQueryResultStruct;

  }

  // ___________________________________________________________________________
  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * The list to add the informational messages to
   */
  protected void collectInformationals(
    final InformationalMsgDtlsList msgDtlsList) {

    // Get the list of informational messages
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;
      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }

  }

  // END, CR00276230

  // _________________________________________________________________________
  /**
   * Method returns initial investigation search criteria to populate create
   * investigation query search criteria.
   *
   * @return Initial create query investigation search criteria
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InitialInvestigationQuerySearchCriteria getInitialSearchCriteria()
    throws AppException, InformationalException {

    final curam.core.sl.intf.InvestigationQuery investigationQueryObj = curam.core.sl.fact.InvestigationQueryFactory.newInstance();

    return investigationQueryObj.getInitialSearchCriteria();
  }

  // _________________________________________________________________________
  /**
   * @param key Investigation query identifier to run
   *
   * @return Investigation query details list and selected query
   * investigation search results
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #listAndRunWithMessages()}. This
   * method has been deprecated to introduce new message handling. See release
   * note: CR00283985.
   *
   * Allows a case worker to search for active investigation queries by
   * user name and run selected investigation query.
   */
  @Override
  @Deprecated
  public ListAndRunInvestigationQueryDetails listAndRun(QueryKey key)
    throws AppException, InformationalException {

    final ListAndRunInvestigationQueryDetails listAndRunInvestigationQueryDetails = new ListAndRunInvestigationQueryDetails();

    listAndRunInvestigationQueryDetails.queryListDtls = listForUser();

    if (key.queryID != CuramConst.gkZero) {

      final curam.core.sl.intf.InvestigationQuery investigationQueryObj = curam.core.sl.fact.InvestigationQueryFactory.newInstance();

      listAndRunInvestigationQueryDetails.runResult = investigationQueryObj.runSaved(
        key);

      listAndRunInvestigationQueryDetails.runResult.numberOfRecords = listAndRunInvestigationQueryDetails.runResult.list.searchDtls.size();

    }

    return listAndRunInvestigationQueryDetails;
  }

  // BEGIN, CR00276230, ELG
  // _________________________________________________________________________
  /**
   * Allows a case worker to search for active investigation queries by
   * user name and run selected investigation query.
   *
   * @param key Investigation query identifier to run
   *
   * @return Investigation query details list, selected query investigation
   * search results, and a list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListAndRunInvestigationQueryDetailsStruct listAndRunWithMessages(
    final QueryKey key) throws AppException, InformationalException {

    final ListAndRunInvestigationQueryDetailsStruct listAndRunInvestigationQueryDetailsStruct = new ListAndRunInvestigationQueryDetailsStruct();

    listAndRunInvestigationQueryDetailsStruct.queryListDtls = listForUser();

    if (key.queryID != 0) {

      final curam.core.sl.intf.InvestigationQuery investigationQueryObj = InvestigationQueryFactory.newInstance();

      listAndRunInvestigationQueryDetailsStruct.runResult = investigationQueryObj.runSaved(
        key);

      listAndRunInvestigationQueryDetailsStruct.runResult.numberOfRecords = listAndRunInvestigationQueryDetailsStruct.runResult.list.searchDtls.size();

    }

    collectInformationals(listAndRunInvestigationQueryDetailsStruct.msgList);

    return listAndRunInvestigationQueryDetailsStruct;

  }

  // END, CR00276230

  // _________________________________________________________________________
  /**
   * This method searches investigation queries for the logged on user.
   *
   * @return List of investigation query details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListQueriesForUserResult listForUser() throws AppException,
      InformationalException {

    final ListQueriesForUserResult listQueriesForUserResult = new ListQueriesForUserResult();

    final curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    final QueryTypeKey queryTypeKey = new QueryTypeKey();

    queryTypeKey.queryType = QUERYTYPE.INVESTIGATIONQUERY;

    listQueriesForUserResult.dtls = queryObj.listUserQueries(queryTypeKey);

    return listQueriesForUserResult;
  }

  // _________________________________________________________________________
  /**
   * This method modifies an investigation query.
   *
   * @param details The investigation search criteria for a query.
   *
   * @return Modified investigation query id.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public QueryKey modify(InvestigationQueryDetails details)
    throws AppException, InformationalException {

    final curam.core.sl.intf.InvestigationQuery investigationQueryObj = curam.core.sl.fact.InvestigationQueryFactory.newInstance();

    return investigationQueryObj.modify(details);
  }

  // _________________________________________________________________________
  /**
   * Reads investigation query name and investigation search criteria.
   *
   * @param key Investigation query identifier
   *
   * @return Investigation query name and saved investigation search criteria
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InvestigationQueryDetails read(QueryKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.InvestigationQuery investigationQueryObj = curam.core.sl.fact.InvestigationQueryFactory.newInstance();

    return investigationQueryObj.read(key);
  }

}
