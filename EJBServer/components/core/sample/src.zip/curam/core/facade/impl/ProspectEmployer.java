/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006-2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import curam.codetable.CONCERNROLEALTERNATEID;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.fact.ConcernRoleAlternateIDFactory;
import curam.core.facade.fact.EmployerFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.intf.Employer;
import curam.core.facade.struct.*;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.fact.MaintainProspectEmployerDetailsFactory;
import curam.core.sl.fact.ProspectEmployerHomePageFactory;
import curam.core.sl.fact.ProspectEmployerRegistrationFactory;
import curam.core.sl.fact.ProspectEmployerSearchRouterFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.sl.intf.MaintainProspectEmployerDetails;
import curam.core.sl.intf.ProspectEmployerHomePage;
import curam.core.sl.intf.ProspectEmployerRegistration;
import curam.core.sl.intf.ProspectEmployerSearchRouter;
import curam.core.sl.struct.ProspectEmployerHomeDetails;
import curam.core.sl.struct.ProspectEmployerRegistrationDtls;
import curam.core.sl.struct.ProspectEmployerSearchDtls;
import curam.core.sl.struct.ReadProspectEmployerResult;
import curam.core.struct.AlternateIDTypeCodeKey;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmployerDetails;
import curam.core.struct.EmployerSearchDtls;
import curam.core.struct.OtherAddressData;
import curam.message.BPOADDRESS;
import curam.message.BPOPROSPECTEMPLOYERSEARCH;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.message.CatEntry;
import curam.util.transaction.TransactionInfo;

/**
 * This process class provides the functionality for the Prospect Employer
 * presentation layer.
 */
public abstract class ProspectEmployer
  extends curam.core.facade.base.ProspectEmployer {

  // BEGIN, CR00234017 , DJ
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu =
    XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParamConcernRoleID =
    XmlMetaDataConst.kParamConcernRoleID;

  @Deprecated
  protected static final String kSeparator =
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  /**
   * Constant for the minimum length of a Phone Number.
   */
  protected static final int kMinimumPhoneNumberLength = 3;

  protected static final String kCommaSpace =
    CuramConst.gkComma + CuramConst.gkSpace;

  // END, CR00234017

  /**
   * The width used to trim the trading name values in the search results
   */
  protected final int TRADING_NAME_WIDTH = 20;

  /**
   * The width used to trim the registered name values in the search results
   */
  protected final int REGISTERED_NAME_WIDTH = 20;

  /**
   * The width used to trim the business address values in the search results
   */
  protected final int BUSINESS_ADDRESS_WIDTH = 32;

  /**
   * The width used to trim the city values in the search results
   */
  protected final int CITY_WIDTH = 10;

  /**
   * This method modifies the Prospect Employer
   *
   * @param details
   * - the updated details of the Prospect Employer
   * @return the modified details of Prospect Employer
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ModifyEmployerReturnDetails
    modifyProspectEmployer(final ModifyEmployerDetails details)
      throws AppException, InformationalException {

    // Prospect Employer maintenance object and key
    final MaintainProspectEmployerDetails maintainProspectEmployerDetails =
      curam.core.sl.fact.MaintainProspectEmployerDetailsFactory.newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey =
      new curam.core.struct.MaintainConcernRoleKey();

    // BEGIN, CR00190252, NP
    final ProspectEmployerRegistrationDtls dtls =
      new ProspectEmployerRegistrationDtls();

    dtls.registeredName = details.readEmployerDetails.registeredName;
    dtls.tradingName = details.readEmployerDetails.tradingName;
    validateProspectEmployerName(dtls);
    // END, CR00190252
    // Details to be returned
    final ModifyEmployerReturnDetails modifyEmployerReturnDetails =
      new ModifyEmployerReturnDetails();

    // Get the concern role ID from the modify details.
    maintainConcernRoleKey.concernRoleID =
      details.readEmployerDetails.concernRoleID;

    // Struct passed to modifyProspectEmployer
    final EmployerDetails employerDetails = new EmployerDetails();

    employerDetails.assign(details.readEmployerDetails);

    // Modify the Prospect employer
    modifyEmployerReturnDetails.informationalMsgDtlsList =
      maintainProspectEmployerDetails
        .modifyProspectEmployer(maintainConcernRoleKey, employerDetails);

    // Return details
    return modifyEmployerReturnDetails;
  }

  /**
   * This method registers a prospect employer with the organization
   *
   * @param details
   * The prospect employer to be registered
   *
   * @return details resulting out from the modify operation
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ProspectEmployerRegistrationResult registerProspectEmployer(
    final ProspectEmployerRegistrationDetails details)
    throws AppException, InformationalException {

    // Prospect Employer registration object
    final curam.core.sl.intf.ProspectEmployerRegistration prospectEmployerRegistrationObj =
      curam.core.sl.fact.ProspectEmployerRegistrationFactory.newInstance();

    // BEGIN, 162475, NN
    validateAlternateID(details.prospectEmployerRegistrationDtls);
    // END, 162475

    // BEGIN, CR00190252, NP
    validateProspectEmployerName(details.prospectEmployerRegistrationDtls);
    // END, CR00190252
    final curam.core.intf.ConcernRole concernRoleObj =
      ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    if (details.prospectEmployerRegistrationDtls.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID =
        details.prospectEmployerRegistrationDtls.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      details.prospectEmployerRegistrationDtls.concernID =
        concernRoleDtls.concernID;
    }
    // BEGIN,CR00096719,GM
    details.prospectEmployerRegistrationDtls.contactTitle =
      details.prospectEmployerRegistrationDtls.companyContactTitle;
    // END,CR00096719

    // BEGIN, CR00078486, POH
    final ProspectEmployerRegistrationResult prospectEmployerRegistrationResult =
      new ProspectEmployerRegistrationResult();

    prospectEmployerRegistrationResult.registrationIDDetails =
      prospectEmployerRegistrationObj
        .registerProspectEmployer(details.prospectEmployerRegistrationDtls);

    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      prospectEmployerRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }

    return prospectEmployerRegistrationResult;
    // END, CR00078486

  }

  /**
   * Validates the prospect employer's alternateID (SSN) doesn't already exist
   * for another prospect employer
   *
   * @param details
   * Prospect Employer information
   * @throws InformationalException
   */
  // BEGIN, 162475, NN
  protected void
    validateAlternateID(final ProspectEmployerRegistrationDtls details)
      throws AppException, InformationalException {

    // Create an informational manager
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // check that the alternateID doesn't already exist for another Prospect
    // Employer
    if (details.socialSecurityNumber.length() > 0) {

      // check if the alternateID already exists
      final AlternateIDTypeCodeKey alternateIDTypeCodeKey =
        new AlternateIDTypeCodeKey();
      alternateIDTypeCodeKey.alternateID = details.socialSecurityNumber;
      alternateIDTypeCodeKey.statusCode = RECORDSTATUS.NORMAL;
      alternateIDTypeCodeKey.typeCode =
        CONCERNROLEALTERNATEID.PROSPECT_EMPLOYER_REFERENCE_NUMBER;
      try {

        ConcernRoleAlternateIDFactory.newInstance()
          .readByAltIDTypeCode(alternateIDTypeCodeKey);

      } catch (final RecordNotFoundException e) {
        // no previous record found, fine to proceed
        return;
      }

      // create the warning string as another Prospect Employer already
      // uses this AlternateID/SSN.
      final curam.util.exception.LocalisableString infoMessage =
        new curam.util.exception.LocalisableString(
          BPOPROSPECTEMPLOYERSEARCH.ERR_PROSPECTEMPLOYER_ALTERNATEID_ALREADY_EXISTS);

      infoMessage.arg(details.socialSecurityNumber);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(infoMessage,
          curam.util.resources.GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    }
  }

  // END, 162475

  /**
   * This method registers a given Prospect Employer as an Employer
   *
   * @param key
   * - The Prospect Employer key to be registered as an employer
   * @param details
   * - the Employer details
   * @return - the details resulting from the employer registration process
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ProspectEmployerRegistrationResult
    registerProspectEmployerAsEmployer(final ProspectEmployerKey key,
      final ProspectEmployerRegistrationDetails details)
      throws AppException, InformationalException {

    final curam.core.sl.intf.ProspectEmployerRegistration prospectEmployerRegistrationObj =
      curam.core.sl.fact.ProspectEmployerRegistrationFactory.newInstance();

    final ProspectEmployerRegistrationResult prospectEmployerRegistrationResult =
      new ProspectEmployerRegistrationResult();

    // BEGIN,CR00096719,GM
    details.prospectEmployerRegistrationDtls.contactTitle =
      details.prospectEmployerRegistrationDtls.companyContactTitle;
    // END,CR00096719

    prospectEmployerRegistrationResult.registrationIDDetails =
      prospectEmployerRegistrationObj.registerProspectEmployerAsEmployer(
        key.maintainConcernRoleKey, details.prospectEmployerRegistrationDtls);

    // BEGIN, CR00078486, POH
    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      prospectEmployerRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    return prospectEmployerRegistrationResult;

  }

  // ___________________________________________________________________________
  /**
   * This method reads a Prospect employer record
   *
   * @param key
   * - The Prospect Employer key of the record to be read
   * @return - the prospect employer details
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ReadEmployerDetailsDetails
    readProspectEmployerDetails(final ReadEmployerDetailsKey key)
      throws AppException, InformationalException {

    // Prospect Employer maintenance object and key
    final curam.core.sl.intf.MaintainProspectEmployerDetails maintainProspectEmployerDetailsObj =
      curam.core.sl.fact.MaintainProspectEmployerDetailsFactory.newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey =
      new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned
    final ReadEmployerDetailsDetails readEmployerDetails =
      new ReadEmployerDetailsDetails();

    // Get the concern role ID from the search key.
    maintainConcernRoleKey.concernRoleID =
      key.maintainConcernRoleKey.concernRoleID;

    // Details struct for the Prospect Employer read
    EmployerDetails employerDetails;

    // Read the prospect employer details
    employerDetails = maintainProspectEmployerDetailsObj
      .readProspectEmployer(maintainConcernRoleKey);
    readEmployerDetails.readEmployerDetails.assign(employerDetails);

    // Get the context description for the concern role
    // BEGIN, CR00232051, GD
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      employerDetails.concernRoleID;

    final curam.core.facade.intf.ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    final ParticipantContextDescriptionDetails participantContextDescriptionDetails =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey);

    readEmployerDetails.participantContextDetails.participantContextDescriptionDetails.description =
      participantContextDescriptionDetails.description;
    // END, CR00232051

    // Return Details
    return readEmployerDetails;
  }

  /**
   * Searches for an employer by EmployerSearchKey.
   *
   * @param key
   * - the search criteria
   * @return Employer details.
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0, replaced by
   * {@link #curam.core.facade.impl.Employer.search1(curam.core.facade.struct.EmployerSearchKey1)}
   * .
   */
  @Override
  @Deprecated
  // BEGIN, CR00234017, DJ
  public EmployerSearchResult searchEmployers(final EmployerSearchKey key)
    throws AppException, InformationalException {

    EmployerSearchResult employerSearchResult;

    final Employer delegate = EmployerFactory.newInstance();

    employerSearchResult = delegate.search(key);

    final EmployerAndProspectEmployerSearchResult result =
      new EmployerAndProspectEmployerSearchResult();

    result.employerAndProspectEmployerSearchResult.eDetails
      .assign(employerSearchResult.employerSearchResult.details);

    trimValues(result);

    employerSearchResult.employerSearchResult.details
      .assign(result.employerAndProspectEmployerSearchResult.eDetails);

    return employerSearchResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectEmployer#searchEmployerDetails(EmployerSearchKey1)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerDetails(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  @Override
  public EmployerSearchResult1 searchEmployers1(final EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // END, CR00282028
    EmployerSearchResult1 employerSearchResult1;
    final Employer delegate = EmployerFactory.newInstance();

    employerSearchResult1 = delegate.search1(key);
    return employerSearchResult1;
  }

  // END, CR00234017

  /**
   * This method searches for prospect employers and employers depending on the
   * ProspectEmployerSearchKey
   *
   * @param key
   * - the search criteria.
   * @return List of Employers and Prospect Employers
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0, replaced by
   * {@link #curam.core.facade.impl.Employer.search1(curam.core.facade.struct.EmployerSearchKey1)}
   * .
   */
  @Override
  @Deprecated
  public EmployerAndProspectEmployerSearchResult
    searchEmployersAndProspectEmployers(final ProspectEmployerSearchKey key)
      throws AppException, InformationalException {

    // Prospect Employer Search object.
    final ProspectEmployerSearchRouter prospectEmployerSearchRouterObj =
      ProspectEmployerSearchRouterFactory.newInstance();

    // Details to be returned.

    curam.core.sl.struct.EmployerAndProspectEmployerSearchResult employerAndProspectEmployerSearchResult;

    final EmployerAndProspectEmployerSearchResult result =
      new EmployerAndProspectEmployerSearchResult();

    // BEGIN CR00081691, PN
    result.employerIndicator = 0;
    result.prospectEmployerIndicator = 0;
    // END CR00081691
    // Call the search.
    // BEGIN CR00096333, PN
    int employerSearchResultsSize = 0;
    int prospectemployerSearchResultsSize = 0;

    // END CR00096333
    employerAndProspectEmployerSearchResult = prospectEmployerSearchRouterObj
      .searchEmployersAndProspectEmployers(key.prospectEmployerSearchKey);

    result.employerAndProspectEmployerSearchResult.eDetails =
      employerAndProspectEmployerSearchResult.eDetails;

    if (employerAndProspectEmployerSearchResult.eDetails.dtls.size() != 0) {
      final CatEntry catEntry = BPOPROSPECTEMPLOYERSEARCH.INF_EMPLOYER_TEXT;

      // BEGIN, CR00163471, JC
      result.employer =
        catEntry.getMessageText(TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
    }

    result.employerAndProspectEmployerSearchResult.peDetails =
      employerAndProspectEmployerSearchResult.peDetails;
    // BEGIN CR00096333,PN
    employerSearchResultsSize =
      result.employerAndProspectEmployerSearchResult.eDetails.dtls.size();
    prospectemployerSearchResultsSize =
      result.employerAndProspectEmployerSearchResult.peDetails.dtls.size();

    for (int i = 0; i < employerSearchResultsSize; i++) {
      // BEGIN CR00096360, PN
      // BEGIN, CR00190258, CL
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE
        .getMessageText(TransactionInfo.getProgramLocale())
        .equals(result.employerAndProspectEmployerSearchResult.eDetails.dtls
          .item(i).businessAddress)) // END, CR00340652
      // END, CR00214655
      {
        result.employerAndProspectEmployerSearchResult.eDetails.dtls
          .item(i).businessAddress = CuramConst.gkEmpty;
      }
      // BEGIN, CR00219204, SW
      // BEGIN, CR00340652, KRK
      if (result.employerAndProspectEmployerSearchResult.eDetails.dtls
        .item(i).businessCity
          .equals(BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE
            .getMessageText(TransactionInfo.getProgramLocale()))) {
        // END, CR00340652
        result.employerAndProspectEmployerSearchResult.eDetails.dtls
          .item(i).businessCity = CuramConst.gkEmpty;

      }
      // END, CR00219204
    }
    // END CR00096360
    for (int i = 0; i < prospectemployerSearchResultsSize; i++) {
      // BEGIN CR00096360, PN
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE
        .getMessageText(TransactionInfo.getProgramLocale())
        .equals(result.employerAndProspectEmployerSearchResult.peDetails.dtls
          .item(i).businessAddress)) // END, CR00214655
      // END, CR00340652
      {
        // END, CR00190258
        result.employerAndProspectEmployerSearchResult.peDetails.dtls
          .item(i).businessAddress = CuramConst.gkEmpty;
      }
      // END CR00096360
      // BEGIN, CR00219204, SW
      // BEGIN, CR00340652, KRK
      if (result.employerAndProspectEmployerSearchResult.peDetails.dtls
        .item(i).businessCity
          .equals(BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE
            .getMessageText(TransactionInfo.getProgramLocale()))) {
        // END, CR00340652
        result.employerAndProspectEmployerSearchResult.peDetails.dtls
          .item(i).businessCity = CuramConst.gkEmpty;
      }
      // END, CR00219204
    }
    // END CR00096333
    if (employerAndProspectEmployerSearchResult.peDetails.dtls.size() != 0) {
      final CatEntry catEntry =
        BPOPROSPECTEMPLOYERSEARCH.INF_PROSPECTEMPLOYER_TEXT;

      // BEGIN, CR00163471, JC
      result.prospectEmployer =
        catEntry.getMessageText(TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
    }

    result.employerAndProspectEmployerSearchResult.messages =
      employerAndProspectEmployerSearchResult.messages;

    result.employerAndProspectEmployerSearchResult.result =
      employerAndProspectEmployerSearchResult.result;
    // BEGIN CR00081691, PN
    result.employerIndicator =
      employerAndProspectEmployerSearchResult.eDetails.dtls.size();
    result.prospectEmployerIndicator =
      employerAndProspectEmployerSearchResult.peDetails.dtls.size();
    // END CR00081691
    trimValues(result);
    return result;

  }

  /**
   * This method trims the value of the search results to accommodate them on
   * the search results page
   *
   * @param result
   * - A List containing the search results.
   */
  // BEGIN, CR00198672, VK
  protected void trimValues(
    final curam.core.facade.struct.EmployerAndProspectEmployerSearchResult result) {

    // END, CR00198672

    EmployerSearchDtls employerSearchDtls;
    ProspectEmployerSearchDtls prospectEmployerSearchDtls;

    for (int i =
      0; i < result.employerAndProspectEmployerSearchResult.eDetails.dtls
        .size(); i++) {
      employerSearchDtls =
        result.employerAndProspectEmployerSearchResult.eDetails.dtls.get(i);
      // BEGIN, CR00051657, GM
      if (employerSearchDtls.tradingName != null
        && !employerSearchDtls.tradingName.equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (employerSearchDtls.tradingName.length() > TRADING_NAME_WIDTH) {
          employerSearchDtls.tradingName =
            employerSearchDtls.tradingName.substring(0, TRADING_NAME_WIDTH);
        }
      }
      // BEGIN, CR00051657, GM
      if (employerSearchDtls.registeredName != null
        && !employerSearchDtls.registeredName.equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (employerSearchDtls.registeredName
          .length() > REGISTERED_NAME_WIDTH) {
          employerSearchDtls.registeredName =
            employerSearchDtls.registeredName.substring(0,
              REGISTERED_NAME_WIDTH);
        }
      }
      // BEGIN, CR00051657, GM
      if (employerSearchDtls.businessAddress != null
        && !employerSearchDtls.businessAddress.equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (employerSearchDtls.businessAddress
          .length() > BUSINESS_ADDRESS_WIDTH) {
          employerSearchDtls.businessAddress =
            employerSearchDtls.businessAddress.substring(0,
              BUSINESS_ADDRESS_WIDTH);
        }
      }
      // BEGIN, CR00051657, GM
      if (employerSearchDtls.businessCity != null
        && !employerSearchDtls.businessCity.equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (employerSearchDtls.businessCity.length() > CITY_WIDTH) {
          employerSearchDtls.businessCity =
            employerSearchDtls.businessCity.substring(0, CITY_WIDTH);
        }
      }
    }

    for (int i =
      0; i < result.employerAndProspectEmployerSearchResult.peDetails.dtls
        .size(); i++) {
      prospectEmployerSearchDtls =
        result.employerAndProspectEmployerSearchResult.peDetails.dtls.get(i);
      // BEGIN, CR00051657, GM
      if (prospectEmployerSearchDtls.tradingName != null
        && !prospectEmployerSearchDtls.tradingName
          .equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (prospectEmployerSearchDtls.tradingName
          .length() > TRADING_NAME_WIDTH) {
          prospectEmployerSearchDtls.tradingName =
            prospectEmployerSearchDtls.tradingName.substring(0,
              TRADING_NAME_WIDTH);
        }
      }

      // BEGIN, CR00051657, GM
      if (prospectEmployerSearchDtls.registeredName != null
        && !prospectEmployerSearchDtls.registeredName
          .equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (prospectEmployerSearchDtls.registeredName
          .length() > REGISTERED_NAME_WIDTH) {
          prospectEmployerSearchDtls.registeredName =
            prospectEmployerSearchDtls.registeredName.substring(0,
              REGISTERED_NAME_WIDTH);
        }
      }
      // BEGIN, CR00051657, GM
      if (prospectEmployerSearchDtls.businessAddress != null
        && !prospectEmployerSearchDtls.businessAddress
          .equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (prospectEmployerSearchDtls.businessAddress
          .length() > BUSINESS_ADDRESS_WIDTH) {
          prospectEmployerSearchDtls.businessAddress =
            prospectEmployerSearchDtls.businessAddress.substring(0,
              BUSINESS_ADDRESS_WIDTH);
        }
      }
      // BEGIN, CR00051657, GM
      if (prospectEmployerSearchDtls.businessCity != null
        && !prospectEmployerSearchDtls.businessCity
          .equals(CuramConst.gkEmpty)) {
        // END, CR00051657
        if (prospectEmployerSearchDtls.businessCity.length() > CITY_WIDTH) {
          prospectEmployerSearchDtls.businessCity =
            prospectEmployerSearchDtls.businessCity.substring(0, CITY_WIDTH);
        }
      }

    }

  }

  /**
   * This method searches for prospect employers depending on the
   * ProspectEmployerSearchKey
   *
   * @param key
   * the search criteria.
   *
   * @return List of Prospect Employers
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ProspectEmployerSearchResult
    searchProspectEmployers(final ProspectEmployerSearchKey key)
      throws AppException, InformationalException {

    // Prospect Employer Search object.
    final ProspectEmployerSearchRouter prospectEmployerSearchRouterObj =
      ProspectEmployerSearchRouterFactory.newInstance();

    // Details to be returned.
    final ProspectEmployerSearchResult prospectEmployerSearchResult =
      new ProspectEmployerSearchResult();

    // Call the search.
    prospectEmployerSearchResult.prospectEmployerSearchResult =
      prospectEmployerSearchRouterObj
        .searchProspectEmployers(key.prospectEmployerSearchKey);

    final EmployerAndProspectEmployerSearchResult result =
      new EmployerAndProspectEmployerSearchResult();
    // BEGIN CR00096333, PN
    int prospectemployerSearchresultSize = 0;

    prospectemployerSearchresultSize =
      prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails.dtls
        .size();

    for (int i = 0; i < prospectemployerSearchresultSize; i++) {
      // BEGIN CR00096360, PN
      // BEGIN, CR00190258, CL
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE
        .getMessageText(TransactionInfo.getProgramLocale()).equals(
          prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails.dtls
            .item(i).businessAddress)) // END, CR00340652
      // END, CR00214655
      {
        prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails.dtls
          .item(i).businessAddress = CuramConst.gkEmpty;
      }
      // END CR00096360
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE
        .getMessageText(TransactionInfo.getProgramLocale()).equals(
          prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails.dtls
            .item(i).businessCity)) {
        // END, CR00340652
        // END, CR00214655
        prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails.dtls
          .item(i).businessCity = CuramConst.gkEmpty;
      }
    }
    // END, CR00190258
    // END CR00096333
    result.employerAndProspectEmployerSearchResult.peDetails.assign(
      prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails);

    trimValues(result);

    prospectEmployerSearchResult.prospectEmployerSearchResult.peDetails
      .assign(result.employerAndProspectEmployerSearchResult.peDetails);

    return prospectEmployerSearchResult;
  }

  /**
   * This method searches for current prospect employers(who are not employers)
   * depending on the ProspectEmployerSearchKey.
   *
   * @param key
   * the search criteria.
   *
   * @return List of Prospect Employers
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ProspectEmployerSearchResult
    searchCurrentProspectEmployers(final ProspectEmployerSearchKey key)
      throws AppException, InformationalException {

    key.prospectEmployerSearchKey.currentProspectEmployers = true;
    return this.searchProspectEmployers(key);
  }

  // BEGIN, CR00077847, POH
  /**
   * This method creates a relationship for a Prospect employer with another
   * Prospect Employer
   *
   * @param details
   * - A struct containing the related prospect employer details
   * @return CreatedRelationshipDetails List of informationals - if any exist -
   * to be displayed to user
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public CreatedRelationshipDetails createRelationship(
    final MaintainProspectEmployerRelationshipDetails details)
    throws AppException, InformationalException {

    final MaintainEmployerRelationshipDetails maintainEmployerRelationshipDetails =
      new MaintainEmployerRelationshipDetails();

    maintainEmployerRelationshipDetails.employerRelationshipDetails
      .assign(details.prospectEmployerRelationshipDetails);

    // BEGIN, CR00234017, DJ
    final Employer delegate = EmployerFactory.newInstance();

    return delegate.createRelationship(maintainEmployerRelationshipDetails);
    // END, CR00234017
  }

  /**
   * This method modifies a relationship for a Prospect employer with another
   * Prospect Employer
   *
   * @param details
   * - A struct containing the related prospect employer details
   * @return ModifiedRelationshipDetails List of informationals - if any exist -
   * to be displayed to user
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ModifiedRelationshipDetails modifyRelationship(
    final MaintainProspectEmployerRelationshipDetails details)
    throws AppException, InformationalException {

    final MaintainEmployerRelationshipDetails maintainEmployerRelationshipDetails =
      new MaintainEmployerRelationshipDetails();

    maintainEmployerRelationshipDetails.employerRelationshipDetails
      .assign(details.prospectEmployerRelationshipDetails);

    // BEGIN, CR00234017, DJ
    final Employer delegate = EmployerFactory.newInstance();

    return delegate.modifyRelationship(maintainEmployerRelationshipDetails);
  }

  // END, CR00234017
  // END, CR00077847

  /**
   * This method populates the Register Prospect Employer As Employer Page with
   * the relevant captured prospect employer data
   *
   * @param key
   * - The Prospect Employer Key containing the Concern Role ID
   * @return - The captured Prospect Employer data
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ProspectEmployerRegistrationDetails
    autoPopulateRegistrationFields(final ProspectEmployerKey key)
      throws AppException, InformationalException {

    // Prospect Person Registration object
    final curam.core.sl.intf.ProspectEmployerRegistration prospectEmployerRegistrationObj =
      curam.core.sl.fact.ProspectEmployerRegistrationFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Details to be returned
    final ProspectEmployerRegistrationDetails prospectEmployerRegistrationDetails =
      new ProspectEmployerRegistrationDetails();

    prospectEmployerRegistrationDetails.prospectEmployerRegistrationDtls =
      prospectEmployerRegistrationObj
        .autoPopulateRegistrationFields(key.maintainConcernRoleKey);
    // BEGIN, CR00096719,GM
    prospectEmployerRegistrationDetails.prospectEmployerRegistrationDtls.companyContactTitle =
      prospectEmployerRegistrationDetails.prospectEmployerRegistrationDtls.contactTitle;
    prospectEmployerRegistrationDetails.prospectEmployerRegistrationDtls.contactTitle =
      "";
    // END,CR00096719
    // Return details
    return prospectEmployerRegistrationDetails;
  }

  /**
   * This method return the Prospect Employer Home Page Details
   *
   * @param key
   * - the Prospect Employer Key containing the concernRoleID
   * @return the Prospect Employer Home Page Details
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ReadProspectEmployerHomeDetails
    readHomePageDetails(final ProspectEmployerKey key)
      throws AppException, InformationalException {

    // Prospect Employer Home Page object.
    final ProspectEmployerHomePage prospectEmployerHomePageObj =
      ProspectEmployerHomePageFactory.newInstance();

    // Details to be returned.
    final ReadProspectEmployerHomeDetails readProspectEmployerHomeDetails =
      new ReadProspectEmployerHomeDetails();

    // Struct returned from Prospect Employer Home Page read.
    ReadProspectEmployerResult readProspectEmployerResult;

    // Read the Prospect Employer Home Page details.
    readProspectEmployerResult =
      prospectEmployerHomePageObj.read(key.maintainConcernRoleKey);

    // Assign the returned details.
    readProspectEmployerHomeDetails.details
      .assign(readProspectEmployerResult.details);

    // BEGIN, CR00232051, GD
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.maintainConcernRoleKey.concernRoleID;

    final curam.core.facade.intf.ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    final ParticipantContextDescriptionDetails participantContextDescriptionDetails =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey);

    readProspectEmployerHomeDetails.participantContextDetails.participantContextDescriptionDetails.description =
      participantContextDescriptionDetails.description;
    // END, CR00232051

    // Return the Prospect Employer Home Page details.
    return readProspectEmployerHomeDetails;
  }

  // BEGIN, CR00065868, PCAL
  // ___________________________________________________________________________
  /**
   * Method returns a list of Prospect Employer Snapshot summary details, and
   * the date-of-creation for each Snapshot record.
   *
   * @param key
   * The Prospect Employer record the snapshots are associated with.
   *
   * @return The list of Prospect Employer snapshot details
   */
  @Override
  public ReadProspectEmployerHistoryList
    listProspectEmployerHistory(final ReadProspectEmployerHistoryListKey key)
      throws AppException, InformationalException {

    // Return struct
    final ReadProspectEmployerHistoryList readProspectEmployerHistoryList =
      new ReadProspectEmployerHistoryList();

    // Retrieve the list of snap shot summary details
    final MaintainProspectEmployerDetails maintainProspectEmployerDetailsObj =
      MaintainProspectEmployerDetailsFactory.newInstance();

    readProspectEmployerHistoryList.historyDtls =
      maintainProspectEmployerDetailsObj
        .listProspectEmployerHistory(key.historyKey);

    // Get the context description by reading the concern role of
    // the Prospect Employer record associated with the list of Snapshots
    // BEGIN, CR00232051, GD
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.historyKey.concernRoleID;

    final curam.core.facade.intf.ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    final ParticipantContextDescriptionDetails participantContextDescriptionDetails =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey);

    readProspectEmployerHistoryList.participantContextDescriptionDetails.description =
      participantContextDescriptionDetails.description;
    // END, CR00232051

    // Return the details
    return readProspectEmployerHistoryList;
  }

  // END, CR00065868
  // ___________________________________________________________________________
  /**
   * Validates the employer's name details limits
   *
   * @param details
   * Employer information
   *
   * @throws InformationalException
   */
  // BEGIN, CR00190252, NP
  // BEGIN, CR00198672, VK
  protected void validateProspectEmployerName(
    final ProspectEmployerRegistrationDtls details)
    throws InformationalException {

    // END, CR00198672
    // Create an informational manager
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    if (details.tradingName.toUpperCase()
      .length() > CuramConst.kUpperTRADINGNAME) {

      // create the warning string
      final curam.util.exception.LocalisableString infoMessage =
        new curam.util.exception.LocalisableString(
          curam.message.GENERALCONCERN.ERR_FV_UPPERTRADING_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(details.tradingName.toUpperCase().length()
        - CuramConst.kUpperTRADINGNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(infoMessage,
          curam.util.resources.GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.registeredName.toUpperCase()
      .length() > CuramConst.kUpperREGISTEREDNAME) {

      // create the warning string
      final curam.util.exception.LocalisableString infoMessage =
        new curam.util.exception.LocalisableString(
          curam.message.GENERALCONCERN.ERR_FV_UPPERREGISTERED_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(details.registeredName.toUpperCase().length()
        - CuramConst.kUpperREGISTEREDNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(infoMessage,
          curam.util.resources.GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    informationalManager.failOperation();
    // END, CR00190252
  }

  // BEGIN, CR00234017, DJ
  /**
   * @param key
   * contains the data to be searched for.
   *
   * @return Employer details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #search1()} Searches for an
   * employer by Concern Role ID.
   */
  @Override
  @Deprecated
  public EmployerSearchResult search(final EmployerSearchKey key)
    throws AppException, InformationalException {

    EmployerSearchResult employerSearchResult = new EmployerSearchResult();
    final Employer delegate = EmployerFactory.newInstance();

    employerSearchResult = delegate.search(key);
    return employerSearchResult;
  }

  /**
   * Searches for an employer by primary alternate ID.
   *
   * @param key
   * contains the reference number to be searched for.
   *
   * @return Employer details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmployerReadDetails
    readByReferenceNumber(final EmployerAlternateSearchKey key)
      throws AppException, InformationalException {

    EmployerReadDetails employerReadDetails = new EmployerReadDetails();
    final Employer delegate = EmployerFactory.newInstance();

    employerReadDetails = delegate.readByReferenceNumber(key);
    return employerReadDetails;
  }

  /**
   * Creates an employer trading status record.
   *
   * @param details
   * contains the employer trading details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createTradingStatus(final MaintainTradingStatusDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createTradingStatus(details);
  }

  /**
   * Modifies an employer trading status record.
   *
   * @param details
   * contains the employer trading status details.
   *
   * @return Trading Status informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public TradingStatusMessageList
    modifyTradingStatus(final MaintainTradingStatusDetails details)
      throws AppException, InformationalException {

    TradingStatusMessageList tradingStatusMessageList =
      new TradingStatusMessageList();
    final Employer delegate = EmployerFactory.newInstance();

    tradingStatusMessageList = delegate.modifyTradingStatus(details);
    return tradingStatusMessageList;
  }

  /**
   * Reads an employer trading status record.
   *
   * @param details
   * contains the employer trading status key.
   *
   * @return Trading Status informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadTradingStatusDetails
    readTradingStatus(final ReadTradingStatusKey key)
      throws AppException, InformationalException {

    ReadTradingStatusDetails readTradingStatusDetails =
      new ReadTradingStatusDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readTradingStatusDetails = delegate.readTradingStatus(key);
    return readTradingStatusDetails;
  }

  /**
   * Retrieves a list of employer trading status records.
   *
   * @param key
   * identifies employer trading status.
   *
   * @return A trading status list for the Employer.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadTradingStatusList
    listTradingStatus(final ReadTradingStatusListKey key)
      throws AppException, InformationalException {

    ReadTradingStatusList readTradingStatusList = new ReadTradingStatusList();
    final Employer delegate = EmployerFactory.newInstance();

    readTradingStatusList = delegate.listTradingStatus(key);
    return readTradingStatusList;
  }

  /**
   * Sets Employer Trading Status record to canceled.
   *
   * @param key
   * identifies trading status to be canceled.
   *
   * @return Trading Status informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public TradingStatusMessageList
    cancelTradingStatus(final CancelTradingStatusKey key)
      throws AppException, InformationalException {

    TradingStatusMessageList tradingStatusMessageList =
      new TradingStatusMessageList();
    final Employer delegate = EmployerFactory.newInstance();

    tradingStatusMessageList = delegate.cancelTradingStatus(key);
    return tradingStatusMessageList;
  }

  /**
   * Registers the employer.
   *
   * @param Details
   * Contains the employer registration details.
   *
   * @return employer registration result.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmployerRegistrationResult
    register(final EmployerRegistrationDetails details)
      throws AppException, InformationalException {

    EmployerRegistrationResult employerRegistrationResult =
      new EmployerRegistrationResult();
    final Employer delegate = EmployerFactory.newInstance();

    employerRegistrationResult = delegate.register(details);
    return employerRegistrationResult;
  }

  /**
   * Reads a relationship record for an employer.
   *
   * @param key
   * contains the employer relationship key.
   *
   * @return relationship details found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadEmployerRelationshipDetails
    readRelationship(final ReadEmployerRelationshipKey key)
      throws AppException, InformationalException {

    ReadEmployerRelationshipDetails readEmployerRelationshipDetails =
      new ReadEmployerRelationshipDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readEmployerRelationshipDetails = delegate.readRelationship(key);
    return readEmployerRelationshipDetails;
  }

  /**
   * Retrieves a list of relationship records for an employer.
   *
   * @param key
   * contains the employer identifier.
   *
   * @return list of relationships found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadEmployerRelationshipList
    listRelationship(final ReadEmployerRelationshipListKey key)
      throws AppException, InformationalException {

    ReadEmployerRelationshipList readEmployerRelationshipList =
      new ReadEmployerRelationshipList();
    final Employer delegate = EmployerFactory.newInstance();

    readEmployerRelationshipList = delegate.listRelationship(key);
    return readEmployerRelationshipList;
  }

  /**
   * Cancels an employer relationship record.
   *
   * @param key
   * contains key of the employer relationship which is to be canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelRelationship(final CancelEmployerRelationshipKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelRelationship(key);
  }

  /**
   * Updates an employer with new details.
   *
   * @param details
   * contains the modified details of the Employer.
   *
   * @return Informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ModifyEmployerReturnDetails
    modifyEmployer(final ModifyEmployerDetails details)
      throws AppException, InformationalException {

    ModifyEmployerReturnDetails modifyEmployerReturnDetails =
      new ModifyEmployerReturnDetails();
    final Employer delegate = EmployerFactory.newInstance();

    modifyEmployerReturnDetails = delegate.modifyEmployer(details);
    return modifyEmployerReturnDetails;
  }

  /**
   * Retrieve a list of cases by concern role ID.
   *
   * @param key
   * contains the identifier of employer concerned.
   *
   * @return A list of cases for the employer.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListCaseDetails listCase(final ListCaseKey_fo key)
    throws AppException, InformationalException {

    ListCaseDetails listCaseDetails = new ListCaseDetails();
    final Employer delegate = EmployerFactory.newInstance();

    listCaseDetails = delegate.listCase(key);
    return listCaseDetails;
  }

  /**
   * Retrieves details for the specified employer.
   *
   * @param key
   * contains unique identifier for the Employer.
   *
   * @return Employer details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadEmployerDetailsDetails
    readEmployerDetails(final ReadEmployerDetailsKey key)
      throws AppException, InformationalException {

    ReadEmployerDetailsDetails readEmployerDetailsDetails =
      new ReadEmployerDetailsDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readEmployerDetailsDetails = delegate.readEmployerDetails(key);
    return readEmployerDetailsDetails;
  }

  /**
   * Returns the employer's full name and address.
   *
   * @param key
   * Contains the employer's concern role identifier.
   *
   * @return EmployerNameAndAddressDetails The employer's full name and address.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmployerNameAndAddressDetails
    readFullNameAndAddress(final ReadEmployerDetailsKey key)
      throws AppException, InformationalException {

    EmployerNameAndAddressDetails employerNameAndAddressDetails =
      new EmployerNameAndAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    employerNameAndAddressDetails = delegate.readFullNameAndAddress(key);
    return employerNameAndAddressDetails;
  }

  /**
   * Method returns a list of Employer Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the Employer record the snapshots are associated with.
   *
   * @return The list of Employer snapshot details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadEmployerHistoryList
    listEmployerHistory(final ReadEmployerHistoryListKey key)
      throws AppException, InformationalException {

    ReadEmployerHistoryList readEmployerHistoryList =
      new ReadEmployerHistoryList();
    final Employer delegate = EmployerFactory.newInstance();

    readEmployerHistoryList = delegate.listEmployerHistory(key);
    return readEmployerHistoryList;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectEmployer#searchEmployerDetails(EmployerSearchKey1)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerDetails(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  @Override
  public EmployerSearchResult1 search1(final EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // END, CR00282028
    EmployerSearchResult1 employerSearchResult1 = new EmployerSearchResult1();
    final Employer delegate = EmployerFactory.newInstance();

    employerSearchResult1 = delegate.search1(key);
    return employerSearchResult1;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria. Does not return
   * names as hyperlinks as this is for popup pages.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectEmployer#searchEmployerForPopup(EmployerSearchKey1)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerForPopup(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Override
  @Deprecated
  public EmployerSearchResult1 search1ForPopup(final EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // END, CR00282028
    EmployerSearchResult1 employerSearchResult1 = new EmployerSearchResult1();
    final Employer delegate = EmployerFactory.newInstance();

    employerSearchResult1 = delegate.search1ForPopup(key);
    return employerSearchResult1;
  }

  /**
   * Cancels a concern role address record.
   *
   * @param key
   * contains the concern role address which is to be canceled
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelAddress(key);
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * contains the concern role alternate id which is being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelAlternateID(key);
  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * contains the key to cancel the communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelCommunication(key);
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * contains the ID of the communication exception being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelCommunicationException(key);
  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * contains the contact ID for the record being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelContact(final CancelContactKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelContact(key);
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * contains the ID of the email address being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelEmailAddress(key);
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * contains the details to create a participant note.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelNote(final CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelNote(details);
  }

  /**
   * Cancel a bank account for a participant. This method handles the
   * cancellation of normal bank account as well as joint accounts.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList
    cancelParticipantBankAccount(final CancelParticipantBankAccountKey key)
      throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();
    final Employer delegate = EmployerFactory.newInstance();

    informationMsgDtlsList = delegate.cancelParticipantBankAccount(key);
    return informationMsgDtlsList;
  }

  /**
   * Cancels a phone number record.
   *
   * @param key
   * contains the concern role phone number ID of the phone record
   * being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelPhoneNumber(key);
  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * contains the details of the web address to cancel
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void
    cancelWebAddress(final CancelParticipantWebAddressDetails details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelWebAddress(details);
  }

  /**
   * Creates a concern role address record.
   *
   * @param details
   * contains the concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CreateParticipantAddressDetails
    createAddress(final MaintainParticipantAddressDetails details)
      throws AppException, InformationalException {

    CreateParticipantAddressDetails createParticipantAddressDetails =
      new CreateParticipantAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    createParticipantAddressDetails = delegate.createAddress(details);
    return createParticipantAddressDetails;
  }

  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  @Override
  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createAdministrator(participantAdministratorDetails);
  }

  /**
   * Create a new administrator for the concernRole supplied.
   *
   * @param details
   * contains the administrator role details being entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#createAdministrator(ParticipantAdministratorDetails)}
   */
  @Override
  @Deprecated
  public void createAdminRole(final CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createAdminRole(details);
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * contains the concern role ID and alternate id details being
   * entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CreateParticipantAlternateIDDetails
    createAlternateID(final MaintainParticipantAlternateIDDetails details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails =
      new CreateParticipantAlternateIDDetails();

    createParticipantAlternateIDDetails = delegate.createAlternateID(details);
    return createParticipantAlternateIDDetails;
  }

  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void cancelBankAccount(final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.cancelBankAccount(key);
  }

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * contains the concern role communication exception details being
   * entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createCommunicationException(details);
  }

  /**
   * Create a contact.
   *
   * @param details
   * contains the contact details being entered
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createContact(details);
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * contains the registration details for the contact
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createContactFromUnregisteredParticipant(
    final CreateContactFromUnregisteredParticipant details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createContactFromUnregisteredParticipant(details);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * contains the email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CreateParticipantEmailAddressDetails
    createEmailAddress(final MaintainParticipantEmailAddressDetails details)
      throws AppException, InformationalException {

    CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails =
      new CreateParticipantEmailAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    createParticipantEmailAddressDetails =
      delegate.createEmailAddress(details);
    return createParticipantEmailAddressDetails;
  }

  /**
   * Creates an email communication.
   *
   * @param details
   * contains the details to create the email communication.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Communication#createEmail(curam.core.facade.struct.CreateEmailCommDetails)}
   */
  @Override
  @Deprecated
  public void
    createEmailCommunication(final CreateEmailCommunicationDetails details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createEmailCommunication(details);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * contains the details to create the freeform communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void
    createFreeformCommunincation(final CreateFreeformCommunication details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createFreeformCommunincation(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createHomePhoneNumber(final CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createHomePhoneNumber(key);
  }

  /**
   * This method creates a mailing address for a participant.
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createMailingAddress(final CreateMailingAddress key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createMailingAddress(key);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * contains the participant note details being entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createNote(details);
  }

  /**
   * Creates a concern role phone number record.
   *
   * @param details
   * contains the concern role identifier & concern role phone number
   * details
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CreateParticipantPhoneDetails
    createPhoneNumber(final MaintainParticipantPhoneDetails details)
      throws AppException, InformationalException {

    CreateParticipantPhoneDetails createParticipantPhoneDetails =
      new CreateParticipantPhoneDetails();
    final Employer delegate = EmployerFactory.newInstance();

    createParticipantPhoneDetails = delegate.createPhoneNumber(details);
    return createParticipantPhoneDetails;
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * contains the details to create the template communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void
    createTemplateCommunication(final CreateTemplateCommunication details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createTemplateCommunication(details);
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * contains the web address details being entered
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createWebAddress(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createWorkPhoneNumber(final CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.createWorkPhoneNumber(key);
  }

  /**
   * Display the address given as a single line. The address is formatted base
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData
   * The address formatted with its descriptors i.e. ADD1=Line1,
   * ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AddressString
    displaySingleLineAddress(final OtherAddressData otherAddressData)
      throws AppException, InformationalException {

    AddressString addressString = new AddressString();
    final Employer delegate = EmployerFactory.newInstance();

    addressString = delegate.displaySingleLineAddress(otherAddressData);
    return addressString;
  }

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * Contains the concern role ID & the case ID
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.endDeduction(details);
  }

  /**
   * Formats the bank account details for a participant. The bank details are
   * formatted to display as a single line of text. The formatting is decided by
   * a system variable.
   *
   * @param bankAccountRMDtls
   * bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BankAccountString
    formatBankAcDetailsString(final BankAccountRMDtls bankAccountRMDtls)
      throws AppException, InformationalException {

    BankAccountString bankAccountString = new BankAccountString();
    final Employer delegate = EmployerFactory.newInstance();

    bankAccountString = delegate.formatBankAcDetailsString(bankAccountRMDtls);
    return bankAccountString;
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void insertPrimaryResidenceAddress(final InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.insertPrimaryResidenceAddress(key);
  }

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantActiveAddressList
    listActiveAddresses(final ReadParticipantAddressListKey key)
      throws AppException, InformationalException {

    final ReadParticipantActiveAddressList readParticipantActiveAddressList =
      new ReadParticipantActiveAddressList();
    final Employer delegate = EmployerFactory.newInstance();

    delegate.listActiveAddresses(key);
    return readParticipantActiveAddressList;
  }

  /**
   * Method to list all active bank accounts for a Case Nominee.
   *
   * @param key
   * contains the concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadActiveBankAccountList
    listActiveBankAccount(final ReadParticipantBankAccountListKey key)
      throws AppException, InformationalException {

    final ReadActiveBankAccountList readActiveBankAccountList =
      new ReadActiveBankAccountList();
    final Employer delegate = EmployerFactory.newInstance();

    delegate.listActiveBankAccount(key);
    return readActiveBankAccountList;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key
   * contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated since Curam V6.0. This method is replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Override
  @Deprecated
  public BankAccountListForRedirectionDetails
    listActiveBankAccountForRedirection(
      final ParticipantBankAccountRedirectionKey key)
      throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails =
      new BankAccountListForRedirectionDetails();
    final Employer delegate = EmployerFactory.newInstance();

    bankAccountListForRedirectionDetails =
      delegate.listActiveBankAccountForRedirection(key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key
   * contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BankAccountListForRedirectionDetails
    listActiveBankAccountForRedirection1(
      final ParticipantBankAccountRedirectionKey1 key)
      throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails =
      new BankAccountListForRedirectionDetails();
    final Employer delegate = EmployerFactory.newInstance();

    bankAccountListForRedirectionDetails =
      delegate.listActiveBankAccountForRedirection1(key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantAddressList
    listAddress(final ReadParticipantAddressListKey key)
      throws AppException, InformationalException {

    ReadParticipantAddressList readParticipantAddressList =
      new ReadParticipantAddressList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantAddressList = delegate.listAddress(key);
    return readParticipantAddressList;
  }

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key
   * contains the Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadAddressHistoryList
    listAddressHistory(final ReadAddressHistoryListKey key)
      throws AppException, InformationalException {

    ReadAddressHistoryList readAddressHistoryList =
      new ReadAddressHistoryList();
    final Employer delegate = EmployerFactory.newInstance();

    readAddressHistoryList = delegate.listAddressHistory(key);
    return readAddressHistoryList;
  }

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantAddressStringList
    listAddressString(final ReadParticipantAddressListKey key)
      throws AppException, InformationalException {

    final ParticipantAddressStringList participantAddressStringList =
      new ParticipantAddressStringList();
    final Employer delegate = EmployerFactory.newInstance();

    delegate.listAddressString(key);
    return participantAddressStringList;
  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantAdministratorDetailsList listAdministrators(
    final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList =
      new ParticipantAdministratorDetailsList();
    final Employer delegate = EmployerFactory.newInstance();

    participantAdministratorDetailsList =
      delegate.listAdministrators(readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is returned
   *
   * @return The list of administrators for the duplicate concern role
   * specified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  @Override
  public ParticipantAdministratorDetailsList
    listAdministratorsForDuplicateParticipant(
      final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
      throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList =
      new ParticipantAdministratorDetailsList();
    final Employer delegate = EmployerFactory.newInstance();

    participantAdministratorDetailsList =
      delegate.listAdministratorsForDuplicateParticipant(
        readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministrators(ReadParticipantAdminRoleListKey)}
   */
  @Override
  @Deprecated
  public ReadParticipantAdminRoleList
    listAdminRole(final ReadParticipantAdminRoleListKey key)
      throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList =
      new ReadParticipantAdminRoleList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantAdminRoleList = delegate.listAdminRole(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministratorsForDuplicateParticipant(ReadParticipantAdminRoleListKey)}
   */
  @Override
  @Deprecated
  public ReadParticipantAdminRoleList
    listAdminRoleForDuplicate(final ReadParticipantAdminRoleListKey key)
      throws AppException, InformationalException {

    final ReadParticipantAdminRoleList readParticipantAdminRoleList =
      new ReadParticipantAdminRoleList();
    final Employer delegate = EmployerFactory.newInstance();

    delegate.listAdminRoleForDuplicate(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantAlternateIDList
    listAlternateID(final ReadParticipantAlternateIDListKey key)
      throws AppException, InformationalException {

    ReadParticipantAlternateIDList readParticipantAlternateIDList =
      new ReadParticipantAlternateIDList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantAlternateIDList = delegate.listAlternateID(key);
    return readParticipantAlternateIDList;
  }

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the alternateID of the AlternateID record the snapshots
   * are associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantAltIDHistoryList
    listAlternateIDHistory(final ReadParticipantAltIDHistoryListKey key)
      throws AppException, InformationalException {

    ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList =
      new ReadParticipantAltIDHistoryList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantAltIDHistoryList = delegate.listAlternateIDHistory(key);
    return readParticipantAltIDHistoryList;
  }

  /**
   * Method returns a list of Assessments for the participant.
   *
   * @param concernRoleKey
   * contains the concern role that the assessments were created for.
   *
   * @return The list of Assessments for the concern role.
   */
  @Override
  public ParticipantAssessmentsList
    listAssessments(final ConcernRoleKey concernRoleKey)
      throws AppException, InformationalException {

    ParticipantAssessmentsList participantAssessmentsList =
      new ParticipantAssessmentsList();
    final Employer delegate = EmployerFactory.newInstance();

    participantAssessmentsList = delegate.listAssessments(concernRoleKey);
    return participantAssessmentsList;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of bank accounts is
   * returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAccountList
    listBankAccount(final ReadParticipantBankAccountListKey key)
      throws AppException, InformationalException {

    ReadParticipantBankAccountList readParticipantBankAccountList =
      new ReadParticipantBankAccountList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantBankAccountList = delegate.listBankAccount(key);
    return readParticipantBankAccountList;
  }

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAcHistoryList
    listBankAccountHistory(final ReadParticipantBankAcHistoryListKey key)
      throws AppException, InformationalException {

    ReadParticipantBankAcHistoryList readParticipantBankAcHistoryList =
      new ReadParticipantBankAcHistoryList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantBankAcHistoryList = delegate.listBankAccountHistory(key);
    return readParticipantBankAcHistoryList;
  }

  /**
   * Lists the formatted bank account details. The bank details are formatted to
   * display as a single line of text.
   *
   * @param key
   * concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantBankAccountStringList
    listBankAccountString(final MaintainConcernRoleKey key)
      throws AppException, InformationalException {

    ParticipantBankAccountStringList participantBankAccountStringList =
      new ParticipantBankAccountStringList();
    final Employer delegate = EmployerFactory.newInstance();

    participantBankAccountStringList = delegate.listBankAccountString(key);
    return participantBankAccountStringList;
  }

  /**
   * Lists all communications by case ID.
   *
   * @param key
   * Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CommunicationDetailList
    listCommunication(final ParticipantCommunicationKey key)
      throws AppException, InformationalException {

    CommunicationDetailList communicationDetailList =
      new CommunicationDetailList();
    final Employer delegate = EmployerFactory.newInstance();

    communicationDetailList = delegate.listCommunication(key);
    return communicationDetailList;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of communication
   * exceptions are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    final ReadParticipantCommunicationExceptionListKey key)
    throws AppException, InformationalException {

    ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList =
      new ReadParticipantCommunicationExceptionList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantCommunicationExceptionList =
      delegate.listCommunicationException(key);
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantConcernRoleList
    listConcernRole(final ReadParticipantConcernRoleKey key)
      throws AppException, InformationalException {

    ReadParticipantConcernRoleList readParticipantConcernRoleList =
      new ReadParticipantConcernRoleList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantConcernRoleList = delegate.listConcernRole(key);
    return readParticipantConcernRoleList;
  }

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadDuplicateParticipantConcernRoleList
    listConcernRoleForDuplicate(final ReadParticipantConcernRoleKey key)
      throws AppException, InformationalException {

    ReadDuplicateParticipantConcernRoleList readDuplicateParticipantConcernRoleList =
      new ReadDuplicateParticipantConcernRoleList();
    final Employer delegate = EmployerFactory.newInstance();

    readDuplicateParticipantConcernRoleList =
      delegate.listConcernRoleForDuplicate(key);
    return readDuplicateParticipantConcernRoleList;
  }

  // BEGIN, CR00294967, MV
  /**
   * A list of contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #listConcernContact()}.
   * The return struct of the current method listContact has an
   * aggregation to the struct ConcernContactRMDtls, the attribute
   * statusCode in the struct ConcernContactRMDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ListConcernContactDetails which
   * has an aggregation to the new struct ConcernContactRMultiDtls
   * where the attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public ListContactDetails listContact(final ListContactKey key)
    throws AppException, InformationalException {

    ListContactDetails listContactDetails = new ListContactDetails();
    final Employer delegate = EmployerFactory.newInstance();

    listContactDetails = delegate.listContact(key);
    return listContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Lists the contacts for a Participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListConcernContactDetails listConcernContact(
    final ListContactKey key) throws AppException, InformationalException {

    ListConcernContactDetails listContactDetails =
      new ListConcernContactDetails();
    final Employer delegate = EmployerFactory.newInstance();

    listContactDetails = delegate.listConcernContact(key);
    return listContactDetails;
  }

  // END, CR00294967

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantDeductionList
    listDeduction(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ReadParticipantDeductionList readParticipantDeductionList =
      new ReadParticipantDeductionList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantDeductionList = delegate.listDeduction(key);
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantDeductionList1
    listDeduction1(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ReadParticipantDeductionList1 readParticipantDeductionList1 =
      new ReadParticipantDeductionList1();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantDeductionList1 = delegate.listDeduction1(key);
    return readParticipantDeductionList1;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadDuplicateParticipantDeductionList
    listDeductionForDuplicate(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ReadDuplicateParticipantDeductionList readDuplicateParticipantDeductionList =
      new ReadDuplicateParticipantDeductionList();
    final Employer delegate = EmployerFactory.newInstance();

    readDuplicateParticipantDeductionList =
      delegate.listDeductionForDuplicate(key);
    return readDuplicateParticipantDeductionList;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of email addresses
   * is returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantEmailAddressList
    listEmailAddress(final ReadParticipantEmailAddressListKey key)
      throws AppException, InformationalException {

    ReadParticipantEmailAddressList readParticipantEmailAddressList =
      new ReadParticipantEmailAddressList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantEmailAddressList = delegate.listEmailAddress(key);
    return readParticipantEmailAddressList;
  }

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public FormattedAddressList listFormattedAddress(
    final ReadParticipantFormattedAddressListKey readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    FormattedAddressList formattedAddressList = new FormattedAddressList();
    final Employer delegate = EmployerFactory.newInstance();

    formattedAddressList =
      delegate.listFormattedAddress(readParticipantFormattedAddressListKey);
    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public FormattedBankAccountList listFormattedBankAccount(
    final ReadParticipantFormattedBankAccountListKey readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    FormattedBankAccountList formattedBankAccountList =
      new FormattedBankAccountList();
    final Employer delegate = EmployerFactory.newInstance();

    formattedBankAccountList = delegate
      .listFormattedBankAccount(readParticipantFormattedBankAccountListKey);
    return formattedBankAccountList;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListInteractionDetails listInteractionDetails =
      new ListInteractionDetails();
    final Employer delegate = EmployerFactory.newInstance();

    listInteractionDetails = delegate.listInteraction(key);
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantInteractionDetails
    listInteractionForDuplicate(final ListInteractionKey key)
      throws AppException, InformationalException {

    ListDuplicateParticipantInteractionDetails listDuplicateParticipantInteractionDetails =
      new ListDuplicateParticipantInteractionDetails();
    final Employer delegate = EmployerFactory.newInstance();

    listDuplicateParticipantInteractionDetails =
      delegate.listInteractionForDuplicate(key);
    return listDuplicateParticipantInteractionDetails;
  }

  /**
   * Method returns a list of Investigations for the participant.
   *
   * @param key
   * contains the concern role that the investigations were created
   * for.
   *
   * @return The list of Investigations for the concern role.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantInvestigationList listInvestigations(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    ParticipantInvestigationList participantInvestigationList =
      new ParticipantInvestigationList();
    final Employer delegate = EmployerFactory.newInstance();

    participantInvestigationList = delegate.listInvestigations(key);
    return participantInvestigationList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListParticipantIssuedPaymentInstrument
    listIssuedPaymentInstrument(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument =
      new ListParticipantIssuedPaymentInstrument();
    final Employer delegate = EmployerFactory.newInstance();

    listParticipantIssuedPaymentInstrument =
      delegate.listIssuedPaymentInstrument(key);
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key
   * Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantIssuedPaymentInstrument
    listIssuedPaymentInstrumentForDuplicate(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPaymentInstrument =
      new ListDuplicateParticipantIssuedPaymentInstrument();
    final Employer delegate = EmployerFactory.newInstance();

    listDuplicateParticipantIssuedPaymentInstrument =
      delegate.listIssuedPaymentInstrumentForDuplicate(key);
    return listDuplicateParticipantIssuedPaymentInstrument;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated - replaced by {@link #listNote1()}
   * @deprecated -since Version 6.0
   */
  @Override
  @Deprecated
  public ParticipantNoteList listNote(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList participantNoteList = new ParticipantNoteList();
    final Employer delegate = EmployerFactory.newInstance();

    participantNoteList = delegate.listNote(key);
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantNoteList1 listNote1(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList1 participantNoteList = new ParticipantNoteList1();
    final Employer delegate = EmployerFactory.newInstance();

    participantNoteList = delegate.listNote1(key);
    return participantNoteList;
  }

  // END, CR00231506

  /**
   * @param key
   * contains the key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listParticipantFinancial1()}. Returns a list of
   * financials for a participant.
   */
  @Override
  @Deprecated
  public ListParticipantFinancials
    listParticipantFinancial(final ListParticipantFinancialsKey key)
      throws AppException, InformationalException {

    ListParticipantFinancials listParticipantFinancials =
      new ListParticipantFinancials();
    final Employer delegate = EmployerFactory.newInstance();

    listParticipantFinancials = delegate.listParticipantFinancial(key);
    return listParticipantFinancials;
  }

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListParticipantFinancials1
    listParticipantFinancial1(final ListParticipantFinancialsKey key)
      throws AppException, InformationalException {

    ListParticipantFinancials1 listParticipantFinancials1 =
      new ListParticipantFinancials1();
    final Employer delegate = EmployerFactory.newInstance();

    listParticipantFinancials1 = delegate.listParticipantFinancial1(key);
    return listParticipantFinancials1;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantFinancials
    listParticipantFinancialForDuplicate(
      final ListParticipantFinancialsKey key)
      throws AppException, InformationalException {

    ListDuplicateParticipantFinancials listDuplicateParticipantFinancials =
      new ListDuplicateParticipantFinancials();
    final Employer delegate = EmployerFactory.newInstance();

    listDuplicateParticipantFinancials =
      delegate.listParticipantFinancialForDuplicate(key);
    return listDuplicateParticipantFinancials;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * contains the key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public TasksForConcernAndCaseDetails
    listParticipantTask(final ListParticipantTaskKey_eo key)
      throws AppException, InformationalException {

    TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails =
      new TasksForConcernAndCaseDetails();
    final Employer delegate = EmployerFactory.newInstance();

    tasksForConcernAndCaseDetails = delegate.listParticipantTask(key);
    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public TasksForDuplicateConcernAndCaseDetails
    listParticipantTaskForDuplicate(final ListParticipantTaskKey_eo key)
      throws AppException, InformationalException {

    TasksForDuplicateConcernAndCaseDetails tasksForDuplicateConcernAndCaseDetails =
      new TasksForDuplicateConcernAndCaseDetails();
    final Employer delegate = EmployerFactory.newInstance();

    tasksForDuplicateConcernAndCaseDetails =
      delegate.listParticipantTaskForDuplicate(key);
    return tasksForDuplicateConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role.
   *
   * @param key
   * contains the concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantPhoneNumberList
    listPhoneNumber(final ReadParticipantPhoneNumberListKey key)
      throws AppException, InformationalException {

    ReadParticipantPhoneNumberList readParticipantPhoneNumberList =
      new ReadParticipantPhoneNumberList();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantPhoneNumberList = delegate.listPhoneNumber(key);
    return readParticipantPhoneNumberList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key
   * Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   */
  @Override
  public ParticipantScreeningList listScreeningCases(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    ParticipantScreeningList participantScreeningList =
      new ParticipantScreeningList();
    final Employer delegate = EmployerFactory.newInstance();

    participantScreeningList = delegate.listScreeningCases(key);
    return participantScreeningList;
  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * contains the key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key)
    throws AppException, InformationalException {

    ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant =
      new ListTemplateByTypeAndParticpant();
    final Employer delegate = EmployerFactory.newInstance();

    listTemplateByTypeAndParticpant =
      delegate.listTemplateByTypeAndParticipant(key);
    return listTemplateByTypeAndParticpant;
  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of web addresses is
   * returned
   * @return The list of web addresses returned from the database
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantWebAddressList
    listWebAddress(final ParticipantWebAddressListKey key)
      throws AppException, InformationalException {

    ParticipantWebAddressList participantWebAddressList =
      new ParticipantWebAddressList();
    final Employer delegate = EmployerFactory.newInstance();

    participantWebAddressList = delegate.listWebAddress(key);
    return participantWebAddressList;
  }

  /**
   * Modifies an address record for a concern role.
   *
   * @param details
   * contains the concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ModifiedAddressDetails
    modifyAddress(final MaintainParticipantAddressDetails details)
      throws AppException, InformationalException {

    ModifiedAddressDetails modifiedAddressDetails =
      new ModifiedAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    modifiedAddressDetails = delegate.modifyAddress(details);
    return modifiedAddressDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * contains the concern role ID and alternate id detail being
   * modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ModifiedAlternateIDDetails
    modifyAlternateID(final MaintainParticipantAlternateIDDetails details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ModifiedAlternateIDDetails modifiedAlternateIDDetails =
      new ModifiedAlternateIDDetails();

    modifiedAlternateIDDetails = delegate.modifyAlternateID(details);
    return modifiedAlternateIDDetails;
  }

  /**
   * @param details
   * contains the bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}. Modify the bank
   * account details for a participant.
   */
  @Override
  @Deprecated
  public InformationMsgDtlsList
    modifyBankAccount(final MaintainParticipantBankAccountDetails details)
      throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();
    final Employer delegate = EmployerFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccount(details);
    return informationMsgDtlsList;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * contains the details to modify the communication.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyCommunication(details);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * contains the concern role communication exception details being
   * modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyCommunicationException(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #modifyConcernContact()}. The parameter struct of the
   * current method modifyContact has an aggregation to the struct
   * ConcernContactDtls, the attribute statusCode in the struct
   * ConcernContactDtls is modeled with a domain of CONTACTSTATUS
   * code-table, but the corresponding entity attribute
   * ConcernRoleContactDtls.statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. So new method is introduced to have new
   * parameter ModifyConcernContactDetails which has an aggregation
   * to the new struct ConcernContactRMultiDtls where the attribute
   * statusCode is modeled with a domain of RECORD_STATUS_CODE. See
   * release note: CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyContact(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyConcernContact(details);
  }

  // END, CR00294967

  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * contains the email address details being modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void
    modifyEmailAddress(final MaintainParticipantEmailAddressDetails details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyEmailAddress(details);
  }

  // BEGIN, CR00231506, PDN
  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated - replaced by {@link #modifyNote1()}
   * @deprecated -since Version 6.0
   */
  @Override
  @Deprecated
  public void modifyNote(final ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyNote(details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyNote1(final ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyNote1(details);
  }

  // END, CR00231506

  /**
   * Modifies a phone number record for a concern role.
   *
   * @param details
   * contains the concern role id and concern role phone number details
   * that will be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyPhoneNumber(details);
  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * contains the details of the sent communication to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void
    modifySentCommunication(final ModifySentCommunicationDetails details)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifySentCommunication(details);
  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * contains the web address details being modified
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.modifyWebAddress(details);
  }

  /**
   * Prints a communication.
   *
   * @param details
   * contains details to print the communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.printCommunication(details);
  }

  /**
   * Reads an address record for a concern role.
   *
   * @param key
   * contains the concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantAddressDetails
    readAddress(final ReadParticipantAddressKey key)
      throws AppException, InformationalException {

    ReadParticipantAddressDetails readParticipantAddressDetails =
      new ReadParticipantAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantAddressDetails = delegate.readAddress(key);
    return readParticipantAddressDetails;
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * contains the concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantAlternateIDDetails
    readAlternateID(final ReadParticipantAlternateIDKey key)
      throws AppException, InformationalException {

    ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails =
      new ReadParticipantAlternateIDDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantAlternateIDDetails = delegate.readAlternateID(key);
    return readParticipantAlternateIDDetails;
  }

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * contains the bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAccountDetails
    readBankAccount(final ReadParticipantBankAccountKey key)
      throws AppException, InformationalException {

    ReadParticipantBankAccountDetails readParticipantBankAccountDetails =
      new ReadParticipantBankAccountDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantBankAccountDetails = delegate.readBankAccount(key);
    return readParticipantBankAccountDetails;
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated
   */
  @Override
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ReadCommDetails readCommDetails = new ReadCommDetails();

    readCommDetails = delegate.readCommunication(key);
    return readCommDetails;
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * contains the key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails =
      new ReadCommunicationAttachmentDetails();

    readCommunicationAttachmentDetails =
      delegate.readCommunicationAttachment(key);
    return readCommunicationAttachmentDetails;
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * contains the communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantCommunicationExceptionDetails
    readCommunicationException(
      final ReadParticipantCommunicationExceptionKey key)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails =
      new ReadParticipantCommunicationExceptionDetails();

    readParticipantCommunicationExceptionDetails =
      delegate.readCommunicationException(key);
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * contains the concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ConcernRoleTypeDetails
    readConcernRoleType(final ReadParticipantConcernRoleKey key)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails =
      new ConcernRoleTypeDetails();

    concernRoleTypeDetails = delegate.readConcernRoleType(key);
    return concernRoleTypeDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #readConcernContact()}.
   * The return struct of the current method readContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ReadConcernContactDetails which
   * has an aggregation to the new struct ConcernContactRMultiDtls
   * where the attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public ReadContactDetails readContact(final ReadContactKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ReadContactDetails readContactDetails = new ReadContactDetails();

    readContactDetails = delegate.readContact(key);
    return readContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadConcernContactDetails readConcernContact(
    final ReadContactKey key) throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ReadConcernContactDetails readConcernContactDetails =
      new ReadConcernContactDetails();

    readConcernContactDetails = delegate.readConcernContact(key);
    return readConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * contains the concern role ID for which the description is
   * retrieved.
   *
   * @return The returned description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantContextDetails
    readContextDescription(final ParticipantContextKey key)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();
    ParticipantContextDetails participantContextDetails =
      new ParticipantContextDetails();

    participantContextDetails = delegate.readContextDescription(key);
    return participantContextDetails;
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * contains the email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantEmailAddressDetails
    readEmailAddress(final ReadParticipantEmailAddressKey key)
      throws AppException, InformationalException {

    ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails =
      new ReadParticipantEmailAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantEmailAddressDetails = delegate.readEmailAddress(key);
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadInteractionDetails readInteraction(final ReadInteractionKey key)
    throws AppException, InformationalException {

    ReadInteractionDetails readInteractionDetails =
      new ReadInteractionDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readInteractionDetails = delegate.readInteraction(key);
    return readInteractionDetails;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated - replaced by {@link #readNote1()}
   * @deprecated -since Version 6.0
   */
  @Override
  @Deprecated
  public ReadParticipantNoteDetails readNote(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails readParticipantNoteDetails =
      new ReadParticipantNoteDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote(key);
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantNoteDetails1 readNote1(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails1 readParticipantNoteDetails =
      new ReadParticipantNoteDetails1();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote1(key);
    return readParticipantNoteDetails;
  }

  // END, CR00231506

  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * contains the contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ContactContextDescriptionDetails
    readParticipantContactContextDescription(
      final ContactContextDescriptionKey key)
      throws AppException, InformationalException {

    ContactContextDescriptionDetails contactContextDescriptionDetails =
      new ContactContextDescriptionDetails();
    final Employer delegate = EmployerFactory.newInstance();

    contactContextDescriptionDetails =
      delegate.readParticipantContactContextDescription(key);
    return contactContextDescriptionDetails;
  }

  /**
   * Reads a phone number record for a concern role.
   *
   * @param key
   * contains the concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantPhoneNumberDetails
    readPhoneNumber(final ReadParticipantPhoneNumberKey key)
      throws AppException, InformationalException {

    ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails =
      new ReadParticipantPhoneNumberDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantPhoneNumberDetails = delegate.readPhoneNumber(key);
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * contains the web address ID of the record being read.
   *
   * @return The web address details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadParticipantWebAddressDetails
    readWebAddress(final ParticipantWebAddressKey key)
      throws AppException, InformationalException {

    ReadParticipantWebAddressDetails readParticipantWebAddressDetails =
      new ReadParticipantWebAddressDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readParticipantWebAddressDetails = delegate.readWebAddress(key);
    return readParticipantWebAddressDetails;
  }

  /**
   * Records an existing communication.
   *
   * @param details
   * contains the details of the existing communication.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.recordExistingCommunication(details);
  }

  /**
   * Removes an address record for a concern role.
   *
   * @param key
   * contains the concern role address key
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.removeAddress(key);
  }

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from the
   * resolve script only.
   *
   * @param key
   * contains the concern Role ID of the record being read.
   *
   * @return The home page name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantHomePageName
    resolveProspectHome(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ParticipantHomePageName participantHomePageName =
      new ParticipantHomePageName();
    final Employer delegate = EmployerFactory.newInstance();

    participantHomePageName = delegate.resolveProspectHome(key);
    return participantHomePageName;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key
   * Participant search criteria
   *
   * @return Participant details found
   *
   * @throws InformationalException
   * Informational Exception
   * @throws AppException
   * Application Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectEmployer#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchParticipantDetails(AllParticipantSearchKey) which returns
   * the informational message along with participant details as
   * well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  @Override
  public AllParticipantSearchResult
    searchParticipant(final AllParticipantSearchKey key)
      throws AppException, InformationalException {

    // END, CR00290965
    AllParticipantSearchResult allParticipantSearchResult =
      new AllParticipantSearchResult();
    final Employer delegate = EmployerFactory.newInstance();

    allParticipantSearchResult = delegate.searchParticipant(key);
    return allParticipantSearchResult;
  }

  /**
   * Sends an email communication.
   *
   * @Deprecated
   * @param details
   * contains the details to send the communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.sendEmailCommunication(details);
  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * contains the concern role ID and the bank account ID of the bank
   * for which payment will now be made to.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void
    updateBankAccountPaymentDetails(final UpdateBankAccPaymentDtlsKey key)
      throws AppException, InformationalException {

    final Employer delegate = EmployerFactory.newInstance();

    delegate.updateBankAccountPaymentDetails(key);
  }

  /**
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}. Create a new bank
   * account for a participant.
   */
  @Override
  @Deprecated
  public CreateParticipantBankAccountDetails
    createBankAccount(final MaintainParticipantBankAccountDetails details)
      throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails =
      new CreateParticipantBankAccountDetails();
    final Employer delegate = EmployerFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccount(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CreateParticipantBankAccountDetails
    createBankAccountWithTextSortCode(
      final MaintainParticipantBankAccountWithTextSortCodeDetails details)
      throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails =
      new CreateParticipantBankAccountDetails();
    final Employer delegate = EmployerFactory.newInstance();

    createParticipantBankAccountDetails =
      delegate.createBankAccountWithTextSortCode(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();
    final Employer delegate = EmployerFactory.newInstance();

    informationMsgDtlsList =
      delegate.modifyBankAccountWithTextSortCode(details);
    return informationMsgDtlsList;
  }

  // END, CR00234017

  // BEGIN, CR00234515, DJ
  /**
   * Reads an employer's home page details and further details.
   *
   * @param key
   * Identifies the person concerned.
   *
   * @return The home page details of the person.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ReadEmployerHomeDetails
    readHomePageDetails(final ReadEmployerHomeKey key)
      throws AppException, InformationalException {

    ReadEmployerHomeDetails readEmployerHomeDetails =
      new ReadEmployerHomeDetails();
    final Employer delegate = EmployerFactory.newInstance();

    readEmployerHomeDetails = delegate.readHomePageDetails(key);
    return readEmployerHomeDetails;
  }

  // END, CR00234515

  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param employerSearchKey1
   * contains employer search key
   *
   * @return employer details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmployerSearchDetailsResult
    searchEmployerDetails(final EmployerSearchKey1 employerSearchKey1)
      throws AppException, InformationalException {

    EmployerSearchDetailsResult employerSearchDetailsResult =
      new EmployerSearchDetailsResult();

    final Employer employer = EmployerFactory.newInstance();

    // BEGIN, 268814, SH
    employerSearchKey1.key.showProspectEmployersIndOpt = true;
    // END, 268814
    employerSearchDetailsResult = employer.searchEmployer(employerSearchKey1);

    return employerSearchDetailsResult;
  }

  /**
   * Searches for an employer by specified search criteria. This is used for
   * popup pages and does not return names as hyperlinks.
   *
   * @param employerSearchKey1
   * contains employer search key
   *
   * @return employer details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EmployerSearchDetailsResult
    searchEmployerForPopup(final EmployerSearchKey1 employerSearchKey1)
      throws AppException, InformationalException {

    EmployerSearchDetailsResult employerSearchResult =
      new EmployerSearchDetailsResult();

    final Employer employer = EmployerFactory.newInstance();

    // BEGIN, 268814, SH
    employerSearchKey1.key.showProspectEmployersIndOpt = true;
    // END, 268814
    employerSearchResult =
      employer.searchEmployerForPopup(employerSearchKey1);

    return employerSearchResult;
  }

  // END, CR00282028

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey
   * contains all participant search key
   *
   * @return participant search details
   *
   * @throws InformationalException
   * Informational Exception
   * @throws AppException
   * Application Exception
   */
  @Override
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey)
    throws AppException, InformationalException {

    AllParticipantSearchDetails allParticipantSearchDetails =
      new AllParticipantSearchDetails();

    final Employer employer = EmployerFactory.newInstance();

    allParticipantSearchDetails =
      employer.searchParticipantDetails(allParticipantSearchKey);

    return allParticipantSearchDetails;
  }

  // END, CR00290965

  /**
   * Saves and associates the prospect employer to the selected Employer record.
   *
   * @param participantDetails
   * Contains the employer concern role id and prospect employer
   * concern role id to be associated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.core.facade.intf.ProspectEmployer#
   * associateProspectWithRegisteredEmployer
   * (curam.core.facade.struct.ReadProspectEmployerHomeDetails)
   */
  @Override
  public void associateProspectWithRegisteredEmployer(
    final ReadProspectEmployerHomeDetails participantDetails)
    throws AppException, InformationalException {

    final ProspectEmployerRegistration prosEmpRegistrationObj =
      ProspectEmployerRegistrationFactory.newInstance();
    final ProspectEmployerHomeDetails details =
      new ProspectEmployerHomeDetails();

    details.assign(participantDetails.details);
    prosEmpRegistrationObj.associateProspectWithRegisteredEmployer(details);

  }
  // END, CR00406231

}
