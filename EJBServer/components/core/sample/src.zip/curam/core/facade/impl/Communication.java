/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002,2019. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;

import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.struct.CancelCommunicationDetails;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.CommunicationAndListRowActionDetails;
import curam.core.facade.struct.CommunicationContextDetails;
import curam.core.facade.struct.CommunicationContextKey;
import curam.core.facade.struct.CorrespondentDetails;
import curam.core.facade.struct.CorrespondentID;
import curam.core.facade.struct.CreateCaseMSWordCommunicationDetails;
import curam.core.facade.struct.CreateEmailCommDetails;
import curam.core.facade.struct.CreateMSWordCommunicationDetails;
import curam.core.facade.struct.CreateProFormaCommDetails;
import curam.core.facade.struct.CreateProFormaCommDetails1;
import curam.core.facade.struct.DeletePageIdentifier;
import curam.core.facade.struct.DuplicateParticipantCommunicationDetailsList;
import curam.core.facade.struct.EmailCommunicationDetails;
import curam.core.facade.struct.FileNameAndDataDtls;
import curam.core.facade.struct.IntegratedCaseIDAndTypeDetails;
import curam.core.facade.struct.ListProFormaTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListProFormaTemplateByTypeAndParticpant;
import curam.core.facade.struct.ModifyCorrespondentDetails;
import curam.core.facade.struct.ModifyEmailCommDetails;
import curam.core.facade.struct.ModifyEmailCommKey;
import curam.core.facade.struct.ModifyMSWordCommunicationDetails;
import curam.core.facade.struct.ModifyMSWordCommunicationDetails1;
import curam.core.facade.struct.ModifyProFormaCommDetails;
import curam.core.facade.struct.ModifyProFormaCommDetails1;
import curam.core.facade.struct.ModifyRecordedCommDetails;
import curam.core.facade.struct.ModifyRecordedCommDetails1;
import curam.core.facade.struct.ModifyRecordedCommKey;
import curam.core.facade.struct.ModifyWordCommunicationDetails;
import curam.core.facade.struct.ModifyWordDocumentDetails;
import curam.core.facade.struct.ParticipantCommunicationDetailsList;
import curam.core.facade.struct.ParticipantCommunicationKey;
import curam.core.facade.struct.PrintProFormaKey;
import curam.core.facade.struct.ProFormaCommDetails;
import curam.core.facade.struct.ProFormaCommDetails1;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCommunicationAttachmentDetails;
import curam.core.facade.struct.ReadEmailCommDetails;
import curam.core.facade.struct.ReadEmailCommKey;
import curam.core.facade.struct.ReadEmailCommunicationCaseMember;
import curam.core.facade.struct.ReadMSWordCommunicationCaseMember;
import curam.core.facade.struct.ReadMSWordCommunicationDetails;
import curam.core.facade.struct.ReadMSWordCommunicationDetails1;
import curam.core.facade.struct.ReadMSWordCommunicationKey;
import curam.core.facade.struct.ReadProFormaCommKey;
import curam.core.facade.struct.ReadProFormaCommunicationCaseMember;
import curam.core.facade.struct.ReadRecordedCommDetails;
import curam.core.facade.struct.ReadRecordedCommDetails1;
import curam.core.facade.struct.ReadRecordedCommKey;
import curam.core.facade.struct.ReadRecordedCommunicationCaseMember;
import curam.core.facade.struct.RecordedCommDetails;
import curam.core.facade.struct.RecordedCommDetails1;
import curam.core.facade.struct.ResolveCorrespondentHomeKey;
import curam.core.facade.struct.SendCommunicationDetails;
import curam.core.facade.struct.SendEmailDetails;
import curam.core.facade.struct.TemplateAndDocumentDataKey;
import curam.core.facade.struct.WordTemplateDocumentAndDataDetails;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CommAttachmentLinkFactory;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.CommAttachmentLink;
import curam.core.intf.ConcernRoleCommunication;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.struct.CommunicationIDKey;
import curam.core.sl.struct.CreateMSWordCommunicationDetails1;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.PreviewProFormaKey;
import curam.core.sl.struct.ProFormaCommKey;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationAttachmentLinkReadmultiKey;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleCommunicationKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameTypeDateDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.OtherAddressData;
import curam.core.struct.SearchTemplatesKey;
import curam.message.GENERALCONCERN;
import curam.message.SEPARATOR;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;

/**
 * Functions for manipulating communication details.
 *
 */
public abstract class Communication
  extends curam.core.facade.base.Communication {

  // BEGIN, HARP, 35558, CC
  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
   * TransactionInfo.getProgramLocale())}. Replacement reason -
   * static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note
   * CR00219408.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00222190

  // END, CR00023323
  // END HARP,35558
  // BEGIN, CR00100651, CSH
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kParamConcernRoleID =
    XmlMetaDataConst.kParamConcernRoleID;

  protected static final String kNavigationMenu =
    XmlMetaDataConst.kNavigationMenu;

  // END, CR00100651

  /**
   * Creates an Microsoft Word communication.
   *
   * @param dtls
   * Details to create an Microsoft Word communication.
   *
   * @return Identifier of the newly created communication.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createMSWordCommunication1()}.
   */
  @Override
  @Deprecated
  public TemplateAndDocumentDataKey
    createMSWordCommunication(final CreateMSWordCommunicationDetails dtls)
      throws AppException, InformationalException {

    // Create return object
    final TemplateAndDocumentDataKey templateAndDocumentDataKey =
      new TemplateAndDocumentDataKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create the Microsoft Word communication
    templateAndDocumentDataKey.dtls =
      communicationObj.createMSWordCommunication(dtls.dtls);

    return templateAndDocumentDataKey;
  }

  /**
   * Creates an Microsoft Word communication.
   *
   * @param dtls
   * Details to create an Microsoft Word communication.
   *
   * @return Identifier of the newly created communication.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #createMSWordCommunicationWithNoMandatoryAddress()}.
   */
  @Deprecated
  @Override
  public TemplateAndDocumentDataKey
    createMSWordCommunication1(final CreateMSWordCommunicationDetails1 dtls)
      throws AppException, InformationalException {

    // Create return object
    final TemplateAndDocumentDataKey templateAndDocumentDataKey =
      new TemplateAndDocumentDataKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create the Microsoft Word communication
    templateAndDocumentDataKey.dtls =
      communicationObj.createMSWordCommunication1(dtls);

    return templateAndDocumentDataKey;
  }

  // BEGIN, CR00265298, JAF

  /**
   * Creates an Microsoft Word communication.
   *
   * @param dtls
   * Details to create an Microsoft Word communication.
   *
   * @return Identifier of the newly created communication.
   */
  @Override
  public TemplateAndDocumentDataKey
    createMSWordCommunicationWithNoMandatoryAddress(
      final CreateMSWordCommunicationDetails1 dtls)
      throws AppException, InformationalException {

    // Create return object
    final TemplateAndDocumentDataKey templateAndDocumentDataKey =
      new TemplateAndDocumentDataKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create the Microsoft Word communication
    templateAndDocumentDataKey.dtls =
      communicationObj.createMSWordCommunication1(dtls);

    return templateAndDocumentDataKey;
  }

  // END, CR00265298, JAF

  // BEGIN, CR00166687, JMA

  /**
   * Modifies Microsoft Word communication details.
   *
   * @param details
   * Modified Microsoft Word communication details.
   */
  @Override
  public void modifyMSWordCommunication1(
    final ModifyMSWordCommunicationDetails1 details)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    communicationIDKey.communicationID = details.dtls.communicationID;

    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    if (caseKey.caseID != 0) {

      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        ServicePlanSecurityImplementationFactory.register();

        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }

    // Call service layer method to Microsoft Word communication
    communicationObj.modifyMSWordCommunication1(details.dtls);

  }

  // BEGIN, CR00236672, NS
  /**
   * Reads a pro forma communication.
   *
   * @param key
   * Communication key.
   * @return Pro forma communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ProFormaCommDetails1 readProForma1(final ReadProFormaCommKey key)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();

    // BEGIN, CR00001117, CM
    final CommunicationIDKey communicationIDKey = new CommunicationIDKey();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    communicationIDKey.communicationID = key.proFormaCommKey.communicationID;
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {

      // BEGIN ,CR00019482, AK
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // If case type is service plan, check service plan security.
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        final ServicePlanDelivery servicePlanDeliveryObj =
          ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        ServicePlanSecurityImplementationFactory.register();

        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kReadSecurityCheck;

        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117
    }
    // END, CR00002484

    // Call service layer method to modify an email communication.
    proFormaCommDetails.readProFormaCommDetails =
      communicationObj.readProForma1(key.proFormaCommKey);

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData =
      proFormaCommDetails.readProFormaCommDetails.addressData;

    if (otherAddressData.addressData.length() != 0) {

      proFormaCommDetails.addressString = ParticipantFactory.newInstance()
        .displaySingleLineAddress(otherAddressData).addressString;
    }

    return proFormaCommDetails;
  }

  // END, CR00236672
  // BEGIN, CR00266244, MC

  /**
   * Reads a pro forma communication and return the case member name and concern
   * role type.
   *
   * @param key
   * ReadProFormaCommKey
   *
   * @return Pro forma communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadProFormaCommunicationCaseMember
    readProFormaAndCaseMember(final ReadProFormaCommKey key)
      throws AppException, InformationalException {

    final ReadProFormaCommunicationCaseMember readProFormaCommunicationCaseMember =
      new ReadProFormaCommunicationCaseMember();

    final ProFormaCommDetails1 proFormaCommDetails1 = readProForma1(key);

    readProFormaCommunicationCaseMember.communicationDtls =
      proFormaCommDetails1;

    // Add the regarding case member name to the return struct
    if (proFormaCommDetails1.readProFormaCommDetails.clientParticipantRoleID != 0) {

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        proFormaCommDetails1.readProFormaCommDetails.clientParticipantRoleID;

      final ConcernRoleNameTypeDateDetails concernRoleNameTypeDateDetails =
        ConcernRoleFactory.newInstance().readNameTypeAndDate(concernRoleKey);

      readProFormaCommunicationCaseMember.clientConcernRoleName =
        concernRoleNameTypeDateDetails.concernRoleName;
      readProFormaCommunicationCaseMember.clientConcernRoleType =
        concernRoleNameTypeDateDetails.concernRoleType;
    }

    return readProFormaCommunicationCaseMember;
  }

  // END, CR00266244

  /**
   * Reads Microsoft Word communication details.
   *
   * @param key
   * Key to read Microsoft Word communication details.
   *
   * @return Microsoft Word communication details.
   */
  @Override
  public ReadMSWordCommunicationDetails1
    readMSWordCommunication1(final ReadMSWordCommunicationKey key)
      throws AppException, InformationalException {

    final ReadMSWordCommunicationDetails1 readMSWordCommunicationDetails =
      new ReadMSWordCommunicationDetails1();

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    communicationIDKey.communicationID = key.key.communicationID;

    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    if (caseKey.caseID != 0) {

      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kReadSecurityCheck;

        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }

    readMSWordCommunicationDetails.dtls =
      communicationObj.readMSWordCommunication1(key.key);

    if (readMSWordCommunicationDetails.dtls.communicationStatus
      .equals(COMMUNICATIONSTATUS.SENT)) {

      readMSWordCommunicationDetails.sentInd = true;

    }

    // Return address in single line
    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData =
      readMSWordCommunicationDetails.dtls.addressData;

    if (otherAddressData.addressData.length() != 0) {

      readMSWordCommunicationDetails.dtls.addressString =
        ParticipantFactory.newInstance()
          .displaySingleLineAddress(otherAddressData).addressString;

    }

    return readMSWordCommunicationDetails;

  }

  // END, CR00166687

  // BEGIN, CR00266244, MC

  /**
   * Reads Microsoft Word communication details and the case members concern
   * role type and name.
   *
   * @param key
   * Key to read Microsoft Word communication details.
   *
   * @return ReadMSWordCommunicationCaseMember Microsoft Word communication and
   * case members details.
   */
  @Override
  public ReadMSWordCommunicationCaseMember
    readMSWordCommunicationAndCaseMember(final ReadMSWordCommunicationKey key)
      throws AppException, InformationalException {

    final ReadMSWordCommunicationCaseMember readMSWordCommunicationCaseMember =
      new ReadMSWordCommunicationCaseMember();

    final ReadMSWordCommunicationDetails1 readMSWordCommunicationDetails1 =
      readMSWordCommunication1(key);

    readMSWordCommunicationCaseMember.communicationDtls =
      readMSWordCommunicationDetails1;

    if (readMSWordCommunicationDetails1.dtls.participantRoleID != 0) {

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        readMSWordCommunicationDetails1.dtls.participantRoleID;
      final ConcernRoleNameTypeDateDetails concernRoleNameTypeDateDetails =
        ConcernRoleFactory.newInstance().readNameTypeAndDate(concernRoleKey);

      readMSWordCommunicationCaseMember.clientConcernRoleName =
        concernRoleNameTypeDateDetails.concernRoleName;
      readMSWordCommunicationCaseMember.clientConcernRoleType =
        concernRoleNameTypeDateDetails.concernRoleType;

    }

    return readMSWordCommunicationCaseMember;
  }

  // END, CR00266244

  /**
   * Retrieves word template document and data.
   *
   * @param key
   * Key to retrieve template document and data.
   *
   * @return Template document and data.
   */
  @Override
  public WordTemplateDocumentAndDataDetails
    getWordTemplateDocumentAndData(final TemplateAndDocumentDataKey key)
      throws AppException, InformationalException {

    // Create return object
    final WordTemplateDocumentAndDataDetails wordTemplateDocumentAndDataDetails =
      new WordTemplateDocumentAndDataDetails();

    // Communication object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to retrieve word template and document data
    wordTemplateDocumentAndDataDetails.dtls =
      communicationObj.getWordTemplateDocumentAndData(key.dtls);

    return wordTemplateDocumentAndDataDetails;
  }

  /**
   * Modifies word document details.
   *
   * @param dtls
   * Modified word document details.
   */
  @Override
  public void modifyWordDocument(final ModifyWordDocumentDetails dtls)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to modify word document
    communicationObj.modifyWordDocument(dtls.dtls);
  }

  /**
   * Modifies the Microsoft Word communication details.
   *
   * @param details
   * Modified Microsoft Word communication details.
   *
   * @return details
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyMSWordCommunication1()}.
   */
  @Override
  @Deprecated
  public ModifyWordCommunicationDetails
    modifyMSWordCommunication(final ModifyMSWordCommunicationDetails details)
      throws AppException, InformationalException {

    // Create return object
    final ModifyWordCommunicationDetails modifyWordCommunicationDetails =
      new ModifyWordCommunicationDetails();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set communication key
    communicationIDKey.communicationID = details.dtls.communicationID;

    // set case key
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482
      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117, CM

    }

    // Call service layer method to Microsoft Word communication
    modifyWordCommunicationDetails.dtls =
      communicationObj.modifyMSWordCommunication(details.dtls);

    return modifyWordCommunicationDetails;
  }

  /**
   * Reads Microsoft Word communication details.
   *
   * @param key
   * Key to read Microsoft Word communication details.
   *
   * @return Microsoft Word communication details.
   * @deprecated since Curam 6.0, replaced with
   * {@link #readMSWordCommunication1()}.
   */
  @Override
  @Deprecated
  public ReadMSWordCommunicationDetails
    readMSWordCommunication(final ReadMSWordCommunicationKey key)
      throws AppException, InformationalException {

    final ReadMSWordCommunicationDetails result =
      new ReadMSWordCommunicationDetails();

    final ReadMSWordCommunicationDetails1 details =
      readMSWordCommunication1(key);

    result.dtls.assign(details.dtls);

    return result;
  }

  /**
   * Cancels a communication.
   *
   * @param details
   * Details to cancel the communication.
   */
  @Override
  public void cancel(final CancelCommunicationDetails details)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set communication key
    communicationIDKey.communicationID = details.details.key.communicationID;

    // set case key
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call business process to cancel the communication
    communicationObj.cancel(details.details);
  }

  /**
   * Sends a communication, i.e. updates the communication status to 'Sent'
   *
   * @param details
   * Details to modify the communication to sent.
   */
  @Override
  public void sendCommunication(final SendCommunicationDetails details)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call business process to send the communication
    communicationObj.send(details.details);
  }

  /**
   * Creates an Microsoft Word communication on a case.
   *
   * @param details
   * Details to create Microsoft Word communication.
   *
   * @return Template and document data key
   * @deprecated Since Curam 6.0, replaced by {@link
   * createCaseMSWordCommunication1()}. The new method returns the
   * same details but also returns indicators that will be used to
   * conditionally display list row action appropriate to the
   * communication type.
   */
  @Override
  @Deprecated
  public TemplateAndDocumentDataKey createCaseMSWordCommunication(
    final CreateCaseMSWordCommunicationDetails details)
    throws AppException, InformationalException {

    // Create return object
    final TemplateAndDocumentDataKey templateAndDocumentDataKey =
      new TemplateAndDocumentDataKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create Microsoft Word communication
    templateAndDocumentDataKey.dtls =
      communicationObj.createCaseMSWordCommunication(details.details);

    return templateAndDocumentDataKey;
  }

  /**
   * Creates an Microsoft Word communication on a case.
   *
   * @param details
   * Details to create Microsoft Word communication.
   *
   * @return Template and document data key
   */
  @Override
  public TemplateAndDocumentDataKey createCaseMSWordCommunication1(
    final CreateMSWordCommunicationDetails1 details)
    throws AppException, InformationalException {

    // Create return object
    final TemplateAndDocumentDataKey templateAndDocumentDataKey =
      new TemplateAndDocumentDataKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create Microsoft Word communication
    templateAndDocumentDataKey.dtls =
      communicationObj.createCaseMSWordCommunication1(details);

    return templateAndDocumentDataKey;
  }

  /**
   * Creates an Email communication.
   *
   * @param createEmailCommDetails
   * Details to create an email communication.
   */
  @Override
  public void createEmail(final CreateEmailCommDetails createEmailCommDetails)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create an email communication
    communicationObj.createEmail(createEmailCommDetails.details);
  }

  /**
   * Modifies a communications correspondent.
   *
   * @param modifyCorrespondentDetails
   * Details of the new communication correspondent.
   */
  @Override
  public void modifyCorrespondent(
    final ModifyCorrespondentDetails modifyCorrespondentDetails)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to modify an communications correspondent
    communicationObj.modifyCorrespondent(modifyCorrespondentDetails.details);
  }

  /**
   * Send an email communication.
   *
   * @param sendEmailDetails
   * Communication details to be sent in the email.
   */
  @Override
  public void sendEmail(final SendEmailDetails sendEmailDetails)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to send an email communication
    communicationObj.sendEmail(sendEmailDetails.details);
  }

  /**
   * Method returns a correspondents participant role id based on parameters
   * passed in.
   *
   * @param correspondentDetails
   * Correspondent details.
   *
   * @return Correspondent participant role identifier.
   */
  @Override
  public CorrespondentID
    getCorrespondent(final CorrespondentDetails correspondentDetails)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // create return object
    final CorrespondentID correspondentID = new CorrespondentID();

    // Call service layer method to send an email communication
    correspondentID.details =
      communicationObj.getCorrespondent(correspondentDetails.details);

    // return correspondent participant role id
    return correspondentID;
  }

  /**
   * Modifies an Email communication.
   *
   * @param modifyEmailCommDetails
   * Details to modify an email communication.
   * @param modifyEmailCommKey
   * identifier for an email communication.
   */
  @Override
  public void modifyEmail(final ModifyEmailCommDetails modifyEmailCommDetails,
    final ModifyEmailCommKey modifyEmailCommKey)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = modifyEmailCommDetails.details.caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify an email communication
    communicationObj.modifyEmail(modifyEmailCommDetails.details,
      modifyEmailCommKey.key);
  }

  /**
   * Reads an Email communication.
   *
   * @param readEmailCommKey
   * Contains the communication identifier.
   * @return ReadEmailCommDetails the communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadEmailCommDetails
    readEmail(final ReadEmailCommKey readEmailCommKey)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // create return struct
    final ReadEmailCommDetails readEmailCommDetails =
      new ReadEmailCommDetails();

    // BEGIN, CR00001117, CM
    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set communication key
    communicationIDKey.communicationID = readEmailCommKey.key.communicationID;

    // set case key
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kReadSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify an email communication
    readEmailCommDetails.details =
      communicationObj.readEmail(readEmailCommKey.key);
    // BEGIN, CR00143201, JMA
    if (readEmailCommDetails.details.communicationStatus
      .equals(COMMUNICATIONSTATUS.DRAFT)) {

      readEmailCommDetails.details.sendLaterInd = true;

    }
    // END, CR00143201
    return readEmailCommDetails;
  }

  /**
   * Reads an Email communication.
   *
   * @param readEmailCommKey
   * Contains the communication identifier.
   * @return ReadEmailCommDetails the communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ReadEmailCommunicationCaseMember
    readEmailAndCaseMember(final ReadEmailCommKey readEmailCommKey)
      throws AppException, InformationalException {

    final ReadEmailCommunicationCaseMember readEmailCommunicationCaseMember =
      new ReadEmailCommunicationCaseMember();

    final ReadEmailCommDetails readEmailCommDetails =
      readEmail(readEmailCommKey);

    readEmailCommunicationCaseMember.communicationDtls = readEmailCommDetails;

    if (readEmailCommDetails.details.clientParticipantRoleID != 0) {

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        readEmailCommDetails.details.clientParticipantRoleID;
      final ConcernRoleNameTypeDateDetails concernRoleNameTypeDateDetails =
        ConcernRoleFactory.newInstance().readNameTypeAndDate(concernRoleKey);

      readEmailCommunicationCaseMember.clientConcernRoleName =
        concernRoleNameTypeDateDetails.concernRoleName;
      readEmailCommunicationCaseMember.clientConcernRoleType =
        concernRoleNameTypeDateDetails.concernRoleType;

    }

    return readEmailCommunicationCaseMember;
  }

  /**
   * Creates a recorded communication.
   *
   * @param recordedCommDetails
   * Recorded communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#createRecordedCommunication1(RecordedCommDetails1)} .
   * See release note: CR00237138.
   */
  @Override
  @Deprecated
  public void
    createRecordedCommunication(final RecordedCommDetails recordedCommDetails)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create a recorded communication
    communicationObj
      .createRecordedCommunication(recordedCommDetails.recordedCommDetails);
  }

  // BEGIN, CR00237138, NS
  /**
   * Creates a recorded communication.
   *
   * @param recordedCommDetails
   * Recorded communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createRecordedCommunication1(
    final RecordedCommDetails1 recordedCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create a recorded communication.
    communicationObj
      .createRecordedCommunication1(recordedCommDetails.recordedCommDetails);
  }

  // END, CR00237138

  /**
   * Modifies a recorded communication.
   *
   * @param modifyRecordedCommKey
   * Communication key.
   *
   * @param modifyRecordedCommDetails
   * Communication Details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#modifyRecordedCommunication1(ModifyRecordedCommKey, ModifyRecordedCommDetails1)}
   * . See release note: CR00237138.
   */
  @Override
  @Deprecated
  public void modifyRecordedCommunication(
    final ModifyRecordedCommKey modifyRecordedCommKey,
    final ModifyRecordedCommDetails modifyRecordedCommDetails)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = modifyRecordedCommDetails.recordedCommDetails.caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify a recorded communication
    communicationObj.modifyRecordedCommunication(
      modifyRecordedCommKey.recordedCommKey,
      modifyRecordedCommDetails.recordedCommDetails);
  }

  // BEGIN, CR00237138, NS
  /**
   * Modifies a recorded communication.
   *
   * @param modifyRecordedCommKey
   * Communication key.
   *
   * @param modifyRecordedCommDetails
   * Communication Details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyRecordedCommunication1(
    final ModifyRecordedCommKey modifyRecordedCommKey,
    final ModifyRecordedCommDetails1 modifyRecordedCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = modifyRecordedCommDetails.recordedCommDetails.caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {

      // BEGIN ,CR00019482, AK
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // If case type is service plan, check service plan security.
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        final ServicePlanDelivery servicePlanDeliveryObj =
          ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // Register the service plan security implementation.
        ServicePlanSecurityImplementationFactory.register();

        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    }
    // END, CR00002484

    // Call service layer method to modify a recorded communication.
    communicationObj.modifyRecordedCommunication1(
      modifyRecordedCommKey.recordedCommKey,
      modifyRecordedCommDetails.recordedCommDetails);
  }

  // END, CR00237138

  /**
   * Reads a recorded communication.
   *
   * @param readRecordedCommKey
   * Communication key.
   * @return readRecordedCommDetails Communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#readRecordedCommunication1(ReadRecordedCommKey)} . See
   * release note: CR00237138.
   */
  @Override
  @Deprecated
  public ReadRecordedCommDetails
    readRecordedCommunication(final ReadRecordedCommKey readRecordedCommKey)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // create return struct
    final ReadRecordedCommDetails readRecordedCommDetails =
      new ReadRecordedCommDetails();

    // BEGIN, CR00001117, CM
    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set communication key
    communicationIDKey.communicationID =
      readRecordedCommKey.recordedCommKey.communicationID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {

      // BEGIN, CR00017098, CM
      // set case key
      caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END, CR00017098

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kReadSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify an email communication
    readRecordedCommDetails.recordedCommDetails = communicationObj
      .readRecordedCommunication(readRecordedCommKey.recordedCommKey);

    return readRecordedCommDetails;
  }

  // BEGIN, CR00237138, NS
  /**
   * Reads a recorded communication.
   *
   * @param readRecordedCommKey
   * Communication key.
   * @return readRecordedCommDetails Communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadRecordedCommDetails1
    readRecordedCommunication1(final ReadRecordedCommKey readRecordedCommKey)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();
    final ReadRecordedCommDetails1 readRecordedCommDetails =
      new ReadRecordedCommDetails1();

    // BEGIN, CR00001117, CM
    final CommunicationIDKey communicationIDKey = new CommunicationIDKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    communicationIDKey.communicationID =
      readRecordedCommKey.recordedCommKey.communicationID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {

      // BEGIN, CR00017098, CM
      caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END, CR00017098

      // If case type is service plan, check service plan security.
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        final ServicePlanDelivery servicePlanDeliveryObj =
          ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // Register the service plan security implementation.
        ServicePlanSecurityImplementationFactory.register();
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kReadSecurityCheck;

        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify an email communication.
    readRecordedCommDetails.recordedCommDetails = communicationObj
      .readRecordedCommunication1(readRecordedCommKey.recordedCommKey);

    return readRecordedCommDetails;
  }

  // END, CR00237138

  /**
   * Reads a recorded communication and the regarding case member details.
   *
   * @param readRecordedCommKey
   * Communication key.
   * @return readRecordedCommDetails Communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ReadRecordedCommunicationCaseMember
    readRecordedCommunicationAndCaseMember(
      final ReadRecordedCommKey readRecordedCommKey)
      throws AppException, InformationalException {

    final ReadRecordedCommunicationCaseMember readRecordedCommunicationCaseMember =
      new ReadRecordedCommunicationCaseMember();

    final ReadRecordedCommDetails1 readRecordedCommDetails =
      readRecordedCommunication1(readRecordedCommKey);

    readRecordedCommunicationCaseMember.recordedCommCaseMember =
      readRecordedCommDetails;

    // Add the regarding case member name to the return struct
    if (readRecordedCommDetails.recordedCommDetails.clientParticipantRoleID != 0) {

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        readRecordedCommDetails.recordedCommDetails.clientParticipantRoleID;

      final ConcernRoleNameTypeDateDetails concernRoleNameTypeDateDetails =
        ConcernRoleFactory.newInstance().readNameTypeAndDate(concernRoleKey);

      readRecordedCommunicationCaseMember.clientConcernRoleName =
        concernRoleNameTypeDateDetails.concernRoleName;
      readRecordedCommunicationCaseMember.clientConcernRoleType =
        concernRoleNameTypeDateDetails.concernRoleType;
    }

    return readRecordedCommunicationCaseMember;
  }

  /**
   * Creates a pro forma communication.
   *
   * @param createProFormaCommDetails
   * Communication Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#createProForma1(CreateProFormaCommDetails1)} . See
   * release note: CR00236672.
   */
  @Override
  @Deprecated
  public void
    createProForma(final CreateProFormaCommDetails createProFormaCommDetails)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to create a pro forma communication
    communicationObj
      .createProForma(createProFormaCommDetails.createProFormaCommDetails);
  }

  // BEGIN, CR00236672, NS
  /**
   * Creates a pro forma communication.
   *
   * @param createProFormaCommDetails
   * Communication Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createProForma1(
    final CreateProFormaCommDetails1 createProFormaCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Create a pro forma communication.
    communicationObj.createProForma1(createProFormaCommDetails.dtls);
  }

  // END, CR00236672

  // BEGIN, CR00342937, KRK
  /**
   * Returns a list of templates based on template type and the participant
   * identifier. To retrieve the templates related to appeal case, this has been
   * overridden by
   * {@link AppealCommunication# listTemplatesByCaseTypeAndParticipant(ListProFormaTemplateByTypeAndParticipantKey listProFormaTemplateByTypeAndParticipantKey)}
   * . in appeals component.
   *
   * @param listProFormaTemplateByTypeAndParticipantKey
   * Key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00342937
  @Override
  public ListProFormaTemplateByTypeAndParticpant
    listTemplateByTypeAndParticipant(
      final ListProFormaTemplateByTypeAndParticipantKey listProFormaTemplateByTypeAndParticipantKey)
      throws AppException, InformationalException {

    // create return object
    final ListProFormaTemplateByTypeAndParticpant listProFormaTemplateByTypeAndParticpant =
      new ListProFormaTemplateByTypeAndParticpant();

    // MaintainXSLTemplate manipulation variables
    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateObj =
      curam.core.fact.MaintainXSLTemplateFactory.newInstance();
    final SearchTemplatesKey searchTemplatesKey = new SearchTemplatesKey();

    if (listProFormaTemplateByTypeAndParticipantKey.participantRoleID == 0
      && listProFormaTemplateByTypeAndParticipantKey.caseID != 0) {

      final curam.core.intf.CaseHeader caseHeaderObj =
        curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // Set key to read caseHeader to retrieve the concernRoleID
      caseHeaderKey.caseID =
        listProFormaTemplateByTypeAndParticipantKey.caseID;
      // BEGIN, CR00108061, GSP
      // Read caseHeader
      listProFormaTemplateByTypeAndParticipantKey.participantRoleID =
        caseHeaderObj.read(caseHeaderKey).concernRoleID;
      // END, CR00108061
    }

    // Set key details to retrieve the list of templates
    searchTemplatesKey.concernRoleID =
      listProFormaTemplateByTypeAndParticipantKey.participantRoleID;
    searchTemplatesKey.templateType =
      listProFormaTemplateByTypeAndParticipantKey.templateType;
    searchTemplatesKey.caseID =
      listProFormaTemplateByTypeAndParticipantKey.caseID;

    // Call MaintainXSLTemplate BPO to retrieve the list of templates
    listProFormaTemplateByTypeAndParticpant.searchTemplatesByConcernAndTypeResult =
      maintainXSLTemplateObj
        .searchTemplatesByConcernAndType(searchTemplatesKey);

    return listProFormaTemplateByTypeAndParticpant;
  }

  /**
   * Modifies a pro forma communication.
   *
   * @param modifyProFormaCommDetails
   * Modifies pro forma communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#modifyProForma1(ModifyProFormaCommDetails1)} . See
   * release note: CR00236672.
   */
  @Override
  @Deprecated
  public void
    modifyProForma(final ModifyProFormaCommDetails modifyProFormaCommDetails)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = modifyProFormaCommDetails.proFormaCommDetails.caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final ServicePlanDelivery servicePlanDeliveryObj =
          ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify a pro forma communication
    communicationObj
      .modifyProForma(modifyProFormaCommDetails.proFormaCommDetails);
  }

  // BEGIN, CR00236672, NS
  /**
   * Modifies a pro forma communication.
   *
   * @param modifyProFormaCommDetails
   * Modifies pro forma communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyProForma1(
    final ModifyProFormaCommDetails1 modifyProFormaCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = modifyProFormaCommDetails.dtls.caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {

      // BEGIN ,CR00019482, AK
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // If case type is service plan, check service plan security.
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        final ServicePlanDelivery servicePlanDeliveryObj =
          ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        ServicePlanSecurityImplementationFactory.register();

        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify a pro forma communication.
    communicationObj.modifyProForma1(modifyProFormaCommDetails.dtls);
  }

  // END, CR00236672

  /**
   * Reads a pro forma communication.
   *
   * @param readProFormaCommKey
   * Communication key.
   * @return Pro forma communication details.
   * @deprecated Since Curam 6.0, replaced by {@link #readProForma1()}.
   */
  @Override
  @Deprecated
  public ProFormaCommDetails
    readProForma(final ReadProFormaCommKey readProFormaCommKey)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // create return struct
    final ProFormaCommDetails proFormaCommDetails = new ProFormaCommDetails();

    // BEGIN, CR00001117, CM
    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set communication key
    communicationIDKey.communicationID =
      readProFormaCommKey.proFormaCommKey.communicationID;

    // set case key
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kReadSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to modify an email communication
    proFormaCommDetails.readProFormaCommDetails =
      communicationObj.readProForma(readProFormaCommKey.proFormaCommKey);

    return proFormaCommDetails;
  }

  /**
   * Prints a pro forma communication.
   *
   * @param printProFormaKey
   * Contains details to print the communication.
   */
  @Override
  public void printProForma(final PrintProFormaKey printProFormaKey)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey =
      new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set communication key
    communicationIDKey.communicationID =
      printProFormaKey.printProformaKey.communicationID;

    // set case key
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    // BEGIN, CR00002484, CM
    if (caseKey.caseID != 0) {
      // BEGIN ,CR00019482, AK
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // END ,CR00019482

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    } // END, CR00002484

    // Call service layer method to print a pro forma communication
    communicationObj.printProForma(printProFormaKey.printProformaKey);
  }

  /**
   * Reads a list of communications for a participant.
   *
   * @param participantCommunicationKey
   * concern role identifier.
   * @return Communication list.
   * @deprecated Since Curam 6.0, replaced by
   * {@link Participant#listCommunication()}. The new method returns
   * the same details but also returns indicators that will be used
   * to conditionally display list row action appropriate to the
   * communication type.
   */
  @Override
  @Deprecated
  public ParticipantCommunicationDetailsList listCommunication(
    final ParticipantCommunicationKey participantCommunicationKey)
    throws AppException, InformationalException {

    // return details
    final ParticipantCommunicationDetailsList participantCommunicationDetailsList =
      new ParticipantCommunicationDetailsList();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to list a participants communications.
    participantCommunicationDetailsList.participantCommunicationDetailsList =
      communicationObj
        .listCommunication(participantCommunicationKey.participantCommKey);

    // Context key
    final CommunicationContextKey communicationContextKey =
      new CommunicationContextKey();

    communicationContextKey.concernRoleID =
      participantCommunicationKey.participantCommKey.concernRoleID;

    // Get the context description for the concern role
    participantCommunicationDetailsList.description =
      readContextDescription(communicationContextKey).description;

    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj =
        curam.core.sl.fact.ClientMergeFactory.newInstance();

      // END, CR00102618

      // BEGIN, CR00102618, CSH
      // Set menu data for displaying any duplicate client communications
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        participantCommunicationKey.participantCommKey.concernRoleID;

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      dupPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listCommunicationForDuplicate;
      origPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listCommunication;

      // BEGIN, CR00102900, CSH
      // Display the duplicate soft links in a tab format

      // Set value of currently selected concern
      final ConcernRoleKey currentKey = new ConcernRoleKey();

      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Build up the xml data needed for the tab widget
      participantCommunicationDetailsList.renderXML =
        clientMergeObj.getDuplicateMenuRendererData(concernRoleKey,
          currentKey, dupPageIdentifier, origPageIdentifier);
      // END, CR00102900

      // Set an indicator if this concern has duplicates
      // Check for duplicates
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
        new ConcernRoleIDStatusCodeKey();

      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      participantCommunicationDetailsList.ind = clientMergeSLObj
        .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
      // END, CR00102618
    }
    // END, CR00221607

    // return list
    return participantCommunicationDetailsList;
  }

  /**
   * Read the Contact Context Description Details for a Communication.
   *
   * @param communicationContextKey
   * The concernRoleID the context description is returned for.
   *
   * @return The communication context description.
   */
  @Override
  public CommunicationContextDetails readContextDescription(
    final CommunicationContextKey communicationContextKey)
    throws AppException, InformationalException {

    // Concern Role object and key.
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Details to be returned.
    final CommunicationContextDetails communicationContextDetails =
      new CommunicationContextDetails();

    // Get the concern role ID from the key.
    concernRoleKey.concernRoleID = communicationContextKey.concernRoleID;

    // Read the concern role details.
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    if (concernRoleDtls.concernRoleType
      .equals(curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {
      // Set the context description for prospect.
      communicationContextDetails.description =
        concernRoleDtls.concernRoleName;
    } else {

      if (concernRoleDtls.primaryAlternateID.length() == 0) {

        // Set the context description without the primaryAlternateID.
        communicationContextDetails.description =
          concernRoleDtls.concernRoleName;
      } else {

        // Set the context description.
        // BEGIN, CR00098942, SAI
        // BEGIN, CR00222190, ELG
        communicationContextDetails.description =
          concernRoleDtls.concernRoleName + CuramConst.gkSpace
            + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
              .getMessageText(TransactionInfo.getProgramLocale())
            + concernRoleDtls.primaryAlternateID;
        // END, CR00222190
        // END, CR00098942
      }

    }

    return communicationContextDetails;
  }

  /**
   * Method returns a correspondents concern role id based on parameters passed
   * in.
   *
   * @param correspondentDetails
   * Correspondent details.
   * @return Correspondent concern role identifier.
   */
  @Override
  public CorrespondentID
    getCaseCorrespondent(final CorrespondentDetails correspondentDetails)
      throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // create return object
    final CorrespondentID correspondentID = new CorrespondentID();

    // Call service layer method to send an email communication
    correspondentID.details =
      communicationObj.getCaseCorrespondent(correspondentDetails.details);

    // return correspondent participant role id
    return correspondentID;
  }

  /**
   * Method returns a integrated case id and integrated case type based on a
   * case participant role id.
   *
   * @param resolveCorrespondentHomeKey
   * Case participant role identifier.
   * @return Integrated Case ID and case type details
   */
  @Override
  public IntegratedCaseIDAndTypeDetails resolveCorrespondentHome(
    final ResolveCorrespondentHomeKey resolveCorrespondentHomeKey)
    throws AppException, InformationalException {

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // create return object
    final IntegratedCaseIDAndTypeDetails integratedCaseIDAndTypeDetails =
      new IntegratedCaseIDAndTypeDetails();

    // Call service layer method to get the integrated Case ID and case
    // type details
    integratedCaseIDAndTypeDetails.integratedCaseIDAndtypeDetails =
      communicationObj.readCaseIDAndParticipantID(
        resolveCorrespondentHomeKey.caseParticipantRoleIDKey);

    // return the integrated Case ID and case type details
    return integratedCaseIDAndTypeDetails;
  }

  // BEGIN, CR00102618, CSH

  /**
   * Reads a list of communications for a duplicate participant.
   *
   * @param key
   * duplicate concern role identifier.
   *
   * @return Communication list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public DuplicateParticipantCommunicationDetailsList
    listCommunicationForDuplicate(final ParticipantCommunicationKey key)
      throws AppException, InformationalException {

    // Return details
    final DuplicateParticipantCommunicationDetailsList duplicateParticipantCommDetailsList =
      new DuplicateParticipantCommunicationDetailsList();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Get the list of communications for the participant
    duplicateParticipantCommDetailsList.dupParticipantCommDetailsList.participantCommunicationDetailsList =
      communicationObj.listCommunication(key.participantCommKey);

    // Context key
    final CommunicationContextKey communicationContextKey =
      new CommunicationContextKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj =
      ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey =
      new SearchByDuplicateConcernRoleIDKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.participantCommKey.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    communicationContextKey.concernRoleID =
      dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the concern role
    duplicateParticipantCommDetailsList.dupParticipantCommDetailsList.description =
      readContextDescription(communicationContextKey).description;

    // Also need to get context for the duplicate to display on list page
    communicationContextKey.concernRoleID =
      key.participantCommKey.concernRoleID;

    // Read the duplicate context description
    duplicateParticipantCommDetailsList.duplicateContextDesc.participantContextDescriptionDetails.description =
      readContextDescription(communicationContextKey).description;

    // BEGIN, CR00102900, CSH
    // Set menu data for displaying any duplicate client communications
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;
    currentKey.concernRoleID = key.participantCommKey.concernRoleID;

    // Set the pages to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    dupPageIdentifier.pageIdentifier =
      CuramConst.kPerson_listCommunicationForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCommunication;

    // Build up the xml data needed for the tab widget
    duplicateParticipantCommDetailsList.dupParticipantCommDetailsList.renderXML =
      clientMergeObj.getDuplicateMenuRendererData(concernRoleKey, currentKey,
        dupPageIdentifier, origPageIdentifier);
    // return list
    return duplicateParticipantCommDetailsList;

  }

  // END, CR00102900
  // END, CR00102618

  // BEGIN, CR00164008, JMA

  /**
   * Generates an XML document from the specified XSL template and previews that
   * document.
   *
   * @param previewProFormaKey
   * the communication id to preview
   *
   * @return the document details to be previewed
   */
  @Override
  public ProFormaReturnDocDetails
    previewProForma(final PreviewProFormaKey previewProFormaKey)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    ProFormaReturnDocDetails proFormaReturnDocDetails =
      new ProFormaReturnDocDetails();
    // BEGIN, CR00164728, JMA
    final ProFormaCommKey proFormaCommKey = new ProFormaCommKey();

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    proFormaCommKey.communicationID = previewProFormaKey.communicationID;

    // BEGIN, CR00236672, NS
    final curam.core.sl.struct.ProFormaCommDetails1 proFormaCommDetails =
      communicationObj.readProForma1(proFormaCommKey);

    // END, CR00236672

    caseKey.caseID = proFormaCommDetails.caseID;
    previewProFormaKey.localeIdentifier =
      proFormaCommDetails.localeIdentifier;
    // END, CR00164728,
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }

    }

    // Call service layer method to print a pro forma communication
    proFormaReturnDocDetails =
      communicationObj.previewProForma(previewProFormaKey);

    return proFormaReturnDocDetails;
  }

  // END, CR00164008

  /**
   * Utility method that returns the delete page for a communication based on
   * the communication format e.g. Email. The constant that is being added to
   * the identifier for the delete page is so that the return page is (usually
   * saved with the SAVE_LINK parameter in the pages) is stored when the
   * URI_SOURCE_NAME is derived in the pages.
   *
   * @param details
   * The communication details
   * @return DeletePageIdentifier the page identifier for the delete page.
   */
  @Override
  public DeletePageIdentifier
    getDeletePageName(final CommunicationAndListRowActionDetails details) {

    final DeletePageIdentifier deletePageIdentifier =
      new DeletePageIdentifier();

    if (details.communicationFormat.equals(COMMUNICATIONFORMAT.EMAIL)) {
      deletePageIdentifier.deletePageName = CuramConst.gkStoreCuramReturnPage
        + CuramConst.kdeleteDraftEmailPageIdentifier;
    } else if (details.communicationFormat
      .equals(COMMUNICATIONFORMAT.MSWORD)) {
      deletePageIdentifier.deletePageName = CuramConst.gkStoreCuramReturnPage
        + CuramConst.kdeleteMSWordPageIdentifier;
    } else if (details.communicationFormat
      .equals(COMMUNICATIONFORMAT.PROFORMA)) {
      deletePageIdentifier.deletePageName = CuramConst.gkStoreCuramReturnPage
        + CuramConst.kdeleteProFormaPageIdentifier;
    } else if (details.communicationFormat
      .equals(COMMUNICATIONFORMAT.RECORDED)) {
      deletePageIdentifier.deletePageName = CuramConst.gkStoreCuramReturnPage
        + CuramConst.kdeleteRecordedCommunicationPageIdentifier;
    }

    return deletePageIdentifier;
  }

  // BEGIN, CR00178447, PM
  /**
   * Creates an Email communication for the case.
   *
   * @param createEmailCommDetails
   * Contains the details to create an email communication.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void createEmailCommunication(
    final CreateEmailCommDetails createEmailCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();

    communicationObj.createEmailCommunication(createEmailCommDetails.details);
  }

  /**
   * Creates a pro forma communication for the case.
   *
   * @param createProFormaCommDetails
   * Contains details for Proforma Communication.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#createProFormaCommunication1(CreateProFormaCommDetails1)}
   * . See release note: CR00236672.
   */
  @Override
  @Deprecated
  public void createProFormaCommunication(
    final CreateProFormaCommDetails createProFormaCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();

    communicationObj.createProFormaCommunication(
      createProFormaCommDetails.createProFormaCommDetails);
  }

  // BEGIN, CR00236672, NS
  /**
   * Creates a pro forma communication for the case.
   *
   * @param createProFormaCommDetails
   * Contains details for Proforma Communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void createProFormaCommunication1(
    final CreateProFormaCommDetails1 createProFormaCommDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();

    communicationObj
      .createProFormaCommunication1(createProFormaCommDetails.dtls);
  }

  // END, CR00236672

  /**
   * Creates a recorded communication for the case.
   *
   * @param recordedCommDetails
   * Contains recorded communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#createRecordedComm1(RecordedCommDetails1)} . See
   * release note: CR00237138.
   */
  @Override
  @Deprecated
  public void
    createRecordedComm(final RecordedCommDetails recordedCommDetails)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();

    communicationObj
      .createRecordedComm(recordedCommDetails.recordedCommDetails);
  }

  // BEGIN, CR00237138, NS
  /**
   * Creates a recorded communication for the case.
   *
   * @param recordedCommDetails
   * Contains recorded communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void
    createRecordedComm1(final RecordedCommDetails1 recordedCommDetails)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();

    communicationObj
      .createRecordedComm1(recordedCommDetails.recordedCommDetails);
  }

  // END, CR00237138
  // BEGIN, CR00262895, MC

  /**
   * Returns a correspondent's concern role id based on the correspondent
   * details passed in.
   *
   * @param correspondentDetails
   * Contains correspondent details.
   *
   * @return The Correspondent concern role identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link Communication#getCaseMemberAndCorrespondentForCommunication()} . A
   * new validation has been added to ensure that a regarding
   * case member is provided with every communication.
   */
  @Override
  @Deprecated
  public CorrespondentID getCaseCorrespondentForCommunication(
    final CorrespondentDetails correspondentDetails)
    throws AppException, InformationalException {

    final CorrespondentID correspondentID = new CorrespondentID();

    correspondentID.details = CommunicationFactory.newInstance()
      .getCaseCorrespondentForCommunication(correspondentDetails.details);

    return correspondentID;
  }

  // END, CR00178447

  /**
   * Returns a correspondent's concern role id based on the correspondent
   * details passed in.
   *
   * @param correspondentDetails
   * Contains correspondent details.
   *
   * @return The Correspondent concern role identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CorrespondentID getCaseMemberAndCorrespondentForCommunication(
    final CorrespondentDetails correspondentDetails)
    throws AppException, InformationalException {

    final CorrespondentID correspondentID = new CorrespondentID();

    correspondentID.details = CommunicationFactory.newInstance()
      .getCaseCorrespondentForCommunication(correspondentDetails.details);

    return correspondentID;
  }

  // END, CR00262895

  // BEGIN, CR00246099, AK
  /**
   * Returns the file content and the file name of the communication that has to
   * be opened or previewed.
   *
   * @param CommunicationIDKey
   * Contains the Communication ID.
   *
   * @return FileNameAndDataDtls the name and the content of the file.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public FileNameAndDataDtls
    printCommunication(final CommunicationIDKey communicationIDKey)
      throws AppException, InformationalException {

    final FileNameAndDataDtls fileNameAndDataDtls = new FileNameAndDataDtls();
    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();
    final ConcernRoleCommunication concernRoleCommunicationObj =
      ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationKey key = new ConcernRoleCommunicationKey();

    key.communicationID = communicationIDKey.communicationID;
    final ConcernRoleCommunicationDtls communicationDetails =
      concernRoleCommunicationObj.read(key);

    // Defect 248175 - only check the participant security if a concern role id
    // exists for the communication
    if (communicationDetails.concernRoleID != 0) {
      // BEGIN, CR00466873, EC
      final DataBasedSecurity dataBasedSecurity =
        SecurityImplementationFactory.get();
      DataBasedSecurityResult dataBasedSecurityResult =
        new DataBasedSecurityResult();

      final ParticipantSecurityCheckKey participantKey =
        new ParticipantSecurityCheckKey();

      participantKey.participantID = communicationDetails.concernRoleID;
      participantKey.type = LOCATIONACCESSTYPE.READ;

      dataBasedSecurityResult =
        dataBasedSecurity.checkParticipantSecurity(participantKey);

      if (!dataBasedSecurityResult.result) {

        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      }
      // END, CR00466873
    }

    if (COMMUNICATIONFORMAT.PROFORMA
      .equals(communicationDetails.communicationFormat)) {

      final PreviewProFormaKey previewProFormaKey = new PreviewProFormaKey();

      previewProFormaKey.communicationID = communicationIDKey.communicationID;
      final ProFormaReturnDocDetails proformaDetails =
        communicationObj.previewProForma(previewProFormaKey);

      fileNameAndDataDtls.fileContent = proformaDetails.fileDate;
      fileNameAndDataDtls.fileName = proformaDetails.fileName;

    } else if (COMMUNICATIONFORMAT.MSWORD
      .equals(communicationDetails.communicationFormat)) {

      final CommAttachmentLink commAttachmentLinkObj =
        CommAttachmentLinkFactory.newInstance();
      final CommunicationAttachmentLinkReadmultiKey rmkey =
        new CommunicationAttachmentLinkReadmultiKey();

      rmkey.communicationID = communicationIDKey.communicationID;
      final ReadAttachmentKey readAttachmentKey = new ReadAttachmentKey();

      readAttachmentKey.readAttachmentIn.attachmentID =
        commAttachmentLinkObj.searchByCommunication(rmkey).dtls
          .item(0).attachmentID;
      final ReadCommunicationAttachmentDetails attachmentDetails =
        ParticipantFactory.newInstance()
          .readCommunicationAttachment(readAttachmentKey);

      fileNameAndDataDtls.fileContent =
        attachmentDetails.readCommunicationAttachmentDtls.attachmentContents;
      fileNameAndDataDtls.fileName =
        attachmentDetails.readCommunicationAttachmentDtls.attachmentName;
    }
    return fileNameAndDataDtls;
  }

  // END, CR00246099

  // BEGIN, CR00467223, MV
  /**
   * Send an email communication without saving in to the concern role
   * communication table.
   *
   * Validations exists for
   * - presence of from-emailID and to-emailID.
   * - incorrect format of from-emailID and to-emailID.
   *
   * @param emailCommunicationDetails
   * email communication details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void sendByEmailWithNoRecord(
    final EmailCommunicationDetails emailCommunicationDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Communication communicationObj =
      CommunicationFactory.newInstance();

    // BEGIN, CR00467234, MV
    communicationObj.sendByEmailWithNoRecord(emailCommunicationDetails.dtls);
    // END, CR00467234
  }
  // END, CR00467223
}
