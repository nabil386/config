/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;


import curam.core.facade.struct.IntegratedCaseAdminDtls;
import curam.core.sl.impl.IntegratedCaseAdminFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Facade for Admin Integrated Case
 *
 */
public class IntegratedCaseAdmin extends curam.core.facade.base.IntegratedCaseAdmin {

  @Override
  public void createAdminIntegratedCase(IntegratedCaseAdminDtls dtls)
    throws AppException, InformationalException {

    final curam.core.sl.impl.IntegratedCaseAdmin adminIntegratedCase = IntegratedCaseAdminFactory.newInstance();

    adminIntegratedCase.createIntegratedCase(dtls);

  }

}
