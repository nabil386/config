/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2003,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.BUSINESSSTATUS;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CASENOMINEESTATUS;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.DEDUCTIONTYPECODE;
import curam.codetable.EVIDENCETREESTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.XSLTEMPLATETYPE;
import curam.codetable.impl.CONCERNROLEADDRESSTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.fact.AttachmentFactory;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.fact.CommunicationFactory;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.fact.ProductFactory;
import curam.core.facade.struct.*;
import curam.core.facade.struct.CaseID;
import curam.core.facade.struct.ICEventDetails;
import curam.core.facade.struct.PersonRegistrationDetails;
import curam.core.facade.struct.ProspectPersonRegistrationDetails;
import curam.core.facade.struct.ReactivationDetails;
import curam.core.fact.AdminIntegratedCaseFactory;
import curam.core.fact.CachedConcernRoleFactory;
import curam.core.fact.CaseDecisionFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainCaseClosureFactory;
import curam.core.fact.MaintainCaseContractFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.ProductHookManager;
import curam.core.intf.CachedConcernRole;
import curam.core.intf.CaseDecision;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainCaseClosure;
import curam.core.intf.MaintainConcernRoleDetails;
import curam.core.intf.Person;
import curam.core.intf.ProductDelivery;
import curam.core.intf.ProspectPerson;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.InvestigationConfigFactory;
import curam.core.sl.entity.fact.RepresentativeFactory;
import curam.core.sl.entity.fact.ScreeningConfigurationFactory;
import curam.core.sl.entity.fact.ScreeningFactory;
import curam.core.sl.entity.intf.IssueDelivery;
import curam.core.sl.entity.intf.Representative;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.sl.entity.struct.AssessmentTypeDetails;
import curam.core.sl.entity.struct.CaseEvidenceTreeKeyStruct;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.InvestigationConfigDtls;
import curam.core.sl.entity.struct.InvestigationConfigKey;
import curam.core.sl.entity.struct.InvestigationDeliveryDtls;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.InvestigationTypeCode;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.IssueTypeCode;
import curam.core.sl.entity.struct.LinkKey;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.entity.struct.ScreeningConfigurationDtls;
import curam.core.sl.entity.struct.ScreeningConfigurationKey;
import curam.core.sl.entity.struct.ScreeningDtls;
import curam.core.sl.entity.struct.ScreeningKey;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.fact.ActionPlanFactory;
import curam.core.sl.fact.AllegationFactory;
import curam.core.sl.fact.AssessmentDeliveryFactory;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.fact.InvestigationDeliveryFactory;
import curam.core.sl.fact.IssueDeliveryFactory;
import curam.core.sl.fact.MilestoneDeliveryFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.impl.ProductFilter;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.infrastructure.fact.EvidenceMetadataFactory;
import curam.core.sl.infrastructure.fact.ICEvidenceLinkFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.infrastructure.struct.ICEvidenceLinkAndEvidenceTypeKey;
import curam.core.sl.intf.ActionPlan;
import curam.core.sl.intf.Allegation;
import curam.core.sl.intf.AssessmentDelivery;
import curam.core.sl.intf.CaseNominee;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.MilestoneDelivery;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.struct.ActivityElementDetails;
import curam.core.sl.struct.CalculationEndDate;
import curam.core.sl.struct.CalculationStartDate;
import curam.core.sl.struct.CalendarElementData;
import curam.core.sl.struct.CancelICMemberNoteDetails;
import curam.core.sl.struct.CaseAccessibleNotesList1;
import curam.core.sl.struct.CaseAndConcernLinkedTaskDtls;
import curam.core.sl.struct.CaseIDAndParticipantRoleIDKey;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseIDTypeCodeKey;
import curam.core.sl.struct.CaseMemberCommDetailsList;
import curam.core.sl.struct.CaseMemberCommunicationDetails;
import curam.core.sl.struct.CaseNomineeCaseIDKey;
import curam.core.sl.struct.CaseNoteList;
import curam.core.sl.struct.CaseNoteList1;
import curam.core.sl.struct.CaseParticipantKeyStruct;
import curam.core.sl.struct.CaseParticipantRoleFullDetails1;
import curam.core.sl.struct.CaseParticipantRoleIDStruct;
import curam.core.sl.struct.CaseParticipantRole_boKey;
import curam.core.sl.struct.CaseSpecialCautionDetails;
import curam.core.sl.struct.CaseSpecialCautionDetailsList;
import curam.core.sl.struct.CommunicationKey;
import curam.core.sl.struct.ContactLogLinkIDLinkTypeKey;
import curam.core.sl.struct.CreateAssessmentDeliveryResult;
import curam.core.sl.struct.DateRangeKey;
import curam.core.sl.struct.DateTimeRangeDetails;
import curam.core.sl.struct.EventElementDetails;
import curam.core.sl.struct.GetBUCaseEvidenceKey;
import curam.core.sl.struct.InsertIntegratedCaseMemberNote;
import curam.core.sl.struct.IntegratedCaseMemberNoteKey;
import curam.core.sl.struct.IntegratedCaseMemberNoteList1;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededKey;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededResult;
import curam.core.sl.struct.ListGroupOnTreeResult;
import curam.core.sl.struct.ModifyICMemberNoteDetails1;
import curam.core.sl.struct.ProspectPersonHomeDetails;
import curam.core.sl.struct.ReadContactLogDetails;
import curam.core.sl.struct.ReadICMemberNoteDetails1;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.SpecialCautionDetails;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.*;
import curam.core.struct.CaseConcernRoleName;
import curam.core.struct.CaseDecisionKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.IntegratedCaseIDKey;
import curam.core.struct.ReadCaseClosureKey;
import curam.dynamicevidence.admin.impl.XmlTools;
import curam.message.BPOBROADCASTTRIGGER;
import curam.message.BPOCOMMUNICATION;
import curam.message.BPOPROSPECTPERSONREGISTRATION;
import curam.message.BPOREFLECTION;
import curam.message.CASEOVERVIEWMESSAGES;
import curam.message.INTEGRATEDCASEMEMBERNOTE;
import curam.message.SEPARATOR;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeStruct;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.administration.struct.XSLTemplateInstDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.XMLParserCache;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.FrequencyPattern;
import curam.util.type.NotFoundIndicator;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateNameKey;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * This business interface provides operations related to integrated cases.
 */
public abstract class IntegratedCase
    extends curam.core.facade.base.IntegratedCase {

  /**
   * The MIME content type.
   */
  private static final String kContentType = "text/xml;charset=utf-8";

  /**
   * The XML attribute 'name' tag.
   */
  public static final String XML_ATTRIBUTE_NAME = "name";

  /**
   * The XML attribute 'value' tag.
   */
  public static final String XML_ATTRIBUTE_VALUE = "value";

  /**
   * The XML element 'messages' tag.
   */
  public static final String XML_ELEMENT_MESSAGES = "messages";

  /**
   * The XML element 'message' tag.
   */
  public static final String XML_ELEMENT_MESSAGE = "message";

  protected static final int kBufSize = 256;

  protected static final int kBufferSize = 2048;

  // BEGIN, CR00023323, SK
  // BEGIN, CR00222190, ELG
  // BEGIN, CR00163471, JC
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   *             {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
   *             TransactionInfo.getProgramLocale())}. Replacement reason -
   *             static variables/constants cannot reference
   *             TransactionInfo.getProgramLocale(). See release note
   *             CR00219408.
   */
  @Deprecated
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
      .getMessageText();

  // END, CR00163471, JC
  // END, CR00222190

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kParamCaseParticipantRoleID = XmlMetaDataConst.kParamCaseParticipantRoleID;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;

  protected static final String kCuramCalendarDataHeader = CuramCalendarHeaderConst.kCuramCalendarDataHeader;

  protected static final String kCuramCalendarDataFooter = CuramCalendarHeaderConst.kCuramCalendarDataFooter;

  protected static final String kCloseBracket = CuramCalendarHeaderConst.kCloseBracket;

  protected static final String kQuote = CuramCalendarHeaderConst.kQuote;

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  /**
   * Inject the ProductFilter interface.
   */
  @Inject
  private ProductFilter productFilter;

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   *             {@link INTEGRATEDCASEMEMBERNOTE.INF_CASE_START_DATE.getMessageText(
   *             TransactionInfo.getProgramLocale())}. Replacement reason -
   *             static variables/constants cannot reference
   *             TransactionInfo.getProgramLocale(). See release note
   *             CR00219408.
   */
  @Deprecated
  // BEGIN, CR00163471, JC
  protected static final String kCaseStartDate = INTEGRATEDCASEMEMBERNOTE.INF_CASE_START_DATE
      .getMessageText();

  // END, CR00163471, JC
  // END, CR00222190

  protected static final String kFrequencyPattern = FrequencyPattern.kZeroFrequencyPattern
      .toString();

  // END, CR00023323

  // BEGIN CR00108134, GBA
  // Add injection for using the new CaseTransactionLog API
  public IntegratedCase() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00211744, VM
  @Inject
  protected AssessmentEngine assessmentEngine;

  // END, CR00211744

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108134

  // BEGIN, CR00240898, KH
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;

  // END, CR00240898

  // BEGIN, CR00213628, PB
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public curam.core.sl.struct.CaseParticipantRoleDtlsList readTranslatorRequiredForMember(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();

    CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = new CaseParticipantRoleDtlsList();
    final curam.core.sl.struct.CaseParticipantRoleDtlsList participantRoleDtlsList = new curam.core.sl.struct.CaseParticipantRoleDtlsList();
    final CaseParticipantRole_eoCaseIDKey caseParticipantRoleCaseIDKey = new CaseParticipantRole_eoCaseIDKey();

    caseParticipantRoleCaseIDKey.caseID = key.caseID;
    caseParticipantRoleDtlsList = caseParticipantRole
        .searchByCaseID(caseParticipantRoleCaseIDKey);
    participantRoleDtlsList.details.assign(caseParticipantRoleDtlsList);

    return participantRoleDtlsList;
  }

  // END, CR00213628

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleFullDetails1 readTranslationRequiredInd(
      final CaseIDKey key) throws AppException, InformationalException {

    // CaseParticipantRole manipulation variables
    final CaseIDTypeCodeKey caseIDTypeCodeKey = new CaseIDTypeCodeKey();
    CaseParticipantRoleFullDetails1 caseParticipantRoleFullDetails1 = new CaseParticipantRoleFullDetails1();
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    caseIDTypeCodeKey.caseID = key.caseID;
    caseIDTypeCodeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    try {
      caseParticipantRoleFullDetails1 = caseParticipantRoleObj
          .readByCaseIDAndTypeCode(caseIDTypeCodeKey);
    } catch (final RecordNotFoundException e) {// Nothing to do.
    }
    return caseParticipantRoleFullDetails1;
  }

  // END, CR00208321

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected ICMemberContextDescriptionDetails getICMemberContextDescription(
      final ICMemberContextDescriptionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICMemberContextDescriptionDetails icMemberContextDescriptionDetails = new ICMemberContextDescriptionDetails();

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = key.concernRoleID;

    // BEGIN CR00103984 SAI
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    final StringBuffer description = new StringBuffer();

    description.append(concernRoleDtls.concernRoleName);
    description.append(GeneralConstants.kSpace);
    description.append(concernRoleDtls.primaryAlternateID);

    // Assign description to the return object
    icMemberContextDescriptionDetails.description = description.toString();
    // END CR00103984

    return icMemberContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected ICMemberMenuDataDetails getICMemberMenuData(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed
    // in
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDCaseRefAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDcaseRefandParticipantID(caseParticipantRoleKey);

    // Get the case's parent case ID - the Integrated case ID
    caseKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails structure
    if (integratedCaseKey.integratedCaseID == 0) {
      caseHeaderKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;
    } else {
      caseHeaderKey.caseID = integratedCaseKey.integratedCaseID;
    }

    // BEGIN, 100358, VM
    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    return menuDataObj.getICMemberMenuData(key, caseHeaderKey);
    // END, 100358
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected ICProductDeliveryContextDescription getICProductDeliveryContextDescription(
      final ICProductDeliveryContextDescriptionKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ICProductDeliveryContextDescription icProductDeliveryContextDescription = new ICProductDeliveryContextDescription();

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component
    // installation
    // setting. If the environment variable is present and set to 'true',
    // run
    // the Reflection code.
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      // BEGIN, CR00023323, SK
      // BEGIN, CR00158377,RV
      final String className = ReflectionConst.coreToAppealDelegateWrapperClassName;
      // END, CR00158377
      // BEGIN, CR00065744, SK
      final String methodName = ReflectionConst.icProductDeliveryContextMethodName;
      // END, CR00065744
      // END, CR00023323
      // Set the arguments to pass through
      final Object[] arguments = new Object[] { key };

      // Set the passed class types to the method
      final Class[] parameterTypes = new Class[] {
          ICProductDeliveryContextDescriptionKey.class };

      return (ICProductDeliveryContextDescription) performReflection(className,
          methodName, arguments, parameterTypes);
    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    CaseConcernRoleName caseConcernRoleName;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory
        .newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read ConcernRole
    // BEGIN CR00103984 SAI
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);
    // END CR00103984
    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read caseHeader
    caseKey.caseID = key.caseID;

    // Read caseHeader
    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    // Read productDelivery
    caseHomePageNameAndType = productDeliveryObj
        .readCaseHomePageNameAndType(caseKey);

    // BEGIN CR00087948, CSH
    // BEGIN CR00077581, MC
    // BEGIN, CR00163098, JC
    // Assign it to the return object
    icProductDeliveryContextDescription.description = CodeTable.getOneItem(
        PRODUCTTYPE.TABLENAME, caseHomePageNameAndType.typeCode,
        TransactionInfo.getProgramLocale())
        // END, CR00163098, JC
        + GeneralConstants.kSpace + caseConcernRoleName.caseReference
        + GeneralConstants.kSpace + GeneralConstants.kMinus
        + GeneralConstants.kSpace
        // BEGIN CR00103984 SAI
        + concernRoleDtls.concernRoleName + GeneralConstants.kSpace
        + concernRoleDtls.primaryAlternateID;
    // END CR00103984
    // END CR00077581
    // END CR00087948
    return icProductDeliveryContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected ICProductDeliveryMenuDataDetails getICProductDeliveryMenuData(
      final ICProductDeliveryMenuDataKey key)
      throws AppException, InformationalException {

    // BEGIN, 100358, VM
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    return menuDataObj.getICProductDeliveryMenuData(key);
    // END, 100358
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected ICContextDescriptionDetails getIntegratedCaseContextDescription(
      final ICContextDescriptionKey_fo key)
      throws AppException, InformationalException {

    // Create return object
    final ICContextDescriptionDetails icContextDescriptionDetails = new ICContextDescriptionDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    ICHomePageNameAndType icHomePageNameAndType;

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Read caseHeader
    caseKey.caseID = key.caseID;
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    // Create the context description
    final StringBuffer buffer = new StringBuffer(kBufSize);

    // BEGIN, CR00163098, JC
    buffer.append(CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
        icHomePageNameAndType.integratedCaseType,
        TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    // BEGIN, CR00093978, SK
    buffer.append(kSpace);
    // END, CR00093978
    // BEGIN, CR00222190, ELG
    buffer.append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
        .getMessageText(TransactionInfo.getProgramLocale()));
    // END, CR00222190
    buffer.append(icHomePageNameAndType.caseReference);

    // Assign it to the return object
    icContextDescriptionDetails.description = buffer.toString();

    return icContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected IntegratedCaseMenuDataDetails getIntegratedCaseMenuData(
      final IntegratedCaseMenuDataKey key)
      throws AppException, InformationalException {

    // BEGIN, 100358, VM
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    return menuDataObj.getIntegratedCaseMenuData(key);
    // END, 100358
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICAdminCaseRoleDetails listAdminCaseRole(
      final ListICAdminCaseRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICAdminCaseRoleDetails listICAdminCaseRoleDetails = new ListICAdminCaseRoleDetails();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory
        .newInstance();
    curam.core.sl.struct.CaseUserRoleDetailsList caseUserRoleDetailsList;
    final curam.core.sl.struct.CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new curam.core.sl.struct.CaseUserRoleCaseIDKey();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Assign key to retrieve the list of Case User Roles
    caseUserRoleCaseIDKey.dtls.caseID = key.caseID;

    // Call CaseUserRole BPO to return the list of Case User Roles
    caseUserRoleDetailsList = caseUserRoleObj
        .listCaseUserRoles(caseUserRoleCaseIDKey);

    // BEGIN, CR00066677, CM
    // BEGIN, CR00205193, SS
    final int listSize = caseUserRoleDetailsList.dtls.size();

    listICAdminCaseRoleDetails.caseUserRoleDetailsList.ensureCapacity(listSize);

    // BEGIN, CR00216640, GSP
    // retrieve environment variable
    final String dispWorkQueueAsOwnerInCaseUserRole = Configuration
        .getProperty(EnvVars.ENV_DISPLAYTEMPWORKQUEUEASOWNERINCASEUSERROLE);

    listICAdminCaseRoleDetails.caseUserRoleDetailsList.ensureCapacity(listSize);
    for (final curam.core.sl.struct.CaseUserRoleDetails caseUserRoleDetails : caseUserRoleDetailsList.dtls
        .items()) {

      if (!(CuramConst.kTemporaryOwnerWorkqueueName.equalsIgnoreCase(
          caseUserRoleDetails.dtls.ownerDetails.orgObjectReferenceName)
          && dispWorkQueueAsOwnerInCaseUserRole
              .equalsIgnoreCase(EnvVars.ENV_VALUE_NO))) {

        listICAdminCaseRoleDetails.caseUserRoleDetailsList
            .addRef(caseUserRoleDetails);
      }
    }
    // END, CR00216640
    // END, CR00066677
    // END, CR00205193

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and set in return object
    listICAdminCaseRoleDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICAdminCaseRoleDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo
        .getInformationalManager();

    final String[] warnings = informationalManager
        .obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listICAdminCaseRoleDetails.informationalMsgDtlsList.dtls
          .addRef(informationalMsgDtls);

    }

    return listICAdminCaseRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICAssessmentDetails listAssessment(final ListICAssessmentKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICAssessmentDetails listICAssessmentDetails = new ListICAssessmentDetails();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;
    final CasesByCaseIDAndTypeKey casesByCaseIDAndTypeKey = new CasesByCaseIDAndTypeKey();

    // Set key to read assessments
    casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
    casesByCaseIDAndTypeKey.dtls.caseTypeCode = CASETYPECODE.ASSESSMENTDELIVERY;

    // read assessment delivery details list
    caseAndConcernSummaryDtlsList = maintainCaseObj
        .listCasesByTypeAndParentCaseID(casesByCaseIDAndTypeKey);

    listICAssessmentDetails.list.assign(caseAndConcernSummaryDtlsList);

    final AssessmentDelivery assessmentDeliveryObj = AssessmentDeliveryFactory
        .newInstance();

    listICAssessmentDetails.assessmentlist = assessmentDeliveryObj
        .listAssessmentCasesByIntegratedCaseID(casesByCaseIDAndTypeKey);

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICAssessmentDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICAssessmentDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICAssessmentDetails;
  }

  // BEGIN, CR00225060, ZV
  // ___________________________________________________________________________
  /**
   * This process will return a list of case members for a specified case.
   *
   * @param key
   *          Contains case identifier.
   *
   * @return List of client role case members.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #listCaseMembers1()}.
   */
  @Override
  @Deprecated
  public ListICClientRoleDetails listCaseMembers(final ListICClientKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

    listICClientRoleDetails.assign(listCaseMembers1(key));

    return listICClientRoleDetails;
  }

  // END, CR00225060

  // BEGIN CR00096012, PN
  // ---------------------------------------------------------------------------
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICClientRoleDetails listCaseMembersExcProspectPerson(
      final ListICClientKey key) throws AppException, InformationalException {

    // Create return object
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;
    String concernRoleType = null;
    int viewParticipantListCount = 0;

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // ICMemberContextDescriptionKey object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    // BEGIN, CR00145619, SS
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    // END, CR00145619

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());
    viewParticipantListCount = viewCaseParticipantRoleDetailsList.dtls.size();
    for (int i = 0; i < viewParticipantListCount; i++) {
      // concernRole manipulation variables
      if (viewCaseParticipantRoleDetailsList.dtls
          .item(i).participantRoleID != 0) {
        concernRoleKey.concernRoleID = viewCaseParticipantRoleDetailsList.dtls
            .item(i).participantRoleID;
        concernRoleDtls = concernRoleObj.read(concernRoleKey);
        if (concernRoleDtls != null) {
          concernRoleType = concernRoleDtls.concernRoleType;
        }
      }
      if (concernRoleType != null
          && !concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {
        // viewCaseParticipantRoleDetailsList.dtls.item(i).recordStatus=true;
        listICClientRoleDetails.participantList
            .addRef(viewCaseParticipantRoleDetailsList.dtls.item(i));

      }

    }
    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICClientRoleDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICClientRoleDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICClientRoleDetails;
  }

  // END CR00096012
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICClientRoleDetails listClientRole(final ListICClientKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // ICMemberContextDescriptionKey object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseParticipantRoleList(viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    // Set the return object
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      final curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

      // BEGIN 206408 IK
      if (!Configuration.getBooleanProperty(
          EnvVars.ENV_DISPLAY_PRIMARYCLIENT_IC,
          EnvVars.ENV_DISPLAY_PRIMARYCLIENT_IC_DEFAULT)
          && viewCaseParticipantRoleDetailsList.dtls.item(i).typeCode
              .equals(CASEPARTICIPANTROLETYPE.PRIMARY)) {
        viewCaseParticipantRoleDetailsList.dtls
            .item(i).typeCode = CASEPARTICIPANTROLETYPE.MEMBER;
      }

      // END,206408
      caseParticipantRoleFullDetails
          .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

      listICClientRoleDetails.participantList
          .addRef(caseParticipantRoleFullDetails);
    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICClientRoleDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICClientRoleDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICClientRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICMemberAssessmentDetails listMemberAssessment(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICMemberAssessmentDetails listICMemberAssessmentDetails = new ListICMemberAssessmentDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;
    final CasesByCaseIDConcernAndTypeKey casesByCaseIDConcernAndTypeKey = new CasesByCaseIDConcernAndTypeKey();

    // IC member context description key
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ListICMemberAssessmentKey listICMemberAssessmentKey = new ListICMemberAssessmentKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // BEGIN, CR00102331, PMD
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Read the integrated case and participant details
    final ReadIntegratedCaseIDAndParticipantDetails readIntegratedCaseIDAndParticipantDetails = caseHeaderObj
        .readIntegratedCaseIDAndParticipantDetails(caseHeaderKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    if (readIntegratedCaseIDAndParticipantDetails.integratedCaseID != 0) {

      listICMemberAssessmentKey.caseID = readIntegratedCaseIDAndParticipantDetails.integratedCaseID;

      listICMemberAssessmentKey.concernRoleID = readIntegratedCaseIDAndParticipantDetails.concernRoleID;
    } else {

      listICMemberAssessmentKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

      listICMemberAssessmentKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;
    }
    // END, CR00102331

    // Set key to read assessments
    casesByCaseIDConcernAndTypeKey.dtls.caseID = listICMemberAssessmentKey.caseID;
    casesByCaseIDConcernAndTypeKey.dtls.concernRoleID = listICMemberAssessmentKey.concernRoleID;
    casesByCaseIDConcernAndTypeKey.dtls.caseTypeCode = CASETYPECODE.ASSESSMENTDELIVERY;

    // read assessment delivery details list
    caseAndConcernSummaryDtlsList = maintainCaseObj
        .listCasesByTypeConcernRoleIDAndParentCaseID(
            casesByCaseIDConcernAndTypeKey);

    // supply the return object
    listICMemberAssessmentDetails.list.assign(caseAndConcernSummaryDtlsList);

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = listICMemberAssessmentKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = listICMemberAssessmentKey.concernRoleID;

    // Read context description
    listICMemberAssessmentDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listICMemberAssessmentDetails.icMemberMenuData = getICMemberMenuData(
        caseParticipantRoleKey);

    return listICMemberAssessmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICMemberProductDeliveryDetails listMemberProduct(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICMemberProductDeliveryDetails listICMemberProductDeliveryDetails = new ListICMemberProductDeliveryDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    final CasesByConcernAndICKey casesByConcernAndICKey = new CasesByConcernAndICKey();

    // ICMemberContextDescriptionKey object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // ICMemberMenuDataKey object
    final ICMemberMenuDataKey icMemberMenuDataKey = new ICMemberMenuDataKey();

    // CaseHeader manipulation variables
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ListICMemberProductDeliveryKey listICMemberProductDeliveryKey = new ListICMemberProductDeliveryKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey_eo = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey_eo.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey_eo);

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey_eo.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey_eo);

    // get the case's parent case ID - the Integrated case ID
    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      listICMemberProductDeliveryKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      listICMemberProductDeliveryKey.caseID = integratedCaseKey.integratedCaseID;
    }

    // Assign concernRoleID details to the listICMemberTaskDetails
    // structure
    icMemberMenuDataKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Set key to retrieve list of member notes
    listICMemberProductDeliveryKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Assign key details
    casesByConcernAndICKey.assign(listICMemberProductDeliveryKey);

    // Read details and copy to return object
    // BEGIN, CR00104037, ZV
    final CaseHeaderConcernRoleDetailsList caseHeaderConcernRoleDetailsList = maintainCaseObj
        .getCasesByConcernAndCaseID(casesByConcernAndICKey);

    for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

      if (caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode
          .equals(CASETYPECODE.PRODUCTDELIVERY)) {

        final ICMemberProductDeliveryDetails icMemberProductDeliveryDetails = new ICMemberProductDeliveryDetails();

        icMemberProductDeliveryDetails
            .assign(caseHeaderConcernRoleDetailsList.dtls.item(i));

        listICMemberProductDeliveryDetails.dtls
            .addRef(icMemberProductDeliveryDetails);
      }

    }
    // END, CR00104037

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = listICMemberProductDeliveryKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = listICMemberProductDeliveryKey.concernRoleID;

    // Read context description
    listICMemberProductDeliveryDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // Set key to read menu data
    icMemberMenuDataKey.caseID = listICMemberProductDeliveryKey.caseID;

    icMemberMenuDataKey.concernRoleID = listICMemberProductDeliveryKey.concernRoleID;

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listICMemberProductDeliveryDetails.memberMenuData = getICMemberMenuData(
        caseParticipantRoleKey);
    return listICMemberProductDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDetails listProduct(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryDetails listICProductDeliveryDetails = new ListICProductDeliveryDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    final CasesByCaseIDAndTypeKey casesByCaseIDAndTypeKey = new CasesByCaseIDAndTypeKey();
    final CasesByCaseIDConcernAndTypeKey casesByCaseIDConcernAndTypeKey = new CasesByCaseIDConcernAndTypeKey();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Create a ICMemberContextDescriptionKey object
    // and read the context description into the return object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // ICMemberMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();

    final curam.core.sl.entity.struct.CaseIDParticipantRoleKey caseIDParticipantRoleKey = new curam.core.sl.entity.struct.CaseIDParticipantRoleKey();

    curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID = new curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID();

    if (key.concernRoleID == 0 && key.caseID != 0) {

      // Assign key details
      casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
      casesByCaseIDAndTypeKey.dtls.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

      // Copy details to return object
      caseAndConcernSummaryDtlsList = maintainCaseObj
          .listCasesByTypeAndParentCaseID(casesByCaseIDAndTypeKey);

    } else {

      // Assign key details
      casesByCaseIDConcernAndTypeKey.dtls.concernRoleID = key.concernRoleID;
      casesByCaseIDConcernAndTypeKey.dtls.caseID = key.caseID;
      casesByCaseIDConcernAndTypeKey.dtls.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

      // Copy details to return object
      caseAndConcernSummaryDtlsList = maintainCaseObj
          .listCasesByTypeConcernRoleIDAndParentCaseID(
              casesByCaseIDConcernAndTypeKey);

    }

    ICProductDeliveryDetails icProductDeliveryDetails;

    // Reserve space in listICProductDeliveryDetails list
    listICProductDeliveryDetails.dtls
        .ensureCapacity(caseAndConcernSummaryDtlsList.list.dtls.size());

    for (int i = 0; i < caseAndConcernSummaryDtlsList.list.dtls.size(); i++) {

      // Filter products
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      productDeliveryKey.caseID = caseAndConcernSummaryDtlsList.list.dtls
          .item(i).caseID;

      final ProductIDDetails productIDDetails = ProductDeliveryFactory
          .newInstance().readProductID(productDeliveryKey);

      // Read the product
      final ProductKey productKey = new ProductKey();
      productKey.productID = productIDDetails.productID;

      if (productFilter.filter(productKey)) {
        continue;
      }

      icProductDeliveryDetails = new ICProductDeliveryDetails();

      icProductDeliveryDetails
          .assign(caseAndConcernSummaryDtlsList.list.dtls.item(i));

      caseIDParticipantRoleKey.participantRoleID = caseAndConcernSummaryDtlsList.list.dtls
          .item(i).concernRoleID;
      caseIDParticipantRoleKey.caseID = key.caseID;

      // Reads caseParticipantRoleID
      caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
          .readCaseParticipantRoleID(caseIDParticipantRoleKey);

      // Assign caseParticipantRoleID to the return object
      icProductDeliveryDetails.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

      listICProductDeliveryDetails.dtls.addRef(icProductDeliveryDetails);
    }

    for (int i = 0; i < listICProductDeliveryDetails.dtls.size(); i++) {

      concernRoleKey.concernRoleID = listICProductDeliveryDetails.dtls
          .item(0).concernRoleID;
      final ConcernRoleDtls concernRoleDtls = concernRoleObj
          .read(concernRoleKey);

      listICProductDeliveryDetails.dtls
          .item(0).concernRoleType = concernRoleDtls.concernRoleType;

    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICProductDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryAdminCaseRole listProductDeliveryAdminCaseRole(
      final ListICProductDeliveryAdminCaseRoleKey key)
      throws AppException, InformationalException {

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo
        .getInformationalManager();

    // Create return object
    final ListICProductDeliveryAdminCaseRole listICProductDeliveryAdminCaseRole = new ListICProductDeliveryAdminCaseRole();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory
        .newInstance();
    curam.core.sl.struct.CaseUserRoleDetailsList caseUserRoleDetailsList;
    final curam.core.sl.struct.CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new curam.core.sl.struct.CaseUserRoleCaseIDKey();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details
    caseUserRoleCaseIDKey.dtls.caseID = key.caseID;

    // Call CaseUserRole BPO to return the list of Case User Roles
    caseUserRoleDetailsList = caseUserRoleObj
        .listCaseUserRoles(caseUserRoleCaseIDKey);

    // BEGIN, CR00205193, SS
    final int listSize = caseUserRoleDetailsList.dtls.size();

    listICProductDeliveryAdminCaseRole.caseUserRoleDetailsList
        .ensureCapacity(listSize);

    // BEGIN, CR00216640, GSP
    // retrieve environment variable
    final String dispWorkQueueAsOwnerInCaseUserRole = Configuration
        .getProperty(EnvVars.ENV_DISPLAYTEMPWORKQUEUEASOWNERINCASEUSERROLE);

    for (final curam.core.sl.struct.CaseUserRoleDetails caseUserRoleDetails : caseUserRoleDetailsList.dtls
        .items()) {

      if (!(CuramConst.kTemporaryOwnerWorkqueueName.equalsIgnoreCase(
          caseUserRoleDetails.dtls.ownerDetails.orgObjectReferenceName)
          && dispWorkQueueAsOwnerInCaseUserRole
              .equalsIgnoreCase(EnvVars.ENV_VALUE_NO))) {

        listICProductDeliveryAdminCaseRole.caseUserRoleDetailsList
            .addRef(caseUserRoleDetails.dtls);
      }
    }
    // END, CR00216640
    // END, CR00205193

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryAdminCaseRole.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryAdminCaseRole.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    // BEGIN, CR00075853, MG
    // retrieve any informational messages
    final String[] warnings = informationalManager
        .obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listICProductDeliveryAdminCaseRole.informationalMsgDtlsList.dtls
          .addRef(informationalMsgDtls);
    }
    // END, CR00075853

    return listICProductDeliveryAdminCaseRole;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryCaseRelationship listProductDeliveryCaseRelationship(
      final ListICProductDeliveryCaseRelationshipKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryCaseRelationship listICProductDeliveryCaseRelationship = new ListICProductDeliveryCaseRelationship();

    // MaintainRelatedCases manipulation variables
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory
        .newInstance();
    final GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details to retrieve list of related cases
    getRelatedCasesKey.assign(key);

    // Call MaintainRelatedCases BPO to retrieve the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj
        .getRelatedCases(getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryCaseRelationship.dtls
          .ensureCapacity(getRelatedCasesList.dtls.size());

      // CaseHeader object
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      final CaseKey caseKey = new CaseKey();
      CaseTypeCode caseTypeCode = new CaseTypeCode();
      final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();

      for (int i = 0; i < getRelatedCasesList.dtls.size(); i++) {

        caseKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

        caseIDAndTypeCodeKey.caseID = getRelatedCasesList.dtls
            .item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        final RelatedCaseProductType relatedCaseProductType = maintainRelatedCasesObj
            .getRelatedCaseProductType(caseIDAndTypeCodeKey);

        getRelatedCasesList.dtls.item(
            i).relatedCaseProductType = relatedCaseProductType.relatedCaseProductType;
        // BEGIN, CR00427963, KRK
        getRelatedCasesList.dtls.item(
            i).relatedCaseNameOpt = relatedCaseProductType.relatedCaseNameOpt;
        // END, CR00427963
      }

      // Assign details to return object
      listICProductDeliveryCaseRelationship.assign(getRelatedCasesList);
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryCaseRelationship.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryCaseRelationship.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryCaseRelationship;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          The certification case identifier.
   *
   * @return A list of certification details.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listProductDeliveryCertification1()}.
   *
   *             Lists the product delivery certification
   */
  @Override
  @Deprecated
  public ListICProductDeliveryCertDetails listProductDeliveryCertification(
      final CertificationCaseIDKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ListICProductDeliveryCertDetails listICProductDeliveryCertDetails = new ListICProductDeliveryCertDetails();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory
        .newInstance();
    final MaintainCertificationCaseIDKey maintainCertificationCaseIDKey = new MaintainCertificationCaseIDKey();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details
    maintainCertificationCaseIDKey.assign(key);

    // Read certifications
    listICProductDeliveryCertDetails.assign(maintainCertificationObj
        .getCertifications(maintainCertificationCaseIDKey));

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryCertDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryCertDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryCertDetails;
  }

  // BEGIN, CR00219840, JF
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryCertDetailsAndVersionNo listProductDeliveryCertificationAndVersionNo(
      final CertificationCaseIDKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ListICProductDeliveryCertDetailsAndVersionNo listICProductDeliveryCertDetailsAndVersionNo = new ListICProductDeliveryCertDetailsAndVersionNo();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory
        .newInstance();
    final MaintainCertificationCaseIDKey maintainCertificationCaseIDKey = new MaintainCertificationCaseIDKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details
    maintainCertificationCaseIDKey.assign(key);

    // Read certifications
    listICProductDeliveryCertDetailsAndVersionNo.assign(maintainCertificationObj
        .getCertificationsAndVersionNo(maintainCertificationCaseIDKey));

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryCertDetailsAndVersionNo.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryCertDetailsAndVersionNo;
  }

  // END, CR00219840, JF

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryClientRoleDetails listProductDeliveryClientRole(
      final ListICProductDeliveryClientRoleKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ListICProductDeliveryClientRoleDetails listICProductDeliveryClientRoleDetails = new ListICProductDeliveryClientRoleDetails();

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Assign key details
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read case participant role details
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseParticipantRoleList(viewCaseParticipantRole_boKey);

    // Reserve space in caseParticipantList
    listICProductDeliveryClientRoleDetails.caseParticipantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      final CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails
          .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

      // Add the integrated case id as part of struct to be returned:
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      caseParticipantRoleFullDetails.parentCaseID = caseHeaderDtls.integratedCaseID;

      listICProductDeliveryClientRoleDetails.caseParticipantList
          .addRef(caseParticipantRoleFullDetails);
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryClientRoleDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryClientRoleDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryClientRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDecision listProductDeliveryDecision(
      final ListICProductDeliveryDecisionKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ListICProductDeliveryDecision listICProductDeliveryDecision = new ListICProductDeliveryDecision();

    // MaintainCaseDecision manipulation variables
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory
        .newInstance();
    final MaintainCaseDecisionCaseIDKey maintainCaseDecisionCaseIDKey = new MaintainCaseDecisionCaseIDKey();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details
    maintainCaseDecisionCaseIDKey.caseID = key.caseID;

    // Read case decisions
    listICProductDeliveryDecision.assign(maintainCaseDecisionObj
        .getCaseDecisions(maintainCaseDecisionCaseIDKey));

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDecision.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDecision.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryDecision;
  }

  // BEGIN, CR00162569, PDN
  // ___________________________________________________________________________
  /**
   * @param key
   *          Case identifier.
   *
   * @return List of the statuses for a product delivery case.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listProductDeliveryStatusHistory1()}.
   *
   *             This process will list the status history of a product delivery
   *             case.
   */
  @Override
  @Deprecated
  public ListICProductDeliveryStatusHistory listProductDeliveryStatusHistory(
      final ListICProductDeliveryStatusHistoryKey key)
      throws AppException, InformationalException {

    final ListICProductDeliveryStatusHistory listICProductDeliveryStatusHistory = new ListICProductDeliveryStatusHistory();

    // BEGIN, CR00220971, ZV
    listICProductDeliveryStatusHistory
        .assign(listProductDeliveryStatusHistory1(key));
    // END, CR00220971

    // Return the status history list
    return listICProductDeliveryStatusHistory;
  }

  // END, CR00150402

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryStatusHistory1 listProductDeliveryStatusHistory1(
      final ListICProductDeliveryStatusHistoryKey key)
      throws AppException, InformationalException {

    final ListICProductDeliveryStatusHistory1 listICProductDeliveryStatusHistory1 = new ListICProductDeliveryStatusHistory1();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory
        .newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();

    // ICMemberContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read case status history details
    caseStatusHistoryKey.caseID = key.caseID;

    // Read case status history details and assign to output object
    listICProductDeliveryStatusHistory1.assign(
        productDeliveryHomeObj.getCaseStatusHistory1(caseStatusHistoryKey));

    // Users manipulation variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Filter list manipulation variables
    final ListICProductDeliveryStatusHistory1 filteredListStatusHistory1 = new ListICProductDeliveryStatusHistory1();

    final boolean showDeferredProc = Configuration
        .getBooleanProperty(EnvVars.ENV_DPDISPLAYINSTATUSHISTORY);

    // Loop through all the status history records and filter out the
    // delayed processing records if the environment variable requests it.
    for (int i = 0; i < listICProductDeliveryStatusHistory1.dtls.size(); i++) {

      // Set the users full name
      usersKey.userName = listICProductDeliveryStatusHistory1.dtls
          .item(i).userName;
      listICProductDeliveryStatusHistory1.dtls.item(i).userFullName = usersObj
          .getFullName(usersKey).fullname;

      // For backward compatibility support, Set the start and end date
      // time to
      // the start and end date if the start and end date times have not
      // been set.
      if (listICProductDeliveryStatusHistory1.dtls.item(i).startDateTime
          .isZero()) {
        listICProductDeliveryStatusHistory1.dtls
            .item(i).startDateTime = new DateTime(
                listICProductDeliveryStatusHistory1.dtls.item(i).startDate
                    .getCalendar());
      }
      if (listICProductDeliveryStatusHistory1.dtls.item(i).endDateTime
          .isZero()) {
        listICProductDeliveryStatusHistory1.dtls
            .item(i).endDateTime = new DateTime(
                listICProductDeliveryStatusHistory1.dtls.item(i).endDate
                    .getCalendar());
      }

      // Only add the details for a delay processing if environment
      // variable
      // permits them
      if (listICProductDeliveryStatusHistory1.dtls.item(i).statusCode
          .equals(curam.codetable.CASESTATUS.DELAYEDPROC) && showDeferredProc) {
        filteredListStatusHistory1.dtls
            .addRef(listICProductDeliveryStatusHistory1.dtls.item(i));
      } else if (!listICProductDeliveryStatusHistory1.dtls.item(i).statusCode
          .equals(curam.codetable.CASESTATUS.DELAYEDPROC)) {
        filteredListStatusHistory1.dtls
            .addRef(listICProductDeliveryStatusHistory1.dtls.item(i));
      }

    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    filteredListStatusHistory1.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    filteredListStatusHistory1.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    // Return the status history list
    return filteredListStatusHistory1;
  }

  // END, CR00162569

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryTaskDetails listProductDeliveryTask(
      final ListICProductDeliveryTaskKey_eo key)
      throws AppException, InformationalException {

    // create return object
    final ListICProductDeliveryTaskDetails listICProductDeliveryTaskDetails = new ListICProductDeliveryTaskDetails();

    // Task manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory
        .newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();
    CaseAndConcernLinkedTaskDtls caseAndConcernLinkedTaskDtls;

    // ICMemberContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // set key to read the list of tasks
    searchTaskForConcernOrCaseKey.details.linkedID = key.caseTasksKey.caseID;

    // Get list of case tasks
    caseAndConcernLinkedTaskDtls = workAllocationTaskObj
        .listCaseTasks(searchTaskForConcernOrCaseKey);

    // assign list to output structure
    listICProductDeliveryTaskDetails.detailsList
        .assign(caseAndConcernLinkedTaskDtls.dtls);

    // Iterate through the list and set reservedByExistsInd to true
    for (int i = 0; i < listICProductDeliveryTaskDetails.detailsList.dtls
        .size(); i++) {

      if (listICProductDeliveryTaskDetails.detailsList.dtls.item(i).reservedBy
          .length() > 0) {

        listICProductDeliveryTaskDetails.detailsList.dtls
            .item(i).reservedByExistsInd = true;
      }
    }

    // set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseTasksKey.caseID;

    // read context description
    listICProductDeliveryTaskDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseTasksKey.caseID;

    // read menu data
    listICProductDeliveryTaskDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICTaskDetails listTask(final ListICTaskKey_eo key)
      throws AppException, InformationalException {

    // create return object
    final ListICTaskDetails listICTaskDetails = new ListICTaskDetails();

    // Task manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory
        .newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();
    CaseAndConcernLinkedTaskDtls caseAndConcernLinkedTaskDtls;

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // set key to read the list of tasks
    searchTaskForConcernOrCaseKey.details.linkedID = key.caseTasksKey.caseID;

    // Get list of case tasks
    caseAndConcernLinkedTaskDtls = workAllocationTaskObj
        .listCaseTasks(searchTaskForConcernOrCaseKey);

    // assign list to output structure
    listICTaskDetails.detailsList.assign(caseAndConcernLinkedTaskDtls.dtls);

    // Iterate through the list and set reservedByExistsInd to true
    for (int i = 0; i < listICTaskDetails.detailsList.dtls.size(); i++) {

      if (listICTaskDetails.detailsList.dtls.item(i).reservedBy.length() > 0) {

        listICTaskDetails.detailsList.dtls.item(i).reservedByExistsInd = true;
      }
    }

    // set key to read context description
    icContextDescriptionKey.caseID = key.caseTasksKey.caseID;

    // read context description and assign to return object
    listICTaskDetails.context = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseTasksKey.caseID;

    // read menu data and assign to return object
    listICTaskDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public curam.core.facade.struct.MemberHomePageName resolveMemberHome(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final curam.core.facade.struct.MemberHomePageName memberHomePageName = new curam.core.facade.struct.MemberHomePageName();

    // MaintainAdminIntegratedCase manipulation variable
    final curam.core.intf.MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj = curam.core.fact.MaintainAdminIntegratedCaseFactory
        .newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Assign key to read member home page name
    caseKey.caseID = key.caseID;

    // Call MaintainAdminIntegratedCase BPO to read member home page name
    // and assign to return object
    memberHomePageName
        .assign(maintainAdminIntegratedCaseObj.readMemberHomePageName(caseKey));

    return memberHomePageName;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICCaseRelationshipDetails listCaseRelationship(
      final ListICCaseRelationshipKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICCaseRelationshipDetails listICCaseRelationshipDetails = new ListICCaseRelationshipDetails();

    // MaintainRelatedCases manipulation variables
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory
        .newInstance();
    final GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // CaseHeader object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    CaseKey caseKey;
    CaseTypeCode caseTypeCode = new CaseTypeCode();
    final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();
    RelatedCaseProductType relatedCaseProductType;

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read the related cases
    getRelatedCasesKey.assign(key);

    // Call MaintainRelatedCases BPO to retrieve the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj
        .getRelatedCases(getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICCaseRelationshipDetails.dtls
          .ensureCapacity(getRelatedCasesList.dtls.size());

      // Assign details to return object
      listICCaseRelationshipDetails.assign(getRelatedCasesList);

      for (int i = 0; i < getRelatedCasesList.dtls.size(); i++) {

        caseKey = new CaseKey();
        caseKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

        caseIDAndTypeCodeKey.caseID = getRelatedCasesList.dtls
            .item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        relatedCaseProductType = maintainRelatedCasesObj
            .getRelatedCaseProductType(caseIDAndTypeCodeKey);

        listICCaseRelationshipDetails.dtls.item(
            i).relatedCaseProductTypeCode = relatedCaseProductType.relatedCaseProductType;
        // BEGIN, CR00427963, KRK
        listICCaseRelationshipDetails.dtls.item(
            i).relatedCaseNameOpt = relatedCaseProductType.relatedCaseNameOpt;
        // END, CR00427963
      }
    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICCaseRelationshipDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICCaseRelationshipDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICCaseRelationshipDetails;
  }

  // ___________________________________________________________________________
  /**
   * This process will create an integrated case.
   *
   * @param details
   *          Details of the integrated case being created.
   *
   * @return Returns the case identifier and home page name.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   *             {@link IntegratedCase#createIntegratedCase1()}.
   */
  @Override
  @Deprecated
  public CreateIntegratedCaseResult createIntegratedCase(
      final CreateIntegratedCaseDetails details)
      throws AppException, InformationalException {

    // Create return object
    final CreateIntegratedCaseResult createIntegratedCaseResult = new CreateIntegratedCaseResult();

    // IntegratedCase manipulation variables
    final curam.core.intf.IntegratedCase integratedCaseObj = curam.core.fact.IntegratedCaseFactory
        .newInstance();
    final IntegratedCaseRegistrationDetails integratedCaseRegistrationDetails = new IntegratedCaseRegistrationDetails();

    curam.core.struct.IntegratedCaseIDKey integratedCaseIDKey;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    ICHomePageName icHomePageName;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Assign details
    integratedCaseRegistrationDetails.assign(details);

    // Assign primaryClientID to caseClientList. This list is used to create
    // the Concern Case Roles inside the IntegratedCase BPO
    integratedCaseRegistrationDetails.caseClientList = String
        .valueOf(details.primaryClientID);

    // Call IntegratedCase BPO to create the integrated case
    integratedCaseIDKey = integratedCaseObj
        .createIntegratedCase(integratedCaseRegistrationDetails);

    // Set key to read Integrated Case Home Page Name
    caseKey.caseID = integratedCaseIDKey.caseID;

    // Read Integrated Case Home Page Name
    icHomePageName = caseHeaderObj.readICHomePageName(caseKey);

    // Map caseID and homePageName to return object
    createIntegratedCaseResult.integratedCaseID = integratedCaseIDKey.caseID;
    createIntegratedCaseResult.homePageName = icHomePageName.homePageName;

    return createIntegratedCaseResult;
  }

  // BEGIN, CR00205110, PB
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  // BEGIN, CR00409050, SG
  @AccessLevel(AccessLevelType.EXTERNAL)
  // END, CR00409050
  public CreateIntegratedCaseResult createIntegratedCase1(
      final CreateIntegratedCaseDetails1 details)
      throws AppException, InformationalException {

    // Create return object
    final CreateIntegratedCaseResult createIntegratedCaseResult = new CreateIntegratedCaseResult();

    // IntegratedCase manipulation variables
    final curam.core.intf.IntegratedCase integratedCaseObj = curam.core.fact.IntegratedCaseFactory
        .newInstance();
    final IntegratedCaseRegistrationDetails1 integratedCaseRegistrationDetails1 = new IntegratedCaseRegistrationDetails1();

    IntegratedCaseIDKey integratedCaseIDKey;

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICHomePageName icHomePageName;
    final CaseKey caseKey = new CaseKey();

    // Assign details
    integratedCaseRegistrationDetails1.assign(details);

    // Assign primaryClientID to caseClientList. This list is used to create
    // the Concern Case Roles inside the IntegratedCase BPO
    integratedCaseRegistrationDetails1.caseClientList = String
        .valueOf(details.primaryClientID);

    // Call IntegratedCase BPO to create the integrated case
    integratedCaseIDKey = integratedCaseObj
        .createIntegratedCase1(integratedCaseRegistrationDetails1);

    // Set key to read Integrated Case Home Page Name
    caseKey.caseID = integratedCaseIDKey.caseID;

    // Read Integrated Case Home Page Name
    icHomePageName = caseHeaderObj.readICHomePageName(caseKey);

    // Map caseID and homePageName to return object
    createIntegratedCaseResult.integratedCaseID = integratedCaseIDKey.caseID;
    createIntegratedCaseResult.homePageName = icHomePageName.homePageName;

    return createIntegratedCaseResult;
  }

  // END, CR00205110
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryOverUnderPaymentDetails listProductDeliveryOverUnderPayment(
      final ListICProductDeliveryOverUnderPaymentKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryOverUnderPaymentDetails listICProductDeliveryOverUnderPaymentDetails = new ListICProductDeliveryOverUnderPaymentDetails();

    // ViewOverUnderPaymentResult manipulation variable
    final curam.core.intf.ViewOverUnderPaymentResult viewOverUnderPaymentResultObj = curam.core.fact.ViewOverUnderPaymentResultFactory
        .newInstance();

    // ICMemberContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Read the over under payment details into the return object
    listICProductDeliveryOverUnderPaymentDetails.getAllOverUnderPaymentsResult = viewOverUnderPaymentResultObj
        .getAllOverUnderPayments(key.getAllOverUnderPaymentsIn);

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.getAllOverUnderPaymentsIn.caseID;

    // Read context description
    listICProductDeliveryOverUnderPaymentDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.getAllOverUnderPaymentsIn.caseID;

    // Read menu data
    listICProductDeliveryOverUnderPaymentDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    // Return the over and under payment details
    return listICProductDeliveryOverUnderPaymentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyCaseDetails(final ModifyIntegratedCaseDetails details)
      throws AppException, InformationalException {

    // IntegratedCaseHome manipulation variables
    final curam.core.intf.IntegratedCaseHome integratedCaseHomeObj = curam.core.fact.IntegratedCaseHomeFactory
        .newInstance();

    final ModifyICFurtherDtls modifyICFurtherDtls = new ModifyICFurtherDtls();

    // Assign details to modify the case
    modifyICFurtherDtls.assign(details);

    // Call IntegratedCase BPO to modify the case details
    integratedCaseHomeObj.modifyIntegratedCaseDetails(modifyICFurtherDtls);

  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Case identifier.
   *
   * @return Integrated case details.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #readCaseDetails1()}.
   *
   *             This process will read an integrated case.
   */
  @Override
  @Deprecated
  public ReadIntegratedCaseDetails readCaseDetails(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadIntegratedCaseDetails readIntegratedCaseDetails = new ReadIntegratedCaseDetails();

    // BEGIN, CR00220971, ZV
    final ReadIntegratedCaseDetails1 readIntegratedCaseDetails1 = readCaseDetails1(
        key);

    readIntegratedCaseDetails.assign(readIntegratedCaseDetails1);
    // END, CR00220971

    return readIntegratedCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void addTaskToContract(
      final curam.core.facade.struct.AddTaskToContractKey key)
      throws AppException, InformationalException {

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final curam.core.struct.AddTaskToContractKey addTaskToContractKey = new curam.core.struct.AddTaskToContractKey();

    // Set key to add task to contract
    addTaskToContractKey.caseContractID = key.caseContractID;
    addTaskToContractKey.caseContractTaskList = key.caseContractTaskList;

    // Call MaintainCaseContract BPO to add the task(s) to the contract
    maintainCaseContractObj.addTaskToContract(addTaskToContractKey);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelContract(final CancelContractKey key)
      throws AppException, InformationalException {

    // MaintainContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final CancelCaseContractKey cancelCaseContractKey = new CancelCaseContractKey();

    // Set key to cancel the case contract
    cancelCaseContractKey.caseContractID = key.cancelContractDetailsKey.contractID;
    cancelCaseContractKey.versionNo = key.cancelContractDetailsKey.versionNo;

    // Call MaintainContract BPO to cancel the contract
    maintainCaseContractObj.cancelCaseContract(cancelCaseContractKey);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void closeCase(final ICClosureDetails key)
      throws AppException, InformationalException {

    // IntegratedCase manipulation variables
    final curam.core.intf.IntegratedCase integratedCaseObj = curam.core.fact.IntegratedCaseFactory
        .newInstance();
    final ICClosureDtls icClosureDtls = new ICClosureDtls();

    // Assign details to close the case
    icClosureDtls.assign(key);

    // Call IntegratedCase BPO to close the case
    integratedCaseObj.closeIntegratedCase(icClosureDtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam 6.0 SP4, replaced by
   *             {@link IntegratedCase# listContractDetails(ListContractKey listContractKey)}
   *             . Retrieves a list of contracts including version number. See
   *             release note :CR00320920.
   */
  @Override
  @Deprecated
  public ListContractDetails listContract(final ListContractKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListContractDetails listContractDetails = new ListContractDetails();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    ReadAllCaseContractsDtlsList readAllCaseContractsDtlsList;
    final CaseContractCaseIDKey caseContractCaseIDKey = new CaseContractCaseIDKey();

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID = new CaseParticipantRole_eoCaseParticipantRoleID();

    // ICContextDescriptionKey struct
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Assign key to read contracts list
    caseContractCaseIDKey.assign(key);

    // Call MaintainCaseContract BPO to retrieve the list of contracts
    // on the Integrated Case
    readAllCaseContractsDtlsList = maintainCaseContractObj
        .readAllCaseContracts(caseContractCaseIDKey);

    // Reserve space in the return object
    listContractDetails.contractDetailsList.dtls
        .ensureCapacity(readAllCaseContractsDtlsList.dtls.size());

    // Assign list details to return object
    listContractDetails.contractDetailsList
        .assign(readAllCaseContractsDtlsList);

    for (int i = 0; i < listContractDetails.contractDetailsList.dtls
        .size(); i++) {

      concernRoleKey.concernRoleID = listContractDetails.contractDetailsList.dtls
          .item(0).concernRoleID;
      final ConcernRoleDtls concernRoleDtls = concernRoleObj
          .read(concernRoleKey);

      listContractDetails.contractDetailsList.dtls
          .item(0).concernRoleType = concernRoleDtls.concernRoleType;

      caseIDParticipantRoleKey.participantRoleID = listContractDetails.contractDetailsList.dtls
          .item(i).concernRoleID;
      caseIDParticipantRoleKey.caseID = key.caseID;

      // Reads caseParticipantRoleID
      caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
          .readCaseParticipantRoleID(caseIDParticipantRoleKey);

      // Assign caseParticipantRoleID to the return object
      listContractDetails.contractDetailsList.dtls.item(
          i).caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;
    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listContractDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listContractDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListTasksDueDuringContractPeriod listTasksDueDuringContractPeriod(
      final ListTasksDueKey key) throws AppException, InformationalException {

    // Create return object
    final ListTasksDueDuringContractPeriod listTasksDueDuringPeriod = new ListTasksDueDuringContractPeriod();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    CaseContractTaskDetailsList caseContractTaskDetailsList;
    final ReadCaseContractTasksKey readCaseContractTasksKey = new ReadCaseContractTasksKey();

    // CaseContract manipulation variables
    final curam.core.intf.CaseContract caseContractObj = curam.core.fact.CaseContractFactory
        .newInstance();
    final CaseContractKey caseContractKey = new CaseContractKey();
    CaseContractDtls caseContractDtls;

    // Set key to read CaseContract entity
    caseContractKey.caseContractID = key.caseContractID;

    // Read caseContract entity
    caseContractDtls = caseContractObj.read(caseContractKey);

    // Set key details to retrieve the list of tasks due
    readCaseContractTasksKey.assign(caseContractDtls);
    readCaseContractTasksKey.caseContractID = key.caseContractID;

    // Set status to 'Closed' to ensure that all except closed tasks will
    // be returned

    readCaseContractTasksKey.status = curam.codetable.TASKSTATUS.CLOSED;

    // Call MaintainCaseContract BPO to retrieve the list of tasks due
    caseContractTaskDetailsList = maintainCaseContractObj
        .readCaseContractTasks(readCaseContractTasksKey);

    // Reserve space in the return object
    listTasksDueDuringPeriod.dtls
        .ensureCapacity(caseContractTaskDetailsList.dtls.size());

    // Assign list to return object
    listTasksDueDuringPeriod.assign(caseContractTaskDetailsList);

    return listTasksDueDuringPeriod;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyContract(final ModifyContractDetails details)
      throws AppException, InformationalException {

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final curam.core.struct.CaseContractDetails caseContractDetails = new curam.core.struct.CaseContractDetails();
    final MaintainCaseContractKey maintainCaseContractKey = new MaintainCaseContractKey();

    // Assign key details to modify contract
    maintainCaseContractKey.caseContractID = details.caseContractID;

    // Assign details to modify the contract
    caseContractDetails.assign(details);

    // Call MaintainCaseContract BPO to modify the contract details
    maintainCaseContractObj.modifyCaseContractDetails(maintainCaseContractKey,
        caseContractDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadContractDetails readContractDetails(final ReadCaseContractKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadContractDetails readContractDetails = new ReadContractDetails();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    ReadCaseContractDetailsResult readCaseContractDetailsResult;
    final ReadCaseContractDetailsKey readCaseContractDetailsKey = new ReadCaseContractDetailsKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();

    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID = new CaseParticipantRole_eoCaseParticipantRoleID();

    // Assign key details to read contract details
    readCaseContractDetailsKey.caseContractID = key.caseContractID;

    // Call MaintainCaseContract BPO to read contract details
    readCaseContractDetailsResult = maintainCaseContractObj
        .readCaseContractDetails(readCaseContractDetailsKey);

    // Assign details to output object
    readContractDetails.contractDetails
        .assign(readCaseContractDetailsResult.dtls);

    caseIDParticipantRoleKey.participantRoleID = readContractDetails.contractDetails.concernRoleID;
    caseIDParticipantRoleKey.caseID = readContractDetails.contractDetails.caseID;

    // Reads caseParticipantRoleID
    caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
        .readCaseParticipantRoleID(caseIDParticipantRoleKey);

    // Assign caseParticipantRoleID to the return object
    readContractDetails.contractDetails.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    readContractDetails.taskList.assign(readCaseContractDetailsResult.taskList);

    return readContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void removeTaskFromContract(
      final curam.core.facade.struct.RemoveTaskFromContractKey key)
      throws AppException, InformationalException {

    // CaseContractContents manipulation variables
    final curam.core.intf.CaseContractContents caseContractContentsObj = curam.core.fact.CaseContractContentsFactory
        .newInstance();
    final curam.core.struct.RemoveTaskFromContractKey removeTaskFromContractKey = new curam.core.struct.RemoveTaskFromContractKey();

    // Assign key details to remove the task from the contract
    removeTaskFromContractKey.assign(key);

    // Call operation to remove the task from the contract
    caseContractContentsObj.removeTaskFromContract(removeTaskFromContractKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberAndContractTemplateDetails listMemberAndContractTemplate(
      final ListMemberAndContractTemplateKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberAndContractTemplateDetails listMemberAndContractTemplateDetails = new ListMemberAndContractTemplateDetails();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final SearchTemplatesByTypeKey searchTemplatesByTypeKey = new SearchTemplatesByTypeKey();

    final ListMemberDetailsKey listMemberDetailsKey = new ListMemberDetailsKey();

    listMemberDetailsKey.caseID = key.caseID;

    // Need to call local function listCaseMembers in order to
    // retrieve the list of case member details

    final ListICClientKey listICClientKey = new ListICClientKey();

    listICClientKey.caseID = key.caseID;

    // BEGIN, CR00225060, ZV
    final ListICClientRoleDetails1 listICClientRoleDetails = listCaseMembers1(
        listICClientKey);

    // END, CR00225060

    // Reserve space in participantList
    listMemberAndContractTemplateDetails.memberDetailsList.memberDetailsList.dtls
        .ensureCapacity(listICClientRoleDetails.participantList.size());

    for (int i = 0; i < listICClientRoleDetails.participantList.size(); i++) {

      final MemberDetails memberDetails = new MemberDetails();

      // Call listMemberDetails and assign list returned to output object

      memberDetails.assign(listICClientRoleDetails.participantList.item(i));

      listMemberAndContractTemplateDetails.memberDetailsList.memberDetailsList.dtls
          .addRef(memberDetails);
    }

    // Assign key details to retrieve contract template details
    // The templateType is set to 'CaseContract'
    searchTemplatesByTypeKey.caseID = key.caseID;
    // BEGIN, CR00163097, JMA
    searchTemplatesByTypeKey.templateType = XSLTEMPLATETYPE.CASECONTRACT;
    // END, CR00163097

    // Call MaintainCaseContract BPO to retrieve the contract template
    // details and assign list returned to output object
    listMemberAndContractTemplateDetails.contractTemplateList
        .assign(maintainCaseContractObj
            .searchTemplatesByType(searchTemplatesByTypeKey));

    return listMemberAndContractTemplateDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberAndContractTemplateDetails listMemberContractDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberAndContractTemplateDetails listMemberAndContractTemplateDetails = new ListMemberAndContractTemplateDetails();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final SearchTemplatesByTypeKey searchTemplatesByTypeKey = new SearchTemplatesByTypeKey();

    // IntegratedCase manipulation variables
    final ListMemberDetailsKey listMemberDetailsKey = new ListMemberDetailsKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ListMemberAndContractTemplateKey listMemberAndContractTemplateKey = new ListMemberAndContractTemplateKey();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID details to the listMemberAndContractTemplateKey
    // structure

    listMemberAndContractTemplateKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Need to call local function listCaseParticipantsDetails in order to
    // retrieve the list of case member details
    // Set key to call local method listMemberDetails
    listMemberDetailsKey.caseID = listMemberAndContractTemplateKey.caseID;

    // Call listMemberDetails and assign list returned to output object
    listMemberAndContractTemplateDetails.memberDetailsList
        .assign(listCaseParticipantsDetails(listMemberDetailsKey));

    // Assign key details to retrieve contract template details
    // The templateType is set to 'CaseContract'
    searchTemplatesByTypeKey.caseID = listMemberAndContractTemplateKey.caseID;
    // BEGIN, CR00163097, JMA
    searchTemplatesByTypeKey.templateType = XSLTEMPLATETYPE.CASECONTRACT;
    // END, CR00163097

    // Call MaintainCaseContract BPO to retrieve the contract template
    // details and assign list returned to output object
    listMemberAndContractTemplateDetails.contractTemplateList
        .assign(maintainCaseContractObj
            .searchTemplatesByType(searchTemplatesByTypeKey));

    return listMemberAndContractTemplateDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listMemberDetails(final ListMemberDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    // IntegratedCase manipulation variables
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

    CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    MemberDetails memberDetails;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseParticipantRoleList(viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    // Set the return object
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails
          .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

      listICClientRoleDetails.participantList
          .addRef(caseParticipantRoleFullDetails);
    }

    // BEGIN, CR00153597, DJ
    final int numRecords = listICClientRoleDetails.participantList.size();

    listMemberDetails.memberDetailsList.dtls
        .ensureCapacity(listICClientRoleDetails.participantList.size());

    for (int i = 0; i < numRecords; i++) {

      boolean notDuplicate = true;

      for (int j = 0; j < listMemberDetails.memberDetailsList.dtls
          .size(); j++) {

        if (listICClientRoleDetails.participantList.item(
            i).participantRoleID == listMemberDetails.memberDetailsList.dtls
                .item(j).participantRoleID) {
          notDuplicate = false;
          break;
        }
      }

      if (notDuplicate
          && !listICClientRoleDetails.participantList.item(i).recordStatus
              .equals(curam.codetable.RECORDSTATUS.CANCELLED)) {

        memberDetails = new MemberDetails();

        caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

        caseParticipantRoleFullDetails.participantRoleID = listICClientRoleDetails.participantList
            .item(i).participantRoleID;
        caseParticipantRoleFullDetails.name = listICClientRoleDetails.participantList
            .item(i).name;
        // BEGIN CR00446316, YF
        caseParticipantRoleFullDetails.nameAndAgeOpt = listICClientRoleDetails.participantList
            .item(i).nameAndAgeOpt;
        // BEGIN CR00446316, YF
        caseParticipantRoleFullDetails.caseParticipantRoleID = listICClientRoleDetails.participantList
            .item(i).caseParticipantRoleID;
        memberDetails.assign(caseParticipantRoleFullDetails);

        // Add to return object
        listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
      }

    }
    // END, CR00153597
    return listMemberDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CreateContractKey createContract(final CreateContractDetails details)
      throws AppException, InformationalException {

    // Create return object
    final CreateContractKey createContractKey = new CreateContractKey();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final curam.core.struct.CaseContractDetails caseContractDetails = new curam.core.struct.CaseContractDetails();

    CreateCaseContractResult createCaseContractResult;

    // Assign details to create the contract
    caseContractDetails.assign(details);

    // XSLTemplateUtility manipulation variables
    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory
        .newInstance();
    final curam.util.xml.struct.XSLTemplateNameKey xslTemplateNameKey = new curam.util.xml.struct.XSLTemplateNameKey();
    XSLTemplateInstDetails xslTemplateInstDetails;

    // Set key to read latest template by name
    xslTemplateNameKey.templateName = caseContractDetails.contractType;
    xslTemplateNameKey.localeIdentifier = TransactionInfo.getProgramLocale();
    // Read template by name
    xslTemplateInstDetails = xslTemplateUtilityObj
        .getLatestTemplateByName(xslTemplateNameKey);

    // Map templateID to caseContractDetails to create the contract
    caseContractDetails.documentID = xslTemplateInstDetails.templateID;
    caseContractDetails.documentVersionNo = xslTemplateInstDetails.templateVersion;

    // Call MaintainCaseContract BPO to create the contract on the case
    createCaseContractResult = maintainCaseContractObj
        .createCaseContract(caseContractDetails);

    // Assign key to return object
    createContractKey.contractID = createCaseContractResult.key.caseContractID;

    return createContractKey;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CreateContractKey createMemberContract(
      final CreateContractDetails details)
      throws AppException, InformationalException {

    // Create return object
    final CreateContractKey createContractKey = new CreateContractKey();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    final curam.core.struct.CaseContractDetails caseContractDetails = new curam.core.struct.CaseContractDetails();

    CreateCaseContractResult createCaseContractResult;

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // BEGIN, CR00102331, PMD
    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // END, CR00102331

    // Read caseID and participantID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = details.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // BEGIN, CR00102331, PMD
    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the details struct
    if (integratedCaseKey.integratedCaseID == 0) {

      details.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      details.caseID = integratedCaseKey.integratedCaseID;
    }
    // END, CR00102331

    details.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Assign details to create the contract
    caseContractDetails.assign(details);

    // XSLTemplateUtility manipulation variables
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory
        .newInstance();
    final XSLTemplateNameKey xslTemplateNameKey = new XSLTemplateNameKey();
    XSLTemplateInstDetails xslTemplateInstDetails;

    // Set key to read latest template by name
    xslTemplateNameKey.templateName = caseContractDetails.contractType;
    xslTemplateNameKey.localeIdentifier = TransactionInfo.getProgramLocale();
    // Read template by name
    xslTemplateInstDetails = xslTemplateUtilityObj
        .getLatestTemplateByName(xslTemplateNameKey);

    // Map templateID to caseContractDetails to create the contract
    caseContractDetails.documentID = xslTemplateInstDetails.templateID;

    caseContractDetails.documentVersionNo = xslTemplateInstDetails.templateVersion;

    // Call MaintainCaseContract BPO to create the contract on the case
    createCaseContractResult = maintainCaseContractObj
        .createCaseContract(caseContractDetails);

    // Assign key to return object
    createContractKey.contractID = createCaseContractResult.key.caseContractID;

    return createContractKey;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ResolveHomePageDetails resolveCaseHome(final ResolveHomePageKey key)
      throws AppException, InformationalException {

    // Create return object
    final ResolveHomePageDetails resolveHomePageDetails = new ResolveHomePageDetails();

    // MaintainAdminIntegratedCase manipulation variables
    final curam.core.intf.MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj = curam.core.fact.MaintainAdminIntegratedCaseFactory
        .newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set key to read case home page name
    caseKey.caseID = key.caseID;

    // Call MaintainAdminIntegratedCase BPO to read the case home page name
    // and assign to return object
    resolveHomePageDetails
        .assign(maintainAdminIntegratedCaseObj.readCaseHomePageName(caseKey));

    return resolveHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberActivityDetails listMemberActivity(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberActivityDetails listMemberActivityDetails = new ListMemberActivityDetails();

    // MaintainIntegratedCases manipulation variables
    final curam.core.intf.MaintainIntegratedCases maintainIntegratedCasesObj = curam.core.fact.MaintainIntegratedCasesFactory
        .newInstance();
    final IntegClientCaseActivityKey integClientCaseActivityKey = new IntegClientCaseActivityKey();
    IntegClientCaseActivityList integClientCaseActivityList;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    final ListMemberActivityKey listMemberActivityKey = new ListMemberActivityKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      listMemberActivityKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      listMemberActivityKey.caseID = integratedCaseKey.integratedCaseID;
    }

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    listMemberActivityKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Set key to read activity details
    integClientCaseActivityKey.assign(listMemberActivityKey);

    // Call MaintainIntegratedCases BPO to retrieve the list of activities
    // for the case member
    integClientCaseActivityList = maintainIntegratedCasesObj
        .readAllICClientActivities(integClientCaseActivityKey);

    // Reserve space in the output object
    listMemberActivityDetails.memberActivityDetailsList.dtls
        .ensureCapacity(integClientCaseActivityList.dtls.size());

    // Assign details to return object
    listMemberActivityDetails.memberActivityDetailsList
        .assign(integClientCaseActivityList);

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = listMemberActivityKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = listMemberActivityKey.concernRoleID;

    // Read context description and assign to return object
    listMemberActivityDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listMemberActivityDetails.menuData = getICMemberMenuData(
        caseParticipantRoleKey);

    return listMemberActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberContractDetails listMemberContract(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberContractDetails listMemberContractDetails = new ListMemberContractDetails();

    // MaintainCaseContract manipulation variables
    final curam.core.intf.MaintainCaseContract maintainCaseContractObj = curam.core.fact.MaintainCaseContractFactory
        .newInstance();
    ReadAllCaseContractsDtlsList readAllCaseContractsDtlsList;
    final ReadClientCaseContractsKey readClientCaseContractsKey = new ReadClientCaseContractsKey();

    // ICMemberContextDescriptionKey struct
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ListMemberContractKey listMemberContractKey = new ListMemberContractKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // BEGIN, CR00102331, PMD
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Read the integrated case and participant details
    final ReadIntegratedCaseIDAndParticipantDetails readIntegratedCaseIDAndParticipantDetails = caseHeaderObj
        .readIntegratedCaseIDAndParticipantDetails(caseHeaderKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    if (readIntegratedCaseIDAndParticipantDetails.integratedCaseID != 0) {

      listMemberContractKey.caseID = readIntegratedCaseIDAndParticipantDetails.integratedCaseID;
      listMemberContractKey.concernRoleID = readIntegratedCaseIDAndParticipantDetails.concernRoleID;
    } else {

      listMemberContractKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
      listMemberContractKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;
    }
    // END, CR00102331

    // Set key to read member case contracts
    readClientCaseContractsKey.assign(listMemberContractKey);

    // Call MaintainCaseContract BPO to retrieve member contracts
    readAllCaseContractsDtlsList = maintainCaseContractObj
        .readClientCaseContracts(readClientCaseContractsKey);

    // Reserve space in output object
    listMemberContractDetails.contractDetailsList.dtls
        .ensureCapacity(readAllCaseContractsDtlsList.dtls.size());

    // Assign contracts list to return object
    listMemberContractDetails.contractDetailsList
        .assign(readAllCaseContractsDtlsList);

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = listMemberContractKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = listMemberContractKey.concernRoleID;

    // Read context description and assign to return object
    listMemberContractDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listMemberContractDetails.menuData = getICMemberMenuData(
        caseParticipantRoleKey);

    return listMemberContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberFinancialDetails listMemberFinancial(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberFinancialDetails listMemberFinancialDetails = new ListMemberFinancialDetails();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory
        .newInstance();
    ViewConcAccountSummaryResult viewConcernRoleAccountSummary;
    final FinancialAccountIdentifier financialAccountIdentifier = new FinancialAccountIdentifier();

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ListMemberFinancialsKey listMemberFinancialsKey = new ListMemberFinancialsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // BEGIN, CR00102331, PMD
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Read the integrated case and participant details
    final ReadIntegratedCaseIDAndParticipantDetails readIntegratedCaseIDAndParticipantDetails = caseHeaderObj
        .readIntegratedCaseIDAndParticipantDetails(caseHeaderKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    if (readIntegratedCaseIDAndParticipantDetails.integratedCaseID != 0) {

      listMemberFinancialsKey.caseID = readIntegratedCaseIDAndParticipantDetails.integratedCaseID;
      listMemberFinancialsKey.concernRoleID = readIntegratedCaseIDAndParticipantDetails.concernRoleID;
      listMemberFinancialsKey.integratedCaseID = readIntegratedCaseIDAndParticipantDetails.integratedCaseID;

    } else {

      listMemberFinancialsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
      listMemberFinancialsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;
      listMemberFinancialsKey.integratedCaseID = caseIDAndParticipantRoleIDDetails.caseID;

    }
    // END, CR00102331

    // Assign key details to search for the concern's financials
    financialAccountIdentifier.assign(listMemberFinancialsKey);

    // Call ViewConcernAccount BPO to return the concern's financial records
    viewConcernRoleAccountSummary = viewConcernAccountObj
        .viewConcernRoleAccountSummary(financialAccountIdentifier);

    // Iterate through the list if it's populated
    if (!viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls
        .isEmpty()) {

      // Reserve space in the output object
      listMemberFinancialDetails.financialDetailsList.dtls.ensureCapacity(
          viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size());

      // ConcernFinancials object
      MemberFinancials memberFinancials;

      for (int i = 0; i < viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls
          .size(); i++) {

        memberFinancials = new MemberFinancials();

        memberFinancials
            .assign(viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls
                .item(i));

        // Amounts are always stored on the database in the base
        // currency and
        // always read back as such. The base currency is returned here
        // for
        // display purposes. The amounts in the money field(s) on each
        // row will
        // be shown in the following format: "USD 1000"
        memberFinancials.currencyType = viewConcernRoleAccountSummary.concernRoleAccSummHeader.currencyType;

        // Add details to the list
        listMemberFinancialDetails.financialDetailsList.dtls
            .addRef(memberFinancials);
      }

    }

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = listMemberFinancialsKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = listMemberFinancialsKey.concernRoleID;

    // Read context description and assign to return object
    listMemberFinancialDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listMemberFinancialDetails.menuData = getICMemberMenuData(
        caseParticipantRoleKey);
    return listMemberFinancialDetails;
  }

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListMemberNoteDetails listMemberNote(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    final ListMemberNoteDetails1 listMemberNoteDetails1 = listMemberNote1(key);

    final ListMemberNoteDetails listMemberNoteDetails = new ListMemberNoteDetails();

    listMemberNoteDetails.assign(listMemberNoteDetails1);

    return listMemberNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberNoteDetails1 listMemberNote1(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberNoteDetails1 listMemberNoteDetails = new ListMemberNoteDetails1();

    // CaseParticipantRoleNoteList manipulation variables
    final curam.core.sl.intf.IntegratedCaseMemberNote integratedCaseMemberNoteObj = curam.core.sl.fact.IntegratedCaseMemberNoteFactory
        .newInstance();

    IntegratedCaseMemberNoteList1 integratedCaseMemberNoteList;
    final CaseParticipantKeyStruct caseParticipantKeyStruct = new CaseParticipantKeyStruct();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // IICMemberContextDescriptionKey struct
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      caseParticipantKeyStruct.key.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      caseParticipantKeyStruct.key.caseID = integratedCaseKey.integratedCaseID;
    }

    // Set key to retrieve list of member notes
    caseParticipantKeyStruct.key.participantID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Set key to read list of member notes
    integratedCaseMemberNoteList = integratedCaseMemberNoteObj
        .list1(caseParticipantKeyStruct);

    // Check to see if the list is empty
    if (!integratedCaseMemberNoteList.dtls.isEmpty()) {

      // Reserve space in the return object
      listMemberNoteDetails.memberNoteDetailsList.dtls
          .ensureCapacity(integratedCaseMemberNoteList.dtls.size());

      MemberNoteDetails1 memberNoteDetails;

      // Iterate through the list of notes
      for (int i = 0; i < integratedCaseMemberNoteList.dtls.size(); i++) {

        memberNoteDetails = new MemberNoteDetails1();

        memberNoteDetails.assign(integratedCaseMemberNoteList.dtls.item(i));

        // Assign note details to return object
        listMemberNoteDetails.memberNoteDetailsList.dtls
            .addRef(memberNoteDetails);
      }

    }

    // Set key to read the context description
    icMemberContextDescriptionKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    icMemberContextDescriptionKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Read context description and assign to return object
    listMemberNoteDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listMemberNoteDetails.menuData = getICMemberMenuData(
        caseParticipantRoleKey);
    return listMemberNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICMemberDetails readMemberDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadICMemberDetails readICMemberDetails = new ReadICMemberDetails();

    // MaintainIntegratedCase manipulation variables
    final curam.core.intf.MaintainIntegratedCases maintainIntegratedCasesObj = curam.core.fact.MaintainIntegratedCasesFactory
        .newInstance();
    final ICPersonHomeKey icPersonHomeKey = new ICPersonHomeKey();

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadMemberDetailsKey readMemberDetailsKey = new ReadMemberDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // ICMemberContextDescriptionKey object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readMemberDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readMemberDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Set key to read Integrated Case member details
    icPersonHomeKey.assign(readMemberDetailsKey);

    // Call MaintainIntegratedCase BPO to read member details and assign
    // to return object
    readICMemberDetails.details.assign(
        maintainIntegratedCasesObj.readICPersonFurtherDetails(icPersonHomeKey));

    // Return back concern role id and type to link to participant home
    // page.
    readICMemberDetails.details.concernRoleID = readMemberDetailsKey.concernRoleID;
    // Return back case ID
    readICMemberDetails.details.caseID = readMemberDetailsKey.caseID;

    // Get concernRoleType
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = readMemberDetailsKey.concernRoleID;
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    readICMemberDetails.details.concernRoleType = concernRoleDtls.concernRoleType;

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readMemberDetailsKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = readMemberDetailsKey.concernRoleID;

    // Read context description
    readICMemberDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // Read menu data
    readICMemberDetails.memberMenuData = getICMemberMenuData(key);

    // Set the key to read the case product list.
    final curam.core.facade.struct.IntegratedCaseIDKey integratedCaseIDKey = new curam.core.facade.struct.IntegratedCaseIDKey();

    integratedCaseIDKey.caseID = readMemberDetailsKey.caseID;

    // Read the list of products.
    ListICProductDeliveryDetails listProductDetails;

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // get the case's parent case ID - the Integrated case ID
    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the integratedCaseIDKey
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      integratedCaseIDKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      integratedCaseIDKey.caseID = integratedCaseKey.integratedCaseID;
    }

    integratedCaseIDKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    listProductDetails = listProduct(integratedCaseIDKey);

    // The product details which will be assigned.
    ICMemberProductDetails icMemberProductDetails;

    // Reserve space in productDetails
    readICMemberDetails.productDetails
        .ensureCapacity(listProductDetails.dtls.size());

    // Assign the list of products.
    for (int i = 0; i < listProductDetails.dtls.size(); i++) {

      icMemberProductDetails = new ICMemberProductDetails();

      icMemberProductDetails.assign(listProductDetails.dtls.item(i));

      readICMemberDetails.productDetails.addRef(icMemberProductDetails);
    }

    return readICMemberDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICAttachmentDetails listAttachment(final ListICAttachmentsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICAttachmentDetails listICAttachmentDetails = new ListICAttachmentDetails();

    // MaintainAttachment manipulation variables
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory
        .newInstance();
    final AttachmentCaseID attachmentCaseID = new AttachmentCaseID();
    CaseAttachmentDetailsList caseAttachmentDetailsList;

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Assign key to retrieve list of attachments
    attachmentCaseID.assign(key);

    // Call MaintainAttachments BPO to retrieve the list of attachments on
    // the
    // Integrated Case
    caseAttachmentDetailsList = maintainAttachmentObj
        .searchIntegCaseAttachments(attachmentCaseID);

    // Check to see if the list is populated
    if (!caseAttachmentDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICAttachmentDetails.attachmentDetailsList.dtls
          .ensureCapacity(caseAttachmentDetailsList.dtls.size());

      // Assign details to return object
      listICAttachmentDetails.attachmentDetailsList
          .assign(caseAttachmentDetailsList);
    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICAttachmentDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICAttachmentDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListICCommunicationDetails listCommunication(
      final ListICCommunicationsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICCommunicationDetails listICCommunicationDetails = new ListICCommunicationDetails();

    // BEGIN, HARP, 35558, CC
    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory
        .newInstance();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Call Communications BPO to retrieve the list of
    // communications
    // Call service layer method to list a participants communications.
    final CommunicationKey communicationKey = new CommunicationKey();

    communicationKey.caseID = key.caseID;

    listICCommunicationDetails.caseCommunicationDetailsList = communicationObj
        .listCommunication(communicationKey);

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICCommunicationDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICCommunicationDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICCommunicationDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListICEventDetails listEvent(final ListICEventKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICEventDetails listICEventDetails = new ListICEventDetails();

    // Call the new version of this method
    final ListICEventDetails1 listICEventDetails1 = listEvent1(key);

    // Populate the return struct with the values returned from the new
    // method
    listICEventDetails.icMenuData = listICEventDetails1.icMenuData;
    listICEventDetails.contextDescription = listICEventDetails1.contextDescription;

    ICEventDetails icEventDetails;

    for (int i = 0; i < listICEventDetails1.eventDetailsList.dtls.size(); i++) {
      icEventDetails = new ICEventDetails();

      icEventDetails.assign(listICEventDetails1.eventDetailsList.dtls.item(i));
      listICEventDetails.eventDetailsList.dtls.addRef(icEventDetails);
    }

    return listICEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICEventDetails1 listEvent1(final ListICEventKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICEventDetails1 listICEventDetails = new ListICEventDetails1();

    // ViewCaseEvents manipulation variables
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList;

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.assign(key);

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList = viewCaseEventsObj
        .readActiveEventsByType1(viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICEventDetails.eventDetailsList.dtls
          .ensureCapacity(viewActiveCaseEventDetailsList.dtls.size());

      // Assign details to return object
      listICEventDetails.eventDetailsList
          .assign(viewActiveCaseEventDetailsList);
    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICEventDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICEventDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    // Determine if CPM is installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      listICEventDetails.isCPMInstalledInd = true;
    }

    return listICEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListICEvidenceDetails listEvidence(final ListICEvidenceKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICEvidenceDetails listICEvidenceDetails = new ListICEvidenceDetails();

    // MaintainEvidence manipulation variables
    final curam.core.intf.MaintainEvidence maintainEvidenceObj = curam.core.fact.MaintainEvidenceFactory
        .newInstance();
    SearchAllEvidenceByCaseResult searchAllEvidenceByCaseResult;
    final ReadAllCaseEvidenceKey readAllCaseEvidenceKey = new ReadAllCaseEvidenceKey();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Assign key details to retrieve the evidence list
    readAllCaseEvidenceKey.assign(key);

    // Call MaintainEvidence BPO to retrieve the evidence list
    searchAllEvidenceByCaseResult = maintainEvidenceObj
        .searchAllEvidenceByCase(readAllCaseEvidenceKey);

    // Check to see if the list is populated
    if (!searchAllEvidenceByCaseResult.caseEvidenceTypeDetailsList.dtls
        .isEmpty()) {

      // Reserve space in the return object
      listICEvidenceDetails.evidenceDetailsList.dtls.ensureCapacity(
          searchAllEvidenceByCaseResult.caseEvidenceTypeDetailsList.dtls
              .size());

      ICEvidenceDetails icEvidenceDetails;

      // Iterate through the list of evidence
      for (int i = 0; i < searchAllEvidenceByCaseResult.caseEvidenceTypeDetailsList.dtls
          .size(); i++) {

        icEvidenceDetails = new ICEvidenceDetails();

        // Assign details
        icEvidenceDetails.assign(
            searchAllEvidenceByCaseResult.caseEvidenceTypeDetailsList.dtls
                .item(i));

        // Check to see if the effectiveFromDate is empty
        if (searchAllEvidenceByCaseResult.caseEvidenceTypeDetailsList.dtls
            .item(i).effectiveFrom.isZero()) {
          // Use string constant for case start date
          // BEGIN, CR00222190, ELG
          icEvidenceDetails.evidenceDateStr = INTEGRATEDCASEMEMBERNOTE.INF_CASE_START_DATE
              .getMessageText(TransactionInfo.getProgramLocale());
          // END, CR00222190
        } else {

          // BEGIN, CR00086110, POB
          icEvidenceDetails.evidenceDateStr = searchAllEvidenceByCaseResult.caseEvidenceTypeDetailsList.dtls
              .item(i).effectiveFrom.getDateTime().toString();
          // END, CR00086110
        }

        // Add details to return object
        listICEvidenceDetails.evidenceDetailsList.dtls
            .addRef(icEvidenceDetails);
      }

    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICEvidenceDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICEvidenceDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICEvidenceDetails;
  }

  // BEGIN, CR00222438, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListICMemberCommunicationDetails listMemberCommunication(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICMemberCommunicationDetails listICMemberCommunicationDetails = new ListICMemberCommunicationDetails();

    // ICMemberContextDescriptionKey object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    final ListICMemberCommunicationKey listICMemberCommunicationKey = getICMemberCommunicationKeyDetails(
        key.dtls);

    listICMemberCommunicationDetails.memberCommCaseID.caseID = listICMemberCommunicationKey.caseID;

    // Call Communications BPO to retrieve the list of
    // communications of all cases that this concern is a member of.
    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory
        .newInstance();

    final CommunicationKey communicationKey = new CommunicationKey();

    communicationKey.caseID = listICMemberCommunicationKey.caseID;
    communicationKey.concernRoleID = listICMemberCommunicationKey.concernRoleID;

    // read the communications based on case and concern role id.
    listICMemberCommunicationDetails.memberCommDetailsList.caseMemberCommDetailsList = communicationObj
        .listCaseMemberCommunication(communicationKey);
    // END HARP 35558

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = listICMemberCommunicationKey.caseID;

    icMemberContextDescriptionKey.concernRoleID = listICMemberCommunicationKey.concernRoleID;

    // Read context description
    listICMemberCommunicationDetails.description = getICMemberContextDescription(
        icMemberContextDescriptionKey).description;

    // Read menu data
    listICMemberCommunicationDetails.memberMenuData = getICMemberMenuData(key);

    return listICMemberCommunicationDetails;
  }

  // ____________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CommunicationDetailList listCaseMemberCommunication(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    final CommunicationDetailList communicationDetailList = new CommunicationDetailList();

    final ListICMemberCommunicationKey listICMemberCommunicationKey = getICMemberCommunicationKeyDetails(
        key.dtls);

    // Call Communications BPO to retrieve the list of
    // communications of all cases that this concern is a member of.
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory
        .newInstance();

    final CommunicationKey communicationKey = new CommunicationKey();

    communicationKey.caseID = listICMemberCommunicationKey.caseID;
    communicationKey.concernRoleID = listICMemberCommunicationKey.concernRoleID;

    // read the communications based on case and concern role id.
    final CaseMemberCommDetailsList caseMemberCommDetailsList = communicationObj
        .listCaseMemberCommunication(communicationKey);

    // Assign the details returned to a new struct that also contains the
    // display indicators and fields required for the actions
    String communicationFormat = "";
    CommunicationAndListRowActionDetails communicationDtls;

    // BEGIN, CR00294269, IBM
    for (final CaseMemberCommunicationDetails caseMemberCommunicationDetails : caseMemberCommDetailsList.dtls
        .items()) {
      // END, CR00294269

      communicationDtls = new CommunicationAndListRowActionDetails();

      // BEGIN, CR00294269, IBM
      communicationDtls.assign(caseMemberCommunicationDetails);

      if (RECORDSTATUS.CANCELLED.equals(communicationDtls.statusCode)) {
        // END, CR00294269

        communicationDtls.canceledInd = true;

        // BEGIN, CR00303767, IBM
        if (COMMUNICATIONFORMAT.MSWORD
            .equals(communicationDtls.communicationFormat)) {
          communicationDtls.msWordInd = true;

          if (COMMUNICATIONSTATUS.DRAFT
              .equals(communicationDtls.communicationStatus)) {
            communicationDtls.duplicateAndCancelIndOpt = true;
          }
        }
        // END, CR00303767

      } else {
        communicationFormat = communicationDtls.communicationFormat;

        // BEGIN, CR00294269, IBM
        if (COMMUNICATIONFORMAT.EMAIL.equals(communicationFormat)
            && COMMUNICATIONSTATUS.DRAFT
                .equals(communicationDtls.communicationStatus)) {
          // END, CR00294269

          communicationDtls.draftEmailInd = true;

          // BEGIN, CR00294269, IBM
        } else if (COMMUNICATIONFORMAT.MSWORD.equals(communicationFormat)) {
          // END, CR00294269

          communicationDtls.msWordInd = true;

          final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

          attachmentLinkKey.attachmentLinkID = communicationDtls.communicationID;

          AttachmentLinkDetails attachmentLinkDetails;

          try {
            attachmentLinkDetails = AttachmentFactory.newInstance()
                .readAttachment(attachmentLinkKey);

            communicationDtls.attachmentDtls.attachmentName = attachmentLinkDetails.attachmentDtls.attachmentName;
            communicationDtls.attachmentDtls.attachmentContents = attachmentLinkDetails.attachmentDtls.attachmentContents;

          } catch (final RecordNotFoundException rnfe) {// Do nothing
            // there are
            // no
            // attachments
            // associated
            // with this
            // communication
          }

          // BEGIN, CR00294269, IBM
        } else if (COMMUNICATIONFORMAT.PROFORMA.equals(communicationFormat)) {
          // END, CR00294269

          communicationDtls.proFormaInd = true;

          // Get the local identifier for the template and add it to
          // the return struct
          final ReadProFormaCommKey readProFormaCommKey = new ReadProFormaCommKey();

          readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
          communicationDtls.localeIdentifier = CommunicationFactory
              .newInstance().readProForma1(
                  readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
        }

        // Get the delete page link
        communicationDtls.deletePage.deletePageName = curam.core.facade.fact.CommunicationFactory
            .newInstance().getDeletePageName(communicationDtls).deletePageName;
      }

      // Add this list item to the return struct
      communicationDetailList.communicationDtls.addRef(communicationDtls);
    }

    return communicationDetailList;
  }

  // __________________________________________________________________________
  /**
   * Returns the case ID and concern Role ID for a case participant.
   *
   * @param key
   *          The case participant id.
   * @return The case id and concern role id.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  protected ListICMemberCommunicationKey getICMemberCommunicationKeyDetails(
      final CaseParticipantRole_boKey key)
      throws AppException, InformationalException {

    final ListICMemberCommunicationKey listICMemberCommunicationKey = new ListICMemberCommunicationKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {
      listICMemberCommunicationKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {
      listICMemberCommunicationKey.caseID = integratedCaseKey.integratedCaseID;
    }

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    listICMemberCommunicationKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    return listICMemberCommunicationKey;
  }

  // END, CR00222438

  // ___________________________________________________________________________
  // BEGIN, CR00246976, SS
  // BEGIN, CR00170405, SS
  /**
   * Returns a list of notes on an Integrated Case.
   *
   * @param key
   *          Key to read the list of notes on an Integrated Case.
   *
   * @return List of notes for an Integrated Case.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since 5.2 SP4, replaced with
   *             {@link IntegratedCase#listAccessibleNote(ListICNotesKey)}. As
   *             the current method does not consider a note access indicator,
   *             as going forward now it is required to consider a note access
   *             indicator which will determine the accessibility of notes. See
   *             release note: CR00246976.
   */
  @Override
  @Deprecated
  // END, CR00246976
  public ListICNoteDetails listNote(final ListICNotesKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICNoteDetails listICNoteDetails = new ListICNoteDetails();

    // CaseNote manipulation variables
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory
        .newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();
    CaseNoteList caseNoteList;

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read the list of notes
    caseKey.key.caseID = key.caseID;

    // Call CaseNotes BPO to retrieve the list of notes
    caseNoteList = caseNoteObj.list(caseKey);

    // Check to see if the list if populated
    if (!caseNoteList.details.isEmpty()) {

      // Reserve space in the return object
      listICNoteDetails.noteDetailsList.dtls
          .ensureCapacity(caseNoteList.details.size());

      // ICNoteDetails object
      ICNoteDetails icNoteDetails;

      // Assign details to return object
      for (int i = 0; i < caseNoteList.details.size(); i++) {

        icNoteDetails = new ICNoteDetails();

        // Assign note details
        icNoteDetails.assign(caseNoteList.details.item(i));

        // Add details to the return objects
        listICNoteDetails.noteDetailsList.dtls.addRef(icNoteDetails);
      }

    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICNoteDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICNoteDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICNoteDetails;
  }

  // END, CR00170405
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryAttachmentDetails listProductDeliveryAttachment(
      final ListICProductDeliveryAttachmentKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryAttachmentDetails listICProductDeliveryAttachmentDetails = new ListICProductDeliveryAttachmentDetails();

    // MaintainAttachment manipulation variables
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory
        .newInstance();
    final AttachmentCaseID attachmentCaseID = new AttachmentCaseID();
    curam.core.struct.AttachmentDetailsList attachmentDetailsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read the list of attachment
    attachmentCaseID.assign(key);

    // Call MaintainAttachment BPO to retrieve the list of attachments
    attachmentDetailsList = maintainAttachmentObj
        .readCaseAttachments(attachmentCaseID);

    // Check to see if the list is populated
    if (!attachmentDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryAttachmentDetails.attachmentDetailsList.dtls
          .ensureCapacity(attachmentDetailsList.dtls.size());

      // Assign details to return object
      listICProductDeliveryAttachmentDetails.attachmentDetailsList
          .assign(attachmentDetailsList);
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryAttachmentDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // BEGIN, CR00305483, SSK
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (caseHeaderDtls.integratedCaseID != 0) {
      // END, CR00305483
      // Set key to read menu data
      icProductDeliveryMenuDataKey.caseID = key.caseID;
      // Read menu data
      listICProductDeliveryAttachmentDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
          icProductDeliveryMenuDataKey);
    }

    return listICProductDeliveryAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Key to read the list of Product Delivery communications.
   *
   * @return List of communications.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link IntegratedCase#listCaseMemberCommunication()}. The new
   *             method returns the same details but also returns indicators
   *             that will be used to conditionally display list row action
   *             appropriate to the event type.
   *
   *             Returns a list of communications for a Product Delivery on an
   *             Integrated Case.
   */
  @Override
  @Deprecated
  public ListICProductDeliveryCommunicationDetails listProductDeliveryCommunication(
      final ListICProductDeliveryCommunicationKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryCommunicationDetails listICProductDeliveryCommunicationDetails = new ListICProductDeliveryCommunicationDetails();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // BEGIN, HARP, 35558, CC
    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory
        .newInstance();

    // Call Communications BPO to retrieve the list of
    // communications
    final CommunicationKey communicationKey = new CommunicationKey();

    communicationKey.caseID = key.caseID;

    listICProductDeliveryCommunicationDetails.communicationDetailsList = communicationObj
        .listCommunication(communicationKey);

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryCommunicationDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryCommunicationDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryCommunicationDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Key to read the list of Product Delivery events.
   *
   * @return List of events on the Product Delivery.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listProductDeliveryEvent1(ListICProductDeliveryEventKey)}
   *             . The new method returns the same details but also returns
   *             indicators that will be used to conditionally display list row
   *             action appropriate to the event type.
   *
   *             Returns a list of events for a Product Delivery on an
   *             Integrated Case.
   */
  @Override
  @Deprecated
  public ListICProductDeliveryEventDetails listProductDeliveryEvent(
      final ListICProductDeliveryEventKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryEventDetails listICProductDeliveryEventDetails = new ListICProductDeliveryEventDetails();

    final ListICProductDeliveryEventDetails1 listICProductDeliveryEventDetails1 = listProductDeliveryEvent1(
        key);

    listICProductDeliveryEventDetails.contextDescription = listICProductDeliveryEventDetails1.contextDescription;
    listICProductDeliveryEventDetails.icProductDeliveryMenuData = listICProductDeliveryEventDetails1.icProductDeliveryMenuData;

    ICProductDeliveryEventDetails icProductDeliveryEventDetails;

    for (int i = 0; i < listICProductDeliveryEventDetails1.eventDetailsList.dtls
        .size(); i++) {
      icProductDeliveryEventDetails = new ICProductDeliveryEventDetails();

      icProductDeliveryEventDetails.assign(
          listICProductDeliveryEventDetails1.eventDetailsList.dtls.item(i));
      listICProductDeliveryEventDetails.eventDetailsList.dtls
          .addRef(icProductDeliveryEventDetails);
    }

    return listICProductDeliveryEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryEventDetails1 listProductDeliveryEvent1(
      final ListICProductDeliveryEventKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryEventDetails1 listICProductDeliveryEventDetails = new ListICProductDeliveryEventDetails1();

    // ViewCaseEvents manipulation variables
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();

    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.assign(key);

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList = viewCaseEventsObj
        .readActiveEventsByType1(viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryEventDetails.eventDetailsList.dtls
          .ensureCapacity(viewActiveCaseEventDetailsList.dtls.size());

      // If the list has case event decisions of type superseded, do not
      // return
      // them
      // on the view list for the case

      // Create new struct to hold all case events except those of type
      // superseded case decisions.
      final ViewActiveCaseEventDetailsList1 viewFileteredCaseEventDetailsList = new ViewActiveCaseEventDetailsList1();

      for (int i = 0; i < viewActiveCaseEventDetailsList.dtls.size(); i++) {
        // Check event to see of type case decision
        final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory
            .newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewActiveCaseEventDetailsList.dtls
            .item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to list if an
        // active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode
              .equals(curam.codetable.CASEDECISIONSTATUS.CURRENT)) {

            viewFileteredCaseEventDetailsList.dtls
                .addRef(viewActiveCaseEventDetailsList.dtls.item(i));
          }
        } else {

          // if not a case decision event - add to list.
          viewFileteredCaseEventDetailsList.dtls
              .addRef(viewActiveCaseEventDetailsList.dtls.item(i));
        }

      }

      // Assign details to the return object
      listICProductDeliveryEventDetails.eventDetailsList
          .assign(viewFileteredCaseEventDetailsList);
      listICProductDeliveryEventDetails.dtlsList
          .assign(viewFileteredCaseEventDetailsList);
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryEventDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryEventDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryEvidenceDetails listProductDeliveryEvidence(
      final ListICProductDeliveryEvidenceKey key)
      throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory
        .newInstance();
    final ListEvidenceTreeLessCanceledAndSupersededKey listEvidenceTreeLessCanceledAndSupersededKey = new ListEvidenceTreeLessCanceledAndSupersededKey();
    ListEvidenceTreeLessCanceledAndSupersededResult listEvidenceTreeLessCanceledAndSupersededResult;

    // Create return object
    final ListICProductDeliveryEvidenceDetails listICProductDeliveryEvidenceDetails = new ListICProductDeliveryEvidenceDetails();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededKey.key.caseID = key.caseID;
    // BEGIN, CR00204750, MC
    listEvidenceTreeLessCanceledAndSupersededKey.key.statusCode2 = EVIDENCETREESTATUS.CANCELED;
    // END, CR00204750
    listEvidenceTreeLessCanceledAndSupersededKey.key.statusCode = EVIDENCETREESTATUS.SUPERSEDED;

    // Call API method to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededResult = caseEvidenceAPIObj
        .listEvidenceTreeLessCanceledAndSuperseded(
            listEvidenceTreeLessCanceledAndSupersededKey);

    if (!listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.isEmpty()) {

      final CaseEvidenceTreeKeyStruct caseEvidenceTreeKeyStruct = new CaseEvidenceTreeKeyStruct();
      ListGroupOnTreeResult listGroupOnTreeResult;

      // Set key to list groups on tree
      caseEvidenceTreeKeyStruct.caseEvidenceTreeID = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
          .item(0).caseEvidenceTreeID;

      // Call API method to list groups on tree
      listGroupOnTreeResult = caseEvidenceAPIObj
          .listGroupOnTree(caseEvidenceTreeKeyStruct);

      // Reserve space in return object
      listICProductDeliveryEvidenceDetails.evidenceList.dtls.ensureCapacity(
          listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.size());

      ICEvidenceDetails icEvidenceDetails;

      for (int i = 0; i < listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
          .size(); i++) {

        icEvidenceDetails = new ICEvidenceDetails();

        icEvidenceDetails.evidenceID = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
            .item(i).caseEvidenceTreeID;
        icEvidenceDetails.effectiveFrom = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
            .item(i).effectiveFrom;
        icEvidenceDetails.statusCode = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
            .item(i).statusCode;
        icEvidenceDetails.versionNo = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
            .item(i).versionNo;
        // Only one product exists on demo products, so select first
        // element in list
        icEvidenceDetails.evidenceGroupNameCode = listGroupOnTreeResult.dtls
            .item(0).evidenceGroupNameCode;

        // Check to see if the effectiveFromDate is empty
        if (listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
            .item(i).effectiveFrom.isZero()) {
          // Use string constant for case start date
          // BEGIN, CR00222190, ELG
          icEvidenceDetails.evidenceDateStr = INTEGRATEDCASEMEMBERNOTE.INF_CASE_START_DATE
              .getMessageText(TransactionInfo.getProgramLocale());
          // END, CR00222190
        } else {

          // BEGIN, CR00086110, POB
          // BEGIN, CR00089684, ANK
          // Set evidenceFrom date string in evidence object
          icEvidenceDetails.evidenceDateStr = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls
              .item(i).effectiveFrom.toString();
          // END, CR00089684
          // END, CR00086110
        }

        // Add details to return object
        listICProductDeliveryEvidenceDetails.evidenceList.dtls
            .addRef(icEvidenceDetails);
      }

    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryEvidenceDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryEvidenceDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryFinancialDetails listProductDeliveryFinancial(
      final ListICProductDeliveryFinancialsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryFinancialDetails listICProductDeliveryFinancialDetails = new ListICProductDeliveryFinancialDetails();

    // ViewRepaymentCaseAccount manipulation variables
    final curam.core.intf.ViewRepaymentCaseAccount viewRepaymentCaseAccountObj = curam.core.fact.ViewRepaymentCaseAccountFactory
        .newInstance();
    ViewRepaymentCaseFinancialsResult viewRepaymentCaseFinancialsResult;
    final RepaymentCaseAccountIdentifier repaymentCaseAccountIdentifier = new RepaymentCaseAccountIdentifier();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details to read the list of financials
    repaymentCaseAccountIdentifier.assign(key);

    // Call ViewRepaymentCaseAccount BPO to retrieve the list of financials
    viewRepaymentCaseFinancialsResult = viewRepaymentCaseAccountObj
        .viewRepaymentCaseFinancials(repaymentCaseAccountIdentifier);

    // Check to see if the list is populated
    if (!viewRepaymentCaseFinancialsResult.repCaseAccountDetailsList.dtls
        .isEmpty()) {

      // Reserve space in the output struct
      listICProductDeliveryFinancialDetails.financialDetailsList.dtls
          .ensureCapacity(
              viewRepaymentCaseFinancialsResult.repCaseAccountDetailsList.dtls
                  .size());

      // ICProductDeliveryFinancialDetails object
      ICProductDeliveryFinancialDetails icProductDeliveryFinancialDetails;

      for (int i = 0; i < viewRepaymentCaseFinancialsResult.repCaseAccountDetailsList.dtls
          .size(); i++) {

        icProductDeliveryFinancialDetails = new ICProductDeliveryFinancialDetails();

        // Assign details
        icProductDeliveryFinancialDetails.assign(
            viewRepaymentCaseFinancialsResult.repCaseAccountDetailsList.dtls
                .item(i));
        icProductDeliveryFinancialDetails.currencyType = viewRepaymentCaseFinancialsResult.searchResultSummary.currencyType;

        // Push details into return object
        listICProductDeliveryFinancialDetails.financialDetailsList.dtls
            .addRef(icProductDeliveryFinancialDetails);
      }

    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryFinancialDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryFinancialDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryFinancialDetails;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00246976, SS
  // BEGIN, CR00170405, SS
  /**
   * Returns a list of notes for a Product Delivery on an Integrated Case.
   *
   * @param key
   *          Key to read the list of Product Delivery notes.
   *
   * @return List of Product Delivery notes.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   *
   * @deprecated Since 5.2 SP4, replaced with
   *             {@link #listPDAccessibleNote(ListICProductDeliveryNoteKey)}. As
   *             the current method does not consider a note access indicator,
   *             as going forward now it is required to consider a note access
   *             indicator which will determine the accessibility of notes. See
   *             release note: CR00246976.
   */
  @Override
  @Deprecated
  // END, CR00246976
  public ListICProductDeliveryNoteDetails listProductDeliveryNote(
      final ListICProductDeliveryNoteKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryNoteDetails listICProductDeliveryNoteDetails = new ListICProductDeliveryNoteDetails();

    // CaseNote manipulation variables
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory
        .newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();
    CaseNoteList caseNoteList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read the list of notes
    caseKey.key.caseID = key.caseID;

    // Call CaseNotes BPO to retrieve the list of notes
    caseNoteList = caseNoteObj.list(caseKey);

    // Check to see if the list if populated
    if (!caseNoteList.details.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryNoteDetails.noteDetailsList.dtls
          .ensureCapacity(caseNoteList.details.size());

      // ICProductDeliveryNoteDetails object
      ICProductDeliveryNoteDetails icProductDeliveryNoteDetails;

      // Assign details to return object
      for (int i = 0; i < caseNoteList.details.size(); i++) {

        icProductDeliveryNoteDetails = new ICProductDeliveryNoteDetails();

        // Assign note details
        icProductDeliveryNoteDetails.assign(caseNoteList.details.item(i));

        // Add details to the return objects
        listICProductDeliveryNoteDetails.noteDetailsList.dtls
            .addRef(icProductDeliveryNoteDetails);
      }

    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryNoteDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryNoteDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryNoteDetails;
  }

  // END, CR00170405
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CreatedCaseIDKey addProductToIntegratedCase(
      final AddProductToICDetails details)
      throws AppException, InformationalException {

    // Create return object
    final CreatedCaseIDKey createdCaseIDKey = new CreatedCaseIDKey();

    // CreateProductDelivery manipulation variables
    final curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory
        .newInstance();
    final RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();

    // Assign details to key
    registerProductDeliveryKey.assign(details);

    // Register the product delivery and assign
    // the returned caseID to the return object
    createdCaseIDKey.caseID = createProductDeliveryObj.registerProductDelivery(
        registerProductDeliveryKey,
        new RegisterProductDeliveryDetails()).caseID;

    return createdCaseIDKey;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Key to read Product Delivery details.
   *
   * @return Contains the home page details.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #readICProductHomePageDetails1()}.
   *
   *             Reads details to populate a Product Delivery home page on an
   *             Integrated Case.
   */
  @Override
  @Deprecated
  public ReadICProductHomePageDetails readICProductHomePageDetails(
      final ReadICProductHomePageKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadICProductHomePageDetails readICProductHomePageDetails = new ReadICProductHomePageDetails();

    // BEGIN, CR00220971, ZV
    readICProductHomePageDetails.assign(readICProductHomePageDetails1(key));
    // END, CR00220971

    return readICProductHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelMemberNote(final CancelMemberNoteKey key)
      throws AppException, InformationalException {

    // IntegratedCaseMemberNote manipulation variables
    final curam.core.sl.intf.IntegratedCaseMemberNote integratedCaseMemberNoteObj = curam.core.sl.fact.IntegratedCaseMemberNoteFactory
        .newInstance();
    final CancelICMemberNoteDetails cancelICMemberNoteDetails = new CancelICMemberNoteDetails();

    // Set key to cancel the note
    cancelICMemberNoteDetails.key.integratedCaseMemberNoteID = key.integratedCaseMemberNoteID;
    cancelICMemberNoteDetails.noteDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelICMemberNoteDetails.noteDetails.versionNo = key.versionNo;

    // Call Service Layer to cancel the note
    integratedCaseMemberNoteObj.cancel(cancelICMemberNoteDetails);
  }

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public void createMemberNote(final CreateMemberNoteDetails details)
      throws AppException, InformationalException {

    final CreateMemberNoteDetails1 createMemberNoteDetails1 = new CreateMemberNoteDetails1();

    createMemberNoteDetails1.assign(details);

    createMemberNote1(createMemberNoteDetails1);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void createMemberNote1(final CreateMemberNoteDetails1 details)
      throws AppException, InformationalException {

    // IntegratedCaseMemberNote manipulation variables
    final curam.core.sl.intf.IntegratedCaseMemberNote integratedCaseMemberNoteObj = curam.core.sl.fact.IntegratedCaseMemberNoteFactory
        .newInstance();
    final InsertIntegratedCaseMemberNote insertIntegratedCaseMemberNote = new InsertIntegratedCaseMemberNote();

    // MaintainCase manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // Read caseID and participantID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // BEGIN, CR00102331, PMD
    // Assign integrated case ID
    if (integratedCaseKey.integratedCaseID == 0) {

      details.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      details.caseID = integratedCaseKey.integratedCaseID;
    }

    details.participantID = caseIDAndParticipantRoleIDDetails.participantRoleID;
    // END, CR00102331

    // Assign details for the creation of the member note
    insertIntegratedCaseMemberNote.noteDetails.integratedCaseNoteDtls
        .assign(details);
    insertIntegratedCaseMemberNote.noteDetails.noteDetails.assign(details);

    // Call Service Layer method to create the note
    integratedCaseMemberNoteObj.insert(insertIntegratedCaseMemberNote);
  }

  // ___________________________________________________________________________
  /**
   * Reads details of an Integrated Case Member Note.
   *
   * @param key
   *          Key to read the Integrated Case Note details.
   *
   * @return Integrated Case Member Note details.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated - since Version 6.0
   * @deprecated - replaced by {@link #readMemberNote1()}
   */
  @Override
  @Deprecated
  public ReadMemberNoteDetails readMemberNote(final ReadMemberNoteKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadMemberNoteDetails readMemberNoteDetails = new ReadMemberNoteDetails();

    final ReadMemberNoteDetails1 readMemberNoteDetails1 = readMemberNote1(key);

    readMemberNoteDetails.assign(readMemberNoteDetails1);

    return readMemberNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadMemberNoteDetails1 readMemberNote1(final ReadMemberNoteKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadMemberNoteDetails1 readMemberNoteDetails1 = new ReadMemberNoteDetails1();

    // IntegratedCaseMemberNote manipulation variables
    final curam.core.sl.intf.IntegratedCaseMemberNote integratedCaseMemberNoteObj = curam.core.sl.fact.IntegratedCaseMemberNoteFactory
        .newInstance();
    final ReadICMemberNoteDetails1 readICMemberNoteDetails = new ReadICMemberNoteDetails1();
    final IntegratedCaseMemberNoteKey integratedCaseMemberNoteKey = new IntegratedCaseMemberNoteKey();

    // Set key to read the note details
    integratedCaseMemberNoteKey.key.integratedCaseMemberNoteID = key.integratedCaseMemberNoteID;

    // Call Service Layer read to retrieve the note details and assign to
    // return object
    readICMemberNoteDetails
        .assign(integratedCaseMemberNoteObj.read1(integratedCaseMemberNoteKey));

    readMemberNoteDetails1.assign(readICMemberNoteDetails.noteDetails);

    return readMemberNoteDetails1;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of an Integrated Case Member Note.
   *
   * @param key
   *          Key to modify the Integrated Case Member Note.
   *
   * @param details
   *          Details to modify the Integrated Case Member Note.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #viewCaseNomineeDetails1()}
   */
  @Override
  @Deprecated
  public void modifyMemberNote(final ModifyMemberNoteDetailsKey key,
      final ModifyMemberNoteDetails details)
      throws AppException, InformationalException {

    final ModifyMemberNoteDetails1 modifyMemberNoteDetails1 = new ModifyMemberNoteDetails1();

    modifyMemberNoteDetails1.assign(details);

    modifyMemberNote1(key, modifyMemberNoteDetails1);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyMemberNote1(final ModifyMemberNoteDetailsKey key,
      final ModifyMemberNoteDetails1 details)
      throws AppException, InformationalException {

    // IntegratedCaseMemberNote manipulation variables
    final curam.core.sl.intf.IntegratedCaseMemberNote integratedCaseMemberNoteObj = curam.core.sl.fact.IntegratedCaseMemberNoteFactory
        .newInstance();

    final ModifyICMemberNoteDetails1 modifyICMemberNoteDetails = new ModifyICMemberNoteDetails1();

    // Set modify details to call Service Layer
    modifyICMemberNoteDetails.integratedCaseNoteDetails.modifyNoteDetails
        .assign(details);
    modifyICMemberNoteDetails.integratedCaseNoteDetails.integratedCaseNoteDetails
        .assign(details);
    modifyICMemberNoteDetails.key.integratedCaseMemberNoteID = key.integratedCaseMemberNoteID;

    // Call Service Layer to modify the note details
    integratedCaseMemberNoteObj.modify1(modifyICMemberNoteDetails);
  }

  // END, CR00231506

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void printContract(final PrintContractDetails details)
      throws AppException, InformationalException {

    // ConcernRoleDocuments manipulation variables
    final curam.core.intf.ConcernRoleDocuments concernRoleDocumentsObj = curam.core.fact.ConcernRoleDocumentsFactory
        .newInstance();
    final ConcernRoleDocumentDetails concernRoleDocumentDetails = new ConcernRoleDocumentDetails();
    final CaseContractDocumentKey caseContractDocumentKey = new CaseContractDocumentKey();

    final curam.core.intf.CaseContract caseContractObj = curam.core.fact.CaseContractFactory
        .newInstance();
    final CaseContractKey caseContractKey = new CaseContractKey();
    CaseContractDtls caseContractDtls;

    // Set key to read caseContract
    caseContractKey.caseContractID = details.caseContractID;

    // Read caseContract
    caseContractDtls = caseContractObj.read(caseContractKey);

    // Assign details to print the document
    concernRoleDocumentDetails.documentID = caseContractDtls.documentID;
    concernRoleDocumentDetails.versionNo = caseContractDtls.documentVersionNo;

    // Assign key details to print the document
    caseContractDocumentKey.caseContractID = details.caseContractID;
    caseContractDocumentKey.caseID = caseContractDtls.caseID;
    caseContractDocumentKey.concernRoleID = caseContractDtls.concernRoleID;

    // Call ConcernRoleDocuments BPO to print the document
    concernRoleDocumentsObj.printCaseContract(caseContractDocumentKey,
        concernRoleDocumentDetails);
  }

  // BEGIN, CR00165745, PDN
  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #searchICProductDeliveryEventAndActivity1()}.
   *
   *             Returns data representing case events and activities for a
   *             Product Delivery on an Integrated Case.
   */
  @Override
  @Deprecated
  public ICProductDeliveryEventAndActivityDetails searchICProductDeliveryEventAndActivity(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICProductDeliveryEventAndActivityDetails icProductDeliveryEventAndActivityDetails = new ICProductDeliveryEventAndActivityDetails();

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory
        .newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj
        .readEventsByType(viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
        kBufferSize * viewCaseEventDetailsList.dtls.size());

    // BEGIN, CR00163098, JC
    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
        .append(curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
            CALENDARTYPE.CASE, TransactionInfo.getProgramLocale()))
        .append(kQuote).append(kCloseBracket).append(kSpace);
    // END, CR00163098, JC

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode
          .equals(curam.codetable.CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls
            .item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls
            .item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls
            .item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls
            .item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls
            .item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls
            .item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls
            .item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls
            .item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj
            .parseActivity(activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls
            .item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
            viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls
            .item(i).typeCode;

        // if it is a event of type case decision with a status of
        // superseded
        // do not add to the calendar
        final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to calendar if
        // an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode
              .equals(curam.codetable.CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj
                .parseEvent(eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
              dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        }
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);

    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    icProductDeliveryEventAndActivityDetails.calendarDetails
        .assign(caseEventAndActivityDetails);

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    icProductDeliveryEventAndActivityDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    icProductDeliveryEventAndActivityDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return icProductDeliveryEventAndActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICProductDeliveryEventAndActivityDetails1 searchICProductDeliveryEventAndActivity1(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICProductDeliveryEventAndActivityDetails1 icProductDeliveryEventAndActivityDetails1 = new ICProductDeliveryEventAndActivityDetails1();

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory
        .newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj
        .readEventsByType(viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
        kBufferSize * viewCaseEventDetailsList.dtls.size());

    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
        .append(curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
            CALENDARTYPE.CASE))
        .append(kQuote).append(kCloseBracket).append(kSpace);

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode
          .equals(curam.codetable.CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls
            .item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls
            .item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls
            .item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls
            .item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls
            .item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls
            .item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls
            .item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls
            .item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj
            .parseActivity(activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls
            .item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
            viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls
            .item(i).typeCode;

        // if it is a event of type case decision with a status of
        // superseded
        // do not add to the calendar
        final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
        CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to calendar if
        // an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode
              .equals(curam.codetable.CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj
                .parseEvent(eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
              dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        }
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);

    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    icProductDeliveryEventAndActivityDetails1.calendarDetails
        .assign(caseEventAndActivityDetails);

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    icProductDeliveryEventAndActivityDetails1.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // BEGIN, CR00305483, SSK
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (caseHeaderDtls.integratedCaseID != 0) {
      // END, CR00305483
      // Set key to read menu data
      icProductDeliveryMenuDataKey.caseID = key.caseID;

      // Read menu data
      icProductDeliveryEventAndActivityDetails1.menuData = getICProductDeliveryMenuData(
          icProductDeliveryMenuDataKey);
    }

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      icProductDeliveryEventAndActivityDetails1.isCPMInstalled = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      icProductDeliveryEventAndActivityDetails1.isAppealsInstalled = true;
    }

    return icProductDeliveryEventAndActivityDetails1;
  }

  // END, CR00165745

  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #searchICCaseEventAndActivity()}.
   *
   *             Returns data representing case events and activities for an
   *             Integrated Case calendar.
   */
  @Override
  @Deprecated
  public ICCaseEventAndActivityDetails searchICCaseEventAndActivity(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICCaseEventAndActivityDetails icCaseEventAndActivityDetails = new ICCaseEventAndActivityDetails();

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;

    // read case header details and assign case type
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    viewCaseEventsByCaseIDAndTypeKey.typeCode = caseHeaderDtls.caseTypeCode;

    viewCaseEventDetailsList = viewCaseEventsObj
        .readEventsByType(viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
        kBufferSize * viewCaseEventDetailsList.dtls.size());

    // BEGIN, CR00163098, JC
    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
        .append(curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
            CALENDARTYPE.CASE, TransactionInfo.getProgramLocale()))
        .append(kQuote).append(kCloseBracket).append(kSpace);
    // END, CR00163098, JC

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode
          .equals(curam.codetable.CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls
            .item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls
            .item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls
            .item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls
            .item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls
            .item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls
            .item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls
            .item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls
            .item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj
            .parseActivity(activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls
            .item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
            viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls
            .item(i).typeCode;

        // Parse the event
        calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);

    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    icCaseEventAndActivityDetails.calendarDetails
        .assign(caseEventAndActivityDetails);

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and set in return object
    icCaseEventAndActivityDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    icCaseEventAndActivityDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return icCaseEventAndActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICCaseEventAndActivityDetails1 searchICCaseEventAndActivity1(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICCaseEventAndActivityDetails1 icCaseEventAndActivityDetails1 = new ICCaseEventAndActivityDetails1();

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;

    // read case header details and assign case type
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    viewCaseEventsByCaseIDAndTypeKey.typeCode = caseHeaderDtls.caseTypeCode;

    viewCaseEventDetailsList = viewCaseEventsObj
        .readEventsByType(viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
        kBufferSize * viewCaseEventDetailsList.dtls.size());

    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
        .append(curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
            CALENDARTYPE.CASE))
        .append(kQuote).append(kCloseBracket).append(kSpace);

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode
          .equals(curam.codetable.CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls
            .item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls
            .item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls
            .item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls
            .item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls
            .item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls
            .item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls
            .item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls
            .item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls
            .item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj
            .parseActivity(activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        // BEGIN, CR00332644, MV
        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls
            .item(i).startDateTime.addTime(12, 0, 0);
        // END, CR00332644
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls
            .item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls
            .item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls
            .item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
            viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls
            .item(i).typeCode;

        // Parse the event
        calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);

    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    icCaseEventAndActivityDetails1.calendarDetails
        .assign(caseEventAndActivityDetails);

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and set in return object
    icCaseEventAndActivityDetails1.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data
    icCaseEventAndActivityDetails1.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      icCaseEventAndActivityDetails1.isCPMInstalled = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      icCaseEventAndActivityDetails1.isAppealsInstalled = true;
    }

    return icCaseEventAndActivityDetails1;
  }

  // END, CR00165745

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICMemberActivityDetails searchICMemberActivity(
      final SearchICMemberActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICMemberActivityDetails icMemberActivityDetails = new ICMemberActivityDetails();

    // MaintainIntegratedCases manipulation variables
    final curam.core.intf.MaintainIntegratedCases maintainIntegratedCasesObj = curam.core.fact.MaintainIntegratedCasesFactory
        .newInstance();
    final IntegClientCaseActivityKey integClientCaseActivityKey = new IntegClientCaseActivityKey();
    IntegClientCaseActivityList integClientCaseActivityList;

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory
        .newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();

    // CaseHeader object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRole_eoKey.caseParticipantRoleID = key.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      key.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      key.caseID = integratedCaseKey.integratedCaseID;
    }

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    key.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Set key to read activity details
    integClientCaseActivityKey.caseID = key.caseID;
    integClientCaseActivityKey.concernRoleID = key.concernRoleID;

    // Call MaintainIntegratedCases BPO to retrieve the list of activities
    // for the case member
    integClientCaseActivityList = maintainIntegratedCasesObj
        .readAllICClientActivities(integClientCaseActivityKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
        kBufferSize * integClientCaseActivityList.dtls.size());

    // BEGIN, CR00163098, JC
    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
        .append(CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASE,
            TransactionInfo.getProgramLocale()))
        .append(kQuote).append(kCloseBracket).append(kSpace);
    // END, CR00163098, JC

    // Loop through list of activities and events
    for (int i = 0; i < integClientCaseActivityList.dtls.size(); i++) {

      // Set element details
      activityElementDetails.activityID = integClientCaseActivityList.dtls
          .item(i).activityID;
      activityElementDetails.acceptanceProvisionalInd = false;
      activityElementDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
      activityElementDetails.allDayInd = integClientCaseActivityList.dtls
          .item(i).allDayInd;
      activityElementDetails.attendeeInd = integClientCaseActivityList.dtls
          .item(i).attendeeInd;
      activityElementDetails.endDateTime = integClientCaseActivityList.dtls
          .item(i).endDateTime;
      activityElementDetails.priorityCode = integClientCaseActivityList.dtls
          .item(i).priorityCode;
      activityElementDetails.readOnlyInd = integClientCaseActivityList.dtls
          .item(i).readOnlyInd;
      activityElementDetails.recurringInd = integClientCaseActivityList.dtls
          .item(i).recurringInd;
      activityElementDetails.startDateTime = integClientCaseActivityList.dtls
          .item(i).startDateTime;
      activityElementDetails.subject = integClientCaseActivityList.dtls
          .item(i).subject;
      activityElementDetails.timeStatusCode = integClientCaseActivityList.dtls
          .item(i).timeStatusCode;

      // Parse the activity
      calendarElementData = calendarDataObj
          .parseActivity(activityElementDetails, dateTimeRangeDetails);

      // Add it to the string
      xmlString.append(calendarElementData.calendarXMLString);
    }

    // Create CURAM_CALENDAR_DATA node footer.
    //
    xmlString.append(kCuramCalendarDataFooter);

    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    icMemberActivityDetails.calendarDetails.assign(caseEventAndActivityDetails);

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = key.caseID;

    icMemberContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Read context description
    icMemberActivityDetails.contextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.caseParticipantRoleID;

    // Read menu data
    icMemberActivityDetails.menuData = getICMemberMenuData(
        caseParticipantRoleKey);

    return icMemberActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryUtility listProductDeliveryUtilityPayment(
      final ListICProductDeliveryUtilityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryUtility listICProductDeliveryUtility = new ListICProductDeliveryUtility();

    // HouseholdBudgetItem manipulation variables
    final curam.core.intf.HouseholdBudgetItem householdBudgetItemObj = curam.core.fact.HouseholdBudgetItemFactory
        .newInstance();
    final HouseholdBudgetItemCaseIDKey householdBudgetItemCaseIDKey = new HouseholdBudgetItemCaseIDKey();
    HouseholdBudgetItemDtlsList householdBudgetItemDtlsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read utility payments
    householdBudgetItemCaseIDKey.caseID = key.caseID;

    // Read list of utility payments
    householdBudgetItemDtlsList = householdBudgetItemObj
        .searchByCaseID(householdBudgetItemCaseIDKey);

    // Retrieve concernRoleID of the participant
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // Read CaseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Map concernRoleID to return object
    listICProductDeliveryUtility.concernRoleStruct.concernRoleID = caseHeaderDtls.concernRoleID;

    // Check to see if the list is populated
    if (!householdBudgetItemDtlsList.dtls.isEmpty()) {

      // variables used to retrieve rule set for case
      final curam.core.intf.CaseRulesLink caseRulesLinkObj = curam.core.fact.CaseRulesLinkFactory
          .newInstance();
      final LookupRulesForCaseKey lookupRulesForCaseKey = new LookupRulesForCaseKey();
      LookupRulesForCaseDetails lookupRulesForCaseDetails;

      // Reserve space in the return object
      listICProductDeliveryUtility.utilityList.dtls
          .ensureCapacity(householdBudgetItemDtlsList.dtls.size());

      ICProductDeliveryUtilityPaymentDetails icProductDeliveryUtilityPaymentDetails;

      for (int i = 0; i < householdBudgetItemDtlsList.dtls.size(); i++) {

        icProductDeliveryUtilityPaymentDetails = new ICProductDeliveryUtilityPaymentDetails();

        // Assign details for list item
        icProductDeliveryUtilityPaymentDetails
            .assign(householdBudgetItemDtlsList.dtls.item(i));

        if (householdBudgetItemDtlsList.dtls.item(i).rulesObjectiveID
            .length() != 0) {

          lookupRulesForCaseKey.date = householdBudgetItemDtlsList.dtls
              .item(i).startDate;
          lookupRulesForCaseKey.caseID = householdBudgetItemDtlsList.dtls
              .item(i).caseID;

          // retrieve rule set
          lookupRulesForCaseDetails = caseRulesLinkObj
              .lookupRulesForCase(lookupRulesForCaseKey);

          final String ruleSetID = lookupRulesForCaseDetails.ruleSetID;

          // read rules objective
          final curam.util.rules.RulesObjectiveResult rulesObjectiveResult = curam.util.rules.Interrule
              .getDynamicObjective(ruleSetID,
                  householdBudgetItemDtlsList.dtls.item(i).rulesObjectiveID);

          icProductDeliveryUtilityPaymentDetails.rulesObjectiveType = rulesObjectiveResult
              .getType();
        }

        // RulesObjective manipulation variables
        final curam.core.intf.Utility utilityObj = curam.core.fact.UtilityFactory
            .newInstance();
        final UtilityKey utilityKey = new UtilityKey();
        UtilityDtls utilityDtls;

        // Set Key
        utilityKey.concernRoleID = icProductDeliveryUtilityPaymentDetails.utilConcernRoleID;

        // read Details
        utilityDtls = utilityObj.read(utilityKey);

        icProductDeliveryUtilityPaymentDetails.utilityName = utilityDtls.name;
        // Add to return object
        listICProductDeliveryUtility.utilityList.dtls
            .addRef(icProductDeliveryUtilityPaymentDetails);
      }

    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryUtility.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryUtility.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryUtility;
  }

  // BEGIN, CR00189687, GD
  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains the case identifier.
   *
   * @return A list of nominees on a product delivery within an Integrated Case.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listProductDeliveryNominee1()}.
   *
   *             Returns a list of nominees on a product delivery within an
   *             integrated case.
   */
  @Override
  @Deprecated
  // END, CR00189687
  public ListICProductDeliveryNominee listProductDeliveryNominee(
      final ListICProductDeliveryNomineeKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryNominee listICProductDeliveryNominee = new ListICProductDeliveryNominee();

    // ServiceLayer CaseNominee objects
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory
        .newInstance();
    final curam.core.facade.struct.CaseNomineeDetails_fo caseNomineeDetails = new curam.core.facade.struct.CaseNomineeDetails_fo();
    final curam.core.facade.struct.CaseNomineeCaseIDKey caseNomineeCaseIDKey = new curam.core.facade.struct.CaseNomineeCaseIDKey();

    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;

    // read list from service layer into return struct
    caseNomineeDetails.caseNomineeDetailsList_bo = caseNomineeObj
        .listCaseNominee(caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Check if the list is empty
    if (!caseNomineeDetails.caseNomineeDetailsList_bo.caseNomineeDetailsList
        .isEmpty()) {

      // Reserve space in return object
      listICProductDeliveryNominee.nomineeList.dtls.ensureCapacity(
          caseNomineeDetails.caseNomineeDetailsList_bo.caseNomineeDetailsList
              .size());

      ICProductDeliveryNomineeDetails icProductDeliveryNomineeDetails;

      final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
          .newInstance();
      final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
      CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;

      for (int i = 0; i < caseNomineeDetails.caseNomineeDetailsList_bo.caseNomineeDetailsList
          .size(); i++) {

        icProductDeliveryNomineeDetails = new ICProductDeliveryNomineeDetails();

        // Assign details
        icProductDeliveryNomineeDetails.assign(
            caseNomineeDetails.caseNomineeDetailsList_bo.caseNomineeDetailsList
                .item(i));

        caseIDParticipantRoleKey.participantRoleID = caseNomineeDetails.caseNomineeDetailsList_bo.caseNomineeDetailsList
            .item(i).concernRoleID;
        caseIDParticipantRoleKey.caseID = key.caseID;

        // Reads caseParticipantRoleID
        caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
            .readCaseParticipantRoleID(caseIDParticipantRoleKey);

        // Assign caseParticipantRoleID to the return object
        icProductDeliveryNomineeDetails.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

        listICProductDeliveryNominee.nomineeList.dtls
            .addRef(icProductDeliveryNomineeDetails);
      }

    }

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Add the integrated case id as part of struct to be returned:
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    listICProductDeliveryNominee.parentCaseID = caseHeaderDtls.integratedCaseID;

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryNominee.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryNominee.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryNominee;
  }

  // BEGIN, CR00189687, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseNomineeDetailsWithVersionNoList listProductDeliveryNominee1(
      final ListICProductDeliveryNomineeKey key)
      throws AppException, InformationalException {

    // Create return object
    CaseNomineeDetailsWithVersionNoList caseNomineeDetailsWithVersionNoList = new CaseNomineeDetailsWithVersionNoList();

    // ServiceLayer CaseNominee objects
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory
        .newInstance();

    final curam.core.facade.struct.CaseNomineeCaseIDKey caseNomineeCaseIDKey = new curam.core.facade.struct.CaseNomineeCaseIDKey();

    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;

    // struct used to store unfiltered list
    CaseNomineeDetailsWithVersionNoList unfilteredCaseNomineeDetailsList = new CaseNomineeDetailsWithVersionNoList();

    // read list from service layer into unfiltered struct
    unfilteredCaseNomineeDetailsList = caseNomineeObj
        .listCaseNomineeAndVersionNo(caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // read filtered list from service layer into return struct
    caseNomineeDetailsWithVersionNoList = caseNomineeObj
        .filterCaseNomineeWithVersionNoListByCaseParticipantRole(
            caseNomineeCaseIDKey.caseNomineeCaseIDKey,
            unfilteredCaseNomineeDetailsList);

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Check if the list is empty
    if (!caseNomineeDetailsWithVersionNoList.dtls.isEmpty()) {

      final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
          .newInstance();
      final curam.core.sl.entity.struct.CaseIDParticipantRoleKey caseIDParticipantRoleKey = new curam.core.sl.entity.struct.CaseIDParticipantRoleKey();
      curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;

      for (int i = 0; i < caseNomineeDetailsWithVersionNoList.dtls
          .size(); i++) {

        caseIDParticipantRoleKey.participantRoleID = caseNomineeDetailsWithVersionNoList.dtls
            .item(i).concernRoleID;
        caseIDParticipantRoleKey.caseID = key.caseID;

        // Reads caseParticipantRoleID
        caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
            .readCaseParticipantRoleID(caseIDParticipantRoleKey);

        // Assign caseParticipantRoleID to the return object
        caseNomineeDetailsWithVersionNoList.dtls.item(
            i).caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

        if (caseNomineeDetailsWithVersionNoList.dtls.item(i).nomineeStatus
            .equals(CASENOMINEESTATUS.EXPIRED)) {
          caseNomineeDetailsWithVersionNoList.dtls.item(i).reactivateInd = true;
        } else {
          caseNomineeDetailsWithVersionNoList.dtls
              .item(i).reactivateInd = false;
        }

      }
    }

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Add the integrated case id as part of struct to be returned:
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    caseNomineeDetailsWithVersionNoList.parentCaseID = caseHeaderDtls.integratedCaseID;

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    caseNomineeDetailsWithVersionNoList.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // BEGIN, CR00305483, SSK
    if (caseHeaderDtls.integratedCaseID != 0) {
      // END, CR00305483
      // Set key to read menu data
      icProductDeliveryMenuDataKey.caseID = key.caseID;

      // Read menu data
      caseNomineeDetailsWithVersionNoList.menuData = getICProductDeliveryMenuData(
          icProductDeliveryMenuDataKey);
    }

    return caseNomineeDetailsWithVersionNoList;
  }

  // END, CR00189687

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryObjectiveAndDelPatt listProductDeliveryObjectiveAndDelPatt(
      final ListObjectiveKey key) throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryObjectiveAndDelPatt listICProductDeliveryObjectiveAndDelPatt = new ListICProductDeliveryObjectiveAndDelPatt();

    // ServiceLayer CaseNominee objects
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory
        .newInstance();
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read objective list
    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;

    // read list from service layer into return struct
    listICProductDeliveryObjectiveAndDelPatt.objectiveList = caseNomineeObj
        .listObjectiveAndDelPattern(caseNomineeCaseIDKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryObjectiveAndDelPatt.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryObjectiveAndDelPatt;

  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains the case identifier.
   *
   * @return A list of objectives on a product delivery.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listProductDeliveryObjectiveAndDelPatt()}.
   *
   *             Returns a list of objectives available on a product delivery.
   */
  @Override
  @Deprecated
  // END, CR00190939
  public ListICProductDeliveryObjective listProductDeliveryObjective(
      final ListObjectiveKey key) throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryObjective listICProductDeliveryObjective = new ListICProductDeliveryObjective();

    // ServiceLayer CaseNominee objects
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory
        .newInstance();
    final curam.core.facade.struct.CaseNomineeCaseIDKey caseNomineeCaseIDKey = new curam.core.facade.struct.CaseNomineeCaseIDKey();
    final curam.core.facade.struct.CaseNomineeObjectiveNameDetailsList caseNomineeObjectiveNameDetailsList = new curam.core.facade.struct.CaseNomineeObjectiveNameDetailsList();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;

    // Set key to read objective list
    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;

    // read list from service layer into return struct
    caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList = caseNomineeObj
        .listObjective(caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // Check if the list is empty
    if (!caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList
        .isEmpty()) {

      // Reserve space in return object
      listICProductDeliveryObjective.objectiveList.dtls.ensureCapacity(
          caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList
              .size());

      ICProductDeliveryObjectiveDetails icProductDeliveryObjectiveDetails;

      for (int i = 0; i < caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList
          .size(); i++) {

        icProductDeliveryObjectiveDetails = new ICProductDeliveryObjectiveDetails();

        // Assign details
        icProductDeliveryObjectiveDetails.assign(
            caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList
                .item(i));

        caseIDParticipantRoleKey.participantRoleID = caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList
            .item(i).concernRoleID;
        caseIDParticipantRoleKey.caseID = key.caseID;

        // Reads caseParticipantRoleID
        caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
            .readCaseParticipantRoleID(caseIDParticipantRoleKey);

        // Assign caseParticipantRoleID to the return object
        icProductDeliveryObjectiveDetails.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

        listICProductDeliveryObjective.objectiveList.dtls
            .addRef(icProductDeliveryObjectiveDetails);
      }

    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryObjective.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryObjective.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryObjective;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CreateAssessmentDeliveryDetails createAssessment(
      final curam.core.facade.struct.CreateAssessmentDeliveryKey key)
      throws AppException, InformationalException {

    // Create return object
    final CreateAssessmentDeliveryDetails createAssessmentDeliveryDetails = new CreateAssessmentDeliveryDetails();

    // Assessment Delivery manipulation variables
    final curam.core.sl.intf.AssessmentDelivery assessmentDeliveryObj = curam.core.sl.fact.AssessmentDeliveryFactory
        .newInstance();
    CreateAssessmentDeliveryResult createAssessmentDeliveryResult;
    final curam.core.sl.struct.CreateAssessmentDeliveryKey createAssessmentDeliveryKey = new curam.core.sl.struct.CreateAssessmentDeliveryKey();

    // set details for creation
    createAssessmentDeliveryKey.assign(key.dtls);

    // create AssessmentDelivery
    createAssessmentDeliveryResult = assessmentDeliveryObj
        .createAssessmentOnIC(createAssessmentDeliveryKey);

    // assign return data
    createAssessmentDeliveryDetails.dtls.assign(createAssessmentDeliveryResult);

    return createAssessmentDeliveryDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICAllCasesDetails listAllCasesForParentCase(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICAllCasesDetails listICAllCasesDetails = new ListICAllCasesDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;
    final CasesByIntegCaseIDKey casesByIntegCaseIDKey = new CasesByIntegCaseIDKey();

    casesByIntegCaseIDKey.caseID = key.caseID;

    // call service layer method
    caseAndConcernSummaryDtlsList = maintainCaseObj
        .listAllCasesByParentCaseID(casesByIntegCaseIDKey);

    // assign return data
    listICAllCasesDetails.dtls.assign(caseAndConcernSummaryDtlsList);

    return listICAllCasesDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listCaseParticipantsDetails(
      final ListMemberDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    // BEGIN, CR00078730, RF
    // We set up showCaseParticipantcluster true by default, to ensure
    // the cluster on
    // VerificationApplication_createVerificationItemProvision.uim
    // is visible all the time. If showCaseParticipantCluster is false the
    // cluster will be hidden (only if we access by the participant
    // screens).
    listMemberDetails.showCaseParticipantCluster = true;
    if (key.caseID == 0) {
      listMemberDetails.showCaseParticipantCluster = false;
    } else {
      // END, CR00078730

      // IntegratedCase manipulation variables
      final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

      CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
      MemberDetails memberDetails;

      // CaseParticipantRole manipulation variables
      final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
          .newInstance();

      // BEGIN, CR00001117, CM
      // Case Header manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      final CaseKey caseKey = new CaseKey();

      // set case key
      caseKey.caseID = key.caseID;

      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = key.caseID;
        servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }

      // END, CR00001117

      ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

      final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

      // Set key to read list of client roles
      viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

      // Read the list of case participant roles
      viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
          .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

      // Reserve space in participantList
      listICClientRoleDetails.participantList
          .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

      // Set the return object
      for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

        caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

        caseParticipantRoleFullDetails
            .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

        listICClientRoleDetails.participantList
            .addRef(caseParticipantRoleFullDetails);

      }

      // Reserve space in memberDetailsList
      listMemberDetails.memberDetailsList.dtls
          .ensureCapacity(listICClientRoleDetails.participantList.size());

      for (int i = 0; i < listICClientRoleDetails.participantList.size(); i++) {

        if (!listICClientRoleDetails.participantList.item(i).recordStatus
            .equals(curam.codetable.RECORDSTATUS.CANCELLED)) {

          memberDetails = new MemberDetails();

          caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

          caseParticipantRoleFullDetails.participantRoleID = listICClientRoleDetails.participantList
              .item(i).participantRoleID;
          caseParticipantRoleFullDetails.name = listICClientRoleDetails.participantList
              .item(i).name;
          // BEGIN, CR00446316, YF
          caseParticipantRoleFullDetails.nameAndAgeOpt = listICClientRoleDetails.participantList
              .item(i).nameAndAgeOpt;
          // END, CR00446316, YF
          caseParticipantRoleFullDetails.caseParticipantRoleID = listICClientRoleDetails.participantList
              .item(i).caseParticipantRoleID;

          memberDetails.assign(caseParticipantRoleFullDetails);

          // Add to return object
          listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
        }

      }
    }
    return listMemberDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ParticipantHomePageName resolveParticipantHome(
      final CaseParticipantRoleIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();

    // MaintainAdminIntegratedCase manipulation variable
    final curam.core.intf.MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj = curam.core.fact.MaintainAdminIntegratedCaseFactory
        .newInstance();

    final ICParticipantHomePageKey iCParticipantHomePageKey = new ICParticipantHomePageKey();

    ICParticipantHomePageName iCParticipantHomePageName;

    // Assign key to read participant home page name
    iCParticipantHomePageKey.caseParticipantRoleID = key.caseParticipantRoleID;

    // Call MaintainAdminIntegratedCase BPO to read participant home page
    // name
    // and assign to return object
    iCParticipantHomePageName = maintainAdminIntegratedCaseObj
        .getICParticipantHomePageName(iCParticipantHomePageKey);

    participantHomePageName.participantHomePageName = iCParticipantHomePageName.participantHomePageName;

    participantHomePageName.participantIconName = iCParticipantHomePageName.participantIconName;

    // return details.
    return participantHomePageName;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICEmployerDetails readEmployerDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // return details
    final ReadICEmployerDetails readICEmployerDetails = new ReadICEmployerDetails();

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Employer Home Page object.
    final curam.core.intf.EmployerHomePage employerHomePageObj = curam.core.fact.EmployerHomePageFactory
        .newInstance();

    // Maintain Concern Role Details object and key.
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory
        .newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Struct returned from Employer Home Page read.
    ReadEmployerResult readEmployerResult;

    // Get the Concern Role ID from the key.
    maintainConcernRoleKey.concernRoleID = readICDetailsKey.concernRoleID;

    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read the Employer Home Page details.
    readEmployerResult = employerHomePageObj.read(concernRoleHomePageKey);

    maintainConcernRoleDetailsObj.readEmployer(maintainConcernRoleKey);
    // assign details to the return object
    readICEmployerDetails.details.assign(readEmployerResult.details);
    readICEmployerDetails.employerDetails.assign(readEmployerResult.details);

    // Return back concern role id and type to link to participant home
    // page.
    readICEmployerDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICEmployerDetails.details.caseID = readICDetailsKey.caseID;

    // read employer concernRoleType
    readICEmployerDetails.details.concernRoleType = CONCERNROLETYPE.EMPLOYER;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICEmployerDetails.employerMenuData.menuData = icMemberMenuDataDetails.menuData;

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICEmployerDetails.employerContextDescription.description = iCContextDescriptionDetails.description;

    return readICEmployerDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICInformationProviderDetails readInformationProviderDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Return details
    final ReadICInformationProviderDetails readICInformationProviderDetails = new ReadICInformationProviderDetails();

    // Create an instance of InfoProviderHomePage.
    final curam.core.intf.InfoProviderHomePage infoProviderHomePageObj = curam.core.fact.InfoProviderHomePageFactory
        .newInstance();

    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read an ReadInfoProviderResult from the previously created
    // InfoProviderHomePage using the concernRoleHomePageKey attribute of
    // the
    // ReadInformationProviderHomeKey Object passed as a parameter.
    final ReadInfoProviderResult readInfoProviderResult = infoProviderHomePageObj
        .read(concernRoleHomePageKey);

    // assign details to the return object
    readICInformationProviderDetails.details
        .assign(readInfoProviderResult.details);

    // Return back concern role id and type to link to participant home
    // page.
    readICInformationProviderDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICInformationProviderDetails.details.caseID = readICDetailsKey.caseID;

    // read information provider concernRoleType
    readICInformationProviderDetails.details.concernRoleType = CONCERNROLETYPE.INFORMATIONPROVIDER;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICInformationProviderDetails.infoProviderMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICInformationProviderDetails.infoProviderContextDescription.description = iCContextDescriptionDetails.description;

    return readICInformationProviderDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICProductProviderDetails readProductProviderDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // details to be returned
    final ReadICProductProviderDetails readICProductProviderDetails = new ReadICProductProviderDetails();

    // Product Provider Home Page object.
    final curam.core.intf.ProductProviderHomePage productProviderHomePageObj = curam.core.fact.ProductProviderHomePageFactory
        .newInstance();

    // Maintain Concern Role Details object and key.
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Struct returned from Product Provider Home Page read.
    ReadProdProviderResult readProductProviderResult;

    // Get the Concern Role ID from the key.
    maintainConcernRoleKey.concernRoleID = readICDetailsKey.concernRoleID;

    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read the Product Provider Home Page details.
    readProductProviderResult = productProviderHomePageObj
        .read(concernRoleHomePageKey);

    // assign details to the return object
    readICProductProviderDetails.details
        .assign(readProductProviderResult.details);

    // Return back concern role id and type to link to participant home
    // page.
    readICProductProviderDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICProductProviderDetails.details.caseID = readICDetailsKey.caseID;

    // read product provider concernRoleType
    readICProductProviderDetails.details.concernRoleType = CONCERNROLETYPE.PRODUCTPROVIDER;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICProductProviderDetails.productProviderMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICProductProviderDetails.productProviderContextDescription.description = iCContextDescriptionDetails.description;

    // return details
    return readICProductProviderDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICRepresentativeDetails readRepresentativeDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // details to be returned
    final ReadICRepresentativeDetails readICRepresentativeDetails = new ReadICRepresentativeDetails();

    final curam.core.facade.struct.RepresentativeKey representativeKey = new curam.core.facade.struct.RepresentativeKey();

    // service layer representative object
    final curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory
        .newInstance();

    // RepresentativeHomePageDetails struct
    final RepresentativeHomePageDetails representativeHomePageDetails = new RepresentativeHomePageDetails();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    representativeKey.representativeKey.representativeID = readICDetailsKey.concernRoleID;

    // BEGIN, CR00272990, KRK
    // call service layer method
    representativeHomePageDetails.representativeDetails = representativeObj
        .viewRepresentativeDetailsForIC(representativeKey.representativeKey);
    // END, CR00272990
    readICRepresentativeDetails.details
        .assign(representativeHomePageDetails.representativeDetails);
    readICRepresentativeDetails.details.assign(
        representativeHomePageDetails.representativeDetails.representativeDetails);

    // Return back case ID
    readICRepresentativeDetails.details.caseID = readICDetailsKey.caseID;

    // read representative concernRoleType
    readICRepresentativeDetails.details.concernRoleType = CONCERNROLETYPE.REPRESENTATIVE;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICRepresentativeDetails.representativeMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICRepresentativeDetails.representativeContextdescription.description = iCContextDescriptionDetails.description;

    return readICRepresentativeDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICServiceSupplierDetails readServiceSupplierDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Return details
    final ReadICServiceSupplierDetails readICServiceSupplierDetails = new ReadICServiceSupplierDetails();

    // Service Supplier Home Page object
    final curam.core.intf.ServiceSupplierHomePage serviceSupplierHomePageObj = curam.core.fact.ServiceSupplierHomePageFactory
        .newInstance();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Struct returned from ServiceSupplierHomePage read
    ServiceSupplierHomePageReadResult serviceSupplierHomePageReadResult;

    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Perform Home Page read
    serviceSupplierHomePageReadResult = serviceSupplierHomePageObj
        .read(concernRoleHomePageKey);

    // assign details to the return object
    readICServiceSupplierDetails.details
        .assign(serviceSupplierHomePageReadResult.servSuppHomePageDetails);

    // Return back concern role id and type to link to participant home
    // page.
    readICServiceSupplierDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICServiceSupplierDetails.details.caseID = readICDetailsKey.caseID;

    // read service supplier concernRoleType
    readICServiceSupplierDetails.details.concernRoleType = CONCERNROLETYPE.SERVICESUPPLIER;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICServiceSupplierDetails.serviceSupplierMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICServiceSupplierDetails.serviceSupplierContextDescription.description = iCContextDescriptionDetails.description;

    return readICServiceSupplierDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICUtilityDetails readUtilityDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // return details
    final ReadICUtilityDetails readICUtilityDetails = new ReadICUtilityDetails();

    // Utility homepage maintenance object
    final curam.core.intf.UtilityHomePage utilityHomePageObj = curam.core.fact.UtilityHomePageFactory
        .newInstance();

    // Concern role details maintenance object
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory
        .newInstance();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // ConcernRoleHomePageKey object
    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read the utility homepage details
    final UtilityHomePageReadResult utilityHomePageReadResult = utilityHomePageObj
        .read(concernRoleHomePageKey);

    // assign details to the return object
    readICUtilityDetails.details
        .assign(utilityHomePageReadResult.utilityHomePageDetails);

    // Read the concern role details
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = readICDetailsKey.concernRoleID;
    final UtilityDetails utilityDetails = maintainConcernRoleDetailsObj
        .readUtility(maintainConcernRoleKey);

    // assign details to the return object.
    readICUtilityDetails.utilityDetails.assign(utilityDetails);

    // Return back concern role id and type to link to participant home
    // page.
    readICUtilityDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICUtilityDetails.details.caseID = readICDetailsKey.caseID;

    // read utility concernRoleType
    readICUtilityDetails.details.concernRoleType = CONCERNROLETYPE.UTILITY;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICUtilityDetails.utilityMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICUtilityDetails.utilityContextDescription.description = iCContextDescriptionDetails.description;

    // return details
    return readICUtilityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICPersonDetails readPersonDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Person Home Page object.
    final curam.core.intf.PersonHomePage personHomePageObj = curam.core.fact.PersonHomePageFactory
        .newInstance();

    // Maintain Person object
    final curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory
        .newInstance();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Details to be returned.
    final ReadICPersonDetails readICPersonDetails = new ReadICPersonDetails();

    // Struct returned from PersonHomePage read.
    ReadPersonResult readPersonResult;

    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read the Person Home Page details
    readPersonResult = personHomePageObj.read(concernRoleHomePageKey);

    PersonFurtherDetails personFurtherDetails;

    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read the Person Further Details
    personFurtherDetails = maintainPersonObj
        .readFurtherDetails(maintainConcernRoleKey);

    // Assign details to the return object
    readICPersonDetails.details.assign(personFurtherDetails);

    readICPersonDetails.details.firstForename = readPersonResult.details.firstForename;
    readICPersonDetails.details.otherForename = readPersonResult.details.otherForename;
    readICPersonDetails.details.surname = readPersonResult.details.surname;
    readICPersonDetails.details.gender = readPersonResult.details.sex;
    readICPersonDetails.details.dateOfBirth = readPersonResult.details.dateOfBirth;
    readICPersonDetails.details.dateOfDeath = readPersonResult.details.dateOfDeath;
    readICPersonDetails.details.registrationDate = readPersonResult.details.registrationDate;
    readICPersonDetails.details.preferredLanguage = readPersonResult.details.preferredLanguage;
    readICPersonDetails.details.nationalityCode = readPersonResult.details.nationality;
    readICPersonDetails.details.placeOfBirth = readPersonResult.details.birthPlace;
    readICPersonDetails.details.phoneAreaCode = readPersonResult.details.phoneAreaCode;
    readICPersonDetails.details.phoneCountryCode = readPersonResult.details.phoneCountryCode;
    readICPersonDetails.details.phoneExtension = readPersonResult.details.phoneExtension;
    readICPersonDetails.details.phoneNumber = readPersonResult.details.phoneNumber;
    readICPersonDetails.details.formattedAddressData = readPersonResult.details.formattedAddressData;
    readICPersonDetails.details.fullName = readPersonResult.details.fullName;
    readICPersonDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    readICPersonDetails.details.concernRoleType = readPersonResult.details.concernRoleType;

    // Return back concern role id and type to link to participant home
    // page.
    readICPersonDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICPersonDetails.details.caseID = readICDetailsKey.caseID;

    // read person concernRoleType
    readICPersonDetails.details.concernRoleType = CONCERNROLETYPE.PERSON;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICPersonDetails.personMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICPersonDetails.personContextDescription.description = iCContextDescriptionDetails.description;

    // return details
    return readICPersonDetails;

  }

  // ____________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICPersonDetails readProspectPersonDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // ProspectPerson Home Page object.
    final curam.core.sl.intf.ProspectPersonHome prospectPersonHomeObj = curam.core.sl.fact.ProspectPersonHomeFactory
        .newInstance();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    readICDetailsKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Details to be returned.
    final ReadICPersonDetails readICPersonDetails = new ReadICPersonDetails();

    // Struct returned from ProspectPersonHomePage read.
    ProspectPersonHomeDetails readProspectPersonResult;

    final ConcernRoleHomePageKey concernRoleHomePageKey = new ConcernRoleHomePageKey();

    concernRoleHomePageKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Read the Prospect Person Home Page details
    readProspectPersonResult = prospectPersonHomeObj
        .read(concernRoleHomePageKey);

    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = readICDetailsKey.concernRoleID;

    // Assign details to the return object

    readICPersonDetails.details.firstForename = readProspectPersonResult.dtls.firstForename;
    readICPersonDetails.details.otherForename = readProspectPersonResult.dtls.otherForename;
    readICPersonDetails.details.surname = readProspectPersonResult.dtls.surname;
    readICPersonDetails.details.gender = readProspectPersonResult.dtls.gender;
    readICPersonDetails.details.dateOfBirth = readProspectPersonResult.dtls.dateOfBirth;
    readICPersonDetails.details.dateOfDeath = readProspectPersonResult.dtls.dateOfDeath;
    readICPersonDetails.details.registrationDate = readProspectPersonResult.dtls.registrationDate;
    readICPersonDetails.details.preferredLanguage = readProspectPersonResult.dtls.preferredLanguage;
    readICPersonDetails.details.nationalityCode = readProspectPersonResult.dtls.nationalityCode;
    readICPersonDetails.details.placeOfBirth = readProspectPersonResult.dtls.placeOfBirth;
    readICPersonDetails.details.phoneAreaCode = readProspectPersonResult.dtls.phoneAreaCode;
    readICPersonDetails.details.phoneCountryCode = readProspectPersonResult.dtls.phoneCountryCode;
    readICPersonDetails.details.phoneExtension = readProspectPersonResult.dtls.phoneExtension;
    readICPersonDetails.details.phoneNumber = readProspectPersonResult.dtls.phoneNumber;
    readICPersonDetails.details.formattedAddressData = readProspectPersonResult.dtls.formattedAddressData;
    readICPersonDetails.details.fullName = readProspectPersonResult.dtls.fullName;
    readICPersonDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    readICPersonDetails.details.concernRoleType = readProspectPersonResult.dtls.concernRoleType;

    // Return back concern role id and type to link to participant home
    // page.
    readICPersonDetails.details.concernRoleID = readICDetailsKey.concernRoleID;
    // Return back case ID
    readICPersonDetails.details.caseID = readICDetailsKey.caseID;

    // read person concernRoleType
    readICPersonDetails.details.concernRoleType = CONCERNROLETYPE.PROSPECTPERSON;

    ICMemberMenuDataDetails icMemberMenuDataDetails;

    // Read menu data
    icMemberMenuDataDetails = getICMemberMenuData(key);

    // populate the menu data
    readICPersonDetails.personMenuData.menuData = icMemberMenuDataDetails.menuData;

    // ICContextDescriptionKey facade object
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.caseID = readICDetailsKey.caseID;
    icMemberContextDescriptionKey.concernRoleID = readICDetailsKey.concernRoleID;

    ICMemberContextDescriptionDetails iCContextDescriptionDetails;

    // Read context description
    iCContextDescriptionDetails = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // populate the context description
    readICPersonDetails.personContextDescription.description = iCContextDescriptionDetails.description;

    // return details
    return readICPersonDetails;
  }

  // ____________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public NewActivityDetails_fo createRecurringrActivity(
      final RecurringrActivityDetails details)
      throws AppException, InformationalException {

    // return details
    final NewActivityDetails_fo newActivityDetails = new NewActivityDetails_fo();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Activity maintenance object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory
        .newInstance();

    // Return objects
    CreateUserActivityIgnoreReturnDetails createUserActivityIgnoreReturnDetails;
    CreateUserActivityWarnConflictResult createUserActivityWarnConflictResult;

    // System user maintenance object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory
        .newInstance();

    // Create MaintainActivityDetails from
    // MaintainRecurringUserActivityDetails
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // CaseHeader object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = details.recurringDetails.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      details.recurringDetails.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      details.recurringDetails.caseID = integratedCaseKey.integratedCaseID;
    }

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    details.recurringDetails.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    maintainActivityDetails.assign(details.recurringDetails);

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // Create and setup user activity key
    final UserActivityKey userActivityKey = new UserActivityKey();

    userActivityKey.userName = systemUserDtls.userName;

    // Create empty AttendeeNameIDDetails instance
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();

    if (details.recurringDetails.frequencyPattern.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .throwWithLookup(
              new AppException(
                  curam.message.BPOACTIVITY.ERR_ACTIVITY_FV_FREQUENCY_PATTERN),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    // Set recurrence start date
    maintainActivityDetails.recurrenceStartDate = new curam.util.type.Date(
        details.recurringDetails.startDateTime);

    // Create the user activity by calling the relevant method according to
    // the value for ignoreConflictInd
    if (details.recurringDetails.ignoreConflictInd) {

      createUserActivityIgnoreReturnDetails = maintainUserActivityObj
          .createUserActivityIgnoreConflict(userActivityKey,
              maintainActivityDetails, attendeeNameIDDetails);
      newActivityDetails.activityID = createUserActivityIgnoreReturnDetails.activityKey.activityID;

    } else {

      createUserActivityWarnConflictResult = maintainUserActivityObj
          .createUserActivityWarnConflict(userActivityKey,
              maintainActivityDetails, attendeeNameIDDetails);
      newActivityDetails.activityID = createUserActivityWarnConflictResult.activityKey.activityID;

      // if there are conflicts throw an error to report them to the user
      if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

        final AppException e = new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

        e.arg(
            createUserActivityWarnConflictResult.activityConflictDetails.conflictString);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .throwWithLookup(e,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
      }
    }

    // Return details
    return newActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public NewActivityDetails_fo createStandardUserActivity(
      final StandardActivityDetails details)
      throws AppException, InformationalException {

    // return details
    final NewActivityDetails_fo newActivityDetails = new NewActivityDetails_fo();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // User Activity Maintenance Object and key
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory
        .newInstance();
    final UserActivityKey userActivityKey = new UserActivityKey();

    // Create an instance of MaintainActivityDetails
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = details.activityDetails.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // get the case's parent case ID - the Integrated case ID
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails
    // structure
    if (integratedCaseKey.integratedCaseID == 0) {

      details.activityDetails.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    } else {

      details.activityDetails.caseID = integratedCaseKey.integratedCaseID;
    }

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    details.activityDetails.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Create an instance of AttendeeNameIDDetails
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();

    // Activity details returned
    CreateUserActivityIgnoreReturnDetails createUserActivityIgnoreReturnDetails;
    CreateUserActivityWarnConflictResult createUserActivityWarnConflictResult;

    // System User Details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory
        .newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // Assign system user details to key
    userActivityKey.userName = systemUserDtls.userName;

    // Get Activity details from key
    maintainActivityDetails.assign(details.activityDetails);

    // Set frequency pattern to blank
    maintainActivityDetails.frequencyPattern = kFrequencyPattern;

    // Assign system user details to maintainActivityDetails
    maintainActivityDetails.userName = systemUserDtls.userName;

    // Call relevant create method depending on ignoreConflictInd value
    if (details.activityDetails.ignoreConflictInd) {
      createUserActivityIgnoreReturnDetails = maintainUserActivityObj
          .createUserActivityIgnoreConflict(userActivityKey,
              maintainActivityDetails, attendeeNameIDDetails);

      newActivityDetails.activityID = createUserActivityIgnoreReturnDetails.activityKey.activityID;

    } else {

      createUserActivityWarnConflictResult = maintainUserActivityObj
          .createUserActivityWarnConflict(userActivityKey,
              maintainActivityDetails, attendeeNameIDDetails);

      newActivityDetails.activityID = createUserActivityWarnConflictResult.activityKey.activityID;

      // if there are conflicts throw an error to report them to the user
      if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

        final AppException e = new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

        e.arg(
            createUserActivityWarnConflictResult.activityConflictDetails.conflictString);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .throwWithLookup(e,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

    }

    // return details
    return newActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListProductsForCategoryDetails listProductsForCategory(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListProductsForCategoryDetails listProductsForCategoryDetails = new ListProductsForCategoryDetails();

    // ProductCategory manipulation variables
    final curam.core.intf.ProductCategory productCategoryObj = curam.core.fact.ProductCategoryFactory
        .newInstance();
    final ReadAllProductsInCategoryKey readAllProductsInCategoryKey = new ReadAllProductsInCategoryKey();
    ProductCategoryReadmultiDetails1List productCategoryReadmultiDetails1List;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final ListProductsForCategoryKey listProductsForCategoryKey = new ListProductsForCategoryKey();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID details to the
    // listProductsForCategoryKey
    // structure

    listProductsForCategoryKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Set key to read caseHeader
    caseHeaderKey.caseID = listProductsForCategoryKey.caseID;

    // Read caseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read products in category
    readAllProductsInCategoryKey.categoryCode = caseHeaderDtls.integratedCaseType;

    // Read products in the specified category
    productCategoryReadmultiDetails1List = productCategoryObj
        .searchProductsByCategory(readAllProductsInCategoryKey);

    // Check to see if the list is populated
    if (!productCategoryReadmultiDetails1List.dtls.isEmpty()) {

      // Product manipulation variables
      final curam.core.intf.Product productObj = curam.core.fact.ProductFactory
          .newInstance();
      ProductNameStructRef productNameStructRef;
      final ProductKey productKey = new ProductKey();

      ProductsForCategoryDetails productsForCategoryDetails;

      // Iterate through the list of product identifiers and read the
      // product name for each one
      for (int i = 0; i < productCategoryReadmultiDetails1List.dtls
          .size(); i++) {

        productsForCategoryDetails = new ProductsForCategoryDetails();

        // Set key to read the product name
        productKey.productID = productCategoryReadmultiDetails1List.dtls
            .item(i).productID;

        // Read product name
        productNameStructRef = productObj.readProductName(productKey);

        // Set product details
        productsForCategoryDetails.productID = productKey.productID;
        productsForCategoryDetails.productName = productNameStructRef.name;

        // Add details to return object
        listProductsForCategoryDetails.dtls.addRef(productsForCategoryDetails);
      }

    }

    return listProductsForCategoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListCasesByConcernRoleDetails listAllCases(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListCasesByConcernRoleDetails listCasesByConcernRoleDetails = new ListCasesByConcernRoleDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    final CasesByConcernRoleIDKey casesByConcernRoleIDKey = new CasesByConcernRoleIDKey();

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final SearchCasesByConcernRoleKey searchCasesByConcernRoleKey = new SearchCasesByConcernRoleKey();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID details to the
    // listProductsForCategoryKey

    searchCasesByConcernRoleKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Get details from key
    casesByConcernRoleIDKey.assign(searchCasesByConcernRoleKey);

    // Set key to display all cases
    casesByConcernRoleIDKey.statusCode = curam.codetable.CASESTATUSSEARCH.ALL;

    // Call getCasesByConcernRoleID operation
    // BEGIN, CR00221180, ZV
    final CaseHeaderConcernRoleDetailsList1 caseHeaderConcernRoleDetailsList = maintainCaseObj
        .getCasesByConcernRoleID1(casesByConcernRoleIDKey);

    // END, CR00221180

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listCasesByConcernRoleDetails.dtls
          .ensureCapacity(caseHeaderConcernRoleDetailsList.dtls.size());

      CasesByConcernRoleDetails casesByConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        casesByConcernRoleDetails = new CasesByConcernRoleDetails();

        // Assign details
        casesByConcernRoleDetails
            .assign(caseHeaderConcernRoleDetailsList.dtls.item(i));

        // BEGIN, CR00049218, GM
        String productTypeDesc = CuramConst.gkEmpty;
        // END, CR00049218

        final String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls
            .item(i).caseTypeCode;

        // BEGIN, CR00139241, GYH
        // Get the description for the type of the product
        if (caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
            || caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

          // ProductDelivery manipulation variables
          final ProductDelivery productDeliveryObj = ProductDeliveryFactory
              .newInstance();
          final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
          ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();

          // populate key for read
          productDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          // read back productType for the case
          productDeliveryTypeDetails = productDeliveryObj
              .readProductType(productDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
              productDeliveryTypeDetails.productType,
              TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

          // CaseHeader manipulation variables
          CaseHeaderDtls caseHeaderDtls;

          // Set key to read caseHeader
          final curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory
              .newInstance();
          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
              caseHeaderDtls.integratedCaseType,
              TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

          // Screening manipulation variables
          final curam.core.sl.entity.intf.Screening screeningObj = curam.core.sl.entity.fact.ScreeningFactory
              .newInstance();
          final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
          ScreeningName screeningName;

          // Set key to read read Screening entity
          caseKeyStruct.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          // Read Screening
          screeningName = screeningObj.readName(caseKeyStruct);

          productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
              screeningName.name, TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

          // assessmentDelivery manipulation variables
          final curam.core.sl.entity.intf.AssessmentDelivery assessmentDeliveryObj = curam.core.sl.entity.fact.AssessmentDeliveryFactory
              .newInstance();
          final AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();
          AssessmentTypeDetails assessmentTypeDetails;

          // Set key to read Assessment type
          assessmentDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          // Read AssessmentType
          assessmentTypeDetails = assessmentDeliveryObj
              .readAssessmentType(assessmentDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
              assessmentTypeDetails.assessmentType,
              TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

          // ServicePlan manipulation variables
          final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
              .newInstance();
          final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
          ServicePlanTypeStruct servicePlanTypeStruct = new ServicePlanTypeStruct();

          // populate key for read
          servicePlanDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          // read back servicePlanType
          servicePlanTypeStruct = servicePlanDeliveryObj
              .readServicePlanType(servicePlanDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(
              curam.codetable.SERVICEPLANTYPE.TABLENAME,
              servicePlanTypeStruct.servicePlanType,
              TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.ISSUE)) {

          // IssueDelivery manipulation variables
          final IssueDelivery issueDeliveryObj = curam.core.sl.entity.fact.IssueDeliveryFactory
              .newInstance();
          final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
          IssueTypeCode issueTypeCode = new IssueTypeCode();

          // populate key for read
          issueDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          // read back issueTyoe
          issueTypeCode = issueDeliveryObj.readIssueType(issueDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(
              curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
              issueTypeCode.issueType, TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.INVESTIGATIONCASE)) {

          // InvestigationDelivery manipulation variables
          final curam.core.sl.entity.intf.InvestigationDelivery investigationDelivery = curam.core.sl.entity.fact.InvestigationDeliveryFactory
              .newInstance();
          final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
          InvestigationTypeCode investigationTypeCode = new InvestigationTypeCode();

          // populate key for read
          investigationDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls
              .item(i).caseID;

          // read back issueTyoe
          investigationTypeCode = investigationDelivery
              .readInvestigationType(investigationDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(
              curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
              investigationTypeCode.investigationType,
              TransactionInfo.getProgramLocale());
        }
        // END, CR00139241

        // Product Description cannot be empty
        if (productTypeDesc == null || productTypeDesc.length() == 0) {

          // BEGIN, CR00163098, JC
          productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
              caseTypeCode, TransactionInfo.getProgramLocale());
          // END, CR00163098, JC
        }

        casesByConcernRoleDetails.productTypeDesc = productTypeDesc;

        // Add to return object
        listCasesByConcernRoleDetails.dtls.addRef(casesByConcernRoleDetails);
      }

    }

    return listCasesByConcernRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listCaseParticipantsDetailsUsingCaseParticipantRoleID(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    // IntegratedCase manipulation variables
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

    curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    MemberDetails memberDetails;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    final ListMemberDetailsKey listMemberDetailsKey = new ListMemberDetailsKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the
    // listICMemberTaskDetails
    // structure
    listMemberDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = listMemberDetailsKey.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    // Set the return object
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails
          .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

      listICClientRoleDetails.participantList
          .addRef(caseParticipantRoleFullDetails);

    }

    // Reserve space in memberDetailsList
    listMemberDetails.memberDetailsList.dtls
        .ensureCapacity(listICClientRoleDetails.participantList.size());

    for (int i = 0; i < listICClientRoleDetails.participantList.size(); i++) {

      if (!listICClientRoleDetails.participantList.item(i).recordStatus
          .equals(curam.codetable.RECORDSTATUS.CANCELLED)) {

        memberDetails = new MemberDetails();

        caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

        caseParticipantRoleFullDetails.participantRoleID = listICClientRoleDetails.participantList
            .item(i).participantRoleID;
        caseParticipantRoleFullDetails.name = listICClientRoleDetails.participantList
            .item(i).name;

        caseParticipantRoleFullDetails.caseParticipantRoleID = listICClientRoleDetails.participantList
            .item(i).caseParticipantRoleID;

        memberDetails.assign(caseParticipantRoleFullDetails);

        // Add to return object
        listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
      }

    }

    return listMemberDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICClientRoleDetails listActiveCaseMembers(
      final curam.core.sl.struct.CaseIDKey key)
      throws AppException, InformationalException {

    final ListICClientKey listICClientKey = new ListICClientKey();

    listICClientKey.caseID = key.caseID;
    listICClientKey.showOnlyActive = true;

    // BEGIN, CR00225060, ZV
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

    listICClientRoleDetails.assign(listCaseMembers1(listICClientKey));

    return listICClientRoleDetails;
    // END, CR00225060

  }

  // BEGIN, CR00262895, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listActiveCaseMembersForCommunicationsFilter(
      final curam.core.sl.struct.CaseIDKey key)
      throws AppException, InformationalException {

    final CaseID caseIDKey = new CaseID();

    caseIDKey.dtls.caseID = key.caseID;

    final ListMemberDetails listMemberDetails = getCaseParticipantsAgeConcernRoleID(
        caseIDKey);

    final MemberDetails memberDetails = new MemberDetails();

    memberDetails.caseParticipantRoleID = 0;
    memberDetails.name = BPOCOMMUNICATION.INF_COMM_ALL_CASEMEMBERS
        .getMessageText(TransactionInfo.getProgramLocale());
    memberDetails.participantRoleID = 0;
    // Don't display the special cautions
    memberDetails.specialCautionInd = false;

    listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);

    return listMemberDetails;
  }

  // END, CR00262895

  // BEGIN CR00124178, GBA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ViewCaseParticipantRoleDetailsList listActiveCaseMembersByCaseParticipantRoleID(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read caseID
    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // key to read list of client roles
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;

    // Read the list of case participant roles
    final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    return viewCaseParticipantRoleDetailsList;

  }

  // END CR00124178

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListDeliveryPatternHistoryDetails listProductDeliveryInfoDetailsForCase(
      final curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey key)
      throws AppException, InformationalException {

    // Manipulation variables
    final ListDeliveryPatternHistoryDetails listDeliveryPatternHistoryDetails = new ListDeliveryPatternHistoryDetails();
    final curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey productDeliveryPatternByCaseIDKey = new curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey();
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory
        .newInstance();
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set the caseID
    productDeliveryPatternByCaseIDKey.productDeliveryPatternByCaseIDKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read back the list of delivery patterns.
    listDeliveryPatternHistoryDetails.productDeliveryPatternInfoDetailsList = caseNomineeObj
        .listProductDeliveryPatternDetailsForCase(
            productDeliveryPatternByCaseIDKey);

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read the product delivery context description
    listDeliveryPatternHistoryDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set the key to read the menu data
    icProductDeliveryMenuDataKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read the menu data
    listDeliveryPatternHistoryDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listDeliveryPatternHistoryDetails;

  }

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListDeliveryPatternHistoryDetails listCurrentDeliveryPattern(
      final curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey key)
      throws AppException, InformationalException {

    // Manipulation variables
    final ListDeliveryPatternHistoryDetails listDeliveryPatternHistoryDetails = new ListDeliveryPatternHistoryDetails();
    final curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey deliveryPatternKey = new curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey();
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory
        .newInstance();

    final ICProductDeliveryContextDescriptionKey contextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set the caseID
    deliveryPatternKey.productDeliveryPatternByCaseIDKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read back the list of delivery patterns.
    listDeliveryPatternHistoryDetails.productDeliveryPatternInfoDetailsList = caseNomineeObj
        .listCurrentDeliveryPatternForCase(deliveryPatternKey);

    // Set key to read context description
    contextDescriptionKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read the product delivery context description
    listDeliveryPatternHistoryDetails.contextDescription = getICProductDeliveryContextDescription(
        contextDescriptionKey);

    // Set the key to read the menu data
    icProductDeliveryMenuDataKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read the menu data
    listDeliveryPatternHistoryDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listDeliveryPatternHistoryDetails;

  }

  // END, CR00190939

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDecision listActiveProductDeliveryDecision(
      final curam.core.facade.struct.ListICProductDeliveryDecisionKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ListICProductDeliveryDecision listICProductDeliveryDecision = new curam.core.facade.struct.ListICProductDeliveryDecision();

    // MaintainCaseDecision manipulation variables
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory
        .newInstance();

    final curam.core.struct.MaintainCaseDecisionCaseIDKey maintainCaseDecisionCaseIDKey = new curam.core.struct.MaintainCaseDecisionCaseIDKey();

    // curam.core.facade.struct.ICProductDeliveryContextDescriptionKey
    // object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new curam.core.facade.struct.ICProductDeliveryContextDescriptionKey();

    // curam.core.facade.struct.ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new curam.core.facade.struct.ICProductDeliveryMenuDataKey();

    // Assign key details
    maintainCaseDecisionCaseIDKey.caseID = key.caseID;

    // Read case decisions
    listICProductDeliveryDecision.assign(maintainCaseDecisionObj
        .getActiveCaseDecisions(maintainCaseDecisionCaseIDKey));

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDecision.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDecision.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryDecision;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberTaskDetails listMemberTasks(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberTaskDetails listMemberTaskDetails = new ListMemberTaskDetails();

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory
        .newInstance();
    final curam.core.sl.entity.struct.SearchByConcernRoleAndCaseKey searchByConcernRoleAndCaseKey = new curam.core.sl.entity.struct.SearchByConcernRoleAndCaseKey();

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey = new CaseParticipantRoleKey();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Context description manipulation variables
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read caseParticipantRole entity
    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRole_eoKey);

    // set key to read context description
    icMemberContextDescriptionKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    icMemberContextDescriptionKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Set key to retrieve list of tasks
    searchByConcernRoleAndCaseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    searchByConcernRoleAndCaseKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Call BPO to retrieve list of tasks
    listMemberTaskDetails.detailsList = workAllocationTaskObj
        .listCaseMemberTasks(searchByConcernRoleAndCaseKey);

    // Iterate through the list and set the reservedBy flag
    for (int i = 0; i < listMemberTaskDetails.detailsList.dtls.dtls
        .size(); i++) {

      if (listMemberTaskDetails.detailsList.dtls.dtls.item(i).reservedBy
          .length() > 0) {

        listMemberTaskDetails.detailsList.dtls.dtls
            .item(i).reservedByExistsInd = true;
      }

    }

    // Set key to read caseParticipantRole
    caseParticipantRole_eoKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read context description
    listMemberTaskDetails.description = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // Set key to read menu data
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Read menu data
    listMemberTaskDetails.menuData = getICMemberMenuData(
        caseParticipantRoleKey);

    // Set key to read CaseHeader for integratedCaseID
    caseKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    final IntegratedCaseKey integratedCaseKey = caseHeaderObj
        .readIntegratedCaseIDByCaseID(caseKey);

    // Check if integratedCaseID is not zero use it
    if (integratedCaseKey.integratedCaseID != 0) {

      listMemberTaskDetails.details.caseID = integratedCaseKey.integratedCaseID;

    } else {

      listMemberTaskDetails.details.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    }

    return listMemberTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   *          Key to read IC benefit underpayment home page details.
   *
   * @return IC benefit underpayment home page details.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #readICBenefitUnderpmtHomePageDetails1()}.
   *
   *             Reads Integrated Case benefit underpayment home page details.
   */
  @Override
  @Deprecated
  public ICBenefitUnderpmtHomePageDetails readICBenefitUnderpmtHomePageDetails(
      final ReadICProductHomePageKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICBenefitUnderpmtHomePageDetails icBenefitUnderpmtHomePageDetails = new ICBenefitUnderpmtHomePageDetails();

    // BEGIN, CR00220971, ZV
    icBenefitUnderpmtHomePageDetails
        .assign(readICBenefitUnderpmtHomePageDetails1(key));
    // END, CR00220971

    return icBenefitUnderpmtHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDeductionDetails listActiveProductDeliveryDeduction(
      final ListICProductDeliveryDeductionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryDeductionDetails listICProductDeliveryDeductionDetails = new ListICProductDeliveryDeductionDetails();

    // MaintainDeductionItemAssistant manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory
        .newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to retrieve the list of existing deductions on the case
    deductionItemCaseID.caseID = key.caseID;

    // Call MaintainDeductionItemAssistant BPO to retrieve the list of
    // deductions on the case and assign to return object
    caseDeductionItemDtlsList = maintainDeductionItemsObj
        .listActiveDeductions(deductionItemCaseID);

    // Check to see if the list is populated
    if (!caseDeductionItemDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryDeductionDetails.dtlsList
          .ensureCapacity(caseDeductionItemDtlsList.dtls.size());

      // Iterate through the list
      for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

        // Initialize details struct on every iteration
        final DeductionListDetails deductionListDetails = new DeductionListDetails();

        // Assign case deduction item details to return details struct
        deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

        // Set the deduction type (category) which can be used to
        // display the
        // deduction type as an icon on the list page
        if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
        } else if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
        } else {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
        }

        // Add struct to list to be returned
        listICProductDeliveryDeductionDetails.dtlsList
            .addRef(deductionListDetails);

        // Set the concernRoleID in return object
        listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = caseDeductionItemDtlsList.dtls
            .item(0).concernRoleID;
      }

    } else {

      // CaseHeader manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

      // Set key to read caseHeader
      caseHeaderKey.caseID = key.caseID;

      // Read caseHeader
      readParticipantRoleIDDetails = caseHeaderObj
          .readParticipantRoleID(caseHeaderKey);

      // Set the concernRoleID in return object
      listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDeductionDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDeductionDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryDeductionDetails;
  }

  // BEGIN, CR00243194, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CurrentDeductionsForProductDeliveryList listCurrentProductDeliveryDeduction(
      final ListICProductDeliveryDeductionKey key)
      throws AppException, InformationalException {

    // Create return object
    final CurrentDeductionsForProductDeliveryList currentDeductionsForProductDeliveryList = new CurrentDeductionsForProductDeliveryList();

    // MaintainDeductionItemAssistant manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory
        .newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    // Set key to retrieve the list of existing deductions on the case
    deductionItemCaseID.caseID = key.caseID;

    // Call MaintainDeductionItemAssistant BPO to retrieve the list of
    // deductions on the case and assign to return object
    caseDeductionItemDtlsList = maintainDeductionItemsObj
        .listCurrentDeductions(deductionItemCaseID);

    // Check to see if the list is populated
    if (!caseDeductionItemDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      currentDeductionsForProductDeliveryList.dtlsList
          .ensureCapacity(caseDeductionItemDtlsList.dtls.size());

      DeductionItemDetail deductionItemDetails;

      // Iterate through the list
      for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

        // Initialize details struct on every iteration
        deductionItemDetails = new DeductionItemDetail();
        // Assign case deduction item details to return details struct
        deductionItemDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

        // Set an indicator to specify if the current deduction is
        // active
        if (deductionItemDetails.businessStatus.equals(BUSINESSSTATUS.ACTIVE)) {
          deductionItemDetails.activeInd = true;
        } else {
          deductionItemDetails.activeInd = false;
        }

        // Add struct to list to be returned
        currentDeductionsForProductDeliveryList.dtlsList
            .addRef(deductionItemDetails);

        /*
         * // Set the concernRoleID in return object
         * currentDeductionsForProductDeliveryList .concernRole.concernRoleID =
         * caseDeductionItemDtlsList.dtls .item(0).concernRoleID;
         */
      }

    }

    /*
     * else {
     *
     * // CaseHeader manipulation variables final curam.core.intf.CaseHeader
     * caseHeaderObj = curam.core.fact. CaseHeaderFactory .newInstance(); final
     * CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
     * ReadParticipantRoleIDDetails readParticipantRoleIDDetails;
     *
     * // Set key to read caseHeader caseHeaderKey.caseID = key.caseID;
     *
     * // Read caseHeader readParticipantRoleIDDetails = caseHeaderObj
     * .readParticipantRoleID(caseHeaderKey);
     *
     * // Set the concernRoleID in return object
     * currentDeductionsForProductDeliveryList.concernRoleDtls.concernRoleID =
     * readParticipantRoleIDDetails.concernRoleID; }
     */

    return currentDeductionsForProductDeliveryList;
  }

  // END, CR00243194

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDeductionDetails listProductDeliveryDeductionHistory(
      final ListICProductDeliveryDeductionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryDeductionDetails listICProductDeliveryDeductionDetails = new ListICProductDeliveryDeductionDetails();

    // MaintainDeductionItemAssistant manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory
        .newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to retrieve the list of existing deductions on the case
    deductionItemCaseID.caseID = key.caseID;

    // Call MaintainDeductionItemAssistant BPO to retrieve the list of
    // deductions on the case and assign to return object
    caseDeductionItemDtlsList = maintainDeductionItemsObj
        .listDeductionHistory(deductionItemCaseID);

    // Check to see if the list is populated
    if (!caseDeductionItemDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryDeductionDetails.dtlsList
          .ensureCapacity(caseDeductionItemDtlsList.dtls.size());

      // Iterate through the list
      for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

        // Initialize details struct on every iteration
        final DeductionListDetails deductionListDetails = new DeductionListDetails();

        // Assign case deduction item details to return details struct
        deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

        // Set the deduction type
        if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
        } else if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
        } else {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
        }

        // Add struct to list to be returned
        listICProductDeliveryDeductionDetails.dtlsList
            .addRef(deductionListDetails);

        // Set the concernRoleID in return object
        listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = caseDeductionItemDtlsList.dtls
            .item(0).concernRoleID;
      }

    } else {

      // CaseHeader manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

      // Set key to read caseHeader
      caseHeaderKey.caseID = key.caseID;

      // Read caseHeader
      readParticipantRoleIDDetails = caseHeaderObj
          .readParticipantRoleID(caseHeaderKey);

      // Set the concernRoleID in return object
      listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDeductionDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDeductionDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryDeductionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDeductionDetails listProductDeliveryAppliedUnappliedDeduction(
      final ListICProductDeliveryDeductionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryDeductionDetails listICProductDeliveryDeductionDetails = new ListICProductDeliveryDeductionDetails();

    // MaintainDeductionItemAssistant manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory
        .newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to retrieve the list of existing deductions on the case
    deductionItemCaseID.caseID = key.caseID;

    // Call MaintainDeductionItemAssistant BPO to retrieve the list of
    // deductions on the case and assign to return object
    caseDeductionItemDtlsList = maintainDeductionItemsObj
        .listAppliedAndUnappliedDeductions(deductionItemCaseID);

    // Check to see if the list is populated
    if (!caseDeductionItemDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryDeductionDetails.dtlsList
          .ensureCapacity(caseDeductionItemDtlsList.dtls.size());

      // Iterate through the list
      for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

        // Initialize details struct on every iteration
        final DeductionListDetails deductionListDetails = new DeductionListDetails();

        // Assign case deduction item details to return details struct
        deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

        // Set the deduction type (category) which can be used to
        // display the
        // deduction type as an icon on the list page
        if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
        } else if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
        } else {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
        }

        // Add struct to list to be returned
        listICProductDeliveryDeductionDetails.dtlsList
            .addRef(deductionListDetails);

        // Set the concernRoleID in return object
        listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = caseDeductionItemDtlsList.dtls
            .item(0).concernRoleID;
      }

    } else {

      // CaseHeader manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

      // Set key to read caseHeader
      caseHeaderKey.caseID = key.caseID;

      // Read caseHeader
      readParticipantRoleIDDetails = caseHeaderObj
          .readParticipantRoleID(caseHeaderKey);

      // Set the concernRoleID in return object
      listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDeductionDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDeductionDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryDeductionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDeductionDetails listProductDeliveryThirdPartyDeduction(
      final ListICProductDeliveryDeductionKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryDeductionDetails listICProductDeliveryDeductionDetails = new ListICProductDeliveryDeductionDetails();

    // MaintainDeductionItemAssistant manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory
        .newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to retrieve the list of existing deductions on the case
    deductionItemCaseID.caseID = key.caseID;

    // Call MaintainDeductionItemAssistant BPO to retrieve the list of
    // deductions on the case and assign to return object
    caseDeductionItemDtlsList = maintainDeductionItemsObj
        .listThirdPartyDeductions(deductionItemCaseID);

    // Check to see if the list is populated
    if (!caseDeductionItemDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICProductDeliveryDeductionDetails.dtlsList
          .ensureCapacity(caseDeductionItemDtlsList.dtls.size());

      // Iterate through the list
      for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

        // Initialize details struct on every iteration
        final DeductionListDetails deductionListDetails = new DeductionListDetails();

        // Assign case deduction item details to return details struct
        deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

        // Set the deduction type (category) which can be used to
        // display the
        // deduction type as an icon on the list page
        if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
        } else if (caseDeductionItemDtlsList.dtls.item(i).category
            .equals(DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
        } else {
          deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
        }

        // Add struct to list to be returned
        listICProductDeliveryDeductionDetails.dtlsList
            .addRef(deductionListDetails);

        // Set the concernRoleID in return object
        listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = caseDeductionItemDtlsList.dtls
            .item(0).concernRoleID;
      }

    } else {

      // CaseHeader manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

      // Set key to read caseHeader
      caseHeaderKey.caseID = key.caseID;

      // Read caseHeader
      readParticipantRoleIDDetails = caseHeaderObj
          .readParticipantRoleID(caseHeaderKey);

      // Set the concernRoleID in return object
      listICProductDeliveryDeductionDetails.concernRoleStruct.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryDeductionDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryDeductionDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryDeductionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryInstructionDetails listProductDeliveryFinInstruction(
      final ListICProductDeliveryFinancialsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryInstructionDetails listICProductDeliveryInstructionDetails = new ListICProductDeliveryInstructionDetails();

    // ViewRepaymentCaseAccount manipulation variables
    final curam.core.intf.ViewRepaymentCaseAccount viewRepaymentCaseAccountObj = curam.core.fact.ViewRepaymentCaseAccountFactory
        .newInstance();
    final RepaymentCaseAccountIdentifier repaymentCaseAccountIdentifier = new RepaymentCaseAccountIdentifier();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details to read the list of financials
    repaymentCaseAccountIdentifier.assign(key);

    // Call ViewRepaymentCaseAccount BPO to retrieve the list of financials
    listICProductDeliveryInstructionDetails.instructList = viewRepaymentCaseAccountObj
        .viewRepaymentCaseFinInstruction(repaymentCaseAccountIdentifier);

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryInstructionDetails.productDeliveryContextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryInstructionDetails.icPDMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryInstructionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Execute reflection on the Argument Class and Method, using argument
   * parameters.
   *
   * @param className
   *          Class name to instantiate
   * @param methodName
   *          Method to be run
   * @param arguments
   *          Arguments to be passed to Method
   * @param parameterTypes
   *          Class Types of Parameters used
   *
   * @return Invoked method will return object which can be case by cast method.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  protected Object performReflection(final String className,
      final String methodName, final Object[] arguments,
      final Class[] parameterTypes)
      throws AppException, InformationalException {

    Class cls = null;

    try {
      // Load the class
      cls = Class.forName(className);

      // Create a method for the static newInstance constructor
      // BEGIN, CR00023323, SK
      final Method constructorMethod = cls
          .getMethod(ReflectionConst.kNewInstance);
      // END, CR00023323
      final Object classObj = constructorMethod.invoke(cls);

      // Define the method
      // BEGIN, CR00142355, CD
      final Method method = classObj.getClass().getMethod(methodName,
          parameterTypes);

      // END, CR00142355

      // Now invoke the method
      return method.invoke(classObj, arguments);

    } catch (final IllegalAccessException e) {// ignore - biz methods MUST
      // be public
    } catch (final ClassNotFoundException e) {

      final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

      ae.arg(className);
      ae.arg(getClass().toString());
      // BEGIN, CR00163098, JC
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      throw new RuntimeException(ae);

    } catch (final NoSuchMethodException e) {

      final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

      ae.arg(className);

      // BEGIN, CR00049218, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00049218

      // BEGIN, CR00163098, JC
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      throw new RuntimeException(ae);

    } catch (final IllegalArgumentException e) {

      final AppException ae = new AppException(
          BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);

      // BEGIN, CR00049218, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00049218

      ae.arg(className);
      // BEGIN, CR00163098, JC
      ae.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      throw new RuntimeException(ae);

    } catch (final InvocationTargetException e) {

      final AppException exc = new AppException(
          BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

      exc.arg(e.getTargetException().getMessage());
      throw exc;
    }

    return null;
  }

  // BEGIN, CR00029525, CM
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public IssueCaseDtlsList listProductDeliveryIssue(
      final CaseHeaderKey caseHeaderKey)
      throws AppException, InformationalException {

    // Return struct
    final IssueCaseDtlsList issueCaseDtlsList = new IssueCaseDtlsList();

    // BEGIN, CR00031196, KH
    // Retrieve the list of issue delivery cases
    issueCaseDtlsList.dtlsList = IssueDeliveryFactory.newInstance()
        .listIssueForProductDelivery(caseHeaderKey);
    // END, CR00031196

    // Set the Context description key
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    icProductDeliveryContextDescriptionKey.caseID = caseHeaderKey.caseID;

    // Set context description
    issueCaseDtlsList.description.description = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey).description;

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = caseHeaderKey.caseID;

    // Read menu data
    issueCaseDtlsList.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    // BEGIN, CR00058145, CSH
    // Read the concernRoleID from the product delivery case header
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails = CaseHeaderFactory
        .newInstance().readParticipantRoleID(caseHeaderKey);

    // Find the caseParticipantRoleID based on the caseID and
    // particpantRoleID
    final CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey = new CaseIDAndParticipantRoleIDKey();

    caseIDAndParticipantRoleIDKey.caseID = caseHeaderKey.caseID;
    caseIDAndParticipantRoleIDKey.participantRoleID = readParticipantRoleIDDetails.concernRoleID;

    final CaseParticipantRoleIDStruct caseParticipantRoleIDStruct = CaseParticipantRoleFactory
        .newInstance().readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(
            caseIDAndParticipantRoleIDKey);

    // This sets which member will be used if an issue is created from the
    // product delivery list issue page
    issueCaseDtlsList.caseParticipantRoleID = caseParticipantRoleIDStruct.caseParticipantRoleID;
    // END, CR00058145

    return issueCaseDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public IssueCaseDtlsList listIssue(final CaseHeaderKey caseHeaderKey)
      throws AppException, InformationalException {

    // Return struct
    final IssueCaseDtlsList issueCaseDtlsList = new IssueCaseDtlsList();

    // BEGIN, CR00031196, KH
    // Retrieve the list of issue delivery cases
    issueCaseDtlsList.dtlsList = IssueDeliveryFactory.newInstance()
        .listIssueForIntegratedCase(caseHeaderKey);
    // END, CR00031196

    // Set the Context description key
    final ICContextDescriptionKey_fo icContextDescription = new ICContextDescriptionKey_fo();

    icContextDescription.caseID = caseHeaderKey.caseID;

    // Set context description
    issueCaseDtlsList.description.description = getIntegratedCaseContextDescription(
        icContextDescription).description;

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = caseHeaderKey.caseID;

    // BEGIN, CR00182936, CL
    // Read menu data and assign to return object
    issueCaseDtlsList.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);
    // END, CR00182936

    // BEGIN, CR00058145, CSH
    // Set the adminIntegratedCaseID for use if a new issue is created from
    // the list page
    issueCaseDtlsList.adminIntegratedCaseID = IssueDeliveryFactory.newInstance()
        .getAdminIntegratedCaseIDForIssue(caseHeaderKey).adminIntegratedCaseID;
    // END, CR00058145

    return issueCaseDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public IssueDeliveryForICMemberDtlsList listMemberIssue(
      final CaseParticipantRoleKey caseParticipantRoleKey)
      throws AppException, InformationalException {

    // Return struct
    final IssueDeliveryForICMemberDtlsList issueDeliveryForICMemberDtlsList = new IssueDeliveryForICMemberDtlsList();

    // BEGIN, CR00031196, KH
    // Retrieve the list of issue delivery cases
    issueDeliveryForICMemberDtlsList.dtlsList = IssueDeliveryFactory
        .newInstance().listIssueForCaseParticipant(caseParticipantRoleKey);
    // END, CR00031196

    // MaintainCase manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails;

    // BEGIN, CR00058145, CSH
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseKey caseKey = new CaseKey();
    IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();

    // END, CR00058145

    // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseIDCaseRefAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDcaseRefandParticipantID(caseParticipantRoleKey);

    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    icMemberContextDescriptionKey.concernRoleID = caseIDCaseRefAndParticipantRoleIDDetails.participantRoleID;

    icMemberContextDescriptionKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;

    // Set context description
    issueDeliveryForICMemberDtlsList.description.description = getICMemberContextDescription(
        icMemberContextDescriptionKey).description;

    // CaseParticipantRoleKey object
    final curam.core.facade.struct.CaseParticipantRoleKey key = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Set key to read menu data
    key.dtls.caseParticipantRoleID = caseParticipantRoleKey.caseParticipantRoleID;

    // BEGIN, CR00182936, CL
    // Read menu data
    // Integrated Case manipulation variables
    issueDeliveryForICMemberDtlsList.icMemberMenuData = getICMemberMenuData(
        key);
    // END, CR00182936

    // BEGIN, CR00058145, CSH
    // As we can only create issues against the integrated case from the
    // member list page, we need to check the type of case id passed in
    // from the client and ensure that we have the integrated case id

    // Get the case ID for the case the issue was raised against
    caseKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;

    // Check if it is an integratedCaseID and if not read back the correct
    // id
    integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);

    if (integratedCaseKey.integratedCaseID == 0) {

      // This means caseID we have is from integrated case header
      caseHeaderKey.caseID = caseKey.caseID;
    } else {

      // Set the case header key to the integrated case header key
      caseHeaderKey.caseID = integratedCaseKey.integratedCaseID;
    }

    // Set the adminIntegratedCaseID using the integrated case id
    issueDeliveryForICMemberDtlsList.adminIntegratedCaseID = IssueDeliveryFactory
        .newInstance()
        .getAdminIntegratedCaseIDForIssue(caseHeaderKey).adminIntegratedCaseID;

    // Set the integrated case ID on the return struct
    issueDeliveryForICMemberDtlsList.caseID = caseHeaderKey.caseID;
    // END, CR00058145

    return issueDeliveryForICMemberDtlsList;
  }

  // END, CR00029525

  // BEGIN, CR00066651, PCAL
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void createICEvidenceLink(final ICEvidenceLinkDetails dtls)
      throws AppException, InformationalException {

    ICEvidenceLinkFactory.newInstance().create(dtls.details);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void createEvidenceMetadata(final ICEvidenceMetadataDetails details)
      throws AppException, InformationalException {

    // If no integrated case is specified, call the service layer insert
    // operation
    if (details.adminIntegratedCaseID == 0) {
      EvidenceMetadataFactory.newInstance().insert(details.details);
    } else {
      // Else, call the service layer insert and create link operation
      final AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();

      adminIntegratedCaseKey.adminIntegratedCaseID = details.adminIntegratedCaseID;

      EvidenceMetadataFactory.newInstance().insertAndCreateICEvidenceLink(
          details.details, adminIntegratedCaseKey);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void deleteICEvidenceLink(final ICEvidenceLinkAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // Call the service layer remove operation
    ICEvidenceLinkFactory.newInstance().remove(key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceMetadataDetailsList listCurrentActiveEvidenceMetadata(
      final AdminIntegratedCaseKey key)
      throws AppException, InformationalException {

    // Create return object
    final EvidenceMetadataDetailsList evidenceMetadataDetailsList = new EvidenceMetadataDetailsList();

    // Call the service layer listICActive operation
    evidenceMetadataDetailsList.list = EvidenceMetadataFactory.newInstance()
        .listActive(key);

    return evidenceMetadataDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICEvidenceTypeDetails listICEvidenceLink(
      final AdminIntegratedCaseKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICEvidenceTypeDetails icEvidenceTypeDetails = new ICEvidenceTypeDetails();

    // Call the service layer list operation
    icEvidenceTypeDetails.list = ICEvidenceLinkFactory.newInstance()
        .listByAdminIntegratedCaseID(key);

    return icEvidenceTypeDetails;
  }

  // END, CR00066651

  // ___________________________________________________________________________
  /**
   * This method is to initialize registrar variables for the external adapter
   * This method will throw an AppException if the adapter registrars list
   * contains names not found in the system.
   *
   * @throws AppException
   *           (BPOBROADCASTTRIGGER.ERR_REGISTRAR_ISSUE) if there was an issue
   *           in the creation of the trigger.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public static void initializeBroadcastTrigger()
      throws AppException, InformationalException {

    // Get the value of the broadcast trigger registrars environment
    // variable

    String registrarsString = Configuration
        .getProperty(EnvVars.ERP_EXTERNAL_ADAPTER_REGISTRARS_LIST);

    // BEGIN, CR00090166, NP
    if (registrarsString == null) {
      registrarsString = EnvVars.ERP_EXTERNAL_ADAPTER_REGISTRARS_LIST_DEFAULT;
    }
    if (registrarsString.length() != 0) {
      // END, CR00090166
      // Get comma-separated list of registrar factory class names
      final String registrarFactoryNames[] = registrarsString
          .split(CuramConst.gkComma);

      // For each registrar factor name create an instance of it and add
      // it the
      // broadcastTriggerInterfaces array
      for (int i = 0; i < registrarFactoryNames.length; i++) {

        final String registrarFactoryName = registrarFactoryNames[i];

        try {
          Class.forName(registrarFactoryName);

        } catch (final Exception e) {

          final AppException ae = new AppException(
              BPOBROADCASTTRIGGER.ERR_REGISTRAR_ISSUE);

          // BEGIN, CR00155683, GYH
          ae.initCause(e);
          // END, CR00155683
          throw ae.arg(registrarFactoryName);

        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedInvestigationListDetails listInvestigation(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final IntegratedInvestigationListDetails integratedInvestigationListDetails = new IntegratedInvestigationListDetails();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    integratedInvestigationListDetails.list = curam.core.sl.fact.InvestigationDeliveryFactory
        .newInstance().listInvestigationByRelatedCase(key);

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    integratedInvestigationListDetails.contextDtls = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    integratedInvestigationListDetails.menuDtls = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return integratedInvestigationListDetails;
  }

  // BEGIN, CR00113516, SD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryAttachmentList listInvestigationDeliveryAttachment(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryAttachmentList icInvestigationDeliveryAttachmentList = new ICInvestigationDeliveryAttachmentList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // MaintainAttachment manipulation variables
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory
        .newInstance();
    final AttachmentCaseID attachmentCaseID = new AttachmentCaseID();
    curam.core.struct.AttachmentDetailsList attachmentDetailsList;

    // Set key to read the list of attachment
    attachmentCaseID.caseID = key.caseID;

    // Call MaintainAttachment BPO to retrieve the list of attachments
    attachmentDetailsList = maintainAttachmentObj
        .readCaseAttachments(attachmentCaseID);

    // Check to see if the list is populated
    if (!attachmentDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      icInvestigationDeliveryAttachmentList.dtlsList.dtls
          .ensureCapacity(attachmentDetailsList.dtls.size());

      // Assign details to return object
      icInvestigationDeliveryAttachmentList.dtlsList
          .assign(attachmentDetailsList);
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryAttachmentList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryAttachmentList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryAttachmentList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryClientRoleList listInvestigationDeliveryClientRole(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create the return object
    final ICInvestigationDeliveryClientRoleList icInvestigationDeliveryClientRoleList = new ICInvestigationDeliveryClientRoleList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
        .newInstance();

    // Assign key details
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read case participant role details
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseParticipantRoleList(viewCaseParticipantRole_boKey);

    // Reserve space in caseParticipantList
    icInvestigationDeliveryClientRoleList.dtlsList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      final curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails
          .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

      // Add the integrated case id as part of struct to be returned
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      caseParticipantRoleFullDetails.parentCaseID = caseHeaderDtls.integratedCaseID;

      icInvestigationDeliveryClientRoleList.dtlsList
          .addRef(caseParticipantRoleFullDetails);
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryClientRoleList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryClientRoleList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryClientRoleList;
  }

  // BEGIN, CR00119574 , MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryClientRoleList listInvestigationDeliveryCaseMember(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    // Reuse the client role list struct as it contains identical values
    final ICInvestigationDeliveryClientRoleList iCInvestigationDeliveryClientRoleList = new ICInvestigationDeliveryClientRoleList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    iCInvestigationDeliveryClientRoleList.dtlsList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      if (viewCaseParticipantRoleDetailsList.dtls.item(i).recordStatus
          .equals(RECORDSTATUS.NORMAL)) {
        iCInvestigationDeliveryClientRoleList.dtlsList
            .addRef(viewCaseParticipantRoleDetailsList.dtls.item(i));
      }
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    iCInvestigationDeliveryClientRoleList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    iCInvestigationDeliveryClientRoleList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return iCInvestigationDeliveryClientRoleList;
  }

  // END, CR00119574

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ICInvestigationDeliveryCommunicationList listInvestigationDeliveryCommunication(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryCommunicationList icInvestigationDeliveryCommunicationList = new ICInvestigationDeliveryCommunicationList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory
        .newInstance();

    // Call Communications BPO to retrieve the list of
    // communications
    final CommunicationKey communicationKey = new CommunicationKey();

    communicationKey.caseID = key.caseID;

    icInvestigationDeliveryCommunicationList.dtlsList = communicationObj
        .listCommunication(communicationKey);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryCommunicationList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryCommunicationList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryCommunicationList;
  }

  // BEGIN, CR00165745, PDN
  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link Case#searchInvestigationEventAndActivity1()}.
   *
   *             Returns data representing case events and activities for an
   *             Investigation Delivery on an Integrated Case.
   */
  @Override
  @Deprecated
  public ICInvestigationEventAndActivityDetails searchInvestigationEventAndActivity(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICInvestigationEventAndActivityDetails icInvestigationEventAndActivityDetails = new ICInvestigationEventAndActivityDetails();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ViewCaseEvents manipulation variables
    final curam.core.facade.intf.InvestigationDelivery investigationFacadeObj = curam.core.facade.fact.InvestigationDeliveryFactory
        .newInstance();

    icInvestigationEventAndActivityDetails.dtls = investigationFacadeObj
        .searchInvestigationDeliveryEventAndActivity(key);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationEventAndActivityDetails.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    caseHeaderKey.caseID = key.caseID;

    icInvestigationEventAndActivityDetails.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(caseHeaderKey);

    return icInvestigationEventAndActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationEventAndActivityDetails1 searchInvestigationEventAndActivity1(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICInvestigationEventAndActivityDetails1 icInvestigationEventAndActivityDetails1 = new ICInvestigationEventAndActivityDetails1();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ViewCaseEvents manipulation variables
    final curam.core.facade.intf.InvestigationDelivery investigationFacadeObj = curam.core.facade.fact.InvestigationDeliveryFactory
        .newInstance();

    icInvestigationEventAndActivityDetails1.dtls = investigationFacadeObj
        .searchInvestigationDeliveryEventAndActivity1(key);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationEventAndActivityDetails1.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    caseHeaderKey.caseID = key.caseID;

    icInvestigationEventAndActivityDetails1.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(caseHeaderKey);

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      icInvestigationEventAndActivityDetails1.dtls.isCPMInstalled = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      icInvestigationEventAndActivityDetails1.dtls.isAppealsInstalled = true;
    }

    return icInvestigationEventAndActivityDetails1;
  }

  // END, CR00165745

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryMilestoneList listInvestigationUncompletedMilestone(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryMilestoneList icInvestigationDeliveryMilestoneList = new ICInvestigationDeliveryMilestoneList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // Milestone manipulation variables
    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory
        .newInstance();

    icInvestigationDeliveryMilestoneList.dtlsList.dtls = milestoneDeliveryObj
        .listUncompletedMilestoneDeliveries(key);

    // BEGIN, CR00148981, SAI
    for (int i = 0; i < icInvestigationDeliveryMilestoneList.dtlsList.dtls.dtlsList.dtls
        .size(); i++) {

      final MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

      milestoneDeliveryKey.milestoneDeliveryID = icInvestigationDeliveryMilestoneList.dtlsList.dtls.dtlsList.dtls
          .item(i).milestoneDeliveryID;

      final curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory
          .newInstance();

      final CheckForWaiverIndicators checkForWaiverIndicators = ((curam.core.facade.impl.ProductDelivery) productDelivery)
          .readWaiverIndicatorDetails(milestoneDeliveryKey);

      icInvestigationDeliveryMilestoneList.dtlsList.waiverIndList
          .addRef(checkForWaiverIndicators);
    }
    // END, CR00148981

    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryMilestoneList.dtlsList.description.description = InvestigationDeliveryFactory
        .newInstance().getInvestigationDeliveryContextDescription(
            investigationDeliveryKey).description;

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryMilestoneList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryMilestoneList;
  }

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ICInvestigationDeliveryNoteList listInvestigationDeliveryNote(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryNoteList icInvestigationDeliveryNoteList = new ICInvestigationDeliveryNoteList();

    final ICInvestigationDeliveryNoteList1 icInvestigationDeliveryNoteList1 = listInvestigationDeliveryNote1(
        key);

    icInvestigationDeliveryNoteList.assign(icInvestigationDeliveryNoteList1);

    return icInvestigationDeliveryNoteList;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryNoteList1 listInvestigationDeliveryNote1(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryNoteList1 icInvestigationDeliveryNoteList = new ICInvestigationDeliveryNoteList1();
    final CaseKey caseKey = new CaseKey();
    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    // CaseNote manipulation variables
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory
        .newInstance();
    final curam.core.sl.struct.CaseKey caseSLKey = new curam.core.sl.struct.CaseKey();

    CaseNoteList1 caseNoteList;

    // Set key to read the list of notes
    caseSLKey.key.caseID = key.caseID;
    // Call CaseNotes BPO to retrieve the list of notes
    caseNoteList = caseNoteObj.list1(caseSLKey);
    // Check to see if the list if populated
    if (!caseNoteList.details.isEmpty()) {

      // Reserve space in the return object
      icInvestigationDeliveryNoteList.dtlsList.dtls
          .ensureCapacity(caseNoteList.details.size());

      // ICProductDeliveryNoteDetails object
      ICProductDeliveryNoteDetails1 icProductDeliveryNoteDetails;

      // Assign details to return object
      for (int i = 0; i < caseNoteList.details.size(); i++) {

        icProductDeliveryNoteDetails = new ICProductDeliveryNoteDetails1();

        // Assign note details
        icProductDeliveryNoteDetails.assign(caseNoteList.details.item(i));

        // Add details to the return objects
        icInvestigationDeliveryNoteList.dtlsList.dtls
            .addRef(icProductDeliveryNoteDetails);
      }

    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryNoteList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryNoteList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryNoteList;
  }

  // END, CR00231506

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryRelatedCaseList listInvestigationDeliveryRelatedCase(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryRelatedCaseList icInvestigationDeliveryRelatedCaseList = new ICInvestigationDeliveryRelatedCaseList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // MaintainRelatedCases manipulation variables
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory
        .newInstance();
    final GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // Assign key details to retrieve list of related cases
    getRelatedCasesKey.caseID = key.caseID;

    // Call MaintainRelatedCases BPO to retrieve the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj
        .getRelatedCases(getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      icInvestigationDeliveryRelatedCaseList.dtlsList
          .ensureCapacity(getRelatedCasesList.dtls.size());

      // CaseHeader object
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory
          .newInstance();
      CaseTypeCode caseTypeCode = new CaseTypeCode();
      final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();

      for (int i = 0; i < getRelatedCasesList.dtls.size(); i++) {

        final ICProductDeliveryCaseRelationshipDetails icProductDeliveryCaseRelationshipDetails = new ICProductDeliveryCaseRelationshipDetails();

        caseKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

        caseIDAndTypeCodeKey.caseID = getRelatedCasesList.dtls
            .item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        final RelatedCaseProductType relatedCaseProductType = maintainRelatedCasesObj
            .getRelatedCaseProductType(caseIDAndTypeCodeKey);

        getRelatedCasesList.dtls.item(
            i).relatedCaseProductType = relatedCaseProductType.relatedCaseProductType;

        // BEGIN, CR00427963, KRK
        getRelatedCasesList.dtls.item(
            i).relatedCaseNameOpt = relatedCaseProductType.relatedCaseNameOpt;
        icProductDeliveryCaseRelationshipDetails.relatedCaseNameOpt = getRelatedCasesList.dtls
            .item(i).relatedCaseNameOpt;
        // END, CR00427963

        icProductDeliveryCaseRelationshipDetails.caseID = getRelatedCasesList.dtls
            .item(i).caseID;
        icProductDeliveryCaseRelationshipDetails.caseRelationshipID = getRelatedCasesList.dtls
            .item(i).caseRelationshipID;
        icProductDeliveryCaseRelationshipDetails.caseTypeCode = getRelatedCasesList.dtls
            .item(i).caseTypeCode;
        icProductDeliveryCaseRelationshipDetails.endDate = getRelatedCasesList.dtls
            .item(i).endDate;
        icProductDeliveryCaseRelationshipDetails.relatedCaseID = getRelatedCasesList.dtls
            .item(i).relatedCaseID;
        icProductDeliveryCaseRelationshipDetails.relatedCaseProductType = getRelatedCasesList.dtls
            .item(i).relatedCaseProductType;
        icProductDeliveryCaseRelationshipDetails.relatedCaseReference = getRelatedCasesList.dtls
            .item(i).relatedCaseReference;
        icProductDeliveryCaseRelationshipDetails.startDate = getRelatedCasesList.dtls
            .item(i).startDate;
        icProductDeliveryCaseRelationshipDetails.typeCode = getRelatedCasesList.dtls
            .item(i).typeCode;
        icProductDeliveryCaseRelationshipDetails.statusCode = getRelatedCasesList.dtls
            .item(i).statusCode;

        // Assign details to return object
        icInvestigationDeliveryRelatedCaseList.dtlsList
            .addRef(icProductDeliveryCaseRelationshipDetails);
      }

    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryRelatedCaseList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryRelatedCaseList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryRelatedCaseList;
  }

  // BEGIN, CR00162569, PDN
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ICInvestigationDeliveryStatusHistoryList listInvestigationDeliveryStatusHistory(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final ICInvestigationDeliveryStatusHistoryList icInvestigationDeliveryStatusHistoryList = new ICInvestigationDeliveryStatusHistoryList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // ProductDeliveryHome manipulation variables, can be used for
    // investigation deliveries also
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory
        .newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();

    // Set key to read case status history details
    caseStatusHistoryKey.caseID = key.caseID;

    // BEGIN, CR00164637, PDN
    // Users entity variables

    // Read case status history details and assign to output object
    final CaseStatusHistoryDetailsList caseStatusHistoryDetailsList = productDeliveryHomeObj
        .getCaseStatusHistory(caseStatusHistoryKey);

    for (int i = 0; i < caseStatusHistoryDetailsList.dtls.size(); i++) {

      final ICProductDeliveryStatusHistoryDetails icProductDeliveryStatusHistoryDetails = new ICProductDeliveryStatusHistoryDetails();

      icProductDeliveryStatusHistoryDetails.caseStatusID = caseStatusHistoryDetailsList.dtls
          .item(i).caseStatusID;
      icProductDeliveryStatusHistoryDetails.endDate = caseStatusHistoryDetailsList.dtls
          .item(i).endDate;
      icProductDeliveryStatusHistoryDetails.reasonCode = caseStatusHistoryDetailsList.dtls
          .item(i).reasonCode;
      icProductDeliveryStatusHistoryDetails.startDate = caseStatusHistoryDetailsList.dtls
          .item(i).startDate;
      icProductDeliveryStatusHistoryDetails.statusCode = caseStatusHistoryDetailsList.dtls
          .item(i).statusCode;

      icInvestigationDeliveryStatusHistoryList.dtlsList
          .addRef(icProductDeliveryStatusHistoryDetails);
    }
    // END, CR00164637
    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryStatusHistoryList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryStatusHistoryList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    // Return the status history list
    return icInvestigationDeliveryStatusHistoryList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryStatusHistoryList1 listInvestigationDeliveryStatusHistory1(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final ICInvestigationDeliveryStatusHistoryList1 icInvestigationDeliveryStatusHistoryList1 = new ICInvestigationDeliveryStatusHistoryList1();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // ProductDeliveryHome manipulation variables, can be used for
    // investigation deliveries also
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory
        .newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();

    // Set key to read case status history details
    caseStatusHistoryKey.caseID = key.caseID;

    // Users entity variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Read case status history details and assign to output object
    final CaseStatusHistoryDetailsList1 caseStatusHistoryDetailsList1 = productDeliveryHomeObj
        .getCaseStatusHistory1(caseStatusHistoryKey);

    for (int i = 0; i < caseStatusHistoryDetailsList1.dtls.size(); i++) {

      final CaseStatusHistory caseStatusHistory = new CaseStatusHistory();

      caseStatusHistory.assign(caseStatusHistoryDetailsList1.dtls.item(i));

      // For backward compatibility support, Set the start and end date
      // time to
      // the start and end date if the start and end date times have not
      // been set.
      if (caseStatusHistory.startDateTime.isZero()) {
        caseStatusHistory.startDateTime = new DateTime(
            caseStatusHistory.startDate.getCalendar());
      }
      if (caseStatusHistory.endDateTime.isZero()) {
        caseStatusHistory.endDateTime = new DateTime(
            caseStatusHistory.endDate.getCalendar());
      }

      // Get the users full name
      usersKey.userName = caseStatusHistoryDetailsList1.dtls.item(i).userName;

      caseStatusHistory.userFullName = usersObj.getFullName(usersKey).fullname;

      icInvestigationDeliveryStatusHistoryList1.dtlsList
          .addRef(caseStatusHistory);
    }
    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryStatusHistoryList1.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryStatusHistoryList1.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    // Return the status history list
    return icInvestigationDeliveryStatusHistoryList1;
  }

  // END, CR00162569

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryTaskList listInvestigationDeliveryTask(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // create return object
    final ICInvestigationDeliveryTaskList icInvestigationDeliveryTaskList = new ICInvestigationDeliveryTaskList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // Task manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory
        .newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();
    CaseAndConcernLinkedTaskDtls caseAndConcernLinkedTaskDtls;

    // set key to read the list of tasks
    searchTaskForConcernOrCaseKey.details.linkedID = key.caseID;

    // Get list of case tasks
    caseAndConcernLinkedTaskDtls = workAllocationTaskObj
        .listCaseTasks(searchTaskForConcernOrCaseKey);

    // assign list to output structure
    icInvestigationDeliveryTaskList.dtlsList
        .assign(caseAndConcernLinkedTaskDtls.dtls);

    // Iterate through the list and set reservedByExistsInd to true
    for (int i = 0; i < icInvestigationDeliveryTaskList.dtlsList.dtls
        .size(); i++) {

      if (icInvestigationDeliveryTaskList.dtlsList.dtls.item(i).reservedBy
          .length() > 0) {

        icInvestigationDeliveryTaskList.dtlsList.dtls
            .item(i).reservedByExistsInd = true;
      }
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryTaskList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryTaskList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryTaskList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryUserRoleList listInvestigationDeliveryUserRole(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo
        .getInformationalManager();

    // Create return object
    final ICInvestigationDeliveryUserRoleList icInvestigationDeliveryUserRoleList = new ICInvestigationDeliveryUserRoleList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory
        .newInstance();
    curam.core.sl.struct.CaseUserRoleDetailsList caseUserRoleDetailsList;
    final curam.core.sl.struct.CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new curam.core.sl.struct.CaseUserRoleCaseIDKey();

    // Assign key details
    caseUserRoleCaseIDKey.dtls.caseID = key.caseID;

    // Call CaseUserRole BPO to return the list of Case User Roles
    caseUserRoleDetailsList = caseUserRoleObj
        .listCaseUserRoles(caseUserRoleCaseIDKey);

    // BEGIN, CR00205193, SS
    final int listSize = caseUserRoleDetailsList.dtls.size();

    icInvestigationDeliveryUserRoleList.dtlsList.ensureCapacity(listSize);

    // BEGIN, CR00216640, GSP
    // retrieve environment variable
    final String dispWorkQueueAsOwnerInCaseUserRole = Configuration
        .getProperty(EnvVars.ENV_DISPLAYTEMPWORKQUEUEASOWNERINCASEUSERROLE);

    for (final curam.core.sl.struct.CaseUserRoleDetails caseUserRoleDetails : caseUserRoleDetailsList.dtls
        .items()) {

      if (!(CuramConst.kTemporaryOwnerWorkqueueName.equalsIgnoreCase(
          caseUserRoleDetails.dtls.ownerDetails.orgObjectReferenceName)
          && dispWorkQueueAsOwnerInCaseUserRole
              .equalsIgnoreCase(EnvVars.ENV_VALUE_NO))) {

        icInvestigationDeliveryUserRoleList.dtlsList
            .addRef(caseUserRoleDetails);
      }
    }
    // END, CR00216640
    // END, CR00205193
    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryUserRoleList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryUserRoleList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    // retrieve any informational messages
    final String[] warnings = informationalManager
        .obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      icInvestigationDeliveryUserRoleList.informationalDtls.dtls
          .addRef(informationalMsgDtls);
    }

    return icInvestigationDeliveryUserRoleList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryAllegationList listInvestigationDeliveryAllegation(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryAllegationList icInvestigationDeliveryAllegationList = new ICInvestigationDeliveryAllegationList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();
    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    final Allegation allegationObj = AllegationFactory.newInstance();

    // Get the list of allegations for this investigation
    caseKeyStruct.caseID = key.caseID;

    icInvestigationDeliveryAllegationList.dtlsList = allegationObj
        .list(caseKeyStruct);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryAllegationList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryAllegationList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryAllegationList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ICInvestigationDeliveryEventList listInvestigationDeliveryEvent(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryEventList icInvestigationDeliveryEventList = new ICInvestigationDeliveryEventList();

    // Call the new version of this method
    final ICInvestigationDeliveryEventList1 icInvestigationDeliveryEventList1 = listInvestigationDeliveryEvent1(
        key);

    // Populate the return struct with the values returned from the new
    // method
    icInvestigationDeliveryEventList.menuDtls = icInvestigationDeliveryEventList1.menuDtls;
    icInvestigationDeliveryEventList.contextDtls = icInvestigationDeliveryEventList1.contextDtls;

    ICProductDeliveryEventDetails icInvestigationDeliveryEvent;

    for (int i = 0; i < icInvestigationDeliveryEventList1.dtlsList.dtls
        .size(); i++) {
      icInvestigationDeliveryEvent = new ICProductDeliveryEventDetails();
      icInvestigationDeliveryEvent
          .assign(icInvestigationDeliveryEventList1.dtlsList.dtls.item(i));

      icInvestigationDeliveryEventList.dtlsList.dtls
          .addRef(icInvestigationDeliveryEvent);
    }

    return icInvestigationDeliveryEventList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryEventList1 listInvestigationDeliveryEvent1(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryEventList1 icInvestigationDeliveryEventList = new ICInvestigationDeliveryEventList1();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // ViewCaseEvents manipulation variables
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory
        .newInstance();
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList;

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList = viewCaseEventsObj
        .readActiveEventsByType1(viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      icInvestigationDeliveryEventList.dtlsList.dtls
          .ensureCapacity(viewActiveCaseEventDetailsList.dtls.size());

      // Assign details to the return object
      icInvestigationDeliveryEventList.dtlsList
          .assign(viewActiveCaseEventDetailsList);
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryEventList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryEventList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryEventList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryMilestoneList listInvestigationDeliveryMilestone(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final ICInvestigationDeliveryMilestoneList icInvestigationDeliveryMilestoneList = new ICInvestigationDeliveryMilestoneList();

    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory
        .newInstance();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    icInvestigationDeliveryMilestoneList.dtlsList.dtls = milestoneDeliveryObj
        .listAllMilestoneDeliveries(key);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    icInvestigationDeliveryMilestoneList.dtlsList.description.description = InvestigationDeliveryFactory
        .newInstance().getInvestigationDeliveryContextDescription(
            investigationDeliveryKey).description;

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    icInvestigationDeliveryMilestoneList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return icInvestigationDeliveryMilestoneList;
  }

  // END, CR00113516

  // BEGIN, CR00119496, JMA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryActionPlanList listInvestigationDeliveryActionPlan(
      final LinkKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryActionPlanList icInvestigationDeliveryActionPlanList = new ICInvestigationDeliveryActionPlanList();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();
    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    final ActionPlan actionPlanObj = ActionPlanFactory.newInstance();

    // Get the list of allegations for this investigation
    caseKeyStruct.caseID = key.linkID;

    // BEGIN, CR00141866, MPB
    icInvestigationDeliveryActionPlanList.dtlsList = actionPlanObj.list(key);
    // END, CR00141866
    // Set key to read context description
    investigationDeliveryKey.caseID = key.linkID;

    // Read context description
    icInvestigationDeliveryActionPlanList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.linkID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    caseHeaderKey.caseID = key.linkID;

    icInvestigationDeliveryActionPlanList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(caseHeaderKey);

    return icInvestigationDeliveryActionPlanList;

  }

  // END, CR00119496
  // BEGIN, CR00119776, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ICInvestigationDeliveryContactLogList listInvestigationDeliveryContactLog(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final ICInvestigationDeliveryContactLogList iCInvestigationDeliveryContactLogList = new ICInvestigationDeliveryContactLogList();

    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    // BEGIN, CR00140221, ZV
    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.caseID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.CASE;

    iCInvestigationDeliveryContactLogList.dtlsList = contactLogObj
        .list(contactLogLinkIDLinkTypeKey);
    // END, CR00140221

    // BEGIN, CR00140531, CL
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < iCInvestigationDeliveryContactLogList.dtlsList.dtls
        .size(); i++) {

      readContactLogDetails.contactLogDetails
          .assign(iCInvestigationDeliveryContactLogList.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj
          .formatContactLogPurpose(readContactLogDetails);

      iCInvestigationDeliveryContactLogList.dtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }
    // END, CR00140531

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    iCInvestigationDeliveryContactLogList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    iCInvestigationDeliveryContactLogList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return iCInvestigationDeliveryContactLogList;
  }

  // END, CR00119776

  // BEGIN, CR00121630, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryAssessmentList listInvestigationDeliveryAssessment(
      final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ICInvestigationDeliveryAssessmentList assessmentList = new ICInvestigationDeliveryAssessmentList();

    final CasesByCaseIDAndTypeKey casesByCaseIDAndTypeKey = new CasesByCaseIDAndTypeKey();

    // Set key to read assessments
    casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
    casesByCaseIDAndTypeKey.dtls.caseTypeCode = CASETYPECODE.ASSESSMENTDELIVERY;

    final AssessmentDelivery assessmentDeliveryObj = AssessmentDeliveryFactory
        .newInstance();

    assessmentList.assessmentList = assessmentDeliveryObj
        .listAssessmentCasesByIntegratedCaseID(casesByCaseIDAndTypeKey);

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    assessmentList.contextDtls = InvestigationDeliveryFactory.newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    final CaseKey caseKey = new CaseKey();

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    assessmentList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return assessmentList;
  }

  // END, CR00121630

  // BEGIN, CR00148211, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListTransactionsLogDetails listRecentTransaction(
      final CaseHeaderKey caseKey) throws AppException, InformationalException {

    // Return Struct
    final ListTransactionsLogDetails listTransactionsLogDetails = new ListTransactionsLogDetails();

    // Case Transaction Log business process object
    final ReadTransactionLogDetailsList readTransactionLogDetailsList = new ReadTransactionLogDetailsList();

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = caseKey.caseID;
    readTransactionLogDetailsList.transactionDetailsList = caseTransactionLogProvider
        .get().readAllTransactions(caseIDKey);

    listTransactionsLogDetails.transactionDetailsList = readTransactionLogDetailsList;

    // Set the integrated case context variables
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read context description
    icContextDescriptionKey.caseID = caseKey.caseID;

    // Read context description and set in return object
    listTransactionsLogDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = caseKey.caseID;

    // Read menu data
    listTransactionsLogDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listTransactionsLogDetails;
  }

  // END, CR00148211

  // BEGIN, CR00148820, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListTransactionsLogDetails listProductDeliveryRecentTransaction(
      final CaseHeaderKey caseKey) throws AppException, InformationalException {

    // Return Struct
    final ListTransactionsLogDetails listTransactionsLogDetails = new ListTransactionsLogDetails();

    // Case Transaction Log business process object
    final ReadTransactionLogDetailsList readTransactionLogDetailsList = new ReadTransactionLogDetailsList();

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = caseKey.caseID;
    readTransactionLogDetailsList.transactionDetailsList = caseTransactionLogProvider
        .get().readAllTransactions(caseIDKey);

    listTransactionsLogDetails.transactionDetailsList = readTransactionLogDetailsList;

    // Add the menu data and context description
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = caseKey.caseID;

    // Read context description
    listTransactionsLogDetails.icProductDeliveryContextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = caseKey.caseID;

    // Read menu data
    listTransactionsLogDetails.icProductDeliveryMenuDataDetails = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listTransactionsLogDetails;
  }

  // END, CR00148820

  // BEGIN, CR00148765, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SpecialCautionsList listSpecialCaution(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Return struct
    final SpecialCautionsList specialCautionsList = new SpecialCautionsList();

    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // IC member context description key
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    // Set key to read context description
    icMemberContextDescriptionKey.concernRoleID = getConcernRoleIDFromParticipantKey(
        caseParticipantRoleKey);

    // Read context description
    specialCautionsList.memberContextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // Read menu data
    specialCautionsList.menuData = getICMemberMenuData(caseParticipantRoleKey);

    // Instance of the service layer Object.
    final curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory
        .newInstance();

    final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

    specialCautionConcernKey.key.concernRoleID = getConcernRoleIDFromParticipantKey(
        caseParticipantRoleKey);

    // Call to method listSpecialCautions on the Service layer Object
    specialCautionsList.list = specialCautionObj
        .listSpecialCautions(specialCautionConcernKey.key);

    return specialCautionsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public SpecialCautionsList listSpecialCautionHistory(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Return struct
    final SpecialCautionsList specialCautionsList = new SpecialCautionsList();

    // IC member context description key
    final ICMemberContextDescriptionKey icMemberContextDescriptionKey = new ICMemberContextDescriptionKey();

    final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

    caseParticipantRoleKey.dtls.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // Set key to read context description
    icMemberContextDescriptionKey.concernRoleID = getConcernRoleIDFromParticipantKey(
        caseParticipantRoleKey);

    // Read context description
    specialCautionsList.memberContextDescription = getICMemberContextDescription(
        icMemberContextDescriptionKey);

    // Read menu data
    specialCautionsList.menuData = getICMemberMenuData(caseParticipantRoleKey);

    // Instance of the service layer Object.
    final curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory
        .newInstance();

    final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

    specialCautionConcernKey.key.concernRoleID = getConcernRoleIDFromParticipantKey(
        caseParticipantRoleKey);

    // Call to method listSpecialCautions on the Service layer Object
    specialCautionsList.list = specialCautionObj
        .listAllSpecialCautions(specialCautionConcernKey.key);

    return specialCautionsList;
  }

  /**
   * Returns the concern role id for a case participant.
   *
   * @bowrite CaseParticipant
   *
   * @param caseParticipantRoleKey
   *          The case participant id.
   *
   * @return The concern role id.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  protected long getConcernRoleIDFromParticipantKey(
      final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey)
      throws AppException, InformationalException {

    // Maintain Case Participant manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_entityKey = new CaseParticipantRoleKey();

    // Read caseID and ConcernRoleID by searching on CaseParticipantRoleID
    // Populate the entity case participant key
    caseParticipantRole_entityKey.caseParticipantRoleID = caseParticipantRoleKey.dtls.caseParticipantRoleID;

    caseIDCaseRefAndParticipantRoleIDDetails = caseParticipantRoleObj
        .readCaseIDcaseRefandParticipantID(caseParticipantRole_entityKey);

    return caseIDCaseRefAndParticipantRoleIDDetails.participantRoleID;
  }

  // END, CR00148765
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseCreationDetails createCaseHelper(
      final CaseCreationDetails caseCreationDetails)
      throws AppException, InformationalException {

    return caseCreationDetails;
  }

  // BEGIN, CR00163245, MC
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public InformationalMsgDtlsList countActiveTasks(final CaseKey caseKey)
      throws AppException, InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo
        .getInformationalManager();

    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory
        .newInstance();

    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();

    final SearchTasksForConcernAndCaseDetails searchTasksForConcernAndCaseDetails = new SearchTasksForConcernAndCaseDetails();

    searchTaskForConcernOrCaseKey.details.linkedID = caseKey.caseID;

    searchTasksForConcernAndCaseDetails.dtls = workAllocationTaskObj
        .listCaseTasks(searchTaskForConcernOrCaseKey);

    final int numTasks = searchTasksForConcernAndCaseDetails.dtls.dtls.dtls
        .size();
    int numberOfTasks = numTasks;

    // check that each task is either COMPLETED or CLOSED
    for (int i = 0; i < numTasks; i++) {

      if (searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.item(i).status
          .equals(curam.codetable.TASKSTATUS.COMPLETED)) {
        numberOfTasks--;
      }
    }

    // Environment variable to define if a case can be closed without
    // manually
    // closing all of the task on it first
    boolean closeCaseWithTasks = false;
    String closeCaseWithTasksProperty = Configuration
        .getProperty(EnvVars.ENV_CLOSE_CASE_WITH_TASKS);

    if (closeCaseWithTasksProperty.length() == 0
        || closeCaseWithTasksProperty == null) {
      closeCaseWithTasksProperty = EnvVars.ENV_CLOSE_CASE_WITH_TASKS_DEFAULT;
    }

    closeCaseWithTasks = closeCaseWithTasksProperty
        .equalsIgnoreCase(EnvVars.ENV_VALUE_YES);

    // If there are active tasks
    if (numberOfTasks > 0 && closeCaseWithTasks) {

      final AppException e = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_ACTIVE_TASKS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(e.arg(true), CuramConst.gkEmpty,
              curam.util.exception.InformationalElement.InformationalType.kWarning,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    final String[] warnings = informationalManager
        .obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  // END, CR00163245

  // BEGIN, CR00266603, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListMemberDetails listDeductionCaseParticipant(
      final ListMemberDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    // IntegratedCase manipulation variables
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();

    CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    MemberDetails memberDetails;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    // Case Header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // BEGIN, CR00181451, SPD
    // Maintain Concern Role Details object
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory
        .newInstance();

    // END, CR00181451

    // set case key
    caseKey.caseID = key.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
          .newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = key.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    // Set the return object
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails
          .assign(viewCaseParticipantRoleDetailsList.dtls.item(i));

      listICClientRoleDetails.participantList
          .addRef(caseParticipantRoleFullDetails);
    }

    // Reserve space in memberDetailsList
    listMemberDetails.memberDetailsList.dtls
        .ensureCapacity(listICClientRoleDetails.participantList.size());

    for (int i = 0; i < listICClientRoleDetails.participantList.size(); i++) {

      if (!listICClientRoleDetails.participantList.item(i).recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {

        memberDetails = new MemberDetails();
        caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

        // BEGIN, CR00181451, SPD
        final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

        concernRolesDetails.concernRoleID = listICClientRoleDetails.participantList
            .item(i).participantRoleID;
        concernRolesDetails.concernRoleType = listICClientRoleDetails.participantList
            .item(i).participantRoleType;
        concernRolesDetails.concernRoleName = listICClientRoleDetails.participantList
            .item(i).name;

        // Populate concern role details to return struct
        memberDetails.name = maintainConcernRoleDetailsObj
            .appendAgeToName(concernRolesDetails).concernRoleName;
        memberDetails.participantRoleID = concernRolesDetails.concernRoleID;
        memberDetails.caseParticipantRoleID = listICClientRoleDetails.participantList
            .item(i).caseParticipantRoleID;

        // Add to return object
        listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
        // END, CR00181451
      }

    }
    return listMemberDetails;
  }

  // END, CR00266603

  // BEGIN, CR00175719, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICInvestigationDeliveryContactLogList1 listInvestigationDeliveryContactLog1(
      final CaseHeaderKey key) throws AppException, InformationalException {

    final ICInvestigationDeliveryContactLogList1 iCInvestigationDeliveryContactLogList = new ICInvestigationDeliveryContactLogList1();

    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();

    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final CaseKey caseKey = new CaseKey();

    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.caseID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.CASE;

    iCInvestigationDeliveryContactLogList.dtlsList = contactLogObj
        .list1(contactLogLinkIDLinkTypeKey);

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < iCInvestigationDeliveryContactLogList.dtlsList.dtls
        .size(); i++) {

      readContactLogDetails.contactLogDetails
          .assign(iCInvestigationDeliveryContactLogList.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj
          .formatContactLogPurpose(readContactLogDetails);

      iCInvestigationDeliveryContactLogList.dtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }

    investigationDeliveryKey.caseID = key.caseID;

    iCInvestigationDeliveryContactLogList.contextDtls = InvestigationDeliveryFactory
        .newInstance()
        .getInvestigationDeliveryContextDescription(investigationDeliveryKey);

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
        .readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager
        .getMenuDataHook(caseTypeCode.caseTypeCode);

    iCInvestigationDeliveryContactLogList.menuDtls = menuDataObj
        .getICInvestigationDeliveryMenuData(key);

    return iCInvestigationDeliveryContactLogList;
  }

  // END, CR00175719

  // BEGIN, CR00168515, SS

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * Returns a list of Accessible notes on an Integrated Case.The list comprises
   * of list of notes with noteAccessInd indicator to restrict access to view
   * and edit the note details.The method also returns the integrated case menu
   * data and case context description.
   *
   * @param key
   *          Key to read the list of notes on an Integrated Case.
   * @return List of Accessible notes for an Integrated Case.
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listAccessibleNote1()}
   */
  @Override
  @Deprecated
  public ListICAccessibleNoteDetails listAccessibleNote(
      final ListICNotesKey key) throws AppException, InformationalException {

    final ListICAccessibleNoteDetails listICAccessibleNoteDetails = new ListICAccessibleNoteDetails();

    final ListICAccessibleNoteDetails1 listICAccessibleNoteDetails1 = listAccessibleNote1(
        key);

    listICAccessibleNoteDetails.assign(listICAccessibleNoteDetails1);

    return listICAccessibleNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICAccessibleNoteDetails1 listAccessibleNote1(
      final ListICNotesKey key) throws AppException, InformationalException {

    // Create return object
    final ListICAccessibleNoteDetails1 listICAccessibleNoteDetails = new ListICAccessibleNoteDetails1();

    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory
        .newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();
    CaseAccessibleNotesList1 caseAccessibleNoteList;

    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read the list of notes
    caseKey.key.caseID = key.caseID;

    // BEGIN, CR00184010, PDN
    // Call CaseNotes BPO to retrieve the list of accessible notes
    caseAccessibleNoteList = caseNoteObj.listAccessibleNotesSorted1(caseKey);
    // END, CR00184010

    // Check to see if the list if populated
    if (!caseAccessibleNoteList.details.isEmpty()) {

      // Reserve space in the return object
      listICAccessibleNoteDetails.noteDetailsList.dtls
          .ensureCapacity(caseAccessibleNoteList.details.size());

      ICAccessibleNoteDetails1 icAccessibleNoteDetails;

      // Assign details to return object
      for (int i = 0; i < caseAccessibleNoteList.details.size(); i++) {

        icAccessibleNoteDetails = new ICAccessibleNoteDetails1();
        icAccessibleNoteDetails.assign(caseAccessibleNoteList.details.item(i));
        // Add details to the return objects
        listICAccessibleNoteDetails.noteDetailsList.dtls
            .addRef(icAccessibleNoteDetails);
      }
    }

    icContextDescriptionKey.caseID = key.caseID;
    // Read context description and assign to return object
    listICAccessibleNoteDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    integratedCaseMenuDataKey.caseID = key.caseID;
    // Read menu data and assign to return object
    listICAccessibleNoteDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listICAccessibleNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of Accessible notes for a Product Delivery on an Integrated
   * Case.The list comprises of list of notes with noteAccessInd indicator to
   * restrict access to view and edit the note details.The method also returns
   * the integrated case menu data and case context description.
   *
   * @param key
   *          Key to read the list of Product Delivery notes.
   * @return List of Accessible Product Delivery notes.
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listPDAccessibleNote1()}
   */
  @Override
  @Deprecated
  public ListICPDAccessibleNoteDetails listPDAccessibleNote(
      final ListICProductDeliveryNoteKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICPDAccessibleNoteDetails listICPDAccessibleNoteDetails = new ListICPDAccessibleNoteDetails();

    final ListICPDAccessibleNoteDetails1 listICPDAccessibleNoteDetails1 = listPDAccessibleNote1(
        key);

    listICPDAccessibleNoteDetails.assign(listICPDAccessibleNoteDetails1);

    return listICPDAccessibleNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICPDAccessibleNoteDetails1 listPDAccessibleNote1(
      final ListICProductDeliveryNoteKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICPDAccessibleNoteDetails1 listICPDAccessibleNoteDetails = new ListICPDAccessibleNoteDetails1();

    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory
        .newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();
    CaseAccessibleNotesList1 caseAccessibleNoteList;

    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Set key to read the list of notes
    caseKey.key.caseID = key.caseID;

    // Call CaseNotes BPO to retrieve the list of notes
    // BEGIN, CR00184010, PDN
    caseAccessibleNoteList = caseNoteObj.listAccessibleNotesSorted1(caseKey);
    // END, CR00184010

    // Check to see if the list if populated
    if (!caseAccessibleNoteList.details.isEmpty()) {

      // Reserve space in the return object
      listICPDAccessibleNoteDetails.noteDetailsList.dtls
          .ensureCapacity(caseAccessibleNoteList.details.size());

      ICPDAccessibleNoteDetails1 icPDAccessibleNoteDetails;

      // Assign details to return object
      for (int i = 0; i < caseAccessibleNoteList.details.size(); i++) {

        icPDAccessibleNoteDetails = new ICPDAccessibleNoteDetails1();

        icPDAccessibleNoteDetails
            .assign(caseAccessibleNoteList.details.item(i));

        // Add details to the return objects
        listICPDAccessibleNoteDetails.noteDetailsList.dtls
            .addRef(icPDAccessibleNoteDetails);
      }
    }
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;
    // Read context description and assign to return object
    listICPDAccessibleNoteDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    icProductDeliveryMenuDataKey.caseID = key.caseID;
    // Read menu data and assign it to return object
    listICPDAccessibleNoteDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICPDAccessibleNoteDetails;
  }

  // END, CR00231506

  // END, CR00168515

  // BEGIN, CR00177579, AK
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails getCaseParticipantsAgeConcernRoleID(
      final CaseID caseID) throws AppException, InformationalException {

    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();
    CaseParticipantRoleKey caseParticipantRoleKey;
    String caseParticipantRoleType;
    PersonKey personKey;
    final Person personObj = PersonFactory.newInstance();
    // BEGIN, CR00214099, AK
    final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory
        .newInstance();
    final CalculationEndDate endDate = new CalculationEndDate();
    final CalculationStartDate startDate = new CalculationStartDate();
    // END, CR00214099
    final ListMemberDetailsKey key = new ListMemberDetailsKey();

    key.caseID = caseID.dtls.caseID;
    final ListMemberDetails caseparticipantList = listCaseParticipantsDetails(
        key);

    for (final MemberDetails dtls : caseparticipantList.memberDetailsList.dtls
        .items()) {
      caseParticipantRoleKey = new CaseParticipantRoleKey();
      caseParticipantRoleKey.caseParticipantRoleID = dtls.caseParticipantRoleID;
      caseParticipantRoleType = caseParticipantRole
          .readTypeCode(caseParticipantRoleKey).typeCode;
      if (CASEPARTICIPANTROLETYPE.MEMBER.equals(caseParticipantRoleType)
          || CASEPARTICIPANTROLETYPE.PRIMARY.equals(caseParticipantRoleType)) {

        // BEGIN, CR00235371, AK
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = dtls.participantRoleID;
        final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj
            .readConcernRoleType(concernRoleKey);

        if (CONCERNROLETYPE.PERSON
            .equals(concernRoleTypeDetails.concernRoleType)) {
          personKey = new PersonKey();
          personKey.concernRoleID = dtls.participantRoleID;
          startDate.startDate = personObj
              .readDateOfBirth(personKey).dateOfBirth;
        }
        if (CONCERNROLETYPE.REPRESENTATIVE
            .equals(concernRoleTypeDetails.concernRoleType)) {
          final Representative representativeObj = RepresentativeFactory
              .newInstance();

          startDate.startDate = representativeObj
              .readRepresentativeDetails(concernRoleKey).dateOfBirth;
        }
        if (CONCERNROLETYPE.PROSPECTPERSON
            .equals(concernRoleTypeDetails.concernRoleType)) {
          final ProspectPerson prospectPersonObj = ProspectPersonFactory
              .newInstance();
          final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

          prospectPersonKey.concernRoleID = dtls.participantRoleID;
          startDate.startDate = prospectPersonObj
              .readProspectPersonDOB(prospectPersonKey).dateOfBirth;
        }
        if (!Date.kZeroDate.equals(startDate.startDate)) {
          endDate.endDate = Date.getCurrentDate();
          dtls.name += GeneralConstants.kSpace
              .concat(GeneralConstants.kOpenBracket)
              .concat(String.valueOf(tabDetailFormatterObj
                  .calculateAge(startDate, endDate).ageYears))
              .concat(GeneralConstants.kCloseBracket);
        }
        // END, CR00235371

      } else {
        caseparticipantList.memberDetailsList.dtls.remove(dtls);
      }
    }
    return caseparticipantList;
  }

  // END, CR00177579

  // BEGIN, CR00220794, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryCertDetails1 listProductDeliveryCertification1(
      final CertificationCaseIDKey key)
      throws AppException, InformationalException {

    // Create the return object
    final ListICProductDeliveryCertDetails1 listICProductDeliveryCertDetails = new ListICProductDeliveryCertDetails1();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory
        .newInstance();
    final MaintainCertificationCaseIDKey maintainCertificationCaseIDKey = new MaintainCertificationCaseIDKey();

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // Assign key details
    maintainCertificationCaseIDKey.assign(key);

    // Read certifications
    listICProductDeliveryCertDetails.assign(maintainCertificationObj
        .getCertifications(maintainCertificationCaseIDKey));

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listICProductDeliveryCertDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    listICProductDeliveryCertDetails.icProductDeliveryMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    return listICProductDeliveryCertDetails;
  }

  // END, CR00220794

  // BEGIN, CR00220971, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadIntegratedCaseDetails1 readCaseDetails1(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadIntegratedCaseDetails1 readIntegratedCaseDetails = new ReadIntegratedCaseDetails1();

    // IntegratedCaseHome manipulation variables
    final curam.core.intf.IntegratedCaseHome integratedCaseHomeObj = curam.core.fact.IntegratedCaseHomeFactory
        .newInstance();
    final IntegratedCaseHomeKey integratedCaseHomeKey = new IntegratedCaseHomeKey();
    // BEGIN, CR00092078, SPD
    GetFurtherDetailsResult getFurtherDetailsResult = new GetFurtherDetailsResult();

    final ListICClientKey listICClientKey = new ListICClientKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory
        .newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // Set key to read details
    integratedCaseHomeKey.caseID = key.caseID;

    // BEGIN, CR00092078, SPD
    // Read back the case details
    getFurtherDetailsResult = integratedCaseHomeObj
        .getFurtherDetails(integratedCaseHomeKey);

    // Assign the case detail to the return object
    readIntegratedCaseDetails.details
        .assign(getFurtherDetailsResult.integratedCaseFurtherDtls);

    // Assign the special caution display indicator to the return object
    readIntegratedCaseDetails.details.specialCautionIndicator = getFurtherDetailsResult.specialCautionIndicator;

    // Populate the bookmark indicator for the case
    readIntegratedCaseDetails.caseIsUserBookmarkInd = getFurtherDetailsResult.caseIsUserBookmarkInd;
    // END, CR00092078

    // BEGIN, CR00278729, SK
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.participantRoleID = readIntegratedCaseDetails.details.concernRoleID;
    readByParticipantRoleTypeAndCaseKey.caseID = readIntegratedCaseDetails.details.caseID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
        .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
            readByParticipantRoleTypeAndCaseKey);

    // Assign caseParticipantRoleID to the return object
    readIntegratedCaseDetails.details.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478
    // END, CR00278729

    // Set key to call local method listMemberDetails
    listICClientKey.caseID = key.caseID;
    // BEGIN, CR00160706, PDN
    listICClientKey.showOnlyActive = true;
    // END, CR00160706

    // BEGIN, CR00225060, ZV
    final ListICClientRoleDetails1 listICClientRoleDetails = listCaseMembers1(
        listICClientKey);

    // END, CR00225060

    for (int i = 0; i < listICClientRoleDetails.participantList.size(); i++) {

      final MemberDetails memberDetails = new MemberDetails();

      memberDetails.assign(listICClientRoleDetails.participantList.item(i));

      readIntegratedCaseDetails.memberDetailsList.memberDetailsList.dtls
          .addRef(memberDetails);

    }

    // Set the key to read the case product list.
    final curam.core.facade.struct.IntegratedCaseIDKey integratedCaseIDKey = new curam.core.facade.struct.IntegratedCaseIDKey();

    integratedCaseIDKey.caseID = key.caseID;

    // Read the list of products.
    ListICProductDeliveryDetails listProductDetails;

    listProductDetails = listProduct(integratedCaseIDKey);

    // The product details which will be assigned.
    ICProductDetails icProductDetails;

    // Reserve space in productDetails
    readIntegratedCaseDetails.productDetails
        .ensureCapacity(listProductDetails.dtls.size());

    // Assign the list of products.
    for (int i = 0; i < listProductDetails.dtls.size(); i++) {

      // BEGIN, CR00240898, KH
      // Do not include Net Zero payment correction cases in the list
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = listProductDetails.dtls.item(i).caseID;

      if (paymentCorrection.isNetZeroPaymentCorrection(caseHeaderKey)) {
        continue;
      }
      // END, CR00240898

      icProductDetails = new ICProductDetails();

      icProductDetails.assign(listProductDetails.dtls.item(i));

      // BEGIN, CR00278729, SK
      // BEGIN, CR00305478, MV
      readByParticipantRoleTypeAndCaseKey.participantRoleID = listProductDetails.dtls
          .item(i).concernRoleID;
      readByParticipantRoleTypeAndCaseKey.caseID = listProductDetails.dtls
          .item(i).caseID;
      readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
      readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

      readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
              readByParticipantRoleTypeAndCaseKey);
      // END, CR00305478

      // Assign caseParticipantRoleID to the return object
      icProductDetails.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
      // END, CR00278729

      readIntegratedCaseDetails.productDetails.addRef(icProductDetails);

    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    readIntegratedCaseDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    readIntegratedCaseDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    // Read Transaction Log Details
    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN CR00108134, GBA
    readIntegratedCaseDetails.transactionDtls.assign(
        caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    // BEGIN, CR00150390, PDN
    final curam.core.facade.intf.Case caseObj = curam.core.facade.fact.CaseFactory
        .newInstance();

    final ReadRelationshipListForCaseMemberKey relationshipkey = new ReadRelationshipListForCaseMemberKey();

    relationshipkey.caseID = key.caseID;

    // Set the relatedNonMembersInd depending on if there are related
    // concerns
    // not
    // already case members
    if (caseObj.listRelationshipForCaseMember1(relationshipkey).dtls.dtls
        .size() != 0) {
      readIntegratedCaseDetails.relatedNonMembersInd = true;
    } else {
      readIntegratedCaseDetails.relatedNonMembersInd = false;
    }
    // END, CR00150390

    // BEGIN, CR00150402, PDN
    // If the case is closed then need to populate the close details for the
    // case.
    if (readIntegratedCaseDetails.details.statusCode
        .equals(curam.codetable.CASESTATUS.CLOSED)) {
      // Set the case close indicator
      readIntegratedCaseDetails.isCaseClosedInd = true;

      // CaseStatus manipulation variables
      final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory
          .newInstance();
      CaseStatusDtls caseStatusDtls;
      final CurrentCaseStatusKey currCaseStatusKey = new CurrentCaseStatusKey();

      currCaseStatusKey.caseID = key.caseID;
      currCaseStatusKey.nullDate = curam.util.type.Date.kZeroDate;

      // Read current status by retrieved Case ID to get the closure
      // details
      // BEGIN, CR00224271, ZV
      caseStatusDtls = caseStatusObj
          .readCurrentStatusByCaseID1(currCaseStatusKey);
      // END, CR00224271

      // Populate the user's full name
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = caseStatusDtls.userName;

      readIntegratedCaseDetails.closureDtls.userFullName = usersObj
          .read(usersKey).fullName;

      readIntegratedCaseDetails.closureDtls.comments = caseStatusDtls.comments;
      readIntegratedCaseDetails.closureDtls.reasonCode = caseStatusDtls.reasonCode;
      readIntegratedCaseDetails.closureDtls.closureDate = caseStatusDtls.startDate;

      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage = new LocalisableString(
          curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage
          .arg(readIntegratedCaseDetails.closureDtls.userFullName);

      // Add the closure date
      dateUserNameMessage
          .arg(readIntegratedCaseDetails.closureDtls.closureDate);
      // END, CR00166458
      readIntegratedCaseDetails.closureDtls.closureDateAndUserFullName = dateUserNameMessage
          .toClientFormattedText();
      // END, CR00163613

    }
    // END, CR00150402

    return readIntegratedCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadICProductHomePageDetails1 readICProductHomePageDetails1(
      final ReadICProductHomePageKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadICProductHomePageDetails1 readICProductHomePageDetails = new ReadICProductHomePageDetails1();

    // Check if external adapters are set correctly
    initializeBroadcastTrigger();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory
        .newInstance();
    final ProductDeliveryHomeKey productDeliveryHomeKey = new ProductDeliveryHomeKey();
    GetProductDeliveryDetailsResult getProductDeliveryDetailsResult;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory
        .newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // Set key to read Product Delivery home page details
    productDeliveryHomeKey.caseID = key.caseID;

    // Read ProductDelivery home page details
    getProductDeliveryDetailsResult = productDeliveryHomeObj
        .getProductDeliveryDetails(productDeliveryHomeKey);

    // Assign home page details to output struct
    readICProductHomePageDetails.details
        .assign(getProductDeliveryDetailsResult.dtls);

    // BEGIN, CR00092078, SPD
    // Populate the bookmark indicator for the case
    readICProductHomePageDetails.caseIsUserBookmarkInd = getProductDeliveryDetailsResult.productDeliveryHomeIndicators.caseIsUserBookmarkInd;
    // END, CR00092078

    // BEGIN, CR00278729, SK
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.participantRoleID = getProductDeliveryDetailsResult.dtls.primaryClientID;
    readByParticipantRoleTypeAndCaseKey.caseID = key.caseID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
        .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
            readByParticipantRoleTypeAndCaseKey);

    // END, CR00305478

    // Assign caseParticipantRoleID to the return object
    readICProductHomePageDetails.details.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;

    // BEGIN, CR00305478, MV
    // To read product provider particiapntRoleID.
    readByParticipantRoleTypeAndCaseKey.participantRoleID = readICProductHomePageDetails.details.productProviderID;
    readByParticipantRoleTypeAndCaseKey.caseID = key.caseID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRODUCTPROVIDER;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    // Reads caseParticipantRoleID for the productProvider
    readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
        .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
            readByParticipantRoleTypeAndCaseKey);

    // Assign productProviderCaseParticipantRoleID to the return object
    readICProductHomePageDetails.details.productProviderCaseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478
    // END, CR00278729

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    readICProductHomePageDetails.contextDescription = getICProductDeliveryContextDescription(
        icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    readICProductHomePageDetails.menuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);

    // BEGIN, CR00022266, PA
    // Read Transaction Log Details

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN CR00108134, GBA
    readICProductHomePageDetails.transactionLogDtls.assign(
        caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134
    // END, CR00022266

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    // BEGIN, CR00150402, PDN
    // If the case is closed then need to populate the close details for
    // the case.
    if (readICProductHomePageDetails.details.caseStatusCode
        .equals(curam.codetable.CASESTATUS.CLOSED)) {
      // Set the closed indicator to closed.
      readICProductHomePageDetails.isCaseClosedInd = true;

      // Read and assign the closure details
      final MaintainCaseClosure MaintainCaseClosureObj = MaintainCaseClosureFactory
          .newInstance();

      final ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();

      readCaseClosureKey.caseID = readICProductHomePageDetails.details.caseID;

      final ClosureDtls closureDtls = MaintainCaseClosureObj
          .readCaseClosure(readCaseClosureKey);

      readICProductHomePageDetails.closureDtls.assign(closureDtls);

      // Populate the user's full name
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = closureDtls.userName;

      readICProductHomePageDetails.closureDtls.userFullName = usersObj
          .read(usersKey).fullName;

      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage = new LocalisableString(
          curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage
          .arg(readICProductHomePageDetails.closureDtls.userFullName);

      // Add the closure date
      dateUserNameMessage
          .arg(readICProductHomePageDetails.closureDtls.closureDate);
      // END, CR00166458

      readICProductHomePageDetails.closureDtls.closureDateAndUserFullName = dateUserNameMessage
          .toClientFormattedText();
      // END, CR00163613

    }
    // END, CR00150402

    return readICProductHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ICBenefitUnderpmtHomePageDetails1 readICBenefitUnderpmtHomePageDetails1(
      final ReadICProductHomePageKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICBenefitUnderpmtHomePageDetails1 icBenefitUnderpmtHomePageDetails = new ICBenefitUnderpmtHomePageDetails1();

    // ReassessmentProduct manipulation variables
    final curam.core.sl.struct.GetUnderpmtEvidenceKey getUnderpmtEvidenceKey = new curam.core.sl.struct.GetUnderpmtEvidenceKey();

    // Call local method to retrieve home page details - this includes the
    // context description
    icBenefitUnderpmtHomePageDetails.details = readICProductHomePageDetails1(
        key);

    // Now need to retrieve the benefit underpayment evidence as this is
    // going to be shown on the home page
    getUnderpmtEvidenceKey.caseID = key.caseID;

    // BEGIN, CR00211744, VM
    final GetBUCaseEvidenceKey getBUCaseEvidenceKey = new GetBUCaseEvidenceKey();

    getBUCaseEvidenceKey.key.caseID = key.caseID;

    icBenefitUnderpmtHomePageDetails.evidenceDetails = assessmentEngine
        .getBenefitUnderpaymentCaseEvidence(
            getBUCaseEvidenceKey).evidenceResult;
    // END, CR00211744

    return icBenefitUnderpmtHomePageDetails;
  }

  // END, CR00220971

  // BEGIN, CR00226543, GYH
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseSpecialCautionDetailsList listSpecialCautionsForCase(
      final curam.core.struct.CaseID key)
      throws AppException, InformationalException {

    // Get the list of case members
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = new ViewCaseParticipantRoleDetailsList();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    // For each case member, find if any special cautions created.
    final SpecialCautionsList specialCautionsList = new SpecialCautionsList();

    for (final curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails details : viewCaseParticipantRoleDetailsList.dtls
        .items()) {
      final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

      caseParticipantRoleKey.dtls.caseParticipantRoleID = details.caseParticipantRoleID;
      final curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory
          .newInstance();
      final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

      specialCautionConcernKey.key.concernRoleID = getConcernRoleIDFromParticipantKey(
          caseParticipantRoleKey);
      specialCautionsList.list.list.addAll(specialCautionObj
          .listSpecialCautions(specialCautionConcernKey.key).list);
    }
    return populateParticipantName(specialCautionsList);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CaseSpecialCautionDetailsList listSpecialCautionHistoryForCase(
      final curam.core.struct.CaseID key)
      throws AppException, InformationalException {

    // Get the list of case members
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = new ViewCaseParticipantRoleDetailsList();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    // For each case member, find if any special cautions created.
    final SpecialCautionsList specialCautionsList = new SpecialCautionsList();

    for (final curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails details : viewCaseParticipantRoleDetailsList.dtls
        .items()) {
      final curam.core.facade.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.facade.struct.CaseParticipantRoleKey();

      caseParticipantRoleKey.dtls.caseParticipantRoleID = details.caseParticipantRoleID;
      final curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory
          .newInstance();
      final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

      specialCautionConcernKey.key.concernRoleID = getConcernRoleIDFromParticipantKey(
          caseParticipantRoleKey);
      specialCautionsList.list.list.addAll(specialCautionObj
          .listAllSpecialCautions(specialCautionConcernKey.key).list);
    }
    return populateParticipantName(specialCautionsList);
  }

  /**
   * Populates the participant name for each special cautions in a specified
   * list.
   *
   * @param specialCautionsList
   *          Contains list of special cautions.
   *
   * @return List of special cautions with participant name.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  protected CaseSpecialCautionDetailsList populateParticipantName(
      final SpecialCautionsList specialCautionsList)
      throws AppException, InformationalException {

    final CaseSpecialCautionDetailsList caseSpecialCautionDetailsList = new CaseSpecialCautionDetailsList();
    final CachedConcernRole concernRoleObj = CachedConcernRoleFactory
        .newInstance();

    for (final SpecialCautionDetails specialCautionDetails : specialCautionsList.list.list
        .items()) {
      final CaseSpecialCautionDetails caseSpecialCautionDetails = new CaseSpecialCautionDetails();

      caseSpecialCautionDetails.details = specialCautionDetails;
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = specialCautionDetails.concernRoleID;
      caseSpecialCautionDetails.participantName = concernRoleObj
          .readConcernRoleName(concernRoleKey).concernRoleName;
      caseSpecialCautionDetailsList.list.addRef(caseSpecialCautionDetails);

    }
    return caseSpecialCautionDetailsList;
  }

  // END, CR00226543

  // BEGIN, CR00225060, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  // BEGIN, CR00409050, SG
  @AccessLevel(AccessLevelType.EXTERNAL)
  // END, CR00409050
  public ListICClientRoleDetails1 listCaseMembers1(final ListICClientKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICClientRoleDetails1 listICClientRoleDetails = new ListICClientRoleDetails1();

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRoleKey = new ViewCaseParticipantRole_boKey();

    // ICMemberContextDescriptionKey object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read list of client roles
    viewCaseParticipantRoleKey.dtls.caseID = key.caseID;
    // BEGIN CR00108989, GBA
    viewCaseParticipantRoleKey.showOnlyActive = key.showOnlyActive;
    // END CR00108989

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRoleKey);

    // Reserve space in participantList
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      listICClientRoleDetails.participantList
          .addRef(viewCaseParticipantRoleDetailsList.dtls.item(i));
      // ENV_DISPLAY_PRIMARYCLIENT_IC
      // BEGIN 206408 IK
      if (!Configuration.getBooleanProperty(
          EnvVars.ENV_DISPLAY_PRIMARYCLIENT_IC,
          EnvVars.ENV_DISPLAY_PRIMARYCLIENT_IC_DEFAULT)
          && viewCaseParticipantRoleDetailsList.dtls.item(i).typeCode
              .equals(CASEPARTICIPANTROLETYPE.PRIMARY)) {
        viewCaseParticipantRoleDetailsList.dtls
            .item(i).typeCode = CASEPARTICIPANTROLETYPE.MEMBER;
      }
      // END, 206408

    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // BEGIN, CR00304790, PB
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final IntegratedCaseKey integratedCaseKey = CaseHeaderFactory.newInstance()
        .readIntegratedCaseIDByCaseID(caseKey);

    if (0 != integratedCaseKey.integratedCaseID) {

      listICClientRoleDetails.contextDescription = getIntegratedCaseContextDescription(
          icContextDescriptionKey);
      integratedCaseMenuDataKey.caseID = key.caseID;
      listICClientRoleDetails.icMenuData = getIntegratedCaseMenuData(
          integratedCaseMenuDataKey);
    }
    // END, CR00304790
    // BEGIN, CR00150390, PDN
    final curam.core.facade.intf.Case caseObj = curam.core.facade.fact.CaseFactory
        .newInstance();

    final ReadRelationshipListForCaseMemberKey relationshipkey = new ReadRelationshipListForCaseMemberKey();

    relationshipkey.caseID = key.caseID;

    // Set the relatedNonMembersInd depending on if there are related
    // concerns
    // not
    // already case members
    listICClientRoleDetails.relatedNonMembersInd = caseObj
        .listRelationshipForCaseMember1(relationshipkey).dtls.dtls.size() != 0;
    // END, CR00150390

    return listICClientRoleDetails;
  }

  // END, CR00225060

  // BEGIN, CR00229496, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CreateIntegratedCaseResultAndMessages createIntegratedCaseAndRegisterPerson(
      final CreateICAndRegisterPerson createICAndRegisterPerson)
      throws AppException, InformationalException {

    CreateIntegratedCaseResult createIntegratedCaseResult = new CreateIntegratedCaseResult();

    final CreateIntegratedCaseResultAndMessages createIntegratedCaseResultAndMessages = new CreateIntegratedCaseResultAndMessages();

    // Register a new person
    PersonRegistrationResult personRegistrationResult = new PersonRegistrationResult();

    final PersonRegistrationDetails personRegistrationDetails = new PersonRegistrationDetails();

    personRegistrationDetails.personRegistrationDetails = createICAndRegisterPerson.personDtls;

    personRegistrationResult = curam.core.facade.fact.PersonFactory
        .newInstance().register(personRegistrationDetails);

    // Pass the concernRoleID for the newly registered person to the create
    // integrated case methods
    CreateIntegratedCaseDetails1 createIntegratedCaseDetails = new CreateIntegratedCaseDetails1();

    createIntegratedCaseDetails = createICAndRegisterPerson.caseDtls;
    createIntegratedCaseDetails.primaryClientID = personRegistrationResult.registrationIDDetails.concernRoleID;

    createIntegratedCaseResult = IntegratedCaseFactory.newInstance()
        .createIntegratedCase1(createIntegratedCaseDetails);

    createIntegratedCaseResultAndMessages.createCaseResult = createIntegratedCaseResult;

    createIntegratedCaseResultAndMessages.warnings = personRegistrationResult.warnings;

    return createIntegratedCaseResultAndMessages;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CreateIntegratedCaseResultAndMessages createIntegratedCaseAndRegisterProspectPerson(
      final CreateICAndRegisterProspectPerson createICAndRegisterProspectPerson)
      throws AppException, InformationalException {

    final CreateIntegratedCaseResultAndMessages createIntegratedCaseResultAndMessages = new CreateIntegratedCaseResultAndMessages();
    CreateIntegratedCaseResult createIntegratedCaseResult = new CreateIntegratedCaseResult();
    // Register a new person
    // BEGIN, CR00348318, GA
    ProspectPersonRegistrationResult prospectPersonRegistrationIDDetails;

    final ProspectPersonRegistrationDetails registerProspectPersonDetails = new ProspectPersonRegistrationDetails();

    // BEGIN, CR00386007, VT
    validateProspectPersonEstimatedAge(createICAndRegisterProspectPerson);

    if (CuramConst.gkStringZero.equals(
        createICAndRegisterProspectPerson.prospectDtls.estimatedFromAgeOpt)) {

      createICAndRegisterProspectPerson.prospectDtls.fromAge = CuramConst.gkMinusOne;

    } else if (createICAndRegisterProspectPerson.prospectDtls.estimatedFromAgeOpt
        .isEmpty()) {

      createICAndRegisterProspectPerson.prospectDtls.fromAge = CuramConst.gkZero;

    } else {

      createICAndRegisterProspectPerson.prospectDtls.fromAge = Integer.parseInt(
          createICAndRegisterProspectPerson.prospectDtls.estimatedFromAgeOpt);

    }

    if (CuramConst.gkStringZero.equals(
        createICAndRegisterProspectPerson.prospectDtls.estimatedToAgeOpt)) {

      createICAndRegisterProspectPerson.prospectDtls.toAge = CuramConst.gkMinusOne;

    } else if (createICAndRegisterProspectPerson.prospectDtls.estimatedToAgeOpt
        .isEmpty()) {

      createICAndRegisterProspectPerson.prospectDtls.toAge = CuramConst.gkZero;

    } else {

      createICAndRegisterProspectPerson.prospectDtls.toAge = Integer.parseInt(
          createICAndRegisterProspectPerson.prospectDtls.estimatedToAgeOpt);
    }
    // END, CR00386007

    registerProspectPersonDetails.prospectPersonRegistrationDtls
        .assign(createICAndRegisterProspectPerson.prospectDtls);

    registerProspectPersonDetails.prospectPersonRegistrationDtls.addressData = createICAndRegisterProspectPerson.prospectDtls.addressData;

    // BEGIN, CR00236822, PB
    registerProspectPersonDetails.prospectPersonRegistrationDtls.addressType = CONCERNROLEADDRESSTYPEEntry.PRIVATE
        .getCode();
    // END, CR00236822

    prospectPersonRegistrationIDDetails = curam.core.facade.fact.ProspectPersonFactory
        .newInstance().registerProspectPerson(registerProspectPersonDetails);
    // END, CR00348318

    // Pass the concernRoleID for the newly registered person to the create
    // integrated case methods
    CreateIntegratedCaseDetails1 createIntegratedCaseDetails = new CreateIntegratedCaseDetails1();

    createIntegratedCaseDetails = createICAndRegisterProspectPerson.caseDtls;
    createIntegratedCaseDetails.primaryClientID = prospectPersonRegistrationIDDetails.registrationIDDetails.concernRoleID;

    createIntegratedCaseResult = IntegratedCaseFactory.newInstance()
        .createIntegratedCase1(createIntegratedCaseDetails);

    createIntegratedCaseResultAndMessages.createCaseResult = createIntegratedCaseResult;

    createIntegratedCaseResultAndMessages.warnings = prospectPersonRegistrationIDDetails.warnings;

    return createIntegratedCaseResultAndMessages;
  }

  // END, CR00229496

  // START,CR00236909
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadIntegratedCaseDetails1 readCaseDetails2(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ReadIntegratedCaseDetails1 readIntegratedCaseDetails = new ReadIntegratedCaseDetails1();

    // BEGIN, 200626 JJ
    readIntegratedCaseDetails.displayICClientsOpt = Configuration
        .getBooleanProperty(EnvVars.ENV_DISPLAY_CASE_CLIENTS_IC_HOME);
    // END, 200626

    // IntegratedCaseHome manipulation variables
    final curam.core.intf.IntegratedCaseHome integratedCaseHomeObj = curam.core.fact.IntegratedCaseHomeFactory
        .newInstance();
    final IntegratedCaseHomeKey integratedCaseHomeKey = new IntegratedCaseHomeKey();
    // BEGIN, CR00092078, SPD
    GetFurtherDetailsResult getFurtherDetailsResult = new GetFurtherDetailsResult();

    final ListICClientKey listICClientKey = new ListICClientKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();
    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();
    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();
    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory
        .newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883
    // Set key to read details
    integratedCaseHomeKey.caseID = key.caseID;
    // BEGIN, CR00092078, SPD
    // Read back the case details
    getFurtherDetailsResult = integratedCaseHomeObj
        .getFurtherDetails(integratedCaseHomeKey);
    // Assign the case detail to the return object
    readIntegratedCaseDetails.details
        .assign(getFurtherDetailsResult.integratedCaseFurtherDtls);

    // Assign the special caution display indicator to the return object
    readIntegratedCaseDetails.details.specialCautionIndicator = getFurtherDetailsResult.specialCautionIndicator;

    // Populate the bookmark indicator for the case
    readIntegratedCaseDetails.caseIsUserBookmarkInd = getFurtherDetailsResult.caseIsUserBookmarkInd;
    // END, CR00092078

    // BEGIN, CR00278729, SK
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.participantRoleID = readIntegratedCaseDetails.details.concernRoleID;
    readByParticipantRoleTypeAndCaseKey.caseID = readIntegratedCaseDetails.details.caseID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
        .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
            readByParticipantRoleTypeAndCaseKey);

    // Assign caseParticipantRoleID to the return object
    readIntegratedCaseDetails.details.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478
    // END, CR00278729

    // Set key to call local method listMemberDetails
    listICClientKey.caseID = key.caseID;
    // BEGIN, CR00160706, PDN
    listICClientKey.showOnlyActive = true;
    // END, CR00160706

    // BEGIN, CR00225060, ZV
    final ListICClientRoleDetails1 listICClientRoleDetails = listCaseMembers1(
        listICClientKey);

    // END, CR00225060

    for (int i = 0; i < listICClientRoleDetails.participantList.size(); i++) {

      final MemberDetails memberDetails = new MemberDetails();

      memberDetails.assign(listICClientRoleDetails.participantList.item(i));

      readIntegratedCaseDetails.memberDetailsList.memberDetailsList.dtls
          .addRef(memberDetails);

    }

    // Set the key to read the case product list.
    final curam.core.facade.struct.IntegratedCaseIDKey integratedCaseIDKey = new curam.core.facade.struct.IntegratedCaseIDKey();

    integratedCaseIDKey.caseID = key.caseID;

    // Read the list of products.
    ListICProductDeliveryDetails listProductDetails;

    listProductDetails = listProduct(integratedCaseIDKey);

    final ListICProductDeliveryDetails listLiabilityProductDetails = listLiabilityProduct(
        integratedCaseIDKey);
    // The product details which will be assigned.
    ICProductDetails icProductDetails;

    // Reserve space in productDetails
    readIntegratedCaseDetails.productDetails
        .ensureCapacity(listProductDetails.dtls.size()
            + listLiabilityProductDetails.dtls.size());

    // Assign the list of products.
    for (int i = 0; i < listProductDetails.dtls.size(); i++) {

      // BEGIN, CR00240898, KH
      // Do not include Net Zero payment correction cases in the list
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = listProductDetails.dtls.item(i).caseID;

      if (paymentCorrection.isNetZeroPaymentCorrection(caseHeaderKey)) {
        continue;
      }
      // END, CR00240898

      icProductDetails = new ICProductDetails();

      icProductDetails.assign(listProductDetails.dtls.item(i));

      // BEGIN, CR00278729, SK
      // BEGIN, CR00305478, MV
      readByParticipantRoleTypeAndCaseKey.participantRoleID = listProductDetails.dtls
          .item(i).concernRoleID;
      readByParticipantRoleTypeAndCaseKey.caseID = listProductDetails.dtls
          .item(i).caseID;
      readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
      readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

      readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
              readByParticipantRoleTypeAndCaseKey);

      // Assign caseParticipantRoleID to the return object
      icProductDetails.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
      // END, CR00305478
      // END, CR00278729

      readIntegratedCaseDetails.productDetails.addRef(icProductDetails);
    }

    // Assign the list of liability products.
    for (int i = 0; i < listLiabilityProductDetails.dtls.size(); i++) {

      // BEGIN, CR00240898, KH
      // Do not include Net Zero payment correction cases in the list
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = listLiabilityProductDetails.dtls.item(i).caseID;

      if (paymentCorrection.isNetZeroPaymentCorrection(caseHeaderKey)) {
        continue;
      }
      // END, CR00240898

      icProductDetails = new ICProductDetails();

      // For Liability Product Type is returning as Empty.
      // So perform this action to set the Product Type.
      final ReadICProductHomePageKey readICProductKey = new ReadICProductHomePageKey();

      readICProductKey.caseID = listLiabilityProductDetails.dtls.item(i).caseID;
      final ReadICProductHomePageDetails1 readICLiability = readICProductHomePageDetails1(
          readICProductKey);
      final long productID = readICLiability.details.productID;
      final curam.core.facade.intf.Product productObj = ProductFactory
          .newInstance();
      final ProductKeyStruct productKey = new ProductKeyStruct();

      productKey.productID = productID;
      final curam.core.facade.struct.ReadLiabilityProductStruct1 readLiabilityProduct = productObj
          .readLiabilityProduct1(productKey);

      listLiabilityProductDetails.dtls.item(
          i).productType = readLiabilityProduct.liabilityProductDetails.typeCode;
      // End of Temporary Fix.
      icProductDetails.assign(listLiabilityProductDetails.dtls.item(i));

      // BEGIN, CR00278729, SK
      // BEGIN, CR00305478, MV
      readByParticipantRoleTypeAndCaseKey.participantRoleID = listLiabilityProductDetails.dtls
          .item(i).concernRoleID;
      readByParticipantRoleTypeAndCaseKey.caseID = listLiabilityProductDetails.dtls
          .item(i).caseID;
      readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
      readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

      readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
              readByParticipantRoleTypeAndCaseKey);

      // Assign caseParticipantRoleID to the return object
      icProductDetails.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
      // END, CR00305478
      // END, CR00278729

      readIntegratedCaseDetails.productDetails.addRef(icProductDetails);
    }
    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;
    // Read context description and assign to return object
    readIntegratedCaseDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);
    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;
    // Read menu data and assign to return object
    readIntegratedCaseDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);
    // Read Transaction Log Details
    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;
    // BEGIN CR00108134, GBA
    readIntegratedCaseDetails.transactionDtls.assign(
        caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134
    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;
    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883
    // BEGIN, CR00150390, PDN
    final curam.core.facade.intf.Case caseObj = curam.core.facade.fact.CaseFactory
        .newInstance();
    final ReadRelationshipListForCaseMemberKey relationshipkey = new ReadRelationshipListForCaseMemberKey();

    relationshipkey.caseID = key.caseID;
    // Set the relatedNonMembersInd depending on if
    // there are related concerns not already case members
    if (caseObj.listRelationshipForCaseMember1(relationshipkey).dtls.dtls
        .size() != 0) {
      readIntegratedCaseDetails.relatedNonMembersInd = true;
    } else {
      readIntegratedCaseDetails.relatedNonMembersInd = false;
    }
    // END, CR00150390

    // BEGIN, CR00150402, PDN
    // If the case is closed then need to populate the close
    // details for the case.
    if (readIntegratedCaseDetails.details.statusCode
        .equals(curam.codetable.CASESTATUS.CLOSED)) {
      // Set the case close indicator
      readIntegratedCaseDetails.isCaseClosedInd = true;
      // CaseStatus manipulation variables
      final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory
          .newInstance();
      CaseStatusDtls caseStatusDtls;
      final CurrentCaseStatusKey currCaseStatusKey = new CurrentCaseStatusKey();

      currCaseStatusKey.caseID = key.caseID;
      currCaseStatusKey.nullDate = curam.util.type.Date.kZeroDate;
      // Read current status by retrieved Case ID to get the closure details
      // BEGIN, CR00224271, ZV
      caseStatusDtls = caseStatusObj
          .readCurrentStatusByCaseID1(currCaseStatusKey);
      // END, CR00224271
      // Populate the user's full name
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = caseStatusDtls.userName;
      readIntegratedCaseDetails.closureDtls.userFullName = usersObj
          .read(usersKey).fullName;
      readIntegratedCaseDetails.closureDtls.comments = caseStatusDtls.comments;
      readIntegratedCaseDetails.closureDtls.reasonCode = caseStatusDtls.reasonCode;
      readIntegratedCaseDetails.closureDtls.closureDate = caseStatusDtls.startDate;
      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage = new LocalisableString(
          curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage
          .arg(readIntegratedCaseDetails.closureDtls.userFullName);
      // Add the closure date
      dateUserNameMessage
          .arg(readIntegratedCaseDetails.closureDtls.closureDate);
      // END, CR00166458
      readIntegratedCaseDetails.closureDtls.closureDateAndUserFullName = dateUserNameMessage
          .toClientFormattedText();
      // END, CR00163613
    }
    // END, CR00150402
    return readIntegratedCaseDetails;
  }

  // END,CR00236909

  // START,CR00236909

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListICProductDeliveryDetails listLiabilityProduct(
      final curam.core.facade.struct.IntegratedCaseIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ListICProductDeliveryDetails listICProductDeliveryDetails = new ListICProductDeliveryDetails();
    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory
        .newInstance();
    final CasesByCaseIDAndTypeKey casesByCaseIDAndTypeKey = new CasesByCaseIDAndTypeKey();
    final CasesByCaseIDConcernAndTypeKey casesByCaseIDConcernAndTypeKey = new CasesByCaseIDConcernAndTypeKey();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Create a ICMemberContextDescriptionKey object
    // and read the context description into the return object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // ICMemberMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory
        .newInstance();

    if (key.concernRoleID == 0 && key.caseID != 0) {

      // Assign key details
      casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
      casesByCaseIDAndTypeKey.dtls.caseTypeCode = CASETYPECODE.LIABILITY;

      // Copy details to return object
      caseAndConcernSummaryDtlsList = maintainCaseObj
          .listCasesByTypeAndParentCaseID(casesByCaseIDAndTypeKey);

    } else {

      // Assign key details
      casesByCaseIDConcernAndTypeKey.dtls.concernRoleID = key.concernRoleID;
      casesByCaseIDConcernAndTypeKey.dtls.caseID = key.caseID;
      casesByCaseIDConcernAndTypeKey.dtls.caseTypeCode = CASETYPECODE.LIABILITY;

      // Copy details to return object
      caseAndConcernSummaryDtlsList = maintainCaseObj
          .listCasesByTypeConcernRoleIDAndParentCaseID(
              casesByCaseIDConcernAndTypeKey);

    }

    ICProductDeliveryDetails icProductDeliveryDetails;

    // Reserve space in listICProductDeliveryDetails list
    listICProductDeliveryDetails.dtls
        .ensureCapacity(caseAndConcernSummaryDtlsList.list.dtls.size());

    for (int i = 0; i < caseAndConcernSummaryDtlsList.list.dtls.size(); i++) {

      icProductDeliveryDetails = new ICProductDeliveryDetails();
      icProductDeliveryDetails
          .assign(caseAndConcernSummaryDtlsList.list.dtls.item(i));

      // BEGIN, CR00305478, MV
      // BEGIN, CR00278729, SK
      final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

      readByParticipantRoleTypeAndCaseKey.participantRoleID = caseAndConcernSummaryDtlsList.list.dtls
          .item(i).concernRoleID;
      readByParticipantRoleTypeAndCaseKey.caseID = key.caseID;
      readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
      readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

      final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
              readByParticipantRoleTypeAndCaseKey);

      // END, CR00278729

      // Assign caseParticipantRoleID to the return object
      icProductDeliveryDetails.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
      // END, CR00305478

      listICProductDeliveryDetails.dtls.addRef(icProductDeliveryDetails);
    }

    for (int i = 0; i < listICProductDeliveryDetails.dtls.size(); i++) {

      concernRoleKey.concernRoleID = listICProductDeliveryDetails.dtls
          .item(0).concernRoleID;
      final ConcernRoleDtls concernRoleDtls = concernRoleObj
          .read(concernRoleKey);

      listICProductDeliveryDetails.dtls
          .item(0).concernRoleType = concernRoleDtls.concernRoleType;
    }
    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;
    // Read context description
    listICProductDeliveryDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);
    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;
    // Read menu data
    listICProductDeliveryDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);
    return listICProductDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00243612, EC
  @Override
  public CaseIDAndParticipantRoleIDDetails readCaseIDandParticipantRoleIDDetails(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    final CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory
        .newInstance();

    final CaseParticipantRoleKey slKey = new CaseParticipantRoleKey();

    slKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;
    final CaseIDAndParticipantRoleIDDetails details = caseParticipantRole
        .readCaseIDandParticipantID(slKey);

    return details;
  }

  // END, CR00243612

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CommunicationDetailList listFilteredCommunication(
      final CommunicationFilterKey key)
      throws AppException, InformationalException {

    CommunicationDetailList communicationDetailList = new CommunicationDetailList();

    // BEGIN, CR00399621, KRK
    final ReadProFormaCommKey readProFormaCommKey = new ReadProFormaCommKey();

    // END, CR00399621

    // If the value for name is 'All' and the concernRoleID is 0 return all
    // of the communications for the case
    if (key.concernRoleID == 0) {

      final ListCommunicationsKey listCommunicationsKey = new ListCommunicationsKey();

      listCommunicationsKey.caseID = key.caseID;

      communicationDetailList = CaseFactory.newInstance()
          .listCaseCommunication(listCommunicationsKey);

    } // A case member has been selected display the communications for them
    else {
      final CommunicationKey communicationKey = new CommunicationKey();

      communicationKey.caseID = key.caseID;
      communicationKey.concernRoleID = key.concernRoleID;

      final CaseMemberCommDetailsList caseMemberCommDetailsList = curam.core.sl.fact.CommunicationFactory
          .newInstance().listRegardingCaseMemberCommunication(communicationKey);

      // Assign the details returned to a new struct that also contains
      // the
      // display indicators and fields required for the actions
      String communicationFormat = "";
      CommunicationAndListRowActionDetails communicationDtls;

      // BEGIN, CR00294269, IBM
      for (final CaseMemberCommunicationDetails caseMemberCommunicationDetails : caseMemberCommDetailsList.dtls
          .items()) {
        // END, CR00294269

        communicationDtls = new CommunicationAndListRowActionDetails();

        // BEGIN, CR00294269, IBM
        communicationDtls.assign(caseMemberCommunicationDetails);

        if (RECORDSTATUS.CANCELLED.equals(communicationDtls.statusCode)) {
          // END, CR00294269

          communicationDtls.canceledInd = true;

          // BEGIN, CR00303767, IBM
          // BEGIN, CR00399621, KRK
          if (COMMUNICATIONFORMAT.MSWORD
              .equals(communicationDtls.communicationFormat)) {
            communicationDtls.msWordInd = true;
          } else if (COMMUNICATIONFORMAT.PROFORMA
              .equals(communicationDtls.communicationFormat)) {
            readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
            communicationDtls.localeIdentifier = CommunicationFactory
                .newInstance().readProForma1(
                    readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
          }
          // END, CR00399621
          // END, CR00303767
        } else {
          communicationFormat = communicationDtls.communicationFormat;

          // BEGIN, CR00294269, IBM
          if (COMMUNICATIONFORMAT.EMAIL.equals(communicationFormat)
              && COMMUNICATIONSTATUS.DRAFT
                  .equals(communicationDtls.communicationStatus)) {
            // END, CR00294269

            communicationDtls.draftEmailInd = true;

            // BEGIN, CR00294269, IBM
          } else if (COMMUNICATIONFORMAT.MSWORD.equals(communicationFormat)) {
            // END, CR00294269

            communicationDtls.msWordInd = true;

            final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

            attachmentLinkKey.attachmentLinkID = communicationDtls.communicationID;

            AttachmentLinkDetails attachmentLinkDetails;

            try {
              attachmentLinkDetails = AttachmentFactory.newInstance()
                  .readAttachment(attachmentLinkKey);

              communicationDtls.attachmentDtls.attachmentName = attachmentLinkDetails.attachmentDtls.attachmentName;
              communicationDtls.attachmentDtls.attachmentContents = attachmentLinkDetails.attachmentDtls.attachmentContents;

            } catch (final RecordNotFoundException rnfe) {// Do
              // nothing
              // there
              // are
              // no
              // attachments
              // associated
              // with
              // this communication
            }

            // BEGIN, CR00294269, IBM
          } else if (COMMUNICATIONFORMAT.PROFORMA.equals(communicationFormat)) {
            // END, CR00294269

            communicationDtls.proFormaInd = true;

            // BEGIN, CR00399621, KRK
            readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
            communicationDtls.localeIdentifier = CommunicationFactory
                .newInstance().readProForma1(
                    readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
          }
        }
        // Get the delete page link
        communicationDtls.deletePage.deletePageName = CommunicationFactory
            .newInstance().getDeletePageName(communicationDtls).deletePageName;
        // END, CR00399621

        // Add this list item to the return struct
        communicationDetailList.communicationDtls.addRef(communicationDtls);
      }

    }

    return communicationDetailList;
  }

  // BEGIN, CR00266603, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listDeductionCaseParticipantWithoutProspect(
      final ListMemberDetailsKey key)
      throws AppException, InformationalException {

    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    MemberDetails memberDetails;

    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory
        .newInstance();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
          .newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      servicePlanSecurityKey.caseID = key.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

    listMemberDetails.memberDetailsList.dtls
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      if (!viewCaseParticipantRoleDetailsList.dtls.item(i).recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {

        // filter out prospect persons and prospect employers
        if (!viewCaseParticipantRoleDetailsList.dtls.item(i).participantRoleType
            .equals(CONCERNROLETYPE.PROSPECTPERSON)
            && !viewCaseParticipantRoleDetailsList.dtls
                .item(i).participantRoleType
                    .equals(CONCERNROLETYPE.PROSPECTEMPLOYER)) {

          memberDetails = new MemberDetails();

          final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

          concernRolesDetails.concernRoleID = viewCaseParticipantRoleDetailsList.dtls
              .item(i).participantRoleID;
          concernRolesDetails.concernRoleType = viewCaseParticipantRoleDetailsList.dtls
              .item(i).participantRoleType;
          concernRolesDetails.concernRoleName = viewCaseParticipantRoleDetailsList.dtls
              .item(i).name;

          memberDetails.name = maintainConcernRoleDetailsObj
              .appendAgeToName(concernRolesDetails).concernRoleName;
          memberDetails.participantRoleID = concernRolesDetails.concernRoleID;
          memberDetails.caseParticipantRoleID = viewCaseParticipantRoleDetailsList.dtls
              .item(i).caseParticipantRoleID;
          // BEGIN, CR00446316, YF
          memberDetails.nameAndAgeOpt = viewCaseParticipantRoleDetailsList.dtls
              .item(i).nameAndAgeOpt;
          // END, CR00446316, YF
          listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);

        }
      }
    }

    return listMemberDetails;
  }

  // END, CR00266603

  // BEGIN, CR00279713, AC
  /**
   * {@inheritDoc}
   */

  @Override
  public ConcernRoleID readConcernRoleID(
      final curam.core.facade.struct.CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    final ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = readMemberDetails(key).details.concernRoleID;
    return concernRoleID;
  }

  // END, CR00279713

  // BEGIN, CR00282451, VMI
  /**
   * {@inheritDoc}
   */
  @Override
  public void reopenCase(final ReactivationDetails reactivationDetails)
      throws AppException, InformationalException {

    final ReactivationDtls reactivationDtls = new ReactivationDtls();

    reactivationDtls.assign(reactivationDetails);
    final curam.core.intf.IntegratedCase integratedCaseObj = curam.core.fact.IntegratedCaseFactory
        .newInstance();

    integratedCaseObj.reopenICCase(reactivationDtls);
  }

  // END, CR00282451
  // END, CR00236909

  // BEGIN, CR00290743, PMD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listCaseParticipantsWithAge(
      final ListMemberDetailsKey key)
      throws AppException, InformationalException {

    final ListMemberDetails listMemberDetails = new ListMemberDetails();

    listMemberDetails.showCaseParticipantCluster = true;

    if (key.caseID == 0) {
      listMemberDetails.showCaseParticipantCluster = false;
    } else {

      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = key.caseID;

      // read case type code
      final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance()
          .readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {
        final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

        servicePlanSecurityKey.caseID = key.caseID;
        servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;
        curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance()
            .checkSecurity(servicePlanSecurityKey);
      }

      final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

      viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

      // Read the list of case participant roles
      final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = CaseParticipantRoleFactory
          .newInstance()
          .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

      // Reserve space in memberDetailsList
      listMemberDetails.memberDetailsList.dtls
          .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

      for (final CaseParticipantRole_eoFullDetails caseParticipantRole_eoFullDetails : viewCaseParticipantRoleDetailsList.dtls) {

        if (!caseParticipantRole_eoFullDetails.recordStatus
            .equals(RECORDSTATUS.CANCELLED)) {

          final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

          concernRolesDetails.concernRoleID = caseParticipantRole_eoFullDetails.participantRoleID;
          concernRolesDetails.concernRoleType = caseParticipantRole_eoFullDetails.participantRoleType;
          concernRolesDetails.concernRoleName = caseParticipantRole_eoFullDetails.name;

          final MemberDetails memberDetails = new MemberDetails();

          memberDetails.name = MaintainConcernRoleDetailsFactory.newInstance()
              .appendAgeToName(concernRolesDetails).concernRoleName;
          // BEGIN, CR00446316, YF
          memberDetails.nameAndAgeOpt = caseParticipantRole_eoFullDetails.nameAndAgeOpt;
          // END, CR00446316, YF
          memberDetails.participantRoleID = concernRolesDetails.concernRoleID;
          memberDetails.caseParticipantRoleID = caseParticipantRole_eoFullDetails.caseParticipantRoleID;
          listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
        }
      }
    }
    return listMemberDetails;
  }

  // END, CR00290743

  // BEGIN, CR00305740, PB
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public ListMemberDetails listCaseParticipantsDetailsForContactLog(
      final ListMemberDetailsKey listMemberDetailsKey)
      throws AppException, InformationalException {

    final ListMemberDetails listMemberDetails = new ListMemberDetails();
    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    final InvestigationConfigKey investigationConfigKey = new InvestigationConfigKey();
    final ScreeningKey screeningKey = new ScreeningKey();
    final ScreeningConfigurationKey screeningConfigurationKey = new ScreeningConfigurationKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final IntegratedCaseTypeStruct integratedCaseTypeStruct = new IntegratedCaseTypeStruct();
    AdminIntegratedCaseDtls adminIntegratedCaseDtls = new AdminIntegratedCaseDtls();
    ScreeningConfigurationDtls screeningConfigurationDtls = new ScreeningConfigurationDtls();
    InvestigationConfigDtls investigationConfigDtls = new InvestigationConfigDtls();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    final ListICClientRoleDetails listICClientRoleDetails = new ListICClientRoleDetails();
    // BEGIN, CR00306249, PB
    CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    MemberDetails memberDetails;
    // END, CR00306249
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory
        .newInstance();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = listMemberDetailsKey.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (CASETYPECODE.INVESTIGATIONCASE.equals(caseTypeCode.caseTypeCode)) {

      investigationDeliveryKey.caseID = listMemberDetailsKey.caseID;
      final InvestigationDeliveryDtls investigationDeliveryDtls = curam.core.sl.entity.fact.InvestigationDeliveryFactory
          .newInstance().read(nfIndicator, investigationDeliveryKey);

      investigationConfigKey.investigationConfigID = investigationDeliveryDtls.investigationConfigID;
      investigationConfigDtls = InvestigationConfigFactory.newInstance()
          .read(nfIndicator, investigationConfigKey);
    } else if (CASETYPECODE.SCREENINGCASE.equals(caseTypeCode.caseTypeCode)) {

      screeningKey.caseID = listMemberDetailsKey.caseID;
      final ScreeningDtls screeningDtls = ScreeningFactory.newInstance()
          .read(nfIndicator, screeningKey);

      screeningConfigurationKey.screeningConfigID = screeningDtls.screeningConfigID;
      screeningConfigurationDtls = ScreeningConfigurationFactory.newInstance()
          .read(nfIndicator, screeningConfigurationKey);
    } else if (CASETYPECODE.INTEGRATEDCASE.equals(caseTypeCode.caseTypeCode)) {

      caseHeaderKey.caseID = listMemberDetailsKey.caseID;
      final CaseHeaderDtls integratedCaseHeaderDtls = CaseHeaderFactory
          .newInstance().read(caseHeaderKey);

      integratedCaseTypeStruct.integratedCaseType = integratedCaseHeaderDtls.integratedCaseType;
      adminIntegratedCaseDtls = AdminIntegratedCaseFactory.newInstance()
          .readAdminIntegratedCaseByType(nfIndicator, integratedCaseTypeStruct);
    }
    final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID = listMemberDetailsKey.caseID;
    // BEGIN, CR00385210, GA
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
        .listICParticipantsForContactLog(viewCaseParticipantRole_boKey);
    // END, CR00385210
    listICClientRoleDetails.participantList
        .ensureCapacity(viewCaseParticipantRoleDetailsList.dtls.size());

    for (final CaseParticipantRole_eoFullDetails viewCaseParticipantRoleDetails : viewCaseParticipantRoleDetailsList.dtls
        .items()) {
      // BEGIN, CR00306249, PB
      caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();
      // END, CR00306249
      caseParticipantRoleFullDetails.assign(viewCaseParticipantRoleDetails);
      listICClientRoleDetails.participantList
          .addRef(caseParticipantRoleFullDetails);
    }
    listMemberDetails.memberDetailsList.dtls
        .ensureCapacity(listICClientRoleDetails.participantList.size());

    for (final CaseParticipantRole_eoFullDetails viewCaseParticipantRoleDetails : listICClientRoleDetails.participantList
        .items()) {
      if (!RECORDSTATUS.CANCELLED
          .equals(viewCaseParticipantRoleDetails.recordStatus)) {
        // BEGIN, CR00306249, PB
        memberDetails = new MemberDetails();
        caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();
        // END, CR00306249
        caseParticipantRoleFullDetails.participantRoleID = viewCaseParticipantRoleDetails.participantRoleID;
        caseParticipantRoleFullDetails.name = viewCaseParticipantRoleDetails.name;
        // BEGIN, CR00446316, YF
        caseParticipantRoleFullDetails.nameAndAgeOpt = viewCaseParticipantRoleDetails.nameAndAgeOpt;
        // END, CR00446316, YF
        caseParticipantRoleFullDetails.typeCode = viewCaseParticipantRoleDetails.typeCode;
        caseParticipantRoleFullDetails.caseParticipantRoleID = viewCaseParticipantRoleDetails.caseParticipantRoleID;
        if (investigationConfigDtls.contactLogInd
            || screeningConfigurationDtls.contactLogInd
            || adminIntegratedCaseDtls.contactLogInd) {

          if (CASEPARTICIPANTROLETYPE.PRIMARY
              .equals(caseParticipantRoleFullDetails.typeCode)
              || CASEPARTICIPANTROLETYPE.MEMBER
                  .equals(caseParticipantRoleFullDetails.typeCode)) {

            memberDetails.assign(caseParticipantRoleFullDetails);
            listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
          }
        } else {

          memberDetails.assign(caseParticipantRoleFullDetails);
          listMemberDetails.memberDetailsList.dtls.addRef(memberDetails);
        }
      }

    }

    return listMemberDetails;
  }

  // END, CR00305740

  // BEGIN, CR00320920, KRK
  /**
   * {@inheritDoc}
   */
  @Override
  public ListCaseContractDetails listContractDetails(
      final ListContractKey listContractKey)
      throws AppException, InformationalException {

    final ListCaseContractDetails listCaseContractDetails = new ListCaseContractDetails();
    final CaseContractCaseIDKey caseContractCaseIDKey = new CaseContractCaseIDKey();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID = new CaseParticipantRole_eoCaseParticipantRoleID();
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    caseContractCaseIDKey.assign(listContractKey);

    final ReadAllCaseContractsDtlsList readAllCaseContractsDtlsList = MaintainCaseContractFactory
        .newInstance().readAllCaseContracts(caseContractCaseIDKey);
    final ListCaseContractDetails caseContractDetailsList = new ListCaseContractDetails();

    caseContractDetailsList.contractDetailsList.dtls
        .ensureCapacity(readAllCaseContractsDtlsList.dtls.size());

    caseContractDetailsList.contractDetailsList
        .assign(readAllCaseContractsDtlsList);

    for (final IntegratedCaseContractDetails integratedCaseContractDetails : caseContractDetailsList.contractDetailsList.dtls
        .items()) {

      concernRoleKey.concernRoleID = integratedCaseContractDetails.concernRoleID;

      final ConcernRoleTypeDetails concernRoleTypeDetails = ConcernRoleFactory
          .newInstance().readConcernRoleType(concernRoleKey);

      integratedCaseContractDetails.concernRoleType = concernRoleTypeDetails.concernRoleType;

      caseIDParticipantRoleKey.participantRoleID = integratedCaseContractDetails.concernRoleID;
      caseIDParticipantRoleKey.caseID = listContractKey.caseID;

      caseParticipantRoleCaseParticipantRoleID = curam.core.sl.entity.fact.CaseParticipantRoleFactory
          .newInstance().readCaseParticipantRoleID(caseIDParticipantRoleKey);
      integratedCaseContractDetails.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

      listCaseContractDetails.contractDetailsList.dtls
          .addRef(integratedCaseContractDetails);
    }

    icContextDescriptionKey.caseID = listContractKey.caseID;

    // Read context description and assign to return object
    listCaseContractDetails.contextDescription = getIntegratedCaseContextDescription(
        icContextDescriptionKey);

    integratedCaseMenuDataKey.caseID = listContractKey.caseID;

    // Read menu data and assign to return object
    listCaseContractDetails.icMenuData = getIntegratedCaseMenuData(
        integratedCaseMenuDataKey);

    return listCaseContractDetails;
  }

  // END, CR00320920

  // BEGIN, CR00349362, GA
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseNomineeDeliveryPatternDetails readNearestDeliveryPatternForCaseNominee(
      final CaseNomineeAndEffectiveDateKey key)
      throws AppException, InformationalException {

    final CaseNomineeDeliveryPatternDetails caseNomineeDeliveryPatternDetails = new CaseNomineeDeliveryPatternDetails();
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();
    final CaseNominee caseNomineeObj = CaseNomineeFactory.newInstance();

    readEffectiveByDateKey.effectiveDate = key.effectiveDate;
    readEffectiveByDateKey.statusCode = RECORDSTATUSEntry.NORMAL.getCode();

    readEffectiveByDateKey.caseNomineeID = key.caseNomineeID;

    caseNomineeDeliveryPatternDetails.deliveryPatternDetails = caseNomineeObj
        .readNearestDeliveryPattern(readEffectiveByDateKey);
    return caseNomineeDeliveryPatternDetails;

  }

  // END, CR00349362

  // BEGIN, CR00386007, VT
  /**
   * Validates the estimated from age and estimated to age values.
   *
   * @param prospectPersonRegistrationDtls
   *          contains all prospect person registration details
   *
   * @throws AppException
   *           Application Exception
   * @throws InformationalException
   *           Informational Exception
   */
  public void validateProspectPersonEstimatedAge(
      final CreateICAndRegisterProspectPerson createICAndRegisterProspectPerson)
      throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    /**
     * Define the numeric pattern
     */
    final String NUMERIC_PATTERN = "[\\d]*";

    if (!Pattern.matches(NUMERIC_PATTERN,
        createICAndRegisterProspectPerson.prospectDtls.estimatedFromAgeOpt)) {

      final LocalisableString infoMessage = new LocalisableString(
          BPOPROSPECTPERSONREGISTRATION.ERR_FV_PROSPECT_PERSON_ESTIMATED_FROM_AGE_MUST_BE_A_WHOLE_NUMBER);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          infoMessage, GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError,
          ValidationManagerConst.kSetOne, 0);
    }

    if (!Pattern.matches(NUMERIC_PATTERN,
        createICAndRegisterProspectPerson.prospectDtls.estimatedToAgeOpt)) {
      final LocalisableString infoMessage = new LocalisableString(
          BPOPROSPECTPERSONREGISTRATION.ERR_FV_PROSPECT_PERSON_ESTIMATED_TO_AGE_MUST_BE_A_WHOLE_NUMBER);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          infoMessage, GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError,
          ValidationManagerConst.kSetOne, 0);
    }

    informationalManager.failOperation();

  }

  // END, CR00386007
  /**
   * Placeholder method used to add the Overview Renderer to the Case. This
   * currently returns an new instance of ReadOverviewDetails which is empty. We
   * may need to add detail to this in future.
   *
   * @return a new ReadOverviewDetails.
   */
  @Override
  public ReadOverviewDetails readOverview() {

    return new ReadOverviewDetails();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public MessageXMLResult readOverviewMessageXML()
      throws AppException, InformationalException {

    final MessageXMLResult messageXMLResult = new MessageXMLResult();

    Document document = null;
    final DocumentBuilder docBuilder = XMLParserCache.getDocumentBuilder();
    document = docBuilder.newDocument();

    final Element rootElement = document.createElement(XML_ELEMENT_MESSAGES);
    document.appendChild(rootElement);

    final Element noBenefitMessageElement = document
        .createElement(XML_ELEMENT_MESSAGE);
    rootElement.appendChild(noBenefitMessageElement);
    final Attr nameAttributeNoBenefit = document
        .createAttribute(XML_ATTRIBUTE_NAME);
    final LocalisableString overviewNoRecordsMessage = new LocalisableString(
        CASEOVERVIEWMESSAGES.NO_CURRENT_BENEFITS);
    nameAttributeNoBenefit
        .setValue(overviewNoRecordsMessage.getCatEntry().getEntry());
    noBenefitMessageElement.setAttributeNode(nameAttributeNoBenefit);
    final Attr valueAttributeNoBenefit = document
        .createAttribute(XML_ATTRIBUTE_VALUE);
    valueAttributeNoBenefit.setValue(overviewNoRecordsMessage
        .getMessage(TransactionInfo.getProgramLocale()));
    noBenefitMessageElement.setAttributeNode(valueAttributeNoBenefit);

    final Element caseTypeDisplayedtMessageElement = document
        .createElement(XML_ELEMENT_MESSAGE);
    rootElement.appendChild(caseTypeDisplayedtMessageElement);
    final Attr nameAttributeCaseTypes = document
        .createAttribute(XML_ATTRIBUTE_NAME);
    final LocalisableString caseTypesDisplayed = new LocalisableString(
        CASEOVERVIEWMESSAGES.CASE_TYPES_DISPLAYED);
    nameAttributeCaseTypes
        .setValue(caseTypesDisplayed.getCatEntry().getEntry());
    caseTypeDisplayedtMessageElement.setAttributeNode(nameAttributeCaseTypes);
    final Attr valueAttributeCaseTypes = document
        .createAttribute(XML_ATTRIBUTE_VALUE);
    valueAttributeCaseTypes.setValue(
        caseTypesDisplayed.getMessage(TransactionInfo.getProgramLocale()));
    caseTypeDisplayedtMessageElement.setAttributeNode(valueAttributeCaseTypes);

    final Element informationRetrievealErrorMessageElement = document
        .createElement(XML_ELEMENT_MESSAGE);
    rootElement.appendChild(informationRetrievealErrorMessageElement);
    final Attr nameAttributeInformationRetrievealError = document
        .createAttribute(XML_ATTRIBUTE_NAME);
    final LocalisableString informationRetrievealErrorDisplayed = new LocalisableString(
        CASEOVERVIEWMESSAGES.ERR_INFORMATION_RETRIEVEAL);
    nameAttributeInformationRetrievealError
        .setValue(informationRetrievealErrorDisplayed.getCatEntry().getEntry());
    informationRetrievealErrorMessageElement
        .setAttributeNode(nameAttributeInformationRetrievealError);
    final Attr valueAttributeInformationRetrievealError = document
        .createAttribute(XML_ATTRIBUTE_VALUE);
    valueAttributeInformationRetrievealError
        .setValue(informationRetrievealErrorDisplayed
            .getMessage(TransactionInfo.getProgramLocale()));
    informationRetrievealErrorMessageElement
        .setAttributeNode(valueAttributeInformationRetrievealError);

    messageXMLResult.xmlResult = XmlTools.convertDocumentToText(document);
    messageXMLResult.contentType = kContentType;

    return messageXMLResult;
  }

}
