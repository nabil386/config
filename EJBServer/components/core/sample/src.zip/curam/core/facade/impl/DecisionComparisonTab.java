/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.codetable.CASEDECISIONRESULTCODE;
import curam.codetable.PRODUCTTYPE;
import curam.core.facade.struct.DecisionComparisonHeaderDetails;
import curam.core.facade.struct.DecisionComparisonHeaderKey;
import curam.core.facade.struct.DecisionComparisonPageDetails;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CachedProductDeliveryFactory;
import curam.core.fact.CaseDecisionFactory;
import curam.core.sl.infrastructure.assessment.codetable.CASEDETERMINATIONINTERVALRESULT;
import curam.core.sl.infrastructure.assessment.impl.CREOLECaseDeterminationAccessor;
import curam.core.sl.infrastructure.assessment.impl.CREOLECaseDeterminationAccessorDAO;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculator;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.product.creole.fact.CREOLEProductFactory;
import curam.core.sl.infrastructure.product.creole.struct.CREOLEProductKey;
import curam.core.struct.CaseDecisionDtls;
import curam.core.struct.CaseDecisionKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ProductDeliveryKey;
import curam.message.GENERAL;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Reads the details required for the decision comparison tab.
 */
public abstract class DecisionComparisonTab extends curam.core.facade.base.DecisionComparisonTab {

  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  @Inject
  protected CREOLECaseDeterminationAccessorDAO creoleCaseDeterminationAccessorDAO;

  /**
   * Constructor.
   */
  public DecisionComparisonTab() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ____________________________________________________________________________
  /**
   * Reads the details required for the decision comparison tab.
   *
   * @param key
   * ID required to read the tab details.
   *
   * @return Details required for the decision comparison tab.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public DecisionComparisonHeaderDetails readDecisionComparisonTabDetail(
    final DecisionComparisonHeaderKey key) throws AppException,
      InformationalException {

    final DecisionComparisonHeaderDetails tabDetails = new DecisionComparisonHeaderDetails();

    // Get the new case decision details
    final CaseDecisionKey newCDKey = new CaseDecisionKey();

    newCDKey.caseDecisionID = key.newCaseDecisionID;

    // BEGIN, CR00404711, CR00411625, CSH
    // Get the product type
    final ProductDeliveryKey pdKey = new ProductDeliveryKey();
    CaseDecisionDtls newCaseDecisionDtls = null;

    // Get the new decision result
    try {

      newCaseDecisionDtls = CaseDecisionFactory.newInstance().read(newCDKey);

      pdKey.caseID = newCaseDecisionDtls.caseID;

      final CREOLECaseDeterminationAccessor newDetermination = creoleCaseDeterminationAccessorDAO.readByDecision(
        key.newCaseDecisionID);

      tabDetails.currentDecisionResult = newDetermination.getDeterminationResult().eligibilityEntitlementTimeline().valueOn(newCaseDecisionDtls.decisionFromDate).result().getCode();

      // Get the new decision cover period
      final LocalisableString currentPeriod = new LocalisableString(
        GENERAL.INF_DATE_TO_DATE);

      currentPeriod.arg(newCaseDecisionDtls.decisionFromDate);
      currentPeriod.arg(newCaseDecisionDtls.decisionToDate);
      tabDetails.currentDecisionPeriod = currentPeriod.toClientFormattedText();

    } catch (final RecordNotFoundException e) {

      // If there is no newCaseDecisionID this could be because the case was
      // closed on a date before the last payment date. In this case use the
      // the oldCaseDecisionID to check the product type
      final CREOLEProductKey creoleProductKey = new CREOLEProductKey();
      boolean isCREOLEProduct = false;
      boolean isCuramRulesProduct = false;
      final CaseDecisionKey oldCDKey = new CaseDecisionKey();

      oldCDKey.caseDecisionID = key.oldCaseDecisionID;
      final CaseDecisionDtls oldCaseDecisionDtls = CaseDecisionFactory.newInstance().read(
        oldCDKey);

      pdKey.caseID = oldCaseDecisionDtls.caseID;

      creoleProductKey.productID = CachedProductDeliveryFactory.newInstance().read(pdKey).productID;

      try {
        CREOLEProductFactory.newInstance().read(creoleProductKey);
        isCREOLEProduct = true;
      } catch (final Exception ex) {
        isCuramRulesProduct = true;
      }

      if (isCREOLEProduct) {

        final LocalisableString newPeriod = new LocalisableString(
          GENERAL.INF_NOT_AVAILABLE);

        tabDetails.currentDecisionPeriod = newPeriod.toClientFormattedText();

        tabDetails.currentDecisionResult = CASEDETERMINATIONINTERVALRESULT.INELIGIBLE;

      } else if (isCuramRulesProduct) {

        // This is not a CER product, use the result code.
        // If there is no new decision then result is ineligible
        tabDetails.currentDecisionResult = CASEDETERMINATIONINTERVALRESULT.INELIGIBLE;

        // Read the period from the case decision record

        // Get the decision cover period
        final LocalisableString currentPeriod = new LocalisableString(
          GENERAL.INF_DATE_TO_DATE);

        currentPeriod.arg(newCaseDecisionDtls.decisionFromDate);
        currentPeriod.arg(newCaseDecisionDtls.decisionToDate);
        tabDetails.currentDecisionPeriod = currentPeriod.toClientFormattedText();
      }
    }

    // Get the old case decision details
    if (key.oldCaseDecisionID != 0) {

      final CaseDecisionKey oldCDKey = new CaseDecisionKey();

      oldCDKey.caseDecisionID = key.oldCaseDecisionID;
      final CaseDecisionDtls oldCaseDecisionDtls = CaseDecisionFactory.newInstance().read(
        oldCDKey);

      // Get the old decision result
      try {
        final CREOLECaseDeterminationAccessor oldDetermination = creoleCaseDeterminationAccessorDAO.readByDecision(
          key.oldCaseDecisionID);

        tabDetails.previousDecisionResult = oldDetermination.getDeterminationResult().eligibilityEntitlementTimeline().valueOn(oldCaseDecisionDtls.decisionFromDate).result().getCode();
      } catch (final RecordNotFoundException e) {

        // This is not a CER product, use the result code
        if (oldCaseDecisionDtls.resultCode.equals(
          CASEDECISIONRESULTCODE.ELIGIBLE)) {

          tabDetails.previousDecisionResult = CASEDETERMINATIONINTERVALRESULT.ELIGIBLE;
        } else {
          tabDetails.previousDecisionResult = CASEDETERMINATIONINTERVALRESULT.INELIGIBLE;
        }
      }

      // Get the old decision cover period
      final LocalisableString oldPeriod = new LocalisableString(
        GENERAL.INF_DATE_TO_DATE);

      oldPeriod.arg(oldCaseDecisionDtls.decisionFromDate);
      oldPeriod.arg(oldCaseDecisionDtls.decisionToDate);
      tabDetails.previousDecisionPeriod = oldPeriod.toClientFormattedText();

    } else {

      /*
       * If the old decision ID is zero we must have moved the case start date
       * back. In this situation no old decision exists so the previous period
       * must be in-eligible and the date range is not available.
       */
      final LocalisableString oldPeriod = new LocalisableString(
        GENERAL.INF_NOT_AVAILABLE);

      tabDetails.previousDecisionPeriod = oldPeriod.toClientFormattedText();
      tabDetails.previousDecisionResult = CASEDETERMINATIONINTERVALRESULT.INELIGIBLE;
    }

    // Get the product type
    tabDetails.productDeliveryType = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
      CachedProductDeliveryFactory.newInstance().read(pdKey).productType,
      TransactionInfo.getProgramLocale());

    // Get the case reference number
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = pdKey.caseID;
    tabDetails.productDeliveryRef = CachedCaseHeaderFactory.newInstance().read(caseHeaderKey).caseReference;
    // END, CR00404711, CR00411625

    return tabDetails;
  }

  // ____________________________________________________________________________
  /**
   * Returns the page name of the appropriate decision comparison page for the
   * product delivery which owns the given decision.
   *
   * @param key
   * ID of a current case decision.
   *
   * @return The name of the decision comparison page.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public DecisionComparisonPageDetails getDecisionComparisonPageName(
    final CaseDecisionKey key) throws AppException, InformationalException {

    final CaseDecisionDtls caseDecisionDtls = CaseDecisionFactory.newInstance().read(
      key);

    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      caseDecisionDtls.caseID);

    return determinationCalculator.getDecisionComparisonPageName(
      caseDecisionDtls);
  }

}
