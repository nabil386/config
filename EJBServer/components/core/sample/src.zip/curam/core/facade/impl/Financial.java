/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2010, 2021.
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office
 */
package curam.core.facade.impl;


import curam.codetable.CANCELLATIONREQUEST;
import curam.codetable.CASETYPECODE;
import curam.codetable.DEDUCTIONITEMTYPE;
import curam.codetable.FINANCIALINSTRUCTION;
import curam.codetable.FININSTRUCTIONSTATUS;
import curam.codetable.ILICATEGORY;
import curam.codetable.ILIRELATIONSHIP;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.PRODUCTNAME;
import curam.codetable.REVERSALREASON;
import curam.codetable.impl.PMTRECONCILIATIONSTATUSEntry;
import curam.core.facade.fact.FinancialContextFactory;
import curam.core.facade.fact.FinancialFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.struct.*;
import curam.core.facade.struct.CancelOrInvalidatePmtDetails;
import curam.core.facade.struct.PaymentReceivedDetails;
import curam.core.facade.struct.ReversalInstructionDetails;
import curam.core.facade.struct.WriteOffDetails;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseDeductionItemFCLinkFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.CreateCancellationFactory;
import curam.core.fact.CreateRefundFactory;
import curam.core.fact.DeductionFCGenerationFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.FinancialInstructionFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.InstructionLineItemProcessingFactory;
import curam.core.fact.MaintainDeductionItemsAssistantFactory;
import curam.core.fact.MaintainDeductionItemsFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.MaintainInstructionLineItemFactory;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.fact.PaymentReceivedInstructionFactory;
import curam.core.fact.PaymentReceivedInstrumentFactory;
import curam.core.fact.PaymentReconciliationFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ReversalInstructionFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.ViewConcernAccountFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.FinancialUtil;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseDeductionItemFCLink;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.CreateCancellation;
import curam.core.intf.FinancialInstruction;
import curam.core.intf.FinancialInstructionStatus;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainDeductionItems;
import curam.core.intf.MaintainDeductionItemsAssistant;
import curam.core.intf.MaintainFinancialComponent;
import curam.core.intf.PaymentInstruction;
import curam.core.intf.PaymentReceivedInstrument;
import curam.core.intf.ProductDelivery;
import curam.core.intf.ViewConcernAccount;
import curam.core.sl.fact.DeductionFactory;
import curam.core.sl.infrastructure.entity.struct.VersionNo;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.DeductionName;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.*;
import curam.message.BPOALLOCATECREDITTRANSACTION;
import curam.message.BPOCREATECANCELLATION;
import curam.message.BPOCREATEREFUND;
import curam.message.GENERAL;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.message.GENERALFINANCE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.Money;
import curam.wizardpersistence.impl.WizardPersistentState;


/**
 * @see curam.core.facade.intf.Financial
 */
public abstract class Financial extends curam.core.facade.base.Financial {

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelPayment(CancelPaymentDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00265418, ZV
    // CreateCancellation manipulation variables
    // BEGIN, CR00265470, ZV
    CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();
    final FinInstructionID finInstructionID = new FinInstructionID();
    final CancelRegenerateSummary cancelRegenerateSummary = new CancelRegenerateSummary();

    // Assign key details to cancel the payment
    finInstructionID.assign(details);

    // Assign details to cancel the payment
    cancelRegenerateSummary.assign(details);

    // Read the class name from property file.
    final String financialResolverName = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_CREATECANCELLATION_CLASS);

    final Object obj = FinancialUtil.getResolverClassName(financialResolverName,
      createCancellationObj.getCaseIDForFinInstructionId(
      finInstructionID.finInstructionID));

    if (null != obj) {
      createCancellationObj = (curam.core.intf.CreateCancellation) obj;
    }
    // END, CR00265470
    // END, CR00265418

    // Call CreateCancellation BPO to cancel the payment
    createCancellationObj.cancelFinInstruction(finInstructionID,
      cancelRegenerateSummary);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void reverseFinancialInstruction(ReverseFinancialInstructionKey key)
    throws AppException, InformationalException {

    // MaintainReversal manipulation variables
    final curam.core.intf.MaintainReversal maintainReversalObj = curam.core.fact.MaintainReversalFactory.newInstance();
    final ReverseSummary reverseSummary = new ReverseSummary();

    // Assign reversal details to call BPO
    reverseSummary.assign(key);

    // Call the MaintainReversal BPO to reverse the Financial Instruction
    maintainReversalObj.reverseFinancialItem(reverseSummary);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void reverseInstructionLineItem(ReverseInstructionLineItemKey key)
    throws AppException, InformationalException {

    // MaintainReversal manipulation variables
    final curam.core.intf.MaintainReversal maintainReversalObj = curam.core.fact.MaintainReversalFactory.newInstance();
    final ReverseSummary reverseSummary = new ReverseSummary();

    // Assign reversal details to call BPO
    reverseSummary.assign(key);

    // Call the MaintainReversal BPO to reverse the Instruction Line Item
    maintainReversalObj.reverseFinancialItem(reverseSummary);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void writeOffInstructionLineItem(WriteOffInstructionLineItemKey key)
    throws AppException, InformationalException {

    // WriteOffInstructionItem manipulation variables
    final curam.core.intf.WriteOffInstructionItem writeOffInstructItemObj = curam.core.fact.WriteOffInstructionItemFactory.newInstance();
    final curam.core.struct.WriteOffDetails writeOffDetails = new curam.core.struct.WriteOffDetails();

    // Assign writeOff details
    writeOffDetails.assign(key);

    // Call WriteOffInstructionItem BPO to write off the Instruction Line Item
    writeOffInstructItemObj.writeOffInstructLineItem(writeOffDetails);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReceivePaymentIdentifiers receivePayment(
    ReceivePaymentDetails details) throws AppException,
      InformationalException {

    // Create return object
    final ReceivePaymentIdentifiers receivePaymentIdentifiers = new ReceivePaymentIdentifiers();

    // ReceivePayment manipulation variables
    final curam.core.intf.ReceivePayment receivePaymentObj = curam.core.fact.ReceivePaymentFactory.newInstance();
    final curam.core.struct.PaymentReceivedDetails paymentReceivedDetails = new curam.core.struct.PaymentReceivedDetails();

    // Assign details to create the payment received
    paymentReceivedDetails.assign(details);

    // Call ReceivePayment BPO to capture payment details and assign
    // payment identifiers to the output struct
    receivePaymentIdentifiers.assign(
      receivePaymentObj.capturePaymentReceived(paymentReceivedDetails));

    return receivePaymentIdentifiers;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListSuspenseAccountDetails searchSuspenseAccount(
    ListSuspenseAccountKey key) throws AppException, InformationalException {

    // Create return object
    final ListSuspenseAccountDetails listSuspenseAccountDetails = new ListSuspenseAccountDetails();

    // SearchForSuspenseEntry manipulation variables
    final curam.core.intf.SearchForSuspenseEntry searchForSuspenseEntryObj = curam.core.fact.SearchForSuspenseEntryFactory.newInstance();
    final SuspenseAccountSearchDtls suspenseAccountSearchDtls = new SuspenseAccountSearchDtls();
    SearchForSuspenseAccEntryResult searchForSuspenseAccEntryResult;

    // Assign details to search for the suspense account records
    suspenseAccountSearchDtls.assign(key);

    // Call SearchForSuspenseEntry BPO to search for suspense account records
    searchForSuspenseAccEntryResult = searchForSuspenseEntryObj.searchForSuspenseAccEntry(
      suspenseAccountSearchDtls);

    // Iterate through the list if it's populated
    if (!searchForSuspenseAccEntryResult.suspAccDetailsList.dtls.isEmpty()) {

      // Reserve space in output struct
      listSuspenseAccountDetails.dtls.ensureCapacity(
        searchForSuspenseAccEntryResult.suspAccDetailsList.dtls.size());

      // Assign base currency to local string
      final String baseCurrency = searchForSuspenseAccEntryResult.financialSearchResultSummary.currencyType;

      // SuspenseAccountDetails object
      curam.core.facade.struct.SuspenseAccountDetails suspenseAccountDetails;

      // Iterate through list of suspense records and map to output struct
      for (int i = 0; i
        < searchForSuspenseAccEntryResult.suspAccDetailsList.dtls.size(); i++) {

        suspenseAccountDetails = new curam.core.facade.struct.SuspenseAccountDetails();

        suspenseAccountDetails.assign(
          searchForSuspenseAccEntryResult.suspAccDetailsList.dtls.item(i));

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        suspenseAccountDetails.currencyType = baseCurrency;

        listSuspenseAccountDetails.dtls.addRef(suspenseAccountDetails);
      }

    }

    listSuspenseAccountDetails.messages.assign(
      searchForSuspenseAccEntryResult.searchMessageDtlsList);

    return listSuspenseAccountDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadSuspenseAccountItemDetails readSuspenseItemIssuerDetails(
    ReadSuspenseItemIssuerDetailsKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadSuspenseAccountItemDetails readSuspenseAccountItemDetails = new ReadSuspenseAccountItemDetails();

    // ViewSuspenseAccount manipulation variables
    final curam.core.intf.ViewSuspenseAccount viewSuspenseAccountObj = curam.core.fact.ViewSuspenseAccountFactory.newInstance();
    ViewSuspenseAccountDetailsResult viewSuspenseAccountDetailsResult;
    final SuspAccountKey suspAccountKey = new SuspAccountKey();

    // Assign key to read suspense account issuer details
    suspAccountKey.suspenseAccountID = key.suspenseAccountID;

    // Call ViewSuspenseAccount BPO to read the suspense account issuer details
    viewSuspenseAccountDetailsResult = viewSuspenseAccountObj.viewSuspenseAccountDetails(
      suspAccountKey);

    // Assign issuer details to output struct
    readSuspenseAccountItemDetails.issuerName = viewSuspenseAccountDetailsResult.suspAccountDetails.issuerName;
    readSuspenseAccountItemDetails.issuerAddressData = viewSuspenseAccountDetailsResult.suspAccountDetails.issuerAddressData;
    readSuspenseAccountItemDetails.issuerFormattedAddressData = viewSuspenseAccountDetailsResult.suspAccountDetails.issuerAddress;

    return readSuspenseAccountItemDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public TransferFromSuspenseResult transferFromSuspenseAccount(
    TransferFromSuspenseAccountKey key) throws AppException,
      InformationalException {

    // Create return object
    final TransferFromSuspenseResult transferFromSuspenseResult = new TransferFromSuspenseResult();

    // SuspenseAccountTransfer manipulation variables
    final curam.core.intf.SuspenseAccountTransfer suspenseAccountTransferObj = curam.core.fact.SuspenseAccountTransferFactory.newInstance();
    final curam.core.struct.SuspenseAccountDetails suspenseAccountDetails = new curam.core.struct.SuspenseAccountDetails();
    FinInstIDInstLineItemID finInstIDInstLineItemID;

    // Assign details to transfer the suspense account details
    suspenseAccountDetails.assign(key);

    // Call SuspenseAccountTransfer BPO to transfer the suspense account
    // details
    finInstIDInstLineItemID = suspenseAccountTransferObj.transferFromSuspenseAccount(
      suspenseAccountDetails);

    // Assign details to return object
    transferFromSuspenseResult.assign(finInstIDInstLineItemID);

    return transferFromSuspenseResult;
  }

  // BEGIN, CR00180306, MC
  /**
   * {@inheritDoc}
   *
   * @throws AppException
   */
  @Override
  public ListLineItemAllocationDetails1 listAllocationsForInstruction(
    FinInstructionID key) throws AppException, InformationalException {

    final ListLineItemAllocationDetails1 listLineItemAllocationDetails = new ListLineItemAllocationDetails1();
    // Get a list of all of the ILIs associated with the given financial
    // instruction ID

    double allocationsTotal = 0;
    double allocationsBalance = 0;

    // instructionLineItem manipulation variables
    final ILIFinInstructID liabilityILIFinInstructID = new ILIFinInstructID();
    InstructionLineItemDtlsList iliDtlsList;
    final curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    liabilityILIFinInstructID.finInstructionID = key.finInstructionID;

    iliDtlsList = instructionLineItemObj.searchByFinInstructID(
      liabilityILIFinInstructID);

    // loop through the list and for each item call listAllocation.
    ListLineItemAllocationKey listLineItemAllocationKey;

    for (int i = 0; i < iliDtlsList.dtls.items().length; i++) {

      listLineItemAllocationKey = new ListLineItemAllocationKey();
      listLineItemAllocationKey.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;

      ListLineItemAllocationDetails1 lineItemAllocationDetails = new ListLineItemAllocationDetails1();

      lineItemAllocationDetails = FinancialFactory.newInstance().listAllocation1(
        listLineItemAllocationKey);

      for (int x = 0; x
        < lineItemAllocationDetails.allocationDetailsList.dtls.size(); x++) {

        // Add the allocation items found for each of the line items to the
        // final list.
        listLineItemAllocationDetails.allocationDetailsList.dtls.addRef(
          lineItemAllocationDetails.allocationDetailsList.dtls.item(x));
      }

      allocationsTotal += lineItemAllocationDetails.allocationHeaderDetails.allocationTotal.getValue();
      allocationsBalance += lineItemAllocationDetails.allocationHeaderDetails.allocationBalance.getValue();

    }
    listLineItemAllocationDetails.allocationHeaderDetails.allocationBalance = new Money(
      allocationsBalance);
    listLineItemAllocationDetails.allocationHeaderDetails.allocationTotal = new Money(
      allocationsTotal);

    return listLineItemAllocationDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListLineItemAllocationDetails1 listAllocation1(
    ListLineItemAllocationKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListLineItemAllocationDetails1 listLineItemAllocationDetails = new ListLineItemAllocationDetails1();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    final ConcernAccILIidentifier concernAccILIidentifier = new ConcernAccILIidentifier();
    ViewInstructionAllocationsResult viewInstructionAllocationsResult;

    // ListAllocationDetails object
    final ListAllocationDetails1 listAllocationDetails = new ListAllocationDetails1();

    // Assign key details to read allocation information
    concernAccILIidentifier.assign(key);

    // Call ViewConcernAccount BPO to read the allocation details
    viewInstructionAllocationsResult = viewConcernAccountObj.viewInstructionAllocations(
      concernAccILIidentifier);

    // BEGIN, CR00183541, MC
    LocalisableString receivedFrom = new LocalisableString(
      curam.message.GENERAL.INF_GENERAL_SEPARATOR);

    // Assign allocation totals to return object
    listLineItemAllocationDetails.allocationHeaderDetails.assign(
      viewInstructionAllocationsResult.concernAccAllocationTotals);

    // Iterate through the list if it's populated
    if (!viewInstructionAllocationsResult.concernAccAllocationList.dtls.isEmpty()) {

      // Reserve space in the output struct
      listLineItemAllocationDetails.allocationDetailsList.dtls.ensureCapacity(
        viewInstructionAllocationsResult.concernAccAllocationList.dtls.size());

      // ILIAllocationDetails object
      ILIAllocationDetails1 iliAllocationDetails;
      ConcernAccAllocationDetails concernAccAllocationDetails;

      for (int i = 0; i
        < viewInstructionAllocationsResult.concernAccAllocationList.dtls.size(); i++) {

        iliAllocationDetails = new ILIAllocationDetails1();
        concernAccAllocationDetails = new ConcernAccAllocationDetails();

        concernAccAllocationDetails = viewInstructionAllocationsResult.concernAccAllocationList.dtls.item(
          i);

        iliAllocationDetails.assign(concernAccAllocationDetails);

        iliAllocationDetails.allocatedFromType = CodeTable.getOneItem(
          FINANCIALINSTRUCTION.TABLENAME,
          iliAllocationDetails.finInstructionCategory,
          TransactionInfo.getProgramLocale());

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = viewInstructionAllocationsResult.concernAccAllocationList.dtls.item(i).concernRoleID;
        final ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = ConcernRoleFactory.newInstance().readConcernRoleNameAndAlternateID(
          concernRoleKey);

        if (iliAllocationDetails.finInstructionCategory.equals(
          FINANCIALINSTRUCTION.PAYMENTRECEIVED)
            && iliAllocationDetails.instructionLineItemType.equals(
              ILITYPE.DEDUCTIONPAYMENT)) {

          // CaseType (CaseReference) - PrimaryClient (ClientReference)
          receivedFrom = new LocalisableString(
            curam.message.GENERAL.INF_GENERAL_CASE_DESCRIPTION_SEPARATOR);

          // Read the primary clients name and reference
          final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          caseIDKey.caseID = concernAccAllocationDetails.caseID;

          final CaseReferenceConcernRoleNameCaseTypeAltID caseReferenceConcernRoleNameCaseTypeAltID = caseHeaderObj.readCaseReferenceCaseTypeConcernRoleNameAlternateID(
            caseIDKey);

          // BEGIN, CR00286590, PMD
          final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
          final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

          productDeliveryKey.caseID = concernAccAllocationDetails.caseID;
          final ProductNameStructRef productName = productDeliveryObj.readProductName(
            productDeliveryKey);

          receivedFrom.arg(
            new CodeTableItemIdentifier(PRODUCTNAME.TABLENAME, productName.name));
          // END, CR00286590

          receivedFrom.arg(
            caseReferenceConcernRoleNameCaseTypeAltID.caseReference);

          iliAllocationDetails.allocatedFromType = GENERALFINANCE.INF_DEDUCTION.getMessageText();
        } // BEGIN, CR00286590, PMD
        else if (iliAllocationDetails.finInstructionCategory.equals(
          FINANCIALINSTRUCTION.PAYMENTRECEIVED)
            && iliAllocationDetails.instructionLineItemType.equals(
              ILITYPE.ALLOCATEDPMTRECVD)) {

          // PrimaryClient (ClientReference)
          receivedFrom = new LocalisableString(
            curam.message.GENERAL.INF_GENERAL_PRIMARY_CLIENT_DESCRIPTION_BRACKETS);
        }
        // END, CR00286590

        // Set the received from field for the allocation items
        // <participant name> (<alternateID>)
        receivedFrom.arg(concernRoleNameAndAlternateID.concernRoleName);
        receivedFrom.arg(concernRoleNameAndAlternateID.primaryAlternateID);

        iliAllocationDetails.receivedFrom = receivedFrom.toClientFormattedText();

        if (iliAllocationDetails.finInstructionCategory.equals(
          FINANCIALINSTRUCTION.WRITEOFF)) {

          iliAllocationDetails.receivedFrom = "";
        }

        // END, CR00183541

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        iliAllocationDetails.currencyType = listLineItemAllocationDetails.allocationHeaderDetails.currencyType;

        // Add details to list
        listAllocationDetails.dtls.addRef(iliAllocationDetails);
      }

    }

    // Assign allocationDetailsList to output struct
    listLineItemAllocationDetails.allocationDetailsList.assign(
      listAllocationDetails);

    return listLineItemAllocationDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListLineItemAllocationDetails listAllocation(
    ListLineItemAllocationKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListLineItemAllocationDetails listLineItemAllocationDetails = new ListLineItemAllocationDetails();

    final ListLineItemAllocationDetails1 listLineItemAllocationDetails1 = listAllocation1(
      key);

    listLineItemAllocationDetails.allocationHeaderDetails.allocationBalance = listLineItemAllocationDetails1.allocationHeaderDetails.allocationBalance;
    listLineItemAllocationDetails.allocationHeaderDetails.allocationTotal = listLineItemAllocationDetails1.allocationHeaderDetails.allocationTotal;
    listLineItemAllocationDetails.allocationHeaderDetails.currencyType = listLineItemAllocationDetails1.allocationHeaderDetails.currencyType;

    ILIAllocationDetails iLIAllocationDetails;

    for (int i = 0; i
      < listLineItemAllocationDetails1.allocationDetailsList.dtls.size(); i++) {

      iLIAllocationDetails = new ILIAllocationDetails();
      iLIAllocationDetails.assign(
        listLineItemAllocationDetails1.allocationDetailsList.dtls.item(i));

      listLineItemAllocationDetails.allocationDetailsList.dtls.addRef(
        iLIAllocationDetails);
    }

    return listLineItemAllocationDetails;
  }

  // END, CR00180306

  // BEGIN, CR00295793, ELG
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  // END, CR00295793
  public ListSearchPaymentReceivedDetail searchForPaymentReceived(
    SearchPaymentReceivedKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListSearchPaymentReceivedDetail listSearchPaymentReceivedDetail = new ListSearchPaymentReceivedDetail();

    // SearchForPaymentReceived manipulation variables
    // BEGIN, CR00077160, CC
    final curam.core.intf.SearchForPaymentReceivedRouter searchForPaymentReceivedObj = curam.core.fact.SearchForPaymentReceivedRouterFactory.newInstance();
    // END, CR00077160, CC
    SearchForPmtRecvdInstrumentResult searchForPmtRecvdInstrumentResult;
    final PaymentReceivedSearchDtls paymentReceivedSearchDtls = new PaymentReceivedSearchDtls();

    // Assign key details to search for the payment received details
    paymentReceivedSearchDtls.assign(key);

    // Call SearchForPaymentReceived BPO to search for the payments received
    // on the system
    searchForPmtRecvdInstrumentResult = searchForPaymentReceivedObj.searchForPmtRecvdInstrument(
      paymentReceivedSearchDtls);

    // Iterate through the loop if it's populated
    if (!searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.isEmpty()) {

      SearchPaymentReceivedDetail searchPaymentReceivedDetail;

      // Reserve space in output object
      listSearchPaymentReceivedDetail.dtls.ensureCapacity(
        searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.size());

      for (int i = 0; i
        < searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.size(); i++) {

        searchPaymentReceivedDetail = new SearchPaymentReceivedDetail();

        searchPaymentReceivedDetail.assign(
          searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.item(
            i));

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        searchPaymentReceivedDetail.currencyTypeCode = searchForPmtRecvdInstrumentResult.financialSearchResultSummary.currencyType;

        // Push details into output object
        listSearchPaymentReceivedDetail.dtls.addRef(searchPaymentReceivedDetail);
      }

    }

    listSearchPaymentReceivedDetail.messages.assign(
      searchForPmtRecvdInstrumentResult.searchMessageDtlsList);

    return listSearchPaymentReceivedDetail;
  }

  // BEGIN, CR00295793, ELG
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   */
  @Override
  public SearchPaymentReceivedResultDetails searchForPaymentReceivedWithIndicators(final SearchPaymentReceivedKey key)
    throws AppException, InformationalException {

    // Return structure
    final SearchPaymentReceivedResultDetails searchPaymentReceivedResultDetails = new SearchPaymentReceivedResultDetails();

    final curam.core.intf.SearchForPaymentReceivedRouter searchForPaymentReceivedObj = curam.core.fact.SearchForPaymentReceivedRouterFactory.newInstance();
    final PaymentReceivedSearchDtls paymentReceivedSearchDtls = new PaymentReceivedSearchDtls();

    // Assign key details to search for the payment received details
    paymentReceivedSearchDtls.assign(key);

    // Call SearchForPaymentReceived BPO to search for the payments received
    // on the system
    final SearchForPmtRecvdInstrumentResult searchForPmtRecvdInstrumentResult = searchForPaymentReceivedObj.searchForPmtRecvdInstrument(
      paymentReceivedSearchDtls);

    // Iterate through the loop if it's populated
    if (!searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.isEmpty()) {

      // Loop variables
      PaymentReceivedAndIndicatorDetails paymentReceivedAndIndicatorDetails;
      ViewPaymentReceivedInstructionDetailResult viewPaymentReceivedInstructionDetailResult;

      // ViewConcernAccount manipulation variables
      final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
      final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

      // Reserve space in output object
      searchPaymentReceivedResultDetails.dtls.ensureCapacity(
        searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.size());

      for (final PmtRecvdInstrumentDtls details : searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls) {

        accountInstructionIdentifier.concernRoleID = details.concernRoleID;
        accountInstructionIdentifier.finInstructionID = details.finInstructionID;

        viewPaymentReceivedInstructionDetailResult = viewConcernAccountObj.viewPaymentReceivedInstructionDetail(
          accountInstructionIdentifier);

        paymentReceivedAndIndicatorDetails = new PaymentReceivedAndIndicatorDetails();
        paymentReceivedAndIndicatorDetails.assign(details);
        paymentReceivedAndIndicatorDetails.reverseIndicator = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.reverseIndicator;
        // BEGIN, CR00324347, KH
        paymentReceivedAndIndicatorDetails.clientName = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.concernRoleName;
        paymentReceivedAndIndicatorDetails.unallocatedAmount = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.unAllocatedAmount;
        paymentReceivedAndIndicatorDetails.allocateIndicator = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.allocateIndicator;
        paymentReceivedAndIndicatorDetails.iliID = details.instructLineItemID;
        paymentReceivedAndIndicatorDetails.concernRoleID = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.concernRoleID;
        // END, CR00324347

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        paymentReceivedAndIndicatorDetails.currencyTypeCode = searchForPmtRecvdInstrumentResult.financialSearchResultSummary.currencyType;

        // Push details into output object
        searchPaymentReceivedResultDetails.dtls.addRef(
          paymentReceivedAndIndicatorDetails);
      }
    }

    searchPaymentReceivedResultDetails.messages.assign(
      searchForPmtRecvdInstrumentResult.searchMessageDtlsList);

    return searchPaymentReceivedResultDetails;
  }

  // END, CR00295793

  // BEGIN, CR00324347, KH
  /**
   * {@inheritDoc}
   */
  @Override
  public void refundPaymentReceived(final RefundFinancialInstructionKey key)
    throws AppException, InformationalException {

    CreateRefundFactory.newInstance().createRefund(key);
  }

  // END, CR00324347

  // BEGIN, CR00326783, CSH
  /**
   * {@inheritDoc}
   */
  @Override
  public void refundMultipleReceivedPayments(
    final AddMultiRefundPayments details) throws AppException,
      InformationalException {

    // Create a refund for the selected unallocated payments
    CreateRefundFactory.newInstance().createMultiplePaymentRefund(details);
  }

  // END, CR00326783

  // BEGIN, CR00327722, CSH
  /**
   * {@inheritDoc}
   */
  @Override
  public SearchPaymentReceivedResultDetails listUnallocatedPaymentReceived(
    final ConcernRoleKeyStruct key) throws AppException,
      InformationalException {

    // BEGIN, CR00328565, CSH
    // Check participant security and sensitivity
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = key.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00328565

    // Return structure
    final SearchPaymentReceivedResultDetails searchPaymentReceivedResultDetails = new SearchPaymentReceivedResultDetails();
    final SearchForPmtRecvdInstrumentResult searchForPmtRecvdInstrumentResult = new SearchForPmtRecvdInstrumentResult();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final PRIConcernRoleIDSearchData priConcernRoleIDSearchData = new PRIConcernRoleIDSearchData();
    PmtRecvdInstrumentDtls pmtRecvdInstrumentDtls = new PmtRecvdInstrumentDtls();
    PRISearchResultDtlsList paymentReceivedInstrumentDtls = null;

    // instructionLineItem manipulation variables
    final InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    final ILIFinInstructIDCategoryTypeStatus iliFinInstructIDCategoryTypeStatus = new ILIFinInstructIDCategoryTypeStatus();

    final PaymentReceivedInstrument pmtRecvInstrumentObj = PaymentReceivedInstrumentFactory.newInstance();

    // priConcernRoleIDSearchData.assign(pmtRecvdSearchDtls);
    priConcernRoleIDSearchData.concernRoleID = key.concernRoleID;

    paymentReceivedInstrumentDtls = pmtRecvInstrumentObj.searchForPaymentsReceived(
      priConcernRoleIDSearchData);

    if (paymentReceivedInstrumentDtls != null) {

      // BEGIN, CR00331183, CSH
      InstructionLineItemDtlsList iliDtlsList;

      // Declaring local variable for iteration.
      for (int i = 0; i < paymentReceivedInstrumentDtls.dtls.size(); i++) {

        pmtRecvdInstrumentDtls = new PmtRecvdInstrumentDtls();

        pmtRecvdInstrumentDtls.assign(
          paymentReceivedInstrumentDtls.dtls.item(i));

        iliFinInstructIDCategoryTypeStatus.finInstructionID = paymentReceivedInstrumentDtls.dtls.item(i).finInstructionID;
        iliFinInstructIDCategoryTypeStatus.instructLineItemCategory = ILICATEGORY.PAYMENTRECEIVEDINSTRUCTION;
        iliFinInstructIDCategoryTypeStatus.instructionLineItemType = ILITYPE.UNALLOCATEPMTRECVD;
        iliFinInstructIDCategoryTypeStatus.statusCode = ILISTATUS.PROCESSED;

        pmtRecvdInstrumentDtls.allocationIndicator = true;

        try {
          iliDtlsList = instructionLineItemObj.searchByFinInstructIDCategoryTypeStatus(
            iliFinInstructIDCategoryTypeStatus);

        } catch (final RecordNotFoundException e) {
          pmtRecvdInstrumentDtls.allocationIndicator = false;
          iliDtlsList = null;
        }

        if (iliDtlsList != null) {

          for (int j = 0; j < iliDtlsList.dtls.size(); j++) {

            pmtRecvdInstrumentDtls.instructLineItemID = iliDtlsList.dtls.item(j).instructLineItemID;
            pmtRecvdInstrumentDtls.instructionLineItemType = iliDtlsList.dtls.item(j).instructionLineItemType;

            searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.addRef(
              pmtRecvdInstrumentDtls);
          }

        }
        // END, CR00331183

      }

    }

    // Iterate through the loop if it's populated
    if (!searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.isEmpty()) {

      // Loop variables
      PaymentReceivedAndIndicatorDetails paymentReceivedAndIndicatorDetails;
      ViewPaymentReceivedInstructionDetailResult viewPaymentReceivedInstructionDetailResult;

      // ViewConcernAccount manipulation variables
      final ViewConcernAccount viewConcernAccountObj = ViewConcernAccountFactory.newInstance();
      final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

      // Reserve space in output object
      searchPaymentReceivedResultDetails.dtls.ensureCapacity(
        searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls.size());

      for (final PmtRecvdInstrumentDtls details : searchForPmtRecvdInstrumentResult.pmtRecvdInstrumentDtlsList.dtls) {

        accountInstructionIdentifier.concernRoleID = details.concernRoleID;
        accountInstructionIdentifier.finInstructionID = details.finInstructionID;

        viewPaymentReceivedInstructionDetailResult = viewConcernAccountObj.viewPaymentReceivedInstructionDetail(
          accountInstructionIdentifier);

        paymentReceivedAndIndicatorDetails = new PaymentReceivedAndIndicatorDetails();
        paymentReceivedAndIndicatorDetails.assign(details);
        paymentReceivedAndIndicatorDetails.reverseIndicator = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.reverseIndicator;
        paymentReceivedAndIndicatorDetails.clientName = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.concernRoleName;
        paymentReceivedAndIndicatorDetails.unallocatedAmount = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.unAllocatedAmount;
        paymentReceivedAndIndicatorDetails.allocateIndicator = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.allocateIndicator;
        paymentReceivedAndIndicatorDetails.iliID = details.instructLineItemID;
        paymentReceivedAndIndicatorDetails.concernRoleID = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.concernRoleID;

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        paymentReceivedAndIndicatorDetails.currencyTypeCode = searchForPmtRecvdInstrumentResult.financialSearchResultSummary.currencyType;

        // Push details into output object
        searchPaymentReceivedResultDetails.dtls.addRef(
          paymentReceivedAndIndicatorDetails);
      }
    } // BEGIN, CR00328565, CSH
    else {

      // Notify the user that no eligible items have been found
      final ConcernRole concernRoleobj = ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRolekey = new ConcernRoleKey();

      concernRolekey.concernRoleID = key.concernRoleID;
      final ConcernRoleDtls concernRoleDtls = concernRoleobj.read(
        concernRolekey);

      final AppException e = new AppException(
        BPOCREATEREFUND.ERR_NO_UNALLOCATED_AMOUNT_FOR_CLIENT);

      e.arg(concernRoleDtls.concernRoleName);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // Obtain the informational(s) to be returned to the client
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final SearchMessageDtls informationalMsgDtls = new SearchMessageDtls();

        informationalMsgDtls.searchMessage = warnings[i];

        searchForPmtRecvdInstrumentResult.searchMessageDtlsList.dtls.addRef(
          informationalMsgDtls);
      }
    }
    // END, CR00328565

    // Add any informational messages to the return struct
    searchPaymentReceivedResultDetails.messages.assign(
      searchForPmtRecvdInstrumentResult.searchMessageDtlsList);

    return searchPaymentReceivedResultDetails;
  }

  // END, CR00327722

  // BEGIN, CR00167497, MC
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadPaymentInstructionDetails readPaymentInstruction(
    ReadPaymentInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadPaymentInstructionDetails readPaymentInstructionDetails = new ReadPaymentInstructionDetails();

    final ReadPaymentInstructionDetails1 readPaymentInstructionDetails1 = readPaymentInstruction1(
      key);

    // Assign the common values from the newer version of this method.
    readPaymentInstructionDetails.assign(readPaymentInstructionDetails1);

    readPaymentInstructionDetails.informationalMsgDtlsList = readPaymentInstructionDetails1.informationalMsgDtlsList;

    // BEGIN, CR00225016, ZV
    readPaymentInstructionDetails.paymentHeaderDetails.assign(
      readPaymentInstructionDetails1.paymentHeaderDetails);
    // END, CR00225016

    PaymentILIDetails paymentILIDetails;
    PaymentDetails paymentDetails;

    for (int i = 0; i
      < readPaymentInstructionDetails1.paymentILIList.dtls.size(); i++) {

      paymentILIDetails = readPaymentInstructionDetails1.paymentILIList.dtls.item(
        i);
      paymentDetails = new PaymentDetails();

      paymentDetails = paymentILIDetails.paymentItemDetails;

      readPaymentInstructionDetails.paymentDetailsList.dtls.addRef(
        paymentDetails);
    }

    return readPaymentInstructionDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadPaymentInstructionDetails1 readPaymentInstruction1(
    ReadPaymentInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadPaymentInstructionDetails1 readPaymentInstructionDetails = new ReadPaymentInstructionDetails1();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    ViewPaymentInstructionDetails viewPaymentInstructionDetails = new ViewPaymentInstructionDetails();

    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Assign key details to read Payment Instruction details
    accountInstructionIdentifier.assign(key);

    // Used to read the reversal details for a reversed payment
    final FinInstructionID reversalInstructionID = new FinInstructionID();

    if (key.finInstructionID == 0) {

      final LocalisableString infoMessage = new LocalisableString(
        curam.message.GENERALFINANCE.ERR_NOINSTRUCTION_GENERATED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }
      readPaymentInstructionDetails.informationalMsgDtlsList = informationMsgDtlsList;

    } else {
      readPaymentInstructionDetails.processedFlag = true;

      // Call ViewConcernAccount BPO to search for the Payment Instruction
      // details
      viewPaymentInstructionDetails = viewConcernAccountObj.viewPaymentInstruction(
        accountInstructionIdentifier);

      readPaymentInstructionDetails.canceledFlag = viewPaymentInstructionDetails.paymentHeader.paymentCanceledInd;

      // Assign header details to the output object
      readPaymentInstructionDetails.paymentHeaderDetails.assign(
        viewPaymentInstructionDetails.paymentHeader);

      if (!viewPaymentInstructionDetails.paymentDetailsList.dtls.isEmpty()) {
        readPaymentInstructionDetails.caseID = viewPaymentInstructionDetails.paymentDetailsList.dtls.item(0).concernAccPaymentDtls.caseID;
      }

      // Assign totals to the output object
      readPaymentInstructionDetails.paymentHeaderDetails.assign(
        viewPaymentInstructionDetails.paymentDetailTotals);

      // Iterate through the list if it's populated
      if (!viewPaymentInstructionDetails.paymentDetailsList.dtls.isEmpty()) {
        PaymentILIDetails paymentILIDetails;

        // Reserve space in output object
        readPaymentInstructionDetails.paymentILIList.dtls.ensureCapacity(
          viewPaymentInstructionDetails.paymentDetailsList.dtls.size());

        ConcernAccPaymentDetail1 currentPaymentLineItem;

        for (int i = 0; i
          < viewPaymentInstructionDetails.paymentDetailsList.dtls.size(); i++) {
          currentPaymentLineItem = viewPaymentInstructionDetails.paymentDetailsList.dtls.item(
            i);

          paymentILIDetails = new PaymentILIDetails();
          paymentILIDetails.paymentItemDetails.assign(
            currentPaymentLineItem.concernAccPaymentDtls);

          // Set the cover period variable for the line item
          final LocalisableString coverPeriod = new LocalisableString(
            curam.message.GENERAL.INF_DATE_TO_DATE);

          coverPeriod.arg(currentPaymentLineItem.coverPeriodFrom);
          coverPeriod.arg(currentPaymentLineItem.coverPeriodTo);

          paymentILIDetails.coverPeriod = coverPeriod.toClientFormattedText();

          // BEGIN, CR00242881, VM
          // The case type won't necessarily be available. For example, it won't
          // be specified for Third Party Payments
          if (currentPaymentLineItem.concernAccPaymentDtls.caseType.length()
            > 0) {

            // Set the Case description variable for the line item
            final LocalisableString caseDescription = new LocalisableString(
              GENERAL.INF_CASETYPE_CASEREF);

            caseDescription.arg(
              new CodeTableItemIdentifier(curam.codetable.PRODUCTTYPE.TABLENAME,
              currentPaymentLineItem.concernAccPaymentDtls.caseType));
            caseDescription.arg(
              currentPaymentLineItem.concernAccPaymentDtls.caseReference);

            paymentILIDetails.caseDescription = caseDescription.toClientFormattedText();
          }
          // END, CR00242881

          paymentILIDetails.statusCode = currentPaymentLineItem.statusCode;

          // Amounts are always stored on the database in the base currency and
          // always read back as such. The base currency is returned here for
          // display purposes. The amounts in the money field(s) on each row
          // will
          // be shown in the following format: "USD 1000"
          paymentILIDetails.paymentItemDetails.currencyTypeCode = viewPaymentInstructionDetails.paymentHeader.currencyType;

          readPaymentInstructionDetails.paymentILIList.dtls.addRef(
            paymentILIDetails);

          // BEGIN, CR00183514, MC
          // If this instruction is reversed find the ID of the reversal
          // instruction from the related ILIs
          if (readPaymentInstructionDetails.paymentHeaderDetails.statusCode.equals(
            FININSTRUCTIONSTATUS.CANCELLED)) {

            final RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();

            // set key to read instructionLineItem
            relatedILIidentifier.instructLineItemID = paymentILIDetails.paymentItemDetails.instructionLineItemID;
            relatedILIidentifier.type = curam.codetable.ILIRELATIONSHIP.REVERSALS;

            // read instructionLineItem
            final RelatedILIDetailsList relatedILIDetailsList = InstructionLineItemFactory.newInstance().searchRelatedILIByInstrLineItemIDType(
              relatedILIidentifier);

            for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

              // If the reversalFinInstructionID is not already set
              if (reversalInstructionID.finInstructionID == 0) {
                reversalInstructionID.finInstructionID = relatedILIDetailsList.dtls.item(j).finInstructionID;
              }
            }
          }
          // END, CR00183514
        }

      }

      final curam.core.facade.intf.FinancialContext financialContextObj = curam.core.facade.fact.FinancialContextFactory.newInstance();

      final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

      // Details to be returned.
      FinancialContextDescription financialContextDescription;

      financialContextDescriptionKey.finInstructionID = key.finInstructionID;

      // Read financial context description
      financialContextDescription = financialContextObj.readContextDescription(
        financialContextDescriptionKey);

      readPaymentInstructionDetails.contextDescription.contextDescription = financialContextDescription.contextDescription;
    }

    // Set the payment date
    readPaymentInstructionDetails.paymentDate = viewPaymentInstructionDetails.paymentDate.paymentDate;

    readPaymentInstructionDetails.formattedNomineeAddress = viewPaymentInstructionDetails.paymentHeader.formattedNomineeAddress;

    // Set the display Indicators
    final String instructionStatusCode = readPaymentInstructionDetails.paymentHeaderDetails.statusCode;

    final LocalisableString paymentStatus = new LocalisableString(
      curam.message.GENERAL.INF_STATUSCODE_DETAILS);

    // BEGIN, CR00182744, MC
    paymentStatus.arg(
      new CodeTableItemIdentifier(
        curam.codetable.FININSTRUCTIONSTATUS.TABLENAME,
        readPaymentInstructionDetails.paymentHeaderDetails.statusCode));

    if (instructionStatusCode.equals(FININSTRUCTIONSTATUS.CANCELLED)
      && readPaymentInstructionDetails.paymentHeaderDetails.invalidatedInd) {
	  // BEGIN, 266655, SH
      paymentStatus.arg(
        CuramConst.gkSpace
          + curam.message.GENERAL.INF_INVALIDATED.getMessageText(TransactionInfo.getProgramLocale()));
	  // END, 266655
    } else {
      // If the payment is not cancelled and invalidated there is no second
      // argument.
      paymentStatus.arg("");
    }
    readPaymentInstructionDetails.paymentStatus = paymentStatus.toClientFormattedText();
    // END, CR00182744

    // Set the display indicators for the delivery method
    final DeliveryMethodType deliveryMethodType = new DeliveryMethodType();

    deliveryMethodType.deliveryMethodType = readPaymentInstructionDetails.paymentHeaderDetails.methodOfDelivery;

    readPaymentInstructionDetails.deliveryMethodInd = readDeliveryMethodIndicators(
      deliveryMethodType);

    // Set up the cover period for display
    final LocalisableString coverPeriod = new LocalisableString(
      curam.message.GENERAL.INF_DATE_TO_DATE);

    coverPeriod.arg(viewPaymentInstructionDetails.paymentDate.coverPeriodFrom);
    coverPeriod.arg(viewPaymentInstructionDetails.paymentDate.coverPeriodTo);

    readPaymentInstructionDetails.coverPeriod = coverPeriod.toClientFormattedText();

    // Set the foreign currency indicator to tell the pages whether or
    // not to display the foreign currency field.
    if (readPaymentInstructionDetails.paymentHeaderDetails.foreignCurrency.length()
      > 0) {
      readPaymentInstructionDetails.foreignCurrencyInd = true;
    } else {
      readPaymentInstructionDetails.foreignCurrencyInd = false;
    }

    // BEGIN, CR00183541,CR00233126 MC
    // Display the reversal details for this instruction if it has been
    // reversed.
    if (readPaymentInstructionDetails.paymentHeaderDetails.statusCode.equals(
      FININSTRUCTIONSTATUS.CANCELLED)) {

      readPaymentInstructionDetails.reversalDetails.reversalInd = true;

      // This is the financial instruction ID on the reversal instruction, read
      // earlier in this method using the relationships between the ILIs
      final ReversalFinInstructionID reversalFinInstructionID = new ReversalFinInstructionID();

      reversalFinInstructionID.finInstructionID = reversalInstructionID.finInstructionID;

      final ReversalInstructionDtls reversalInstructionDtls = ReversalInstructionFactory.newInstance().readByFinInstructionID(
        reversalFinInstructionID);

      readPaymentInstructionDetails.reversalDetails.closureEffectiveDate = reversalInstructionDtls.effectiveDate;

      final ReversalReasonCode reversalReasonCode = new ReversalReasonCode();

      reversalReasonCode.reversalCode = reversalInstructionDtls.reasonCode;

      readPaymentInstructionDetails.reversalDetails.reasonDescription = getReversalReasonDescription(reversalReasonCode).description;

      // Comments are stored on the FinancialInstruction for the reversal
      final FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();

      financialInstructionKey.finInstructionID = reversalFinInstructionID.finInstructionID;

      readPaymentInstructionDetails.reversalDetails.comments = FinancialInstructionFactory.newInstance().read(financialInstructionKey).comments;

    } else {
      readPaymentInstructionDetails.reversalDetails.reversalInd = false;
    }
    // END, CR00183541

    // Check to see if the nomineeName is populated. If it's not, use the
    // concern role name - nomineeName will not be populated for Third Party
    // Payments
    if (readPaymentInstructionDetails.paymentHeaderDetails.nomineeName.length()
      == 0) {
      readPaymentInstructionDetails.paymentHeaderDetails.nomineeName = readPaymentInstructionDetails.paymentHeaderDetails.concernRoleName;
    }

    return readPaymentInstructionDetails;
  }

  // END, CR00167497

  // BEGIN, CR00175754, MC
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadPaymentReceivedDetails readPaymentReceivedInstruction(
    ReadPaymentReceivedInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadPaymentReceivedDetails readPaymentReceivedDetails = new ReadPaymentReceivedDetails();

    // return from the new readPaymentReceivedInstruction1 method
    ReadPaymentReceivedDetails1 readPaymentReceivedDetails1 = new ReadPaymentReceivedDetails1();

    readPaymentReceivedDetails1 = readPaymentReceivedInstruction1(key);

    readPaymentReceivedDetails.contextDescription = readPaymentReceivedDetails1.contextDescription;
    readPaymentReceivedDetails.informationalMsgDtlsList = readPaymentReceivedDetails1.informationalMsgDtlsList;
    readPaymentReceivedDetails.paymentReceivedHeaderDetails.assign(
      readPaymentReceivedDetails1.paymentReceivedHeaderDetails);

    PaymentReceivedDetails paymentReceivedDetails;
    PaymentReceivedDetails1 paymentReceivedDetails1;

    for (int i = 0; i
      < readPaymentReceivedDetails1.paymentReceivedDetailsList.dtls.size(); i++) {
      paymentReceivedDetails1 = new PaymentReceivedDetails1();
      paymentReceivedDetails = new PaymentReceivedDetails();

      paymentReceivedDetails1.assign(
        readPaymentReceivedDetails1.paymentReceivedDetailsList.dtls.item(i));

      paymentReceivedDetails.assign(paymentReceivedDetails1);

      readPaymentReceivedDetails.paymentReceivedDetailsList.dtls.addRef(
        paymentReceivedDetails);
    }

    return readPaymentReceivedDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadPaymentReceivedDetails1 readPaymentReceivedInstruction1(
    ReadPaymentReceivedInstructionKey key) throws AppException,
      InformationalException {

    final ReadPaymentReceivedDetails1 readPaymentReceivedDetails = new ReadPaymentReceivedDetails1();

    // ViewConcernAccount manipulation variables
    final ViewConcernAccount viewConcernAccountObj = ViewConcernAccountFactory.newInstance();
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    ViewPaymentReceivedInstructionDetailResult viewPaymentReceivedInstructionDetailResult;

    // Used to read the reversal details for a reversed payment
    final FinInstructionID reversalInstructionID = new FinInstructionID();

    // BEGIN, CR00093537, CW
    // If this is an overallocation that has yet to be applied then it will have
    // no financialInstructionID
    if (key.finInstructionID == 0
      && key.instructionLineItemType.equalsIgnoreCase(ILITYPE.OVERALLOCATION)) {

      // Create informational message list
      final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

      // Flush out the informational manager
      TransactionInfo.setInformationalManager();

      // Handle messages from the informational manager
      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      // Unallocated overallocation will have no instruction to view so display
      // appropriate informational to user
      final LocalisableString infoMessage = new LocalisableString(
        GENERALFINANCE.INF_NO_INSTRUCTION_FOR_OVERALLOCATION);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        ValidationManagerConst.kSetOne, 0);

      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }

      readPaymentReceivedDetails.informationalMsgDtlsList = informationMsgDtlsList;

    } else {
      // END, CR00093537

      // Assign key details to search for the Payment Received Instruction
      accountInstructionIdentifier.assign(key);

      // Search for the Payment Received Instruction detail
      viewPaymentReceivedInstructionDetailResult = viewConcernAccountObj.viewPaymentReceivedInstructionDetail(
        accountInstructionIdentifier);

      // Assign details to output struct
      readPaymentReceivedDetails.paymentReceivedHeaderDetails.assign(
        viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader);
      // BEGIN, CR00105404, CW
      // Set the processedFlag to true when there is an instruction id
      readPaymentReceivedDetails.paymentReceivedHeaderDetails.processedFlag = key.finInstructionID
        != 0;
      // END, CR00105404

      // Iterate through the list if it's populated
      if (!viewPaymentReceivedInstructionDetailResult.pmtReceivedDetailList.dtls.isEmpty()) {

        // Reserve space in output object
        readPaymentReceivedDetails.paymentReceivedDetailsList.dtls.ensureCapacity(
          viewPaymentReceivedInstructionDetailResult.pmtReceivedDetailList.dtls.size());

        // Assign base currency to local string
        final String baseCurrency = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.currencyType;

        PaymentReceivedDetails1 paymentReceivedDetails;

        for (int i = 0; i
          < viewPaymentReceivedInstructionDetailResult.pmtReceivedDetailList.dtls.size(); i++) {

          paymentReceivedDetails = new PaymentReceivedDetails1();

          paymentReceivedDetails.assign(
            viewPaymentReceivedInstructionDetailResult.pmtReceivedDetailList.dtls.item(
              i));

          // Amounts are always stored on the database in the base currency and
          // always read back as such. The base currency is returned here for
          // display purposes. The amounts in the money field(s) on each row
          // will
          // be shown in the following format: "USD 1000"
          paymentReceivedDetails.currencyType = baseCurrency;

          // BEGIN, CR00183541, MC
          // Payments received are still listed on the participants list even
          // when they do not apply (have not been allocated) to a case
          if (paymentReceivedDetails.caseID != 0) {

            final LocalisableString allocatedTo = new LocalisableString(
              GENERAL.INF_GENERAL_CASE_DESCRIPTION_SEPARATOR);

            // Read the primary clients name and reference
            final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
            final CaseIDKey caseIDKey = new CaseIDKey();

            caseIDKey.caseID = paymentReceivedDetails.caseID;

            final CaseReferenceConcernRoleNameCaseTypeAltID caseReferenceConcernRoleNameCaseTypeAltID = caseHeaderObj.readCaseReferenceCaseTypeConcernRoleNameAlternateID(
              caseIDKey);

            allocatedTo.arg(
              new CodeTableItemIdentifier(CASETYPECODE.TABLENAME,
              caseReferenceConcernRoleNameCaseTypeAltID.caseTypeCode));
            allocatedTo.arg(
              caseReferenceConcernRoleNameCaseTypeAltID.caseReference);
            allocatedTo.arg(
              caseReferenceConcernRoleNameCaseTypeAltID.concernRoleName);
            allocatedTo.arg(
              caseReferenceConcernRoleNameCaseTypeAltID.primaryAlternateID);

            paymentReceivedDetails.allocatedTo = allocatedTo.toClientFormattedText();
          } else {
            paymentReceivedDetails.allocatedTo = CuramConst.gkEmpty;
          }
          // END, CR00183541
          // BEGIN, CR00251584, MC
          final LocalisableString coversPeriod = new LocalisableString(
            curam.message.GENERAL.INF_DATE_TO_DATE);

          final FinInstructionAndCaseID finInstructionAndCaseID = new FinInstructionAndCaseID();

          finInstructionAndCaseID.caseID = paymentReceivedDetails.caseID;
          finInstructionAndCaseID.finInstructionID = paymentReceivedDetails.finInstructionID;

          final PaymentDateDetails paymentDateDetails = FinancialInstructionFactory.newInstance().readPaymentDateDetailsByCaseAndInstructionID(
            finInstructionAndCaseID);

          coversPeriod.arg(paymentDateDetails.coverPeriodFrom);
          coversPeriod.arg(paymentDateDetails.coverPeriodTo);

          paymentReceivedDetails.coversPeriod = coversPeriod.toClientFormattedText();
          // END, CR00251584

          // BEGIN, CR00324347, KH
          // Only add ILIs which are allocated against a liability...
          if (paymentReceivedDetails.caseID != 0) {

            readPaymentReceivedDetails.paymentReceivedDetailsList.dtls.addRef(
              paymentReceivedDetails);

            // If we've added an allocation, set the flag to display the cluster
            readPaymentReceivedDetails.paymentReceivedDetailsList.allocationFlag = true;

            // BEGIN, CR00328466, KH
          } else if (paymentReceivedDetails.type.equals(ILITYPE.REFUND)) {
            // END, CR00328466

            /*
             * Allocated ILIs without a caseID could be refunds or reversals,
             * we only want to display refunds
             */
            final RefundDetails refundDtls = new RefundDetails();

            refundDtls.amount = paymentReceivedDetails.amount;
            refundDtls.effectiveDate = paymentReceivedDetails.effectiveDate;
            refundDtls.statusCode = paymentReceivedDetails.statusCode; // This
            // might
            // be the
            // fin
            // instruction
            // status?

            readPaymentReceivedDetails.refundList.dtls.addRef(refundDtls);

            // If we've added a refund, set the flag to display the cluster
            readPaymentReceivedDetails.refundList.refundFlag = true;
          }
          // END, CR00324347
        }
      }

      // BEGIN, CR00183514, MC
      // If this instruction is reversed find the ID of the reversal
      // instruction from the related ILIs
      if (readPaymentReceivedDetails.paymentReceivedHeaderDetails.statusCode.equals(
        FININSTRUCTIONSTATUS.REVERSED)) {

        // Read a list of the ILIs associated with this instruction
        final ILIFinInstructID pmtRecvILIFinInstructID = new ILIFinInstructID();

        pmtRecvILIFinInstructID.finInstructionID = key.finInstructionID;
        final InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
          pmtRecvILIFinInstructID);

        for (int i = 0; i < iliDtlsList.dtls.size(); i++) {
          final RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();

          // set key to read instructionLineItem
          relatedILIidentifier.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;
          relatedILIidentifier.type = ILIRELATIONSHIP.REVERSALS;

          // read instructionLineItem
          final RelatedILIDetailsList relatedILIDetailsList = InstructionLineItemFactory.newInstance().searchRelatedILIByInstrLineItemIDType(
            relatedILIidentifier);

          for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

            // If the reversalFinInstructionID is not already set
            if (reversalInstructionID.finInstructionID == 0) {
              reversalInstructionID.finInstructionID = relatedILIDetailsList.dtls.item(j).finInstructionID;
            }
          }
        }
      }
      // END, CR00183514

      final DeliveryMethodType deliveryMethodType = new DeliveryMethodType();

      deliveryMethodType.deliveryMethodType = readPaymentReceivedDetails.paymentReceivedHeaderDetails.methodOfDelivery;

      // Cash and check are the only delivery methods currently supported.
      // The reverse link is conditionally displayed based on the delivery
      // method
      readPaymentReceivedDetails.deliveryMethodInd = readDeliveryMethodIndicators(
        deliveryMethodType);

      // The allocate link is only displayed if there is an amount left to
      // allocate
      if (readPaymentReceivedDetails.paymentReceivedHeaderDetails.unAllocatedAmount.isPositive()
        && readPaymentReceivedDetails.paymentReceivedHeaderDetails.processedFlag) {
        readPaymentReceivedDetails.paymentReceivedHeaderDetails.allocateIndicator = true;
      } else {
        readPaymentReceivedDetails.paymentReceivedHeaderDetails.allocateIndicator = false;
      }
      // Set the foreign currency indicator to tell the pages whether or
      // not to display the foreign currency field.
      if (readPaymentReceivedDetails.paymentReceivedHeaderDetails.foreignCurrency.length()
        > 0) {
        readPaymentReceivedDetails.paymentReceivedHeaderDetails.foreignCurrencyInd = true;
      } else {
        readPaymentReceivedDetails.paymentReceivedHeaderDetails.foreignCurrencyInd = false;
      }
    }

    // BEGIN, CR00181398, MC
    // Read the nominee address from the payment received instrument
    final PmtRecvFinInstructionID pmtRecvFinInstructionID = new PmtRecvFinInstructionID();

    pmtRecvFinInstructionID.finInstructionID = key.finInstructionID;

    final PaymentReceivedInstrumentKey paymentReceivedInstrumentKey = new PaymentReceivedInstrumentKey();

    paymentReceivedInstrumentKey.pmtRecInstrumentID = PaymentReceivedInstructionFactory.newInstance().readByFinInstructionID(pmtRecvFinInstructionID).pmtRecInstrumentID;

    if (paymentReceivedInstrumentKey.pmtRecInstrumentID != 0) {
      final PaymentReceivedInstrumentDtls paymentReceivedInstrumentDtls = PaymentReceivedInstrumentFactory.newInstance().read(
        paymentReceivedInstrumentKey);

      // Address key and details
      final OtherAddressData otherAddressData = new OtherAddressData();
      final AddressKey addressKey = new AddressKey();

      addressKey.addressID = paymentReceivedInstrumentDtls.addressID;
      otherAddressData.addressData = AddressFactory.newInstance().read(addressKey).addressData;

      readPaymentReceivedDetails.paymentReceivedHeaderDetails.formattedNomineeAddress = ParticipantFactory.newInstance().displaySingleLineAddress(otherAddressData).addressString;
    }
    // END, CR00181398

    // BEGIN, CR00183541, MC
    // Display the reversal details for this instruction if it has been
    // reversed.
    if (readPaymentReceivedDetails.paymentReceivedHeaderDetails.statusCode.equals(
      FININSTRUCTIONSTATUS.REVERSED)) {

      readPaymentReceivedDetails.reversalDetails.reversalInd = true;

      // This is the financial instruction ID on the reversal instruction, read
      // earlier in this method using the relationships between the ILIs
      final ReversalFinInstructionID reversalFinInstructionID = new ReversalFinInstructionID();

      reversalFinInstructionID.finInstructionID = reversalInstructionID.finInstructionID;

      final ReversalReasonCode reversalReasonCode = new ReversalReasonCode();

      reversalReasonCode.reversalCode = ReversalInstructionFactory.newInstance().readByFinInstructionID(reversalFinInstructionID).reasonCode;

      readPaymentReceivedDetails.reversalDetails.reasonDescription = getReversalReasonDescription(reversalReasonCode).description;

      // Comments are stored on the FinancialInstruction for the reversal
      final FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();

      financialInstructionKey.finInstructionID = reversalFinInstructionID.finInstructionID;

      final FinancialInstructionDtls reversalDtls = FinancialInstructionFactory.newInstance().read(
        financialInstructionKey);

      readPaymentReceivedDetails.reversalDetails.comments = reversalDtls.comments;
      // BEGIN, CR00324347, KH
      readPaymentReceivedDetails.reversalDetails.closureEffectiveDate = reversalDtls.effectiveDate;
      // END, CR00324347
    } else {
      readPaymentReceivedDetails.reversalDetails.reversalInd = false;
    }
    // END, CR00183541

    // BEGIN, CR00184135, MC
    // The status of a cancelled payment received is "Reversed" change so it
    // reads
    // Cancelled.
    if (readPaymentReceivedDetails.paymentReceivedHeaderDetails.statusCode.equals(
      FININSTRUCTIONSTATUS.REVERSED)) {

      // Leave the actual status as reversed but display cancelled.
      readPaymentReceivedDetails.paymentReceivedHeaderDetails.statusCode = FININSTRUCTIONSTATUS.CANCELLED;
    }
    // END, CR00184135

    // Add a context description
    final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

    financialContextDescriptionKey.finInstructionID = key.finInstructionID;
    readPaymentReceivedDetails.contextDescription.contextDescription = FinancialContextFactory.newInstance().readContextDescription(financialContextDescriptionKey).contextDescription;

    return readPaymentReceivedDetails;
  }

  // END, CR00175754

  // BEGIN, CR00180712, MC
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadReversalInstructionDetails readReversalInstruction(
    ReadReversalInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadReversalInstructionDetails readReversalInstructionDetails = new ReadReversalInstructionDetails();

    final ReadReversalInstructionDetails1 readReversalInstructionDetails1 = readReversalInstruction1(
      key);

    readReversalInstructionDetails.contextDescription = readReversalInstructionDetails1.contextDescription;
    readReversalInstructionDetails.reversalInstructionHeaderDetails.assign(
      readReversalInstructionDetails1.reversalInstructionHeaderDetails);

    ReversalInstructionDetails reversalInstructionDetails;

    for (int i = 0; i
      < readReversalInstructionDetails1.reversalInstructionDetailsList.dtls.size(); i++) {
      reversalInstructionDetails = new ReversalInstructionDetails();

      reversalInstructionDetails.assign(
        readReversalInstructionDetails1.reversalInstructionDetailsList.dtls.item(
          i));

      readReversalInstructionDetails.reversalInstructionDetailsList.dtls.addRef(
        reversalInstructionDetails);
    }

    return readReversalInstructionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadReversalInstructionDetails1 readReversalInstruction1(
    ReadReversalInstructionKey key) throws AppException,
      InformationalException {

    final ReadReversalInstructionDetails1 readReversalInstructionDetails = new ReadReversalInstructionDetails1();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    ViewReversalInstructionDetailResult1 viewReversalInstructionDetailResult;
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // Assign key details to search for the Payment Received Instruction
    accountInstructionIdentifier.assign(key);

    // Call ViewConcernAccount BPO to read Reversal Instruction details
    viewReversalInstructionDetailResult = viewConcernAccountObj.viewReversalInstructionDetail1(
      accountInstructionIdentifier);

    // Assign details to output object
    readReversalInstructionDetails.reversalInstructionHeaderDetails.assign(
      viewReversalInstructionDetailResult.reversalHeader);

    // Need to retrieve the description of the reversal code as this can be
    // populated by multiple codetables,
    final ReversalReasonCode reversalReasonCode = new ReversalReasonCode();
    final ReversalReasonDescription reversalReasonDescription = new ReversalReasonDescription();

    reversalReasonCode.reversalCode = viewReversalInstructionDetailResult.reversalHeader.reasonCode;

    reversalReasonDescription.description = getReveralReasonDescription(reversalReasonCode).description;

    readReversalInstructionDetails.reversalInstructionHeaderDetails.reasonCodeDescription = reversalReasonDescription.description;

    Double outstandingBalance = new Double(0);

    // Iterate through the list if it's populated
    if (!viewReversalInstructionDetailResult.reversalItemslist.dtls.isEmpty()) {

      // Reserve space in the output object
      readReversalInstructionDetails.reversalInstructionDetailsList.dtls.ensureCapacity(
        viewReversalInstructionDetailResult.reversalItemslist.dtls.size());

      // Assign header currency to local string
      final String baseCurrency = viewReversalInstructionDetailResult.reversalHeader.currencyType;

      ReversalInstructionDetails1 reversalInstructionDetails;

      for (int i = 0; i
        < viewReversalInstructionDetailResult.reversalItemslist.dtls.size(); i++) {

        reversalInstructionDetails = new ReversalInstructionDetails1();

        reversalInstructionDetails.assign(
          viewReversalInstructionDetailResult.reversalItemslist.dtls.item(i));

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        reversalInstructionDetails.currencyType = baseCurrency;

        // BEGIN, CR00317416, CSH
        if (reversalInstructionDetails.caseID != 0) {
          // Add case description
          final LocalisableString caseDescription = new LocalisableString(
            curam.message.GENERAL.INF_CASETYPE_CASEREF);
          final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
          final CaseKey caseKey = new CaseKey();

          caseKey.caseID = reversalInstructionDetails.caseID;
          final CaseReferenceAndTypeDetails caseReferenceAndTypeDetails = caseHeaderObj.readCaseReferenceAndTypeByCaseID(
            caseKey);

          caseDescription.arg(
            new CodeTableItemIdentifier(curam.codetable.CASETYPECODE.TABLENAME,
            caseReferenceAndTypeDetails.caseTypeCode));
          caseDescription.arg(caseReferenceAndTypeDetails.caseReference);
          reversalInstructionDetails.caseDescription = caseDescription.toClientFormattedText();
        }
        // Total the outstanding amounts on the list items for the details
        // header
        outstandingBalance = outstandingBalance
          + reversalInstructionDetails.outstandingAmount.getValue();

        // BEGIN, CR00324745, CSH
        // Check if we want to display the write off or allocate actions
        if (reversalInstructionDetails.outstandingAmount.isPositive()) {

          if (reversalInstructionDetails.creditAmount.isPositive()) {
            reversalInstructionDetails.allocateIndOpt = true;
          } else if (reversalInstructionDetails.debitAmount.isPositive()) {
            reversalInstructionDetails.writeOffIndOpt = true;
            readReversalInstructionDetails.reversalInstructionHeaderDetails.writeOffInd = true;
          }

        } else {

          reversalInstructionDetails.allocateIndOpt = false;
          reversalInstructionDetails.writeOffIndOpt = false;
          readReversalInstructionDetails.reversalInstructionHeaderDetails.writeOffInd = false;

        }

        // set type text
        final LocalisableString reversalDesc = new LocalisableString(
          GENERAL.INF_SERVER_FORMATTED_MESSAGE);
        String typeDesc = CuramConst.gkEmpty;

        if (reversalInstructionDetails.type.equals(ILITYPE.ALLOCATEDREVERSAL)
          && reversalInstructionDetails.statusCode.equals(
            FININSTRUCTIONSTATUS.PROCESSED)) {

          if (reversalInstructionDetails.outstandingAmount.isPositive()
            && reversalInstructionDetails.debitAmount.isPositive()) {
            typeDesc = GENERALFINANCE.INF_REPLACEMENT_LIABILITY.getMessageText(
              TransactionInfo.getProgramLocale());
          } else if (reversalInstructionDetails.outstandingAmount.isPositive()
            && reversalInstructionDetails.creditAmount.isPositive()) {

            typeDesc = GENERALFINANCE.INF_REPLACEMENT_RECEIPT.getMessageText(
              TransactionInfo.getProgramLocale());

          } else {
            typeDesc = GENERALFINANCE.INF_REVERSED_LINE_ITEM.getMessageText(
              TransactionInfo.getProgramLocale());
          }
        } else {
          typeDesc = GENERALFINANCE.INF_REVERSED_LINE_ITEM.getMessageText(
            TransactionInfo.getProgramLocale());
        }
        // END, CR00324745

        if (typeDesc.length() > 0) {

          reversalDesc.arg(typeDesc);
          reversalInstructionDetails.typeDescriptionOpt = reversalDesc.getMessage();

        } else {

          reversalInstructionDetails.typeDescriptionOpt = CodeTable.getOneItem(
            ILITYPE.TABLENAME, reversalInstructionDetails.type);
        }

        // END, CR00317416

        readReversalInstructionDetails.reversalInstructionDetailsList.dtls.addRef(
          reversalInstructionDetails);
      }
    }

    // Set the total of the outstandingAmounts from the list items.
    readReversalInstructionDetails.reversalInstructionHeaderDetails.amountOutstanding = new Money(
      outstandingBalance);

    // Set the foreign currency indicator to tell the pages whether or
    // not to display the foreign currency field.
    if (readReversalInstructionDetails.reversalInstructionHeaderDetails.foreignCurrency.length()
      > 0) {
      readReversalInstructionDetails.reversalInstructionHeaderDetails.foreignCurrencyInd = true;
    } else {
      readReversalInstructionDetails.reversalInstructionHeaderDetails.foreignCurrencyInd = false;
    }

    // Get the delivery method for the instruction that was reversed
    if (readReversalInstructionDetails.reversalInstructionHeaderDetails.reversalTypeCode.equals(
      FINANCIALINSTRUCTION.PAYMENT)) {

      // Payment instruction details
      final FinInstructionID pmtFinInstructionID = new FinInstructionID();

      // set key to read paymentInstruction
      pmtFinInstructionID.finInstructionID = readReversalInstructionDetails.reversalInstructionHeaderDetails.reversalFinInstructionID;

      // Read the details of the payment instrument
      // Payment instrument key and details
      final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory.newInstance().readByFinInstructionID(pmtFinInstructionID).pmtInstrumentID;

      final PaymentInstrumentDtls paymentInstrumentDtls = PaymentInstrumentFactory.newInstance().read(
        paymentInstrumentKey);

      readReversalInstructionDetails.reversalInstructionHeaderDetails.caseNomineeID = paymentInstrumentDtls.caseNomineeID;

    }

    // BEGIN, CR00160310, MC
    // Add a context description
    final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

    // Details to be returned.
    financialContextDescriptionKey.finInstructionID = key.finInstructionID;

    // Read financial context description
    readReversalInstructionDetails.contextDescription.contextDescription = FinancialContextFactory.newInstance().readContextDescription(financialContextDescriptionKey).contextDescription;
    // END, CR00160310

    return readReversalInstructionDetails;
  }

  // END, CR00180712

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadInstructionLineItemDetails readInstructionLineItemDetails(
    ReadInstructionLineItemKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadInstructionLineItemDetails readInstructionLineItemDetails = new ReadInstructionLineItemDetails();

    // ViewFinancialItem manipulation variables
    final curam.core.intf.ViewFinancialItem viewFinancialItemObj = curam.core.fact.ViewFinancialItemFactory.newInstance();
    final FinancialItemIdentifier financialItemIdentifier = new FinancialItemIdentifier();

    // Assign key to read line item details
    financialItemIdentifier.assign(key);

    // Read Instruction Line Item details and assign to output struct
    readInstructionLineItemDetails.assign(
      viewFinancialItemObj.viewFinancialItemDetail(financialItemIdentifier));

    return readInstructionLineItemDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ListPaymentIssuedDetails searchForPaymentIssued(
    SearchForPaymentIssuedKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListPaymentIssuedDetails listPaymentIssuedDetails = new ListPaymentIssuedDetails();

    final ListPaymentIssuedDetails1 listPaymentIssuedDetails1 = FinancialFactory.newInstance().searchForPaymentIssued1(
      key);

    PaymentIssuedDetails paymentIssuedDetails;

    for (int i = 0; i < listPaymentIssuedDetails1.dtls.size(); i++) {
      paymentIssuedDetails = new PaymentIssuedDetails();
      paymentIssuedDetails.assign(listPaymentIssuedDetails1.dtls.item(i));
    }

    listPaymentIssuedDetails.messages.assign(listPaymentIssuedDetails1.messages);

    return listPaymentIssuedDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListPaymentIssuedDetails1 searchForPaymentIssued1(
    SearchForPaymentIssuedKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListPaymentIssuedDetails1 listPaymentIssuedDetails = new ListPaymentIssuedDetails1();

    // SearchForPaymentsIssued manipulation variables
    final curam.core.intf.SearchForPaymentIssuedRouter searchForPaymentIssuedObj = curam.core.fact.SearchForPaymentIssuedRouterFactory.newInstance();

    SearchForPmtIssuedInstrumentResult searchForPmtIssuedInstrumentResult;
    final PaymentIssuedSearchDtls paymentIssuedSearchDtls = new PaymentIssuedSearchDtls();

    // Assign key details to search for the payments issued
    paymentIssuedSearchDtls.assign(key);

    // Call SearchForPaymentIssued BPO to search for the payments issued
    searchForPmtIssuedInstrumentResult = searchForPaymentIssuedObj.searchForPmtIssuedInstrument(
      paymentIssuedSearchDtls);

    // Assign details to output object
    listPaymentIssuedDetails.assign(
      searchForPmtIssuedInstrumentResult.pmtIssuedInstrumentDtlsList);

    listPaymentIssuedDetails.messages.assign(
      searchForPmtIssuedInstrumentResult.searchMessageDtlsList);

    // If the payment has already been reissued do not display the reissue
    // button
    // Has the cancelled payment been invalidated?
    final FinancialListHelper financialListHelper = new FinancialListHelper();
    final FinancialInstructionDetails financialInstructionDetails = new FinancialInstructionDetails();

    final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

    PaymentIssuedDetails1 paymentIssuedDetails1;

    for (int i = 0; i < listPaymentIssuedDetails.dtls.size(); i++) {

      boolean alreadyRegenerated = false;

      paymentIssuedDetails1 = listPaymentIssuedDetails.dtls.item(i);

      paymentInstrumentKey.pmtInstrumentID = paymentIssuedDetails1.pmtInstrumentID;

      financialInstructionDetails.typeCode = FINANCIALINSTRUCTION.PAYMENT;

      if (paymentIssuedDetails1.reconcilStatusCode.equals(
        FININSTRUCTIONSTATUS.CANCELLED)) {

        financialInstructionDetails.statusCode = FININSTRUCTIONSTATUS.CANCELLED;
        // Find all instructions associated with the instrument
        final FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList = PaymentInstructionFactory.newInstance().searchByPmtInstrumentID(
          paymentInstrumentKey);

        // Check each financial instruction in turn to see if it has been
        // regenerated
        for (int x = 0; x < finInstructionIDConcernRoleIDList.dtls.size(); x++) {

          financialInstructionDetails.finInstructionID = finInstructionIDConcernRoleIDList.dtls.item(x).finInstructionID;

          if (financialListHelper.paymentReissued(financialInstructionDetails).booleanResult) {
            alreadyRegenerated = true;
            break;
          }

        }
        if (alreadyRegenerated
          || PaymentInstrumentFactory.newInstance().readInvalidatedInd(paymentInstrumentKey).invalidatedInd) {
          paymentIssuedDetails1.actionDisplayInds.reissueInd = false;
        } else {
          paymentIssuedDetails1.actionDisplayInds.reissueInd = true;
        }
        paymentIssuedDetails1.actionDisplayInds.cancelInd = false;
      } else {
        paymentIssuedDetails1.actionDisplayInds.cancelInd = true;
      }
    }

    return listPaymentIssuedDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public void allocateCreditTransaction(AllocationDetails details)
    throws AppException, InformationalException {

    final AllocationDetails1 allocationDetails1 = new AllocationDetails1();

    allocationDetails1.amount = details.amount;
    allocationDetails1.debitInstructionLineItemID = details.debitInstructionLineItemID;
    allocationDetails1.creditInstructionLineItemID = details.creditInstructionLineItemID;

    allocateCreditTransaction1(allocationDetails1);
  }

  /**
   * {@inheritDoc}
   *
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void allocateCreditTransaction1(AllocationDetails1 details)
    throws AppException, InformationalException {

    // AllocateCreditTransaction manipulation variables
    final curam.core.intf.AllocateCreditTransaction allocateCreditTransactionObj = curam.core.fact.AllocateCreditTransactionFactory.newInstance();
    final CreditAllocateKey creditAllocateKey = new CreditAllocateKey();
    final AllocationDtlsCaptured allocationDtlsCaptured = new AllocationDtlsCaptured();

    // Assign details to capture the allocation amount on the draft allocation
    // line
    allocationDtlsCaptured.assign(details);

    // If the allocateAll indicator is true allocate the full unprocessed amount
    if (details.allocateAll) {
      // Read the unallocated amount and set it as the amount to allocate.
      final InstructionLineItemKey creditILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls creditILIDtls;

      creditILIKey.instructLineItemID = allocationDtlsCaptured.creditInstructionLineItemID;

      // read credit ILI
      creditILIDtls = InstructionLineItemFactory.newInstance().read(
        creditILIKey);
      allocationDtlsCaptured.amount = creditILIDtls.unprocessedAmount;
    }

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (details.allocateAll && !details.amount.isZero()) {
      // Either Allocate All or a specified amount to allocate can be entered,
      // not both.
      final AppException e = new AppException(
        BPOALLOCATECREDITTRANSACTION.ERR_ALLOCATEPAYMENT_XFV_ALL_AND_AMOUNT);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
    // You must select a liability to allocate the received payment to.
    if (details.debitInstructionLineItemID == 0) {
      final AppException e = new AppException(
        BPOALLOCATECREDITTRANSACTION.ERR_ALLOCATEPAYMENT_LIABILITY_NOT_SPECIFIED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    informationalManager.failOperation();

    // Call AllocateCreditTransaction BPO to store the allocation amount
    allocateCreditTransactionObj.captureAllocationLine(allocationDtlsCaptured);

    // Assign key details to perform the allocation
    creditAllocateKey.instructionLineItemID = details.creditInstructionLineItemID;

    // Call AllocateCreditTransaction BPO to perform the allocation
    allocateCreditTransactionObj.allocateCreditTransaction(creditAllocateKey);

    // Call the AllocateCreditTransaction BPO to remove the draft allocation
    // line
    allocateCreditTransactionObj.removeAllocationDtls(creditAllocateKey);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadDebitsForAllocation readDebitsForAllocation(AllocationKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadDebitsForAllocation readDebitsForAllocation = new ReadDebitsForAllocation();

    // AllocateCreditTransaction manipulation variables
    final curam.core.intf.AllocateCreditTransaction allocateCreditTransactionObj = curam.core.fact.AllocateCreditTransactionFactory.newInstance();
    final CreditAllocateKey creditAllocateKey = new CreditAllocateKey();
    ReadDebitsForAllocationResult readDebitsForAllocationResult;

    // Assign key details to search for the debits for allocation
    creditAllocateKey.assign(key);

    // Call the AllocateCreditTransaction BPO to read debits for allocation
    readDebitsForAllocationResult = allocateCreditTransactionObj.readDebitsForAllocation(
      creditAllocateKey);

    // BEGIN, CR00158104, SAI

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readDebitsForAllocation.infoDtls.dtls.addRef(informationalMsgDtls);

    }
    // END, CR00158104

    // Assign allocation summary details to return object
    readDebitsForAllocation.creditAllocationSummary.assign(
      readDebitsForAllocationResult.creditAllocationSummary);

    // Assign debits for allocation to the return object
    readDebitsForAllocation.listDebitsOutstanding.assign(
      readDebitsForAllocationResult.debitsOutstandingList);

    return readDebitsForAllocation;
  }

  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadDebitsForAllocation1 readDebitsForAllocation1(AllocationKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadDebitsForAllocation1 readDebitsForAllocation = new ReadDebitsForAllocation1();

    // AllocateCreditTransaction manipulation variables
    final curam.core.intf.AllocateCreditTransaction allocateCreditTransactionObj = curam.core.fact.AllocateCreditTransactionFactory.newInstance();
    final CreditAllocateKey creditAllocateKey = new CreditAllocateKey();
    ReadDebitsForAllocationResult readDebitsForAllocationResult;

    // Assign key details to search for the debits for allocation
    creditAllocateKey.assign(key);

    // Call the AllocateCreditTransaction BPO to read debits for allocation
    readDebitsForAllocationResult = allocateCreditTransactionObj.readDebitsForAllocation(
      creditAllocateKey);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readDebitsForAllocation.infoDtls.dtls.addRef(informationalMsgDtls);

    }

    // Assign allocation summary details to return object
    readDebitsForAllocation.creditAllocationSummary.assign(
      readDebitsForAllocationResult.creditAllocationSummary);

    // Assign debits for allocation to the return object
    readDebitsForAllocation.listDebitsOutstanding.assign(
      readDebitsForAllocationResult.debitsOutstandingList);

    if (readDebitsForAllocation.creditAllocationSummary.unallocatedAmount.isZero()) {
      readDebitsForAllocation.amountToAllocateInd = false;
    } else {
      readDebitsForAllocation.amountToAllocateInd = true;
    }

    DebitsOutstandingDetails_fo debitsOutstandingDetails;

    for (int i = 0; i
      < readDebitsForAllocation.listDebitsOutstanding.dtls.size(); i++) {

      debitsOutstandingDetails = new DebitsOutstandingDetails_fo();
      debitsOutstandingDetails = readDebitsForAllocation.listDebitsOutstanding.dtls.item(
        i);

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = debitsOutstandingDetails.debitCaseID;

      final CaseReferenceAndTypeDetails caseReferenceAndTypeDetails = caseHeaderObj.readCaseReferenceAndTypeByCaseID(
        caseKey);

      final LocalisableString caseDescription = new LocalisableString(
        GENERAL.INF_CASETYPE_CASEREF);

      // BEGIN, CR00400635, KRK
      // BEGIN, CR00401443, KRK
      caseDescription.arg(
        new CodeTableItemIdentifier(CASETYPECODE.TABLENAME, caseReferenceAndTypeDetails.caseTypeCode).toString());
      caseDescription.arg(caseReferenceAndTypeDetails.caseReference);
      // END, CR00401443
      debitsOutstandingDetails.debitCaseReference = caseDescription.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00400635
    }
    return readDebitsForAllocation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void captureManualPayment(
    curam.core.facade.struct.ManualPaymentDetails details)
    throws AppException, InformationalException {

    // ManualPayments manipulation variables
    final curam.core.intf.ManualPayments manualPaymentsObj = curam.core.fact.ManualPaymentsFactory.newInstance();
    final curam.core.struct.ManualPaymentDetails manualPaymentDetails = new curam.core.struct.ManualPaymentDetails();

    // Assign details to capture the manual payment
    manualPaymentDetails.assign(details);

    // Call ManualPayments BPO to capture the manual payment details
    manualPaymentsObj.captureManualPayment(manualPaymentDetails);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListLiabilityIssuedDetails searchForLiabilityIssued(
    SearchForLiabilityIssuedKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListLiabilityIssuedDetails listLiabilityIssuedDetails = new ListLiabilityIssuedDetails();

    // SearchForLiabilityIssued manipulation variables
    final curam.core.intf.SearchForLiabilityIssuedRouter searchForLiabilityIssuedObj = curam.core.fact.SearchForLiabilityIssuedRouterFactory.newInstance();
    final LiabilityIssuedSearchDtls liabilityIssuedSearchDtls = new LiabilityIssuedSearchDtls();
    SearchForLiabilityIssuedInstrumentResult searchForLiabilityIssuedInstrumentResult;

    // Assign key details to search for the liabilities issued
    liabilityIssuedSearchDtls.assign(key);

    // Call SearchForLiabilityIssued BPO to search for the liabilities issued
    searchForLiabilityIssuedInstrumentResult = searchForLiabilityIssuedObj.searchForLiabilityIssuedInstrument(
      liabilityIssuedSearchDtls);

    // Assign details to return object
    listLiabilityIssuedDetails.assign(
      searchForLiabilityIssuedInstrumentResult.liabilityIssuedInstrumentDtlsList);

    listLiabilityIssuedDetails.messages.assign(
      searchForLiabilityIssuedInstrumentResult.searchMessageDtlsList);

    return listLiabilityIssuedDetails;
  }

  // BEGIN, CR00174383, MC
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadLiabilityInstructionDetails readLiabilityInstruction(
    ReadLiabilityInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadLiabilityInstructionDetails readLiabilityInstructionDetails = new ReadLiabilityInstructionDetails();

    final ReadLiabilityInstructionDetails1 readLiabilityInstructionDetails1 = readLiabilityInstruction1(
      key);

    readLiabilityInstructionDetails.contextDescription = readLiabilityInstructionDetails1.contextDescription;
    readLiabilityInstructionDetails.liabilityHeaderDetails = readLiabilityInstructionDetails1.liabilityHeaderDetails;

    LiabilityDetails1 liabilityDetails1;
    LiabilityDetails liabilityDetails;

    for (int i = 0; i
      < readLiabilityInstructionDetails1.liabilityDetailsList.dtls.size(); i++) {
      liabilityDetails1 = readLiabilityInstructionDetails1.liabilityDetailsList.dtls.item(
        i);
      liabilityDetails = new LiabilityDetails();
      liabilityDetails.assign(liabilityDetails1);

      readLiabilityInstructionDetails.liabilityDetailsList.dtls.addRef(
        liabilityDetails);
    }

    return readLiabilityInstructionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadLiabilityInstructionDetails1 readLiabilityInstruction1(
    ReadLiabilityInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadLiabilityInstructionDetails1 readLiabilityInstructionDetails = new ReadLiabilityInstructionDetails1();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    ViewLiabilityInstructionDetailResult1 viewLiabilityInstructionDetailResult;
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // ListLiabilityDetails object
    final ListLiabilityDetails1 listLiabilityDetails = new ListLiabilityDetails1();

    // Assign key details to search for the Liability Instruction
    accountInstructionIdentifier.assign(key);

    // Call ViewConcernAccount BPO to read Liability Instruction details
    viewLiabilityInstructionDetailResult = viewConcernAccountObj.viewLiabilityInstructionDetail1(
      accountInstructionIdentifier);

    // Assign header details to return object
    readLiabilityInstructionDetails.liabilityHeaderDetails.assign(
      viewLiabilityInstructionDetailResult.liabilityHeader);

    // Used to read the reversal details for a reversed payment
    final FinInstructionID reversalInstructionID = new FinInstructionID();
    boolean liabilityILIsReversed = false;

    // Iterate through the list if it's populated
    if (!viewLiabilityInstructionDetailResult.liabilityDetailList.dtls.isEmpty()) {
      // Reserve space in the output object
      readLiabilityInstructionDetails.liabilityDetailsList.dtls.ensureCapacity(
        viewLiabilityInstructionDetailResult.liabilityDetailList.dtls.size());

      // LiabilityDetails object
      LiabilityDetails1 liabilityDetails1;

      for (int i = 0; i
        < viewLiabilityInstructionDetailResult.liabilityDetailList.dtls.size(); i++) {

        liabilityDetails1 = new LiabilityDetails1();
        liabilityDetails1.assign(
          viewLiabilityInstructionDetailResult.liabilityDetailList.dtls.item(i));

        if (liabilityDetails1.outstandingAmount.isZero()
          || !liabilityDetails1.statusCode.equals(
            curam.codetable.ILISTATUS.PROCESSED)
              && !liabilityDetails1.statusCode.equals(
                curam.codetable.ILISTATUS.UNPROCESSED)) {
          // Don't display the write off indicator
          liabilityDetails1.writeOffIndicator = false;
        }

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        liabilityDetails1.currencyType = viewLiabilityInstructionDetailResult.liabilityHeader.currencyType;

        // Add details to list
        listLiabilityDetails.dtls.addRef(liabilityDetails1);

        // BEGIN, CR00183514, MC
        // If any of the instruction line items are reversed find the ID of the
        // reversal
        // instruction from the related ILIs and set an indicator so that the
        // reversal
        // details are read and displayed on the liability screen.
        final RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();

        // set key to read instructionLineItem
        relatedILIidentifier.instructLineItemID = liabilityDetails1.instructionLineItemID;
        relatedILIidentifier.type = curam.codetable.ILIRELATIONSHIP.REVERSALS;

        final InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

        final InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

        instructionLineItemKey.instructLineItemID = liabilityDetails1.instructionLineItemID;

        if (instructionLineItemObj.read(instructionLineItemKey).statusCode.equals(
          ILISTATUS.REVERSED)) {
          liabilityILIsReversed = true;
        }
        // read instructionLineItems related to this instruction
        final RelatedILIDetailsList relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
          relatedILIidentifier);

        for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

          // If the reversalFinInstructionID is not already set
          if (reversalInstructionID.finInstructionID == 0) {
            reversalInstructionID.finInstructionID = relatedILIDetailsList.dtls.item(j).finInstructionID;
          }
        }
      }
      // END, CR00183514
    }

    // Assign liability instruction details list to return object
    readLiabilityInstructionDetails.liabilityDetailsList.assign(
      listLiabilityDetails);

    readLiabilityInstructionDetails.totalOutstanding = viewLiabilityInstructionDetailResult.totalOutstanding;
    readLiabilityInstructionDetails.deliveryMethod = viewLiabilityInstructionDetailResult.deliveryMethod;
    readLiabilityInstructionDetails.issuedDate = viewLiabilityInstructionDetailResult.issuedDate;

    // Set up the covers period for display
    final LocalisableString coversPeriod = new LocalisableString(
      curam.message.GENERAL.INF_DATE_TO_DATE);

    coversPeriod.arg(
      readLiabilityInstructionDetails.liabilityHeaderDetails.coverPeriodFromDate);
    coversPeriod.arg(
      readLiabilityInstructionDetails.liabilityHeaderDetails.coverPeriodToDate);

    readLiabilityInstructionDetails.coversPeriod = coversPeriod.toClientFormattedText();

    // BEGIN, CR00181398, MC
    readLiabilityInstructionDetails.formattedNomineeAddress = viewLiabilityInstructionDetailResult.formattedNomineeAddress;
    // END, CR00181398

    // BEGIN, CR00183541, MC
    // Display the reversal details for this instruction if it has been
    // reversed.
    if (liabilityILIsReversed) {

      readLiabilityInstructionDetails.reversalDetails.reversalInd = true;

      // This is the financial instruction ID on the reversal instruction, read
      // earlier in this method using the relationships between the ILIs
      final ReversalFinInstructionID reversalFinInstructionID = new ReversalFinInstructionID();

      reversalFinInstructionID.finInstructionID = reversalInstructionID.finInstructionID;

      final ReversalReasonCode reversalReasonCode = new ReversalReasonCode();

      reversalReasonCode.reversalCode = ReversalInstructionFactory.newInstance().readByFinInstructionID(reversalFinInstructionID).reasonCode;

      readLiabilityInstructionDetails.reversalDetails.reasonDescription = getReversalReasonDescription(reversalReasonCode).description;

      // Comments are stored on the FinancialInstruction for the reversal
      final FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();

      financialInstructionKey.finInstructionID = reversalFinInstructionID.finInstructionID;

      readLiabilityInstructionDetails.reversalDetails.comments = FinancialInstructionFactory.newInstance().read(financialInstructionKey).comments;

      // Display the status of the liability as reversed
      readLiabilityInstructionDetails.liabilityHeaderDetails.statusCode = FININSTRUCTIONSTATUS.REVERSED;

    } else {
      readLiabilityInstructionDetails.reversalDetails.reversalInd = false;
    }
    // END, CR00183541

    // BEGIN, CR00160310, MC
    // Add a context description
    final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

    // Details to be returned.
    financialContextDescriptionKey.finInstructionID = key.finInstructionID;

    // Read financial context description
    readLiabilityInstructionDetails.contextDescription.contextDescription = FinancialContextFactory.newInstance().readContextDescription(financialContextDescriptionKey).contextDescription;
    // END, CR00160310

    return readLiabilityInstructionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadWriteOffInstructionDetails1 readWriteOffInstruction1(
    ReadWriteOffInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadWriteOffInstructionDetails1 readWriteOffInstructionDetails = new ReadWriteOffInstructionDetails1();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    ViewWriteOffInstructionDetailResult1 viewWriteOffInstructionDetailResult;
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // ListWriteOffDetails object
    final ListWriteOffDetails1 listWriteOffDetails = new ListWriteOffDetails1();

    // Assign key details to search for the Write-off Instruction
    accountInstructionIdentifier.assign(key);

    // Call ViewConcernAccount BPO to read Write-off Instruction details
    viewWriteOffInstructionDetailResult = viewConcernAccountObj.viewWriteOffInstructionDetail1(
      accountInstructionIdentifier);

    // Assign header details to output struct
    readWriteOffInstructionDetails.writeOffHeaderDetails.assign(
      viewWriteOffInstructionDetailResult.writeOffHeader);

    // Iterate through the list if it's populated
    if (!viewWriteOffInstructionDetailResult.writeOffDetailsList.dtls.isEmpty()) {

      // Reserve space in the output struct
      readWriteOffInstructionDetails.writeOffDetailsList.dtls.ensureCapacity(
        viewWriteOffInstructionDetailResult.writeOffDetailsList.dtls.size());

      // WriteOffDetails object
      curam.core.facade.struct.WriteOffDetails1 writeOffDetails;

      for (int i = 0; i
        < viewWriteOffInstructionDetailResult.writeOffDetailsList.dtls.size(); i++) {
        writeOffDetails = new curam.core.facade.struct.WriteOffDetails1();

        writeOffDetails.assign(
          viewWriteOffInstructionDetailResult.writeOffDetailsList.dtls.item(i));

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        writeOffDetails.currencyType = viewWriteOffInstructionDetailResult.writeOffHeader.currencyType;

        // Subtract the amounts written off by the write off line items
        // This figure does not currently include the allocations for this
        // write off.
        writeOffDetails.outstandingAmount = new Money(
          writeOffDetails.amount.getValue()
            - writeOffDetails.allocationAmount.getValue());

        // Add details to list
        listWriteOffDetails.dtls.addRef(writeOffDetails);
      }

    }

    // Assign write-off details list to return object
    readWriteOffInstructionDetails.writeOffDetailsList.assign(
      listWriteOffDetails);

    // BEGIN, CR00160310, MC
    // Add a context description
    final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

    // Details to be returned.
    financialContextDescriptionKey.finInstructionID = key.finInstructionID;

    // Read financial context description
    readWriteOffInstructionDetails.contextDescription.contextDescription = FinancialContextFactory.newInstance().readContextDescription(financialContextDescriptionKey).contextDescription;
    // END, CR00160310

    return readWriteOffInstructionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadWriteOffInstructionDetails readWriteOffInstruction(
    ReadWriteOffInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadWriteOffInstructionDetails readWriteOffInstructionDetails = new ReadWriteOffInstructionDetails();

    final ReadWriteOffInstructionDetails1 readWriteOffInstructionDetails1 = readWriteOffInstruction1(
      key);

    readWriteOffInstructionDetails.contextDescription = readWriteOffInstructionDetails1.contextDescription;

    readWriteOffInstructionDetails.writeOffHeaderDetails.assign(
      readWriteOffInstructionDetails1.writeOffHeaderDetails);

    WriteOffDetails1 writeOffDetails1;
    WriteOffDetails writeOffDetails;

    for (int i = 0; i
      < readWriteOffInstructionDetails1.writeOffDetailsList.dtls.size(); i++) {
      writeOffDetails = new WriteOffDetails();
      writeOffDetails1 = readWriteOffInstructionDetails1.writeOffDetailsList.dtls.item(
        i);
      writeOffDetails.assign(writeOffDetails1);

      readWriteOffInstructionDetails.writeOffDetailsList.dtls.addRef(
        writeOffDetails);
    }

    return readWriteOffInstructionDetails;
  }

  // END, CR00174383

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadSuspenseAccountDetails readSuspenseAccount(
    ReadSuspenseAccountKey key) throws AppException, InformationalException {

    // Create return object
    final ReadSuspenseAccountDetails readSuspenseAccountDetails = new ReadSuspenseAccountDetails();

    // ViewSuspenseAccount manipulation variables
    final curam.core.intf.ViewSuspenseAccount viewSuspenseAccountObj = curam.core.fact.ViewSuspenseAccountFactory.newInstance();
    ViewSuspenseAccountDetailsResult viewSuspenseAccountDetailsResult;
    final SuspAccountKey suspAccountKey = new SuspAccountKey();

    // Assign key details to read Suspense Account details
    suspAccountKey.assign(key);

    // Call ViewSuspenseAccount BPO to read Suspense Account details
    viewSuspenseAccountDetailsResult = viewSuspenseAccountObj.viewSuspenseAccountDetails(
      suspAccountKey);

    // Assign details to return object
    readSuspenseAccountDetails.assign(
      viewSuspenseAccountDetailsResult.suspAccountDetails);

    return readSuspenseAccountDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void approvePayment(ApprovePaymentDetails details)
    throws AppException, InformationalException {

    // ApprovePayment manipulation variables
    final curam.core.intf.ApprovePayment approvePaymentObj = curam.core.fact.ApprovePaymentFactory.newInstance();
    final PaymentDetailsSummary paymentDetailsSummary = new PaymentDetailsSummary();

    // Set details to approve payment
    paymentDetailsSummary.approvalDate = details.approvalDate;
    paymentDetailsSummary.reasonText = details.reasonText;
    paymentDetailsSummary.finInstructionID = details.finInstructionID;

    // Call BPO to approve payment
    approvePaymentObj.approvePaymentIssue(paymentDetailsSummary);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void regenerateCanceledPayment(
    curam.core.struct.FinInstructionID finInstructionID) throws AppException,
      InformationalException {

    // BEGIN, CR00198173, SS
    // BEGIN, CR00265470, ZV
    CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();

    // Read the class name from property file.
    final String financialResolverName = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_CREATECANCELLATION_CLASS);

    // BEGIN, CR00206354, SS
    final Object obj = FinancialUtil.getResolverClassName(financialResolverName,
      createCancellationObj.getCaseIDForFinInstructionId(
      finInstructionID.finInstructionID));

    // END, CR00206354
    if (null != obj) {
      createCancellationObj = (curam.core.intf.CreateCancellation) obj;
    }
    // END, CR00265470

    // Call CreateCancellation BPO to regenerate the canceled payment.
    createCancellationObj.regeneratePayment(finInstructionID);
    // END, CR00198173
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void captureAccountAdjustment(
    AccountAdjustmentDetails accountAdjustmentDetails) throws AppException,
      InformationalException {

    // AccountAdjustment manipulation variables
    final curam.core.intf.AccountAdjustment accountAdjustmentObj = curam.core.fact.AccountAdjustmentFactory.newInstance();
    final AdjustmentDetails adjustmentDetails = new AdjustmentDetails();

    adjustmentDetails.adjustmentType = accountAdjustmentDetails.adjustmentType;
    adjustmentDetails.amount = accountAdjustmentDetails.amount;
    adjustmentDetails.comments = accountAdjustmentDetails.comments;
    adjustmentDetails.concernRoleID = accountAdjustmentDetails.concernRoleID;
    adjustmentDetails.currencyTypeCode = accountAdjustmentDetails.currencyTypeCode;
    adjustmentDetails.reasonCode = accountAdjustmentDetails.reasonCode;

    // Call CaptureAccountAdjustment BPO to record account adjustment details
    accountAdjustmentObj.captureAccountAdjustment(adjustmentDetails);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadPaymentDetailsResult readPaymentDetails(ReadPaymentDetailsKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadPaymentDetailsResult readPaymentDetailsResult = new ReadPaymentDetailsResult();

    // ViewConcernAcccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();

    // Call business operation to retrieve payment instrument details
    readPaymentDetailsResult.result = viewConcernAccountObj.viewPaymentInstrumentDetails(
      key.key);

    return readPaymentDetailsResult;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadPaymentInstrumentDetail readPaymentInstrument(
    ReadPaymentDetailsKey key) throws AppException, InformationalException {

    // Create return object
    final ReadPaymentInstrumentDetail readPaymentInstrumentDetail = new ReadPaymentInstrumentDetail();

    // address manipulation variables
    final AddressKey addressKey = new AddressKey();
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final OtherAddressData unformatedAddress = new OtherAddressData();

    // ViewConcernAcccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();

    // Call business operation to retrieve payment instrument details
    readPaymentInstrumentDetail.instrumentDtls = viewConcernAccountObj.viewPaymentInstrumentDetails(
      key.key);

    unformatedAddress.addressData = CuramConst.gkEmpty;
    addressKey.addressID = PaymentInstrumentFactory.newInstance().read(key.key.key).addressID;

    // read address entity
    unformatedAddress.addressData = addressObj.read(addressKey).addressData;

    readPaymentInstrumentDetail.formattedNomineeAddress = ParticipantFactory.newInstance().displaySingleLineAddress(unformatedAddress).addressString;

    // Set the Delivery method display indicators
    final DeliveryMethodType deliveryMethodType = new DeliveryMethodType();

    deliveryMethodType.deliveryMethodType = readPaymentInstrumentDetail.instrumentDtls.paymentDetails.paymentHeader.methodOfDelivery;
    readPaymentInstrumentDetail.deliveryMethodDisplayInds = readDeliveryMethodIndicators(
      deliveryMethodType);

    // Set the foreign currency indicator to conditionally display the foreign
    // currency field.
    final String foreignCurrency = readPaymentInstrumentDetail.instrumentDtls.paymentDetails.paymentHeader.foreignCurrency;

    if (foreignCurrency.length() > 0) {
      readPaymentInstrumentDetail.foreignCurrencyInd = true;
    }

    // BEGIN, CR00369678, GA
    // Check to see if the nominee name is populated. If it's not, use the
    // concern role name as nomineeName will not be populated for Third Party
    // Payments.
    if (readPaymentInstrumentDetail.instrumentDtls.paymentDetails.paymentHeader.nomineeName.isEmpty()) {
      readPaymentInstrumentDetail.instrumentDtls.paymentDetails.paymentHeader.nomineeName = readPaymentInstrumentDetail.instrumentDtls.paymentDetails.paymentHeader.concernRoleName;
    }
    // END, CR00369678

    return readPaymentInstrumentDetail;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DeliveryMethodIndicators readDeliveryMethodIndicators(
    DeliveryMethodType deliveryMethod) {

    final DeliveryMethodIndicators deliveryMethodIndicators = new DeliveryMethodIndicators();

    if (deliveryMethod.deliveryMethodType.equals(METHODOFDELIVERY.CASH)) {
      deliveryMethodIndicators.cashInd = true;
    } else if (deliveryMethod.deliveryMethodType.equals(METHODOFDELIVERY.CHEQUE)) {
      deliveryMethodIndicators.chequeInd = true;
    } else if (deliveryMethod.deliveryMethodType.equals(METHODOFDELIVERY.EFT)) {
      // BEGIN, CR00372248, GA

      final InternationalBankAccountIndicator internationalBankAccountIndicator = new InternationalBankAccountIndicator();

      internationalBankAccountIndicator.ibanInd = Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_ENABLE_IBAN_FUNCTIONALITY);

      if (internationalBankAccountIndicator.ibanInd) {
        deliveryMethodIndicators.EFTWithIBANIndOpt = true;
      } else {

        deliveryMethodIndicators.EFTInd = true;
      }
      // END, CR00372248
    } else if (deliveryMethod.deliveryMethodType.equals(
      METHODOFDELIVERY.VOUCHER)) {
      deliveryMethodIndicators.voucherInd = true;
    } else {
      // Set the catch all to be true
      deliveryMethodIndicators.otherDeliveryMethodInd = true;
    }

    return deliveryMethodIndicators;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public void regenerateCanceledPaymentForNewNominee(
    RegenerateCanceledPaymentForNewNomineeDetails key) throws AppException,
      InformationalException {

    // BEGIN, CR00198173, SS
    // BEGIN, CR00265470, ZV
    CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();

    // Read the class name from property file.
    final String financialResolverName = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_CREATECANCELLATION_CLASS);

    // BEGIN, CR00206354, SS
    final Object obj = FinancialUtil.getResolverClassName(financialResolverName,
      createCancellationObj.getCaseIDForFinInstructionId(
      key.regeneratePaymentDetails.finInstructionID));

    // END, CR00206354
    if (null != obj) {
      createCancellationObj = (curam.core.intf.CreateCancellation) obj;
    }
    // END, CR00265470
    // END, CR00198173
    // Based on the financial instruction id find the current nominee for the
    // case and compare to the nominee passed in.

    // InstructionLineItem manipulation variables
    final InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    final FinancialInstructionIDKey financialInstructionKey = new FinancialInstructionIDKey();

    // Set key to read InstructionLineItem.
    financialInstructionKey.finInstructionID = key.regeneratePaymentDetails.finInstructionID;

    // Read the current caseNomineeID from the instruction line item.
    final long currentCaseNomineeID = instructionLineItemObj.readCaseNomineeIDByFinInstructionID(financialInstructionKey).caseNomineeID;

    // If the nominee id passed in is the same as the current nominee regenerate
    // payments for the current nominee.
    // BEGIN, CR00142428, MC
    // If the caseNomineeID passed in by the UI is zero use the current case
    // nominee ID when regenerating the payment.
    if (currentCaseNomineeID == key.regeneratePaymentDetails.caseNomineeID
      || key.regeneratePaymentDetails.caseNomineeID == 0) {
      // END, CR00142428
      final FinInstructionID finInstructionID = new FinInstructionID();

      finInstructionID.finInstructionID = key.regeneratePaymentDetails.finInstructionID;

      // Call CreateCancellation BPO to regenerate the canceled payment.
      createCancellationObj.regeneratePayment(finInstructionID);

      // If a new nominee is passed regenerate payments for that nominee.
    } else {

      createCancellationObj.regeneratePaymentForNewNominee(
        key.regeneratePaymentDetails);
    }

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseIDDetails readIntegratedCaseIDByCaseID(
    ResolveIntegratedCaseKey resolveIntegratedCaseKey) throws AppException,
      InformationalException {

    // Return Object
    final IntegratedCaseIDDetails integratedCaseIDDetails = new IntegratedCaseIDDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // do a read to see if the case has an integrated case
    integratedCaseIDDetails.integratedCaseID = caseHeaderObj.readIntegratedCaseIDByCaseID(
      resolveIntegratedCaseKey.caseKey);

    // return the integrated case id
    return integratedCaseIDDetails;
  }

  // END,HARP 41398
  // BEGIN, CR00184306, MC
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public ReadAdjustmentInstructionResult readAdjustmentInstruction(
    ReadAdjustmentInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadAdjustmentInstructionResult readAdjustmentInstructionResult = new ReadAdjustmentInstructionResult();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // Set key to retrieve adjustment instruction details
    accountInstructionIdentifier.finInstructionID = key.financialInstructionID;
    accountInstructionIdentifier.concernRoleID = key.concernRoleID;

    // Retrieve adjustment instruction details
    readAdjustmentInstructionResult.result = viewConcernAccountObj.viewAdjustmentInstructionDetail(
      accountInstructionIdentifier);

    // BEGIN, CR00160310, MC
    // Add a context description
    final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

    // Details to be returned.
    financialContextDescriptionKey.finInstructionID = key.financialInstructionID;

    // Read financial context description
    readAdjustmentInstructionResult.contextDescription.contextDescription = FinancialContextFactory.newInstance().readContextDescription(financialContextDescriptionKey).contextDescription;
    // END, CR00160310

    return readAdjustmentInstructionResult;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadAdjustmentInstructionResult1 readAdjustmentInstruction1(
    ReadAdjustmentInstructionKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadAdjustmentInstructionResult1 readAdjustmentInstructionResult = new ReadAdjustmentInstructionResult1();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // Set key to retrieve adjustment instruction details
    accountInstructionIdentifier.finInstructionID = key.financialInstructionID;
    accountInstructionIdentifier.concernRoleID = key.concernRoleID;

    // Retrieve adjustment instruction details
    final ViewAdjustmentInstructionDetailResult viewAdjustmentInstructionDetailResult = viewConcernAccountObj.viewAdjustmentInstructionDetail(
      accountInstructionIdentifier);

    readAdjustmentInstructionResult.assign(
      viewAdjustmentInstructionDetailResult.adjustmentHeader);

    if (readAdjustmentInstructionResult.foreignCurrency.length() > 0) {
      readAdjustmentInstructionResult.foreignCurrencyInd = true;
    } else {
      readAdjustmentInstructionResult.foreignCurrencyInd = false;
    }

    // Only one ILI is generated per adjustment instruction
    final LocalisableString adjustmentTypeDescription = new LocalisableString(
      curam.message.GENERAL.INF_CASETYPE_CASEREF);

    final ConcernAccAdjustedItemsDetail concernAccAdjustedItemsDetail = viewAdjustmentInstructionDetailResult.adjustedItemsList.dtls.item(
      0);

    adjustmentTypeDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.ADJUSTMENTTYPE.TABLENAME,
      concernAccAdjustedItemsDetail.adjustmentType));

    if (concernAccAdjustedItemsDetail.creditAmount.isZero()) {
      adjustmentTypeDescription.arg(
        GENERALFINANCE.INF_DEBIT.getMessageText(
          TransactionInfo.getProgramLocale()));
    } else {
      adjustmentTypeDescription.arg(
        GENERALFINANCE.INF_CREDIT.getMessageText(
          TransactionInfo.getProgramLocale()));
    }

    readAdjustmentInstructionResult.adjustmentTypeDescription = adjustmentTypeDescription.toClientFormattedText();

    return readAdjustmentInstructionResult;
  }

  // END, CR00184306

  /**
   * {@inheritDoc}
   */
  @Override
  public ReversalReasonDescription getReversalReasonDescription(
    ReversalReasonCode details) throws AppException, InformationalException {

    // Create return object
    final ReversalReasonDescription reversalReasonDescription = new ReversalReasonDescription();

    // Codetable manipulation variables
    final int kNumberOfTables = 2;
    final String[] codeTableList = new String[kNumberOfTables];
    // BEGIN, CR00049218, GM
    String reversalCodeDesc = CuramConst.gkEmpty;

    // END, CR00049218
    // Set codetable names in list
    codeTableList[0] = CANCELLATIONREQUEST.TABLENAME;
    codeTableList[1] = REVERSALREASON.TABLENAME;

    // Loop through the list of tables to find the code description
    for (int i = 0; i < kNumberOfTables; i++) {
      // BEGIN, CR00163098, JC
      reversalCodeDesc = curam.util.type.CodeTable.getOneItem(codeTableList[i],
        details.reversalCode, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      if (reversalCodeDesc != null && reversalCodeDesc.length() != 0) {

        // found correct code so set return object and exit for loop
        reversalReasonDescription.description = reversalCodeDesc;
        break;
      }

    }

    return reversalReasonDescription;
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by getReversalReasonDescription
   */
  @Override
  public ReversalReasonDescription getReveralReasonDescription(
    ReversalReasonCode details) throws AppException, InformationalException {

    return getReversalReasonDescription(details);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void generateLiability(GenerateLiabilityKey key)
    throws AppException, InformationalException {

    // GenerateLiability manipulation variables
    final curam.core.intf.GenerateLiability generateLiabilityObj = curam.core.fact.GenerateLiabilityFactory.newInstance();
    final CaseIdentifier caseIdentifier = new CaseIdentifier();

    // Assign key details to generate the liability
    caseIdentifier.caseID = key.caseID;

    // Call GenerateLiability BPO to generate the liability
    generateLiabilityObj.generateInteractiveLiability(caseIdentifier);
  }

  // BEGIN, CR00002146, KH
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelPaymentInstrument(CancelPaymentInstrumentDetails details)
    throws AppException, InformationalException {

    // CreateCancellation manipulation variables
    final curam.core.intf.CreateCancellation createCancellationObj = curam.core.fact.CreateCancellationFactory.newInstance();
    final PaymentInstrumentKey pmtInstrumentKey = new PaymentInstrumentKey();
    final CancelRegenerateSummary cancelRegenerateSummary = new CancelRegenerateSummary();

    // Assign key details to cancel the payment
    pmtInstrumentKey.pmtInstrumentID = details.pmtInstrumentID;

    // Assign details to cancel the payment
    cancelRegenerateSummary.assign(details);

    // Call CreateCancellation BPO to cancel the payment
    createCancellationObj.cancelPaymentInstrument(pmtInstrumentKey,
      cancelRegenerateSummary);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void regenerateCanceledPaymentInstrument(
    PaymentInstrumentKey pmtInstrumentKey) throws AppException,
      InformationalException {

    // CreateCancellation manipulation variables
    final curam.core.intf.CreateCancellation createCancellationObj = curam.core.fact.CreateCancellationFactory.newInstance();

    // Call CreateCancellation BPO to regenerate the canceled payment
    createCancellationObj.regeneratePaymentInstrument(pmtInstrumentKey);
  }

  // END, CR00002146

  // BEGIN, CR00172652, MC
  // BEGIN, CR00003380, SD
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public InformationMsgDtlsList cancelOrInvalidatePayment(
    CancelOrInvalidatePmtDetails details) throws AppException,
      InformationalException {

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Call BPO to cancel or invalidate the payment
    CreateCancellationFactory.newInstance().cancelOrInvalidatePayment(
      details.details);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00003380

  /**
   * {@inheritDoc}
   */
  @Override
  public InformationMsgDtlsList cancelRegenerateOrInvalidatePayment(
    CancelRegenerateOrInvalidatePmtDetails details) throws AppException,
      InformationalException {

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00314367, SG
    if (0 < details.caseNomineeConcernRoleIDOpt.length()) {
      final String[] ids = details.caseNomineeConcernRoleIDOpt.split(
        CuramConst.gkComma);

      details.caseNomineeID = Long.parseLong(ids[0]);
    }
    // END, CR00314367

    // A nominee and the regenerate check box cannot both be selected
    if (details.caseNomineeID != 0 && details.regenerateInd) {

      final LocalisableString infoMessage = new LocalisableString(
        curam.message.GENERALFINANCE.ERR_XFV_REGENERATEIND_AND_NOMINEE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();
    }

    // If a new nominee is selected regenerate to them
    if (details.caseNomineeID != 0) {
      details.regenerateInd = true;
    }

    // CreateCancellation manipulation variables
    // BEGIN, CR00265470, ZV
    CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();

    // Read the class name from property file.
    final String financialResolverName = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_CREATECANCELLATION_CLASS);

    final Object obj = FinancialUtil.getResolverClassName(financialResolverName,
      createCancellationObj.getCaseIDForFinInstructionId(
      details.finInstructionID));

    if (null != obj) {
      createCancellationObj = (curam.core.intf.CreateCancellation) obj;
    }
    // END, CR00265470

    // Call BPO to cancel, regenerate or invalidate the payment
    createCancellationObj.cancelRegenerateOrInvalidatePayment(details);
    // END, CR00265470

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public InformationMsgDtlsList invalidateCanceledPayment(
    CancelRegenerateOrInvalidatePmtDetails details) throws AppException,
      InformationalException {

    details.invalidateInd = true;

    return FinancialFactory.newInstance().cancelRegenerateOrInvalidatePayment(
      details);
  }

  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void regeneratePaymentForNominee(
    RegeneratePaymentForNomineeDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00198173, SS
    // BEGIN, CR00265470, ZV
    CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();

    // Read the class name from property file.
    final String financialResolverName = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_CREATECANCELLATION_CLASS);

    // BEGIN, CR00206354, SS
    final Object obj = FinancialUtil.getResolverClassName(financialResolverName,
      createCancellationObj.getCaseIDForFinInstructionId(
      details.finInstructionID));

    // END, CR00206354
    if (null != obj) {
      createCancellationObj = (curam.core.intf.CreateCancellation) obj;
    }
    // END, CR00265470
    // END, CR00198173

    // BEGIN, CR00333363, SG
    long concernRoleID = 0L;

    if (0 < details.caseNomineeConcernRoleIDOpt.length()) {
      final String[] ids = details.caseNomineeConcernRoleIDOpt.split(
        CuramConst.gkComma);

      details.caseNomineeID = Long.parseLong(ids[0]);
      concernRoleID = Long.parseLong(ids[1]);
    }
    // END, CR00333363

    // BEGIN, CR00244234, MC
    if (details.originalNomineeInd && details.caseNomineeID != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCREATECANCELLATION.ERR_PMTINSTRUMENT_RV_REGENERATE_OR_INVALIDATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00244234

    if (details.originalNomineeInd || details.caseNomineeID == 0) {
      final FinInstructionID finInstructionID = new FinInstructionID();

      finInstructionID.finInstructionID = details.finInstructionID;
      // Reissue to the original nominee.
      createCancellationObj.regeneratePayment(finInstructionID);

    } else {

      // BEGIN, CR00358036, GA
      final FinInstructionID finInstructionID = new FinInstructionID();

      finInstructionID.finInstructionID = details.finInstructionID;

      final PaymentInstructionDtls paymentInstructionDtls = PaymentInstructionFactory.newInstance().readByFinInstructionID(
        finInstructionID);

      final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      paymentInstrumentKey.pmtInstrumentID = paymentInstructionDtls.pmtInstrumentID;

      final PaymentInstrumentDtls paymentInstrumentDtls = PaymentInstrumentFactory.newInstance().read(
        paymentInstrumentKey);

      if (0 == paymentInstrumentDtls.caseNomineeID) {
        ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOCREATECANCELLATION.ERR_REGENERATING_THIRD_PARTY_PAYMENT_DIFFERENT_NOMINEE),
            ValidationManagerConst.kSetOne,
            0);
      }
      // END, CR00358036
      final RegeneratePaymentForNewNomineeDetails regeneratePaymentForNewNomineeDetails = new RegeneratePaymentForNewNomineeDetails();

      regeneratePaymentForNewNomineeDetails.caseNomineeID = details.caseNomineeID;
      regeneratePaymentForNewNomineeDetails.finInstructionID = details.finInstructionID;

      // BEGIN, CR00333363, SG
      regeneratePaymentForNewNomineeDetails.concernRoleIDOpt = concernRoleID;
      // END, CR00333363

      createCancellationObj.regeneratePaymentForNewNominee(
        regeneratePaymentForNewNomineeDetails);
    }

  }

  // END, CR00172652

  // BEGIN CR00074870 FOD
  /**
   * {@inheritDoc}
   *
   * @throws AppException
   */
  @Override
  public FinancialInstructionTypeDetails readFinancialInstructionType(
    FinancialInstructionKey key) throws AppException, InformationalException {

    // entity object
    final FinancialInstruction financialInstructionObj = FinancialInstructionFactory.newInstance();

    // perform read to get details
    final FinancialInstructionDtls financialInstructionDtls = financialInstructionObj.read(
      key);

    // assign value
    final FinancialInstructionTypeDetails financialInstructionTypeDetails = new FinancialInstructionTypeDetails();

    financialInstructionTypeDetails.financialInstructionType = financialInstructionDtls.typeCode;

    // return
    return financialInstructionTypeDetails;
  }

  // END CR00074870

  // BEGIN, CR00101372, CM
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FinancialILICaseIDList searchCaseIDByFinInstructID(
    ILIFinInstructID finInstructID) throws AppException,
      InformationalException {

    // Return struct
    final FinancialILICaseIDList financialILICaseIDList = new FinancialILICaseIDList();

    // InstructionLineItem object
    final curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    // searches for all the caseIDs
    financialILICaseIDList.dtlsList.addAll(
      instructionLineItemObj.searchCaseIDByFinInstructID(finInstructID).dtls);

    return financialILICaseIDList;
  }

  // END, CR00101372

  // BEGIN, CR00265470, ZV
  /**
   * Returns the appropriate caseID for the given finInstructionID.
   *
   * @param finInstructionID
   *
   * @return Associated caseID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link curam.core.impl.CreateCancellation#getCaseIDForFinInstructionId()}.
   */
  @Deprecated
  protected long getCaseIDForFinInstructionId(long finInstructionID)
    throws AppException, InformationalException {

    final ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID;

    final InstructionLineItemDtlsList originalILIDtlsList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
      iliFinInstructID);
    long finInstructionCaseID = 0;

    // Loop through the ILI list to find the first non zero case id
    for (int i = 0; i < originalILIDtlsList.dtls.size(); i++) {
      if (originalILIDtlsList.dtls.item(i).caseID != 0) {
        finInstructionCaseID = originalILIDtlsList.dtls.item(i).caseID;
        break;
      }
    }
    return finInstructionCaseID;
  }

  // END, CR00265470

  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public WizardProperties getCaptureManualPaymentWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCaptureManualPaymentWizardProperties;

    return wizardProperties;
  }

  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public WizardProperties getAppliedFixedDeductionWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kAppliedFixedDeductionWizardProperties;

    return wizardProperties;
  }

  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public WizardProperties getAppliedVariableDeductionWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kAppliedVariableDeductionWizardProperties;

    return wizardProperties;
  }

  // END, CR00212191
  // BEGIN, CR00279713, AC
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreditDebitTypeDtls readCreditDebitType(
    ReadInstructionLineItemKey readInstructionLineItemKey)
    throws AppException, InformationalException {

    // Create return object
    final CreditDebitTypeDtls creditDebitTypeDtls = new CreditDebitTypeDtls();
    final ReadInstructionLineItemDetails readInstructionLineItemDetails = readInstructionLineItemDetails(
      readInstructionLineItemKey);

    creditDebitTypeDtls.CreditDebitType = readInstructionLineItemDetails.creditDebitType;
    return creditDebitTypeDtls;
  }

  // END, CR00279713

  // BEGIN, CR00289420, PMD
  /**
   * {@inheritDoc}
   */
  @Override
  public PaymentsReceivedList listPaymentsReceived(
    final curam.core.facade.struct.CaseID key) throws AppException,
      InformationalException {

    final PaymentsReceivedList paymentsReceivedList = new PaymentsReceivedList();
    final ViewConcernAccount viewConcernAccountObj = ViewConcernAccountFactory.newInstance();
    final InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    ViewInstructionAllocationsResult viewInstructionAllocationsResult;

    final ILICaseIDCategory iliCaseIDCategory = new ILICaseIDCategory();

    iliCaseIDCategory.caseID = key.dtls.caseID;
    iliCaseIDCategory.instructLineItemCategory = ILICATEGORY.LIABILITYINSTRUCTION;

    // Get the Liability ILI
    final InstructionLineItemDtlsList iliDtlsList = instructionLineItemObj.searchByCaseIDAndCategory(
      iliCaseIDCategory);

    for (final InstructionLineItemDtls iliDtls : iliDtlsList.dtls) {

      final ConcernAccILIidentifier concernAccILIidentifier = new ConcernAccILIidentifier();

      concernAccILIidentifier.instructLineItemID = iliDtls.instructLineItemID;

      // Call ViewConcernAccount BPO to read the allocation details
      viewInstructionAllocationsResult = viewConcernAccountObj.viewInstructionAllocations(
        concernAccILIidentifier);

      LocalisableString receivedFrom = new LocalisableString(
        curam.message.GENERAL.INF_GENERAL_SEPARATOR);

      if (!viewInstructionAllocationsResult.concernAccAllocationList.dtls.isEmpty()) {

        // Reserve space in the output struct
        paymentsReceivedList.payRecDtls.ensureCapacity(
          viewInstructionAllocationsResult.concernAccAllocationList.dtls.size());

        for (final ConcernAccAllocationDetails concernAccAllocationDetails : viewInstructionAllocationsResult.concernAccAllocationList.dtls) {

          if (concernAccAllocationDetails.finInstructionCategory.equals(
            FINANCIALINSTRUCTION.PAYMENTRECEIVED)) {

            final ILIFinInstructIDCategoryTypeStatus payRecILIKey = new ILIFinInstructIDCategoryTypeStatus();

            final PaymentsReceivedListDetails paymentsReceivedListDetails = new PaymentsReceivedListDetails();

            paymentsReceivedListDetails.assign(concernAccAllocationDetails);

            paymentsReceivedListDetails.allocatedFromType = CodeTable.getOneItem(
              FINANCIALINSTRUCTION.TABLENAME,
              paymentsReceivedListDetails.finInstructionCategory,
              TransactionInfo.getProgramLocale());

            final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

            concernRoleKey.concernRoleID = concernAccAllocationDetails.concernRoleID;
            final ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = ConcernRoleFactory.newInstance().readConcernRoleNameAndAlternateID(
              concernRoleKey);

            if (paymentsReceivedListDetails.finInstructionCategory.equals(
              FINANCIALINSTRUCTION.PAYMENTRECEIVED)
                && paymentsReceivedListDetails.instructionLineItemType.equals(
                  ILITYPE.DEDUCTIONPAYMENT)) {

              // CaseType (CaseReference) - PrimaryClient (ClientReference)
              receivedFrom = new LocalisableString(
                curam.message.GENERAL.INF_GENERAL_CASE_DESCRIPTION_SEPARATOR);

              // Read the primary clients name and reference
              final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
              final CaseIDKey caseIDKey = new CaseIDKey();

              caseIDKey.caseID = concernAccAllocationDetails.caseID;

              final CaseReferenceConcernRoleNameCaseTypeAltID caseReferenceConcernRoleNameCaseTypeAltID = caseHeaderObj.readCaseReferenceCaseTypeConcernRoleNameAlternateID(
                caseIDKey);

              final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
              final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

              productDeliveryKey.caseID = concernAccAllocationDetails.caseID;
              final ProductNameStructRef productName = productDeliveryObj.readProductName(
                productDeliveryKey);

              receivedFrom.arg(
                new CodeTableItemIdentifier(PRODUCTNAME.TABLENAME,
                productName.name));
              receivedFrom.arg(
                caseReferenceConcernRoleNameCaseTypeAltID.caseReference);

              paymentsReceivedListDetails.allocatedFromType = GENERALFINANCE.INF_DEDUCTION.getMessageText();

              payRecILIKey.instructLineItemCategory = ILICATEGORY.PAYMENTINSTRUCTIONFORDEDUCTION;

            } else if (paymentsReceivedListDetails.finInstructionCategory.equals(
              FINANCIALINSTRUCTION.PAYMENTRECEIVED)
                && paymentsReceivedListDetails.instructionLineItemType.equals(
                  ILITYPE.ALLOCATEDPMTRECVD)) {

              // PrimaryClient (ClientReference)
              receivedFrom = new LocalisableString(
                curam.message.GENERAL.INF_GENERAL_PRIMARY_CLIENT_DESCRIPTION_BRACKETS);

              payRecILIKey.instructLineItemCategory = paymentsReceivedListDetails.finInstructionCategory;
            }

            // Set the indicator to determine if the 'Reverse' action should be
            // displayed
            if (concernAccAllocationDetails.finInstructionStatusOpt != null
              && !concernAccAllocationDetails.finInstructionStatusOpt.isEmpty()) {

              payRecILIKey.finInstructionID = paymentsReceivedListDetails.finInstructionID;
              payRecILIKey.instructionLineItemType = paymentsReceivedListDetails.instructionLineItemType;
              payRecILIKey.statusCode = concernAccAllocationDetails.finInstructionStatusOpt;

              final InstructionLineItemDtls payRecILIDtls = new InstructionLineItemDtls();
              InstructionLineItemDtlsList payRecILIDtlsList = new InstructionLineItemDtlsList();

              // BEGIN, CR00331183, CSH
              payRecILIDtlsList = instructionLineItemObj.searchByFinInstructIDCategoryTypeStatus(
                payRecILIKey);

              for (final InstructionLineItemDtls payRecILI : payRecILIDtlsList.dtls) {

                if (!payRecILIDtls.deliveryMethodType.equals(
                  METHODOFDELIVERY.CASH)) {
                  paymentsReceivedListDetails.reverseActionInd = true;
                }

                // BEGIN, CR00328565, CSH
                // Check if any of the payment received remains unallocated by
                // using the financial instruction to find a related instruction
                // line item with an unprocessed amount.
                final ILIFinInstructID pmtRecvILIFinInstructID = new ILIFinInstructID();

                // Instruction line items details list
                InstructionLineItemDtlsList relatedIliDtlsList;

                // Set the key to read instructionLineItem
                pmtRecvILIFinInstructID.finInstructionID = paymentsReceivedListDetails.finInstructionID;
                relatedIliDtlsList = instructionLineItemObj.searchByFinInstructID(
                  pmtRecvILIFinInstructID);
                for (int i = 0; i < relatedIliDtlsList.dtls.size(); i++) {

                  // We only want to populate the instructionLineItemID if there
                  // is an unprocessed amount that can be allocated or refunded.
                  // There should only be one such item.
                  if (relatedIliDtlsList.dtls.item(i).unprocessedAmount.isPositive()) {

                    // BEGIN, CR00336404, CSH
                    paymentsReceivedListDetails.unprocessedAmount = relatedIliDtlsList.dtls.item(i).unprocessedAmount;
                    paymentsReceivedListDetails.instructionLineItemID = relatedIliDtlsList.dtls.item(i).instructLineItemID;
                    paymentsReceivedListDetails.concernRoleID = relatedIliDtlsList.dtls.item(i).concernRoleID;
                    // END, CR00336404

                    // If there is an unprocessed amount then set indicators
                    // allowing the allocate or refund actions to be enabled.
                    paymentsReceivedListDetails.allocateActionInd = true;
                    paymentsReceivedListDetails.refundActionInd = true;
                    break;
                  }
                }
              }
              // END, CR00328565
            }
            // END, CR00331183

            // Set the received from field for the allocation items
            // <participant name> (<alternateID>)
            receivedFrom.arg(concernRoleNameAndAlternateID.concernRoleName);
            receivedFrom.arg(concernRoleNameAndAlternateID.primaryAlternateID);

            paymentsReceivedListDetails.receivedFrom = receivedFrom.toClientFormattedText();

            // Add details to list
            paymentsReceivedList.payRecDtls.addRef(paymentsReceivedListDetails);

          }
        }
      }
    }

    // Set the indicator used to display the unprocessed menu item
    final SearchUnprocessedByCaseIDKey searchUnprocessedKey = new SearchUnprocessedByCaseIDKey();

    searchUnprocessedKey.caseID = key.dtls.caseID;
    searchUnprocessedKey.statusCode = ILISTATUS.UNPROCESSED;

    if (InstructionLineItemFactory.newInstance().countUnprocessedByCaseID(searchUnprocessedKey).count
      > 0) {
      paymentsReceivedList.unprocessedILIsInd = true;
    } else {
      paymentsReceivedList.unprocessedILIsInd = false;
    }

    return paymentsReceivedList;
  }

  // END, CR00289420

  // BEGIN, CR00369134, KRK
  /**
   * {@inheritDoc}
   */
  @Override
  public WizardStateID createFixedDeductionWizard(
    final RegenerateDeductionDetails regenerateDeductionDetails)
    throws AppException, InformationalException {

    final WizardStateID wizardStateID = new WizardStateID();
    final WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();
    final ReadFinInstructionIDAndDeductionDetails readFinInstructionIDAndDeductionDetails = new ReadFinInstructionIDAndDeductionDetails();
    final MaintainDeductionItemsAssistant MaintainDeductionItemsAssistantObj = MaintainDeductionItemsAssistantFactory.newInstance();

    if (regenerateDeductionDetails.deductionDetails.relatedCaseID != 0) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = regenerateDeductionDetails.deductionDetails.relatedCaseID;

      final ReadParticipantRoleIDDetails readParticipantRoleIDDetails = CaseHeaderFactory.newInstance().readParticipantRoleID(
        caseHeaderKey);

      readFinInstructionIDAndDeductionDetails.relatedCaseID = regenerateDeductionDetails.deductionDetails.relatedCaseID;
      regenerateDeductionDetails.deductionDetails.liabilityConcernRoleID = readParticipantRoleIDDetails.concernRoleID;

    }
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    maintainDeductionItemDetails.assign(
      regenerateDeductionDetails.deductionDetails);

    maintainDeductionItemDetails.caseNomineeID = regenerateDeductionDetails.deductionDetails.nomineeID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = regenerateDeductionDetails.deductionDetails.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    readFinInstructionIDAndDeductionDetails.caseID = regenerateDeductionDetails.deductionDetails.caseID;
    readFinInstructionIDAndDeductionDetails.category = maintainDeductionItemDetails.category;
    readFinInstructionIDAndDeductionDetails.finInstructionID = regenerateDeductionDetails.finInstructionID;
    readFinInstructionIDAndDeductionDetails.deductionName = regenerateDeductionDetails.deductionDetails.deductionName;
    readFinInstructionIDAndDeductionDetails.deductionAmount = regenerateDeductionDetails.deductionDetails.amount;
    readFinInstructionIDAndDeductionDetails.nomineeID = regenerateDeductionDetails.deductionDetails.nomineeID;

    if (CuramConst.NEXT_ACTION.equalsIgnoreCase(
      regenerateDeductionDetails.actionString)) {

      wizardStateID.wizardStateID = regenerateDeductionDetails.wizardStateID;

      if (wizardStateID.wizardStateID == 0) {

        readFinInstructionIDAndDeductionDetails.wizardStateID = regenerateDeductionDetails.wizardStateID;
        MaintainDeductionItemsAssistantObj.validateFixedDeductionDetails(
          maintainDeductionItemDetails);
        MaintainDeductionItemsAssistantObj.validateDeductionAmount(
          readFinInstructionIDAndDeductionDetails);

        wizardStateID.wizardStateID = wizardPersistentStateObj.create(
          regenerateDeductionDetails);
      } else {
        readFinInstructionIDAndDeductionDetails.wizardStateID = regenerateDeductionDetails.wizardStateID;
        MaintainDeductionItemsAssistantObj.validateFixedDeductionDetails(
          maintainDeductionItemDetails);
        MaintainDeductionItemsAssistantObj.validateDeductionAmount(
          readFinInstructionIDAndDeductionDetails);
        wizardPersistentStateObj.modify(wizardStateID.wizardStateID,
          regenerateDeductionDetails);
      }
    }
    return wizardStateID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RegenerateDeductionDetails readUnappliedDeductionWizardDetails(
    final WizardStateID wizardStateID) throws AppException,
      InformationalException {

    final WizardPersistentState wizardPersistentState = new WizardPersistentState();
    RegenerateDeductionDetails regenerateDeductionDetails = new RegenerateDeductionDetails();

    if (wizardStateID.wizardStateID != 0) {
      regenerateDeductionDetails = (RegenerateDeductionDetails) wizardPersistentState.read(
        wizardStateID.wizardStateID);

    }
    regenerateDeductionDetails.wizardMenu = CuramConst.kReissueUnappliedDeductionWizardProperties;
    return regenerateDeductionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RegenerateDeductionDetails readAppliedDeductionWizardDetails(
    final WizardStateID wizardStateID) throws AppException,
      InformationalException {

    final WizardPersistentState wizardPersistentState = new WizardPersistentState();
    RegenerateDeductionDetails regenerateDeductionDetails = new RegenerateDeductionDetails();

    if (wizardStateID.wizardStateID != 0) {
      regenerateDeductionDetails = (RegenerateDeductionDetails) wizardPersistentState.read(
        wizardStateID.wizardStateID);
    }
    regenerateDeductionDetails.wizardMenu = CuramConst.kReissueAppliedDeductionWizardProperties;
    return regenerateDeductionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public InformationMsgDtlsList regeneratePaymentByDeduction(
    RegenerateDeductionDetails regenerateDeductionDetails)
    throws AppException, InformationalException {

    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    final FixedDeductionDetails1 fixedDeductionDetails = new FixedDeductionDetails1();
    final MaintainDeductionItems maintainDeductionItemsObj = MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();
    final MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();

    fixedDeductionDetails.deductionDtls = regenerateDeductionDetails.deductionDetails;
    fixedDeductionDetails.nomineeDtls = regenerateDeductionDetails.nomineeDtls;

    if (regenerateDeductionDetails.deductionDetails.relatedCaseID != 0) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = regenerateDeductionDetails.deductionDetails.relatedCaseID;

      final ReadParticipantRoleIDDetails readParticipantRoleIDDetails = CaseHeaderFactory.newInstance().readParticipantRoleID(
        caseHeaderKey);

      fixedDeductionDetails.deductionDtls.liabilityConcernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    maintainDeductionItemDetails.assign(fixedDeductionDetails.deductionDtls);

    maintainDeductionItemDetails.caseNomineeID = fixedDeductionDetails.deductionDtls.nomineeID;

    final FinInstructionID finInstructionID = new FinInstructionID();

    finInstructionID.finInstructionID = regenerateDeductionDetails.finInstructionID;

    final PaymentDateDetails paymentDateDetails = FinancialInstructionFactory.newInstance().readPaymentDateDetailsByInstructionID(
      finInstructionID);

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = fixedDeductionDetails.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;
    maintainDeductionItemDetails.startDate = paymentDateDetails.coverPeriodFrom;
    maintainDeductionItemDetails.endDate = paymentDateDetails.coverPeriodTo;
    maintainDeductionItemDetails.applyNextPriorityInd = true;

    maintainDeductionItemsObj.createProcessedDeductionItem(
      maintainDeductionItemDetails);

    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;
    // BEGIN, 176963, CC
    regenerateDeductionDetails.deductionDetails.caseDeductionItemIDOpt =
    		maintainDeductionItemDetails.caseDeductionItemID;
    // END,   176963, CC

    final VersionNo versionNo = CaseDeductionItemFactory.newInstance().readVersionNo(
      caseDeductionItemKey);

    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    caseDeductionItemIDVersionNo.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;
    caseDeductionItemIDVersionNo.versionNo = versionNo.versionNo;

    maintainDeductionItemsObj.activateDeductionWithoutRegeneration(
      caseDeductionItemIDVersionNo);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    final CaseDeductionItemID caseDeductionItemID = new CaseDeductionItemID();

    caseDeductionItemID.caseDeductionItemID = caseDeductionItemKey.caseDeductionItemID;

    final DeductionItemFinCompDetails deductionItemFinCompDetails = DeductionFCGenerationFactory.newInstance().getDeductionFCDetails(
      caseDeductionItemID);

    final CaseDeductionItemFCLink caseDeductionItemFCLinkObj = CaseDeductionItemFCLinkFactory.newInstance();
    final CaseDeductionItemFCLinkDtls caseDeductionItemFCLinkDtls = new CaseDeductionItemFCLinkDtls();

    final FinancialComponentKey financialComponentKey = new FinancialComponentKey();

    final FinComponentID deductionItemFinComponentID = MaintainFinancialComponentFactory.newInstance().addDeductionItemFinComp(
      deductionItemFinCompDetails);

    caseDeductionItemFCLinkDtls.caseDeductionItemFCLinkID = UniqueIDFactory.newInstance().getNextID();
    caseDeductionItemFCLinkDtls.financialComponentID = deductionItemFinComponentID.finComponentID;
    caseDeductionItemFCLinkDtls.caseDeductionItemID = deductionItemFinCompDetails.caseDeductionItemID;

    caseDeductionItemFCLinkObj.insert(caseDeductionItemFCLinkDtls);

    financialComponentKey.financialCompID = deductionItemFinComponentID.finComponentID;

    final FinCompIdentifier finCompIdentifier = new FinCompIdentifier();

    finCompIdentifier.processingDate = Date.getCurrentDate();
    finCompIdentifier.caseID = regenerateDeductionDetails.deductionDetails.caseID;

    final DateStruct processFCinputDate = new DateStruct();

    processFCinputDate.date = curam.util.type.Date.getCurrentDate();

    final DateStruct processFCcalculatedDate = new DateStruct();

    final FinancialProcessingDetails financialProcessingDetails = new FinancialProcessingDetails();

    financialProcessingDetails.deliveryMethodType = deductionItemFinCompDetails.nomineeDelivMethod;
    financialProcessingDetails.processingDate = curam.util.type.Date.getCurrentDate();

    processFCcalculatedDate.date = curam.core.fact.MaintainFinancialCalendarFactory.newInstance().getNextValidDate(financialProcessingDetails).nextValidDate;

    final FinancialComponentDtls financialComponentDtls = FinancialComponentFactory.newInstance().read(
      financialComponentKey);

    final TotalDeductionAmount totalDeductionAmount = new TotalDeductionAmount();

    totalDeductionAmount.amount = regenerateDeductionDetails.deductionDetails.amount;
    totalDeductionAmount.deductibleAmountList.caseNomineeID = regenerateDeductionDetails.deductionDetails.nomineeID;

    final CurrencyExchangeDtls currencyExchangeDtls = MaintainFinancialComponentFactory.newInstance().getCurrencyExchangeDetails(
      financialComponentDtls);

    final FinCompCoverPeriod finCompCoverPeriod = new FinCompCoverPeriod();

    finCompCoverPeriod.coverPeriodFrom = paymentDateDetails.coverPeriodFrom;
    finCompCoverPeriod.coverPeriodTo = paymentDateDetails.coverPeriodTo;

    final FCAmount fcAmount = new FCAmount();

    fcAmount.amount = regenerateDeductionDetails.deductionDetails.amount;

    MaintainInstructionLineItemFactory.newInstance().addDeductionItemILIsForRegeneratePayment(
      financialComponentDtls, finCompCoverPeriod, fcAmount,
      currencyExchangeDtls, totalDeductionAmount);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = regenerateDeductionDetails.deductionDetails.caseID;

    final ILICaseIDCategoryStatusCoverPeriod iliCaseIDCategoryStatusCoverPeriod = new ILICaseIDCategoryStatusCoverPeriod();

    // Set search criteria for deduction payment instructions
    iliCaseIDCategoryStatusCoverPeriod.instructLineItemCategory = ILICATEGORY.PAYMENTINSTRUCTIONFORDEDUCTION;
    iliCaseIDCategoryStatusCoverPeriod.caseID = regenerateDeductionDetails.deductionDetails.relatedCaseID;
    iliCaseIDCategoryStatusCoverPeriod.statusCode = ILISTATUS.UNPROCESSED;

    // Read deductions for the related liability case.
    final InstructionLineItemDtlsList instructionLineItemDtlsList = InstructionLineItemFactory.newInstance().searchByCaseIDCategoryStatusCoverPeriod(
      iliCaseIDCategoryStatusCoverPeriod);

    final FinancialComponentKey liabilityFinancialComponentKey = new FinancialComponentKey();
    FinancialComponentDtls liabiltyFinancialComponenDetails = new FinancialComponentDtls();

    if (0 != regenerateDeductionDetails.deductionDetails.relatedCaseID) {
      for (final InstructionLineItemDtls instructionLineItemDtls : instructionLineItemDtlsList.dtls.items()) {

        liabilityFinancialComponentKey.financialCompID = instructionLineItemDtls.financialCompID;
        InstructionLineItemProcessingFactory.newInstance().processDeductionLineGroup(
          instructionLineItemDtls);
      }

    }
    CreateCancellationFactory.newInstance().regeneratePayment(finInstructionID);

    maintainFinancialComponentObj.expireFinancialComp(financialComponentDtls);

    if (0 != regenerateDeductionDetails.deductionDetails.relatedCaseID) {

      liabiltyFinancialComponenDetails = FinancialComponentFactory.newInstance().read(
        liabilityFinancialComponentKey);
      maintainFinancialComponentObj.expireFinancialComp(
        liabiltyFinancialComponenDetails);
    }

    return informationMsgDtlsList;
  }

  // END, CR00369134

  // BEGIN, CR00372022, DJ
  /**
   * Updates the specified payment instrument with the reconciliation status
   * code supplied.
   *
   * @param pmtInstrumentAndReconcilStatus Contains the paymentInstrumentID and
   * the new reconciliation status code.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public void modifyPaymentInstrumentReconciliationStatus(
    final PmtInstrumentAndReconcilStatus pmtInstrumentAndReconcilStatus)
    throws AppException, InformationalException {

    final PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();
    final PIReconcilStatusCode piReconcilStatusCode = new PIReconcilStatusCode();

    piReconcilStatusCode.reconcilStatusCode = PMTRECONCILIATIONSTATUSEntry.get(pmtInstrumentAndReconcilStatus.reconciliationStatusCode).toString();
    paymentInstrumentKey.pmtInstrumentID = pmtInstrumentAndReconcilStatus.pmtInstrumentID;
    PaymentReconciliationFactory.newInstance().modifyReconciliationStatus(
      paymentInstrumentKey, piReconcilStatusCode);
  }

  // END, CR00372022

  // BEGIN, CR00401013, RD
  /**
   * Reads the Payment Instrument Details using the payment instrument key
   * information.
   *
   * @param key
   * PaymentInstrument Key information.
   *
   * @return Payment Instrument Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public PaymentInstrumentDtls readPaymentInstrumentDetails(
    PaymentInstrumentKey key) throws AppException, InformationalException {

    final PaymentInstrumentDtls paymentInstrumentDtls = PaymentInstrumentFactory.newInstance().read(
      key);

    return paymentInstrumentDtls;
  }

  /**
   * Reads Payment Instruction by payment instrument ID information.
   *
   * @param key
   * Payment Instrument key information.
   *
   * @return Payment Instruction Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public PaymentInstructionDtls readPaymentInstructionByPmtInstrumentID(
    PaymentInstrumentKey key) throws AppException, InformationalException {

    final PaymentInstruction paymentInstruction = PaymentInstructionFactory.newInstance();
    final PmtInstrumentID pmtInstrumentID = new PmtInstrumentID();

    pmtInstrumentID.pmtInstrumentID = key.pmtInstrumentID;
    final FinInstructionID finInstructionID = paymentInstruction.readByPmtInstrumentID(
      pmtInstrumentID);
    final PaymentInstructionDtls paymentInstructionDtls = paymentInstruction.readByFinInstructionID(
      finInstructionID);

    return paymentInstructionDtls;
  }

  /**
   * Retrieves Financial Instruction details using the financial instruction
   * key.
   *
   * @param financialInstructionKey
   * Financial Instruction Key
   *
   * @return Financial Instruction Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public FinancialInstructionDtls readFinancialInstructionByFinID(
    FinancialInstructionKey financialInstructionKey) throws AppException,
      InformationalException {

    return FinancialInstructionFactory.newInstance().read(
      financialInstructionKey);
  }

  /**
   * Retrieves Financial Instruction details using financial instruction key
   * and status code key.
   *
   * @param financialInstructionStatusCode
   * Financial Instruction Status Code.
   *
   * @return Financial Instruction Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public FinancialInstructionDtls readFinancialInstructionByFinIDStatusCode(
    FinancialInstructionStatusCode financialInstructionStatusCode)
    throws AppException, InformationalException {

    return FinancialInstructionFactory.newInstance().readByFinIDStatusCode(
      financialInstructionStatusCode);
  }

  // END, CR00401013

  // BEGIN, CR00405595, RD
  /**
   * Modifies Financial Instruction status details only.
   *
   * @param status
   * Contains Financial Status and version number details.
   * @param finInstKey
   * Contains Financial Instruction Key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyFinancialInstructionStatus(FIstatusCode status,
    FinancialInstructionKey finInstKey) throws AppException,
      InformationalException {

    final FinancialInstruction financialInstruction = FinancialInstructionFactory.newInstance();
    final FinancialInstructionDtls financialInstructionDtls = financialInstruction.read(
      finInstKey);

    financialInstructionDtls.statusCode = status.statusCode;
    financialInstructionDtls.versionNo = status.versionNo;
    financialInstruction.modifyStatus(finInstKey, status);
    final FinancialInstructionStatusDtls finInstructionStatusDtls = new FinancialInstructionStatusDtls();
    final FinancialInstructionStatus financialInstructionStatusObj = curam.core.fact.FinancialInstructionStatusFactory.newInstance();

    finInstructionStatusDtls.finInstructionStatusID = UniqueIDFactory.newInstance().getNextID();
    finInstructionStatusDtls.finInstructionID = finInstKey.finInstructionID;
    finInstructionStatusDtls.statusDate = curam.util.transaction.TransactionInfo.getSystemDate();
    finInstructionStatusDtls.statusCode = status.statusCode;
    finInstructionStatusDtls.versionNo = status.versionNo;
    financialInstructionStatusObj.insert(finInstructionStatusDtls);
  }
  // END, CR00405595

}
