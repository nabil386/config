/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2017. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.bihelper.sl.impl.BIHelper;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.CaseAuditKey;
import curam.caseaudit.entity.struct.FocusAreaStatsList;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditCaseConfigDAO;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.AuditPlanFocusArea;
import curam.caseaudit.impl.AuditPlanFocusAreaDAO;
import curam.caseaudit.impl.Auditor;
import curam.caseaudit.impl.AuditorDAO;
import curam.caseaudit.impl.CaseAuditConst;
import curam.caseaudit.impl.CaseAuditDAO;
import curam.caseaudit.impl.FocusAreaFinding;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.HtmlHeaderBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.WidgetDocumentBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.CodeTableItemEntry;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.cefwidgets.utilities.impl.RendererConfig;
import curam.cefwidgets.utilities.impl.RendererConfig.RendererConfigType;
import curam.codetable.AUDITCASEFOCUSAREA;
import curam.codetable.CASEAUDITSTATUS;
import curam.codetable.CASECATTYPECODE;
import curam.codetable.CASESTATUS;
import curam.codetable.CONCERNROLESEARCHALTERNATEID;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.intf.Organization;
import curam.core.facade.struct.AssignCaseAuditResult;
import curam.core.facade.struct.AuditContextDetails;
import curam.core.facade.struct.AuditPlanAndAuditorKey;
import curam.core.facade.struct.AuditPlanFocusAreaKey;
import curam.core.facade.struct.AuditPlanMemberDetails;
import curam.core.facade.struct.AuditPlanMemberDetailsList;
import curam.core.facade.struct.AuditsOnPlanByAuditorDetails;
import curam.core.facade.struct.CaseAuditAndVersionKey;
import curam.core.facade.struct.CaseAuditAssignDetails;
import curam.core.facade.struct.CaseAuditAssignList;
import curam.core.facade.struct.CaseAuditDetails;
import curam.core.facade.struct.CaseAuditHomePageName;
import curam.core.facade.struct.CaseAuditIDTabbedList;
import curam.core.facade.struct.CaseAuditListDetails;
import curam.core.facade.struct.CaseAuditListDetailsList;
import curam.core.facade.struct.CaseAuditListFilterKey;
import curam.core.facade.struct.CaseAuditModifyDetails;
import curam.core.facade.struct.CaseAuditStatusDetails;
import curam.core.facade.struct.CaseAuditStatusDetailsList;
import curam.core.facade.struct.CaseAuditStatusFilter;
import curam.core.facade.struct.CaseAuditTabDetails;
import curam.core.facade.struct.CaseAuditTabXML;
import curam.core.facade.struct.CaseSearchDefaultData;
import curam.core.facade.struct.CaseSearchDetailsList;
import curam.core.facade.struct.CaseSearchList1;
import curam.core.facade.struct.CaseSelectSearchCriteria;
import curam.core.facade.struct.CodeTableName;
import curam.core.facade.struct.CodetableCodeAndDescription;
import curam.core.facade.struct.CodetableCodeAndDescriptionList;
import curam.core.facade.struct.FocusAreaFindingListDetails;
import curam.core.facade.struct.MaintainCodeTableItem;
import curam.core.facade.struct.MyCaseAuditSearchCriteria;
import curam.core.facade.struct.ReadCaseAuditDetails;
import curam.core.facade.struct.ReadCodeTableItemKey;
import curam.core.facade.struct.RemoveAuditorDetails;
import curam.core.facade.struct.SearchAllCaseAuditsDetailsList;
import curam.core.facade.struct.SearchAllCaseAuditsKey;
import curam.core.facade.struct.SearchAllCaseAuditsResult;
import curam.core.facade.struct.SearchAllCaseAuditsResultsList;
import curam.core.facade.struct.SearchUserDetails;
import curam.core.facade.struct.UserSearchDetails;
import curam.core.facade.struct.UserSearchKey;
import curam.core.facade.struct.WarningsDtls;
import curam.core.facade.struct.WarningsDtlsList;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.UserFullname;
import curam.core.struct.UserSearchDetailsRef;
import curam.core.struct.UserSearchDetailsReference;
import curam.core.struct.UsersKey;
import curam.message.BPOAUDITPLANTAB;
import curam.message.BPOCASEAUDITTAB;
import curam.message.BPOCASETAB;
import curam.message.ENTCASEAUDIT;
import curam.message.FACADECASEAUDIT;
import curam.message.impl.FACADECASEAUDITExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;


/**
 * Facade Class for the CEF CaseAudit implementation.
 *
 */
public abstract class CaseAudit extends curam.core.facade.base.CaseAudit {

  // BEGIN, CR00223475, ELG
  /**
   * BI report retrieval class *
   */
  @Inject
  protected BIHelper biHelper;

  // END, CR00223475

  /**
   * The Dynamic Menu node.
   */
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  /**
   * The Link (child) node.
   */
  protected static final String kItem = XmlMetaDataConst.kItem;

  /**
   * The page id attribute for a node.
   */
  protected static final String kPageID = XmlMetaDataConst.kPageID;

  /**
   * The audit plan homepage URL.
   */
  protected static final String kAuditPlanHome = UimConst.kAuditPlanHome;

  /**
   * The description attribute for a node.
   */
  protected static final String kDesc = XmlMetaDataConst.kDesc;

  /**
   * The type attribute for a node.
   */
  protected static final String kType = XmlMetaDataConst.kType;

  /**
   * The parameter attribute for a node.
   */
  protected static final String kParam = XmlMetaDataConst.kParam;

  /**
   * The name tag for a parameter.
   */
  protected static final String kName = XmlMetaDataConst.kName;

  /**
   * The value tag for a parameter.
   */
  protected static final String kValue = XmlMetaDataConst.kValue;

  /**
   * The audit plan node type.
   */
  protected static final String kTypeAuditPlan = XmlMetaDataConst.kTypeAuditPlan;

  /**
   * The case audit node type.
   */
  protected static final String kTypeCaseAudit = XmlMetaDataConst.kTypeCaseAudit;

  /**
   * The case audit ID parameter.
   */
  protected static final String kParamCaseAuditID = XmlMetaDataConst.kParamCaseAuditID;

  protected static final LocalisableString kCaseAudit = new LocalisableString(
    FACADECASEAUDIT.PAGE_DESC_CASE_AUDIT);

  /**
   * The audit plan ID parameter.
   */
  protected static final String kParamAuditPlanID = XmlMetaDataConst.kParamAuditPlanID;

  protected static final LocalisableString kAuditPlan = new LocalisableString(
    FACADECASEAUDIT.PAGE_DESC_AUDIT_PLAN);

  /**
   * The auditor case audit homepage URL.
   */
  protected static final String kAuditorCaseAuditHome = UimConst.kAuditorCaseAuditHomePage;

  /**
   * The coordinator case audit homepage URL.
   */
  protected static final String kCoordinatorCaseAuditHome = UimConst.kCoordinatorCaseAuditHomePage;

  @Inject
  protected AuditCaseConfigDAO auditCaseConfigDAO;

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected AuditPlanFocusAreaDAO auditPlanFocusAreaDAO;

  @Inject
  protected AuditorDAO auditorDAO;

  // BEGIN, CR00385977, KRK
  // Check the security roles are restricted for assignments.
  final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
    EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES,
    Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));

  // END, CR00385977

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public CaseAudit() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * UserSearchDetailsRef Comparator.
   */
  protected class UserSearchDetailsRefComparator implements
    Comparator<UserSearchDetailsRef> {

    public UserSearchDetailsRefComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on the user's surname and first name.
     */
    @Override
    public int compare(final UserSearchDetailsRef o1,
      final UserSearchDetailsRef o2) {

      final int surNameComparison = o1.surname.compareTo(o2.surname);
      final int firstNameComparison = o1.firstname.compareTo(o2.firstname);

      if (surNameComparison == 0) {
        return firstNameComparison;
      }
      return surNameComparison;
    }
  }


  // BEGIN, CR00298781, ZV
  // ___________________________________________________________________________
  /**
   * UserSearchDetailsRef Comparator.
   */
  protected class UserSearchDetailsReferenceComparator implements
    Comparator<UserSearchDetailsReference> {

    public UserSearchDetailsReferenceComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on the user's surname and first name.
     */
    @Override
    public int compare(final UserSearchDetailsReference o1,
      final UserSearchDetailsReference o2) {

      final int surNameComparison = o1.surname.compareTo(o2.surname);
      final int firstNameComparison = o1.firstname.compareTo(o2.firstname);

      if (surNameComparison == 0) {
        return firstNameComparison;
      }
      return surNameComparison;
    }
  }

  // END, CR00298781

  // ___________________________________________________________________________
  /**
   * Method to generate the context description for a case audit.
   *
   * @param key Contains the case audit identifier.
   *
   * @return Context description for the case audit.
   */
  @Override
  public AuditContextDetails getCaseAuditContextDescription(
    final CaseAuditKey key) {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    final LocalisableString description = new LocalisableString(
      FACADECASEAUDIT.INF_CASE_AUDIT_DYNAMIC_MENU_DESCRIPTION);

    description.arg(kCaseAudit.getMessage());
    description.arg(caseAuditObj.getCaseAuditReference());

    final AuditContextDetails auditContextDetails = new AuditContextDetails();

    auditContextDetails.description = description.getMessage(
      TransactionInfo.getProgramLocale());
    return auditContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to generate the context description for a case audit.
   *
   * @param caseAudit Contains the case audit identifier.
   *
   * @return Context description for the case audit.
   */
  public String getCaseAuditContextDescription(
    final curam.caseaudit.impl.CaseAudit caseAudit) {

    final LocalisableString description = new LocalisableString(
      FACADECASEAUDIT.INF_CASE_AUDIT_DYNAMIC_MENU_DESCRIPTION);

    description.arg(kCaseAudit.getMessage());
    description.arg(caseAudit.getCaseAuditReference());

    return description.toClientFormattedText();
  }

  // ___________________________________________________________________________
  /**
   * Method to compute the focus area numbers for a list of case audits,
   * displaying how many focus areas have been
   * a) Satisfied
   * b) Not Satisfied
   * c) have not yet been examined
   *
   * @param details List of Case Audits for an Audit Plan
   */

  public void listCaseAuditFocusAreaStats(
    final CaseAuditListDetailsList details) throws AppException,
      InformationalException {

    int stCounterFocusSatisified;
    int stCounterFocusNotSatisified;
    int stCounterFocusNotSpecified;

    for (final CaseAuditListDetails caseAuditListDetails : details.dtls) {

      final curam.caseaudit.impl.CaseAudit caseAudit = caseAuditDAO.get(
        caseAuditListDetails.caseAuditID);

      stCounterFocusSatisified = 0;
      stCounterFocusNotSatisified = 0;
      stCounterFocusNotSpecified = 0;

      final List<FocusAreaFinding> focusAreaFindingList = caseAudit.getFocusAreaFindings();

      for (final FocusAreaFinding finding : focusAreaFindingList) {

        if (finding.getFocusAreaSatisfied().equals(FOCUSAREASATISFIEDEntry.YES)) {
          stCounterFocusSatisified++;
        } else if (finding.getFocusAreaSatisfied().equals(
          FOCUSAREASATISFIEDEntry.NO)) {
          stCounterFocusNotSatisified++;
        } else if (finding.getFocusAreaSatisfied().equals(
          FOCUSAREASATISFIEDEntry.NOT_SPECIFIED)) {
          stCounterFocusNotSpecified++;
        }

        caseAuditListDetails.numSatisfied = stCounterFocusSatisified;
        caseAuditListDetails.numNotSatisfied = stCounterFocusNotSatisified;
        caseAuditListDetails.numNotExamined = stCounterFocusNotSpecified;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to read a Case Audit for display.
   *
   * @param key The ID of the Case Audit
   *
   * @return Details of the Case Audit for display
   */
  @Override
  public ReadCaseAuditDetails readCaseAudit(final CaseAuditKey key)
    throws AppException, InformationalException {

    // return struct
    final ReadCaseAuditDetails readCaseAuditDetails = new ReadCaseAuditDetails();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    final curam.caseaudit.impl.CaseAudit caseAudit = caseAuditDAO.get(
      key.caseAuditID);
    final AuditPlan auditPlan = caseAudit.getAuditPlan();

    readCaseAuditDetails.caseAuditID = key.caseAuditID;
    readCaseAuditDetails.caseAuditReference = caseAudit.getCaseAuditReference();

    readCaseAuditDetails.auditPlanID = auditPlan.getID();
    readCaseAuditDetails.auditPlanReference = auditPlan.getAuditPlanReference();

    final CaseHeader caseHeader = caseAudit.getCase();

    readCaseAuditDetails.caseID = caseHeader.getID();
    readCaseAuditDetails.caseReference = caseHeader.getCaseReference();

    readCaseAuditDetails.caseAuditStatus = caseAudit.getLifecycleState().getCode();

    if (readCaseAuditDetails.caseAuditStatus.equals(
      CASEAUDITSTATUS.FEEDBACKCOMPLETE)
        || readCaseAuditDetails.caseAuditStatus.equals(
          CASEAUDITSTATUS.FEEDBACKRECEIVED)) {
      readCaseAuditDetails.showCompleteAuditInd = true;
    }

    if (caseAudit.getAuditor().getID() != 0) {

      readCaseAuditDetails.auditorFullname = caseAudit.getAuditor().getName();
    }

    UserFullname userFullname;

    usersKey.userName = auditPlan.getCoordinator();
    userFullname = userAccessObj.getFullName(usersKey);

    readCaseAuditDetails.coordinatorUsername = auditPlan.getCoordinator();
    readCaseAuditDetails.coordinatorFullname = userFullname.fullname;

    readCaseAuditDetails.purpose = auditPlan.getPurpose().getCode();

    readCaseAuditDetails.comments = caseAudit.getComments();
    readCaseAuditDetails.versionNo = caseAudit.getVersionNo();

    readCaseAuditDetails.auditorID = caseAudit.getAuditor().getID();

    // BEGIN, CR00189977, AF
    // CA Findings recorded and Case Audit not complete
    if (caseAudit.areFindingsEntered()
      && !readCaseAuditDetails.caseAuditStatus.equals(CASEAUDITSTATUS.COMPLETE)) {
      readCaseAuditDetails.showViewFindingsLinkInd = true;
      readCaseAuditDetails.showModifyFindingsLinkInd = true;
    } // CA Findings recorded and Case Audit complete
    else if (caseAudit.areFindingsEntered()
      && readCaseAuditDetails.caseAuditStatus.equals(CASEAUDITSTATUS.COMPLETE)) {
      readCaseAuditDetails.showViewFindingsLinkInd = true;
    } else {
      // CA Findings not yet recorded
      readCaseAuditDetails.showAddFindingsLinkInd = true;
    }
    // END, CR00189977, AF

    final AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    readCaseAuditDetails.categoryName = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME, auditCaseConfig.getCaseCategory().getCode());

    final List<FocusAreaFinding> focusAreaFindingList = caseAudit.getFocusAreaFindings();

    boolean allFocusFindingsDone = true;

    for (final FocusAreaFinding focusAreaFinding : focusAreaFindingList) {

      final FocusAreaFindingListDetails focusAreaFindingListDetails = new FocusAreaFindingListDetails();

      focusAreaFindingListDetails.focusAreaFindingID = focusAreaFinding.getID();
      focusAreaFindingListDetails.caseAuditID = focusAreaFinding.getCaseAudit().getID();

      final AuditPlanFocusArea auditPlanFocusArea = focusAreaFinding.getAuditPlanFocusArea();

      focusAreaFindingListDetails.auditPlanFocusAreaID = auditPlanFocusArea.getID();

      focusAreaFindingListDetails.focusAreaText = CodeTable.getOneItemForUserLocale(
        AUDITCASEFOCUSAREA.TABLENAME,
        auditPlanFocusArea.getFocusArea().getCode());

      focusAreaFindingListDetails.focusAreaSatisfied = focusAreaFinding.getFocusAreaSatisfied().getCode();

      if (focusAreaFinding.getFocusAreaSatisfied().equals(
        FOCUSAREASATISFIEDEntry.NOT_SPECIFIED)
          && StringUtil.isNullOrEmpty(focusAreaFinding.getFindingsText())) {
        focusAreaFindingListDetails.showAddFAFindingInd = true;
      }

      if (focusAreaFinding.getFocusAreaSatisfied().equals(
        FOCUSAREASATISFIEDEntry.NOT_SPECIFIED)) {
        allFocusFindingsDone = false;
      }

      readCaseAuditDetails.focusAreaFindings.dtls.addRef(
        focusAreaFindingListDetails);
    }

    if (readCaseAuditDetails.caseAuditStatus.equals(
      CASEAUDITSTATUSEntry.ASSIGNED.getCode())
        && caseAudit.areFindingsEntered()
        && allFocusFindingsDone) {
      readCaseAuditDetails.showCompleteFindingsInd = true;
    }

    return readCaseAuditDetails;
  }

  // BEGIN, CR00201195, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Method to return specific cases for audit based on case reference,
   * client reference or client name.
   *
   * @param details The search criteria
   *
   * @return A list of one or more cases depending on criteria submitted
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link CaseAudit#selectSpecificCaseForAuditDetails(CaseSelectSearchCriteria)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * selectSpecificCaseForAuditDetails(CaseSelectSearchCriteria)
   * which returns the informational message along with case audit details as
   * well.
   * See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 selectSpecificCaseForAudit(
    final CaseSelectSearchCriteria details) throws AppException,
      InformationalException {

    // END, CR00290965
    final CaseSearchList1 caseSearchList = new CaseSearchList1();

    // Validate that some criteria has been selected
    validateCaseSelectCriteria(details);

    List<curam.piwrapper.caseheader.impl.CaseHeader> caseHeaderList = new ArrayList<curam.piwrapper.caseheader.impl.CaseHeader>();

    // Get the type of cases to be audited
    final AuditPlan auditPlanObj = auditPlanDAO.get(details.auditPlanID);
    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      auditPlanObj.getAuditCaseConfig().getID());

    // Retrieve the list of cases that match the criteria supplied
    caseHeaderList = caseHeaderDAO.searchSpecificCase(details.caseReference,
      details.concernRoleID, details.alternateIDType,
      details.primaryAlternateID,
      CASETYPECODEEntry.get(auditCaseConfigObj.getCaseType().getCode()),
      CASECATTYPECODEEntry.get(auditCaseConfigObj.getCaseCategory().getCode()));

    for (final curam.piwrapper.caseheader.impl.CaseHeader caseHeader : caseHeaderList) {

      final curam.core.struct.CaseSearchDetails1 resultDetails = new curam.core.struct.CaseSearchDetails1();

      // Check if the case has already been selected for audit
      final List<curam.caseaudit.impl.CaseAudit> results = caseAuditDAO.searchByAuditPlanAndCase(
        auditPlanObj, caseHeader);

      if (results.size() < 1) {

        resultDetails.caseID = caseHeader.getID();
        resultDetails.caseReference = caseHeader.getCaseReference();
        resultDetails.concernRoleID = caseHeader.getConcernRole().getID();
        resultDetails.startDate = caseHeader.getStartDate();
        resultDetails.statusCode = caseHeader.getStatus().getCode();

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

        concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
        resultDetails.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

        caseSearchList.listDtls.searchDtls.addRef(resultDetails);

      }
    }
    return caseSearchList;
  }

  // END, CR00201195

  // ___________________________________________________________________________
  /**
   * Returns initial details to populate case select search criteria.
   *
   * @return Initial details to populate case select search criteria.
   */
  @Override
  public CaseSearchDefaultData getCaseSelectDefaultData()
    throws AppException, InformationalException {

    final CaseSearchDefaultData caseSearchDefaultData = new CaseSearchDefaultData();

    // get client reference label description
    caseSearchDefaultData.clientRefLabel = CodeTable.getOneItem(
      CONCERNROLESEARCHALTERNATEID.TABLENAME,
      CONCERNROLESEARCHALTERNATEID.DEFAULTCODE)
        + CuramConst.gkColon;

    return caseSearchDefaultData;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate that some case search criteria have been entered.
   *
   * @param details the case search criteria
   */
  @Override
  protected void validateCaseSelectCriteria(
    final CaseSelectSearchCriteria details) throws AppException,
      InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (StringHelper.isEmpty(details.caseReference)
      && details.concernRoleID == 0
      && StringHelper.isEmpty(details.primaryAlternateID)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(FACADECASEAUDIT.ERR_NO_CASE_SELECT_CRITERIA_ENTERED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to create a Case Audit.
   *
   * @param details Details of the Case Audit to create
   *
   * @return unique id of the created case audit
   */
  @Override
  public CaseAuditKey createCaseAudit(final CaseAuditDetails details)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.newInstance();
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeaderObj = caseHeaderDAO.get(
      details.dtls.caseID);
    final AuditPlan auditPlanObj = auditPlanDAO.get(details.dtls.auditPlanID);

    caseAuditObj.setCase(caseHeaderObj);
    caseAuditObj.setAuditPlan(auditPlanObj);

    caseAuditObj.insert();

    // Return the newly created id
    final CaseAuditKey caseAuditKey = new CaseAuditKey();

    caseAuditKey.caseAuditID = caseAuditObj.getID();
    return caseAuditKey;
  }

  // BEGIN, CR00201195, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Method to direct processing to either search for specific cases
   * for audit or to create Case Audit records for cases selected.
   *
   * @param details Case search or selected case details
   *
   * @return the list of Cases returned by the search
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link CaseAudit#selectOrCreateCaseAuditDetails(CaseSelectSearchCriteria)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by
   * selectOrCreateCaseAuditDetails(CaseSelectSearchCriteria)
   * which returns the informational message along with case audit details
   * as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseSearchList1 selectOrCreateCaseAudit(
    final CaseSelectSearchCriteria details) throws AppException,
      InformationalException {

    // END, CR00290965
    CaseSearchList1 caseSearchList = new CaseSearchList1();

    if (details.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {

      final AuditPlan auditPlanObj = auditPlanDAO.get(details.auditPlanID);

      // In the case of regeneration, remove selection criteria
      auditPlanObj.clearSelectionCriteria();

      final CaseAuditDetails caseAuditDetails = new CaseAuditDetails();

      caseAuditDetails.dtls.auditPlanID = details.auditPlanID;

      String tabList = new String();

      tabList = details.caseIDList;

      // String list of Case IDs
      final StringList caseIDList = StringUtil.tabText2StringList(tabList);

      for (int i = 0; i < caseIDList.size(); i++) {

        caseAuditDetails.dtls.caseID = Long.parseLong(caseIDList.item(i));
        createCaseAudit(caseAuditDetails);
      }

      auditPlanObj.setCasesUserSelected(true);
      auditPlanObj.setNumberCases(CuramConst.gkZero);
      auditPlanObj.setPercentageCases(CuramConst.gkDoubleZero);
      auditPlanObj.modify(auditPlanObj.getVersionNo());

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kSearchActionID)) {

      caseSearchList = selectSpecificCaseForAudit(details);

    } else if (details.actionIDProperty.equals(ClientActionConst.kFinish)) {

      final AuditPlanKey auditPlanKey = new AuditPlanKey();

      auditPlanKey.auditPlanID = details.auditPlanID;
      markManuallySelected(auditPlanKey);
    }

    return caseSearchList;
  }

  // END, CR00201195

  // ___________________________________________________________________________
  /**
   * Method to remove cases from the audit plan .
   *
   * @param key The unique id of the case audit record to be removed
   */
  @Override
  public void removeCaseAudit(final CaseAuditAndVersionKey key)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    caseAuditObj.remove(key.versionNo);

  }

  // ___________________________________________________________________________
  /**
   * Method to list case audits on an audit plan which have satisfied a given
   * focus area.
   *
   * @param key The audit plan and focus area
   *
   * @return Records in a form suitable for the client interface
   */
  @Override
  public CaseAuditListDetailsList listAuditsOnPlanMeetingFocus(
    final AuditPlanFocusAreaKey key) throws AppException,
      InformationalException {

    return listCaseAuditsForFocusArea(key, FOCUSAREASATISFIEDEntry.YES);
  }

  // ___________________________________________________________________________
  /**
   * Method to list case audits on an audit plan which have not satisfied a
   * given focus area.
   *
   * @param key The audit plan and focus area
   *
   * @return Records in a form suitable for the client interface
   */
  @Override
  public CaseAuditListDetailsList listAuditsOnPlanNotMeetingFocus(
    final AuditPlanFocusAreaKey key) throws AppException,
      InformationalException {

    return listCaseAuditsForFocusArea(key, FOCUSAREASATISFIEDEntry.NO);
  }

  // ___________________________________________________________________________
  /**
   * Method to list case audits on an audit plan which have not yet examined a
   * given focus area.
   *
   * @param key The audit plan and focus area
   *
   * @return Records in a form suitable for the client interface
   */
  @Override
  public CaseAuditListDetailsList listAuditsOnPlanFocusAreaNotYetExamined(
    final AuditPlanFocusAreaKey key) throws AppException,
      InformationalException {

    return listCaseAuditsForFocusArea(key,
      FOCUSAREASATISFIEDEntry.NOT_SPECIFIED);
  }

  // ___________________________________________________________________________
  /**
   * protected method to list case audits for a focus area filtering by whether
   * or not they are satisfied and whether they have been examined.
   *
   * @param key The audit plan and focus area
   * @param focusAreaMet Indicates whether the focus area was satisfied.
   *
   * @return Records in a form suitable for the client interface
   */
  protected CaseAuditListDetailsList listCaseAuditsForFocusArea(
    final AuditPlanFocusAreaKey key,
    final FOCUSAREASATISFIEDEntry focusAreaMet) throws AppException,
      InformationalException {

    // Retrieve the audit plan details
    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    // Retrieve the focus area details
    final AuditPlanFocusArea auditPlanFocusArea = auditPlanFocusAreaDAO.get(
      key.auditFocusAreaID);

    final Set<curam.caseaudit.impl.CaseAudit> caseAuditSet = caseAuditDAO.searchCaseAuditsForFocusArea(
      auditPlanObj, auditPlanFocusArea, focusAreaMet);

    final CaseAuditListDetailsList caseAuditListDetailsList = getCaseAuditListDetailsListFromSet(
      caseAuditSet);

    // BEGIN, CR00290965, IBM
    collectInformationalMsgs(caseAuditListDetailsList.informationalMsgDtlsList);
    // END, CR00290965

    return caseAuditListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to remove the assignment of any case audits from the specified
   * auditor on the specified audit plan.
   *
   * @param details The Audit Plan and Auditor details
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void unassignCaseAudits(final RemoveAuditorDetails details)
    throws AppException, InformationalException {

    // move all the auditor / audit teams case audits back into 'Open'
    final AuditPlanAndAuditorKey auditPlanAndAuditorKey = new AuditPlanAndAuditorKey();

    auditPlanAndAuditorKey.auditorID = details.auditorID;
    auditPlanAndAuditorKey.auditPlanID = details.auditPlanID;

    final AuditsOnPlanByAuditorDetails caseAuditList = listAuditsOnPlanByAuditor(
      auditPlanAndAuditorKey);

    for (int i = 0; i < caseAuditList.caseAuditList.dtls.size(); i++) {

      final long caseAuditID = caseAuditList.caseAuditList.dtls.item(i).caseAuditID;
      final int versionNo = caseAuditList.caseAuditList.dtls.item(i).versionNo;

      final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
        caseAuditID);

      caseAuditObj.removeAuditor(versionNo);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve all Case Audits for the logged in User.
   *
   * @param key The criteria to search on
   *
   * @return List of Case Audits for an Audit Plan
   */
  @Override
  public CaseAuditListDetailsList listCaseAuditsForCurrentUser(
    final MyCaseAuditSearchCriteria key) throws AppException,
      InformationalException {

    final CaseAuditListDetailsList caseAuditListDetailsList = new CaseAuditListDetailsList();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // String list of IDs
    final StringList originalAssignedToList = StringUtil.tabText2StringList(
      key.assignedToList);
    final StringList finalAssignedToList = new StringList();

    finalAssignedToList.addAll(originalAssignedToList);

    // Check if the auditor is an auditor on any other audit plans
    for (final String auditorID : originalAssignedToList) {

      try {
        final Auditor auditor = auditorDAO.get(Long.valueOf(auditorID));

        if (auditor.isUser()) {
          // Search for auditor on other audit plans
          final List<Auditor> auditorList = auditorDAO.searchByUserName(
            auditor.getAuditorName());

          for (final Auditor auditorUser : auditorList) {
            if (!auditorUser.getID().equals(auditor.getID())) {
              finalAssignedToList.add(String.valueOf(auditorUser.getID()));
            }
          }
        }
      } catch (final RecordNotFoundException rnfe) {// Current user is not an
        // auditor,
        // ignore
      }
    }

    final StringList statusList = StringUtil.tabText2StringList(
      key.auditStatusList);

    final List<curam.caseaudit.impl.CaseAudit> caseAuditList = caseAuditDAO.searchByAssignedAuditorAndStatus(
      finalAssignedToList, statusList);

    for (final curam.caseaudit.impl.CaseAudit caseAudit : caseAuditList) {

      final CaseAuditListDetails caseAuditListDetails = new CaseAuditListDetails();

      // read case header
      final CaseHeader caseHeader = caseAudit.getCase();

      caseAuditListDetails.caseAuditID = caseAudit.getID();
      caseAuditListDetails.caseAuditReference = caseAudit.getCaseAuditReference();
      caseAuditListDetails.caseID = caseHeader.getID();
      caseAuditListDetails.caseRef = caseHeader.getCaseReference();
      caseAuditListDetails.caseTypeCode = caseHeader.getCaseType().getCode();
      caseAuditListDetails.caseAuditStatus = caseAudit.getLifecycleState().getCode();
      caseAuditListDetails.caseClientConcernRoleID = caseHeader.getConcernRole().getID();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      caseAuditListDetails.caseClientFullName = concernRoleNameDetails.concernRoleName;

      if (caseAudit.getAuditor().getID() != 0) {

        caseAuditListDetails.auditor = caseAudit.getAuditor().getID();
        caseAuditListDetails.dateAssigned = caseAudit.getDateAssigned();
      }
      caseAuditListDetailsList.dtls.addRef(caseAuditListDetails);
    }

    // BEGIN, CR00290965, IBM
    collectInformationalMsgs(caseAuditListDetailsList.informationalMsgDtlsList);
    // END, CR00290965

    return caseAuditListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all case audit status values except open.
   *
   * @return the list of case audit status values.
   */
  @Override
  public CaseAuditStatusFilter listInProgressCaseAuditStatuses()
    throws AppException, InformationalException {

    final curam.core.facade.intf.System systemObj = curam.core.facade.fact.SystemFactory.newInstance();

    final CaseAuditStatusFilter caseAuditStatusFilter = new CaseAuditStatusFilter();

    final CaseAuditStatusDetailsList availableList = new CaseAuditStatusDetailsList();

    final StringBuffer defaultSelection = new StringBuffer();

    // BEGIN, CR00335654, GA
    CaseAuditStatusDetails caseAuditStatusDetails;
    final CodeTableName codeTableName = new CodeTableName();

    codeTableName.name = CASEAUDITSTATUS.TABLENAME;

    final CodetableCodeAndDescriptionList listItemsInCodeTable = systemObj.listEnabledItemsInCodetableForLocale(
      codeTableName);

    for (final CodetableCodeAndDescription codeTableItemDetails : listItemsInCodeTable.codetableCodeAndDescription.items()) {

      if (!CASEAUDITSTATUSEntry.OPEN.getCode().equals(codeTableItemDetails.code)
        && !CASEAUDITSTATUSEntry.COMPLETE.getCode().equals(
          codeTableItemDetails.code)) {
        caseAuditStatusDetails = new CaseAuditStatusDetails();
        defaultSelection.append(codeTableItemDetails.code + "\t");
        caseAuditStatusDetails.description = codeTableItemDetails.description;
        caseAuditStatusDetails.caseAuditCode = codeTableItemDetails.code;
        availableList.dtlsList.addRef(caseAuditStatusDetails);

      }
    }

    // Adding 'Complete' status at the end.
    MaintainCodeTableItem maintainCodeTableItem = new MaintainCodeTableItem();
    final ReadCodeTableItemKey readCodeTableItemKey = new ReadCodeTableItemKey();

    readCodeTableItemKey.code = CASEAUDITSTATUS.COMPLETE;
    readCodeTableItemKey.languageCode = TransactionInfo.getProgramLocale();
    readCodeTableItemKey.name = CASEAUDITSTATUS.TABLENAME;

    maintainCodeTableItem = systemObj.readCodeTableItem(readCodeTableItemKey);

    caseAuditStatusDetails = new CaseAuditStatusDetails();
    caseAuditStatusDetails.description = maintainCodeTableItem.description;
    caseAuditStatusDetails.caseAuditCode = CASEAUDITSTATUS.COMPLETE;
    availableList.dtlsList.addRef(caseAuditStatusDetails);
    // END, CR00335654

    caseAuditStatusFilter.availableStatuses = availableList;

    if (defaultSelection.length() > 0) {
      caseAuditStatusFilter.selectedStatuses = defaultSelection.substring(0,
        defaultSelection.length() - 1);
    }

    return caseAuditStatusFilter;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify a Case Audit.
   *
   * @param details Details of the Case Audit to modify
   */
  @Override
  public void modifyCaseAudit(final CaseAuditModifyDetails details)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      details.caseAuditID);

    caseAuditObj.setComments(details.comments);

    caseAuditObj.modify(details.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to read specific Case Audit details to be modified.
   *
   * @param key ID of the Case Audit
   *
   * @return Details of the Case Audit to modify
   */
  @Override
  public CaseAuditModifyDetails readCaseAuditForModify(final CaseAuditKey key) throws AppException,
      InformationalException {

    final CaseAuditModifyDetails caseAuditModifyDetails = new CaseAuditModifyDetails();

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    caseAuditModifyDetails.caseAuditID = caseAuditObj.getID();
    caseAuditModifyDetails.versionNo = caseAuditObj.getVersionNo();
    caseAuditModifyDetails.comments = caseAuditObj.getComments();

    return caseAuditModifyDetails;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Method to search all Case Audits on the system based on the supplied
   * criteria.
   *
   * @param key Criteria for the search
   *
   * @return List of Case Audits that matched the search criteria
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link CaseAudit#searchAllCaseAuditsDetails(SearchAllCaseAuditsKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchAllCaseAuditsDetails(SearchAllCaseAuditsKey)
   * which returns the informational message along with case audits
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public SearchAllCaseAuditsResultsList searchAllCaseAudits(
    final SearchAllCaseAuditsKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    final SearchAllCaseAuditsResultsList searchResults = new SearchAllCaseAuditsResultsList();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    AuditCaseConfig auditCaseConfigObj = null;

    if (key.auditCaseConfig != 0) {
      auditCaseConfigObj = auditCaseConfigDAO.get(key.auditCaseConfig);
    }

    final List<curam.caseaudit.impl.CaseAudit> caseAuditList = caseAuditDAO.searchAllCaseAudits(
      key.auditPlanReference, key.caseAuditReference, auditCaseConfigObj,
      CASEAUDITSTATUSEntry.get(key.caseAuditStatus), key.auditor,
      key.coordinator);

    for (final curam.caseaudit.impl.CaseAudit caseAuditObj : caseAuditList) {

      final SearchAllCaseAuditsResult result = new SearchAllCaseAuditsResult();

      result.caseAuditID = caseAuditObj.getID();
      result.caseAuditStatus = caseAuditObj.getLifecycleState().getCode();

      final AuditPlan auditPlanObj = caseAuditObj.getAuditPlan();

      final String caseAuditName = curam.util.type.CodeTable.getOneItemForUserLocale(
        CASECATTYPECODE.TABLENAME,
        auditPlanObj.getAuditCaseConfig().getCaseCategory().getCode());
      final String caseAuditReference = caseAuditObj.getCaseAuditReference();

      result.planNameCaseAuditRef = caseAuditName + CuramConst.kSeparator
        + caseAuditReference;
      final Auditor auditorObj = caseAuditObj.getAuditor();

      if (auditorObj.getID() != 0) {
        result.auditorName = auditorObj.getName();
      }

      usersKey = new UsersKey();
      usersKey.userName = auditPlanObj.getCoordinator();

      result.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

      final CaseHeader caseHeaderObj = caseAuditObj.getCase();

      concernRoleKey.concernRoleID = caseHeaderObj.getConcernRole().getID();
      result.clientFullName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      searchResults.dtls.addRef(result);
    }
    return searchResults;
  }

  // ___________________________________________________________________________
  /**
   * Method to manually complete a Case Audit. This is used when the audit is
   * in status 'Awaiting Feedback', and causes the audit to transition to
   * 'Complete' status as well as closing any related feedback tasks still
   * assigned to the case owner or supervisor.
   *
   * @param key ID and version number of the case audit record.
   */
  @Override
  public void completeCaseAudit(final CaseAuditAndVersionKey key)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    caseAuditObj.complete(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to assign the list of case audits for the audit plan to the
   * specified auditor.
   *
   * @param details the case audit assignment details.
   */
  @Override
  public void assignCaseAudits(final CaseAuditAssignDetails details)
    throws AppException, InformationalException {

    // Validate that the assign function can be carried out.
    validateAssignCaseAudit(details);

    // Get the auditor
    final Auditor auditorObj = auditorDAO.get(details.auditorID);

    String tabList = new String();

    tabList = details.caseIDVersNoList;

    // String list of Case IDs
    final StringList caseIDAndVersionNoList = StringUtil.tabText2StringList(
      tabList);

    for (int i = 0; i < caseIDAndVersionNoList.size(); i++) {

      final StringList caseIDAndVersionNoStringList = StringUtil.delimitedText2StringList(
        caseIDAndVersionNoList.item(i), '|');

      final long caseAuditID = Long.parseLong(
        caseIDAndVersionNoStringList.item(0));
      final int versionNo = (int) Long.parseLong(
        caseIDAndVersionNoStringList.item(1));

      final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
        caseAuditID);

      caseAuditObj.assign(auditorObj, versionNo);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to remove the assigned auditor or audit team from the case audits
   * for the audit plan selected.
   *
   * @param details the case audit assignment details.
   */
  @Override
  public void removeAssignmentCaseAudits(final CaseAuditAssignDetails details)
    throws AppException, InformationalException {

    String tabList = new String();

    tabList = details.caseIDVersNoList;

    // String list of Case IDs
    final StringList caseIDAndVersionNoList = StringUtil.tabText2StringList(
      tabList);

    for (int i = 0; i < caseIDAndVersionNoList.size(); i++) {

      final StringList caseIDAndVersionNoStringList = StringUtil.delimitedText2StringList(
        caseIDAndVersionNoList.item(i), '|');

      final long caseAuditID = Long.parseLong(
        caseIDAndVersionNoStringList.item(0));
      final int versionNo = (int) Long.parseLong(
        caseIDAndVersionNoStringList.item(1));

      final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
        caseAuditID);

      caseAuditObj.removeAuditor(versionNo);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to return the list of case audits which have been selected by the
   * audit coordinator for assignment.
   *
   * @param details The case audit list.
   *
   * @return List of case audit details
   */
  @Override
  public CaseAuditListDetailsList listCaseAuditsForAssignment(
    final CaseAuditAssignList details) throws AppException,
      InformationalException {

    final CaseAuditListDetailsList caseAuditListDetailsList = new CaseAuditListDetailsList();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    String tabList = new String();

    tabList = details.caseIDVersNoList;

    // String list of Case IDs
    final StringList caseIDAndVersionNoList = StringUtil.tabText2StringList(
      tabList);

    for (int i = 0; i < caseIDAndVersionNoList.size(); i++) {

      final CaseAuditListDetails caseAuditListDetails = new CaseAuditListDetails();

      final StringList caseIDAndVersionNoStringList = StringUtil.delimitedText2StringList(
        caseIDAndVersionNoList.item(i), '|');

      final long caseAuditID = Long.parseLong(
        caseIDAndVersionNoStringList.item(0));

      final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
        caseAuditID);

      // read case header
      final CaseHeader caseHeader = caseAuditObj.getCase();

      caseAuditListDetails.caseAuditID = caseAuditID;
      caseAuditListDetails.caseAuditReference = caseAuditObj.getCaseAuditReference();
      caseAuditListDetails.caseRef = caseHeader.getCaseReference();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      caseAuditListDetails.caseClientConcernRoleID = caseHeader.getConcernRole().getID();
      caseAuditListDetails.caseClientFullName = concernRoleNameDetails.concernRoleName;

      caseAuditListDetailsList.dtls.addRef(caseAuditListDetails);
    }

    return caseAuditListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve all Case Audits that have yet to be assigned.
   *
   * @param key The criteria to search on
   *
   * @return List of Case Audits for an Audit Plan
   */
  @Override
  public CaseAuditListDetailsList listUnassignedCaseAudits(
    final AuditPlanKey key) throws AppException, InformationalException {

    // return struct
    final CaseAuditListDetailsList caseAuditListDetailsList = new CaseAuditListDetailsList();

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    final String caseAuditName = curam.util.type.CodeTable.getOneItemForUserLocale(
      CASECATTYPECODE.TABLENAME,
      auditPlanObj.getAuditCaseConfig().getCaseCategory().getCode());

    final List<curam.caseaudit.impl.CaseAudit> caseAuditList = caseAuditDAO.searchByAuditPlanAndStatus(
      auditPlanObj, CASEAUDITSTATUSEntry.OPEN);

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    for (final curam.caseaudit.impl.CaseAudit caseAudit : caseAuditList) {

      final CaseAuditListDetails caseAuditListDetails = new CaseAuditListDetails();

      // read case header
      final CaseHeader caseHeader = caseAudit.getCase();

      caseAuditListDetails.caseAuditID = caseAudit.getID();
      caseAuditListDetails.caseAuditReference = caseAudit.getCaseAuditReference()
        + CuramConst.kSeparator + caseAuditName;

      caseAuditListDetails.auditPlanID = caseAudit.getAuditPlan().getID();

      caseAuditListDetails.versionNo = caseAudit.getVersionNo();

      caseAuditListDetails.caseID = caseHeader.getID();
      caseAuditListDetails.caseRef = caseHeader.getCaseReference();

      caseAuditListDetails.caseAuditStatus = caseAudit.getLifecycleState().getCode();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      caseAuditListDetails.caseClientConcernRoleID = caseHeader.getConcernRole().getID();
      caseAuditListDetails.caseClientFullName = concernRoleNameDetails.concernRoleName;

      caseAuditListDetailsList.dtls.addRef(caseAuditListDetails);
    }

    return caseAuditListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to pass a multi select list of identifiers, for example case audit
   * id's, from one page to another.
   *
   * @param details The string of identifiers and a dummy action id property
   * (which allows multiple submit actions to use the list).
   *
   * @return The method parameter verbatim.
   */
  @Override
  public AssignCaseAuditResult passCaseAuditListAsParam(
    final CaseAuditIDTabbedList details) throws InformationalException {

    // BEGIN, CR00182410, GD
    final AssignCaseAuditResult assignCaseAuditResult = new AssignCaseAuditResult();

    if (details.caseIDVersNoList.equals("")) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADECASEAUDITExceptionCreator.ERR_RV_NO_CASE_AUDIT_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      final WarningsDtlsList warningsDtlsList = new WarningsDtlsList();

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      // Retrieve list of informational messages
      final String[] messages = informationalManager.obtainInformationalAsString();

      // Return the Informational messages
      for (int i = 0; i < messages.length; i++) {

        final WarningsDtls warningsDtls = new WarningsDtls();

        warningsDtls.warning = messages[i];
        warningsDtlsList.dtls.addRef(warningsDtls);
      }

      assignCaseAuditResult.warnings = warningsDtlsList;
      ValidationHelper.failIfErrorsExist();
    }

    assignCaseAuditResult.tabbedList = details;
    return assignCaseAuditResult;
    // END, CR00182410
  }

  // ___________________________________________________________________________
  /**
   * Method to list case audits on an audit plan which have been assigned to a
   * given auditor.
   *
   * @param key The audit plan and auditor identifiers.
   *
   * @return Records in a form suitable for the client interface
   */
  @Override
  public AuditsOnPlanByAuditorDetails listAuditsOnPlanByAuditor(
    final AuditPlanAndAuditorKey key) throws AppException,
      InformationalException {

    final AuditsOnPlanByAuditorDetails auditsOnPlanByAuditorDetails = new AuditsOnPlanByAuditorDetails();

    // get the name of the auditor for the page title
    auditsOnPlanByAuditorDetails.auditorDisplayName = auditorDAO.get(key.auditorID).getName();

    final StringList assignedToList = new StringList();

    assignedToList.add(String.valueOf(key.auditorID));
    final StringList statusList = new StringList();

    final List<curam.caseaudit.impl.CaseAudit> caseAuditList = caseAuditDAO.searchByAssignedAuditorAndStatus(
      assignedToList, statusList);

    auditsOnPlanByAuditorDetails.caseAuditList = new CaseAuditListDetailsList();
    CaseAuditListDetails caseAuditListDetails;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    for (final curam.caseaudit.impl.CaseAudit caseAudit : caseAuditList) {

      // only return case audits on this audit plan
      if (caseAudit.getAuditPlan().getID() == key.auditPlanID) {

        caseAuditListDetails = new CaseAuditListDetails();

        // read case header
        final CaseHeader caseHeader = caseAudit.getCase();

        caseAuditListDetails.caseAuditID = caseAudit.getID();
        caseAuditListDetails.caseAuditReference = caseAudit.getCaseAuditReference();
        caseAuditListDetails.dateAssigned = caseAudit.getDateAssigned();
        caseAuditListDetails.versionNo = caseAudit.getVersionNo();
        caseAuditListDetails.caseID = caseHeader.getID();
        caseAuditListDetails.caseRef = caseHeader.getCaseReference();
        caseAuditListDetails.caseAuditStatus = caseAudit.getLifecycleState().getCode();

        concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
        final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
          concernRoleKey);

        caseAuditListDetails.caseClientConcernRoleID = caseHeader.getConcernRole().getID();
        caseAuditListDetails.caseClientFullName = concernRoleNameDetails.concernRoleName;

        auditsOnPlanByAuditorDetails.caseAuditList.dtls.addRef(
          caseAuditListDetails);
      }
    }

    // BEGIN, CR00290965, IBM
    collectInformationalMsgs(
      auditsOnPlanByAuditorDetails.caseAuditList.informationalMsgDtlsList);
    // END, CR00290965

    return auditsOnPlanByAuditorDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate that the assign case audits function can be
   * carried out.
   *
   * @param details the assignment details selected by the user.
   */
  @Override
  public void validateAssignCaseAudit(final CaseAuditAssignDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Check that an auditor has been selected
    if (details.auditorID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          ENTCASEAUDIT.ERR_FV_CONTRIBUTOR_REQUIRED_FOR_ASSIGNED_STATE),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      informationalManager.failOperation();
    }

    if (details.caseIDVersNoList.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_NO_CASE_AUDITS_SELECTED_FOR_ASSIGNMENT),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve all Case Audits for a given Audit Plan, filtered by
   * the given search criteria.
   *
   * @param key Specifies the audit plan and further search criteria
   *
   * @return List of Case Audits for an Audit Plan
   */
  @Override
  public CaseAuditListDetailsList filterCaseAuditsListForAuditPlan(
    final CaseAuditListFilterKey key) throws AppException,
      InformationalException {

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    final Set<curam.caseaudit.impl.CaseAudit> caseAuditSet = caseAuditDAO.searchCaseAudits(
      auditPlanObj, key.caseAuditReference, auditorDAO.get(key.auditor),
      FOCUSAREASATISFIEDEntry.get(key.focusAreasMet),
      CASEAUDITSTATUSEntry.get(key.caseAuditStatus));

    final CaseAuditListDetailsList caseAuditListDetailsList = getCaseAuditListDetailsListFromSet(
      caseAuditSet);

    listCaseAuditFocusAreaStats(caseAuditListDetailsList);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings = informationalManager.obtainInformationalAsString();
    InformationalMsgDtls informationalMsgDtls;

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      caseAuditListDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // BEGIN, CR00229866, GD
    caseAuditListDetailsList.key.assign(key);
    // END, CR00229866

    // Dynamically display 'Assign Case Audits' link
    for (final CaseAuditListDetails caseAuditListDetails : caseAuditListDetailsList.dtls) {

      if (caseAuditListDetails.caseAuditStatus.equals(
        CASEAUDITSTATUSEntry.OPEN.getCode())) {
        caseAuditListDetailsList.showAssignLink = true;
        break;
      }
    }

    // Dynamically display 'Change list of cases' and 'Add Cases' links
    if (caseAuditListDetailsList.dtls.size() > 0
      && auditPlanObj.getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)
      && auditPlanObj.getRecordStatus().equals(RECORDSTATUSEntry.NORMAL)) {

      if (auditPlanObj.areCasesUserSelected()) {
        caseAuditListDetailsList.showAddCasesLink = true;
      } else {
        caseAuditListDetailsList.showChangeSampleLink = true;
      }
    }

    return caseAuditListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve all Case Audits for a given Audit Plan.
   *
   * @param auditPlanKey The Audit Plan to search on
   *
   * @return List of Case Audits for an Audit Plan
   */
  @Override
  public CaseAuditListDetailsList listAllCaseAuditsForAuditPlan(
    final AuditPlanKey auditPlanKey) throws AppException,
      InformationalException {

    // fetch audit plan and get full list of case audits from that
    final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.get(
      auditPlanKey.auditPlanID);

    final Set<curam.caseaudit.impl.CaseAudit> caseAuditSet = auditPlan.getCaseAudits();

    return getCaseAuditListDetailsListFromSet(caseAuditSet);
  }

  // ___________________________________________________________________________
  /**
   * Method to return the list of auditors and audit teams for the
   * specified audit plan.
   *
   * @param key The audit plan identifier.
   *
   * @return Details of the audit plan members
   */
  @Override
  public AuditPlanMemberDetailsList listAuditPlanMembers(
    final AuditPlanKey key) throws AppException, InformationalException {

    final AuditPlanMemberDetailsList auditPlanMemberDetailsList = new AuditPlanMemberDetailsList();

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);
    final List<Auditor> auditorList = auditorDAO.searchByAuditPlan(auditPlanObj);

    auditPlanMemberDetailsList.dtls.ensureCapacity(auditorList.size());

    for (final Auditor auditor : auditorList) {

      final AuditPlanMemberDetails auditPlanMemberDetails = new AuditPlanMemberDetails();

      auditPlanMemberDetails.auditorID = auditor.getID();
      auditPlanMemberDetails.auditorType = auditor.getAuditorType().getCode();
      auditPlanMemberDetails.auditorName = auditor.getName();

      auditPlanMemberDetailsList.dtls.addRef(auditPlanMemberDetails);
    }

    return auditPlanMemberDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to return the list of auditors and audit teams for the
   * specified audit plan.
   *
   * @param key The audit plan identifier.
   *
   * @return Details of the audit plan members
   */
  @Override
  public AuditPlanMemberDetailsList listAuditPlanMembersAndStats(
    final AuditPlanKey key) throws AppException, InformationalException {

    final AuditPlanMemberDetailsList auditPlanMemberDetailsList = new AuditPlanMemberDetailsList();

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);
    final List<Auditor> auditorList = auditorDAO.searchByAuditPlan(auditPlanObj);

    auditPlanMemberDetailsList.dtls.ensureCapacity(auditorList.size());

    for (final Auditor auditor : auditorList) {

      final AuditPlanMemberDetails auditPlanMemberDetails = new AuditPlanMemberDetails();

      // populate auditor details
      auditPlanMemberDetails.auditorID = auditor.getID();
      auditPlanMemberDetails.auditorType = auditor.getAuditorType().getCode();

      // BEGIN, CR00219367, GD
      // if auditor is team append number of auditors on team to team name
      if (auditor.isTeam()) {

        final int teamSize = auditor.getAuditTeam().getMembers().size();

        if (teamSize > 0) {
          final LocalisableString teamName = new LocalisableString(
            FACADECASEAUDIT.INF_AUDIT_TEAM_NAME_SIZE);

          teamName.arg(auditor.getName());
          teamName.arg(teamSize);
          auditPlanMemberDetails.auditorName = teamName.getMessage(
            TransactionInfo.getProgramLocale());
        } else {
          auditPlanMemberDetails.auditorName = auditor.getName();
        }

      } else {
        auditPlanMemberDetails.auditorName = auditor.getName();
      }
      // END, CR00219367

      auditPlanMemberDetails.dateAdded = auditor.getDateAdded();
      auditPlanMemberDetails.teamInd = auditor.isTeam();

      // populate stats
      final AuditPlanAndAuditorKey auditPlanAndAuditorKey = new AuditPlanAndAuditorKey();

      auditPlanAndAuditorKey.auditorID = auditor.getID();
      auditPlanAndAuditorKey.auditPlanID = key.auditPlanID;

      // Get all case audits assigned to auditor
      final CaseAuditListDetailsList auditsAssignedToAuditor = listAuditsOnPlanByAuditor(auditPlanAndAuditorKey).caseAuditList;

      // Filter out complete case audits
      for (int i = 0; i < auditsAssignedToAuditor.dtls.size(); i++) {

        if (!auditsAssignedToAuditor.dtls.item(i).caseAuditStatus.equals(
          CASEAUDITSTATUS.COMPLETE)) {

          auditPlanMemberDetails.numCaseAudits++;
        }
      }

      // BEGIN, CR00222499, GD
      if (auditPlanMemberDetails.numCaseAudits > 0) {
        auditPlanMemberDetails.assignedCaseAuditInd = true;
      }
      // END, CR00222499

      auditPlanMemberDetailsList.dtls.addRef(auditPlanMemberDetails);
    }

    return auditPlanMemberDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to convert a Set of curam.caseaudit.impl.CaseAudit records
   * into the format required for the client interface
   * (CaseAuditListDetailsList).
   *
   * @param caseAuditSet Set of curam.caseaudit.impl.CaseAudit records
   *
   * @return Records in a form suitable for the client interface
   */
  protected CaseAuditListDetailsList getCaseAuditListDetailsListFromSet(
    final Set<curam.caseaudit.impl.CaseAudit> caseAuditSet)
    throws AppException, InformationalException {

    // return struct
    final CaseAuditListDetailsList caseAuditListDetailsList = new CaseAuditListDetailsList();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    for (final curam.caseaudit.impl.CaseAudit caseAudit : caseAuditSet) {

      final CaseAuditListDetails caseAuditListDetails = new CaseAuditListDetails();

      // read case header
      final CaseHeader caseHeader = caseAudit.getCase();

      caseAuditListDetails.caseAuditID = caseAudit.getID();
      caseAuditListDetails.caseAuditReference = caseAudit.getCaseAuditReference();

      caseAuditListDetails.auditPlanID = caseAudit.getAuditPlan().getID();

      caseAuditListDetails.versionNo = caseAudit.getVersionNo();

      if (caseAudit.getAuditor().getID() != 0) {

        caseAuditListDetails.auditorFullName = caseAudit.getAuditor().getName();
      }

      caseAuditListDetails.caseID = caseHeader.getID();
      caseAuditListDetails.caseRef = caseHeader.getCaseReference();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();

      final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      final StringBuffer description = new StringBuffer();

      description.append(caseHeader.getCaseReference());
      description.append(GeneralConstants.kMinus);
      description.append(concernRoleNameDetails.concernRoleName);

      caseAuditListDetails.caseDetails = description.toString();

      caseAuditListDetails.caseStartDate = caseHeader.getStartDate();
      caseAuditListDetails.caseStatusCode = caseHeader.getStatus().getCode();

      caseAuditListDetails.caseAuditStatus = caseAudit.getLifecycleState().getCode();

      caseAuditListDetails.caseClientConcernRoleID = caseHeader.getConcernRole().getID();
      caseAuditListDetails.caseClientFullName = concernRoleNameDetails.concernRoleName;

      // TODO: CSH: set focus areas not met indicator
      // Need to update this to check case audit status
      // Changes pending BA investigation
      caseAuditListDetailsList.dtls.addRef(caseAuditListDetails);
    }

    return caseAuditListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to generate the context description for an audit plan.
   *
   * @param key Contains the audit plan identifier.
   *
   * @return Context description for the audit plan.
   */
  protected String getAuditPlanContextDescription(
    final curam.caseaudit.impl.AuditPlan auditPlan) {

    final LocalisableString description = new LocalisableString(
      FACADECASEAUDIT.INF_AUDIT_PLAN_DYNAMIC_MENU_DESCRIPTION);

    description.arg(kAuditPlan.getMessage());
    description.arg(auditPlan.getAuditPlanReference());

    return description.toClientFormattedText();
  }

  // ___________________________________________________________________________
  /**
   * Method to pass case audit assignment details from one page to another.
   *
   * @param details the assignment details
   *
   * @return the assignment details
   */
  @Override
  public CaseAuditAssignDetails passCaseAuditAssignDetailsAsParam(
    final CaseAuditAssignDetails details) throws AppException,
      InformationalException {

    return details;
  }

  // ___________________________________________________________________________
  /**
   * Method to resolve the case audit home page. If the logged in user is the
   * coordinator of the associated audit plan, they will be directed to the
   * coordinator version of the case audit home page, otherwise the user will
   * be directed to the auditor version of the case audit home page.
   *
   * @param key the unique identifier of the case audit to be viewed.
   *
   * @return the case audit home page name
   */
  @Override
  public CaseAuditHomePageName resolveCaseAuditHomePageName(
    final CaseAuditKey key) throws AppException, InformationalException {

    final CaseAuditHomePageName caseAuditHomePageName = new CaseAuditHomePageName();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Get the currently logged in user
    usersKey.userName = userAccessObj.getUserDetails().userName;

    // Get the associated audit plan
    final AuditPlan auditPlanObj = caseAuditDAO.get(key.caseAuditID).getAuditPlan();

    // Return the relevant page name
    if (auditPlanObj.getCoordinator().equals(usersKey.userName)) {
      caseAuditHomePageName.name = kCoordinatorCaseAuditHome;
    } else {
      caseAuditHomePageName.name = kAuditorCaseAuditHome;
    }
    return caseAuditHomePageName;
  }

  // ___________________________________________________________________________
  /**
   * Method used to validate and pass parameters from one page to another.
   *
   * @param key The parameters to be passed.
   *
   * @return The parameters to be passed
   */
  @Override
  public MyCaseAuditSearchCriteria getMyCaseAuditsListKey(
    final MyCaseAuditSearchCriteria key) throws AppException,
      InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // String list of IDs
    final StringList assignedToList = StringUtil.tabText2StringList(
      key.assignedToList);
    final StringList statusList = StringUtil.tabText2StringList(
      key.auditStatusList);

    if (assignedToList.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(FACADECASEAUDIT.ERR_RV_NO_ASSIGNEE_SELECTED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (statusList.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(FACADECASEAUDIT.ERR_RV_NO_CASE_AUDIT_STATUS_SELECTED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    informationalManager.failOperation();

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of Auditors and Audit Teams that can be reassigned to
   * the specified case audit list, the returned list of Auditors/Audit Teams
   * doesn't include the Auditor / Audit Team that is currently assigned to
   * these Case Audits. This list is used to populate a dropdown list of
   * Auditors/Audit Teams that the user can reassign Case Audits to.
   *
   * @param key The case audit list being reassigned.
   *
   * @return Details of the audit plan members
   */
  @Override
  public AuditPlanMemberDetailsList listAssignableAuditMembers(
    final CaseAuditAssignList key) throws AppException,
      InformationalException {

    final AuditPlanMemberDetailsList auditPlanMemberDetailsList = new AuditPlanMemberDetailsList();

    if (key.caseIDVersNoList.equals("")) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FACADECASEAUDITExceptionCreator.ERR_RV_NO_CASE_AUDIT_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    } else {

      final String tabList = key.caseIDVersNoList;

      // String list of Case IDs
      final StringList caseIDAndVersionNoList = StringUtil.tabText2StringList(
        tabList);

      // All cases in this list are assigned to the same auditor / audit team
      // so we just need to get the first case audit record, find the
      // corresponding auditor and exclude this auditor from the list of
      // auditors we are returning because this auditor is already assigned to
      // this case audit.
      final StringList caseIDAndVersionNoStringList = StringUtil.delimitedText2StringList(
        caseIDAndVersionNoList.item(0), '|');

      final long caseAuditID = Long.parseLong(
        caseIDAndVersionNoStringList.item(0));

      final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
        caseAuditID);

      // Current Assigned Auditor/Audit Team
      final Auditor currentAuditor = caseAuditObj.getAuditor();

      final curam.caseaudit.impl.AuditPlan auditPlanObj = caseAuditObj.getAuditPlan();

      final List<Auditor> auditorList = auditorDAO.searchByAuditPlan(
        auditPlanObj);

      auditPlanMemberDetailsList.dtls.ensureCapacity(auditorList.size());

      // filter out current assigned auditor from the list of auditors on the
      // audit plan
      for (final Auditor auditor : auditorList) {

        final AuditPlanMemberDetails auditPlanMemberDetails = new AuditPlanMemberDetails();

        if (auditor.getID() != currentAuditor.getID()) {

          // this is different auditor to the currently assigned
          // auditor so add to the return list
          auditPlanMemberDetails.auditorID = auditor.getID();
          auditPlanMemberDetails.auditorType = auditor.getAuditorType().getCode();
          auditPlanMemberDetails.auditorName = auditor.getName();

          auditPlanMemberDetailsList.dtls.addRef(auditPlanMemberDetails);
        }
      }
    }
    return auditPlanMemberDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to mark that the case list for the audit plan was generated
   * manually by the audit coordinator.
   *
   * @param key The audit plan that the case list is being generated for.
   */
  @Override
  public void markManuallySelected(final AuditPlanKey key)
    throws AppException, InformationalException {

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    auditPlanObj.setCasesUserSelected(true);
    auditPlanObj.setNumberCases(CuramConst.gkZero);
    auditPlanObj.setPercentageCases(CuramConst.gkDoubleZero);
    auditPlanObj.modify(auditPlanObj.getVersionNo());
  }

  // ___________________________________________________________________________
  /**
   * Method to read the tab details for a case audit.
   *
   * @param key The case audit unique identifier
   *
   * @return The case audit tab details
   */
  @Override
  public CaseAuditTabXML readCaseAuditTabDetails(final CaseAuditKey key)
    throws AppException, InformationalException {

    final CaseAuditTabXML caseAuditTabXML = new CaseAuditTabXML();
    final CaseAuditTabDetails caseAuditTabDetails = new CaseAuditTabDetails();

    final curam.caseaudit.impl.CaseAudit caseAudit = caseAuditDAO.get(
      key.caseAuditID);
    final CaseHeader caseHeader = caseAudit.getCase();
    final AuditPlan auditPlan = caseAudit.getAuditPlan();

    caseAuditTabDetails.caseAuditRef = caseAudit.getCaseAuditReference();
    caseAuditTabDetails.caseID = caseHeader.getID();
    caseAuditTabDetails.caseAuditStatus = caseAudit.getLifecycleState().getCode();

    if (caseAudit.getAuditor().getID() != 0) {
      caseAuditTabDetails.auditorName = caseAudit.getAuditor().getAuditorName();
      caseAuditTabDetails.auditorID = caseAudit.getAuditor().getID();

    }
    caseAuditTabDetails.caseRef = caseHeader.getCaseReference();
    caseAuditTabDetails.caseStatus = caseHeader.getStatus().getCode();
    caseAuditTabDetails.auditPlanEndDate = auditPlan.getScheduledEndDate();
    caseAuditTabDetails.coordinator = auditPlan.getCoordinator();
    caseAuditTabDetails.ownerOrgObjectLinkID = caseHeader.getOwnerOrgObjectLink().getID();
    caseAuditTabDetails.caseAuditID = caseAudit.getID();
    caseAuditTabDetails.auditPlanID = auditPlan.getID();

    // BEGIN, CR00290965, IBM
    final FocusAreaStatsList focusAreaList = auditPlan.listFocusAreaStatsCount();

    // END, CR00290965

    caseAuditTabDetails.numFocusAreas = focusAreaList.dtls.size();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
    final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
      concernRoleKey);

    caseAuditTabDetails.primaryClientRef = caseHeader.getConcernRole().getPrimaryAlternateID();
    caseAuditTabDetails.primaryClient = concernRoleNameDetails.concernRoleName;
    caseAuditTabDetails.auditItem = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME,
      auditPlan.getAuditCaseConfig().getCaseCategory().getCode());

    // Create container panel
    final ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditContainerPanel);

    final ContentPanelBuilder caseAuditDetails = getCaseAuditDetails(
      caseAuditTabDetails);

    if (caseAudit.getLifecycleState().equals(CASEAUDITSTATUSEntry.COMPLETE)) {
      final LocalisableString complete = new LocalisableString(
        BPOCASEAUDITTAB.INF_COMPLETE);

      caseAuditDetails.addlocalisableStringItem(
        complete.toClientFormattedText(), CuramConst.gkWaterMark);
    }

    containerPanel.addWidgetItem(caseAuditDetails, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CuramConst.gkCaseAuditContentPanel);

    final ContentPanelBuilder chartPanel = getCaseAuditFocusAreasGraph(
      caseAuditTabDetails);

    // Add the right panel to the border container
    containerPanel.addWidgetItem(chartPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CuramConst.gkCaseAuditReportContent);

    caseAuditTabXML.xmlPanelData = containerPanel.toString();

    final LocalisableString description = new LocalisableString(
      BPOCASEAUDITTAB.INF_CASE_AUDIT_LABEL);

    description.arg(caseAudit.getCaseAuditReference());

    caseAuditTabXML.description = description.getMessage(
      TransactionInfo.getProgramLocale());

    return caseAuditTabXML;
  }

  // ___________________________________________________________________________
  /**
   * Format XML data for case audit tab details.
   *
   * @param details
   * Case Audit details.
   *
   * @return ContentPanelBuilder.
   */
  protected ContentPanelBuilder getCaseAuditDetails(
    final CaseAuditTabDetails details) throws AppException,
      InformationalException {

    final ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditTabDetails);

    contentPanelBuilder.addRoundedCorners();

    final ContentPanelBuilder caseAuditDetail = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditDetails);

    // Add the case audit reference
    final String caseAudit = new LocalisableString(BPOCASEAUDITTAB.INF_CASE_AUDIT_LABEL).toClientFormattedText();

    caseAuditDetail.addlocalisableStringItem(caseAudit,
      CuramConst.gkCaseAuditRef);
    caseAuditDetail.addStringItem(String.valueOf(details.caseAuditRef),
      CuramConst.gkCaseAuditRefID);

    // Add the case name, reference and status
    final String caseNameRefAndStatus = new LocalisableString(BPOCASEAUDITTAB.INF_CASE_NAME_REF_STATUS).arg(details.auditItem).arg(details.caseRef).arg(new CodeTableItemIdentifier(CASESTATUS.TABLENAME, details.caseStatus)).toClientFormattedText();

    final LinkBuilder caseNameRefAndStatusLinkBuilder = LinkBuilder.createLocalizableLink(
      caseNameRefAndStatus, CuramConst.gkCaseHomePage);

    caseNameRefAndStatusLinkBuilder.addParameter(CuramConst.gkCaseIDParameter,
      String.valueOf(details.caseID));
    final LocalisableString relatedCase = new LocalisableString(
      BPOAUDITPLANTAB.INF_RELATEDCASE_TITLE);

    caseNameRefAndStatusLinkBuilder.addLinkTitle(relatedCase);

    caseAuditDetail.addLinkItem(caseNameRefAndStatusLinkBuilder,
      CuramConst.gkCaseAuditLink);

    final ListBuilder caseAuditList = ListBuilder.createHorizontalList(2);
    // BEGIN, 186068 - CC
    caseAuditList.setId(CuramConst.gkCaseAuditDetailsTable);
    // END, 186068 - CC
    caseAuditList.addRow();

    // Add the primary client and reference
    // BEGIN, CR00230776, BD
    caseAuditList.addEntry(1, 1,
      new LocalisableString(BPOCASEAUDITTAB.INF_PRIMARY_CLIENT_LABEL));

    caseAuditList.addEntry(2, 1,
      new LocalisableString(BPOCASEAUDITTAB.INF_PRIMARY_CLIENT).arg(details.primaryClient).arg(
      details.primaryClientRef));

    caseAuditList.addRow();

    // Add the case audit status
    caseAuditList.addEntry(1, 2,
      new LocalisableString(BPOCASEAUDITTAB.INF_STATUS_LABEL));
    final CodeTableItemEntry caseAuditStatus = DocBuilderHelperFactory.getCodeTableItemEntry(
      details.caseAuditStatus, CuramConst.gkDomainCaseAuditStatus);

    caseAuditList.addEntry(2, 2, caseAuditStatus);

    caseAuditList.addRow();

    // Add a link to the coordinator
    caseAuditList.addEntry(1, 3,
      new LocalisableString(BPOCASEAUDITTAB.INF_COORDINATOR_LABEL));

    final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = details.coordinator;

    final String coordinatorFullName = tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

    final String coordinator = new LocalisableString(BPOCASEAUDITTAB.INF_COORDINATOR).arg(coordinatorFullName).toClientFormattedText();

    final LinkBuilder coordLinkBuilder = LinkBuilder.createLocalizableLink(
      coordinator, CuramConst.gkUserDetailsPage);

    coordLinkBuilder.openAsModal();
    coordLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      details.coordinator);
    final LocalisableString coordinatorTitle = new LocalisableString(
      BPOAUDITPLANTAB.INF_COORDINATOR_TITLE);

    coordLinkBuilder.addLinkTitle(coordinatorTitle);
    final RendererConfig linkRendererConfig = new RendererConfig(
      RendererConfigType.STYLE, CuramConst.gkLink);

    caseAuditList.addEntry(2, 3, coordLinkBuilder, linkRendererConfig);

    caseAuditList.addRow();

    // Add a link to the auditor
    caseAuditList.addEntry(1, 4,
      new LocalisableString(BPOCASEAUDITTAB.INF_AUDITOR_LABEL));

    if (StringHelper.isEmpty(details.auditorName)) {
      caseAuditList.addEntry(2, 4,
        new LocalisableString(BPOCASEAUDITTAB.INF_AUDITOR_NOT_ASSIGNED));

    } else {

      usersKey = new UsersKey();
      usersKey.userName = details.auditorName;

      final String auditorFullName = tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

      final String auditor = new LocalisableString(BPOCASEAUDITTAB.INF_AUDITOR).arg(auditorFullName).toClientFormattedText();

      final LinkBuilder auditorLinkBuilder = LinkBuilder.createLocalizableLink(
        auditor, CuramConst.gkAuditorDetailsPage);

      auditorLinkBuilder.openAsModal();
      auditorLinkBuilder.addParameter(CuramConst.gkPageParameterAuditorID,
        String.valueOf(details.auditorID));
      final LocalisableString auditorTitle = new LocalisableString(
        BPOAUDITPLANTAB.INF_AUDITOR_TITLE);

      auditorLinkBuilder.addLinkTitle(auditorTitle);
      caseAuditList.addEntry(2, 4, auditorLinkBuilder, linkRendererConfig);
    }

    caseAuditDetail.addSingleListItem(caseAuditList,
      CuramConst.gkCaseAuditDetailsTable);
    contentPanelBuilder.addWidgetItem(caseAuditDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    final ContentPanelBuilder extraDetailsContent = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditExtraDetailContent);

    final ContentPanelBuilder extraDetailsContentDetail = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditExtraDetailContentDetail);

    final ImageBuilder caseOwnerImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconCaseOwner, CuramConst.gkEmpty);

    caseOwnerImageBuilder.setImageResource(CuramConst.gkRendererImages);

    final LocalisableString altTextLocalizedMessage = new LocalisableString(
      BPOCASETAB.INF_CASE_OWNER);

    caseOwnerImageBuilder.setImageAltText(
      altTextLocalizedMessage.toClientFormattedText());

    extraDetailsContentDetail.addImageItem(caseOwnerImageBuilder,
      CuramConst.gkCaseAuditOwnerImage);

    final ListBuilder caseOwnerContent = ListBuilder.createHorizontalList(2);
    // BEGIN, 186068 - CC
    caseOwnerContent.setId(CuramConst.gkCaseAuditCaseOwnerTable);
    // END, 186068 - CC
    caseOwnerContent.addRow();

    caseOwnerContent.addEntry(1, 1,
      new LocalisableString(BPOCASEAUDITTAB.INF_CASE_OWNER_LABEL));

    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

    orgObjectLinkKey.orgObjectLinkID = details.ownerOrgObjectLinkID;

    final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwnerName(
      orgObjectLinkKey);

    if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

      usersKey = new UsersKey();

      usersKey.userName = caseOwnerDetails.userName;

      caseOwnerDetails.orgObjectReferenceName = tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

    } else {
      caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.orgObjectReferenceName;
    }

    final LinkBuilder caseOwnerLinkBuilder = LinkBuilder.createLink(
      caseOwnerDetails.orgObjectReferenceName, CuramConst.gkCaseOwnerHomePage);

    caseOwnerLinkBuilder.openAsModal();
    caseOwnerLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      String.valueOf(caseOwnerDetails.userName));
    caseOwnerLinkBuilder.addParameter(
      CuramConst.gkPageParameterOrgObjectReference,
      String.valueOf(caseOwnerDetails.orgObjectReference));
    caseOwnerLinkBuilder.addParameter(CuramConst.gkPageParameterOrgObjectType,
      String.valueOf(caseOwnerDetails.orgObjectType));
    final LocalisableString caseOwnerTitle = new LocalisableString(
      BPOAUDITPLANTAB.INF_CASEOWNER_TITLE);

    caseOwnerLinkBuilder.addLinkTitle(caseOwnerTitle);

    caseOwnerContent.addEntry(2, 1, caseOwnerLinkBuilder, linkRendererConfig);

    extraDetailsContentDetail.addSingleListItem(caseOwnerContent,
      CuramConst.gkCaseAuditCaseOwnerTable);

    if (!details.caseAuditStatus.equals(CASEAUDITSTATUSEntry.COMPLETE.getCode())
      && !details.auditPlanEndDate.isZero()) {

      int numDays = 0;

      if (details.auditPlanEndDate.before(Date.getCurrentDate())) {

        final DateRange dateRange = new DateRange(details.auditPlanEndDate,
          Date.getCurrentDate());

        if (dateRange.isValidRange()) {
          numDays = dateRange.length();
        }

        final ImageBuilder endDatePassedImageBuilder = ImageBuilder.createImage(
          CuramConst.gkIconAtTimeLimitBlue, CuramConst.gkEmpty);

        endDatePassedImageBuilder.setImageResource(CuramConst.gkRendererImages);

        final String endDateAltText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

        endDatePassedImageBuilder.setImageAltText(endDateAltText);

        extraDetailsContentDetail.addImageItem(endDatePassedImageBuilder);

        final ListBuilder endDatePassed = ListBuilder.createHorizontalList(1);
        // BEGIN, 186068 - CC
        endDatePassed.setId(CuramConst.gkCaseAuditTimeLimitTable);
        // END, 186068 - CC
        endDatePassed.addRow();

        endDatePassed.addEntry(1, 1,
          new LocalisableString(BPOAUDITPLANTAB.INF_NUM_DAYS_EXCEEDED_BY).arg(
          numDays));

        extraDetailsContentDetail.addSingleListItem(endDatePassed,
          CuramConst.gkCaseAuditTimeLimitTable);

      } else if (details.auditPlanEndDate.after(Date.getCurrentDate())) {

        final DateRange dateRange = new DateRange(Date.getCurrentDate(),
          details.auditPlanEndDate);

        if (dateRange.isValidRange()) {
          numDays = dateRange.length();
        }

        final ImageBuilder endDateApproachingImageBuilder = ImageBuilder.createImage(
          CuramConst.gkIconGoodTimeBlue, CuramConst.gkEmpty);

        endDateApproachingImageBuilder.setImageResource(
          CuramConst.gkRendererImages);

        final String daysToCompleteAltText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

        endDateApproachingImageBuilder.setImageAltText(daysToCompleteAltText);

        extraDetailsContentDetail.addImageItem(endDateApproachingImageBuilder);

        final ListBuilder endDateApproaching = ListBuilder.createHorizontalList(
          1);
        // BEGIN, 186068 - CC
        endDateApproaching.setId(CuramConst.gkCaseAuditTimeLimitTable);
        // END, 186068 - CC
        endDateApproaching.addRow();

        endDateApproaching.addEntry(1, 1,
          new LocalisableString(BPOAUDITPLANTAB.INF_NUM_DAYS_TO_COMPLETE).arg(
          numDays));

        extraDetailsContentDetail.addSingleListItem(endDateApproaching,
          CuramConst.gkCaseAuditTimeLimitTable);
      } else if (details.auditPlanEndDate.equals(Date.getCurrentDate())) {

        final ImageBuilder endDateApproachingImageBuilder = ImageBuilder.createImage(
          CuramConst.gkIconGoodTimeBlue, CuramConst.gkEmpty);

        endDateApproachingImageBuilder.setImageResource(
          CuramConst.gkRendererImages);

        final String scheduledEndAltText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

        endDateApproachingImageBuilder.setImageAltText(scheduledEndAltText);

        extraDetailsContentDetail.addImageItem(endDateApproachingImageBuilder);

        final ListBuilder endDateApproaching = ListBuilder.createHorizontalList(
          1);
        
        // BEGIN, 186068 - CC
        endDateApproaching.setId(CuramConst.gkCaseAuditTimeLimitTable);
        // END, 186068 - CC
        endDateApproaching.addRow();

        endDateApproaching.addEntry(1, 1,
          new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULED_TO_END_TODAY));
        // END, CR00230776

        extraDetailsContentDetail.addSingleListItem(endDateApproaching,
          CuramConst.gkCaseAuditTimeLimitTable);
      }
    }
    extraDetailsContent.addWidgetItem(extraDetailsContentDetail,
      CuramConst.gkStyle, CuramConst.gkContentPanel);

    contentPanelBuilder.addWidgetItem(extraDetailsContent, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return contentPanelBuilder;
  }

  // ___________________________________________________________________________
  /**
   * Format XML data for a case audit focus areas chart.
   *
   * @param caseAuditTabDetails
   * The case audit tab details.
   *
   * @return ContentPanelBuilder.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ContentPanelBuilder getCaseAuditFocusAreasGraph(
    final CaseAuditTabDetails caseAuditTabDetails) throws AppException,
      InformationalException {

    final ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditReportDetails);

    contentPanelBuilder.addRoundedCorners();

    final ContentPanelBuilder focusAreasDetail = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditFocusAreasContentDetail);

    final HtmlHeaderBuilder htmlHeaderBuilder = HtmlHeaderBuilder.createHeader(
      3, CuramConst.gkCaseAuditFocusAreasTitle, null);

    htmlHeaderBuilder.addLocalizableHeaderItem(
      new LocalisableString(BPOCASEAUDITTAB.INF_NUM_FOCUS_AREAS).arg(caseAuditTabDetails.numFocusAreas).toClientFormattedText());

    focusAreasDetail.addWidgetItem(htmlHeaderBuilder, CuramConst.gkStyle,
      CuramConst.gkStyleHeader);

    contentPanelBuilder.addWidgetItem(focusAreasDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    final ContentPanelBuilder reportPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditChartContentPanel);

    // BEGIN, CR00223475, ELG
    final Map<String, String> reportParameters = new HashMap<String, String>();

    reportParameters.put(CuramConst.gkReportParameterCaseAuditID,
      String.valueOf(caseAuditTabDetails.caseAuditID));
    reportParameters.put(
      CuramConst.gkReportParameterFocusAreaSatisfiedTableName,
      FOCUSAREASATISFIEDEntry.TABLENAME);

    // BEGIN, CR00225043, GD
    final WidgetDocumentBuilder reportBuilder = biHelper.getDocumentBuilder(
      CuramConst.gkCaseAuditFocusAreasChart, reportParameters);

    // END, CR00225043
    // END, CR00223475

    reportPanel.addWidgetItem(reportBuilder, CuramConst.gkStyle,
      CuramConst.gkStyleBirt);

    contentPanelBuilder.addWidgetItem(reportPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return contentPanelBuilder;
  }

  // BEGIN, CR00229866, GD
  // ___________________________________________________________________________
  /**
   * Method used to pass parameters from one page to another.
   *
   * @param key The parameters to be passed.
   *
   * @return The parameters to be passed
   */
  @Override
  public CaseAuditListFilterKey getCaseAuditFilterKey(
    final CaseAuditListFilterKey key) throws AppException,
      InformationalException {

    return key;
  }

  // END, CR00229866

  // BEGIN, CR00298781, ZV
  // BEGIN, CR00229926, GD
  // ___________________________________________________________________________
  /**
   * Method to search for users with an auditor role or audit coordinator role.
   *
   * @param key The user search criteria.
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   * @deprecated - since 6.0 SP3
   * @deprecated This method is replaced by {@link #searchAuditorDetails()}.
   * This method is
   * deprecated because it was not allowing to do a search based on
   * the start date of a position.The userDetailsSearch method
   * considers the start date of a position also when doing a user
   * search for the active positions.See release note: <CR00215472>.
   */
  @Override
  @Deprecated
  public UserSearchDetails searchAuditors(final UserSearchKey key)
    throws AppException, InformationalException {

    // create an ordered set
    final Set<UserSearchDetailsRef> orderedUserList = new TreeSet<UserSearchDetailsRef>(
      new UserSearchDetailsRefComparator());

    final Organization organizationObj = OrganizationFactory.newInstance();

    // add all the audit coordinators to the ordered list
    key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
    final UserSearchDetails auditcoordinators = organizationObj.userSearch(key);

    orderedUserList.addAll(
      auditcoordinators.userSearchResultsList.userSearchDetailsRefList.dtls);

    // add all the auditors to the ordered list
    key.userSearchCriteria.criteria.roleName = CaseAuditConst.kAuditorUserRoleName;
    final UserSearchDetails auditors = organizationObj.userSearch(key);

    orderedUserList.addAll(
      auditors.userSearchResultsList.userSearchDetailsRefList.dtls);

    final UserSearchDetails result = new UserSearchDetails();

    // convert ordered list into return struct
    for (final UserSearchDetailsRef userSearchDetailsRef : orderedUserList) {
      result.userSearchResultsList.userSearchDetailsRefList.dtls.addRef(
        userSearchDetailsRef);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Method to search for users with an audit coordinator role.
   *
   * @param key The user search criteria.
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   * @deprecated - since 6.0 SP3
   * @deprecated This method is replaced by
   * {@link #searchAuditCoordinatorDetails()}. This method is
   * deprecated because it was not allowing to do a search based on
   * the start date of a position.The userDetailsSearch method
   * considers the start date of a position also when doing a user
   * search for the active positions.See release note: <CR00215472>.
   */
  @Override
  @Deprecated
  public UserSearchDetails searchAuditCoordinators(final UserSearchKey key)
    throws AppException, InformationalException {

    // create an ordered set
    final Set<UserSearchDetailsRef> orderedUserList = new TreeSet<UserSearchDetailsRef>(
      new UserSearchDetailsRefComparator());

    final Organization organizationObj = OrganizationFactory.newInstance();

    // add all the audit coordinators to the list
    key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
    final UserSearchDetails auditcoordinators = organizationObj.userSearch(key);

    orderedUserList.addAll(
      auditcoordinators.userSearchResultsList.userSearchDetailsRefList.dtls);

    final UserSearchDetails result = new UserSearchDetails();

    // convert ordered list into return struct
    for (final UserSearchDetailsRef userSearchDetailsRef : orderedUserList) {
      result.userSearchResultsList.userSearchDetailsRefList.dtls.addRef(
        userSearchDetailsRef);
    }
    return result;
  }

  // END, CR00229926
  // END, CR00298781

  // BEGIN, CR00290965, IBM
  /**
   * Searches for specific cases for audit or to create case audit records
   * for cases selected.
   *
   * @param caseSelectSearchCriteria contains case select search details
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList selectOrCreateCaseAuditDetails(
    final CaseSelectSearchCriteria caseSelectSearchCriteria)
    throws AppException, InformationalException {

    CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    if (ClientActionConst.kSelectActionID.equals(
      caseSelectSearchCriteria.actionIDProperty)) {

      final AuditPlan auditPlan = auditPlanDAO.get(
        caseSelectSearchCriteria.auditPlanID);

      // In the case of regeneration, remove selection criteria
      auditPlan.clearSelectionCriteria();

      final CaseAuditDetails caseAuditDetails = new CaseAuditDetails();

      caseAuditDetails.dtls.auditPlanID = caseSelectSearchCriteria.auditPlanID;

      String tabList = new String();

      tabList = caseSelectSearchCriteria.caseIDList;

      // String list of Case IDs
      final StringList caseIDList = StringUtil.tabText2StringList(tabList);

      for (final String caseID : caseIDList.items()) {

        caseAuditDetails.dtls.caseID = Long.parseLong(caseID);
        createCaseAudit(caseAuditDetails);
      }

      auditPlan.setCasesUserSelected(true);
      auditPlan.setNumberCases(CuramConst.gkZero);
      auditPlan.setPercentageCases(CuramConst.gkDoubleZero);
      auditPlan.modify(auditPlan.getVersionNo());

    } else if (ClientActionConst.kSearchActionID.equals(
      caseSelectSearchCriteria.actionIDProperty)) {

      caseSearchDetailsList = selectSpecificCaseForAuditDetails(
        caseSelectSearchCriteria);

    } else if (ClientActionConst.kFinish.equals(
      caseSelectSearchCriteria.actionIDProperty)) {

      final AuditPlanKey auditPlanKey = new AuditPlanKey();

      auditPlanKey.auditPlanID = caseSelectSearchCriteria.auditPlanID;
      markManuallySelected(auditPlanKey);
    }

    collectInformationalMsgs(caseSearchDetailsList.informationalMsgDtls);

    return caseSearchDetailsList;
  }

  /**
   * Retrieve specific cases for audit selected by case reference, client
   * reference
   * or client name. Called during processing when an audit coordinator user is
   * creating a list of cases to be audited as part of an audit plan.
   *
   * @param caseSelectSearchCriteria contains case select search details
   *
   * @return case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public CaseSearchDetailsList selectSpecificCaseForAuditDetails(
    final CaseSelectSearchCriteria caseSelectSearchCriteria)
    throws AppException, InformationalException {

    final CaseSearchDetailsList caseSearchDetailsList = new CaseSearchDetailsList();

    validateCaseSelectCriteria(caseSelectSearchCriteria);

    List<CaseHeader> caseHeaderList = new ArrayList<CaseHeader>();

    final AuditPlan auditPlan = auditPlanDAO.get(
      caseSelectSearchCriteria.auditPlanID);
    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      auditPlan.getAuditCaseConfig().getID());

    caseHeaderList = caseHeaderDAO.searchSpecificCase(
      caseSelectSearchCriteria.caseReference,
      caseSelectSearchCriteria.concernRoleID,
      caseSelectSearchCriteria.alternateIDType,
      caseSelectSearchCriteria.primaryAlternateID,
      CASETYPECODEEntry.get(auditCaseConfigObj.getCaseType().getCode()),
      CASECATTYPECODEEntry.get(auditCaseConfigObj.getCaseCategory().getCode()));

    for (final CaseHeader caseHeader : caseHeaderList) {

      final CaseSearchDetails1 caseSearchDetails1 = new CaseSearchDetails1();

      final List<curam.caseaudit.impl.CaseAudit> results = caseAuditDAO.searchByAuditPlanAndCase(
        auditPlan, caseHeader);

      if (results.isEmpty()) {
        caseSearchDetails1.caseID = caseHeader.getID();
        caseSearchDetails1.caseReference = caseHeader.getCaseReference();
        caseSearchDetails1.concernRoleID = caseHeader.getConcernRole().getID();
        caseSearchDetails1.startDate = caseHeader.getStartDate();
        caseSearchDetails1.statusCode = caseHeader.getStatus().getCode();

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

        concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
        caseSearchDetails1.concernRoleName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

        caseSearchDetailsList.listDtls.searchDtls.addRef(caseSearchDetails1);
      }
    }

    collectInformationalMsgs(caseSearchDetailsList.informationalMsgDtls);

    return caseSearchDetailsList;
  }

  /**
   * Searches for an all case audits on the system by provided search criteria.
   *
   * @param searchAllCaseAuditsKey contains all case audits search key
   *
   * @return all case search details list
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public SearchAllCaseAuditsDetailsList searchAllCaseAuditsDetails(
    final SearchAllCaseAuditsKey searchAllCaseAuditsKey) throws AppException,
      InformationalException {

    final SearchAllCaseAuditsDetailsList searchAllCaseAuditsDetailsList = new SearchAllCaseAuditsDetailsList();

    final UserAccess userAccess = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRole concernRole = ConcernRoleFactory.newInstance();

    AuditCaseConfig auditCaseConfig = null;

    if (0 != searchAllCaseAuditsKey.auditCaseConfig) {
      auditCaseConfig = auditCaseConfigDAO.get(
        searchAllCaseAuditsKey.auditCaseConfig);
    }

    final List<curam.caseaudit.impl.CaseAudit> caseAuditList = caseAuditDAO.searchAllCaseAudits(
      searchAllCaseAuditsKey.auditPlanReference,
      searchAllCaseAuditsKey.caseAuditReference, auditCaseConfig,
      CASEAUDITSTATUSEntry.get(searchAllCaseAuditsKey.caseAuditStatus),
      searchAllCaseAuditsKey.auditor, searchAllCaseAuditsKey.coordinator);

    for (final curam.caseaudit.impl.CaseAudit caseAudit : caseAuditList) {

      final SearchAllCaseAuditsResult result = new SearchAllCaseAuditsResult();

      result.caseAuditID = caseAudit.getID();
      result.caseAuditStatus = caseAudit.getLifecycleState().getCode();

      final AuditPlan auditPlanObj = caseAudit.getAuditPlan();

      final String caseAuditName = CodeTable.getOneItemForUserLocale(
        CASECATTYPECODE.TABLENAME,
        auditPlanObj.getAuditCaseConfig().getCaseCategory().getCode());
      final String caseAuditReference = caseAudit.getCaseAuditReference();

      result.planNameCaseAuditRef = caseAuditName + CuramConst.kSeparator
        + caseAuditReference;
      final Auditor auditorObj = caseAudit.getAuditor();

      if (0 != auditorObj.getID()) {
        result.auditorName = auditorObj.getName();
      }

      usersKey = new UsersKey();
      usersKey.userName = auditPlanObj.getCoordinator();

      result.coordinatorFullName = userAccess.getFullName(usersKey).fullname;

      final CaseHeader caseHeader = caseAudit.getCase();

      concernRoleKey.concernRoleID = caseHeader.getConcernRole().getID();
      result.clientFullName = concernRole.readConcernRoleName(concernRoleKey).concernRoleName;

      searchAllCaseAuditsDetailsList.dtls.addRef(result);
    }

    collectInformationalMsgs(
      searchAllCaseAuditsDetailsList.informationalMsgDtls);

    return searchAllCaseAuditsDetailsList;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList msgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00290965

  // BEGIN, CR00298781, ZV
  // ___________________________________________________________________________
  /**
   * Method to search for users with an auditor role or audit coordinator role.
   *
   * @param key The user search criteria.
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public SearchUserDetails searchAuditorDetails(UserSearchKey key)
    throws AppException, InformationalException {

    // create an ordered set
    final Set<UserSearchDetailsReference> orderedUserList = new TreeSet<UserSearchDetailsReference>(
      new UserSearchDetailsReferenceComparator());

    final Organization organizationObj = OrganizationFactory.newInstance();

    // BEGIN, CR00385977, KRK
    if (isUserRoleRestricted) {

      // Add all the audit coordinators to the ordered list.
      key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
      final SearchUserDetails auditcoordinators = organizationObj.searchUserDetails(
        key);

      orderedUserList.addAll(
        auditcoordinators.dtls.dtls.userSearchDetailsReferenceList);

      // Add all the auditors to the ordered list.
      key.userSearchCriteria.criteria.roleName = CaseAuditConst.kAuditorUserRoleName;
      final SearchUserDetails auditors = organizationObj.searchUserDetails(key);

      orderedUserList.addAll(auditors.dtls.dtls.userSearchDetailsReferenceList);
    } else {

      final SearchUserDetails searchUserDetails = organizationObj.searchUserDetails(
        key);

      orderedUserList.addAll(
        searchUserDetails.dtls.dtls.userSearchDetailsReferenceList);
    }
    // END, CR00385977

    final SearchUserDetails result = new SearchUserDetails();

    // convert ordered list into return struct
    for (final UserSearchDetailsReference userSearchDetailsRef : orderedUserList) {
      result.dtls.dtls.userSearchDetailsReferenceList.addRef(
        userSearchDetailsRef);
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Method to search for users with an audit coordinator role.
   *
   * @param key The user search criteria.
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public SearchUserDetails searchAuditCoordinatorDetails(UserSearchKey key)
    throws AppException, InformationalException {

    // create an ordered set
    final Set<UserSearchDetailsReference> orderedUserList = new TreeSet<UserSearchDetailsReference>(
      new UserSearchDetailsReferenceComparator());

    final Organization organizationObj = OrganizationFactory.newInstance();

    // BEGIN, CR00385977, KRK
    if (isUserRoleRestricted) {
      key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
    }
    final SearchUserDetails searchUserDetails = organizationObj.searchUserDetails(
      key);

    orderedUserList.addAll(
      searchUserDetails.dtls.dtls.userSearchDetailsReferenceList);
    // END, CR00385977

    final SearchUserDetails result = new SearchUserDetails();

    // convert ordered list into return struct
    for (final UserSearchDetailsReference userSearchDetailsRef : orderedUserList) {
      result.dtls.dtls.userSearchDetailsReferenceList.addRef(
        userSearchDetailsRef);
    }
    return result;
  }
  // END, CR00298781
}
