/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.CaseAuditFeedbackKey;
import curam.caseaudit.entity.struct.CaseAuditKey;
import curam.caseaudit.entity.struct.FocusAreaFindingKey;
import curam.caseaudit.entity.struct.FocusAreaStats;
import curam.caseaudit.entity.struct.FocusAreaStatsDetails;
import curam.caseaudit.entity.struct.FocusAreaStatsList;
import curam.caseaudit.impl.AuditCaseFocusArea;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.AuditPlanFocusArea;
import curam.caseaudit.impl.AuditPlanFocusAreaDAO;
import curam.caseaudit.impl.CaseAudit;
import curam.caseaudit.impl.CaseAuditConst;
import curam.caseaudit.impl.CaseAuditDAO;
import curam.caseaudit.impl.CaseAuditFeedback;
import curam.caseaudit.impl.CaseAuditFeedbackDAO;
import curam.caseaudit.impl.FocusAreaFinding;
import curam.caseaudit.impl.FocusAreaFindingDAO;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.AUDITCASEFOCUSAREA;
import curam.codetable.AUDITPLANSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.CaseAuditAndFocusAreaFindings;
import curam.core.facade.struct.CaseAuditAndVersionKey;
import curam.core.facade.struct.CaseAuditAttachmentDetails;
import curam.core.facade.struct.CaseAuditAttachmentDetailsList;
import curam.core.facade.struct.CaseAuditFindingModifyDetails;
import curam.core.facade.struct.CaseAuditFindingReadDetails;
import curam.core.facade.struct.FeedbackListDetails;
import curam.core.facade.struct.FeedbackListDetailsList;
import curam.core.facade.struct.FocusArea;
import curam.core.facade.struct.FocusAreaFindingListDetails;
import curam.core.facade.struct.FocusAreaFindingModifyDetails;
import curam.core.facade.struct.FocusAreaFindingReadDetails;
import curam.core.facade.struct.FocusAreaList;
import curam.core.facade.struct.ModifyAuditPlanFocusAreaDetails;
import curam.core.facade.struct.ModifyFeedbackDetails;
import curam.core.facade.struct.ReadFeedbackDetails;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.AttachmentFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserDetails;
import curam.core.struct.UsersKey;
import curam.message.ENTAUDITPLAN;
import curam.message.FACADECASEAUDIT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;


public abstract class CaseAuditFindings extends curam.core.facade.base.CaseAuditFindings {

  /**
   * The add focus areas page URL.
   */
  protected static final String kAddFocusAreas = UimConst.kAddFocusAreas;

  /**
   * The audit plan homepage URL.
   */
  protected static final String kAuditPlanHome = UimConst.kAuditPlanHome;

  /**
   * The list focus areas page URL.
   */
  protected static final String kListFocusAreas = UimConst.kListFocusAreas;

  /**
   * The modify focus areas page URL.
   */
  protected static final String kModifyFocusAreas = UimConst.kModifyFocusAreas;

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  @Inject
  protected FocusAreaFindingDAO focusAreaFindingDAO;

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected CaseAuditFeedbackDAO caseAuditFeedbackDAO;

  @Inject
  protected AuditPlanFocusAreaDAO auditPlanFocusAreaDAO;

  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00354960

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public CaseAuditFindings() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * FocusAreaText Comparator.
   */
  public class FocusAreaTextComparator implements Comparator<FocusAreaStats> {

    /**
     * Constructor.
     */
    public FocusAreaTextComparator() {

      super();
    }

    /**
     * Method to compare two FocusAreaStats.
     *
     * @param o1 A FocusAreaStats object.
     * @param o2 Another FocusAreaStats object.
     *
     * @return The comparison result.
     */
    @Override
    public int compare(final FocusAreaStats o1, final FocusAreaStats o2) {

      return o1.focusAreaText.compareTo(o2.focusAreaText);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to add an Attachment to a Focus Area Finding.
   *
   * @param details Contains the allegation id and attachment details
   *
   * @return The Attachment Link key
   */
  @Override
  public AttachmentLinkKey createFocusAreaFindingsAttachment(
    final AttachmentLinkDetails details) throws AppException,
      InformationalException {

    final AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.FOCUSAREAFINDING;
    details.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

    // BEGIN, CR00354960, CD
    // add the case reference as meta data for the attachment
    final FocusAreaFinding focusAreaFinding = focusAreaFindingDAO.get(
      details.attachmentLinkDtls.relatedObjectID);
    final String caseReference = focusAreaFinding.getCaseAudit().getCase().getCaseReference();
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseReference, caseReference);
    // END, CR00354960

    final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

    attachmentLinkKey.attachmentLinkID = attachmentLink.insert(details);

    return attachmentLinkKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all attachments for the specified case audit.
   *
   * @param key
   * ID of the case audit
   *
   * @return List of attachment details
   */
  @Override
  public CaseAuditAttachmentDetailsList listAttachmentsByCaseAudit(
    final CaseAuditKey key) throws AppException, InformationalException {

    // return struct
    final CaseAuditAttachmentDetailsList caseAuditAttachmentDetailsList = new CaseAuditAttachmentDetailsList();

    final CaseAudit caseAuditObj = caseAuditDAO.get(key.caseAuditID);

    final List<FocusAreaFinding> focusAreaFindingList = caseAuditObj.getFocusAreaFindings();

    for (final FocusAreaFinding focusAreaFinding : focusAreaFindingList) {

      // see if there is an attachment for this focus area finding
      final List<AttachmentLink> attachmentLinkList = attachmentLinkDAO.searchByRelatedIDAndType(
        focusAreaFinding.getID(),
        ATTACHMENTOBJECTLINKTYPEEntry.FOCUSAREAFINDING);

      final curam.core.sl.intf.Attachment attachmentObj = AttachmentFactory.newInstance();

      final AttachmentKey attachmentKey = new AttachmentKey();

      for (int i = 0; i < attachmentLinkList.size(); i++) {

        final CaseAuditAttachmentDetails caseAuditAttachmentDetails = new CaseAuditAttachmentDetails();

        final AttachmentLink attachmentLinkObj = attachmentLinkList.get(i);

        caseAuditAttachmentDetails.attachmentID = attachmentLinkObj.getAttachmentID();
        caseAuditAttachmentDetails.attachmentLinkID = attachmentLinkObj.getID();
        caseAuditAttachmentDetails.versionNo = attachmentLinkObj.getVersionNo();

        attachmentKey.attachmentID = caseAuditAttachmentDetails.attachmentID;

        final AttachmentDtls attachmentDtls = attachmentObj.readAttachment(
          attachmentKey);

        if (!attachmentDtls.statusCode.equals(
          RECORDSTATUSEntry.CANCELLED.getCode())) {
          caseAuditAttachmentDetails.attachmentStatus = attachmentDtls.attachmentStatus;
          caseAuditAttachmentDetails.statusCode = attachmentDtls.statusCode;
          caseAuditAttachmentDetails.receiptDate = attachmentDtls.receiptDate;

          String description = attachmentLinkObj.getDescription();

          // Truncate the description to 40 chars and append an ellipsis
          if (description.length() > 40) {
            description = description.substring(0, 40) + CuramConst.kEllipsis;
          }

          caseAuditAttachmentDetails.description = description;
          caseAuditAttachmentDetails.focusAreaCode = focusAreaFinding.getAuditPlanFocusArea().getFocusArea().getCode();

          caseAuditAttachmentDetails.attachmentFileName = attachmentDtls.attachmentName;

          caseAuditAttachmentDetailsList.dtls.addRef(caseAuditAttachmentDetails);
        }
      }
    }

    return caseAuditAttachmentDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify a Focus Area Finding record.
   *
   * @param details Details of the Focus Area Finding record to modify
   */
  @Override
  public void modifyFocusAreaFinding(
    final FocusAreaFindingModifyDetails details) throws AppException,
      InformationalException {

    final FocusAreaFinding focusAreaFinding = focusAreaFindingDAO.get(
      details.focusAreaFindingID);

    focusAreaFinding.setFocusAreaSatisfied(
      FOCUSAREASATISFIEDEntry.get(details.focusAreaSatisfied));
    // BEGIN, CR00221556, GD
    focusAreaFinding.setFindingsText(details.findingsText);
    // END, CR00221556

    focusAreaFinding.modify(details.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to read a Focus Area Finding record for display.
   *
   * @param key ID of the Focus Area Finding record to read
   *
   * @return Details of the Focus Area Finding for display
   */
  @Override
  public FocusAreaFindingReadDetails viewFocusAreaFinding(
    final FocusAreaFindingKey key) throws AppException,
      InformationalException {

    // return struct
    final FocusAreaFindingReadDetails focusAreaFindingReadDetails = new FocusAreaFindingReadDetails();

    final FocusAreaFinding focusAreaFinding = focusAreaFindingDAO.get(
      key.focusAreaFindingID);

    focusAreaFindingReadDetails.focusAreaFindingID = focusAreaFinding.getID();
    focusAreaFindingReadDetails.caseAuditID = focusAreaFinding.getCaseAudit().getID();

    final AuditPlanFocusArea auditPlanFocusArea = focusAreaFinding.getAuditPlanFocusArea();

    focusAreaFindingReadDetails.auditPlanFocusAreaID = auditPlanFocusArea.getID();

    focusAreaFindingReadDetails.focusAreaText = CodeTable.getOneItemForUserLocale(
      AUDITCASEFOCUSAREA.TABLENAME, auditPlanFocusArea.getFocusArea().getCode());

    // BEGIN, CR00221556, GD
    focusAreaFindingReadDetails.findingsText = focusAreaFinding.getFindingsText();
    // END, CR00221556
    if (StringHelper.isEmpty(focusAreaFindingReadDetails.findingsText)) {
      focusAreaFindingReadDetails.noFindingsYetInd = true;
    } else {
      focusAreaFindingReadDetails.noFindingsYetInd = false;
    }
    focusAreaFindingReadDetails.focusAreaSatisfied = focusAreaFinding.getFocusAreaSatisfied().getCode();
    focusAreaFindingReadDetails.versionNo = focusAreaFinding.getVersionNo();

    return focusAreaFindingReadDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to complete the case audit findings. This causes the audit to
   * transition to either 'Complete' or 'Awaiting Feedback' depending on the
   * configuration of the audit plan. Appropriate feedback tasks are also
   * created for the case owner and supervisor if required.
   *
   * @param key ID of the case audit record.
   */
  @Override
  public void completeCaseAuditFindings(final CaseAuditAndVersionKey key)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    caseAuditObj.completeFindings(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the findings on a case audit.
   *
   * @param details Details of the modified findings
   */
  @Override
  public void modifyCaseAuditFinding(
    final CaseAuditFindingModifyDetails details) throws AppException,
      InformationalException {

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      details.caseAuditID);

    // BEGIN, CR00221556, GD
    caseAuditObj.setCaseAuditFindings(details.findingsText);
    // END, CR00221556

    caseAuditObj.modify(details.versionNo);
  }

  // BEGIN, CR00320581, MV
  /**
   * Method to read the details of a case using case audit ID.
   *
   * @param key
   * ID of the case audit.
   *
   * @return Details of the case.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  @Override
  public CaseHeaderDtls readCaseHeaderAuditFeedBack(final CaseAuditKey key)
    throws AppException, InformationalException {

    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();
    final CaseAudit caseAuditObj = caseAuditDAO.get(key.caseAuditID);
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeaderDetails = caseAuditObj.getCase();

    caseHeaderDtls.caseID = caseHeaderDetails.getID();
    caseHeaderDtls.caseReference = caseHeaderDetails.getCaseReference();
    caseHeaderDtls.caseTypeCode = caseHeaderDetails.getCaseType().getCode();
    return caseHeaderDtls;
  }

  // END, CR00320581

  // ___________________________________________________________________________
  /**
   * Method to read the findings for a case audit.
   *
   * @param key ID of the case audit
   *
   * @return Details of the case audit findings
   */
  @Override
  public CaseAuditFindingReadDetails readCaseAuditFinding(
    final CaseAuditKey key) throws AppException, InformationalException {

    // return struct
    final CaseAuditFindingReadDetails caseAuditFindingReadDetails = new CaseAuditFindingReadDetails();

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    caseAuditFindingReadDetails.caseAuditID = caseAuditObj.getID();
    caseAuditFindingReadDetails.versionNo = caseAuditObj.getVersionNo();
    caseAuditFindingReadDetails.caseAuditReference = caseAuditObj.getCaseAuditReference();

    // BEGIN, CR00221556, GD
    caseAuditFindingReadDetails.findingsText = caseAuditObj.getCaseAuditFindings();

    if (StringHelper.isEmpty(caseAuditFindingReadDetails.findingsText)) {
      caseAuditFindingReadDetails.noFindingsYetInd = true;
    } else {
      caseAuditFindingReadDetails.noFindingsYetInd = false;
    }
    // END, CR00221556

    return caseAuditFindingReadDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the feedback provided on a case audit.
   *
   * @param details Details of the feedback to modify
   */
  @Override
  public void modifyCaseAuditFeedback(final ModifyFeedbackDetails details)
    throws AppException, InformationalException {

    final CaseAuditFeedback caseAuditFeedback = caseAuditFeedbackDAO.get(
      details.feedbackID);

    // Check if user has indicated feedback completion
    if (details.actionIDProperty.equals(ClientActionConst.kSaveAndComplete)) {
      details.feedbackCompleteInd = true;
      caseAuditFeedback.setFeedbackComplete(details.feedbackCompleteInd);
    } else if (details.actionIDProperty.equals(ClientActionConst.kSave)) {
      details.feedbackCompleteInd = false;
    }

    // BEGIN, CR00221556, GD
    caseAuditFeedback.setFeedbackText(details.feedbackText);
    // END, CR00221556
    caseAuditFeedback.modify(details.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to read feedback entered for a case audit.
   *
   * @param key details of the feedback to read
   *
   * @return Details for display on the feedback page
   */
  @Override
  public ReadFeedbackDetails readCaseAuditFeedback(
    final CaseAuditFeedbackKey key) throws AppException,
      InformationalException {

    final ReadFeedbackDetails readFeedbackDetails = new ReadFeedbackDetails();

    final CaseAuditKey caseAuditKey = new CaseAuditKey();

    final CaseAuditFeedback caseAuditFeedbackObj = caseAuditFeedbackDAO.get(
      key.feedbackID);

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditFeedbackObj.getCaseAudit();

    readFeedbackDetails.feedbackID = caseAuditFeedbackObj.getID();
    readFeedbackDetails.versionNo = caseAuditFeedbackObj.getVersionNo();
    readFeedbackDetails.feedbackCompleteInd = caseAuditFeedbackObj.isFeedbackComplete();
    // BEGIN, CR00221556, GD
    readFeedbackDetails.feedbackText = caseAuditFeedbackObj.getFeedbackText();

    // BEGIN, CR00230760, GD
    readFeedbackDetails.username = caseAuditFeedbackObj.getUsername();
    // END, CR00230760, GD

    if (StringHelper.isEmpty(readFeedbackDetails.feedbackText)) {
      readFeedbackDetails.noFeedbackYetInd = true;
    } else {
      readFeedbackDetails.noFeedbackYetInd = false;
    }
    // END, CR00221556

    readFeedbackDetails.caseAuditID = caseAuditObj.getID();
    readFeedbackDetails.caseAuditReference = caseAuditObj.getCaseAuditReference();

    final List<FocusAreaFinding> focusAreaFindingList = caseAuditObj.getFocusAreaFindings();

    for (final FocusAreaFinding focusAreaFinding : focusAreaFindingList) {

      final FocusAreaFindingListDetails focusAreaFindingListDetails = new FocusAreaFindingListDetails();

      focusAreaFindingListDetails.focusAreaFindingID = focusAreaFinding.getID();
      focusAreaFindingListDetails.caseAuditID = focusAreaFinding.getCaseAudit().getID();

      final AuditPlanFocusArea auditPlanFocusArea = focusAreaFinding.getAuditPlanFocusArea();

      focusAreaFindingListDetails.auditPlanFocusAreaID = auditPlanFocusArea.getID();

      focusAreaFindingListDetails.focusAreaText = CodeTable.getOneItemForUserLocale(
        AUDITCASEFOCUSAREA.TABLENAME,
        auditPlanFocusArea.getFocusArea().getCode());

      focusAreaFindingListDetails.focusAreaSatisfied = focusAreaFinding.getFocusAreaSatisfied().getCode();

      readFeedbackDetails.focusAreaFindings.dtls.addRef(
        focusAreaFindingListDetails);
    }

    // Add Case Audit Findings details to the return struct
    caseAuditKey.caseAuditID = readFeedbackDetails.caseAuditID;
    readFeedbackDetails.caseAuditFindings = readCaseAuditFinding(caseAuditKey);

    return readFeedbackDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve all focus areas for a particular audit plan.
   *
   * @param key ID of the Audit Plan
   *
   * @return List of configured focus areas
   */
  @Override
  public FocusAreaList getConfiguredFocusAreas(final AuditPlanKey key)
    throws AppException, InformationalException {

    final FocusAreaList focusAreaList = new FocusAreaList();

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    final Set<AuditCaseFocusArea> focusAreas = auditPlanObj.getAuditCaseConfig().getSelectedFocusAreas();

    for (final AuditCaseFocusArea auditCaseFocusArea : focusAreas) {

      final FocusArea focusArea = new FocusArea();

      focusArea.focusAreaCode = auditCaseFocusArea.getFocusArea().getCode();
      focusAreaList.focusAreas.addRef(focusArea);
    }

    return focusAreaList;
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve all focus areas configured or selected for a particular
   * audit plan. (This does not include user defined focus areas)
   *
   * @param key ID of the Audit Plan
   *
   * @return List of selected/configured focus areas
   */
  @Override
  public FocusAreaList getSelectedConfiguredFocusAreas(final AuditPlanKey key)
    throws AppException, InformationalException {

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    final FocusAreaList focusAreaList = getConfiguredFocusAreas(key);

    final List<AuditPlanFocusArea> selectedAlready = auditPlanObj.getSelectedFocusAreas();

    final StringBuffer sbuf = new StringBuffer();

    for (final AuditPlanFocusArea auditPlanFocusArea : selectedAlready) {
      sbuf.append(auditPlanFocusArea.getFocusArea().getCode() + "\t");
    }

    if (sbuf.length() > 0) {
      focusAreaList.selectedFocusAreas = sbuf.substring(0, sbuf.length() - 1);
    }

    return focusAreaList;
  }

  // ___________________________________________________________________________
  /**
   * Method to update which focus areas are selected for a particular audit
   * plan.
   *
   * @param details The Audit Plan and the list of selected focus areas.
   */
  @Override
  public void modifyAuditPlanFocusAreas(
    final ModifyAuditPlanFocusAreaDetails details) throws AppException,
      InformationalException {

    final AuditPlanKey auditPlanKey = new AuditPlanKey();

    auditPlanKey.auditPlanID = details.auditPlanID;

    validateManageFocusAreas(auditPlanKey);

    AuditPlanFocusArea auditPlanFocusAreaObj;

    final AuditPlan auditPlanObj = auditPlanDAO.get(details.auditPlanID);

    final List<AuditPlanFocusArea> selectedAlready = auditPlanObj.getSelectedFocusAreas();

    final StringList newFocusAreas = StringUtil.tabText2StringList(
      details.selectedFocusAreas);
    final int newFocusAreasSize = newFocusAreas.size();

    // go through the old ones and if there are any missing from
    // the new list, remove them
    for (final AuditPlanFocusArea oldFocusArea : selectedAlready) {

      boolean remove = true;

      for (int i = 0; i < newFocusAreasSize; i++) {
        final String newFocusArea = newFocusAreas.item(i);

        if (oldFocusArea.getFocusArea().equals(newFocusArea)) {
          remove = false;
        }
      }

      if (remove) {
        oldFocusArea.remove();
      }
    }

    // go through the new list and if there are any not
    // in the old list, add them
    for (int i = 0; i < newFocusAreasSize; i++) {

      final String newFocusArea = newFocusAreas.item(i);

      boolean add = true;

      for (final AuditPlanFocusArea oldFocusArea : selectedAlready) {
        if (oldFocusArea.getFocusArea().equals(newFocusArea)) {
          add = false;
        }
      }

      if (add) {
        auditPlanFocusAreaObj = auditPlanFocusAreaDAO.newInstance();
        auditPlanFocusAreaObj.setAuditPlan(auditPlanObj);
        auditPlanFocusAreaObj.setFocusArea(
          AUDITCASEFOCUSAREAEntry.get(newFocusArea));
        auditPlanFocusAreaObj.insert();
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to validate changing the focus areas associated with an audit plan.
   *
   * @param key The unique ID of the audit plan
   */
  @Override
  protected void validateManageFocusAreas(final AuditPlanKey key)
    throws InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    // ensure that the audit plan is still active
    if (auditPlanObj.getRecordStatus().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(ENTAUDITPLAN.ERR_RV_CANNOT_MODIFY_CANCELLED_AUDIT_PLAN),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      informationalManager.failOperation();
    }

    // ensure that the audit plan is still pending
    if (!auditPlanObj.getLifecycleState().getCode().equals(
      AUDITPLANSTATUS.PENDING)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_FV_CANNOT_MODIFY_AUDIT_PLAN_FOCUS_AREAS),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to read the case audit findings and focus area findings
   * for the specified case audit.
   *
   * @param key The ID of the case audit
   *
   * @return Details of the case audit and focus area findings
   */
  @Override
  public CaseAuditAndFocusAreaFindings readCaseAuditAndFocusAreaFindings(
    final CaseAuditKey key) throws AppException, InformationalException {

    final CaseAuditAndFocusAreaFindings caseAuditAndFocusAreaFindings = new CaseAuditAndFocusAreaFindings();

    // Read the case audit findings
    caseAuditAndFocusAreaFindings.caseAuditFindings = readCaseAuditFinding(key);

    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    // Get the list of focus areas and their findings
    final List<FocusAreaFinding> focusAreaFindingList = caseAuditObj.getFocusAreaFindings();

    for (final FocusAreaFinding focusAreaFinding : focusAreaFindingList) {

      final FocusAreaFindingListDetails focusAreaFindingListDetails = new FocusAreaFindingListDetails();

      focusAreaFindingListDetails.focusAreaFindingID = focusAreaFinding.getID();
      focusAreaFindingListDetails.caseAuditID = focusAreaFinding.getCaseAudit().getID();

      final AuditPlanFocusArea auditPlanFocusArea = focusAreaFinding.getAuditPlanFocusArea();

      focusAreaFindingListDetails.auditPlanFocusAreaID = auditPlanFocusArea.getID();

      focusAreaFindingListDetails.focusAreaText = CodeTable.getOneItemForUserLocale(
        AUDITCASEFOCUSAREA.TABLENAME,
        auditPlanFocusArea.getFocusArea().getCode());

      focusAreaFindingListDetails.focusAreaSatisfied = focusAreaFinding.getFocusAreaSatisfied().getCode();

      caseAuditAndFocusAreaFindings.focusAreaFindings.dtls.addRef(
        focusAreaFindingListDetails);
    }

    return caseAuditAndFocusAreaFindings;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Lists all the Focus Areas on an Audit Plan displaying how many case audits
   * on the audit plan.
   * a) met the focus area
   * b) did not meet the focus area
   * c) have not yet been examined
   *
   * @param key ID of the audit plan
   *
   * @return the statistics on the focus areas.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link CaseAuditFindings#listAuditPlanFocusAreaStatsDetails(AuditPlanKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by listAuditPlanFocusAreaStatsDetails(AuditPlanKey)
   * which returns the informational message along with focus areas on an audit
   * plan details as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public FocusAreaStatsList listAuditPlanFocusAreaStats(final AuditPlanKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    final AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    final Comparator<FocusAreaStats> focusAreaTextComparator = new FocusAreaTextComparator();

    final FocusAreaStatsList focusAreaStatsList = auditPlanObj.listFocusAreaStats();

    Collections.sort(focusAreaStatsList.dtls, focusAreaTextComparator);

    return focusAreaStatsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve the list of feedback details for a case audit.
   *
   * @param key Contains the case audit identifier.
   *
   * @return The list of feedback details.
   */
  @Override
  public FeedbackListDetailsList readCaseAuditFeedbackList(
    final CaseAuditKey key) throws AppException, InformationalException {

    final FeedbackListDetailsList feedbackListDetailsList = new FeedbackListDetailsList();
    final curam.caseaudit.impl.CaseAudit caseAuditObj = caseAuditDAO.get(
      key.caseAuditID);

    final List<CaseAuditFeedback> feedbackList = caseAuditFeedbackDAO.searchByCaseAudit(
      caseAuditObj);

    for (final CaseAuditFeedback feedback : feedbackList) {

      final FeedbackListDetails feedbackListDetails = new FeedbackListDetails();

      feedbackListDetails.feedbackID = feedback.getID();
      feedbackListDetails.caseAuditReference = caseAuditObj.getCaseAuditReference();

      feedbackListDetails.noFeedbackYetInd = feedback.isFeedbackComplete();
      if (feedbackListDetails.noFeedbackYetInd) {
        feedbackListDetails.feedbackComplete = CaseAuditConst.kYes;
      } else {
        feedbackListDetails.feedbackComplete = CaseAuditConst.kNo;
      }

      feedbackListDetails.username = feedback.getUsername();

      // Look up the user role for the user that provided the feedback
      final UsersKey usersKey = new UsersKey();
      final UserAccess userAccessObj = UserAccessFactory.newInstance();

      usersKey.userName = feedback.getUsername();

      // BEGIN, CR00230760, GD
      final UserDetails userDetails = userAccessObj.getUserDetails(usersKey);
      final String roleName = userDetails.roleName;

      feedbackListDetails.userFullName = userDetails.fullName;
      feedbackListDetails.userRole = roleName;
      // END, CR00230760

      feedbackListDetailsList.list.addRef(feedbackListDetails);
    }
    return feedbackListDetailsList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Lists all the focus areas on an audit plan displaying how many case audits
   * on the audit plan.
   * (a) met the focus area
   * (b) did not meet the focus area and
   * (c) have not yet been examined.
   *
   * @param auditPlanKey contains audit plan key
   *
   * @return the statistics on the focus areas details.
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  @Override
  public FocusAreaStatsDetails listAuditPlanFocusAreaStatsDetails(
    final AuditPlanKey auditPlanKey) throws AppException,
      InformationalException {

    final FocusAreaStatsDetails focusAreaStatsDetails = new FocusAreaStatsDetails();

    final AuditPlan auditPlan = auditPlanDAO.get(auditPlanKey.auditPlanID);

    final Comparator<FocusAreaStats> focusAreaTextComparator = new FocusAreaTextComparator();

    focusAreaStatsDetails.dtlsList = auditPlan.listFocusAreaStats();

    Collections.sort(focusAreaStatsDetails.dtlsList.dtls,
      focusAreaTextComparator);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      focusAreaStatsDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return focusAreaStatsDetails;
  }
  // END, CR00290965
}
