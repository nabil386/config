/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import com.google.inject.Inject;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.codetable.ACTIONCONTROLID;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.INCIDENTPARTICIPANTROLE;
import curam.codetable.INCIDENTSTATUS;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.INCIDENTCATEGORYEntry;
import curam.codetable.impl.INCIDENTCLOSUREREASONEntry;
import curam.codetable.impl.INCIDENTPARTICIPANTROLEEntry;
import curam.codetable.impl.INCIDENTREPORTMETHODEntry;
import curam.codetable.impl.INCIDENTSEVERITYEntry;
import curam.codetable.impl.INCIDENTSTATUSEntry;
import curam.codetable.impl.INCIDENTTIMEOFDAYEntry;
import curam.codetable.impl.INCIDENTTYPEEntry;
import curam.codetable.impl.LOCATIONACCESSTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.contactlog.impl.ContactLogSearchTextFilter;
import curam.contactlog.impl.ContactLogUtility;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.intf.Case;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.CloseIncidentDetails;
import curam.core.facade.struct.CloseIncidentWithVersionNoDetails;
import curam.core.facade.struct.ContactLogAttendeeList;
import curam.core.facade.struct.ContactLogSearchDetails;
import curam.core.facade.struct.ContactLogSearchKey1;
import curam.core.facade.struct.ContactLogWizardMenuDetails;
import curam.core.facade.struct.CreateIncidentContactLogContactDetails;
import curam.core.facade.struct.CreateIncidentContactLogContactDetails1;
import curam.core.facade.struct.CreateIncidentContactLogDetails;
import curam.core.facade.struct.CreateIncidentContactLogDetails1;
import curam.core.facade.struct.CreateIncidentDetails;
import curam.core.facade.struct.CreateIncidentDetails1;
import curam.core.facade.struct.CreateIncidentParticipantRoleDetails;
import curam.core.facade.struct.CreateIncidentParticipantRoleDetails1;
import curam.core.facade.struct.IncidentAttachmentDetailsList;
import curam.core.facade.struct.IncidentAttachmentWithVersionNoDetails;
import curam.core.facade.struct.IncidentAttachmentWithVersionNoDetailsList;
import curam.core.facade.struct.IncidentContactLogWizardDetails;
import curam.core.facade.struct.IncidentContextDescriptionDetails;
import curam.core.facade.struct.IncidentDetails;
import curam.core.facade.struct.IncidentForDuplicateParticipantDetailsList;
import curam.core.facade.struct.IncidentForDuplicateParticipantDetailsList1;
import curam.core.facade.struct.IncidentForParticipantDetails;
import curam.core.facade.struct.IncidentForParticipantDetails1;
import curam.core.facade.struct.IncidentForParticipantDetailsList;
import curam.core.facade.struct.IncidentForParticipantDetailsList1;
import curam.core.facade.struct.IncidentIDAndVersionNoDtls;
import curam.core.facade.struct.IncidentParticipantDetails;
import curam.core.facade.struct.IncidentParticipantDetailsList;
import curam.core.facade.struct.IncidentParticipantRoleDetails;
import curam.core.facade.struct.IncidentParticipantRoleDetailsList;
import curam.core.facade.struct.IncidentParticipantRoleIDAndVersionNoDtls;
import curam.core.facade.struct.IncidentReportedByName;
import curam.core.facade.struct.IncidentSearchDetailsList;
import curam.core.facade.struct.IncidentSearchKey;
import curam.core.facade.struct.IncidentSearchResult;
import curam.core.facade.struct.IncidentSearchResult1;
import curam.core.facade.struct.IncidentSearchResult1List;
import curam.core.facade.struct.IncidentSearchResultList;
import curam.core.facade.struct.IncidentStatusHistoryDetails;
import curam.core.facade.struct.IncidentStatusHistoryDetails1;
import curam.core.facade.struct.IncidentStatusHistoryDetailsList;
import curam.core.facade.struct.IncidentStatusHistoryDetailsList1;
import curam.core.facade.struct.IsNewReporterSpecifiedDetails;
import curam.core.facade.struct.ListContactLogDetails;
import curam.core.facade.struct.ListIncidentContactLogDetails;
import curam.core.facade.struct.MaintainIncidentDetails;
import curam.core.facade.struct.MaintainIncidentDetails1;
import curam.core.facade.struct.ParticipantContextDescriptionDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.PreviewIncidentContactLogIDKey;
import curam.core.facade.struct.PreviewIncidentContactLogKey;
import curam.core.facade.struct.PreviewIncidentContactLogXMLDetails;
import curam.core.facade.struct.SearchContactLogDetails;
import curam.core.facade.struct.ViewIncidentDetails;
import curam.core.facade.struct.ViewIncidentDetails1;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.NoteStatus;
import curam.core.impl.NoteType;
import curam.core.impl.NoteUtil;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.Address;
import curam.core.intf.AddressData;
import curam.core.intf.ConcernRole;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.ContactLogKey;
import curam.core.sl.entity.struct.ContactLogListDtls1;
import curam.core.sl.entity.struct.ContactLogListDtlsList;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.fact.AttachmentFactory;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.ContactLogAttendeeFactory;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.ContactLog;
import curam.core.sl.intf.ContactLogAttendee;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.CancelContactLogDetails;
import curam.core.sl.struct.ContactLogLinkIDLinkTypeKey;
import curam.core.sl.struct.CreateContactLogAttendeeDetails1;
import curam.core.sl.struct.CreateContactLogDetails;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.PreviewCaseContactLogKey;
import curam.core.sl.struct.PrintContactLogWizardDetails;
import curam.core.sl.struct.ReadContactLogDetails;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CuramInd;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.UsersKey;
import curam.incident.entity.struct.IncidentDtls;
import curam.incident.entity.struct.IncidentKey;
import curam.incident.entity.struct.IncidentParticipantRoleKey;
import curam.incident.impl.Incident;
import curam.incident.impl.IncidentDAO;
import curam.incident.impl.IncidentParticipant;
import curam.incident.impl.IncidentParticipantDAO;
import curam.incident.impl.IncidentStatusHistory;
import curam.message.ENTCONTACTLOG;
import curam.message.FACADEINCIDENT;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.message.SEPARATOR;
import curam.message.impl.BPOINCIDENTExceptionCreator;
import curam.message.impl.FACADEINCIDENTExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import curam.wizardpersistence.impl.WizardPersistentState;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import static curam.incident.impl.IncidentHelper.sensitivityChecker;

/**
 * Facade Class for the CEF Incidents implementation. Provides methods for
 * listing, creating, modifying and viewing the Incidents t
 */
public abstract class Incidents extends curam.core.facade.base.Incidents {

  /**
   * Start of the opening h5 tag with aria-label.
   */
  protected static final String H5_TAG_WITH_ARIA_LABEL_OPEN_START = "<h5 id=\"subject-text\" aria-label=\"";

  /**
   * End of the opening h5 tag with aria-label.
   */
  protected static final String H5_TAG_WITH_ARIA_LABEL_OPEN_END = "\">";

  /**
   * Opening h5 tag.
   */
  protected static final String H5_TAG_OPEN = "<h5 id=\"subject-text\">";

  /**
   * Closing h5 tag.
   */
  protected static final String H5_TAG_CLOSE = "</h5>";

  /**
   * Double dash. Used to represent empty Subject when searching contact logs.
   */
  protected static final String DOUBLE_DASH = "--";

  // BEGIN, CR00160459, ZV
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
      .getMessageText();

  protected static final String kSpace = CuramConst.gkSpace;

  // END, CR00160459

  @Inject
  protected IncidentDAO incidentDAO;

  @Inject
  protected IncidentParticipantDAO incidentParticipantDAO;

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  @Inject
  protected ContactLogSearchTextFilter contactLogSearchTextFilter;

  // ___________________________________________________________________________
  /**
   * Constructor.
   */
  public Incidents() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Method to create an Incident.
   *
   * @param details
   *          Details of the Incident to create
   * @return created incident key
   * @deprecated Since Curam 6.0, replaced by {@link #createIncident1()}. New
   *             method passes additional 'Reported By Me' parameter to create
   *             Incident. 'Date time' attribute split into two 'Date' and
   *             'Time' attributes.
   */
  @Override
  @Deprecated
  public IncidentKey createIncident(final CreateIncidentDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00167126, ZV
    final CreateIncidentDetails1 createIncidentDetails1 = new CreateIncidentDetails1();

    createIncidentDetails1.assign(details);

    // BEGIN, CR00195286, ZV
    createIncidentDetails1.incidentParticipantRoleType = INCIDENTPARTICIPANTROLEEntry.AGAINST
        .getCode();
    // END, CR00195286

    if (!details.incidentDtls.incidentDateTime.isZero()) {

      createIncidentDetails1.incidentDtls.incidentDate = new Date(
          details.incidentDtls.incidentDateTime);
      // BEGIN, CR00188956, ZV
      final Calendar calendar = details.incidentDtls.incidentDateTime
          .getCalendar();

      final Calendar zeroDateTime = Calendar.getInstance();

      zeroDateTime.clear();

      createIncidentDetails1.incidentDtls.incidentTime = new DateTime(
          zeroDateTime).addTime(calendar.get(Calendar.HOUR_OF_DAY),
              calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
      // END, CR00188956
    }

    final IncidentKey incidentKey = createIncident1(createIncidentDetails1);

    details.assign(createIncidentDetails1);

    return incidentKey;
    // END, CR00167126

  }

  /**
   * Method to list incidents for a given Participant.
   *
   * @param key
   *          ID of the Participant concerned
   *
   * @return List of Incidents for the participant
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listIncidentsForParticipant1()}
   */
  @Override
  @Deprecated
  public IncidentForParticipantDetailsList listIncidentsForParticipant(
      final ConcernRoleKey key) throws AppException, InformationalException {

    IncidentForParticipantDetailsList incidentForParticipantDetailsList = new IncidentForParticipantDetailsList();

    // BEGIN, CR00147819, ZV
    incidentForParticipantDetailsList = populateIncidentForParticipantList(
        incidentDAO.searchByParticipant(key.concernRoleID), key);
    // END, CR00147819

    return incidentForParticipantDetailsList;
  }

  // _________________________________________________________________________
  /**
   * Method for maintaining an Incident.
   *
   * @param details
   *          Details of the Incident to maintain
   * @deprecated Since Curam 6.0, replaced by {@link #maintainIncident1()}. New
   *             method passes additional 'Reported By Me' parameter to modify
   *             Incident. 'Date time' attribute split into two 'Date' and
   *             'Time' attributes.
   */
  @Override
  @Deprecated
  public void maintainIncident(final MaintainIncidentDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00167126, ZV
    final MaintainIncidentDetails1 maintainIncidentDetails1 = new MaintainIncidentDetails1();

    maintainIncidentDetails1.assign(details);

    if (!details.incidentDtls.incidentDateTime.isZero()) {

      maintainIncidentDetails1.incidentDtls.incidentDate = new Date(
          details.incidentDtls.incidentDateTime);
      // BEGIN, CR00188956, ZV
      final Calendar calendar = details.incidentDtls.incidentDateTime
          .getCalendar();

      final Calendar zeroDateTime = Calendar.getInstance();

      zeroDateTime.clear();

      maintainIncidentDetails1.incidentDtls.incidentTime = new DateTime(
          zeroDateTime).addTime(calendar.get(Calendar.HOUR_OF_DAY),
              calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
      // END, CR00188956
    }

    maintainIncident1(maintainIncidentDetails1);

    details.assign(maintainIncidentDetails1);
    // END, CR00167126
  }

  // ____________________________________________________________________________
  /**
   * Method to view an Incident.
   *
   * @param key
   *          ID of the Incident to view
   *
   * @return Details of the Incident for viewing on screen
   * @deprecated Since Curam 6.0, replaced by {@link #viewIncident1()}. New
   *             method reads additional 'Reported By Me' parameter to display
   *             Incident. 'Date time' attribute split into two 'Date' and
   *             'Time' attributes.
   */
  @Override
  @Deprecated
  public ViewIncidentDetails viewIncident(final IncidentKey key)
      throws AppException, InformationalException {

    final ViewIncidentDetails viewIncidentDetails = new ViewIncidentDetails();

    // BEGIN, CR00167126, ZV
    final ViewIncidentDetails1 viewIncidentDetails1 = viewIncident1(key);

    viewIncidentDetails.assign(viewIncidentDetails1);
    // END, CR00167126

    return viewIncidentDetails;
  }

  // BEGIN, CR00127598, POB
  /**
   * Method to validate the entered reporter details.
   *
   * @param details
   *          Details of the user or participant chosen as the reporter
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #validateReporterDetails1()}. New method passes
   *             additional 'Reported By Me' parameter for create Incident
   *             Reporter validation.
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected void validateReporterDetails(final CreateIncidentDetails details)
      throws AppException, InformationalException {

    // END, CR00198672
    // BEGIN, CR00167126, ZV
    // BEGIN, CR00180707, ZV
    final CreateIncidentParticipantRoleDetails1 reporterDetails = new CreateIncidentParticipantRoleDetails1();

    reporterDetails.assign(details.reporter);

    validateReporterDetails1(reporterDetails, details.incidentDtls);
    // END, CR00180707
    // END, CR00167126
  }

  // END, CR00127598

  // BEGIN, CR00127776, POB
  /**
   * Method to validate the entered reporter details.
   *
   * @param details
   *          Details of the user or participant chosen as the reporter
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #validateReporterDetails1()}. New method passes
   *             additional 'Reported By Me' parameter for modify Incident
   *             Reporter validation.
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected void validateReporterDetails(final MaintainIncidentDetails details)
      throws AppException, InformationalException {

    // END, CR00198672
    // BEGIN, CR00167126, ZV
    // BEGIN, CR00180707, ZV
    final CreateIncidentParticipantRoleDetails1 reporterDetails = new CreateIncidentParticipantRoleDetails1();

    reporterDetails.assign(details.reporter);

    validateReporterDetails1(reporterDetails, details.incidentDtls);
    // END, CR00180707
    // END, CR00167126
  }

  /**
   * Method to determine if any participant details were specified.
   *
   * @param details
   *          Details of the participant
   *
   * @return boolean true if any of the screen fields were filled in
   */
  // BEGIN, CR00198672, VK
  protected boolean isParticipantSpecified(
      final CreateIncidentParticipantRoleDetails details)
      throws AppException, InformationalException {

    // END, CR00198672
    final boolean userNameSpecified = details.userName.equals("") ? false
        : true;
    final boolean registeredParticipantSpecified = details.participantRoleID == 0
        ? false
        : true;
    boolean newParticipantSpecified = true;

    // determine if any of the new participant details have been
    // specified
    final Address addressObj = AddressFactory.newInstance();

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = details.address;

    final boolean addressEmpty = addressObj.isEmpty(otherAddressData).emptyInd;
    final boolean areaCodeEmpty = details.phoneAreaCode.equals("");
    final boolean phoneNumberEmpty = details.phoneNumber.equals("");

    if (details.participantName.equals("") && details.email.equals("")
        && areaCodeEmpty && phoneNumberEmpty && addressEmpty) {
      newParticipantSpecified = false;
    }

    if (userNameSpecified || registeredParticipantSpecified
        || newParticipantSpecified) {
      return true;
    }

    return false;
  }

  // END, CR00127776

  /**
   * Method to validate the entered participant details.
   *
   * @param details
   *          Details of the user or participant chosen as the incident
   *          participant
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #validateIncidentParticipantDetails1()}. New method
   *             passes additional 'Reported By Me' parameter for Incident
   *             participant validation.
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected void validateIncidentParticipantDetails(
      final CreateIncidentParticipantRoleDetails details)
      throws AppException, InformationalException {

    // END, CR00198672
    // BEGIN, CR00180707, ZV
    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    final boolean userNameSpecified = details.userName.equals("") ? false
        : true;
    final boolean registeredParticipantSpecified = details.participantRoleID == 0
        ? false
        : true;
    boolean newParticipantSpecified = true;

    // determine if any of the new participant details have been
    // specified
    final Address addressObj = AddressFactory.newInstance();

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = details.address;

    final boolean addressEmpty = addressObj.isEmpty(otherAddressData).emptyInd;
    final boolean areaCodeEmpty = details.phoneAreaCode.equals("");
    final boolean phoneNumberEmpty = details.phoneNumber.equals("");

    if (details.participantName.equals("") && details.email.equals("")
        && areaCodeEmpty && phoneNumberEmpty && addressEmpty) {
      newParticipantSpecified = false;
    }

    // if nothing specified throw an error
    if (!userNameSpecified && !registeredParticipantSpecified
        && !newParticipantSpecified) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(
                  FACADEINCIDENT.ERR_INCIDENT_XFV_MANDATORY_REPORTER_NOT_SET),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    // if more than one option chosen throw an error
    if (userNameSpecified
        && (registeredParticipantSpecified || newParticipantSpecified)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_MORE_THAN_ONE_SPECIFIED),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
    }

    // if more than one option chosen throw an error
    if (registeredParticipantSpecified
        && (userNameSpecified || newParticipantSpecified)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_MORE_THAN_ONE_SPECIFIED),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              3);
    }

    if (newParticipantSpecified) {

      if (details.participantName.equals("")) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(
                new AppException(
                    FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_NO_NAME_SPECIFIED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
      }

      if (areaCodeEmpty && !phoneNumberEmpty) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_PHONE_NO_AREA_CODE),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

      if (phoneNumberEmpty && !areaCodeEmpty) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_AREA_CODE_NO_PHONE),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

    }

    informationalManager.failOperation();
    // END, CR00180707

  }

  /**
   * Retrieves the concern role identifier for the specified participant. If the
   * specified participant details do not yet exist, the participant is
   * registered as a representative and a corresponding concern role identifier
   * is generated.
   *
   * @bowrite Representative
   *
   * @boread Address
   * @param details
   *          Participant role creation details.
   *
   * @return Concern role identifier.
   */
  // BEGIN, CR00198672, VK
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public ConcernRoleKey getConcernRoleIDForParticipant(
      final CreateIncidentParticipantRoleDetails details)
      throws AppException, InformationalException {

    // END, CR00198672
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    if (details.participantRoleID != 0) {
      concernRoleKey.concernRoleID = details.participantRoleID;
    } else {
      // need to register a new representative
      final curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory
          .newInstance();

      final RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.participantName;

      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.phoneAreaCode;

      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.phoneNumber;

      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date
          .getCurrentDate();

      final Address addressObj = AddressFactory.newInstance();

      final OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = details.address;

      final boolean addressEmpty = addressObj
          .isEmpty(otherAddressData).emptyInd;

      if (addressEmpty) {
        // BEGIN, CR00190258, CL
        final AddressData addressDataObj = AddressDataFactory.newInstance();

        representativeRegistrationDetails.representativeRegistrationDetails.addressData = addressDataObj
            .getAddressDataForLocale().addressData;
        // END, CR00190258
      } else {
        representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.address;
      }

      representativeObj
          .registerRepresentative(representativeRegistrationDetails);

      concernRoleKey.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    }

    return concernRoleKey;
  }

  /**
   * Method to add an Incident ParticipantRole to an Incident.
   *
   * @param incidentKey
   *          Incident key to add participant
   * @param details
   *          Details of the Incident Participant Role to add
   *
   * @return Key of the Incident Participant Role created
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #addIncidentParticipantRole1()}. New method passes
   *             additional existing Incident Participant attribute to add new
   *             Incident Participant.
   */
  @Override
  @Deprecated
  public IncidentParticipantRoleKey addIncidentParticipantRole(
      final IncidentKey incidentKey,
      final CreateIncidentParticipantRoleDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00167126, ZV
    final CreateIncidentParticipantRoleDetails1 createIncidentParticipantRoleDetails1 = new CreateIncidentParticipantRoleDetails1();

    createIncidentParticipantRoleDetails1.assign(details);

    return addIncidentParticipantRole1(incidentKey,
        createIncidentParticipantRoleDetails1);
    // END, CR00167126
  }

  /**
   * Method to modify an Incident ParticipantRole to an Incident.
   *
   * @param details
   *          Details of the Incident Participant Role to modify
   */
  @Override
  public void maintainIncidentParticipantRole(
      final IncidentParticipantRoleDetails details)
      throws AppException, InformationalException {

    final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .get(details.incidentParticipantRoleID);

    incidentParticipantObj.setRole(
        INCIDENTPARTICIPANTROLEEntry.get(details.incidentParticipantRoleType));

    // BEGIN, CR00148812, CW
    incidentParticipantObj.setComments(details.comments);
    // END, CR00148812

    incidentParticipantObj.modify(details.versionNo);
  }

  /**
   * Method to view an Incident ParticipantRole to an Incident.
   *
   * @param key
   *          ID of the Incident Participant Role to view
   * @return Incident participant role details
   */
  @Override
  public IncidentParticipantRoleDetails viewIncidentParticipantRole(
      final IncidentParticipantRoleKey key)
      throws AppException, InformationalException {

    // return struct
    final IncidentParticipantRoleDetails incidentParticipantRoleDetails = new IncidentParticipantRoleDetails();

    final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .get(key.incidentParticipantRoleID);

    incidentParticipantRoleDetails.incidentParticipantRoleID = key.incidentParticipantRoleID;
    incidentParticipantRoleDetails.incidentParticipantRoleType = incidentParticipantObj
        .getRole().getCode();
    incidentParticipantRoleDetails.concernRoleID = incidentParticipantObj
        .getConcernRoleID();
    incidentParticipantRoleDetails.userName = incidentParticipantObj
        .getUserName();
    incidentParticipantRoleDetails.recordStatus = incidentParticipantObj
        .getLifecycleState().getCode();
    incidentParticipantRoleDetails.versionNo = incidentParticipantObj
        .getVersionNo();
    // BEGIN, CR00148812, CW
    incidentParticipantRoleDetails.comments = incidentParticipantObj
        .getComments();
    // END, CR00148812

    if (incidentParticipantRoleDetails.concernRoleID == 0) {

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = incidentParticipantRoleDetails.userName;

      incidentParticipantRoleDetails.fullName = userAccessObj
          .getFullName(usersKey).fullname;

    } else {
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = incidentParticipantRoleDetails.concernRoleID;

      incidentParticipantRoleDetails.fullName = concernRoleObj
          .readConcernRoleName(concernRoleKey).concernRoleName;
    }

    return incidentParticipantRoleDetails;
  }

  // BEGIN, CR00243200, ZV
  // BEGIN, CR00224036, ZV
  /**
   * Method to close an Incident without optimistic locking.
   *
   * @param key
   *          details of the Incident to close
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #closeIncidentWithVersionNo()}.
   */
  @Override
  @Deprecated
  public void closeIncident(final CloseIncidentDetails key)
      throws AppException, InformationalException {

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    incidentObj.close(key.comments,
        INCIDENTCLOSUREREASONEntry.get(key.closureReason),
        incidentObj.getVersionNo());

  }

  // END, CR00224036
  // END, CR00243200

  // BEGIN, CR00243200, ZV
  /**
   * Method to delete an Incident without optimistic locking.
   *
   * @param key
   *          ID of the Incident to delete
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #deleteIncidentWithVersionNo()}.
   */
  @Override
  @Deprecated
  public void deleteIncident(final IncidentKey key)
      throws AppException, InformationalException {

    final Incident incidentObj = incidentDAO.get(key.incidentID);
    incidentObj.cancel(incidentObj.getVersionNo());

  }

  // END, CR00243200

  /**
   * Method to delete an incident participant.
   *
   * @param key
   *          ID of the Incident Participant to delete
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #deleteIncidentParticipant1()}. Current method reads
   *             versionNo of incident participant to be deleted, while new
   *             method passes versionNo as input parameter.
   */
  @Override
  @Deprecated
  public void deleteIncidentParticipant(final IncidentParticipantRoleKey key)
      throws AppException, InformationalException {

    final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .get(key.incidentParticipantRoleID);

    final int versionNo = incidentParticipantObj.getVersionNo();

    incidentParticipantObj.cancel(versionNo);

  }

  /**
   * Method to return a list of status history records for an incident.
   *
   * @param key
   *          ID of the Incident concerned
   *
   * @return List of status history records for the incident
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listStatusHistoryForIncident1()}. New method reads
   *             Incident Status History user name for display.
   */
  @Override
  @Deprecated
  public IncidentStatusHistoryDetailsList listStatusHistoryForIncident(
      final IncidentKey key) throws AppException, InformationalException {

    // return struct
    final IncidentStatusHistoryDetailsList incidentStatusHistoryDetailsList = new IncidentStatusHistoryDetailsList();

    // BEGIN, CR00167126, ZV
    final IncidentStatusHistoryDetailsList1 incidentStatusHistoryDetailsList1 = listStatusHistoryForIncident1(
        key);

    for (int i = 0; i < incidentStatusHistoryDetailsList1.dtlsList
        .size(); i++) {

      final IncidentStatusHistoryDetails incidentStatusHistoryDetails = new IncidentStatusHistoryDetails();

      incidentStatusHistoryDetails
          .assign(incidentStatusHistoryDetailsList1.dtlsList.item(i));

      incidentStatusHistoryDetailsList.dtlsList
          .addRef(incidentStatusHistoryDetails);
    }
    // END, CR00167126

    return incidentStatusHistoryDetailsList;
  }

  // BEGIN, CR00127288, JMA
  /**
   * Sorts the list of status history records by date.
   *
   * @param unSortedlist
   *          Unsorted list of status history records.
   * @return List Sorted list of status history records
   */
  // BEGIN, CR00198672, VK
  protected List<IncidentStatusHistory> sortByDate(
      final Set<IncidentStatusHistory> unSortedlist) {

    // END, CR00198672
    final List<IncidentStatusHistory> incidentStatusHistory = new ArrayList<IncidentStatusHistory>(
        unSortedlist);

    Collections.sort(incidentStatusHistory,
        new Comparator<IncidentStatusHistory>() {

          @Override
          public int compare(final IncidentStatusHistory lhs,
              final IncidentStatusHistory rhs) {

            return rhs.getEventDateTime().compareTo(lhs.getEventDateTime());
          }
        });

    return incidentStatusHistory;
  }

  // END, CR00127288

  /**
   * Method to create a Contact Log record on the Incident.
   *
   * @param details
   *          Details of the Contact Log record to create
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #createIncidentContactLog1()} New method passes
   *             additional incident participant role id list as tab separated
   *             string parameter to create Incident Contact Log.
   */
  @Override
  @Deprecated
  public void createIncidentContactLog(
      final CreateIncidentContactLogDetails details)
      throws AppException, InformationalException {

    details.contactLogDtls.contactLogDetails.author = TransactionInfo
        .getProgramUser();

    // BEGIN, CR00173401, ZV
    // BEGIN, CR00140221, ZV
    final CreateIncidentContactLogDetails1 createIncidentContactLogDetails = new CreateIncidentContactLogDetails1();

    createIncidentContactLogDetails.contactLogDtls
        .assign(details.contactLogDtls);

    createIncidentContactLog1(createIncidentContactLogDetails);

    details.contactLogDtls
        .assign(createIncidentContactLogDetails.contactLogDtls);
    // END, CR00140221
    // END, CR00173401

  }

  /**
   * Method to add a Contact to an Incidents Contact Log record.
   *
   * @param details
   *          Details of the contact to create
   * @deprecated Since Curam 6.0, replaced by {@link #addContactLogContact1()}
   *             New method passes additional incident participant role id list
   *             as tab separated string parameter to add Incident Contact Log
   *             Participant.
   */
  @Override
  @Deprecated
  public void addContactLogContact(
      final CreateIncidentContactLogContactDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00167126, ZV
    final CreateIncidentContactLogContactDetails1 createIncidentContactLogContactDetails = new CreateIncidentContactLogContactDetails1();

    createIncidentContactLogContactDetails.assign(details);

    addContactLogContact1(createIncidentContactLogContactDetails);

    details.assign(createIncidentContactLogContactDetails);
    // END, CR00167126
  }

  /**
   * Method to add an attachment for an incident.
   *
   * @param details
   *          Details of the attachment to add
   */
  @Override
  public void addAttachmentForIncident(final AttachmentLinkDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00130566, SK
    final Incident incident = incidentDAO
        .get(details.attachmentLinkDtls.relatedObjectID);

    if (incident.getLifecycleState().equals(INCIDENTSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addValidationHelperExceptionWithLookup(FACADEINCIDENTExceptionCreator
              .ERR_INCIDENT_XRV_ATTACHMENT_CAN_NOT_ADDED_INCIDENT_CANCELED(
                  incident.getLifecycleState().getCodeTableItemIdentifier()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }
    // END, CR00130566

    final AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.INCIDENT;
    /*
     * NO CHANGE TO THIS METHOD: RTC 183047, COF NOTE: DEFAULTCODE is the same
     * as MINIMUM We've updated the AttachmentLinkImpl sensitivity checker to
     * take into account IncidentImpl sensitivity as well as AttachmentLinkImpl
     * sensitivity, so that the "effective sensitivity" of an attachment, is the
     * greater of the 2 sensitivity levels. To allow attachments to have an
     * effective sensitivity of that of the incident,even as the incident's
     * sensitivity changes over time, the AttachmentLink's sensitivity must be
     * initialized to the lowest it can be.
     */
    details.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;
    attachmentLink.insert(details);

  }

  // BEGIN, CR00245044, ZV
  /**
   * Method to list all attachments for the specified incident.
   *
   * @param key
   *          ID of the incident
   *
   * @return List of attachment details
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listAttachmentsWithVersionNoByIncident()}
   */
  @Override
  @Deprecated
  public IncidentAttachmentDetailsList listAttachmentsByIncident(
      final IncidentKey key) throws AppException, InformationalException {

    // return struct
    final IncidentAttachmentDetailsList incidentAttachmentDetailsList = new IncidentAttachmentDetailsList();

    final IncidentAttachmentWithVersionNoDetailsList incidentAttachmentWithVersionNoDetailsList = listAttachmentsWithVersionNoByIncident(
        key);

    incidentAttachmentDetailsList
        .assign(incidentAttachmentWithVersionNoDetailsList);

    return incidentAttachmentDetailsList;
  }

  // END, CR00245044

  // BEGIN, CR00190355, MC
  // __________________________________________________________________________
  /**
   * Method to search for incidents based on various parameters..
   *
   * @param key
   *          Values for searching for incidents
   *
   * @return List of Incident Details for display
   * @deprecated Since Curam 6.0, replaced by {@link #searchIncidents1()}.
   */
  @Override
  @Deprecated
  public IncidentSearchResultList searchIncidents(final IncidentSearchKey key)
      throws AppException, InformationalException {

    final IncidentSearchResultList incidentSearchResultList = new IncidentSearchResultList();

    final IncidentSearchResult1List incidentSearchResultList1 = searchIncidents1(
        key);
    IncidentSearchResult incidentSearchResult;

    for (int i = 0; i < incidentSearchResultList1.dtlsList.size(); i++) {
      incidentSearchResult = new IncidentSearchResult();
      incidentSearchResult.assign(incidentSearchResultList1.dtlsList.item(i));

      incidentSearchResultList.dtlsList.addRef(incidentSearchResult);
    }

    return incidentSearchResultList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Method to search for incidents based on various parameters.
   *
   * @param key
   *          Values for searching for incidents
   *
   * @return List of Incident Details for display
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   *             {@link Incidents#searchIncidentsDetails(IncidentSearchKey)}
   *
   *             This method is deprecated as informational messages are not
   *             returned. This method is replaced by
   *             searchIncidentsDetails(IncidentSearchKey) which returns the
   *             informational message along with incident details as well. See
   *             release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public IncidentSearchResult1List searchIncidents1(final IncidentSearchKey key)
      throws AppException, InformationalException {

    // END, CR00290965
    final IncidentSearchResult1List incidentSearchResultList = new IncidentSearchResult1List();

    final SortedSet<Incident> incidents = incidentDAO.search(key.recordedDate,
        INCIDENTSEVERITYEntry.get(key.severity),
        INCIDENTREPORTMETHODEntry.get(key.reportingMethod),
        INCIDENTTYPEEntry.get(key.type), key.location);

    for (final Incident incident : incidents) {

      // BEGIN, RTC 177382, COF
      if (!incident.isSensitiveForCurrentUser()) {
        continue;
      }
      // END, RTC 177382

      final IncidentSearchResult1 incidentSearchResult = new IncidentSearchResult1();

      incidentSearchResult.incidentID = incident.getID();
      incidentSearchResult.incidentStatus = incident.getLifecycleState()
          .getCode();
      incidentSearchResult.recordedDate = incident.getRecordedDate();
      incidentSearchResult.severity = incident.getSeverity().getCode();
      incidentSearchResult.type = incident.getType().getCode();
      incidentSearchResult.concernRoleID = incident.getAgainstConcernRole();

      incidentSearchResultList.dtlsList.addRef(incidentSearchResult);

    }

    return incidentSearchResultList;
  }

  // END, CR00190355

  // BEGIN, CR00129480, SK

  /**
   * Deletes the contact log of an incident.
   *
   * @param keyVersion
   *          Contains the contact log ID and version number.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void cancelContactLog(final CancelContactLogDetails keyVersion)
      throws AppException, InformationalException {

    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    contactLogObj.cancel(keyVersion);
  }

  // END, CR00129480

  // BEGIN, CR00140221, ZV

  /**
   * Method to list all contact logs for the specified incident. New method
   * returns additional end date time field.
   *
   * @param key
   *          ID of the incident
   *
   * @return List of contact log details
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listContactLogForIncident1()}.
   */
  @Override
  @Deprecated
  public ContactLogListDtlsList listContactLogForIncident(final IncidentKey key)
      throws AppException, InformationalException {

    // Contact Log service object and variable
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();
    final curam.core.sl.struct.ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new curam.core.sl.struct.ContactLogLinkIDLinkTypeKey();

    // set incident id and incident type
    contactLogLinkIDLinkTypeKey.linkID = key.incidentID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    // BEGIN, CR00140531, CL
    ContactLogListDtlsList contactLogListDtlsList = new ContactLogListDtlsList();

    // list contact log details
    contactLogListDtlsList = contactLogObj.list(contactLogLinkIDLinkTypeKey);

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < contactLogListDtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails
          .assign(contactLogListDtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj
          .formatContactLogPurpose(readContactLogDetails);

      contactLogListDtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }

    // return contact log details list
    return contactLogListDtlsList;
    // END, CR00140531

  }

  // END, CR00140221

  // BEGIN, CR00144945, SS
  /**
   * List incidents for duplicate participant.
   *
   * @param key
   *          contains Concern Role key
   * @return list of incidents
   * @throws AppException
   *           Generic Exception Signature.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #listIncidentsForDuplicateParticipant1()}.
   */
  @Override
  @Deprecated
  public IncidentForDuplicateParticipantDetailsList listIncidentsForDuplicateParticipant(
      final ConcernRoleKey key) throws AppException, InformationalException {

    // BEGIN, CR00147819, ZV
    return populateIncidentForDuplicateParticipantList(
        incidentDAO.searchByParticipant(key.concernRoleID), key);
    // END, CR00147819

  }

  // END, CR00144945

  // BEGIN, CR00160459, ZV
  // BEGIN, CR00195286, ZV
  /**
   * List active participant roles for an incident.
   *
   * @param key
   *          contains Incident key
   * @return list of incident participant roles
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentParticipantDetailsList listIncidentActiveParticipantRole(
      final IncidentKey key) throws AppException, InformationalException {

    final IncidentParticipantDetailsList incidentParticipantDetailsList = new IncidentParticipantDetailsList();

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    // BEGIN, RTC 183047, COF
    if (!sensitivityChecker(incidentObj, 10)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    final Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO
        .searchByIncident(incidentObj);

    final Iterator<IncidentParticipant> incidentParticipantSetIterator = incidentParticipantSet
        .iterator();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    while (incidentParticipantSetIterator.hasNext()) {

      final IncidentParticipant incidentParticipantObj = incidentParticipantSetIterator
          .next();

      if (!incidentParticipantObj.getLifecycleState()
          .equals(RECORDSTATUSEntry.CANCELLED)) {

        final IncidentParticipantDetails incidentParticipantRoleDetails = new IncidentParticipantDetails();

        incidentParticipantRoleDetails.incidentParticipantRoleID = incidentParticipantObj
            .getID();
        incidentParticipantRoleDetails.participantName = incidentParticipantObj
            .getUserName();

        if (incidentParticipantObj.getConcernRoleID() == 0) {

          usersKey.userName = incidentParticipantObj.getUserName();

          incidentParticipantRoleDetails.participantName = userAccessObj
              .getFullName(usersKey).fullname;

          incidentParticipantRoleDetails.userName = incidentParticipantObj
              .getUserName();

        } else {

          concernRoleKey.concernRoleID = incidentParticipantObj
              .getConcernRoleID();

          incidentParticipantRoleDetails.participantName = concernRoleObj
              .readConcernRoleName(concernRoleKey).concernRoleName;

          incidentParticipantRoleDetails.concernRoleID = incidentParticipantObj
              .getConcernRoleID();
        }

        // add only unique participants
        boolean particinantExistInd = false;

        for (int i = 0; i < incidentParticipantDetailsList.dtlsList
            .size(); i++) {

          if (incidentParticipantDetailsList.dtlsList.item(i).userName
              .length() > 0
              && incidentParticipantDetailsList.dtlsList.item(i).userName
                  .equals(incidentParticipantRoleDetails.userName)
              || incidentParticipantDetailsList.dtlsList
                  .item(i).concernRoleID != 0
                  && incidentParticipantDetailsList.dtlsList.item(
                      i).concernRoleID == incidentParticipantRoleDetails.concernRoleID) {

            particinantExistInd = true;
            break;
          }
        }

        if (!particinantExistInd) {
          incidentParticipantDetailsList.dtlsList
              .addRef(incidentParticipantRoleDetails);
        }

      }

    }

    // Sort the incident participant roles by participant name
    final Comparator<IncidentParticipantDetails> participantComparator = new ParticipantComparator();

    Collections.sort(incidentParticipantDetailsList.dtlsList,
        participantComparator);

    return incidentParticipantDetailsList;
  }

  // END, CR00195286

  /**
   * Method to get incident context description.
   *
   * @param key
   *          contains Incident key
   * @return Incident context description
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentContextDescriptionDetails getIncidentContextDescription(
      final IncidentKey key) throws AppException, InformationalException {

    final IncidentContextDescriptionDetails incidentContextDescriptionDetails = new IncidentContextDescriptionDetails();

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    // BEGIN, RTC 183047, COF
    if (!sensitivityChecker(incidentObj, 11)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    // BEGIN, CR00195286, ZV
    incidentContextDescriptionDetails.description = incidentObj.getType()
        .toUserLocaleString() + kSpace + kSeparator + kSpace
        + incidentObj.getIncidentDate();
    // END CR00195286

    return incidentContextDescriptionDetails;
  }

  /*
   * Comparator used to order an incident participant roles by participant name
   */
  public class ParticipantComparator
      implements Comparator<IncidentParticipantDetails> {

    // _________________________________________________________________________
    /**
     * Sorts incident participant list based on name.
     */
    public ParticipantComparator() {

      super();
    }

    // _________________________________________________________________________
    /**
     * Sorts incident participant list based on name.
     *
     * @param details1
     *          Incident participant details to compare
     * @param details2
     *          Incident participant details to compare
     *
     * @return boolean value based on two participant names
     */
    @Override
    public int compare(final IncidentParticipantDetails details1,
        final IncidentParticipantDetails details2) {

      return details1.participantName.compareTo(details2.participantName);
    }

  }

  // END, CR00160459

  // BEGIN, CR00167126, ZV
  // _________________________________________________________________________
  /**
   * Method to add a Contact to an Incidents Contact Log record.
   *
   * @param details
   *          Details of the contact to create
   *          <p>
   *          It adds the following informational exceptions to the validation
   *          helper when validation fails.
   *          </p>
   *          <ul>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_CONTACT_PARTICIPANT_EMPTY}
   *          - If contact log participant not specified.</li>
   *          </ul>
   */
  @Override
  public void addContactLogContact1(
      final CreateIncidentContactLogContactDetails1 details)
      throws AppException, InformationalException {

    // BEGIN, CR00227859, PM
    if (0 != details.contactDtls.concernRoleID) {

      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
          .get();
      // Concern Role Variables
      final ParticipantSecurityCheckKey participantKey = new ParticipantSecurityCheckKey();

      // perform concern role sensitivity check
      participantKey.participantID = details.contactDtls.concernRoleID;
      participantKey.type = LOCATIONACCESSTYPE.MAINTAIN;

      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
          .checkParticipantSecurity(participantKey);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
              GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
        } else {
          throw new AppException(
              GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }
    }
    // END, CR00227859

    final curam.core.sl.intf.ContactLogAttendee contactLogAttendeeObj = curam.core.sl.fact.ContactLogAttendeeFactory
        .newInstance();

    if (details.incidentParticipantRoleIDTabList.length() == 0
        && details.contactDtls.concernRoleID == 0
        && details.contactDtls.userName.length() == 0
        && details.contactDtls.concernRoleName.length() == 0
        && !details.contactDtls.currentUserIsAttendeeInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addValidationHelperExceptionWithLookup(
              FACADEINCIDENTExceptionCreator
                  .ERR_INCIDENT_XFV_CONTACT_PARTICIPANT_EMPTY(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    ValidationHelper.failIfErrorsExist();

    final StringList incidentParticipantRoleIDList = StringUtil
        .tabText2StringListWithTrim(details.incidentParticipantRoleIDTabList);

    IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .newInstance();

    // BEGIN, CR00173401, ZV
    final CreateContactLogAttendeeDetails1 createContactLogAttendeeDetails = new CreateContactLogAttendeeDetails1();

    // END, CR00173401

    createContactLogAttendeeDetails.contactLogID = details.contactDtls.contactLogID;

    for (int i = 0; i < incidentParticipantRoleIDList.size(); i++) {

      if (incidentParticipantRoleIDList.item(i).length() > 0) {

        incidentParticipantObj = incidentParticipantDAO
            .get(Long.parseLong(incidentParticipantRoleIDList.item(i)));

        createContactLogAttendeeDetails.concernRoleID = incidentParticipantObj
            .getConcernRoleID();
        createContactLogAttendeeDetails.userName = incidentParticipantObj
            .getUserName();

        // BEGIN, CR00173401, ZV
        // create contact participant
        contactLogAttendeeObj.create1(createContactLogAttendeeDetails);
        // END, CR00173401

      } // if (incidentParticipantRoleIDs.item(i).length() >0)
    } // for i

    contactLogAttendeeObj.create1(details.contactDtls);
  }

  // BEGIN, CR00228358,NRK
  /**
   * Method to create a Contact Log record on the Incident.
   *
   * @param details
   *          Details of the Contact Log record to create
   *
   * @return Created contact log key
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey createIncidentContactLog1(
      final CreateIncidentContactLogDetails1 details)
      throws AppException, InformationalException {

    // BEGIN, CR00426798, AC
    details.contactLogDtls.contactLogDetails.author = details.contactLogDtls.contactLogDetails.author;
    // END, CR00426798
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    details.contactLogDtls.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    final ContactLogKey contactLogKey = contactLogObj
        .create1(details.contactLogDtls);

    // create incident participants as contact log contacts if required
    if (details.incidentParticipantRoleIDTabList.length() > 0) {

      final CreateIncidentContactLogContactDetails1 createIncidentContactLogContactDetails = new CreateIncidentContactLogContactDetails1();

      createIncidentContactLogContactDetails.contactDtls.contactLogID = contactLogKey.contactLogID;
      createIncidentContactLogContactDetails.incidentParticipantRoleIDTabList = details.incidentParticipantRoleIDTabList;

      addContactLogContact1(createIncidentContactLogContactDetails);
    }

    return contactLogKey;

  }

  // END, CR00228358
  /**
   * Method to add an Incident ParticipantRole to an Incident.
   *
   * @param incidentKey
   *          Incident key to add Participant
   * @param details
   *          Details of the Incident Participant Role to add
   *
   * @return Key of the Incident Participant Role created
   */
  @Override
  public IncidentParticipantRoleKey addIncidentParticipantRole1(
      final IncidentKey incidentKey,
      final CreateIncidentParticipantRoleDetails1 details)
      throws AppException, InformationalException {

    validateIncidentParticipantDetails1(details);

    final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .newInstance();

    final Incident incidentObj = incidentDAO.get(incidentKey.incidentID);

    incidentParticipantObj.setRole(
        INCIDENTPARTICIPANTROLEEntry.get(details.incidentParticipantRoleType));
    incidentParticipantObj.setIncident(incidentObj);

    // BEGIN, CR00183167, ZV
    // BEGIN, CR00148812, CW
    incidentParticipantObj.setComments(details.comments);
    // END, CR00148812

    final IncidentParticipantRoleKey incidentParticipantRoleKey = new IncidentParticipantRoleKey();

    final StringList incidentParticipantStringList = StringUtil
        .tabText2StringListWithTrim(details.incidentParticipantRoleIDTabList);

    for (int i = 0; i < incidentParticipantStringList.size(); i++) {

      if (incidentParticipantStringList.item(i).length() > 0) {

        final IncidentParticipant existingIncidentParticipantObj = incidentParticipantDAO
            .get(Long.parseLong(incidentParticipantStringList.item(i)));

        incidentParticipantObj.setConcernRoleID(
            existingIncidentParticipantObj.getConcernRoleID());
        incidentParticipantObj
            .setUserName(existingIncidentParticipantObj.getUserName());

        incidentParticipantObj.insert();

      }
    }

    if (details.userName != null && !details.userName.equals("")) {
      incidentParticipantObj.setUserName(details.userName);
      incidentParticipantObj.insert();
    } else if (details.participantRoleID != 0
        || details.participantName.length() > 0) {

      final CreateIncidentParticipantRoleDetails createIncidentParticipantRoleDetails = new CreateIncidentParticipantRoleDetails();

      createIncidentParticipantRoleDetails.assign(details);

      final ConcernRoleKey concernRoleKey = getConcernRoleIDForParticipant(
          createIncidentParticipantRoleDetails);

      incidentParticipantObj.setConcernRoleID(concernRoleKey.concernRoleID);
      incidentParticipantObj.insert();
    }
    // END, CR00183167

    // BEGIN, CR00184101, ZV
    details.versionNo = incidentParticipantObj.getVersionNo();
    // END, CR00184101
    incidentParticipantRoleKey.incidentParticipantRoleID = incidentParticipantObj
        .getID();

    return incidentParticipantRoleKey;
  }

  // _________________________________________________________________________
  /**
   * Method to create an Incident.
   *
   * @param details
   *          Details of the Incident to create
   * @return Created incident key
   *         <p>
   *         It adds the following informational exceptions to the validation
   *         helper when validation fails.
   *         </p>
   *         <ul>
   *         <li>
   *         {@link BPOINCIDENT#ERR_INCIDENT_XRV_CANNOT_CREATE_FOR_DUPLICATE_CLIENT}
   *         - If an Incident should be created for a client that is currently
   *         marked as a duplicate.</li>
   *         <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_INCIDENT_DATE_EMPTY} -
   *         If an incident date is not specified when a time is specified.</li>
   *         <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_INCIDENT_TIME_EMPTY} -
   *         If an incident time is not specified when a date is specified.</li>
   *         </ul>
   */
  @Override
  public IncidentKey createIncident1(final CreateIncidentDetails1 details)
      throws AppException, InformationalException {

    final Incident incidentObj = incidentDAO.newInstance();
    // BEGIN, CR00146028, SS
    CuramInd duplicateClientIndicator = null;
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;
    duplicateClientIndicator = clientMergeObj
        .isConcernRoleDuplicate(concernRoleKey);

    if (duplicateClientIndicator.statusInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addValidationHelperExceptionWithLookup(
              BPOINCIDENTExceptionCreator
                  .ERR_INCIDENT_XRV_CANNOT_CREATE_FOR_DUPLICATE_CLIENT(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    ValidationHelper.failIfErrorsExist();
    // END, CR00146028

    // BEGIN, CR00127598, POB
    // BEGIN, CR00180707, ZV
    validateReporterDetails1(details.reporter, details.incidentDtls);
    // END, CR00180707
    // END, CR00127598

    incidentObj.setType(INCIDENTTYPEEntry.get(details.incidentDtls.type));
    incidentObj
        .setSeverity(INCIDENTSEVERITYEntry.get(details.incidentDtls.severity));
    incidentObj.setSensitivity(
        SENSITIVITYEntry.get(details.incidentDtls.sensitivityCode));
    // BEGIN, CR00180934, ZV
    incidentObj.setIncidentDate(details.incidentDtls.incidentDate);
    incidentObj.setIncidentTime(details.incidentDtls.incidentTime);
    // END, CR00180934
    incidentObj.setTimeOfDay(
        INCIDENTTIMEOFDAYEntry.get(details.incidentDtls.timeOfDay));
    incidentObj.setLocation(details.incidentDtls.location);
    incidentObj.appendDescription(details.incidentDtls.description);

    // BEGIN, CR00386722, MP
    incidentObj
        .setCategory(INCIDENTCATEGORYEntry.get(details.incidentDtls.category));
    // END, CR00386722

    incidentObj.setReportMethod(
        INCIDENTREPORTMETHODEntry.get(details.incidentDtls.reportMethod));
    incidentObj.setAnonymousReporter(details.incidentDtls.anonymousReportInd);

    incidentObj.insert();

    // BEGIN, CR00149999, ZV
    details.incidentDtls.incidentID = incidentObj.getID();
    details.incidentDtls.versionNo = incidentObj.getVersionNo();
    // END, CR00149999

    // if not an anonymous report, create the chosen incident participant
    if (!details.incidentDtls.anonymousReportInd) {

      // BEGIN, CR00160459, ZV
      if (details.reporter.reportedByMeInd) {
        details.reporter.userName = TransactionInfo.getProgramUser();
      }
      // END, CR00160459

      final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
          .newInstance();

      incidentParticipantObj.setIncident(incidentObj);
      incidentParticipantObj.setRole(INCIDENTPARTICIPANTROLEEntry.REPORTER);

      if (details.reporter.userName != null
          && !details.reporter.userName.equals("")) {
        incidentParticipantObj.setUserName(details.reporter.userName);
      } else {

        final CreateIncidentParticipantRoleDetails createIncidentParticipantRoleDetails = new CreateIncidentParticipantRoleDetails();

        createIncidentParticipantRoleDetails.assign(details.reporter);

        // BEGIN, CR00146028, SS
        concernRoleKey = getConcernRoleIDForParticipant(
            createIncidentParticipantRoleDetails);
        // END, CR00146028
        incidentParticipantObj.setConcernRoleID(concernRoleKey.concernRoleID);
      }

      incidentParticipantObj.insert();
    }

    // BEGIN, CR00195286, ZV
    final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .newInstance();

    incidentParticipantObj.setIncident(incidentObj);
    incidentParticipantObj.setRole(
        INCIDENTPARTICIPANTROLEEntry.get(details.incidentParticipantRoleType));
    incidentParticipantObj.setConcernRoleID(details.concernRoleID);

    incidentParticipantObj.insert();
    // END, CR00195286

    final IncidentKey incidentKey = new IncidentKey();

    incidentKey.incidentID = incidentObj.getID();

    return incidentKey;
  }

  // _________________________________________________________________________
  /**
   * Method to return a list of status history records for an incident.
   *
   * @param key
   *          ID of the Incident concerned
   *
   * @return List of status history records for the incident
   */
  @Override
  public IncidentStatusHistoryDetailsList1 listStatusHistoryForIncident1(
      final IncidentKey key) throws AppException, InformationalException {

    // return struct
    final IncidentStatusHistoryDetailsList1 incidentStatusHistoryDetailsList = new IncidentStatusHistoryDetailsList1();

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    // BEGIN, RTC 183047, COF
    if (!sensitivityChecker(incidentObj, 12)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    // BEGIN, CR00127288, JMA
    final List<IncidentStatusHistory> incidentStatusHistoryList = sortByDate(
        incidentObj.getStatusHistory());

    final Iterator<IncidentStatusHistory> incidentStatusHistoryIterator = incidentStatusHistoryList
        .iterator();

    // END, CR00127288
    while (incidentStatusHistoryIterator.hasNext()) {

      final IncidentStatusHistory incidentStatusHistory = incidentStatusHistoryIterator
          .next();

      final IncidentStatusHistoryDetails1 incidentStatusHistoryDetails = new IncidentStatusHistoryDetails1();

      // BEGIN, CR00141707, MC
      // Return the user first name and surname
      final Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = incidentStatusHistory.getUserName();

      // BEGIN, CR00160459, ZV
      incidentStatusHistoryDetails.userName = incidentStatusHistory
          .getUserName();
      // END, CR00160459

      incidentStatusHistoryDetails.concernRoleName = usersObj
          .getFullName(usersKey).fullname;
      // END, CR00141707

      incidentStatusHistoryDetails.incidentStatus = incidentStatusHistory
          .getStatus().getCode();
      incidentStatusHistoryDetails.incidentStatusDateTime = incidentStatusHistory
          .getEventDateTime();
      incidentStatusHistoryDetails.incidentStatusHistoryID = incidentStatusHistory
          .getID();

      incidentStatusHistoryDetailsList.dtlsList
          .addRef(incidentStatusHistoryDetails);
    }

    return incidentStatusHistoryDetailsList;
  }

  // _________________________________________________________________________
  /**
   * Method for maintaining an Incident.
   *
   * @param details
   *          Details of the Incident to maintain
   */
  @Override
  public void maintainIncident1(final MaintainIncidentDetails1 details)
      throws AppException, InformationalException {

    final Incident incidentObj = incidentDAO
        .get(details.incidentDtls.incidentID);

    // BEGIN, CR00127776, POB

    final CreateIncidentParticipantRoleDetails createIncidentParticipantRoleDetails = new CreateIncidentParticipantRoleDetails();

    createIncidentParticipantRoleDetails.assign(details.reporter);

    // were new details specified
    // BEGIN, CR00184101, ZV
    final boolean newReporterSpecified = isNewReporterSpecified(
        details).isNewReporterSpecifiedInd;

    // END, CR00184101

    // BEGIN, CR00128602, POB
    if (newReporterSpecified) {
      // validate no more than one option chosen
      // BEGIN, CR00180707, ZV
      validateReporterDetails1(details.reporter, details.incidentDtls);
      // END, CR00180707
    }
    // END, CR00128602

    // BEGIN, CR00160459, ZV
    if (details.reporter.reportedByMeInd) {
      details.reporter.userName = TransactionInfo.getProgramUser();
    }

    // if anonymous or new details specified, delete old reporter record
    // if one exists
    if (newReporterSpecified) {
      final Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO
          .searchActiveByIncidentAndRole(incidentObj,
              INCIDENTPARTICIPANTROLEEntry.REPORTER);

      final Iterator<IncidentParticipant> incidentParticipantSetIterator = incidentParticipantSet
          .iterator();

      while (incidentParticipantSetIterator.hasNext()) {
        final IncidentParticipant incidentParticipantObj = incidentParticipantSetIterator
            .next();

        // BEGIN, CR00149999, ZV
        incidentParticipantObj.cancel(details.reporter.versionNo);
        // END, CR00149999
      }
    }
    // END, CR00127776
    // END, CR00160459

    incidentObj.setType(INCIDENTTYPEEntry.get(details.incidentDtls.type));
    incidentObj
        .setSeverity(INCIDENTSEVERITYEntry.get(details.incidentDtls.severity));
    incidentObj.setSensitivity(
        SENSITIVITYEntry.get(details.incidentDtls.sensitivityCode));

    // BEGIN, CR00386722, MP
    incidentObj
        .setCategory(INCIDENTCATEGORYEntry.get(details.incidentDtls.category));
    // END, CR00386722

    // BEGIN, CR00180934, ZV
    incidentObj.setIncidentDate(details.incidentDtls.incidentDate);
    incidentObj.setIncidentTime(details.incidentDtls.incidentTime);
    // END, CR00180934
    incidentObj.setTimeOfDay(
        INCIDENTTIMEOFDAYEntry.get(details.incidentDtls.timeOfDay));
    incidentObj.setLocation(details.incidentDtls.location);
    incidentObj.appendDescription(details.incidentDtls.description);

    incidentObj.setReportMethod(
        INCIDENTREPORTMETHODEntry.get(details.incidentDtls.reportMethod));
    incidentObj.setAnonymousReporter(details.incidentDtls.anonymousReportInd);

    incidentObj.modify(details.incidentDtls.versionNo);

    // BEGIN, CR00127776, POB
    // if not an anonymous report, create the chosen incident participant
    // BEGIN, CR00128602, POB
    if (!details.incidentDtls.anonymousReportInd && newReporterSpecified) {
      // END, CR00128602

      final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
          .newInstance();

      incidentParticipantObj.setIncident(incidentObj);
      incidentParticipantObj.setRole(INCIDENTPARTICIPANTROLEEntry.REPORTER);

      if (details.reporter.userName != null
          && !details.reporter.userName.equals("")) {
        incidentParticipantObj.setUserName(details.reporter.userName);
      } else {

        final ConcernRoleKey concernRoleKey = getConcernRoleIDForParticipant(
            createIncidentParticipantRoleDetails);

        incidentParticipantObj.setConcernRoleID(concernRoleKey.concernRoleID);
      }

      incidentParticipantObj.insert();
    }
    // END, CR00127776

  }

  // ____________________________________________________________________________
  /**
   * Method to view an Incident.
   *
   * @param key
   *          ID of the Incident to view
   *
   * @return Details of the Incident for viewing on screen
   */
  @Override
  public ViewIncidentDetails1 viewIncident1(final IncidentKey key)
      throws AppException, InformationalException {

    final ViewIncidentDetails1 viewIncidentDetails = new ViewIncidentDetails1();

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    // BEGIN, RTC 183047, COF
    if (!sensitivityChecker(incidentObj, 14)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    // BEGIN, CR00300328, ZV
    incidentObj.checkSecurity(LOCATIONACCESSTYPEEntry.READ);
    // END, CR00300328

    final INCIDENTTYPEEntry incidentType = incidentObj.getType();

    // BEGIN, CR00160459, ZV
    viewIncidentDetails.pageDescription = getIncidentContextDescription(
        key).description;
    // END, CR00160459

    viewIncidentDetails.incidentDtls.type = incidentType.getCode();

    viewIncidentDetails.incidentDtls.status = incidentObj.getLifecycleState()
        .getCode();
    viewIncidentDetails.incidentDtls.closureReason = incidentObj
        .getClosureReason().getCode();
    viewIncidentDetails.incidentDtls.closureComment = incidentObj
        .getClosureComment();
    // BEGIN, CR00160459, ZV
    viewIncidentDetails.incidentDtls.closureDate = incidentObj
        .getIncidentClosureDate();
    // END, CR00160459
    // BEGIN, CR00194113, ZV
    viewIncidentDetails.incidentDtls.recordedDate = incidentObj
        .getRecordedDate();
    // END, CR00194113
    viewIncidentDetails.incidentDtls.severity = incidentObj.getSeverity()
        .getCode();
    viewIncidentDetails.incidentDtls.sensitivityCode = incidentObj
        .getSensitivity().getCode();

    // BEGIN, CR00386722, MP
    viewIncidentDetails.incidentDtls.category = incidentObj.getCategory()
        .getCode();
    // END, CR00386722

    // BEGIN, CR00180934, ZV
    viewIncidentDetails.incidentDtls.incidentDate = incidentObj
        .getIncidentDate();
    viewIncidentDetails.incidentDtls.incidentTime = incidentObj
        .getIncidentTime();
    if (incidentObj.getIncidentTime().isZero()) {
      viewIncidentDetails.incidentDateTime = incidentObj.getIncidentDate()
          .getDateTime();
    } else {
      // BEGIN, CR00188956, ZV
      final Calendar calendar = viewIncidentDetails.incidentDtls.incidentTime
          .getCalendar();

      viewIncidentDetails.incidentDateTime = new DateTime(
          viewIncidentDetails.incidentDtls.incidentDate.getDateTime().addTime(
              calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE),
              calendar.get(Calendar.SECOND)));
      // END, CR00188956
      viewIncidentDetails.incidentDateTimeInd = true;
    }
    // END, CR00180934
    viewIncidentDetails.incidentDtls.timeOfDay = incidentObj.getTimeOfDay()
        .getCode();
    viewIncidentDetails.incidentDtls.location = incidentObj.getLocation();
    viewIncidentDetails.incidentDtls.description = incidentObj.getDescription();
    viewIncidentDetails.incidentDtls.reportMethod = incidentObj
        .getReportMethod().getCode();
    viewIncidentDetails.incidentDtls.anonymousReportInd = incidentObj
        .isAnonymousReporter();
    // BEGIN, CR00149999, ZV
    viewIncidentDetails.incidentDtls.incidentID = incidentObj.getID();
    // END, CR00149999

    // BEGIN, CR00127598, POB
    if (viewIncidentDetails.incidentDtls.anonymousReportInd) {
      viewIncidentDetails.reporterIncidentParticipantRoleID = 0;
      // BEGIN, CR00190258, CL
      viewIncidentDetails.reporterFullName = new curam.util.exception.LocalisableString(
          curam.message.GENERALCONCERN.TEXT_ANONYMOUS)
              .getMessage(TransactionInfo.getProgramLocale());
      // END, CR00190258
      viewIncidentDetails.reporterConcernRoleID = 0;
    }
    // END, CR00127598

    viewIncidentDetails.incidentDtls.versionNo = incidentObj.getVersionNo();

    final Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO
        .searchByIncident(incidentObj);

    final Iterator<IncidentParticipant> incidentParticipantSetIterator = incidentParticipantSet
        .iterator();

    viewIncidentDetails.roles = new IncidentParticipantRoleDetailsList();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    while (incidentParticipantSetIterator.hasNext()) {

      final IncidentParticipant incidentParticipantObj = incidentParticipantSetIterator
          .next();

      final IncidentParticipantRoleDetails incidentParticipantRoleDetails = new IncidentParticipantRoleDetails();

      incidentParticipantRoleDetails.incidentParticipantRoleID = incidentParticipantObj
          .getID();
      incidentParticipantRoleDetails.incidentParticipantRoleType = incidentParticipantObj
          .getRole().getCode();
      incidentParticipantRoleDetails.concernRoleID = incidentParticipantObj
          .getConcernRoleID();
      incidentParticipantRoleDetails.userName = incidentParticipantObj
          .getUserName();
      incidentParticipantRoleDetails.recordStatus = incidentParticipantObj
          .getLifecycleState().getCode();
      // BEGIN, CR00149999, ZV
      incidentParticipantRoleDetails.versionNo = incidentParticipantObj
          .getVersionNo();
      // END, CR00149999

      if (incidentParticipantRoleDetails.concernRoleID == 0) {

        usersKey.userName = incidentParticipantRoleDetails.userName;

        incidentParticipantRoleDetails.fullName = userAccessObj
            .getFullName(usersKey).fullname;

      } else {

        concernRoleKey.concernRoleID = incidentParticipantRoleDetails.concernRoleID;

        incidentParticipantRoleDetails.fullName = concernRoleObj
            .readConcernRoleName(concernRoleKey).concernRoleName;
      }

      if (incidentParticipantRoleDetails.incidentParticipantRoleType
          .equals(INCIDENTPARTICIPANTROLE.AGAINST)) {

        viewIncidentDetails.incidentConcernRoleID = incidentParticipantRoleDetails.concernRoleID;

      } else if (incidentParticipantRoleDetails.incidentParticipantRoleType
          .equals(INCIDENTPARTICIPANTROLE.REPORTER)
          && !incidentParticipantRoleDetails.recordStatus
              .equals(RECORDSTATUSEntry.CANCELLED.getCode())) {

        viewIncidentDetails.reporterIncidentParticipantRoleID = incidentParticipantRoleDetails.incidentParticipantRoleID;
        viewIncidentDetails.reporterFullName = incidentParticipantRoleDetails.fullName;
        viewIncidentDetails.reporterConcernRoleID = incidentParticipantRoleDetails.concernRoleID;
        // BEGIN, CR00160459, ZV
        viewIncidentDetails.reportedByMeInd = incidentParticipantRoleDetails.userName
            .equals(TransactionInfo.getProgramUser());
        // END, CR00160459
        // BEGIN, CR00149999, ZV
        viewIncidentDetails.reporterVersionNo = incidentParticipantRoleDetails.versionNo;
        // END, CR00149999

      }

      // BEGIN, CR00127776, POB
      if (!incidentParticipantRoleDetails.incidentParticipantRoleType
          .equals(INCIDENTPARTICIPANTROLE.REPORTER)) {
        viewIncidentDetails.roles.dtlsList
            .addRef(incidentParticipantRoleDetails);
      }
      // END, CR00127776

    }

    // BEGIN, CR00141707, MC
    // If this incident is closed set this indicator which will be used to
    // tell if the UI should display the closure details.
    viewIncidentDetails.incidentClosedInd = incidentObj.getLifecycleState()
        .equals(INCIDENTSTATUSEntry.CLOSED);
    // BEGIN, CR00141707

    return viewIncidentDetails;
  }

  // BEGIN, CR00180707, ZV
  // ____________________________________________________________________________
  /**
   * Method to validate the entered reporter details.
   *
   * @param reporterDetails
   *          Details of the user or participant chosen as the reporter
   * @param incidentDtls
   *          Reporter Incident details
   *          <p>
   *          It adds the following informational exceptions to the validation
   *          helper when validation fails.
   *          </p>
   *          <ul>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_MANDATORY_REPORTER_NOT_SET}
   *          - If incident is not anonymously reported and reporter is not
   *          entered.</li>
   *          <li>
   *          {@link FACADEINCIDENT#ERR_INCIDENT_XFV_REPORTER_MORE_THAN_ONE_SPECIFIED}
   *          - If more than one method of specifying a reporter is chosen.</li>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_REPORTER_NO_NAME_SPECIFIED}
   *          - If a new participant is specified as the incident reporter and a
   *          participant name is not given.</li>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_REPORTER_PHONE_NO_AREA_CODE}
   *          - If an area code is not specified in conjunction with a phone
   *          number.</li>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_REPORTER_AREA_CODE_NO_PHONE}
   *          - If a phone number is not specified in conjunction with an area
   *          number.</li>
   *          <li>
   *          {@link FACADEINCIDENT#ERR_INCIDENT_XFV_NO_REPORTERS_FOR_ANONYMOUS_INCIDENT}
   *          - If an incident is marked as anonymously reported, when
   *          participant roles of type reporter are recorded for it.</li>
   *          </ul>
   */
  @Override
  protected void validateReporterDetails1(
      final CreateIncidentParticipantRoleDetails1 reporterDetails,
      final IncidentDtls incidentDtls)
      throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    final boolean userNameSpecified = reporterDetails.userName.length() > 0;
    final boolean registeredParticipantSpecified = reporterDetails.participantRoleID != 0;
    boolean newParticipantSpecified = true;

    // determine if any of the new participant details have been
    // specified
    final Address addressObj = AddressFactory.newInstance();

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = reporterDetails.address;

    final boolean addressEmpty = addressObj.isEmpty(otherAddressData).emptyInd;
    final boolean areaCodeEmpty = reporterDetails.phoneAreaCode.length() == 0;
    final boolean phoneNumberEmpty = reporterDetails.phoneNumber.length() == 0;

    if (reporterDetails.participantName.length() == 0
        && reporterDetails.email.length() == 0 && areaCodeEmpty
        && phoneNumberEmpty && addressEmpty) {
      newParticipantSpecified = false;
    }

    if (!incidentDtls.anonymousReportInd) {

      // if nothing specified throw an error
      // BEGIN, CR00160459, ZV
      if (!userNameSpecified && !registeredParticipantSpecified
          && !newParticipantSpecified && !reporterDetails.reportedByMeInd) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(
                new AppException(
                    FACADEINCIDENT.ERR_INCIDENT_XFV_MANDATORY_REPORTER_NOT_SET),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
      }

      // if more than one option chosen throw an error
      if (userNameSpecified && (registeredParticipantSpecified
          || newParticipantSpecified || reporterDetails.reportedByMeInd)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_MORE_THAN_ONE_SPECIFIED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
      }

      // if more than one option chosen throw an error
      if (registeredParticipantSpecified && (userNameSpecified
          || newParticipantSpecified || reporterDetails.reportedByMeInd)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_MORE_THAN_ONE_SPECIFIED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

      if (newParticipantSpecified
          && (userNameSpecified || registeredParticipantSpecified
              || reporterDetails.reportedByMeInd)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_MORE_THAN_ONE_SPECIFIED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                4);
      }
      // END, CR00160459

      if (newParticipantSpecified) {

        if (reporterDetails.participantName.length() == 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager()
              .addInfoMgrExceptionWithLookup(new AppException(
                  FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_NO_NAME_SPECIFIED),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
        }

        if (areaCodeEmpty && !phoneNumberEmpty) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager()
              .addInfoMgrExceptionWithLookup(new AppException(
                  FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_PHONE_NO_AREA_CODE),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  1);
        }

        if (phoneNumberEmpty && !areaCodeEmpty) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager()
              .addInfoMgrExceptionWithLookup(new AppException(
                  FACADEINCIDENT.ERR_INCIDENT_XFV_REPORTER_AREA_CODE_NO_PHONE),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  1);
        }

      }

    } else {
      // BEGIN, CR00160459, ZV
      if (userNameSpecified || registeredParticipantSpecified
          || newParticipantSpecified || reporterDetails.reportedByMeInd) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_NO_REPORTERS_FOR_ANONYMOUS_INCIDENT),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }
      // END, CR00160459
    }

    informationalManager.failOperation();
  }

  // END, CR00180707

  // ____________________________________________________________________________
  /**
   * Method to validate the entered participant details.
   *
   * @param details
   *          Details of the user or participant chosen as the incident
   *          participant
   *          <p>
   *          It adds the following informational exceptions to the validation
   *          helper when validation fails.
   *          </p>
   *          <ul>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_MANDATORY_PARTICIPANT_NOT_SET}
   *          - If incident participant is not entered.</li>
   *          <li>
   *          {@link FACADEINCIDENT#ERR_INCIDENT_XFV_PARTICIPANT_MORE_THAN_ONE_SPECIFIED}
   *          - If more than one method of specifying an incident participant is
   *          chosen.</li>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_PARTICIPANT_NO_NAME_SPECIFIED}
   *          - If a new participant is specified and a participant name is not
   *          given.</li>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_PARTICIPANT_PHONE_NO_AREA_CODE}
   *          - If an area code is not specified in conjunction with a phone
   *          number.</li>
   *          <li>{@link FACADEINCIDENT#ERR_INCIDENT_XFV_PARTICIPANT_AREA_CODE_NO_PHONE}
   *          - If a phone number is not specified in conjunction with an area
   *          code.</li>
   *          </ul>
   */
  @Override
  protected void validateIncidentParticipantDetails1(
      final CreateIncidentParticipantRoleDetails1 details)
      throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    // BEGIN, CR00183167, ZV
    boolean incidentParticipantSpecified = false;

    final StringList incidentParticipantStringList = StringUtil
        .tabText2StringListWithTrim(details.incidentParticipantRoleIDTabList);

    for (int i = 0; i < incidentParticipantStringList.size(); i++) {

      if (incidentParticipantStringList.item(i).length() > 0) {
        incidentParticipantSpecified = true;
        break;
      }
    }
    // END, CR00183167

    final boolean userNameSpecified = details.userName.length() > 0;
    final boolean registeredParticipantSpecified = details.participantRoleID != 0;
    boolean newParticipantSpecified = true;

    // determine if any of the new participant details have been
    // specified
    final Address addressObj = AddressFactory.newInstance();

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = details.address;

    final boolean addressEmpty = addressObj.isEmpty(otherAddressData).emptyInd;
    final boolean areaCodeEmpty = details.phoneAreaCode.equals("");
    final boolean phoneNumberEmpty = details.phoneNumber.equals("");

    if (details.participantName.length() == 0 && details.email.length() == 0
        && areaCodeEmpty && phoneNumberEmpty && addressEmpty) {
      newParticipantSpecified = false;
    }

    // if nothing specified throw an error
    // BEGIN, CR00160459, ZV
    // BEGIN, CR00183167, ZV
    if (!userNameSpecified && !registeredParticipantSpecified
        && !newParticipantSpecified && !details.reportedByMeInd
        && !incidentParticipantSpecified) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_MANDATORY_PARTICIPANT_NOT_SET),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    // if more than one option chosen throw an error
    if (userNameSpecified
        && (registeredParticipantSpecified || newParticipantSpecified
            || details.reportedByMeInd || incidentParticipantSpecified)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_MORE_THAN_ONE_SPECIFIED),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
    }

    // if more than one option chosen throw an error
    if (registeredParticipantSpecified
        && (userNameSpecified || newParticipantSpecified
            || details.reportedByMeInd || incidentParticipantSpecified)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_MORE_THAN_ONE_SPECIFIED),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
    }

    if (newParticipantSpecified
        && (userNameSpecified || registeredParticipantSpecified
            || details.reportedByMeInd || incidentParticipantSpecified)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_MORE_THAN_ONE_SPECIFIED),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
    }

    if (incidentParticipantSpecified
        && (userNameSpecified || registeredParticipantSpecified
            || newParticipantSpecified || details.reportedByMeInd)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(new AppException(
              FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_MORE_THAN_ONE_SPECIFIED),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              3);
    }
    // END, CR00183167
    // END, CR00160459

    if (newParticipantSpecified) {

      if (details.participantName.equals("")) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_NO_NAME_SPECIFIED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

      if (areaCodeEmpty && !phoneNumberEmpty) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_PHONE_NO_AREA_CODE),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

      if (phoneNumberEmpty && !areaCodeEmpty) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .addInfoMgrExceptionWithLookup(new AppException(
                FACADEINCIDENT.ERR_INCIDENT_XFV_PARTICIPANT_AREA_CODE_NO_PHONE),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
      }

    }

    informationalManager.failOperation();
  }

  // END, CR00167126

  // BEGIN, CR00149999, ZV
  // ____________________________________________________________________________
  /**
   * Method to delete an Incident using optimistic locking.
   *
   * @param key
   *          ID and versionNo of the Incident to delete
   */
  @Override
  public void deleteIncidentWithVersionNo(final IncidentIDAndVersionNoDtls key)
      throws AppException, InformationalException {

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    incidentObj.cancel(key.versionNo);
  }

  // ____________________________________________________________________________
  /**
   * Method to delete an incident participant.
   *
   * @param key
   *          ID and versionNo of the Incident Participant to delete
   */
  @Override
  public void deleteIncidentParticipant1(
      final IncidentParticipantRoleIDAndVersionNoDtls key)
      throws AppException, InformationalException {

    final IncidentParticipant incidentParticipantObj = incidentParticipantDAO
        .get(key.incidentParticipantRoleID);

    incidentParticipantObj.cancel(key.versionNo);

  }

  // BEGIN, CR00224036, ZV
  // ____________________________________________________________________________
  /**
   * Method to close an Incident using optimistic locking.
   *
   * @param key
   *          details of the Incident to close
   */
  @Override
  public void closeIncidentWithVersionNo(
      final CloseIncidentWithVersionNoDetails key)
      throws AppException, InformationalException {

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    incidentObj.close(key.comments,
        INCIDENTCLOSUREREASONEntry.get(key.closureReason), key.versionNo);
  }

  // END, CR00224036
  // END, CR00149999

  // BEGIN, CR00175719, ZV
  // ___________________________________________________________________________
  /**
   * Lists the contact log contact participant records for a specified incident.
   *
   * @param key
   *          The Incident key
   *
   * @return The Incident Contact Log Contact Participant details list
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogAttendeeList listIncidentContactLogAttendee(
      final IncidentKey key) throws AppException, InformationalException {

    final ContactLogAttendeeList contactLogAttendeeList = new ContactLogAttendeeList();

    final ContactLogAttendee contactLogAttendeeObj = ContactLogAttendeeFactory
        .newInstance();
    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.incidentID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    contactLogAttendeeList.attendeeList = contactLogAttendeeObj
        .listByLinkID(contactLogLinkIDLinkTypeKey);

    return contactLogAttendeeList;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Search for Incident Contact Logs that match the given search criteria.
   *
   * @param key
   *          The criteria the Contact Logs should match.
   *
   * @return contact log details list
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   *             {@link Incidents#searchContactLogs(ContactLogSearchKey1)}.
   *
   *             This method is deprecated as informational messages are not
   *             returned. This method is replaced by
   *             searchContactLogs(ContactLogSearchKey1) which returns the
   *             informational message along with search contact log details as
   *             well. See release note: CS-09152/CR00282028.
   */
  @Override
  @Deprecated
  public ContactLogSearchDetails searchContactLog(
      final ContactLogSearchKey1 key)
      throws AppException, InformationalException {

    // END, CR00282028
    final ContactLogSearchDetails contactLogSearchDetails = new ContactLogSearchDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.SEARCH)) {

      key.key.key.linkType = CONTACTLOGLINKTYPE.INCIDENT;

      contactLogSearchDetails.dtlsList = curam.core.sl.fact.ContactLogFactory
          .newInstance().searchContactLogs1(key.key);

    }

    final ContactLog contactLogObj = ContactLogFactory.newInstance();

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < contactLogSearchDetails.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails
          .assign(contactLogSearchDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj
          .formatContactLogPurpose(readContactLogDetails);

      contactLogSearchDetails.dtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }

    return contactLogSearchDetails;
  }

  // BEGIN, CR00407986, AC
  // ___________________________________________________________________________
  // BEGIN, CR00400630, AC
  /**
   * Method to list all contact logs for the specified incident.
   *
   * @param key
   *          ID of the incident
   *
   * @return List of contact log details
   *
   *         * @deprecated and replaced by method
   *         listCaseContactLogDetails(CaseKey). Since V6.0.4.4.see release
   *         notes of CR00400630.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  @Deprecated
  public ListContactLogDetails listContactLogForIncident1(final IncidentKey key)
      throws AppException, InformationalException {

    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.incidentID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    final ListContactLogDetails listContactLogDetails = new ListContactLogDetails();

    listContactLogDetails.dtlsList = contactLogObj
        .list1(contactLogLinkIDLinkTypeKey);

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < listContactLogDetails.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails
          .assign(listContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj
          .formatContactLogPurpose(readContactLogDetails);

      listContactLogDetails.dtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }

    return listContactLogDetails;

  }

  // END, CR00175719
  // END, CR00400630
  // BEGIN, CR00147819, ZV
  // ___________________________________________________________________________
  /**
   * @param key
   *          ID of the Participant concerned
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   *             {@link #listIncidentsForParticipant2()}. Method to list
   *             incidents for a given Participant.
   */
  @Override
  @Deprecated
  public IncidentForParticipantDetailsList listIncidentsForParticipant1(
      final ConcernRoleKey key) throws AppException, InformationalException {

    return populateIncidentForParticipantList(
        incidentDAO.searchByParticipant1(key.concernRoleID), key);
  }

  // ___________________________________________________________________________
  /**
   * Method to list incidents for a given Participant.
   *
   * @param key
   *          ID of the Participant concerned
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentForParticipantDetailsList1 listIncidentsForParticipant2(
      final ConcernRoleKey key) throws AppException, InformationalException {

    // BEGIN, CR00301053, ZV
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
        .get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = key.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
        .checkParticipantSecurity(participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00301053

    return populateIncidentForParticipantList1(
        incidentDAO.searchByParticipant1(key.concernRoleID), key);
  }

  // ___________________________________________________________________________
  /**
   * @param incidentsSet
   *          incident details set
   * @param key
   *          concern role key to populate incidents for
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   *             {@link #populateIncidentForParticipantList1()}. Method to
   *             populate incident list based on incident set.
   */
  @Deprecated
  protected IncidentForParticipantDetailsList populateIncidentForParticipantList(
      final Set<Incident> incidentsSet, final ConcernRoleKey key)
      throws AppException, InformationalException {

    final IncidentForParticipantDetailsList incidentForParticipantDetailsList = populateIncidentList(
        incidentsSet, key);

    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidentsForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidents;

      // Display the duplicate soft links in a tab format
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory
          .newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory
          .newInstance();

      final ConcernRoleKey currentKey = new ConcernRoleKey();

      currentKey.concernRoleID = key.concernRoleID;

      // Build up the xml data needed for the tab widget
      incidentForParticipantDetailsList.renderXML = clientMergeObj
          .getDuplicateMenuRendererData(key, currentKey, dupPageIdentifier,
              origPageIdentifier);

      // Set an indicator if this concern has duplicates
      // Check for duplicates
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      incidentForParticipantDetailsList.ind = clientMergeSLObj
          .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    }
    // END, CR00221607

    return incidentForParticipantDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * @param incidentsSet
   *          incident details set
   * @param key
   *          concern role key to populate incidents for
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   *             {@link #populateIncidentList1()}. Method to populate incident
   *             list based on incident set.
   */
  @Deprecated
  protected IncidentForParticipantDetailsList populateIncidentList(
      final Set<Incident> incidentsSet, final ConcernRoleKey key)
      throws AppException, InformationalException {

    final IncidentForParticipantDetailsList incidentForParticipantDetailsList = new IncidentForParticipantDetailsList();

    IncidentForParticipantDetails incidentForParticipantDetails;
    final Iterator<Incident> incidentsSetIterator = incidentsSet.iterator();

    while (incidentsSetIterator.hasNext()) {

      final Incident incidentObj = incidentsSetIterator.next();

      // BEGIN, RTC 177382, COF
      if (!incidentObj.isSensitiveForCurrentUser()) {
        continue;
      }

      // END, RTC 177382

      incidentForParticipantDetails = new IncidentForParticipantDetails();

      incidentForParticipantDetails.incidentDtls.incidentID = incidentObj
          .getID();
      incidentForParticipantDetails.incidentDtls.anonymousReportInd = incidentObj
          .isAnonymousReporter();
      incidentForParticipantDetails.incidentDtls.type = incidentObj.getType()
          .getCode();
      incidentForParticipantDetails.incidentDtls.closureDate = incidentObj
          .getIncidentClosureDate();
      incidentForParticipantDetails.incidentDtls.recordedDate = incidentObj
          .getRecordedDate();
      incidentForParticipantDetails.incidentDtls.severity = incidentObj
          .getSeverity().getCode();
      incidentForParticipantDetails.incidentDtls.status = incidentObj
          .getLifecycleState().getCode();
      // BEGIN, CR00219597, MC
      incidentForParticipantDetails.incidentDtls.versionNo = incidentObj
          .getVersionNo();
      // END, CR00219597

      // BEGIN, CR00190355, MC
      if (incidentForParticipantDetails.incidentDtls.anonymousReportInd) {
        // BEGIN, CR00190258, CL
        incidentForParticipantDetails.reportedBy = new curam.util.exception.LocalisableString(
            curam.message.GENERALCONCERN.TEXT_ANONYMOUS)
                .getMessage(TransactionInfo.getProgramLocale());
        // END, CR00190258
      } else {
        final IncidentKey incidentKey = new IncidentKey();

        incidentKey.incidentID = incidentObj.getID();
        incidentForParticipantDetails.reportedBy = readReportedByName(
            incidentKey).reportedBy;
      }
      // END, CR00190355

      incidentForParticipantDetailsList.dtlsList
          .addRef(incidentForParticipantDetails);
    }

    final curam.core.facade.intf.ParticipantContext participantContextObj = ParticipantContextFactory
        .newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    final ParticipantContextDescriptionDetails participantContextDescriptionDetails = participantContextObj
        .readContextDescription(participantContextDescriptionKey);

    incidentForParticipantDetailsList.pageDescription = participantContextDescriptionDetails.description;

    return incidentForParticipantDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to populate incident list based on incident set.
   *
   * @param incidentsSet
   *          incident details set
   * @param key
   *          concern role key to populate incidents for
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected IncidentForParticipantDetailsList1 populateIncidentForParticipantList1(
      final Set<Incident> incidentsSet, final ConcernRoleKey key)
      throws AppException, InformationalException {

    final IncidentForParticipantDetailsList1 incidentForParticipantDetailsList1 = populateIncidentList1(
        incidentsSet, key);

    if (Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidentsForDuplicate2;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidents2;

      // Display the duplicate soft links in a tab format
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory
          .newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory
          .newInstance();

      final ConcernRoleKey currentKey = new ConcernRoleKey();

      currentKey.concernRoleID = key.concernRoleID;

      // Build up the xml data needed for the tab widget
      incidentForParticipantDetailsList1.renderXML = clientMergeObj
          .getDuplicateMenuRendererData(key, currentKey, dupPageIdentifier,
              origPageIdentifier);

      // Set an indicator if this concern has duplicates
      // Check for duplicates
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      incidentForParticipantDetailsList1.ind = clientMergeSLObj
          .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    }

    return incidentForParticipantDetailsList1;
  }

  // ___________________________________________________________________________
  /**
   * Populates the incident list based on the specified set of incident details.
   *
   * @boread ConcernRoleDuplicate
   *
   * @boread ClientMerge
   * @boread Incident
   * @param incidentsSet
   *          A set of incident details.
   * @param key
   *          The concern role identifier for whom the incident details are
   *          being created.
   *
   * @return List of incidents for the specified participant.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public IncidentForParticipantDetailsList1 populateIncidentList1(
      final Set<Incident> incidentsSet, final ConcernRoleKey key)
      throws AppException, InformationalException {

    final IncidentForParticipantDetailsList1 incidentForParticipantDetailsList1 = new IncidentForParticipantDetailsList1();

    IncidentForParticipantDetails1 incidentForParticipantDetails1;
    final Iterator<Incident> incidentsSetIterator = incidentsSet.iterator();

    // BEGIN, CR00289903, ZV
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();
    final CuramInd duplicateClientIndicator = clientMergeObj
        .isConcernRoleDuplicate(key);

    // END, CR00289903

    while (incidentsSetIterator.hasNext()) {

      final Incident incidentObj = incidentsSetIterator.next();

      // BEGIN, RTC 177382, COF
      if (!incidentObj.isSensitiveForCurrentUser()) {
        continue;
      }
      // END, RTC 177382

      incidentForParticipantDetails1 = new IncidentForParticipantDetails1();

      incidentForParticipantDetails1.incidentDtls.incidentID = incidentObj
          .getID();
      incidentForParticipantDetails1.incidentDtls.anonymousReportInd = incidentObj
          .isAnonymousReporter();
      incidentForParticipantDetails1.incidentDtls.type = incidentObj.getType()
          .getCode();
      incidentForParticipantDetails1.incidentDtls.closureDate = incidentObj
          .getIncidentClosureDate();
      incidentForParticipantDetails1.incidentDtls.recordedDate = incidentObj
          .getRecordedDate();
      incidentForParticipantDetails1.incidentDtls.severity = incidentObj
          .getSeverity().getCode();
      incidentForParticipantDetails1.incidentDtls.status = incidentObj
          .getLifecycleState().getCode();
      incidentForParticipantDetails1.incidentDtls.versionNo = incidentObj
          .getVersionNo();

      if (incidentForParticipantDetails1.incidentDtls.status
          .equals(INCIDENTSTATUS.CANCELLED)) {
        incidentForParticipantDetails1.cancelledInd = true;
      }

      if (incidentForParticipantDetails1.incidentDtls.anonymousReportInd) {

        incidentForParticipantDetails1.reportedBy = new curam.util.exception.LocalisableString(
            curam.message.GENERALCONCERN.TEXT_ANONYMOUS)
                .getMessage(TransactionInfo.getProgramLocale());
      } else {
        final IncidentKey incidentKey = new IncidentKey();

        incidentKey.incidentID = incidentObj.getID();
        incidentForParticipantDetails1.reportedBy = readReportedByName(
            incidentKey).reportedBy;
      }

      // BEGIN, CR00289903, ZV
      incidentForParticipantDetails1.editableIndOpt = !(incidentForParticipantDetails1.cancelledInd
          || duplicateClientIndicator.statusInd);
      // END, CR00289903

      incidentForParticipantDetailsList1.dtlsList
          .addRef(incidentForParticipantDetails1);
    }

    final curam.core.facade.intf.ParticipantContext participantContextObj = ParticipantContextFactory
        .newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    final ParticipantContextDescriptionDetails participantContextDescriptionDetails = participantContextObj
        .readContextDescription(participantContextDescriptionKey);

    incidentForParticipantDetailsList1.pageDescription = participantContextDescriptionDetails.description;
    // BEGIN, CR00289903, ZV
    incidentForParticipantDetailsList1.createIncidentIndOpt = !duplicateClientIndicator.statusInd;
    // END, CR00289903

    return incidentForParticipantDetailsList1;
  }

  // BEGIN, CR00190355, MC
  // __________________________________________________________________________
  /**
   * Convenience method to read the full name of the reporter of an incident.
   *
   * @param incidentKey
   *          The incident instance to read the reporter of.
   *
   * @return the full name of the reporter of an incident.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentReportedByName readReportedByName(
      final IncidentKey incidentKey)
      throws AppException, InformationalException {

    final IncidentReportedByName incidentReportedByName = new IncidentReportedByName();

    final Incident incidentObj = incidentDAO.get(incidentKey.incidentID);

    // BEGIN, RTC 183047, COF
    // In CEF this is called by Incidents#populateIncidentList and
    // Incidents#populateIncidentList1 which already filter out incidents with
    // higher level
    // of sensitivity than the user's.
    if (!sensitivityChecker(incidentObj, 15)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    // BEGIN, CR00224036, ZV
    final IncidentParticipant incidentReporterObj = incidentObj.getReporter();

    if (incidentReporterObj.getConcernRoleID() == 0) {

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = incidentReporterObj.getUserName();

      incidentReportedByName.reportedBy = userAccessObj
          .getFullName(usersKey).fullname;

    } else {

      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = incidentReporterObj.getConcernRoleID();

      incidentReportedByName.reportedBy = concernRoleObj
          .readConcernRoleName(concernRoleKey).concernRoleName;
    }
    // END, CR00224036

    return incidentReportedByName;
  }

  // END, CR00190355

  // ___________________________________________________________________________
  /**
   * @param key
   *          contains Concern Role key
   *
   * @return list of incidents
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   *             {@link #listIncidentsForDuplicateParticipant2()}. List
   *             incidents for duplicate participant.
   */
  @Override
  @Deprecated
  public IncidentForDuplicateParticipantDetailsList listIncidentsForDuplicateParticipant1(
      final ConcernRoleKey key) throws AppException, InformationalException {

    return populateIncidentForDuplicateParticipantList(
        incidentDAO.searchByParticipant1(key.concernRoleID), key);
  }

  // ___________________________________________________________________________
  /**
   * List incidents for duplicate participant.
   *
   * @param key
   *          contains Concern Role key
   *
   * @return list of incidents
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentForDuplicateParticipantDetailsList1 listIncidentsForDuplicateParticipant2(
      final ConcernRoleKey key) throws AppException, InformationalException {

    // BEGIN, CR00301053, ZV
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
        .get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = key.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
        .checkParticipantSecurity(participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00301053

    return populateIncidentForDuplicateParticipantList1(
        incidentDAO.searchByParticipant1(key.concernRoleID), key);
  }

  // ___________________________________________________________________________
  /**
   * @param incidentsSet
   *          incident details set
   * @param key
   *          concern role key to populate incidents for
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   *             {@link #populateIncidentForDuplicateParticipantList1()}. Method
   *             to populate incident list based on incident set.
   */
  @Deprecated
  protected IncidentForDuplicateParticipantDetailsList populateIncidentForDuplicateParticipantList(
      final Set<Incident> incidentsSet, final ConcernRoleKey key)
      throws AppException, InformationalException {

    final IncidentForDuplicateParticipantDetailsList incidentForDupParticipantDetailsList = new IncidentForDuplicateParticipantDetailsList();

    incidentForDupParticipantDetailsList.IncidentForDupParticipantDetail = populateIncidentList(
        incidentsSet, key);

    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory
        .newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;
    currentKey.concernRoleID = key.concernRoleID;

    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory
        .newInstance();

    // Set the pages to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidentsForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidents;

    // Build up the xml data needed for the tab widget
    incidentForDupParticipantDetailsList.IncidentForDupParticipantDetail.renderXML = clientMergeObj
        .getDuplicateMenuRendererData(concernRoleKey, currentKey,
            dupPageIdentifier, origPageIdentifier);

    return incidentForDupParticipantDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to populate incident list based on incident set.
   *
   * @param incidentsSet
   *          incident details set
   * @param key
   *          concern role key to populate incidents for
   *
   * @return List of Incidents for the participant
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected IncidentForDuplicateParticipantDetailsList1 populateIncidentForDuplicateParticipantList1(
      final Set<Incident> incidentsSet, final ConcernRoleKey key)
      throws AppException, InformationalException {

    final IncidentForDuplicateParticipantDetailsList1 incidentForDupParticipantDetailsList1 = new IncidentForDuplicateParticipantDetailsList1();

    incidentForDupParticipantDetailsList1.IncidentForDupParticipantDetail = populateIncidentList1(
        incidentsSet, key);

    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory
        .newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;
    currentKey.concernRoleID = key.concernRoleID;

    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory
        .newInstance();

    // Set the pages to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidentsForDuplicate2;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIncidents2;

    // Build up the xml data needed for the tab widget
    incidentForDupParticipantDetailsList1.IncidentForDupParticipantDetail.renderXML = clientMergeObj
        .getDuplicateMenuRendererData(concernRoleKey, currentKey,
            dupPageIdentifier, origPageIdentifier);

    return incidentForDupParticipantDetailsList1;
  }

  // BEGIN, CR00357485, AC
  // BEGIN, CR00243200, ZV
  // BEGIN, CR00182243, ZV
  // ___________________________________________________________________________
  /**
   * Method to preview list of Incident Contact Logs.
   *
   * @param key
   *          Contains incident id and list of contact log ids
   *
   * @return The list of Contact Log preview notes details
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.5.0, replaced with
   *             {@link Case#previewIncidentContactLogDetails(PreviewIncidentContactLogIDKey)}
   *             . This method selects the contact log with key of fixed size so
   *             the size of the key is increased. See release note: CR00357485.
   */
  @Override
  @Deprecated
  public PreviewIncidentContactLogXMLDetails previewIncidentContactLogs(
      final PreviewIncidentContactLogKey key)
      throws AppException, InformationalException {

    final PreviewIncidentContactLogXMLDetails previewIncidentContactLogXMLDetails = new PreviewIncidentContactLogXMLDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)
        || key.actionControlID.length() == 0) {

      final ContactLog contactLogObj = ContactLogFactory.newInstance();

      key.previewContactLogKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;
      previewIncidentContactLogXMLDetails.dtls = contactLogObj
          .previewList1(key.previewContactLogKey);

      previewIncidentContactLogXMLDetails.contextDescription = getIncidentContextDescription(
          key.incidentKey).description;
    }

    return previewIncidentContactLogXMLDetails;
  }

  // END, CR00182243
  // END, CR00243200
  // END, CR00357485
  // BEGIN, CR00183167, ZV
  // BEGIN, CR00195286, ZV
  // ___________________________________________________________________________
  /**
   * List active concern role participant roles for an incident.
   *
   * @param key
   *          contains Incident key
   * @return list of incident concern role participant roles
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentParticipantDetailsList listIncidentActiveConcernRoleParticipantRole(
      final IncidentKey key) throws AppException, InformationalException {

    final IncidentParticipantDetailsList incidentParticipantDetailsList = listIncidentActiveParticipantRole(
        key);

    for (int i = 0; i < incidentParticipantDetailsList.dtlsList.size(); i++) {
      if (incidentParticipantDetailsList.dtlsList.item(i).userName
          .length() > 0) {
        incidentParticipantDetailsList.dtlsList.remove(i);
        i--;
      }
    }

    return incidentParticipantDetailsList;
  }

  // END, CR00195286

  // BEGIN, CR00195286, ZV
  // ___________________________________________________________________________
  /**
   * List active user participant roles for an incident.
   *
   * @param key
   *          contains Incident key
   * @return list of incident user participant roles
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentParticipantDetailsList listIncidentActiveUserParticipantRole(
      final IncidentKey key) throws AppException, InformationalException {

    final IncidentParticipantDetailsList incidentParticipantDetailsList = listIncidentActiveParticipantRole(
        key);

    for (int i = 0; i < incidentParticipantDetailsList.dtlsList.size(); i++) {
      if (incidentParticipantDetailsList.dtlsList.item(i).userName
          .length() == 0) {
        incidentParticipantDetailsList.dtlsList.remove(i);
        i--;
      }
    }

    return incidentParticipantDetailsList;
  }

  // END, CR00195286
  // END, CR00183167

  // BEGIN, CR00184101, ZV
  // ___________________________________________________________________________
  /**
   * Method to determine if new reporter details were specified.
   *
   * @param details
   *          Details of the participant
   *
   * @return boolean true if any of the screen fields were filled in
   */
  @Override
  protected IsNewReporterSpecifiedDetails isNewReporterSpecified(
      final MaintainIncidentDetails1 details)
      throws AppException, InformationalException {

    final IsNewReporterSpecifiedDetails isNewReporterSpecifiedDetails = new IsNewReporterSpecifiedDetails();

    final CreateIncidentParticipantRoleDetails createIncidentParticipantRoleDetails = new CreateIncidentParticipantRoleDetails();

    createIncidentParticipantRoleDetails.assign(details.reporter);

    // were new details specified
    isNewReporterSpecifiedDetails.isNewReporterSpecifiedInd = isParticipantSpecified(
        createIncidentParticipantRoleDetails);

    if (isNewReporterSpecifiedDetails.isNewReporterSpecifiedInd) {
      return isNewReporterSpecifiedDetails;
    }

    final Incident incidentObj = incidentDAO
        .get(details.incidentDtls.incidentID);

    final Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO
        .searchActiveByIncidentAndRole(incidentObj,
            INCIDENTPARTICIPANTROLEEntry.REPORTER);

    boolean currentUserIsReporterInd = false;

    if (!incidentParticipantSet.isEmpty()) {
      final IncidentParticipant incidentParticipantObj = incidentParticipantSet
          .iterator().next();

      if (incidentParticipantObj.getUserName()
          .equals(TransactionInfo.getProgramUser())) {
        currentUserIsReporterInd = true;
      }
    }

    if (details.reporter.reportedByMeInd) {
      if (!currentUserIsReporterInd) {
        isNewReporterSpecifiedDetails.isNewReporterSpecifiedInd = true;
        return isNewReporterSpecifiedDetails;
      }
    } else {
      if (currentUserIsReporterInd) {
        isNewReporterSpecifiedDetails.isNewReporterSpecifiedInd = true;
        return isNewReporterSpecifiedDetails;
      }
    }

    if (details.incidentDtls.anonymousReportInd) {
      if (!incidentObj.isAnonymousReporter()) {
        isNewReporterSpecifiedDetails.isNewReporterSpecifiedInd = true;
        return isNewReporterSpecifiedDetails;
      }
    } else {
      if (incidentObj.isAnonymousReporter()) {
        isNewReporterSpecifiedDetails.isNewReporterSpecifiedInd = true;
        return isNewReporterSpecifiedDetails;
      }
    }

    return isNewReporterSpecifiedDetails;

  }

  // END, CR00184101

  // BEGIN, CR00195286, ZV
  // ___________________________________________________________________________
  /**
   * List participant roles for an incident.
   *
   * @param key
   *          contains Incident key
   * @return list of incident participant roles
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentParticipantRoleDetailsList listIncidentParticipantRole(
      final IncidentKey key) throws AppException, InformationalException {

    final IncidentParticipantRoleDetailsList incidentParticipantRoleDetailsList = new IncidentParticipantRoleDetailsList();

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    // BEGIN, RTC 183047, COF
    if (!sensitivityChecker(incidentObj, 16)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    final Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO
        .searchByIncident(incidentObj);

    final Iterator<IncidentParticipant> incidentParticipantSetIterator = incidentParticipantSet
        .iterator();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    while (incidentParticipantSetIterator.hasNext()) {

      final IncidentParticipant incidentParticipantObj = incidentParticipantSetIterator
          .next();

      if (!incidentParticipantObj.getRole()
          .equals(INCIDENTPARTICIPANTROLEEntry.REPORTER)) {

        final IncidentParticipantRoleDetails incidentParticipantRoleDetails = new IncidentParticipantRoleDetails();

        incidentParticipantRoleDetails.incidentParticipantRoleID = incidentParticipantObj
            .getID();
        incidentParticipantRoleDetails.incidentParticipantRoleType = incidentParticipantObj
            .getRole().getCode();
        incidentParticipantRoleDetails.recordStatus = incidentParticipantObj
            .getLifecycleState().getCode();
        incidentParticipantRoleDetails.versionNo = incidentParticipantObj
            .getVersionNo();

        if (incidentParticipantObj.getConcernRoleID() == 0) {

          usersKey.userName = incidentParticipantObj.getUserName();

          incidentParticipantRoleDetails.fullName = userAccessObj
              .getFullName(usersKey).fullname;

          incidentParticipantRoleDetails.userName = incidentParticipantObj
              .getUserName();

        } else {

          concernRoleKey.concernRoleID = incidentParticipantObj
              .getConcernRoleID();

          incidentParticipantRoleDetails.fullName = concernRoleObj
              .readConcernRoleName(concernRoleKey).concernRoleName;

          incidentParticipantRoleDetails.concernRoleID = incidentParticipantObj
              .getConcernRoleID();
        }

        incidentParticipantRoleDetailsList.dtlsList
            .addRef(incidentParticipantRoleDetails);
      }

    }

    // BEGIN, CR00243200, ZV
    // Sort incident participant list by names
    final Comparator<IncidentParticipantRoleDetails> participantNameComparator = new ParticipantNameComparator();

    Collections.sort(incidentParticipantRoleDetailsList.dtlsList,
        participantNameComparator);
    // END, CR00243200

    // if the incident is closed, set incidentClosedInd to true to disable page
    // level menu options
    incidentParticipantRoleDetailsList.incidentClosedInd = incidentObj
        .getLifecycleState().equals(INCIDENTSTATUSEntry.CLOSED);

    return incidentParticipantRoleDetailsList;
  }

  // END, CR00195286

  // BEGIN, CR00224036, ZV
  // ___________________________________________________________________________
  /**
   * Method to read Incident details.
   *
   * @param key
   *          contains Incident key
   *
   * @return Read Incident details
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public IncidentDetails viewIncidentDetails(final IncidentKey key)
      throws AppException, InformationalException {

    final IncidentDetails incidentDetails = new IncidentDetails();

    final Incident incidentObj = incidentDAO.get(key.incidentID);

    // BEGIN, RTC 183047, COF
    if (!sensitivityChecker(incidentObj, 17)) {
      ValidationHelper.failIfErrorsExist();
    }
    // END, RTC 183047

    incidentDetails.status = incidentObj.getLifecycleState().getCode();
    incidentDetails.closureReason = incidentObj.getClosureReason().getCode();
    incidentDetails.closureComment = incidentObj.getClosureComment();
    incidentDetails.closureDate = incidentObj.getIncidentClosureDate();
    incidentDetails.sensitivityCode = incidentObj.getSensitivity().getCode();
    incidentDetails.location = incidentObj.getLocation();
    incidentDetails.description = incidentObj.getDescription();
    incidentDetails.anonymousReportInd = incidentObj.isAnonymousReporter();
    incidentDetails.incidentID = incidentObj.getID();
    incidentDetails.versionNo = incidentObj.getVersionNo();

    // BEGIN, CR00386722, MP
    incidentDetails.incidentCategoryOpt = incidentObj.getCategory().getCode();
    // END, CR00386722

    if (incidentDetails.anonymousReportInd) {

      incidentDetails.reporterFullName = new curam.util.exception.LocalisableString(
          curam.message.GENERALCONCERN.TEXT_ANONYMOUS)
              .getMessage(TransactionInfo.getProgramLocale());

    } else {

      final IncidentParticipant incidentReporterObj = incidentObj.getReporter();

      incidentDetails.reporterIncidentParticipantRoleID = incidentReporterObj
          .getID();

      if (incidentReporterObj.getConcernRoleID() == 0) {

        final UserAccess userAccessObj = UserAccessFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = incidentReporterObj.getUserName();
        incidentDetails.reporterFullName = userAccessObj
            .getFullName(usersKey).fullname;
        // BEGIN, CR00241473, ZV
        incidentDetails.reporterUserName = usersKey.userName;
        incidentDetails.reporterUserInd = true;
        // END, CR00241473

      } else {

        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = incidentReporterObj.getConcernRoleID();

        incidentDetails.reporterFullName = concernRoleObj
            .readConcernRoleName(concernRoleKey).concernRoleName;
        incidentDetails.reporterConcernRoleID = incidentReporterObj
            .getConcernRoleID();

      }
    }

    incidentDetails.incidentClosedInd = incidentObj.getLifecycleState()
        .equals(INCIDENTSTATUSEntry.CLOSED);
    return incidentDetails;
  }

  // END, CR00224036

  // BEGIN, CR00228358,NRK
  /**
   * Stores the contact details of the contact log wizard in the Wizard
   * persistence cache.
   *
   * @param incidentContactWizardDetails
   *          Wizard details(contact details) to be cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public WizardStateID createContactLogWizard(
      final IncidentContactLogWizardDetails incidentContactWizardDetails)
      throws AppException, InformationalException {

    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = incidentContactWizardDetails.wizardStateID;
    final IncidentContactLogWizardDetails contactLogWizardDetails = readWizardDetails(
        wizardStateID);

    incidentContactWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.wizardStateID = incidentContactWizardDetails.wizardStateID;
    incidentContactWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.caseID = incidentContactWizardDetails.linkID;
    // BEGIN, CR00426798, AC
    incidentContactWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.author = incidentContactWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.author;
    // END, CR00426798
    contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails
        .assign(
            incidentContactWizardDetails.incidentWizardDetails.wizardDetails.contactDetails);
    if (CuramConst.kStoreAction
        .equals(incidentContactWizardDetails.actionString)) {

      wizardStateID = contactLogObj.storeContactDetails(
          contactLogWizardDetails.incidentWizardDetails.wizardDetails);
    }
    return wizardStateID;
  }

  // END, CR00228358

  // ___________________________________________________________________________
  /**
   * Retrieves Wizard details from the WizardPersistentState.
   *
   * @param wizardStateID
   *          Wizard state ID.
   *
   * @return wizard details cached in the wizard persistent state.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00233604,NRK
  @Override
  public IncidentContactLogWizardDetails readWizardDetails(
      final WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    final IncidentContactLogWizardDetails contactLogWizardDetails = new IncidentContactLogWizardDetails();

    if (wizardStateID.wizardStateID != 0) {
      wizardStateID.wizardStateID = wizardStateID.wizardStateID;
      contactLogWizardDetails.incidentWizardDetails.wizardDetails = contactLogObj
          .readWizardDetails(wizardStateID);
      contactLogWizardDetails.incidentParticipantRoleIDTabList = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList;
    }
    // BEGIN, CR00380898, KRK
    if (CuramConst.gkZero < contactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileContents
        .length()) {
      contactLogWizardDetails.incidentWizardDetails.showAttachmentInd = true;
    }
    // END, CR00380898
    return contactLogWizardDetails;
  }

  // END, CR00233604
  /**
   * Stores Narrative text of the contact log wizard in the wizard persistence
   * cache.
   *
   * @param narrativeDetails
   *          Wizard details updated with narrative details and cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey storeNarrativeText(
      final IncidentContactLogWizardDetails narrativeDetails)
      throws AppException, InformationalException {

    ContactLogKey contactLogKey = new ContactLogKey();
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();
    final CreateContactLogDetails createContactLogDetails = new CreateContactLogDetails();

    createContactLogDetails.noteDetails.notesText = narrativeDetails.incidentWizardDetails.wizardDetails.narrativeDetails.notesText
        .replace("<br />", "");
    contactLogObj.validateDetails(createContactLogDetails);
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = narrativeDetails.wizardStateID;
    final IncidentContactLogWizardDetails wizardDetails = readWizardDetails(
        wizardStateID);

    wizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.assign(
        narrativeDetails.incidentWizardDetails.wizardDetails.narrativeDetails);
    wizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.wizardStateID = wizardStateID.wizardStateID;
    if (CuramConst.kNextAction.equals(narrativeDetails.actionString)
        || CuramConst.kBackAction.equals(narrativeDetails.actionString)) {
      wizardStateID = contactLogObj.storeNarrativeText(
          wizardDetails.incidentWizardDetails.wizardDetails);
    } else if (CuramConst.kSaveAction.equals(narrativeDetails.actionString)) {
      contactLogObj.storeNarrativeText(
          wizardDetails.incidentWizardDetails.wizardDetails);
      contactLogKey = insertContactLogWizardDetails(wizardStateID);
      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }
    return contactLogKey;
  }

  // BEGIN, CR00233604, NRK
  /**
   * Stores Participant details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param participantDetails
   *          Wizard details updated with Participant details and cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey storeParticipantsDetails(
      final IncidentContactLogWizardDetails participantDetails)
      throws AppException, InformationalException {

    ContactLogKey contactLogKey = new ContactLogKey();
    WizardStateID wizardStateID = new WizardStateID();
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();

    wizardStateID.wizardStateID = participantDetails.wizardStateID;
    final IncidentContactLogWizardDetails wizardDetails = readWizardDetails(
        wizardStateID);

    wizardDetails.incidentWizardDetails.wizardDetails.participantDetails.assign(
        participantDetails.incidentWizardDetails.wizardDetails.participantDetails);
    wizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList = participantDetails.incidentParticipantRoleIDTabList;
    wizardDetails.incidentWizardDetails.wizardDetails.participantDetails.wizardStateID = wizardStateID.wizardStateID;
    if (CuramConst.kNextAction.equals(participantDetails.actionString)
        || CuramConst.kBackAction.equals(participantDetails.actionString)) {
      wizardStateID = contactLogObj.storeParticipantsDetails(
          wizardDetails.incidentWizardDetails.wizardDetails);
    } else if (CuramConst.kSaveAction.equals(participantDetails.actionString)) {
      contactLogObj.storeParticipantsDetails(
          wizardDetails.incidentWizardDetails.wizardDetails);
      contactLogKey = insertContactLogWizardDetails(wizardStateID);
      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }
    return contactLogKey;
  }

  // END, CR00233604
  /**
   * Stores Attachment details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param attachementDetails
   *          Wizard details updated with Attachment details and cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey storeAttachmentDetails(
      final IncidentContactLogWizardDetails attachementDetails)
      throws AppException, InformationalException {

    ContactLogKey contactLogKey = new ContactLogKey();
    WizardStateID wizardStateID = new WizardStateID();
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();

    wizardStateID.wizardStateID = attachementDetails.wizardStateID;
    final IncidentContactLogWizardDetails wizardDetails = readWizardDetails(
        wizardStateID);

    // BEGIN, CR00407842, KRK
    wizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.assign(
        attachementDetails.incidentWizardDetails.wizardDetails.attachmentDetails);
    // END, CR00407842

    wizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.wizardStateID = wizardStateID.wizardStateID;
    if (CuramConst.kBackAction.equals(attachementDetails.actionString)) {
      wizardStateID = contactLogObj
          .storeAttachments(wizardDetails.incidentWizardDetails.wizardDetails);
    } else if (CuramConst.kSaveAction.equals(attachementDetails.actionString)) {
      wizardStateID = contactLogObj
          .storeAttachments(wizardDetails.incidentWizardDetails.wizardDetails);
      contactLogKey = insertContactLogWizardDetails(wizardStateID);
      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }
    return contactLogKey;
  }

  /**
   * Reads the wizard menu properties
   *
   * @param wizardStateID
   *          WizardState ID.
   *
   * @return The wizard properties containing the wizard menu details.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogWizardMenuDetails readWizardMenu(
      final WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final ContactLogWizardMenuDetails contactLogWizardMenuDetails = new ContactLogWizardMenuDetails();

    final Case caseObj = CaseFactory.newInstance();
    // Boolean to check whether the subject is enabled for contact logs
    final boolean subjectEnabled = caseObj
        .checkContactLogSubjectEnabled().contactLogSubjectEnabledInd;

    if (wizardStateID.wizardStateID == 0) {
      if (!subjectEnabled) {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kCreateIncidentContactLogWizard;
      } else {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kCreateIncidentContactLogWizardSubject;
      }
    } else {
      if (!subjectEnabled) {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kModifyIncidentContactLogWizard;
      } else {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kModifyIncidentContactLogWizardSubject;
      }
    }
    return contactLogWizardMenuDetails;
  }

  /**
   * Saves the contact log details - contact details, participant details,
   * narrative text and attachment details in the respective entities.
   *
   * @param wizardStateID
   *          WizardState ID to retrieve the information cached in
   *          WizardPersistentState.
   *
   * @return The Contact log reference id.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00228358,NRK
  @Override
  public ContactLogKey insertContactLogWizardDetails(
      final WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    final IncidentContactLogWizardDetails contactLogWizardDetails = readWizardDetails(
        wizardStateID);
    final CreateIncidentContactLogDetails1 incidentContactLogDetails1 = new CreateIncidentContactLogDetails1();

    // Add Contact details
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.purpose = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.purpose;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.location = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.location;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.startDateTime = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.startDateTime;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.endDateTime = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.endDateTime;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.locationDescription = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.locationDescription;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.contactLogType = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.contactLogType;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.method = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.contactLogMethod;
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.subject = contactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.subject;
    incidentContactLogDetails1.contactLogDtls.linkID = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.caseID;
    // Add Narrative details
    incidentContactLogDetails1.contactLogDtls.noteDetails.notesText = contactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.notesText;
    // Add Participant details
    incidentContactLogDetails1.contactLogDtls.attendeeDetails.concernRoleType = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleType;
    incidentContactLogDetails1.contactLogDtls.attendeeDetails.concernRoleID = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleID;
    incidentContactLogDetails1.contactLogDtls.attendeeDetails.concernRoleName = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleName;
    incidentContactLogDetails1.contactLogDtls.attendeeDetails.userName = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.userName;
    // BEGIN, CR00243200, ZV
    incidentContactLogDetails1.contactLogDtls.attendeeDetails.currentUserIsAttendeeInd = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.currentUserIsAttendeeInd;
    // END, CR00243200
    incidentContactLogDetails1.incidentParticipantRoleIDTabList = contactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList;
    // BEGIN, CR00426798, AC
    incidentContactLogDetails1.contactLogDtls.contactLogDetails.author = contactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.author;
    // END, CR00426798
    // Save the contact details
    final ContactLogKey contactLogKey = createIncidentContactLog1(
        incidentContactLogDetails1);

    contactLogObj.saveAttachmentDetails(
        contactLogWizardDetails.incidentWizardDetails.wizardDetails,
        contactLogKey);

    wizardStateID.wizardStateID = wizardStateID.wizardStateID;
    contactLogObj.removeWizardDetails(wizardStateID);
    return contactLogKey;
  }

  // END, CR00228358
  // END, CR00226335,NRK

  // BEGIN, CR00243200, ZV
  /*
   * Comparator used to order incident participants by name
   */
  protected class ParticipantNameComparator
      implements Comparator<IncidentParticipantRoleDetails> {

    public ParticipantNameComparator() {

      super();
    }

    @Override
    public int compare(final IncidentParticipantRoleDetails struct1,
        final IncidentParticipantRoleDetails struct2) {

      return struct1.fullName.compareTo(struct2.fullName);
    }

  }

  // END, CR00243200

  // BEGIN, CR00245044, ZV
  /**
   * Method to list all attachments with versionNo for the specified incident.
   *
   * @param key
   *          ID of the incident
   *
   * @return List of attachment details
   */
  @Override
  public IncidentAttachmentWithVersionNoDetailsList listAttachmentsWithVersionNoByIncident(
      final IncidentKey key) throws AppException, InformationalException {

    // BEGIN, RTC 183047, COF
    sensitivityChecker(this.incidentDAO.get(key.incidentID), 18);
    // END, RTC 183047

    final IncidentAttachmentWithVersionNoDetailsList incidentAttachmentDetailsList = new IncidentAttachmentWithVersionNoDetailsList();

    final List<AttachmentLink> attachmentLinkList = attachmentLinkDAO
        .searchByRelatedIDAndType(key.incidentID,
            ATTACHMENTOBJECTLINKTYPEEntry.INCIDENT);

    final curam.core.sl.intf.Attachment attachmentObj = AttachmentFactory
        .newInstance();

    final AttachmentKey attachmentKey = new AttachmentKey();

    for (int i = 0; i < attachmentLinkList.size(); i++) {

      final IncidentAttachmentWithVersionNoDetails incidentAttachmentDetails = new IncidentAttachmentWithVersionNoDetails();

      final AttachmentLink attachmentLinkObj = attachmentLinkList.get(i);

      incidentAttachmentDetails.attachmentID = attachmentLinkObj
          .getAttachmentID();
      incidentAttachmentDetails.attachmentLinkID = attachmentLinkObj.getID();

      attachmentKey.attachmentID = incidentAttachmentDetails.attachmentID;

      final AttachmentDtls attachmentDtls = attachmentObj
          .readAttachment(attachmentKey);

      incidentAttachmentDetails.attachmentStatus = attachmentDtls.attachmentStatus;
      incidentAttachmentDetails.statusCode = attachmentDtls.statusCode;
      incidentAttachmentDetails.receiptDate = attachmentDtls.receiptDate;
      incidentAttachmentDetails.description = attachmentLinkObj
          .getDescription();
      incidentAttachmentDetails.attachmentFileName = attachmentDtls.attachmentName;
      incidentAttachmentDetails.versionNo = attachmentDtls.versionNo;

      incidentAttachmentDetailsList.dtlsList.addRef(incidentAttachmentDetails);
    }

    incidentAttachmentDetailsList.pageDescription = getIncidentContextDescription(
        key).description;

    return incidentAttachmentDetailsList;
  }

  // END, CR00245044

  // BEGIN, CR00282028, IBM
  /**
   * Search for contact logs associated with an Incident using the specified
   * search criteria.
   *
   * @param contactLogSearchKey1
   *          Contains contact log search criteria
   *
   * @return List of contact log details
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature
   */
  @Override
  public SearchContactLogDetails searchContactLogs(
      final ContactLogSearchKey1 contactLogSearchKey1)
      throws AppException, InformationalException {

    final SearchContactLogDetails searchContactLogDetails = new SearchContactLogDetails();

    if (ACTIONCONTROLID.SEARCH.equals(contactLogSearchKey1.actionControlID)) {

      contactLogSearchKey1.key.key.linkType = CONTACTLOGLINKTYPE.INCIDENT;

      searchContactLogDetails.dtlsList = ContactLogFactory.newInstance()
          .searchContactLogs1(contactLogSearchKey1.key);

      // filter further by the search text if it has been entered
      if (!StringUtil.isNullOrEmpty(contactLogSearchKey1.key.key.searchText)) {

        searchContactLogDetails.dtlsList = contactLogSearchTextFilter
            .filterOnSearchText(searchContactLogDetails.dtlsList,
                contactLogSearchKey1.key.key.searchText);
      } else {
        formatSubjectNarrative(searchContactLogDetails);
      }

    }
    // BEGIN, CR00407986, AC
    final int kMaxNoCases;
    final String envMaxNoCases = Configuration
        .getProperty(EnvVars.ENV_CASES_MAXNOCONTACTLOGS);

    if (null == envMaxNoCases) {

      kMaxNoCases = EnvVars.ENV_CASES_MAXNOCONTACTLOGS_DEFAULT;
    } else {
      kMaxNoCases = Integer.parseInt(envMaxNoCases);
    }
    final ContactLog contactLogObj = ContactLogFactory.newInstance();

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    final SearchContactLogDetails searchContactLogDetails1 = new SearchContactLogDetails();

    for (int i = 0; i < searchContactLogDetails.dtlsList.dtls.size()
        && i < kMaxNoCases; i++) {

      readContactLogDetails.contactLogDetails
          .assign(searchContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj
          .formatContactLogPurpose(readContactLogDetails);

      searchContactLogDetails.dtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
      searchContactLogDetails1.dtlsList.dtls
          .addRef(searchContactLogDetails.dtlsList.dtls.item(i));

      // determine the narrative edit status, which is used to conditionally
      // display different icons for different statuses.
      final NoteUtil noteUtil = new NoteUtil();
      final NoteStatus narrativeEditStatus = noteUtil.determineNoteEditStatus(
          searchContactLogDetails.dtlsList.dtls
              .item(i).latestNarrativeAuthorOpt,
          searchContactLogDetails.dtlsList.dtls
              .item(i).latestNarrativeCreatedOnOpt,
          NoteType.CONTACT_LOG_NARRATIVE);

      searchContactLogDetails.dtlsList.dtls
          .item(i).narrativeEditStatusOpt = narrativeEditStatus.toString();
    }
    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();
    String[] infos = informationalManager.obtainInformationalAsString();

    if (searchContactLogDetails.dtlsList.dtls.size() >= kMaxNoCases) {
      final LocalisableString infoMessage = new LocalisableString(
          ENTCONTACTLOG.INF_ALL_CONTACTLOG_CANNOT_BE_DISPLAYED);

      infoMessage.arg(kMaxNoCases);
      infoMessage.arg(searchContactLogDetails.dtlsList.dtls.size());
      informationalManager.addInformationalMsg(infoMessage,
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kWarning);
    }
    infos = informationalManager.obtainInformationalAsString();
    // END, CR400407986
    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      searchContactLogDetails1.informationalMsgDtls.dtls
          .addRef(informationalMsgDtls);
    }

    // format the date field to condense start and end date into one field
    for (final ContactLogListDtls1 contactLog : searchContactLogDetails1.dtlsList.dtls
        .items()) {
      // If the start date time and end date time are the same or there is no
      // end date, display as start
      // date time only
      if (contactLog.startDateTime.equals(contactLog.endDateTime)
          || contactLog.endDateTime.equals(DateTime.kZeroDateTime)) {
        contactLog.dateOpt = contactLog.startDateTime.toString();
      }
      // Otherwise display as start date time - end date time
      else {
        contactLog.dateOpt = contactLog.startDateTime.toString() + " - "
            + contactLog.endDateTime.toString();
      }
    }
    return searchContactLogDetails1;
    // END, CR00282028
  }

  /**
   * Formats the subject and narrative for display on the contact log search
   * result page.
   *
   * @param searchContactLogDetails
   *          Search contact log details
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  private void formatSubjectNarrative(
      final SearchContactLogDetails searchContactLogDetails)
      throws AppException, InformationalException {

    final Case caseObj = CaseFactory.newInstance();
    // Boolean to check whether the subject is enabled for contact logs
    final boolean subjectEnabled = caseObj
        .checkContactLogSubjectEnabled().contactLogSubjectEnabledInd;

    for (final ContactLogListDtls1 contactLogDetails : searchContactLogDetails.dtlsList.dtls
        .items()) {

      // get the narrative content
      final List<String> narrativeTextStrings = ContactLogUtility
          .getNarrativeContent(contactLogDetails.contactLogID);

      if (subjectEnabled) {
        // add heading tag to the subject and check if subject is still
        // empty here, means there is no
        // subject so set it to '--'
        if (StringUtil.isNullOrEmpty(contactLogDetails.subject)) {
          contactLogDetails.subjectRichText = H5_TAG_WITH_ARIA_LABEL_OPEN_START
              + ENTCONTACTLOG.INF_NO_SUBJECT_LABEL
              + H5_TAG_WITH_ARIA_LABEL_OPEN_END + DOUBLE_DASH + H5_TAG_CLOSE;
        } else {
          contactLogDetails.subjectRichText = H5_TAG_OPEN
              + contactLogDetails.subject + H5_TAG_CLOSE;
        }
        contactLogDetails.subjectRichText = ContactLogUtility
            .handleNarrativeTruncation(contactLogDetails.subjectRichText,
                narrativeTextStrings.get(0).trim());
      } else {
        contactLogDetails.subjectRichText = ContactLogUtility
            .handleNarrativeTruncation(contactLogDetails.subject,
                narrativeTextStrings.get(0).trim());
      }
    }
  }

  // BEGIN, CR00290965, IBM
  /**
   * Search incident details by provided search criteria.
   *
   * @param incidentSearchKey
   *          contains incidents search key
   *
   * @return incident details list
   *
   * @throws AppException
   *           Generic Exception Signature
   * @throws InformationalException
   *           Generic Exception Signature
   */
  @Override
  public IncidentSearchDetailsList searchIncidentsDetails(
      final IncidentSearchKey incidentSearchKey)
      throws AppException, InformationalException {

    final IncidentSearchDetailsList incidentSearchDetailsList = new IncidentSearchDetailsList();

    final SortedSet<Incident> incidents = incidentDAO.search(
        incidentSearchKey.recordedDate,
        INCIDENTSEVERITYEntry.get(incidentSearchKey.severity),
        INCIDENTREPORTMETHODEntry.get(incidentSearchKey.reportingMethod),
        INCIDENTTYPEEntry.get(incidentSearchKey.type),
        incidentSearchKey.location);

    for (final Incident incident : incidents) {

      // BEGIN, RTC 177382, COF
      if (!incident.isSensitiveForCurrentUser()) {
        continue;
      }
      // END, RTC 177382

      final IncidentSearchResult1 incidentSearchResult = new IncidentSearchResult1();

      incidentSearchResult.incidentID = incident.getID();
      incidentSearchResult.incidentStatus = incident.getLifecycleState()
          .getCode();
      incidentSearchResult.recordedDate = incident.getRecordedDate();
      incidentSearchResult.severity = incident.getSeverity().getCode();
      incidentSearchResult.type = incident.getType().getCode();
      incidentSearchResult.concernRoleID = incident.getAgainstConcernRole();

      incidentSearchDetailsList.dtlsList.addRef(incidentSearchResult);

    }

    collectInformationalMsgs(incidentSearchDetailsList.informationalMsgDtls);

    return incidentSearchDetailsList;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   *          contains informational message details.
   */
  protected void collectInformationalMsgs(
      final InformationalMsgDtlsList msgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00290965

  // BEGIN, CR00357485, AC
  /**
   * Preview contact log details for incident.
   *
   * @param previewIncidentContactLogIDKey
   *          contains contact log preview key.
   *
   * @return preview incident contact log details.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */

  @Override
  public PreviewIncidentContactLogXMLDetails previewIncidentContactLogDetails(
      final PreviewIncidentContactLogIDKey previewIncidentContactLogIDKey)
      throws AppException, InformationalException {

    final PreviewIncidentContactLogXMLDetails previewIncidentContactLogXMLDetails = new PreviewIncidentContactLogXMLDetails();

    if (previewIncidentContactLogIDKey.dtls.actionControlID
        .equals(ACTIONCONTROLID.PREVIEW)
        || 0 == previewIncidentContactLogIDKey.dtls.actionControlID.length()) {
      final PreviewCaseContactLogKey previewContactLogKey = new PreviewCaseContactLogKey();

      previewContactLogKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;
      previewContactLogKey.multiSelectStr = previewIncidentContactLogIDKey.dtls.dtls.multiSelectStr;
      previewIncidentContactLogXMLDetails.dtls = ContactLogFactory.newInstance()
          .previewContactLogList(previewContactLogKey);
      final IncidentKey incidentKey = new IncidentKey();

      incidentKey.incidentID = previewIncidentContactLogIDKey.incidentKey.incidentID;
      previewIncidentContactLogXMLDetails.contextDescription = getIncidentContextDescription(
          incidentKey).description;
    }

    return previewIncidentContactLogXMLDetails;
  }

  /**
   * Gets the incident print contact log details.
   *
   * @param PreviewIncidentContactLogIDKey
   *          to get the preview list
   * @return PrintContactLogWizardDetails for the temporary storage of print log
   *         details
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  public PrintContactLogWizardDetails getIncidentPrintContactLogDetails(
      final PreviewIncidentContactLogIDKey previewIncidentContactLogIDKey)
      throws AppException, InformationalException {

    final IncidentKey incidentKey = new IncidentKey();

    incidentKey.incidentID = previewIncidentContactLogIDKey.incidentKey.incidentID;
    final CaseContextDescription caseContextDescription = new CaseContextDescription();

    caseContextDescription.description = getIncidentContextDescription(
        incidentKey).description;
    final WizardPersistentState wizardPersistentState = new WizardPersistentState();
    final PrintContactLogWizardDetails printContactLogWizardDetails = new PrintContactLogWizardDetails();

    printContactLogWizardDetails.description = caseContextDescription.description;
    printContactLogWizardDetails.multiSelectString = previewIncidentContactLogIDKey.dtls.dtls.multiSelectStr;
    printContactLogWizardDetails.wizardStateID = wizardPersistentState
        .create(printContactLogWizardDetails);

    return printContactLogWizardDetails;

  }

  // END, CR00357485
  // BEGIN, CR00407986, AC
  /**
   * Method to list Contact Log details for a incident case.
   *
   *
   * @param key
   *          Contains case id
   *
   * @return The Contact Log details List
   */
  @Override
  public ListIncidentContactLogDetails listIncidentContactLogDetails(
      final IncidentKey key) throws AppException, InformationalException {

    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.incidentID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    final ListIncidentContactLogDetails listContactLogDetails = new ListIncidentContactLogDetails();

    listContactLogDetails.dtlsList = ContactLogFactory.newInstance()
        .list1(contactLogLinkIDLinkTypeKey);
    final int kMaxNoCases;
    final String envMaxNoCases = Configuration
        .getProperty(EnvVars.ENV_CASES_MAXNOCONTACTLOGS);

    if (null == envMaxNoCases) {

      kMaxNoCases = EnvVars.ENV_CASES_MAXNOCONTACTLOGS_DEFAULT;
    } else {
      kMaxNoCases = Integer.parseInt(envMaxNoCases);
    }
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();
    final ListIncidentContactLogDetails listContactLogDetails1 = new ListIncidentContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < listContactLogDetails.dtlsList.dtls.size()
        && i < kMaxNoCases; i++) {

      readContactLogDetails.contactLogDetails
          .assign(listContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = ContactLogFactory.newInstance()
          .formatContactLogPurpose(readContactLogDetails);

      listContactLogDetails.dtlsList.dtls
          .item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
      listContactLogDetails1.dtlsList.dtls
          .addRef(listContactLogDetails.dtlsList.dtls.item(i));

      // determine the narrative edit status, which is used to conditionally
      // display different icons for different statuses.
      final NoteUtil noteUtil = new NoteUtil();
      final NoteStatus narrativeEditStatus = noteUtil.determineNoteEditStatus(
          listContactLogDetails1.dtlsList.dtls.item(i).latestNarrativeAuthorOpt,
          listContactLogDetails1.dtlsList.dtls
              .item(i).latestNarrativeCreatedOnOpt,
          NoteType.CONTACT_LOG_NARRATIVE);

      listContactLogDetails1.dtlsList.dtls
          .item(i).narrativeEditStatusOpt = narrativeEditStatus.toString();

    }
    final InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    if (listContactLogDetails.dtlsList.dtls.size() > kMaxNoCases) {
      final LocalisableString infoMessage = new LocalisableString(
          ENTCONTACTLOG.INF_ALL_CONTACTLOG_CANNOT_BE_DISPLAYED);

      infoMessage.arg(kMaxNoCases);
      infoMessage.arg(listContactLogDetails.dtlsList.dtls.size());
      informationalManager.addInformationalMsg(infoMessage,
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kWarning);
    }
    final String[] warnings = informationalManager
        .obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationMsgDtls = new InformationalMsgDtls();

      informationMsgDtls.informationMsgTxt = warnings[i];
      listContactLogDetails1.dtls.dtls.addRef(informationMsgDtls);
    }
    return listContactLogDetails1;

  }
  // END, CR00407986
}
