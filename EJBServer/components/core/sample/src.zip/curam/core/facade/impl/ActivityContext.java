/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.core.facade.struct.ActivityContextDescriptionDetails;
import curam.core.facade.struct.ActivityContextDescriptionKey;
import curam.core.struct.ActivityDtls;
import curam.core.struct.ActivityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality to retrieve context
 * descriptions for a participant.
 *
 */
public abstract class ActivityContext extends curam.core.facade.base.ActivityContext {

  // ___________________________________________________________________________
  /**
   * Reads the description of the Activity.
   *
   * @param activityContextDescriptionKey The activity context key.
   *
   * @return details The activity subject description.
   */
  @Override
  public ActivityContextDescriptionDetails readContextDescription(
    ActivityContextDescriptionKey activityContextDescriptionKey)
    throws AppException, InformationalException {

    // Activity object and key
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    final ActivityKey activityKey = new ActivityKey();
    // Activity details
    ActivityDtls activityDtls;

    // Details to be returned
    final ActivityContextDescriptionDetails activityContextDescriptionDetails = new ActivityContextDescriptionDetails();

    // Read the activity ID
    activityKey.activityID = activityContextDescriptionKey.activityID;
    activityDtls = activityObj.read(activityKey);

    // Set the context description
    activityContextDescriptionDetails.description = activityDtls.subject;

    // Return the details
    return activityContextDescriptionDetails;

  }

}
