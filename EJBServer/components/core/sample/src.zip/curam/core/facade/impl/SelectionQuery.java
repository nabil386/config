/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.SELECTIONQUERYCATEGORYEntry;
import curam.codetable.impl.SELECTIONQUERYTYPEEntry;
import curam.core.facade.struct.CreateCriteriaDetails;
import curam.core.facade.struct.CreateOrRemoveSelectionQueryDetails;
import curam.core.facade.struct.CriteriaDetails;
import curam.core.facade.struct.CriteriaDetailsList;
import curam.core.facade.struct.CriteriaIDAndVersionNo;
import curam.core.facade.struct.QueryValidationDetails;
import curam.core.facade.struct.SelectionQueryDetails;
import curam.core.facade.struct.SelectionQueryHomeDetails;
import curam.core.facade.struct.SelectionQueryIDAndVersionNo;
import curam.core.facade.struct.SelectionQueryListDetails;
import curam.core.facade.struct.SelectionQueryListDetailsList;
import curam.core.facade.struct.ValidateOrUndoQueryDetails;
import curam.core.impl.CuramConst;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.struct.InformationalMsgDtls;
import curam.message.FACADESELECTIONQUERY;
import curam.selectionquery.entity.struct.CriteriaKey;
import curam.selectionquery.entity.struct.SelectionQueryKey;
import curam.selectionquery.impl.Criteria;
import curam.selectionquery.impl.CriteriaDAO;
import curam.selectionquery.impl.SelectionQueryCriteriaLink;
import curam.selectionquery.impl.SelectionQueryCriteriaLinkDAO;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import java.util.List;


/**
 * Facade Class for the SelectionQuery implementation.
 *
 */
public abstract class SelectionQuery extends curam.core.facade.base.SelectionQuery {

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  @Inject
  protected CriteriaDAO criteriaDAO;

  @Inject
  protected SelectionQueryCriteriaLinkDAO selectionQueryCriteriaLinkDAO;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public SelectionQuery() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Method to list all selection queries. (excludes predefined queries)
   *
   * @return a list of selection queries
   */
  @Override
  public SelectionQueryListDetailsList listSelectionQueries()
    throws AppException, InformationalException {

    final SelectionQueryListDetailsList selectionQueryListDetailsList = new SelectionQueryListDetailsList();

    final List<curam.selectionquery.impl.SelectionQuery> selectionQueryList = selectionQueryDAO.searchAdministrableQueries();

    for (final curam.selectionquery.impl.SelectionQuery selectionQuery : selectionQueryList) {

      final SelectionQueryListDetails selectionQueryListDetails = new SelectionQueryListDetails();

      selectionQueryListDetails.queryID = selectionQuery.getID();
      selectionQueryListDetails.queryCategory = selectionQuery.getCategory().getCode();
      selectionQueryListDetails.queryType = selectionQuery.getType().getCode();
      selectionQueryListDetails.queryName = selectionQuery.getName();
      selectionQueryListDetails.queryStatus = selectionQuery.getLifecycleState().getCode();
      selectionQueryListDetails.versionNo = selectionQuery.getVersionNo();
      selectionQueryListDetailsList.dtls.addRef(selectionQueryListDetails);
    }

    return selectionQueryListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to read a selection query.
   *
   * @param key unique id of the selection query
   *
   * @return Details of the selection query and any associated criteria
   */
  @Override
  public SelectionQueryHomeDetails readSelectionQuery(
    final SelectionQueryKey key) throws AppException, InformationalException {

    final SelectionQueryHomeDetails selectionQueryHomeDetails = new SelectionQueryHomeDetails();

    if (key.selectionQueryID != 0) {

      final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
        key.selectionQueryID);

      selectionQueryHomeDetails.details.dtls.category = selectionQueryObj.getCategory().getCode();
      selectionQueryHomeDetails.details.dtls.type = selectionQueryObj.getType().getCode();
      selectionQueryHomeDetails.details.dtls.name = selectionQueryObj.getName();
      selectionQueryHomeDetails.details.dtls.randPageName = selectionQueryObj.getRandomPageName();
      selectionQueryHomeDetails.details.dtls.manPageName = selectionQueryObj.getManualPageName();
      selectionQueryHomeDetails.details.dtls.comments = selectionQueryObj.getComments();
      selectionQueryHomeDetails.details.dtls.sqlText = selectionQueryObj.getSQLText();
      selectionQueryHomeDetails.details.dtls.status = selectionQueryObj.getLifecycleState().getCode();
      selectionQueryHomeDetails.details.dtls.recordStatus = selectionQueryObj.getRecordStatus().getCode();
      selectionQueryHomeDetails.details.dtls.versionNo = selectionQueryObj.getVersionNo();

      // List all criteria for the selection query
      selectionQueryHomeDetails.dtls = listSelectionQueryCriteria(key);
      selectionQueryHomeDetails.showCriteriaListInd = selectionQueryHomeDetails.dtls.dtls.size()
        > 0;

      // BEGIN, CR00219367, GD
      // Don't display page name field if the query is fixed
      if (selectionQueryObj.getType().equals(SELECTIONQUERYTYPEEntry.FIXED)) {
        selectionQueryHomeDetails.showPageNameInd = false;
      } else {
        selectionQueryHomeDetails.showPageNameInd = true;
      }
      // END, CR00219367
    }

    return selectionQueryHomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel a selection query.
   *
   * @param key unique id of the selection query and the version number
   * held by the client
   */
  @Override
  public void cancelSelectionQuery(final SelectionQueryIDAndVersionNo key)
    throws AppException, InformationalException {

    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      key.selectionQueryID);

    selectionQueryObj.cancel(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to publish a selection query. This sets the status of the selection
   * query to 'Active', once published no more modifications may be made
   * to the selection query.
   *
   * @param key unique id of the selection query and the version number
   * held by the client
   */
  @Override
  public void publishSelectionQuery(final SelectionQueryIDAndVersionNo key)
    throws AppException, InformationalException {

    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      key.selectionQueryID);

    selectionQueryObj.publish(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to create criteria.
   *
   * @param details Details of the criteria to create and the selection query
   * to associate it to.
   *
   * @return unique id of the created criteria
   */
  @Override
  public CriteriaKey createCriteria(final CreateCriteriaDetails details)
    throws AppException, InformationalException {

    final Criteria criteriaObj = criteriaDAO.newInstance();

    criteriaObj.setName(details.dtls.name);
    criteriaObj.setValue(details.dtls.value);
    criteriaObj.setDisplayName(details.dtls.displayName);
    criteriaObj.setDisplayValue(details.dtls.displayValue);

    criteriaObj.insert();

    // Return the newly created id
    final CriteriaKey result = new CriteriaKey();

    result.criteriaID = criteriaObj.getID();

    // Link to the selection query
    final SelectionQueryCriteriaLink selectionQueryCriteriaLinkObj = selectionQueryCriteriaLinkDAO.newInstance();
    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      details.selectionQueryID);

    selectionQueryCriteriaLinkObj.setSelectionQuery(selectionQueryObj);
    selectionQueryCriteriaLinkObj.setCriteria(criteriaObj);
    selectionQueryCriteriaLinkObj.insert();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all criteria associated with a selection query.
   *
   * @param key the selection query to search by
   *
   * @return a list of all criteria associated with a selection query.
   */
  @Override
  public CriteriaDetailsList listSelectionQueryCriteria(
    final SelectionQueryKey key) throws AppException, InformationalException {

    final CriteriaDetailsList criteriaDetailsList = new CriteriaDetailsList();

    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      key.selectionQueryID);

    final List<Criteria> criteriaList = selectionQueryObj.getCriteria();

    for (final Criteria criteria : criteriaList) {

      final CriteriaDetails criteriaDetails = new CriteriaDetails();

      criteriaDetails.dtls.criteriaID = criteria.getID();
      criteriaDetails.dtls.displayName = criteria.getDisplayName();
      criteriaDetails.dtls.displayValue = criteria.getDisplayValue();
      criteriaDetails.dtls.name = criteria.getName();
      criteriaDetails.dtls.value = criteria.getValue();
      criteriaDetails.dtls.versionNo = criteria.getVersionNo();
      criteriaDetailsList.dtls.addRef(criteriaDetails);
    }

    return criteriaDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify criteria.
   *
   * @param details the modified criteria details
   */
  @Override
  public void modifyCriteria(final CriteriaDetails details)
    throws AppException, InformationalException {

    final Criteria criteriaObj = criteriaDAO.get(details.dtls.criteriaID);

    criteriaObj.setName(details.dtls.name);
    criteriaObj.setValue(details.dtls.value);
    criteriaObj.setDisplayName(details.dtls.displayName);
    criteriaObj.setDisplayValue(details.dtls.displayValue);

    criteriaObj.modify(details.dtls.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to read criteria.
   *
   * @param key unique id of the criteria
   *
   * @return Details of the criteria
   */
  @Override
  public CriteriaDetails readCriteria(final CriteriaKey key)
    throws AppException, InformationalException {

    final CriteriaDetails criteriaDetails = new CriteriaDetails();

    final Criteria criteriaObj = criteriaDAO.get(key.criteriaID);

    criteriaDetails.dtls.criteriaID = criteriaObj.getID();
    criteriaDetails.dtls.name = criteriaObj.getName();
    criteriaDetails.dtls.value = criteriaObj.getValue();
    criteriaDetails.dtls.displayName = criteriaObj.getDisplayName();
    criteriaDetails.dtls.displayValue = criteriaObj.getDisplayValue();
    criteriaDetails.dtls.versionNo = criteriaObj.getVersionNo();

    return criteriaDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to remove criteria.
   *
   * @param key unique id of the criteria and the version number
   * held by the client
   */
  @Override
  public void removeCriteria(final CriteriaIDAndVersionNo key)
    throws AppException, InformationalException {

    final Criteria criteriaObj = criteriaDAO.get(key.criteriaID);

    final List<SelectionQueryCriteriaLink> links = selectionQueryCriteriaLinkDAO.searchBy(
      criteriaObj);

    for (final SelectionQueryCriteriaLink link : links) {
      link.remove();
    }

    criteriaObj.remove(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to validate a selection query.
   *
   * @param key the unique identifier of the selection query to be validated.
   */
  public void validateSelectionQuery(final SelectionQueryKey key)
    throws AppException, InformationalException {

    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      key.selectionQueryID);

    selectionQueryObj.validateSelectionQuery();
  }

  // ___________________________________________________________________________
  /**
   * Method to remove a selection query.
   *
   * @param key the unique identifier of the selection query to be removed and
   * the version number held by the client
   */
  @Override
  public void removeSelectionQuery(final SelectionQueryIDAndVersionNo key)
    throws AppException, InformationalException {

    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      key.selectionQueryID);

    final List<SelectionQueryCriteriaLink> links = selectionQueryCriteriaLinkDAO.searchBy(
      selectionQueryObj);

    for (final SelectionQueryCriteriaLink link : links) {

      final Criteria criteriaObj = criteriaDAO.get(link.getCriteria().getID());

      link.remove();
      criteriaObj.remove(criteriaObj.getVersionNo());
    }

    selectionQueryObj.remove(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to validate or undo a query. Undoing a query will delete the query
   * along with any associated criteria.
   *
   * @param key unique id of the selection query, the version number held by
   * the client and an action id to identify if the query is to be
   * validated or removed.
   *
   * @return A message outlining if the query was valid.
   */
  @Override
  public QueryValidationDetails validateOrUndoQuery(
    final ValidateOrUndoQueryDetails key) throws AppException,
      InformationalException {

    final QueryValidationDetails queryValidationDetails = new QueryValidationDetails();

    if (key.actionIDProperty.equals(ClientActionConst.kValidateSelectionQuery)) {

      final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
        key.selectionQueryID);

      selectionQueryObj.validateSelectionQuery();

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        FACADESELECTIONQUERY.INF_SELECTION_QUERY_VALID);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // Obtain the informational(s) to be returned to the client
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];

        queryValidationDetails.dtls.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }

    } else if (key.actionIDProperty.equals(
      ClientActionConst.kUndoSelectionQuery)) {

      final SelectionQueryIDAndVersionNo selectionQueryIDAndVersionNo = new SelectionQueryIDAndVersionNo();

      selectionQueryIDAndVersionNo.selectionQueryID = key.selectionQueryID;
      selectionQueryIDAndVersionNo.versionNo = key.versionNo;

      removeSelectionQuery(selectionQueryIDAndVersionNo);
    }

    return queryValidationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to create a selection query. As the creation of selection queries
   * is part of a wizard there is a chance that the query may have been created
   * already, in this case the modify function is called.
   *
   * @param details Details of the selection query to be created
   *
   * @return unique id of the created selection query
   */
  @Override
  public SelectionQueryKey createSelectionQuery(
    final SelectionQueryDetails details) throws AppException,
      InformationalException {

    final SelectionQueryKey result = new SelectionQueryKey();

    if (details.dtls.selectionQueryID == 0) {

      // Create a new selection query
      final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.newInstance();

      selectionQueryObj.setCategory(
        SELECTIONQUERYCATEGORYEntry.get(details.dtls.category));
      selectionQueryObj.setType(SELECTIONQUERYTYPEEntry.get(details.dtls.type));
      selectionQueryObj.setName(details.dtls.name);
      selectionQueryObj.setRandomPageName(details.dtls.randPageName);
      selectionQueryObj.setManualPageName(details.dtls.manPageName);
      selectionQueryObj.setSQLText(details.dtls.sqlText);
      selectionQueryObj.setComments(details.dtls.comments);

      selectionQueryObj.insert();

      // Return the newly created id
      result.selectionQueryID = selectionQueryObj.getID();

    } else {

      // Modify the selection query
      modifySelectionQuery(details);
      result.selectionQueryID = details.dtls.selectionQueryID;
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify a selection query.
   *
   * @param details Details of the selection query to modify
   */
  @Override
  public void modifySelectionQuery(final SelectionQueryDetails details)
    throws AppException, InformationalException {

    // Modify the selection query
    final curam.selectionquery.impl.SelectionQuery selectionQueryObj = selectionQueryDAO.get(
      details.dtls.selectionQueryID);

    selectionQueryObj.setCategory(
      SELECTIONQUERYCATEGORYEntry.get(details.dtls.category));
    selectionQueryObj.setType(SELECTIONQUERYTYPEEntry.get(details.dtls.type));
    selectionQueryObj.setName(details.dtls.name);
    selectionQueryObj.setRandomPageName(details.dtls.randPageName);
    selectionQueryObj.setManualPageName(details.dtls.manPageName);
    selectionQueryObj.setSQLText(details.dtls.sqlText);
    selectionQueryObj.setComments(details.dtls.comments);

    selectionQueryObj.modify(details.dtls.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to create or remove a query.
   *
   * @param details unique id of the selection query, the version number held by
   * the client, an action id to identify if the query is to be
   * created or removed and the selection query creation details
   *
   * @return The key of the created or removed selection query.
   */
  @Override
  public SelectionQueryKey createOrRemoveSelectionQuery(
    final CreateOrRemoveSelectionQueryDetails details) throws AppException,
      InformationalException {

    SelectionQueryKey selectionQueryKey = new SelectionQueryKey();

    if (details.actionIDProperty.equals(ClientActionConst.kCreateSelectionQuery)
      || details.actionIDProperty.equals(
        ClientActionConst.kCreateAndExitSelectionQuery)) {

      final SelectionQueryDetails selectionQueryDetails = new SelectionQueryDetails();

      selectionQueryDetails.dtls.assign(details.dtls);
      selectionQueryKey = createSelectionQuery(selectionQueryDetails);
    } else if (details.actionIDProperty.equals(
      ClientActionConst.kUndoSelectionQuery)) {

      if (details.selectionQueryID != 0) {
        final SelectionQueryIDAndVersionNo selectionQueryIDAndVersionNo = new SelectionQueryIDAndVersionNo();

        selectionQueryIDAndVersionNo.selectionQueryID = details.selectionQueryID;
        selectionQueryIDAndVersionNo.versionNo = details.versionNo;
        removeSelectionQuery(selectionQueryIDAndVersionNo);
        selectionQueryKey.selectionQueryID = details.selectionQueryID;
      }
    }

    return selectionQueryKey;
  }

}
