/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CASEDECISIONSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESOLUTIONSTATUSCODE;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.infrastructure.fact.EvidenceFactory;
import curam.core.facade.infrastructure.intf.Evidence;
import curam.core.facade.infrastructure.struct.EvidenceListKey;
import curam.core.facade.intf.ParticipantContext;
import curam.core.facade.struct.ApproveResolutionKey;
import curam.core.facade.struct.CaseEventAndActivityDetails;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.CloseCaseDetails;
import curam.core.facade.struct.ContextDescriptionDetails;
import curam.core.facade.struct.IssueApprovalRequestDetails;
import curam.core.facade.struct.IssueApprovalRequestDtlsList;
import curam.core.facade.struct.IssueAttachmentList;
import curam.core.facade.struct.IssueClosureDetails;
import curam.core.facade.struct.IssueClosureDetails1;
import curam.core.facade.struct.IssueCommunicationList;
import curam.core.facade.struct.IssueDeliveryAddEvidenceDetails;
import curam.core.facade.struct.IssueDeliveryCreationAndEvidenceDetails;
import curam.core.facade.struct.IssueDeliveryHomePageDetails;
import curam.core.facade.struct.IssueDeliveryHomePageDetails1;
import curam.core.facade.struct.IssueDeliveryMenuDataDetails;
import curam.core.facade.struct.IssueDeliveryMenuDataKey;
import curam.core.facade.struct.IssueEventAndActivityList;
import curam.core.facade.struct.IssueEventAndActivityList1;
import curam.core.facade.struct.IssueEventList;
import curam.core.facade.struct.IssueEventList1;
import curam.core.facade.struct.IssueEvidenceTypeAndMemberDetails;
import curam.core.facade.struct.IssueNoteList;
import curam.core.facade.struct.IssueNoteList1;
import curam.core.facade.struct.IssueRelatedCaseList;
import curam.core.facade.struct.IssueTaskList;
import curam.core.facade.struct.IssueUserRoleList;
import curam.core.facade.struct.IssuesForConcernRoleDetailsList;
import curam.core.facade.struct.IssuesForDuplicateConcernRoleDetailsList;
import curam.core.facade.struct.ListTransactionsLogDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ReadTransactionLogDetailsList;
import curam.core.facade.struct.RejectDetails;
import curam.core.facade.struct.RejectResolutionKey;
import curam.core.facade.struct.ResolutionAndConfigIDDetailsList;
import curam.core.facade.struct.ResolutionDetails;
import curam.core.facade.struct.ResolutionStatusHistoryDtls;
import curam.core.facade.struct.ResolutionStatusHistoryDtlsList;
import curam.core.facade.struct.SearchCaseEventAndActivityKey;
import curam.core.facade.struct.SubmitResolutionForApprovalKey;
import curam.core.facade.struct.WizardProperties;
import curam.core.fact.CaseDecisionFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainAttachmentFactory;
import curam.core.fact.MaintainRelatedCasesFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ViewCaseEventsFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseDecision;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainAttachment;
import curam.core.intf.MaintainRelatedCases;
import curam.core.intf.ProductDelivery;
import curam.core.intf.ViewCaseEvents;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.HomePageIDIssueTypeCaseRef;
import curam.core.sl.entity.struct.IssueApprovalRequestKey;
import curam.core.sl.entity.struct.IssueConfigurationKey;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.entity.struct.ResolutionKey;
import curam.core.sl.entity.struct.ResolutionStatusHistoryKey;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.fact.ApprovalRequestFactory;
import curam.core.sl.fact.CalendarDataFactory;
import curam.core.sl.fact.CaseNoteFactory;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.IssueDeliveryFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECActiveEvidenceDtls;
import curam.core.sl.intf.ApprovalRequest;
import curam.core.sl.intf.CalendarData;
import curam.core.sl.intf.CaseNote;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.struct.ActivityElementDetails;
import curam.core.sl.struct.CalendarElementData;
import curam.core.sl.struct.CaseAndConcernLinkedTaskDtls;
import curam.core.sl.struct.CaseNoteList1;
import curam.core.sl.struct.CaseUserRoleCaseIDKey;
import curam.core.sl.struct.CaseUserRoleDetails;
import curam.core.sl.struct.CaseUserRoleDetailsList;
import curam.core.sl.struct.CommunicationDetailsList;
import curam.core.sl.struct.CommunicationKey;
import curam.core.sl.struct.ContextDescription;
import curam.core.sl.struct.DateRangeKey;
import curam.core.sl.struct.DateTimeRangeDetails;
import curam.core.sl.struct.EventElementDetails;
import curam.core.sl.struct.IsUserSupervisor;
import curam.core.sl.struct.IssueDeliveryHeaderDetails;
import curam.core.sl.struct.ModifyRejectionDetails;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.struct.AttachmentCaseID;
import curam.core.struct.AttachmentDetailsList;
import curam.core.struct.CaseDecisionDtls;
import curam.core.struct.CaseDecisionKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseIDAndTypeCodeKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.GetRelatedCasesKey;
import curam.core.struct.GetRelatedCasesList;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.RelatedCaseID;
import curam.core.struct.RelatedCaseProductType;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.core.struct.UserNameKey;
import curam.core.struct.ViewActiveCaseEventDetails;
import curam.core.struct.ViewActiveCaseEventDetailsList1;
import curam.core.struct.ViewCaseEventDetailsList;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.message.BPOINTEGRATEDCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * This process class provides the functionality for the Issue Delivery facade.
 */
public abstract class IssueDelivery extends curam.core.facade.base.IssueDelivery {

  // BEGIN, CR00028783, KH
  // BEGIN, CR00053248, GM
  protected static final String kSpace = CuramConst.gkSpace;

  // END, CR00028783
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;

  protected static final String kParamCaseParticipantRoleID = XmlMetaDataConst.kParamCaseParticipantRoleID;

  // BEGIN, CR00029133, KH
  protected static final int kBufferSize = 2048;

  protected static final String kCuramCalendarDataHeader = CuramCalendarHeaderConst.kCuramCalendarDataHeader;

  protected static final String kCuramCalendarDataFooter = CuramCalendarHeaderConst.kCuramCalendarDataFooter;

  protected static final String kCloseBracket = CuramCalendarHeaderConst.kCloseBracket;

  protected static final String kQuote = CuramCalendarHeaderConst.kQuote;

  // END, CR00029133
  // BEGIN, CR00030508, CM
  protected static final String kTypeIssue = XmlMetaDataConst.kTypeIssue;

  // END, CR00053248
  // END, CR00030508
  // BEGIN, CR00099881, CSH
  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  // END, CR00099881

  // BEGIN CR00108593, GBA
  // Add injection for using the new CaseTransactionLog API
  public IssueDelivery() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108593

  // ___________________________________________________________________________
  /**
   * This method is used to modify the issue delivery case header details.
   *
   * @param issueDeliveryHeaderDetails The new case header details for the
   * issue delivery case.
   */
  @Override
  public void modifyIssueCaseHeader(
    IssueDeliveryHeaderDetails issueDeliveryHeaderDetails)
    throws AppException, InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Modify the case header details
    issueDeliveryObj.modifyIssueDeliveryHeaderDetails(
      issueDeliveryHeaderDetails);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to read the issue delivery case header details.
   *
   * @param issueCaseHeaderKey The case ID of the issue delivery case.
   *
   * @return The case header details for the issue delivery case.
   */
  @Override
  public curam.core.facade.struct.IssueDeliveryHeaderDetails readIssueCaseHeader(CaseHeaderKey issueCaseHeaderKey)
    throws AppException, InformationalException {

    // Return struct
    final curam.core.facade.struct.IssueDeliveryHeaderDetails issueDeliveryHeaderDetails = new curam.core.facade.struct.IssueDeliveryHeaderDetails();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // Read the case header details
    issueDeliveryHeaderDetails.dtls = issueDeliveryObj.readIssueDeliveryHeaderDetails(
      issueCaseHeaderKey);

    // Set key to find context description
    issueDeliveryKey.caseID = issueCaseHeaderKey.caseID;

    // Set context description
    issueDeliveryHeaderDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return issueDeliveryHeaderDetails;
  }

  // BEGIN, CR00028783, KH
  // ___________________________________________________________________________
  /**
   * This method generates the context description for the Issue Delivery.
   *
   * @param issueDeliveryKey The case ID of the issue delivery case.
   *
   * @return The issue delivery context description.
   */
  @Override
  protected ContextDescriptionDetails getIssueDeliveryContextDescription(
    IssueDeliveryKey issueDeliveryKey) throws AppException,
      InformationalException {

    // Return struct
    final ContextDescriptionDetails contextDescriptionDetails = new ContextDescriptionDetails();

    // BEGIN, CR00030749, SPD
    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    ContextDescription contextDescription = new ContextDescription();

    // read back context description
    contextDescription = issueDeliveryObj.getIssueDeliveryContextDescription(
      issueDeliveryKey);

    // Set context description details
    contextDescriptionDetails.description = contextDescription.description;
    // END, CR00030749

    return contextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param caseHeaderKey The case ID of the issue delivery case.
   *
   * @return The issue delivery case homepage details.
   * @deprecated Since Curam 6.0, replaced by {@link #readHomePageDetails1()}.
   *
   * This method is used to display the issue delivery case homepage.
   */
  @Override
  @Deprecated
  public IssueDeliveryHomePageDetails readHomePageDetails(
    CaseHeaderKey caseHeaderKey) throws AppException, InformationalException {

    // Return struct
    final IssueDeliveryHomePageDetails issueDeliveryHomePageDetails = new IssueDeliveryHomePageDetails();

    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // Set key to view Issue Delivery Case details
    issueDeliveryKey.caseID = caseHeaderKey.caseID;

    // BEGIN, CR00031196, KH
    issueDeliveryHomePageDetails.dtls = issueDeliveryObj.readIssueHomePageDetails(
      issueDeliveryKey);
    // END, CR00031196

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = caseHeaderKey.caseID;

    // BEGIN, CR00058145, CSH
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();
    // END, CR00066883

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueDeliveryHomePageDetails.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueDeliveryHomePageDetails.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);

      // BEGIN, CR00066535, CSH
      // Get the adminIntegratedCaseID
      final CaseHeaderKey integratedCaseHeaderKey = new CaseHeaderKey();

      integratedCaseHeaderKey.caseID = relatedCaseID.relatedCaseID;

      issueDeliveryHomePageDetails.adminIntegratedCaseID = IssueDeliveryFactory.newInstance().getAdminIntegratedCaseIDForIssue(integratedCaseHeaderKey).adminIntegratedCaseID;
    }

    // Return the product delivery CaseID
    issueDeliveryHomePageDetails.relatedCaseID = relatedCaseID.relatedCaseID;
    // END, CR00066535
    // END, CR00058145

    // Check case status to set display indicators
    if (issueDeliveryHomePageDetails.dtls.caseDetails.caseStatus.equals(
      CASESTATUS.CLOSED)) {

      issueDeliveryHomePageDetails.indicators.caseClosedInd = true;

    }

    // Check resolution status to set display indicators
    if (issueDeliveryHomePageDetails.dtls.resolutionDetails.resolutionStatus.equals(
      RESOLUTIONSTATUSCODE.INEDIT)) {

      issueDeliveryHomePageDetails.indicators.inEditResolutionInd = true;

    } else if (issueDeliveryHomePageDetails.dtls.resolutionDetails.resolutionStatus.equals(
      RESOLUTIONSTATUSCODE.SUBMITTED)) {

      issueDeliveryHomePageDetails.indicators.submittedResolutionInd = true;

    } else if (issueDeliveryHomePageDetails.dtls.resolutionDetails.resolutionStatus.equals(
      RESOLUTIONSTATUSCODE.APPROVED)) {

      issueDeliveryHomePageDetails.indicators.approvedResolutionInd = true;

    } else { // There is no resolution

      issueDeliveryHomePageDetails.indicators.noResolutionInd = true;
    }

    // Set key to find context description
    issueDeliveryKey.caseID = caseHeaderKey.caseID;

    // Set context description
    issueDeliveryHomePageDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    // BEGIN, CR00022647, AK

    // Read Transaction Log Details
    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = caseHeaderKey.caseID;

    // BEGIN CR00108593, GBA
    issueDeliveryHomePageDetails.transactionDtls.transactionDetailsList.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108593
    // END, CR00022280

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = caseHeaderKey.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    return issueDeliveryHomePageDetails;
  }

  // BEGIN, CR00029046, KH
  // ___________________________________________________________________________
  /**
   * This method returns a list of attachments on an Issue Delivery.
   *
   * @param issueDeliveryKey Key to read the list of Issue Delivery attachments.
   *
   * @return List of Issue Delivery attachments.
   */
  @Override
  public IssueAttachmentList listAttachment(IssueDeliveryKey issueDeliveryKey) throws AppException,
      InformationalException {

    // Return struct
    final IssueAttachmentList issueAttachmentList = new IssueAttachmentList();

    // MaintainAttachment manipulation variables
    final MaintainAttachment maintainAttachmentObj = MaintainAttachmentFactory.newInstance();
    final AttachmentCaseID attachmentCaseID = new AttachmentCaseID();
    AttachmentDetailsList attachmentDetailsList;

    // Set key to retrieve list of attachments
    attachmentCaseID.caseID = issueDeliveryKey.caseID;

    // Get the list of attachments
    attachmentDetailsList = maintainAttachmentObj.readCaseAttachments(
      attachmentCaseID);

    // Check to see if the list is populated
    if (!attachmentDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      issueAttachmentList.dtlsList.dtls.ensureCapacity(
        attachmentDetailsList.dtls.size());

      // Assign details to return object
      issueAttachmentList.dtlsList.assign(attachmentDetailsList);
    }

    // Read context description and assign to return object
    issueAttachmentList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueAttachmentList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueAttachmentList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueAttachmentList;
  }

  // ___________________________________________________________________________
  /**
   * @param issueDeliveryKey Key to read the list of Issue Delivery
   * communications.
   *
   * @return List of Issue Delivery communications.
   * @deprecated Since Curam 6.0, replaced by
   * {@link Case#listCaseCommunication()}. The new method returns the
   * same details but also returns indicators that will be used to
   * conditionally display list row action appropriate to the event
   * type.
   *
   * This method returns a list of communications on an Issue Delivery.
   */
  @Override
  @Deprecated
  public IssueCommunicationList listCommunication(
    IssueDeliveryKey issueDeliveryKey) throws AppException,
      InformationalException {

    // Return struct
    final IssueCommunicationList issueCommunicationList = new IssueCommunicationList();

    // Communication manipulation variables
    CommunicationDetailsList communicationDtlsList;
    final Communication communicationObj = CommunicationFactory.newInstance();
    final CommunicationKey communicationKey = new CommunicationKey();

    // Set key to retrieve list of communications
    communicationKey.caseID = issueDeliveryKey.caseID;

    // Get the list of communications
    communicationDtlsList = communicationObj.listCommunication(communicationKey);

    // Check to see if the list is populated
    if (!communicationDtlsList.concernRoleCommList.dtls.isEmpty()) {

      // Reserve space in the return object
      issueCommunicationList.dtlsList.concernRoleCommList.dtls.ensureCapacity(
        communicationDtlsList.concernRoleCommList.dtls.size());

      // Assign details to return object
      issueCommunicationList.dtlsList.assign(communicationDtlsList);
    }

    // Read context description and assign to return object
    issueCommunicationList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueCommunicationList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueCommunicationList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueCommunicationList;
  }

  // BEGIN, CR00218063, MC
  // ___________________________________________________________________________
  /**
   * @param issueDeliveryKey Key to read the list of Issue Delivery events.
   *
   * @return List of events on the Issue Delivery.
   * @deprecated Since Curam 6.0, replaced by {@link #listEvent1(ListEventKey)}
   * The new method returns the
   * same details but also returns indicators that will be used to
   * conditionally display list row action appropriate to the event
   * type.
   *
   * This method returns a list of events for an Issue Delivery case.
   */
  @Override
  @Deprecated
  public IssueEventList listEvent(IssueDeliveryKey issueDeliveryKey)
    throws AppException, InformationalException {

    // Return struct
    final IssueEventList issueEventList = new IssueEventList();
    final IssueEventList1 issueEventList1 = listEvent1(issueDeliveryKey);

    issueEventList.description = issueEventList1.description;
    issueEventList.idMenuData = issueEventList1.idMenuData;

    ViewActiveCaseEventDetails viewActiveCaseEventDetails;

    for (int i = 0; i < issueEventList1.dtlsList.dtls.size(); i++) {

      viewActiveCaseEventDetails = new ViewActiveCaseEventDetails();
      viewActiveCaseEventDetails.assign(issueEventList1.dtlsList.dtls.item(i));

      issueEventList.dtlsList.dtls.addRef(viewActiveCaseEventDetails);
    }

    return issueEventList;
  }

  // BEGIN, CR00165745, PDN
  // ___________________________________________________________________________
  /**
   * @param key Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchIssueDeliveryEventAndActivity1()}.
   *
   * This method returns data representing case events and activities for an
   * Issue Delivery case.
   */
  @Override
  @Deprecated
  public IssueEventAndActivityList searchIssueDeliveryEventAndActivity(
    SearchCaseEventAndActivityKey key) throws AppException,
      InformationalException {

    // Return Struct
    final IssueEventAndActivityList issueEventAndActivityList = new IssueEventAndActivityList();

    // CalendarData manipulation variables
    final CalendarData calendarDataObj = CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // CaseDecision manipulation variables
    final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();
    boolean caseEventTypeDecisionInd = true;

    // ViewCaseEvents manipulation variables
    final ViewCaseEvents viewCaseEventsObj = ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Calendar data variables
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;
    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj.readEventsByType(
      viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * viewCaseEventDetailsList.dtls.size());

    // BEGIN, CR00163098, JC
    xmlString.append(kCuramCalendarDataHeader).append(kQuote).append(CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASE, TransactionInfo.getProgramLocale())).append(kQuote).append(kCloseBracket).append(
      kSpace);
    // END, CR00163098, JC

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it is an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode.equals(
        CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = curam.codetable.ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj.parseActivity(
          activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else { // It is an event

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls.item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date and end date are the same for events
        eventElementDetails.eventDate = new Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());
        eventElementDetails.eventType = viewCaseEventDetailsList.dtls.item(i).typeCode;

        // Check if this is a case decision event
        CaseDecisionDtls caseDecisionDtls = null;

        caseEventTypeDecisionInd = true;

        // Set key to read case decision
        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

        } catch (final RecordNotFoundException e) {

          // This is not a case decision event
          caseEventTypeDecisionInd = false;
        }

        // If this is a case decision event, only add to list if it is active
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj.parseEvent(
              eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        } // end if caseEventTypeDecisionInd
      } // end if activity

    } // end for i

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);
    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    issueEventAndActivityList.calendarDtls.assign(caseEventAndActivityDetails);

    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = key.caseID;

    // Read context description and assign to return object
    issueEventAndActivityList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueEventAndActivityList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueEventAndActivityList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueEventAndActivityList;
  }

  // END, CR00029133

  // ___________________________________________________________________________
  /**
   * This method returns data representing case events and activities for an
   * Issue Delivery case.
   *
   * @param key Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   */
  @Override
  public IssueEventAndActivityList1 searchIssueDeliveryEventAndActivity1(
    SearchCaseEventAndActivityKey key) throws AppException,
      InformationalException {

    // Return Struct
    final IssueEventAndActivityList1 issueEventAndActivityList1 = new IssueEventAndActivityList1();

    // CalendarData manipulation variables
    final CalendarData calendarDataObj = CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // CaseDecision manipulation variables
    final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();
    boolean caseEventTypeDecisionInd = true;

    // ViewCaseEvents manipulation variables
    final ViewCaseEvents viewCaseEventsObj = ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Calendar data variables
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;
    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj.readEventsByType(
      viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * viewCaseEventDetailsList.dtls.size());

    xmlString.append(kCuramCalendarDataHeader).append(kQuote).append(CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASE)).append(kQuote).append(kCloseBracket).append(
      kSpace);

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it is an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode.equals(
        CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = curam.codetable.ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj.parseActivity(
          activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else { // It is an event

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls.item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date and end date are the same for events
        eventElementDetails.eventDate = new Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());
        eventElementDetails.eventType = viewCaseEventDetailsList.dtls.item(i).typeCode;

        // Check if this is a case decision event
        CaseDecisionDtls caseDecisionDtls = null;

        caseEventTypeDecisionInd = true;

        // Set key to read case decision
        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

        } catch (final RecordNotFoundException e) {

          // This is not a case decision event
          caseEventTypeDecisionInd = false;
        }

        // If this is a case decision event, only add to list if it is active
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj.parseEvent(
              eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        } // end if caseEventTypeDecisionInd
      } // end if activity

    } // end for i

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);
    xmlString.append(kSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    issueEventAndActivityList1.calendarDtls.assign(caseEventAndActivityDetails);

    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = key.caseID;

    // Read context description and assign to return object
    issueEventAndActivityList1.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueEventAndActivityList1.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueEventAndActivityList1.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      issueEventAndActivityList1.isCPMInstalled = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      issueEventAndActivityList1.isAppealsInstalled = true;
    }

    return issueEventAndActivityList1;
  }

  // END, CR00165745

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * This method returns a list of notes on an Issue Delivery.
   *
   * @param issueDeliveryKey Key to read the list of Issue Delivery notes.
   *
   * @return List of Issue Delivery notes.
   * @deprecated - replaced by {@link #listNote1()}
   * @deprecated -since Version 6.0
   */
  @Override
  @Deprecated
  public IssueNoteList listNote(IssueDeliveryKey issueDeliveryKey)
    throws AppException, InformationalException {

    final IssueNoteList issueNoteList = new IssueNoteList();

    final IssueNoteList1 issueNoteList1 = listNote1(issueDeliveryKey);

    issueNoteList.assign(issueNoteList1);

    return issueNoteList;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of notes on an Issue Delivery.
   *
   * @param issueDeliveryKey Key to read the list of Issue Delivery notes.
   *
   * @return List of Issue Delivery notes.
   */
  @Override
  public IssueNoteList1 listNote1(IssueDeliveryKey issueDeliveryKey)
    throws AppException, InformationalException {

    // Create return object
    final IssueNoteList1 issueNoteList = new IssueNoteList1();

    // CaseNote manipulation variables
    final CaseNote caseNoteObj = CaseNoteFactory.newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();
    CaseNoteList1 caseNoteList;

    // Set key to read the list of notes
    caseKey.key.caseID = issueDeliveryKey.caseID;

    // Get list of notes
    caseNoteList = caseNoteObj.list1(caseKey);

    // Check to see if the list is populated
    if (!caseNoteList.details.isEmpty()) {

      // Reserve space in the return object
      issueNoteList.dtlsList.details.ensureCapacity(caseNoteList.details.size());

      // Assign details to return object
      issueNoteList.dtlsList.assign(caseNoteList);
    }

    // Read context description and assign to return object
    issueNoteList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey relatedCaseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    relatedCaseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(
      relatedCaseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueNoteList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueNoteList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueNoteList;
  }

  // END, CR00231506

  // ___________________________________________________________________________
  /**
   * This method returns a list of related cases to the Issue Delivery.
   *
   * @param issueDeliveryKey Key to retrieve the list of related cases.
   *
   * @return List of related cases to the Issue Delivery.
   */
  @Override
  public IssueRelatedCaseList listRelatedCase(
    IssueDeliveryKey issueDeliveryKey) throws AppException,
      InformationalException {

    // Create return object
    final IssueRelatedCaseList issueRelatedCaseList = new IssueRelatedCaseList();

    // MaintainRelatedCases manipulation variables
    final MaintainRelatedCases maintainRelatedCasesObj = MaintainRelatedCasesFactory.newInstance();
    final GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // Assign key details to retrieve list of related cases
    getRelatedCasesKey.caseID = issueDeliveryKey.caseID;

    // Get the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj.getRelatedCases(
      getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      issueRelatedCaseList.dtlsList.dtls.ensureCapacity(
        getRelatedCasesList.dtls.size());

      // CaseHeader object
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();
      CaseTypeCode caseTypeCode = new CaseTypeCode();
      final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();

      for (int i = 0; i < getRelatedCasesList.dtls.size(); i++) {

        caseKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

        caseIDAndTypeCodeKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        final RelatedCaseProductType relatedCaseProductType = maintainRelatedCasesObj.getRelatedCaseProductType(
          caseIDAndTypeCodeKey);

        getRelatedCasesList.dtls.item(i).relatedCaseProductType = relatedCaseProductType.relatedCaseProductType;

        // BEGIN, CR00427963, KRK
        getRelatedCasesList.dtls.item(i).relatedCaseNameOpt = relatedCaseProductType.relatedCaseNameOpt;
        // END, CR00427963
      }

      // Assign details to return object
      issueRelatedCaseList.dtlsList.assign(getRelatedCasesList);
    }

    // Read context description and assign to return object
    issueRelatedCaseList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueRelatedCaseList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueRelatedCaseList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueRelatedCaseList;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of tasks for an Issue Delivery.
   *
   * @param issueDeliveryKey Key to read the list of Issue Delivery tasks.
   *
   * @return List of Issue Delivery task details.
   */
  @Override
  public IssueTaskList listTask(IssueDeliveryKey issueDeliveryKey)
    throws AppException, InformationalException {

    // Return struct
    final IssueTaskList issueTaskList = new IssueTaskList();

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj = WorkAllocationTaskFactory.newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();
    CaseAndConcernLinkedTaskDtls caseAndConcernLinkedTaskDtls;

    // set key to read the list of tasks
    searchTaskForConcernOrCaseKey.details.linkedID = issueDeliveryKey.caseID;

    // Get list of case tasks
    caseAndConcernLinkedTaskDtls = workAllocationTaskObj.listCaseTasks(
      searchTaskForConcernOrCaseKey);

    // Check to see if the list is populated
    if (!caseAndConcernLinkedTaskDtls.dtls.dtls.isEmpty()) {

      // Reserve space in the return object
      issueTaskList.dtlsList.dtls.ensureCapacity(
        caseAndConcernLinkedTaskDtls.dtls.dtls.size());

      // Assign details to return object
      issueTaskList.dtlsList.assign(caseAndConcernLinkedTaskDtls.dtls);

      // Iterate through the list and set reservedByExistsInd to true
      for (int i = 0; i < issueTaskList.dtlsList.dtls.size(); i++) {

        if (issueTaskList.dtlsList.dtls.item(i).reservedBy.length() > 0) {

          issueTaskList.dtlsList.dtls.item(i).reservedByExistsInd = true;
        }
      } // end for i
    }

    // Read context description and assign to return object
    issueTaskList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueTaskList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueTaskList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueTaskList;
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of user roles for an Issue Delivery.
   *
   * @param issueDeliveryKey Key to read the list of Issue Delivery user roles.
   *
   * @return List of Issue Delivery user role details.
   */
  @Override
  public IssueUserRoleList listUserRole(IssueDeliveryKey issueDeliveryKey)
    throws AppException, InformationalException {

    final IssueUserRoleList issueUserRoleList = new IssueUserRoleList();
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    CaseUserRoleDetailsList caseUserRoleDetailsList;
    final CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new CaseUserRoleCaseIDKey();

    caseUserRoleCaseIDKey.dtls.caseID = issueDeliveryKey.caseID;

    caseUserRoleDetailsList = caseUserRoleObj.listCaseUserRoles(
      caseUserRoleCaseIDKey);

    // BEGIN, CR00187598, SS
    final int userRoleslistSize = caseUserRoleDetailsList.dtls.size();

    if (!caseUserRoleDetailsList.dtls.isEmpty()) {

      issueUserRoleList.dtlsList.dtls.ensureCapacity(userRoleslistSize);

      // BEGIN, CR, GSP
      // retrieve environment variable
      final String dispWorkQueueAsOwnerInCaseUserRole = Configuration.getProperty(
        EnvVars.ENV_DISPLAYTEMPWORKQUEUEASOWNERINCASEUSERROLE);

      for (final CaseUserRoleDetails caseUserRoleDetails : caseUserRoleDetailsList.dtls.items()) {

        if (!(CuramConst.kTemporaryOwnerWorkqueueName.equalsIgnoreCase(
          caseUserRoleDetails.dtls.ownerDetails.orgObjectReferenceName)
            && dispWorkQueueAsOwnerInCaseUserRole.equalsIgnoreCase(
              EnvVars.ENV_VALUE_NO))) {

          issueUserRoleList.dtlsList.dtls.addRef(caseUserRoleDetails);
        }
      }
      // END, CR, GSP
    }
    // END, CR00187598

    // Read context description and assign to return object.
    issueUserRoleList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data.
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data.
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id.
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against.
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery.
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery.
      issueUserRoleList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case.
      issueUserRoleList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    return issueUserRoleList;
  }

  // END, CR00029046

  // BEGIN, CR00019643, CM
  // ___________________________________________________________________________
  /**
   * This method is used to list all the resolution status changes that the
   * issue has been through.
   *
   * @param key Resolution entity key
   *
   * @return Details of the resolution status history
   */
  @Override
  public ResolutionStatusHistoryDtlsList listResolutionStatusHistory(
    ResolutionKey key) throws AppException, InformationalException {

    // Return Struct
    final ResolutionStatusHistoryDtlsList resolutionStatusHistoryDtlsList = new ResolutionStatusHistoryDtlsList();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    resolutionStatusHistoryDtlsList.dtlsList = issueDeliveryObj.listResolutionStatusHistory(
      key);

    // Get key to find context description
    issueDeliveryKey = issueDeliveryObj.readIssueDeliveryKeyForResolution(key);

    // Set context description
    resolutionStatusHistoryDtlsList.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return resolutionStatusHistoryDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the user to view the resolution status for an issue.
   * An issue can have the following status: In Edit, Submitted, Approved.
   *
   * @param key Resolution Status History key
   *
   * @return Details of the resolution status history
   */
  @Override
  public ResolutionStatusHistoryDtls readResolutionStatusHistory(
    ResolutionStatusHistoryKey key) throws AppException,
      InformationalException {

    // Return struct
    final ResolutionStatusHistoryDtls resolutionStatusHistoryDtls = new ResolutionStatusHistoryDtls();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // Resolution manipulation variables
    final ResolutionKey resolutionKey = new ResolutionKey();

    resolutionStatusHistoryDtls.dtls = issueDeliveryObj.readResolutionStatusHistory(
      key);

    // Set key to read issue delivery ID
    resolutionKey.resolutionID = resolutionStatusHistoryDtls.dtls.dtls.resolutionID;

    // Get key to find context description
    issueDeliveryKey = issueDeliveryObj.readIssueDeliveryKeyForResolution(
      resolutionKey);

    // Set context description
    resolutionStatusHistoryDtls.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return resolutionStatusHistoryDtls;
  }

  // END, CR00019643

  // ___________________________________________________________________________
  /**
   * Generates the menu data for an issue delivery on an integrated case.
   *
   * @param key Contains the case identifier
   *
   * @return Menu data for the issue delivery
   */
  @Override
  public IssueDeliveryMenuDataDetails getIssueDeliveryMenuData(
    IssueDeliveryMenuDataKey key) throws AppException, InformationalException {

    // Create return object
    final IssueDeliveryMenuDataDetails issueDeliveryMenuDataDetails = new IssueDeliveryMenuDataDetails();

    final CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();
    ParticipantHomePageName participantHomePageName;

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    final CaseKey caseKey = new CaseKey();

    // BEGIN, CR00030419, CM
    // ProductDelivery manipulation variables
    final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;
    CaseHomePageNameAndType caseHomePageNameAndType;
    // END, CR00030419

    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = curam.core.sl.fact.IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
    HomePageIDIssueTypeCaseRef homePageIDIssueTypeCaseRef = new HomePageIDIssueTypeCaseRef();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // BEGIN, CR00030419, CM
    // BEGIN, CR00030928, KH
    // Set key to read issue configuration
    issueDeliveryKey.caseID = key.caseID;

    // BEGIN, CR00054295, CSH
    // Find the caseID for the related case
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00030928

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    // Set the key to read product deliveries homepage name and type
    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Read productDelivery to retrieve the case home page name and
    // product type
    caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);
    // END, CR00030419

    // Reads the issueDelivery home page identifier and type
    homePageIDIssueTypeCaseRef = issueDeliveryObj.readHomePageIDIssueTypeCaseRef(
      issueDeliveryKey);

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey = caseHeaderObj.readIntegratedCaseReferenceByCaseID(
      caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    // Setting the case header to a localized string
    // e.g. PC1 - 515
    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Integrated Case Tab Bar
    // Creating the dynamic menu for the Integrated Case
    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node (link elements)
    Element linkElement = new Element(kItem);

    // Setting the link page ID and the description
    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    // Set the type
    linkElement.setAttribute(kType, kTypeCase);

    // Add the child node to the root node
    navigationMenuElement.addContent(linkElement);

    // Create parameter
    Element paramElement = new Element(kParam);

    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    // Add the parameter elements to the child node
    linkElement.addContent(paramElement);

    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.caseID = integratedCaseReferenceKey.integratedCaseID;
    readByParticipantRoleTypeAndCaseKey.participantRoleID = productDeliveryDtls.recipConcernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
      readByParticipantRoleTypeAndCaseKey);

    // END, CR00278729

    // Set the caseParticipantRoleID
    caseParticipantRoleIDKey.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478

    // Get participant home page
    participantHomePageName = IntegratedCaseFactory.newInstance().resolveParticipantHome(
      caseParticipantRoleIDKey);

    // ICMember Tab Bar
    // Creating the dynamic menu for the ICMember
    // create link to the participant home page.
    linkElement = new Element(kItem);

    // Set the link elements
    // Set the page ID
    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    // Set the description and type
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    // Add the child node to the root node
    navigationMenuElement.addContent(linkElement);

    // Create parameter element
    paramElement = new Element(kParam);

    // Set the parameter elements
    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);

    // BEGIN, CR00305478, MV
    paramElement.setAttribute(kValue,
      Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478

    // Add the parameter elements to the child node
    linkElement.addContent(paramElement);

    // Create parameter element
    paramElement = new Element(kParam);

    // Set the parameters elements, name and value
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    // Add the parameter elements to the link elements
    linkElement.addContent(paramElement);

    // BEGIN, CR00030419, CM
    // Product Delivery Tab Bar
    // Create product item child element and add it to the root
    linkElement = new Element(kItem);
    linkElement.setAttribute(kPageID, caseHomePageNameAndType.caseHomePageName);

    // Set the description
    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    // Set the typeCode
    description.arg(
      new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode));

    // Set the link elements
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeProduct);

    // Add the link elements to the root node
    navigationMenuElement.addContent(linkElement);

    // Create parameter elements
    paramElement = new Element(kParam);

    // Set parameter elements
    paramElement.setAttribute(kName, kParamCaseID);
    // BEGIN, CR00058145, CSH
    // Set the product delivery case id
    paramElement.setAttribute(kValue, Long.toString(productDeliveryKey.caseID));
    // END, CR00058145

    // Add parameter elements to the link elements
    linkElement.addContent(paramElement);
    // END, CR00030419

    // Issue Delivery Tab Bar
    // Create Issue item child element and add it to the root
    linkElement = new Element(kItem);

    // Set link elements
    linkElement.setAttribute(kPageID,
      homePageIDIssueTypeCaseRef.homePageIdentifier);

    // Displays the issue type and the issue reference number
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_ID_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(ISSUECONFIGURATIONTYPE.TABLENAME,
      homePageIDIssueTypeCaseRef.issueType));

    description.arg(homePageIDIssueTypeCaseRef.caseReference);

    // Sets the link elements
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    // BEGIN, CR00030508, CM
    linkElement.setAttribute(kType, kTypeIssue);
    // END, CR00030508

    // Adds the link elements to the root node
    navigationMenuElement.addContent(linkElement);

    // Create a parameter
    paramElement = new Element(kParam);

    // Sets the parameter elements
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    // Adds the parameter elements to the link elements
    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    // The root node is added to the menu data
    issueDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return issueDeliveryMenuDataDetails;
  }

  // BEGIN, CR00019714, PMD
  // ___________________________________________________________________________
  /**
   * This method is used to render a Resolution on an issue.
   *
   * @param details the resolution details
   */
  @Override
  public void createResolution(ResolutionDetails details)
    throws AppException, InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Call API to perform the create operation
    issueDeliveryObj.createResolution(details.details);
  }

  // ___________________________________________________________________________
  /**
   * This method lists active resolutions which have been configured
   * for this type of issue.
   *
   * @param key The ID of the issue configured in administration.
   *
   * @return A list of active resolutions.
   */
  @Override
  public ResolutionAndConfigIDDetailsList listActiveResolutionsForIssue(
    IssueConfigurationKey key) throws AppException, InformationalException {

    // Return Object
    final ResolutionAndConfigIDDetailsList resolutionAndConfigIDDetailsList = new ResolutionAndConfigIDDetailsList();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Call API to perform the list operation
    resolutionAndConfigIDDetailsList.detailsList = issueDeliveryObj.listActiveResolutionsForIssue(
      key);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      resolutionAndConfigIDDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return resolutionAndConfigIDDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to modify a Resolution.
   *
   * @param details The resolution details.
   */
  @Override
  public void modifyResolution(ResolutionDetails details)
    throws AppException, InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Call API to perform the modify operation
    issueDeliveryObj.modifyResolution(details.details);
  }

  // END, CR00019714

  // BEGIN, CR00020132, PMD
  // ___________________________________________________________________________
  /**
   * This method is used to submit a resolution for approval.
   *
   * @param key The submit resolution for approval key .
   */
  @Override
  public void submitResolutionForApproval(SubmitResolutionForApprovalKey key)
    throws AppException, InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Call API to submit resolution for approval
    issueDeliveryObj.submitResolution(key.key);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to approve a resolution. An issue resolution can
   * only be approved by a user with the appropriate privileges.
   * 
   * @param key The case and resolution unique identifiers.
   */
  @Override
  public void approveResolution(ApproveResolutionKey key)
    throws AppException, InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // BEGIN, CR00092073, PMD
    // CaseUserRole manipulation variable
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final UserNameKey userNameKey = new UserNameKey();

    // Set the case header key
    caseHeaderKey.caseID = key.key.caseID;

    // Set the username key to be the current user
    userNameKey.userName = TransactionInfo.getProgramUser();

    // Check if the user is a supervisor
    final IsUserSupervisor isUserSupervisor = caseUserRoleObj.isUserSupervisor(
      caseHeaderKey, userNameKey);

    // User must be a supervisor to approve a resolution
    if (!isUserSupervisor.isUserSupervisor) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOPRODUCTDELIVERYAPPROVAL.ERR_USER_FV_NOT_SUPERVISOR),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    // END, CR00092073

    // Call API to approve resolution
    issueDeliveryObj.approveResolution(key.key);
  }

  // END, CR00020132

  // BEGIN, CR00028885, PMD
  // ___________________________________________________________________________
  /**
   * This method is used to reject a resolution.
   *
   * @param key The case and resolution unique identifiers along with a
   * rejection reason and any comments.
   */
  @Override
  public void rejectResolution(RejectResolutionKey key) throws AppException,
      InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // BEGIN, CR00092073, PMD
    // CaseUserRole manipulation variable
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final UserNameKey userNameKey = new UserNameKey();

    // Set the case header key
    caseHeaderKey.caseID = key.key.caseID;

    // Set the username key to be the current user
    userNameKey.userName = TransactionInfo.getProgramUser();

    // Check if the user is a supervisor
    final IsUserSupervisor isUserSupervisor = caseUserRoleObj.isUserSupervisor(
      caseHeaderKey, userNameKey);

    // User must be a supervisor to reject a resolution
    if (!isUserSupervisor.isUserSupervisor) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOPRODUCTDELIVERYAPPROVAL.ERR_USER_FV_NOT_SUPERVISOR),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    }
    // END, CR00092073

    // Call API to reject resolution
    issueDeliveryObj.rejectResolution(key.key);
  }

  // END, CR00028885

  // BEGIN, CR00020047, CSH
  // ___________________________________________________________________________
  /**
   * This method is used to close an issue delivery.
   *
   * @param details The closure details.
   */
  @Override
  public void close(CloseCaseDetails details) throws AppException,
      InformationalException {

    // IssueDelivery object
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final ClosureDtls closureDtls = new ClosureDtls();

    // Assign closure details
    closureDtls.caseID = details.caseID;
    closureDtls.comments = details.comments;
    closureDtls.reasonCode = details.reasonCode;

    // BEGIN CR00161590, PDN
    // Set the user that is closing the case
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    closureDtls.userID = systemUserObj.getUserDetails().userName;
    // END, CR00161590

    // BEGIN, CR00031196, KH
    // Close the issue delivery
    issueDeliveryObj.closeIssueDelivery(closureDtls);
    // END, CR00031196
  }

  // ___________________________________________________________________________
  /**
   * This method is used to modify the closure details for an issue delivery.
   *
   * @param details The updated issue delivery closure details.
   */
  @Override
  public void modifyClosureDetails(CloseCaseDetails details)
    throws AppException, InformationalException {

    // IssueDelivery object
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final ClosureDtls closureDtls = new ClosureDtls();

    // Assign closure details
    closureDtls.caseID = details.caseID;
    closureDtls.comments = details.comments;
    closureDtls.reasonCode = details.reasonCode;

    // BEGIN, CR00031196, KH
    // Modify the issue delivery closure details
    issueDeliveryObj.modifyIssueDeliveryClosureDetails(closureDtls);
    // END, CR00031196
  }

  // ___________________________________________________________________________
  /**
   * @param details The closure details.
   * @deprecated Since Curam 6.0, replaced by {@link #readClosureDetails1()}.
   *
   * This method is used to view the closure details of a closed issue delivery.
   */
  @Override
  @Deprecated
  public IssueClosureDetails readClosureDetails(CloseCaseDetails details)
    throws AppException, InformationalException {

    // IssueDelivery object
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
    final ClosureDtls closureDtls = new ClosureDtls();

    // Return struct
    final IssueClosureDetails issueClosureDetails = new IssueClosureDetails();

    // Assign closure details
    closureDtls.caseID = details.caseID;
    closureDtls.comments = details.comments;
    closureDtls.reasonCode = details.reasonCode;

    // BEGIN, CR00031196, KH
    // Read the issue delivery closure details
    issueClosureDetails.dtls = issueDeliveryObj.readIssueDeliveryClosureDetails(
      closureDtls);
    // END, CR00031196

    // Set key to find context description
    issueDeliveryKey.caseID = details.caseID;

    // Set context description
    issueClosureDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return issueClosureDetails;
  }

  // END, CR00020047

  // BEGIN, CR00029141, CM
  // ___________________________________________________________________________
  /**
   * This method is used to list all the resolution approval requests for an
   * issue.
   *
   * @param key The case header key.
   *
   * @return The issue approval request details list.
   */
  @Override
  public IssueApprovalRequestDtlsList listIssueApprovalRequest(
    CaseHeaderKey key) throws AppException, InformationalException {

    // IssueApprovalRequest manipulation variables
    final IssueApprovalRequestDtlsList issueApprovalRequestDtlsList = new IssueApprovalRequestDtlsList();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // Call API to list the issue approval requests
    issueApprovalRequestDtlsList.dtlsList = issueDeliveryObj.listIssueApprovalRequest(
      key);

    // Set key to find context description
    issueDeliveryKey.caseID = key.caseID;

    // Set context description
    issueApprovalRequestDtlsList.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00068504, CSH
    // Read Menu Data

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueApprovalRequestDtlsList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueApprovalRequestDtlsList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00068504

    return issueApprovalRequestDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to view a resolution approval request homepage.
   *
   * @param key The issue approval request key.
   *
   * @return The issue approval request details.
   */
  @Override
  public IssueApprovalRequestDetails viewIssueApprovalRequest(
    IssueApprovalRequestKey key) throws AppException, InformationalException {

    // IssueApprovalRequest manipulation variables
    final IssueApprovalRequestDetails issueApprovalRequestDetails = new IssueApprovalRequestDetails();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // Call API to read the issue approval request
    issueApprovalRequestDetails.dtls = issueDeliveryObj.readIssueApprovalRequest(
      key);

    // Get key to find context description
    issueDeliveryKey = issueDeliveryObj.readIssueDeliveryKeyForApprovalRequest(
      key);

    // Set context description
    issueApprovalRequestDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return issueApprovalRequestDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method modifies an issue resolution approval request.
   * An approval request may only be modified if it has a status of Rejected.
   *
   * @param key The issue approval request key
   */
  @Override
  public void modifyApprovalRequest(IssueApprovalRequestKey key,
    ModifyRejectionDetails details) throws AppException,
      InformationalException {

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Call API to modify the issue approval request
    issueDeliveryObj.modifyIssueApprovalRequest(key, details);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve the rejection details required
   * to modify the issue approval request.
   *
   * @param key The issue approval request key.
   *
   * @return The rejection details from the approval request entity.
   */
  @Override
  public RejectDetails readRejectDetails(IssueApprovalRequestKey key)
    throws AppException, InformationalException {

    // Return struct
    final RejectDetails rejectDetails = new RejectDetails();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // ApprovalRequest manipulation variables
    final ApprovalRequest approvalRequestObj = ApprovalRequestFactory.newInstance();

    // Read rejection reason and comments
    rejectDetails.dtls = approvalRequestObj.readRejectDtlsByIssueApprovalRequest(
      key);

    // Get key to find context description
    issueDeliveryKey = issueDeliveryObj.readIssueDeliveryKeyForApprovalRequest(
      key);

    // Set context description
    rejectDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return rejectDetails;
  }

  // END, CR00029141

  // BEGIN, CR00047428, CSH
  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all issue deliveries for a specified
   * concern role.
   *
   * @param key The unique id for the concern role.
   *
   * @return The list of issue delivery details for the concern.
   */
  @Override
  public IssuesForConcernRoleDetailsList listIssuesForConcernRole(
    RelationshipConcernRoleIDKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final IssuesForConcernRoleDetailsList issuesForConcernRoleDetailsList = new IssuesForConcernRoleDetailsList();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // BEGIN, CR00169613, VK
    // Participant manipulation variable
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // Context Description key
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Set the Context key
    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    issuesForConcernRoleDetailsList.description.description = participantContextObj.readContextDescription(participantContextDescriptionKey).description;
    // END, CR00169613
    // Search for issue delivery cases
    issuesForConcernRoleDetailsList.dtlsList = issueDeliveryObj.listIssueForConcernRole(
      key);

    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssueForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssue;

      // Build up the xml data needed for the tab widget
      issuesForConcernRoleDetailsList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      issuesForConcernRoleDetailsList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    return issuesForConcernRoleDetailsList;
  }

  // END, CR00047428

  // BEGIN, CR00058145, CSH
  // ___________________________________________________________________________
  /**
   * This method is used to get the evidence type, issue type and member details
   * selected by the user.
   *
   * @param details The evidence and issue type and member details.
   *
   * @return The evidence and issue type and member details..
   */
  @Override
  public IssueEvidenceTypeAndMemberDetails getIssueEvidenceTypeAndMemberDetails(
    IssueEvidenceTypeAndMemberDetails details) throws AppException,
      InformationalException {

    // Declare return struct
    final IssueEvidenceTypeAndMemberDetails issueEvidenceTypeAndMemberDetails = new IssueEvidenceTypeAndMemberDetails();

    issueEvidenceTypeAndMemberDetails.assign(details);

    // Return
    return issueEvidenceTypeAndMemberDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to add evidence selected by the user to an issue
   * delivery.
   *
   * @param details The issue delivery evidence details.
   *
   * @return IssueDeliveryKey The unique identifier for the issue delivery.
   */
  @Override
  public IssueDeliveryKey addEvidence(IssueDeliveryAddEvidenceDetails details) throws AppException,
      InformationalException {

    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // BEGIN, CR00066535, CSH
    // Add the evidence to the issue delivery
    issueDeliveryKey = issueDeliveryObj.addIssueDeliveryEvidence(details.dtls);
    // END, CR00066535

    // Return the case id for the issue delivery
    return issueDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to create an issue delivery using details manually
   * entered by the user.
   *
   * @param details The issue creation details.
   *
   * @return IssueDeliveryKey The unique ID for the issue delivery case.
   */
  @Override
  public IssueDeliveryKey create(
    IssueDeliveryCreationAndEvidenceDetails details) throws AppException,
      InformationalException {

    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
    curam.core.sl.struct.IssueDeliveryCreationAndEvidenceDetails issueDeliveryDetails = new curam.core.sl.struct.IssueDeliveryCreationAndEvidenceDetails();

    // Get the details
    issueDeliveryDetails = details.dtls;

    // Create the issue delivery
    issueDeliveryKey = issueDeliveryObj.createManualIssueDelivery(
      issueDeliveryDetails);

    // BEGIN, CR00080678, CH
    // The issue may not have been created if an issue already exists
    // for the piece of evidence selected, if this is the case the key will
    // not have been populated. We now return an informational to the user
    // informing them that this is the case.
    if (issueDeliveryKey.caseID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOISSUEDELIVERY.ERR_EVIDENCE_ALREADY_ADDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // END, CR00080678

    // Return the case id for the issue delivery
    return issueDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to return a list of evidence records of the the type
   * associated with the case that the issue is raised against if an evidence
   * type is select by the user as part of manual issue creation process.
   *
   * @param key The unique evidence ID and evidence type.
   *
   * @return IssueDeliveryKey The list of evidence records for the specified
   * type.
   */
  @Override
  public curam.core.facade.infrastructure.struct.EvidenceListDetails listEvidence(EvidenceListKey key) throws AppException,
      InformationalException {

    // Evidence manipulation variables
    final Evidence evidenceObj = EvidenceFactory.newInstance();
    curam.core.facade.infrastructure.struct.EvidenceListDetails evidenceList = new curam.core.facade.infrastructure.struct.EvidenceListDetails();

    // List variable to be returned
    final curam.core.facade.infrastructure.struct.EvidenceListDetails issueDeliveryEvidenceList = new curam.core.facade.infrastructure.struct.EvidenceListDetails();

    // Check if the user selected an evidence
    // BEGIN, CR00053248, GM
    if (!key.key.evidenceType.equals(CuramConst.gkEmpty)) {
      // END, CR00053248

      // Get the list of all of evidence of relevant status associated with the
      // type of case the issue was raised against
      evidenceList = evidenceObj.listEvidence(key);

      // Add all the records we are interested in to the same list
      issueDeliveryEvidenceList.dtls.activeList.dtls.addAll(
        evidenceList.dtls.activeList.dtls);

      for (int i = 0; i < evidenceList.dtls.newAndUpdateList.dtls.size(); i++) {

        final ECActiveEvidenceDtls ecActiveEvidenceDtls = new ECActiveEvidenceDtls();

        ecActiveEvidenceDtls.evidenceDescriptorID = evidenceList.dtls.newAndUpdateList.dtls.item(i).evidenceDescriptorID;
        ecActiveEvidenceDtls.correctionSetID = evidenceList.dtls.newAndUpdateList.dtls.item(i).correctionSetID;
        // BEGIN, CR00075116, CSH
        ecActiveEvidenceDtls.evidenceID = evidenceList.dtls.newAndUpdateList.dtls.item(i).evidenceID;
        // END, CR00075116
        ecActiveEvidenceDtls.evidenceType = evidenceList.dtls.newAndUpdateList.dtls.item(i).evidenceType;
        ecActiveEvidenceDtls.concernRoleName = evidenceList.dtls.newAndUpdateList.dtls.item(i).concernRoleName;
        ecActiveEvidenceDtls.effectiveFrom = evidenceList.dtls.newAndUpdateList.dtls.item(i).effectiveFrom;
        ecActiveEvidenceDtls.summary = evidenceList.dtls.newAndUpdateList.dtls.item(i).summary;
        ecActiveEvidenceDtls.statusCode = evidenceList.dtls.newAndUpdateList.dtls.item(i).statusCode;

        issueDeliveryEvidenceList.dtls.activeList.dtls.add(ecActiveEvidenceDtls);
      }
    }
    // Return the list
    return issueDeliveryEvidenceList;
  }

  // ___________________________________________________________________________
  /**
   * Generates the menu data for an issue delivery on an integrated case.
   *
   * @param key Contains the case identifier
   *
   * @return Menu data for the issue delivery
   */
  @Override
  public IssueDeliveryMenuDataDetails getIssueDeliveryMenuDataForIC(
    IssueDeliveryMenuDataKey key) throws AppException, InformationalException {

    // Create return object
    final IssueDeliveryMenuDataDetails issueDeliveryMenuDataDetails = new IssueDeliveryMenuDataDetails();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();
    ParticipantHomePageName participantHomePageName;

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICHomePageNameAndType icHomePageNameAndType = new ICHomePageNameAndType();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    final CaseKey caseKey = new CaseKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = curam.core.sl.fact.IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
    HomePageIDIssueTypeCaseRef homePageIDIssueTypeCaseRef = new HomePageIDIssueTypeCaseRef();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Set key to read issue configuration
    issueDeliveryKey.caseID = key.caseID;

    // Find the caseID for the related case
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    // Set the case header key for the issue delivery
    caseHeaderKey.caseID = key.caseID;

    // Set the case header key for the case against which the issue was raised
    caseKey.caseID = relatedCaseID.relatedCaseID;

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // Read concernRoleName
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    // Set the key to read integrated case homepage name and type
    caseKey.caseID = relatedCaseID.relatedCaseID;

    // Read home page name and type
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    // Reads the issueDelivery home page identifier and type
    homePageIDIssueTypeCaseRef = issueDeliveryObj.readHomePageIDIssueTypeCaseRef(
      issueDeliveryKey);

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    // Setting the case header to a localized string
    // e.g. PC1 - 515
    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icHomePageNameAndType.integratedCaseType));

    description.arg(icHomePageNameAndType.caseReference);

    // Integrated Case Tab Bar
    // Creating the dynamic menu for the Integrated Case
    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node (link elements)
    Element linkElement = new Element(kItem);

    // Setting the link page ID and the description
    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    // Set the type
    linkElement.setAttribute(kType, kTypeCase);

    // Add the child node to the root node
    navigationMenuElement.addContent(linkElement);

    // Create parameter
    Element paramElement = new Element(kParam);

    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(caseKey.caseID));

    // Add the parameter elements to the child node
    linkElement.addContent(paramElement);

    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    // BEGIN, CR00305478, MV
    // BEGIN, 146339, MD
    ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = 
      getCaseParticipantRoleID(caseKey.caseID, concernRoleKey.concernRoleID);
    // END, 146339
    // END, CR00278729

    // Set the caseParticipantRoleID
    caseParticipantRoleIDKey.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478

    // Get participant home page
    participantHomePageName = IntegratedCaseFactory.newInstance().resolveParticipantHome(
      caseParticipantRoleIDKey);

    // ICMember Tab Bar
    // Creating the dynamic menu for the ICMember
    // create link to the participant home page.
    linkElement = new Element(kItem);

    // Set the link elements
    // Set the page ID
    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    // Set the description and type
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    // Add the child node to the root node
    navigationMenuElement.addContent(linkElement);

    // Create parameter element
    paramElement = new Element(kParam);

    // Set the parameter elements
    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);

    // BEGIN, CR00305478, MV
    paramElement.setAttribute(kValue,
      Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478

    // Add the parameter elements to the child node
    linkElement.addContent(paramElement);

    // Create parameter element
    paramElement = new Element(kParam);

    // Set the parameters elements, name and value
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(caseKey.caseID));

    // Add the parameter elements to the link elements
    linkElement.addContent(paramElement);

    // Issue Delivery Tab Bar
    // Create Issue item child element and add it to the root
    linkElement = new Element(kItem);

    // Set link elements
    linkElement.setAttribute(kPageID,
      homePageIDIssueTypeCaseRef.homePageIdentifier);

    // Displays the issue type and the issue reference number
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_ID_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(ISSUECONFIGURATIONTYPE.TABLENAME,
      homePageIDIssueTypeCaseRef.issueType));

    description.arg(homePageIDIssueTypeCaseRef.caseReference);

    // Sets the link elements
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeIssue);

    // Adds the link elements to the root node
    navigationMenuElement.addContent(linkElement);

    // Create a parameter
    paramElement = new Element(kParam);

    // Sets the parameter elements
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    // Adds the parameter elements to the link elements
    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    // The root node is added to the menu data
    issueDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return issueDeliveryMenuDataDetails;
  }

  // END, CR00058145

  // BEGIN, CR00102618, CSH
  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all issue deliveries for a specified
   * duplicate concern role.
   *
   * @param key The unique id for the duplicate concern role.
   *
   * @return The list of issue delivery details for the duplicate concern.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public IssuesForDuplicateConcernRoleDetailsList listIssuesForDuplicateConcernRole(ConcernRoleKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final IssuesForDuplicateConcernRoleDetailsList issuesForDupConcernRoleDetailsList = new IssuesForDuplicateConcernRoleDetailsList();

    // IssueDelivery manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // Participant manipulation variable
    final ParticipantContext participantContextObj = ParticipantContextFactory.newInstance();

    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // BEGIN, CR00169613, VK
    // Set the Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the original concern role
    issuesForDupConcernRoleDetailsList.issuesForDuplicateConcern.description.description = participantContextObj.readContextDescription(participantContextDescriptionKey).description;

    // Set the context description key to be the duplicate concern role ID
    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the duplicate concern role
    issuesForDupConcernRoleDetailsList.duplicateContextDesc.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);
    // END, CR00169613
    // Set the key for issue delivery case search
    final RelationshipConcernRoleIDKey relConcernRoleIDKey = new RelationshipConcernRoleIDKey();

    relConcernRoleIDKey.concernRoleID = key.concernRoleID;

    // Search for issue delivery cases
    issuesForDupConcernRoleDetailsList.issuesForDuplicateConcern.dtlsList = issueDeliveryObj.listIssueForConcernRole(
      relConcernRoleIDKey);

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssueForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssue;

    // Build up the xml data needed for the tab widget
    issuesForDupConcernRoleDetailsList.issuesForDuplicateConcern.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Set an indicator if this concern has duplicates
    issuesForDupConcernRoleDetailsList.issuesForDuplicateConcern.ind = clientMergeSLObj.isConcernRoleOriginalClient(
      concernRoleIDStatusCodeKey);
    // END, CR00120078

    return issuesForDupConcernRoleDetailsList;
  }

  // END, CR00102618

  // BEGIN, CR00148820, MC
  // ___________________________________________________________________________
  /**
   * Reads the list of recent transactions on this investigation delivery case.
   *
   * @param caseKey CaseHeaderKey the identifier for the issue delivery case.
   * @return ListTransactionsLogDetails The list of recent transactions and the
   * appropriate menu and context data.
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListTransactionsLogDetails listRecentTransaction(
    IssueDeliveryKey issueDeliveryKey) throws AppException,
      InformationalException {

    // Return Struct
    final ListTransactionsLogDetails listTransactionsLogDetails = new ListTransactionsLogDetails();

    // Case Transaction Log business process object
    final ReadTransactionLogDetailsList readTransactionLogDetailsList = new ReadTransactionLogDetailsList();

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = issueDeliveryKey.caseID;
    readTransactionLogDetailsList.transactionDetailsList = caseTransactionLogProvider.get().readAllTransactions(
      caseIDKey);

    listTransactionsLogDetails.transactionDetailsList = readTransactionLogDetailsList;

    listTransactionsLogDetails.contextDescription.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = issueDeliveryKey.caseID;

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      listTransactionsLogDetails.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      listTransactionsLogDetails.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }

    return listTransactionsLogDetails;
  }

  // END, CR00148820

  // BEGIN, CR00211698, MC
  // ___________________________________________________________________________
  /**
   * Returns the wizard details for the integrated case issue delivery creation
   * wizard sample.
   *
   * @return The wizard details for the integrated case issue delivery creation
   * wizard sample.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public WizardProperties getCreateIssueDeliveryWizard() throws AppException,
      InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCreateIssueDeliveryWizardProperties;

    return wizardProperties;
  }

  // END, CR00211698

  // BEGIN, CR00241755, MC
  // ___________________________________________________________________________
  /**
   * Returns the wizard details for the integrated case issue delivery creation
   * wizard sample.
   *
   * @return The wizard details for the integrated case issue delivery creation
   * wizard sample.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public WizardProperties getCreateIssueDeliveryForPDWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCreateIssueDeliveryForPDWizardProperties;

    return wizardProperties;
  }

  // END, CR00241755

  // ___________________________________________________________________________
  /**
   * This method returns a list of events for an Issue Delivery case.
   *
   * @param issueDeliveryKey Key to read the list of Issue Delivery events.
   *
   * @return List of events on the Issue Delivery.
   */
  @Override
  public IssueEventList1 listEvent1(IssueDeliveryKey issueDeliveryKey)
    throws AppException, InformationalException {

    // Return struct
    final IssueEventList1 issueEventList = new IssueEventList1();

    // ViewCaseEvents manipulation variables
    final ViewCaseEvents viewCaseEventsObj = ViewCaseEventsFactory.newInstance();
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList;

    // CaseDecision manipulation variables
    final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();
    boolean caseEventTypeDecisionInd = true;

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.caseID = issueDeliveryKey.caseID;

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList = viewCaseEventsObj.readActiveEventsByType1(
      viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      issueEventList.dtlsList.dtls.ensureCapacity(
        viewActiveCaseEventDetailsList.dtls.size());

      // If the list has case event decisions of type superseded, do not
      // return them on the view list for the case

      // Create new struct to hold all case events except those of type
      // superseded case decisions
      final ViewActiveCaseEventDetailsList1 viewFilteredCaseEventDetailsList = new ViewActiveCaseEventDetailsList1();

      for (int i = 0; i < viewActiveCaseEventDetailsList.dtls.size(); i++) {

        // Check if this is a case decision event
        CaseDecisionDtls caseDecisionDtls = null;

        caseEventTypeDecisionInd = true;

        // Set key to read case decision
        caseDecisionKey.caseDecisionID = viewActiveCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

        } catch (final RecordNotFoundException e) {

          // This is not a case decision event
          caseEventTypeDecisionInd = false;

        }

        // If this is a case decision event, only add to list if it is active
        if (caseEventTypeDecisionInd) {

          if (caseDecisionDtls.statusCode.equals(CASEDECISIONSTATUS.CURRENT)) {

            viewFilteredCaseEventDetailsList.dtls.addRef(
              viewActiveCaseEventDetailsList.dtls.item(i));
          }

        } else {

          // If not a case decision event, add to list
          viewFilteredCaseEventDetailsList.dtls.addRef(
            viewActiveCaseEventDetailsList.dtls.item(i));
        }

      } // end for i

      // Assign details to the return object
      issueEventList.dtlsList.assign(viewFilteredCaseEventDetailsList);

    } // end if viewActiveCaseEventDetailsList not empty

    // Read context description and assign to return object
    issueEventList.description.description = getIssueDeliveryContextDescription(issueDeliveryKey).description;

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = issueDeliveryKey.caseID;

    // BEGIN, CR00058145, CSH
    // Read Menu Data
    // IssueDelivery object manipulation variable
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueEventList.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueEventList.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);
    }
    // END, CR00058145

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      issueEventList.isCPMInstalledInd = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      issueEventList.isAppealsInstalledInd = true;
    }

    return issueEventList;
  }

  // BEGIN, CR00220923, ZV
  // ___________________________________________________________________________
  /**
   * This method is used to view the closure details of a closed issue delivery.
   *
   * @param details The closure details.
   */
  @Override
  public IssueClosureDetails1 readClosureDetails1(CloseCaseDetails details)
    throws AppException, InformationalException {

    // IssueDelivery object
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
    final ClosureDtls closureDtls = new ClosureDtls();

    // Return struct
    final IssueClosureDetails1 issueClosureDetails = new IssueClosureDetails1();

    // Assign closure details
    closureDtls.caseID = details.caseID;
    closureDtls.comments = details.comments;
    closureDtls.reasonCode = details.reasonCode;

    // BEGIN, CR00031196, KH
    // Read the issue delivery closure details
    issueClosureDetails.dtls = issueDeliveryObj.readIssueDeliveryClosureDetails1(
      closureDtls);
    // END, CR00031196

    // Set key to find context description
    issueDeliveryKey.caseID = details.caseID;

    // Set context description
    issueClosureDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    return issueClosureDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to display the issue delivery case homepage.
   *
   * @param caseHeaderKey The case ID of the issue delivery case.
   *
   * @return The issue delivery case homepage details.
   */
  @Override
  public IssueDeliveryHomePageDetails1 readHomePageDetails1(
    CaseHeaderKey caseHeaderKey) throws AppException, InformationalException {

    // Return struct
    final IssueDeliveryHomePageDetails1 issueDeliveryHomePageDetails = new IssueDeliveryHomePageDetails1();

    // IssueDelivery manipulation variables
    final curam.core.sl.intf.IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    // Set key to view Issue Delivery Case details
    issueDeliveryKey.caseID = caseHeaderKey.caseID;

    // BEGIN, CR00031196, KH
    issueDeliveryHomePageDetails.dtls = issueDeliveryObj.readIssueHomePageDetails(
      issueDeliveryKey);
    // END, CR00031196

    // Set the key for the Issue Delivery Menu Data
    final IssueDeliveryMenuDataKey issueDeliveryMenuDataKey = new IssueDeliveryMenuDataKey();

    issueDeliveryMenuDataKey.caseID = caseHeaderKey.caseID;

    // BEGIN, CR00058145, CSH
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();
    // END, CR00066883

    // Set the key to read the related case id
    final RelatedCaseID relatedCaseID = issueDeliveryObj.readRelatedCaseKey(
      issueDeliveryKey);

    caseKey.caseID = relatedCaseID.relatedCaseID;
    // END, CR00054295

    // Check what type of case the issue was raised against
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case type of the related case is product delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      // Read menu data for I.C. product delivery
      issueDeliveryHomePageDetails.idMenuData = getIssueDeliveryMenuData(
        issueDeliveryMenuDataKey);

    } else {

      // Read menu data for integrated case
      issueDeliveryHomePageDetails.idMenuData = getIssueDeliveryMenuDataForIC(
        issueDeliveryMenuDataKey);

      // BEGIN, CR00066535, CSH
      // Get the adminIntegratedCaseID
      final CaseHeaderKey integratedCaseHeaderKey = new CaseHeaderKey();

      integratedCaseHeaderKey.caseID = relatedCaseID.relatedCaseID;

      issueDeliveryHomePageDetails.adminIntegratedCaseID = IssueDeliveryFactory.newInstance().getAdminIntegratedCaseIDForIssue(integratedCaseHeaderKey).adminIntegratedCaseID;
    }

    // Return the product delivery CaseID
    issueDeliveryHomePageDetails.relatedCaseID = relatedCaseID.relatedCaseID;
    // END, CR00066535
    // END, CR00058145

    // Check case status to set display indicators
    if (issueDeliveryHomePageDetails.dtls.caseDetails.caseStatus.equals(
      CASESTATUS.CLOSED)) {

      issueDeliveryHomePageDetails.indicators.caseClosedInd = true;

      // BEGIN CR00161590, PDN
      final ClosureDtls closureDtls = new ClosureDtls();

      closureDtls.caseID = issueDeliveryKey.caseID;

      issueDeliveryHomePageDetails.closureDtls.dtls = issueDeliveryObj.readIssueDeliveryClosureDetails1(
        closureDtls);
      // END, CR00161590

      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage = new LocalisableString(
        curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage.arg(
        issueDeliveryHomePageDetails.closureDtls.dtls.userFullName);

      // Add the closure date
      dateUserNameMessage.arg(
        issueDeliveryHomePageDetails.closureDtls.dtls.closureDate);
      // END, CR00166458

      issueDeliveryHomePageDetails.closureDtls.dtls.closureDateAndUserFullName = dateUserNameMessage.toClientFormattedText();
      // END, CR00163613

    }

    // Check resolution status to set display indicators
    if (issueDeliveryHomePageDetails.dtls.resolutionDetails.resolutionStatus.equals(
      RESOLUTIONSTATUSCODE.INEDIT)) {

      issueDeliveryHomePageDetails.indicators.inEditResolutionInd = true;

    } else if (issueDeliveryHomePageDetails.dtls.resolutionDetails.resolutionStatus.equals(
      RESOLUTIONSTATUSCODE.SUBMITTED)) {

      issueDeliveryHomePageDetails.indicators.submittedResolutionInd = true;

    } else if (issueDeliveryHomePageDetails.dtls.resolutionDetails.resolutionStatus.equals(
      RESOLUTIONSTATUSCODE.APPROVED)) {

      issueDeliveryHomePageDetails.indicators.approvedResolutionInd = true;

    } else { // There is no resolution

      issueDeliveryHomePageDetails.indicators.noResolutionInd = true;
    }

    // Set key to find context description
    issueDeliveryKey.caseID = caseHeaderKey.caseID;

    // Set context description
    issueDeliveryHomePageDetails.description = getIssueDeliveryContextDescription(
      issueDeliveryKey);

    // BEGIN, CR00022647, AK

    // Read Transaction Log Details
    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = caseHeaderKey.caseID;

    // BEGIN CR00108593, GBA
    issueDeliveryHomePageDetails.transactionDtls.transactionDetailsList.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108593
    // END, CR00022280

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = caseHeaderKey.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    return issueDeliveryHomePageDetails;
  }
  // END, CR00220923

  // BEGIN, 146339, MD
  /**
   * Retrieves the ReadByParticipantRoleTypeAndCaseDetails struct which contains the 
   * caseParticipantRoleID of the Primary Client or Member of the caseID.
   * @param caseID
   * @param concernRoleID
   * @return ReadByParticipantRoleTypeAndCaseDetails
   * @throws AppException
   * @throws InformationalException
   */
  private ReadByParticipantRoleTypeAndCaseDetails getCaseParticipantRoleID(final long caseID, final long concernRoleID) 
    throws AppException, InformationalException {

    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.caseID = caseID;
    readByParticipantRoleTypeAndCaseKey.participantRoleID = concernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;
    NotFoundIndicator notFoundIndicator = new NotFoundIndicator();
    
    // return the caseParticipantRoleID based on caseID and concernRoleID if Primary Client
    ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails =
      caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(notFoundIndicator, readByParticipantRoleTypeAndCaseKey);

    // if the Primary Client wasn't found check for existence of Member
    if (notFoundIndicator.isNotFound()) {
      readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.MEMBER;
      readByParticipantRoleTypeAndCaseDetails = caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(readByParticipantRoleTypeAndCaseKey);
    }
    
    return readByParticipantRoleTypeAndCaseDetails;
  }
  // END, 146339
}
