/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.struct.ReassignAllCasesDetails;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process for delayed reassigning of all cases assigned to one user to another
 * user.
 *
 */
public abstract class ReassignAllCasesToAnotherUser extends curam.core.facade.base.ReassignAllCasesToAnotherUser {

  // ___________________________________________________________________________
  /**
   * Delayed reassignment of cases for user.
   *
   * @param ticketID Ticket identification
   * @param inst_data_id Key to read wmInstanceData
   * @param flag Whether ticket should be closed
   */
  @Override
  public void delayedReassignAllCasesToAnotherUser(long ticketID,
    long inst_data_id, boolean flag) throws AppException,
      InformationalException {

    // wmInstanceData manipulation variables
    final curam.core.intf.WMInstanceData wmInstanceDataObj = curam.core.fact.WMInstanceDataFactory.newInstance();
    WMInstanceDataDtls wmInstanceDataDtls;
    final WMInstanceDataKey wmInstanceDataKey = new WMInstanceDataKey();

    // MaintainUser manipulation variables
    final curam.core.intf.MaintainUsers maintainUsersObj = curam.core.fact.MaintainUsersFactory.newInstance();
    final ReassignAllCasesDetails reassignAllCasesDetails = new ReassignAllCasesDetails();

    // clearCachedRecords object
    final curam.core.intf.ClearCachedRecords clearCachedRecordsObj = curam.core.fact.ClearCachedRecordsFactory.newInstance();

    // clear Cached Records
    clearCachedRecordsObj.clearAllCaches();

    // set key to read wmInstanceData
    wmInstanceDataKey.wm_instDataID = inst_data_id;

    // read wmInstanceData
    wmInstanceDataDtls = wmInstanceDataObj.read(wmInstanceDataKey);

    // reassign cases for user
    reassignAllCasesDetails.assign(wmInstanceDataDtls);

    maintainUsersObj.reassignAllUserCasesToAnotherUser(reassignAllCasesDetails);

  }

}
