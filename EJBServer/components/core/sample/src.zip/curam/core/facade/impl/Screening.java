/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.CreateScreeningCaseApprovalCheckDetails;
import curam.core.facade.struct.ModifyScreeningCaseApprovalCheckDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ScreeningAssessmentDecision;
import curam.core.facade.struct.ScreeningCaseApprovalCheckDetails;
import curam.core.facade.struct.ScreeningCaseApprovalCheckDetailsList;
import curam.core.facade.struct.ScreeningCaseApprovalCheckKey;
import curam.core.facade.struct.ScreeningCaseClosureDtls;
import curam.core.facade.struct.ScreeningCaseID;
import curam.core.facade.struct.ScreeningClientDtls;
import curam.core.facade.struct.ScreeningClientKey;
import curam.core.facade.struct.ViewAssessmentDecisionKey;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.ScreeningFactory;
import curam.core.sl.struct.CloseScreeningCaseDtls;
import curam.core.sl.struct.ScreeningClientDetailsDtls;
import curam.core.struct.MaintainAssessmentKey;
import curam.core.struct.ViewAssessmentDecisionResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This module contains implementation for viewing details of the selected
 * screening case client.
 */

public abstract class Screening extends curam.core.facade.base.Screening {

  // ___________________________________________________________________________
  /**
   * Method used to view details of the selected screening case client.
   *
   * @param key concernRoleID of the selected client
   *
   * @return details of the selected screening client
   */
  @Override
  public ScreeningClientDtls viewClientDetails(ScreeningClientKey key)
    throws AppException, InformationalException {

    // Create the return object
    final ScreeningClientDtls screeningClientDtls = new ScreeningClientDtls();

    // Screening_so manipulation variables
    final curam.core.sl.intf.Screening screening_soObj = curam.core.sl.fact.ScreeningFactory.newInstance();
    final curam.core.sl.struct.ScreeningClientKey screeningClientKey = new curam.core.sl.struct.ScreeningClientKey();
    ScreeningClientDetailsDtls screeningClientDetailsDtls;

    // Set up key to call viewScreeningClientDetails
    screeningClientKey.screenClientKey.concernRoleID = key.concernRoleID;

    // Read the details
    screeningClientDetailsDtls = screening_soObj.viewScreeningClientDetails(
      screeningClientKey);

    // Assign the details to the return object
    screeningClientDtls.screeningClientDetailsDtls.assign(
      screeningClientDetailsDtls);

    // Context object and key
    final curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Populate context description key
    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Read the context description
    screeningClientDtls.screeningClientDetailsDtls.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    return screeningClientDtls;
  }

  // ___________________________________________________________________________
  /**
   * Functionality to close a screening case
   *
   * @param dtls details of the screening case to be closed
   */
  @Override
  public void closeScreeningCase(ScreeningCaseClosureDtls dtls)
    throws AppException, InformationalException {

    // Screening_so manipulation variables
    final curam.core.sl.intf.Screening screening_soObj = curam.core.sl.fact.ScreeningFactory.newInstance();
    final CloseScreeningCaseDtls closeScreeningCaseDtls = new CloseScreeningCaseDtls();

    // Set the details to close the screening case
    closeScreeningCaseDtls.assign(dtls);
    closeScreeningCaseDtls.priority = curam.codetable.CASEPRIORITY.DEFAULTCODE;
    closeScreeningCaseDtls.sensitivityCode = curam.codetable.SENSITIVITY.DEFAULTCODE;
    closeScreeningCaseDtls.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    screening_soObj.closeScreeningCase(closeScreeningCaseDtls);
  }

  // ___________________________________________________________________________
  /**
   * To close a screening case using the caseID as an input parameter
   *
   * @param key screening case identifier.
   */
  @Override
  public void closeScreeningCaseByCaseID(ScreeningCaseID key)
    throws AppException, InformationalException {

    // Screening_so manipulation variables
    final curam.core.sl.intf.Screening screening_soObj = curam.core.sl.fact.ScreeningFactory.newInstance();
    final CloseScreeningCaseDtls closeScreeningCaseDtls = new CloseScreeningCaseDtls();

    // Set the details to close the case
    closeScreeningCaseDtls.caseID = key.caseID;
    closeScreeningCaseDtls.closureDate = curam.util.type.Date.getCurrentDate();

    // BEGIN, CR00049218, GM
    closeScreeningCaseDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218

    closeScreeningCaseDtls.priority = curam.codetable.CASEPRIORITY.DEFAULTCODE;
    closeScreeningCaseDtls.reasonCode = curam.codetable.CASECLOSEREASON.DEFAULTCODE;
    closeScreeningCaseDtls.sensitivityCode = curam.codetable.SENSITIVITY.DEFAULTCODE;
    closeScreeningCaseDtls.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    screening_soObj.closeScreeningCase(closeScreeningCaseDtls);

  }

  // ___________________________________________________________________________
  /**
   * To view the result of a screening assessment.
   *
   * @param key assessment decision identifier.
   *
   * @return screening assessment decision details.
   */
  @Override
  public ScreeningAssessmentDecision viewAssessmentDecision(
    ViewAssessmentDecisionKey key) throws AppException,
      InformationalException {

    // Return struct
    final ScreeningAssessmentDecision screeningAssessmentDecision = new ScreeningAssessmentDecision();

    // MaintainAssessments manipulation variables
    final curam.core.intf.MaintainAssessments maintainAssessmentsObj = curam.core.fact.MaintainAssessmentsFactory.newInstance();
    final MaintainAssessmentKey maintainAssessmentKey = new MaintainAssessmentKey();
    ViewAssessmentDecisionResult viewAssessmentDecisionResult;

    // Set key to view assessment decision
    maintainAssessmentKey.assessmentID = key.assessmentID;

    viewAssessmentDecisionResult = maintainAssessmentsObj.viewAssessmentDecision(
      maintainAssessmentKey);

    // Map details to the return struct
    screeningAssessmentDecision.assesDecision.assign(
      viewAssessmentDecisionResult);

    return screeningAssessmentDecision;

  }

  // BEGIN, CR00351516, HK
  /**
   * Allows an administrator to cancel an Screening Case Approval Check.
   *
   * @param screeningCaseApprovalCheckKey
   * unique id of the screening case resolution Approval Check to be
   * canceled.
   */
  @Override
  public void deleteScreeningCaseApprovalCheck(
    ScreeningCaseApprovalCheckKey screeningCaseApprovalCheckKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.Screening screeningObj = ScreeningFactory.newInstance();

    screeningObj.deleteScreeningCaseApprovalCheck(
      screeningCaseApprovalCheckKey.dtls);
  }

  /**
   * Lists all existing approval checks.
   *
   * @param screeningCaseApprovalCheckKey
   * unique id of the user that the screening case resolution approval
   * checks are being listed for.
   *
   * @return screeningCaseApprovalCheckDetailsList
   * list of resolution approval checks.
   */
  @Override
  public ScreeningCaseApprovalCheckDetailsList listScreeningCaseApprovalCheckForUser(
    ScreeningCaseApprovalCheckKey screeningCaseApprovalCheckKey)
    throws AppException, InformationalException {

    final ScreeningCaseApprovalCheckDetailsList screeningCaseApprovalCheckDetailsList = new ScreeningCaseApprovalCheckDetailsList();
    final curam.core.sl.intf.Screening screeningObj = ScreeningFactory.newInstance();

    screeningCaseApprovalCheckDetailsList.dtls = screeningObj.listScreeningCaseApprovalCheckForUser(
      screeningCaseApprovalCheckKey.dtls);
    return screeningCaseApprovalCheckDetailsList;
  }

  /**
   * Allows an administrator to modify an Screening Case Approval Check.
   *
   * @param modifyScreeningCaseApprovalCheckDetails
   * screening Case Approval Check details.
   *
   * @return screeningCaseApprovalCheckKey
   */
  @Override
  public ScreeningCaseApprovalCheckKey modifyScreeningCaseApprovalCheckForUser(
    ModifyScreeningCaseApprovalCheckDetails modifyScreeningCaseApprovalCheckDetails)
    throws AppException, InformationalException {

    final ScreeningCaseApprovalCheckKey screeningCaseApprovalCheckKey = new ScreeningCaseApprovalCheckKey();
    final curam.core.sl.intf.Screening screeningObj = ScreeningFactory.newInstance();

    screeningCaseApprovalCheckKey.dtls = screeningObj.modifyScreeningCaseApprovalCheckForUser(
      modifyScreeningCaseApprovalCheckDetails.dtls);
    return screeningCaseApprovalCheckKey;
  }

  /**
   * Allows an administrator to view a approval.
   *
   * @param screeningCaseApprovalCheckKey
   * unique id of the Screening Case Approval Check to be read.
   * @return approval check details.
   */
  @Override
  public ScreeningCaseApprovalCheckDetails viewScreeningCaseApprovalCheck(
    ScreeningCaseApprovalCheckKey screeningCaseApprovalCheckKey)
    throws AppException, InformationalException {

    final ScreeningCaseApprovalCheckDetails screeningCaseApprovalCheckDetails = new ScreeningCaseApprovalCheckDetails();
    final curam.core.sl.intf.Screening screeningObj = ScreeningFactory.newInstance();

    screeningCaseApprovalCheckDetails.dtls = screeningObj.viewScreeningCaseApprovalCheck(
      screeningCaseApprovalCheckKey.dtls);
    return screeningCaseApprovalCheckDetails;
  }

  /**
   * Allows an administrator to configure an approval check. It allows a
   * percentage of resolutions on screening case which are submitted for
   * approval to be reviewed.
   *
   * @param createScreeningCaseApprovalCheckDetails
   * screening Case Approval Check details.
   *
   * @return screeningCaseApprovalCheckKey
   */
  @Override
  public ScreeningCaseApprovalCheckKey createScreeningCaseApprovalCheckForUser(
    CreateScreeningCaseApprovalCheckDetails createScreeningCaseApprovalCheckDetails)
    throws AppException, InformationalException {

    final ScreeningCaseApprovalCheckKey screeningCaseApprovalCheckKey = new ScreeningCaseApprovalCheckKey();
    final curam.core.sl.intf.Screening screeningObj = ScreeningFactory.newInstance();

    screeningCaseApprovalCheckKey.dtls = screeningObj.createScreeningCaseApprovalCheckForUser(
      createScreeningCaseApprovalCheckDetails.dtls);
    return screeningCaseApprovalCheckKey;
  }
  // END, CR00351516
}
