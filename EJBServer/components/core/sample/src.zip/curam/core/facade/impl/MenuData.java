/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;


import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.CaseParticipantRoleKey;
import curam.core.facade.struct.ICMemberMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.IntegratedCaseMenuDataDetails;
import curam.core.facade.struct.IntegratedCaseMenuDataKey;
import curam.core.facade.struct.InvestigationDeliveryMenuDataDetails;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.HomePageIdentifier;
import curam.core.sl.entity.struct.InvestigationDeliveryDtls;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.message.BPOINTEGRATEDCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.CodeTableItemIdentifier;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * This class manages the creation of the menu data to be returned on an
 * Integrated Case. The functions here contain the default behavior. However,
 * these functions are basically hooks (called by the IntegratedCase facade
 * class) that can be overridden to provide custom behavior if necessary.
 * The overriding of these functions is managed by the Product Hook
 * registrar mechanism.
 */
public abstract class MenuData extends curam.core.facade.base.MenuData {

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kParamCaseParticipantRoleID = XmlMetaDataConst.kParamCaseParticipantRoleID;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;

  protected static final String kTypeInvestigation = XmlMetaDataConst.kTypeInvestigation;

  protected static final String kQuote = CuramCalendarHeaderConst.kQuote;

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for the Integrated Case.
   *
   * @param key Integrated Case identifier.
   *
   * @return Menu Data for the Integrated Case.
   */
  @Override
  public IntegratedCaseMenuDataDetails getIntegratedCaseMenuData(
    IntegratedCaseMenuDataKey key) throws AppException,
      InformationalException {

    // Create return object
    final IntegratedCaseMenuDataDetails integratedCaseMenuDataDetails = new IntegratedCaseMenuDataDetails();

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create child node
    final Element linkElement = new Element(kItem);

    // Need to retrieve the IC Home Page Name And Type
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    ICHomePageNameAndType icHomePageNameAndType;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set key to read IC Home Page Name and Type
    caseKey.caseID = key.caseID;

    // Read home page name and type
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    final LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icHomePageNameAndType.integratedCaseType));

    description.arg(icHomePageNameAndType.caseReference);

    // Set up node property values
    linkElement.setAttribute(kPageID, icHomePageNameAndType.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    final Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    integratedCaseMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return integratedCaseMenuDataDetails;
  }

  // ___________________________________________________________________________
  /**
   * Generates the menu data for a product delivery on an Integrated Case.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   */
  @Override
  public ICProductDeliveryMenuDataDetails getICProductDeliveryMenuData(
    ICProductDeliveryMenuDataKey key) throws AppException,
      InformationalException {

    // Create return object
    final ICProductDeliveryMenuDataDetails icProductDeliveryMenuDataDetails = new ICProductDeliveryMenuDataDetails();

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    final CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
      concernRoleKey);

    // Set key to read productDelivery
    caseKey.caseID = key.caseID;

    // Read productDelivery to retrieve the case home page name and
    // product type
    final CaseHomePageNameAndType caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey = caseHeaderObj.readIntegratedCaseReferenceByCaseID(
      caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // BEGIN, CR00305478, MV
    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    // BEGIN, CR00312208, AKr
    readByParticipantRoleTypeAndCaseKey.caseID = key.caseID;
    // END, CR00312208
    readByParticipantRoleTypeAndCaseKey.participantRoleID = productDeliveryDtls.recipConcernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
      readByParticipantRoleTypeAndCaseKey);

    // END, CR00278729

    caseParticipantRoleIDKey.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478

    // Get participant home page
    final ParticipantHomePageName participantHomePageName = IntegratedCaseFactory.newInstance().resolveParticipantHome(
      caseParticipantRoleIDKey);

    // create link to the participant home page
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    // BEGIN, CR00305478, MV
    paramElement.setAttribute(kValue,
      Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseID);
    // BEGIN, CR00312208, AKr
    paramElement.setAttribute(kValue, String.valueOf(key.caseID));
    // END, CR00312208

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(kItem);
    linkElement.setAttribute(kPageID, caseHomePageNameAndType.caseHomePageName);

    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode));

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    icProductDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return icProductDeliveryMenuDataDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for an Integrated Case member.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu Data for an Integrated Case member
   */
  @Override
  public ICMemberMenuDataDetails getICMemberMenuData(
    CaseParticipantRoleKey key, CaseHeaderKey caseKey) throws AppException,
      InformationalException {

    // Return object
    final ICMemberMenuDataDetails icMemberMenuDataDetails = new ICMemberMenuDataDetails();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // MaintainCase manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final CaseKey caseReadKey = new CaseKey();

    CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails;
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID
    // passed in
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDCaseRefAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDcaseRefandParticipantID(
      caseParticipantRoleKey);

    // Read concernRoleName
    concernRoleKey.concernRoleID = caseIDCaseRefAndParticipantRoleIDDetails.participantRoleID;

    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    // Read IC page names, type and concern details
    caseReadKey.caseID = caseKey.caseID;

    final ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseReadKey);

    // Convert IC Case Type Code to its description
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = caseKey.caseID;

    description.arg(
      caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(caseKey.caseID));

    linkElement.addContent(paramElement);
    linkElement = new Element(kItem);

    // Create CaseParticipantRoleIDKey
    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    caseParticipantRoleIDKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    // create
    ParticipantHomePageName participantHomePageName;

    // get correct IC homepage for current participant.
    participantHomePageName = IntegratedCaseFactory.newInstance().resolveParticipantHome(
      caseParticipantRoleIDKey);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, participantHomePageName.participantIconName);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue,
      String.valueOf(key.dtls.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(caseKey.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    icMemberMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return icMemberMenuDataDetails;
  }

  // BEGIN, CR00113516, SD
  // ___________________________________________________________________________
  /**
   * Generates the menu data for an investigation delivery on an Integrated
   * Case.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu data for an investigation delivery.
   */
  @Override
  public InvestigationDeliveryMenuDataDetails getICInvestigationDeliveryMenuData(CaseHeaderKey key)
    throws AppException, InformationalException {

    // Create return object
    final InvestigationDeliveryMenuDataDetails investigationDeliveryMenuDataDetails = new InvestigationDeliveryMenuDataDetails();

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    final CaseKey caseKey = new CaseKey();

    // InvestigationDelivery manipulation variables
    final curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryObj = curam.core.sl.entity.fact.InvestigationDeliveryFactory.newInstance();
    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    InvestigationDeliveryDtls investigationDeliveryDtls;

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read Investigation Delivery
    investigationDeliveryKey.caseID = key.caseID;

    // Read Investigation Delivery
    investigationDeliveryDtls = investigationDeliveryObj.read(
      investigationDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = caseHeaderObj.read(key).concernRoleID;

    // Read concernRoleName
    final ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
      concernRoleKey);

    // Set key to read productDelivery
    caseKey.caseID = key.caseID;

    // Read Investigation Delivery to retrieve the case home page name
    final HomePageIdentifier homePageIdentifier = investigationDeliveryObj.readHomePageIdentifier(
      investigationDeliveryKey);

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey = caseHeaderObj.readIntegratedCaseReferenceByCaseID(
      caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // BEGIN, CR00305478, MV
    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.caseID = integratedCaseReferenceKey.integratedCaseID;
    readByParticipantRoleTypeAndCaseKey.participantRoleID = concernRoleKey.concernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
      readByParticipantRoleTypeAndCaseKey);

    // END, CR00278729

    caseParticipantRoleIDKey.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478

    // Get participant home page
    final ParticipantHomePageName participantHomePageName = IntegratedCaseFactory.newInstance().resolveParticipantHome(
      caseParticipantRoleIDKey);

    // create link to the participant home page
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);

    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    // BEGIN, CR00305478, MV
    paramElement.setAttribute(kValue,
      Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478
    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(kItem);
    linkElement.setAttribute(kPageID, homePageIdentifier.homePageIdentifier);

    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(
        curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
        investigationDeliveryDtls.investigationType));

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeInvestigation);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    investigationDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return investigationDeliveryMenuDataDetails;
  }

  // END, CR00113516

  // BEGIN, CR00345678, ZV
  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for the Participant Data Case.
   *
   * @param key Participant Data Case identifier.
   *
   * @return Menu Data for the Participant Data Case.
   */
  @Override
  public curam.core.facade.infrastructure.struct.MenuData getParticipantDataCaseMenuData(CaseHeaderKey key) throws AppException,
      InformationalException {

    final curam.core.facade.infrastructure.struct.MenuData menuData = new curam.core.facade.infrastructure.struct.MenuData();

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create child node
    final Element linkElement = new Element(kItem);

    // TODO
    // Need to retrieve the Participant Data Case Home Page Name
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    ICHomePageNameAndType icHomePageNameAndType;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Set key to read IC Home Page Name and Type
    caseKey.caseID = key.caseID;

    // Read home page name and type
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    final LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(CASETYPECODE.TABLENAME,
      CASETYPECODE.PARTICIPANTDATACASE));

    description.arg(icHomePageNameAndType.caseReference);

    // Set up node property values
    linkElement.setAttribute(kPageID, icHomePageNameAndType.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    final Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    menuData.menuData = outputter.outputString(navigationMenuElement);

    return menuData;
  }
  // END, CR00345678

}
