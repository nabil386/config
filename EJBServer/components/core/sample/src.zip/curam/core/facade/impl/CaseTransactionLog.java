/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.core.facade.struct.CaseIDKey;
import curam.core.facade.struct.ReadTransactionLogDetailsList;
import curam.core.fact.CaseTransactionLogFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.struct.CaseTransactionLogByCaseIDKey;
import curam.core.struct.CaseTransactionLogDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * This process class provides the functionality for the Case Transaction Log
 * presentation layer.
 */
// BEGIN, CR00426899, SKP
@AccessLevel(AccessLevelType.EXTERNAL)
// END, CR00426899
public abstract class CaseTransactionLog extends curam.core.facade.base.CaseTransactionLog {

  // BEGIN CR00108134, GBA
  // Add injection for using the new CaseTransactionLog API
  public CaseTransactionLog() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108134

  // ___________________________________________________________________________
  /**
   * Fetches the list of all transactions for a given case.
   *
   * @param key - CaseIDKey The case id.
   *
   * @return ReadTransactionLogDetailsList The list of transaction logs.
   */
  @Override
  // BEGIN, CR00426899, SKP
  @AccessLevel(AccessLevelType.EXTERNAL)
  // END, CR00426899
  public ReadTransactionLogDetailsList listAllChanges(CaseIDKey key)
    throws AppException, InformationalException {

    // Case Transaction Log business process object
    final ReadTransactionLogDetailsList readTransactionLogDetailsList = new ReadTransactionLogDetailsList();

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.dtls.dtls.caseID;
    // BEGIN CR00108134, GBA
    readTransactionLogDetailsList.transactionDetailsList = caseTransactionLogProvider.get().readAllTransactions(
      caseIDKey);
    // END CR00108134

    return readTransactionLogDetailsList;
  }

  // BEGIN, CR00426899, SKP
  /**
   * Retrieve transactionID, caseID, transactionType, transactionDateTime and
   * userName for the given case filtered by caseID.
   *
   * @param caseTransactionLogByCaseIDKey
   * Contains CaseID.
   * @return List of Case Transaction Log Details
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Override
  public CaseTransactionLogDetailsList searchByCaseID(
    final CaseTransactionLogByCaseIDKey caseTransactionLogByCaseIDKey)
    throws AppException, InformationalException {

    final curam.core.intf.CaseTransactionLog caseTransactionLog = CaseTransactionLogFactory.newInstance();

    return caseTransactionLog.searchByCaseID(caseTransactionLogByCaseIDKey);
  }
  // END, CR00426899
}
