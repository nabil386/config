/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.PRODUCTTYPE;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.SERVICEPLANTYPENAME;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.struct.AssessmentCaseID;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This process class provides the functionality to retrieve context
 * descriptions for a case.
 *
 */
public abstract class CaseContext extends curam.core.facade.base.CaseContext {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.
   * getProgramLocale())}.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note CR00219408.
   */
  @Deprecated
  // BEGIN, CR00023618, SK
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00222190

  // BEGIN, CR00098942, SAI
  protected static final String kSpace = CuramConst.gkSpace;

  // END, CR00098942
  // END, CR00023618

  // ___________________________________________________________________________
  /**
   * Method to read Case context information.
   * Returns context string of the format:
   * "Case productType caseID concernRoleName"
   *
   * @param caseContextDescriptionKey Contains caseID
   *
   * @return Context description for case
   */
  @Override
  public CaseContextDescription readContextDescription(
    CaseContextDescriptionKey caseContextDescriptionKey) throws AppException,
      InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;
    // BEGIN, CR00049218, GM
    String productTypeDesc = CuramConst.gkEmpty;
    // END, CR00049218

    final int kBufSize = 256;

    // Create and initialize StringBuffer
    final StringBuffer contextDescription = new StringBuffer(kBufSize);

    // Set key to read CaseHeader
    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    // Read CaseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read ConcernRole
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read ConcernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
        || caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY)) {

      // ProductDelivery manipulation variables
      final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;

      // Set key to read productDelivery
      productDeliveryKey.caseID = caseContextDescriptionKey.caseID;

      // Read ProductDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // BEGIN, CR00163098, JC
      productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        productDeliveryDtls.productType, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SCREENINGCASE)) {

      // ProductDelivery manipulation variables
      final curam.core.sl.entity.intf.Screening screeningObj = curam.core.sl.entity.fact.ScreeningFactory.newInstance();
      final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
      ScreeningName screeningName;

      // Set key to read Screening
      caseKeyStruct.caseID = caseContextDescriptionKey.caseID;

      // Read Screening
      screeningName = screeningObj.readName(caseKeyStruct);

      // BEGIN, CR00163098, JC
      productTypeDesc = CodeTable.getOneItem(SERVICEPLANTYPE.TABLENAME,
        screeningName.name, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

    } // BEGIN, HARP 37088, CC
    else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.ASSESSMENTDELIVERY)) {

      // read assessment delivery
      final curam.core.intf.AssessmentConfiguration assessmentConfigurationObj = curam.core.fact.AssessmentConfigurationFactory.newInstance();

      final AssessmentCaseID caseKeyStruct = new AssessmentCaseID();

      caseKeyStruct.caseID = caseContextDescriptionKey.caseID;

      // assessment configuration
      productTypeDesc = assessmentConfigurationObj.readAssessmentDescription(caseKeyStruct).description;
      // BEGIN, CR00098942, SAI
      // BEGIN, CR00222190, ELG
      contextDescription.append(productTypeDesc).append(kSpace).append(caseHeaderDtls.caseReference).append(kSpace).append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())).append(concernRoleDtls.concernRoleName).append(kSpace).append(
        concernRoleDtls.primaryAlternateID);
      // END, CR00222190
      // END, CR00098942

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery manipulation variables
      final curam.serviceplans.facade.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

      final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

      servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseContextDescriptionKey.caseID;

      // read service plan product type
      final curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = servicePlanDeliveryObj.readParticipantTypeAndReferenceDetails(
        servicePlanDeliveryKey.servicePlanDeliveryKey);

      // BEGIN, CR00163098, JC
      productTypeDesc = CodeTable.getOneItem(SERVICEPLANTYPENAME.TABLENAME,
        spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
      // END, HARP 48175
    }

    // return structure
    final CaseContextDescription caseContextDescription = new CaseContextDescription();

    // If case type is integrated case there will be no product type in the
    // context description.
    if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
        || caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY)
          || caseHeaderDtls.caseTypeCode.equals(
            curam.codetable.CASETYPECODE.SCREENINGCASE)
            || caseHeaderDtls.caseTypeCode.equals(
              curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // BEGIN, CR00098942, SAI
      // BEGIN, CR00222190, ELG
      contextDescription.append(productTypeDesc).append(kSpace).append(caseHeaderDtls.caseReference).append(kSpace).append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())).append(concernRoleDtls.concernRoleName).append(kSpace).append(
        concernRoleDtls.primaryAlternateID);
      // END, CR00222190
      // END, CR00098942

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {

      // BEGIN, CR00098942, SAI
      // BEGIN, CR00222190, ELG
      contextDescription.append(caseHeaderDtls.caseReference).append(kSpace).append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())).append(concernRoleDtls.concernRoleName).append(kSpace).append(
        concernRoleDtls.primaryAlternateID);
      // END, CR00222190
      // END, CR00098942
    }

    caseContextDescription.description = contextDescription.toString();

    return caseContextDescription;
  }

}
