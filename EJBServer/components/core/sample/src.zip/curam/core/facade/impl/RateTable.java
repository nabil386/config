/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2003, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003, 2006, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.RATETABLEHISTORYFILTER;
import curam.codetable.RATETABLETYPE;
import curam.core.facade.struct.CancelRateTableKey;
import curam.core.facade.struct.CloneRateTableKey;
import curam.core.facade.struct.CreateRateCellDetails;
import curam.core.facade.struct.CreateRateColumnDetails;
import curam.core.facade.struct.CreateRateRowDetails;
import curam.core.facade.struct.CreateRateTableHeaderDetails;
import curam.core.facade.struct.CreateSubColumnDetails;
import curam.core.facade.struct.CreateSubRowDetails;
import curam.core.facade.struct.ListRateTableHistoryKey;
import curam.core.facade.struct.ModifyRateCellValueDetails;
import curam.core.facade.struct.ModifyRateColumnDetails;
import curam.core.facade.struct.ModifyRateHeaderDetails;
import curam.core.facade.struct.ModifyRateRowDetails;
import curam.core.facade.struct.ModifySubColumnDetails;
import curam.core.facade.struct.RateHeaderDetailsList;
import curam.core.facade.struct.RateTableContextDescription;
import curam.core.facade.struct.RateTableStructList;
import curam.core.facade.struct.ReadCellDetails;
import curam.core.facade.struct.ReadColumnDetails;
import curam.core.facade.struct.ReadRateCellKey;
import curam.core.facade.struct.ReadRateCellValue;
import curam.core.facade.struct.ReadRateColumnKey;
import curam.core.facade.struct.ReadRateHeaderDetails;
import curam.core.facade.struct.ReadRateRowKey;
import curam.core.facade.struct.ReadRateTableDescriptionKey;
import curam.core.facade.struct.ReadRateTableDetails;
import curam.core.facade.struct.ReadRateTableKey;
import curam.core.facade.struct.ReadRowDetails;
import curam.core.facade.struct.ReadValueByColumnAndRowIndexKey;
import curam.core.facade.struct.RemoveRateCellKey;
import curam.core.facade.struct.RemoveRateColumnKey;
import curam.core.facade.struct.RemoveRateRowKey;
import curam.core.facade.struct.RemoveSubColumnKey;
import curam.core.facade.struct.RemoveSubRowKey;
import curam.core.sl.fact.RateTableFactory;
import curam.message.BPORATETABLE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.CodeTableItemIdentifier;


/**
 * This process class provides the functionality for the Rate Table
 * presentation layer.
 *
 */
public abstract class RateTable extends curam.core.facade.base.RateTable {

  /**
   * Cancels a rate table.
   *
   * @param cancelRateTableKey Rate Table identifier.
   */
  @Override
  public void cancelRateTable(CancelRateTableKey cancelRateTableKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    rateTableObj.cancelRateTable(cancelRateTableKey.key);
  }

  /**
   * Creates a rate cell.
   *
   * @param createRateCellDetails Rate Cell details.
   */
  @Override
  public void createRateCell(CreateRateCellDetails createRateCellDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    final curam.core.sl.entity.struct.ModifyRateCellValueDetails modifyRateCellValueDetails = new curam.core.sl.entity.struct.ModifyRateCellValueDetails();

    modifyRateCellValueDetails.key.rateCellID = createRateCellDetails.createRateCellDetails.rateCellID;

    modifyRateCellValueDetails.minMaxAndValueStringDetails.assign(
      createRateCellDetails.createRateCellDetails);
    rateTableObj.modifyRateCell(modifyRateCellValueDetails);
  }

  /**
   * Creates rate column record.
   *
   * @param createRateColumnDetails rate column details
   */
  @Override
  public void createRateColumn(CreateRateColumnDetails createRateColumnDetails)
    throws AppException, InformationalException {

    // variables, used to create rate column
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // create rate column
    rateTableObj.createRateColumn(
      createRateColumnDetails.createRateColumnDetails);
  }

  /**
   * Creates rate row record.
   *
   * @param createRateRowDetails rate row details
   */
  @Override
  public void createRateRow(CreateRateRowDetails createRateRowDetails)
    throws AppException, InformationalException {

    // variables, used to create rate row
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // create rate row
    rateTableObj.createRateRow(createRateRowDetails.createRateRowDetails);
  }

  /**
   * Creates a rate table header record.
   *
   * @param createRateTableHeaderDetails Rate Header details.
   */
  @Override
  public void createRateTableHeader(
    CreateRateTableHeaderDetails createRateTableHeaderDetails)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    rateTableObj.createRateTableHeader(
      createRateTableHeaderDetails.createRateTableHeaderDetails);
  }

  /**
   * Creates rate sub column record.
   *
   * @param createSubColumnDetails rate sub column details
   */
  @Override
  public void createSubColumn(CreateSubColumnDetails createSubColumnDetails)
    throws AppException, InformationalException {

    // variables, used to create rate sub column
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // create rate sub column
    rateTableObj.createSubColumn(createSubColumnDetails.createSubColumnDetails);
  }

  /**
   * Creates rate sub row record.
   *
   * @param createSubRowDetails rate sub row details
   */
  @Override
  public void createSubRow(CreateSubRowDetails createSubRowDetails)
    throws AppException, InformationalException {

    // variables, used to create rate sub row
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // create rate sub row
    rateTableObj.createSubRow(createSubRowDetails.createSubRowDetails);
  }

  /**
   * Lists the Active history records for a Rate Table.
   *
   * @param listRateTableHistoryKey Rate Table to list history for.
   *
   * @return History list for a Rate Table
   */
  @Override
  public RateHeaderDetailsList listActiveRateTableHistory(
    ListRateTableHistoryKey listRateTableHistoryKey) throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Create Return Object
    final RateHeaderDetailsList rateHeaderDetailsList = new RateHeaderDetailsList();

    // Set rateTableHistoryFilter to false
    listRateTableHistoryKey.listRateTableHistoryKey.rateTableHistoryFilter = RATETABLEHISTORYFILTER.ACTIVE;

    // Get rate table history list
    rateHeaderDetailsList.rateHeaderDetailsList = rateTableObj.listRateTableHistory(
      listRateTableHistoryKey.listRateTableHistoryKey);

    // Context Description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    if (rateHeaderDetailsList.rateHeaderDetailsList.rateHeaderData.isEmpty()) {

      readRateTableDescriptionKey.rateTableType = listRateTableHistoryKey.listRateTableHistoryKey.rateTableStatusDateKey.rateTableType;

    } else {

      // first position in list
      final int i = 0;

      // Get the rate header id of first item in list, the context description
      // of this item will be the same as the other items in the list
      readRateTableDescriptionKey.rateHeaderID = rateHeaderDetailsList.rateHeaderDetailsList.rateHeaderData.item(i).rateHeaderID;
    }

    // Read Context description
    rateHeaderDetailsList.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    // Return Details
    return rateHeaderDetailsList;
  }

  /**
   * Lists all the Rate Tables.
   *
   * @return List of Rate Tables
   */
  @Override
  public RateTableStructList listRateTable() throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Create return object
    final RateTableStructList rateTableStructList = new RateTableStructList();

    // Get the list of rate tables
    rateTableStructList.rateTableStructList = rateTableObj.listRateTable();

    // Return details
    return rateTableStructList;
  }

  /**
   * Lists the history for a Rate Table.
   *
   * @param listRateTableHistoryKey Rate Table to list history for.
   *
   * @return History list for a Rate Table
   */
  @Override
  public RateHeaderDetailsList listRateTableHistory(
    ListRateTableHistoryKey listRateTableHistoryKey) throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Create return object
    final RateHeaderDetailsList rateHeaderDetailsList = new RateHeaderDetailsList();

    // Set rateTableHistoryFilter to false
    listRateTableHistoryKey.listRateTableHistoryKey.rateTableHistoryFilter = RATETABLEHISTORYFILTER.ALL;

    // Get Rate Table History list
    rateHeaderDetailsList.rateHeaderDetailsList = rateTableObj.listRateTableHistory(
      listRateTableHistoryKey.listRateTableHistoryKey);

    // Context Description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    if (rateHeaderDetailsList.rateHeaderDetailsList.rateHeaderData.isEmpty()) {

      readRateTableDescriptionKey.rateTableType = listRateTableHistoryKey.listRateTableHistoryKey.rateTableStatusDateKey.rateTableType;
      // END, 25303

    } else {

      // first position in list
      final int i = 0;

      // Get the rate header id of first item in list, the context description
      // of this item will be the same as the other items in the list
      readRateTableDescriptionKey.rateHeaderID = rateHeaderDetailsList.rateHeaderDetailsList.rateHeaderData.item(i).rateHeaderID;
    }

    // Read Context description
    rateHeaderDetailsList.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    // Return Details
    return rateHeaderDetailsList;
  }

  /**
   * Lists the history records for a Rate Table by date.
   *
   * @param listRateTableHistoryKey Rate Table to list history for.
   *
   * @return History list for a Rate Table
   */
  @Override
  public RateHeaderDetailsList listRateTableHistoryByDate(
    ListRateTableHistoryKey listRateTableHistoryKey) throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Create return object
    final RateHeaderDetailsList rateHeaderDetailsList = new RateHeaderDetailsList();

    // Set rateTableHistoryFilter to false
    listRateTableHistoryKey.listRateTableHistoryKey.rateTableHistoryFilter = RATETABLEHISTORYFILTER.DATE;

    // Get Rate Table History list
    rateHeaderDetailsList.rateHeaderDetailsList = rateTableObj.listRateTableHistory(
      listRateTableHistoryKey.listRateTableHistoryKey);

    // Context Description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    if (rateHeaderDetailsList.rateHeaderDetailsList.rateHeaderData.isEmpty()) {

      readRateTableDescriptionKey.rateTableType = listRateTableHistoryKey.listRateTableHistoryKey.rateTableStatusDateKey.rateTableType;
      // END, 25303

    } else {

      // first position in list
      final int i = 0;

      // Get the rate header id of first item in list, the context description
      // of this item will be the same as the other items in the list
      readRateTableDescriptionKey.rateHeaderID = rateHeaderDetailsList.rateHeaderDetailsList.rateHeaderData.item(i).rateHeaderID;
    }

    // Read Context description
    rateHeaderDetailsList.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    // Return Details
    return rateHeaderDetailsList;
  }

  /**
   * Modifies a rate cell.
   *
   * @param details Rate Cell identifier and details
   */
  @Override
  public void modifyRateCell(ModifyRateCellValueDetails details)
    throws AppException, InformationalException {

    // BD If we are about to modify a cell in an Active table, then first
    // clone the table to an 'In-edit' version, and write these changes to
    // the in-edit rate table.

    // RateTable maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Modify Rate Cell
    rateTableObj.modifyRateCell(details.details);
  }

  /**
   * Modifies a rate column.
   *
   * @param modifyRateColumnDetails Rate Column identifier and details
   */
  @Override
  public void modifyRateColumn(ModifyRateColumnDetails modifyRateColumnDetails)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Modify Rate Column
    rateTableObj.modifyRateColumn(
      modifyRateColumnDetails.modifyRateColumnDetails);
  }

  /**
   * Modifies a rate row.
   *
   * @param modifyRateRowDetails Rate Row identifier and details
   */
  @Override
  public void modifyRateRow(ModifyRateRowDetails modifyRateRowDetails)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Modify Rate Column
    rateTableObj.modifyRateRow(modifyRateRowDetails.modifyRateRowDetails);
  }

  /**
   * Modifies a sub column.
   *
   * @param modifySubColumnDetails Column identifier and details
   */
  @Override
  public void modifySubColumn(ModifySubColumnDetails modifySubColumnDetails)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Modify Rate Column
    rateTableObj.modifySubColumn(modifySubColumnDetails.modifySubColumnDetails);
  }

  /**
   * Reads entire rate table.
   *
   * @param readRateTableKey rate table key
   *
   * @return rate table details
   */
  @Override
  public ReadRateTableDetails readRateTable(ReadRateTableKey readRateTableKey) throws AppException,
      InformationalException {

    // BD
    // If this is the Active version, and there is an in-edit version of this
    // rate table, then fetch back the in-edit version instead.

    // create return object
    final ReadRateTableDetails readRateTableDetails = new ReadRateTableDetails();

    // variables, used to read rate table
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Context description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    // read rate table
    readRateTableDetails.readRateTableDetails = rateTableObj.readRateTable(
      readRateTableKey.readRateTableKey);

    readRateTableDescriptionKey.rateHeaderID = readRateTableKey.readRateTableKey.rateHeaderID;

    // Read Context description
    readRateTableDetails.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    // return rate table details
    return readRateTableDetails;
  }

  /**
   * Removes a rate column.
   *
   * @param removeRateColumnKey Rate Column identifier
   */
  @Override
  public void removeRateColumn(RemoveRateColumnKey removeRateColumnKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Remove Rate Column
    rateTableObj.removeRateColumn(removeRateColumnKey.removeRateColumnKey);
  }

  /**
   * Removes a rate row.
   *
   * @param removeRateRowKey Rate Row identifier
   */
  @Override
  public void removeRateRow(RemoveRateRowKey removeRateRowKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Remove Rate Column
    rateTableObj.removeRateRow(removeRateRowKey.removeRateRowKey);
  }

  /**
   * Removes a sub column.
   *
   * @param removeSubColumnKey Sub Column identifier
   */
  @Override
  public void removeSubColumn(RemoveSubColumnKey removeSubColumnKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Remove Rate Column
    rateTableObj.removeSubColumn(removeSubColumnKey.removeSubColumnKey);
  }

  /**
   * Removes a sub row.
   *
   * @param removeSubRowKey Sub Row identifier
   */
  @Override
  public void removeSubRow(RemoveSubRowKey removeSubRowKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Remove Rate Column
    rateTableObj.removeSubRow(removeSubRowKey.removeSubRowKey);
  }

  /**
   * Clones a rate table.
   *
   * @param cloneRateTableKey Rate Table identifier
   */
  @Override
  public void cloneRateTable(CloneRateTableKey cloneRateTableKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Clone Rate Table
    rateTableObj.cloneRateTable(cloneRateTableKey.cloneRateTableKey);
  }

  /**
   * Removes a rate cell.
   *
   * @param removeRateCellKey Rate Cell identifier
   */
  @Override
  public void removeRateCellData(RemoveRateCellKey removeRateCellKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Remove Rate Cell
    rateTableObj.removeRateCellData(removeRateCellKey.key);
  }

  /**
   * Modifies a rate table header.
   *
   * @param modifyRateHeaderDetails Rate Header identifier and details
   */
  @Override
  public void modifyRateTableHeader(
    ModifyRateHeaderDetails modifyRateHeaderDetails) throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Modify Rate Header Details
    rateTableObj.modifyRateHeader(
      modifyRateHeaderDetails.modifyRateHeaderDetails);
  }

  /**
   * Reads a rate cell.
   *
   * @param readRateCellKey rate cell key
   *
   * @return Rate Cell details
   */
  @Override
  public ReadCellDetails readRateCellData(ReadRateCellKey readRateCellKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Context description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    final curam.core.sl.struct.ReadRateColumnKey readRateColumnKey = new curam.core.sl.struct.ReadRateColumnKey();

    curam.core.sl.struct.ReadColumnDetails readColumnDetails;

    // Details to be returned
    final ReadCellDetails readCellDetails = new ReadCellDetails();

    // Read the Rate Cell
    readCellDetails.readCellDetails = rateTableObj.readRateCellData(
      readRateCellKey.readRateCellKey);

    readRateColumnKey.rateColumnID = readCellDetails.readCellDetails.rateColumnID;

    // Read Rate Column to get Rate Header ID
    readColumnDetails = rateTableObj.readRateColumn(readRateColumnKey);

    readRateTableDescriptionKey.rateHeaderID = readColumnDetails.rateHeaderID;

    // Read Context description
    readCellDetails.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    return readCellDetails;
  }

  /**
   * Reads a rate column.
   *
   * @param readRateColumnKey rate column key
   *
   * @return Rate Column details
   */
  @Override
  public ReadColumnDetails readRateColumn(ReadRateColumnKey readRateColumnKey) throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Details to be returned
    final ReadColumnDetails readColumnDetails = new ReadColumnDetails();

    // Read Rate Column Details
    readColumnDetails.readColumnDetails = rateTableObj.readRateColumn(
      readRateColumnKey.readRateColumnKey);

    // Context description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    readRateTableDescriptionKey.rateHeaderID = readColumnDetails.readColumnDetails.rateHeaderID;

    // Read Context description
    readColumnDetails.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    return readColumnDetails;
  }

  /**
   * Reads a rate row.
   *
   * @param readRateRowKey rate row key
   *
   * @return Rate Row details
   */
  @Override
  public ReadRowDetails readRateRow(ReadRateRowKey readRateRowKey)
    throws AppException, InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Details to be returned
    final ReadRowDetails readRowDetails = new ReadRowDetails();

    // Read Rate Row
    readRowDetails.readRowDetails = rateTableObj.readRateRow(
      readRateRowKey.readRateRowKey);

    // Context description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    readRateTableDescriptionKey.rateHeaderID = readRowDetails.readRowDetails.rateHeaderID;

    // Read Context description
    readRowDetails.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    // Return Details
    return readRowDetails;
  }

  /**
   * Reads a rate table header.
   *
   * @param readRateTableKey rate header key
   *
   * @return Rate Header details
   */
  @Override
  public ReadRateHeaderDetails readRateTableHeader(
    ReadRateTableKey readRateTableKey) throws AppException,
      InformationalException {

    // Rate Table maintenance object
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Details to be returned
    final ReadRateHeaderDetails readRateHeaderDetails = new ReadRateHeaderDetails();

    // Context description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    readRateHeaderDetails.readRateHeaderDetails = rateTableObj.readRateHeader(
      readRateTableKey.readRateTableKey);

    readRateTableDescriptionKey.rateHeaderID = readRateTableKey.readRateTableKey.rateHeaderID;

    // Read Context description
    readRateHeaderDetails.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    return readRateHeaderDetails;
  }

  /**
   * Returns a rate table description.
   *
   * @param readRateTableDescriptionKey rate table key
   *
   * @return rate table description
   */
  @Override
  protected RateTableContextDescription readRateTableDescription(
    ReadRateTableDescriptionKey readRateTableDescriptionKey)
    throws AppException, InformationalException {

    // variables, used to read rate table
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Create return object
    final RateTableContextDescription rateTableContextDescription = new RateTableContextDescription();

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      BPORATETABLE.INF_RATE_TABLE_CONTEXT_DESCRIPTION);

    if (readRateTableDescriptionKey.rateHeaderID == 0) {

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(RATETABLETYPE.TABLENAME,
        readRateTableDescriptionKey.rateTableType));

    } else {

      // Struct passed to RateTable::readRateHeader
      final curam.core.sl.struct.ReadRateTableKey readRateTableKey = new curam.core.sl.struct.ReadRateTableKey();

      // Struct returned from RateTable::readRateHeader
      curam.core.sl.struct.ReadRateHeaderDetails readRateHeaderDetails;

      // Get rate header id from key
      readRateTableKey.rateHeaderID = readRateTableDescriptionKey.rateHeaderID;

      readRateHeaderDetails = rateTableObj.readRateHeader(readRateTableKey);

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(RATETABLETYPE.TABLENAME,
        readRateHeaderDetails.rateHeaderDtls.rateTableType));

    }

    // Populate the context description field with the localizable text
    rateTableContextDescription.description = contextDescription.toClientFormattedText();

    // Return details
    return rateTableContextDescription;
  }

  /**
   * Reads entire rate table.
   *
   * @param readRateTableKey rate table key
   *
   * @return rate table details
   */
  @Override
  public ReadRateTableDetails readRateTableReadOnly(
    final ReadRateTableKey readRateTableKey) throws AppException,
      InformationalException {

    // create return object
    final ReadRateTableDetails readRateTableDetails = new ReadRateTableDetails();

    // variables, used to read rate table
    final curam.core.sl.intf.RateTable rateTableObj = curam.core.sl.fact.RateTableFactory.newInstance();

    // Context description key
    final ReadRateTableDescriptionKey readRateTableDescriptionKey = new ReadRateTableDescriptionKey();

    // Set read only indicator to true
    readRateTableKey.readRateTableKey.readOnlyInd = true;

    // read rate table
    readRateTableDetails.readRateTableDetails = rateTableObj.readRateTable(
      readRateTableKey.readRateTableKey);

    readRateTableDescriptionKey.rateHeaderID = readRateTableKey.readRateTableKey.rateHeaderID;

    // Read Context description
    readRateTableDetails.rateTableContextDescription = readRateTableDescription(
      readRateTableDescriptionKey);

    // return rate table details
    return readRateTableDetails;
  }

  // BEGIN, CR00356871, GA
  /**
   * {@inheritDoc}
   */
  @Override
  public ReadRateCellValue readRateCellValue(
    final ReadValueByColumnAndRowIndexKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.RateTable rateTableObj = RateTableFactory.newInstance();

    final ReadRateCellValue readRateCellValue = new ReadRateCellValue();

    readRateCellValue.dtls = rateTableObj.readValueByColumnAndRowIndex(key.dtls);

    return readRateCellValue;
  }
  // END, CR00356871
}
