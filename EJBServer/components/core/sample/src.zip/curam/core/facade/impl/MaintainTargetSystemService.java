/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2022. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;

import com.google.inject.Inject;
import curam.codetable.TARGETSYSTEMSTATUS;
import curam.codetable.impl.SYSTEMSERVICENAMEEntry;
import curam.codetable.impl.TARGETSYSTEMSTATUSEntry;
import curam.core.facade.struct.ServiceNameKey;
import curam.core.facade.struct.SystemDetailsList;
import curam.core.facade.struct.TargetSystemServiceDetails;
import curam.core.facade.struct.TargetSystemServiceDetailsList;
import curam.core.facade.struct.TargetSystemServiceKey;
import curam.core.facade.targetsystem.impl.TargetSystemServiceValidationInterface;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.security.util.impl.SymmetricEncryption;
import curam.core.struct.UsersKey;
import curam.ctm.sl.entity.struct.NameAndStatusKey;
import curam.ctm.targetsystem.impl.TargetSystemDAO;
import curam.ctm.targetsystem.impl.TargetSystemServiceDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import java.util.List;
import java.util.Map;

/**
 * This facade class manages a
 * {@link curam.ctm.targetsystem.impl.TargetSystemService TargetSystemService}.
 * It stores the details of the target system service details.
 */
public abstract class MaintainTargetSystemService
  extends curam.core.facade.base.MaintainTargetSystemService {

  /**
   * Reference to {@link curam.ctm.targetsystem.impl.TargetSystemService
   * TargetSystemService}.
   */
  @Inject
  protected TargetSystemServiceDAO targetSystemServiceDAO;

  /**
   * Reference to {@link curam.ctm.targetsystem.impl.TargetSystem TargetSystem}.
   */
  @Inject
  protected TargetSystemDAO targetSystemDAO;

  /**
   * Reference to {@link curam.core.security.util.SymmetricEncryption} .
   */
  @Inject
  protected SymmetricEncryption codec;

  @Inject
  protected Map<SYSTEMSERVICENAMEEntry, TargetSystemServiceValidationInterface> validatorMap;

  /**
   * Default constructor.
   */
  public MaintainTargetSystemService() {

    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Creates a target system service for a given target system. This method also
   * sets the status of the target system service to 'Active'.
   *
   * @param details
   * Contains the target system service details.
   *
   * @return The key of the target system service.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TargetSystemServiceKey
    createTargetSystemService(final TargetSystemServiceDetails details)
      throws AppException, InformationalException {

    final TargetSystemServiceKey targetSystemServiceKey =
      new TargetSystemServiceKey();

    // BEGIN, CR00241358, EC
    final String password = details.dtls.password;
    final String encryptedPassword = this.codec.encrypt(password);

    final TargetSystemServiceValidationInterface validator =
      validatorMap.get(SYSTEMSERVICENAMEEntry.get(details.dtls.name));

    if (validator != null) {
      // validate
      validator.validateCreate(details);
    }

    final curam.ctm.targetsystem.impl.TargetSystemService targetSystemService =
      targetSystemServiceDAO.createTargetSystemService(details.dtls.name,
        details.dtls.extensionURL, targetSystemDAO.get(details.dtls.systemID),
        details.dtls.username, encryptedPassword);

    // END, CR00241358
    targetSystemServiceKey.serviceID = targetSystemService.getID();
    return targetSystemServiceKey;
  }

  /**
   * Modifies a target system service details. User can modify target system
   * service name and extension URL if the record status is 'Active'.
   *
   * @param details
   * Contains the target system service details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void
    modifyTargetSystemService(final TargetSystemServiceDetails details)
      throws AppException, InformationalException {

    final curam.ctm.targetsystem.impl.TargetSystemService targetSystemService =
      targetSystemServiceDAO.get(details.dtls.serviceID);

    final TargetSystemServiceValidationInterface validator =
      validatorMap.get(SYSTEMSERVICENAMEEntry.get(details.dtls.name));

    if (validator != null) {
      // validate
      validator.validateModify(details);
    }

    setTargetSystemServiceFields(targetSystemService, details);
    targetSystemService.modify(details.dtls.versionNo);
  }

  /**
   * Deletes a target system service details and sets the target system service
   * status to 'Canceled'.
   *
   * @param key
   * Contains key of a target system service record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void deleteTargetSystemService(final TargetSystemServiceKey key)
    throws AppException, InformationalException {

    final curam.ctm.targetsystem.impl.TargetSystemService targetSystemService =
      targetSystemServiceDAO.get(key.serviceID);

    targetSystemService.setStatus(TARGETSYSTEMSTATUSEntry.CANCELED);
    targetSystemService.modify(targetSystemService.getVersionNo());
  }

  /**
   * Returns list of active target systems associated for a target system
   * service.
   *
   * @param key
   * Contains target system service name.
   *
   * @return List of active target systems associated for a target system
   * service.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public SystemDetailsList listTargetSystemsByServiceName(
    final ServiceNameKey key) throws AppException, InformationalException {

    final curam.ctm.sl.entity.struct.NameAndStatusKey nameAndStatusKey =
      new NameAndStatusKey();

    nameAndStatusKey.name = key.name;
    nameAndStatusKey.status = TARGETSYSTEMSTATUS.ACTIVE;
    final SystemDetailsList systemDetailsList = new SystemDetailsList();

    systemDetailsList.dtls.addAll(targetSystemServiceDAO
      .listTargetSystemsByServiceName(nameAndStatusKey).dtls);
    return systemDetailsList;
  }

  /**
   * Returns list of active target system services for a given target system ID.
   *
   * @param key
   * Contains target system ID.
   *
   * @return List of active target system services of a target system.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TargetSystemServiceDetailsList listTargetSystemServices(
    final curam.ctm.sl.entity.struct.TargetSystemKey key)
    throws AppException, InformationalException {

    final List<curam.ctm.targetsystem.impl.TargetSystemService> targetSystemServices =
      targetSystemServiceDAO.listTargetSystemServices(key);
    final TargetSystemServiceDetailsList targetSystemServiceDetailsList =
      new TargetSystemServiceDetailsList();

    for (final curam.ctm.targetsystem.impl.TargetSystemService targetSystemService : targetSystemServices) {
      final TargetSystemServiceDetails targetSystemServiceDetails =
        getTargetSystemServiceFields(targetSystemService);

      // BEGIN, CR00241358, EC
      targetSystemServiceDetails.dtls.password = CuramConst.gkEmpty;
      // END, CR00241358
      targetSystemServiceDetailsList.details
        .addRef(targetSystemServiceDetails);
    }
    return targetSystemServiceDetailsList;
  }

  /**
   * Views a target system details consisting of service name, created date,
   * status, created user and extension URL.
   *
   * @param key
   * Contains key of the target system service.
   *
   * @return The target system service details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TargetSystemServiceDetails viewTargetSystemService(
    final curam.ctm.sl.entity.struct.TargetSystemServiceKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00241358, EC
    final TargetSystemServiceDetails details =
      this.getTargetSystemServiceFields(
        targetSystemServiceDAO.get(key.serviceID));

    details.dtls.password = CuramConst.gkEmpty;

    return details;
    // END, CR00241358
  }

  /**
   * Gets the target system service details from an TargetSystemService
   * instance.
   *
   * @param targetSystemService
   * TargetSystemService instance.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected TargetSystemServiceDetails getTargetSystemServiceFields(
    final curam.ctm.targetsystem.impl.TargetSystemService targetSystemService)
    throws AppException, InformationalException {

    final TargetSystemServiceDetails targetSystemServiceDetails =
      new TargetSystemServiceDetails();

    targetSystemServiceDetails.dtls.serviceID = targetSystemService.getID();
    targetSystemServiceDetails.dtls.systemID =
      targetSystemService.getTargetSystem().getID();
    targetSystemServiceDetails.dtls.name = targetSystemService.getName();
    targetSystemServiceDetails.dtls.extensionURL =
      targetSystemService.getExtensionURL();
    targetSystemServiceDetails.dtls.extensionURL =
      targetSystemService.getExtensionURL();
    final UsersKey userskey = new UsersKey();

    userskey.userName = targetSystemService.getCreatedBy();
    targetSystemServiceDetails.dtls.createdBy =
      UsersFactory.newInstance().readUserFullname(userskey).fullname;

    targetSystemServiceDetails.dtls.createdDate =
      targetSystemService.getCreationDate();
    targetSystemServiceDetails.dtls.status =
      targetSystemService.getStatus().getCode();
    targetSystemServiceDetails.dtls.versionNo =
      targetSystemService.getVersionNo();

    // BEGIN, CR00241358, EC
    targetSystemServiceDetails.dtls.username =
      targetSystemService.getUsername();

    final String encryptedPassword = targetSystemService.getPassword();
    final String password = this.codec.decrypt(encryptedPassword);

    targetSystemServiceDetails.dtls.password = password;
    // END, CR00241358, EC

    if (targetSystemService.getStatus()
      .equals(TARGETSYSTEMSTATUSEntry.CANCELED)) {
      targetSystemServiceDetails.recordCanceledInd = true;
    } else {
      targetSystemServiceDetails.recordCanceledInd = false;
    }

    return targetSystemServiceDetails;
  }

  /**
   * Sets the target system service details to an TargetSystemService instance.
   *
   * @param targetSystemService
   * TargetSystemService instance.
   * @param details
   * Target system service details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setTargetSystemServiceFields(
    final curam.ctm.targetsystem.impl.TargetSystemService targetSystemService,
    final TargetSystemServiceDetails details)
    throws AppException, InformationalException {

    targetSystemService.setName(details.dtls.name);
    targetSystemService.setExtensionURL(details.dtls.extensionURL);
    targetSystemService
      .setTargetSystem(targetSystemDAO.get(details.dtls.systemID));
    // BEGIN, CR00241358, EC
    targetSystemService.setUsername(details.dtls.username);

    final String password = details.dtls.password;
    final String encryptedPassword = this.codec.encrypt(password);

    targetSystemService.setPassword(encryptedPassword);
    // END, CR00241358, EC
  }
}
