/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CASEDECISIONSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESOLUTIONSTATUSCODE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.INCIDENTOBJECTLINKTYPEEntry;
import curam.core.facade.struct.AllegationDetailsIndicatorList;
import curam.core.facade.struct.AllegationDetailsList;
import curam.core.facade.struct.AllegationRoleDetailsList;
import curam.core.facade.struct.CaseEventAndActivityDetails;
import curam.core.facade.struct.CloseCaseDetails;
import curam.core.facade.struct.ClosureDetails;
import curam.core.facade.struct.ContextDescriptionDetails;
import curam.core.facade.struct.CreateActionDetails;
import curam.core.facade.struct.CreateAssessmentDeliveryDetails;
import curam.core.facade.struct.CreateAssessmentDeliveryKey;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.IntegratedInvestigationHomeDtls;
import curam.core.facade.struct.IntegratedInvestigationHomeDtls1;
import curam.core.facade.struct.InvestigationDeliveryActionPlanList;
import curam.core.facade.struct.InvestigationDeliveryAssessmentList;
import curam.core.facade.struct.InvestigationDeliveryEventAndActivityDetails;
import curam.core.facade.struct.InvestigationDeliveryEventAndActivityDetails1;
import curam.core.facade.struct.InvestigationHomePageDtls;
import curam.core.facade.struct.InvestigationHomePageDtls1;
import curam.core.facade.struct.InvestigationHomePageName;
import curam.core.facade.struct.InvestigationIntegratedIndPrimaryClient;
import curam.core.facade.struct.InvestigationResolutionAndConfigIDDetailsList;
import curam.core.facade.struct.InvestigationSearchByOwnerDetailsList;
import curam.core.facade.struct.InvestigationSearchByOwnerResult;
import curam.core.facade.struct.InvestigationSearchList;
import curam.core.facade.struct.InvestigationSearchListStruct;
import curam.core.facade.struct.ListICAssessmentKey;
import curam.core.facade.struct.ListMilestoneForInvestigationTypeDetails;
import curam.core.facade.struct.MyInvestigationFilterList;
import curam.core.facade.struct.ReactivationDetails;
import curam.core.facade.struct.ReadInvestigationHomePageNameKey;
import curam.core.facade.struct.ResolutionActionDisplayIndicators;
import curam.core.facade.struct.ResolutionDetails;
import curam.core.facade.struct.ResolutionStatusHistoryDtls;
import curam.core.facade.struct.ResolutionStatusHistoryDtlsList;
import curam.core.facade.struct.SearchCaseEventAndActivityKey;
import curam.core.facade.struct.SearchTasksForConcernAndCaseDetails;
import curam.core.fact.CaseDecisionFactory;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseSearchFactory;
import curam.core.fact.CaseSearchRouterFactory;
import curam.core.fact.MaintainCaseClosureFactory;
import curam.core.fact.UsersFactory;
import curam.core.fact.ViewCaseEventsFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.ProductHookManager;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseDecision;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseSearch;
import curam.core.intf.CaseSearchRouter;
import curam.core.intf.MaintainCaseClosure;
import curam.core.intf.ViewCaseEvents;
import curam.core.sl.entity.struct.ActionChildLinkDtls;
import curam.core.sl.entity.struct.ActionChildLinkKey;
import curam.core.sl.entity.struct.ActionKey;
import curam.core.sl.entity.struct.ActionPlanDtls;
import curam.core.sl.entity.struct.ActionPlanKey;
import curam.core.sl.entity.struct.AllegationDtlsList;
import curam.core.sl.entity.struct.AllegationKey;
import curam.core.sl.entity.struct.AllegationRoleKey;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.FindingDtls;
import curam.core.sl.entity.struct.FindingDtlsList;
import curam.core.sl.entity.struct.FindingKey;
import curam.core.sl.entity.struct.InvestigationConfigKey;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.LinkKey;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.entity.struct.ModifyOverrideReasonDtls;
import curam.core.sl.entity.struct.ResolutionKey;
import curam.core.sl.entity.struct.ResolutionStatusHistoryKey;
import curam.core.sl.fact.AllegationFactory;
import curam.core.sl.fact.AllegationRoleFactory;
import curam.core.sl.fact.AssessmentDeliveryFactory;
import curam.core.sl.fact.BookmarkFactory;
import curam.core.sl.fact.CalendarDataFactory;
import curam.core.sl.fact.CaseActionPlanFactory;
import curam.core.sl.fact.FindingFactory;
import curam.core.sl.fact.InvestigationConfigurationFactory;
import curam.core.sl.fact.InvestigationDeliveryFactory;
import curam.core.sl.fact.MilestoneDeliveryFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndCaseID;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.intf.Allegation;
import curam.core.sl.intf.AllegationRole;
import curam.core.sl.intf.AssessmentDelivery;
import curam.core.sl.intf.Bookmark;
import curam.core.sl.intf.CalendarData;
import curam.core.sl.intf.CaseActionPlan;
import curam.core.sl.intf.Finding;
import curam.core.sl.intf.InvestigationConfiguration;
import curam.core.sl.intf.MilestoneDelivery;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.struct.ActionAndAllegationDetails;
import curam.core.sl.struct.ActionPlanAndActionDetails;
import curam.core.sl.struct.ActionPlanAndSituationDetails;
import curam.core.sl.struct.ActivityElementDetails;
import curam.core.sl.struct.AllegationAndFindingDetails;
import curam.core.sl.struct.AllegationAndParticipantListDtls;
import curam.core.sl.struct.AllegationDetails;
import curam.core.sl.struct.AllegationDetailsForList1;
import curam.core.sl.struct.AllegationHomeDetails;
import curam.core.sl.struct.AllegationRoleDetails;
import curam.core.sl.struct.AllegationRoleParticipantListDetails;
import curam.core.sl.struct.CalendarElementData;
import curam.core.sl.struct.CancelActionPlanKey;
import curam.core.sl.struct.CancelAllegationDetails;
import curam.core.sl.struct.CancelIncidentLinkDetails;
import curam.core.sl.struct.CaseIDAndConcernRoleIDKey;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CountCaseBookmarkKey;
import curam.core.sl.struct.CreateActionPlanDetails;
import curam.core.sl.struct.CreateAssessmentDeliveryResult;
import curam.core.sl.struct.DateRangeKey;
import curam.core.sl.struct.DateTimeRangeDetails;
import curam.core.sl.struct.EventElementDetails;
import curam.core.sl.struct.InvestigationCaseHomeDetails;
import curam.core.sl.struct.InvestigationCreationDetails;
import curam.core.sl.struct.InvestigationDeliveryIncidentDetailsList;
import curam.core.sl.struct.InvestigationHeaderDetails;
import curam.core.sl.struct.InvestigationMilestoneDeliveryDtls;
import curam.core.sl.struct.PrintActionPlanDetails;
import curam.core.sl.struct.SearchCaseParticipantDetails;
import curam.core.sl.struct.SearchCaseParticipantDetailsKey;
import curam.core.sl.struct.SearchCaseParticipantDetailsList;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.ApprovalMessageList;
import curam.core.struct.CaseDecisionDtls;
import curam.core.struct.CaseDecisionKey;
import curam.core.struct.CaseEventByCaseIDKey;
import curam.core.struct.CaseEventDtlsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CasesByCaseIDAndTypeKey;
import curam.core.struct.ClosureDtls;
import curam.core.struct.Count;
import curam.core.struct.CuramInd;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.InitialInvestigationSearchCriteria;
import curam.core.struct.InvestigationSearchCriteria;
import curam.core.struct.ProductDeliveryApprovalKey;
import curam.core.struct.ProductDeliveryApprovalKey1;
import curam.core.struct.ReactivationDtls;
import curam.core.struct.ReadCaseClosureKey;
import curam.core.struct.UsersKey;
import curam.core.struct.ViewCaseEventDetailsList;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.incident.entity.struct.IncidentLinkDtls;
import curam.incident.entity.struct.IncidentLinkKey;
import curam.incident.impl.Incident;
import curam.incident.impl.IncidentDAO;
import curam.incident.impl.IncidentLink;
import curam.incident.impl.IncidentLinkDAO;
import curam.message.BPOALLEGATION;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import java.util.Collections;
import java.util.Comparator;

public abstract class InvestigationDelivery
  extends curam.core.facade.base.InvestigationDelivery {

  // BEGIN, CR00120720, ZV
  // Add injection for using the new API
  public InvestigationDelivery() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00120720

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // BEGIN, CR00121009, ZV
  @Inject
  protected IncidentDAO incidentDAO;

  @Inject
  protected IncidentLinkDAO incidentLinkDAO;

  // END, CR00121009

  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // BEGIN, CR00354960, CD

  protected static final String kSpace = CuramConst.gkSpace;

  protected static final String kSeparator = CuramConst.gkDash;

  protected static final String kCuramCalendarDataHeader =
    CuramCalendarHeaderConst.kCuramCalendarDataHeader;

  protected static final String kCuramCalendarDataFooter =
    CuramCalendarHeaderConst.kCuramCalendarDataFooter;

  protected static final String kQuote = CuramCalendarHeaderConst.kQuote;

  protected static final String kCloseBracket =
    CuramCalendarHeaderConst.kCloseBracket;

  // BEGIN, CR00105225, ZV
  // ___________________________________________________________________________
  /**
   * This method lists all milestones which have been configured in
   * administration for the investigation case type.
   * Only milestones which have no end date or an end date
   * in the future are displayed for selection.
   *
   * @param key investigation configuration key.
   *
   * @return the list of milestone configuration details.
   */
  @Override
  public ListMilestoneForInvestigationTypeDetails
    listMilestoneForInvestigationType(final CaseHeaderKey key)
      throws AppException, InformationalException {

    final ListMilestoneForInvestigationTypeDetails listMilestoneForInvestigationTypeDetails =
      new ListMilestoneForInvestigationTypeDetails();

    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      curam.core.sl.fact.InvestigationDeliveryFactory.newInstance();

    listMilestoneForInvestigationTypeDetails.dtls =
      investigationDeliveryObj.listMilestoneForInvestigationType(key);

    // Obtain the informational(s) to be returned to the client
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      listMilestoneForInvestigationTypeDetails.informationalMsgDtlsList.dtls
        .addRef(informationalMsgDtls);
    }

    return listMilestoneForInvestigationTypeDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method creates an investigation delivery milestone
   *
   * @param dtls the investigation delivery milestone details
   * @return The unique identifier of the newly created milestone delivery
   */
  @Override
  public MilestoneDeliveryKey
    createMilestone(final InvestigationMilestoneDeliveryDtls dtls)
      throws AppException, InformationalException {

    final MilestoneDelivery milestoneDeliveryObj =
      MilestoneDeliveryFactory.newInstance();

    final curam.core.sl.struct.MilestoneDeliveryDtls milestoneDeliveryDtls =
      new curam.core.sl.struct.MilestoneDeliveryDtls();

    milestoneDeliveryDtls.dtls.assign(dtls);

    return milestoneDeliveryObj.create(milestoneDeliveryDtls);
  }

  // END, CR00105225

  // BEGIN, CR00105142, SD
  // ___________________________________________________________________________
  /**
   * This method is used to create an Investigation Delivery case.
   *
   * @param details The information needed to create an investigation delivery
   * case.
   *
   * @return The ID of the new investigation delivery.
   */
  @Override
  public InvestigationDeliveryKey
    create(final InvestigationCreationDetails details)
      throws AppException, InformationalException {

    // InvestigationDelivery manipulation variables
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      curam.core.sl.fact.InvestigationDeliveryFactory.newInstance();
    InvestigationDeliveryKey investigationDeliveryKey =
      new InvestigationDeliveryKey();

    // Create the investigation delivery
    investigationDeliveryKey =
      investigationDeliveryObj.createInvestigationDelivery(details);

    // Return the case id for the investigation delivery
    return investigationDeliveryKey;
  }

  // ___________________________________________________________________________
  /**
   * @param key The case ID of the investigation delivery case.
   *
   * @return The investigation delivery case homepage details.
   * @deprecated Since Curam 6.0, replaced by {@link #readHomePageDetails1()}.
   *
   * This method is used to display the investigation delivery case homepage.
   */
  @Override
  @Deprecated
  public InvestigationHomePageDtls
    readHomePageDetails(final InvestigationDeliveryKey key)
      throws AppException, InformationalException {

    final InvestigationHomePageDtls investigationHomePageDtls =
      new InvestigationHomePageDtls();

    // BEGIN, CR00220971, ZV
    investigationHomePageDtls.assign(readHomePageDetails1(key));
    // END, CR00220971

    return investigationHomePageDtls;
  }

  // END, CR00105142

  // ___________________________________________________________________________
  /**
   * Cancels an allegation for a case.
   *
   * @param cancelAllegationDetails Key to cancel the allegation
   */
  @Override
  public void
    cancelAllegation(final CancelAllegationDetails cancelAllegationDetails)
      throws AppException, InformationalException {

    AllegationFactory.newInstance().cancel(cancelAllegationDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates an allegation for a case.
   *
   * @param createAllegationDetails Key to create the allegation
   */
  @Override
  public AllegationKey
    createAllegation(final AllegationDetails createAllegationDetails)
      throws AppException, InformationalException {

    // Return Type
    final AllegationKey allegationKey = new AllegationKey();

    final Allegation allegationObj = AllegationFactory.newInstance();

    allegationObj.create(createAllegationDetails);

    allegationKey.allegationID =
      createAllegationDetails.allegationDtls.allegationID;

    return allegationKey;
  }

  // BEGIN, CR00231044, CSH
  // ___________________________________________________________________________
  /**
   * Lists allegations for a case.
   *
   * @param key CaseKeyStruct the identifier for the case.
   * @return List of allegations
   * @deprecated Since Curam 6.0, replaced by
   * {@link #curam.core.facade.intf.InvestigationDelivery.listAllegation1()
   *
   */
  @Override
  @Deprecated
  public AllegationDetailsList listAllegation(final CaseKeyStruct key)
    throws AppException, InformationalException {

    // Return struct
    final AllegationDetailsList allegationDetailsList =
      new AllegationDetailsList();
    final Allegation allegationObj = AllegationFactory.newInstance();
    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseKeyStruct.caseID = key.caseID;
    caseHeaderKey.caseID = key.caseID;

    allegationDetailsList.allegationDetailsList =
      allegationObj.list(caseKeyStruct);

    allegationDetailsList.contextDtls.description =
      getContextDescription(caseHeaderKey).description;

    return allegationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists allegations for a case.
   *
   * @param key CaseKeyStruct the identifier for the case.
   * @return List of allegations
   */
  @Override
  public AllegationDetailsIndicatorList listAllegation1(
    final CaseKeyStruct key) throws AppException, InformationalException {

    // Return struct
    final AllegationDetailsIndicatorList allegationDetailsIndicatorList =
      new AllegationDetailsIndicatorList();

    // BEGIN, CR00301053, ZV
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00301053

    final AllegationDetailsList allegationDetailsList =
      new AllegationDetailsList();
    // Allegation allegationObj = AllegationFactory.newInstance();
    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseKeyStruct.caseID = key.caseID;
    caseHeaderKey.caseID = key.caseID;

    AllegationDtlsList allegationDtlsList = new AllegationDtlsList();

    allegationDtlsList = curam.core.sl.entity.fact.AllegationFactory
      .newInstance().searchByInvestigationCaseID(key);

    // allegationDetailsList.allegationDetailsList =
    // allegationObj.list(caseKeyStruct);
    // Assign allegation details

    if (allegationDtlsList.dtls.size() > 0) {

      for (int j = 0; j < allegationDtlsList.dtls.size(); j++) {

        // Set indicators for client action display
        final AllegationDetailsForList1 allegationDetailsForList1 =
          new AllegationDetailsForList1();
        final AllegationKey allegationKey = new AllegationKey();
        FindingDtlsList findingDtlsList = new FindingDtlsList();
        final Finding findingObj = FindingFactory.newInstance();

        allegationKey.allegationID =
          allegationDtlsList.dtls.item(j).allegationID;

        findingDtlsList = findingObj.listForAllegation(allegationKey);

        // Sorting the list by created time stamp
        if (!findingDtlsList.dtls.isEmpty()) {

          Collections.sort(findingDtlsList.dtls,
            new Comparator<FindingDtls>() {

              @Override
              public int compare(final FindingDtls obj1,
                final FindingDtls obj2) {

                return obj1.createdTimeStamp.compareTo(obj2.createdTimeStamp);
              }
            });

          final int k = findingDtlsList.dtls.size();

          // Set finding details for return struct
          allegationDetailsForList1.findingID =
            findingDtlsList.dtls.item(k - 1).findingID;

          allegationDetailsForList1.actionIndicators.addFindingInd = false;
          allegationDetailsForList1.actionIndicators.viewHistoryInd = true;
        } else {

          allegationDetailsForList1.actionIndicators.addFindingInd = true;
          allegationDetailsForList1.actionIndicators.viewHistoryInd = false;
        }

        // Set allegation details for return struct
        allegationDetailsForList1.assign(allegationDtlsList.dtls.item(j));

        allegationDetailsIndicatorList.allegationDetailsList
          .addRef(allegationDetailsForList1);

        // Get the investigation case status
        final curam.core.intf.CaseHeader caseHeaderObj =
          curam.core.fact.CaseHeaderFactory.newInstance();

        // Read the status of the issue case
        final CaseStatusCode caseStatusCode =
          caseHeaderObj.readCaseStatus(caseHeaderKey);

        // Check has investigation case been re-opened/reactivated
        boolean investigationReopened = false;
        CaseEventDtlsList caseEventDtlsList = new CaseEventDtlsList();
        final CaseEventByCaseIDKey caseEventByCaseIDKey =
          new CaseEventByCaseIDKey();
        final CaseEvent caseEventObj = CaseEventFactory.newInstance();

        caseEventByCaseIDKey.caseID = key.caseID;
        caseEventDtlsList = caseEventObj.searchByCaseID(caseEventByCaseIDKey);
        // BEGIN,CR00278002 , DK
        boolean investigationApproved = false;

        // check to see if the case has been approved to allow override findings
        for (int i = 0; i < caseEventDtlsList.dtls.size(); i++) {

          if (caseEventDtlsList.dtls.item(i).eventTypeCode
            .equals(CASEEVENTTYPE.CASEAPPROVAL)) {

            investigationApproved = true;
          }
        }
        // END,CR00278002 , DK
        for (int i = 0; i < caseEventDtlsList.dtls.size(); i++) {

          if (caseEventDtlsList.dtls.item(i).eventTypeCode
            .equals(CASEEVENTTYPE.CASEREACTIVATION)
            && !(caseStatusCode.equals(CASESTATUS.PENDINGCLOSURE)
              || caseStatusCode.equals(CASESTATUS.CLOSED))) {

            investigationReopened = true;
          }
        }

        if (findingDtlsList.dtls.size() > 0 && !investigationReopened) {

          allegationDetailsForList1.actionIndicators.editFindingInd = true;
        } else {

          allegationDetailsForList1.actionIndicators.editFindingInd = false;
        }

        if (findingDtlsList.dtls.size() > 0 && investigationReopened
          && investigationApproved) {

          allegationDetailsForList1.actionIndicators.overrideFindingInd =
            true;
        } else {

          allegationDetailsForList1.actionIndicators.overrideFindingInd =
            false;
        }
      }
    }

    return allegationDetailsIndicatorList;
  }

  // END, CR00231044

  // ___________________________________________________________________________
  /**
   * Modifies an allegation for a case.
   *
   * @param modifyAllegationDetails details to modify the allegation
   */
  @Override
  public void
    modifyAllegation(final AllegationDetails modifyAllegationDetails)
      throws AppException, InformationalException {

    final Allegation allegationObj = AllegationFactory.newInstance();

    allegationObj.modify(modifyAllegationDetails);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the Case Participants by Case
   *
   * @param key Contains the case identifier
   * @return List of Case Participants
   */
  @Override
  public SearchCaseParticipantDetailsList
    listCaseParticipant(final SearchCaseParticipantDetailsKey key)
      throws AppException, InformationalException {

    final SearchCaseParticipantDetailsList searchCaseParticipantDetailsList =
      new SearchCaseParticipantDetailsList();

    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
      .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

    SearchCaseParticipantDetails searchCaseParticipantDetails;

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      if (viewCaseParticipantRoleDetailsList.dtls.item(i).recordStatus
        .equals(curam.codetable.RECORDSTATUS.NORMAL)) {

        searchCaseParticipantDetails = new SearchCaseParticipantDetails();

        searchCaseParticipantDetails.caseParticipantRoleID =
          viewCaseParticipantRoleDetailsList.dtls
            .item(i).caseParticipantRoleID;
        searchCaseParticipantDetails.name =
          viewCaseParticipantRoleDetailsList.dtls.item(i).name;

        searchCaseParticipantDetailsList.searchCaseParticipantDetails
          .addRef(searchCaseParticipantDetails);
      }

    }

    return searchCaseParticipantDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads an allegation for a case.
   *
   * @param allegationKey Key to read the allegation
   */
  @Override
  public AllegationAndFindingDetails
    readAllegation(final AllegationKey allegationKey)
      throws AppException, InformationalException {

    final Allegation allegationObj = AllegationFactory.newInstance();

    final AllegationAndFindingDetails allegationAndFindingDetails =
      allegationObj.read(allegationKey);

    return allegationAndFindingDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads an allegation details for modifying.
   *
   * @param key key of the allegation
   * @return the allegation and participant list details
   */
  @Override
  public AllegationAndParticipantListDtls readAllegationForModify(
    final AllegationKey key) throws AppException, InformationalException {

    final AllegationAndParticipantListDtls allegationAndParticipantListDtls =
      curam.core.sl.fact.AllegationFactory.newInstance()
        .readAllegationForModify(key);

    return allegationAndParticipantListDtls;
  }

  // BEGIN, CR00128420, MC
  // ___________________________________________________________________________
  /**
   * Returns the context description for the client. The following format is
   * returned:
   * Investigation type, case reference number, primary client name, alternate
   * ID
   * Example: Benefit Fraud 514 - James Smith 24684
   *
   * @param key the case header key for the investigation case.
   * @return A description of the case context.
   */
  @Override
  public ContextDescriptionDetails getContextDescription(
    final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ContextDescriptionDetails contextDescription =
      new ContextDescriptionDetails();
    final InvestigationDeliveryKey investigationDeliveryKey =
      new InvestigationDeliveryKey();

    investigationDeliveryKey.caseID = key.caseID;

    contextDescription.description = InvestigationDeliveryFactory
      .newInstance().getInvestigationDeliveryContextDescription(
        investigationDeliveryKey).description;

    return contextDescription;
  }

  // END, CR00128420

  // BEGIN, CR00105466, ZV
  // ___________________________________________________________________________
  /**
   * Method to create a finding for an allegation
   *
   * @param dtls The finding details to be created.
   *
   * @return Created finding key
   */
  @Override
  public FindingKey createFinding(final FindingDtls dtls)
    throws AppException, InformationalException {

    // Finding entity manipulation variables
    final Finding findingObj = FindingFactory.newInstance();

    // create finding
    return findingObj.create(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Method to list finding details for an allegation
   *
   * @param key The allegation key to list finding details for.
   *
   * @return List of finding details for allegation
   */
  @Override
  public FindingDtlsList listFinding(final AllegationKey key)
    throws AppException, InformationalException {

    // Finding entity manipulation variables
    final Finding findingObj = FindingFactory.newInstance();

    // list finding details for an allegation
    return findingObj.listForAllegation(key);
  }

  // ___________________________________________________________________________
  /**
   * Method to modify finding details
   *
   * @param dtls The finding details to be modified.
   */
  @Override
  public void modifyFinding(final FindingDtls dtls)
    throws AppException, InformationalException {

    // Finding entity manipulation variables
    final Finding findingObj = FindingFactory.newInstance();

    // modify finding details
    findingObj.modify(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Method to override finding.
   *
   * @param dtls The finding override details.
   */
  @Override
  public void overrideFinding(final ModifyOverrideReasonDtls dtls)
    throws AppException, InformationalException {

    // Finding entity manipulation variables
    final Finding findingObj = FindingFactory.newInstance();

    // override finding details
    findingObj.override(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Method to read finding details.
   *
   * @param key The finding key
   *
   * @return The finding details
   */
  @Override
  public FindingDtls readFinding(final FindingKey key)
    throws AppException, InformationalException {

    // Finding entity manipulation variables
    final Finding findingObj = FindingFactory.newInstance();

    // read finding details
    return findingObj.read(key);
  }

  // END, CR00105466

  // BEGIN, CR00105577, MC
  // ___________________________________________________________________________
  /**
   * This method is used to render a Resolution on an investigation.
   *
   * @param details the resolution details
   */
  @Override
  public void createResolution(final ResolutionDetails details)
    throws AppException, InformationalException {

    // Use the InvestigationDelivery manipulation variable
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      InvestigationDeliveryFactory.newInstance();

    // Call API to perform the create operation
    investigationDeliveryObj.createResolution(details.details);
  }

  // ___________________________________________________________________________
  /**
   * This method lists active resolutions which have been configured
   * for this type of investigation.
   *
   * @param key The ID of the investigation configured in administration.
   *
   * @return A list of active resolutions.
   */
  @Override
  public InvestigationResolutionAndConfigIDDetailsList
    listActiveResolutionForInvestigation(final InvestigationDeliveryKey key)
      throws AppException, InformationalException {

    // Return Object
    final InvestigationResolutionAndConfigIDDetailsList resolutionAndConfigIDDetailsList =
      new InvestigationResolutionAndConfigIDDetailsList();

    // InvestigationDelivery manipulation variable
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      InvestigationDeliveryFactory.newInstance();

    // Use the entity Investigation Delivery to read for the investigation
    // config key
    final curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryEntityObj =
      curam.core.sl.entity.fact.InvestigationDeliveryFactory.newInstance();

    final InvestigationConfigKey investigationConfigKey =
      new InvestigationConfigKey();

    investigationConfigKey.investigationConfigID =
      investigationDeliveryEntityObj.read(key).investigationConfigID;

    // Call API to perform the list operation
    resolutionAndConfigIDDetailsList.dtlsList = investigationDeliveryObj
      .listActiveResolutionForInvestigation(investigationConfigKey);

    // Get the current resolution for this Investigation
    final RecordStatusAndCaseID recordStatusAndCaseID =
      new RecordStatusAndCaseID();

    recordStatusAndCaseID.integratedCaseID = key.caseID;
    recordStatusAndCaseID.recordStatus = RECORDSTATUS.NORMAL;

    resolutionAndConfigIDDetailsList.resolutionConfigurationID =
      investigationDeliveryObj.readResolutionForInvestigation(
        recordStatusAndCaseID).resolutionConfigurationID;

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      resolutionAndConfigIDDetailsList.informationalMsgDtlsList.dtls
        .addRef(informationalMsgDtls);
    }

    return resolutionAndConfigIDDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to modify a Resolution.
   *
   * @param details The resolution details.
   */
  @Override
  public void modifyResolution(final ResolutionDetails details)
    throws AppException, InformationalException {

    // InvestigationDelivery manipulation variable
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      InvestigationDeliveryFactory.newInstance();

    // Call API to perform the modify operation
    investigationDeliveryObj.modifyResolution(details.details);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to list all the resolution status changes that the
   * investigation has been through.
   *
   * @param key Resolution entity key
   *
   * @return Details of the resolution status history
   */
  @Override
  public ResolutionStatusHistoryDtlsList
    listResolutionChangeHistory(final InvestigationDeliveryKey key)
      throws AppException, InformationalException {

    // Return Struct
    final ResolutionStatusHistoryDtlsList resolutionStatusHistoryDtlsList =
      new ResolutionStatusHistoryDtlsList();

    // InvestigationDelivery manipulation variable
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      InvestigationDeliveryFactory.newInstance();

    resolutionStatusHistoryDtlsList.dtlsList =
      investigationDeliveryObj.listResolutionChangeHistory(key);

    // BEGIN, CR00128420, MC
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // Set context description
    resolutionStatusHistoryDtlsList.description =
      getContextDescription(caseHeaderKey);
    // END, CR00128420

    return resolutionStatusHistoryDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the user to view the resolution status for an
   * investigation.
   * An investigation can have the following status: In Edit, Submitted,
   * Approved.
   *
   * @param key Resolution Change History key
   *
   * @return Details of the resolution status history
   */
  @Override
  public ResolutionStatusHistoryDtls
    readResolutionChangeHistory(final ResolutionStatusHistoryKey key)
      throws AppException, InformationalException {

    // Return struct
    final ResolutionStatusHistoryDtls resolutionStatusHistoryDtls =
      new ResolutionStatusHistoryDtls();

    // InvestigationDelivery manipulation variable
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      InvestigationDeliveryFactory.newInstance();
    InvestigationDeliveryKey investigationDeliveryKey =
      new InvestigationDeliveryKey();

    resolutionStatusHistoryDtls.dtls =
      investigationDeliveryObj.readResolutionChangeHistory(key);

    final ResolutionKey resolutionKey = new ResolutionKey();

    // Set key to read investigation delivery ID
    resolutionKey.resolutionID =
      resolutionStatusHistoryDtls.dtls.dtls.resolutionID;

    // Get key to find context description
    investigationDeliveryKey = investigationDeliveryObj
      .readInvestigationDeliveryKeyForResolution(resolutionKey);

    // BEGIN, CR00128420, MC
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = investigationDeliveryKey.caseID;

    // Set context description
    resolutionStatusHistoryDtls.description =
      getContextDescription(caseHeaderKey);
    // END, CR00128420

    return resolutionStatusHistoryDtls;
  }

  // END, CR00105577
  // ___________________________________________________________________________
  /**
   * Removes an allegation role for an allegation.
   *
   * @param key to remove the allegation role
   */
  @Override
  public void removeAllegationRole(final AllegationRoleKey key)
    throws AppException, InformationalException {

    curam.core.sl.fact.AllegationRoleFactory.newInstance()
      .removeAllegationRole(key);

  }

  // ___________________________________________________________________________
  /**
   * Modifies an allegation role for an allegation.
   *
   * @param details details to modify the allegation role
   */
  @Override
  public void modifyAllegationRole(final AllegationRoleDetails details)
    throws AppException, InformationalException {

    curam.core.sl.fact.AllegationRoleFactory.newInstance()
      .modifyAllegationRole(details);

  }

  // ___________________________________________________________________________
  /**
   * Reads an allegation role for an allegation.
   *
   * @param key The identifier for the allegation to be read.
   */
  @Override
  public AllegationRoleParticipantListDetails readAllegationRole(
    final AllegationRoleKey key) throws AppException, InformationalException {

    AllegationRoleParticipantListDetails allegationRoleParticipantListDetails =
      new AllegationRoleParticipantListDetails();

    final curam.core.sl.intf.AllegationRole allegationRoleSLObj =
      curam.core.sl.fact.AllegationRoleFactory.newInstance();
    final curam.core.sl.entity.intf.AllegationRole allegationRoleEntityObj =
      curam.core.sl.entity.fact.AllegationRoleFactory.newInstance();
    final SearchCaseParticipantDetailsKey searchCaseParticipantDetailsKey =
      new SearchCaseParticipantDetailsKey();
    final AllegationKey allegationKey = new AllegationKey();

    allegationRoleParticipantListDetails =
      allegationRoleSLObj.readAllegationRole(key);

    allegationKey.allegationID =
      allegationRoleEntityObj.read(key).allegationID;

    searchCaseParticipantDetailsKey.caseID =
      curam.core.sl.entity.fact.AllegationFactory.newInstance()
        .read(allegationKey).caseID;

    allegationRoleParticipantListDetails.participantList =
      listCaseParticipant(searchCaseParticipantDetailsKey);

    return allegationRoleParticipantListDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates an allegation role for an allegation.
   *
   * @param key case id and allegation id
   * @param details details to modify the allegation role
   */
  @Override
  public void createAllegationRole(final AllegationKey key,
    final AllegationRoleDetails details)
    throws AppException, InformationalException {

    curam.core.sl.fact.AllegationRoleFactory.newInstance()
      .createAllegationRole(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Reads an allegation home page details.
   *
   * @param key key of the allegation
   * @return the allegation home page details
   */
  @Override
  public AllegationHomeDetails readAllegationHomeDetails(
    final AllegationKey key) throws AppException, InformationalException {

    final AllegationHomeDetails allegationHomeDetails =
      AllegationFactory.newInstance().readAllegationHomeDetails(key);

    return allegationHomeDetails;
  }

  // BEGIN, CR00165745, PDN
  // ___________________________________________________________________________
  /**
   * @param key Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchInvestigationDeliveryEventAndActivity1()}.
   *
   * This method returns data representing case events and activities for an
   * Investigation Delivery case.
   */
  @Override
  @Deprecated
  public InvestigationDeliveryEventAndActivityDetails
    searchInvestigationDeliveryEventAndActivity(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Return Struct
    final InvestigationDeliveryEventAndActivityDetails investigationDeliveryEventAndActivityDetails =
      new InvestigationDeliveryEventAndActivityDetails();

    // CalendarData manipulation variables
    final CalendarData calendarDataObj = CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // CaseDecision manipulation variables
    final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();
    boolean caseEventTypeDecisionInd = true;

    // ViewCaseEvents manipulation variables
    final ViewCaseEvents viewCaseEventsObj =
      ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey =
      new ViewCaseEventsByCaseIDAndTypeKey();

    // Calendar data variables
    final ActivityElementDetails activityElementDetails =
      new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();
    final CaseEventAndActivityDetails caseEventAndActivityDetails =
      new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;
    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList =
      viewCaseEventsObj.readEventsByType(viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    // BEGIN, CR00113566, JMA
    final StringBuffer xmlString =
      new StringBuffer(2048 * viewCaseEventDetailsList.dtls.size());

    // END, CR00113566
    // BEGIN, CR00113566, JMA
    // BEGIN, CR00163098, JC
    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
      .append(CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASE,
        TransactionInfo.getProgramLocale()))
      .append(kQuote).append(kCloseBracket).append(CuramConst.gkSpace);
    // END, CR00163098, JC
    // END, CR00113566
    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it is an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode
        .equals(CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID =
          viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd =
          viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode =
          curam.codetable.ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd =
          viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd =
          viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime =
          viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode =
          viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd =
          viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd =
          viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime =
          viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject =
          viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode =
          viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj
          .parseActivity(activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else { // It is an event

        eventElementDetails.eventStartDate =
          viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate =
          viewCaseEventDetailsList.dtls.item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID =
          viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription =
          viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date and end date are the same for events
        eventElementDetails.eventDate = new Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());
        eventElementDetails.eventType =
          viewCaseEventDetailsList.dtls.item(i).typeCode;

        // Check if this is a case decision event
        CaseDecisionDtls caseDecisionDtls = null;

        caseEventTypeDecisionInd = true;

        // Set key to read case decision
        caseDecisionKey.caseDecisionID =
          viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

        } catch (final RecordNotFoundException e) {

          // This is not a case decision event
          caseEventTypeDecisionInd = false;
        }

        // If this is a case decision event, only add to list if it is active
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode
            .equals(CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj
              .parseEvent(eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj
            .parseEvent(eventElementDetails, dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        } // end if caseEventTypeDecisionInd
      } // end if activity

    } // end for i

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);
    // BEGIN, CR00113566, JMA
    xmlString.append(CuramConst.gkSpace);
    // END, CR00113566
    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    investigationDeliveryEventAndActivityDetails.calendarDtls
      .assign(caseEventAndActivityDetails);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // Read context description and assign to return object
    investigationDeliveryEventAndActivityDetails.contextDescription.description =
      getContextDescription(caseHeaderKey).description;

    return investigationDeliveryEventAndActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method returns data representing case events and activities for an
   * Investigation Delivery case.
   *
   * @param key Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   */
  @Override
  public InvestigationDeliveryEventAndActivityDetails1
    searchInvestigationDeliveryEventAndActivity1(
      final SearchCaseEventAndActivityKey key)
      throws AppException, InformationalException {

    // Return Struct
    final InvestigationDeliveryEventAndActivityDetails1 investigationDeliveryEventAndActivityDetails1 =
      new InvestigationDeliveryEventAndActivityDetails1();

    // CalendarData manipulation variables
    final CalendarData calendarDataObj = CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // CaseDecision manipulation variables
    final CaseDecision caseDecisionObj = CaseDecisionFactory.newInstance();
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();
    boolean caseEventTypeDecisionInd = true;

    // ViewCaseEvents manipulation variables
    final ViewCaseEvents viewCaseEventsObj =
      ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey =
      new ViewCaseEventsByCaseIDAndTypeKey();

    // Calendar data variables
    final ActivityElementDetails activityElementDetails =
      new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();
    final CaseEventAndActivityDetails caseEventAndActivityDetails =
      new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;
    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList =
      viewCaseEventsObj.readEventsByType(viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString =
      new StringBuffer(2048 * viewCaseEventDetailsList.dtls.size());

    xmlString.append(kCuramCalendarDataHeader).append(kQuote)
      .append(CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASE))
      .append(kQuote).append(kCloseBracket).append(CuramConst.gkSpace);

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it is an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode
        .equals(CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID =
          viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd =
          viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode =
          curam.codetable.ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd =
          viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd =
          viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime =
          viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode =
          viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd =
          viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd =
          viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime =
          viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject =
          viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode =
          viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj
          .parseActivity(activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else { // It is an event

        eventElementDetails.eventStartDate =
          viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate =
          viewCaseEventDetailsList.dtls.item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID =
          viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription =
          viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date and end date are the same for events
        eventElementDetails.eventDate = new Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());
        eventElementDetails.eventType =
          viewCaseEventDetailsList.dtls.item(i).typeCode;

        // Check if this is a case decision event
        CaseDecisionDtls caseDecisionDtls = null;

        caseEventTypeDecisionInd = true;

        // Set key to read case decision
        caseDecisionKey.caseDecisionID =
          viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

        } catch (final RecordNotFoundException e) {

          // This is not a case decision event
          caseEventTypeDecisionInd = false;
        }

        // If this is a case decision event, only add to list if it is active
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode
            .equals(CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj
              .parseEvent(eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj
            .parseEvent(eventElementDetails, dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        } // end if caseEventTypeDecisionInd
      } // end if activity

    } // end for i

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(kCuramCalendarDataFooter);
    xmlString.append(CuramConst.gkSpace);

    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Map to return object
    investigationDeliveryEventAndActivityDetails1.calendarDtls
      .assign(caseEventAndActivityDetails);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // Read context description and assign to return object
    investigationDeliveryEventAndActivityDetails1.contextDescription.description =
      getContextDescription(caseHeaderKey).description;

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      investigationDeliveryEventAndActivityDetails1.isCPMInstalled = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      investigationDeliveryEventAndActivityDetails1.isAppealsInstalled = true;
    }

    return investigationDeliveryEventAndActivityDetails1;
  }

  // END, CR00165745

  // ___________________________________________________________________________
  /**
   * Removes a resolution from this Investigation. A change history record is
   * also
   * created.
   *
   * @param resolutionKey The identifier for the resolution to be removed.
   */
  @Override
  public void removeResolution(final ResolutionKey resolutionKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      curam.core.sl.fact.InvestigationDeliveryFactory.newInstance();

    investigationDeliveryObj.removeResolution(resolutionKey);
  }

  // ___________________________________________________________________________
  /**
   * Approves an investigation delivery.
   *
   * @param key The identifier of the case being approved.
   */
  @Override
  public void approve(final ProductDeliveryApprovalKey key)
    throws AppException, InformationalException {

    InvestigationDeliveryFactory.newInstance().approve(key);

  }

  // BEGIN, CR00246335, PB
  // ___________________________________________________________________________
  /**
   * @param details Details of the case to be closed.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #close1()}.
   * Closes an investigation delivery.
   */
  @Override
  @Deprecated
  public void close(final CloseCaseDetails details)
    throws AppException, InformationalException {

    final ClosureDtls closureDtls = new ClosureDtls();

    closureDtls.assign(details);

    InvestigationDeliveryFactory.newInstance().closeCase(closureDtls);

  }

  // END, CR00246335
  // ___________________________________________________________________________
  /**
   * This process will modify the closure details for a case.
   *
   * @param details The case closure details.
   */
  @Override
  public void modifyClosureDetails(final CloseCaseDetails details)
    throws AppException, InformationalException {

    final ClosureDtls closureDtls = new ClosureDtls();

    closureDtls.assign(details);

    InvestigationDeliveryFactory.newInstance().modifyCaseClosure(closureDtls);

  }

  // ___________________________________________________________________________
  /**
   * This process will read the closure details for a case.
   *
   * @param key The case identifier.
   *
   * @return Details of the case closure.
   */
  @Override
  public ClosureDetails readClosureDetails(final CaseHeaderKey key)
    throws AppException, InformationalException {

    // Create a return object
    final ClosureDetails closureDetails = new ClosureDetails();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    caseHeaderKey.caseID = key.caseID;

    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (!(caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)
      || caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED))) {
      // BEGIN, CR00163236, CL
      closureDetails.closureDetailsMsg = new LocalisableString(
        curam.message.BPOMAINTAINCASECLOSURE.ERR_CASECLOSURE_FV_NO_CLOSURE)
          .getMessage(TransactionInfo.getProgramLocale());
      // END, CR00163236
    } else {

      closureDetails.closureDetailsFlag = true;

      // Call MaintainCaseClosure BPO to read closure details
      final ClosureDtls closureDtls =
        InvestigationDeliveryFactory.newInstance().readClosureDetails(key);

      // Assign the case closure details to the return object
      closureDetails.assign(closureDtls);
    }

    return closureDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key Details of the case to be rejected.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #reject1()}.
   *
   * Rejects an investigation delivery case.
   */
  @Override
  @Deprecated
  public void reject(final ProductDeliveryApprovalKey key)
    throws AppException, InformationalException {

    InvestigationDeliveryFactory.newInstance().reject(key);

  }

  // ___________________________________________________________________________
  /**
   * Reopens an investigation delivery.
   *
   * @param details Details of the case being reopened.
   */
  @Override
  public void reopen(final ReactivationDetails details)
    throws AppException, InformationalException {

    final ReactivationDtls reactivationDtls = new ReactivationDtls();

    reactivationDtls.assign(details);

    InvestigationDeliveryFactory.newInstance().reopen(reactivationDtls);

  }

  // ___________________________________________________________________________
  /**
   * This process will submit an investigation delivery case for approval.
   *
   * @param key The case identifier.
   *
   * @return Message details list.
   */
  @Override
  public ApprovalMessageList submitForApproval(final CaseHeaderKey key)
    throws AppException, InformationalException {

    return InvestigationDeliveryFactory.newInstance().submitForApproval(key);
  }

  // ___________________________________________________________________________
  /**
   * A method to modify a header for an investigation delivery.
   *
   * @param details The details of the header to be modified.
   */
  @Override
  public void modifyHeader(final InvestigationHeaderDetails details)
    throws AppException, InformationalException {

    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Modify the case header details
    InvestigationDeliveryFactory.newInstance().modifyHeader(details);

    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls
        .addRef(informationalMsgDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads investigation case header details.
   *
   * @param key Contains the case identifier.
   *
   * @return Investigation Case header details.
   */
  @Override
  public InvestigationHeaderDetails readHeader(final CaseHeaderKey key)
    throws AppException, InformationalException {

    return InvestigationDeliveryFactory.newInstance().readHeader(key);
  }

  // ___________________________________________________________________________
  /**
   * Reads investigation related case type and primary client to be used when
   * creating an investigation case.
   *
   * @param key Contains the case identifier.
   *
   * @return Contains an indicator to show if the related case is an
   * integrated case and contains the primary client details.
   */
  @Override
  public InvestigationIntegratedIndPrimaryClient
    getRelatedCaseTypeAndPrimaryClient(final CaseHeaderKey key)
      throws AppException, InformationalException {

    final InvestigationIntegratedIndPrimaryClient investigationIntegratedIndPrimaryClient =
      new InvestigationIntegratedIndPrimaryClient();

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(key);

    if (caseHeaderDtls.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {

      investigationIntegratedIndPrimaryClient.integratedCaseInd = true;

    } else {

      investigationIntegratedIndPrimaryClient.integratedCaseInd = false;
      investigationIntegratedIndPrimaryClient.primaryClientID =
        caseHeaderDtls.concernRoleID;
    }

    return investigationIntegratedIndPrimaryClient;
  }

  // BEGIN, CR00113516, SD
  // ___________________________________________________________________________
  /**
   * @param key The case ID of the investigation delivery case.
   *
   * @return The investigation delivery case homepage details.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #readIntegratedInvestigationHomeDetails1()}.
   *
   * This method is used to display the integrated investigation delivery case
   * homepage, with the integrated menu details.
   */
  @Override
  @Deprecated
  public IntegratedInvestigationHomeDtls
    readIntegratedInvestigationHomeDetails(final InvestigationDeliveryKey key)
      throws AppException, InformationalException {

    final IntegratedInvestigationHomeDtls integratedInvestigationHomeDtls =
      new IntegratedInvestigationHomeDtls();

    // BEGIN, CR00220971, ZV
    integratedInvestigationHomeDtls
      .assign(readIntegratedInvestigationHomeDetails1(key));
    // END, CR00220971

    return integratedInvestigationHomeDtls;
  }

  // ___________________________________________________________________________
  /**
   * This method indicates if the investigation delivery is associated with an
   * integrated case. Returns true if it is an integrated investigation.
   *
   * @param key The case ID of the investigation delivery case.
   *
   * @return The indicator to show if it is an integrated investigation.
   */
  @Override
  public CuramInd resolveIntegratedInvestigation(final CaseHeaderKey key)
    throws AppException, InformationalException {

    final CuramInd result = new CuramInd();

    result.statusInd = false;

    if (CaseHeaderFactory.newInstance().read(key).integratedCaseID != 0) {

      result.statusInd = true;
    }

    return result;
  }

  // END, CR00113516

  // BEGIN, CR00119327, ZV
  // ___________________________________________________________________________
  /**
   * This method reads Action details and associated Allegation details list.
   *
   * @param key The action id.
   *
   * @return The Action details and associated Allegation details list.
   */
  @Override
  public ActionAndAllegationDetails readActionAndAllegationDetails(
    final ActionKey key) throws AppException, InformationalException {

    // Action service object
    final curam.core.sl.intf.Action actionObj =
      curam.core.sl.fact.ActionFactory.newInstance();

    // read and return action details and associated allegation details list
    return actionObj.readWithAllegation(key);
  }

  // ___________________________________________________________________________
  /**
   * Method to list allegation details list which are not associated to an
   * action and are assigned to provided case id
   *
   * @param key The case id
   *
   * @return The not associated allegations details list
   */
  @Override
  public curam.core.sl.struct.AllegationDetailsList listUnassignedAllegation(
    final CaseKey key) throws AppException, InformationalException {

    // allegation service object
    final Allegation allegationObj = AllegationFactory.newInstance();

    // return allegation details list
    return allegationObj.listUnassignedAllegation(key);
  }

  // END, CR00119327

  // BEGIN, CR00119578, ZV
  // ___________________________________________________________________________
  /**
   * Method to associate Action to an Allegation
   *
   * @param details Contains action id, allegation id
   *
   * @return The created action child link key
   */
  @Override
  public ActionChildLinkKey
    createActionAllegationAssociation(final ActionChildLinkDtls details)
      throws AppException, InformationalException {

    // Action Child Link entity object and return variable
    final curam.core.sl.entity.intf.ActionChildLink actionChildLinkObj =
      curam.core.sl.entity.fact.ActionChildLinkFactory.newInstance();
    final ActionChildLinkKey actionChildLinkKey = new ActionChildLinkKey();

    // set action child type to allegation
    details.childType = curam.codetable.ACTIONCHILDTYPE.ALLEGATION;

    // create action association to an allegation
    actionChildLinkObj.insert(details);

    // set action child link key
    actionChildLinkKey.actionChildLinkID = details.actionChildLinkID;

    // return created action child link key
    return actionChildLinkKey;

  }

  // END, CR00119578

  // BEGIN, CR00119496, JMA
  // ___________________________________________________________________________
  /**
   * Creates an action plan for a case.
   *
   * @param details - details to create the action plan
   */
  @Override
  public void createActionPlan(final CreateActionPlanDetails details)
    throws AppException, InformationalException {

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();

    caseActionPlanObj.create(details);
  }

  // ___________________________________________________________________________
  /**
   * Lists action plans for a case.
   *
   * @param linkKey Key to list the action plans
   * @return List of allegations
   */
  @Override
  public InvestigationDeliveryActionPlanList listActionPlans(
    final LinkKey linkKey) throws AppException, InformationalException {

    final InvestigationDeliveryActionPlanList investigationDeliveryActionPlanList =
      new InvestigationDeliveryActionPlanList();

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    investigationDeliveryActionPlanList.actionPlanListDtlsList =
      caseActionPlanObj.list(linkKey);

    caseHeaderKey.caseID = linkKey.linkID;

    investigationDeliveryActionPlanList.contextDescription.description =
      getContextDescription(caseHeaderKey).description;

    return investigationDeliveryActionPlanList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies an action plan for a case.
   *
   * @param details - details to modify the action plan
   */
  @Override
  public void modifyActionPlan(final ActionPlanDtls details)
    throws AppException, InformationalException {

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();

    caseActionPlanObj.modify(details);
  }

  // ___________________________________________________________________________
  /**
   * Reads an allegation for a case.
   *
   * @param key - Key to read the action plan
   */
  @Override
  public ActionPlanDtls readActionPlan(final ActionPlanKey key)
    throws AppException, InformationalException {

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();

    return caseActionPlanObj.read(key);

  }

  // ___________________________________________________________________________
  /**
   * Cancels an action plan for a case.
   *
   * @param key - Key to read the allegation
   */
  @Override
  public void cancelActionPlan(final CancelActionPlanKey key)
    throws AppException, InformationalException {

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();

    caseActionPlanObj.cancel(key);

  }

  // END, CR00119496

  // BEGIN, CR00119850, ZV
  // ___________________________________________________________________________
  /**
   * @param details Contains action details and action plan id
   *
   * @return The created action key
   * @deprecated Since Curam 6.0, as part of the Action Plan Enhancement,
   * replaced by
   * {@link #curam.core.facade.impl.Action.createAction1(CreateActionDetails1)},
   * as the situation details are captured independent of the action.
   * See release note: <CEF-722> : ActionPlan Enhancement
   *
   * Method to associate create Action and associate it to Action Plan
   */
  @Override
  @Deprecated
  public ActionKey
    createActionForActionPlan(final CreateActionDetails details)
      throws AppException, InformationalException {

    // Action facade object and return variable
    final curam.core.facade.intf.Action actionObj =
      curam.core.facade.fact.ActionFactory.newInstance();
    final ActionKey actionKey = new ActionKey();

    // set action parent type to action plan
    details.actionDetails.parentType =
      curam.codetable.ACTIONPARENTTYPE.ACTIONPLAN;

    // create action plan association to an action
    actionObj.createAction(details);

    // set action key
    actionKey.actionID = details.actionDetails.dtls.actionID;

    // return created action key
    return actionKey;
  }

  // ___________________________________________________________________________
  /**
   * Reads an action plan details and associated action details list.
   *
   * @param key Action Plan key
   *
   * @return action plan details and associated action details list
   */
  @Override
  public ActionPlanAndActionDetails readActionPlanAndAction(
    final ActionPlanKey key) throws AppException, InformationalException {

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();

    return caseActionPlanObj.readActionPlanAndAction(key);

  }

  // END, CR00119850

  // ___________________________________________________________________________
  /**
   * Prints Action Plan details and Action details list.
   *
   * @param key Contains action plan key
   *
   * @return The file name and document data
   */
  @Override
  public PrintActionPlanDetails printActionPlan(final ActionPlanKey key)
    throws AppException, InformationalException {

    // Case Action Plan service object
    final curam.core.sl.intf.CaseActionPlan actionPlanObj =
      curam.core.sl.fact.CaseActionPlanFactory.newInstance();

    // print Action Plan details
    return actionPlanObj.print(key);

  }

  // BEGIN, CR00120720, ZV
  // ___________________________________________________________________________
  /**
   * Method to add an Attachment to an Allegation.
   *
   * @param details Contains the allegation id and attachment details
   *
   * @return The Attachment Link key
   */
  @Override
  public AttachmentLinkKey
    createAllegationAttachment(final AttachmentLinkDetails details)
      throws AppException, InformationalException {

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    final AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType =
      ATTACHMENTOBJECTLINKTYPE.ALLEGATION;
    details.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

    final Allegation allegationObj = AllegationFactory.newInstance();
    final AllegationKey allegationKey = new AllegationKey();

    allegationKey.allegationID = details.attachmentLinkDtls.relatedObjectID;

    final AllegationAndFindingDetails allegationDtls =
      allegationObj.read(allegationKey);

    if (allegationDtls.allegationDtls.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      final AppException e = new AppException(
        BPOALLEGATION.ERR_ALLEGATION_ATTACHMENT_NOT_INSERTED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(e.arg(true), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

      informationalManager.failOperation();
    }
    //
    // populate meta data for the attachment
    //
    allegationKey.allegationID = details.attachmentLinkDtls.relatedObjectID;
    final long caseID = allegationDtls.allegationDtls.caseID;

    // BEGIN, CR00354960, CD
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID, Long.toString(caseID));
    // END, CR00354960

    // add allegation attachment
    attachmentLink.insert(details);

    final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

    attachmentLinkKey.attachmentLinkID = attachmentLink.getID();

    return attachmentLinkKey;
  }

  // END, CR00120720

  // BEGIN, CR00121009, ZV
  // ___________________________________________________________________________
  /**
   * Method to create an Incident association to Investigation Delivery.
   *
   * @param details Contains the Incident link details for association
   *
   * @return The created incident link key
   */
  @Override
  public IncidentLinkKey
    createIncidentAssociation(final IncidentLinkDtls details)
      throws AppException, InformationalException {

    Incident incident = incidentDAO.newInstance();

    incident = incidentDAO.get(details.incidentID);

    final IncidentLink incidentLink = incidentLinkDAO.newInstance();

    incidentLink.setIncident(incident);
    incidentLink.setRelatedObjectID(details.relatedObjectID);
    incidentLink.setRelatedObjectType(INCIDENTOBJECTLINKTYPEEntry.CASE);

    // add incident link
    incidentLink.insert();

    final IncidentLinkKey incidentLinkKey = new IncidentLinkKey();

    incidentLinkKey.incidentLinkID = incidentLink.getID();

    return incidentLinkKey;

  }

  // BEGIN, CR00121165, ZV
  // ___________________________________________________________________________
  /**
   * Lists Incidents not associated to Investigation delivery but associated to
   * provided concern role.
   *
   * @param key Contains case id and concern role id
   *
   * @return List of Incidents not associated to Investigation delivery
   */
  @Override
  public InvestigationDeliveryIncidentDetailsList
    listUnassociatedIncidentForInvestigationDelivery(
      final CaseIDAndConcernRoleIDKey key)
      throws AppException, InformationalException {

    // InvestigationDelivery service object
    final curam.core.sl.intf.InvestigationDelivery investigationDeliveryObj =
      curam.core.sl.fact.InvestigationDeliveryFactory.newInstance();

    // call service method to list Incidents not associated to
    return investigationDeliveryObj
      .listUnassociatedIncidentForInvestigationDelivery(key);
  }

  // END, CR00121009

  // ___________________________________________________________________________
  /**
   * Cancels an incident association.
   *
   * @param details - incident link id and version no
   */
  @Override
  public void
    cancelIncidentAssociation(final CancelIncidentLinkDetails details)
      throws AppException, InformationalException {

    incidentLinkDAO.get(details.incidentLinkID).cancel(details.versionNo);
  }

  // END, CR00121165

  // BEGIN, CR00121630, ZV
  // ___________________________________________________________________________
  /**
   * Creates an assessment delivery on the Investigation Case.
   *
   * @param key
   * Contains assessment delivery details.
   *
   * @return Assessment delivery caseID.
   */
  @Override
  public CreateAssessmentDeliveryDetails
    createAssessment(final CreateAssessmentDeliveryKey key)
      throws AppException, InformationalException {

    // Create return object
    final CreateAssessmentDeliveryDetails createAssessmentDeliveryDetails =
      new CreateAssessmentDeliveryDetails();

    // Assessment Delivery manipulation variables
    final curam.core.sl.intf.AssessmentDelivery assessmentDeliveryObj =
      curam.core.sl.fact.AssessmentDeliveryFactory.newInstance();
    CreateAssessmentDeliveryResult createAssessmentDeliveryResult;
    final curam.core.sl.struct.CreateAssessmentDeliveryKey createAssessmentDeliveryKey =
      new curam.core.sl.struct.CreateAssessmentDeliveryKey();

    // set details for creation
    createAssessmentDeliveryKey.assign(key.dtls);

    // create AssessmentDelivery
    createAssessmentDeliveryResult = assessmentDeliveryObj
      .createAssessmentOnInvC(createAssessmentDeliveryKey);

    // assign return data
    createAssessmentDeliveryDetails.dtls
      .assign(createAssessmentDeliveryResult);

    return createAssessmentDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * This process will return a list of assessments on an Investigation Case.
   *
   * @param key investigation case id.
   *
   * @return List of assessment details.
   */
  @Override
  public InvestigationDeliveryAssessmentList
    listAssessment(final ListICAssessmentKey key)
      throws AppException, InformationalException {

    // Create return object
    final InvestigationDeliveryAssessmentList assessmentList =
      new InvestigationDeliveryAssessmentList();

    final CasesByCaseIDAndTypeKey casesByCaseIDAndTypeKey =
      new CasesByCaseIDAndTypeKey();

    // Set key to read assessments
    casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
    casesByCaseIDAndTypeKey.dtls.caseTypeCode =
      CASETYPECODE.ASSESSMENTDELIVERY;

    final AssessmentDelivery assessmentDeliveryObj =
      AssessmentDeliveryFactory.newInstance();

    assessmentList.assessmentList = assessmentDeliveryObj
      .listAssessmentCasesByIntegratedCaseID(casesByCaseIDAndTypeKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    assessmentList.contextDtls.description =
      getContextDescription(caseHeaderKey).description;

    return assessmentList;

  }

  // END, CR00121630

  // BEGIN, CR00176835, AK
  /**
   * Reads an action plan details and associated action details list.
   *
   * @param key Action Plan key
   *
   * @return action plan details and associated action details list
   */
  @Override
  public ActionPlanAndSituationDetails
    readActionPlanAndSituation(final ActionPlanKey actionPlanKey)
      throws AppException, InformationalException {

    final CaseActionPlan caseActionPlanObj =
      CaseActionPlanFactory.newInstance();

    return caseActionPlanObj.readActionPlanAndSituation(actionPlanKey);

  }

  // END, CR00176835

  // BEGIN, CR00203865, ZV
  // ___________________________________________________________________________
  /**
   * Returns initial details to populate my investigation search filter lists.
   *
   * @return Initial details to populate my investigation search filter lists.
   */
  @Override
  public MyInvestigationFilterList getMyInvestigationFilterList()
    throws AppException, InformationalException {

    final MyInvestigationFilterList myInvestigationFilterList =
      new MyInvestigationFilterList();

    myInvestigationFilterList.dtls =
      CaseSearchFactory.newInstance().getMyInvestigationFilterList();
    return myInvestigationFilterList;
  }

  // ___________________________________________________________________________
  /**
   * @return Details for the list of investigation found.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #investigationDefaultSearchByOwner1()}. This
   * method has been deprecated to introduce new message handling. See release
   * note: CR00284116.
   *
   * Search investigation by specified owner using default values.
   */
  @Override
  @Deprecated
  public InvestigationSearchByOwnerDetailsList
    investigationDefaultSearchByOwner()
      throws AppException, InformationalException {

    final InvestigationSearchByOwnerDetailsList investigationSearchByOwnerDetailsList =
      new InvestigationSearchByOwnerDetailsList();

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    final InvestigationSearchCriteria investigationSearchCriteria =
      new InvestigationSearchCriteria();

    final curam.core.struct.MyInvestigationFilterList filterList =
      caseSearchObj.getMyInvestigationFilterList();

    investigationSearchCriteria.assign(filterList);

    investigationSearchByOwnerDetailsList.dtls = CaseSearchFactory
      .newInstance().searchInvestigationByOwner(investigationSearchCriteria);

    return investigationSearchByOwnerDetailsList;
  }

  // BEGIN, CR00276421, ELG
  // ___________________________________________________________________________
  /**
   * Search investigation by owner using default values. Owner is current user.
   *
   * @return Details for the list of investigation found and list of
   * informational messages.
   */
  @Override
  public InvestigationSearchByOwnerResult investigationDefaultSearchByOwner1()
    throws AppException, InformationalException {

    final InvestigationSearchByOwnerResult investigationSearchByOwnerResult =
      new InvestigationSearchByOwnerResult();

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    final InvestigationSearchCriteria investigationSearchCriteria =
      new InvestigationSearchCriteria();

    final curam.core.struct.MyInvestigationFilterList filterList =
      caseSearchObj.getMyInvestigationFilterList();

    investigationSearchCriteria.assign(filterList);

    investigationSearchByOwnerResult.dtls = CaseSearchFactory.newInstance()
      .searchInvestigationByOwner(investigationSearchCriteria);

    collectInformationals(investigationSearchByOwnerResult.msgList);

    return investigationSearchByOwnerResult;

  }

  // ___________________________________________________________________________
  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * The list to add the informational messages to
   */
  protected void
    collectInformationals(final InformationalMsgDtlsList msgDtlsList) {

    // Get the list of informational messages
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;
      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }

  }

  // END, CR00276421

  // ___________________________________________________________________________
  /**
   * Stores user investigation search criteria values.
   *
   * @param caseSearchCriteria
   * User investigation search criteria values to be stored.
   */
  @Override
  public void storeInvestigationSearchCriteria(
    final InvestigationSearchCriteria details)
    throws AppException, InformationalException {

    CaseSearchFactory.newInstance().storeInvestigationSearchCriteria(details);
  }

  // END, CR00203865

  // BEGIN, CR00204411, ZV
  // ___________________________________________________________________________
  /**
   * Returns initial details to populate investigation search criteria.
   *
   * @return Initial details to populate investigation search criteria.
   */
  @Override
  public InitialInvestigationSearchCriteria getInvestigationSearchCriteria()
    throws AppException, InformationalException {

    return CaseSearchFactory.newInstance().getInvestigationSearchCiteria();
  }

  // ___________________________________________________________________________
  /**
   * @param searchCriteria
   * Contains the case search criteria.
   *
   * @return Details for the list of cases found.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #investigationSearch1()}. This
   * method has been deprecated to introduce new message handling. See release
   * note: CR00284116.
   *
   * Presentation layer method to search for a case.
   */
  @Override
  @Deprecated
  public InvestigationSearchList
    investigationSearch(final InvestigationSearchCriteria searchCriteria)
      throws AppException, InformationalException {

    final InvestigationSearchList investigationSearchList =
      new InvestigationSearchList();

    final CaseSearchRouter caseSearchRouterObj =
      CaseSearchRouterFactory.newInstance();

    investigationSearchList.listDtls =
      caseSearchRouterObj.investigationSearch(searchCriteria);

    return investigationSearchList;
  }

  // BEGIN, CR00276421, ELG
  // ___________________________________________________________________________
  /**
   * Presentation layer method to search for investigation cases.
   *
   * @param key
   * Contains the case search criteria.
   *
   * @return Details for the list of investigation cases found and list of
   * informational messages.
   */
  @Override
  public InvestigationSearchListStruct
    investigationSearch1(final InvestigationSearchCriteria key)
      throws AppException, InformationalException {

    final InvestigationSearchListStruct investigationSearchListStruct =
      new InvestigationSearchListStruct();

    final CaseSearchRouter caseSearchRouterObj =
      CaseSearchRouterFactory.newInstance();

    investigationSearchListStruct.listDtls =
      caseSearchRouterObj.investigationSearch(key);

    collectInformationals(investigationSearchListStruct.msgList);

    return investigationSearchListStruct;

  }

  // END, CR00276421

  // ___________________________________________________________________________
  /**
   * Returns list of active allegation role records for an investigation
   *
   * @param key Contains case id.
   *
   * @return active allegation role details list for an investigation
   */
  @Override
  public AllegationRoleDetailsList listActiveAllegationRole(
    final CaseIDKey key) throws AppException, InformationalException {

    final AllegationRoleDetailsList allegationRoleDetailsList =
      new AllegationRoleDetailsList();

    final AllegationRole allegationRoleObj =
      AllegationRoleFactory.newInstance();

    allegationRoleDetailsList.dtls =
      allegationRoleObj.listAllegationRoleByCase(key);

    return allegationRoleDetailsList;
  }

  // END, CR00204411

  // BEGIN, CR00220794, ZV
  // ___________________________________________________________________________
  /**
   * Rejects an investigation delivery case.
   *
   * @param key Details of the case to be rejected.
   */
  @Override
  public void reject1(final ProductDeliveryApprovalKey1 key)
    throws AppException, InformationalException {

    InvestigationDeliveryFactory.newInstance().reject1(key);

  }

  // END, CR00220794

  // BEGIN, CR00220971, ZV
  // ___________________________________________________________________________
  /**
   * This method is used to display the investigation delivery case homepage.
   *
   * @param key The case ID of the investigation delivery case.
   *
   * @return The investigation delivery case homepage details.
   */
  @Override
  public InvestigationHomePageDtls1
    readHomePageDetails1(final InvestigationDeliveryKey key)
      throws AppException, InformationalException {

    final InvestigationHomePageDtls1 investigationHomePageDtls =
      new InvestigationHomePageDtls1();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj =
      UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails =
      new UserRecentActionDetails();

    final InvestigationCaseHomeDetails investigationCaseHomeDetails =
      InvestigationDeliveryFactory.newInstance().readHomePageDetails(key);

    caseHeaderKey.caseID = key.caseID;

    // Populate return struct
    investigationHomePageDtls.dtls.assign(investigationCaseHomeDetails);
    investigationHomePageDtls.contextDtls.description =
      getContextDescription(caseHeaderKey).description;
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);

    // BEGIN, CR00150402, PDN
    // If the case is closed then need to populate the close details for the
    // case.
    if (investigationHomePageDtls.dtls.caseDtls.caseStatus
      .equals(curam.codetable.CASESTATUS.CLOSED)) {
      // Set the case close indicator
      investigationHomePageDtls.isCaseCloseInd = true;

      // BEGIN, CR00163265, PDN
      // Read and assign the closure details
      final MaintainCaseClosure MaintainCaseClosureObj =
        MaintainCaseClosureFactory.newInstance();

      final ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();

      readCaseClosureKey.caseID = key.caseID;

      final ClosureDtls closureDtls =
        MaintainCaseClosureObj.readCaseClosure(readCaseClosureKey);

      investigationHomePageDtls.closureDtls.assign(closureDtls);

      // Populate the user's full name
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = closureDtls.userName;
      // END, CR00163265

      investigationHomePageDtls.closureDtls.userFullName =
        usersObj.read(usersKey).fullName;

      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage =
        new LocalisableString(curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage
        .arg(investigationHomePageDtls.closureDtls.userFullName);

      // Add the closure date
      dateUserNameMessage
        .arg(investigationHomePageDtls.closureDtls.closureDate);
      // END, CR00166458

      investigationHomePageDtls.closureDtls.closureDateAndUserFullName =
        dateUserNameMessage.toClientFormattedText();
      // END, CR00163613

    }
    // END, CR00150402

    // BEGIN, CR00240786, MC
    investigationHomePageDtls.actionDisplayIndicators =
      setResolutionActionDisplayIndicators(investigationCaseHomeDetails);

    final Bookmark bookmarkObj = BookmarkFactory.newInstance();
    final CountCaseBookmarkKey countCaseBookmarkKey =
      new CountCaseBookmarkKey();

    countCaseBookmarkKey.dtls.userName = TransactionInfo.getProgramUser();
    countCaseBookmarkKey.dtls.caseID = key.caseID;

    // return number of case bookmarks for the current user
    final Count count = bookmarkObj.countCaseBookmark(countCaseBookmarkKey);

    // check if a case bookmark record exists, the default is false
    if (count.numberOfRecords > 0) {

      investigationHomePageDtls.caseIsUserBookmarkInd = true;
    }
    // END, CR00240786
    return investigationHomePageDtls;
  }

  // __________________________________________________________________________
  /**
   * Display the following actions based in the conditions described below:
   *
   * Add Resolution
   * Where no Resolution has been recorded and each Allegation associated
   * with the Investigation has a Finding recorded.
   *
   * Edit Resolution
   * Where Resolution is recorded and the Investigation status is not
   * Submitted, Approved or Closed.
   *
   * Remove Resolution
   * Where a Resolution is recorded and Investigation Status is Open or
   * Rejected.
   *
   * View Resolution History
   * Where there is a (or ever was) a resolution for this investigation
   *
   * @param investigationCaseHomeDetails the investigation details
   * @return ResolutionActionDisplayIndicators the indicators to display the
   * resolution menu actions.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ResolutionActionDisplayIndicators
    setResolutionActionDisplayIndicators(
      final InvestigationCaseHomeDetails investigationCaseHomeDetails)
      throws AppException, InformationalException {

    final ResolutionActionDisplayIndicators resolutionActionDisplayIndicators =
      new ResolutionActionDisplayIndicators();

    // You should not be able to add an allegation until all allegations have a
    // finding
    final boolean allegationsHaveFindings = findingRecordedForEachAllegation(
      investigationCaseHomeDetails.allegationDetailsList);

    boolean noResolutionRecordedInd = false;

    if (investigationCaseHomeDetails.resolutionDtls.resolutionID == 0
      || investigationCaseHomeDetails.resolutionDtls.resolutionStatus
        .equals(RESOLUTIONSTATUSCODE.CANCELED)) {
      noResolutionRecordedInd = true;
    }
    // If there is a resolution or the resolution has been cancelled display the
    // resolution history action.

    if (investigationCaseHomeDetails.resolutionInd.resolutionHistoryInd
      || !noResolutionRecordedInd) {
      resolutionActionDisplayIndicators.displayHistoryInd = true;
    }

    resolutionActionDisplayIndicators.displayAddInd =
      allegationsHaveFindings && noResolutionRecordedInd;

    // The edit resolution action should be displayed when there is a resolution
    // and the case status is not Submitted, Approved or Closed.
    final String statusCode =
      investigationCaseHomeDetails.caseDtls.caseStatus;

    resolutionActionDisplayIndicators.displayEditInd =
      !noResolutionRecordedInd && (!statusCode.equals(CASESTATUSEntry.CLOSED)
        || !statusCode.equals(CASESTATUSEntry.APPROVED)
        || !statusCode.equals(CASESTATUSEntry.COMPLETED));

    resolutionActionDisplayIndicators.displayCancelInd =
      !noResolutionRecordedInd && (!statusCode.equals(CASESTATUSEntry.OPEN)
        || !statusCode.equals(CASESTATUSEntry.REJECTED));

    return resolutionActionDisplayIndicators;
  }

  // __________________________________________________________________________
  /**
   * Checks that each allegation on the investigation has a finding recorded
   * for it.
   *
   * @param CaseHeader the case header for the Investigation.
   *
   * @return a boolean to state if the there are findings for each allegation
   * on the investigation.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean findingRecordedForEachAllegation(
    final curam.core.sl.struct.AllegationDetailsList allegationDetailsList)
    throws AppException, InformationalException {

    boolean allegationFindingsFound = true;

    if (allegationDetailsList.dtls.size() == 0) {

      allegationFindingsFound = false;

    } else {

      // Check that each allegation has a finding
      for (int i = 0; i < allegationDetailsList.dtls.size(); i++) {

        if (allegationDetailsList.dtls.item(i).recordStatus
          .equals(RECORDSTATUS.NORMAL)) {

          // Finding entity manipulation variables
          final curam.core.sl.entity.intf.Finding findingObj =
            curam.core.sl.entity.fact.FindingFactory.newInstance();
          final AllegationKey allegationKey = new AllegationKey();

          allegationKey.allegationID =
            allegationDetailsList.dtls.item(i).allegationID;

          // list finding details for allegation
          final FindingDtlsList findingDtlsList =
            findingObj.searchByAllegationID(allegationKey);

          if (findingDtlsList.dtls.size() == 0) {

            allegationFindingsFound = false;
            break;
          }
        }
      }
    }

    return allegationFindingsFound;
  }

  // END, CR00240786

  // ___________________________________________________________________________
  /**
   * This method is used to display the integrated investigation delivery case
   * homepage, with the integrated menu details.
   *
   * @param key The case ID of the investigation delivery case.
   *
   * @return The investigation delivery case homepage details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public IntegratedInvestigationHomeDtls1
    readIntegratedInvestigationHomeDetails1(
      final InvestigationDeliveryKey key)
      throws AppException, InformationalException {

    final IntegratedInvestigationHomeDtls1 integratedInvestigationHomeDtls =
      new IntegratedInvestigationHomeDtls1();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseKey caseKey = new CaseKey();

    // Read main home page details
    integratedInvestigationHomeDtls.homeDtls = readHomePageDetails1(key);

    caseHeaderKey.caseID = key.caseID;
    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    // Get the menu details for the integrated case
    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj =
      productHookManager.getMenuDataHook(caseTypeCode.caseTypeCode);

    integratedInvestigationHomeDtls.menuDtls =
      menuDataObj.getICInvestigationDeliveryMenuData(caseHeaderKey);

    return integratedInvestigationHomeDtls;
  }

  // END, CR00220971

  // BEGIN, CR00246335, PB
  // ___________________________________________________________________________
  /**
   * Closes an investigation delivery.
   *
   * @param details Details of the case to be closed.
   * @return Informational Messages list
   */
  @Override
  public InformationalMsgDtlsList close1(final CloseCaseDetails details)
    throws AppException, InformationalException {

    // Informational Manager handle
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    final ClosureDtls closureDtls = new ClosureDtls();

    closureDtls.assign(details);

    InvestigationDeliveryFactory.newInstance().closeCase(closureDtls);

    // obtain the informational(s) to be returned to the client
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (final String informationMsgTxt : warnings) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = informationMsgTxt;
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationalMsgDtlsList;
  }

  // END, CR00246335

  // BEGIN, CR00263993, JAF
  // ___________________________________________________________________________
  /**
   * Resolves the investigation home page name.
   *
   * @param key
   * Key to read the investigation home page name.
   *
   * @return
   * Contains the investigation home page name.
   */
  @Override
  public InvestigationHomePageName resolveInvestigationHomePageName(
    final ReadInvestigationHomePageNameKey key)
    throws AppException, InformationalException {

    final InvestigationHomePageName investigationHomePageName =
      new InvestigationHomePageName();

    final curam.core.sl.intf.InvestigationDelivery investigationDelivery =
      InvestigationDeliveryFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    InvestigationHeaderDetails investigationHeaderDetails;
    final InvestigationConfiguration investigationConfiguration =
      InvestigationConfigurationFactory.newInstance();
    final InvestigationConfigKey investigationConfigKey =
      new InvestigationConfigKey();

    caseHeaderKey.caseID = key.caseID;

    investigationHeaderDetails =
      investigationDelivery.readHeader(caseHeaderKey);

    investigationConfigKey.investigationConfigID =
      investigationHeaderDetails.investigationConfigID;

    if (investigationConfigKey.investigationConfigID == 0) {
      investigationHomePageName.homePageName = "";
    } else {
      investigationHomePageName.homePageName =
        investigationConfiguration.readInvestigationConfiguration(
          investigationConfigKey).dtls.homePageIdentifier;
    }

    return investigationHomePageName;
  }

  // END, CR00263993, JAF

  // BEGIN, CR00278002,DK
  /**
   * Counts if there are tasks active on the investigation to be closed. If
   * there are
   * active tasks an informational is returned.
   *
   * @return BPOCLOSECASE.INF_CLOSECASE_ACTIVE_TASKS If there are active tasks
   * on the case to be closed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public InformationalMsgDtlsList countActiveTasks(final CaseKey caseKey)
    throws AppException, InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();
    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey =
      new SearchTaskForConcernOrCaseKey();

    final SearchTasksForConcernAndCaseDetails searchTasksForConcernAndCaseDetails =
      new SearchTasksForConcernAndCaseDetails();

    searchTaskForConcernOrCaseKey.details.linkedID = caseKey.caseID;

    searchTasksForConcernAndCaseDetails.dtls =
      workAllocationTaskObj.listCaseTasks(searchTaskForConcernOrCaseKey);

    final int numTasks =
      searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.size();
    int numberOfTasks = numTasks;

    // check that each task is either COMPLETED or CLOSED
    for (int i = 0; i < numTasks; i++) {

      if (searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.item(i).status
        .equals(curam.codetable.TASKSTATUS.COMPLETED)) {
        numberOfTasks--;
      }
    }

    // Environment variable to define if a case can be closed without manually
    // closing all of the task on it first
    boolean closeCaseWithTasks = false;
    String closeCaseWithTasksProperty =
      Configuration.getProperty(EnvVars.ENV_CLOSE_CASE_WITH_TASKS);

    if (closeCaseWithTasksProperty.length() == 0
      || closeCaseWithTasksProperty == null) {
      closeCaseWithTasksProperty = EnvVars.ENV_CLOSE_CASE_WITH_TASKS_DEFAULT;
    }

    closeCaseWithTasks =
      closeCaseWithTasksProperty.equalsIgnoreCase(EnvVars.ENV_VALUE_YES);

    // If there are active tasks
    if (numberOfTasks > 0 && closeCaseWithTasks) {

      final AppException e = new AppException(
        curam.message.BPOCLOSECASE.INF_CLOSECASE_ACTIVE_TASKS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(e.arg(true), CuramConst.gkEmpty,
          curam.util.exception.InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }
  // END , CR00278002, DK

}
