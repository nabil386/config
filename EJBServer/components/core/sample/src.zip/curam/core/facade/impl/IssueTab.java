/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.core.facade.struct.IssueTabDetails;
import curam.core.sl.fact.IssueTabFactory;
import curam.core.sl.struct.CaseIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class IssueTab extends curam.core.facade.base.IssueTab {

  // __________________________________________________________________________
  /**
   * Read the details for the issue case tab details panel.
   *
   * @param CaseIDKey The unique identifier for the Issue case
   * @return IssueTabDetails Issue delivery tab details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public IssueTabDetails readIssueTabDetail(CaseIDKey caseIDKey)
    throws AppException, InformationalException {

    final IssueTabDetails issueTabDetails = new IssueTabDetails();

    issueTabDetails.dtls = IssueTabFactory.newInstance().readIssueTabDetail(
      caseIDKey);

    return issueTabDetails;
  }

}
