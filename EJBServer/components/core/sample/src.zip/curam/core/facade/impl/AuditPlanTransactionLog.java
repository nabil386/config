/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.AuditPlanTransactionLogKey;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.AuditPlanTransactionLogDAO;
import curam.core.facade.struct.AuditPlanTransactionLogDtls;
import curam.core.facade.struct.AuditPlanTransactionLogDtlsList;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import java.util.SortedSet;


/**
 * Facade Class for the Audit Plan Transaction Log implementation.
 *
 */
public abstract class AuditPlanTransactionLog extends curam.core.facade.base.AuditPlanTransactionLog {

  @Inject
  protected AuditPlanTransactionLogDAO auditPlanTransactionLogDAO;

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public AuditPlanTransactionLog() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of all transactions for a given audit plan.
   *
   * @param key - AuditPlanKey The audit plan id.
   *
   * @return AuditPlanTransactionLogDtlsList The list of transaction logs.
   */
  @Override
  public AuditPlanTransactionLogDtlsList listAllTransactions(AuditPlanKey key) throws AppException,
      InformationalException {

    final AuditPlanTransactionLogDtlsList auditPlanTransactionLogDtlsList = new AuditPlanTransactionLogDtlsList();

    // Return Struct
    final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.get(
      key.auditPlanID);

    final UsersKey usersKey = new UsersKey();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final SortedSet<curam.caseaudit.impl.AuditPlanTransactionLog> auditPlanTransactionLogList = auditPlanTransactionLogDAO.searchByAuditPlan(
      auditPlan);

    for (final curam.caseaudit.impl.AuditPlanTransactionLog auditPlanTransactionLog : auditPlanTransactionLogList) {

      final AuditPlanTransactionLogDtls auditPlanTransactionLogDtls = new AuditPlanTransactionLogDtls();

      auditPlanTransactionLogDtls.auditPlanID = auditPlanTransactionLog.getAuditPlan().getID();
      auditPlanTransactionLogDtls.description = auditPlanTransactionLog.getDescription();
      auditPlanTransactionLogDtls.transactionID = auditPlanTransactionLog.getID();
      auditPlanTransactionLogDtls.relatedID = auditPlanTransactionLog.getRelatedID();
      auditPlanTransactionLogDtls.transactionDateTime = auditPlanTransactionLog.getTransactionDateTime();
      auditPlanTransactionLogDtls.transactionType = auditPlanTransactionLog.getTransactionType().getCode();

      final String userName = auditPlanTransactionLog.getUserName();

      usersKey.userName = userName;

      auditPlanTransactionLogDtls.userName = userName;

      auditPlanTransactionLogDtls.name = userAccessObj.getFullName(usersKey).fullname;

      auditPlanTransactionLogDtlsList.dtlsList.addRef(
        auditPlanTransactionLogDtls);
    }

    return auditPlanTransactionLogDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of recent transactions for a given audit plan.
   *
   * @param key - AuditPlanKey The audit plan id.
   *
   * @return AuditPlanTransactionLogDtlsList The list of transaction logs.
   */
  @Override
  public AuditPlanTransactionLogDtlsList listRecentTransactions(
    AuditPlanKey key) throws AppException, InformationalException {

    final AuditPlanTransactionLogDtlsList allTransactions = listAllTransactions(
      key);
    final AuditPlanTransactionLogDtlsList filteredTransactions = new AuditPlanTransactionLogDtlsList();

    long numberOfTransactions = allTransactions.dtlsList.size();

    if (curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_AUDIT_PLAN_TRANSACTION_LOG_NO_OF_TRANSACTION)
        != null) {
      numberOfTransactions = Long.parseLong(
        curam.util.resources.Configuration.getProperty(
          EnvVars.ENV_AUDIT_PLAN_TRANSACTION_LOG_NO_OF_TRANSACTION));
    }

    if (allTransactions.dtlsList.size() > 0) {
      for (int i = 0; i < numberOfTransactions; i++) {

        // Number of Transaction Log records available is less than
        // configured max number of Transactions
        if (allTransactions.dtlsList.size() <= i) {
          break;
        }
        filteredTransactions.dtlsList.addRef(allTransactions.dtlsList.item(i));
      }
    }
    return filteredTransactions;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details of a given audit plan transaction.
   *
   * @param key - AuditPlanTransactionLogKey The audit plan transaction id.
   *
   * @return AuditPlanTransactionLogDtls The details of the audit plan
   * transaction.
   */
  @Override
  public AuditPlanTransactionLogDtls readAuditPlanTransaction(
    AuditPlanTransactionLogKey key) throws AppException,
      InformationalException {

    // Return Struct
    final AuditPlanTransactionLogDtls auditPlanTransactionLogDtls = new AuditPlanTransactionLogDtls();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final curam.caseaudit.impl.AuditPlanTransactionLog auditPlanTransactionLog = auditPlanTransactionLogDAO.get(
      key.transactionID);

    auditPlanTransactionLogDtls.auditPlanID = auditPlanTransactionLog.getAuditPlan().getID();
    auditPlanTransactionLogDtls.description = auditPlanTransactionLog.getDescription();
    auditPlanTransactionLogDtls.transactionID = auditPlanTransactionLog.getID();
    auditPlanTransactionLogDtls.relatedID = auditPlanTransactionLog.getRelatedID();
    auditPlanTransactionLogDtls.transactionDateTime = auditPlanTransactionLog.getTransactionDateTime();
    auditPlanTransactionLogDtls.transactionType = auditPlanTransactionLog.getTransactionType().getCode();

    final String userName = auditPlanTransactionLog.getUserName();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = userName;

    auditPlanTransactionLogDtls.userName = userName;

    auditPlanTransactionLogDtls.name = userAccessObj.getFullName(usersKey).fullname;

    return auditPlanTransactionLogDtls;
  }

}
