/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASETYPECODE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RELATEDCASEPRODUCTTYPE;
import curam.core.facade.fact.ProductFactory;
import curam.core.facade.intf.Product;
import curam.core.facade.struct.CreateICProductDetails;
import curam.core.facade.struct.CreatedCaseIDKey;
import curam.core.facade.struct.ICContextDescriptionDetails;
import curam.core.facade.struct.ICContextDescriptionKey_fo;
import curam.core.facade.struct.ICProductDeliveryContextDescription;
import curam.core.facade.struct.ICProductDeliveryContextDescriptionKey;
import curam.core.facade.struct.ICProductDeliveryMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.IntegratedCaseMenuDataDetails;
import curam.core.facade.struct.IntegratedCaseMenuDataKey;
import curam.core.facade.struct.ListICCaseRelationshipDetails;
import curam.core.facade.struct.ListICCaseRelationshipKey;
import curam.core.facade.struct.OutcomeNameAndIDDetailsList;
import curam.core.facade.struct.ReadICProductHomePageDetails1;
import curam.core.facade.struct.ReadICProductHomePageKey;
import curam.core.facade.struct.WarningsDtls;
import curam.core.facade.struct.WarningsDtlsList;
import curam.core.facade.struct.WizardProperties;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.MaintainCaseClosureFactory;
import curam.core.fact.ProductProvisionFactory;
import curam.core.fact.ProvisionLocationFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.ProductHookManager;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.MaintainCaseClosure;
import curam.core.intf.ProductProvision;
import curam.core.intf.ProvisionLocation;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.struct.IsEventDateListEnabledDetailsKey;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.struct.CaseConcernRoleName;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseIDAndTypeCodeKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.GetProductDeliveryDetailsResult;
import curam.core.struct.GetRelatedCasesKey;
import curam.core.struct.GetRelatedCasesList;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryHomeKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductKey;
import curam.core.struct.ProductKeyStruct;
import curam.core.struct.ProductProvisionDetails1List;
import curam.core.struct.ProductProvisionKey;
import curam.core.struct.ProductTypeCodeIn;
import curam.core.struct.ProvisionLocationDetailsStructRef1List;
import curam.core.struct.ReadCaseClosureKey;
import curam.core.struct.RegisterProductDeliveryDetails;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.core.struct.RelatedCaseProductType;
import curam.core.struct.UsersKey;
import curam.message.BPOBROADCASTTRIGGER;
import curam.message.BPOREFLECTION;
import curam.message.SEPARATOR;
import curam.util.administration.fact.CacheAdminFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


/*
 * Contains the create case function for a product on an Integrated
 * Case.
 */
public class IntegratedCaseProduct extends curam.core.facade.base.IntegratedCaseProduct {

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
    ProgramLocale.getDefaultServerLocale());

  protected static final int kBufSize = 256;

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // Add injection for using the new CaseTransactionLog API
  public IntegratedCaseProduct() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Method to return the wizard details for the integrated case product
   * delivery
   * creation wizard sample.
   *
   * @return The wizard details for the integrated case product delivery
   * creation
   * wizard sample.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public WizardProperties getICProductDeliveryCreateWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCreateDefaultICProductDeliveryWizardProperties;

    return wizardProperties;
  }

  /**
   * Creates a product delivery and associated evidence on an Integrated Case.
   *
   * @param details
   * Details to create the Integrated Case Product.
   *
   * @return The Case ID of the case created
   */
  @Override
  public CreatedCaseIDKey createCase(CreateICProductDetails details)
    throws AppException, InformationalException {

    // Create return object
    final CreatedCaseIDKey createdCaseIDKey = new CreatedCaseIDKey();

    // CreateProductDelivery manipulation variables
    final curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory.newInstance();
    final RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();
    final RegisterProductDeliveryDetails registerProductDeliveryDetails = new RegisterProductDeliveryDetails();

    registerProductDeliveryDetails.integratedCaseInd = true;

    // register the security implementation
    SecurityImplementationFactory.register();

    // MaintainCase manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Only get caseID & concernRoleID if a case participant role id exists
    if (details.caseParticipantRoleID != 0) {
      // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID
      // passed in.
      caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRoleID;

      caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDandParticipantID(
        caseParticipantRoleKey);

      // Assign caseID and concern role id details to the
      details.clientID = caseIDAndParticipantRoleIDDetails.participantRoleID;

      details.integratedCaseID = caseIDAndParticipantRoleIDDetails.caseID;
    }

    // Assign details to key
    registerProductDeliveryKey.assign(details);

    // BEGIN, CR00150534, JMA
    registerProductDeliveryKey.caseStartDate = Date.getCurrentDate();
    // BEGIN, CR00347149, KH
    // Use the base currency specified in the application properties
    String baseCurrency = Configuration.getProperty(EnvVars.ENV_BASECURRENCY);

    if (baseCurrency == null) {
      baseCurrency = EnvVars.ENV_BASECURRENCY_DEFAULT;
    }
    registerProductDeliveryKey.currencyType = baseCurrency;
    // END, CR00347149

    // Get Provider and Location details
    final ProductKey productKey = new ProductKey();
    // BEGIN, CR00220013, ZV
    ProductProvisionDetails1List productProvisionDetailsList = new ProductProvisionDetails1List();

    // END, CR00220013

    // Get productID from key
    productKey.productID = details.productID;

    final ProductProvision productProvisionObj = ProductProvisionFactory.newInstance();

    // BEGIN, CR00220013, ZV
    productProvisionDetailsList = productProvisionObj.searchProvisionByProductID1(
      productKey);
    // END, CR00220013
    // Value to compare earliest provision creation date
    Date earliestProvisionDate = new Date();
    final ProductProvisionKey productProvisionKey = new ProductProvisionKey();

    for (int i = 0; i < productProvisionDetailsList.dtls.size(); i++) {

      // Check that provision end date has not passed
      if (productProvisionDetailsList.dtls.item(i).endDate.after(
        Date.getCurrentDate())
          || productProvisionDetailsList.dtls.item(i).endDate.isZero()) {

        if (earliestProvisionDate.isZero()
          || productProvisionDetailsList.dtls.item(i).creationDate.before(
            earliestProvisionDate)) {

          earliestProvisionDate = productProvisionDetailsList.dtls.item(i).creationDate;

          registerProductDeliveryKey.productProviderID = productProvisionDetailsList.dtls.item(i).providerConcernRoleID;
          productProvisionKey.productProvisionID = productProvisionDetailsList.dtls.item(i).productProvisionID;
        }
      }
    }

    // get the provision location
    if (productProvisionKey.productProvisionID != 0) {

      final ProvisionLocation provisionLocationObj = ProvisionLocationFactory.newInstance();
      // BEGIN, CR00220013, ZV
      final ProvisionLocationDetailsStructRef1List provisionLocationDetailsStructRefList = provisionLocationObj.searchProvisionLocationByProvisionID1(
        productProvisionKey);
      // END, CR00220013

      // Value to compare earliest provision location creation date
      Date earliestProvisionLocationDate = new Date();

      for (int i = 0; i < provisionLocationDetailsStructRefList.dtls.size(); i++) {

        // Check that provision location end date has not passed
        if (productProvisionDetailsList.dtls.item(i).endDate.after(
          Date.getCurrentDate())
            || productProvisionDetailsList.dtls.item(i).endDate.isZero()) {

          if (earliestProvisionLocationDate.isZero()
            || provisionLocationDetailsStructRefList.dtls.item(i).creationDate.before(
              earliestProvisionDate)) {

            earliestProvisionLocationDate = provisionLocationDetailsStructRefList.dtls.item(i).creationDate;

            registerProductDeliveryKey.providerLocationID = provisionLocationDetailsStructRefList.dtls.item(i).providerLocationID;
          }
        }
      }
    }
    // END, CR00150534

    // Set the integrated case id as related case id
    registerProductDeliveryKey.relatedCaseID = details.integratedCaseID;

    // Call CreateProductDelivery BPO to register the new Product
    createdCaseIDKey.caseID = createProductDeliveryObj.registerProductDelivery(registerProductDeliveryKey, registerProductDeliveryDetails).caseID;

    final IsEventDateListEnabledDetailsKey isEventDateListEnabledDetailsKey = new IsEventDateListEnabledDetailsKey();

    isEventDateListEnabledDetailsKey.productID = details.productID;

    // BEGIN, CR00021498, NK
    createdCaseIDKey.warnings = getWarnings();
    // END, CR00021498

    return createdCaseIDKey;
  }

  /**
   * Extracts warning message from InformationManager and returns warning
   * details
   *
   * @return Warnings list
   */
  @Override
  public WarningsDtlsList getWarnings() throws AppException,
      InformationalException {

    final WarningsDtlsList warningsDtlsList = new WarningsDtlsList();
    // InformationalManager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Retrieve list of informational messages
    final String[] messages = informationalManager.obtainInformationalAsString();

    // Return the Informational messages
    for (int i = 0; i < messages.length; i++) {

      final WarningsDtls warningsDtls = new WarningsDtls();

      warningsDtls.warning = messages[i];
      warningsDtlsList.dtls.addRef(warningsDtls);
    }

    return warningsDtlsList;
  }

  /**
   * Lists all existing outcomes.
   *
   * @return List of existing outcome details (name and ID)
   */
  @Override
  public OutcomeNameAndIDDetailsList listAllExistingOutcomes()
    throws AppException, InformationalException {

    // return value
    final OutcomeNameAndIDDetailsList outcomeNameAndIDDetailsList = new OutcomeNameAndIDDetailsList();

    // Product Delivery Planned Item business object
    final curam.core.sl.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.fact.ProductDeliveryPlanItemLinkFactory.newInstance();

    // list all existing outcomes
    outcomeNameAndIDDetailsList.OutcomeNameAndIDDetailsList = productDeliveryPlanItemLinkObj.listAllExpectedOutcomes();

    // return the list
    return outcomeNameAndIDDetailsList;
  }

  @Override
  public ListICCaseRelationshipDetails listCaseRelationship(
    ListICCaseRelationshipKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListICCaseRelationshipDetails listICCaseRelationshipDetails = new ListICCaseRelationshipDetails();

    // MaintainRelatedCases manipulation variables
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();
    final GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // ICContextDescriptionKey facade object
    final ICContextDescriptionKey_fo icContextDescriptionKey = new ICContextDescriptionKey_fo();

    // CaseHeader object
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseKey caseKey;
    CaseTypeCode caseTypeCode = new CaseTypeCode();
    final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();
    RelatedCaseProductType relatedCaseProductType;

    // IntegratedCaseMenuDataKey object
    final IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

    // Set key to read the related cases
    getRelatedCasesKey.assign(key);

    // Call MaintainRelatedCases BPO to retrieve the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj.getRelatedCases(
      getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      listICCaseRelationshipDetails.dtls.ensureCapacity(
        getRelatedCasesList.dtls.size());

      // Assign details to return object
      listICCaseRelationshipDetails.assign(getRelatedCasesList);

      for (int i = 0; i < getRelatedCasesList.dtls.size(); i++) {
        caseKey = new CaseKey();
        caseKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
        caseIDAndTypeCodeKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        relatedCaseProductType = maintainRelatedCasesObj.getRelatedCaseProductType(
          caseIDAndTypeCodeKey);
        final String typeCode = relatedCaseProductType.relatedCaseProductType;

        // BEGIN, CR00391388, CW
        // Do not include product type of related case if the field is empty
        if (!typeCode.isEmpty() && !alreadyExists(typeCode)) {
          // END, CR00391388
          final ReadICProductHomePageKey homePageKey = new ReadICProductHomePageKey();

          homePageKey.caseID = caseKey.caseID;

          final ReadICProductHomePageDetails1 homePageDetails = readICProductHomePageDetails(
            homePageKey);

          final Product productObj = ProductFactory.newInstance();
          final ProductKeyStruct productKeyStruct = new ProductKeyStruct();

          productKeyStruct.productID = homePageDetails.details.productID;

          final ProductTypeCodeIn productTypeCodeIn = productObj.readProductTypeByProductID(
            productKeyStruct);
          final String productType = CodeTable.getOneItem(
            curam.codetable.PRODUCTTYPE.TABLENAME, productTypeCodeIn.typeCode);

          CodeTable.addCodeTableItem(
            curam.codetable.RELATEDCASEPRODUCTTYPE.TABLENAME,
            relatedCaseProductType.relatedCaseProductType, productType,
            StringHelper.EMPTY_STRING, true, CuramConst.gkZero,
            TransactionInfo.getProgramLocale());
          CacheAdminFactory.newInstance().reloadCodetableCache();
        }

        listICCaseRelationshipDetails.dtls.item(i).relatedCaseProductTypeCode = relatedCaseProductType.relatedCaseProductType;
        // BEGIN, CR00427963, KRK
        listICCaseRelationshipDetails.dtls.item(i).relatedCaseNameOpt = relatedCaseProductType.relatedCaseNameOpt;
        // END, CR00427963
      }

    }

    // Set key to read context description
    icContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listICCaseRelationshipDetails.contextDescription = getIntegratedCaseContextDescription(
      icContextDescriptionKey);

    // Set key to read menu data
    integratedCaseMenuDataKey.caseID = key.caseID;

    // Read menu data and assign to return object
    listICCaseRelationshipDetails.icMenuData = getIntegratedCaseMenuData(
      integratedCaseMenuDataKey);

    return listICCaseRelationshipDetails;
  }

  /**
   * Generates the context description for an Integrated Case.
   *
   * @param key
   * Integrated case context description identifier.
   *
   * @return A context description for an Integrated Case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ICContextDescriptionDetails getIntegratedCaseContextDescription(
    ICContextDescriptionKey_fo key) throws AppException,
      InformationalException {

    // Create return object
    final ICContextDescriptionDetails icContextDescriptionDetails = new ICContextDescriptionDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    ICHomePageNameAndType icHomePageNameAndType;

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Read caseHeader
    caseKey.caseID = key.caseID;
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    // Create the context description
    final StringBuffer buffer = new StringBuffer(kBufSize);

    // BEGIN, CR00163098, JC
    buffer.append(
      CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
      icHomePageNameAndType.integratedCaseType,
      TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    // BEGIN, CR00093978, SK
    buffer.append(kSpace);
    // END, CR00093978
    buffer.append(kSeparator);
    buffer.append(icHomePageNameAndType.caseReference);

    // Assign it to the return object
    icContextDescriptionDetails.description = buffer.toString();

    return icContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for the Integrated Case.
   *
   * @param key
   * Integrated Case identifier.
   *
   * @return Menu Data for the Integrated Case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected IntegratedCaseMenuDataDetails getIntegratedCaseMenuData(
    IntegratedCaseMenuDataKey key) throws AppException,
      InformationalException {

    // BEGIN, 100358, VM
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager.getMenuDataHook(
      caseTypeCode.caseTypeCode);

    return menuDataObj.getIntegratedCaseMenuData(key);
    // END, 100358
  }

  // ___________________________________________________________________________
  /**
   * Generates the context description for a product delivery on an Integrated
   * Case
   *
   * @param key
   * Contains the case identifier.
   *
   * @return A context description for a product delivery.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ICProductDeliveryContextDescription getICProductDeliveryContextDescription(
    ICProductDeliveryContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create the return object
    final ICProductDeliveryContextDescription icProductDeliveryContextDescription = new ICProductDeliveryContextDescription();

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component installation
    // setting. If the environment variable is present and set to 'true', run
    // the Reflection code.
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      // BEGIN, CR00023323, SK
      // BEGIN, CR00158377,RV
      final String className = ReflectionConst.coreToAppealDelegateWrapperClassName;
      // END, CR00158377
      // BEGIN, CR00065744, SK
      final String methodName = ReflectionConst.icProductDeliveryContextMethodName;
      // END, CR00065744
      // END, CR00023323
      // Set the arguments to pass through
      final Object[] arguments = new Object[] { key };

      // Set the passed class types to the method
      final Class[] parameterTypes = new Class[] {
        ICProductDeliveryContextDescriptionKey.class };

      return (ICProductDeliveryContextDescription) performReflection(className,
        methodName, arguments, parameterTypes);
    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseConcernRoleName caseConcernRoleName;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read ConcernRole
    // BEGIN CR00103984 SAI
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);
    // END CR00103984
    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read caseHeader
    caseKey.caseID = key.caseID;

    // Read caseHeader
    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    // Read productDelivery
    caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);

    // BEGIN CR00087948, CSH
    // BEGIN CR00077581, MC
    // BEGIN, CR00163098, JC
    // Assign it to the return object
    icProductDeliveryContextDescription.description = CodeTable.getOneItem(
      PRODUCTTYPE.TABLENAME, caseHomePageNameAndType.typeCode,
      TransactionInfo.getProgramLocale())
        // END, CR00163098, JC
        + GeneralConstants.kSpace
        + caseConcernRoleName.caseReference
        + GeneralConstants.kSpace
        + GeneralConstants.kMinus
        + GeneralConstants.kSpace
        // BEGIN CR00103984 SAI
        + concernRoleDtls.concernRoleName
        + GeneralConstants.kSpace
        + concernRoleDtls.primaryAlternateID;
    // END CR00103984
    // END CR00077581
    // END CR00087948
    return icProductDeliveryContextDescription;
  }

  /**
   * Execute reflection on the Argument Class and Method, using argument
   * parameters.
   *
   * @param className
   * Class name to instantiate
   * @param methodName
   * Method to be run
   * @param arguments
   * Arguments to be passed to Method
   * @param parameterTypes
   * Class Types of Parameters used
   *
   * @return Invoked method will return object which can be case by cast method.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Object performReflection(String className, String methodName,
    Object[] arguments, Class[] parameterTypes) throws AppException,
      InformationalException {

    Class cls = null;

    try {
      // Load the class
      cls = Class.forName(className);

      // Create a method for the static newInstance constructor
      // BEGIN, CR00023323, SK
      final Method constructorMethod = cls.getMethod(
        ReflectionConst.kNewInstance);
      // END, CR00023323
      final Object classObj = constructorMethod.invoke(cls);

      // Define the method
      // BEGIN, CR00142355, CD
      final Method method = classObj.getClass().getMethod(methodName,
        parameterTypes);

      // END, CR00142355

      // Now invoke the method
      return method.invoke(classObj, arguments);

    } catch (final IllegalAccessException e) {// ignore - biz methods MUST be
      // public
    } catch (final ClassNotFoundException e) {

      final AppException ae = new AppException(
        BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

      ae.arg(className);
      ae.arg(getClass().toString());
      // BEGIN, CR00163098, JC
      ae.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      throw new RuntimeException(ae);

    } catch (final NoSuchMethodException e) {

      final AppException ae = new AppException(
        BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

      ae.arg(className);

      // BEGIN, CR00049218, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00049218

      // BEGIN, CR00163098, JC
      ae.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      throw new RuntimeException(ae);

    } catch (final IllegalArgumentException e) {

      final AppException ae = new AppException(
        BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);

      // BEGIN, CR00049218, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00049218

      ae.arg(className);
      // BEGIN, CR00163098, JC
      ae.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      throw new RuntimeException(ae);

    } catch (final InvocationTargetException e) {

      final AppException exc = new AppException(
        BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

      exc.arg(e.getTargetException().getMessage());
      throw exc;
    }

    return null;
  }

  // ___________________________________________________________________________
  /**
   * Reads details to populate a Product Delivery home page on an Integrated
   * Case.
   *
   * @param key
   * Key to read Product Delivery details.
   *
   * @return Contains the home page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ReadICProductHomePageDetails1 readICProductHomePageDetails(
    ReadICProductHomePageKey key) throws AppException, InformationalException {

    // Create return object
    final ReadICProductHomePageDetails1 readICProductHomePageDetails = new ReadICProductHomePageDetails1();

    // Check if external adapters are set correctly
    initializeBroadcastTrigger();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final ProductDeliveryHomeKey productDeliveryHomeKey = new ProductDeliveryHomeKey();
    GetProductDeliveryDetailsResult getProductDeliveryDetailsResult;

    // ICProductDeliveryContextDescriptionKey object
    final ICProductDeliveryContextDescriptionKey icProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    // ICProductDeliveryMenuDataKey object
    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseIDParticipantRoleKey caseIDParticipantRoleKey = new curam.core.sl.entity.struct.CaseIDParticipantRoleKey();
    curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // Set key to read Product Delivery home page details
    productDeliveryHomeKey.caseID = key.caseID;

    // Read ProductDelivery home page details
    getProductDeliveryDetailsResult = productDeliveryHomeObj.getProductDeliveryDetails(
      productDeliveryHomeKey);

    // Assign home page details to output struct
    readICProductHomePageDetails.details.assign(
      getProductDeliveryDetailsResult.dtls);

    // BEGIN, CR00092078, SPD
    // Populate the bookmark indicator for the case
    readICProductHomePageDetails.caseIsUserBookmarkInd = getProductDeliveryDetailsResult.productDeliveryHomeIndicators.caseIsUserBookmarkInd;
    // END, CR00092078

    // Set key to read concernRoleName
    caseIDParticipantRoleKey.participantRoleID = getProductDeliveryDetailsResult.dtls.primaryClientID;
    caseIDParticipantRoleKey.caseID = key.caseID;

    // Reads caseParticipantRoleID
    caseParticipantRoleCaseParticipantRoleID = caseParticipantRole.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // Assign caseParticipantRoleID to the return object
    readICProductHomePageDetails.details.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    // set particiapntRoleId for the productProvider
    caseIDParticipantRoleKey.participantRoleID = readICProductHomePageDetails.details.productProviderID;

    // Reads caseParticipantRoleID for the productProvider
    caseParticipantRoleCaseParticipantRoleID = caseParticipantRole.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // Assign productProviderCaseParticipantRoleID to the return object
    readICProductHomePageDetails.details.productProviderCaseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    // Set key to read context description
    icProductDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    readICProductHomePageDetails.contextDescription = getICProductDeliveryContextDescription(
      icProductDeliveryContextDescriptionKey);

    // Set key to read menu data
    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // Read menu data
    readICProductHomePageDetails.menuData = getICProductDeliveryMenuData(
      icProductDeliveryMenuDataKey);

    // BEGIN, CR00022266, PA
    // Read Transaction Log Details

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN CR00108134, GBA
    readICProductHomePageDetails.transactionLogDtls.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134
    // END, CR00022266

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    // BEGIN, CR00150402, PDN
    // If the case is closed then need to populate the close details for
    // the case.
    if (readICProductHomePageDetails.details.caseStatusCode.equals(
      curam.codetable.CASESTATUS.CLOSED)) {
      // Set the closed indicator to closed.
      readICProductHomePageDetails.isCaseClosedInd = true;

      // Read and assign the closure details
      final MaintainCaseClosure MaintainCaseClosureObj = MaintainCaseClosureFactory.newInstance();

      final ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();

      readCaseClosureKey.caseID = readICProductHomePageDetails.details.caseID;

      final ClosureDtls closureDtls = MaintainCaseClosureObj.readCaseClosure(
        readCaseClosureKey);

      readICProductHomePageDetails.closureDtls.assign(closureDtls);

      // Populate the user's full name
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = closureDtls.userName;

      readICProductHomePageDetails.closureDtls.userFullName = usersObj.read(usersKey).fullName;

      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage = new LocalisableString(
        curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage.arg(
        readICProductHomePageDetails.closureDtls.userFullName);

      // Add the closure date
      dateUserNameMessage.arg(
        readICProductHomePageDetails.closureDtls.closureDate);
      // END, CR00166458

      readICProductHomePageDetails.closureDtls.closureDateAndUserFullName = dateUserNameMessage.toClientFormattedText();
      // END, CR00163613

    }
    // END, CR00150402

    return readICProductHomePageDetails;
  }

  /**
   * This method is to initialize registrar variables for the external adapter
   * This method will throw an AppException if the adapter registrars list
   * contains names not found in the system.
   *
   * @throws AppException
   * (BPOBROADCASTTRIGGER.ERR_REGISTRAR_ISSUE) if there was an issue
   * in the creation of the trigger.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static void initializeBroadcastTrigger() throws AppException,
      InformationalException {

    // Get the value of the broadcast trigger registrars environment variable

    String registrarsString = Configuration.getProperty(
      EnvVars.ERP_EXTERNAL_ADAPTER_REGISTRARS_LIST);

    // BEGIN, CR00090166, NP
    if (registrarsString == null) {
      registrarsString = EnvVars.ERP_EXTERNAL_ADAPTER_REGISTRARS_LIST_DEFAULT;
    }
    if (registrarsString.length() != 0) {
      // END, CR00090166
      // Get comma-separated list of registrar factory class names
      final String registrarFactoryNames[] = registrarsString.split(
        CuramConst.gkComma);

      // For each registrar factor name create an instance of it and add it the
      // broadcastTriggerInterfaces array
      for (int i = 0; i < registrarFactoryNames.length; i++) {

        final String registrarFactoryName = registrarFactoryNames[i];

        try {
          Class.forName(registrarFactoryName);

        } catch (final Exception e) {

          final AppException ae = new AppException(
            BPOBROADCASTTRIGGER.ERR_REGISTRAR_ISSUE);

          throw ae.arg(registrarFactoryName);

        }
      }
    }
  }

  /**
   * Generates the menu data for a Product Delivery on an Integrated Case.
   *
   * @param key
   * Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ICProductDeliveryMenuDataDetails getICProductDeliveryMenuData(
    ICProductDeliveryMenuDataKey key) throws AppException,
      InformationalException {

    // BEGIN, 100358, VM
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager.getMenuDataHook(
      caseTypeCode.caseTypeCode);

    return menuDataObj.getICProductDeliveryMenuData(key);
    // END, 100358
  }

  /**
   * Identify if the RelatedCaseProductType is already exists in the code
   * table.
   *
   * @param relatedCaseProductType
   * as String
   * @return boolean true if already exists.
   * @throws AppException
   * Generic {@link AppException}
   * @throws InformationalException
   * Generic {@link InformationalException}
   */
  protected boolean alreadyExists(String relatedCaseProductType)
    throws AppException, InformationalException {

    boolean isExists = false;
    final curam.util.administration.intf.CodeTableAdmin codeTableAdminObj = curam.util.administration.fact.CodeTableAdminFactory.newInstance();
    final curam.util.administration.struct.CodeTableAdminListAllItemsAndDefaultOut codeTableItemList = codeTableAdminObj.listAllItems(
      RELATEDCASEPRODUCTTYPE.TABLENAME.toString());

    for (int i = 0; i < codeTableItemList.dtls.size(); i++) {
      if (codeTableItemList.dtls.item(i).code.equalsIgnoreCase(
        relatedCaseProductType)) {
        isExists = true;
        break;
      }
    }
    return isExists;
  }
}
