/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2005, 2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.facade.infrastructure.impl;

import com.google.inject.Inject;
import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.DASHBOARDEVIDENCEREQUIRED;
import curam.codetable.EVIDENCECATEGORY;
import curam.codetable.EVIDENCECHANGEREASON;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.core.facade.infrastructure.struct.ActiveEvdInstanceDtls;
import curam.core.facade.infrastructure.struct.ActiveEvdInstanceDtlsList;
import curam.core.facade.infrastructure.struct.ActiveEvidenceDetails;
import curam.core.facade.infrastructure.struct.ActiveEvidenceDetailsList;
import curam.core.facade.infrastructure.struct.ApplyAllChangesReturnDtls;
import curam.core.facade.infrastructure.struct.ApplyChangesDetails;
import curam.core.facade.infrastructure.struct.ApplyChangesReturnDtls;
import curam.core.facade.infrastructure.struct.ApplyUserChangesReturnDtls;
import curam.core.facade.infrastructure.struct.ApprovedEvidenceApprovalRequestDetails;
import curam.core.facade.infrastructure.struct.AttributionDetailsList;
import curam.core.facade.infrastructure.struct.AutoEndDateEvidenceList;
import curam.core.facade.infrastructure.struct.AutoEndDateIndDetails;
import curam.core.facade.infrastructure.struct.CaseEvidenceDetails;
import curam.core.facade.infrastructure.struct.CaseEvidenceDetailsKey;
import curam.core.facade.infrastructure.struct.CaseIDAndEvidenceCategoryKey;
import curam.core.facade.infrastructure.struct.CaseIDAndLongEvidenceTypeList;
import curam.core.facade.infrastructure.struct.CaseIDEvdTypeAndDateRange;
import curam.core.facade.infrastructure.struct.CaseIDRelatedIDAndEvidenceTypeDtls;
import curam.core.facade.infrastructure.struct.CaseIDRelatedIDAndEvidenceTypeDtlsList;
import curam.core.facade.infrastructure.struct.CaseMembersAndTransferEvidenceList;
import curam.core.facade.infrastructure.struct.CountAutoEndDateEvidence;
import curam.core.facade.infrastructure.struct.CountAutoEndDateEvidenceKey;
import curam.core.facade.infrastructure.struct.DashboardFilterIDKey;
import curam.core.facade.infrastructure.struct.DetailsForEvidenceTransfer;
import curam.core.facade.infrastructure.struct.EvdInstanceChangeDtls;
import curam.core.facade.infrastructure.struct.EvdInstanceChangeDtlsList;
import curam.core.facade.infrastructure.struct.EvidenceCatDashboardDetails;
import curam.core.facade.infrastructure.struct.EvidenceCatDashboardDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceCategoryAndTypes;
import curam.core.facade.infrastructure.struct.EvidenceCategoryDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceContextDescription;
import curam.core.facade.infrastructure.struct.EvidenceCorrectionDtls;
import curam.core.facade.infrastructure.struct.EvidenceCorrectionDtlsList;
import curam.core.facade.infrastructure.struct.EvidenceDescriptorIDKey;
import curam.core.facade.infrastructure.struct.EvidenceDescriptorMultiSelectKey;
import curam.core.facade.infrastructure.struct.EvidenceDetails;
import curam.core.facade.infrastructure.struct.EvidenceDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceIssuesDetails;
import curam.core.facade.infrastructure.struct.EvidenceIssuesDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceKey;
import curam.core.facade.infrastructure.struct.EvidenceListDetails;
import curam.core.facade.infrastructure.struct.EvidenceListKey;
import curam.core.facade.infrastructure.struct.EvidenceObjectSummaryHeaderDetails;
import curam.core.facade.infrastructure.struct.EvidenceParticipantDtls;
import curam.core.facade.infrastructure.struct.EvidenceSiteMapDetails;
import curam.core.facade.infrastructure.struct.EvidenceTabSummaryHeaderDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeAndParticipantIDDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeDashboardDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeDashboardDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceTypeDescription;
import curam.core.facade.infrastructure.struct.EvidenceTypeDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeLimit;
import curam.core.facade.infrastructure.struct.EvidenceTypeWorkspaceListDetails;
import curam.core.facade.infrastructure.struct.ListAllActiveEVDInstanceWorkspaceDtls;
import curam.core.facade.infrastructure.struct.ListAllEvidenceDtls;
import curam.core.facade.infrastructure.struct.ListAllForActiveWorkspaceDtls;
import curam.core.facade.infrastructure.struct.ListAllForInEditWorkspaceDtls;
import curam.core.facade.infrastructure.struct.ListAllInEditDtls;
import curam.core.facade.infrastructure.struct.ListAutoEndDateEvidenceKey;
import curam.core.facade.infrastructure.struct.ListEvidenceChangeHistoryResult;
import curam.core.facade.infrastructure.struct.ListICAttributionDatesResult;
import curam.core.facade.infrastructure.struct.ListMultiEvidenceKey;
import curam.core.facade.infrastructure.struct.ListMultiParticipantKey;
import curam.core.facade.infrastructure.struct.MultiEvidenceDetails;
import curam.core.facade.infrastructure.struct.MultiParticipantDetails;
import curam.core.facade.infrastructure.struct.MultiParticipantDiscardInEditEvidenceListDtls;
import curam.core.facade.infrastructure.struct.PageNameDetails;
import curam.core.facade.infrastructure.struct.RejectedEvidenceApprovalRequestDetails;
import curam.core.facade.infrastructure.struct.SetPendingRemovalReturnDtls;
import curam.core.facade.infrastructure.struct.TransferEvidenceKey;
import curam.core.facade.intf.MenuData;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.IntegratedCaseMenuDataKey;
import curam.core.fact.CachedConcernRoleFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.EvidenceUpdatesAllowed;
import curam.core.impl.ProductHookManager;
import curam.core.intf.CachedConcernRole;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.ApprovalRequestKey;
import curam.core.sl.entity.struct.CaseEvidenceTreeDtls;
import curam.core.sl.entity.struct.CaseEvidenceTreeKey;
import curam.core.sl.entity.struct.CaseIDAndParticipantIDDetails;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.EvidenceDashboardFilterFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.impl.PostponeVerificationInterface;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceChangeHistoryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceMetadataFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceChangeHistory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndStatuses;
import curam.core.sl.infrastructure.entity.struct.ChangeUserDetails;
import curam.core.sl.infrastructure.entity.struct.CorrectionSetIDDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDashboardDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceDashboardDetailsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorIDAndStatusDetailsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceParticipantIDNameDetailsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeDateAndStatusKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.ParticipantDataIndDetails;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.RelatedIDEvidenceTypeAndCaseIDKey;
import curam.core.sl.infrastructure.entity.struct.SharedInstanceIDCaseIDStatusCode;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.AutoEndDateEvidenceOperations;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceHelper;
import curam.core.sl.infrastructure.impl.EvidenceIssues;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.EvidenceVerification;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.MultiEvidenceHook;
import curam.core.sl.infrastructure.impl.MultiEvidenceOperations;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.infrastructure.struct.ApplyWIPChangeDetails;
import curam.core.sl.infrastructure.struct.ApprovalRequestHistoryDetailsList;
import curam.core.sl.infrastructure.struct.BusinessObjectEvidenceTypeKey;
import curam.core.sl.infrastructure.struct.BusinessObjectSummaryList;
import curam.core.sl.infrastructure.struct.DashboardFilterEvidenceTypeDetails;
import curam.core.sl.infrastructure.struct.DashboardFilterEvidenceTypeDetailsList;
import curam.core.sl.infrastructure.struct.DiscardPendingRemoveKey;
import curam.core.sl.infrastructure.struct.ECActiveEvidenceDtlsList;
import curam.core.sl.infrastructure.struct.ECApprovalRequestDtls;
import curam.core.sl.infrastructure.struct.ECWIPChangeDetails;
import curam.core.sl.infrastructure.struct.ECWIPChangeDtls;
import curam.core.sl.infrastructure.struct.ECWIPDtls;
import curam.core.sl.infrastructure.struct.ECWIPNewAndUpdateDtls;
import curam.core.sl.infrastructure.struct.ECWIPRemoveDtls;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.sl.infrastructure.struct.ECWarningsDtlsList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceKeyList;
import curam.core.sl.infrastructure.struct.EvidencePeriod;
import curam.core.sl.infrastructure.struct.EvidenceRejectionDetails;
import curam.core.sl.infrastructure.struct.EvidenceSiteMapDetailsList;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetails;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetailsList;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDesc;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDescList;
import curam.core.sl.infrastructure.struct.EvidenceTypeWorkspaceDetails;
import curam.core.sl.infrastructure.struct.EvidenceTypeWorkspaceKey;
import curam.core.sl.infrastructure.struct.IssueDetails;
import curam.core.sl.infrastructure.struct.IssueDetailsList;
import curam.core.sl.infrastructure.struct.ListParticipantEvidenceKey;
import curam.core.sl.infrastructure.struct.ListParticipantEvidenceResult;
import curam.core.sl.infrastructure.struct.PendingApprovalDtls;
import curam.core.sl.infrastructure.struct.TransferEvidenceDetails;
import curam.core.sl.infrastructure.struct.TransferEvidenceDetails1;
import curam.core.sl.infrastructure.struct.ViewApprovalRequestDetails;
import curam.core.sl.struct.AssociationDetails;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseIDParticipantIDEvidenceTypeKey;
import curam.core.sl.struct.DashboardFilterCaseKey;
import curam.core.sl.struct.DashboardFilterDetails;
import curam.core.sl.struct.DashboardFilterDetailsList;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.sl.struct.MultiEvidenceDtls;
import curam.core.sl.struct.ParticipantIDNameDetails;
import curam.core.sl.struct.ParticipantIDNameDetailsList;
import curam.core.sl.struct.ReturnEvidenceDetails;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndTypeDetails;
import curam.core.struct.CaseReferenceCRNameAltIDDetails;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.datastore.entity.struct.DatastoreEntityKey;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.NoSuchSchemaException;
import curam.dynamicevidence.sl.entity.struct.DynamicEvidenceDataAttributeDtls;
import curam.dynamicevidence.sl.entity.struct.EvidenceIDDetails;
import curam.dynamicevidence.util.impl.DateUtil;
import curam.dynamicevidence.validation.impl.MultiFailOperation;
import curam.evidence.impl.EvidenceTypeFactory;
import curam.message.BPOEVIDENCE;
import curam.message.BPOEVIDENCECONST;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.EVIDENCEDASHBOARD;
import curam.message.FACADEEVIDENCE;
import curam.message.PDCEVIDENCEDESCRIPTION;
import curam.message.impl.BPOEVIDENCECONTROLLERExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.impl.ClientURI;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import curam.wizard.util.impl.CodetableUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;

/**
 * @see curam.core.facade.infrastructure.intf.Evidence
 */

public abstract class Evidence
  extends curam.core.facade.infrastructure.base.Evidence {

  // BEGIN, CR00216737, GYH
  // protected variables used in the parsing evidence information passed
  // in from the client.
  protected static final int kElementsInTabList = 5;

  protected static final int kFirstElement = 0;

  protected static final int kSecondElement = 1;

  protected static final int kThirdElement = 2;

  protected static final int kFourthElement = 3;

  protected static final int kFifthElement = 4;

  // END, CR00216737
  // BEGIN, CR00223998, ELG
  // Sixth element is for new and updated indicator. It is used in the
  // facade only.
  protected static final int kSixthElement = 5;

  // END, CR00223998

  // BEGIN, CR00188098, PB
  /**
   * A hash map reference of the case evidence type module which is registered
   * in the registry.
   */
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  @Inject
  protected MultiEvidenceOperations multiOperations;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected EvidenceIssues evidenceIssues;

  @Inject
  protected EvidenceVerification evidenceVerification;

  @Inject
  protected EvidenceURIHelper evidenceURIHelper;

  // BEGIN, CR00427296, AKr
  @Inject
  protected PostponeVerificationInterface postponeVerificationInterface;

  // END, CR00427296

  @Inject
  private EvidenceHelper evidenceHelper;

  // BEGIN, CR00472418, ZV
  @Inject(optional = true)
  protected MultiEvidenceHook multiEvidenceHook;

  // END, CR00472418

  // BEGIN, 187736 - CC
  @Inject
  protected AutoEndDateEvidenceOperations autoEndDateEvidenceOperations;

  // BEGIN, 187736 - CC

  /**
   * Default constructor for the class.
   */
  public Evidence() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00188098
  // BEGIN, CR00032741, DK
  /*
   * Generic mechanism to combine two different sorts. This Comparator is used
   * when we want to order a list based on two different fields. We define a
   * generic CompositeComparator that combines the logic of two individual
   * Comparators. We refer to the two Comparators as the major and minor
   * comparators. The major comparator has priority over the minor comparator.
   * If the major comparator returns < 0 or > 0, then that result is passed
   * back. The minor comparator's result is used only if the major comparator
   * returns 0
   */

  public class CompositeComparator implements Comparator {

    protected Comparator<Object> major;

    protected Comparator<Object> minor;

    public CompositeComparator(final Comparator<Object> major,
      final Comparator<Object> minor) {

      this.major = major;
      this.minor = minor;
    }

    /**
     * Default Constructor.
     */
    public CompositeComparator() {// Default constructor

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compare(final Object o1, final Object o2) {

      final int result = major.compare(o1, o2);

      if (result != 0) {
        return result;
      } else {
        return minor.compare(o1, o2);
      }
    }

    public void setMajor(final Comparator<Object> major) {

      this.major = major;
    }

    public void setMinor(final Comparator<Object> minor) {

      this.minor = minor;
    }

  }

  /*
   * Comparator used when ordering list of WIP evidences by evidence description
   */
  public class WIPEvidenceDescComparator implements Comparator {

    /**
     * Default Constructor.
     */
    public WIPEvidenceDescComparator() {

      super();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compare(final Object o1, final Object o2) {

      // BEGIN, CR00071077, GM
      String evType1 = CuramConst.gkEmpty;
      String evType2 = CuramConst.gkEmpty;

      // END, CR00071077

      if (o1.getClass().equals(new ECWIPNewAndUpdateDtls().getClass())) {
        evType1 = ((ECWIPNewAndUpdateDtls) o1).evidenceType;
        evType2 = ((ECWIPNewAndUpdateDtls) o2).evidenceType;
      } else if (o1.getClass().equals(new ECWIPRemoveDtls().getClass())) {
        evType1 = ((ECWIPRemoveDtls) o1).evidenceType;
        evType2 = ((ECWIPRemoveDtls) o2).evidenceType;
      } else {
        return 0;
      }
      // BEGIN, CR00072947, GM
      String a = CuramConst.gkEmpty;
      String b = CuramConst.gkEmpty;

      // END, CR00072947

      // BEGIN, CR00100972, VM
      try {
        // BEGIN, CR00163098, JC
        a = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, evType1,
          TransactionInfo.getProgramLocale());
        b = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, evType2,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } catch (final AppException app) {
        final AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, app);

        throw new AppRuntimeException(ae);
      } catch (final InformationalException inf) {
        final AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, inf);

        throw new AppRuntimeException(ae);
      }
      // END, CR00100972

      return a.compareTo(b);
    }

  }

  /*
   * Comparator used when ordering list of WIP evidences by participant name
   */
  public class WIPEvidenceParticipantNameComparator implements Comparator {

    /**
     * Default Constructor.
     */
    public WIPEvidenceParticipantNameComparator() {

      super();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compare(final Object o1, final Object o2) {

      // BEGIN, CR00071077, GM
      String concernRoleName1 = CuramConst.gkEmpty;
      String concernRoleName2 = CuramConst.gkEmpty;

      // END, CR00071077

      if (o1.getClass().equals(new ECWIPNewAndUpdateDtls().getClass())) {
        concernRoleName1 = ((ECWIPNewAndUpdateDtls) o1).concernRoleName;
        concernRoleName2 = ((ECWIPNewAndUpdateDtls) o2).concernRoleName;
      } else if (o1.getClass().equals(new ECWIPRemoveDtls().getClass())) {
        concernRoleName1 = ((ECWIPRemoveDtls) o1).concernRoleName;
        concernRoleName2 = ((ECWIPRemoveDtls) o2).concernRoleName;
      }

      return concernRoleName1.compareTo(concernRoleName2);
    }

  }

  /*
   * Comparator used to order a list by participant name
   */
  // BEGIN, CR00222660, PF
  public class ParticipantIDNameDetailsComparator
    implements Comparator<ParticipantIDNameDetails> {

    public ParticipantIDNameDetailsComparator() {

      super();
    }

    @Override
    public int compare(final ParticipantIDNameDetails o1,
      final ParticipantIDNameDetails o2) {

      return o1.participantName.compareTo(o2.participantName);
    }

  }

  // END, CR00222660

  // ___________________________________________________________________________
  /**
   * Method to sort a list of participant details by name.
   *
   * @param input
   * Input structure containing a list of participant details
   */
  protected void
    sortListByParticipant(final ParticipantIDNameDetailsList input)
      throws AppException, InformationalException {

    // BEGIN, CR00222660, PF
    // Sort the input data by name
    final Comparator<ParticipantIDNameDetails> participantIDNameDetailsComparator =
      new ParticipantIDNameDetailsComparator();
    final ArrayList<ParticipantIDNameDetails> arrayList =
      new ArrayList<ParticipantIDNameDetails>();

    arrayList.addAll(input.dtls);
    Collections.sort(arrayList, participantIDNameDetailsComparator);

    // Empty list in order to re-use
    input.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < arrayList.size(); i++) {

      input.dtls.addRef(arrayList.get(i));
    }

  }

  /*
   * Comparator used to order a list by evidence type description
   */
  public class EvidenceDescComparator
    implements Comparator<EvidenceTypeAndDesc> {

    public EvidenceDescComparator() {

      super();
    }

    @Override
    public int compare(final EvidenceTypeAndDesc o1,
      final EvidenceTypeAndDesc o2) {

      // BEGIN, CR00072947, GM
      String a = CuramConst.gkEmpty;
      String b = CuramConst.gkEmpty;

      // END, CR00072947

      // BEGIN, CR00100972, VM
      try {
        // BEGIN, CR00163098, JC
        a = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, o1.evidenceType,
          TransactionInfo.getProgramLocale());
        b = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, o2.evidenceType,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } catch (final AppException app) {
        final AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, app);

        throw new AppRuntimeException(ae);
      } catch (final InformationalException inf) {
        final AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, inf);

        throw new AppRuntimeException(ae);
      }
      // END, CR00100972

      return a.compareTo(b);
    }

  }

  // END, CR00222660

  // ___________________________________________________________________________
  /**
   * Method to sort the in edit workspace list of evidences by participant name
   * and evidence type description.
   *
   * @param input
   * List of evidences to be displayed on the workspace
   */
  protected void
    sortInEditListByParticipantAndEvidenceDesc(final ECWIPDtls input) {

    final CompositeComparator compComparator = new CompositeComparator();

    // Sort In Edit Evidence firstly by participantName and then by evidenceType

    // Set the major Comparator (i.e. Comparator that takes priority)
    // as the WIPEvidenceParticipantNameComparator which sorts by
    // concernRoleName
    compComparator.setMajor(new WIPEvidenceParticipantNameComparator());

    // Set the minor Comparator as the WIPEvidenceDescComparator
    // which sorts by evidence type description
    compComparator.setMinor(new WIPEvidenceDescComparator());

    final ArrayList newAndUpdateList = new ArrayList();

    newAndUpdateList.addAll(input.newAndUpdateList.dtls);
    Collections.sort(newAndUpdateList, compComparator);

    // Empty list in order to re-use
    input.newAndUpdateList.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < newAndUpdateList.size(); i++) {
      input.newAndUpdateList.dtls
        .addRef((ECWIPNewAndUpdateDtls) newAndUpdateList.get(i));
    }

    final ArrayList removeList = new ArrayList();

    removeList.addAll(input.removeList.dtls);
    Collections.sort(removeList, compComparator);

    // Empty list in order to re-use
    input.removeList.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < removeList.size(); i++) {
      input.removeList.dtls.addRef((ECWIPRemoveDtls) removeList.get(i));
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to sort a list by evidence type description.
   *
   * @param input
   * Input structure containing a list of evidence types and
   * descriptions
   */
  protected void sortListByEvidenceDesc(final EvidenceTypeAndDescList input)
    throws AppException, InformationalException {

    // BEGIN, CR00222660, PF
    // Sort the input data by evidence description
    final Comparator<EvidenceTypeAndDesc> evidenceDescComparator =
      new EvidenceDescComparator();
    final ArrayList<EvidenceTypeAndDesc> arrayList =
      new ArrayList<EvidenceTypeAndDesc>();

    arrayList.addAll(input.dtls);
    Collections.sort(arrayList, evidenceDescComparator);

    // Empty list in order to re-use
    input.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < arrayList.size(); i++) {

      input.dtls.addRef(arrayList.get(i));
    }
    // END, CR00222660

  }

  // END, CR00032741

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Sets the Evidence identified by input Evidence Descriptor key as 'Pending
   * Removal' and returns the details object for the same evidence.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return Details of evidence pending removal.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public SetPendingRemovalReturnDtls
    setPendingRemovalForActiveEvidence(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // Call controller operation to remove evidence
    EvidenceControllerFactory.newInstance().removeEvidence(key);

    final SetPendingRemovalReturnDtls setPendingRemovalReturnDtls =
      new SetPendingRemovalReturnDtls();

    setPendingRemovalReturnDtls.warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    return setPendingRemovalReturnDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards 'pending removal' from active evidences. Discards the pending
   * removal evidence (by setting the <code>pendingRemovalInd</code> field on
   * the EvidenceDescriptor entity to <code>false</code>). If the change has
   * been submitted for approval and/or if the user does not have sufficient
   * privileges to discard pending removal evidences, exception is thrown.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Contains EvidenceDescriptor key and details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void
    clearPendingRemovalForActiveEvidence(final DiscardPendingRemoveKey key)
      throws AppException, InformationalException {

    // Call controller operation to discard pending removal evidences
    EvidenceControllerFactory.newInstance().discardPendingRemove(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards the pending update evidence (by setting the
   * <code>statusCode</code> of the EvidenceDescriptor to Canceled).
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void discardPendingUpdate(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    // Call controller operation to discard pending update evidences
    EvidenceControllerFactory.newInstance().discardPendingUpdate(key);
  }

  // BEGIN, CR00471820, JAY
  /**
   * Discards the pending update evidence for multiple evidence (by setting the
   * <code>statusCode</code> of the EvidenceDescriptor to Canceled).
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key contains Evidence Descriptor multi select.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void discardPendingUpdateMultiParticipant(
    final EvidenceDescriptorMultiSelectKey key)
    throws AppException, InformationalException {

    final String evidenceDescriptorMultiSelect =
      key.evidenceDescriptorMultiSelectList;

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    final StringList multiSelectEvidenceDescriptorIDList =
      StringUtil.tabText2StringListWithTrim(evidenceDescriptorMultiSelect);

    final List<EvidenceDescriptorKey> evidenceList =
      new ArrayList<EvidenceDescriptorKey>(
        multiSelectEvidenceDescriptorIDList.size() + CuramConst.gkOne);

    if (!multiSelectEvidenceDescriptorIDList.isEmpty()) {

      // BEGIN, CR00472676, YF
      TransactionInfo.setFacadeScopeObject(CuramConst.gkMeoTransactionKey,
        true);
      // END, CR00472676, YF

      if (multiEvidenceHook != null) {
        evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;
        evidenceList.add(evidenceDescriptorKey);

        for (final String evidenceDescriptorID : multiSelectEvidenceDescriptorIDList) {
          evidenceDescriptorKey.evidenceDescriptorID =
            Long.parseLong(evidenceDescriptorID);
          evidenceList.add(evidenceDescriptorKey);
        }

        multiEvidenceHook.preDiscardMultiEvidence(evidenceList);
      }
    }

    // Discard the evidence selected
    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;

    EvidenceControllerFactory.newInstance()
      .discardPendingUpdate(evidenceDescriptorKey);

    // Discard if MultiSelect list has evidence
    if (!evidenceDescriptorMultiSelect.isEmpty()) {
      final EvidenceDescriptorKey evidenceDescriptorMultiKey =
        new EvidenceDescriptorKey();

      for (final String evidenceDescriptorID : multiSelectEvidenceDescriptorIDList) {
        evidenceDescriptorMultiKey.evidenceDescriptorID =
          Long.parseLong(evidenceDescriptorID);
        EvidenceControllerFactory.newInstance()
          .discardPendingUpdate(evidenceDescriptorMultiKey);
      }

      if (multiEvidenceHook != null) {
        multiEvidenceHook.postDiscardMultiEvidence(evidenceList);
      }

      // BEGIN, CR00472676, YF
      MultiFailOperation.checkForInformationals();
      // END, CR00472676, YF

      TransactionInfo.setFacadeScopeObject(CuramConst.gkMeoTransactionKey,
        null);
    }

  }

  /**
   * Retrieves list of InEdit evidence for the discard evidence page.
   * If return list of {@link #listEvidenceForMultiDiscard(EvidenceKey)} is not
   * empty
   * then list added to return struct, isMultiParticipantList set to TRUE and
   * evidence discard page message set with localized message
   * FACADEEVIDENCE.EVIDENCE_DISCARD_SUMMARY.
   * Else it will return boolean variable isMultiParticipantList set to FALSE.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key contains Evidence Descriptor, Evidence Type and CaseID.
   *
   * @return Details of evidence pending removal for multiple participant.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public MultiParticipantDiscardInEditEvidenceListDtls
    listMultiParticipantDiscardPendingEvidence(
      final EvidenceDescriptorIDKey key)
      throws AppException, InformationalException {

    final MultiParticipantDiscardInEditEvidenceListDtls multiParticipantInEditList =
      new MultiParticipantDiscardInEditEvidenceListDtls();

    final EvidenceDescriptorKey eviDescriptorKey =
      new EvidenceDescriptorKey();

    eviDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorIDParam;

    // Read evidence descriptor details
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorDtls evidenceDescriptorDetails =
      evidenceDescriptorObj.read(eviDescriptorKey);

    // BEGIN WI232181, YF
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    // Read concern role details only if there is a participant ID
    // on the evidence
    if (evidenceDescriptorDetails.participantID != 0) {

      // ConfernRoleKey to get participant name
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = evidenceDescriptorDetails.participantID;

      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
    }
    // END WI232181, YF

    // EIEvidenceKey to get list of multiple participant evidence for discard
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = evidenceDescriptorDetails.relatedID;
    eiEvidenceKey.evidenceType = evidenceDescriptorDetails.evidenceType;

    final EvidenceKey evidenceKey = new EvidenceKey();

    evidenceKey.key = eiEvidenceKey;

    // Get list of multiple participant evidence for discard
    final MultiEvidenceDetails multiEvidenceDtls =
      listEvidenceForMultiDiscard(evidenceKey);

    // If multiple participant list is not empty remove the evidence selected
    // for discard
    // Create discard page localized message
    if (multiEvidenceDtls.showListInd) {
      if (multiEvidenceDtls.list.size() == 1
        && key.evidenceDescriptorIDParam == multiEvidenceDtls.list
          .get(0).evidenceDescriptorID) {
        return multiParticipantInEditList;
      } else {
        for (final MultiEvidenceDtls eviDetails : multiEvidenceDtls.list) {
          if (key.evidenceDescriptorIDParam != eviDetails.evidenceDescriptorID) {
            multiParticipantInEditList.multiEvidenceDtls.list.add(eviDetails);
          }
        }
        multiParticipantInEditList.isMultiParticipantList = true;

        final LocalisableString description =
          new LocalisableString(FACADEEVIDENCE.EVIDENCE_DISCARD_SUMMARY);

        description.arg(concernRoleDtls.concernRoleName);

        multiParticipantInEditList.discardEvidenceMessage =
          description.toClientFormattedText();
      }
    }

    return multiParticipantInEditList;
  }

  // END, CR00471820, JAY

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns view page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key
   *
   * @return Page name details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readViewPage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readViewPage(key.key);

    return pageNameDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns modify page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readModifyPage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the modify page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readModifyPage(key.key);

    return pageNameDetails;
  }

  // BEGIN, CR00223998, ELG
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains a case identifier
   *
   * @return List of all evidences for applying changes
   * @deprecated Since Curam 6.0, replaced with
   * {@link #listAllForApplyChanges1(CaseKey)}. As part of evidence
   * processing enhancements the return apply changes evidence list
   * had to be changed. See release note: CR00223998.
   *
   * Lists all evidences for applying changes.
   */
  @Override
  @Deprecated
  // END, CR00223998
  public ECWIPDtls listAllForApplyChanges(final CaseKey key)
    throws AppException, InformationalException {

    // Call method for retrieving the list of all work in progress details
    return EvidenceControllerFactory.newInstance().listWorkInProgress(key);
  }

  // BEGIN, CR00223998, ELG

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all evidences for applying changes.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier and, optionally, an evidence type.
   *
   * @return List of all evidences for applying changes
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  // BEGIN, CR00245734, CD
  @Override
  public ECWIPChangeDetails
    listAllForApplyChanges1(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // END, CR00245734
    final EvidenceController evidenceControllerObj =
      EvidenceControllerFactory.newInstance();

    return evidenceControllerObj.listWorkInProgressDetails(key);

  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all Evidence for validating changes.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier and, optionally, an evidence type.
   *
   * @return List of all evidences for validating changes
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ECWIPChangeDetails
    listAllForValidateChanges(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // get the full list
    final ECWIPChangeDetails fullList = listAllForApplyChanges1(key);

    //
    // filter out participant evidence
    //

    final ECWIPChangeDetails filteredList = new ECWIPChangeDetails();

    filteredList.filterByTypeInd = fullList.filterByTypeInd;

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceTypeKey evTypeKey = new EvidenceTypeKey();

    for (final ECWIPChangeDtls changeDtls : fullList.changeList.dtls) {

      evTypeKey.evidenceType = changeDtls.evidenceType;
      if (!evidenceControllerObj.isEvidenceParticipantData(evTypeKey)) {
        filteredList.changeList.dtls.add(changeDtls);
      }

    }

    return filteredList;

  }

  // END, CR00223998

  // BEGIN, CR00223998, ELG
  // ___________________________________________________________________________
  /**
   * @param caseKey
   * Contains a case identifier
   * @param details
   * Contains a tabbed evidence list
   *
   * @return ApplyChangesReturnDtls warnings that occurred while applying the
   * changes
   * @deprecated Since Curam 6.0, replaced with
   * {@link #applyChanges1(CaseKey, ApplyWIPChangeDetails)}. As part
   * of evidence processing enhancements the evidence for apply
   * changes is now passed in as single tabbed list. See release
   * note: CR00223998.
   *
   * Applies changes on the (tabbed) list of evidence passed into
   * the function.
   */
  @Override
  @Deprecated
  // END, CR00223998
  public ApplyChangesReturnDtls applyChanges(final CaseKey caseKey,
    final ApplyChangesDetails details)
    throws AppException, InformationalException {

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // Call method to apply changes
    evidenceControllerObj.applyChanges(caseKey, details.details);

    // Return the warnings
    final ApplyChangesReturnDtls applyChangesReturnDtls =
      new ApplyChangesReturnDtls();

    applyChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyChangesReturnDtls;
  }

  // BEGIN, CR00223998, ELG

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies changes on the (tabbed) list of evidences passed into the method
   * to the given case. This tabbed list includes new, modified, and pending
   * deletion evidences.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param caseKey Contains a case identifier.
   *
   * @param tabbedList Contains a tabbed list of evidence changes to be
   * applied.
   *
   * @return Warnings that occurred while applying the changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ApplyChangesReturnDtls applyChanges1(final CaseKey key,
    final ApplyWIPChangeDetails tabbedList)
    throws AppException, InformationalException {

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final curam.core.sl.infrastructure.struct.ApplyChangesDetails applyChangesDetails =
      convertChangeListToApplyChangesDetails(tabbedList.changeList);

    // Call method to apply changes
    evidenceControllerObj.applyChanges(key, applyChangesDetails);

    // Return the warnings
    final ApplyChangesReturnDtls applyChangesReturnDtls =
      new ApplyChangesReturnDtls();

    applyChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyChangesReturnDtls;

  }

  /**
   * Helper method for converting tab separated evidence list to two lists -
   * newAndUpdateList & removeList.
   *
   * @param tabList
   * Tab separated list of evidence data to be parsed.
   *
   * @return Structure containing newAndUpdateList & removeList tab separated
   * lists.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected curam.core.sl.infrastructure.struct.ApplyChangesDetails
    convertChangeListToApplyChangesDetails(final String tabList) {

    // Return structure
    final curam.core.sl.infrastructure.struct.ApplyChangesDetails applyChangesDetails =
      new curam.core.sl.infrastructure.struct.ApplyChangesDetails();

    // Variables for evidence details
    String evidenceDescriptorIDStr;
    String evidenceIDStr;
    String evidenceTypeStr;
    String correctionSetIDStr;
    String successionIDStr;
    boolean newAndUpdatedInd;

    // New and Update List
    final StringList sourceList = StringUtil.tabText2StringList(tabList);

    final StringBuffer newAndUpdateStringBuffer = new StringBuffer();
    final StringBuffer removeStringBuffer = new StringBuffer();

    final int numElementsInList = kElementsInTabList + CuramConst.gkOne;

    int newAndUpdateListElementCount = 0;
    int removeListElementCount = 0;

    for (int i = 0; i < sourceList.size(); i++) {

      final StringList evidenceDetailsList =
        StringUtil.delimitedText2StringList(sourceList.item(i),
          CuramConst.gkPipeDelimiterChar);

      if (evidenceDetailsList.size() != numElementsInList) {
        continue;
      }

      evidenceDescriptorIDStr = evidenceDetailsList.item(kFirstElement);
      evidenceIDStr = evidenceDetailsList.item(kSecondElement);
      evidenceTypeStr = evidenceDetailsList.item(kThirdElement);
      correctionSetIDStr = evidenceDetailsList.item(kFourthElement);
      successionIDStr = evidenceDetailsList.item(kFifthElement);
      newAndUpdatedInd =
        Boolean.parseBoolean(evidenceDetailsList.item(kSixthElement));

      if (newAndUpdatedInd) {

        if (newAndUpdateListElementCount > 0) {
          newAndUpdateStringBuffer.append(CuramConst.gkTabDelimiterChar);
        }

        newAndUpdateStringBuffer.append(evidenceDescriptorIDStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(evidenceIDStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(evidenceTypeStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(correctionSetIDStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(successionIDStr);

        newAndUpdateListElementCount++;

      } else {

        if (removeListElementCount > 0) {
          removeStringBuffer.append(CuramConst.gkTabDelimiterChar);
        }

        removeStringBuffer.append(evidenceDescriptorIDStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(evidenceIDStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(evidenceTypeStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(correctionSetIDStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(successionIDStr);

        removeListElementCount++;

      }

    }

    applyChangesDetails.newAndUpdateList =
      newAndUpdateStringBuffer.toString();
    applyChangesDetails.removeList = removeStringBuffer.toString();

    return applyChangesDetails;

  }

  // END, CR00223998

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies all changes in Evidences to case, specified by case key, key.
   *
   * Before applying changes, all evidences are checked to ensure that they
   * have been approved and activation is allowed.
   *
   * If changes could not be applied, appropriate warnings are added to
   * <code>InformationalManager</Code>.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @param caseKey Contains a case identifier.
   *
   * @return ApplyAllChangesReturnDtls warnings that occurred while applying
   * the changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ApplyAllChangesReturnDtls applyAllChanges(final CaseKey caseKey)
    throws AppException, InformationalException {

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // Call method to apply all changes
    evidenceControllerObj.applyAllChanges(caseKey);

    // Return the warnings
    final ApplyAllChangesReturnDtls applyAllChangesReturnDtls =
      new ApplyAllChangesReturnDtls();

    applyAllChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyAllChangesReturnDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies changes to evidences, to the case, identified by key, where the
   * currently logged in user was the most recent user to modify the evidences.
   * Before applying changes, evidences are checked to ensure that they have
   * been approved and activation is allowed.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param caseKey Contains a case identifier.
   *
   * @return List of warnings that occurred while applying the changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ApplyUserChangesReturnDtls applyUserChanges(final CaseKey caseKey)
    throws AppException, InformationalException {

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.applyUserChanges(caseKey);

    // Return the warnings
    final ApplyUserChangesReturnDtls applyUserChangesReturnDtls =
      new ApplyUserChangesReturnDtls();

    applyUserChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyUserChangesReturnDtls;
  }

  // BEGIN, CR00031254, CD

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all evidence of a given type for a given case to populate the
   * evidence workspace.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Key to retrieve list of evidence consisting of a caseID and
   * evidenceType
   *
   * @return List of Evidence
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceListDetails listEvidence(final EvidenceListKey key)
    throws AppException, InformationalException {

    // Instantiate the return struct
    final EvidenceListDetails evidenceListDetails = new EvidenceListDetails();

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceListDetails.dtls =
      evidenceControllerObj.listAllForEvidenceListPage(key.key);
    final CaseKey caseKey = new CaseKey();

    // Retrieve context description
    // BEGIN, CR00080440, CD
    caseKey.caseID = key.key.caseID;

    evidenceListDetails.contextDescription.contextDescription =
      getContextDescription(caseKey).contextDescription;
    // END, CR00080440
    // BEGIN, CR00100757, CH
    // Putting back in the showVerificationCluster
    // BEGIN, CR00077979, CH
    // The showVerificationCluster boolean has been removed as a temporary
    // measure. For this reason the code is being commented out rather
    // than being removed.
    // BEGIN, CR00032741, DK
    if (evidenceListDetails.dtls.verificationDtlsList.verificationDtls
      .size() > 0) {

      evidenceListDetails.showVerificationCluster = true;
    }
    // END, CR00032741
    // END, CR00077979
    // END, CR00100757

    return evidenceListDetails;
  }

  // END, CR00031254

  // BEGIN, CR00224418, EC

  // BEGIN, CR00397587, PS
  /**
   * Lists a summary of all business objects for the supplied evidence type
   * optionally filtered by a related succession ID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Key to retrieve list of business objects
   *
   * @return List of summaries of business objects.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public BusinessObjectSummaryList listBusinessObjectsForEvidenceType(
    final BusinessObjectEvidenceTypeKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00389944, ZV
    String displayDeletedEvidence =
      Configuration.getProperty(EnvVars.ENV_DISPLAY_DELETED_EVIDENCE);

    if (displayDeletedEvidence == null) {
      displayDeletedEvidence = EnvVars.ENV_DISPLAY_DELETED_EVIDENCE;
    }

    key.includeExcludedStatus =
      displayDeletedEvidence.equals(EnvVars.ENV_VALUE_YES);
    // END, CR00389944
    // BEGIN, CR00452380, GK
    return EvidenceControllerFactory.newInstance()
      .listBusinessObjectsForEvidenceType1(key);
    // END, CR00452380
  }

  // END, CR00224418

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of evidence change history records.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Evidence history details list for display.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListEvidenceChangeHistoryResult listEvidenceChangeHistory(
    final EvidenceKey key) throws AppException, InformationalException {

    // Return object
    final ListEvidenceChangeHistoryResult listEvidenceChangeHistoryResult =
      new ListEvidenceChangeHistoryResult();

    // Call the method to retrieve the list of evidence change history
    // records
    listEvidenceChangeHistoryResult.detailsList = EvidenceControllerFactory
      .newInstance().listEvidenceChangeHistory(key.key);

    return listEvidenceChangeHistoryResult;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies attribution on a product delivery case where some or all of the
   * evidence is stored at the related Integrated Case level.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Contains the case identifier.
   *
   * @return List of informational warnings.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ECWarningsDtlsList performProductDeliveryAttribution(
    final CaseKey key) throws AppException, InformationalException {

    // Call the method for attributing evidence
    EvidenceControllerFactory.newInstance()
      .performProductDeliveryAttribution(key, new EvidenceKeyList());

    return EvidenceControllerFactory.newInstance().getWarnings();
  }

  /**
   * Lists active case participants whose case participant role types are
   * specific for the given evidence type
   *
   * @param evType contains the evidence type
   *
   * @param key contains case ID, evidence type and evidence received date
   *
   * @return MultiParticipantDetails struct, containing:
   * showListInd - boolean, true when more then one participant is returned
   * list - a list of case participant details
   * dtls - a single participant details object to be used when only a single
   * record is found
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public MultiParticipantDetails
    listParticipantsForMultiCreate(final ListMultiParticipantKey key)
      throws AppException, InformationalException {

    final MultiParticipantDetails detailsList = new MultiParticipantDetails();

    // Search for active case members
    detailsList.list
      .addAll(multiOperations.listParticipantsForMultiCreate(key.key));

    detailsList.showListInd = detailsList.list.size() > CuramConst.gkOne;
    if (detailsList.list.size() == CuramConst.gkOne) {
      detailsList.dtls = detailsList.list.item(CuramConst.gkZero);
    }

    return detailsList;
  }

  /**
   * Lists all in-edit evidence records of the given evidence type on the case
   *
   * @param key contains the evidence key.
   *
   * @return List of in-edit evidences
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public MultiEvidenceDetails listEvidenceForMultiDiscard(
    final EvidenceKey key) throws AppException, InformationalException {

    final MultiEvidenceDetails detailsList = new MultiEvidenceDetails();

    // Get in-edit evidence records
    detailsList.list
      .addAll(multiOperations.listEvidenceForMultiDiscard(key.key));
    detailsList.showListInd = !detailsList.list.isEmpty();
    return detailsList;
  }

  /**
   * Lists all current active and in-edit evidence records of the given evidence
   * type on the case
   *
   * @param key contains the evidence key.
   *
   * @return MultiEvidenceDetails struct
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public MultiEvidenceDetails
    listEvidenceForMultiModify(final ListMultiEvidenceKey key)
      throws AppException, InformationalException {

    final MultiEvidenceDetails detailsList = new MultiEvidenceDetails();

    // Search for case active current evidence
    detailsList.list
      .addAll(multiOperations.listEvidenceForMultiModify(key.key));
    detailsList.showListInd = !detailsList.list.isEmpty();
    return detailsList;
  }

  // ___________________________________________________________________________
  /**
   * Validates the selected evidence records of one evidence type.
   *
   * @param key Contains a case identifier
   *
   * @param dtls List of evidence records to be validated.
   *
   * @deprecated -since v6.0.
   * @deprecated Replaced by validateChanges1 for usability changes.
   */
  @Deprecated
  @Override
  public void validateChanges(final CaseKey key,
    final ApplyChangesDetails dtls)
    throws AppException, InformationalException {

    // Call the method for apply changes
    EvidenceControllerFactory.newInstance().validateChanges(dtls.details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Validates the selected evidence records of one evidence type.
   *
   * @bowrite EvidenceController
   *
   * @param key Contains a case identifier.
   *
   * @param dtls List of evidence records to be validated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void validateChanges1(final CaseIDAndEvidenceTypeKey key,
    final ApplyWIPChangeDetails dtls)
    throws AppException, InformationalException {

    final curam.core.sl.infrastructure.struct.ApplyChangesDetails applyChangesDetails =
      convertChangeListToApplyChangesDetails(dtls.changeList);

    // Call the method for apply changes
    EvidenceControllerFactory.newInstance()
      .validateChanges(applyChangesDetails);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * List attribution periods for evidence associated with the Integrated Case.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return List of evidence attribution details for an integrated case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListICAttributionDatesResult
    listICAttributionDates(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // Return object
    final ListICAttributionDatesResult listICAttributionDatesResult =
      new ListICAttributionDatesResult();

    // Call method to retrieve a list of integrated case evidence
    // attribution dates
    listICAttributionDatesResult.dtls =
      EvidenceControllerFactory.newInstance().listICAttributionDates(key);

    return listICAttributionDatesResult;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists the attribution dates for an evidence descriptor identifier.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return List of evidence attribution details for a product delivery.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public AttributionDetailsList
    listAttributionDates(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // Return object
    final AttributionDetailsList attributionDetailsList =
      new AttributionDetailsList();

    // Call the method to retrieve a list of attribution dates
    attributionDetailsList.dtls =
      EvidenceControllerFactory.newInstance().listAttributionDates(key);

    return attributionDetailsList;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of all evidence that have pending changes for approval or
   * removal for a specific case. Called during case processing by the
   * caseworker.
   *
   * @boread Evidence
   *
   * @param key Contains a case identifier.
   *
   * @return List of all pending approval or pending removal changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587

  // BEGIN, CR00019750, VM
  @Override
  public ECApprovalRequestDtls listAllForApproveReject(final CaseKey key)
    throws AppException, InformationalException {

    // Return object
    final ECApprovalRequestDtls ecApprovalRequestDtls =
      new ECApprovalRequestDtls();

    final EvidenceController evidenceControllerObj =
      EvidenceControllerFactory.newInstance();

    // Call method for retrieving the list of all pending approval records
    final ECWIPDtls ecWIPDtls =
      evidenceControllerObj.listWorkInProgressApprovalRequested(key);

    for (int i = 0; i < ecWIPDtls.newAndUpdateList.dtls.size(); i++) {

      final PendingApprovalDtls pendingApprovalDtls =
        new PendingApprovalDtls();

      pendingApprovalDtls.assign(ecWIPDtls.newAndUpdateList.dtls.item(i));

      ecApprovalRequestDtls.pendingApprovalList.dtls.add(pendingApprovalDtls);
    }

    for (int i = 0; i < ecWIPDtls.removeList.dtls.size(); i++) {

      final PendingApprovalDtls pendingApprovalDtls =
        new PendingApprovalDtls();

      pendingApprovalDtls.assign(ecWIPDtls.removeList.dtls.item(i));

      ecApprovalRequestDtls.pendingApprovalList.dtls.add(pendingApprovalDtls);
    }

    return ecApprovalRequestDtls;
    // END, CR00019750
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Rejects a list of evidence Approval Requests made by a caseworker.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param details List of evidence to reject approval requests.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void rejectApprovalRequests(
    final RejectedEvidenceApprovalRequestDetails details)
    throws AppException, InformationalException {

    EvidenceControllerFactory.newInstance()
      .rejectApprovalRequests(details.details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Approves multiple approval requests for evidences listed in the input
   * tabbed list.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param details Tabbed list of evidence approval requests to approve.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void approveApprovalRequests(
    final ApprovedEvidenceApprovalRequestDetails details)
    throws AppException, InformationalException {

    EvidenceControllerFactory.newInstance()
      .approveApprovalRequests(details.details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Approves an approval request made against a piece of Evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key EvidenceKey to identify evidence row for approval.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void approveApprovalRequest(
    final curam.core.sl.infrastructure.struct.EvidenceKey key)
    throws AppException, InformationalException {

    EvidenceControllerFactory.newInstance().approveApprovalRequest(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Rejects an Approval Request made by a caseworker against a piece of
   * Evidence.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key EvidenceKey to identify evidence row for rejection.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void rejectApprovalRequest(
    final curam.core.sl.infrastructure.struct.EvidenceKey key,
    final EvidenceRejectionDetails details)
    throws AppException, InformationalException {

    EvidenceControllerFactory.newInstance().rejectApprovalRequest(key,
      details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Reads the approval request details for a evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key EvidenceKey for this row of evidence.
   *
   * @return Approval Request details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ViewApprovalRequestDetails
    readApprovalRequestDetails(final ApprovalRequestKey key)
      throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance().readApprovalRequest(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns Evidence Descriptor details for an evidence entity.
   *
   * @boread Evidence
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return Details for Evidence Descriptor associated with this evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceDescriptorDtlsList
    readEvidenceDescriptor(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // Return object
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();

    evidenceDescriptorDtlsList.dtls.add(EvidenceControllerFactory
      .newInstance().readEvidenceDescriptorDtls(key));

    return evidenceDescriptorDtlsList;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Retrieves the context description for a specific piece of Evidence.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key CaseKey Contains a case identifier.
   *
   * @return Evidence context description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587

  // BEGIN, CR00080440, CD
  @Override
  public EvidenceContextDescription getContextDescription(final CaseKey key)
    // END, CR00080440
    throws AppException, InformationalException {

    // Create return object
    final EvidenceContextDescription evidenceContextDescription =
      new EvidenceContextDescription();

    // BEGIN, CR00031254, CD
    // set up the context description
    final LocalisableString description =
      new LocalisableString(FACADEEVIDENCE.EVIDENCECONTEXTDESCRIPTION);

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    CaseReferenceCRNameAltIDDetails caseReferenceCRNameAltIDDetails;

    // read case details to get case reference number and participant name
    caseKey.caseID = key.caseID;
    caseReferenceCRNameAltIDDetails =
      caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(caseKey);

    // BEGIN, CR00032741, DK
    final String caseTypeCode =
      caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode;

    // BEGIN, CR00163098, JC
    String caseTypeValue =
      curam.util.type.CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseTypeCode, TransactionInfo.getProgramLocale());
    // END, CR00163098, JC
    // BEGIN, CR00188098, PB
    final CaseTypeEvidence caseTypeEvidence =
      caseTypeEvidenceMap.get(caseTypeCode);

    // BEGIN CR00197474, PB
    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END CR00197474
    caseTypeValue = caseTypeEvidence.getCaseTypeDescription(caseKey);

    // END, CR00188098
    // Add the items to the localizable string
    description.arg(caseTypeValue);
    // END, CR00032741
    description.arg(caseReferenceCRNameAltIDDetails.caseReference);
    description.arg(caseReferenceCRNameAltIDDetails.concernRoleName);
    description.arg(caseReferenceCRNameAltIDDetails.primaryAlternateID);
    // END, CR00031254

    // Assign it to the return object
    evidenceContextDescription.contextDescription =
      description.toClientFormattedText();

    return evidenceContextDescription;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of all approval requests for a specific piece of evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key EvidenceDescriptorKey Contains a EvidenceDescriptor identifier.
   *
   * @return List of Approval Request history details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ApprovalRequestHistoryDetailsList
    listApprovalRequestHistory(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance()
      .listApprovalRequestHistory(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all 'In Edit' and 'Pending Removal' evidences for the current user.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier.
   *
   * @return List of all evidences for applying user changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ECWIPDtls listAllForUserApplyChanges(final CaseKey key)
    throws AppException, InformationalException {

    // Call method for retrieving the list of all work in progress details
    // for the current user
    return EvidenceControllerFactory.newInstance()
      .listWorkInProgressForUser(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Creates an association of the evidence with another given
   * evidence record. This method returns the details of the evidence that was
   * associated with and warnings, if any.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param dtls The association details of the Evidence that needs to be
   * associated.
   *
   * @return Details of the Evidence record that was associated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ReturnEvidenceDetails
    createAssociation(final AssociationDetails dtls)
      throws AppException, InformationalException {

    // create association for the evidence record and populate the return
    // details
    return EvidenceControllerFactory.newInstance().createAssociation(dtls);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Cancels a pre existing association of the evidence with another
   * given evidence record. This method returns the details of the evidence,
   * with which the association was canceled, along with warnings, if any.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param dtls The identifiers of the association.
   *
   * @return Details of the modified record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ReturnEvidenceDetails
    cancelAssociation(final AssociationDetails dtls)
      throws AppException, InformationalException {

    // cancel associations of the evidence record and populate the return
    // details
    return EvidenceControllerFactory.newInstance().cancelAssociation(dtls);
  }

  // BEGIN, CR00397587, PS
  // BEGIN, CR00058169, VM
  // ___________________________________________________________________________
  /**
   * Returns the name of view snapshot evidence page for a given piece of
   * evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return Evidence Snapshot page name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readViewSnapshotPage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view snapshot page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readViewSnapshotPage(key.key);

    return pageNameDetails;
  }

  // END, CR00058169

  // BEGIN, CR00066544, VM

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a unique list of active evidence types pertaining to the specified
   * participant.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Concern Role entity key.
   *
   * @return Unique list of evidence types pertaining to the specified
   * participant.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListParticipantEvidenceResult listEvidenceTypeForParticipant(
    final ConcernRoleKey key) throws AppException, InformationalException {

    final ListParticipantEvidenceKey listParticipantEvidenceKey =
      new ListParticipantEvidenceKey();

    listParticipantEvidenceKey.key.participantID = key.concernRoleID;

    return EvidenceControllerFactory.newInstance()
      .listActiveEvidenceForParticipant(listParticipantEvidenceKey);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns all active evidence for the specified case, evidence type and
   * participant.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains the caseID and evidence type.
   *
   * @param concernRoleKey Concern Role entity key of the participant whose
   * Evidence is being retrieved.
   *
   * @return List of active evidence for the specified case and participant.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceListDetails listEvidenceForTransfer(
    final CaseIDAndEvidenceTypeKey key, final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    // Return object
    final EvidenceListDetails evidenceListDetails = new EvidenceListDetails();

    final ListParticipantEvidenceKey listParticipantEvidenceKey =
      new ListParticipantEvidenceKey();

    listParticipantEvidenceKey.key.participantID =
      concernRoleKey.concernRoleID;

    final ListParticipantEvidenceResult listParticipantEvidenceResult =
      EvidenceControllerFactory.newInstance()
        .listActiveEvidenceForParticipant(listParticipantEvidenceKey);

    // BEGIN, CR00087761, VM
    final EvidenceListKey evidenceListKey = new EvidenceListKey();
    // END, CR00087761

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceListKey.key.caseID = key.caseID;

    for (int i = 0; i < listParticipantEvidenceResult.result.dtls
      .size(); i++) {

      evidenceTypeKey.evidenceType =
        listParticipantEvidenceResult.result.dtls.item(i).evidenceType;

      // BEGIN, CR00087761, VM
      if (!EvidenceControllerFactory.newInstance()
        .isEvidenceParticipantData(evidenceTypeKey)) {
        // END, CR00087761

        // BEGIN, CR00101193, VM
        // Filter out the records by the case we're currently on
        final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
          new RelatedIDAndEvidenceTypeKey();

        relatedIDAndEvidenceTypeKey.evidenceType =
          listParticipantEvidenceResult.result.dtls.item(i).evidenceType;
        relatedIDAndEvidenceTypeKey.relatedID =
          listParticipantEvidenceResult.result.dtls.item(i).relatedID;

        final EvidenceDescriptorDtls evidenceDescriptorDtls =
          EvidenceDescriptorFactory.newInstance()
            .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

        if (evidenceDescriptorDtls.caseID == key.caseID) {
          // END, CR00101193

          evidenceListKey.key.evidenceType =
            listParticipantEvidenceResult.result.dtls.item(i).evidenceType;

          final EvidenceListDetails tempEvidenceListDetails =
            listEvidence(evidenceListKey);

          // BEGIN, CR00101611, VM
          for (int j = 0; j < tempEvidenceListDetails.dtls.activeList.dtls
            .size(); j++) {

            // Find a match
            if (tempEvidenceListDetails.dtls.activeList.dtls.item(
              j).evidenceDescriptorID == evidenceDescriptorDtls.evidenceDescriptorID) {
              evidenceListDetails.dtls.activeList.dtls
                .addRef(tempEvidenceListDetails.dtls.activeList.dtls.item(j));
              break;
            }
          }
          // END, CR00101611
        }
      }
    }
    return evidenceListDetails;
  }

  // BEGIN, CR00245135, ELG
  // ___________________________________________________________________________
  /**
   * @param details
   * Contains the evidence transfer details.
   * @return List of informational warnings
   * @deprecated Since Curam 6.0, replaced with
   * {@link #transferEvidence1(TransferEvidenceDetails1)}.
   * This method was deprecated as part of the evidence processing
   * enhancements. Please see release note: CR00245135.
   *
   * Transfers the evidence from one case to another for a specified
   * participant.
   */
  @Deprecated
  @Override
  public ECWarningsDtlsList
    transferEvidence(final TransferEvidenceDetails details)
      throws AppException, InformationalException {

    // Return object
    final ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();

    EvidenceControllerFactory.newInstance()
      .transferParticipantEvidence(details);

    return ecWarningsDtlsList;

  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Transfers the evidence from one case to another for a specified
   * participant.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @param details Contains the evidence transfer details.
   *
   * @return List of informational warnings
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ECWarningsDtlsList
    transferEvidence1(final TransferEvidenceDetails1 details)
      throws AppException, InformationalException {

    final ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();

    if (!details.actionIDProperty.equals(CuramConst.kNO)) {

      EvidenceControllerFactory.newInstance()
        .transferParticipantEvidence1(details);

    }

    if (details.actionIDProperty.equals(CuramConst.kYES)
      || details.actionIDProperty.equals(CuramConst.kNO)) {

      final DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

      datastoreEntityKey.entityID = details.datastoreEntityID;
      getDeleteEvidenceTransferDatastore(datastoreEntityKey);

    }

    return ecWarningsDtlsList;

  }

  // END, CR00245135

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns case participant details for transferring participant evidence
   * from one case to another.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @boread CaseParticipant
   *
   * @param toCaseKey Case Header entity key of the case to which evidence is
   * being transferred.
   *
   * @param key Case Participant Role of the member whose evidence is being
   * transferred.
   *
   * @return Details for transferring participant evidence from one case to
   * another.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public DetailsForEvidenceTransfer getDetailsForEvidenceTransfer(
    final CaseHeaderKey toCaseKey, final CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    // Return object
    final DetailsForEvidenceTransfer detailsForEvidenceTransfer =
      new DetailsForEvidenceTransfer();

    // Read the Case Participant Role entity
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      CaseParticipantRoleFactory.newInstance().read(key);

    detailsForEvidenceTransfer.caseID = toCaseKey.caseID;
    detailsForEvidenceTransfer.caseParticipantRoleID =
      key.caseParticipantRoleID;
    detailsForEvidenceTransfer.participantRoleID =
      caseParticipantRoleDtls.participantRoleID;

    return detailsForEvidenceTransfer;
  }

  // END, CR00066544

  // BEGIN, CR00032741, DK

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all active evidence for a case, filtering by participant and/or
   * evidenceType.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Contains a case identifier, participant identifier and an
   * Evidence type code.
   *
   * @return List of 'Active' evidence
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllForActiveWorkspaceDtls
    listAllForActiveWorkspace(final CaseIDParticipantIDEvidenceTypeKey key)
      throws AppException, InformationalException {

    // create the return struct
    final ListAllForActiveWorkspaceDtls listAllForActiveWorkspaceDtls =
      new ListAllForActiveWorkspaceDtls();

    //
    // Create default drop down "ALL" entries
    //

    EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

    // BEGIN, CR00109753, SK
    final LocalisableString messageAll =
      new LocalisableString(curam.message.BPOEVIDENCECONST.INF_CONST_ALL);

    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc =
      messageAll.getMessage(TransactionInfo.getProgramLocale());

    listAllForActiveWorkspaceDtls.evidenceTypeList.dtls
      .addRef(evidenceTypeAndDesc);

    ParticipantIDNameDetails participantIDNameDetails =
      new ParticipantIDNameDetails();

    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName =
      messageAll.getMessage(TransactionInfo.getProgramLocale());
    // END, CR00109753
    listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
      .addRef(participantIDNameDetails);

    // Call method for retrieving the list of all active details
    final CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseIDKey.caseID;

    final ECActiveEvidenceDtlsList activeEvidenceList =
      EvidenceControllerFactory.newInstance().listActive(caseKey);

    // Create drop down lists and filter list of evidence
    for (int i = 0; i < activeEvidenceList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID =
        activeEvidenceList.dtls.item(i).participantID;
      participantIDNameDetails.participantName =
        activeEvidenceList.dtls.item(i).concernRoleName;

      for (int j =
        0; j < listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
          .size(); j++) {
        final ParticipantIDNameDetails current =
          listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
            .item(j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
          .add(participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType =
        activeEvidenceList.dtls.item(i).evidenceType;
      // BEGIN, CR00163098, JC
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      for (int j = 0; j < listAllForActiveWorkspaceDtls.evidenceTypeList.dtls
        .size(); j++) {
        final EvidenceTypeAndDesc current =
          listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.item(j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForActiveWorkspaceDtls.evidenceTypeList.dtls
          .add(evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
        && (key.participantKey.key.participantID == 0
          || participantIDNameDetails.participantID == key.participantKey.key.participantID)) {

        listAllForActiveWorkspaceDtls.activeList.dtls
          .add(activeEvidenceList.dtls.item(i));

      }
    }

    sortListByParticipant(
      listAllForActiveWorkspaceDtls.participantIDNameDetailsList);
    sortListByEvidenceDesc(listAllForActiveWorkspaceDtls.evidenceTypeList);

    //
    // get the menu and the context details
    //

    // BEGIN, CR00080440, CR00122110, CD, VM
    listAllForActiveWorkspaceDtls.menuData = determineMenuData(key).menuData;

    listAllForActiveWorkspaceDtls.filteredEvidenceType = key.evidenceType;
    listAllForActiveWorkspaceDtls.filteredParticipantID =
      key.participantKey.key.participantID;

    // Set the context details
    listAllForActiveWorkspaceDtls.contextDescription =
      getContextDescription(caseKey);
    // END, CR00080440, CR00122110

    return listAllForActiveWorkspaceDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all 'In Edit' and 'Pending Removal' evidences for a case, filtering
   * by participant and evidenceType.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Contains a case identifier, participant identifier and an
   * Evidence type code.
   *
   * @return List of 'In Edit' and 'Pending Removal' evidence
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllForInEditWorkspaceDtls
    listAllForInEditWorkspace(final CaseIDParticipantIDEvidenceTypeKey key)
      throws AppException, InformationalException {

    // create the return struct
    final ListAllForInEditWorkspaceDtls listAllForInEditWorkspaceDtls =
      new ListAllForInEditWorkspaceDtls();

    //
    // Create default drop down "ALL" entries
    //

    EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();
    // BEGIN, CR00109753, SK
    final LocalisableString messageAll =
      new LocalisableString(BPOEVIDENCECONST.INF_CONST_ALL);

    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc =
      messageAll.getMessage(TransactionInfo.getProgramLocale());

    listAllForInEditWorkspaceDtls.evidenceTypeList.dtls
      .add(evidenceTypeAndDesc);

    ParticipantIDNameDetails participantIDNameDetails =
      new ParticipantIDNameDetails();

    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName =
      messageAll.getMessage(TransactionInfo.getProgramLocale());
    // END, CR00109753

    listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
      .add(participantIDNameDetails);

    // Call method for retrieving the list of all in edit details
    final CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseIDKey.caseID;

    final ECWIPDtls ecWIPDtls = EvidenceControllerFactory.newInstance()
      .listAllForInEditWorkspace(caseKey);

    // Add to drop down lists and filter list of "In Edit" evidence
    for (int i = 0; i < ecWIPDtls.newAndUpdateList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID =
        ecWIPDtls.newAndUpdateList.dtls.item(i).participantID;
      participantIDNameDetails.participantName =
        ecWIPDtls.newAndUpdateList.dtls.item(i).concernRoleName;

      for (int j =
        0; j < listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
          .size(); j++) {
        final ParticipantIDNameDetails current =
          listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
            .item(j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
          .add(participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType =
        ecWIPDtls.newAndUpdateList.dtls.item(i).evidenceType;
      // BEGIN, CR00163098, JC
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      for (int j = 0; j < listAllForInEditWorkspaceDtls.evidenceTypeList.dtls
        .size(); j++) {
        final EvidenceTypeAndDesc current =
          listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.item(j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForInEditWorkspaceDtls.evidenceTypeList.dtls
          .add(evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
        && (key.participantKey.key.participantID == 0
          || participantIDNameDetails.participantID == key.participantKey.key.participantID)) {

        listAllForInEditWorkspaceDtls.wipDtls.newAndUpdateList.dtls
          .add(ecWIPDtls.newAndUpdateList.dtls.item(i));

      }
    }

    // Add to drop down lists and filter list of "Pending Removal" evidence
    for (int i = 0; i < ecWIPDtls.removeList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID =
        ecWIPDtls.removeList.dtls.item(i).participantID;
      participantIDNameDetails.participantName =
        ecWIPDtls.removeList.dtls.item(i).concernRoleName;

      for (int j =
        0; j < listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
          .size(); j++) {
        final ParticipantIDNameDetails current =
          listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
            .item(j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls
          .add(participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType =
        ecWIPDtls.removeList.dtls.item(i).evidenceType;
      // BEGIN, CR00163098, JC
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      for (int j = 0; j < listAllForInEditWorkspaceDtls.evidenceTypeList.dtls
        .size(); j++) {
        final EvidenceTypeAndDesc current =
          listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.item(j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForInEditWorkspaceDtls.evidenceTypeList.dtls
          .add(evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
        && (key.participantKey.key.participantID == 0
          || participantIDNameDetails.participantID == key.participantKey.key.participantID)) {

        listAllForInEditWorkspaceDtls.wipDtls.removeList.dtls
          .add(ecWIPDtls.removeList.dtls.item(i));
      }
    }

    sortListByParticipant(
      listAllForInEditWorkspaceDtls.participantIDNameDetailsList);
    sortListByEvidenceDesc(listAllForInEditWorkspaceDtls.evidenceTypeList);
    sortInEditListByParticipantAndEvidenceDesc(
      listAllForInEditWorkspaceDtls.wipDtls);

    //
    // get the menu and the context details
    //

    // Set the menu and context details
    // BEGIN, CR00122110, VM
    listAllForInEditWorkspaceDtls.menuData = determineMenuData(key).menuData;
    // END, CR00122110

    // BEGIN, CR00080440, CD
    listAllForInEditWorkspaceDtls.filteredEvidenceType = key.evidenceType;
    listAllForInEditWorkspaceDtls.filteredParticipantID =
      key.participantKey.key.participantID;

    // Set the context details
    listAllForInEditWorkspaceDtls.contextDescription =
      getContextDescription(caseKey);
    // END, CR00080440

    // BEGIN, CR00119847, DG
    //
    // Set the indicator for the Synchronize evidence link
    //
    // Get the list of Indirect evidence to be synchronized for this case
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    final CaseIDAndStatusKey identicalKey = new CaseIDAndStatusKey();

    identicalKey.caseID = key.caseIDKey.caseID;
    identicalKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;

    final CaseIDAndStatusKey nonIdenticalKey = new CaseIDAndStatusKey();

    nonIdenticalKey.caseID = key.caseIDKey.caseID;
    nonIdenticalKey.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;

    if (evidenceDescriptorObj.searchByCaseIDAndStatus(nonIdenticalKey).dtls
      .isEmpty()
      && evidenceDescriptorObj.searchByCaseIDAndStatus(identicalKey).dtls
        .isEmpty()) {
      listAllForInEditWorkspaceDtls.synchronizeLinkInd = false;
    } else {
      listAllForInEditWorkspaceDtls.synchronizeLinkInd = true;
    }
    // END, CR00119847

    return listAllForInEditWorkspaceDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all top level evidence types and descriptions for a case. This is
   * used primarily for retrieving the site map details. It is also used to
   * populate the create evidence drop down list.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier.
   *
   * @return List of top level evidence types and descriptions
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeAndDescList listTopLevelEvidenceTypesAndDescs(
    final CaseKey key) throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance()
      .listTopLevelEvidenceTypesAndDescs(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the site map details for the product.
   *
   * @boread Evidence
   *
   * @param key Contains the case identifier.
   *
   * @return The site map details for the SampleEGProduct product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceSiteMapDetailsList readEvidenceSiteMapDetails(
    final CaseKey key) throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance()
      .readEvidenceSiteMapDetails(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the input parameter, in this default implementation.
   *
   * @param key Contains the evidence type.
   *
   * @return Contains the evidence type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeDetails getEvidenceType(final EvidenceTypeDetails key)
    throws AppException, InformationalException {

    return key;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the input parameter, in this default implementation.
   *
   * @param key Contains the evidence type and participant identifier.
   *
   * @return Contains the evidence type and participant identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeAndParticipantIDDetails getEvidenceTypeAndParticipantID(
    final EvidenceTypeAndParticipantIDDetails key)
    throws AppException, InformationalException {

    return key;
  }

  // END, CR00032741

  // BEGIN, CR00078225, CD

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Determines if the evidence type is of type 'Participant Data'.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Participant
   *
   * @param key Contains the evidence type of the participant data E.g. Person.
   *
   * @return Returns <code>true</code> if the evidence is of type 'Participant
   * Data'. Otherwise <code>false</code> is returned in ParticipantDataInd
   * return object.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ParticipantDataIndDetails isEvidenceParticipantData(
    final EvidenceTypeKey key) throws AppException, InformationalException {

    // create the return struct
    final ParticipantDataIndDetails participantDataIndDetails =
      new ParticipantDataIndDetails();

    // Call controller operation to determine if it's participant evidence
    participantDataIndDetails.participantDataInd =
      EvidenceControllerFactory.newInstance().isEvidenceParticipantData(key);

    return participantDataIndDetails;
  }

  // END, CR00078225

  // BEGIN, CR00080440, CD

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all evidence types along with their associated descriptions for a
   * given case.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains a case identifier.
   *
   * @return List of evidence types and descriptions.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeAndDescList listEvidenceTypeAndDesc(final CaseKey key)
    throws AppException, InformationalException {

    // get all evidence for the case
    final EvidenceTypeAndDescList evidenceTypeAndDescList =
      EvidenceControllerFactory.newInstance().listEvidenceTypeAndDesc(key);

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    // Filter participant evidence out of the list.
    // As we are removing items from the list, work back from the end.
    for (int i = evidenceTypeAndDescList.dtls.size() - 1; i >= 0; i--) {
      evidenceTypeKey.evidenceType =
        evidenceTypeAndDescList.dtls.item(i).evidenceType;
      if (isEvidenceParticipantData(evidenceTypeKey).participantDataInd) {
        evidenceTypeAndDescList.dtls.remove(i);
      }
    }
    // BEGIN, CR00092862, CD
    // sort the list alphabetically by evidence description
    sortListByEvidenceDesc(evidenceTypeAndDescList);
    // END, CR00092862
    return evidenceTypeAndDescList;
  }

  // END, CR00080440

  // BEGIN, CR00119048, MR

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns case evidence tree details for an Evidence.
   *
   * @param key Case evidence tree key
   *
   * @return Case evidence tree details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public CaseEvidenceTreeDtls
    readCaseEvidenceTree(final CaseEvidenceTreeKey key)
      throws AppException, InformationalException {

    // Details to be returned.
    CaseEvidenceTreeDtls caseEvidenceTreeDtls = new CaseEvidenceTreeDtls();

    // CaseEvidenceTree manipulation variables
    final curam.core.sl.entity.intf.CaseEvidenceTree caseEvidenceTreeObj =
      curam.core.sl.entity.fact.CaseEvidenceTreeFactory.newInstance();

    try {
      caseEvidenceTreeDtls = caseEvidenceTreeObj.read(key);
    } catch (final RecordNotFoundException e) {// do nothing.
    }
    // Return the details.
    return caseEvidenceTreeDtls;
  }

  // END, CR00119048

  // BEGIN, CR00121379, MR

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Retrieves evidence type description for an Evidence.
   *
   * @boread Evidence
   *
   * @param key Evidence type.
   *
   * @return Evidence type description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeDescription
    getEvidenceTypeDescription(final EvidenceTypeDetails key)
      throws AppException, InformationalException {

    // Details to be returned.
    final EvidenceTypeDescription evidenceTypeDescription =
      new EvidenceTypeDescription();

    evidenceTypeDescription.evidenceTypeDesc =
      CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, key.evidenceType,
        TransactionInfo.getProgramLocale());

    return evidenceTypeDescription;
  }

  // END, CR00121379

  // BEGIN, CR00122110, VM
  // ___________________________________________________________________________
  /**
   * Generates the menu data for a Product Delivery on an Integrated Case.
   *
   * @param key
   * - Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData
    getICProductDeliveryMenuData(final CaseKey key)
      throws AppException, InformationalException {

    final curam.core.facade.infrastructure.struct.MenuData menuData =
      new curam.core.facade.infrastructure.struct.MenuData();

    final ProductHookManager productHookManager = new ProductHookManager();

    final CaseTypeCode caseTypeCode =
      CaseHeaderFactory.newInstance().readCaseTypeCode(key);

    final MenuData menuDataObj =
      productHookManager.getMenuDataHook(caseTypeCode.caseTypeCode);

    final ICProductDeliveryMenuDataKey icMenuDataKey =
      new ICProductDeliveryMenuDataKey();

    icMenuDataKey.caseID = key.caseID;

    menuData.menuData =
      menuDataObj.getICProductDeliveryMenuData(icMenuDataKey).menuData;

    return menuData;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for an Integrated Case.
   *
   * @param key
   * - Integrated Case identifier.
   *
   * @return Menu Data for the Integrated Case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData
    getIntegratedCaseMenuData(final IntegratedCaseMenuDataKey key)
      throws AppException, InformationalException {

    final curam.core.facade.infrastructure.struct.MenuData menuData =
      new curam.core.facade.infrastructure.struct.MenuData();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();

    final MenuData menuDataObj =
      productHookManager.getMenuDataHook(caseTypeCode.caseTypeCode);

    menuData.menuData = menuDataObj.getIntegratedCaseMenuData(key).menuData;

    return menuData;
  }

  // ___________________________________________________________________________
  /**
   * Function to determine the correct menu data for a case. This will differ
   * depending on whether the case is an Integrated Case or a Product Delivery
   * within an Integrated Case.
   *
   * @param key
   * - Contains the identifier of the case whose menu data is being
   * retrieved.
   * @return The menu data for the case
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData
    determineMenuData(final CaseIDParticipantIDEvidenceTypeKey key)
      throws AppException, InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseIDKey.caseID;

    final CaseHeaderDtls caseHeaderDtls =
      CaseHeaderFactory.newInstance().read(caseHeaderKey);

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

      final IntegratedCaseMenuDataKey integratedCaseMenuDataKey =
        new IntegratedCaseMenuDataKey();

      integratedCaseMenuDataKey.caseID = key.caseIDKey.caseID;

      return getIntegratedCaseMenuData(integratedCaseMenuDataKey);

    } else if (caseHeaderDtls.caseTypeCode
      .equals(CASETYPECODE.PRODUCTDELIVERY)) {

      if (caseHeaderDtls.integratedCaseID != 0) {

        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = key.caseIDKey.caseID;

        return getICProductDeliveryMenuData(caseKey);
      }
    }

    return null;
  }

  // END, CR00122110

  // ___________________________________________________________________________
  // BEGIN CR00199453, MC

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of evidence instance for the supplied key. Evidence
   * instance represent a group of evidence types having the same succession
   * id.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @param key The key based on which the evidence instance list is filtered.
   *
   * @return the list of evidence instances.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeWorkspaceListDetails
    listDistinctEvidence(final EvidenceTypeWorkspaceKey key)
      throws AppException, InformationalException {

    final EvidenceTypeWorkspaceListDetails evidenceListDetails =
      new EvidenceTypeWorkspaceListDetails();
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    final EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();
    final LocalisableString messageAll =
      new LocalisableString(BPOEVIDENCECONST.INF_CONST_ALL);
    Map<Long, String> participantMap = new Hashtable<Long, String>();
    ParticipantIDNameDetails participantIDNameDetails =
      new ParticipantIDNameDetails();

    evidenceListDetails.dtls = evidenceControllerObj.listEvidenceTypes(key);
    caseKey.caseID = key.caseID;
    evidenceListDetails.contextDescription.contextDescription =
      getContextDescription(caseKey).contextDescription;

    // Create default drop down "ALL" entries.
    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc =
      messageAll.getMessage(TransactionInfo.getProgramLocale());
    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName =
      messageAll.getMessage(TransactionInfo.getProgramLocale());
    evidenceListDetails.participantList.dtls.add(participantIDNameDetails);

    // Add to drop down lists to filter by participant.
    for (final EvidenceTypeWorkspaceDetails evidenceTypeWorkspaceDetails : evidenceListDetails.dtls.list
      .items()) {
      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID =
        evidenceTypeWorkspaceDetails.participantID;
      participantIDNameDetails.participantName =
        evidenceTypeWorkspaceDetails.concernRoleName;
      participantMap = new Hashtable<Long, String>();
      participantMap.put(participantIDNameDetails.participantID,
        participantIDNameDetails.participantName);
    }

    if (!participantMap.isEmpty()) {
      final Iterator<Long> iterate = participantMap.keySet().iterator();

      while (iterate.hasNext()) {
        participantIDNameDetails = new ParticipantIDNameDetails();
        participantIDNameDetails.participantID = iterate.next();
        participantIDNameDetails.participantName =
          participantMap.get(participantIDNameDetails.participantID);
        evidenceListDetails.participantList.dtls
          .add(participantIDNameDetails);
      }
    }
    evidenceListDetails.evidenceType = CodeTable
      .getOneItemForUserLocale(CASEEVIDENCE.TABLENAME, key.evidenceType);
    return evidenceListDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of evidence instance for the supplied key on search.
   * Evidence instance represent a group of evidence types having the same
   * succession id.
   *
   * @boread Evidence
   *
   * @param key The key based on which the evidence instance list is filtered.
   *
   * @return the list of evidence instances.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTypeWorkspaceListDetails
    listDistinctEvidenceOnSearch(final EvidenceTypeWorkspaceKey key)
      throws AppException, InformationalException {

    final EvidenceTypeWorkspaceListDetails evidenceListDetails =
      listDistinctEvidence(key);

    evidenceListDetails.isSearch = true;
    return evidenceListDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Sets the evidence status within the <code>EvidenceDescriptor</code> entity
   * to <code>EvidenceDescriptorStatus.CANCELLED</code>. The input key to this
   * method contains the evidence descriptor id, based on which the succession
   * id of the evidence type is retrieved. All <code>EvidenceDescriptor</code>
   * records having this succession id will have it's status set to canceled.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key ID of the deleted Evidence to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void deleteEvidenceFromWorkspace(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.deleteEvidenceFromWorkspace(key);
  }

  // END, CR00199453
  // BEGIN, CR00204924, GSP

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all 'Active' evidences for a case, filtering by participant and
   * evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Participant
   *
   * @param key Contains a case identifier, participant identifier and an
   * evidence type.
   *
   * @return List of 'Active' evidence instance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllActiveEVDInstanceWorkspaceDtls
    listAllActiveEVDInstanceWorkspaceDtls(
      final CaseIDParticipantIDEvidenceTypeKey key)
      throws AppException, InformationalException {

    // create the return struct
    final ListAllActiveEVDInstanceWorkspaceDtls listAllForActiveWorkspaceDtls =
      new ListAllActiveEVDInstanceWorkspaceDtls();

    // Create default drop down "ALL" entries
    EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

    final LocalisableString messageAll =
      new LocalisableString(curam.message.BPOEVIDENCECONST.INF_CONST_ALL);

    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc =
      messageAll.getMessage(TransactionInfo.getProgramLocale());

    listAllForActiveWorkspaceDtls.evidenceTypeList.dtls
      .addRef(evidenceTypeAndDesc);

    ParticipantIDNameDetails participantIDNameDetails =
      new ParticipantIDNameDetails();

    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName =
      messageAll.getMessage(TransactionInfo.getProgramLocale());
    listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
      .addRef(participantIDNameDetails);

    // Call method for retrieving the list of all active details
    final CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseIDKey.caseID;

    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();
    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList =
      evidenceController.listAllactiveEvdInstances(caseKey);

    // Create drop down lists and filter list of evidence
    for (int i = 0; i < activeEvdInstanceDtlsList.dtls.size(); i++) {

      // BEGIN, CR00466527, SH
      final ActiveEvdInstanceDtls activeEvdInstanceDtls =
        activeEvdInstanceDtlsList.dtls.item(i);

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = activeEvdInstanceDtls.evidenceID;
      eiEvidenceKey.evidenceType = activeEvdInstanceDtls.evidenceType;

      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        evidenceController.getEvidenceSummaryDetails(eiEvidenceKey);

      activeEvdInstanceDtls.summary = LocalizableXMLStringHelper
        .toClientFormattedText(eiFieldsForListDisplayDtls.summary);
      // END, CR00466527, SH

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID =
        activeEvdInstanceDtls.participantID;
      participantIDNameDetails.participantName =
        activeEvdInstanceDtls.concernRoleName;

      for (int j =
        0; j < listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
          .size(); j++) {
        final ParticipantIDNameDetails current =
          listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
            .item(j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls
          .add(participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType = activeEvdInstanceDtls.evidenceType;
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());

      for (int j = 0; j < listAllForActiveWorkspaceDtls.evidenceTypeList.dtls
        .size(); j++) {
        final EvidenceTypeAndDesc current =
          listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.item(j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForActiveWorkspaceDtls.evidenceTypeList.dtls
          .add(evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
        && (key.participantKey.key.participantID == 0
          || participantIDNameDetails.participantID == key.participantKey.key.participantID)) {

        listAllForActiveWorkspaceDtls.activeEvdInstanceDtlsList.dtls
          .add(activeEvdInstanceDtls);
      }
    }

    sortListByParticipant(
      listAllForActiveWorkspaceDtls.participantIDNameDetailsList);
    sortListByEvidenceDesc(listAllForActiveWorkspaceDtls.evidenceTypeList);

    // get the filter and the context details
    listAllForActiveWorkspaceDtls.filteredEvidenceType = key.evidenceType;
    listAllForActiveWorkspaceDtls.filteredParticipantID =
      key.participantKey.key.participantID;

    // Set the context details
    listAllForActiveWorkspaceDtls.contextDescription =
      getContextDescription(caseKey);

    // BEGIN, CR00242523, CSH
    final VerificationInterface verificationObj =
      evidenceVerification.getVerificationImpl();

    // BEGIN, CR00444317, DG

    // Set the flag for any issues OR verifications on the case
    if (!evidenceIssues.listIssuesForCase(key.caseIDKey.caseID).dtls
      .isEmpty()) {

      listAllForActiveWorkspaceDtls.hasVerificationsOrIssues = true;
    } else {

      // Check if any outstanding verifications exist
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = key.caseIDKey.caseID;
      boolean verificationsExist = false;

      for (final Integer evidenceVerificationCount : verificationObj
        .listOutstandingVerificationAndEvidenceTypeForCase(caseIDKey, true)
        .values()) {
        if (evidenceVerificationCount > 0) {
          verificationsExist = true;
          break;
        }
      }
      if (verificationsExist) {
        listAllForActiveWorkspaceDtls.hasVerificationsOrIssues = true;
      } else {
        // No verifications or issues have been found on the case
        listAllForActiveWorkspaceDtls.hasVerificationsOrIssues = false;
      }
    }
    // END, CR00242523
    // END, CR00444317

    return listAllForActiveWorkspaceDtls;
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all succession evidence changes on an 'Active' evidence instance.
   *
   * There is another version of this method - listActiveEvdInstanceChanges1.
   * Whenever there is any change
   * made to this method, developer is requested to visit -
   * listActiveEvdInstanceChanges1 as well.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvdInstanceChangeDtlsList listActiveEvdInstanceChanges(
    final curam.core.sl.infrastructure.entity.struct.SuccessionID key)
    throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method - listActiveEvdInstanceChanges1.
    // Whenever there is any change
    // made to this method, developer is requested to visit -
    // listActiveEvdInstanceChanges1 as well.
    // END, CR00452604
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      evidenceController.listActiveEvdInstanceChanges(key);

    // BEGIN, CR00287546, ELG
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsListRet =
      new EvdInstanceChangeDtlsList();

    // BEGIN, CR00242523, CSH
    evdInstanceChangeDtlsListRet.verificationOrIssuesExist = false;

    for (final EvdInstanceChangeDtls details : evdInstanceChangeDtlsList.dtlsList) {

      if (details.verificationOrIssuesExist
        && !evdInstanceChangeDtlsListRet.verificationOrIssuesExist) {
        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsListRet.verificationOrIssuesExist = true;
      }

      if (!details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT)
        && !details.statusCode
          .equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALREJECTED)) {
        evdInstanceChangeDtlsListRet.dtlsList.addRef(details);
      }

    }
    // END, CR00242523

    // BEGIN, CR00250011, PMD
    if (Configuration
      .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsListRet.evdBrokerEnabled = true;
    }
    // END, CR00250011
    evdInstanceChangeDtlsListRet.inEditExistInd =
      evdInstanceChangeDtlsList.inEditExistInd;

    return evdInstanceChangeDtlsListRet;
    // END, CR00287546

  }

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Lists all succession evidence changes on an Evidence instance.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvdInstanceChangeDtlsList listEvdInstanceChanges(
    final SuccessionID key) throws AppException, InformationalException {

    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      evidenceController.listEvdInstanceChanges(key);

    // BEGIN, CR00389944, ZV
    String displayDeletedEvidence =
      Configuration.getProperty(EnvVars.ENV_DISPLAY_DELETED_EVIDENCE);

    if (displayDeletedEvidence == null) {
      displayDeletedEvidence = EnvVars.ENV_DISPLAY_DELETED_EVIDENCE;
    }

    final boolean displayDeletedEvidenceInd =
      displayDeletedEvidence.equals(EnvVars.ENV_VALUE_YES);

    // BEGIN, CR00287546, ELG
    // return structure
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsListRet =
      new EvdInstanceChangeDtlsList();

    // BEGIN, CR00242523, CSH
    evdInstanceChangeDtlsListRet.verificationOrIssuesExist = false;
    for (final EvdInstanceChangeDtls details : evdInstanceChangeDtlsList.dtlsList) {

      if (details.verificationOrIssuesExist
        && !evdInstanceChangeDtlsListRet.verificationOrIssuesExist) {
        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsListRet.verificationOrIssuesExist = true;
      }

      if (!details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT)
        && !details.statusCode
          .equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALREJECTED)
        && (displayDeletedEvidenceInd
          || !details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.CANCELED))) {
        evdInstanceChangeDtlsListRet.dtlsList.addRef(details);
      }

    }
    // END, CR00242523
    // END, CR00389944

    // BEGIN, CR00250011, PMD
    if (Configuration
      .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsListRet.evdBrokerEnabled = true;
    }
    // END, CR00250011

    evdInstanceChangeDtlsListRet.inEditExistInd =
      evdInstanceChangeDtlsList.inEditExistInd;

    // BEGIN, CR00445130, JD

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    for (int j =
      0; j < evdInstanceChangeDtlsList.dtlsList.items().length; j++) {
      caseKey.caseID = evdInstanceChangeDtlsList.dtlsList.item(j).caseID;

      // Create a new instance of interface EvidenceUpdatesAllowed.
      // And determine whether a case, depending on it's status will allow for
      // Enabling/Disabling page-level actions.
      final EvidenceUpdatesAllowed evidenceUpdatesAllowed =
        new EvidenceUpdatesAllowed();
      final boolean evidenceUpdatesAllowedInd =
        evidenceUpdatesAllowed.isUpdatesAllowed(caseKey);

      // Set the appropriate indicator in return struct
      if (evidenceUpdatesAllowedInd == false) {
        evdInstanceChangeDtlsListRet.caseUpdatesAllowed = false;

        // Set the readOnlyInd to true for each evidence item, to disable the
        // row-level actions
        for (int i =
          0; i < evdInstanceChangeDtlsList.dtlsList.items().length; i++) {
          evdInstanceChangeDtlsList.dtlsList.item(i).readOnlyInd = true;
        }
      } else {
        evdInstanceChangeDtlsListRet.caseUpdatesAllowed = true;
      }

      if (evdInstanceChangeDtlsListRet.caseUpdatesAllowed == true
        && evdInstanceChangeDtlsListRet.evdBrokerEnabled == true) {
        evdInstanceChangeDtlsListRet.evdBrokerEnabledUpdatesAllowed = true;
      } else if (evdInstanceChangeDtlsListRet.caseUpdatesAllowed == false
        && evdInstanceChangeDtlsListRet.evdBrokerEnabled == true) {
        evdInstanceChangeDtlsListRet.evdBrokerEnabledNoUpdatesAllowed = true;
      } else if (evdInstanceChangeDtlsListRet.caseUpdatesAllowed == true
        && evdInstanceChangeDtlsListRet.evdBrokerEnabled == false) {
        evdInstanceChangeDtlsListRet.evdBrokerDisabledUpdatesAllowed = true;
      } else if (evdInstanceChangeDtlsListRet.caseUpdatesAllowed == false
        && evdInstanceChangeDtlsListRet.evdBrokerEnabled == false) {
        evdInstanceChangeDtlsListRet.evdBrokerDisabledNoUpdatesAllowed = true;
      }
    }

    // END, CR00445130, JD

    return evdInstanceChangeDtlsListRet;
    // END, CR00287546

  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all succession evidence changes on an 'In Edit' evidence instance.
   * There is another version of this method - listInEditEvdInstanceChanges1.
   * Therefore, if
   * there is any changes made to this method then developer should also visit -
   * listInEditEvdInstanceChanges1.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvdInstanceChangeDtlsList listInEditEvdInstanceChanges(
    final SuccessionID key) throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method - listInEditEvdInstanceChanges1.
    // Therefore, if
    // there is any changes made to this method then developer should also visit
    // - listInEditEvdInstanceChanges1.
    // END, CR00452604
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      evidenceController.listInEditEvdInstanceChanges(key);

    // BEGIN, CR00242523, CSH
    // Check if any issues or verifications exist
    evdInstanceChangeDtlsList.verificationOrIssuesExist = false;
    for (int i = 0; i < evdInstanceChangeDtlsList.dtlsList.size(); i++) {

      if (evdInstanceChangeDtlsList.dtlsList
        .item(i).verificationOrIssuesExist) {

        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsList.verificationOrIssuesExist = true;
        break;
      }
    }
    // END, CR00242523

    // BEGIN, CR00250011, PMD
    if (Configuration
      .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsList.evdBrokerEnabled = true;
    }
    // END, CR00250011

    return evdInstanceChangeDtlsList;
  }

  // END, CR00204924

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of evidence types grouped by categories and parent evidence
   * types as an XML string to be displayed on the evidence dash-board.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains a case identifier and a participant identifier.
   *
   * @return Evidence types in an XML string format.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceSiteMapDetails
    getEvidenceDashboardData(final CaseIDAndParticipantIDDetails key)
      throws AppException, InformationalException {

    // BEGIN, CR00295440, PMD
    final EvidenceSiteMapDetails evidenceSiteMapDetails =
      new EvidenceSiteMapDetails();

    // Instance of helper class to build the XML
    final XMLBuilder xml =
      new XMLBuilder(EvidenceDashboardConst.kEvidenceDashboard);

    setupXML(xml, key, null);

    final EvidenceDashboardDetailsList evidenceDashboardDetailsList =
      EvidenceTypeFactory.newInstance().getEvidenceDashboardDetails(key);

    String currentCategory = "";
    final String locale = TransactionInfo.getProgramLocale();
    boolean categoryProcessed = false;

    final EvidenceCatDashboardDetailsList evidenceCatDashboardDetailsList =
      new EvidenceCatDashboardDetailsList();
    EvidenceCatDashboardDetails evidenceCatDashboardDetails = null;
    EvidenceTypeDashboardDetailsList evidenceTypeDashboardDetailsList = null;

    final Comparator<EvidenceCatDashboardDetails> evidenceCategoryComparator =
      new SortDashboardEvdCategoriesBySortOrderAndDesc();
    final Comparator<EvidenceTypeDashboardDetails> evidenceTypeComparator =
      new SortDashboardEvdTypesBySortOrderAndDesc();

    final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey =
      new CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = key.caseID;
    // BEGIN, CR00361859, CSH
    // Sort this list by category
    if (!evidenceDashboardDetailsList.dtls.isEmpty()) {
      Collections.sort(evidenceDashboardDetailsList.dtls,
        new Comparator<EvidenceDashboardDetails>() {

          @Override
          public int compare(final EvidenceDashboardDetails obj1,
            final EvidenceDashboardDetails obj2) {

            // BEGIN, CR00434343, JAY
            final String type1 = CodetableUtil.getCachedCodetableDescription(
              EVIDENCECATEGORY.TABLENAME, obj1.category);
            final String type2 = CodetableUtil.getCachedCodetableDescription(
              EVIDENCECATEGORY.TABLENAME, obj2.category);

            // END, CR00434343, JAY

            return type1.compareTo(type2);
          }
        });
    }
    // END, CR00361859

    // BEGIN, CR00456443, DG

    // Get the details of outstanding verifications for the case.
    Integer outstandingCount = 0;
    final curam.core.sl.struct.CaseIDKey caseKey =
      new curam.core.sl.struct.CaseIDKey();

    caseKey.caseID = key.caseID;
    final Map<String, Integer> verCountAndEviTypeDtlsList =
      evidenceVerification.getVerificationImpl()
        .listOutstandingVerificationAndEvidenceTypeForCase(caseKey, false);

    // END, CR00456443

    // Get all relevant category and evidence type details and sort into the
    // correct order
    for (final EvidenceDashboardDetails evidenceDashboardDetails : evidenceDashboardDetailsList.dtls) {
      if (!currentCategory.equals(evidenceDashboardDetails.category)
        || !categoryProcessed) {

        if (categoryProcessed) {
          Collections.sort(evidenceTypeDashboardDetailsList.evdTypeDetails,
            evidenceTypeComparator);
          evidenceCatDashboardDetails.evdTypeList =
            evidenceTypeDashboardDetailsList;
          evidenceCatDashboardDetailsList.evdCatDetails
            .addRef(evidenceCatDashboardDetails);
        }

        currentCategory = evidenceDashboardDetails.category;
        evidenceCatDashboardDetails = new EvidenceCatDashboardDetails();
        evidenceCatDashboardDetails.category =
          evidenceDashboardDetails.category;
        evidenceCatDashboardDetails.description =
          CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
            evidenceDashboardDetails.category, locale);
        evidenceCatDashboardDetails.sortOrder = CodeTable
          .sortOrder(EVIDENCECATEGORY.TABLENAME, currentCategory, locale);
        categoryProcessed = true;
        evidenceTypeDashboardDetailsList =
          new EvidenceTypeDashboardDetailsList();
      }

      final EvidenceTypeDashboardDetails evidenceTypeDashboardDetails =
        new EvidenceTypeDashboardDetails();

      evidenceTypeDashboardDetails.type =
        evidenceDashboardDetails.evidenceType;
      evidenceTypeDashboardDetails.description =
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
          evidenceDashboardDetails.evidenceType, locale);
      evidenceTypeDashboardDetails.sortOrder =
        evidenceDashboardDetails.sortOrder;
      evidenceTypeDashboardDetails.inEditCount =
        evidenceDashboardDetails.inEditCount;
      evidenceTypeDashboardDetails.isRecorded =
        evidenceDashboardDetails.isRecorded;

      if (evidenceDashboardDetails.isRecorded) {
        // BEGIN, CR00456443, DG
        outstandingCount = verCountAndEviTypeDtlsList
          .get(evidenceDashboardDetails.evidenceType);

        if (outstandingCount == null) {
          outstandingCount = 0;
        }
        evidenceTypeDashboardDetails.numVerifications = outstandingCount;
        // END, CR00443445
        evidenceTypeDashboardDetails.numIssues =
          evidenceIssues.listIssuesForEvidenceType(key.caseID,
            CASEEVIDENCEEntry.get(evidenceDashboardDetails.evidenceType)).dtls
              .size();
      }

      evidenceTypeDashboardDetailsList.evdTypeDetails
        .addRef(evidenceTypeDashboardDetails);
    }

    if (evidenceTypeDashboardDetailsList != null
      && !evidenceTypeDashboardDetailsList.evdTypeDetails.isEmpty()) {
      Collections.sort(evidenceTypeDashboardDetailsList.evdTypeDetails,
        evidenceTypeComparator);
      evidenceCatDashboardDetails.evdTypeList =
        evidenceTypeDashboardDetailsList;
      evidenceCatDashboardDetailsList.evdCatDetails
        .addRef(evidenceCatDashboardDetails);

      Collections.sort(evidenceCatDashboardDetailsList.evdCatDetails,
        evidenceCategoryComparator);
    }

    for (final EvidenceCatDashboardDetails xmlCatDashboardDetails : evidenceCatDashboardDetailsList.evdCatDetails) {

      xml.createTag(EvidenceDashboardConst.kEvidenceCategory);
      xml.addAttribute(EvidenceDashboardConst.kEvidenceCategoryName,
        xmlCatDashboardDetails.description);
      xml.addAttribute(EvidenceDashboardConst.kSortOrder,
        String.valueOf(xmlCatDashboardDetails.sortOrder));

      for (final EvidenceTypeDashboardDetails xmlEvidenceTypeDashboardDetails : xmlCatDashboardDetails.evdTypeList.evdTypeDetails) {
        constructEvidence(xml, xmlEvidenceTypeDashboardDetails, null);
        xml.closeTag(); // </EVIDENCE>
      }
      xml.closeTag(); // </EVIDENCE_CATEGORY>
    }

    xml.closeTag(); // </EVIDENCE_DASHBOARD>

    evidenceSiteMapDetails.evidenceTypes = xml.getXmlString();
    // END, CR00295440

    return evidenceSiteMapDetails;
  }

  // BEGIN, CR00457057, EC

  /**
   * Returns a list of evidence types grouped by categories and parent evidence
   * types with relationship as an XML string to be displayed on the evidence
   * dash-board.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains a case identifier and a participant identifier.
   *
   * @return Evidence types in an XML string format.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public EvidenceSiteMapDetails getEvidenceDashboardDataWithRelationship(
    final CaseIDAndParticipantIDDetails key)
    throws AppException, InformationalException {

    final EvidenceSiteMapDetails evidenceSiteMapDetails =
      new EvidenceSiteMapDetails();

    // Instance of helper class to build the XML
    XMLBuilder xml =
      new XMLBuilder(EvidenceDashboardConst.kEvidenceDashboard);

    setupXML(xml, key, null);

    final EvidenceDashboardDetailsList evidenceDashboardDetailsList =
      EvidenceTypeFactory.newInstance().getEvidenceDashboardDetails(key);

    xml =
      groupEvidencePerCategory(evidenceDashboardDetailsList, null, key, xml);

    evidenceSiteMapDetails.evidenceTypes = xml.getXmlString();

    return evidenceSiteMapDetails;
  }

  /**
   * Returns a list of evidence types grouped by categories and parent evidence
   * types with relationship as an XML string to be displayed on the evidence
   * dash-board. If a filter ID is specified, only the evidence types within
   * that filter group are returned.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains a case identifier and a participant identifier.
   *
   * @param filterKey Contains a filter identifier.
   *
   * @return Evidence types in an XML string format.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public EvidenceSiteMapDetails
    getEvidenceDashboardDataWithRelationshipAndFilter(
      final CaseIDAndParticipantIDDetails key,
      final DashboardFilterIDKey filterKey)
      throws AppException, InformationalException {

    final EvidenceSiteMapDetails evidenceSiteMapDetails =
      new EvidenceSiteMapDetails();

    // Instance of helper class to build the XML
    XMLBuilder xml =
      new XMLBuilder(EvidenceDashboardConst.kEvidenceDashboard);

    setupXML(xml, key, filterKey);

    // getting all the filter groups configured for the current case type
    // CaseHeaderDtls caseHeader = caseHeaderAdapter.read(key.caseID, false);
    final DashboardFilterCaseKey caseTypeKey = new DashboardFilterCaseKey();

    // caseTypeKey.caseTypeCode = caseHeader.caseTypeCode;
    caseTypeKey.caseTypeCodeID =
      caseHeaderDAO.get(key.caseID).getAdminConfigurationID();

    // getting all the evidence filters groups for the current case type
    final DashboardFilterDetailsList filtersList =
      EvidenceDashboardFilterFactory.newInstance()
        .listCurrentCaseTypeDashboardFilters(caseTypeKey);

    // constructing the XML for the filter groups
    constructFilters(xml, filtersList, filterKey);

    // getting the list of evidence types associated to the current case type
    final EvidenceDashboardDetailsList evidenceDashboardDetailsList =
      EvidenceTypeFactory.newInstance().getEvidenceDashboardDetails(key);

    // getting the list of evidence types in the current filter group
    EvidenceDashboardDetailsList filteredEvidenceDetailsList = null;

    long groupFilterID = 0;

    if (filterKey != null && filterKey.groupFilterID != null
      && !filterKey.groupFilterID.equals("")
      && !filterKey.groupFilterID.equals("null")
      && !filterKey.groupFilterID.equals(CuramConst.gkDash)) {

      try {
        groupFilterID = Long.valueOf(filterKey.groupFilterID);
      } catch (final NumberFormatException ex) {
        ex.printStackTrace();
      }

      final DashboardFilterCaseKey filterCaseKey =
        new DashboardFilterCaseKey();

      // filterCaseKey.caseTypeCode = caseHeader.caseTypeCode;
      filterCaseKey.caseTypeCodeID =
        caseHeaderDAO.get(key.caseID).getAdminConfigurationID();
      filterCaseKey.filterID = groupFilterID;

      final DashboardFilterEvidenceTypeDetailsList evidenceTypesInFilter =
        EvidenceDashboardFilterFactory.newInstance()
          .listEvidenceTypesForFilter(filterCaseKey);

      // out of the list of evidence types associated to current case,
      // we are only keeping the ones that belong to the current filter group
      // too
      filteredEvidenceDetailsList = getCommonEvidenceForFilterAndCase(
        evidenceDashboardDetailsList, evidenceTypesInFilter);
    }

    xml = groupEvidencePerCategory(evidenceDashboardDetailsList,
      filteredEvidenceDetailsList, key, xml);

    evidenceSiteMapDetails.evidenceTypes = xml.getXmlString();
    return evidenceSiteMapDetails;
  }

  // BEGIN, CR00459976 , DM
  /**
   * Parses two lists of evidence types, one being made of the evidence types
   * assigned to a case,
   * and the other being the evidence types contained by a filter group.
   *
   * @param evidenceListForCase list of evidence types assigned to a case type
   * @paramevidenceTypesInFilter list of evidence types contained by a filter
   * group
   *
   * @return the evidence types that belong to both lists
   *
   */
  private EvidenceDashboardDetailsList getCommonEvidenceForFilterAndCase(
    final EvidenceDashboardDetailsList evidenceListForCase,
    final DashboardFilterEvidenceTypeDetailsList evidenceTypesInFilter) {

    final EvidenceDashboardDetailsList intersectionList =
      new EvidenceDashboardDetailsList();

    for (final EvidenceDashboardDetails caseEvidenceType : evidenceListForCase.dtls) {
      for (final DashboardFilterEvidenceTypeDetails filterEvidenceType : evidenceTypesInFilter.dtls) {
        if (caseEvidenceType.evidenceType
          .equals(filterEvidenceType.evidenceType)) {

          if (filterEvidenceType.requiredInd
            .equalsIgnoreCase(DASHBOARDEVIDENCEREQUIRED.YES)) {
            caseEvidenceType.isMandatory = true;
          }

          intersectionList.dtls.addRef(caseEvidenceType);
          break;
        }
      }
    }
    return intersectionList;

  }

  /**
   * Parses two lists of evidence types, one being made of the evidence types
   * assigned to a category,
   * and the other being the evidence types contained by a filter group.
   *
   * @param evidenceListForCategory list of evidence types assigned to a
   * category
   * @param evidenceListForFilter list of evidence types contained by a filter
   * group
   *
   * @return the evidence types that belong to both lists
   *
   */
  private EvidenceTypeDashboardDetailsList
    getCommonEvidenceForFilterAndCategory(
      final EvidenceDashboardDetailsList evidenceListForFilter,
      final EvidenceTypeDashboardDetailsList evidenceListForCategory) {

    final EvidenceTypeDashboardDetailsList intersectionList =
      new EvidenceTypeDashboardDetailsList();

    for (final EvidenceTypeDashboardDetails categoryEvidenceType : evidenceListForCategory.evdTypeDetails) {
      for (final EvidenceDashboardDetails filterEvidenceType : evidenceListForFilter.dtls) {
        if (filterEvidenceType.evidenceType
          .equals(categoryEvidenceType.type)) {
          categoryEvidenceType.isMandatory =
            Boolean.valueOf(filterEvidenceType.isMandatory);
          intersectionList.evdTypeDetails.addRef(categoryEvidenceType);
          break;
        }
      }
    }
    return intersectionList;

  }

  // END, CR00459976

  private XMLBuilder groupEvidencePerCategory(
    final EvidenceDashboardDetailsList evidenceDashboardDetailsList,
    final EvidenceDashboardDetailsList filteredEvidenceDetailsList,
    final CaseIDAndParticipantIDDetails key, final XMLBuilder xml)
    throws AppException, InformationalException {

    final EvidenceCatDashboardDetailsList evidenceCatDashboardDetailsList =
      new EvidenceCatDashboardDetailsList();
    EvidenceCatDashboardDetails evidenceCatDashboardDetails = null;
    final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey =
      new CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = key.caseID;

    // Sort this list by category
    if (!evidenceDashboardDetailsList.dtls.isEmpty()) {
      Collections.sort(evidenceDashboardDetailsList.dtls,
        new Comparator<EvidenceDashboardDetails>() {

          @Override
          public int compare(final EvidenceDashboardDetails obj1,
            final EvidenceDashboardDetails obj2) {

            final String type1 = CodetableUtil.getCachedCodetableDescription(
              EVIDENCECATEGORY.TABLENAME, obj1.category);
            final String type2 = CodetableUtil.getCachedCodetableDescription(
              EVIDENCECATEGORY.TABLENAME, obj2.category);

            return type1.compareTo(type2);
          }
        });
    }

    // Get the details of outstanding verifications for the case.
    Integer outstandingCount = 0;
    final curam.core.sl.struct.CaseIDKey caseKey =
      new curam.core.sl.struct.CaseIDKey();

    caseKey.caseID = key.caseID;
    final Map<String, Integer> verCountAndEviTypeDtlsList =
      evidenceVerification.getVerificationImpl()
        .listOutstandingVerificationAndEvidenceTypeForCase(caseKey, false);

    // Create hasp map to store the children that have been configured with the
    // case.
    HashMap<String, EvidenceTypeDashboardDetails> childHM = null;

    childHM = new HashMap<String, EvidenceTypeDashboardDetails>();

    final Comparator<EvidenceCatDashboardDetails> evidenceCategoryComparator =
      new SortDashboardEvdCategoriesBySortOrderAndDesc();
    final Comparator<EvidenceTypeDashboardDetails> evidenceTypeComparator =
      new SortDashboardEvdTypesBySortOrderAndDesc();

    String currentCategory = "";
    boolean categoryProcessed = false;
    final String locale = TransactionInfo.getProgramLocale();

    EvidenceTypeDashboardDetailsList evidenceTypeDashboardDetailsList = null;

    // Get all relevant category and evidence type details and sort into the
    // correct order
    for (final EvidenceDashboardDetails evidenceDashboardDetails : evidenceDashboardDetailsList.dtls) {

      if (!currentCategory.equals(evidenceDashboardDetails.category)
        || !categoryProcessed) {

        if (categoryProcessed) {
          Collections.sort(evidenceTypeDashboardDetailsList.evdTypeDetails,
            evidenceTypeComparator);
          evidenceCatDashboardDetails.evdTypeList =
            evidenceTypeDashboardDetailsList;
          evidenceCatDashboardDetailsList.evdCatDetails
            .addRef(evidenceCatDashboardDetails);
        }

        currentCategory = evidenceDashboardDetails.category;
        evidenceCatDashboardDetails = new EvidenceCatDashboardDetails();
        evidenceCatDashboardDetails.category =
          evidenceDashboardDetails.category;
        evidenceCatDashboardDetails.description =
          CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
            evidenceDashboardDetails.category, locale);
        evidenceCatDashboardDetails.sortOrder = CodeTable
          .sortOrder(EVIDENCECATEGORY.TABLENAME, currentCategory, locale);
        categoryProcessed = true;
        evidenceTypeDashboardDetailsList =
          new EvidenceTypeDashboardDetailsList();
      }

      final EvidenceTypeDashboardDetails evidenceTypeDashboardDetails =
        new EvidenceTypeDashboardDetails();

      evidenceTypeDashboardDetails.type =
        evidenceDashboardDetails.evidenceType;
      evidenceTypeDashboardDetails.description =
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
          evidenceDashboardDetails.evidenceType, locale);
      evidenceTypeDashboardDetails.sortOrder =
        evidenceDashboardDetails.sortOrder;
      evidenceTypeDashboardDetails.inEditCount =
        evidenceDashboardDetails.inEditCount;
      evidenceTypeDashboardDetails.isRecorded =
        evidenceDashboardDetails.isRecorded;
      evidenceTypeDashboardDetails.childrenList =
        evidenceDashboardDetails.childrenList;
      evidenceTypeDashboardDetails.parentList =
        evidenceDashboardDetails.parentList;
      evidenceTypeDashboardDetails.readOnly =
        evidenceDashboardDetails.readOnly;
      evidenceTypeDashboardDetails.isMandatory =
        evidenceDashboardDetails.isMandatory;
      // BEGIN, CR00461154, DM
      evidenceTypeDashboardDetails.selectedParentList =
        evidenceDashboardDetails.selectedParentList;
      // END, CR00461154

      if (evidenceDashboardDetails.isRecorded) {
        outstandingCount = verCountAndEviTypeDtlsList
          .get(evidenceDashboardDetails.evidenceType);

        if (outstandingCount == null) {
          outstandingCount = 0;
        }
        evidenceTypeDashboardDetails.numVerifications = outstandingCount;
        evidenceTypeDashboardDetails.numIssues =
          evidenceIssues.listIssuesForEvidenceType(key.caseID,
            CASEEVIDENCEEntry.get(evidenceDashboardDetails.evidenceType)).dtls
              .size();
      }

      evidenceTypeDashboardDetailsList.evdTypeDetails
        .addRef(evidenceTypeDashboardDetails);

      // Add the evidence type to the list if it has parents.
      if (!evidenceDashboardDetails.parentList.equals(CuramConst.gkEmpty)
        && (filteredEvidenceDetailsList == null
          || filteredEvidenceDetailsList.dtls == null
          || filteredEvidenceDetailsList.dtls
            .contains(evidenceDashboardDetails))) {
        childHM.put(evidenceTypeDashboardDetails.type,
          evidenceTypeDashboardDetails);
      }
    }

    if (evidenceTypeDashboardDetailsList != null
      && !evidenceTypeDashboardDetailsList.evdTypeDetails.isEmpty()) {
      Collections.sort(evidenceTypeDashboardDetailsList.evdTypeDetails,
        evidenceTypeComparator);
      evidenceCatDashboardDetails.evdTypeList =
        evidenceTypeDashboardDetailsList;
      evidenceCatDashboardDetailsList.evdCatDetails
        .addRef(evidenceCatDashboardDetails);

      Collections.sort(evidenceCatDashboardDetailsList.evdCatDetails,
        evidenceCategoryComparator);
    }

    for (final EvidenceCatDashboardDetails xmlCatDashboardDetails : evidenceCatDashboardDetailsList.evdCatDetails) {
      // construct the XML for each of the evidence types (and its children) in
      // the current category
      xml.createTag(EvidenceDashboardConst.kEvidenceCategory);
      xml.addAttribute(EvidenceDashboardConst.kEvidenceCategoryName,
        xmlCatDashboardDetails.description);
      xml.addAttribute(EvidenceDashboardConst.kSortOrder,
        String.valueOf(xmlCatDashboardDetails.sortOrder));

      if (filteredEvidenceDetailsList != null) {
        xmlCatDashboardDetails.evdTypeList =
          getCommonEvidenceForFilterAndCategory(filteredEvidenceDetailsList,
            xmlCatDashboardDetails.evdTypeList);
      }

      for (final EvidenceTypeDashboardDetails xmlEvidenceTypeDashboardDetails : xmlCatDashboardDetails.evdTypeList.evdTypeDetails) {
        // If the evidence type is a top parent.
        if (xmlEvidenceTypeDashboardDetails.parentList
          .equals(CuramConst.gkEmpty)) {
          // Construct evidence.
          constructEvidence(xml, xmlEvidenceTypeDashboardDetails, null);
          // Build the relationship of the evidence type.
          buildRelationship(xml, childHM, xmlEvidenceTypeDashboardDetails);
          xml.closeTag(); // </EVIDENCE>
        }
      }
      xml.closeTag(); // </EVIDENCE_CATEGORY>
    }

    xml.closeTag(); // </EVIDENCE_DASHBOARD>

    return xml;
  }

  /**
   * Constructs the xml for the filter groups.
   *
   * @param xml the builder object for xml construction.
   * @param xmlEvidenceTypeDashboardDetails the parent evidence type.
   */
  private void constructFilters(final XMLBuilder xml,
    final DashboardFilterDetailsList filtersList,
    final DashboardFilterIDKey filterKey) {

    final Comparator<DashboardFilterDetails> filterComparator =
      new SortEvidenceFiltersByName();

    Collections.sort(filtersList.dtls, filterComparator);

    long groupFilterID = 0;

    if (filterKey != null && filterKey.groupFilterID != null
      && !filterKey.groupFilterID.equals("null")
      && !filterKey.groupFilterID.equals("")
      && !filterKey.groupFilterID.equals(CuramConst.gkDash)) {
      try {
        groupFilterID = Long.valueOf(filterKey.groupFilterID);
      } catch (final NumberFormatException ex) {
        ex.printStackTrace();
      }
    }

    xml.createTag(EvidenceDashboardConst.kEvidenceFilters);

    if (filtersList != null && filtersList.dtls != null) {
      for (final DashboardFilterDetails filter : filtersList.dtls) {
        xml.createTag(EvidenceDashboardConst.kEvidenceFilterGroup);
        xml.addAttribute(EvidenceDashboardConst.kEvidenceFilterGroupName,
          filter.name);
        xml.addAttribute(EvidenceDashboardConst.kEvidenceFilterGroupId,
          String.valueOf(filter.dashBoardFilterID));
        // marking the current filter as being "selected"
        if (filter.dashBoardFilterID == groupFilterID) {
          xml.addAttribute(
            EvidenceDashboardConst.kEvidenceFilterGroupSelected, "true");
        } else {
          xml.addAttribute(
            EvidenceDashboardConst.kEvidenceFilterGroupSelected, "false");
        }
        xml.closeTag(); // </FILTER_GROUP>
      }
    }

    xml.closeTag(); // </EVIDENCE_FILTERS>
  }

  /**
   * Build the relationship among the evidence type.
   *
   * @param xml the builder object for xml construction.
   * @param map the hash map to store the children.
   * @param xmlEvidenceTypeDashboardDetails the parent evidence type.
   */
  private void buildRelationship(final XMLBuilder xml,
    final HashMap<String, EvidenceTypeDashboardDetails> map,
    final EvidenceTypeDashboardDetails xmlEvidenceTypeDashboardDetails) {

    // Check whether the evidence type has any children.
    if (xmlEvidenceTypeDashboardDetails.childrenList
      .equals(CuramConst.gkEmpty)) {
      return;
    }
    // Get the child evidence types from the list.
    final StringTokenizer st = new StringTokenizer(
      xmlEvidenceTypeDashboardDetails.childrenList, CuramConst.gkComma);
    // Children created flag.
    boolean childrenCreated = false;

    while (st.hasMoreElements()) {
      final Object type = st.nextElement();
      // Try to find out whether the child is configured with the case.
      // If it is configured, it should be in the list.
      final EvidenceTypeDashboardDetails xmlDtls = map.get(type);

      // If the child is found in the list, create a children tag.
      if (xmlDtls != null) {
        // If the children tag has been created already, skip it.
        if (!childrenCreated) {
          xml.createTag(EvidenceDashboardConst.kChildren);
          childrenCreated = true;
        }
        constructEvidence(xml, xmlDtls, xmlEvidenceTypeDashboardDetails);
        buildRelationship(xml, map, xmlDtls);
        xml.closeTag(); // </EVIDENCE>
      }
    }
    // Only create the children close tag if the children tag has been created.
    if (childrenCreated) {
      xml.closeTag(); // </CHILDREN>
    }
    return;
  }

  /**
   * Construct the evidence type relationship xml.
   *
   * @param xml the builder object for xml construction.
   * @param xmlEvidenceTypeDashboardDetails the parent evidence type.
   */
  private void constructEvidence(final XMLBuilder xml,
    final EvidenceTypeDashboardDetails xmlEvidenceTypeDashboardDetails,
    final EvidenceTypeDashboardDetails parentXmlDetails) {

    xml.createTag(EvidenceDashboardConst.kEvidence);
    xml.addAttribute(EvidenceDashboardConst.kEvidenceName,
      xmlEvidenceTypeDashboardDetails.description);
    xml.addAttribute(EvidenceDashboardConst.kEvidenceType,
      xmlEvidenceTypeDashboardDetails.type);
    xml.addAttribute(EvidenceDashboardConst.kInEdit,
      Integer.toString(xmlEvidenceTypeDashboardDetails.inEditCount));

    if (xmlEvidenceTypeDashboardDetails.isRecorded) {
      // BEGIN, CR00461154, DM
      if (parentXmlDetails == null) {
        xml.addAttribute(EvidenceDashboardConst.kIsRecorded,
          EvidenceDashboardConst.kTrue);
      } else if (parentXmlDetails.isRecorded) {
        // a child evidence type placed under a parent evidence type can only be
        // recorded if both types are recorded
        // AND if there is an actual relationship between an evidence item of
        // the child type
        // and an evidence item of the parent type ( SPMP-15110 )
        boolean existingEvidenceItemForParent = false;

        if (xmlEvidenceTypeDashboardDetails.selectedParentList != null) {
          final StringTokenizer st = new StringTokenizer(
            xmlEvidenceTypeDashboardDetails.selectedParentList,
            CuramConst.gkComma);

          while (st.hasMoreElements()) {
            final String associatedType = (String) st.nextElement();

            if (associatedType.equalsIgnoreCase(parentXmlDetails.type)) {
              existingEvidenceItemForParent = true;
              break;
            }
          }
        }
        if (existingEvidenceItemForParent) {
          xml.addAttribute(EvidenceDashboardConst.kIsRecorded,
            EvidenceDashboardConst.kTrue);
        } else {
          xml.addAttribute(EvidenceDashboardConst.kIsRecorded,
            EvidenceDashboardConst.kFalse);
        }
      }
      // END, CR00461154
    } else {
      xml.addAttribute(EvidenceDashboardConst.kIsRecorded,
        EvidenceDashboardConst.kFalse);
    }

    // BEGIN, CR00458459, EC
    if (xmlEvidenceTypeDashboardDetails.readOnly) {
      xml.addAttribute(EvidenceDashboardConst.kReadOnlyText,
        EvidenceDashboardConst.kTrue);
    } else {
      xml.addAttribute(EvidenceDashboardConst.kReadOnlyText,
        EvidenceDashboardConst.kFalse);
    }
    // END, CR00458459

    // BEGIN, CR00459976, DM
    if (xmlEvidenceTypeDashboardDetails.isMandatory) {
      xml.addAttribute(EvidenceDashboardConst.kIsMandatory,
        EvidenceDashboardConst.kTrue);
    } else {
      xml.addAttribute(EvidenceDashboardConst.kIsMandatory,
        EvidenceDashboardConst.kFalse);
    }
    // END, CR00459976

    xml.addAttribute(EvidenceDashboardConst.kVerifications,
      Integer.toString(xmlEvidenceTypeDashboardDetails.numVerifications));
    xml.addAttribute(EvidenceDashboardConst.kIssues,
      Integer.toString(xmlEvidenceTypeDashboardDetails.numIssues));
    xml.addAttribute(EvidenceDashboardConst.kSortOrder,
      Long.toString(xmlEvidenceTypeDashboardDetails.sortOrder));

    return;
  }

  /**
   * Set up the XML - localizable string, headers...etc.
   *
   * @param xml the xml builder.
   * @param key contains case id and participant id.
   */
  private void setupXML(final XMLBuilder xml,
    final CaseIDAndParticipantIDDetails key,
    final DashboardFilterIDKey filterKey) {

    xml.addAttribute(EvidenceDashboardConst.kCaseID,
      Long.toString(key.caseID));
    xml.addAttribute(EvidenceDashboardConst.kParticipantID,
      Long.toString(key.participantID));

    // BEGIN, CR00461450, DM
    // this is the default UIM displaying the evidence dashboard based on a
    // selected filter group
    if (filterKey != null && !filterKey.customFilterPage.isEmpty()) {
      xml.addAttribute(EvidenceDashboardConst.kFilterDashboardPage,
        filterKey.customFilterPage);
    } else {
      xml.addAttribute(EvidenceDashboardConst.kFilterDashboardPage,
        EvidenceDashboardConst.kDashboardDefaultFilterPage);
    }
    // END, CR00461450

    // BEGIN, CR00233058, DG
    final LocalisableString issueText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_ISSUE_TEXT);
    final LocalisableString verificationText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_VERIFICATION_TEXT);
    final LocalisableString ineditText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_INEDIT_TEXT);
    final LocalisableString notRecordedText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_NOT_RECORDED_TEXT);
    final LocalisableString recordedText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_RECORDED_TEXT);
    final LocalisableString allText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_ALL_TEXT);
    // BEGIN, CR00457538, DM
    final LocalisableString createText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_CREATE_TEXT);
    // END, CR00457538
    // BEGIN, CR00459702, DM
    final LocalisableString mandatoryText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_MANDATORY_TEXT);
    final LocalisableString filtersLabelText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_FILTERS_LABEL_TEXT);
    final LocalisableString filtersNoneText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_FILTERS_NONE_TEXT);

    // END, CR00459702

    xml.addAttribute(EvidenceDashboardConst.kIssueText,
      issueText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kVerificationText,
      verificationText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kIneditText,
      ineditText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kNotRecordedText,
      notRecordedText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kRecordedText,
      recordedText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kAllText,
      allText.getMessage(TransactionInfo.getProgramLocale()));
    // BEGIN, CR00457538, DM
    xml.addAttribute(EvidenceDashboardConst.kCreateText,
      createText.getMessage(TransactionInfo.getProgramLocale()));
    // END, CR00457538
    // BEGIN, CR00459702, DM
    xml.addAttribute(EvidenceDashboardConst.kMandatoryText,
      mandatoryText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kFiltersLabelText,
      filtersLabelText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kFiltersNoneText,
      filtersNoneText.getMessage(TransactionInfo.getProgramLocale()));
    // END, CR00459702

    // END, CR00233058

    // BEGIN, CR00289015, SD
    // Accessibility related text being added
    final LocalisableString selectedText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_ACCESS_SELECTED_TEXT);
    final LocalisableString expandText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_ACCESS_STATE_EXPAND_TEXT);
    final LocalisableString collapseText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_ACCESS_STATE_COLLAPSE_TEXT);

    xml.addAttribute(EvidenceDashboardConst.kSelectedText,
      selectedText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kExpandText,
      expandText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kCollapseText,
      collapseText.getMessage(TransactionInfo.getProgramLocale()));
    // END, CR00289015
    
    // BEGIN, 233930, SH
    final LocalisableString noEvidenceTypesText =
      new LocalisableString(EVIDENCEDASHBOARD.INF_EVIDENCE_TYPES_NOT_DEFINED);
    xml.addAttribute(EvidenceDashboardConst.kEvidenceMessage,
      noEvidenceTypesText.getMessage(TransactionInfo.getProgramLocale()));
    // END, 233930
  }

  // END, CR00457057, EC

  // BEGIN, CR00230454, ELG
  /**
   * Gets sorted evidence category details set from the
   * EvidenceTypeAdminDetailsList list.
   *
   * @param detailsList
   * Contains EvidenceTypeAdminDetailsList.
   * @param addAllAndPreferedInd
   * Flag to indicate should 'All' and 'Preferred' categories be added
   * to the sorted set.
   * @return Sorted set of evidence category details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * // BEGIN, CR00456443, DG
   *
   * // Get the details of outstanding verifications for the case.
   * Integer outstandingCount = 0;
   * final curam.core.sl.struct.CaseIDKey caseKey = new
   * curam.core.sl.struct.CaseIDKey();
   *
   * caseKey.caseID = key.caseID;
   * final Map<String, Integer> verCountAndEviTypeDtlsList =
   * evidenceVerification
   * .getVerificationImpl().listOutstandingVerificationAndEvidenceTypeForCase(
   * caseKey, false);
   *
   * // END, CR00456443
   *
   * // BEGIN, CR00456443, DG
   * outstandingCount = verCountAndEviTypeDtlsList.get(
   * evidenceDashboardDetails.evidenceType);
   *
   * if (outstandingCount == null) {
   * outstandingCount = 0;
   * }
   * evidenceTypeDashboardDetails.numVerifications = outstandingCount;
   * // END, CR00443445
   * Generic Exception Signature.
   */
  protected SortedSet<EvidenceCategoryDetails>
    getSortedEvidenceCategoriesFromList(
      final EvidenceTypeAdminDetailsList detailsList,
      final boolean addAllAndPreferedInd)
      throws AppException, InformationalException {

    // BEGIN, CR00296357, ELG
    // Return set.
    SortedSet<EvidenceCategoryDetails> evidenceCategories;

    if (addAllAndPreferedInd) {

      // get a list of unique categories on the case
      evidenceCategories = new TreeSet<EvidenceCategoryDetails>(
        new SortEvidenceCategoryBySortOrderAndNameComparator());

      final String locale = TransactionInfo.getProgramLocale();

      evidenceCategories.add(new EvidenceCategoryDetails(EVIDENCECATEGORY.ALL,
        CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
          locale),
        CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
          locale)));

      evidenceCategories
        .add(new EvidenceCategoryDetails(EVIDENCECATEGORY.PREFERRED,
          CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
            EVIDENCECATEGORY.PREFERRED, locale),
          CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
            EVIDENCECATEGORY.PREFERRED, locale)));

      evidenceCategories = getSortedEvidenceCategoriesFromListToSet(
        evidenceCategories, detailsList);

    } else {

      evidenceCategories =
        getSortedEvidenceCategoriesFromListToSet(null, detailsList);

    }
    // END, CR00296357

    return evidenceCategories;

  }

  // END, CR00230454

  // BEGIN, CR00296357, ELG
  /**
   * Adds EvidenceTypeAdminDetailsList list items to the sorted set specified.
   * If the sorted set is not specified, then this method creates the
   * new sorted set and then populates it using the list items from
   * EvidenceTypeAdminDetailsList. After adding the list items it returns
   * the sorted set. This utility method intended for local use only.
   *
   * @param evidenceCategorySet
   * Contains sorted set of evidence category details to which the
   * list item data must be added.
   * @param detailsList
   * Contains EvidenceTypeAdminDetailsList list.
   * @return Sorted set of evidence category details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected SortedSet<EvidenceCategoryDetails>
    getSortedEvidenceCategoriesFromListToSet(
      final SortedSet<EvidenceCategoryDetails> evidenceCategorySet,
      final EvidenceTypeAdminDetailsList detailsList)
      throws AppException, InformationalException {

    // Return set.
    SortedSet<EvidenceCategoryDetails> evidenceCategories;

    if (evidenceCategorySet == null) {
      evidenceCategories = new TreeSet<EvidenceCategoryDetails>(
        new SortEvidenceCategoryBySortOrderAndNameComparator());
    } else {
      evidenceCategories = evidenceCategorySet;
    }

    final String locale = TransactionInfo.getProgramLocale();

    for (final EvidenceTypeAdminDetails evidenceTypeAdminDetails : detailsList.dtls
      .items()) {

      final EvidenceCategoryDetails evidenceCategoryDetails =
        new EvidenceCategoryDetails(evidenceTypeAdminDetails.category,
          CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
            evidenceTypeAdminDetails.category, locale),
          CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
            evidenceTypeAdminDetails.category, locale));

      // Add new categories to the list.
      if (!evidenceCategories.contains(evidenceCategoryDetails)) {
        evidenceCategories.add(evidenceCategoryDetails);
      }

    }

    return evidenceCategories;

  }

  /**
   * Gets sorted evidence category details set from the
   * EvidenceTypeAdminDetailsList list.
   *
   * @param detailsList
   * Contains EvidenceTypeAdminDetailsList.
   * @param addAllAndPreferedInd
   * Flag to indicate should 'All' and 'Preferred' categories be added
   * to the sorted set.
   * @param caseID Unique ID of the case for which evidence category details
   * must be retrieved.
   * @return Sorted set of evidence category details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected SortedSet<EvidenceCategoryDetails>
    getSortedEvidenceCategoriesFromListForCase(
      final EvidenceTypeAdminDetailsList detailsList,
      final boolean addAllAndPreferedInd, final long caseID)
      throws AppException, InformationalException {

    // get a list of unique categories on the case
    final SortedSet<EvidenceCategoryDetails> evidenceCategories =
      new TreeSet<EvidenceCategoryDetails>(
        new SortEvidenceCategoryBySortOrderAndNameComparator());

    final String locale = TransactionInfo.getProgramLocale();

    if (addAllAndPreferedInd) {

      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = caseID;

      // Get evidence types
      final EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList =
        EvidenceControllerFactory.newInstance().listEvidenceTypes(caseKey);

      boolean preferredFoundInd = false;

      // Check are there any preferred evidence types
      for (final EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeAdminDetailsList.dtls
        .items()) {

        if (!evidenceTypeAdminDetails.participantDataInd
          && evidenceTypeAdminDetails.quickLinkInd) {
          preferredFoundInd = true;
          break;
        }

      }

      if (preferredFoundInd) {

        evidenceCategories
          .add(new EvidenceCategoryDetails(EVIDENCECATEGORY.PREFERRED,
            CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
              EVIDENCECATEGORY.PREFERRED, locale),
            CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
              EVIDENCECATEGORY.PREFERRED, locale)));

      }

      evidenceCategories.add(new EvidenceCategoryDetails(EVIDENCECATEGORY.ALL,
        CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
          locale),
        CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
          locale)));

    }

    return getSortedEvidenceCategoriesFromListToSet(evidenceCategories,
      detailsList);

  }

  // END, CR00296357

  /*
   * protected class to represent an evidence type in the dash board data
   */
  protected class EvidenceXMLDetails {

    String name;

    String evidenceType;

    int inEdit;

    boolean isRecorded;

    int verifications;

    int issues;

    long sortOrder;

    EvidenceXMLDetails(final String name, final String evidenceType,
      final int inEdit, final boolean isRecorded, final int verifications,
      final int issues, final long sortOrder) {

      this.name = name;
      this.evidenceType = evidenceType;
      this.inEdit = inEdit;
      this.isRecorded = isRecorded;
      this.verifications = verifications;
      this.issues = issues;
      this.sortOrder = sortOrder;
    }

    @Override
    public boolean equals(final Object o) {

      return this.evidenceType.equals(((EvidenceXMLDetails) o).evidenceType);
    }
  }

  // ___________________________________________________________________________
  /**
   * SortEvidenceXMLDetailsBySortOrderAndName Comparator.
   */
  protected class SortEvidenceXMLDetailsBySortOrderAndNameComparator
    implements Comparator<EvidenceXMLDetails> {

    public SortEvidenceXMLDetailsBySortOrderAndNameComparator() {// None

      // required
    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence category code sort order and name.
     */
    @Override
    public int compare(final EvidenceXMLDetails o1,
      final EvidenceXMLDetails o2) {

      final int result =
        Long.valueOf(o1.sortOrder).compareTo(Long.valueOf(o2.sortOrder));

      if (result == 0) {
        return o1.name.compareTo(o2.name);
      }
      return result;
    }
  }

  /*
   * protected class to represent an evidence category in the dash board data
   */
  protected class EvidenceCategoryDetails {

    String code;

    String description;

    int sortOrder;

    EvidenceCategoryDetails(final String code, final String description,
      final int sortOrder) {

      this.code = code;
      this.description = description;
      this.sortOrder = sortOrder;
    }

    @Override
    public boolean equals(final Object o) {

      return this.code.equals(((EvidenceCategoryDetails) o).code);
    }
  }

  // ___________________________________________________________________________
  /**
   * SortEvidenceCategoryBySortOrderAndName Comparator.
   */
  protected class SortEvidenceCategoryBySortOrderAndNameComparator
    implements Comparator<EvidenceCategoryDetails> {

    public SortEvidenceCategoryBySortOrderAndNameComparator() {// None required

    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence category code sort order and name.
     */
    @Override
    public int compare(final EvidenceCategoryDetails o1,
      final EvidenceCategoryDetails o2) {

      final int result = Integer.valueOf(o1.sortOrder)
        .compareTo(Integer.valueOf(o2.sortOrder));

      if (result == 0) {
        return o1.description.compareTo(o2.description);
      }
      return result;
    }
  }

  // BEGIN, CR00295440, PMD
  // ___________________________________________________________________________
  /**
   * SortDashboardEvdCategoriesBySortOrderAndDesc Comparator.
   */
  protected class SortDashboardEvdCategoriesBySortOrderAndDesc
    implements Comparator<EvidenceCatDashboardDetails> {

    public SortDashboardEvdCategoriesBySortOrderAndDesc() {// None required

    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence category sort order and description.
     */
    @Override
    public int compare(final EvidenceCatDashboardDetails o1,
      final EvidenceCatDashboardDetails o2) {

      final int result =
        Long.valueOf(o1.sortOrder).compareTo(Long.valueOf(o2.sortOrder));

      if (result == 0) {
        // BEGIN, CR00457057, EC
        return o1.description.compareToIgnoreCase(o2.description);
        // END, CR00457057
      }
      return result;
    }
  }

  // ___________________________________________________________________________
  /**
   * SortDashboardEvdTypesBySortOrderAndDesc Comparator.
   */
  protected class SortDashboardEvdTypesBySortOrderAndDesc
    implements Comparator<EvidenceTypeDashboardDetails> {

    public SortDashboardEvdTypesBySortOrderAndDesc() {// None required

    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence type sort order and description.
     */
    @Override
    public int compare(final EvidenceTypeDashboardDetails o1,
      final EvidenceTypeDashboardDetails o2) {

      final int result =
        Long.valueOf(o1.sortOrder).compareTo(Long.valueOf(o2.sortOrder));

      if (result == 0) {
        // BEGIN, CR00457057, EC
        return o1.description.compareToIgnoreCase(o2.description);
        // END, CR00457057
      }
      return result;
    }
  }

  // END, CR00295440

  // END, CR00230638

  // BEGIN, CR00459976, DM
  // ___________________________________________________________________________
  /**
   * SortEvidenceFiltersByName Comparator.
   */
  protected class SortEvidenceFiltersByName
    implements Comparator<DashboardFilterDetails> {

    public SortEvidenceFiltersByName() {// None required

    }

    // _________________________________________________________________________
    /**
     * Sort based on filter name.
     */
    @Override
    public int compare(final DashboardFilterDetails filter1,
      final DashboardFilterDetails filter2) {

      return filter1.name.compareTo(filter2.name);
    }
  }

  // END, CR00459976

  // BEGIN, CR00213278, MC

  

  // END, CR00213278

  // BEGIN, CR00214296, MC

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of participants for a case with evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param caseID The caseID for which the list of participants having
   * evidence are to be retrieved.
   *
   * @return List of participant names and id.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceParticipantIDNameDetailsList
    getEvidenceParticipantListForCase(final CaseID caseID)
      throws AppException, InformationalException {

    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    return evidenceController.getEvidenceParticipantListForCase(caseID);
  }

  // END, CR00214296

  // END, EVDMGMT

  // BEGIN, CR00397587, PS
  /**
   * Returns details of Evidence and case for given SuccessionID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key The succession identifier.
   *
   * @return The evidence identifier and type as well as the case identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceCaseKey getEvidenceAndCaseFromSuccession(
    final SuccessionID key) throws AppException, InformationalException {

    final EvidenceDescriptorDtls lastInSuccession = EvidenceControllerFactory
      .newInstance().getBusinessObjectDescriptor(key);

    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey.caseID = lastInSuccession.caseID;
    evidenceCaseKey.evidenceKey.evidenceID = lastInSuccession.relatedID;
    evidenceCaseKey.evidenceKey.evType = lastInSuccession.evidenceType;
    return evidenceCaseKey;
  }

  // BEGIN, CR00216737, GYH

  // BEGIN, CR00397587, PS
  /**
   * Returns case participant and related evidence details for transferring
   * participant evidence from one case to another.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Contains case participant and case identifier details.
   *
   * @return Case participant and related evidence details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public CaseEvidenceDetails
    getEvidenceDetailsForTransfer(final CaseEvidenceDetailsKey key)
      throws AppException, InformationalException {

    final CaseEvidenceDetails caseEvidenceDetails = new CaseEvidenceDetails();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      CaseParticipantRoleFactory.newInstance().read(caseParticipantRoleKey);
    final DetailsForEvidenceTransfer detailsForEvidenceTransfer =
      new DetailsForEvidenceTransfer();

    detailsForEvidenceTransfer.caseID = key.caseID;
    detailsForEvidenceTransfer.caseParticipantRoleID =
      key.caseParticipantRoleID;
    detailsForEvidenceTransfer.participantRoleID =
      caseParticipantRoleDtls.participantRoleID;
    caseEvidenceDetails.evidenceDetails = detailsForEvidenceTransfer;
    caseEvidenceDetails.toCaseID = key.details.toCaseID;
    if (key.actionIDProperty.equals(CuramConst.kYES)) {

      // To case reference must be specified to transfer evidence.
      if (0 == key.details.toCaseID) {
        final AppException appException = new AppException(
          BPOEVIDENCECONTROLLER.ERR_CONTROLLER_FV_TO_CASE_REFRENCE_NUMBER_ENTERED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(appException,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // At least one evidence must be selected to transfer evidence.
      if (key.details.evidenceTransferList.equals(CuramConst.gkEmpty)) {
        final AppException appException = new AppException(
          BPOEVIDENCECONTROLLER.ERR_CONTROLLER_FV_EVIDENCE_RECORD_MUST_BE_SELECTED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(appException,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      Datastore datastoreObj = null;

      try {
        datastoreObj = DatastoreFactory.newInstance()
          .openDatastore(GeneralConst.kEvidenceTransferData);
      } catch (final NoSuchSchemaException e) {// do nothing.
      }
      final DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

      datastoreEntityKey.entityID = key.datastoreEntityID;
      Entity evidenceTransferDetails = getEntity(datastoreEntityKey);

      if (0 == evidenceTransferDetails
        .getAttribute(GeneralConst.kEvidenceTransferList).length()) {
        evidenceTransferDetails.setAttribute(GeneralConst.kCaseID,
          String.valueOf(key.caseID));
        evidenceTransferDetails.setAttribute(
          GeneralConst.kEvidenceTransferList,
          key.details.evidenceTransferList);
        evidenceTransferDetails =
          datastoreObj.addRootEntity(evidenceTransferDetails);
        caseEvidenceDetails.datastoreEntityID =
          evidenceTransferDetails.getUniqueID();
      }
    }
    return caseEvidenceDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns list of evidence to be transferred from one case to another case
   * along with confirmation message.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @boread Participant
   *
   * @param key Contains case participant and case identifier details.
   *
   * @return List of evidence to be transferred from one case to another case
   * along with confirmation message.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceListDetails
    listTransferEvidenceForConfirmation(final CaseEvidenceDetailsKey key)
      throws AppException, InformationalException {

    // First get the tab list of evidence to be transferred from data store and
    // then parse as list of evidence types.
    final EvidenceListDetails evidenceListDetails = new EvidenceListDetails();
    final DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

    datastoreEntityKey.entityID = key.details.datastoreEntityID;
    final Entity evidenceDetails = getEntity(datastoreEntityKey);
    final String evidenceTransferList =
      evidenceDetails.getAttribute(GeneralConst.kEvidenceTransferList);
    final EvidenceKeyList evidenceKeyList = parseHelper(evidenceTransferList);

    for (final curam.core.sl.infrastructure.struct.EvidenceKey evidenceKey : evidenceKeyList.dtls
      .items()) {
      final ECWIPNewAndUpdateDtls ecWIPNewAndUpdateDtls =
        new ECWIPNewAndUpdateDtls();

      ecWIPNewAndUpdateDtls.evidenceID = evidenceKey.evidenceID;
      ecWIPNewAndUpdateDtls.evidenceType = evidenceKey.evidenceType;
      ecWIPNewAndUpdateDtls.correctionSetID = evidenceKey.correctionSetID;
      ecWIPNewAndUpdateDtls.evidenceDescriptorID =
        evidenceKey.evidenceDescriptorID;
      ecWIPNewAndUpdateDtls.successionID = evidenceKey.successionID;
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = evidenceKey.evidenceID;
      eiEvidenceKey.evidenceType = evidenceKey.evidenceType;
      ecWIPNewAndUpdateDtls.period =
        getPeriodAsString(EvidenceControllerFactory.newInstance()
          .getPeriodForEvidenceRecord(eiEvidenceKey));
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = key.details.participantRoleID;
      ecWIPNewAndUpdateDtls.concernRoleName = CachedConcernRoleFactory
        .newInstance().readConcernRoleName(concernRoleKey).concernRoleName;
      // Get last user who updated this evidence row
      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceKey.evidenceDescriptorID;
      final ChangeUserDetails changeUserDetails = EvidenceChangeHistoryFactory
        .newInstance().readUserForLatestChange(evidenceDescriptorKey);
      final LocalisableString latestActivity =
        new LocalisableString(BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

      latestActivity.arg(changeUserDetails.changeUser);
      latestActivity.arg(changeUserDetails.changeDateTime);
      ecWIPNewAndUpdateDtls.latestActivity =
        latestActivity.getMessage(TransactionInfo.getProgramLocale());

      // BEGIN, CR00241203, POB
      final EvidenceMap map =
        curam.core.sl.infrastructure.impl.EvidenceController.getEvidenceMap();

      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(eiEvidenceKey.evidenceType);

      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

      // BEGIN, CR00244064, CD
      // Summary may now be marked up as client formatted text.
      // Ensure that this assignment keeps to it's original contract.
      ecWIPNewAndUpdateDtls.summary = LocalizableXMLStringHelper
        .toPlainText(eiFieldsForListDisplayDtls.summary);
      // END, CR00244064
      // END, CR00241203

      evidenceListDetails.dtls.newAndUpdateList.dtls
        .addRef(ecWIPNewAndUpdateDtls);
    }

    // Construct the evidence to be transferred confirmation message.
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;
    final CaseKey fromCaseKey = new CaseKey();

    fromCaseKey.caseID = key.caseID;
    final CaseReferenceAndTypeDetails fromCaseReferenceAndTypeDetails =
      CaseHeaderFactory.newInstance()
        .readCaseReferenceAndTypeByCaseID(fromCaseKey);
    final CaseKey toCaseKey = new CaseKey();

    toCaseKey.caseID = key.details.toCaseID;
    final CaseReferenceAndTypeDetails toCaseReferenceAndTypeDetails =
      CaseHeaderFactory.newInstance()
        .readCaseReferenceAndTypeByCaseID(toCaseKey);
    final AppException appException = new AppException(
      BPOEVIDENCECONTROLLER.ERR_CONTROLLER_TRANSFER_EVIDENCE_CONFIRMATION);

    appException.arg(curam.core.sl.entity.fact.CaseParticipantRoleFactory
      .newInstance().readFullName(caseParticipantRoleKey).fullName);
    appException.arg(getSourceCaseDescription(fromCaseKey));
    appException.arg(fromCaseReferenceAndTypeDetails.caseReference);
    appException.arg(getSourceCaseDescription(toCaseKey));
    appException.arg(toCaseReferenceAndTypeDetails.caseReference);
    evidenceListDetails.confirmationMessage =
      appException.getMessage(ProgramLocale.getDefaultServerLocale());
    return evidenceListDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of all active case members of a case. Also returns active
   * evidences for the specified case and participant.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @boread Participant
   *
   * @param key Contains concern role and case identifier details.
   *
   * @param concernRoleKey Key of the concern role
   *
   * @return List of all active case members of a case. Also returns active
   * evidences for the specified case and participant.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public CaseMembersAndTransferEvidenceList
    listCaseMembersAndEvidenceForTransfer(final CaseIDAndEvidenceTypeKey key,
      final ConcernRoleKey concernRoleKey)
      throws AppException, InformationalException {

    final CaseMembersAndTransferEvidenceList caseMembersAndTransferEvidenceList =
      new CaseMembersAndTransferEvidenceList();

    // Get list of case members.
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    caseMembersAndTransferEvidenceList.caseMembers =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance()
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    // Get the default case participant.
    if (0 == concernRoleKey.concernRoleID) {
      final curam.core.sl.entity.struct.CaseIDTypeCodeKey caseIDTypeCodeKey =
        new curam.core.sl.entity.struct.CaseIDTypeCodeKey();

      caseIDTypeCodeKey.caseID = key.caseID;
      caseIDTypeCodeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
      caseMembersAndTransferEvidenceList.filteredParticipantID =
        CaseParticipantRoleFactory.newInstance().readByCaseIDAndTypeCode(
          caseIDTypeCodeKey).dtls.caseParticipantRoleID;
    } else {
      final CaseIDParticipantRoleKey caseIDParticipantRoleKey =
        new CaseIDParticipantRoleKey();

      caseIDParticipantRoleKey.caseID = key.caseID;
      caseIDParticipantRoleKey.participantRoleID =
        concernRoleKey.concernRoleID;
      caseMembersAndTransferEvidenceList.filteredParticipantID =
        CaseParticipantRoleFactory.newInstance().readCaseParticipantRoleID(
          caseIDParticipantRoleKey).caseParticipantRoleID;
    }

    // Get the list of evidence for a given concern role and case identifier.
    final ECActiveEvidenceDtlsList activeEvidenceDtlsList =
      listEvidenceForTransfer(key, concernRoleKey).dtls.activeList;
    final ActiveEvidenceDetailsList activeEvidenceDetailsList =
      new ActiveEvidenceDetailsList();

    for (final curam.core.sl.infrastructure.struct.ECActiveEvidenceDtls activeEvidenceDtls : activeEvidenceDtlsList.dtls
      .items()) {
      final ActiveEvidenceDetails activeEvidenceDetails =
        new ActiveEvidenceDetails();

      activeEvidenceDetails.evidenceDetails.assign(activeEvidenceDtls);

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = activeEvidenceDtls.evidenceID;
      eiEvidenceKey.evidenceType = activeEvidenceDtls.evidenceType;
      activeEvidenceDetails.period =
        getPeriodAsString(EvidenceControllerFactory.newInstance()
          .getPeriodForEvidenceRecord(eiEvidenceKey));

      // Get last user who updated this evidence row
      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        activeEvidenceDtls.evidenceDescriptorID;
      final ChangeUserDetails changeUserDetails = EvidenceChangeHistoryFactory
        .newInstance().readUserForLatestChange(evidenceDescriptorKey);
      final LocalisableString latestActivity =
        new LocalisableString(BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

      latestActivity.arg(changeUserDetails.changeUser);
      latestActivity.arg(changeUserDetails.changeDateTime);
      activeEvidenceDetails.latestActivity =
        latestActivity.getMessage(TransactionInfo.getProgramLocale());
      activeEvidenceDetailsList.activeEvidenceList
        .addRef(activeEvidenceDetails);
    }
    caseMembersAndTransferEvidenceList.evidenceList
      .assign(activeEvidenceDetailsList);

    return caseMembersAndTransferEvidenceList;
  }

  /**
   * Returns data store entity object for the given data store ID. If the object
   * is not created before, then it creates the one and returns.
   *
   * @param key
   * Contains data store identifier.
   *
   * @return Data store entity object.
   */
  protected Entity getEntity(final DatastoreEntityKey datastoreEntityKey) {

    Datastore datastoreObj = null;

    try {
      datastoreObj = DatastoreFactory.newInstance()
        .openDatastore(GeneralConst.kEvidenceTransferData);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }
    Entity evidenceTransferDetails = null;

    if (0 == datastoreEntityKey.entityID) {
      evidenceTransferDetails =
        datastoreObj.newEntity(GeneralConst.kEvidenceTransferData);
    } else {
      evidenceTransferDetails =
        datastoreObj.readEntity(datastoreEntityKey.entityID);
    }
    return evidenceTransferDetails;
  }

  /**
   * Deletes evidence transfer data store entity object for the given data store
   * ID.
   *
   * @param key
   * Contains data store identifier.
   */
  protected void getDeleteEvidenceTransferDatastore(
    final DatastoreEntityKey datastoreEntityKey) {

    Datastore datastoreObj = null;

    try {
      datastoreObj = DatastoreFactory.newInstance()
        .openDatastore(GeneralConst.kEvidenceTransferData);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }
    datastoreObj.readEntity(datastoreEntityKey.entityID).delete();
  }

  /**
   * Helper method for parsing evidence list.
   *
   * @param tabList
   * Contains list of evidence data to be parsed.
   *
   * @return Parsed evidence details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected EvidenceKeyList parseHelper(final String tabList)
    throws AppException, InformationalException {

    final EvidenceKeyList evidenceKeyList = new EvidenceKeyList();
    final StringList evidenceIDAndTypeList =
      StringUtil.tabText2StringList(tabList);

    for (int i = 0; i < evidenceIDAndTypeList.size(); i++) {
      final StringList evidenceIDAndTypeStringList = StringUtil
        .delimitedText2StringList(evidenceIDAndTypeList.item(i), '|');

      if (evidenceIDAndTypeStringList.size() != kElementsInTabList) {
        continue;
      }
      final curam.core.sl.infrastructure.struct.EvidenceKey evidenceKey =
        new curam.core.sl.infrastructure.struct.EvidenceKey();

      evidenceKey.evidenceDescriptorID =
        Long.parseLong(evidenceIDAndTypeStringList.item(kFirstElement));
      evidenceKey.evidenceID =
        Long.parseLong(evidenceIDAndTypeStringList.item(kSecondElement));
      evidenceKey.evidenceType =
        evidenceIDAndTypeStringList.item(kThirdElement);
      evidenceKey.correctionSetID =
        evidenceIDAndTypeStringList.item(kFourthElement);
      evidenceKey.successionID =
        Long.parseLong(evidenceIDAndTypeStringList.item(kFifthElement));
      evidenceKeyList.dtls.addRef(evidenceKey);
    }
    return evidenceKeyList;
  }

  // END, CR00216737

  // BEGIN, CR00225417, GYH
  /**
   * This method renders the effective period of an evidence record as a string.
   *
   * @param evidencePeriod
   * The effective period of an evidence record
   * @return The period rendered as a string
   */
  protected String getPeriodAsString(final EvidencePeriod evidencePeriod) {

    LocalisableString period = null;

    if (evidencePeriod.endDate.isZero()) {
      period =
        new LocalisableString(BPOEVIDENCECONTROLLER.INF_PERIOD_NO_END_DATE);
      period.arg(evidencePeriod.startDate);
    } else {
      period = new LocalisableString(BPOEVIDENCECONTROLLER.INF_PERIOD);

      period.arg(evidencePeriod.startDate);
      period.arg(evidencePeriod.endDate);
    }

    return period.getMessage(TransactionInfo.getProgramLocale());

  }

  /**
   * Returns source case description for the given case identifier.
   *
   * @param key
   * Containing case identifier.
   *
   * @return Source case description.
   *
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER#ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED} - if
   * the case type being passed is not having the corresponding
   * handler to support the required functionality.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String getSourceCaseDescription(final CaseKey caseKey)
    throws AppException, InformationalException {

    final CaseTypeCode caseTypeCode =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);
    final CaseTypeEvidence caseTypeEvidence =
      caseTypeEvidenceMap.get(caseTypeCode.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseTypeCode.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    return caseTypeEvidence.getCaseTypeDescription(caseKey);
  }

  // END, CR00225417

  // BEGIN, CR00397587, PS
  /**
   * Returns the header details for the evidence business object summary.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread ConcernRole
   *
   * @boread Participant
   *
   * @param key The succession identifier.
   *
   * @return The header details for the evidence business object summary.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceObjectSummaryHeaderDetails readObjectSummaryHeaderDetails(
    final SuccessionID key) throws AppException, InformationalException {

    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final EvidenceDescriptorDtls lastInSuccession =
      evidenceControllerObj.getBusinessObjectDescriptor(key);

    // get the evidence type
    final CodeTableItemIdentifier evidenceTypeArg =
      new CodeTableItemIdentifier(curam.codetable.CASEEVIDENCE.TABLENAME,
        lastInSuccession.evidenceType);

    // get the participant name
    String participantNameArg = CuramConst.gkEmpty;

    if (lastInSuccession.participantID != 0) {
      // ConcernRole manipulation variables
      final CachedConcernRole concernRoleObj =
        CachedConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = lastInSuccession.participantID;
      participantNameArg =
        concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
    }
    final EvidenceObjectSummaryHeaderDetails evidenceObjectSummaryHeaderDetails =
      new EvidenceObjectSummaryHeaderDetails();

    if (lastInSuccession.participantID != 0) {
      // ConcernRole manipulation variables
      final CachedConcernRole concernRoleObj =
        CachedConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = lastInSuccession.participantID;
      participantNameArg =
        concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      evidenceObjectSummaryHeaderDetails.tabName =
        new LocalisableString(FACADEEVIDENCE.EVIDENCEOBJECTTABNAME)
          .arg(evidenceTypeArg).arg(participantNameArg)
          .toClientFormattedText();

      evidenceObjectSummaryHeaderDetails.tabTitle =
        new LocalisableString(FACADEEVIDENCE.EVIDENCEOBJECTSUMMARYTITLE)
          .arg(evidenceTypeArg).arg(participantNameArg)
          .toClientFormattedText();

    } else {

      evidenceObjectSummaryHeaderDetails.tabName = new LocalisableString(
        FACADEEVIDENCE.EVIDENCEOBJECTTABNAME_NO_PARTICIPANT)
          .arg(evidenceTypeArg).toClientFormattedText();

      evidenceObjectSummaryHeaderDetails.tabTitle = new LocalisableString(
        FACADEEVIDENCE.EVIDENCEOBJECTSUMMARYTITLE_NO_PARTICIPANT)
          .arg(evidenceTypeArg).toClientFormattedText();

    }

    return evidenceObjectSummaryHeaderDetails;
  }

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Returns the tab name and title for the Evidence Type Workspace tab.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Case ID and Evidence Type
   *
   * @return Name and title for the tab.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceObjectSummaryHeaderDetails readWorkspaceTypeSummaryDetails(
    final curam.core.facade.infrastructure.struct.CaseIDAndEvidenceTypeKey key)
    throws AppException, InformationalException {

    final EvidenceObjectSummaryHeaderDetails evidenceObjectSummaryHeaderDetails =
      new EvidenceObjectSummaryHeaderDetails();

    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(key.caseID);

    // get the case name
    final String caseNameArg =
      caseHeader.getAdminCaseConfiguration().getLinkText();

    // get the case reference
    final String caseReference = caseHeader.getCaseReference();

    // get the evidence type
    final CodeTableItemIdentifier evidenceTypeArg =
      new CodeTableItemIdentifier(curam.codetable.CASEEVIDENCE.TABLENAME,
        key.evidenceType);

    evidenceObjectSummaryHeaderDetails.tabName =
      new LocalisableString(FACADEEVIDENCE.EVIDENCE_TYPEWORKSPACE_TABNAME)
        .arg(evidenceTypeArg).arg(caseNameArg).arg(caseReference)
        .toClientFormattedText();

    evidenceObjectSummaryHeaderDetails.tabTitle =
      new LocalisableString(FACADEEVIDENCE.EVIDENCE_TYPEWORKSPACE_TABTITLE)
        .arg(evidenceTypeArg).arg(caseNameArg).arg(caseReference)
        .toClientFormattedText();

    return evidenceObjectSummaryHeaderDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns the header details for the evidence tab summary.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key The case identifier.
   *
   * @return The header details for the evidence tab summary.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceTabSummaryHeaderDetails readEvidenceTabHeaderDetails(
    final CaseKey key) throws AppException, InformationalException {

    final EvidenceTabSummaryHeaderDetails tabSummaryHeaderDetails =
      new EvidenceTabSummaryHeaderDetails();

    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(key.caseID);

    // get the case name
    final String caseNameArg =
      caseHeader.getAdminCaseConfiguration().getLinkText();

    // get the case reference
    final String caseReference = caseHeader.getCaseReference();

    // set the tab name and title
    tabSummaryHeaderDetails.tabName =
      new LocalisableString(FACADEEVIDENCE.EVIDENCETABNAME).arg(caseNameArg)
        .arg(caseReference).toClientFormattedText();
    tabSummaryHeaderDetails.tabTitle =
      new LocalisableString(FACADEEVIDENCE.EVIDENCETABTITLE).arg(caseNameArg)
        .arg(caseReference).toClientFormattedText();

    return tabSummaryHeaderDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Sets active evidences to 'Pending Removal'.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Succession identifier.
   *
   * @return Details of the Evidence which has had its status set to "Pending
   * Removal".
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public SetPendingRemovalReturnDtls setPendingRemovalForActiveObject(
    final SuccessionID key) throws AppException, InformationalException {

    // get the descriptor
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceDescriptorDtls lastInSuccession =
      evidenceControllerObj.getBusinessObjectDescriptor(key);
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      lastInSuccession.evidenceDescriptorID;

    // Call controller operation to remove evidence
    evidenceControllerObj.removeEvidence(evidenceDescriptorKey);

    final SetPendingRemovalReturnDtls setPendingRemovalReturnDtls =
      new SetPendingRemovalReturnDtls();

    setPendingRemovalReturnDtls.warnings =
      evidenceControllerObj.getWarnings();

    return setPendingRemovalReturnDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards the pending update evidence (by setting the
   * <code>statusCode</code> of the EvidenceDescriptor to Canceled).
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Succession identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void discardPendingUpdateObject(final SuccessionID key)
    throws AppException, InformationalException {

    // get the descriptor
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceDescriptorDtls lastInSuccession =
      evidenceControllerObj.getBusinessObjectDescriptor(key);
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      lastInSuccession.evidenceDescriptorID;

    // Call controller operation to discard pending update evidences
    evidenceControllerObj.discardPendingUpdate(evidenceDescriptorKey);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards 'pending removal' from active evidences. Discards the pending
   * removal evidence (by setting the <code>pendingRemovalInd</code> field on
   * the EvidenceDescriptor entity to <code>false</code>). If the change has
   * been submitted for approval and/or if the user does not have sufficient
   * privileges to discard pending removal evidences, exception is thrown.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Succession identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public void clearPendingRemovalForActiveObject(final SuccessionID key)
    throws AppException, InformationalException {

    // get the descriptor
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceDescriptorDtls lastInSuccession =
      evidenceControllerObj.getBusinessObjectDescriptor(key);

    final DiscardPendingRemoveKey discardPendingRemoveKey =
      new DiscardPendingRemoveKey();

    discardPendingRemoveKey.key.evidenceDescriptorID =
      lastInSuccession.evidenceDescriptorID;
    discardPendingRemoveKey.details.versionNo = lastInSuccession.versionNo;

    // Call controller operation to discard pending removal evidences
    evidenceControllerObj.discardPendingRemove(discardPendingRemoveKey);
  }

  // BEGIN, CR00397587, PS
  // BEGIN, CR00226297, GYH
  /**
   * Lists evidence types along with their associated descriptions for a given
   * case and evidence category.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains case identifier and evidence category.
   *
   * @return Lists evidence types along with their associated descriptions.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceCategoryAndTypes
    listEvidenceTypes(final CaseIDAndEvidenceCategoryKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00230454, ELG
    // return structure
    final EvidenceCategoryAndTypes evidenceCategoryAndTypes =
      new EvidenceCategoryAndTypes();

    evidenceCategoryAndTypes.filteredCategory = key.category;

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList =
      EvidenceControllerFactory.newInstance().listEvidenceTypes(caseKey);

    // Filter participant evidence out of the list.
    for (final EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeAdminDetailsList.dtls
      .items()) {

      if (!evidenceTypeAdminDetails.participantDataInd
        && (evidenceTypeAdminDetails.category.equals(key.category)
          || evidenceTypeAdminDetails.category.length() == 0
          || key.category.equals(EVIDENCECATEGORY.ALL)
          || key.category.equals(EVIDENCECATEGORY.PREFERRED)
            && evidenceTypeAdminDetails.quickLinkInd)) {

        final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

        eiEvidenceKey.evidenceType = evidenceTypeAdminDetails.evidenceType;

        final EvidenceTypeAndDesc evidenceTypeAndDesc =
          new EvidenceTypeAndDesc();

        evidenceTypeAndDesc.evidenceType =
          evidenceTypeAdminDetails.evidenceType;
        evidenceTypeAndDesc.evidenceDesc =
          EvidenceControllerFactory.newInstance()
            .readEvidenceTypeDescription(eiEvidenceKey).description;

        if (StringHelper.isEmpty(evidenceTypeAndDesc.evidenceDesc)) {
          evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
            CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType);
        }

        evidenceCategoryAndTypes.evidenceTypes.dtls
          .addRef(evidenceTypeAndDesc);

      }

    }
    // END, CR00230454

    return evidenceCategoryAndTypes;
  }

  /**
   * Lists editable evidence types along with their associated descriptions for
   * a given
   * case and evidence category.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains case identifier and evidence category.
   *
   * @return Lists editable evidence types along with their associated
   * descriptions.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public EvidenceCategoryAndTypes
    listEditableEvidenceTypes(final CaseIDAndEvidenceCategoryKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00230454, ELG
    // return structure
    final EvidenceCategoryAndTypes evidenceCategoryAndTypes =
      new EvidenceCategoryAndTypes();

    evidenceCategoryAndTypes.filteredCategory = key.category;

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList =
      EvidenceControllerFactory.newInstance().listEvidenceTypes(caseKey);

    // Filter participant evidence out of the list.
    for (final EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeAdminDetailsList.dtls
      .items()) {

      if (!evidenceTypeAdminDetails.readOnly
        && !evidenceTypeAdminDetails.participantDataInd
        && (evidenceTypeAdminDetails.category.equals(key.category)
          || evidenceTypeAdminDetails.category.length() == 0
          || key.category.equals(EVIDENCECATEGORY.ALL)
          || key.category.equals(EVIDENCECATEGORY.PREFERRED)
            && evidenceTypeAdminDetails.quickLinkInd)) {

        final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

        eiEvidenceKey.evidenceType = evidenceTypeAdminDetails.evidenceType;

        final EvidenceTypeAndDesc evidenceTypeAndDesc =
          new EvidenceTypeAndDesc();

        evidenceTypeAndDesc.evidenceType =
          evidenceTypeAdminDetails.evidenceType;
        evidenceTypeAndDesc.evidenceDesc =
          EvidenceControllerFactory.newInstance()
            .readEvidenceTypeDescription(eiEvidenceKey).description;

        if (StringHelper.isEmpty(evidenceTypeAndDesc.evidenceDesc)) {
          evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
            CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType);
        }

        evidenceCategoryAndTypes.evidenceTypes.dtls
          .addRef(evidenceTypeAndDesc);

      }

    }
    // END, CR00230454

    return evidenceCategoryAndTypes;
  }

  // BEGIN, CR00230454, ELG

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of evidence categories for the case.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains case ID.
   *
   * @return List of evidence categories.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceCategoryDetailsList getEvidenceCategoryList(
    final CaseKey key) throws AppException, InformationalException {

    // return structure
    final EvidenceCategoryDetailsList evidenceCategoryDetailsList =
      new EvidenceCategoryDetailsList();

    final EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList =
      EvidenceControllerFactory.newInstance().listEvidenceTypes(key);

    // BEGIN, CR00296357, ELG
    final SortedSet<EvidenceCategoryDetails> evidenceCategoryDetailsSet =
      getSortedEvidenceCategoriesFromListForCase(evidenceTypeAdminDetailsList,
        true, key.caseID);
    // END, CR00296357

    // loop variable
    curam.core.facade.infrastructure.struct.EvidenceCategoryDetails evidenceCategoryDtls;

    // populate the category selection list
    for (final EvidenceCategoryDetails evdCategoryDetails : evidenceCategoryDetailsSet) {

      evidenceCategoryDtls =
        new curam.core.facade.infrastructure.struct.EvidenceCategoryDetails();
      evidenceCategoryDtls.categoryCode = evdCategoryDetails.code;
      evidenceCategoryDtls.categoryDescription =
        evdCategoryDetails.description;
      if (!evdCategoryDetails.code.equals(EVIDENCECATEGORY.PARTICIPANTDATA)) {
        evidenceCategoryDetailsList.dtls.addRef(evidenceCategoryDtls);
      }

    }

    return evidenceCategoryDetailsList;

  }

  // END, CR00230454

  // BEGIN, CR00397587, PS
  /**
   * Returns the case ID and evidence category identifier. Passes the case ID
   * and evidence category identifier onto the next page.
   *
   * @param key Contains case identifier and evidence category.
   *
   * @return Returns the case ID and evidence category identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public CaseIDAndEvidenceCategoryKey
    getCaseAndEvidenceCategoryDetails(final CaseIDAndEvidenceCategoryKey key)
      throws AppException, InformationalException {

    return key;
  }

  // END, CR00226297

  // BEGIN, CR00224982, POB

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns business object page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readBusinessObjectPage(final SuccessionID key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    final EvidenceCaseKey evCaseKey = getEvidenceAndCaseFromSuccession(key);

    final EIEvidenceKey eiEvKey = new EIEvidenceKey();

    eiEvKey.evidenceType = evCaseKey.evidenceKey.evType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readBusinessObjectPage(eiEvKey);

    return pageNameDetails;
  }

  // END, CR00224982

  // BEGIN, CR00239880, POB

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns create page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readHistoryRecordPage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readHistoryRecordPage(key.key);

    return pageNameDetails;
  }

  // END, CR00239880

  // BEGIN, CR00251167, CD

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the business object page name for the evidence type of the given
   * succession ID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readBusinessObjectVerificationsPage(
    final SuccessionID key) throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    final EvidenceCaseKey evCaseKey = getEvidenceAndCaseFromSuccession(key);

    final EIEvidenceKey eiEvKey = new EIEvidenceKey();

    eiEvKey.evidenceType = evCaseKey.evidenceKey.evType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance()
      .readBusinessObjectVerificationsPage(eiEvKey);

    return pageNameDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the Business Object Issues page name for the evidence type of the
   * given succession ID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readBusinessObjectIssuesPage(final SuccessionID key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    final EvidenceCaseKey evCaseKey = getEvidenceAndCaseFromSuccession(key);

    final EIEvidenceKey eiEvKey = new EIEvidenceKey();

    eiEvKey.evidenceType = evCaseKey.evidenceKey.evType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance()
      .readBusinessObjectIssuesPage(eiEvKey);

    return pageNameDetails;
  }

  // END, CR00251167

  // BEGIN, CR00224675, POB

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns create page name details depending on evidence type. workspaces.
   *
   * @boread Evidence
   *
   * @boread PageNameDetails
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readCreatePage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readCreatePage(key.key);

    return pageNameDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns workspace page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public PageNameDetails readWorkspacePage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readWorkspacePage(key.key);

    return pageNameDetails;
  }

  // END, CR00224675

  // BEGIN, CR00397587, PS
  /**
   * Lists the correction history for a given Evidence record.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence record identifier
   *
   * @return A list of corrections for the evidence record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceCorrectionDtlsList listEvidenceCorrectionHistory(
    final EIEvidenceKey key) throws AppException, InformationalException {

    // Details to return
    final EvidenceCorrectionDtlsList evidenceCorrectionDtlsList =
      new EvidenceCorrectionDtlsList();

    // Retrieve the Evidence Descriptor record for this evidence
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceController evidenceControllerObj =
      EvidenceControllerFactory.newInstance();

    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
      new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceType;
    relatedIDAndEvidenceTypeKey.relatedID = key.evidenceID;
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      evidenceDescriptorObj
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

    // Read the related correction records
    final CorrectionSetIDDetails correctionSetIDDetails =
      new CorrectionSetIDDetails();

    correctionSetIDDetails.caseID = evidenceDescriptorDtls.caseID;
    correctionSetIDDetails.correctionSetID =
      evidenceDescriptorDtls.correctionSetID;
    final EvidenceDescriptorIDAndStatusDetailsList correctionList =
      evidenceDescriptorObj.searchAllRelatedDescriptorIDsByCorrectionSetID(
        correctionSetIDDetails);

    for (int i = 0; i < correctionList.dtls.size(); i++) {
      final EvidenceCorrectionDtls evidenceCorrectionDtls =
        new EvidenceCorrectionDtls();

      // Read the evidence descriptor for this record
      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        correctionList.dtls.item(i).evidenceDescriptorID;
      final EvidenceDescriptorDtls evidenceDescriptorDtls2 =
        evidenceDescriptorObj.read(evidenceDescriptorKey);

      // BEGIN, CR00335498, GYH
      // Unaccepted shared evidence should not be displayed on evidence
      // correction history
      final EVIDENCEDESCRIPTORSTATUSEntry evidencedescriptorstatusEntry =
        EVIDENCEDESCRIPTORSTATUSEntry.get(evidenceDescriptorDtls2.statusCode);

      if (EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALINEDIT
        .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALDISCARDED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALREJECTED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALREMOVALACCEPTED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.NONIDENTICALINEDIT
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.NONIDENTICALRESOLVED
          .equals(evidencedescriptorstatusEntry)) {
        continue;
      }
      // END, CR00335498
      evidenceCorrectionDtls.evidenceID = evidenceDescriptorDtls2.relatedID;

      // Set the period
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = evidenceDescriptorDtls2.relatedID;
      eiEvidenceKey.evidenceType = evidenceDescriptorDtls2.evidenceType;
      evidenceCorrectionDtls.period = getPeriodAsString(
        evidenceControllerObj.getPeriodForEvidenceRecord(eiEvidenceKey));

      // BEGIN, CR00233161, CD
      // Get the Change Summary
      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      evidenceTypeKey.evidenceType = evidenceDescriptorDtls2.evidenceType;

      // for participant evidence the change reason does not apply
      if (isEvidenceParticipantData(evidenceTypeKey).participantDataInd) {

        final LocalisableString description = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_DESCRIPTION_PARTICIPANT);

        description.arg(evidenceDescriptorDtls2.receivedDate);
        evidenceCorrectionDtls.changeSummary =
          description.toClientFormattedText();

      } else {

        final LocalisableString description =
          new LocalisableString(BPOEVIDENCECONTROLLER.INF_DESCRIPTION);

        description.arg(evidenceDescriptorDtls2.receivedDate);
        description
          .arg(new CodeTableItemIdentifier(EVIDENCECHANGEREASON.TABLENAME,
            evidenceDescriptorDtls2.changeReason));
        evidenceCorrectionDtls.changeSummary =
          description.toClientFormattedText();

      }
      // END, CR00233161

      // Updated By
      final ChangeUserDetails changeUserDetails = EvidenceChangeHistoryFactory
        .newInstance().readUserForLatestChange(evidenceDescriptorKey);
      final LocalisableString latestActivity =
        new LocalisableString(BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

      final UsersKey usersKey = new UsersKey();

      usersKey.userName = changeUserDetails.changeUser;

      final UserFullname fullname =
        UserAccessFactory.newInstance().getFullName(usersKey);

      latestActivity.arg(fullname.fullname);
      latestActivity.arg(changeUserDetails.changeDateTime);
      evidenceCorrectionDtls.updatedBy =
        latestActivity.toClientFormattedText();

      // Add to return list
      evidenceCorrectionDtlsList.dtls.addRef(evidenceCorrectionDtls);
    }

    // Return list
    return evidenceCorrectionDtlsList;
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all of the Issues for a case.
   *
   * @boread Evidence
   *
   * @boread Issue
   *
   * @param key Case identifier.
   *
   * @return A list of issues for the case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceIssuesDetailsList listIssuesForCase(final CaseKey key)
    throws AppException, InformationalException {

    // Retrieve the list of issues for the case
    final IssueDetailsList issueDetailsList =
      evidenceIssues.listIssuesForCase(key.caseID);

    return getIssueDetails(key.caseID, issueDetailsList);
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all of the issues for a given evidence record.
   *
   * @boread Evidence
   *
   * @boread Issue
   *
   * @param key Evidence record identifier.
   *
   * @return A list of issues for the evidence record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceIssuesDetailsList listIssuesForEvidence(
    final SuccessionID key) throws AppException, InformationalException {

    // Retrieve the list of issues for the evidence type
    final long caseID = EvidenceDescriptorFactory.newInstance()
      .readCaseIDForBusinessObject(key).caseID;
    final IssueDetailsList issueDetailsList =
      evidenceIssues.listIssuesForEvidenceType(caseID, key.successionID);

    return getIssueDetails(caseID, issueDetailsList);
  }

  /**
   * Helper method to setup the list of Evidence Issue details.
   *
   * @param caseID
   * Case identifier.
   * @param issueDetailsList
   * The Evidence Issues.
   *
   * @return A list of issues to display on client.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected EvidenceIssuesDetailsList getIssueDetails(final long caseID,
    final IssueDetailsList issueDetailsList)
    throws AppException, InformationalException {

    final EvidenceIssuesDetailsList evidenceIssuesDetailsList =
      new EvidenceIssuesDetailsList();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    // BEGIN, CR00230584, ELG
    // Loop variables
    IssueDetails issueDetails;
    EvidenceIssuesDetails evidenceIssuesDetails;

    // END, CR00230584

    for (int i = 0; i < issueDetailsList.dtls.size(); i++) {

      // BEGIN, CR00230584, ELG
      evidenceIssuesDetails = new EvidenceIssuesDetails();

      // Note, that only issueID, description, caseID and evidenceType
      // are guaranteed to be set in IssueDetails after call to EvidenceIssues
      // interface methods. All other details in IssueDetails are not mandatory
      // (for return) and can be set or not, depending on the particular issue.
      issueDetails = issueDetailsList.dtls.item(i);

      // Retrieve the evidence ID. This is used for the modify evidence link
      if (issueDetails.evidenceDescriptorID != 0) {

        evidenceDescriptorKey.evidenceDescriptorID =
          issueDetails.evidenceDescriptorID;
        evidenceIssuesDetails.evidenceID =
          evidenceDescriptorObj.read(evidenceDescriptorKey).relatedID;

      }

      evidenceIssuesDetails.evidenceType = issueDetails.evidenceType;
      evidenceIssuesDetails.subject = issueDetails.description;
      evidenceIssuesDetails.evidenceDescriptorID =
        issueDetails.evidenceDescriptorID;
      // END, CR00230584

      evidenceIssuesDetailsList.dtls.addRef(evidenceIssuesDetails);

    }

    evidenceIssuesDetailsList.caseID = caseID;

    return evidenceIssuesDetailsList;
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all of the issues for a given evidence type.
   *
   * @boread Evidence
   *
   * @boread Issue
   *
   * @param key Evidence type identifier.
   *
   * @return A list of evidence issues for a given evidence type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public EvidenceIssuesDetailsList
    listIssuesForEvidenceType(final EvidenceTypeWorkspaceKey key)
      throws AppException, InformationalException {

    // Retrieve the list of issues for the case
    final IssueDetailsList issueDetailsList =
      evidenceIssues.listIssuesForEvidenceType(key.caseID,
        CASEEVIDENCEEntry.get(key.evidenceType));

    return getIssueDetails(key.caseID, issueDetailsList);
  }

  // BEGIN, CR00229824, EC

  // BEGIN, CR00397587, PS
  /**
   * Lists all 'In Edit' and 'Pending Removal' evidences for a case, filtering
   * by Participant and Evidence Type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, Participant identifier and an
   * Evidence Type code.
   *
   * @return List of 'In Edit' and 'Pending Removal' Evidence
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllInEditDtls
    listAllInEdit(final CaseIDParticipantIDEvidenceTypeKey key)
      throws AppException, InformationalException {

    final ListAllInEditDtls listAllInEditDtls =
      EvidenceControllerFactory.newInstance().listAllInEdit(key);

    // BEGIN, CR00428286, GK
    for (final curam.core.sl.infrastructure.struct.EvidenceParticipantDtls evidenceParticipantDtlsObj : listAllInEditDtls.evidenceParticipantDtlsList.dtls) {
      if (evidenceParticipantDtlsObj.verificationOrIssuesExist) {
        listAllInEditDtls.hasVerificationsOrIssues = true;
      }
      if (evidenceParticipantDtlsObj.isUnevaluatedEvidence) {
        listAllInEditDtls.hasUnevaluatedEvidenceOpt = true;
      }
    }
    // END, CR00428286
    return listAllInEditDtls;
  }

  // END, CR00229824

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Returns a list of business objects for the given case id and list of
   * Evidence types.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key CaseID and list of evidence types.
   *
   * @return List of business objects.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public BusinessObjectSummaryList
    listPossibleRelatedObjects(final CaseIDAndLongEvidenceTypeList key)
      throws AppException, InformationalException {

    final BusinessObjectSummaryList returnStruct =
      new BusinessObjectSummaryList();

    final List<String> evidenceTypeList =
      StringUtil.delimitedText2StringList(key.evidenceTypeList, '|');

    final EvidenceController evidenceControllerObj =
      EvidenceControllerFactory.newInstance();

    final BusinessObjectEvidenceTypeKey businessObjectTypeKey =
      new BusinessObjectEvidenceTypeKey();

    businessObjectTypeKey.caseID = key.caseID;

    final SuccessionID successionID = new SuccessionID();

    for (final String evidenceType : evidenceTypeList) {

      businessObjectTypeKey.evidenceType = evidenceType;
      final BusinessObjectSummaryList summaryList = evidenceControllerObj
        .listBusinessObjectsForEvidenceType(businessObjectTypeKey);

      for (int i = 0; i < summaryList.dtls.size(); i++) {
        successionID.successionID = summaryList.dtls.item(i).successionID;
        final EvdInstanceChangeDtlsList changeList =
          listActiveEvdInstanceChanges(successionID);

        if (changeList.dtlsList.size() != 1
          || !changeList.dtlsList.item(0).pendingRemovalInd) {
          returnStruct.dtls.addRef(summaryList.dtls.item(i));
        }
      }

    }

    return returnStruct;
  }

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Returns a list of business objects for a given caseID and list of evidence
   * types
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key CaseID and list of evidence types.
   *
   * @return List of business objects.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public BusinessObjectSummaryList
    listBusinessObjects(final CaseIDAndLongEvidenceTypeList key)
      throws AppException, InformationalException {

    final BusinessObjectSummaryList returnStruct =
      new BusinessObjectSummaryList();

    final List<String> evidenceTypeList =
      StringUtil.delimitedText2StringList(key.evidenceTypeList, '|');

    final EvidenceController evidenceControllerObj =
      EvidenceControllerFactory.newInstance();

    final BusinessObjectEvidenceTypeKey businessObjectTypeKey =
      new BusinessObjectEvidenceTypeKey();

    businessObjectTypeKey.caseID = key.caseID;

    for (final String evidenceType : evidenceTypeList) {

      businessObjectTypeKey.evidenceType = evidenceType;
      final BusinessObjectSummaryList summaryList = evidenceControllerObj
        .listBusinessObjectsForEvidenceType(businessObjectTypeKey);

      returnStruct.dtls.addAll(summaryList.dtls);
    }

    return returnStruct;
  }

  // BEGIN, CR00236468, GYH

  // BEGIN, CR00397587, PS
  /**
   * Returns an informational message about the incoming evidence for a given
   * case identifier.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Contains case identifier.
   *
   * @return An informational message about the incoming evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ECWarningsDtlsList getIncomingEvidenceInformation(final CaseKey key)
    throws AppException, InformationalException {

    // Check if there are any incoming evidence for the given case identifier.
    boolean isIncomingEvidenceFound = false;
    // BEGIN, CR00379700, SSK
    final CaseIDAndStatuses caseIDAndStatuses = new CaseIDAndStatuses();

    caseIDAndStatuses.caseID = key.caseID;
    caseIDAndStatuses.statusCode1 = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    caseIDAndStatuses.statusCode2 =
      EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    if (!evidenceDescriptorObj
      .searchEvidenceByCaseIDAndStatus(caseIDAndStatuses).dtls.isEmpty()) {
      isIncomingEvidenceFound = true;
    }
    // END, CR00379700

    // If there are any incoming evidence for the given case identifier then
    // construct and return the informational message about the incoming
    // evidence.
    final ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    if (isIncomingEvidenceFound) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          BPOEVIDENCECONTROLLERExceptionCreator
            .INF_INCOMING_EVIDENCE_INFORMATION(),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

      final String warnings[] =
        informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

        ecWarningsDtls.msg = warnings[i];
        ecWarningsDtlsList.dtls.addRef(ecWarningsDtls);
      }
    }

    return ecWarningsDtlsList;
  }

  // END, CR00236468

  // BEGIN, CR00265745, JMA

  // BEGIN, CR00397587, PS
  /**
   * Delegates to the listCaseMembersAndEvidenceForTransfer method or the
   * getEvidenceDetailsForTransfer method based on the action id passed in.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Evidence Transfer key.
   *
   * @return Evidence Transfer Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public curam.core.facade.infrastructure.struct.TransferEvidenceDetails
    transferEvidenceDetails(final TransferEvidenceKey key)
      throws AppException, InformationalException {

    final curam.core.facade.infrastructure.struct.TransferEvidenceDetails transferEvidenceDetails =
      new curam.core.facade.infrastructure.struct.TransferEvidenceDetails();

    if (key.actionIDProperty.equals(CuramConst.kYES)) {

      key.dtls.actionIDProperty = CuramConst.kYES;
      transferEvidenceDetails.dtls = getEvidenceDetailsForTransfer(key.dtls);

    } else {

      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final CaseParticipantRole caseParticipantRoleObj =
        CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      if (key.dtls.caseParticipantRoleID != 0) {

        caseParticipantRoleKey.caseParticipantRoleID =
          key.dtls.caseParticipantRoleID;

        concernRoleKey.concernRoleID = caseParticipantRoleObj
          .readParticipantRoleDetails(caseParticipantRoleKey).concernRoleID;

      } else {

        final curam.core.sl.entity.struct.CaseIDTypeCodeKey caseIDTypeCodeKey =
          new curam.core.sl.entity.struct.CaseIDTypeCodeKey();

        caseIDTypeCodeKey.caseID = key.caseIDAndEvidenceKey.caseID;
        caseIDTypeCodeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
        caseParticipantRoleKey.caseParticipantRoleID =
          CaseParticipantRoleFactory.newInstance().readByCaseIDAndTypeCode(
            caseIDTypeCodeKey).dtls.caseParticipantRoleID;

        concernRoleKey.concernRoleID = caseParticipantRoleObj
          .readParticipantRoleDetails(caseParticipantRoleKey).concernRoleID;
      }

      final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey =
        new CaseIDAndEvidenceTypeKey();

      caseIDAndEvidenceTypeKey.caseID = key.caseIDAndEvidenceKey.caseID;
      caseIDAndEvidenceTypeKey.evidenceType =
        key.caseIDAndEvidenceKey.evidenceType;

      transferEvidenceDetails.caseMemberEvidenceList =
        listCaseMembersAndEvidenceForTransfer(caseIDAndEvidenceTypeKey,
          concernRoleKey);

    }

    return transferEvidenceDetails;

  }

  // END, CR00265745
  // BEGIN, CR00279713, AC

  // BEGIN, CR00397587, PS
  /**
   * Returns case ID for an Evidence.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Case Evidence Tree Key.
   *
   * @return Case ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public CaseID readCaseID(final CaseEvidenceTreeKey key)
    throws AppException, InformationalException {

    final CaseID caseID = new CaseID();
    final CaseEvidenceTreeDtls caseEvidenceTreeDtls =
      readCaseEvidenceTree(key);

    caseID.caseID = caseEvidenceTreeDtls.caseID;
    return caseID;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns case ID , related ID and the Evidence type details for an
   * Evidence.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Evidence Descriptor Key.
   *
   * @return Case ID, related ID and the Evidence type details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public CaseIDRelatedIDAndEvidenceTypeDtlsList
    readCaseIDandEvidenceType(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final CaseIDRelatedIDAndEvidenceTypeDtlsList caseIDRelatedIDAndEvidenceTypeDtlsList =
      new CaseIDRelatedIDAndEvidenceTypeDtlsList();
    CaseIDRelatedIDAndEvidenceTypeDtls caseIDRelatedIDAndEvidenceTypeDtls;

    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
      readEvidenceDescriptor(key);

    for (final EvidenceDescriptorDtls dtls : evidenceDescriptorDtlsList.dtls
      .items()) {
      caseIDRelatedIDAndEvidenceTypeDtls =
        new CaseIDRelatedIDAndEvidenceTypeDtls();
      caseIDRelatedIDAndEvidenceTypeDtls.caseID = dtls.caseID;
      caseIDRelatedIDAndEvidenceTypeDtls.evidenceType = dtls.evidenceType;
      caseIDRelatedIDAndEvidenceTypeDtls.relatedID = dtls.relatedID;
      caseIDRelatedIDAndEvidenceTypeDtlsList.dtls
        .addRef(caseIDRelatedIDAndEvidenceTypeDtls);
    }

    return caseIDRelatedIDAndEvidenceTypeDtlsList;
  }

  // END, CR00233772
  // BEGIN, CR00345678, ZV
  // ___________________________________________________________________________
  /**
   * Generates the menu data for a Participant Data Case.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu data for a participant data case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData
    getParticipantDataCaseMenuData(final CaseKey key)
      throws AppException, InformationalException {

    final curam.core.facade.infrastructure.struct.MenuData menuData =
      new curam.core.facade.infrastructure.struct.MenuData();

    final ProductHookManager productHookManager = new ProductHookManager();

    final MenuData menuDataObj =
      productHookManager.getMenuDataHook(CASETYPECODE.PARTICIPANTDATACASE);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    menuData.menuData =
      menuDataObj.getParticipantDataCaseMenuData(caseHeaderKey).menuData;

    return menuData;
  }

  // END, CR00345678

  // BEGIN, CR00352812, BF

  // BEGIN, CR00397587, PS
  /**
   * Retrieves the list of ALL evidence (active and in edit) associated with the
   * case.
   * There is another version of this method - listAllEvidence1. Whenever there
   * is any change made to this method, developer is requested to visit -
   * listAllEvidence1
   * as well.
   *
   * @param key Contains a case identifier.
   *
   * @return result A list of 'In Edit' and 'Active' evidence for the Case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllEvidenceDtls listAllEvidence(
    final curam.core.facade.infrastructure.struct.CaseKey caseKey)
    throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method - listAllEvidence1. Whenever
    // there
    // is any change made to this method, developer is requested to visit -
    // listAllEvidence1
    // as well.
    // END, CR00452604
    ListAllEvidenceDtls result = new ListAllEvidenceDtls();

    final CaseIDParticipantIDEvidenceTypeKey caseIDEvidenceTypeKey =
      new CaseIDParticipantIDEvidenceTypeKey();

    caseIDEvidenceTypeKey.caseIDKey.caseID = caseKey.caseID;

    result.caseID = caseKey.caseID;
    final ListAllInEditDtls inEditEvd = EvidenceControllerFactory
      .newInstance().listAllInEdit(caseIDEvidenceTypeKey);

    // assign in-edit evidence to return struct
    result = assignInEditEvidenceParticipantDtlsList(result, inEditEvd);
    result.caseID = caseKey.caseID;

    final curam.core.struct.CaseKey key = new curam.core.struct.CaseKey();

    key.caseID = caseKey.caseID;

    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList =
      EvidenceControllerFactory.newInstance().listAllactiveEvdInstances(key);

    // assign active evidence to return struct.
    result = assignActiveEvidenceParticipantDtlsList(result,
      activeEvdInstanceDtlsList);

    // BEGIN, CR00424202, JD

    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed =
      new EvidenceUpdatesAllowed();
    final boolean evidenceUpdatesAllowedInd =
      evidenceUpdatesAllowed.isUpdatesAllowed(key);

    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      result.caseUpdatesAllowed = false;

      // Set the readOnlyInd to true for each evidence item, to disable the
      // row-level actions
      for (int i =
        0; i < result.evidenceParticipantDtlsList.dtls.items().length; i++) {
        result.evidenceParticipantDtlsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      result.caseUpdatesAllowed = true;
    }

    // END, CR00424202, JD

    return result;

  }

  /**
   * Retrieves the list of evidence (active and in edit) associated with the
   * case for a specific set of evidence types.
   *
   * @param caseKey Contains a case identifier.
   * @param evidenceTypesKey A list of evidence type codes.
   * @param typeLimit The maximum number of records per evidence type to return.
   *
   * @return result A list of 'In Edit' and 'Active' evidence for the Case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllEvidenceDtls listAllEvidenceByTypes(final CaseKey caseKey,
    final curam.core.facade.infrastructure.struct.EvidenceTypeList evidenceTypesKey,
    final EvidenceTypeLimit typeLimit)
    throws AppException, InformationalException {

    ListAllEvidenceDtls result = new ListAllEvidenceDtls();

    final CaseIDParticipantIDEvidenceTypeKey caseIDEvidenceTypeKey =
      new CaseIDParticipantIDEvidenceTypeKey();

    caseIDEvidenceTypeKey.caseIDKey.caseID = caseKey.caseID;

    result.caseID = caseKey.caseID;
    final ListAllInEditDtls inEditEvd =
      EvidenceControllerFactory.newInstance().listAllInEditByTypes(
        caseIDEvidenceTypeKey, evidenceTypesKey, typeLimit);

    // assign in-edit evidence to return struct
    result = assignInEditEvidenceParticipantDtlsList(result, inEditEvd);

    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList =
      EvidenceControllerFactory.newInstance()
        .listAllActiveEvdInstancesByTypes(caseKey, evidenceTypesKey,
          typeLimit);

    result.moreRecordsAvailable =
      activeEvdInstanceDtlsList.moreRecordsAvailable;

    // assign active evidence to return struct.
    result = assignActiveEvidenceParticipantDtlsList(result,
      activeEvdInstanceDtlsList);

    // BEGIN, CR00424202, JD

    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed =
      new EvidenceUpdatesAllowed();
    final boolean evidenceUpdatesAllowedInd =
      evidenceUpdatesAllowed.isUpdatesAllowed(caseKey);

    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      result.caseUpdatesAllowed = false;

      // Set the readOnlyInd to true for each evidence item, to disable the
      // row-level actions
      for (int i =
        0; i < result.evidenceParticipantDtlsList.dtls.items().length; i++) {
        result.evidenceParticipantDtlsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      result.caseUpdatesAllowed = true;
    }

    // END, CR00424202, JD

    return result;
  }

  /**
   * Retrieves the list of open evidence (active and in edit) associated with
   * the
   * case for a specific set of evidence types (evidence with no business end
   * date).
   *
   * @param caseKey Contains a case identifier.
   * @param evidenceTypesKey A list of evidence type codes.
   *
   * @return result A list of open 'In Edit' and 'Active' evidence for the Case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00397587
  @Override
  public ListAllEvidenceDtls listOpenEvidenceByTypes(final CaseKey caseKey,
    final curam.core.facade.infrastructure.struct.EvidenceTypeList evidenceTypesKey)
    throws AppException, InformationalException {

    final CaseIDParticipantIDEvidenceTypeKey caseIDEvidenceTypeKey =
      new CaseIDParticipantIDEvidenceTypeKey();

    caseIDEvidenceTypeKey.caseIDKey.caseID = caseKey.caseID;
    final EvidenceTypeLimit typeLimit = new EvidenceTypeLimit();

    typeLimit.limit = CuramConst.gkZero;

    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();
    final ListAllInEditDtls inEditEvd =
      evidenceController.listAllInEditByTypes(caseIDEvidenceTypeKey,
        evidenceTypesKey, typeLimit);

    ListAllEvidenceDtls result = new ListAllEvidenceDtls();

    result.caseID = caseKey.caseID;
    // assign in-edit evidence to return struct
    result = assignInEditEvidenceParticipantDtlsList(result, inEditEvd);

    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList =
      evidenceController.listCurrentActiveEvdInstancesByTypes(caseKey,
        evidenceTypesKey, typeLimit);

    // get evidenceIDs where there is no end date or end date in future
    final List<Long> openEvidenceIDs =
      getEvidenceListWithOpenEndDate(activeEvdInstanceDtlsList);
    final ActiveEvdInstanceDtlsList openEvidence =
      new ActiveEvdInstanceDtlsList();

    // add evidence with open end date
    for (final ActiveEvdInstanceDtls activeEvdInstance : activeEvdInstanceDtlsList.dtls) {
      if (openEvidenceIDs.contains(activeEvdInstance.evidenceID)) {
        openEvidence.dtls.add(activeEvdInstance);
      }
    }

    // assign active evidence to return struct.
    result = assignActiveEvidenceParticipantDtlsList(result, openEvidence);

    // BEGIN, CR00424202, JD

    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed =
      new EvidenceUpdatesAllowed();
    final boolean evidenceUpdatesAllowedInd =
      evidenceUpdatesAllowed.isUpdatesAllowed(caseKey);

    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      result.caseUpdatesAllowed = false;

      // Set the readOnlyInd to true for each evidence item, to disable the
      // row-level actions
      for (int i =
        0; i < result.evidenceParticipantDtlsList.dtls.items().length; i++) {
        result.evidenceParticipantDtlsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      result.caseUpdatesAllowed = true;
    }

    // END, CR00424202, JD

    return result;
  }

  /**
   * Retrieves the list of evidence (active and in edit) associated with the
   * case for a specific set of evidence types. Only evidence that was active
   * in the given date range will be returned.
   *
   * @param key Contains a case identifier, the evidence type code, the date
   * range and the maximum number of records per evidence type to return.
   *
   * @return result A list of 'In Edit' and 'Active' evidence for the Case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListAllEvidenceDtls
    listAllEvidenceByDateRangeAndType(final CaseIDEvdTypeAndDateRange key)
      throws AppException, InformationalException {

    ListAllEvidenceDtls result = new ListAllEvidenceDtls();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseIDParticipantIDEvidenceTypeKey caseIDEvidenceTypeKey =
      new CaseIDParticipantIDEvidenceTypeKey();

    caseIDEvidenceTypeKey.caseIDKey.caseID = key.caseID;

    final curam.core.facade.infrastructure.struct.EvidenceTypeList evidenceTypesKey =
      new curam.core.facade.infrastructure.struct.EvidenceTypeList();
    final EvidenceTypeDetails evidenceType = new EvidenceTypeDetails();

    evidenceType.evidenceType = key.evidenceType;
    evidenceTypesKey.dtls.add(evidenceType);

    final ListAllInEditDtls inEditEvidence =
      EvidenceControllerFactory.newInstance().listAllInEditByTypes(
        caseIDEvidenceTypeKey, evidenceTypesKey, key.typeLimit);

    // assign in-edit evidence to return struct
    result = assignInEditEvidenceParticipantDtlsList(result, inEditEvidence);
    result.caseID = key.caseID;

    final ActiveEvdInstanceDtlsList activeEvidence = EvidenceControllerFactory
      .newInstance().listActiveEvdInstancesByDateRangeAndType(caseKey,
        evidenceTypesKey, key.typeLimit, key.dateRange);

    result.moreRecordsAvailable = activeEvidence.moreRecordsAvailable;

    // assign active evidence to return struct.
    result = assignActiveEvidenceParticipantDtlsList(result, activeEvidence);

    // BEGIN, CR00424202, JD

    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed =
      new EvidenceUpdatesAllowed();
    final boolean evidenceUpdatesAllowedInd =
      evidenceUpdatesAllowed.isUpdatesAllowed(caseKey);

    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      result.caseUpdatesAllowed = false;

      // Set the readOnlyInd to true for each evidence item, to disable the
      // row-level actions
      for (int i =
        0; i < result.evidenceParticipantDtlsList.dtls.items().length; i++) {
        result.evidenceParticipantDtlsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      result.caseUpdatesAllowed = true;
    }

    // END, CR00424202, JD

    return result;
  }

  /*
   * Filters a list of evidence records by removing any elements outside the
   * typeLimit.
   * Assumes records have been sorted already.
   */
  private boolean filterActiveList(final List<ActiveEvdInstanceDtls> list,
    final EvidenceTypeLimit typeLimit) {

    boolean moreRecordsAvailable = false;
    int i = 1;

    for (final Iterator<ActiveEvdInstanceDtls> iterator =
      list.iterator(); iterator.hasNext();) {
      final ActiveEvdInstanceDtls dtls = iterator.next();

      // remove items that fall outside limit
      if (typeLimit.limit != 0 && i > typeLimit.limit) {
        iterator.remove();
        moreRecordsAvailable = true;
      }
      i++;
    }
    return moreRecordsAvailable;
  }

  /**
   * Returns a list of evidenceIDs from the given evidence list that have an
   * open business end
   * date (ie. no end date, or end date is in future).
   *
   * @param activeEvdInstanceDtlsList the list of evidence.
   * @return a list of evidenceIDs that have an open end date.
   * @throws AppException
   * @throws InformationalException
   */
  public List<Long> getEvidenceListWithOpenEndDate(
    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList)
    throws AppException, InformationalException {

    final Date today = curam.util.type.Date.getCurrentDate();

    final List<Long> openEvidence = new ArrayList<Long>();

    for (final ActiveEvdInstanceDtls evidenceDetails : activeEvdInstanceDtlsList.dtls) {
      final EvidenceIDDetails evidenceIDDtls = new EvidenceIDDetails();

      evidenceIDDtls.evidenceID = evidenceDetails.evidenceID;

      final DynamicEvidenceDataAttributeDtls dataAttributeDetails =
        EvidenceControllerFactory.newInstance()
          .getBusinessEndDateAttribute(evidenceIDDtls);

      final DynamicEvidenceDataAttributeDtls startDateAttributeDetails =
        EvidenceControllerFactory.newInstance()
          .getBusinessStartDateAttribute(evidenceIDDtls);

      if (dataAttributeDetails != null) {
        final curam.util.type.Date endDate =
          DateUtil.getISODate(dataAttributeDetails.value);

        // BEGIN, 231333, DOC
        final curam.util.type.Date startDate =
          DateUtil.getISODate(startDateAttributeDetails.value);

        // if end date is open ended, null, or not before today, the evidence is
        // current assuming that the start date is not in the future
        if (endDate == null || endDate.isZero() || !endDate.before(today)) {

          // Check to make sure start date is not in future
          if (!startDate.after(today)) {
            openEvidence.add(evidenceIDDtls.evidenceID);
          }
          // END, 231333, DOC
        }
        // BEGIN, CR00463497, YF
      } else {
        // no business end date attribute, therefore classed as open, add to
        // return list
        openEvidence.add(evidenceIDDtls.evidenceID);
      }
      // END, CR00463497, YF
    }
    return openEvidence;
  }

  /*
   * Helper method to check for an empty date
   */
  private boolean isEmptyDate(final curam.util.type.Date date) {

    return date == null || date.equals(Date.kZeroDate);
  }

  // END, CR00463497, YF

  /*
   * Assigns in-edit evidence details to return list.
   * There is another version of this method -
   * assignInEditEvidenceParticipantDtlsList1. Whenever there
   * is any change made to this method, developer is requested to visit -
   * assignInEditEvidenceParticipantDtlsList1
   * as well.
   *
   * @param listAllEvidenceDtls
   * The overall return structure that will contain both active and
   * in-edit evidence.
   *
   * @param inEditEvidenceDtls
   * The In-Edit Evidence details retrieved.
   *
   * @return The overall return structure that will contain both active and
   * in-edit evidence.
   */
  private ListAllEvidenceDtls assignInEditEvidenceParticipantDtlsList(
    final ListAllEvidenceDtls listAllEvidenceDtls,
    final ListAllInEditDtls inEditEvidenceDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method -
    // assignInEditEvidenceParticipantDtlsList1. Whenever there
    // is any change made to this method, developer is requested to visit -
    // assignInEditEvidenceParticipantDtlsList1
    // as well.
    // END, CR00452604
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    for (final curam.core.sl.infrastructure.struct.EvidenceParticipantDtls evidenceParticipantDtls : inEditEvidenceDtls.evidenceParticipantDtlsList.dtls) {
      final EvidenceParticipantDtls newEvidenceParticipantDtls =
        new EvidenceParticipantDtls();

      // BEGIN, CR00466301, SH
      final SuccessionID arg0 = new SuccessionID();

      arg0.successionID = evidenceParticipantDtls.successionID;
      final EvdInstanceChangeDtlsList listInEditEvdInstanceChanges =
        evidenceController.listInEditEvdInstanceChanges(arg0);

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID =
        listInEditEvdInstanceChanges.dtlsList.get(0).evidenceID;
      eiEvidenceKey.evidenceType = evidenceParticipantDtls.evidenceType;
      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        evidenceController.getEvidenceSummaryDetails(eiEvidenceKey);

      newEvidenceParticipantDtls.summary = LocalizableXMLStringHelper
        .toClientFormattedText(eiFieldsForListDisplayDtls.summary);
      // END, CR00466301, SH

      newEvidenceParticipantDtls.activeEvidence = false;
      newEvidenceParticipantDtls.caseID = evidenceParticipantDtls.caseID;
      newEvidenceParticipantDtls.endDate = evidenceParticipantDtls.endDate;
      newEvidenceParticipantDtls.evidenceType =
        evidenceParticipantDtls.evidenceType;
      newEvidenceParticipantDtls.latestActivity =
        evidenceParticipantDtls.latestActivity;
      newEvidenceParticipantDtls.participantID =
        evidenceParticipantDtls.participantID;
      newEvidenceParticipantDtls.participantName =
        evidenceParticipantDtls.participantName;
      newEvidenceParticipantDtls.period = evidenceParticipantDtls.period;
      newEvidenceParticipantDtls.startDate =
        evidenceParticipantDtls.startDate;
      newEvidenceParticipantDtls.successionID =
        evidenceParticipantDtls.successionID;
      // BEGIN, CR00417992, DG
      newEvidenceParticipantDtls.readOnlyInd =
        evidenceParticipantDtls.readOnlyInd;
      // END, CR00417992

      final EvdInstanceChangeDtlsList inEditChangeDtlsList =
        populateEvidenceIDandDescriptorID_InEdit(newEvidenceParticipantDtls);

      newEvidenceParticipantDtls.evidenceDetailsPanelURL =
        determineEvidencePagePanel(newEvidenceParticipantDtls,
          inEditChangeDtlsList.dtlsList.size() > 1).getURI();

      // Do not show the InEdit Record Succession twice if already exists in the
      // Active Record on this case.
      if (!isEvidenceSharedIntancePresentOnActiveEvidence(
        newEvidenceParticipantDtls)) {
        listAllEvidenceDtls.evidenceParticipantDtlsList.dtls
          .add(newEvidenceParticipantDtls);
      }

    }

    return listAllEvidenceDtls;
  }

  /*
   * Assigns active evidence details to return list.
   * There is another version of this method -
   * assignActiveEvidenceParticipantDtlsList1. Whenever there
   * is any change made to this method, developer is requested to visit -
   * assignActiveEvidenceParticipantDtlsList1
   * as well.
   *
   * @param listAllEvidenceDtlsResult
   * The return struct where the evidenceParticipant details will be
   * added to.
   *
   * @param activeEvdDetails
   * The active evidence details.
   *
   * @return The details of all the evidence.
   */
  private ListAllEvidenceDtls assignActiveEvidenceParticipantDtlsList(
    final ListAllEvidenceDtls listAllEvidenceDtlsResult,
    final ActiveEvdInstanceDtlsList activeEvdDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method -
    // assignActiveEvidenceParticipantDtlsList. Whenever there
    // is any change made to this method, developer is requested to visit -
    // assignActiveEvidenceParticipantDtlsList
    // as well.
    // END, CR00452604
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    for (final ActiveEvdInstanceDtls activeEvdInstanceDtls : activeEvdDetails.dtls) {
      final EvidenceParticipantDtls newEvidenceParticipantDtls =
        new EvidenceParticipantDtls();

      // BEGIN, CR00466301, SH
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = activeEvdInstanceDtls.evidenceID;
      eiEvidenceKey.evidenceType = activeEvdInstanceDtls.evidenceType;
      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        evidenceController.getEvidenceSummaryDetails(eiEvidenceKey);

      newEvidenceParticipantDtls.summary = LocalizableXMLStringHelper
        .toClientFormattedText(eiFieldsForListDisplayDtls.summary);
      newEvidenceParticipantDtls.activeEvidence = true;
      newEvidenceParticipantDtls.endDate = activeEvdInstanceDtls.endDate;
      newEvidenceParticipantDtls.evidenceType =
        activeEvdInstanceDtls.evidenceType;
      newEvidenceParticipantDtls.latestActivity =
        activeEvdInstanceDtls.latestActivity;
      newEvidenceParticipantDtls.participantID =
        activeEvdInstanceDtls.participantID;
      newEvidenceParticipantDtls.participantName =
        activeEvdInstanceDtls.concernRoleName;
      newEvidenceParticipantDtls.period = activeEvdInstanceDtls.period;
      newEvidenceParticipantDtls.startDate = activeEvdInstanceDtls.startDate;
      newEvidenceParticipantDtls.successionID =
        activeEvdInstanceDtls.successionID;
      newEvidenceParticipantDtls.caseID = listAllEvidenceDtlsResult.caseID;
      //BEGIN, WI253775, YF
      newEvidenceParticipantDtls.evidenceID = activeEvdInstanceDtls.evidenceID;
      // BEGIN, CR00417992, DG
      newEvidenceParticipantDtls.readOnlyInd =
        activeEvdInstanceDtls.readOnlyInd;     
      // END, CR00417992
      
      //Read the evidence descriptor ID
      RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();
      relatedIDAndEvidenceTypeKey.evidenceType = activeEvdInstanceDtls.evidenceType;
      relatedIDAndEvidenceTypeKey.relatedID = activeEvdInstanceDtls.evidenceID;
      newEvidenceParticipantDtls.evidenceDescriptorID 
        = evidenceController.readEvidenceDescriptorByRelatedIDAndType(relatedIDAndEvidenceTypeKey).evidenceDescriptorID;

      //Determine how many active records the evidence has, to set the evidence panel URI
      final SuccessionID successionID = new SuccessionID();
      successionID.successionID = activeEvdInstanceDtls.successionID;
      final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
        listActiveEvdInstanceChanges(successionID);
          
      final int numberOfEvdRecords = evdInstanceChangeDtlsList.dtlsList.size();

      newEvidenceParticipantDtls.evidenceDetailsPanelURL =
        determineEvidencePagePanel(newEvidenceParticipantDtls,
          numberOfEvdRecords > 1).getURI();

      if (numberOfEvdRecords == 1) {
        newEvidenceParticipantDtls.activeWithSingleInstanceInd = true;
      }
      //END, WI253775, YF
      // Add details to result
      listAllEvidenceDtlsResult.evidenceParticipantDtlsList.dtls
        .add(newEvidenceParticipantDtls);
    }

    return listAllEvidenceDtlsResult;
  }

  /**
   * There is another version of this method - determineEvidencePagePanel1.
   * Therefore if there is any change
   * made to this method, then developer should also visit -
   * determineEvidencePagePanel1.
   * Determines the evidence preview panel page details based on the evidence
   * details.
   *
   * @param evidenceParticipantDtls
   * The specific evidence details.
   *
   * @return ClientURI The preview panel URI page to be displayed.
   */
  private ClientURI determineEvidencePagePanel(
    final EvidenceParticipantDtls evidenceParticipantDtls,
    final boolean hasMultipleEvdRecords) {

    // If multiple instances for this evidence record exist
    if (evidenceParticipantDtls.activeEvidence && hasMultipleEvdRecords) {
      return evidenceURIHelper.getEvidenceListMultipleInstancesURI(
        evidenceParticipantDtls.successionID);
    } else {
      return evidenceURIHelper
        .getEvidenceDetailsPanelURI(evidenceParticipantDtls);
    }
  }

  /*
   * Assigns the evidenceID and evidenceDescriptorID for active evidence.
   *
   * There is another version of this method -
   * populateEvidenceIDandDescriptorID_Active1. Whenever there
   * is any change made to this method, developer is requested to visit -
   * populateEvidenceIDandDescriptorID_Active1
   * as well.
   *
   * @param evidenceParticipantDtls
   * The Evidence Participant Details.
   */
  private EvdInstanceChangeDtlsList populateEvidenceIDandDescriptorID_Active(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = evidenceParticipantDtls.successionID;

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      listActiveEvdInstanceChanges(successionID);

    if (evidenceParticipantDtls.activeEvidence
      && evdInstanceChangeDtlsList.dtlsList.size() == 1) {
      // Should ever be one
      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList
          .get(CuramConst.gkZero).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;
    } else {
      // If multiple instances get the latest one
      final int position = checkForEffectiveDate(evdInstanceChangeDtlsList);

      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList.get(position).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(position).evidenceID;
    }
    return evdInstanceChangeDtlsList;
  }

  /*
   * Assigns the evidenceID and evidenceDescriptorID for in-edit evidence.
   *
   * There is another version of this method -
   * populateEvidenceIDandDescriptorID_InEdit1. Whenever there
   * is any change made to this method, developer is requested to visit -
   * populateEvidenceIDandDescriptorID_InEdit1
   * as well.
   *
   * @param evidenceParticipantDtls
   * The Evidence Participant Details.
   */
  private EvdInstanceChangeDtlsList populateEvidenceIDandDescriptorID_InEdit(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = evidenceParticipantDtls.successionID;

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      listInEditEvdInstanceChanges(successionID);

    evidenceParticipantDtls.evidenceDescriptorID =
      evdInstanceChangeDtlsList.dtlsList
        .get(CuramConst.gkZero).evidenceDescriptorID;
    evidenceParticipantDtls.evidenceID =
      evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;

    return evdInstanceChangeDtlsList;
  }

  /**
   * Determines if an InEdit Evidence succession record shares the same
   * sharedInstanceID on any active record on a specified case. If this
   * succession already exist for an active record, returns true.
   *
   * @param evidenceParticipantDtls
   * The specific evidence details.
   *
   * @return Indicator to determine if the sharedInstanceID already exists on an
   * active record.
   */
  private boolean isEvidenceSharedIntancePresentOnActiveEvidence(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    // Determine if there are other instances of the sharedInstanceID on an
    // active record.
    final SharedInstanceIDCaseIDStatusCode sharedInstanceKey =
      new SharedInstanceIDCaseIDStatusCode();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      evidenceParticipantDtls.evidenceDescriptorID;

    final EvidenceDescriptor evidenceDecscriptorObj =
      EvidenceDescriptorFactory.newInstance();

    // Searches for all active records with the same shared instance ID on the
    // specified case.
    final long sharedInstanceID =
      evidenceDecscriptorObj.read(evidenceDescriptorKey).sharedInstanceID;

    sharedInstanceKey.sharedInstanceID = sharedInstanceID;

    sharedInstanceKey.caseID = evidenceParticipantDtls.caseID;
    sharedInstanceKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    if (evidenceDecscriptorObj
      .searchActiveBySharedInstanceIDCaseID(sharedInstanceKey).dtls
        .size() > 0) {
      // An active shared instanceID exists for this record.
      return true;
    }
    return false;
  }

  /**
   * Returns the correct position of the latest {@link #evidenceDescriptorID} in
   * a list of {@link #EvdInstanceChangeDtlsList}.
   *
   * @param evdInstanceChangeDtlsList
   * The evidence Details
   * @return The position of the latest {@link #evidenceDescriptorID} in a list
   * of {@link #EvdInstanceChangeDtlsList}.
   *
   * <strong>Note<strong>
   * <p>
   * This function is no longer used as of IBM Curam 7.0.9 as the logic within
   * the API made no sense. The most recent records were being deemed the most
   * recent by virtue of their latest update timestamp, which makes no sense.
   * In temporal terms, such records could be years old.
   */
  private int checkForEffectiveDate(
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList)
    throws AppException, InformationalException {

    int loopControl = 0;
    int returnPosition = 0;
    DateTime changedDatetime = null;
    DateTime latestChangedDatetime = null;

    // loop through the Evidence Change History to get the most up to date
    // evidence entry
    for (final EvdInstanceChangeDtls evdInstanceChangeDtls : evdInstanceChangeDtlsList.dtlsList) {
      final EvidenceChangeHistory evidenceChangeHistoryObj =
        EvidenceChangeHistoryFactory.newInstance();
      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        evdInstanceChangeDtls.evidenceDescriptorID;
      final EvidenceChangeHistoryDtlsList evidenceChangeHistoryDtlsList =
        evidenceChangeHistoryObj
          .searchByEvidenceDescriptorID(evidenceDescriptorKey);

      for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : evidenceChangeHistoryDtlsList.dtls) {
        if (latestChangedDatetime == null) {
          latestChangedDatetime = evidenceChangeHistoryDtls.changeDateTime;
        } else {
          if (evidenceChangeHistoryDtls.changeDateTime
            .after(latestChangedDatetime)) {
            latestChangedDatetime = evidenceChangeHistoryDtls.changeDateTime;
          }
        }
      }
      if (changedDatetime == null) {
        changedDatetime = latestChangedDatetime;
        returnPosition = loopControl;
      }
      if (latestChangedDatetime.after(changedDatetime)) {
        changedDatetime = latestChangedDatetime;
        returnPosition = loopControl;
      }
      loopControl++;
    }
    return returnPosition;

  }

  // END, CR00352812

  /**
   * Retrieve a list of Evidence succession record details for the specified
   * successionId.
   *
   * @param key the successionId on which to retrieve the evidence details
   * list.
   * @return EvidenceDetailsList the list of evidence details for each
   * succession record.
   * @throws InformationalException generic informational exception
   * @throws AppException generic application exception.
   */
  @Override
  public EvidenceDetailsList listEvidenceSuccessions(
    final curam.core.sl.infrastructure.entity.struct.SuccessionID key)
    throws AppException, InformationalException {

    final EvidenceDetailsList evidenceList = new EvidenceDetailsList();

    final EvdInstanceChangeDtlsList changeList =
      listActiveEvdInstanceChanges(key);

    if (changeList.dtlsList.size() > 0) {

      for (int i = 0; i < changeList.dtlsList.size(); i++) {
        final EvidenceDetails evidenceDetails = new EvidenceDetails();

        evidenceDetails.caseID = changeList.dtlsList.get(i).caseID;
        evidenceDetails.evidenceDescriptorID =
          changeList.dtlsList.get(i).evidenceDescriptorID;
        evidenceDetails.evidenceID = changeList.dtlsList.get(i).evidenceID;
        evidenceDetails.successionID =
          changeList.dtlsList.get(i).successionID;
        evidenceDetails.source = changeList.dtlsList.get(i).source;
        evidenceDetails.updatedBy = changeList.dtlsList.get(i).latestActivity;
        evidenceDetails.period = changeList.dtlsList.get(i).period;
        evidenceDetails.evidenceType =
          changeList.dtlsList.get(i).evidenceType;

        final EvidenceDescriptorKey evidenceDescriptorKey =
          new EvidenceDescriptorKey();
        final EvidenceDescriptor evidenceDescriptorObj =
          EvidenceDescriptorFactory.newInstance();

        evidenceDescriptorKey.evidenceDescriptorID =
          changeList.dtlsList.get(i).evidenceDescriptorID;
        final EvidenceDescriptorDtls evidenceDescriptorDtls2 =
          evidenceDescriptorObj.read(evidenceDescriptorKey);

        final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

        evidenceTypeKey.evidenceType = evidenceDescriptorDtls2.evidenceType;

        if (isEvidenceParticipantData(evidenceTypeKey).participantDataInd) {

          final LocalisableString description = new LocalisableString(
            BPOEVIDENCECONTROLLER.INF_DESCRIPTION_PARTICIPANT);

          description.arg(evidenceDescriptorDtls2.receivedDate);
          evidenceDetails.changeSummary = description.toClientFormattedText();

        } else {

          final LocalisableString description =
            new LocalisableString(BPOEVIDENCECONTROLLER.INF_DESCRIPTION);

          description.arg(evidenceDescriptorDtls2.receivedDate);
          description
            .arg(new CodeTableItemIdentifier(EVIDENCECHANGEREASON.TABLENAME,
              evidenceDescriptorDtls2.changeReason));
          evidenceDetails.changeSummary = description.toClientFormattedText();

        }

        // Read the source of the evidence
        final LocalisableString source = getEvidenceSource(evidenceDetails);

        evidenceDetails.source = source.toClientFormattedText();

        evidenceList.dtls.add(evidenceDetails);
      }
    }

    return evidenceList;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the originating source of this evidence record. If the
   * evidence was shared via the evidence broker this will return the name of
   * the originating case, otherwise the source will be the participant record.
   *
   * @param concernRoleKey
   * The unique identifier for the participant.
   *
   * @param pdcEvidence
   * The evidence details.
   *
   * @return Text displaying the source of the evidence in the user's locale.
   */
  protected LocalisableString
    getEvidenceSource(final EvidenceDetails evidenceDetails)
      throws AppException, InformationalException {

    // Create a place holder for the source of the evidence
    String tempSource = CuramConst.gkEmpty;

    // Get the evidence descriptor record
    EvidenceDescriptorDtls evidenceDescriptorDtls =
      new EvidenceDescriptorDtls();
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    final RelatedIDEvidenceTypeAndCaseIDKey relEvKey =
      new RelatedIDEvidenceTypeAndCaseIDKey();

    relEvKey.caseID = evidenceDetails.caseID;
    relEvKey.evidenceType = evidenceDetails.evidenceType;
    relEvKey.relatedID = evidenceDetails.evidenceID;

    evidenceDescriptorDtls =
      evidenceDescriptorObj.readByRelatedIDTypeAndCaseID(relEvKey);

    // Check if the evidence was shared from another case
    if (evidenceDescriptorDtls.sharedInd) {

      // Get the case type of the source case
      final CaseKey sourceCaseKey = new CaseKey();

      sourceCaseKey.caseID = evidenceDescriptorDtls.sourceCaseID;
      // BEGIN, CR00364401, ZV
      tempSource = getSourceCaseDescription(sourceCaseKey);
      // END, CR00364401
    } else {

      // Check the concern role type

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      CaseReferenceCRNameAltIDDetails caseReferenceCRNameAltIDDetails;

      final CaseHeaderKey cKey = new CaseHeaderKey();

      cKey.caseID = evidenceDetails.caseID;
      // read case details to get case reference number and participant name
      caseKey.caseID = evidenceDetails.caseID;
      caseReferenceCRNameAltIDDetails =
        caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(caseKey);

      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(cKey);

      // Check the concern role type
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
      final ConcernRoleTypeDetails concernRoleTypeDetails =
        concernRoleObj.readConcernRoleType(concernRoleKey);

      // Dependency on PDC here should be removed but due to time-line on
      // localization
      // new entries in core message files will need to wait.
      if (concernRoleTypeDetails.concernRoleType
        .equals(CONCERNROLETYPE.PERSON)) {

        tempSource =
          PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PERSON.toString();
      } else if (concernRoleTypeDetails.concernRoleType
        .equals(CONCERNROLETYPE.PROSPECTPERSON)) {

        tempSource =
          PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PROSPECT.toString();
      }
    }

    final LocalisableString source =
      new LocalisableString(PDCEVIDENCEDESCRIPTION.PDC_GEN_DESC)
        .arg(tempSource);

    return source;
  }

  // BEGIN, CR00426702, GK
  /**
   * Returns an informational message about the un evaluated evidence for a
   * given
   * case identifier.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Contains case identifier.
   *
   * @return An informational message about the unevaluated evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ECWarningsDtlsList getUnevaluatedEvidenceInformation(
    final CaseKey key) throws AppException, InformationalException {

    // Check if there are any unevaluated evidence for the given case
    // identifier.
    boolean isUnevaluatedEvidenceFound = false;
    final CaseID caseID = new CaseID();

    caseID.caseID = key.caseID;
    // BEGIN, CR00427296, AKr
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
      postponeVerificationInterface
        .listEvidenceswithpostponedVerifications(caseID);

    isUnevaluatedEvidenceFound = evidenceDescriptorDtlsList.dtls.size() > 0;
    // END, CR00427296
    // If there are any un evaluated evidence for the given case identifier then
    // construct and return the informational message about the unevaluated
    // evidence.
    final ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    if (isUnevaluatedEvidenceFound) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          BPOEVIDENCECONTROLLERExceptionCreator
            .INF_UNEVALUATED_EVIDENCE_INFORMATION(),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

      final String warnings[] =
        informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

        ecWarningsDtls.msg = warnings[i];
        ecWarningsDtlsList.dtls.addRef(ecWarningsDtls);
      }
    }

    return ecWarningsDtlsList;
  }

  // END, CR00426702

  /**
   * Lists all succession evidence changes on an 'Active' evidence instance.
   *
   * There is another version of this method - listActiveEvdInstanceChanges.
   * Whenever there is any change
   * made to this method, developer is requested to visit -
   * listActiveEvdInstanceChanges as well.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public EvdInstanceChangeDtlsList listActiveEvdInstanceChanges1(
    final curam.core.sl.infrastructure.entity.struct.SuccessionID key)
    throws AppException, InformationalException {

    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      evidenceController.listActiveEvdInstanceChanges1(key);
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsListRet =
      new EvdInstanceChangeDtlsList();

    evdInstanceChangeDtlsListRet.verificationOrIssuesExist = false;

    for (final EvdInstanceChangeDtls details : evdInstanceChangeDtlsList.dtlsList) {

      if (details.verificationOrIssuesExist
        && !evdInstanceChangeDtlsListRet.verificationOrIssuesExist) {
        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsListRet.verificationOrIssuesExist = true;
      }

      if (!details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT)
        && !details.statusCode
          .equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALREJECTED)) {
        evdInstanceChangeDtlsListRet.dtlsList.addRef(details);
      }

    }
    if (Configuration
      .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsListRet.evdBrokerEnabled = true;
    }
    evdInstanceChangeDtlsListRet.inEditExistInd =
      evdInstanceChangeDtlsList.inEditExistInd;

    return evdInstanceChangeDtlsListRet;

  }

  /**
   * Assigns the evidenceID and evidenceDescriptorID for active evidence.
   *
   * There is another version of this method -
   * populateEvidenceIDandDescriptorID_Active. Whenever there
   * is any change made to this method, developer is requested to visit -
   * populateEvidenceIDandDescriptorID_Active
   * as well.
   *
   * @param evidenceParticipantDtls
   * The Evidence Participant Details.
   *
   */
  private EvdInstanceChangeDtlsList populateEvidenceIDandDescriptorID_Active1(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = evidenceParticipantDtls.successionID;

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      listActiveEvdInstanceChanges1(successionID);

    if (evidenceParticipantDtls.activeEvidence
      && evdInstanceChangeDtlsList.dtlsList.size() == 1) {
      // Should ever be one
      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList
          .get(CuramConst.gkZero).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;
    } else {
      // If multiple instances get the latest one
      final int position = checkForEffectiveDate(evdInstanceChangeDtlsList);

      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList.get(position).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(position).evidenceID;
    }
    return evdInstanceChangeDtlsList;
  }

  /**
   * Assigns the evidenceID and evidenceDescriptorID for in-edit evidence.
   *
   * There is another version of this method -
   * populateEvidenceIDandDescriptorID_InEdit. Whenever there
   * is any change made to this method, developer is requested to visit -
   * populateEvidenceIDandDescriptorID_InEdit
   * as well.
   *
   * @param evidenceParticipantDtls
   * The Evidence Participant Details.
   *
   */
  private EvdInstanceChangeDtlsList populateEvidenceIDandDescriptorID_InEdit1(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = evidenceParticipantDtls.successionID;

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      listInEditEvdInstanceChanges1(successionID);

    evidenceParticipantDtls.evidenceDescriptorID =
      evdInstanceChangeDtlsList.dtlsList
        .get(CuramConst.gkZero).evidenceDescriptorID;
    evidenceParticipantDtls.evidenceID =
      evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;

    return evdInstanceChangeDtlsList;
  }

  /**
   * Assigns active evidence details to return list.
   *
   * There is another version of this method -
   * assignActiveEvidenceParticipantDtlsList. Whenever there
   * is any change made to this method, developer is requested to visit -
   * assignActiveEvidenceParticipantDtlsList
   * as well.
   *
   * @param listAllEvidenceDtlsResult
   * The return struct where the evidenceParticipant details will be
   * added to.
   * @param activeEvdDetails
   * The active evidence details.
   * @return The details of all the evidence.
   */
  private ListAllEvidenceDtls assignActiveEvidenceParticipantDtlsList1(
    final ListAllEvidenceDtls listAllEvidenceDtlsResult,
    final ActiveEvdInstanceDtlsList activeEvdDetails)
    throws AppException, InformationalException {

    // There is another version of this method -
    // assignActiveEvidenceParticipantDtlsList. Whenever there
    // is any change made to this method, developer is requested to visit -
    // assignActiveEvidenceParticipantDtlsList
    // as well.
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    for (final ActiveEvdInstanceDtls activeEvdInstanceDtls : activeEvdDetails.dtls) {
      final EvidenceParticipantDtls newEvidenceParticipantDtls =
        new EvidenceParticipantDtls();

      // BEGIN, CR00466301, SH
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = activeEvdInstanceDtls.evidenceID;
      eiEvidenceKey.evidenceType = activeEvdInstanceDtls.evidenceType;
      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        evidenceController.getEvidenceSummaryDetails(eiEvidenceKey);

      newEvidenceParticipantDtls.summary = LocalizableXMLStringHelper
        .toClientFormattedText(eiFieldsForListDisplayDtls.summary);
      // END, CR00466301, SH

      newEvidenceParticipantDtls.activeEvidence = true;
      newEvidenceParticipantDtls.endDate = activeEvdInstanceDtls.endDate;
      newEvidenceParticipantDtls.evidenceType =
        activeEvdInstanceDtls.evidenceType;
      newEvidenceParticipantDtls.latestActivity =
        activeEvdInstanceDtls.latestActivity;
      newEvidenceParticipantDtls.participantID =
        activeEvdInstanceDtls.participantID;
      newEvidenceParticipantDtls.participantName =
        activeEvdInstanceDtls.concernRoleName;
      newEvidenceParticipantDtls.period = activeEvdInstanceDtls.period;
      newEvidenceParticipantDtls.startDate = activeEvdInstanceDtls.startDate;
      newEvidenceParticipantDtls.successionID =
        activeEvdInstanceDtls.successionID;
      newEvidenceParticipantDtls.caseID = listAllEvidenceDtlsResult.caseID;
      newEvidenceParticipantDtls.readOnlyInd =
        activeEvdInstanceDtls.readOnlyInd;
      //BEGIN, WI253775, YF
      newEvidenceParticipantDtls.evidenceID = activeEvdInstanceDtls.evidenceID;
      newEvidenceParticipantDtls.readOnlyInd =
        activeEvdInstanceDtls.readOnlyInd;     
      
      //Read the evidence descriptor ID
      RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();
      relatedIDAndEvidenceTypeKey.evidenceType = activeEvdInstanceDtls.evidenceType;
      relatedIDAndEvidenceTypeKey.relatedID = activeEvdInstanceDtls.evidenceID;
      newEvidenceParticipantDtls.evidenceDescriptorID 
        = evidenceController.readEvidenceDescriptorByRelatedIDAndType(relatedIDAndEvidenceTypeKey).evidenceDescriptorID;

      //Determine how many active records the evidence has, to set the evidence panel URI
      final SuccessionID successionID = new SuccessionID();
      successionID.successionID = activeEvdInstanceDtls.successionID;
      final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
        listActiveEvdInstanceChanges(successionID);
          
      final int numberOfEvdRecords = evdInstanceChangeDtlsList.dtlsList.size();

      newEvidenceParticipantDtls.evidenceDetailsPanelURL =
        determineEvidencePagePanel(newEvidenceParticipantDtls,
          numberOfEvdRecords > 1).getURI();
      // If only one instance exist for this active record, set the indicator.
      if (numberOfEvdRecords == 1) {
        newEvidenceParticipantDtls.activeWithSingleInstanceInd = true;
      }
      //END, WI253775, YF
      // Add details to result
      listAllEvidenceDtlsResult.evidenceParticipantDtlsList.dtls
        .add(newEvidenceParticipantDtls);

    }

    return listAllEvidenceDtlsResult;
  }

  /**
   * Assigns the evidenceID and evidenceDescriptorID for active evidence.
   *
   * There is another version of this method -
   * populateEvidenceIDandDescriptorID. Whenever there
   * is any change made to this method, developer is requested to visit -
   * populateEvidenceIDandDescriptorID
   * as well.
   *
   * @param evidenceParticipantDtls
   * The Evidence Participant Details.
   *
   */
  private void populateEvidenceIDandDescriptorID1(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    // There is another version of this method -
    // populateEvidenceIDandDescriptorID. Whenever there
    // is any change made to this method, developer is requested to visit -
    // populateEvidenceIDandDescriptorID
    // as well.
    EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      new EvdInstanceChangeDtlsList();
    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = evidenceParticipantDtls.successionID;

    if (!evidenceParticipantDtls.activeEvidence) {
      evdInstanceChangeDtlsList = listInEditEvdInstanceChanges1(successionID);
      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList
          .get(CuramConst.gkZero).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;
    } else if (evidenceParticipantDtls.activeEvidence
      && listActiveEvdInstanceChanges1(successionID).dtlsList.size() == 1) {
      // Should ever be one
      evdInstanceChangeDtlsList = listActiveEvdInstanceChanges1(successionID);
      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList
          .get(CuramConst.gkZero).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;
    } else {

      // If multiple instances get the latest one
      evdInstanceChangeDtlsList = listActiveEvdInstanceChanges1(successionID);
      final int position = checkForEffectiveDate(evdInstanceChangeDtlsList);

      evidenceParticipantDtls.evidenceDescriptorID =
        evdInstanceChangeDtlsList.dtlsList.get(position).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID =
        evdInstanceChangeDtlsList.dtlsList.get(position).evidenceID;
    }
  }

  /**
   * Assigns in-edit evidence details to return list.
   *
   * There is another version of this method -
   * assignInEditEvidenceParticipantDtlsList. Whenever there
   * is any change made to this method, developer is requested to visit -
   * assignInEditEvidenceParticipantDtlsList
   * as well.
   *
   * @param listAllEvidenceDtls
   * The overall return structure that will contain both active and
   * in-edit evidence.
   * @param inEditEvidenceDtls
   * The In-Edit Evidence details retrieved.
   *
   * @return The overall return structure that will contain both active and
   * in-edit evidence.
   */
  private ListAllEvidenceDtls assignInEditEvidenceParticipantDtlsList1(
    final ListAllEvidenceDtls listAllEvidenceDtls,
    final ListAllInEditDtls inEditEvidenceDtls)
    throws AppException, InformationalException {

    // There is another version of this method -
    // assignInEditEvidenceParticipantDtlsList. Whenever there
    // is any change made to this method, developer is requested to visit -
    // assignInEditEvidenceParticipantDtlsList
    // as well.
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    for (final curam.core.sl.infrastructure.struct.EvidenceParticipantDtls evidenceParticipantDtls : inEditEvidenceDtls.evidenceParticipantDtlsList.dtls) {
      final EvidenceParticipantDtls newEvidenceParticipantDtls =
        new EvidenceParticipantDtls();

      // BEGIN, CR00466301, SH
      final SuccessionID arg0 = new SuccessionID();

      arg0.successionID = evidenceParticipantDtls.successionID;
      final EvdInstanceChangeDtlsList listInEditEvdInstanceChanges =
        evidenceController.listInEditEvdInstanceChanges(arg0);
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID =
        listInEditEvdInstanceChanges.dtlsList.get(0).evidenceID;
      eiEvidenceKey.evidenceType = evidenceParticipantDtls.evidenceType;
      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        evidenceController.getEvidenceSummaryDetails(eiEvidenceKey);

      newEvidenceParticipantDtls.summary = LocalizableXMLStringHelper
        .toClientFormattedText(eiFieldsForListDisplayDtls.summary);
      // END, CR00466301, SH

      newEvidenceParticipantDtls.activeEvidence = false;
      newEvidenceParticipantDtls.caseID = evidenceParticipantDtls.caseID;
      newEvidenceParticipantDtls.endDate = evidenceParticipantDtls.endDate;
      newEvidenceParticipantDtls.evidenceType =
        evidenceParticipantDtls.evidenceType;
      newEvidenceParticipantDtls.latestActivity =
        evidenceParticipantDtls.latestActivity;
      newEvidenceParticipantDtls.participantID =
        evidenceParticipantDtls.participantID;
      newEvidenceParticipantDtls.participantName =
        evidenceParticipantDtls.participantName;
      newEvidenceParticipantDtls.period = evidenceParticipantDtls.period;
      newEvidenceParticipantDtls.startDate =
        evidenceParticipantDtls.startDate;
      newEvidenceParticipantDtls.successionID =
        evidenceParticipantDtls.successionID;
      newEvidenceParticipantDtls.readOnlyInd =
        evidenceParticipantDtls.readOnlyInd;

      populateEvidenceIDandDescriptorID1(newEvidenceParticipantDtls);
      newEvidenceParticipantDtls.evidenceDetailsPanelURL =
        determineEvidencePagePanel1(newEvidenceParticipantDtls).getURI();

      // Do not show the InEdit Record Succession twice if already exists in the
      // Active Record on this case.
      if (!isEvidenceSharedIntancePresentOnActiveEvidence(
        newEvidenceParticipantDtls)) {
        listAllEvidenceDtls.evidenceParticipantDtlsList.dtls
          .add(newEvidenceParticipantDtls);
      }

    }

    return listAllEvidenceDtls;
  }

  /**
   * Retrieves the list of ALL evidence (active and in edit) associated with the
   * case.
   *
   * There is another version of this method - listAllEvidence. Whenever there
   * is any change made to this method, developer is requested to visit -
   * listAllEvidence
   * as well.
   *
   * @param key Contains a case identifier.
   *
   * @return result A list of 'In Edit' and 'Active' evidence for the Case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListAllEvidenceDtls listAllEvidence1(
    final curam.core.facade.infrastructure.struct.CaseKey caseKey)
    throws AppException, InformationalException {

    // There is another version of this method - listAllEvidence. Whenever there
    // is any change made to this method, developer is requested to visit -
    // listAllEvidence
    // as well.
    ListAllEvidenceDtls result = new ListAllEvidenceDtls();

    final CaseIDParticipantIDEvidenceTypeKey caseIDEvidenceTypeKey =
      new CaseIDParticipantIDEvidenceTypeKey();

    caseIDEvidenceTypeKey.caseIDKey.caseID = caseKey.caseID;

    result.caseID = caseKey.caseID;
    final ListAllInEditDtls inEditEvd = EvidenceControllerFactory
      .newInstance().listAllInEdit1(caseIDEvidenceTypeKey);
    //BEGIN, WI253775, YF
    // assign in-edit evidence to return struct
    result = assignInEditEvidenceParticipantDtlsList(result, inEditEvd);
    //END, WI253775, YF
    result.caseID = caseKey.caseID;

    final curam.core.struct.CaseKey key = new curam.core.struct.CaseKey();

    key.caseID = caseKey.caseID;
    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList =
      EvidenceControllerFactory.newInstance().listAllactiveEvdInstances(key);

    // assign active evidence to return struct.
    result = assignActiveEvidenceParticipantDtlsList1(result,
      activeEvdInstanceDtlsList);
    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed =
      new EvidenceUpdatesAllowed();
    final boolean evidenceUpdatesAllowedInd =
      evidenceUpdatesAllowed.isUpdatesAllowed(key);

    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      result.caseUpdatesAllowed = false;
      // Set the readOnlyInd to true for each evidence item, to disable the
      // row-level actions
      for (int i =
        0; i < result.evidenceParticipantDtlsList.dtls.items().length; i++) {
        result.evidenceParticipantDtlsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      result.caseUpdatesAllowed = true;
    }
    return result;

  }

  /**
   * Lists all succession evidence changes on an 'In Edit' evidence instance.
   * There is another version of this method - listInEditEvdInstanceChanges.
   * Therefore, if
   * there is any changes made to this method then developer should also visit -
   * listInEditEvdInstanceChanges.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public EvdInstanceChangeDtlsList listInEditEvdInstanceChanges1(
    final SuccessionID key) throws AppException, InformationalException {

    // There is another version of this method - listInEditEvdInstanceChanges.
    // Therefore, if
    // there is any changes made to this method then developer should also visit
    // - listInEditEvdInstanceChanges.
    final EvidenceController evidenceController =
      EvidenceControllerFactory.newInstance();

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList =
      evidenceController.listInEditEvdInstanceChanges1(key);

    // Check if any issues or verifications exist
    evdInstanceChangeDtlsList.verificationOrIssuesExist = false;
    for (int i = 0; i < evdInstanceChangeDtlsList.dtlsList.size(); i++) {

      if (evdInstanceChangeDtlsList.dtlsList
        .item(i).verificationOrIssuesExist) {

        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsList.verificationOrIssuesExist = true;
        break;
      }
    }
    if (Configuration
      .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsList.evdBrokerEnabled = true;
    }
    return evdInstanceChangeDtlsList;
  }

  /**
   * Determines the evidence preview panel page details based on the evidence
   * details.
   *
   * There is another version of this method - determineEvidencePagePanel.
   * Therefore if there is any change
   * made to this method, then developer should also visit -
   * determineEvidencePagePanel.
   *
   * @param evidenceParticipantDtls
   * The specific evidence details.
   *
   * @return ClientURI The preview panel URI page to be displayed.
   */
  private ClientURI determineEvidencePagePanel1(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method - determineEvidencePagePanel.
    // Therefore if there is any change
    // made to this method, then developer should also visit -
    // determineEvidencePagePanel
    // END, CR00452604
    // Determine if there are multiple instance of the evidence record
    final SuccessionID sucessionIDKey = new SuccessionID();

    sucessionIDKey.successionID = evidenceParticipantDtls.successionID;

    // If multiple instances for this evidence record exist
    if (evidenceParticipantDtls.activeEvidence
      && listActiveEvdInstanceChanges1(sucessionIDKey).dtlsList.size() > 1) {
      return evidenceURIHelper.getEvidenceListMultipleInstancesURI(
        evidenceParticipantDtls.successionID);
    } else {
      return evidenceURIHelper
        .getEvidenceDetailsPanelURI(evidenceParticipantDtls);
    }
  }

  // END, CR00452604

  // BEGIN, RTC 183546, ZV
  /**
   * Lists all current active and in-edit evidence records with no end date set
   * of the given evidence type on the case for auto end dating evidence list.
   *
   * @param key Contains case ID, evidence type , participant ID and evidence
   * Id.
   * @return Active and in-edit evidence records with no end date set.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AutoEndDateEvidenceList
    listEvidenceForAutoEndDating(final ListAutoEndDateEvidenceKey key)
      throws AppException, InformationalException {

    final AutoEndDateEvidenceList list = new AutoEndDateEvidenceList();

    // BEGIN, 188669 - CC
    final StringList participantIDList =
      StringUtil.tabText2StringListWithTrim(key.participantIDList);

    final StringList evidenceIDList =
      StringUtil.tabText2StringListWithTrim(key.evidenceIDList);

    // If it is multiple participant creation of evidences.
    final Set<Long> participantIDSet = new HashSet<Long>(
      participantIDList.size() + key.participantID == CuramConst.gkZero ? 0
        : 1 + key.caseParticipantRoleID == CuramConst.gkZero ? 0 : 1);
    final Set<Long> evidenceIDSet = new HashSet<Long>(evidenceIDList.size());

    for (final String participantID : participantIDList) {
      participantIDSet.add(Long.parseLong(participantID));
    }

    for (final String evidenceID : evidenceIDList) {
      evidenceIDSet.add(Long.parseLong(evidenceID));
    }

    // BEGIN, 188277, ZV
    if (key.evidenceID != CuramConst.gkZero) {
      evidenceIDSet.add(key.evidenceID);
    }

    if (key.participantID != CuramConst.gkZero) {
      participantIDSet.add(key.participantID);
    }

    if (key.caseParticipantRoleID != CuramConst.gkZero) {
      final CaseParticipantRole caseParticipantRole =
        CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      caseParticipantRoleKey.caseParticipantRoleID =
        key.caseParticipantRoleID;

      participantIDSet.add(
        caseParticipantRole.read(caseParticipantRoleKey).participantRoleID);

    }
    // END, 188277
    // END, 188669 - CC
    // BEGIN, 187736 - CC
    list.list.addAll(
      autoEndDateEvidenceOperations.listEvidenceForAutoEndDating(key.key,
        participantIDSet, evidenceIDSet));
    // END, 187736 - CC
    list.showListInd = !list.list.isEmpty();
    // BEGIN, 189491, ZV
    // Convert ISO string date to date type
    // BEGIN, 191560, JAY
    if (key.startDateStr != null && key.startDateStr.length() != 0) {
      list.endDate = DateUtil.getISODate(key.startDateStr);
      if (!list.endDate.isZero()) {
        list.endDate = list.endDate.addDays(-1);
      }
    }
    // END, 191560, JAY
    // END, 189491
    return list;
  }

  // END, RTC 183546

  // BEGIN, 187736 - CC
  /**
   * Counts all current active and in-edit evidence records with no end date set
   * of the given evidence type on the case for auto end dating evidence.
   *
   * @param key Contains case ID and evidence type.
   *
   * @return Number of active and in-edit evidence records with no end date set.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CountAutoEndDateEvidence
    countEvidenceForAutoEndDating(final CountAutoEndDateEvidenceKey key)
      throws AppException, InformationalException {

    final CountAutoEndDateEvidence countAutoEndDateEvidence =
      new CountAutoEndDateEvidence();
    countAutoEndDateEvidence.numberOfEvidences =
      autoEndDateEvidenceOperations.countEvidenceForAutoEndDating(key.key);
    return countAutoEndDateEvidence;
  }

  // END, 187736 - CC

  // BEGIN, 191560, JAY
  /**
   * {@inheritDoc}
   */
  @Override
  public PageNameDetails readCreateResolvePage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    final EIEvidenceKey eiKey = new EIEvidenceKey();
    eiKey.evidenceID = key.key.evidenceID;
    eiKey.evidenceType = key.key.evidenceType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails =
      EvidenceControllerFactory.newInstance().readCreateResolvePage(eiKey);

    return pageNameDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public PageNameDetails readCreateStaticEvdPage(
    final curam.core.facade.infrastructure.struct.CaseIDAndEvidenceTypeKey key)
    throws AppException, InformationalException {

    // Return object
    final PageNameDetails pageNameDetails = new PageNameDetails();

    final EvidenceTypeDateAndStatusKey evidenceTypeDateAndStatusKey =
      new EvidenceTypeDateAndStatusKey();
    evidenceTypeDateAndStatusKey.evidenceType = key.evidenceType;

    if (isEvdEligibleForAutoEndDate(key).autoEndDateEligibleInd) {

      pageNameDetails.pageDetails.pageName.pageName = EvidenceMetadataFactory
        .newInstance().readWizardCreatePageNameByTypeAndDate(
          evidenceTypeDateAndStatusKey).pageName;

    } else {

      pageNameDetails.pageDetails.pageName.pageName =
        EvidenceMetadataFactory.newInstance().readCreatePageNameByTypeAndDate(
          evidenceTypeDateAndStatusKey).pageName;

    }

    return pageNameDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AutoEndDateIndDetails isEvdEligibleForAutoEndDate(
    final curam.core.facade.infrastructure.struct.CaseIDAndEvidenceTypeKey key)
    throws AppException, InformationalException {

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();
    evidenceTypeKey.evidenceType = key.evidenceType;

    final CountAutoEndDateEvidenceKey countAutoEndDateEvidenceKey =
      new CountAutoEndDateEvidenceKey();
    countAutoEndDateEvidenceKey.key.caseID = key.caseID;
    countAutoEndDateEvidenceKey.key.evidenceType = key.evidenceType;

    final AutoEndDateIndDetails autoEndDateIndDetails =
      new AutoEndDateIndDetails();

    if (EvidenceMetadataFactory.newInstance()
      .readByEvidenceType(evidenceTypeKey).autoEndDateIndOpt) {
      if (countEvidenceForAutoEndDating(
        countAutoEndDateEvidenceKey).numberOfEvidences > 0) {
        autoEndDateIndDetails.autoEndDateEligibleInd = true;
      }
    }

    return autoEndDateIndDetails;

  }
  // END, 191560, JAY
}
