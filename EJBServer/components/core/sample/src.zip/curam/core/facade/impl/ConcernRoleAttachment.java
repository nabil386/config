/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.core.facade.struct.ConcernRoleAttachmentDetails;
import curam.core.facade.struct.ConcernRoleAttachmentListContainer;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.sl.fact.ConcernRoleAttachmentFactory;
import curam.core.struct.ConcernRoleAttachmentLinkKey;
import curam.core.struct.ConcernRoleAttachmentLinkReadmultiKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class ConcernRoleAttachment extends curam.core.facade.base.ConcernRoleAttachment {

  // ___________________________________________________________________________
  /**
   * Facade method to cancel the concern role attachment
   *
   * @param linkKey The concern role attachment link identifier
   */
  @Override
  public void cancelConcernRoleAttachment(ConcernRoleAttachmentLinkKey linkKey)
    throws AppException, InformationalException {

    // Create concern role attachment manipulation variables
    final curam.core.sl.intf.ConcernRoleAttachment attachmentLinkObj = ConcernRoleAttachmentFactory.newInstance();

    // Call service layer cancel
    attachmentLinkObj.cancelConcernRoleAttachment(linkKey);

  }

  // ___________________________________________________________________________
  /**
   * Creates an attachment with the specified details for the concern role
   *
   * @param attachmentDetails Provides details on the attachment and concern
   * role
   */
  @Override
  public void createConcernRoleAttachment(
    ConcernRoleAttachmentDetails attachmentDetails) throws AppException,
      InformationalException {

    // Attachment manipulation variables
    final curam.core.sl.intf.ConcernRoleAttachment concernRoleAttachmentObj = curam.core.sl.fact.ConcernRoleAttachmentFactory.newInstance();

    concernRoleAttachmentObj.createConcernRoleAttachment(attachmentDetails);

  }

  // ___________________________________________________________________________
  /**
   * Facade method to list concern role attachments given the specified
   * concern role identifier
   *
   * @param listAttachmentsKey contains the concern role identifier
   * @return List of concern role attachments
   */
  @Override
  public ConcernRoleAttachmentListContainer listConcernRoleAttachments(
    ConcernRoleAttachmentLinkReadmultiKey listAttachmentsKey)
    throws AppException, InformationalException {

    // Create concern role objects
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final curam.core.sl.intf.ConcernRoleAttachment concernRoleAttachmentObj = ConcernRoleAttachmentFactory.newInstance();

    // Create and populate structs
    final ConcernRoleAttachmentListContainer attachmentListContainer = new ConcernRoleAttachmentListContainer();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = listAttachmentsKey.concernRoleID;

    // Get list of attachments
    attachmentListContainer.list = concernRoleAttachmentObj.searchConcernRoleAttachment(
      listAttachmentsKey);

    // Assign alternateID and name
    final ConcernRoleNameAndAlternateID nameAndAltID = concernRoleObj.readConcernRoleNameAndAlternateID(
      concernRoleKey);

    attachmentListContainer.personName = nameAndAltID.concernRoleName;
    attachmentListContainer.alternateID = nameAndAltID.primaryAlternateID;

    return attachmentListContainer;
  }

  // ___________________________________________________________________________
  /**
   * Facade method to modify concern role attachments given the specified
   * concern role identifier
   *
   * @param attachmentDetails contains the concern role attachment details
   */
  @Override
  public void modifyConcernRoleAttachment(
    ConcernRoleAttachmentDetails attachmentDetails) throws AppException,
      InformationalException {

    // Call the service layer modify

    final curam.core.sl.intf.ConcernRoleAttachment attachmentObj = ConcernRoleAttachmentFactory.newInstance();

    attachmentObj.modifyConcernRoleAttachment(attachmentDetails);

  }

  // ___________________________________________________________________________
  /**
   * Facade method to read a concern role attachment given the specified
   * concern role attachment link identifier
   *
   * @param linkKey contains the concern role attachment link identifier.
   */
  @Override
  public ConcernRoleAttachmentDetails readConcernRoleAttachment(
    ConcernRoleAttachmentLinkKey linkKey) throws AppException,
      InformationalException {

    // Call the service layer read
    final curam.core.sl.intf.ConcernRoleAttachment attachmentObj = ConcernRoleAttachmentFactory.newInstance();

    return attachmentObj.readConcernRoleAttachment(linkKey);
  }

}
