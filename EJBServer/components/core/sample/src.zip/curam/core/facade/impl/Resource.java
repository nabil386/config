/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.ASSESSMENTNAME;
import curam.codetable.EVIDENCENAMECODE;
import curam.codetable.SERVICETYPE;
import curam.core.facade.struct.*;
import curam.core.fact.AdminAssessmentConfigurationFactory;
import curam.core.intf.AdminAssessmentConfiguration;
import curam.core.sl.entity.struct.InvestigationConfigKey;
import curam.core.sl.entity.struct.InvestigationIDTypeDtls;
import curam.core.sl.entity.struct.ScreeningAssessmentWithVersionNoDetailsList;
import curam.core.sl.fact.DeductionFactory;
import curam.core.sl.fact.ICAssessmentConfigurationFactory;
import curam.core.sl.fact.InvCAssessmentConfigFactory;
import curam.core.sl.fact.ProductAssessmentConfigurationFactory;
import curam.core.sl.infrastructure.fact.TemporalEvidenceApprovalCheckFactory;
import curam.core.sl.infrastructure.struct.CancelTemporalEvidenceApprovalCheck;
import curam.core.sl.intf.Deduction;
import curam.core.sl.intf.ICAssessmentConfiguration;
import curam.core.sl.intf.InvCAssessmentConfig;
import curam.core.sl.intf.ProductAssessmentConfiguration;
import curam.core.sl.struct.CancelEvidenceScreenDetails;
import curam.core.sl.struct.CreateEvidenceScreenDetails;
import curam.core.sl.struct.DeductionName;
import curam.core.sl.struct.ListEvidenceScreenDetails;
import curam.core.sl.struct.ListEvidenceScreenKey;
import curam.core.sl.struct.ReadDeductionDetails;
import curam.core.sl.struct.ReadEvidenceScreenDetails;
import curam.core.sl.struct.ReadEvidenceScreenKey;
import curam.core.sl.struct.ScreeningAssessmentConfigDetailsList;
import curam.core.struct.AdminIntegratedCaseKey;
import curam.core.struct.AssessmentConfigurationDetails;
import curam.core.struct.AssessmentConfigurationDtls;
import curam.core.struct.AssessmentRulesLinkDetails;
import curam.core.struct.CaseKey;
import curam.core.struct.ComponentNomineeDtlsList;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.IntegratedCaseTypeStruct;
import curam.core.struct.ListAllDeliveryMethodsIn;
import curam.core.struct.RemoveCategoryFromServiceKey;
import curam.core.struct.ServiceDetailsKey;
import curam.core.struct.ServiceDtls;
import curam.core.struct.ServiceIDKey;
import curam.core.struct.ServiceKey;
import curam.core.struct.ViewAssessmentConfigurationDetailsKey;
import curam.core.struct.ViewAssessmentRuleLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;


/**
 * This process class provides the functionality for the Resource
 * presentation layer.
 */
public abstract class Resource extends curam.core.facade.base.Resource {

  /**
   * Cancels an assessment.
   *
   * @param key The assessment ID being canceled.
   */
  @Override
  public void cancelAssessment(CancelAssessmentKey key) throws AppException,
      InformationalException {

    // The admin assessment object and details.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();
    final AssessmentConfigurationDetails assessmentConfigurationDetails = new AssessmentConfigurationDetails();

    // Set the assessment ID and version no.
    assessmentConfigurationDetails.assessmentConfigurationID = key.cancelAssessment.assessmentConfigurationID;
    assessmentConfigurationDetails.versionNo = key.cancelAssessment.versionNo;

    // Cancel the assessment.
    adminAssessmentConfigurationObj.cancelAssessmentConfiguration(
      assessmentConfigurationDetails);
  }

  // ___________________________________________________________________________
  /**
   * Creates an assessment.
   *
   * @param key The details created for the assessment.
   */
  @Override
  public void createAssessment(InsertAssessmentKey key) throws AppException,
      InformationalException {

    // The admin assessment object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Create the assessment.
    adminAssessmentConfigurationObj.addAssessmentConfiguration(
      key.assessmentConfigurationDetails);
  }

  /**
   * Reads a list of assessments.
   *
   * @return The list of assessments.
   */
  @Override
  public ListAssessmentConfigurationDetails listAssessment()
    throws AppException, InformationalException {

    // The returned details.
    final ListAssessmentConfigurationDetails listAssessmentConfigurationDetails = new ListAssessmentConfigurationDetails();

    // The admin assessment object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Read the list of assessments.
    listAssessmentConfigurationDetails.assessmentConfigurationDetailsList = adminAssessmentConfigurationObj.viewAssessmentConfigurationList();

    // Retrieve the assessmentName for each entry in the list
    for (int i = 0; i
      < listAssessmentConfigurationDetails.assessmentConfigurationDetailsList.dtls.size(); i++) {
      // BEGIN, CR00163098, JC
      listAssessmentConfigurationDetails.assessmentConfigurationDetailsList.dtls.item(i).assessmentName = CodeTable.getOneItem(
        ASSESSMENTNAME.TABLENAME,
        listAssessmentConfigurationDetails.assessmentConfigurationDetailsList.dtls.item(i).name,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }

    // Return the list of assessments.
    return listAssessmentConfigurationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an assessment.
   *
   * @param details The assessment details being modified..
   */
  @Override
  public void modifyAssessment(ModifyAssessmentConfigurationDetails details)
    throws AppException, InformationalException {

    // The admin assessment object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Modify the assessment details.
    adminAssessmentConfigurationObj.modifyAssessmentConfiguration(
      details.assessmentConfigurationDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads an assessment details.
   *
   * @param key The assessment ID being read.
   *
   * @return The assessment details returned from the database.
   */
  @Override
  public ReadAssessmentConfigurationDetails readAssessment(
    ReadAssessmentConfigurationKey key) throws AppException,
      InformationalException {

    final ReadAssessmentConfigurationDetails readAssessmentConfigurationDetails = new ReadAssessmentConfigurationDetails();

    // The admin assessment object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Read the assessment details.
    readAssessmentConfigurationDetails.assessmentConfigurationDetails = adminAssessmentConfigurationObj.getAssessmentConfigurationDetails(
      key.viewAssessmentConfigurationDetailsKey);

    // Get the context description.
    final AssessmentContextDescriptionKey assessmentDescriptionKey = new AssessmentContextDescriptionKey();

    // Set the assessment configuration ID.
    assessmentDescriptionKey.assessmentConfigurationID = key.viewAssessmentConfigurationDetailsKey.assessmentConfigurationID;

    // Set the description.
    readAssessmentConfigurationDetails.assessmentContextDescription = getAssessmentContextDescription(
      assessmentDescriptionKey);

    // Return the details.
    return readAssessmentConfigurationDetails;
  }

  // BEGIN, CR00264159, JAF
  // ___________________________________________________________________________
  /**
   * Reads an assessment name.
   *
   * @param key The assessment ID being read.
   *
   * @return The assessment name returned from the database.
   */
  @Override
  public ReadAssessmentConfigurationName readAssessmentName(
    ReadAssessmentConfigurationKey key) throws AppException,
      InformationalException {

    final ReadAssessmentConfigurationName readAssessmentConfigurationName = new ReadAssessmentConfigurationName();

    final AdminAssessmentConfiguration adminAssessmentConfiguration = AdminAssessmentConfigurationFactory.newInstance();

    final ViewAssessmentConfigurationDetailsKey viewAssessmentConfigurationDetailsKey = new ViewAssessmentConfigurationDetailsKey();

    viewAssessmentConfigurationDetailsKey.assessmentConfigurationID = key.viewAssessmentConfigurationDetailsKey.assessmentConfigurationID;

    readAssessmentConfigurationName.name.assessmentName = adminAssessmentConfiguration.getAssessmentConfigurationName(viewAssessmentConfigurationDetailsKey).assessmentName;

    return readAssessmentConfigurationName;
  }

  // ___________________________________________________________________________
  // END, CR00264159, JAF

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to cancel an Evidence Form.
   *
   * @param key The id of the Evidence Form to be canceled.
   */
  @Override
  public void cancelEvidenceForm(
    curam.core.facade.struct.CancelEvidenceFormKey key) throws AppException,
      InformationalException {

    // Instantiate the AdminEvidenceForm Object
    final curam.core.intf.AdminEvidenceForm adminEvidenceObj = curam.core.fact.AdminEvidenceFormFactory.newInstance();

    // Use AdminEvidenceForm to perform the cancel operation
    adminEvidenceObj.cancelEvidenceForm(key.cancelEvidenceFormKey);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to create an Evidence Form.
   *
   * @param details Data concerning the Evidence Form to be created.
   */
  @Override
  public void createEvidenceForm(CreateEvidenceFormDetails details)
    throws AppException, InformationalException {

    // Instantiate the AdminEvidenceForm Object
    final curam.core.intf.AdminEvidenceForm adminEvidenceObj = curam.core.fact.AdminEvidenceFormFactory.newInstance();

    // Use AdminEvidenceForm to perform the create operation
    adminEvidenceObj.createEvidenceForm(details.evidenceFormDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to list Evidence Forms.
   *
   * @return A list of details of all evidence forms.
   */
  @Override
  public ListEvidenceFormDetails listEvidenceForm() throws AppException,
      InformationalException {

    // Instantiate the AdminEvidenceForm object
    final curam.core.intf.AdminEvidenceForm adminEvidenceObj = curam.core.fact.AdminEvidenceFormFactory.newInstance();

    // Create the object to be returned as a result of this query
    final ListEvidenceFormDetails listEvidenceFormDetails = new ListEvidenceFormDetails();

    // Use AdminEvidenceForm to perform the read and collect the results
    listEvidenceFormDetails.evidenceFormDetailsList = adminEvidenceObj.listAllEvidenceForms();

    // Retrieve the typeCode description for each entry in the list
    for (int i = 0; i
      < listEvidenceFormDetails.evidenceFormDetailsList.dtls.size(); i++) {
      // BEGIN, CR00163098, JC
      listEvidenceFormDetails.evidenceFormDetailsList.dtls.item(i).evidenceNameCodeDescription = CodeTable.getOneItem(
        EVIDENCENAMECODE.TABLENAME,
        listEvidenceFormDetails.evidenceFormDetailsList.dtls.item(i).evidenceNameCode,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }

    return listEvidenceFormDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to modify an Evidence Form.
   *
   * @param details The data with which to update an Evidence Form.
   */
  @Override
  public void modifyEvidenceForm(ModifyEvidenceFormDetails details)
    throws AppException, InformationalException {

    // Instantiate the AdminEvidenceForm Object
    final curam.core.intf.AdminEvidenceForm adminEvidenceObj = curam.core.fact.AdminEvidenceFormFactory.newInstance();

    // Use AdminEvidenceForm to perform the modify operation
    adminEvidenceObj.modifyEvidenceForm(details.evidenceFormDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read Evidence Form details.
   *
   * @param key The ID of the Evidence Form to be read.
   *
   * @return Details of the Evidence Form read.
   */
  @Override
  public ReadEvidenceFormDetails readEvidenceForm(ReadEvidenceFormKey key)
    throws AppException, InformationalException {

    // Instantiate the AdminEvidenceForm Object
    final curam.core.intf.AdminEvidenceForm adminEvidenceObj = curam.core.fact.AdminEvidenceFormFactory.newInstance();

    // Create the object to be returned as a result of this query
    final ReadEvidenceFormDetails readEvidenceFormDetails = new ReadEvidenceFormDetails();

    // Use AdminEvidenceForm to perform the read and collect the results
    readEvidenceFormDetails.evidenceFormDetails = adminEvidenceObj.readEvidenceForm(
      key.readByEvidenceFormIDKey);

    return readEvidenceFormDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to create a Delivery Method.
   *
   * @param details The details of the Delivery Method to be created.
   */
  @Override
  public void createDeliveryMethod(CreateDeliveryMethodDetails details)
    throws AppException, InformationalException {

    // AdminDeliveryMethod object.
    final curam.core.intf.AdminDeliveryMethod adminDeliveryMethodObj = curam.core.fact.AdminDeliveryMethodFactory.newInstance();

    // Create Delivery Method
    adminDeliveryMethodObj.createDeliveryMethod(details.deliveryMethodDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to list Delivery Methods.
   *
   * @return The list of Delivery Methods.
   */
  @Override
  public ListDeliveryMethodDetails listDeliveryMethod() throws AppException,
      InformationalException {

    // AdminDeliveryMethod object.
    final curam.core.intf.AdminDeliveryMethod AdminDeliveryMethodObj = curam.core.fact.AdminDeliveryMethodFactory.newInstance();

    // Details to be returned
    final ListDeliveryMethodDetails listDeliveryMethodDetails = new ListDeliveryMethodDetails();

    // Struct to hold details
    final ListAllDeliveryMethodsIn listAllDeliveryMethodsIn = new ListAllDeliveryMethodsIn();

    // Set Initial Details
    listAllDeliveryMethodsIn.productID = 0;
    listAllDeliveryMethodsIn.benefitMethodsInd = false;
    listAllDeliveryMethodsIn.allMethodsInd = true;

    // Read list of phone numbers
    listDeliveryMethodDetails.listAllDeliveryMethodsResult = AdminDeliveryMethodObj.listAllDeliveryMethods(
      listAllDeliveryMethodsIn);

    // Return Delivery Method Details list
    return listDeliveryMethodDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to modify a Delivery Method.
   *
   * @param details The details of the Delivery Method to be modified.
   */
  @Override
  public void modifyDeliveryMethod(ModifyDeliveryMethodDetails details)
    throws AppException, InformationalException {

    // AdminDeliveryMethod object.
    final curam.core.intf.AdminDeliveryMethod adminDeliveryMethodObj = curam.core.fact.AdminDeliveryMethodFactory.newInstance();

    // Modify the Delivery Method
    adminDeliveryMethodObj.modifyDeliveryMethod(details.deliveryMethodDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read a Delivery Method.
   *
   * @param key The key of the Delivery Method to be read.
   *
   * @return The details of the Delivery Method Read.
   */
  @Override
  public ReadDeliveryMethodDetails readDeliveryMethod(
    ReadDeliveryMethodKey key) throws AppException, InformationalException {

    // AdminDeliveryMethod object.
    final curam.core.intf.AdminDeliveryMethod adminDeliveryMethodObj = curam.core.fact.AdminDeliveryMethodFactory.newInstance();

    // Details to be returned
    final ReadDeliveryMethodDetails readDeliveryMethodDetails = new ReadDeliveryMethodDetails();

    // Read the delivery Method
    readDeliveryMethodDetails.deliveryMethodDetails = adminDeliveryMethodObj.readDeliveryMethod(
      key.adminDeliveryMethodIDKey);

    // Return Delivery Method Details
    return readDeliveryMethodDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Resource Context Description.
   *
   * @param key The Delivery method Context Description Key.
   *
   * @return The Context of the Delivery Method.
   */
  @Override
  protected DeliveryMethodContextDescription getDeliveryMethodContextDescription(DeliveryMethodContextKey key)
    throws AppException, InformationalException {

    // DeliveryMethod object
    final curam.core.intf.DeliveryMethod deliveryMethodObj = curam.core.fact.DeliveryMethodFactory.newInstance();

    // DeliveryMethodDtls object
    DeliveryMethodDtls deliveryMethodDtls;

    // DeliveryMethodKey object
    final DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    // Resource Context Description object
    final DeliveryMethodContextDescription deliveryMethodContextDescription = new DeliveryMethodContextDescription();

    // set up the key for the read
    deliveryMethodKey.deliveryMethodID = key.deliveryMethodID;

    // read the product details to get the name code
    deliveryMethodDtls = deliveryMethodObj.read(deliveryMethodKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_DELIVERY_METHOD_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.METHODOFDELIVERY.TABLENAME,
      deliveryMethodDtls.name));

    // Populate the context description field with the localizable text
    deliveryMethodContextDescription.description = contextDescription.toClientFormattedText();

    // populate the return parameter
    return deliveryMethodContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Reads a selected Resource Service
   *
   * @param key The Read Service Key which contains the ID of the service.
   *
   * @return The details of the particular service record to be read.
   */
  @Override
  public ReadServiceDetails readService(ReadServiceKey key)
    throws AppException, InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Create the return object
    final ReadServiceDetails readServiceDetails = new ReadServiceDetails();

    // service context key
    final ServiceContextKey serviceContextKey = new ServiceContextKey();
    ResourceContextDescription resourceContextDescription;

    // Perform the read and return the results
    readServiceDetails.readServiceResult = maintainServiceDetailObj.readService(
      key.serviceDetailsKey);

    // get context details
    serviceContextKey.serviceID = key.serviceDetailsKey.serviceID;
    resourceContextDescription = getResourceContextDescription(
      serviceContextKey);
    readServiceDetails.serviceContextDescription.description = resourceContextDescription.description;

    return readServiceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modify the specified Resource Service
   *
   * @param details The details of the Service which is to be modified.
   */
  @Override
  public void modifyService(ModifyServiceDetails details)
    throws AppException, InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // The serviceID in the mandatory ServiceDetailsKey object has not yet been
    // set, so we set it here explicitly.
    final ServiceDetailsKey serviceDetailsKey = new ServiceDetailsKey();

    serviceDetailsKey.serviceID = details.serviceDetails.serviceID;

    // Use MaintainServiceDetail to perform the modify operation
    maintainServiceDetailObj.modifyService(serviceDetailsKey,
      details.serviceDetails);
  }

  // ___________________________________________________________________________
  /**
   * List the services for the system
   *
   * @return A list of all the services
   */
  @Override
  public ListServiceDetails listService() throws AppException,
      InformationalException {

    // Service maintenance business process object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Details to be returned
    final ListServiceDetails listServiceDetails = new ListServiceDetails();

    // Retrieve the list of services
    listServiceDetails.serviceRMDtlsList = maintainServiceDetailObj.listAllServices();

    // Retrieve the typeCode description for each entry in the list
    for (int i = 0; i < listServiceDetails.serviceRMDtlsList.dtls.size(); i++) {
      // BEGIN, CR00163098, JC
      listServiceDetails.serviceRMDtlsList.dtls.item(i).typeCodeDescription = CodeTable.getOneItem(
        SERVICETYPE.TABLENAME,
        listServiceDetails.serviceRMDtlsList.dtls.item(i).typeCode,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }

    // Return details
    return listServiceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancels the specified Resource Service
   *
   * @param key The Cancel Service Key which contains the ID of the service.
   */
  @Override
  public void cancelService(CancelServiceKey key) throws AppException,
      InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Use MaintainServiceDetail to perform the cancel operation
    maintainServiceDetailObj.cancelService(key.cancelServiceDetailsKey);
  }

  // ___________________________________________________________________________
  /**
   * Create a new Resource Service
   *
   * @param details The details of the Service to be created.
   */
  @Override
  public void createService(CreateServiceDetails details)
    throws AppException, InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Use MaintainServiceDetail to perform the create operation
    maintainServiceDetailObj.createService(details.serviceDetails,
      details.categoryListTab);
  }

  // ___________________________________________________________________________
  /**
   * Cancels an assessment rule assignment.
   *
   * @param key The assessment rules link ID for the record being canceled.
   */
  @Override
  public void cancelAssessmentRulesLink(CancelAssessmentRulesLinkKey key)
    throws AppException, InformationalException {

    // The admin assessment configuration object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationbj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Cancel the assessment rule details.
    adminAssessmentConfigurationbj.cancelAssessmentRulesLink(
      key.assessmentRulesLinkDetails);
  }

  // ___________________________________________________________________________
  /**
   * Assigns a rule set to an assessment.
   *
   * @param details The rule set details.
   */
  @Override
  public void createAssessmentRulesLink(
    CreateAssessmentRulesLinkDetails details) throws AppException,
      InformationalException {

    // The admin assessment configuration object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationbj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Add the assessment rule details.
    adminAssessmentConfigurationbj.addAssessmentRulesLink(
      details.assessmentRulesLinkDetails);
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of rule sets for an assessment.
   *
   * @param key The assignment configuration id.
   *
   * @return The assignment rule set details returned from the database
   */
  @Override
  public ListAssessmentRulesLinkDetails listAssessmentRulesLink(
    ListAssessmentRulesLinkKey key) throws AppException,
      InformationalException {

    // The returned details.
    final ListAssessmentRulesLinkDetails listAssessmentRulesLinkDetails = new ListAssessmentRulesLinkDetails();

    // The admin assessment configuration object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationbj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Read the assessment rules list.
    listAssessmentRulesLinkDetails.assessmentRulesLinkDetailsList = adminAssessmentConfigurationbj.getAssessmentRulesLinkList(
      key.viewAssessmentConfigurationDetailsKey);

    // Get the context description.
    final AssessmentContextDescriptionKey assessmentDescriptionKey = new AssessmentContextDescriptionKey();

    // Set the assessment configuration ID.
    assessmentDescriptionKey.assessmentConfigurationID = key.viewAssessmentConfigurationDetailsKey.assessmentConfigurationID;

    // Set the description.
    listAssessmentRulesLinkDetails.assessmentContextDescription = getAssessmentContextDescription(
      assessmentDescriptionKey);

    // Return the list returned from the database.
    return listAssessmentRulesLinkDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modify the assigned rule set for an assessment.
   *
   * @param details The modified assessment rule set details.
   */
  @Override
  public void modifyAssessmentRulesLink(
    ModifyAssessmentRulesLinkDetails details) throws AppException,
      InformationalException {

    // The admin assessment configuration object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationbj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Modify the assessment rule details.
    adminAssessmentConfigurationbj.modifyAssessmentRulesLink(
      details.assessmentRulesLinkDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modify the assigned rule set for an assessment.
   *
   * @param key The assessment rules link ID
   *
   * @return The assessment rule set details returned from the database
   */
  @Override
  public ReadAssessmentRulesLinkDetails readAssessmentRulesLink(
    ReadAssessmentRulesLinkKey key) throws AppException,
      InformationalException {

    // The returned details.
    final ReadAssessmentRulesLinkDetails readAssessmentRulesLinkDetails = new ReadAssessmentRulesLinkDetails();

    // The admin assessment configuration object.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationbj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Read the assessment rule details.
    readAssessmentRulesLinkDetails.assessmentRulesLinkDetails = adminAssessmentConfigurationbj.readAssessmentRulesLink(
      key.viewAssessmentRuleLinkKey);

    // Get the context description for the rule set assignment.
    final AssessmentRulesLinkContextDescriptionKey contextDescriptionKey = new AssessmentRulesLinkContextDescriptionKey();

    // Set the context description key.
    contextDescriptionKey.assessmentRulesLinkID = key.viewAssessmentRuleLinkKey.assessmentRulesLinkID;

    // Read the rule set assignment context description.
    readAssessmentRulesLinkDetails.assessmentRulesLinkContextDescription = getAssessmentRulesLinkContextDescription(
      contextDescriptionKey);

    // The details returned from the database.
    return readAssessmentRulesLinkDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Resource Context Description.
   *
   * @param key The Resource Context Description Key.
   *
   * @return The context description of the resource.
   */
  @Override
  protected ResourceContextDescription getResourceContextDescription(
    ServiceContextKey key) throws AppException, InformationalException {

    // Service entity, key and details
    final curam.core.intf.Service serviceObj = curam.core.fact.ServiceFactory.newInstance();
    final ServiceKey serviceKey = new ServiceKey();
    ServiceDtls serviceDtls;

    // Resource Context Description object
    final ResourceContextDescription resourceContextDescription = new ResourceContextDescription();

    // set up the key for the read
    serviceKey.serviceID = key.serviceID;

    // read the service details to get the name code

    serviceDtls = serviceObj.read(serviceKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_RESOURCE_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.SERVICETYPE.TABLENAME,
      serviceDtls.typeCode));

    // Populate the context description field with the localizable text
    resourceContextDescription.description = contextDescription.toClientFormattedText();

    // populate the return parameter
    return resourceContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to obtain a list of all templates required for
   * Evidence Forms.
   *
   * @return The details of all templates found.
   */
  @Override
  public ListEvidenceFormTemplatesDetails listEvidenceFormTemplates()
    throws AppException, InformationalException {

    // Create the BPO
    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateObj = curam.core.fact.MaintainXSLTemplateFactory.newInstance();

    // Create the return object
    final ListEvidenceFormTemplatesDetails listEvidenceFormTemplatesDetails = new ListEvidenceFormTemplatesDetails();

    // Assign the results of the search to the return object.
    listEvidenceFormTemplatesDetails.getEvidenceFormTemplatesResult = maintainXSLTemplateObj.getEvidenceFormTemplates();

    return listEvidenceFormTemplatesDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Assessment Context Description.
   *
   * @param key The Assessment Context Description Key.
   *
   * @return The context description of the assessment.
   */
  @Override
  protected AssessmentContextDescriptionDetails getAssessmentContextDescription(AssessmentContextDescriptionKey key)
    throws AppException, InformationalException {

    // The returned details.
    final AssessmentContextDescriptionDetails assessmentContextDescriptionDetails = new AssessmentContextDescriptionDetails();

    // Maintain assessment object to return context details.
    final curam.core.intf.AssessmentConfiguration assessmentConfigurationObj = curam.core.fact.AssessmentConfigurationFactory.newInstance();
    final curam.core.struct.AssessmentConfigurationKey assessmentConfigurationKey = new curam.core.struct.AssessmentConfigurationKey();
    AssessmentConfigurationDtls assessmentConfigurationDtls;

    // Assessment key.
    assessmentConfigurationKey.assessmentConfigurationID = key.assessmentConfigurationID;

    // Read the assessment details.
    assessmentConfigurationDtls = assessmentConfigurationObj.read(
      assessmentConfigurationKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_ASSESSMENT_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.ASSESSMENTNAME.TABLENAME,
      assessmentConfigurationDtls.name));

    // Populate the context description field with the localizable text
    assessmentContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return assessmentContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Assessment Rule Context
   * Description.
   *
   * @param key The Assessment Rule Context Description Key.
   *
   * @return The context description of the assessment rule.
   */
  @Override
  protected AssessmentRulesLinkContextDescriptionDetails getAssessmentRulesLinkContextDescription(
    AssessmentRulesLinkContextDescriptionKey key) throws AppException,
      InformationalException {

    // The rule set description which is returned.
    final AssessmentRulesLinkContextDescriptionDetails assessmentRulesLinkContextDescriptionDetails = new AssessmentRulesLinkContextDescriptionDetails();

    // The admin assessment object and key.
    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigurationObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();
    final ViewAssessmentRuleLinkKey viewAssessmentRuleLinkKey = new ViewAssessmentRuleLinkKey();

    // The details returned from rules information link read.
    AssessmentRulesLinkDetails assessmentRulesLinkDetails;

    // Set the assessment rule link ID.
    viewAssessmentRuleLinkKey.assessmentRulesLinkID = key.assessmentRulesLinkID;

    // Read the assessment link details.
    assessmentRulesLinkDetails = adminAssessmentConfigurationObj.readAssessmentRulesLink(
      viewAssessmentRuleLinkKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_ASSESSMENT_RULES_LINK_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.ASSESSMENTNAME.TABLENAME,
      assessmentRulesLinkDetails.assessmentName));

    // Add the Rules Name to the localizable string
    contextDescription.arg(assessmentRulesLinkDetails.rulesName);

    // Populate the context description field with the localizable text
    assessmentRulesLinkContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return assessmentRulesLinkContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Adds one or more categories to the specified Resource Service.
   *
   * @param key Contains the ID of the service and the categories to be added.
   */
  @Override
  public void addCategoriesToService(AddCategoriesToServiceKey key)
    throws AppException, InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Use the BPO to add the list of categories to the service.
    maintainServiceDetailObj.addCategoriesToService(key.serviceIDKey,
      key.categoryTabList);
  }

  // ___________________________________________________________________________
  /**
   * Produces two lists, the first is a list of categories that have been added
   * to the Service and the other a list of all categories that have not been
   * added to the Service.
   *
   * @param key Contains the ID of the service.
   *
   * @return Service Category lists.
   */
  @Override
  public ListServiceCategoryDetails listServiceCategory(ServiceIDKey key)
    throws AppException, InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Create the return object.
    final ListServiceCategoryDetails listServiceCategoryDetails = new ListServiceCategoryDetails();

    // Assign the value returned from the BPO method which searches for all
    // categories.
    listServiceCategoryDetails.serviceCategoryLists = maintainServiceDetailObj.listServiceCategory(
      key);

    return listServiceCategoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Removes a category from the specified Resource Service.
   *
   * @param key Contains the ID of the service and the ID of the category to be
   * removed.
   */
  @Override
  public void removeCategoryFromService(RemoveCategoryFromServiceKey key)
    throws AppException, InformationalException {

    // Instantiate the MaintainServiceDetail Object
    final curam.core.intf.MaintainServiceDetail maintainServiceDetailObj = curam.core.fact.MaintainServiceDetailFactory.newInstance();

    // Use the BPO to remove the specified category from the service.
    maintainServiceDetailObj.removeCategoryFromService(key);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a facade independent page identifier for the assessment
   * configuration, which identifies the HomePage for this assessment
   * configuration.
   *
   * @param key The assessment configuration ID
   *
   * @return Page identifier for the assessment configuration
   */
  @Override
  public HomePageIdentifier getAssessmentConfigurationHomePageIdentifier(
    curam.core.facade.struct.AssessmentConfigurationKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.AssessmentConfiguration assessmentConfiguration = curam.core.sl.fact.AssessmentConfigurationFactory.newInstance();

    // Create the return object.
    final HomePageIdentifier homePageIdentifier = new HomePageIdentifier();

    final curam.core.sl.struct.AssessmentConfigurationHomePageIdentifierKey assessmentConfigurationHomePageIdentifierKey = new curam.core.sl.struct.AssessmentConfigurationHomePageIdentifierKey();

    assessmentConfigurationHomePageIdentifierKey.assessmentConfigurationID = key.dtls.dtls.assessmentConfigurationID;

    // Assign the value returned from the BPO method
    homePageIdentifier.dtls = assessmentConfiguration.getAssessmentConfigurationHomePageIdentifier(
      assessmentConfigurationHomePageIdentifierKey);

    return homePageIdentifier;
  }

  // ___________________________________________________________________________
  /**
   * Creates a Screening Configuration as specified.
   *
   * @param details The Screening Configuration details to be created.
   *
   * @return Screening configuration created
   */
  @Override
  public curam.core.facade.struct.ScreeningConfigurationKey createScreeningConfiguration(
    curam.core.facade.struct.ScreeningConfigurationDetails details)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final curam.core.facade.struct.ScreeningConfigurationKey screeningConfigurationKey = new curam.core.facade.struct.ScreeningConfigurationKey();

    // Assign the value returned from the BPO method
    screeningConfigurationKey.dtls = screeningConfigurationObj.createScreeningConfiguration(
      details.dtls);

    return screeningConfigurationKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing ScreeningConfiguration as specified.
   *
   * @param details The permitted changes that can be made.
   * @deprecated since Curam 6.0, replaced with
   * {@link #modifyScreeningConfiguration1(ScreeningConfigurationModifyDtls)}.
   *
   * New method contains additional attribute to indicate if an ownership
   * strategy is configured for a case type.
   *
   * See release note: CEF-635/CR00187598.
   */
  @Override
  @Deprecated
  public void modifyScreeningConfiguration(
    curam.core.facade.struct.ScreeningConfigurationModifyDetails details)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    screeningConfigurationObj.modifyScreeningConfiguration(details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Gets the Screening Configuration details requested.
   *
   * @param key The Screening Configuration ID
   *
   * @return Screening configuration details
   */
  @Override
  public curam.core.facade.struct.ScreeningConfigurationDetails viewScreeningConfiguration(
    curam.core.facade.struct.ScreeningConfigurationKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final curam.core.facade.struct.ScreeningConfigurationDetails screeningConfigurationDetails = new curam.core.facade.struct.ScreeningConfigurationDetails();

    // Assign the value returned from the BPO method
    screeningConfigurationDetails.dtls = screeningConfigurationObj.viewScreeningConfiguration(
      key.dtls);

    final ScreeningConfigContextDescriptionKey screeningConfigContextDescriptionKey = new ScreeningConfigContextDescriptionKey();

    screeningConfigContextDescriptionKey.screeningConfigurationID = key.dtls.dtls.screeningConfigID;
    screeningConfigContextDescriptionKey.optionalName = screeningConfigurationDetails.dtls.dtls.dtls.name;

    screeningConfigurationDetails.contextDescription = getScreeningConfigContextDescription(
      screeningConfigContextDescriptionKey);
    // BEGIN, CR00235514, PB
    if (!screeningConfigurationDetails.dtls.dtls.dtls.adminTranslationRequiredInd) {
      screeningConfigurationDetails.dtls.dtls.dtls.adminTranslationRequiredInd = false;
    }
    // END, CR00235514
    return screeningConfigurationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists ALL the Screening Configuration independent of status or dates.
   *
   * @return List of all screening configurations
   */
  @Override
  public ScreeningConfigurationList listAllScreeningConfiguration()
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final ScreeningConfigurationList screeningConfigurationList = new ScreeningConfigurationList();

    // Assign the value returned from the BPO method
    screeningConfigurationList.dtls = screeningConfigurationObj.listAllScreeningConfiguration();

    return screeningConfigurationList;
  }

  // ___________________________________________________________________________
  /**
   * Attempts to add the specified Assessment Configuration type to this
   * Screening Configuration type for the specified dates.
   *
   * @param details The Assessment, Screening and date range
   *
   * @return Details of assessment added to screening configuration
   */
  @Override
  public curam.core.facade.struct.ScreeningAssessmentConfigKey addAssessmentToScreeningConfiguration(
    curam.core.facade.struct.ScreeningAssessmentAddDetails details)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final curam.core.facade.struct.ScreeningAssessmentConfigKey screeningAssessmentConfigKey = new curam.core.facade.struct.ScreeningAssessmentConfigKey();

    // Assign the value returned from the BPO method
    screeningAssessmentConfigKey.dtls = screeningConfigurationObj.addAssessmentToScreeningConfiguration(
      details.dtls);

    return screeningAssessmentConfigKey;
  }

  // ___________________________________________________________________________
  /**
   * Attempts to modify the specific relationship between the specified
   * Screening Configuration and Assessment Configuration.
   *
   * @param details The Screening Assessment Configuration changes
   */
  @Override
  public void modifyScreeningAssessment(
    curam.core.facade.struct.ScreeningAssessmentModifyDetails details)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    screeningConfigurationObj.modifyScreeningAssessmentConfig(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a specific relationship details between a Screening
   * Configuration and an Assessment Configuration.
   *
   * @param key The ScreeningAssessmentConfig ID
   *
   * @return Screening assessment configuration details
   */
  @Override
  public curam.core.facade.struct.ScreeningAssessmentConfigDetails viewScreeningAssessment(
    curam.core.facade.struct.ScreeningAssessmentConfigKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final curam.core.facade.struct.ScreeningAssessmentConfigDetails screeningAssessmentConfigDetails = new curam.core.facade.struct.ScreeningAssessmentConfigDetails();

    // Assign the value returned from the BPO method
    screeningAssessmentConfigDetails.dtls = screeningConfigurationObj.viewScreeningAssessmentConfig(
      key.dtls);

    final ScreeningAssessmentConfigContextDescriptionKey screeningAssessmentConfigContextDescriptionKey = new ScreeningAssessmentConfigContextDescriptionKey();

    screeningAssessmentConfigContextDescriptionKey.scrAssConfigID = key.dtls.dtls.scrAssConfigID;

    screeningAssessmentConfigDetails.contextDescription = getScreeningAssessmentConfigContextDescription(
      screeningAssessmentConfigContextDescriptionKey);

    return screeningAssessmentConfigDetails;
  }

  // BEGIN, CR00243704, KX
  // ___________________________________________________________________________
  /**
   * @param key The Screening Configuration ID
   *
   * @return List of Assessment Configuration relationships
   * @deprecated Since Curam 6.0, replaced with
   * {@link #listScreeningAssessmentWithVersionNo()}. As
   * part of the new API versionNo fields must be returned in lists which allow
   * items to be deleted
   * See release note: CR00243704.
   *
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Screening Configuration.
   */
  @Override
  @Deprecated
  public curam.core.facade.struct.ScreeningAssessmentConfigDetailsList listScreeningAssessment(
    curam.core.facade.struct.ScreeningConfigurationKey key)
    throws AppException, InformationalException {

    final curam.core.facade.struct.ScreeningAssessmentConfigDetailsList screeningAssessmentConfigDetailsList = new curam.core.facade.struct.ScreeningAssessmentConfigDetailsList();
    final ScreeningAssessmentConfigWithVersionNoDetailsList screeningAssessmentConfigWithVersionNoDetailsList = listScreeningAssessmentWithVersionNo(
      key);

    screeningAssessmentConfigDetailsList.dtls = new ScreeningAssessmentConfigDetailsList();
    screeningAssessmentConfigDetailsList.dtls.dtls = new curam.core.sl.entity.struct.ScreeningAssessmentConfigDetailsList();
    screeningAssessmentConfigDetailsList.dtls.dtls.assign(
      screeningAssessmentConfigWithVersionNoDetailsList);
    screeningAssessmentConfigDetailsList.contextDescription = screeningAssessmentConfigWithVersionNoDetailsList.contextDescription;
    return screeningAssessmentConfigDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Screening Configuration.
   *
   * This method replaces the deprecated method
   * {@link #listScreeningAssessmentConfig()}
   *
   * @param key The Screening Configuration ID
   *
   * @return List of Assessment Configuration relationships
   */
  @Override
  public ScreeningAssessmentConfigWithVersionNoDetailsList listScreeningAssessmentWithVersionNo(
    curam.core.facade.struct.ScreeningConfigurationKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final ScreeningAssessmentConfigWithVersionNoDetailsList screeningAssessmentConfigWithVersionNoDetailsList = new ScreeningAssessmentConfigWithVersionNoDetailsList();

    // Assign the value returned from the BPO method
    final ScreeningAssessmentWithVersionNoDetailsList screeningAssessmentWithVersionNoDetailsList = screeningConfigurationObj.listScreeningAssessmentConfigWithVersionNo(
      key.dtls);

    screeningAssessmentConfigWithVersionNoDetailsList.dtls.addAll(
      screeningAssessmentWithVersionNoDetailsList.dtls.dtls);

    final ScreeningConfigContextDescriptionKey screeningConfigContextDescriptionKey = new ScreeningConfigContextDescriptionKey();

    screeningConfigContextDescriptionKey.screeningConfigurationID = key.dtls.dtls.screeningConfigID;

    screeningAssessmentConfigWithVersionNoDetailsList.contextDescription.description = getScreeningConfigContextDescription(screeningConfigContextDescriptionKey).description;

    return screeningAssessmentConfigWithVersionNoDetailsList;
  }

  // END, CR00243704, KX

  // ___________________________________________________________________________
  /**
   * Cancels (logical delete) the specified Screening Configuration.
   *
   * @param key The Screening Configuration ID and version number
   */
  @Override
  public void cancelScreeningConfiguration(
    curam.core.facade.struct.ScreeningConfigurationCancelKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    screeningConfigurationObj.cancelScreeningConfiguration(key.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of Assessments that can be added to this Screening
   * Configuration. They must be ACTIVE and available within the date bounds of
   * the Screening Configuration.
   *
   * @param key The screening Configuration ID
   *
   * @return List of active assessments
   */
  @Override
  public AssessmentConfigurationList listAvailableAssessmentsForAdding(
    curam.core.facade.struct.ScreeningConfigurationKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final AssessmentConfigurationList assessmentConfigurationList = new AssessmentConfigurationList();

    // Assign the value returned from the BPO method
    assessmentConfigurationList.dtls = screeningConfigurationObj.listAvailableAssessmentsForAdding(
      key.dtls);

    return assessmentConfigurationList;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the client independent home page identifier for the specified
   * Screening Configuration.
   *
   * @param key The ID of the Screening Configuration
   *
   * @return Home page identifier for the specified Screening Configuration.
   */
  @Override
  public HomePageIdentifier getScreeningConfigurationHomePageIdentifier(
    curam.core.facade.struct.ScreeningConfigurationKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Create the return object.
    final HomePageIdentifier homePageIdentifier = new HomePageIdentifier();

    // Assign the value returned from the BPO method
    homePageIdentifier.dtls = screeningConfigurationObj.getScreeningConfigurationHomePageIdentifier(
      key.dtls);

    return homePageIdentifier;
  }

  // ___________________________________________________________________________
  /**
   * Cancels (logical delete) the specified Screening Assessment Configuration.
   *
   * @param key The Screening Assessment Configuration
   */
  @Override
  public void cancelScreeningAssessmentConfig(
    curam.core.facade.struct.ScreeningAssessmentConfigCancelKey key)
    throws AppException, InformationalException {

    // Instantiate the ScreeningConfiguration Object
    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    screeningConfigurationObj.cancelScreeningAssessmentConfig(key.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Screening Configuration Context
   * Description.
   *
   * @param key The Screening Configuration ID and optional details
   *
   * @return The context description.
   */
  @Override
  protected ScreeningConfigContextDescriptionDetails getScreeningConfigContextDescription(
    ScreeningConfigContextDescriptionKey key) throws AppException,
      InformationalException {

    // The screening configuration description which is returned.
    final ScreeningConfigContextDescriptionDetails screeningConfigContextDescriptionDetails = new ScreeningConfigContextDescriptionDetails();

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_SCREENING_CONFIGURATION_CONTEXT_DESCRIPTION);

    if (key.optionalName.length() == 0) {

      // The screening configuration object and key.
      final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

      final curam.core.sl.struct.ScreeningConfigurationKey screeningConfigurationKey = new curam.core.sl.struct.ScreeningConfigurationKey();

      // Set the screening configuration ID.
      screeningConfigurationKey.dtls.screeningConfigID = key.screeningConfigurationID;

      // Read the screening configuration details.
      final curam.core.sl.struct.ScreeningConfigurationDetails screeningConfigurationDetails = screeningConfigurationObj.viewScreeningConfiguration(
        screeningConfigurationKey);

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(curam.codetable.SCREENINGNAMECODE.TABLENAME,
        screeningConfigurationDetails.dtls.dtls.name));

    } else {

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(curam.codetable.SCREENINGNAMECODE.TABLENAME,
        key.optionalName));

    }

    // Populate the context description field with the localizable text
    screeningConfigContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return screeningConfigContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Screening Assessment Configuration
   * Context Description.
   *
   * @param key The Screening Assessment Configuration Id and optional details.
   *
   * @return The context description.
   */
  @Override
  protected ScreeningAssessmentConfigContextDescriptionDetails getScreeningAssessmentConfigContextDescription(
    ScreeningAssessmentConfigContextDescriptionKey key)
    throws AppException, InformationalException {

    // The screening configuration description which is returned.
    final ScreeningAssessmentConfigContextDescriptionDetails screeningAssessmentConfigContextDescriptionDetails = new ScreeningAssessmentConfigContextDescriptionDetails();

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_SCREENING_ASSESSMENT_CONFIGURATION_CONTEXT_DESCRIPTION);

    if (key.optionalScreeningName.length() == 0
      || key.optionalAssessmentName.length() == 0) {

      // The screening configuration object and key.
      final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

      final curam.core.sl.struct.ScreeningAssessmentConfigKey screeningAssessmentConfigKey = new curam.core.sl.struct.ScreeningAssessmentConfigKey();

      // Set the screening configuration ID.
      screeningAssessmentConfigKey.dtls.scrAssConfigID = key.scrAssConfigID;

      // Read the screening configuration details.
      final curam.core.sl.struct.ScreeningAssessmentConfigDetails screeningAssessmentConfigDetails = screeningConfigurationObj.viewScreeningAssessmentConfig(
        screeningAssessmentConfigKey);

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(curam.codetable.SCREENINGNAMECODE.TABLENAME,
        screeningAssessmentConfigDetails.dtls.screeningConfigurationName));

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(curam.codetable.ASSESSMENTNAME.TABLENAME,
        screeningAssessmentConfigDetails.dtls.assessmentConfigurationName));

    } else {

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(curam.codetable.SCREENINGNAMECODE.TABLENAME,
        key.optionalScreeningName));

      // Add the code table item to the localizable string
      contextDescription.arg(
        new CodeTableItemIdentifier(curam.codetable.ASSESSMENTNAME.TABLENAME,
        key.optionalAssessmentName));

    }

    // Populate the context description field with the localizable text
    screeningAssessmentConfigContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return screeningAssessmentConfigContextDescriptionDetails;
  }

  // ____________________________________________________________________________
  /**
   * Cancels an evidence group page for an integrated case.
   *
   * @param details Evidence group page details for an integrated case.
   */
  @Override
  public void cancelICEvidenceGroupPage(
    CancelICEvidenceGroupPageDetails details) throws AppException,
      InformationalException {

    // EvidenceScreen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final CancelEvidenceScreenDetails cancelEvidenceScreenDetails = new CancelEvidenceScreenDetails();

    // Set key for cancel
    cancelEvidenceScreenDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details for cancel
    cancelEvidenceScreenDetails.details.versionNo = details.versionNo;

    // Call BPO to cancel evidence screen
    evidenceScreenObj.cancel(cancelEvidenceScreenDetails);
  }

  // ____________________________________________________________________________
  /**
   * Cancels an evidence page for an integrated case.
   *
   * @param details Evidence page details for an integrated case.
   */
  @Override
  public void cancelICEvidencePage(CancelICEvidencePageDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final CancelEvidenceScreenDetails cancelEvidenceScreenDetails = new CancelEvidenceScreenDetails();

    // Set key for cancel
    cancelEvidenceScreenDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details for cancel
    cancelEvidenceScreenDetails.details.versionNo = details.versionNo;

    // Call BPO to cancel evidence screen
    evidenceScreenObj.cancel(cancelEvidenceScreenDetails);
  }

  // ____________________________________________________________________________
  /**
   * Cancels a site map for an integrated case.
   *
   * @param details Site map details for an integrated case.
   */
  @Override
  public void cancelICSiteMapPage(CancelSiteMapDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final CancelEvidenceScreenDetails cancelEvidenceScreenDetails = new CancelEvidenceScreenDetails();

    // Set key for cancel
    cancelEvidenceScreenDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details for cancel
    cancelEvidenceScreenDetails.details.versionNo = details.versionNo;

    // Call BPO to cancel evidence screen
    evidenceScreenObj.cancel(cancelEvidenceScreenDetails);
  }

  // ____________________________________________________________________________
  /**
   * Creates an evidence group page for an integrated case.
   *
   * @param details Evidence group page details.
   */
  @Override
  public void createICEvidenceGroupPage(
    CreateICEvidenceGroupPageDetails details) throws AppException,
      InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final CreateEvidenceScreenDetails createEvidenceScreenDetails = new CreateEvidenceScreenDetails();

    // Assign evidence screen details
    createEvidenceScreenDetails.dtls.assign(details);

    // Set codetable values for evidence group page creation
    createEvidenceScreenDetails.dtls.evidenceLevel = curam.codetable.EVIDENCELEVEL.EVIDENCEGROUP;
    createEvidenceScreenDetails.dtls.pageType = curam.codetable.PAGETYPE.EVIDENCEGROUP;
    createEvidenceScreenDetails.dtls.relatedType = curam.codetable.EVIDENCESCREENRELATEDTYPE.INTEGRATEDCASE;

    // Call BPO to create evidence screen record for evidence group page
    evidenceScreenObj.create(createEvidenceScreenDetails);
  }

  // ____________________________________________________________________________
  /**
   * Creates an evidence page for an integrated case.
   *
   * @param details Evidence page details.
   */
  @Override
  public void createICEvidencePage(CreateICEvidencePageDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final CreateEvidenceScreenDetails createEvidenceScreenDetails = new CreateEvidenceScreenDetails();

    // Assign details for create
    createEvidenceScreenDetails.dtls.assign(details);

    // Set codetable values for evidence page creation
    createEvidenceScreenDetails.dtls.evidenceLevel = curam.codetable.EVIDENCELEVEL.EVIDENCE;
    createEvidenceScreenDetails.dtls.relatedType = curam.codetable.EVIDENCESCREENRELATEDTYPE.INTEGRATEDCASE;

    // Call BPO to create evidence screen record
    evidenceScreenObj.create(createEvidenceScreenDetails);
  }

  // ____________________________________________________________________________
  /**
   * Creates a site map for an integrated case.
   *
   * @param details Site map details.
   */
  @Override
  public void createICSiteMapPage(CreateICSiteMapDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final CreateEvidenceScreenDetails createEvidenceScreenDetails = new CreateEvidenceScreenDetails();

    // Assign details for create
    createEvidenceScreenDetails.dtls.assign(details);

    // Setting codes to default values for Site Map page
    createEvidenceScreenDetails.dtls.evidenceLevel = curam.codetable.EVIDENCELEVEL.SITEMAP;
    createEvidenceScreenDetails.dtls.pageType = curam.codetable.PAGETYPE.SITEMAP;
    createEvidenceScreenDetails.dtls.relatedType = curam.codetable.EVIDENCESCREENRELATEDTYPE.INTEGRATEDCASE;
    createEvidenceScreenDetails.dtls.evidenceNodeCode = curam.codetable.SITEMAP.SITEMAP;

    // Call BPO to create evidence screen record
    evidenceScreenObj.create(createEvidenceScreenDetails);
  }

  // ____________________________________________________________________________
  /**
   * Reads list of evidence group page details.
   *
   * @param key Key to read list of evidence group page details.
   *
   * @return List of evidence group page details.
   */
  @Override
  public ListICEvidenceGroupPageDetails listICEvidenceGroupPage(
    ListICEvidenceGroupPageKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListICEvidenceGroupPageDetails listICEvidenceGroupPageDetails = new ListICEvidenceGroupPageDetails();

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final ListEvidenceScreenKey listEvidenceScreenKey = new ListEvidenceScreenKey();
    ListEvidenceScreenDetails listEvidenceScreenDetails;

    // Context description manipulation variables
    final ICContextDescriptionKey icContextDescriptionKey = new ICContextDescriptionKey();
    ICContextDescription icContextDescription;

    // Set key to read list of evidence screen details
    listEvidenceScreenKey.key.relatedID = key.key.key.relatedID;
    listEvidenceScreenKey.key.evidenceLevel = curam.codetable.EVIDENCELEVEL.EVIDENCEGROUP;

    // Call BPO to read list of evidence group page details
    listEvidenceScreenDetails = evidenceScreenObj.list(listEvidenceScreenKey);

    // Reserve capacity in the return object
    listICEvidenceGroupPageDetails.detailsList.dtls.ensureCapacity(
      listEvidenceScreenDetails.detailsList.dtls.size());

    // Evidence group page manipulation variable
    ICEvidenceGroupPageDetails icEvidenceGroupPageDetails;

    for (int i = 0; i < listEvidenceScreenDetails.detailsList.dtls.size(); i++) {

      icEvidenceGroupPageDetails = new ICEvidenceGroupPageDetails();

      icEvidenceGroupPageDetails.assign(
        listEvidenceScreenDetails.detailsList.dtls.item(i));

      listICEvidenceGroupPageDetails.detailsList.dtls.addRef(
        icEvidenceGroupPageDetails);
    }

    // Set key to read context description
    icContextDescriptionKey.adminIntegratedCaseID = key.key.key.relatedID;

    // Read context description
    icContextDescription = getAdminIntegratedCaseContextDescription(
      icContextDescriptionKey);

    // Assign context description to return object
    listICEvidenceGroupPageDetails.contextDescription.description = icContextDescription.description;

    return listICEvidenceGroupPageDetails;
  }

  // ____________________________________________________________________________
  /**
   * Reads list of evidence page details for an integrated case.
   *
   * @param key Key to read list of evidence page details.
   *
   * @return Evidence page list for an integrated case.
   */
  @Override
  public ListICEvidencePageDetails listICEvidencePage(
    ListICEvidencePageKey key) throws AppException, InformationalException {

    // Create return object
    final ListICEvidencePageDetails listICEvidencePageDetails = new ListICEvidencePageDetails();

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final ListEvidenceScreenKey listEvidenceScreenKey = new ListEvidenceScreenKey();
    ListEvidenceScreenDetails listEvidenceScreenDetails;

    // Context description manipulation variables
    final ICContextDescriptionKey icContextDescriptionKey = new ICContextDescriptionKey();
    ICContextDescription icContextDescription;

    // Assign key to read evidence screen list
    listEvidenceScreenKey.key.relatedID = key.key.key.relatedID;
    listEvidenceScreenKey.key.evidenceLevel = curam.codetable.EVIDENCELEVEL.EVIDENCE;

    // Call BPO to read list of evidence screens
    listEvidenceScreenDetails = evidenceScreenObj.list(listEvidenceScreenKey);

    // Reserve space in return object
    listICEvidencePageDetails.detailsList.dtls.ensureCapacity(
      listEvidenceScreenDetails.detailsList.dtls.size());

    // Evidence page manipulation variable
    ICEvidencePageDetails icEvidencePageDetails;

    for (int i = 0; i < listEvidenceScreenDetails.detailsList.dtls.size(); i++) {

      icEvidencePageDetails = new ICEvidencePageDetails();

      icEvidencePageDetails.assign(
        listEvidenceScreenDetails.detailsList.dtls.item(i));

      listICEvidencePageDetails.detailsList.dtls.addRef(icEvidencePageDetails);
    }

    // Set key to read context description
    icContextDescriptionKey.adminIntegratedCaseID = key.key.key.relatedID;

    // Read context description
    icContextDescription = getAdminIntegratedCaseContextDescription(
      icContextDescriptionKey);

    // Assign context description to return object
    listICEvidencePageDetails.contextDescription.description = icContextDescription.description;

    return listICEvidencePageDetails;
  }

  // ____________________________________________________________________________
  /**
   * Reads list of site map details for an integrated case.
   *
   * @param key Key to read site map list.
   *
   * @return List of site map details.
   */
  @Override
  public ListICSiteMapDetails listICSiteMapPage(ListICSiteMapKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListICSiteMapDetails listICSiteMapDetails = new ListICSiteMapDetails();

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final ListEvidenceScreenKey listEvidenceScreenKey = new ListEvidenceScreenKey();
    ListEvidenceScreenDetails listEvidenceScreenDetails;

    // Context description manipulation variables
    final ICContextDescriptionKey icContextDescriptionKey = new ICContextDescriptionKey();
    ICContextDescription icContextDescription;

    // Set key to read evidence screen list
    listEvidenceScreenKey.key.relatedID = key.key.key.relatedID;
    listEvidenceScreenKey.key.evidenceLevel = curam.codetable.EVIDENCELEVEL.SITEMAP;

    // Read evidence screen list
    listEvidenceScreenDetails = evidenceScreenObj.list(listEvidenceScreenKey);

    // Reserve capacity in return object
    listICSiteMapDetails.detailsList.dtls.ensureCapacity(
      listEvidenceScreenDetails.detailsList.dtls.size());

    // Site map manipulation variable
    ICSiteMapDetails icSiteMapDetails;

    for (int i = 0; i < listEvidenceScreenDetails.detailsList.dtls.size(); i++) {

      icSiteMapDetails = new ICSiteMapDetails();

      icSiteMapDetails.assign(
        listEvidenceScreenDetails.detailsList.dtls.item(i));

      listICSiteMapDetails.detailsList.dtls.addRef(icSiteMapDetails);
    }

    // Set key to read context description
    icContextDescriptionKey.adminIntegratedCaseID = key.key.key.relatedID;

    // Read context description
    icContextDescription = getAdminIntegratedCaseContextDescription(
      icContextDescriptionKey);

    // Assign context description to return object
    listICSiteMapDetails.contextDescription.description = icContextDescription.description;

    return listICSiteMapDetails;
  }

  // ____________________________________________________________________________
  /**
   * Modifies evidence group page details for an integrated case.
   *
   * @param details Modified evidence group page details.
   */
  @Override
  public void modifyICEvidenceGroupPage(
    ModifyICEvidenceGroupPageDetails details) throws AppException,
      InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final curam.core.sl.struct.ModifyEvidenceGroupPageDetails modifyEvidenceGroupPageDetails = new curam.core.sl.struct.ModifyEvidenceGroupPageDetails();

    // Set key to modify evidence group page
    modifyEvidenceGroupPageDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details to modify evidence group page
    modifyEvidenceGroupPageDetails.details.assign(details);

    // Call BPO to modify evidence group page
    evidenceScreenObj.modifyEvidenceGroupPage(modifyEvidenceGroupPageDetails);
  }

  // ____________________________________________________________________________
  /**
   * Modifies evidence page details for an integrated case.
   *
   * @param details Modified evidence page details.
   */
  @Override
  public void modifyICEvidencePage(ModifyICEvidencePageDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final curam.core.sl.struct.ModifyEvidencePageDetails modifyEvidencePageDetails = new curam.core.sl.struct.ModifyEvidencePageDetails();

    // Set key to modify evidence page
    modifyEvidencePageDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details to modify evidence page
    modifyEvidencePageDetails.details.assign(details);

    // Call BPO to modify evidence group page
    evidenceScreenObj.modifyEvidencePage(modifyEvidencePageDetails);
  }

  // ____________________________________________________________________________
  /**
   * Modifies site map page details for an integrated case.
   *
   * @param details Modified site map details.
   */
  @Override
  public void modifyICSiteMapPage(ModifyICSiteMapDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final curam.core.sl.struct.ModifySiteMapDetails modifySiteMapDetails = new curam.core.sl.struct.ModifySiteMapDetails();

    // Set key to modify site map
    modifySiteMapDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details to modify site map
    modifySiteMapDetails.details.assign(details);

    // Call BPO to modify site map
    evidenceScreenObj.modifySiteMap(modifySiteMapDetails);
  }

  // ____________________________________________________________________________
  /**
   * Reads evidence group page details for an integrated case.
   *
   * @param key Key to read evidence group page details for an evidence group.
   *
   * @return Evidence group page details for an evidence group.
   */
  @Override
  public ReadICEvidenceGroupPageDetails readICEvidenceGroupPage(
    ReadICEvidenceGroupPageKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadICEvidenceGroupPageDetails readICEvidenceGroupPageDetails = new ReadICEvidenceGroupPageDetails();

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final ReadEvidenceScreenKey readEvidenceScreenKey = new ReadEvidenceScreenKey();
    ReadEvidenceScreenDetails readEvidenceScreenDetails;

    // Set key to read evidence screen details
    readEvidenceScreenKey.key.evidenceScreenID = key.key.evidenceScreenID;

    // Read evidence screen details
    readEvidenceScreenDetails = evidenceScreenObj.readEvidenceScreenDetails(
      readEvidenceScreenKey);

    // Assign details to return object
    readICEvidenceGroupPageDetails.assign(readEvidenceScreenDetails.details);

    return readICEvidenceGroupPageDetails;
  }

  // ____________________________________________________________________________
  /**
   * Reads evidence page details for an integrated case.
   *
   * @param key Key to read evidence page details for an integrated case.
   *
   * @return Evidence page details for an integrated case.
   */
  @Override
  public ReadICEvidencePageDetails readICEvidencePage(
    ReadICEvidencePageKey key) throws AppException, InformationalException {

    // Create return object
    final ReadICEvidencePageDetails readICEvidencePageDetails = new ReadICEvidencePageDetails();

    // Evidence Screen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final ReadEvidenceScreenKey readEvidenceScreenKey = new ReadEvidenceScreenKey();
    ReadEvidenceScreenDetails readEvidenceScreenDetails;

    // Set key to read evidence screen details
    readEvidenceScreenKey.key.evidenceScreenID = key.key.key.evidenceScreenID;

    // Read evidence screen details
    readEvidenceScreenDetails = evidenceScreenObj.readEvidenceScreenDetails(
      readEvidenceScreenKey);

    // Assign details to return object
    readICEvidencePageDetails.assign(readEvidenceScreenDetails.details);

    return readICEvidencePageDetails;
  }

  // ____________________________________________________________________________
  /**
   * Reads site map page details for an integrated case.
   *
   * @param key Key to read site map details.
   *
   * @return Site map details for an integrated case.
   */
  @Override
  public ReadICSiteMapDetails readICSiteMapPage(ReadICSiteMapKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadICSiteMapDetails readICSiteMapDetails = new ReadICSiteMapDetails();

    // EvidenceScreen service layer objects
    final curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    final ReadEvidenceScreenKey readEvidenceScreenKey = new ReadEvidenceScreenKey();
    ReadEvidenceScreenDetails readEvidenceScreenDetails;

    // Set key to read evidence screen details
    readEvidenceScreenKey.key.evidenceScreenID = key.key.evidenceScreenID;

    // Call BPO to read evidence screen details
    readEvidenceScreenDetails = evidenceScreenObj.readEvidenceScreenDetails(
      readEvidenceScreenKey);

    // Assign details to return object
    readICSiteMapDetails.assign(readEvidenceScreenDetails.details);

    return readICSiteMapDetails;
  }

  // ____________________________________________________________________________
  /**
   * Reads the integrated case context description.
   *
   * @param key Key to read the integrated case context description.
   *
   * @return Integrated Case context description
   */
  @Override
  protected ICContextDescription getAdminIntegratedCaseContextDescription(
    ICContextDescriptionKey key) throws AppException, InformationalException {

    // Create return object
    final ICContextDescription icContextDescription = new ICContextDescription();

    // AdminIntegratedCase manipulation variables
    final curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();
    IntegratedCaseTypeStruct integratedCaseTypeStruct;
    final AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();

    // Set key to read AdminIntegratedCase
    adminIntegratedCaseKey.adminIntegratedCaseID = key.adminIntegratedCaseID;

    // Read AdminIntegratedCase to get IC Type
    integratedCaseTypeStruct = adminIntegratedCaseObj.readIntegratedCaseType(
      adminIntegratedCaseKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_INTEGRATED_CASE_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.PRODUCTCATEGORY.TABLENAME,
      integratedCaseTypeStruct.integratedCaseType));

    // Populate the context description field with the localizable text
    icContextDescription.description = contextDescription.toClientFormattedText();

    return icContextDescription;
  }

  // END, 29841

  // ___________________________________________________________________________
  /**
   * Cancels (logical delete) the specified Integrated Case Assessment
   * Configuration.
   *
   * @param key The Integrated Case Assessment Configuration
   */
  @Override
  public void cancelICAssessmentConfiguration(
    CancelICAssessmentConfigurationKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Cancel the ICAssessment Configuration
    icAssessmentConfigurationObj.cancelICAssessmentConfiguration(key.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Attempts to add the specified Assessment Configuration type to an
   * Integrated Case Configuration type for the specified dates.
   *
   * @param details The Assessment, Screening and date range
   *
   * @return Assessment configuration details
   */
  @Override
  public CreatedICAssessmentConfigurationIdentifier createICAssessmentConfiguration(
    CreateICAssessmentConfigurationDetails details) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Create the return object
    final CreatedICAssessmentConfigurationIdentifier createdICAssessmentConfigurationIdentifier = new CreatedICAssessmentConfigurationIdentifier();

    // Create the ICAssessment Configuration
    createdICAssessmentConfigurationIdentifier.dtls = icAssessmentConfigurationObj.createICAssessmentConfiguration(
      details.dtls);

    return createdICAssessmentConfigurationIdentifier;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Integrated Case Configuration.
   *
   * @param key The Integrated Case Configuration ID
   *
   * @return List of Assessment Configuration relationships
   */
  @Override
  public ReadICAssessmentConfigurationListDetailsList listICAssessmentConfiguration(ReadICAssessmentConfigurationListKey key)
    throws AppException, InformationalException {

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Create the return object
    final ReadICAssessmentConfigurationListDetailsList readICAssessmentConfigurationListDetailsList = new ReadICAssessmentConfigurationListDetailsList();

    // Read the list ICAssessment Configurations
    readICAssessmentConfigurationListDetailsList.dtls = icAssessmentConfigurationObj.listICAssessmentConfiguration(
      key.dtls);

    // Create and populate the key to read the context description
    final ICContextDescriptionKey icContextDescriptionKey = new ICContextDescriptionKey();

    icContextDescriptionKey.adminIntegratedCaseID = key.dtls.adminIntegratedCaseID;

    // Read context description
    readICAssessmentConfigurationListDetailsList.ctxDescription = getAdminIntegratedCaseContextDescription(
      icContextDescriptionKey);

    return readICAssessmentConfigurationListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing ICAssessmentConfiguration record.
   *
   * @param details The permitted changes that can be made
   */
  @Override
  public void modifyICAssessmentConfiguration(
    ModifyICAssessmentConfigurationDetails details) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Modify the ICAssessment Configuration
    icAssessmentConfigurationObj.modifyICAssessmentConfiguration(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Integrated Case Assessment
   * Configuration Context Description.
   *
   * @param key The Integrated Case Assessment Configuration ID
   *
   * @return The context description.
   */
  @Override
  protected GetICAssessmentConfigContextDescriptionDetails getICAssessmentConfigContextDescription(
    GetICAssessmentConfigContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create the return object
    final GetICAssessmentConfigContextDescriptionDetails getICAssessmentConfigContextDescriptionDetails = new GetICAssessmentConfigContextDescriptionDetails();

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_IC_ASSESSMENT_CONFIGURATION_CONTEXT_DESCRIPTION);

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Create and populate the key to read the ICAssessmentConfiguration
    final curam.core.sl.struct.ReadICAssessmentConfigurationKey readICAssessmentConfigurationKey = new curam.core.sl.struct.ReadICAssessmentConfigurationKey();

    readICAssessmentConfigurationKey.icAssessmentConfigurationID = key.icAssessmentConfigurationKey;

    // Read the ICAssessmentConfiguration details.
    final curam.core.sl.struct.ReadICAssessmentConfigurationDetails readICAssessmentConfigurationDetails = icAssessmentConfigurationObj.readICAssessmentConfiguration(
      readICAssessmentConfigurationKey);

    // AdminIntegratedCase manipulation variables
    final curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();
    IntegratedCaseTypeStruct integratedCaseTypeStruct;
    final AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();

    // Set key to read AdminIntegratedCase
    adminIntegratedCaseKey.adminIntegratedCaseID = readICAssessmentConfigurationDetails.readDtls.adminIntegratedCaseID;

    // Read AdminIntegratedCase to get IC Type
    integratedCaseTypeStruct = adminIntegratedCaseObj.readIntegratedCaseType(
      adminIntegratedCaseKey);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.PRODUCTCATEGORY.TABLENAME,
      integratedCaseTypeStruct.integratedCaseType));

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.ASSESSMENTNAME.TABLENAME,
      readICAssessmentConfigurationDetails.readDtls.assessmentConfigurationName));

    // Populate the context description field with the localizable text
    getICAssessmentConfigContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return getICAssessmentConfigContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a specific relationship details between an Integrated Case
   * Configuration and an Assessment Configuration.
   *
   * @param key The ICAssessmentConfig ID
   *
   * @return The ICAssessmentConfiguration details
   */
  @Override
  public ReadICAssessmentConfigurationDetails readICAssessmentConfiguration(
    ReadICAssessmentConfigurationKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Create the return object
    final ReadICAssessmentConfigurationDetails readICAssessmentConfigurationDetails = new ReadICAssessmentConfigurationDetails();

    // Read the ICAssessment Configuration
    readICAssessmentConfigurationDetails.dtls = icAssessmentConfigurationObj.readICAssessmentConfiguration(
      key.dtls);

    // Create and populate the key to read the context description
    final GetICAssessmentConfigContextDescriptionKey getICAssessmentConfigContextDescriptionKey = new GetICAssessmentConfigContextDescriptionKey();

    getICAssessmentConfigContextDescriptionKey.icAssessmentConfigurationKey = key.dtls.icAssessmentConfigurationID;

    // Read the context description
    readICAssessmentConfigurationDetails.ctxDescription = getICAssessmentConfigContextDescription(
      getICAssessmentConfigContextDescriptionKey);

    return readICAssessmentConfigurationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a deduction.
   *
   * @param details The details of the deduction to be cancelled.
   */
  @Override
  public void cancelDeduction(CancelDeductionDetails details)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.core.sl.intf.Deduction deductionObj = curam.core.sl.fact.DeductionFactory.newInstance();

    // Cancel the deduction
    deductionObj.cancelDeduction(details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates a deduction.
   *
   * @param details The details with which to create the deduction.
   */
  @Override
  public void createDeduction(CreateDeductionDtls details)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.core.sl.intf.Deduction deductionObj = curam.core.sl.fact.DeductionFactory.newInstance();

    // Create the deduction
    deductionObj.createDeduction(details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Lists the deductions that exist on the system.
   *
   * @return A list of the deductions.
   */
  @Override
  public ListDeductionDtls listDeduction() throws AppException,
      InformationalException {

    // create object from service layer
    final curam.core.sl.intf.Deduction deductionObj = curam.core.sl.fact.DeductionFactory.newInstance();

    // Variable for the deduction list
    final ListDeductionDtls listDeductionDtls = new ListDeductionDtls();

    // Retrieve the deduction list
    listDeductionDtls.dtls = deductionObj.list();

    // Return the deduction list
    return listDeductionDtls;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the deduction.
   *
   * @param details Contains the key of the deduction to be modified and
   * the new details of the deduction.
   */
  @Override
  public void modifyDeduction(ModifyDeductionDetails details)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.core.sl.intf.Deduction deductionObj = curam.core.sl.fact.DeductionFactory.newInstance();

    // Modify the deduction
    deductionObj.modifyDeduction(details.key, details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads the deduction.
   *
   * @param key Contains the key of the deduction that is required.
   * @return The details of the deduction matching the key.
   */
  @Override
  public ReadDeductionDtls readDeduction(DeductionKey key)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.core.sl.intf.Deduction deductionObj = curam.core.sl.fact.DeductionFactory.newInstance();

    // Variable to read the deduction details
    final ReadDeductionDtls readDeductionDtls = new ReadDeductionDtls();

    // Read the deduction details
    readDeductionDtls.dtls = deductionObj.read(key.key);

    // Get the context description.
    final DeductionContextDescriptionKey deductionContextDescriptionKey = new DeductionContextDescriptionKey();

    // Set the deduction ID.
    deductionContextDescriptionKey.deductionID = key.key.key.deductionID;

    // Set the description.
    readDeductionDtls.deductionContextDescription = getDeductionContextDescription(
      deductionContextDescriptionKey);

    // Return the deduction details
    return readDeductionDtls;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Deduction Context Description.
   *
   * @param key The Deduction Context Description Key.
   * @return The context description of the deduction.
   */
  @Override
  public DeductionContextDescriptionDetails getDeductionContextDescription(
    DeductionContextDescriptionKey key)

    throws AppException, InformationalException {

    // The returned details.
    final DeductionContextDescriptionDetails deductionContextDescriptionDetails = new DeductionContextDescriptionDetails();

    // Maintain deduction object to return context details.
    final curam.core.sl.intf.Deduction deductionObj = curam.core.sl.fact.DeductionFactory.newInstance();
    curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = new curam.core.sl.struct.ReadDeductionDetails();
    final DeductionKey deductionKey = new DeductionKey();

    // Deduction key.
    deductionKey.key.key.deductionID = key.deductionID;

    // Read the deduction details.
    readDeductionDetails = deductionObj.read(deductionKey.key);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_DEDUCTION_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.DEDUCTIONNAME.TABLENAME,
      readDeductionDetails.dtls.deductionName));

    // Populate the context description field with the localizable text
    deductionContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return deductionContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the priority, actionType,
   * defaultAmount
   * and defaultPercentage by deductionName.
   *
   * @param key DeductionName
   * @return ReadDeductionDtlsByName Priority, actionType, defaultAmount,
   * defaultPercentage
   */
  @Override
  public ReadDeductionDtls readDeductionByName(DeductionNameCaseID key)
    throws AppException, InformationalException {

    // Deduction object variables
    final Deduction deductionObj = DeductionFactory.newInstance();
    ReadDeductionDetails readDeductionDetails = new ReadDeductionDetails();
    final DeductionName deductionName = new DeductionName();

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    ComponentNomineeDtlsList componentNomineeDtlsList = new ComponentNomineeDtlsList();
    final CaseKey casekey = new CaseKey();

    // Return Struct
    final ReadDeductionDtls readDeductionDtls = new ReadDeductionDtls();

    // Set key for read
    deductionName.deductionName = key.deductionName;

    // Read back details
    readDeductionDetails = deductionObj.readDeductionDetailsByName(
      deductionName);

    // Populate return struct
    readDeductionDtls.dtls.assign(readDeductionDetails);

    // Set key for read
    casekey.caseID = key.caseID;

    // Returns component and nominee details
    componentNomineeDtlsList = maintainDeductionItemsObj.listComponentNomineeDetails(
      casekey);

    // Populate return struct
    readDeductionDtls.dtlsList.dtls.assign(componentNomineeDtlsList);

    return readDeductionDtls;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a Temporal Evidence Approval Check.
   *
   * @param key Contains cancellation details for a Temporal Evidence Approval
   * Check.
   */
  @Override
  public void cancelTemporalEvidenceApprovalCheck(
    TemporalEvidenceApprovalCheckKey key,
    ModifyTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    final CancelTemporalEvidenceApprovalCheck cancelTemporalEvidenceApprovalCheck = new CancelTemporalEvidenceApprovalCheck();

    cancelTemporalEvidenceApprovalCheck.key = key.key.key;

    cancelTemporalEvidenceApprovalCheck.dtls.recordStatus = dtls.recordStatus;
    cancelTemporalEvidenceApprovalCheck.dtls.versionNo = dtls.versionNo;

    // Call business process to cancel the Temporal Evidence Approval Check
    TemporalEvidenceApprovalCheckFactory.newInstance().cancel(
      cancelTemporalEvidenceApprovalCheck);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Temporal Evidence Approval Check.
   *
   * @param dtls Temporal Evidence Approval Check creation details
   */
  @Override
  public void createTemporalEvidenceApprovalCheck(
    CreateTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    final TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    temporalEvidenceApprovalCheckDetails.details.dtls.assign(dtls);

    // BEGIN, C00079325, CH
    temporalEvidenceApprovalCheckDetails.details.allEvidenceInd = dtls.allEvidenceInd;
    // END, CR00079325

    // Call business process to create the Temporal Evidence Approval Check
    TemporalEvidenceApprovalCheckFactory.newInstance().insert(
      temporalEvidenceApprovalCheckDetails.details);
  }

  // ___________________________________________________________________________
  /**
   * Lists Temporal Evidence Approval Check entries created at Evidence level.
   *
   * @return List containing Temporal Evidence Approval Check records created
   * at the evidence type level
   */
  @Override
  public curam.core.facade.struct.TemporalEvidenceApprovalCheckList listTemporalEvidenceApprovalCheckByEvidenceType() throws AppException,
      InformationalException {

    // Return object
    final curam.core.facade.struct.TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckList = new curam.core.facade.struct.TemporalEvidenceApprovalCheckList();

    temporalEvidenceApprovalCheckList.assign(
      TemporalEvidenceApprovalCheckFactory.newInstance().listByEvidenceTypeOnly());

    return temporalEvidenceApprovalCheckList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies Temporal Evidence Approval Check details.
   *
   * @param dtls Modified Temporal Evidence Approval Check details
   */
  @Override
  public void modifyTemporalEvidenceApprovalCheck(
    ModifyTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    final TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    final TemporalEvidenceApprovalCheckKey temporalEvidenceApprovalCheckKey = new TemporalEvidenceApprovalCheckKey();

    temporalEvidenceApprovalCheckKey.key.key.temporalEvApprovalCheckID = dtls.temporalEvApprovalCheckID;

    temporalEvidenceApprovalCheckDetails.details = TemporalEvidenceApprovalCheckFactory.newInstance().read(
      temporalEvidenceApprovalCheckKey.key);

    temporalEvidenceApprovalCheckDetails.details.dtls.assign(dtls);

    temporalEvidenceApprovalCheckDetails.details.allEvidenceInd = dtls.allEvidenceInd;

    // Call business process to modify Temporal Evidence Approval Check details
    TemporalEvidenceApprovalCheckFactory.newInstance().modify(
      temporalEvidenceApprovalCheckDetails.details);
  }

  // ___________________________________________________________________________
  /**
   * Reads Temporal Evidence Approval Check details.
   *
   * @param key Contains a Temporal Evidence Approval Check entity key
   * @return Temporal Evidence Approval Check details
   */
  @Override
  public ViewTemporalEvidenceApprovalCheck readTemporalEvidenceApprovalCheckDetails(
    TemporalEvidenceApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return object
    final ViewTemporalEvidenceApprovalCheck viewTemporalEvidenceApprovalCheck = new ViewTemporalEvidenceApprovalCheck();

    final TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    // Call service layer operation to read Temporal Evidence Approval Check
    // details
    temporalEvidenceApprovalCheckDetails.details = TemporalEvidenceApprovalCheckFactory.newInstance().read(
      key.key);

    viewTemporalEvidenceApprovalCheck.assign(
      temporalEvidenceApprovalCheckDetails.details.dtls);

    return viewTemporalEvidenceApprovalCheck;
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of Integrated Case associated with an Assessment
   * Configuration
   *
   * @param key Contains a AssessmentConfigurationKey
   * @return IntegratedCaseTypesForAssessmentConfigDetailsList
   */
  @Override
  public curam.core.facade.struct.IntegratedCaseTypesForAssessmentConfigDetailsList listIntegratedCaseTypesForAssessmentConfiguration(
    AssessmentConfigurationKey key) throws AppException,
      InformationalException {

    // Integrated Case Assessment Configuration BPO
    final ICAssessmentConfiguration icAssessmentConfigurationObj = ICAssessmentConfigurationFactory.newInstance();
    // Return Struct
    final curam.core.facade.struct.IntegratedCaseTypesForAssessmentConfigDetailsList integratedCaseTypes = new curam.core.facade.struct.IntegratedCaseTypesForAssessmentConfigDetailsList();

    // get the list of integrated case types associated to an assessment
    // configuration
    integratedCaseTypes.dtls = icAssessmentConfigurationObj.listIntegratedCaseTypesForAssessmentConfiguration(
      key.dtls);
    // Get the Context description
    final AssessmentContextDescriptionKey contextDescriptionKey = new AssessmentContextDescriptionKey();

    // set the key
    contextDescriptionKey.assessmentConfigurationID = key.dtls.dtls.assessmentConfigurationID;
    integratedCaseTypes.contextDescription = getAssessmentContextDescription(
      contextDescriptionKey);
    return integratedCaseTypes;
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of Products associated with an Assessment Configuration
   *
   * @param key Contains a AssessmentConfigurationKey
   * @return BenefitProductsForAssessmentConfigDetailsList
   */
  @Override
  public BenefitProductsForAssessmentConfigDetailsList listProductsForAssessmentConfiguration(AssessmentConfigurationKey key)
    throws AppException, InformationalException {

    // Product Assessment Configuration BPO
    final ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();
    // Return Struct
    final BenefitProductsForAssessmentConfigDetailsList assessmentConfigDetailsList = new BenefitProductsForAssessmentConfigDetailsList();

    // get the list of products associated to an assessment configuration
    assessmentConfigDetailsList.dtls = productAssessmentConfigurationObj.listProductsForAssessmentConfiguration(
      key.dtls);
    // Get the Context description
    final AssessmentContextDescriptionKey contextDescriptionKey = new AssessmentContextDescriptionKey();

    // set the context description key
    contextDescriptionKey.assessmentConfigurationID = key.dtls.dtls.assessmentConfigurationID;
    assessmentConfigDetailsList.contextDescription = getAssessmentContextDescription(
      contextDescriptionKey);
    return assessmentConfigDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of Distinct Integrated case Assessment configurations
   * associated with an Assessment Case
   *
   * @param key Contains a ListAssessmentTypesForICCaseIDKey
   * @return AssessmentConfigurationIDAndNameDetailsList
   */
  @Override
  public AssessmentConfigurationIDAndNameDetailsList listDistinctICAssessmentConfigurationsByCaseID(
    ListAssessmentTypesForICCaseIDKey key) throws AppException,
      InformationalException {

    // Return Struct
    final AssessmentConfigurationIDAndNameDetailsList assessmentConfigIDAndNameDetailsList = new AssessmentConfigurationIDAndNameDetailsList();
    // Integrated Case Assessment Configuration BPO
    final ICAssessmentConfiguration icAssessmentConfigurationObj = ICAssessmentConfigurationFactory.newInstance();

    // get the distinct list of assessment configuration associated to an
    // integrated case and that are active in status
    assessmentConfigIDAndNameDetailsList.list = icAssessmentConfigurationObj.listDistinctICAssessmentConfigurationsByCaseID(
      key.key);
    return assessmentConfigIDAndNameDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a facade independent page identifier for the assessment
   * configuration, which identifies the HomePage for this assessment
   * configuration.
   *
   * @param key The assessment case ID
   *
   * @return Page identifier for the assessment configuration
   */
  @Override
  public HomePageIdentifier getAssessmentConfigurationHomePageIdentifierByAssessmentCaseID(
    curam.core.facade.struct.CaseIDKey key) throws AppException,
      InformationalException {

    // Instantiate the Assessment Configuration Object
    final curam.core.sl.intf.AssessmentConfiguration assessmentConfigurationObj = curam.core.sl.fact.AssessmentConfigurationFactory.newInstance();
    // Create the return object.
    final HomePageIdentifier homePageIdentifier = new HomePageIdentifier();
    // set the key
    final curam.core.sl.struct.AssessmentConfigurationHomePageIdentifierKey assessmentConfigurationHomePageIdentifierKey = new curam.core.sl.struct.AssessmentConfigurationHomePageIdentifierKey();

    // assign the key
    assessmentConfigurationHomePageIdentifierKey.caseID = key.dtls.dtls.caseID;
    // Assign the value returned from the BPO method
    homePageIdentifier.dtls = assessmentConfigurationObj.getAssessmentConfigurationHomePageIdentifier(
      assessmentConfigurationHomePageIdentifierKey);
    return homePageIdentifier;
  }

  // BEGIN, CR00081013, PMD
  // ___________________________________________________________________________
  /**
   * Method to return a list of all assessment types.
   *
   * @return a list of assessment types
   */
  @Override
  public AssessmentConfigTypeList listAllAssessmentTypes()
    throws AppException, InformationalException {

    // Return struct
    final AssessmentConfigTypeList assessmentConfigTypeList = new AssessmentConfigTypeList();

    final curam.core.intf.AdminAssessmentConfiguration adminAssessmentConfigObj = curam.core.fact.AdminAssessmentConfigurationFactory.newInstance();

    // Get the list of screening types
    assessmentConfigTypeList.assessmentTypes = adminAssessmentConfigObj.listAllAssessmentTypes();

    return assessmentConfigTypeList;
  }

  // ___________________________________________________________________________
  /**
   * Method to return a list of all screening types.
   *
   * @return a list of screening types
   */
  @Override
  public ScreeningConfigNameList listAllScreeningTypes() throws AppException,
      InformationalException {

    // Return struct
    final ScreeningConfigNameList screeningConfigNameList = new ScreeningConfigNameList();

    final curam.core.sl.intf.ScreeningConfiguration screeningConfigObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    // Get the list of screening types
    screeningConfigNameList.screeningConfgNameList = screeningConfigObj.listAllScreeningTypes();

    return screeningConfigNameList;
  }

  // END, CR00081013

  // BEGIN, CR00121630, ZV
  // ___________________________________________________________________________
  /**
   * Cancels (logical delete) the specified Integrated Case Assessment
   * Configuration.
   *
   * @param key The Integrated Case Assessment Configuration id
   */
  @Override
  public void cancelInvCAssessmentConfiguration(
    CancelInvCAssessmentConfigKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.InvCAssessmentConfig InvCAssessmentConfigObj = curam.core.sl.fact.InvCAssessmentConfigFactory.newInstance();

    // Cancel the InvCAssessment Configuration
    InvCAssessmentConfigObj.cancelInvCAssessmentConfig(key.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Attempts to add the specified Assessment Configuration type to an
   * Integrated Case Configuration type for the specified dates.
   *
   * @param details The Assessment, Screening and date range
   *
   * @return Assessment configuration details
   */
  @Override
  public CreatedInvCAssessmentConfigIdentifier createInvCAssessmentConfiguration(
    CreateInvCAssessmentConfigDetails details) throws AppException,
      InformationalException {

    final curam.core.sl.intf.InvCAssessmentConfig InvCAssessmentConfigObj = curam.core.sl.fact.InvCAssessmentConfigFactory.newInstance();

    // Create the return object
    final CreatedInvCAssessmentConfigIdentifier createdInvCAssessmentConfigIdentifier = new CreatedInvCAssessmentConfigIdentifier();

    // Create the InvCAssessment Configuration
    createdInvCAssessmentConfigIdentifier.dtls = InvCAssessmentConfigObj.createInvCAssessmentConfig(
      details.dtls);

    return createdInvCAssessmentConfigIdentifier;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Integrated Case Configuration.
   *
   * @param key The Integrated Case Configuration ID
   *
   * @return List of Assessment Configuration relationships
   */
  @Override
  public ReadInvCAssessmentConfigListDetailsList listInvCAssessmentConfiguration(ReadInvCAssessmentConfigListKey key)
    throws AppException, InformationalException {

    final curam.core.sl.intf.InvCAssessmentConfig InvCAssessmentConfigObj = curam.core.sl.fact.InvCAssessmentConfigFactory.newInstance();

    // Create the return object
    final ReadInvCAssessmentConfigListDetailsList readInvCAssessmentConfigListDetailsList = new ReadInvCAssessmentConfigListDetailsList();

    // Read the list InvCAssessment Configurations
    readInvCAssessmentConfigListDetailsList.dtls = InvCAssessmentConfigObj.listInvCAssessmentConfig(
      key.dtls);

    // Create and populate the key to read the context description
    final InvCContextDescriptionKey invcContextDescriptionKey = new InvCContextDescriptionKey();

    invcContextDescriptionKey.investigationConfigID = key.dtls.investigationConfigID;

    // Read context description
    readInvCAssessmentConfigListDetailsList.ctxDescription = getInvestigationCaseContextDescription(
      invcContextDescriptionKey);

    return readInvCAssessmentConfigListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing Investigation case assessment configuration record.
   *
   * @param details The Investigation case assessment configuration details
   * to be updated
   */
  @Override
  public void modifyInvCAssessmentConfiguration(
    ModifyInvCAssessmentConfigDetails details) throws AppException,
      InformationalException {

    final curam.core.sl.intf.InvCAssessmentConfig InvCAssessmentConfigObj = curam.core.sl.fact.InvCAssessmentConfigFactory.newInstance();

    // Modify the InvCAssessment Configuration
    InvCAssessmentConfigObj.modifyInvCAssessmentConfig(details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to read the Integrated Case Assessment
   * Configuration Context Description.
   *
   * @param key The Investigation Case Assessment Configuration ID
   *
   * @return The context description.
   */
  @Override
  protected GetInvCAssessmentConfigContextDescriptionDetails getInvCAssessmentConfigContextDescription(
    GetInvCAssessmentConfigContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create the return object
    final GetInvCAssessmentConfigContextDescriptionDetails getInvCAssessmentConfigContextDescriptionDetails = new GetInvCAssessmentConfigContextDescriptionDetails();

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_IC_ASSESSMENT_CONFIGURATION_CONTEXT_DESCRIPTION);

    final curam.core.sl.intf.InvCAssessmentConfig InvCAssessmentConfigObj = curam.core.sl.fact.InvCAssessmentConfigFactory.newInstance();

    // Create and populate the key to read the InvCAssessmentConfig
    final curam.core.sl.struct.ReadInvCAssessmentConfigKey readInvCAssessmentConfigKey = new curam.core.sl.struct.ReadInvCAssessmentConfigKey();

    readInvCAssessmentConfigKey.invCAssessmentConfigID = key.invCAssessmentConfigKey;

    // Read the InvCAssessmentConfig details.
    final curam.core.sl.struct.ReadInvCAssessmentConfigDetails readInvCAssessmentConfigDetails = InvCAssessmentConfigObj.readInvCAssessmentConfig(
      readInvCAssessmentConfigKey);

    // InvestigationConfig manipulation variables
    final curam.core.sl.entity.intf.InvestigationConfig investigationConfigObj = curam.core.sl.entity.fact.InvestigationConfigFactory.newInstance();
    InvestigationIDTypeDtls investigationIDTypeDtls;
    final InvestigationConfigKey investigationConfigKey = new InvestigationConfigKey();

    // Set key to read AdminIntegratedCase
    investigationConfigKey.investigationConfigID = readInvCAssessmentConfigDetails.readDtls.investigationConfigID;

    // Read InvestigationConfig to get IC Type
    investigationIDTypeDtls = investigationConfigObj.readInvestigationType(
      investigationConfigKey);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(
        curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
        investigationIDTypeDtls.type));

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(curam.codetable.ASSESSMENTNAME.TABLENAME,
      readInvCAssessmentConfigDetails.readDtls.assessmentConfigurationName));

    // Populate the context description field with the localizable text
    getInvCAssessmentConfigContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return getInvCAssessmentConfigContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a specific relationship details between an Investigation Case
   * Configuration and an Assessment Configuration.
   *
   * @param key The Investigation case assessment configuration ID
   *
   * @return The Investigation case assessment configuration details
   */
  @Override
  public ReadInvCAssessmentConfigDetails readInvCAssessmentConfiguration(
    ReadInvCAssessmentConfigKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.InvCAssessmentConfig InvCAssessmentConfigObj = curam.core.sl.fact.InvCAssessmentConfigFactory.newInstance();

    // Create the return object
    final ReadInvCAssessmentConfigDetails readInvCAssessmentConfigDetails = new ReadInvCAssessmentConfigDetails();

    // Read the InvCAssessment Configuration
    readInvCAssessmentConfigDetails.dtls = InvCAssessmentConfigObj.readInvCAssessmentConfig(
      key.dtls);

    // Create and populate the key to read the context description
    final GetInvCAssessmentConfigContextDescriptionKey getInvCAssessmentConfigContextDescriptionKey = new GetInvCAssessmentConfigContextDescriptionKey();

    getInvCAssessmentConfigContextDescriptionKey.invCAssessmentConfigKey = key.dtls.invCAssessmentConfigID;

    // Read the context description
    readInvCAssessmentConfigDetails.ctxDescription = getInvCAssessmentConfigContextDescription(
      getInvCAssessmentConfigContextDescriptionKey);

    return readInvCAssessmentConfigDetails;
  }

  // ____________________________________________________________________________
  /**
   * Reads the investigation case context description.
   *
   * @param key Key to read the investigation case context description.
   *
   * @return Investigation Case context description
   */
  @Override
  protected InvCContextDescription getInvestigationCaseContextDescription(
    InvCContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create return object
    final InvCContextDescription invcContextDescription = new InvCContextDescription();

    // InvestigationConfig manipulation variables
    final curam.core.sl.entity.intf.InvestigationConfig adminIntegratedCaseObj = curam.core.sl.entity.fact.InvestigationConfigFactory.newInstance();
    InvestigationIDTypeDtls investigationIDTypeDtls;
    final InvestigationConfigKey investigationConfigKey = new InvestigationConfigKey();

    // Set key to read AdminIntegratedCase
    investigationConfigKey.investigationConfigID = key.investigationConfigID;

    // Read InvestigationConfig to get IC Type
    investigationIDTypeDtls = adminIntegratedCaseObj.readInvestigationType(
      investigationConfigKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_INVESTIGATION_CASE_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(
        curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
        investigationIDTypeDtls.type));

    // Populate the context description field with the localizable text
    invcContextDescription.description = contextDescription.toClientFormattedText();

    return invcContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of Distinct Investigation case Assessment configurations
   * associated with an Investigation Case
   *
   * @param key Contains an investigation case id
   * @return Investigation case assessment configuration id and name list
   */
  @Override
  public AssessmentConfigurationIDAndNameDetailsList listDistinctInvCAssessmentConfigurationsByCaseID(
    ListAssessmentTypesForICCaseIDKey key) throws AppException,
      InformationalException {

    // Return Struct
    final AssessmentConfigurationIDAndNameDetailsList assessmentConfigIDAndNameDetailsList = new AssessmentConfigurationIDAndNameDetailsList();
    // Integrated Case Assessment Configuration BPO
    final InvCAssessmentConfig invcAssessmentConfigObj = InvCAssessmentConfigFactory.newInstance();

    // get the distinct list of assessment configuration associated to
    // an investigation case and that are active in status
    assessmentConfigIDAndNameDetailsList.list = invcAssessmentConfigObj.listDistinctInvCAssessmentConfigsByCaseID(
      key.key);

    return assessmentConfigIDAndNameDetailsList;
  }

  // END, CR00121630

  // BEGIN, CR00197386, SS
  /**
   * This method replaces the deprecated method
   * {@link #modifyScreeningConfiguration()}.
   * <p>
   * Modifies an existing ScreeningConfiguration with the details passed as
   * parameter to this method.
   *
   * @param details
   * Contains configuration details such as comments, dates and
   * ownership strategy configured for this case type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyScreeningConfiguration1(
    ScreeningConfigurationModifyDtls details) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    screeningConfigurationObj.modifyScreeningConfiguration1(details.dtls);
  }

  // END, CR00197386

  /**
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Integrated Case Configuration with versionNo.
   *
   * @param key The Integrated Case Configuration ID
   *
   * @return List of Assessment Configuration relationships
   */

  @Override
  public ReadICAssessmentConfigurationListDetailsListAndVersionNo listICAssessmentConfigurationAndVersionNo(
    ReadICAssessmentConfigurationListKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.ICAssessmentConfiguration icAssessmentConfigurationObj = curam.core.sl.fact.ICAssessmentConfigurationFactory.newInstance();

    // Create the return object
    final ReadICAssessmentConfigurationListDetailsListAndVersionNo readICAssessmentConfigurationListDetailsList = new ReadICAssessmentConfigurationListDetailsListAndVersionNo();

    // Read the list ICAssessment Configurations
    readICAssessmentConfigurationListDetailsList.dtls = icAssessmentConfigurationObj.listICAssessmentConfigurationAndVersionNo(
      key.dtls);

    return readICAssessmentConfigurationListDetailsList;
  }

}
