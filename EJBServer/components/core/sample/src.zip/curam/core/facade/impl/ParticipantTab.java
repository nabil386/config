/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.MaintainConcernRoleKey;
import curam.core.facade.struct.ParticipantImageDetails;
import curam.core.facade.struct.ParticipantTabXML;
import curam.core.sl.fact.ConcernRoleImageFactory;
import curam.core.sl.fact.ParticipantTabFactory;
import curam.core.sl.intf.ConcernRoleImage;
import curam.core.sl.struct.EducationalInstituteTabDetails;
import curam.core.sl.struct.ExternalPartyTabDetails;
import curam.core.sl.struct.InfoProviderTabDetails;
import curam.core.sl.struct.ParticipantContentDetailsXML;
import curam.core.sl.struct.ProductProviderTabDetails;
import curam.core.sl.struct.ServiceSupplierTabDetails;
import curam.core.sl.struct.UtilityTabDetails;
import curam.core.struct.ConcernRoleImageDtls;
import curam.core.struct.ConcernRoleKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.MultipleRecordException;


/**
 * This process class provides the functionality for the Participant tab
 * details.
 */
public abstract class ParticipantTab extends curam.core.facade.base.ParticipantTab {

  // ___________________________________________________________________________
  /**
   * Read the tab details for an educational institute.
   *
   * @param key
   * The concern role id of the educational institute.
   *
   * @return The educational institute tab details.
   */
  @Override
  public EducationalInstituteTabDetails readEducationalInstitute(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    return ParticipantTabFactory.newInstance().readEducationalInstitute(
      key.maintainConcernRoleKey);

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for an Employer.
   *
   * @param key
   * The concern role id of the Employer.
   *
   * @return The Employer tab details.
   */
  @Override
  public ParticipantTabXML readEmployer(MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    final ParticipantTabXML participantTabXML = new ParticipantTabXML();

    ParticipantContentDetailsXML participantContentDetailsXML = new ParticipantContentDetailsXML();

    participantContentDetailsXML = ParticipantTabFactory.newInstance().readEmployer(
      key.maintainConcernRoleKey);

    participantTabXML.xmlPanelData = participantContentDetailsXML.xmlPanelData;
    participantTabXML.description = participantContentDetailsXML.participantName;

    return participantTabXML;

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for an Person.
   *
   * @param key
   * The concern role id of the Person.
   *
   * @return The Person tab details.
   */
  @Override
  public ParticipantTabXML readPerson(MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    final ParticipantTabXML participantTabXML = new ParticipantTabXML();

    ParticipantContentDetailsXML participantContentDetailsXML = new ParticipantContentDetailsXML();

    participantContentDetailsXML = ParticipantTabFactory.newInstance().readPerson(
      key.maintainConcernRoleKey);

    participantTabXML.xmlPanelData = participantContentDetailsXML.xmlPanelData;
    participantTabXML.description = participantContentDetailsXML.participantName;

    return participantTabXML;
  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for a Prospect Employer.
   *
   * @param key
   * The concern role id of the Prospect Employer.
   *
   * @return The Prospect Employer tab details.
   */
  @Override
  public ParticipantTabXML readProspectEmployer(MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    final ParticipantTabXML participantTabXML = new ParticipantTabXML();

    ParticipantContentDetailsXML participantContentDetailsXML = new ParticipantContentDetailsXML();

    try {
      participantContentDetailsXML = ParticipantTabFactory.newInstance().readProspectEmployer(
        key.maintainConcernRoleKey);
    } catch (final MultipleRecordException e) {
      throw new AppException(
        curam.message.BPOEMPLOYERREGISTRATION.ERR_XRV_PROSPECT_EMPLOYER_REGISTERED_AS_EMPLOYER);

    }
    participantTabXML.xmlPanelData = participantContentDetailsXML.xmlPanelData;
    participantTabXML.description = participantContentDetailsXML.participantName;

    return participantTabXML;
  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for a Prospect Person.
   *
   * @param key
   * The concern role id of the Prospect Person.
   *
   * @return The Prospect Person tab details.
   */
  @Override
  public ParticipantTabXML readProspectPerson(MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    final ParticipantTabXML participantTabXML = new ParticipantTabXML();

    ParticipantContentDetailsXML participantContentDetailsXML = new ParticipantContentDetailsXML();

    participantContentDetailsXML = ParticipantTabFactory.newInstance().readProspectPerson(
      key.maintainConcernRoleKey);

    participantTabXML.xmlPanelData = participantContentDetailsXML.xmlPanelData;
    participantTabXML.description = participantContentDetailsXML.participantName;

    return participantTabXML;

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for an external party.
   *
   * @param key
   * The concern role id of the external party.
   *
   * @return The external party tab details.
   */
  @Override
  public ExternalPartyTabDetails readExternalParty(MaintainConcernRoleKey key) throws AppException,
      InformationalException {

    return ParticipantTabFactory.newInstance().readExternalParty(
      key.maintainConcernRoleKey);

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for an Information Provider.
   *
   * @param key
   * The concern role id of the Information Provider.
   *
   * @return The Information Provider tab details.
   */
  @Override
  public InfoProviderTabDetails readInformationProvider(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    return ParticipantTabFactory.newInstance().readInformationProvider(
      key.maintainConcernRoleKey);

  }

  // ___________________________________________________________________________
  /**
   * Read the tab image for a Participant.
   *
   * @param key
   * The concern role id of the Participant.
   *
   * @return The image details.
   */
  @Override
  public ParticipantImageDetails readParticipantImage(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    final ParticipantImageDetails participantImageDetails = new ParticipantImageDetails();
    final ConcernRoleImage concernRoleImageObj = ConcernRoleImageFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    if (concernRoleImageObj.hasImage(concernRoleKey).statusInd) {

      final ConcernRoleImageDtls concernRoleImageDtls = concernRoleImageObj.getLatestPersonImage(
        concernRoleKey);

      participantImageDetails.concernRoleImageBlob = concernRoleImageDtls.imageBlob;

      participantImageDetails.concernRoleImageID = concernRoleImageDtls.concernRoleImageID;
    }

    return participantImageDetails;

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for a Product Provider.
   *
   * @param key
   * The concern role id of the Product Provider.
   *
   * @return The Product Provider tab details.
   */
  @Override
  public ProductProviderTabDetails readProductProvider(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    return ParticipantTabFactory.newInstance().readProductProvider(
      key.maintainConcernRoleKey);

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for a Service Supplier.
   *
   * @param key
   * The concern role id of the Service Supplier.
   *
   * @return The Service Supplier tab details.
   */
  @Override
  public ServiceSupplierTabDetails readServiceSupplier(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    return ParticipantTabFactory.newInstance().readServiceSupplier(
      key.maintainConcernRoleKey);

  }

  // ___________________________________________________________________________
  /**
   * Read the tab details for a Utility.
   *
   * @param key
   * The concern role id of the Utility.
   *
   * @return The Utility tab details.
   */
  @Override
  public UtilityTabDetails readUtility(MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    return ParticipantTabFactory.newInstance().readUtility(
      key.maintainConcernRoleKey);

  }

}
