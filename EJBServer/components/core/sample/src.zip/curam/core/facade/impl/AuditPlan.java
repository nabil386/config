/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;
import curam.bihelper.sl.impl.BIHelper;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.FocusAreaStatsList;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditCaseConfigDAO;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.AuditorDAO;
import curam.caseaudit.impl.CaseAudit;
import curam.caseaudit.impl.CaseAuditConst;
import curam.caseaudit.impl.CaseAuditDAO;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.WidgetDocumentBuilder;
import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.CodeTableItemEntry;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.cefwidgets.utilities.impl.RendererConfig;
import curam.cefwidgets.utilities.impl.RendererConfig.RendererConfigType;
import curam.codetable.CASEAUDITSTATUS;
import curam.codetable.CASECATTYPECODE;
import curam.codetable.impl.AUDITPLANPRIORITYEntry;
import curam.codetable.impl.AUDITPLANPURPOSEEntry;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.AUDITPLANUSERACCESSEntry;
import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.intf.Organization;
import curam.core.facade.struct.AuditContextDetails;
import curam.core.facade.struct.AuditPlanAndVersionKey;
import curam.core.facade.struct.AuditPlanDetails;
import curam.core.facade.struct.AuditPlanDetailsList;
import curam.core.facade.struct.AuditPlanHomeDetails;
import curam.core.facade.struct.AuditPlanModifySumFindings;
import curam.core.facade.struct.AuditPlanScheduleDetails;
import curam.core.facade.struct.AuditPlanSearchKey;
import curam.core.facade.struct.AuditPlanSearchResult;
import curam.core.facade.struct.AuditPlanSearchResultList;
import curam.core.facade.struct.AuditPlanSearchResults;
import curam.core.facade.struct.AuditPlanSummaryFindings;
import curam.core.facade.struct.AuditPlanTabDetails;
import curam.core.facade.struct.AuditPlanTabXML;
import curam.core.facade.struct.BIReportDetails;
import curam.core.facade.struct.CaseAuditListPageName;
import curam.core.facade.struct.CodeTableName;
import curam.core.facade.struct.ConfigIDTypeAndName;
import curam.core.facade.struct.ConfigIDTypeAndNameList;
import curam.core.facade.struct.ConfiguredTypesAndCoordinator;
import curam.core.facade.struct.CreateAuditPlanDetails;
import curam.core.facade.struct.ListItemsInCodeTable;
import curam.core.facade.struct.ProgressChartXML;
import curam.core.facade.struct.UserSearchDetails;
import curam.core.facade.struct.UserSearchKey;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.message.BPOAUDITPLANTAB;
import curam.message.FACADECASEAUDIT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeMap;


/**
 * Facade Class for the AuditPlan implementation.
 *
 */
public abstract class AuditPlan extends curam.core.facade.base.AuditPlan {

  // BEGIN, CR00223475, ELG
  /**
   * BI report retrieval class *
   */
  @Inject
  protected BIHelper biHelper;

  // END, CR00223475

  /**
   * The Dynamic Menu node.
   */
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  /**
   * The Link (child) node.
   */
  protected static final String kItem = XmlMetaDataConst.kItem;

  /**
   * The page id attribute for a node.
   */
  protected static final String kPageID = XmlMetaDataConst.kPageID;

  /**
   * The audit plan homepage URL.
   */
  protected static final String kAuditPlanHome = UimConst.kAuditPlanHome;

  /**
   * The description attribute for a node.
   */
  protected static final String kDesc = XmlMetaDataConst.kDesc;

  /**
   * The type attribute for a node.
   */
  protected static final String kType = XmlMetaDataConst.kType;

  /**
   * The parameter attribute for a node.
   */
  protected static final String kParam = XmlMetaDataConst.kParam;

  /**
   * The name tag for a parameter.
   */
  protected static final String kName = XmlMetaDataConst.kName;

  /**
   * The value tag for a parameter.
   */
  protected static final String kValue = XmlMetaDataConst.kValue;

  /**
   * The audit plan node type.
   */
  protected static final String kTypeAuditPlan = XmlMetaDataConst.kTypeAuditPlan;

  /**
   * The audit plan ID parameter.
   */
  protected static final String kParamAuditPlanID = XmlMetaDataConst.kParamAuditPlanID;

  protected static final LocalisableString kAuditPlan = new LocalisableString(
    FACADECASEAUDIT.PAGE_DESC_AUDIT_PLAN);

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected AuditCaseConfigDAO auditCaseConfigDAO;

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected AuditorDAO auditorDAO;

  // BEGIN, CR00385977, KRK
  // Check the security roles are restricted for assignments.
  final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
    EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES,
    Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));

  // END, CR00385977

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public AuditPlan() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Wraps the user search in a filter for audit coordinator roles.
   *
   * @param key The user search criteria.
   *
   * @return A list of user records.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public UserSearchDetails auditCoordinatorSearch(final UserSearchKey key)
    throws AppException, InformationalException {

    final Organization organizationObj = OrganizationFactory.newInstance();

    // BEGIN, CR00385977, KRK
    if (isUserRoleRestricted) {
      key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
    }
    // END, CR00385977

    return organizationObj.userSearch(key);
  }

  // ___________________________________________________________________________
  /**
   * Cancels an Audit Plan.
   *
   * @param key Details of the Audit Plan to cancel
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void cancelAuditPlan(final AuditPlanAndVersionKey key)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    auditPlanObj.cancel(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Creates an Audit Plan.
   *
   * @param details Details of the Audit Plan to create
   *
   * @return unique id of the created audit plan
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AuditPlanKey createAuditPlan(final CreateAuditPlanDetails details)
    throws AppException, InformationalException {

    // Create the audit plan
    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.newInstance();

    auditPlanObj.setPurpose(AUDITPLANPURPOSEEntry.get(details.purpose));
    auditPlanObj.setPriority(AUDITPLANPRIORITYEntry.get(details.priority));
    auditPlanObj.setUserAccess(AUDITPLANUSERACCESSEntry.get(details.userAccess));
    auditPlanObj.setCoordinator(details.coordinator);
    auditPlanObj.setComments(details.comments);

    // Set the configuration
    final AuditCaseConfig auditCaseConfigObj = auditCaseConfigDAO.get(
      details.auditCaseConfigID);

    auditPlanObj.setAuditCaseConfig(auditCaseConfigObj);

    auditPlanObj.insert();

    // Return the newly created id
    final AuditPlanKey result = new AuditPlanKey();

    result.auditPlanID = auditPlanObj.getID();

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Removes the scheduling information from an audit plan.
   *
   * @param key The ID of the audit plan
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void deleteAuditPlanScheduleInfo(final AuditPlanAndVersionKey key)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.get(
      key.auditPlanID);

    auditPlan.removeSchedule(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Generates the context description for an audit plan.
   *
   * @param key Contains the audit plan identifier.
   *
   * @return Context description for the audit plan.
   */
  @Override
  public AuditContextDetails getAuditPlanContextDescription(
    final AuditPlanKey key) {

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    final LocalisableString description = new LocalisableString(
      FACADECASEAUDIT.INF_AUDIT_PLAN_DYNAMIC_MENU_DESCRIPTION);

    description.arg(kAuditPlan.getMessage());
    description.arg(auditPlanObj.getAuditPlanReference());

    final AuditContextDetails auditContextDetails = new AuditContextDetails();

    auditContextDetails.description = description.getMessage(
      TransactionInfo.getProgramLocale());
    return auditContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns list of all configured types that an audit plan can be created for.
   *
   * @return List of types that an audit plan can be created for
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ConfigIDTypeAndNameList getConfiguredTypes() throws AppException,
      InformationalException {

    final ConfigIDTypeAndNameList configIDTypeAndNameList = new ConfigIDTypeAndNameList();

    // Get the list of all available configurations
    final List<AuditCaseConfig> auditCaseConfigList = auditCaseConfigDAO.readAll();

    if (auditCaseConfigList.size() == 0) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        FACADECASEAUDIT.ERR_CASE_AUDIT_NO_CONFIGURATIONS_AVAILABLE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // Retrieve list of informational messages
      final String[] messages = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < messages.length; i++) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = messages[i];

        configIDTypeAndNameList.informationMsgTxt.dtls.addRef(
          informationalMsgDtls);
      }
    } else {
      for (final AuditCaseConfig auditCaseConfig : auditCaseConfigList) {

        final ConfigIDTypeAndName configIDTypeAndName = new ConfigIDTypeAndName();

        configIDTypeAndName.auditCaseConfigID = auditCaseConfig.getID();
        configIDTypeAndName.type = auditCaseConfig.getCaseCategory().getCode();
        configIDTypeAndName.name = curam.util.type.CodeTable.getOneItem(
          CASECATTYPECODE.TABLENAME,
          auditCaseConfig.getCaseCategory().getCode());

        configIDTypeAndNameList.list.addRef(configIDTypeAndName);
      }
    }
    return configIDTypeAndNameList;
  }

  // ___________________________________________________________________________
  /**
   * Returns list of all configured audit case types and the potential
   * coordinator.
   *
   * @return all configured audit case types and the potential
   * coordinator.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ConfiguredTypesAndCoordinator getConfiguredTypesAndCoordinator()
    throws AppException, InformationalException {

    // User manipulation variables
    final UsersKey usersKey = new UsersKey();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final ConfiguredTypesAndCoordinator configuredTypesAndCoordinator = new ConfiguredTypesAndCoordinator();
    ConfigIDTypeAndNameList configIDTypeAndNameList = new ConfigIDTypeAndNameList();

    // Default the coordinator to the user creating the audit plan
    usersKey.userName = userAccessObj.getUserDetails().userName;
    configuredTypesAndCoordinator.coordinatorUserName = usersKey.userName;
    configuredTypesAndCoordinator.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

    configIDTypeAndNameList = getConfiguredTypes();

    configuredTypesAndCoordinator.configList.assign(configIDTypeAndNameList);

    return configuredTypesAndCoordinator;
  }

  // ___________________________________________________________________________
  /**
   * Returns list all active audit plans where the logged in user is the audit
   * plan coordinator.
   *
   * @return The list of audit plans
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AuditPlanDetailsList listActiveAuditPlansForUser()
    throws AppException, InformationalException {

    final AuditPlanDetailsList auditPlanDetailsList = new AuditPlanDetailsList();
    AuditPlanDetails auditPlanDetails;
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final String currentUser = userAccessObj.getUserDetails().userName;

    // Get all active audit plans where the current user is the coordinator
    final SortedSet<curam.caseaudit.impl.AuditPlan> auditPlanList = auditPlanDAO.searchByRecordStatusAndCoordinator(
      RECORDSTATUSEntry.NORMAL, currentUser);

    for (final curam.caseaudit.impl.AuditPlan auditPlan : auditPlanList) {

      auditPlanDetails = new AuditPlanDetails();
      auditPlanDetails.auditPlanDtls.auditPlanID = auditPlan.getID();
      auditPlanDetails.auditPlanDtls.auditPlanReference = auditPlan.getAuditPlanReference();
      auditPlanDetails.type = curam.util.type.CodeTable.getOneItem(
        CASECATTYPECODE.TABLENAME,
        auditPlan.getAuditCaseConfig().getCaseCategory().getCode());
      auditPlanDetails.auditPlanDtls.purpose = auditPlan.getPurpose().getCode();
      auditPlanDetails.auditPlanDtls.auditPlanStatus = auditPlan.getLifecycleState().getCode();
      auditPlanDetails.auditPlanDtls.scheduledStartDate = auditPlan.getScheduledStartDate();
      auditPlanDetailsList.list.addRef(auditPlanDetails);
    }

    return auditPlanDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Maintains the schedule details of an audit plan.
   *
   * @param details The new schedule detailS for the audit plan
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void maintainAuditPlanScheduleDetails(
    final AuditPlanScheduleDetails details) throws AppException,
      InformationalException {

    final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.get(
      details.auditPlanID);

    auditPlan.setSchedule(details.scheduledStartDate, details.scheduledEndDate);
    auditPlan.setScheduleComments(details.scheduleComments);

    auditPlan.modify(details.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Modifies an Audit Plan.
   *
   * @param details Details of the modified Audit Plan
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void modifyAuditPlan(final AuditPlanDetails details)
    throws AppException, InformationalException {

    // Ensure the audit plan is in the correct state before
    // allowing modification of Purpose or User Involvement
    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      details.auditPlanDtls.auditPlanID);

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final String currentUser = userAccessObj.getUserDetails().userName;

    // Ensure that the modifier is the coordinator
    if (!auditPlanObj.getCoordinator().equals(currentUser)) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_AUDIT_PLAN_XRV_CANNOT_MODIFY_AUDIT_PLAN_INVALID_USER),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    } else {

      auditPlanObj.setComments(details.auditPlanDtls.comments);
      auditPlanObj.setPriority(
        AUDITPLANPRIORITYEntry.get(details.auditPlanDtls.priority));
      auditPlanObj.setPurpose(
        AUDITPLANPURPOSEEntry.get(details.auditPlanDtls.purpose));
      auditPlanObj.setUserAccess(
        AUDITPLANUSERACCESSEntry.get(details.auditPlanDtls.userAccess));

      auditPlanObj.modify(details.auditPlanDtls.versionNo);
    }
  }

  // ___________________________________________________________________________
  /**
   * Changes the Coordinator of an Audit Plan.
   *
   * @param details Details of the Audit Plan to modify
   *
   * @return unique id of the modified audit plan
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AuditPlanKey modifyCoordinator(final AuditPlanDetails details)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      details.auditPlanDtls.auditPlanID);

    // ensure the user has coordinator permissions
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = userAccessObj.getUserDetails().userName;
    final String roleName = userAccessObj.getUserDetails(usersKey).roleName;

    // BEGIN, CR00385977, KRK
    if (isUserRoleRestricted) {
      if (CaseAuditConst.kCoordinatorUserRoleName.equals(roleName)) {

        auditPlanObj.changeCoordinator(details.auditPlanDtls.versionNo,
          details.auditPlanDtls.coordinator);

      } else {
        ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(FACADECASEAUDIT.ERR_MODIFY_COORD_NO_ACCESS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          ValidationManagerConst.kSetOne, 0);

        TransactionInfo.getInformationalManager().failOperation();

      }
    } else {
      auditPlanObj.changeCoordinator(details.auditPlanDtls.versionNo,
        details.auditPlanDtls.coordinator);
    }
    // END, CR00385977

    final AuditPlanKey auditPlanKey = new AuditPlanKey();

    auditPlanKey.auditPlanID = details.auditPlanDtls.auditPlanID;
    return auditPlanKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the schedule details for an audit plan.
   *
   * @param key The ID of the audit plan
   *
   * @return schedule details for the audit plan
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AuditPlanScheduleDetails readAuditPlanScheduleDetails(
    final AuditPlanKey key) throws AppException, InformationalException {

    final AuditPlanScheduleDetails auditPlanScheduleDetails = new AuditPlanScheduleDetails();

    final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.get(
      key.auditPlanID);

    auditPlanScheduleDetails.auditPlanID = key.auditPlanID;

    auditPlanScheduleDetails.auditPlanReference = auditPlan.getAuditPlanReference();

    auditPlanScheduleDetails.scheduledStartDate = auditPlan.getScheduledStartDate();
    auditPlanScheduleDetails.scheduledEndDate = auditPlan.getScheduledEndDate();
    auditPlanScheduleDetails.scheduleComments = auditPlan.getScheduleComments();

    auditPlanScheduleDetails.versionNo = auditPlan.getVersionNo();

    return auditPlanScheduleDetails;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Returns list of audit plans that match search criteria.
   *
   * @param key
   * Values for searching for audit plans
   *
   * @return List of audit plan details for display
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link AuditPlan#searchAuditPlanDetails(AuditPlanSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchAuditPlanDetails(AuditPlanSearchKey) which
   * returns the informational message along with audit plan details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public AuditPlanSearchResultList searchAuditPlan(
    final AuditPlanSearchKey key) throws AppException, InformationalException {

    // END, CR00290965

    final AuditPlanSearchResultList auditPlanSearchResultList = new AuditPlanSearchResultList();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // BEGIN, AF
    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    // END

    if (!StringHelper.isEmpty(key.auditPlanReference)) {

      // Read the record directly
      final AuditPlanSearchResult auditPlanSearchResult = new AuditPlanSearchResult();

      final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.readByAuditPlanReference(
        key.auditPlanReference);

      // If no search results are found, alert user
      if (auditPlan != null) {

        usersKey.userName = auditPlan.getCoordinator();
        auditPlanSearchResult.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;
        // BEGIN, AF
        if (usersKey.userName.equals(TransactionInfo.getProgramUser())) {
          auditPlanSearchResult.isAuditPlanCoordinator = true;
        }
        // END

        auditPlanSearchResult.auditPlanID = auditPlan.getID();
        auditPlanSearchResult.auditPlanReference = auditPlan.getAuditPlanReference();
        auditPlanSearchResult.purpose = auditPlan.getPurpose().getCode();
        auditPlanSearchResult.scheduledStartDate = auditPlan.getScheduledStartDate();
        auditPlanSearchResult.status = auditPlan.getLifecycleState().getCode();
        auditPlanSearchResult.type = curam.util.type.CodeTable.getOneItem(
          CASECATTYPECODE.TABLENAME,
          auditPlan.getAuditCaseConfig().getCaseCategory().getCode());

        auditPlanSearchResultList.dtlsList.addRef(auditPlanSearchResult);

      } else {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOAUDITPLANDAO.INF_AUDIT_PLAN_SEARCH_NO_MATCH),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            2);
      }
    } else {

      final SortedSet<curam.caseaudit.impl.AuditPlan> auditPlans = auditPlanDAO.search(
        key.coordinator, CASECATTYPECODEEntry.get(key.type),
        AUDITPLANSTATUSEntry.get(key.status), key.activeOnlyInd);

      for (final curam.caseaudit.impl.AuditPlan auditPlan : auditPlans) {

        final AuditPlanSearchResult auditPlanSearchResult = new AuditPlanSearchResult();

        usersKey.userName = auditPlan.getCoordinator();
        auditPlanSearchResult.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;
        // BEGIN, AF
        if (usersKey.userName.equals(TransactionInfo.getProgramUser())) {
          auditPlanSearchResult.isAuditPlanCoordinator = true;
        }
        // END

        auditPlanSearchResult.auditPlanID = auditPlan.getID();
        auditPlanSearchResult.auditPlanReference = auditPlan.getAuditPlanReference();
        auditPlanSearchResult.purpose = auditPlan.getPurpose().getCode();
        auditPlanSearchResult.scheduledStartDate = auditPlan.getScheduledStartDate();
        auditPlanSearchResult.status = auditPlan.getLifecycleState().getCode();
        auditPlanSearchResult.type = curam.util.type.CodeTable.getOneItem(
          CASECATTYPECODE.TABLENAME,
          auditPlan.getAuditCaseConfig().getCaseCategory().getCode());

        auditPlanSearchResultList.dtlsList.addRef(auditPlanSearchResult);
      }
    }

    return auditPlanSearchResultList;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details of a specific Audit Plan.
   *
   * @param key The unique identifier of the Audit Plan record
   *
   * @return The audit plan home details
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AuditPlanHomeDetails viewAuditPlan(final AuditPlanKey key)
    throws AppException, InformationalException {

    // User manipulation variables
    final UsersKey usersKey = new UsersKey();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final AuditPlanHomeDetails auditPlanHomeDetails = new AuditPlanHomeDetails();

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    auditPlanHomeDetails.auditPlanDtls.auditPlanID = auditPlanObj.getID();
    auditPlanHomeDetails.auditPlanDtls.auditPlanReference = auditPlanObj.getAuditPlanReference();
    auditPlanHomeDetails.auditPlanDtls.auditPlanStatus = auditPlanObj.getLifecycleState().getCode();
    auditPlanHomeDetails.auditPlanDtls.createdDate = auditPlanObj.getCreatedDate();
    auditPlanHomeDetails.auditPlanDtls.priority = auditPlanObj.getPriority().getCode();
    auditPlanHomeDetails.auditPlanDtls.purpose = auditPlanObj.getPurpose().getCode();
    auditPlanHomeDetails.auditPlanDtls.recordStatus = auditPlanObj.getRecordStatus().getCode();
    auditPlanHomeDetails.auditPlanDtls.userAccess = auditPlanObj.getUserAccess().getCode();
    auditPlanHomeDetails.auditPlanDtls.comments = auditPlanObj.getComments();
    auditPlanHomeDetails.auditPlanDtls.scheduledStartDate = auditPlanObj.getScheduledStartDate();
    auditPlanHomeDetails.auditPlanDtls.scheduledEndDate = auditPlanObj.getScheduledEndDate();
    auditPlanHomeDetails.auditPlanDtls.scheduleComments = auditPlanObj.getScheduleComments();
    auditPlanHomeDetails.auditPlanDtls.casesUserSelected = auditPlanObj.areCasesUserSelected();
    auditPlanHomeDetails.auditPlanDtls.numberCases = auditPlanObj.getNumberCases();
    auditPlanHomeDetails.auditPlanDtls.percentageCases = auditPlanObj.getPercentageCases();
    auditPlanHomeDetails.auditPlanDtls.coordinator = auditPlanObj.getCoordinator();
    auditPlanHomeDetails.auditPlanDtls.createdBy = auditPlanObj.getCreatedBy();

    usersKey.userName = auditPlanObj.getCoordinator();
    auditPlanHomeDetails.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

    usersKey.userName = auditPlanObj.getCreatedBy();
    auditPlanHomeDetails.createdByFullName = userAccessObj.getFullName(usersKey).fullname;

    auditPlanHomeDetails.auditPlanDtls.versionNo = auditPlanObj.getVersionNo();

    if (auditPlanHomeDetails.auditPlanDtls.scheduledStartDate.equals(
      Date.kZeroDate)
        && auditPlanHomeDetails.auditPlanDtls.scheduledEndDate.equals(
          Date.kZeroDate)
          && StringHelper.isEmpty(
            auditPlanHomeDetails.auditPlanDtls.scheduleComments)) {
      auditPlanHomeDetails.scheduleInfoSetInd = false;
    } else {
      auditPlanHomeDetails.scheduleInfoSetInd = true;
    }

    if (auditPlanObj.getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)) {
      // BEGIN, CR00219367, GD
      // Only show schedule delete indicator if a schedule has been entered
      if (auditPlanHomeDetails.scheduleInfoSetInd) {
        auditPlanHomeDetails.allowScheduleDeleteInd = true;
      }
      // END, CR00219367
    } else {
      auditPlanHomeDetails.allowScheduleDeleteInd = false;
    }

    // Check if summary findings have been added
    if (auditPlanObj.areSummaryFindingsEntered()) {
      auditPlanHomeDetails.showAddSumFindingsLinkInd = false;
    } else {
      auditPlanHomeDetails.showAddSumFindingsLinkInd = true;
    }

    // Check if the audit plan is complete
    if (auditPlanObj.getLifecycleState().equals(AUDITPLANSTATUSEntry.COMPLETE)) {
      auditPlanHomeDetails.auditPlanCompleteInd = true;
    } else {
      auditPlanHomeDetails.auditPlanCompleteInd = false;
    }

    // Do not display modify findings option if plan is complete
    if (auditPlanHomeDetails.auditPlanCompleteInd) {
      auditPlanHomeDetails.showEditSumFindingsInd = false;
    } else if (!auditPlanHomeDetails.auditPlanCompleteInd
      && !auditPlanHomeDetails.showAddSumFindingsLinkInd) {

      auditPlanHomeDetails.showEditSumFindingsInd = true;
    }

    // Check if all case audits are completed and summary findings added
    if (auditPlanObj.areSummaryFindingsEntered()
      && auditPlanObj.areAllCaseAuditsComplete()
      && !auditPlanHomeDetails.auditPlanCompleteInd) {

      auditPlanHomeDetails.showCompleteLinkInd = true;
    } else {
      auditPlanHomeDetails.showCompleteLinkInd = false;
    }

    // Dynamically display random and manual selection links
    if (auditPlanObj.getCaseAudits().isEmpty()) {

      auditPlanHomeDetails.showGenerateRandomInd = true;

      if (auditPlanObj.getAuditCaseConfig().isManualCaseSelectionAllowed()) {
        auditPlanHomeDetails.showManualSelectionInd = true;
      }
    }

    auditPlanHomeDetails.type = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME,
      auditPlanObj.getAuditCaseConfig().getCaseCategory().getCode());

    return auditPlanHomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns details of the focus areas on an Audit Plan for displaying as a
   * chart.
   *
   * @param key The unique identifier of the Audit Plan record
   *
   * @return The audit plan focus area chart
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public BIReportDetails getAuditPlanFocusAreaChart(final AuditPlanKey key)
    throws AppException, InformationalException {

    // Return structure
    final BIReportDetails reportDetails = new BIReportDetails();

    // Calculate number of cases to be audited
    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    final int numberOfCaseAudits = auditPlanObj.getCaseAudits().size();

    // BEGIN, CR00223475, ELG
    final Map<String, String> reportParameters = new HashMap<String, String>();

    reportParameters.put(CuramConst.gkParam_CA_auditPlanID,
      String.valueOf(key.auditPlanID));
    reportParameters.put(CuramConst.gkParam_CA_caseAuditSize,
      String.valueOf(numberOfCaseAudits));

    final String reportData = biHelper.getReportDataXML(
      CuramConst.gkAuditPlanFocusAreaReportName, reportParameters);

    reportDetails.report = reportData;
    // END, CR00223475

    return reportDetails;
  }

  // __________________________________________________________________________
  /**
   * Returns the XML data needed to render up a chart of the audit plan
   * progress details.
   *
   * @param auditPlanKey The unique identifier for the audit plan.
   *
   * @return String of chart data
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  protected ProgressChartXML getAuditPlanProgressDetails(
    final AuditPlanKey auditPlanKey) throws AppException,
      InformationalException {

    final ProgressChartXML progressChartXML = new ProgressChartXML();

    final curam.core.facade.intf.System systemObj = curam.core.facade.fact.SystemFactory.newInstance();

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      auditPlanKey.auditPlanID);

    final CodeTableName tableName = new CodeTableName();

    tableName.name = CASEAUDITSTATUS.TABLENAME;

    // Get all of the items from the Case Audit Status code table
    final ListItemsInCodeTable caseAuditStatusList = systemObj.listItemsInCodeTable(
      tableName);

    final Map<String, String> caseAuditStatusMap = new TreeMap<String, String>();

    // Initialize default chart data settings.
    for (int i = 0; i < caseAuditStatusList.codeTableItemDetails.size(); i++) {

      caseAuditStatusMap.put(
        caseAuditStatusList.codeTableItemDetails.item(i).description, "0");
    }

    // Update initial default chart data settings
    final Set<curam.caseaudit.impl.CaseAudit> caseAuditSet = caseAuditDAO.searchByAuditPlan(
      auditPlanObj);

    for (int j = 0; j < caseAuditStatusList.codeTableItemDetails.size(); j++) {

      int numRecords = 0;
      String caseAuditStatusDesc = new String();

      caseAuditStatusDesc = caseAuditStatusList.codeTableItemDetails.item(j).description;

      for (final CaseAudit caseAudit : caseAuditSet) {

        if (caseAudit.getLifecycleState().getCode().equals(
          caseAuditStatusList.codeTableItemDetails.item(j).code)) {

          numRecords++;
        }
      }

      // Override default setting for each case status if case audits have
      // been added to the plan
      if (numRecords != 0) {
        caseAuditStatusMap.put(caseAuditStatusDesc, String.valueOf(numRecords));
      }
    }

    // Instance of helper class to build the XML
    final XMLBuilder xmlBuilder = new XMLBuilder("chart");

    xmlBuilder.addAttribute("name", CaseAuditConst.kProgressChart);
    xmlBuilder.addAttribute("style", "bar-chart-view");
    xmlBuilder.addAttribute("width", "100%");
    xmlBuilder.addAttribute("height", "240px");
    xmlBuilder.addAttribute("xLabel", CaseAuditConst.kNumberOfCaseAudits);
    xmlBuilder.addAttribute("yLabel", "");

    // Integer object needed for string conversion
    Integer index = 0;

    // Build XML element for each case audit status
    for (final String key : caseAuditStatusMap.keySet()) {

      xmlBuilder.createTag("unit");

      xmlBuilder.createTag("caption");
      xmlBuilder.addAttribute("text", key);
      xmlBuilder.closeTag();

      xmlBuilder.createTag("block");
      xmlBuilder.addAttribute("id", index.toString());
      xmlBuilder.addAttribute("type", key);
      xmlBuilder.addAttribute("length", caseAuditStatusMap.get(key));
      xmlBuilder.closeTag();

      xmlBuilder.closeTag();

      index++;
    }

    xmlBuilder.closeTag();

    // Return the xml in the format required for passing to the client
    progressChartXML.progressChart = xmlBuilder.getXmlString();
    return progressChartXML;
  }

  // ___________________________________________________________________________
  /**
   * Manually completes an Audit Plan.
   *
   * @param key The unique identifier of the Audit Plan record.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void completeAuditPlan(final AuditPlanAndVersionKey key)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    auditPlanObj.complete(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Modifies the findings on an audit plan.
   *
   * @param details Details of the modified findings
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void modifyAuditPlanFindings(final AuditPlanModifySumFindings details)
    throws AppException, InformationalException {

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      details.auditPlanID);

    // BEGIN, CR00221556, GD
    auditPlanObj.setSummaryFindings(details.findingsText);
    // END, CR00221556

    auditPlanObj.modify(details.versionNo);

  }

  // ___________________________________________________________________________
  /**
   * Returns the findings for an audit plan.
   *
   * @param key The unique identifier of the Audit Plan record
   * @return the audit plan findings
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AuditPlanSummaryFindings readAuditPlanFindings(final AuditPlanKey key) throws AppException,
      InformationalException {

    // return struct
    final AuditPlanSummaryFindings auditPlanSummaryFindings = new AuditPlanSummaryFindings();

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    auditPlanSummaryFindings.auditPlanID = auditPlanObj.getID();
    auditPlanSummaryFindings.versionNo = auditPlanObj.getVersionNo();
    auditPlanSummaryFindings.auditPlanReference = auditPlanObj.getAuditPlanReference();

    // BEGIN, CR00221556, GD
    auditPlanSummaryFindings.findingsText = auditPlanObj.getSummaryFindings();

    if (StringHelper.isEmpty(auditPlanSummaryFindings.findingsText)) {
      auditPlanSummaryFindings.noFindingsYetInd = true;
    } else {
      auditPlanSummaryFindings.noFindingsYetInd = false;
    }
    // END, CR00221556

    return auditPlanSummaryFindings;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the correct the case audit list page the user should be redirected
   * to. The user will be directed to two different pages depending on whether
   * or not the case sample was generated randomly or manually.
   *
   * @param key the unique identifier of the audit plan.
   *
   * @return the case audit list page name
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseAuditListPageName resolveCaseAuditList(final AuditPlanKey key)
    throws AppException, InformationalException {

    final CaseAuditListPageName caseAuditListPageName = new CaseAuditListPageName();

    final curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    if (auditPlanObj.areCasesUserSelected()) {
      caseAuditListPageName.pageName = UimConst.kManualCaseAuditListPage;
    } else {
      caseAuditListPageName.pageName = UimConst.kRandomCaseAuditListPage;
    }

    return caseAuditListPageName;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the tab details for an audit plan.
   *
   * @param key The audit plan unique identifier
   *
   * @return The audit plan tab details
   */
  @Override
  public AuditPlanTabXML readAuditPlanTabDetails(final AuditPlanKey key)
    throws AppException, InformationalException {

    final AuditPlanTabXML auditPlanTabXML = new AuditPlanTabXML();
    final AuditPlanTabDetails auditPlanTabDetails = new AuditPlanTabDetails();

    final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.get(
      key.auditPlanID);

    auditPlanTabDetails.auditPlanRef = auditPlan.getAuditPlanReference();
    auditPlanTabDetails.auditPlanID = key.auditPlanID;
    auditPlanTabDetails.auditStartDate = auditPlan.getScheduledStartDate();
    auditPlanTabDetails.auditEndDate = auditPlan.getScheduledEndDate();
    auditPlanTabDetails.coordinator = auditPlan.getCoordinator();
    auditPlanTabDetails.userAccess = auditPlan.getUserAccess().getCode();
    auditPlanTabDetails.auditItem = curam.util.type.CodeTable.getOneItem(
      CASECATTYPECODE.TABLENAME,
      auditPlan.getAuditCaseConfig().getCaseCategory().getCode());

    auditPlanTabDetails.auditPlanStatus = auditPlan.getLifecycleState().getCode();

    // BEGIN, CR00290965, IBM
    final FocusAreaStatsList focusAreaList = auditPlan.listFocusAreaStatsCount();

    // END, CR00290965

    auditPlanTabDetails.numFocusAreas = focusAreaList.dtls.size();

    final List<curam.caseaudit.impl.Auditor> auditorList = auditorDAO.searchByAuditPlan(
      auditPlan);

    auditPlanTabDetails.numAuditors = auditorList.size();

    // Create container panel
    final ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditContainerPanel);

    final ContentPanelBuilder auditPlanDetails = getAuditPlanDetails(
      auditPlanTabDetails);

    if (auditPlan.getLifecycleState().equals(AUDITPLANSTATUSEntry.COMPLETE)) {
      final LocalisableString complete = new LocalisableString(
        BPOAUDITPLANTAB.INF_COMPLETE);

      auditPlanDetails.addlocalisableStringItem(
        complete.toClientFormattedText(), CuramConst.gkWaterMark);
    }

    containerPanel.addWidgetItem(auditPlanDetails, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CuramConst.gkCaseAuditContentPanel);

    if (auditPlan.getCaseAudits().size() != 0) {

      final ContentPanelBuilder chartPanel = getAuditPlanProgressGraph(
        key.auditPlanID);

      // Add the right panel to the border container
      containerPanel.addWidgetItem(chartPanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CuramConst.gkCaseAuditReportContent);

    } else {

      final ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
        CuramConst.gkCaseAuditReportDetails);

      contentPanelBuilder.addRoundedCorners();

      contentPanelBuilder.addlocalisableStringItem(
        new LocalisableString(BPOAUDITPLANTAB.INF_NO_REPORT).toClientFormattedText(),
        CuramConst.gkCaseAuditNoReport);

      // Add the right panel to the border container
      containerPanel.addWidgetItem(contentPanelBuilder, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CuramConst.gkCaseAuditReportContent);
    }

    auditPlanTabXML.xmlPanelData = containerPanel.toString();

    final LocalisableString description = new LocalisableString(
      BPOAUDITPLANTAB.INF_AUDIT_PLAN_LABEL);

    description.arg(auditPlan.getAuditPlanReference());

    auditPlanTabXML.description = description.getMessage(
      TransactionInfo.getProgramLocale());

    return auditPlanTabXML;
  }

  // ___________________________________________________________________________
  /**
   * Format XML data for audit plan tab details.
   *
   * @param details
   * Audit Plan details.
   *
   * @return ContentPanelBuilder.
   */
  protected ContentPanelBuilder getAuditPlanDetails(
    final AuditPlanTabDetails details) throws AppException,
      InformationalException {

    final ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditTabDetails);

    contentPanelBuilder.addRoundedCorners();

    final ContentPanelBuilder auditPlanDetail = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditDetails);

    // Add the audit plan reference
    final String auditPlan = new LocalisableString(BPOAUDITPLANTAB.INF_AUDIT_PLAN_LABEL).toClientFormattedText();

    auditPlanDetail.addlocalisableStringItem(auditPlan,
      CuramConst.gkCaseAuditPlanRef);
    auditPlanDetail.addStringItem(String.valueOf(details.auditPlanRef),
      CuramConst.gkCaseAuditRefID);

    final ListBuilder auditPlanList = ListBuilder.createHorizontalList(2);

    auditPlanList.addRow();

    // Add the audit item

    // BEGIN, CR00230776, BD
    auditPlanList.addEntry(1, 1,
      new LocalisableString(BPOAUDITPLANTAB.INF_AUDIT_ITEM_LABEL));

    final CodeTableItemEntry caseType = DocBuilderHelperFactory.getCodeTableItemEntry(
      details.auditItem, CuramConst.gkDomainAuditItem);

    auditPlanList.addEntry(2, 1, caseType);

    auditPlanList.addRow();

    // Add the user involvement
    auditPlanList.addEntry(1, 2,
      new LocalisableString(BPOAUDITPLANTAB.INF_USER_ACCESS_LABEL));

    final CodeTableItemEntry userAccess = DocBuilderHelperFactory.getCodeTableItemEntry(
      details.userAccess, CuramConst.gkDomainAuditPlanUserAccess);

    auditPlanList.addEntry(2, 2, userAccess);

    auditPlanList.addRow();

    // Add the coordinator
    auditPlanList.addEntry(1, 3,
      new LocalisableString(BPOAUDITPLANTAB.INF_COORDINATOR_LABEL));

    final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = details.coordinator;

    final String coordinatorFullName = tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

    final String coordinator = new LocalisableString(BPOAUDITPLANTAB.INF_COORDINATOR).arg(coordinatorFullName).toClientFormattedText();

    final LinkBuilder coordLinkBuilder = LinkBuilder.createLocalizableLink(
      coordinator, CuramConst.gkUserDetailsPage);

    coordLinkBuilder.openAsModal();
    coordLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      details.coordinator);

    final LocalisableString coordinatorTitle = new LocalisableString(
      BPOAUDITPLANTAB.INF_COORDINATOR_TITLE);

    coordLinkBuilder.addLinkTitle(coordinatorTitle);

    final RendererConfig linkRendererConfig = new RendererConfig(
      RendererConfigType.STYLE, CuramConst.gkLink);

    auditPlanList.addEntry(2, 3, coordLinkBuilder, linkRendererConfig);

    auditPlanList.addRow();

    // Add a link to the number of auditors
    auditPlanList.addEntry(1, 4,
      new LocalisableString(BPOAUDITPLANTAB.INF_NUM_AUDITORS_LABEL));

    final String numAuditors = new LocalisableString(BPOAUDITPLANTAB.INF_NUM_AUDITORS).arg(details.numAuditors).toClientFormattedText();

    final LinkBuilder numAuditorsLinkBuilder = LinkBuilder.createLocalizableLink(
      numAuditors, CuramConst.gkListAuditorsPage);

    numAuditorsLinkBuilder.addParameter(CuramConst.gkPageParameterAuditPlanID,
      String.valueOf(details.auditPlanID));
    final LocalisableString numAuditorsTitle = new LocalisableString(
      BPOAUDITPLANTAB.INF_AUDITORS_TITLE);

    numAuditorsLinkBuilder.addLinkTitle(numAuditorsTitle);

    auditPlanList.addEntry(2, 4, numAuditorsLinkBuilder, linkRendererConfig);

    auditPlanDetail.addSingleListItem(auditPlanList,
      CuramConst.gkCaseAuditDetailsTable);

    final ListBuilder auditPlanList2 = ListBuilder.createHorizontalList(2);

    auditPlanList2.addRow();

    // Add the audit start date
    auditPlanList2.addEntry(1, 1,
      new LocalisableString(BPOAUDITPLANTAB.INF_START_DATE_LABEL));
    auditPlanList2.addEntry(2, 1, details.auditStartDate);

    auditPlanList2.addRow();

    // Add the audit end date
    auditPlanList2.addEntry(1, 2,
      new LocalisableString(BPOAUDITPLANTAB.INF_END_DATE_LABEL));
    auditPlanList2.addEntry(2, 2, details.auditEndDate);

    auditPlanList2.addRow();

    // Add a link to the number of focus areas
    auditPlanList2.addEntry(1, 3,
      new LocalisableString(BPOAUDITPLANTAB.INF_NUM_FOCUS_AREAS_LABEL));

    final String numFocusAreas = new LocalisableString(BPOAUDITPLANTAB.INF_NUM_FOCUS_AREAS).arg(details.numFocusAreas).toClientFormattedText();

    final LinkBuilder numFocusAreasLinkBuilder = LinkBuilder.createLocalizableLink(
      numFocusAreas, CuramConst.gkListFocusAreasPage);

    numFocusAreasLinkBuilder.addParameter(CuramConst.gkPageParameterAuditPlanID,
      String.valueOf(details.auditPlanID));
    final LocalisableString focusAreasTitle = new LocalisableString(
      BPOAUDITPLANTAB.INF_FOCUSAREAS_TITLE);

    numFocusAreasLinkBuilder.addLinkTitle(focusAreasTitle);

    auditPlanList2.addEntry(2, 3, numFocusAreasLinkBuilder, linkRendererConfig);

    auditPlanDetail.addSingleListItem(auditPlanList2,
      CuramConst.gkCaseAuditDetailsTable2);

    contentPanelBuilder.addWidgetItem(auditPlanDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    final ContentPanelBuilder extraDetailsContent = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditExtraDetailContent);

    final ContentPanelBuilder extraDetailsContentDetail = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditExtraDetailContentDetail);

    if (!details.auditPlanStatus.equals(AUDITPLANSTATUSEntry.COMPLETE.getCode())) {

      if (!details.auditEndDate.isZero()) {

        int numDays = 0;

        if (details.auditEndDate.before(Date.getCurrentDate())) {

          final DateRange dateRange = new DateRange(details.auditEndDate,
            Date.getCurrentDate());

          if (dateRange.isValidRange()) {
            numDays = dateRange.length();
          }

          final ImageBuilder endDatePassedImageBuilder = ImageBuilder.createImage(
            CuramConst.gkIconAtTimeLimitBlue, CuramConst.gkEmpty);

          endDatePassedImageBuilder.setImageResource(
            CuramConst.gkRendererImages);
          final String endDateAltText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

          endDatePassedImageBuilder.setImageAltText(endDateAltText);

          extraDetailsContentDetail.addImageItem(endDatePassedImageBuilder);

          extraDetailsContentDetail.addlocalisableStringItem(
            new LocalisableString(BPOAUDITPLANTAB.INF_NUM_DAYS_EXCEEDED_BY).arg(numDays).toClientFormattedText(),
            CuramConst.gkScheduleDetail);

        } else if (details.auditEndDate.after(Date.getCurrentDate())) {

          final DateRange dateRange = new DateRange(Date.getCurrentDate(),
            details.auditEndDate);

          if (dateRange.isValidRange()) {
            numDays = dateRange.length();
          }

          final ImageBuilder endDateApproachingImageBuilder = ImageBuilder.createImage(
            CuramConst.gkIconGoodTimeBlue, CuramConst.gkEmpty);

          endDateApproachingImageBuilder.setImageResource(
            CuramConst.gkRendererImages);

          final String daysToCompleteAltText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

          endDateApproachingImageBuilder.setImageAltText(daysToCompleteAltText);

          extraDetailsContentDetail.addImageItem(endDateApproachingImageBuilder);

          extraDetailsContentDetail.addlocalisableStringItem(
            new LocalisableString(BPOAUDITPLANTAB.INF_NUM_DAYS_TO_COMPLETE).arg(numDays).toClientFormattedText(),
            CuramConst.gkScheduleDetail);

        } else if (details.auditEndDate.equals(Date.getCurrentDate())) {

          final ImageBuilder endDateApproachingImageBuilder = ImageBuilder.createImage(
            CuramConst.gkIconGoodTimeBlue, CuramConst.gkEmpty);

          endDateApproachingImageBuilder.setImageResource(
            CuramConst.gkRendererImages);

          final String scheduledEndAltText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

          endDateApproachingImageBuilder.setImageAltText(scheduledEndAltText);

          extraDetailsContentDetail.addImageItem(endDateApproachingImageBuilder);

          extraDetailsContentDetail.addlocalisableStringItem(
            new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULED_TO_END_TODAY).toClientFormattedText(),
            CuramConst.gkScheduleDetail);
        }
      } else {

        final ImageBuilder endDatePassedImageBuilder = ImageBuilder.createImage(
          CuramConst.gkIconAttention, CuramConst.gkEmpty);

        endDatePassedImageBuilder.setImageResource(CuramConst.gkRendererImages);

        final String notScheduledText = new LocalisableString(BPOAUDITPLANTAB.INF_SCHEDULE).toClientFormattedText();

        endDatePassedImageBuilder.setImageAltText(notScheduledText);

        extraDetailsContentDetail.addImageItem(endDatePassedImageBuilder);

        extraDetailsContentDetail.addlocalisableStringItem(
          new LocalisableString(BPOAUDITPLANTAB.INF_NOT_SCHEDULED).toClientFormattedText(),
          CuramConst.gkScheduleDetail);
      }
    }

    extraDetailsContent.addWidgetItem(extraDetailsContentDetail,
      CuramConst.gkStyle, CuramConst.gkContentPanel);

    contentPanelBuilder.addWidgetItem(extraDetailsContent, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return contentPanelBuilder;
  }

  // ___________________________________________________________________________
  /**
   * Format XML data for an audit plan progress chart.
   *
   * @param auditPlanID
   * The unique identifier of the audit plan to report on.
   *
   * @return ContentPanelBuilder.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected ContentPanelBuilder getAuditPlanProgressGraph(
    final long auditPlanID) throws AppException, InformationalException {

    final ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkCaseAuditReportDetails);

    contentPanelBuilder.addRoundedCorners();

    // BEGIN, CR00223475, ELG
    final Map<String, String> reportParameters = new HashMap<String, String>();

    reportParameters.put(CuramConst.gkReportParameterAuditPlanID,
      String.valueOf(auditPlanID));
    reportParameters.put(CuramConst.gkReportParameterCaseAuditStatusTableName,
      CASEAUDITSTATUSEntry.TABLENAME);

    // BEGIN, CR00225043, GD
    final WidgetDocumentBuilder reportBuilder = biHelper.getDocumentBuilder(
      CuramConst.gkAuditPlanProgressChart, reportParameters);

    // END, CR00225043
    // END, CR00223475

    contentPanelBuilder.addWidgetItem(reportBuilder, CuramConst.gkStyle,
      CuramConst.gkStyleBirt);

    return contentPanelBuilder;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an audit plan details by provided search criteria.
   *
   * @param auditPlanSearchKey contains audit plan search key
   *
   * @return audit plan search details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AuditPlanSearchResults searchAuditPlanDetails(
    final AuditPlanSearchKey auditPlanSearchKey) throws AppException,
      InformationalException {

    final AuditPlanSearchResults auditPlanSearchResults = new AuditPlanSearchResults();

    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    if (!StringHelper.isEmpty(auditPlanSearchKey.auditPlanReference)) {

      final AuditPlanSearchResult auditPlanSearchResult = new AuditPlanSearchResult();

      final curam.caseaudit.impl.AuditPlan auditPlan = auditPlanDAO.readByAuditPlanReference(
        auditPlanSearchKey.auditPlanReference);

      // If no search results are found, alert user
      if (auditPlan != null) {

        usersKey.userName = auditPlan.getCoordinator();
        auditPlanSearchResult.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

        if (usersKey.userName.equals(TransactionInfo.getProgramUser())) {
          auditPlanSearchResult.isAuditPlanCoordinator = true;
        }

        auditPlanSearchResult.auditPlanID = auditPlan.getID();
        auditPlanSearchResult.auditPlanReference = auditPlan.getAuditPlanReference();
        auditPlanSearchResult.purpose = auditPlan.getPurpose().getCode();
        auditPlanSearchResult.scheduledStartDate = auditPlan.getScheduledStartDate();
        auditPlanSearchResult.status = auditPlan.getLifecycleState().getCode();
        auditPlanSearchResult.type = curam.util.type.CodeTable.getOneItem(
          CASECATTYPECODE.TABLENAME,
          auditPlan.getAuditCaseConfig().getCaseCategory().getCode());

        auditPlanSearchResults.dtlsList.addRef(auditPlanSearchResult);

      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOAUDITPLANDAO.INF_AUDIT_PLAN_SEARCH_NO_MATCH),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    } else {

      final SortedSet<curam.caseaudit.impl.AuditPlan> auditPlans = auditPlanDAO.search(
        auditPlanSearchKey.coordinator,
        CASECATTYPECODEEntry.get(auditPlanSearchKey.type),
        AUDITPLANSTATUSEntry.get(auditPlanSearchKey.status),
        auditPlanSearchKey.activeOnlyInd);

      for (final curam.caseaudit.impl.AuditPlan auditPlan : auditPlans) {

        final AuditPlanSearchResult auditPlanSearchResult = new AuditPlanSearchResult();

        usersKey.userName = auditPlan.getCoordinator();
        auditPlanSearchResult.coordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

        if (usersKey.userName.equals(TransactionInfo.getProgramUser())) {
          auditPlanSearchResult.isAuditPlanCoordinator = true;
        }

        auditPlanSearchResult.auditPlanID = auditPlan.getID();
        auditPlanSearchResult.auditPlanReference = auditPlan.getAuditPlanReference();
        auditPlanSearchResult.purpose = auditPlan.getPurpose().getCode();
        auditPlanSearchResult.scheduledStartDate = auditPlan.getScheduledStartDate();
        auditPlanSearchResult.status = auditPlan.getLifecycleState().getCode();
        auditPlanSearchResult.type = curam.util.type.CodeTable.getOneItem(
          CASECATTYPECODE.TABLENAME,
          auditPlan.getAuditCaseConfig().getCaseCategory().getCode());

        auditPlanSearchResults.dtlsList.addRef(auditPlanSearchResult);
      }
    }

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      auditPlanSearchResults.informationMsgTxt.dtls.addRef(informationalMsgDtls);
    }

    return auditPlanSearchResults;
  }
  // END, CR00290965
}
