/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008,2022. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.facade.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.codetable.ACTIONCONTROLID;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.CONTACTLOGPURPOSE;
import curam.codetable.CONTACTLOGTYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.contactlog.impl.ContactLogUtility;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.intf.Case;
import curam.core.facade.struct.AttachmentWizardDetails;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.facade.struct.ContactLogAttendeeByTypeList;
import curam.core.facade.struct.ContactLogCaseDetails;
import curam.core.facade.struct.ContactLogDetails;
import curam.core.facade.struct.ContactLogNarrativeDetails;
import curam.core.facade.struct.ContactLogNarrativeSearchKey;
import curam.core.facade.struct.ContactLogPreviewIDKey;
import curam.core.facade.struct.ContactLogPreviewKey;
import curam.core.facade.struct.ContactLogWizardDetails;
import curam.core.facade.struct.ContactLogWizardMenuDetails;
import curam.core.facade.struct.DefaultContactLogDetails;
import curam.core.facade.struct.NarrativeTextWizardDetails;
import curam.core.facade.struct.ParticipantWizardDetails;
import curam.core.facade.struct.PreviewCaseContactLogIDKey;
import curam.core.facade.struct.PreviewContactLogXMLDetails;
import curam.core.facade.struct.PurposeCode;
import curam.core.facade.struct.PurposeCodeList;
import curam.core.facade.struct.WizardDetails;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.NoteUtil;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.fact.ContactLogLinkFactory;
import curam.core.sl.entity.intf.ContactLogLink;
import curam.core.sl.entity.struct.ContactLogAttendeeKey;
import curam.core.sl.entity.struct.ContactLogDtls;
import curam.core.sl.entity.struct.ContactLogIDRecordStatusKey;
import curam.core.sl.entity.struct.ContactLogKey;
import curam.core.sl.entity.struct.LinkIDAndLinkTypeDtlsList;
import curam.core.sl.fact.ContactLogAttendeeFactory;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.ContactLogAttendee;
import curam.core.sl.struct.CancelContactLogAttendeeDetails;
import curam.core.sl.struct.CancelContactLogDetails;
import curam.core.sl.struct.ContactLogIDLinkTypeKey;
import curam.core.sl.struct.CreateContactLogAttendeeDetails;
import curam.core.sl.struct.CreateContactLogAttendeeDetails1;
import curam.core.sl.struct.ModifyContactLogDetails;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.PreviewContactLogKey1;
import curam.core.sl.struct.PreviewContactLogWidgetDetails;
import curam.core.sl.struct.PreviewContactLogXMLData;
import curam.core.sl.struct.PrintContactLogWizardDetails;
import curam.core.sl.struct.PrintPreviewCaseContactLogKey;
import curam.core.sl.struct.PrintPreviewContactLogFileDetails;
import curam.core.sl.struct.PrintPreviewContactLogKey;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.message.BPOCASEEVENTS;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.wizardpersistence.impl.WizardPersistentState;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.NullFragmenter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;

/**
 * This process class provides the functionality for the Contact Log facade
 * layer.
 */
public abstract class ContactLog extends curam.core.facade.base.ContactLog {

  /**
   * Static constant for {@code <c-o-n-t-e-n-t>} tag, which is the temporary
   * replacement for {@code <content>}.
   */
  protected static final String START_CONTENT_TAG_REPLACEMENT = "<c-o-n-t-e-n-t>";

  /**
   * Static constant for {@code <t-n-e-t-n-o-c>} tag, which is the temporary
   * replacement for {@code </content>}.
   */
  protected static final String END_CONTENT_TAG_REPLACEMENT = "<t-n-e-t-n-o-c>";

  /**
   * Static constant for {@code <content>} tag.
   */
  protected static final String START_CONTENT_TAG = "<content>";

  /**
   * Static constant for {@code </content>} tag.
   */
  protected static final String END_CONTENT_TAG = "</content>";

  /**
   * Static constant for {@code </note>} tag.
   */
  protected static final String END_NOTE_TAG = "</note>";

  /**
   * Static constant for {@code </author>} tag.
   */
  protected static final String END_AUTHOR_TAG = "</author>";

  /**
   * Static constant for "L-O-R-E-M".
   */
  protected static final String LOREM = "L-O-R-E-M";

  /**
   * AttachmentLinkDAO object.
   */
  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // BEGIN, CR00234804, PM
  /**
   * CaseTransactionLogIntf provider.
   */
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
  // END, CR00234804

  // BEGIN, CR00119940, ZV
  // Add injection for using the new API

  /**
   * ContactLog object.
   */
  protected final curam.core.sl.intf.ContactLog contactLogDatastore = ContactLogFactory
      .newInstance();

  /**
   * Constructor.
   */
  public ContactLog() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Method to add an Attachment to a Contact Log.
   *
   * @param details
   *          Contains the contact log id and attachment details
   *
   * @return The Attachment Link key
   */
  @Override
  public AttachmentLinkKey addContactLogAttachment(
      final AttachmentLinkDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00407868, SG
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseIDOpt;

    checkMaintainCaseSecurity(caseSecurityCheckKey);

    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = details.attachmentLinkDtls.participantRoleID;

    checkMaintainParticipantSecurity(participantSecurityCheckKey);
    // END, CR00407868

    final AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.CONTACTLOG;
    details.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

    // add contact log attachment
    attachmentLink.insert(details);

    // BEGIN, CR00241171, ZV
    // BEGIN, CR00234804, PM
    // Log Transaction Details.
    final ContactLogLink contactLogLinkObj = ContactLogLinkFactory
        .newInstance();
    final ContactLogIDRecordStatusKey contactLogIDRecordStatusKey = new ContactLogIDRecordStatusKey();

    contactLogIDRecordStatusKey.contactLogID = details.attachmentLinkDtls.relatedObjectID;
    final LinkIDAndLinkTypeDtlsList linkIDAndLinkTypeDtlsList = contactLogLinkObj
        .searchActiveLinkIDAndTypeByContactLogID(contactLogIDRecordStatusKey);

    for (int i = 0; i < linkIDAndLinkTypeDtlsList.dtls.size(); i++) {

      if (linkIDAndLinkTypeDtlsList.dtls.item(i).linkType
          .equals(CONTACTLOGLINKTYPE.CASE)) {

        final curam.core.sl.entity.intf.ContactLog contactLog = curam.core.sl.entity.fact.ContactLogFactory
            .newInstance();
        final ContactLogKey contactLogKey = new ContactLogKey();

        contactLogKey.contactLogID = details.attachmentLinkDtls.relatedObjectID;
        final ContactLogDtls contactLogDtls = contactLog.read(contactLogKey);

        final CodeTableItemIdentifier codeTableItemIdentifier = new CodeTableItemIdentifier(
            CONTACTLOGTYPE.TABLENAME, contactLogDtls.contactLogType);

        final LocalisableString description = new LocalisableString(
            BPOCASEEVENTS.CONTACT_ATTACHMENT_ADDED)
                .arg(codeTableItemIdentifier);

        caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.CONTACT_ATTACHMENT_ADDED, description,
            linkIDAndLinkTypeDtlsList.dtls.item(i).linkID,
            details.attachmentLinkDtls.attachmentLinkID);
      }

    }

    // END, CR00234804
    // END, CR00241171

    final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

    attachmentLinkKey.attachmentLinkID = attachmentLink.getID();

    return attachmentLinkKey;

  }

  // END, CR00119940

  // ___________________________________________________________________________
  /**
   * @param details
   *          Contains the contact log id and the attendee details
   *
   * @return The Contact Log Attendee key
   * @deprecated Since Curam 6.0, replaced by {@link #addContactLogAttendee1()}
   *
   *             Method to add an Attendee to a Contact Log. New method passes
   *             additional 'I am a Contact Participant' parameter to create
   *             Contact Log Attendee.
   */
  @Override
  @Deprecated
  public ContactLogAttendeeKey addContactLogAttendee(
      final CreateContactLogAttendeeDetails details)
      throws AppException, InformationalException {

    return ContactLogAttendeeFactory.newInstance().create(details);
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel a Contact Log.
   *
   * @param details
   *          Contains the Contact Log ID and version No
   */
  @Override
  public void cancelContactLog(final CancelContactLogDetails details)
      throws AppException, InformationalException {

    ContactLogFactory.newInstance().cancel(details);
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the Contact Log details.
   *
   * @param details
   *          Contains the contact log details to be updated
   */
  @Override
  public void modifyContactLog(final ModifyContactLogDetails details)
      throws AppException, InformationalException {

    ContactLogFactory.newInstance().modify1(details);
  }

  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains the contact log ID
   *
   * @return The Contact Log preview notes details
   * @deprecated Since Curam 6.0, replaced by {@link #previewContactLog1()}
   *
   *             Method to preview the Contact Log notes.
   */
  @Override
  @Deprecated
  public curam.core.sl.struct.PreviewContactLogDetails previewContactLog(
      final ContactLogKey key) throws AppException, InformationalException {

    return ContactLogFactory.newInstance().preview(key);
  }

  // BEGIN, CR00120432, ZV
  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains a list of contact log IDs and action control id
   *
   * @return The list of Contact Log preview notes details
   * @deprecated Since Curam 6.0, replaced by {@link #previewContactLogs1()}
   *
   *             Method to preview a list of Contact Logs.
   */
  @Override
  @Deprecated
  public PreviewContactLogWidgetDetails previewContactLogs(
      final ContactLogPreviewKey key)
      throws AppException, InformationalException {

    // return preview details list variable
    PreviewContactLogWidgetDetails previewContactLogWidgetDetails = new PreviewContactLogWidgetDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)) {

      // Contact Log service object
      final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
          .newInstance();

      // preview contact log list notes
      previewContactLogWidgetDetails = contactLogObj
          .getPreviewWidgetData(contactLogObj.previewList(key.key));

    }

    return previewContactLogWidgetDetails;
  }

  // END, CR00120432

  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains the contact log ID
   *
   * @return The Contact Log details
   * @deprecated Since Curam 6.0, replaced by {@link #readContactLog1()}
   *
   *             Method to read the Contact Log details.
   */
  @Override
  @Deprecated
  public curam.core.sl.struct.ReadContactLogDetails readContactLog(
      final ContactLogKey key) throws AppException, InformationalException {

    // The return struct
    final curam.core.sl.struct.ReadContactLogDetails readContactLogDetailsSL = new curam.core.sl.struct.ReadContactLogDetails();

    final curam.core.facade.struct.ReadContactLogDetails readContactLogDetails = readContactLog1(
        key);

    // Populate return struct
    readContactLogDetailsSL.assign(readContactLogDetails.readDetails);

    return readContactLogDetailsSL;
    // END, CR00140531
  }

  // END, CR00167103

  // ___________________________________________________________________________
  // BEGIN, CR00140325, NP
  /**
   * Facade method to read Contact Log attachments given the specified contact
   * log identifier.
   *
   * @param contactLogkey
   *          Contains the contact log identifier
   *
   * @return List of attachments
   *
   * @throws AppException
   *           Generic Exception Message
   * @throws InformationalException
   *           Generic Exception Message
   */
  @Override
  public ListAttachmentLinkDetails readContactLogAttachments(
      final ContactLogKey contactLogkey)
      throws AppException, InformationalException {

    return attachmentLinkDAO.newInstance().listAttachmentByRelatedObject(
        contactLogkey.contactLogID, ATTACHMENTOBJECTLINKTYPEEntry.CONTACTLOG);
  }
  // END, CR00140325

  // ___________________________________________________________________________
  /**
   * Method to remove a Contact Log Attendee.
   *
   * @param key
   *          Contains the Contact Log Attendee ID and version No
   */
  @Override
  public void removeContactLogAttendee(
      final CancelContactLogAttendeeDetails key)
      throws AppException, InformationalException {

    ContactLogAttendeeFactory.newInstance().cancel(key);
  }

  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * @param key
   *          Contains list of contact log ids
   *
   * @return The file name and document data
   * @deprecated Since Curam 6.0, replaced by
   *             {@link #printPreviewContactLogs1()}
   *
   *             Method to print preview list of Contact Logs.
   */
  @Override
  @Deprecated
  public PrintPreviewContactLogFileDetails printPreviewContactLogs(
      final PrintPreviewContactLogKey key)
      throws AppException, InformationalException {

    return ContactLogFactory.newInstance().printPreviewList(key);
  }

  // END, CR00167103

  // BEGIN, CR00140531, CL
  // ___________________________________________________________________________
  /**
   * Method to read all enabled Contact Log Purpose codes from the code table.
   *
   * @return A list of Contact Log Purpose code table codes and descriptions
   */
  @Override
  public PurposeCodeList listPurpose()
      throws AppException, InformationalException {

    final PurposeCodeList purposeCodeList = new PurposeCodeList();
    PurposeCode purposeCode = null;

    // Return the list of purpose codes
    final LinkedHashMap<?, ?> purposeHashMap = CodeTable.getAllEnabledItems(
        CONTACTLOGPURPOSE.TABLENAME, TransactionInfo.getProgramLocale());

    if (!purposeHashMap.isEmpty()) {

      final Set<?> comKeys = purposeHashMap.keySet();

      final Iterator<?> itr = comKeys.iterator();

      while (itr.hasNext()) {
        final String purposeCodeKey = itr.next().toString();

        purposeCode = new PurposeCode();
        purposeCode.purposeName = purposeHashMap.get(purposeCodeKey).toString();
        purposeCode.purposeCode = purposeCodeKey;
        purposeCodeList.list.add(purposeCode);
      }

    }

    return purposeCodeList;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the Contact Log details for the modify screen.
   *
   * @param key
   *          Contains the contact log ID
   *
   * @return The Contact Log details
   */
  @Override
  public curam.core.facade.struct.ReadContactLogDetails readContactLogForModify(
      final ContactLogKey key) throws AppException, InformationalException {

    // Return struct
    final curam.core.facade.struct.ReadContactLogDetails readContactLogDetails = new curam.core.facade.struct.ReadContactLogDetails();

    // Contact Log service object
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    // Read back the contact log details
    readContactLogDetails.readDetails = contactLogObj.read1(key);

    /*
     * message displayed to the user, which differs based on the narrative edit
     * status. The message is left empty if the narrative is outside the edit
     * period.
     */
    if (readContactLogDetails.readDetails.narrativeEditDetails.narrativeEditableInd) {

      // message for editable
      final LocalisableString editableMessage = new LocalisableString(
          curam.message.NOTE.INF_NARRATIVE_EDITABLE_UNTIL);

      editableMessage.arg(
          readContactLogDetails.readDetails.narrativeEditDetails.editPeriodEndDateTime);

      readContactLogDetails.editableNarrativeMessageOpt = editableMessage
          .toClientFormattedText();

    } else if (readContactLogDetails.readDetails.narrativeEditDetails.narrativeLockedInd) {
      // message for locked
      final LocalisableString lockedMessage = new LocalisableString(
          curam.message.NOTE.INF_NARRATIVE_LOCKED_UNTIL);

      lockedMessage.arg(
          readContactLogDetails.readDetails.narrativeEditDetails.latestNarrativeAuthorFullName);
      lockedMessage.arg(
          readContactLogDetails.readDetails.narrativeEditDetails.editPeriodEndDateTime);

      readContactLogDetails.editableNarrativeMessageOpt = lockedMessage
          .toClientFormattedText();
    }

    // label text for the narrative field, which is different if the narrative
    // is being edited or appended to.
    if (readContactLogDetails.readDetails.narrativeEditDetails.narrativeEditableInd) {
      readContactLogDetails.narrativeFieldLabelTextOpt = curam.message.NOTE.INF_EDIT_NARRATIVE_LABEL
          .getMessageText(TransactionInfo.getProgramLocale());
    } else {
      readContactLogDetails.narrativeFieldLabelTextOpt = curam.message.NOTE.INF_APPEND_NARRATIVE_LABEL
          .getMessageText(TransactionInfo.getProgramLocale());
    }

    /*
     * The note history displayed in a modal has it's own renderer vs the note
     * histry displayed elsewhere. It does not render with any html links to the
     * author/user of the note, as the links cause issues in modals.
     */
    if (readContactLogDetails.readDetails.narrativeEditDetails.narrativeEditableInd) {
      // narrative history does not contain the latest entry if the narrative is
      // editable
      final NoteUtil noteUtil = new NoteUtil();
      final String narrativeHistoryWithoutLatestEntry = noteUtil
          .getNoteHistoryWithoutLatestNote(
              readContactLogDetails.readDetails.noteDetails.notesText);

      readContactLogDetails.narrativeHistoryOpt = narrativeHistoryWithoutLatestEntry;
    } else {
      readContactLogDetails.narrativeHistoryOpt = readContactLogDetails.readDetails.noteDetails.notesText;
    }

    // return contact log details
    return readContactLogDetails;
  }

  // END, CR00140531

  // BEGIN, CR00161622, ZV
  // ___________________________________________________________________________
  /**
   * Method to get default Contact Log details used to create new contact Log.
   *
   * @return The default contact log details
   *
   * @deprecated Since Curam 6.0.5.0, replaced by
   *             {@link #getDefaultContactLogParticipant()}
   *             <p>
   *             This method is deprecated because it was used to display the
   *             current user as the contact log participant always. See release
   *             note: CR00349273.
   */
  @Override
  @Deprecated
  public DefaultContactLogDetails getDefaultContactLogDetails()
      throws AppException, InformationalException {

    final DefaultContactLogDetails defaultContactLogDetails = new DefaultContactLogDetails();

    defaultContactLogDetails.currentUserIsAttendeeInd = true;

    return defaultContactLogDetails;
  }

  // END, CR00161622

  // BEGIN, CR00243200, ZV
  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * Method to preview the Contact Log notes.
   *
   * @param key
   *          Contains the contact log ID
   *
   * @return The Contact Log preview notes details
   */
  @Override
  public PreviewContactLogXMLData previewContactLog1(final ContactLogKey key)
      throws AppException, InformationalException {

    final ContactLogIDLinkTypeKey contactLogIDLinkTypeKey = new ContactLogIDLinkTypeKey();

    contactLogIDLinkTypeKey.contactLogID = key.contactLogID;

    return ContactLogFactory.newInstance().preview1(contactLogIDLinkTypeKey);
  }

  // END, CR00243200

  // ___________________________________________________________________________
  /**
   * Method to read the Contact Log details.
   *
   * @param key
   *          Contains the contact log ID
   *
   * @return The Contact Log details
   */
  @Override
  public curam.core.facade.struct.ReadContactLogDetails readContactLog1(
      final ContactLogKey key) throws AppException, InformationalException {

    // The return struct
    final curam.core.facade.struct.ReadContactLogDetails readContactLogDetails = new curam.core.facade.struct.ReadContactLogDetails();

    // Contact Log service object
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();
    curam.core.sl.struct.ReadContactLogDetails readContactLogDetailsSL = new curam.core.sl.struct.ReadContactLogDetails();

    readContactLogDetails.readDetails = contactLogObj.read1(key);

    readContactLogDetailsSL.contactLogDetails.purpose = readContactLogDetails.readDetails.contactLogDetails.purpose;

    // Format the purpose field for display
    readContactLogDetailsSL = contactLogObj
        .formatContactLogPurpose(readContactLogDetailsSL);

    // Populate return struct with formatted purpose
    readContactLogDetails.readDetails.contactLogDetails.purpose = readContactLogDetailsSL.contactLogDetails.purpose;

    return readContactLogDetails;
  }

  // BEGIN, CR00388252, AC
  /**
   * Method to print preview list of Contact Logs.
   *
   * @param key
   *          Contains list of contact log ids
   *
   * @return The file name and document data
   *
   * @deprecated and replaced by method
   *             printContactLogs(PrintPreviewContactLogKey). This method
   *             selects the contact log with key of fixed size so the size of
   *             the key is increased. Since V6.0.4.4.see release notes of
   *             CR00388252.
   */
  @Override
  @Deprecated
  public curam.core.facade.struct.PrintPreviewContactLogFileDetails printPreviewContactLogs1(
      final PrintPreviewContactLogKey key)
      throws AppException, InformationalException {

    // Return preview details variable
    final curam.core.facade.struct.PrintPreviewContactLogFileDetails previewContactLogDetailsFileList = new curam.core.facade.struct.PrintPreviewContactLogFileDetails();

    // Contact Log service object
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    // Print preview contact log list notes
    previewContactLogDetailsFileList.details = contactLogObj
        .printPreviewList1(key);

    return previewContactLogDetailsFileList;
  }

  // END, CR00388252
  /**
   * Method to preview a list of Contact Logs.
   *
   * @param key
   *          Contains a list of contact log IDs and action control id
   *
   * @return The list of Contact Log preview notes details
   *
   * @deprecated and replaced by method
   *             previewCaseContactLogs(ContactLogPreviewIDKey). This method
   *             selects the contact log with key of fixed size so the size of
   *             the key is increased. since V6.0.5.0.see Release notes for
   *             CR00342633.
   */
  @Override
  @Deprecated
  public PreviewContactLogXMLDetails previewContactLogs1(
      final ContactLogPreviewKey key)
      throws AppException, InformationalException {

    // return preview details list variable
    final PreviewContactLogXMLDetails previewContactLogXMLDetails = new PreviewContactLogXMLDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)) {

      // Contact Log service object
      final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
          .newInstance();
      final PreviewContactLogKey1 previewContactLogKey1 = new PreviewContactLogKey1();

      previewContactLogKey1.multiSelectStr = key.key.multiSelectStr;
      // BEGIN, CR00183167, ZV
      previewContactLogXMLDetails.dtls = contactLogObj
          .previewList1(previewContactLogKey1);
      // END, CR00183167

    }
    return previewContactLogXMLDetails;
  }

  // END, CR00167103
  // END, CR00243200
  // END, CR00342633
  // BEGIN, CR00175532, ZV
  // ___________________________________________________________________________
  /**
   * Method to add an Attendee to a Contact Log.
   *
   * @param details
   *          Contains the contact log id and the attendee details
   *
   * @return The Contact Log Attendee key
   */
  @Override
  public ContactLogAttendeeKey addContactLogAttendee1(
      final CreateContactLogAttendeeDetails1 details)
      throws AppException, InformationalException {

    final ContactLogAttendee contactLogAttendeeObj = ContactLogAttendeeFactory
        .newInstance();

    return contactLogAttendeeObj.create1(details);

  }

  // END, CR00175532

  // BEGIN, CR00226335, NRK
  // ___________________________________________________________________________
  /**
   * Stores the contact details of the contact log wizard in the Wizard
   * persistence cache.
   *
   * @param contactLogWizardDetails
   *          Wizard details(contact details) to be cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00233604,NRK
  @Override
  public WizardStateID createContact(
      final ContactLogWizardDetails contactLogWizardDetails)
      throws AppException, InformationalException {

    WizardStateID wizardStateID = new WizardStateID();
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();

    wizardStateID.wizardStateID = contactLogWizardDetails.wizardStateID;
    final WizardDetails wizardDetails = readWizardDetails(wizardStateID);
    wizardDetails.wizardDetails.contactDetails
        .assign(contactLogWizardDetails.contactLogWizardDetails);

    if (CuramConst.kStoreAction.equals(contactLogWizardDetails.actionString)) {
      wizardDetails.wizardDetails.contactDetails.wizardStateID = contactLogWizardDetails.wizardStateID;
      wizardStateID = contactLogObj
          .storeContactDetails(wizardDetails.wizardDetails);
    }

    return wizardStateID;
  }

  // END, CR00233604

  // ___________________________________________________________________________
  /**
   * Retrieves Wizard details from the WizardPersistentState.
   *
   * @param wizardStateID
   *          Wizard state ID.
   *
   * @return wizard details cached in the wizard persistent state.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  // BEGIN, CR00228358,NRK
  @Override
  public WizardDetails readWizardDetails(final WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();
    final WizardDetails wizardDetails = new WizardDetails();

    if (wizardStateID.wizardStateID != 0) {
      wizardStateID.wizardStateID = wizardStateID.wizardStateID;
      wizardDetails.wizardDetails = contactLogObj
          .readWizardDetails(wizardStateID);
    }

    wizardDetails.wizardMenu = CuramConst.kCreateContactLogWizard;
    return wizardDetails;
  }

  // END, CR00228358
  /**
   * Reads the wizard menu properties.
   *
   * @param wizardStateID
   *          WizardState ID.
   *
   * @return The wizard properties containing the wizard menu details.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogWizardMenuDetails readWizardMenu(
      final WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final ContactLogWizardMenuDetails contactLogWizardMenuDetails = new ContactLogWizardMenuDetails();

    final Case caseObj = CaseFactory.newInstance();
    // Boolean to check whether the subject is enabled for contact logs
    final boolean subjectEnabled = caseObj
        .checkContactLogSubjectEnabled().contactLogSubjectEnabledInd;

    if (wizardStateID.wizardStateID == 0) {
      if (!subjectEnabled) {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kCreateContactLogWizard;
      } else {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kCreateContactLogWizardSubject;
      }
    } else {
      if (!subjectEnabled) {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kModifyContactLogWizard;
      } else {
        contactLogWizardMenuDetails.wizardMenu = CuramConst.kModifyContactLogWizardSubject;
      }
    }

    return contactLogWizardMenuDetails;
  }

  /**
   * Stores Attachment details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param attachmentWizardDetails
   *          Wizard details updated with Attachment details and cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey storeAttachmentDetails(
      final AttachmentWizardDetails attachmentWizardDetails)
      throws AppException, InformationalException {

    ContactLogKey contactLogKey = new ContactLogKey();
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = attachmentWizardDetails.attachmentWizardDetails.wizardStateID;
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();
    final WizardDetails wizardDetails = readWizardDetails(wizardStateID);

    // BEGIN, CR00407842, KRK
    wizardDetails.wizardDetails.attachmentDetails
        .assign(attachmentWizardDetails.attachmentWizardDetails);
    // END, CR00407842

    if (CuramConst.kBackAction.equals(attachmentWizardDetails.actionString)) {

      contactLogObj.storeAttachments(wizardDetails.wizardDetails);

    } else if (CuramConst.kSaveAction
        .equals(attachmentWizardDetails.actionString)) {

      wizardStateID = contactLogObj
          .storeAttachments(wizardDetails.wizardDetails);
      contactLogKey = contactLogObj.insertWizardDetails(wizardStateID);

      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }

    return contactLogKey;
  }

  /**
   * Stores Narrative text of the contact log wizard in the wizard persistence
   * cache.
   *
   * @param narrativeTextWizardDetails
   *          Wizard details updated with narrative details and cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey storeNarrativeText(
      final NarrativeTextWizardDetails narrativeTextWizardDetails)
      throws AppException, InformationalException {

    ContactLogKey contactLogKey = new ContactLogKey();
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();
    final WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = narrativeTextWizardDetails.narrativeTextWizardDetails.wizardStateID;
    final WizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.wizardDetails.narrativeDetails
        .assign(narrativeTextWizardDetails.narrativeTextWizardDetails);

    if (CuramConst.kNextAction.equals(narrativeTextWizardDetails.actionString)

        || CuramConst.kBackAction
            .equals(narrativeTextWizardDetails.actionString)) {
      contactLogObj.storeNarrativeText(wizardDetails.wizardDetails);

    } else if (CuramConst.kSaveAction
        .equals(narrativeTextWizardDetails.actionString)) {

      contactLogObj.storeNarrativeText(wizardDetails.wizardDetails);
      contactLogKey = contactLogObj.insertWizardDetails(wizardStateID);

      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }

    return contactLogKey;
  }

  /**
   * Stores Participant details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param participantWizardDetails
   *          Wizard details updated with Participant details and cached in
   *          WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  @Override
  public ContactLogKey storeParticipantsDetails(
      final ParticipantWizardDetails participantWizardDetails)
      throws AppException, InformationalException {

    ContactLogKey contactLogKey = new ContactLogKey();
    final WizardStateID wizardStateID = new WizardStateID();
    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory
        .newInstance();

    wizardStateID.wizardStateID = participantWizardDetails.participantWizardDetails.wizardStateID;
    final WizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.wizardDetails.participantDetails
        .assign(participantWizardDetails.participantWizardDetails);

    if (CuramConst.kNextAction.equals(participantWizardDetails.actionString)
        || CuramConst.kBackAction
            .equals(participantWizardDetails.actionString)) {

      contactLogObj.storeParticipantsDetails(wizardDetails.wizardDetails);

    } else if (CuramConst.kSaveAction
        .equals(participantWizardDetails.actionString)) {

      contactLogObj.storeParticipantsDetails(wizardDetails.wizardDetails);
      contactLogKey = contactLogObj.insertWizardDetails(wizardStateID);

      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }

    return contactLogKey;
  }

  // END, CR00226335

  // BEGIN, CR00119940, ZV
  // ___________________________________________________________________________
  /**
   * Method to read contact log concern role and user attendees in separate
   * lists.
   *
   * @param key
   *          Contact log key
   *
   * @return The two separate lists for contact concern role and user details
   */
  @Override
  public ContactLogAttendeeByTypeList listContactLogAttendee(
      final ContactLogKey key) throws AppException, InformationalException {

    final ContactLogAttendeeByTypeList contactLogAttendeeByTypeList = new ContactLogAttendeeByTypeList();

    final ContactLogAttendee contactLogAttendeeObj = ContactLogAttendeeFactory
        .newInstance();

    contactLogAttendeeByTypeList.userList = contactLogAttendeeObj
        .listUser1(key);

    contactLogAttendeeByTypeList.concernRoleList = contactLogAttendeeObj
        .listConcernRole(key);

    return contactLogAttendeeByTypeList;
  }

  // ___________________________________________________________________________
  /**
   * Method to read contact log narrative details.
   *
   * @param key
   *          Contact log key
   *
   * @return The contact log narrative details
   */
  @Override
  public ContactLogNarrativeDetails readContactLogNarrative(
      final ContactLogKey key) throws AppException, InformationalException {

    final ContactLogNarrativeDetails contactLogNarrativeDetails = new ContactLogNarrativeDetails();

    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    contactLogNarrativeDetails.dtls = contactLogObj.readNarrative(key);

    if (contactLogNarrativeDetails.dtls.editNarrativeDetails.narrativeEditableInd) {
      // message for editable
      final LocalisableString editableMessage = new LocalisableString(
          curam.message.NOTE.INF_NARRATIVE_EDITABLE_UNTIL);

      editableMessage.arg(
          contactLogNarrativeDetails.dtls.editNarrativeDetails.editPeriodEndDateTime);

      contactLogNarrativeDetails.editableNarrativeMessageOpt = editableMessage
          .toClientFormattedText();

    } else if (contactLogNarrativeDetails.dtls.editNarrativeDetails.narrativeLockedInd) {
      // message for locked
      final LocalisableString lockedMessage = new LocalisableString(
          curam.message.NOTE.INF_NARRATIVE_LOCKED_UNTIL);

      lockedMessage.arg(
          contactLogNarrativeDetails.dtls.editNarrativeDetails.latestNarrativeAuthorFullName);
      lockedMessage.arg(
          contactLogNarrativeDetails.dtls.editNarrativeDetails.editPeriodEndDateTime);

      contactLogNarrativeDetails.editableNarrativeMessageOpt = lockedMessage
          .toClientFormattedText();

    }

    return contactLogNarrativeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to read contact log narrative details using the Lucene memory index
   * search.
   *
   * @param key
   *          Contact log key
   *
   * @return Contact log narrative details
   */
  @Override
  public ContactLogNarrativeDetails readContactLogNarrativeLucene(
      final ContactLogNarrativeSearchKey key)
      throws AppException, InformationalException {

    final ContactLogNarrativeDetails contactLogNarrativeDetails = new ContactLogNarrativeDetails();

    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    final ContactLogKey contactLogKey = new ContactLogKey();
    contactLogKey.contactLogID = key.contactLogID;

    contactLogNarrativeDetails.dtls = contactLogObj
        .readNarrative(contactLogKey);

    final String tempNotesForReinsertion = prepareNotesForReinsertingContent(
        contactLogNarrativeDetails.dtls.noteDetails.notesText);

    final String tempNotes = prepareNotesForSearch(
        contactLogNarrativeDetails.dtls.noteDetails.notesText);

    // Check the search term and highlight matched terms in the narrative
    if (!StringUtil.isNullOrEmpty(key.narrativeSearchText)
        && key.resultInNarrativeInd) {

      final Analyzer analyzer = ContactLogUtility.getLocaleAnalyzer();

      final QueryParser parser = new QueryParser("notes", analyzer);

      // Uses HTML &lt;B&gt;&lt;/B&gt; tag to highlight the searched terms
      final Formatter formatter = new SimpleHTMLFormatter("&lt;mark&gt;",
          "&lt;/mark&gt;");

      // It scores text fragments by the number of unique query terms found
      // Basically the matching score in layman terms
      final QueryScorer scorer;

      try {
        final String narrativeSearchTextEscaped = ContactLogUtility
            .escapeSpecialCharacters(key.narrativeSearchText);

        scorer = new QueryScorer(parser.parse(narrativeSearchTextEscaped));

        // Used to mark-up highlighted terms found in the best sections of a
        // text
        final Highlighter highlighter = new Highlighter(formatter, scorer);

        // It breaks text up into same-size texts but does not split up spans
        final Fragmenter fragmenter = new NullFragmenter();

        // Set fragmenter to highlighter
        highlighter.setTextFragmenter(fragmenter);

        final String bestFragmentString = highlighter.getBestFragment(analyzer,
            "notes", tempNotes);

        contactLogNarrativeDetails.dtls.noteDetails.notesText = prepareNotesForUI(
            bestFragmentString, tempNotesForReinsertion);

      } catch (final ParseException | IOException
          | InvalidTokenOffsetsException e) {
        throw new AppRuntimeException(e);
      }
    }

    if (contactLogNarrativeDetails.dtls.editNarrativeDetails.narrativeEditableInd) {
      // message for editable
      final LocalisableString editableMessage = new LocalisableString(
          curam.message.NOTE.INF_NARRATIVE_EDITABLE_UNTIL);

      editableMessage.arg(
          contactLogNarrativeDetails.dtls.editNarrativeDetails.editPeriodEndDateTime);

      contactLogNarrativeDetails.editableNarrativeMessageOpt = editableMessage
          .toClientFormattedText();

    } else if (contactLogNarrativeDetails.dtls.editNarrativeDetails.narrativeLockedInd) {
      // message for locked
      final LocalisableString lockedMessage = new LocalisableString(
          curam.message.NOTE.INF_NARRATIVE_LOCKED_UNTIL);

      lockedMessage.arg(
          contactLogNarrativeDetails.dtls.editNarrativeDetails.latestNarrativeAuthorFullName);
      lockedMessage.arg(
          contactLogNarrativeDetails.dtls.editNarrativeDetails.editPeriodEndDateTime);

      contactLogNarrativeDetails.editableNarrativeMessageOpt = lockedMessage
          .toClientFormattedText();

    }

    return contactLogNarrativeDetails;
  }

  /**
   * Prepare the notes for presenting on the client. Take the notes with the
   * best fragments highlighted, re-insert the {@code <content>} and
   * {@code </content>} tags, and re-insert the {@code content} array elements
   * in the overall notes string.
   * <p>
   * If the cleansed and highlighted string is {@code null}, meaning that the
   * searched for term did not exist in the notes text, return {@code null} from
   * this API.
   *
   * @param cleansedAndHighlightedStr
   *          Cleansed and highlighted string for presenting to the user
   * @param tempNotes
   *          Temporary notes string with the place-holders present for the
   *          re-insertion of the content array elements
   *
   * @return Notes string that can be presented to the user or {@code null} if
   *         the {@code cleansedAndHighlightedStr} parameter passed into the
   *         function.
   */
  String prepareNotesForUI(final String cleansedAndHighlightedStr,
      final String tempNotes) {

    if (cleansedAndHighlightedStr == null) {
      return null;
    }

    final String[] contentArrayAfterSearch = cleansedAndHighlightedStr
        .split(END_CONTENT_TAG_REPLACEMENT);

    // We've split on the replacement for </content>, so we need to
    // re-add </content> to each of the elements in the array
    for (int i = 0; i < contentArrayAfterSearch.length; i++) {

      final String contentStartTagReadded = contentArrayAfterSearch[i]
          .replace(START_CONTENT_TAG_REPLACEMENT, START_CONTENT_TAG);

      final String contentEndTagReadded = contentStartTagReadded
          + END_CONTENT_TAG;

      contentArrayAfterSearch[i] = contentEndTagReadded;
    }

    String notes = tempNotes;

    // Now iterate over the content array and reinsert into the notes text
    for (int i = 0; i < contentArrayAfterSearch.length; i++) {

      notes = notes.replace(LOREM + "[" + i + "]", contentArrayAfterSearch[i]);
    }

    return notes;
  }

  /**
   * Prepare the notes text for re-insertion of the content sections after the
   * search has taken place. Each section book-ended by {@code <content>} and
   * {@code </content>} tags will be replaced by LOREM[i], where i is the
   * <i>nth</i> element of the array of content entries.
   *
   * @param notes
   *          Notes text from the Note entity
   *
   * @return Note text prepared for the re-insertion of the content array
   *         elements after the search has taken place
   */
  String prepareNotesForReinsertingContent(final String notes) {

    // Extract all the content elements from the notes string
    final String[] contentArray = StringUtils.substringsBetween(notes,
        END_AUTHOR_TAG, END_NOTE_TAG);

    String tempNotes = notes;

    if (contentArray != null) {
      // Replace the extracted content elements with a numerical placeholder
      // for re-insertion after the search has taken place
      for (int i = 0; i < contentArray.length; i++) {

        final String replacement = LOREM + "[" + i + "]";

        tempNotes = StringUtils.replace(tempNotes, contentArray[i],
            replacement);
      }
    }
    return tempNotes;
  }

  /**
   * Searches for all content entries in the notes text and creates a content
   * array of these entries. Then join the array elements together into one
   * string and replace the {@code <content>} tag with {@code <C-O-N-T-E-N-T>}
   * and {@code </content>} with {@code <T-N-E-T-N-0-C>}.
   *
   * @param notes
   *          Notes text
   *
   * @return Notes prepared for searching
   */
  String prepareNotesForSearch(final String notes) {

    // Extract all the content elements from the notes string
    final String[] contentArray = StringUtils.substringsBetween(notes,
        END_AUTHOR_TAG, END_NOTE_TAG);

    if (contentArray != null) {
      // Join all the content elements together into one string for getting
      // the best fragment
      final String joinedUpArray = String.join("", contentArray);

      // As content might be a word that is searched on, we need to mask
      // the word content in the start and end tags before the call is
      // made to getBestFragment
      final String joinedUpArrayStartContentCleansed = StringUtils.replace(
          joinedUpArray, START_CONTENT_TAG, START_CONTENT_TAG_REPLACEMENT);

      // This represents the fully cleansed string (content elements)
      return StringUtils.replace(joinedUpArrayStartContentCleansed,
          END_CONTENT_TAG, END_CONTENT_TAG_REPLACEMENT);
    } else {
      return notes;
    }

  }

  // ___________________________________________________________________________
  // BEGIN, CR00348376, AC
  /**
   * Method to read contact log tab details.
   *
   * @param key
   *          Contact log key
   *
   * @return The contact log tab details
   * @deprecated and replaced by method
   *             readContactLogCaseDetails(ContactLogKey). The method returns
   *             contact log details with create date as date. since
   *             V6.0.5.0.see Release notes for CR00348376.
   */
  @Override
  @Deprecated
  public ContactLogDetails readContactLogDetails(final ContactLogKey key)
      throws AppException, InformationalException {

    final ContactLogDetails contactLogDetails = new ContactLogDetails();

    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory
        .newInstance();

    contactLogDetails.dtls = contactLogObj.readDetails(key);

    return contactLogDetails;
  }

  // END, CR00348376
  // BEGIN, CR00342633, AC
  /**
   * Method to preview a list of Contact Logs.
   *
   * @param key
   *          to read the preview ContactLog details.
   *
   * @return the preview Contact Log list.
   *
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public PreviewContactLogXMLDetails previewCaseContactLogs(
      final ContactLogPreviewIDKey contactLogPreviewIDKey)
      throws AppException, InformationalException {

    final PreviewContactLogXMLDetails previewContactLogXMLDetails = new PreviewContactLogXMLDetails();

    final curam.core.sl.struct.PreviewCaseContactLogKey previewContactLogKey = new curam.core.sl.struct.PreviewCaseContactLogKey();

    previewContactLogKey.multiSelectStr = contactLogPreviewIDKey.dtls.multiSelectStr;
    previewContactLogXMLDetails.dtls = curam.core.sl.fact.ContactLogFactory
        .newInstance().previewContactLogList(previewContactLogKey);

    return previewContactLogXMLDetails;
  }

  /**
   * Method to print preview list of Contact Logs.
   *
   * @param key
   *          Contains list of contact log print key.
   *
   * @return The file name and document data.
   *
   * @throws AppException.
   *           Generic Exception Signature.
   * @throws InformatinalException.
   *           Generic Exception Signature.
   */
  @Override
  public curam.core.facade.struct.PrintPreviewContactLogFileDetails printContactLogs(
      final WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();

    final PrintContactLogWizardDetails printContactLogWizardDetails = (PrintContactLogWizardDetails) wizardPersistentStateObj
        .read(wizardStateID.wizardStateID);

    printContactLogWizardDetails.wizardStateID = wizardStateID.wizardStateID;

    return setPrintContactDetails(printContactLogWizardDetails);
  }

  /**
   * Gets the print log details.
   *
   * @param PreviewCaseContactLogIDKey
   *          to get the Preview list
   * @return PrintContactLogWizardDetails for the temporary storage of print log
   *         details
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public PrintContactLogWizardDetails getPrintContactLogDetails(
      final PreviewCaseContactLogIDKey previewCaseContactLogIDkey)
      throws AppException, InformationalException {

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = previewCaseContactLogIDkey.casekey.caseID;

    final WizardPersistentState wizardPersistentState = new WizardPersistentState();
    final PrintContactLogWizardDetails printContactLogWizardDetails = new PrintContactLogWizardDetails();
    final CaseContextDescription caseContextDescription = CaseFactory
        .newInstance().readCaseContextDescription(caseContextDescriptionKey);

    printContactLogWizardDetails.description = caseContextDescription.description;
    printContactLogWizardDetails.multiSelectString = previewCaseContactLogIDkey.dtls.multiSelectStr;
    printContactLogWizardDetails.wizardStateID = wizardPersistentState
        .create(printContactLogWizardDetails);

    return printContactLogWizardDetails;
  }

  /**
   * Sets the print log details.
   *
   * @param PreviewCaseContactLogIDKey
   *          to get the Preview list
   * @return PrintContactLogWizardDetails for the temporary storage of print log
   *         details
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public curam.core.facade.struct.PrintPreviewContactLogFileDetails setPrintContactDetails(
      final PrintContactLogWizardDetails printContactLogWizardDetails)
      throws AppException, InformationalException {

    final curam.core.facade.struct.PrintPreviewContactLogFileDetails printPreviewContactLogFileDetails = new curam.core.facade.struct.PrintPreviewContactLogFileDetails();
    final WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = printContactLogWizardDetails.wizardStateID;

    final PrintPreviewCaseContactLogKey printContactLogKey = new PrintPreviewCaseContactLogKey();

    // BEGIN, CR00348506, AC
    printContactLogKey.description = printContactLogWizardDetails.description;
    // END, CR00348506
    printContactLogKey.dtls.multiSelectStr = printContactLogWizardDetails.multiSelectString;
    printPreviewContactLogFileDetails.details = curam.core.sl.fact.ContactLogFactory
        .newInstance().printPreviewContactLogListDetails(printContactLogKey);

    return printPreviewContactLogFileDetails;
  }

  // END, CR00342633
  // BEGIN, CR00348376, AC
  /**
   * Reads contact log tab details.
   *
   * @param key
   *          Contact log key
   *
   * @return The contact log tab details
   */
  @Override
  public ContactLogCaseDetails readContactLogCaseDetails(
      final ContactLogKey contactLogKey)
      throws AppException, InformationalException {

    final ContactLogCaseDetails contactLogCaseDetails = new ContactLogCaseDetails();

    contactLogCaseDetails.dtls = ContactLogFactory.newInstance()
        .readContactLogDetails(contactLogKey);

    return contactLogCaseDetails;
  }

  // END, CR00348376

  // BEGIN, CR00349273, DJ
  /**
   * Determines if the current user is a participant for the contact log or not.
   * For the first time it will be set as true and later on wards the value is
   * set based on the user inputs.
   *
   * @param wizardStateID
   *          contains the wizard state id.
   *
   * @return The value which indicates if the current user is the participant.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public DefaultContactLogDetails getDefaultContactLogParticipant(
      final curam.core.facade.struct.WizardStateID wizardStateID)
      throws AppException, InformationalException {

    final DefaultContactLogDetails defaultContactLogDetails = new DefaultContactLogDetails();
    final WizardPersistentState wizardPersistentStateobj = new WizardPersistentState();

    final curam.core.sl.struct.WizardDetails wizardDetails = (curam.core.sl.struct.WizardDetails) wizardPersistentStateobj
        .read(wizardStateID.wizardStateID);

    if (!wizardDetails.participantDetails.currentUserIsAttendeeInd
        && wizardDetails.participantDetails.caseParticipantRoleIDTabList
            .isEmpty()
        && wizardDetails.participantDetails.concernRoleName.isEmpty()
        && wizardDetails.participantDetails.participantName.isEmpty()
        && wizardDetails.participantDetails.userName.isEmpty()
        || wizardDetails.participantDetails.currentUserIsAttendeeInd) {
      defaultContactLogDetails.currentUserIsAttendeeInd = true;
    } else if (!(wizardDetails.participantDetails.caseParticipantRoleIDTabList
        .isEmpty() || wizardDetails.participantDetails.concernRoleName.isEmpty()
        || wizardDetails.participantDetails.participantName.isEmpty()
        || wizardDetails.participantDetails.userName.isEmpty())) {
      defaultContactLogDetails.currentUserIsAttendeeInd = false;
    }

    return defaultContactLogDetails;
  }

  // END, CR00349273

  // BEGIN, CR00407868, SG
  /**
   * Checks if the user has maintain rights on the case.
   *
   * @param key
   *          ID of the case that is being checked.
   *
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           (GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS) if the user
   *           does not have any privilege.
   * @throws AppException
   *           (GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS) if the user
   *           has read only privilege.
   */
  @Override
  public void checkMaintainCaseSecurity(final CaseSecurityCheckKey key)
      throws AppException, InformationalException {

    if (0 != key.caseID) {

      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
          .get();

      key.type = DataBasedSecurity.kMaintainSecurityCheck;

      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
          .checkCaseSecurity1(key);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                  GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS),
              ValidationManagerConst.kSetOne, 2);
        } else if (dataBasedSecurityResult.restricted) {
          ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS),
              ValidationManagerConst.kSetOne, 2);
        } else {
          ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                  GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS),
              ValidationManagerConst.kSetOne, 2);
        }
      }

    }

  }

  /**
   * Checks if the user has maintain rights on the participant.
   *
   * @param key
   *          ID of the participant that is being checked.
   *
   * @throws AppException
   *           (GENERALCONCERN.ERR_CONCERNROLE_FV_NOMINEE_SENSITIVITY) if the
   *           user does not have the required privilege.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Override
  public void checkMaintainParticipantSecurity(
      final ParticipantSecurityCheckKey key)
      throws AppException, InformationalException {

    if (0 != key.participantID) {

      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory
          .get();

      key.type = LOCATIONACCESSTYPE.MAINTAIN;

      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
          .checkParticipantSecurity(key);

      if (!dataBasedSecurityResult.result) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
            .throwWithLookup(
                new AppException(
                    GENERALCONCERN.ERR_CONCERNROLE_FV_NOMINEE_SENSITIVITY),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
      }
    }

  }
  // END, CR00407868
}
