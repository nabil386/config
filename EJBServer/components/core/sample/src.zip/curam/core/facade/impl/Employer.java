/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012-2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.core.facade.impl;

import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.fact.ProspectEmployerFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.intf.ProspectEmployer;
import curam.core.facade.struct.*;
import curam.core.fact.EmployerSearchRouterFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.EmployerSearchRouter;
import curam.core.intf.MaintainConcernRoleDetails;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmployerDetails;
import curam.core.struct.EmployerReadDtls;
import curam.core.struct.EmployerReadDtlsList;
import curam.core.struct.EmployerSearchResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.MaintainConcernRoleRelationshipDetails;
import curam.core.struct.MaintainConcernRoleRelationshipKey;
import curam.core.struct.MaintainConcernRoleRelationshipList;
import curam.core.struct.MaintainTradingStatusKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadConcernRoleKey;
import curam.core.struct.ReadEmployerResult;
import curam.message.GENERALSEARCH;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;

/**
 * This process class provides the functionality for the Employer presentation
 * layer.
 */
public abstract class Employer extends curam.core.facade.base.Employer {

  // BEGIN, CR00233791, DJ
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu =
    XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParamConcernRoleID =
    XmlMetaDataConst.kParamConcernRoleID;

  protected static final String kCommaSpace =
    CuramConst.gkComma + CuramConst.gkSpace;

  @Deprecated
  protected static final String kSeparator =
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  // BEGIN, CR00238338, PF
  @Deprecated
  protected static final int kMinimumPhoneNumberLength =
    CuramConst.gkMinimumPhoneNumberLength;

  // END, CR00238338
  // END, CR00233791

  // ___________________________________________________________________________
  /**
   * Searches for an employer by primary alternate ID.
   *
   * @param key
   * reference number to be searched for
   *
   * @return Employer details
   * @deprecated Since Curam 6.0.5.3, replaced by
   * {@link #searchByReferenceNumber()}
   */
  @Deprecated
  @Override
  public EmployerReadDetails
    readByReferenceNumber(final EmployerAlternateSearchKey key)
      throws AppException, InformationalException {

    // Employer Search object.
    final curam.core.intf.EmployerSearchRouter employerSearchRouterObj =
      curam.core.fact.EmployerSearchRouterFactory.newInstance();

    // Details to be returned.
    final EmployerReadDetails employerReadDetails = new EmployerReadDetails();

    // Call the search.
    final EmployerReadDtls employerReadDtls =
      employerSearchRouterObj.readByReferenceNumber(key.alternateIDSearchKey);

    if (employerReadDtls != null) {
      employerReadDetails.employerReadDtls = employerReadDtls;
    }

    // Return the details.
    return employerReadDetails;
  }

  // ___________________________________________________________________________
  /**
   * Searches for an employer by primary alternate ID.
   *
   * @param key
   * reference number to be searched for
   *
   * @return Employer details
   * @return Employer details.
   */
  @Override
  public EmployerReadDtlsList
    searchByReferenceNumber(final EmployerAlternateSearchKey key)
      throws AppException, InformationalException {

    final curam.core.intf.EmployerSearchRouter employerSearchRouterObj =
      curam.core.fact.EmployerSearchRouterFactory.newInstance();

    EmployerReadDtlsList employerReadDtlsList = new EmployerReadDtlsList();

    // Call the search.
    employerReadDtlsList = employerSearchRouterObj
      .searchByReferenceNumber(key.alternateIDSearchKey);

    return employerReadDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * @param key
   * data to be searched for.
   *
   * @return Employer details.
   * @return Employer details
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Searches for an employer by Concern Role ID.
   */
  @Override
  @Deprecated
  public curam.core.facade.struct.EmployerSearchResult
    search(final curam.core.facade.struct.EmployerSearchKey key)
      throws AppException, InformationalException {

    // Employer Search object.
    final curam.core.intf.EmployerSearchRouter employerSearchRouterObj =
      curam.core.fact.EmployerSearchRouterFactory.newInstance();

    // Details to be returned.
    final curam.core.facade.struct.EmployerSearchResult employerSearchResult =
      new curam.core.facade.struct.EmployerSearchResult();

    // Call the search.
    final EmployerSearchResult empSearchResult =
      employerSearchRouterObj.search(key.employerSearchKey);

    if (empSearchResult != null) {

      employerSearchResult.employerSearchResult = empSearchResult;
    }

    // Return the details.
    return employerSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Sets Employer Trading Status record to canceled.
   *
   * @param key
   * identifies trading status to be canceled.
   *
   * @return Trading Status informational messages
   * @return Trading Status informational messages.
   */
  @Override
  public TradingStatusMessageList
    cancelTradingStatus(final CancelTradingStatusKey key)
      throws AppException, InformationalException {

    // Maintain Employer Trading Status object.
    final curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj =
      curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    // Details to be returned.
    final TradingStatusMessageList tradingStatusMessageList =
      new TradingStatusMessageList();

    // Cancel the Employer Trading Status.
    tradingStatusMessageList.informationalMsgDtlsList =
      maintainEmployerTradingStatusObj
        .cancelTradingStatus(key.cancelEmployerTradingStatusKey);

    // Return the details.
    return tradingStatusMessageList;
  }

  // ___________________________________________________________________________
  /**
   * Creates an employer trading status record.
   *
   * @param details
   * employer trading details
   */
  @Override
  public void createTradingStatus(final MaintainTradingStatusDetails details)
    throws AppException, InformationalException {

    // Maintain Employer Trading Status object and key.
    final curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj =
      curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    final MaintainTradingStatusKey maintainTradingStatusKey =
      new MaintainTradingStatusKey();

    // Get the Concern Role ID from the key.
    maintainTradingStatusKey.concernRoleID =
      details.tradingStatusDetails.concernRoleID;

    // Create the Trading Status record.
    maintainEmployerTradingStatusObj.createTradingStatus(
      maintainTradingStatusKey, details.tradingStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of employer trading status records.
   *
   * @param key
   * identifies employer trading status.
   *
   * @return A trading status list for the Employer.
   */
  @Override
  public ReadTradingStatusList
    listTradingStatus(final ReadTradingStatusListKey key)
      throws AppException, InformationalException {

    // Maintain Employer Trading Status object.
    final curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj =
      curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    // Details to be returned.
    final ReadTradingStatusList readTradingStatusList =
      new ReadTradingStatusList();

    // Retrieve the list of trading status's.
    readTradingStatusList.tradingStatusRMDetailsList =
      maintainEmployerTradingStatusObj
        .readmultiByConcernRole(key.maintainTradingStatusKey);

    // Get the context description for the concern role
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.maintainTradingStatusKey.concernRoleID;

    readTradingStatusList.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return the details
    return readTradingStatusList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an employer trading status record.
   *
   * @param details
   * employer trading status details.
   *
   * @return Trading Status informational messages
   * @return Trading Status informational messages.
   */
  @Override
  public TradingStatusMessageList
    modifyTradingStatus(final MaintainTradingStatusDetails details)
      throws AppException, InformationalException {

    // Maintain Employer Trading Status object and key.
    final curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj =
      curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    final MaintainTradingStatusKey maintainTradingStatusKey =
      new MaintainTradingStatusKey();

    // Details to be returned.
    final TradingStatusMessageList tradingStatusMessageList =
      new TradingStatusMessageList();

    // Get the Concern Role ID from the key.
    maintainTradingStatusKey.concernRoleID =
      details.tradingStatusDetails.concernRoleID;

    // Modify the Trading Status record.
    maintainEmployerTradingStatusObj.modifyTradingStatus(
      maintainTradingStatusKey, details.tradingStatusDetails);

    // BEGIN, CR00016578, SPD
    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      tradingStatusMessageList.informationalMsgDtlsList.dtls
        .addRef(informationalMsgDtls);
    }
    // END, CR00016578

    // Return the details.
    return tradingStatusMessageList;
  }

  // __________________________________________________________________________
  /**
   * Reads employer trading status record.
   *
   * @param key
   * identifies the employer trading status record.
   *
   * @return Trading Status details for the Employer.
   */
  @Override
  public ReadTradingStatusDetails
    readTradingStatus(final ReadTradingStatusKey key)
      throws AppException, InformationalException {

    // Maintain Employer Trading Status object.
    final curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj =
      curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    // Details to be returned.
    final ReadTradingStatusDetails readTradingStatusDetails =
      new ReadTradingStatusDetails();

    // Read the Trading Status details.
    readTradingStatusDetails.tradingStatusDetails =
      maintainEmployerTradingStatusObj
        .readTradingStatus(key.readEmployerTradingStatusKey);

    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      readTradingStatusDetails.tradingStatusDetails.concernRoleID;

    readTradingStatusDetails.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return the Employer Trading Status details.
    return readTradingStatusDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads an employers home page details and further details.
   *
   * @param key
   * identifies employer concerned.
   *
   * @return The Employer details.
   */
  @Override
  public ReadEmployerHomeDetails
    readHomePageDetails(final ReadEmployerHomeKey key)
      throws AppException, InformationalException {

    // Employer Home Page object.
    final curam.core.intf.EmployerHomePage employerHomePageObj =
      curam.core.fact.EmployerHomePageFactory.newInstance();

    // Maintain Concern Role Details object and key.
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj =
      curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey =
      new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned.
    final ReadEmployerHomeDetails readEmployerHomeDetails =
      new ReadEmployerHomeDetails();

    // Struct returned from Employer Home Page read.
    ReadEmployerResult readEmployerResult;

    // Struct returned from Employer Further Details read.
    EmployerDetails employerDetails;

    // Get the Concern Role ID from the key.
    maintainConcernRoleKey.concernRoleID =
      key.concernRoleHomePageKey.concernRoleID;

    // Read the Employer Home Page details.
    readEmployerResult = employerHomePageObj.read(key.concernRoleHomePageKey);

    // Read the Employer Further Details.
    employerDetails =
      maintainConcernRoleDetailsObj.readEmployer(maintainConcernRoleKey);

    // Assign the returned details.
    readEmployerHomeDetails.employerHomeDetails.assign(employerDetails);
    readEmployerHomeDetails.employerHomeDetails
      .assign(readEmployerResult.details);

    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.concernRoleHomePageKey.concernRoleID;

    readEmployerHomeDetails.participantContextDetails.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return the Employer Home Page details.
    return readEmployerHomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Register an employer
   *
   * @param details
   * details of the employer to be registered
   *
   * @return details from the operation
   * @return details from the operation.
   */
  @Override
  public EmployerRegistrationResult register(
    final curam.core.facade.struct.EmployerRegistrationDetails details)
    throws AppException, InformationalException {

    // Employer maintenance object
    final curam.core.intf.EmployerRegistration employerRegistrationObj =
      curam.core.fact.EmployerRegistrationFactory.newInstance();

    // Concern role entity objects
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Read concern ID from ConcernRole, if necessary
    if (details.employerRegistrationDetails.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID =
        details.employerRegistrationDetails.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // Set concern ID in registration details
      details.employerRegistrationDetails.concernID =
        concernRoleDtls.concernID;
    }

    // Details to be returned
    final EmployerRegistrationResult employerRegistrationResult =
      new EmployerRegistrationResult();

    // Register employer
    employerRegistrationResult.registrationIDDetails = employerRegistrationObj
      .registerEmployer(details.employerRegistrationDetails);

    // BEGIN, CR00078486, POH
    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      employerRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    // Return details
    return employerRegistrationResult;
  }

  // ___________________________________________________________________________
  /**
   * Cancels an employer relationship record
   *
   * @param key
   * key of the employer relationship which is to be canceled
   */
  @Override
  public void cancelRelationship(final CancelEmployerRelationshipKey key)
    throws AppException, InformationalException {

    // Relationship maintenance object
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj =
      curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Cancel the relationship
    maintainConcernRoleRelationshipsObj
      .cancelRelationship(key.cancelRelationshipDetailsKey);
  }

  // BEGIN, CR00077847, POH
  // ___________________________________________________________________________
  /**
   * Creates an employer relationship record
   *
   * @param details
   * concern role identifier & concern role phone number details
   * @return CreatedRelationshipDetails
   * List of informationals - if any exist - to be displayed to user
   */
  @Override
  public CreatedRelationshipDetails
    createRelationship(final MaintainEmployerRelationshipDetails details)
      throws AppException, InformationalException {

    // return struct
    final CreatedRelationshipDetails createdRelationshipDetails =
      new CreatedRelationshipDetails();

    // Relationship maintenance object
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj =
      curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    final MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails =
      new MaintainConcernRoleRelationshipDetails();

    // Assign relationship details
    maintainConcernRoleRelationshipDetails
      .assign(details.employerRelationshipDetails);

    // Create Relationship
    maintainConcernRoleRelationshipsObj
      .createRelationshipByAltID(maintainConcernRoleRelationshipDetails);

    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdRelationshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdRelationshipDetails;
  }

  // END, CR00077847

  // ___________________________________________________________________________
  /**
   * Retrieves a list of relationship records for an employer
   *
   * @param key
   * employer identifier
   *
   * @return list of relationships found
   */
  @Override
  public ReadEmployerRelationshipList
    listRelationship(final ReadEmployerRelationshipListKey key)
      throws AppException, InformationalException {

    // Relationship maintenance object
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj =
      curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned
    final ReadEmployerRelationshipList readEmployerRelationshipList =
      new ReadEmployerRelationshipList();

    EmployerRelationshipRMDetails employerRelationshipRMDetails;

    MaintainConcernRoleRelationshipList maintainConcernRoleRelationshipList;

    // Read list of relationships
    maintainConcernRoleRelationshipList = maintainConcernRoleRelationshipsObj
      .readmultiByConcernRoleID(key.relationshipsByConcernRoleIDKey);

    key.relationshipsByConcernRoleIDKey
      .assign(maintainConcernRoleRelationshipList);

    readEmployerRelationshipList.employerRelationshipRMDetails
      .ensureCapacity(maintainConcernRoleRelationshipList.dtls.size());

    // BEGIN, 124089, NN
    // Removed if statement from here
    // Adding to the list to display list of relationships
    for (int i = 0; i < maintainConcernRoleRelationshipList.dtls
      .size(); i++) {

      employerRelationshipRMDetails = new EmployerRelationshipRMDetails();

      employerRelationshipRMDetails
        .assign(maintainConcernRoleRelationshipList.dtls.item(i));
      readEmployerRelationshipList.employerRelationshipRMDetails
        .addRef(employerRelationshipRMDetails);
    }
    // END, 124089
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.relationshipsByConcernRoleIDKey.concernRoleID;

    readEmployerRelationshipList.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return Details
    return readEmployerRelationshipList;
  }

  // BEGIN, CR00077847, POH
  // ___________________________________________________________________________
  /**
   * Modifies a relationship record for an employer
   *
   * @param details
   * employer identifier & employer relationship details
   * @return ModifiedRelationshipDetails
   * List of informationals - if any exist - to be displayed to user
   */
  @Override
  public ModifiedRelationshipDetails
    modifyRelationship(final MaintainEmployerRelationshipDetails details)
      throws AppException, InformationalException {

    // return struct
    final ModifiedRelationshipDetails modifiedRelationshipDetails =
      new ModifiedRelationshipDetails();

    // Relationship maintenance object and key
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj =
      curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();
    final MaintainConcernRoleRelationshipKey maintainConcernRoleRelationshipKey =
      new MaintainConcernRoleRelationshipKey();

    final MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails =
      new MaintainConcernRoleRelationshipDetails();

    // Assign relationship details
    maintainConcernRoleRelationshipDetails
      .assign(details.employerRelationshipDetails);

    // Get concern role relationship id from key
    maintainConcernRoleRelationshipKey.concernRoleRelationshipID =
      details.employerRelationshipDetails.concernRoleRelationshipID;

    // Modify Relationship
    maintainConcernRoleRelationshipsObj.modifyRelationshipByAltID(
      maintainConcernRoleRelationshipKey,
      maintainConcernRoleRelationshipDetails);

    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    final String[] warnings =
      informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      final ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedRelationshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedRelationshipDetails;
  }

  // END, CR00077847

  // ___________________________________________________________________________
  /**
   * Reads a relationship record for an employer
   *
   * @param key
   * employer relationship key.
   *
   * @return relationship details found.
   */
  @Override
  public ReadEmployerRelationshipDetails
    readRelationship(final ReadEmployerRelationshipKey key)
      throws AppException, InformationalException {

    // Relationship maintenance object and key
    final curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj =
      curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned
    final ReadEmployerRelationshipDetails readEmployerRelationshipDetails =
      new ReadEmployerRelationshipDetails();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails;

    // Read relationship details
    maintainConcernRoleRelationshipDetails =
      maintainConcernRoleRelationshipsObj
        .readRelationship(key.maintainConcernRoleRelationshipKey);

    readEmployerRelationshipDetails.employerRelationshipDetails
      .assign(maintainConcernRoleRelationshipDetails);

    // Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      maintainConcernRoleRelationshipDetails.concernRoleID;

    readEmployerRelationshipDetails.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return Details
    return readEmployerRelationshipDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieve a list of cases by concern role ID
   *
   * @param key
   * identifier of employer concerned.
   *
   * @return A list of cases for the employer.
   */
  @Override
  public ListCaseDetails listCase(final ListCaseKey_fo key)
    throws AppException, InformationalException {

    // Maintain Case maintenance object and key
    final curam.core.intf.MaintainCase maintainCaseObj =
      curam.core.fact.MaintainCaseFactory.newInstance();

    // Details to be returned
    final ListCaseDetails listCaseDetails = new ListCaseDetails();

    // Set status code for search
    key.casesByConcernRoleIDKey.statusCode =
      curam.codetable.CASESTATUSSEARCH.ALL;

    // Retrieve the list of cases
    // BEGIN, CR00221180, ZV
    listCaseDetails.caseHeaderConcernRoleDetailsList.assign(
      maintainCaseObj.getCasesByConcernRoleID1(key.casesByConcernRoleIDKey));
    // END, CR00221180

    // Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.casesByConcernRoleIDKey.concernRoleID;

    listCaseDetails.participantContextDetails.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // return details
    return listCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates an employer with new details.
   *
   * @param details
   * Modified details of the Employer.
   *
   * @return Informational messages.
   */
  @Override
  public ModifyEmployerReturnDetails
    modifyEmployer(final ModifyEmployerDetails details)
      throws AppException, InformationalException {

    // Employer maintenance object and key
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj =
      curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey =
      new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned
    final ModifyEmployerReturnDetails modifyEmployerReturnDetails =
      new ModifyEmployerReturnDetails();

    // Get the concern role ID from the modify details.
    maintainConcernRoleKey.concernRoleID =
      details.readEmployerDetails.concernRoleID;

    // Struct passed to modifyEmployer
    final EmployerDetails employerDetails = new EmployerDetails();

    employerDetails.assign(details.readEmployerDetails);

    // Modify the employer
    modifyEmployerReturnDetails.informationalMsgDtlsList =
      maintainConcernRoleDetailsObj.modifyEmployer(maintainConcernRoleKey,
        employerDetails);

    // Return details
    return modifyEmployerReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details for the specified employer.
   *
   * @param key
   * Unique identifier for the Employer.
   *
   * @return Employer details
   * @return Employer details.
   */
  @Override
  public ReadEmployerDetailsDetails
    readEmployerDetails(final ReadEmployerDetailsKey key)
      throws AppException, InformationalException {

    // Employer maintenance object and key
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj =
      curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    final curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey =
      new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned
    final ReadEmployerDetailsDetails readEmployerDetailsDetails =
      new ReadEmployerDetailsDetails();

    // Get the concern role ID from the search key.
    maintainConcernRoleKey.concernRoleID =
      key.maintainConcernRoleKey.concernRoleID;

    // Details struct for the Employer read
    EmployerDetails employerDetails;

    // Read the employer details
    employerDetails =
      maintainConcernRoleDetailsObj.readEmployer(maintainConcernRoleKey);
    readEmployerDetailsDetails.readEmployerDetails.assign(employerDetails);

    // Context key
    // BEGIN, CR00060595, PCAL
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      readEmployerDetailsDetails.readEmployerDetails.concernRoleID;

    readEmployerDetailsDetails.participantContextDetails.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return Details
    return readEmployerDetailsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the employer's full name and address.
   *
   * @param key
   * Contains the employer's concern role identifier.
   *
   * @return EmployerNameAndAddressDetails The employer's full name and address.
   */
  @Override
  public EmployerNameAndAddressDetails
    readFullNameAndAddress(final ReadEmployerDetailsKey key)
      throws AppException, InformationalException {

    // Create return object
    final EmployerNameAndAddressDetails employerNameAndAddressDetails =
      new EmployerNameAndAddressDetails();

    // MaintainConcernRoleDetails manipulation variables
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj =
      curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    final ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
    curam.core.struct.ReadContactDetails readContactDetails;

    // Set key to read concern role details
    readConcernRoleKey.concernRoleID =
      key.maintainConcernRoleKey.concernRoleID;

    // Call MaintainConcernRoleDetails BPO to read employer's full name and
    // address
    readContactDetails =
      maintainConcernRoleDetailsObj.readAllContactDetails(readConcernRoleKey);

    // Assign details to return object
    employerNameAndAddressDetails.assign(readContactDetails);

    return employerNameAndAddressDetails;
  }

  // BEGIN, CR00060595, PCAL
  // ___________________________________________________________________________
  /**
   * Method returns a list of Employer Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key The Employer record the snapshots are associated with.
   *
   * @return The list of Employer snapshot details
   */
  @Override
  public ReadEmployerHistoryList
    listEmployerHistory(final ReadEmployerHistoryListKey key)
      throws AppException, InformationalException {

    // Return struct
    final ReadEmployerHistoryList readEmployerHistoryList =
      new ReadEmployerHistoryList();

    // Retrieve the list of snap shot summary details
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj =
      MaintainConcernRoleDetailsFactory.newInstance();

    readEmployerHistoryList.historyDtls =
      maintainConcernRoleDetailsObj.listEmployerHistory(key.historyKey);

    // Get the context description by reading the concern role of
    // the Employer record associated with the list of Snapshots
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID =
      key.historyKey.concernRoleID;

    readEmployerHistoryList.participantContextDetails.participantContextDescriptionDetails =
      ParticipantContextFactory.newInstance()
        .readContextDescription(participantContextDescriptionKey);

    // Return the details
    return readEmployerHistoryList;
  }

  // END, CR00060595

  // BEGIN, CR00218664, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Employer#searchEmployer(EmployerSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployer(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Override
  @Deprecated
  public EmployerSearchResult1 search1(final EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // END, CR00282028
    final EmployerSearchRouter employerSearchRouterObj =
      EmployerSearchRouterFactory.newInstance();

    final EmployerSearchResult1 employerSearchResult =
      new EmployerSearchResult1();

    employerSearchResult.dtls = employerSearchRouterObj.search1(key.key);

    return employerSearchResult;
  }

  // END, CR00218664

  // BEGIN, CR00219812, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria. Does not return
   * names as hyperlinks as this is for popup pages.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Employer#searchEmployerForPopup(EmployerSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerForPopup(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Override
  @Deprecated
  public EmployerSearchResult1 search1ForPopup(final EmployerSearchKey1 key)
    throws AppException, InformationalException {

    // END, CR00282028
    final EmployerSearchRouter employerSearchRouterObj =
      EmployerSearchRouterFactory.newInstance();

    final EmployerSearchResult1 employerSearchResult =
      new EmployerSearchResult1();

    key.key.disableLinkInd = true;

    employerSearchResult.dtls = employerSearchRouterObj.search1(key.key);

    return employerSearchResult;
  }

  // END, CR00219812

  // BEGIN, CR00233791, DJ
  /**
   * Cancels a concern role address record.
   *
   * @param key
   * contains the concern role address which is to be canceled
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAddress(key);
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * contains the concern role alternate id which is being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAlternateID(key);
  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * contains the key to cancel the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunication(key);
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * contains the ID of the communication exception being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunicationException(key);
  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * contains the contact ID for the record being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelContact(final CancelContactKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelContact(key);
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * contains the ID of the email address being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelEmailAddress(key);
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * contains the details to create a participant note.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelNote(final CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelNote(details);
  }

  /**
   * Cancel a bank account for a participant.
   * This method handles the cancellation of normal bank account
   * as well as joint accounts.
   *
   * @param key contains the ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList
    cancelParticipantBankAccount(final CancelParticipantBankAccountKey key)
      throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();
    final Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.cancelParticipantBankAccount(key);
    return informationMsgDtlsList;
  }

  /**
   * Cancels a phone number record.
   *
   * @param key
   * contains the concern role phone number ID of the phone record being
   * canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelPhoneNumber(key);
  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * contains the details of the web address to cancel
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void
    cancelWebAddress(final CancelParticipantWebAddressDetails details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelWebAddress(details);
  }

  /**
   * Creates a concern role address record.
   *
   * @param details
   * contains the concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantAddressDetails
    createAddress(final MaintainParticipantAddressDetails details)
      throws AppException, InformationalException {

    CreateParticipantAddressDetails createParticipantAddressDetails =
      new CreateParticipantAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantAddressDetails = delegate.createAddress(details);
    return createParticipantAddressDetails;
  }

  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdministrator(participantAdministratorDetails);
  }

  /**
   * Create a new administrator for the concernRole supplied.
   *
   * @param details
   * contains the administrator role details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#createAdministrator(ParticipantAdministratorDetails)}
   */
  @Override
  @Deprecated
  public void createAdminRole(final CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdminRole(details);
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * contains the concern role ID and alternate id details being
   * entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantAlternateIDDetails
    createAlternateID(final MaintainParticipantAlternateIDDetails details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails =
      new CreateParticipantAlternateIDDetails();

    createParticipantAlternateIDDetails = delegate.createAlternateID(details);
    return createParticipantAlternateIDDetails;
  }

  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void cancelBankAccount(final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    // BEGIN, CR00247430, MR
    delegate.cancelParticipantBankAccount(key);
    // END, CR00247430
  }

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * contains the concern role communication exception details being
   * entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createCommunicationException(details);
  }

  /**
   * Create a contact.
   *
   * @param details
   * contains the contact details being entered
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createContact(details);
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * contains the registration details for the contact
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createContactFromUnregisteredParticipant(
    final CreateContactFromUnregisteredParticipant details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createContactFromUnregisteredParticipant(details);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * contains the email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantEmailAddressDetails
    createEmailAddress(final MaintainParticipantEmailAddressDetails details)
      throws AppException, InformationalException {

    CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails =
      new CreateParticipantEmailAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantEmailAddressDetails =
      delegate.createEmailAddress(details);
    return createParticipantEmailAddressDetails;
  }

  /**
   * Creates an email communication.
   *
   * @param details
   * contains the details to create the email communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Communication#createEmail(curam.core.facade.struct.CreateEmailCommDetails)}
   */
  @Override
  @Deprecated
  public void
    createEmailCommunication(final CreateEmailCommunicationDetails details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createEmailCommunication(details);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * contains the details to create the freeform communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void
    createFreeformCommunincation(final CreateFreeformCommunication details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createFreeformCommunincation(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createHomePhoneNumber(final CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createHomePhoneNumber(key);
  }

  /**
   * This method creates a mailing address for a participant.
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createMailingAddress(final CreateMailingAddress key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createMailingAddress(key);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * contains the participant note details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createNote(details);
  }

  /**
   * Creates a concern role phone number record.
   *
   * @param details
   * contains the concern role identifier & concern role phone number
   * details
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantPhoneDetails
    createPhoneNumber(final MaintainParticipantPhoneDetails details)
      throws AppException, InformationalException {

    CreateParticipantPhoneDetails createParticipantPhoneDetails =
      new CreateParticipantPhoneDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantPhoneDetails = delegate.createPhoneNumber(details);
    return createParticipantPhoneDetails;
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * contains the details to create the template communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void
    createTemplateCommunication(final CreateTemplateCommunication details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createTemplateCommunication(details);
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * contains the web address details being entered
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createWebAddress(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void createWorkPhoneNumber(final CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.createWorkPhoneNumber(key);
  }

  /**
   * Display the address given as a single line. The address is formatted base
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData The address formatted with its descriptors i.e.
   * ADD1=Line1, ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AddressString
    displaySingleLineAddress(final OtherAddressData otherAddressData)
      throws AppException, InformationalException {

    AddressString addressString = new AddressString();
    final Participant delegate = ParticipantFactory.newInstance();

    addressString = delegate.displaySingleLineAddress(otherAddressData);
    return addressString;
  }

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * Contains the concern role ID & the case ID
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.endDeduction(details);
  }

  /**
   * Formats the bank account details for a participant. The bank details
   * are formatted to display as a single line of text. The formatting is
   * decided by a system variable.
   *
   * @param bankAccountRMDtls bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public BankAccountString
    formatBankAcDetailsString(final BankAccountRMDtls bankAccountRMDtls)
      throws AppException, InformationalException {

    BankAccountString bankAccountString = new BankAccountString();
    final Participant delegate = ParticipantFactory.newInstance();

    bankAccountString = delegate.formatBankAcDetailsString(bankAccountRMDtls);
    return bankAccountString;
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void insertPrimaryResidenceAddress(final InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.insertPrimaryResidenceAddress(key);
  }

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantActiveAddressList
    listActiveAddresses(final ReadParticipantAddressListKey key)
      throws AppException, InformationalException {

    final ReadParticipantActiveAddressList readParticipantActiveAddressList =
      new ReadParticipantActiveAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveAddresses(key);
    return readParticipantActiveAddressList;
  }

  /**
   * Method to list all active bank accounts for a Case Nominee.
   *
   * @param key
   * contains the concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadActiveBankAccountList
    listActiveBankAccount(final ReadParticipantBankAccountListKey key)
      throws AppException, InformationalException {

    final ReadActiveBankAccountList readActiveBankAccountList =
      new ReadActiveBankAccountList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveBankAccount(key);
    return readActiveBankAccountList;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam V6.0. This method is replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Override
  @Deprecated
  public BankAccountListForRedirectionDetails
    listActiveBankAccountForRedirection(
      final ParticipantBankAccountRedirectionKey key)
      throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails =
      new BankAccountListForRedirectionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails =
      delegate.listActiveBankAccountForRedirection(key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public BankAccountListForRedirectionDetails
    listActiveBankAccountForRedirection1(
      final ParticipantBankAccountRedirectionKey1 key)
      throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails =
      new BankAccountListForRedirectionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails =
      delegate.listActiveBankAccountForRedirection1(key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAddressList
    listAddress(final ReadParticipantAddressListKey key)
      throws AppException, InformationalException {

    ReadParticipantAddressList readParticipantAddressList =
      new ReadParticipantAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressList = delegate.listAddress(key);
    return readParticipantAddressList;
  }

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key contains the Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadAddressHistoryList
    listAddressHistory(final ReadAddressHistoryListKey key)
      throws AppException, InformationalException {

    ReadAddressHistoryList readAddressHistoryList =
      new ReadAddressHistoryList();
    final Participant delegate = ParticipantFactory.newInstance();

    readAddressHistoryList = delegate.listAddressHistory(key);
    return readAddressHistoryList;
  }

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantAddressStringList
    listAddressString(final ReadParticipantAddressListKey key)
      throws AppException, InformationalException {

    final ParticipantAddressStringList participantAddressStringList =
      new ParticipantAddressStringList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listAddressString(key);
    return participantAddressStringList;
  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ParticipantAdministratorDetailsList listAdministrators(
    final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList =
      new ParticipantAdministratorDetailsList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList =
      delegate.listAdministrators(readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is returned
   *
   * @return The list of administrators for the duplicate concern role
   * specified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public ParticipantAdministratorDetailsList
    listAdministratorsForDuplicateParticipant(
      final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
      throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList =
      new ParticipantAdministratorDetailsList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList =
      delegate.listAdministratorsForDuplicateParticipant(
        readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministrators(ReadParticipantAdminRoleListKey)}
   */
  @Override
  @Deprecated
  public ReadParticipantAdminRoleList
    listAdminRole(final ReadParticipantAdminRoleListKey key)
      throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList =
      new ReadParticipantAdminRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAdminRoleList = delegate.listAdminRole(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministratorsForDuplicateParticipant(ReadParticipantAdminRoleListKey)}
   */
  @Override
  @Deprecated
  public ReadParticipantAdminRoleList
    listAdminRoleForDuplicate(final ReadParticipantAdminRoleListKey key)
      throws AppException, InformationalException {

    final ReadParticipantAdminRoleList readParticipantAdminRoleList =
      new ReadParticipantAdminRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listAdminRoleForDuplicate(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAlternateIDList
    listAlternateID(final ReadParticipantAlternateIDListKey key)
      throws AppException, InformationalException {

    ReadParticipantAlternateIDList readParticipantAlternateIDList =
      new ReadParticipantAlternateIDList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDList = delegate.listAlternateID(key);
    return readParticipantAlternateIDList;
  }

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the alternateID of the AlternateID record the snapshots
   * are associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAltIDHistoryList
    listAlternateIDHistory(final ReadParticipantAltIDHistoryListKey key)
      throws AppException, InformationalException {

    ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList =
      new ReadParticipantAltIDHistoryList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAltIDHistoryList = delegate.listAlternateIDHistory(key);
    return readParticipantAltIDHistoryList;
  }

  /**
   * Method returns a list of Assessments for the participant.
   *
   * @param concernRoleKey contains the concern role that the assessments were
   * created for.
   *
   * @return The list of Assessments for the concern role.
   */
  @Override
  public ParticipantAssessmentsList
    listAssessments(final ConcernRoleKey concernRoleKey)
      throws AppException, InformationalException {

    ParticipantAssessmentsList participantAssessmentsList =
      new ParticipantAssessmentsList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantAssessmentsList = delegate.listAssessments(concernRoleKey);
    return participantAssessmentsList;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of bank accounts is
   * returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAccountList
    listBankAccount(final ReadParticipantBankAccountListKey key)
      throws AppException, InformationalException {

    ReadParticipantBankAccountList readParticipantBankAccountList =
      new ReadParticipantBankAccountList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountList = delegate.listBankAccount(key);
    return readParticipantBankAccountList;
  }

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAcHistoryList
    listBankAccountHistory(final ReadParticipantBankAcHistoryListKey key)
      throws AppException, InformationalException {

    ReadParticipantBankAcHistoryList readParticipantBankAcHistoryList =
      new ReadParticipantBankAcHistoryList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAcHistoryList = delegate.listBankAccountHistory(key);
    return readParticipantBankAcHistoryList;
  }

  /**
   * Lists the formatted bank account details. The bank details
   * are formatted to display as a single line of text.
   *
   * @param key concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantBankAccountStringList
    listBankAccountString(final MaintainConcernRoleKey key)
      throws AppException, InformationalException {

    ParticipantBankAccountStringList participantBankAccountStringList =
      new ParticipantBankAccountStringList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantBankAccountStringList = delegate.listBankAccountString(key);
    return participantBankAccountStringList;
  }

  /**
   * Lists all communications by case ID.
   *
   * @param key Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CommunicationDetailList
    listCommunication(final ParticipantCommunicationKey key)
      throws AppException, InformationalException {

    CommunicationDetailList communicationDetailList =
      new CommunicationDetailList();
    final Participant delegate = ParticipantFactory.newInstance();

    communicationDetailList = delegate.listCommunication(key);
    return communicationDetailList;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of communication
   * exceptions are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    final ReadParticipantCommunicationExceptionListKey key)
    throws AppException, InformationalException {

    ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList =
      new ReadParticipantCommunicationExceptionList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantCommunicationExceptionList =
      delegate.listCommunicationException(key);
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantConcernRoleList
    listConcernRole(final ReadParticipantConcernRoleKey key)
      throws AppException, InformationalException {

    ReadParticipantConcernRoleList readParticipantConcernRoleList =
      new ReadParticipantConcernRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantConcernRoleList = delegate.listConcernRole(key);
    return readParticipantConcernRoleList;
  }

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadDuplicateParticipantConcernRoleList
    listConcernRoleForDuplicate(final ReadParticipantConcernRoleKey key)
      throws AppException, InformationalException {

    ReadDuplicateParticipantConcernRoleList readDuplicateParticipantConcernRoleList =
      new ReadDuplicateParticipantConcernRoleList();
    final Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantConcernRoleList =
      delegate.listConcernRoleForDuplicate(key);
    return readDuplicateParticipantConcernRoleList;
  }

  // BEGIN, CR00294967, MV
  /**
   * A list of contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3,
   * replaced by {@link #listConcernContact()}.
   * The return struct of the current method listContact has an aggregation
   * to the struct ConcernContactRMDtls, the attribute statusCode in the struct
   * ConcernContactRMDtls is modeled with a domain of CONTACTSTATUS code-table,
   * but the corresponding entity attribute ConcernRoleContactDtls.statusCode
   * is modeled with a domain of RECORD_STATUS_CODE. So new method is introduced
   * to return new struct ListConcernContactDetails which has an aggregation
   * to the new struct ConcernContactRMultiDtls where the attribute
   * statusCode is modeled with a domain of RECORD_STATUS_CODE.
   * See release note: CEF-8999.
   */
  @Override
  @Deprecated
  // END, CR00294967
  public ListContactDetails listContact(final ListContactKey key)
    throws AppException, InformationalException {

    ListContactDetails listContactDetails = new ListContactDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listContactDetails = delegate.listContact(key);
    return listContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Lists the contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListConcernContactDetails listConcernContact(
    final ListContactKey key) throws AppException, InformationalException {

    ListConcernContactDetails listConcernContactDetails =
      new ListConcernContactDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listConcernContactDetails = delegate.listConcernContact(key);
    return listConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */

  @Override
  public ReadParticipantDeductionList
    listDeduction(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ReadParticipantDeductionList readParticipantDeductionList =
      new ReadParticipantDeductionList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList = delegate.listDeduction(key);
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantDeductionList1
    listDeduction1(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ReadParticipantDeductionList1 readParticipantDeductionList1 =
      new ReadParticipantDeductionList1();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList1 = delegate.listDeduction1(key);
    return readParticipantDeductionList1;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadDuplicateParticipantDeductionList
    listDeductionForDuplicate(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ReadDuplicateParticipantDeductionList readDuplicateParticipantDeductionList =
      new ReadDuplicateParticipantDeductionList();
    final Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantDeductionList =
      delegate.listDeductionForDuplicate(key);
    return readDuplicateParticipantDeductionList;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of email addresses
   * is returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantEmailAddressList
    listEmailAddress(final ReadParticipantEmailAddressListKey key)
      throws AppException, InformationalException {

    ReadParticipantEmailAddressList readParticipantEmailAddressList =
      new ReadParticipantEmailAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressList = delegate.listEmailAddress(key);
    return readParticipantEmailAddressList;
  }

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FormattedAddressList listFormattedAddress(
    final ReadParticipantFormattedAddressListKey readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    FormattedAddressList formattedAddressList = new FormattedAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    formattedAddressList =
      delegate.listFormattedAddress(readParticipantFormattedAddressListKey);
    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public FormattedBankAccountList listFormattedBankAccount(
    final ReadParticipantFormattedBankAccountListKey readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    FormattedBankAccountList formattedBankAccountList =
      new FormattedBankAccountList();
    final Participant delegate = ParticipantFactory.newInstance();

    formattedBankAccountList = delegate
      .listFormattedBankAccount(readParticipantFormattedBankAccountListKey);
    return formattedBankAccountList;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListInteractionDetails listInteractionDetails =
      new ListInteractionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listInteractionDetails = delegate.listInteraction(key);
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantInteractionDetails
    listInteractionForDuplicate(final ListInteractionKey key)
      throws AppException, InformationalException {

    ListDuplicateParticipantInteractionDetails listDuplicateParticipantInteractionDetails =
      new ListDuplicateParticipantInteractionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantInteractionDetails =
      delegate.listInteractionForDuplicate(key);
    return listDuplicateParticipantInteractionDetails;
  }

  /**
   * Method returns a list of Investigations for the participant.
   *
   * @param key contains the concern role that the investigations
   * were created for.
   *
   * @return The list of Investigations for the concern role.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantInvestigationList listInvestigations(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    ParticipantInvestigationList participantInvestigationList =
      new ParticipantInvestigationList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantInvestigationList = delegate.listInvestigations(key);
    return participantInvestigationList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListParticipantIssuedPaymentInstrument
    listIssuedPaymentInstrument(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument =
      new ListParticipantIssuedPaymentInstrument();
    final Participant delegate = ParticipantFactory.newInstance();

    listParticipantIssuedPaymentInstrument =
      delegate.listIssuedPaymentInstrument(key);
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantIssuedPaymentInstrument
    listIssuedPaymentInstrumentForDuplicate(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPaymentInstrument =
      new ListDuplicateParticipantIssuedPaymentInstrument();
    final Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantIssuedPaymentInstrument =
      delegate.listIssuedPaymentInstrumentForDuplicate(key);
    return listDuplicateParticipantIssuedPaymentInstrument;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listNote1()}
   */
  @Override
  @Deprecated
  public ParticipantNoteList listNote(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList participantNoteList = new ParticipantNoteList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote(key);
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantNoteList1 listNote1(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList1 participantNoteList = new ParticipantNoteList1();
    final Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote1(key);
    return participantNoteList;
  }

  // END, CR00231506

  /**
   * @param key
   * contains the key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listParticipantFinancial1()}.
   * Returns a list of financials for a participant.
   */
  @Override
  @Deprecated
  public ListParticipantFinancials
    listParticipantFinancial(final ListParticipantFinancialsKey key)
      throws AppException, InformationalException {

    ListParticipantFinancials listParticipantFinancials =
      new ListParticipantFinancials();
    final Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials = delegate.listParticipantFinancial(key);
    return listParticipantFinancials;
  }

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListParticipantFinancials1
    listParticipantFinancial1(final ListParticipantFinancialsKey key)
      throws AppException, InformationalException {

    ListParticipantFinancials1 listParticipantFinancials1 =
      new ListParticipantFinancials1();
    final Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials1 = delegate.listParticipantFinancial1(key);
    return listParticipantFinancials1;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListDuplicateParticipantFinancials
    listParticipantFinancialForDuplicate(
      final ListParticipantFinancialsKey key)
      throws AppException, InformationalException {

    ListDuplicateParticipantFinancials listDuplicateParticipantFinancials =
      new ListDuplicateParticipantFinancials();
    final Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantFinancials =
      delegate.listParticipantFinancialForDuplicate(key);
    return listDuplicateParticipantFinancials;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * contains the key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public TasksForConcernAndCaseDetails
    listParticipantTask(final ListParticipantTaskKey_eo key)
      throws AppException, InformationalException {

    TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails =
      new TasksForConcernAndCaseDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    tasksForConcernAndCaseDetails = delegate.listParticipantTask(key);
    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public TasksForDuplicateConcernAndCaseDetails
    listParticipantTaskForDuplicate(final ListParticipantTaskKey_eo key)
      throws AppException, InformationalException {

    TasksForDuplicateConcernAndCaseDetails tasksForDuplicateConcernAndCaseDetails =
      new TasksForDuplicateConcernAndCaseDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    tasksForDuplicateConcernAndCaseDetails =
      delegate.listParticipantTaskForDuplicate(key);
    return tasksForDuplicateConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role.
   *
   * @param key
   * contains the concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantPhoneNumberList
    listPhoneNumber(final ReadParticipantPhoneNumberListKey key)
      throws AppException, InformationalException {

    ReadParticipantPhoneNumberList readParticipantPhoneNumberList =
      new ReadParticipantPhoneNumberList();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberList = delegate.listPhoneNumber(key);
    return readParticipantPhoneNumberList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   */
  @Override
  public ParticipantScreeningList listScreeningCases(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    ParticipantScreeningList participantScreeningList =
      new ParticipantScreeningList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantScreeningList = delegate.listScreeningCases(key);
    return participantScreeningList;
  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * contains the key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key)
    throws AppException, InformationalException {

    ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant =
      new ListTemplateByTypeAndParticpant();
    final Participant delegate = ParticipantFactory.newInstance();

    listTemplateByTypeAndParticpant =
      delegate.listTemplateByTypeAndParticipant(key);
    return listTemplateByTypeAndParticpant;
  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of web addresses is
   * returned
   * @return The list of web addresses returned from the database
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantWebAddressList
    listWebAddress(final ParticipantWebAddressListKey key)
      throws AppException, InformationalException {

    ParticipantWebAddressList participantWebAddressList =
      new ParticipantWebAddressList();
    final Participant delegate = ParticipantFactory.newInstance();

    participantWebAddressList = delegate.listWebAddress(key);
    return participantWebAddressList;
  }

  /**
   * Modifies an address record for a concern role.
   *
   * @param details
   * contains the concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ModifiedAddressDetails
    modifyAddress(final MaintainParticipantAddressDetails details)
      throws AppException, InformationalException {

    ModifiedAddressDetails modifiedAddressDetails =
      new ModifiedAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    modifiedAddressDetails = delegate.modifyAddress(details);
    return modifiedAddressDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * contains the concern role ID and alternate id detail being
   * modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ModifiedAlternateIDDetails
    modifyAlternateID(final MaintainParticipantAlternateIDDetails details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ModifiedAlternateIDDetails modifiedAlternateIDDetails =
      new ModifiedAlternateIDDetails();

    modifiedAlternateIDDetails = delegate.modifyAlternateID(details);
    return modifiedAlternateIDDetails;
  }

  /**
   * @param details
   * contains the bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}.
   * Modify the bank account details for a participant.
   */
  @Override
  @Deprecated
  public InformationMsgDtlsList
    modifyBankAccount(final MaintainParticipantBankAccountDetails details)
      throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();
    final Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccount(details);
    return informationMsgDtlsList;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * contains the details to modify the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunication(details);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * contains the concern role communication exception details being
   * modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunicationException(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #modifyConcernContact()}.
   * The parameter struct of the current method modifyContact has
   * an aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to have new parameter ModifyConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyContact(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyConcernContact(details);
  }

  // END, CR00294967

  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * contains the email address details being modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void
    modifyEmailAddress(final MaintainParticipantEmailAddressDetails details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyEmailAddress(details);
  }

  // BEGIN, CR00231506, PDN
  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #modifyNote1()}
   */
  @Override
  @Deprecated
  public void modifyNote(final ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote(details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyNote1(final ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote1(details);
  }

  // END, CR00231506

  /**
   * Modifies a phone number record for a concern role.
   *
   * @param details
   * contains the concern role id and concern role phone number details
   * that will be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyPhoneNumber(details);
  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * contains the details of the sent communication to be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void
    modifySentCommunication(final ModifySentCommunicationDetails details)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifySentCommunication(details);
  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * contains the web address details being modified
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyWebAddress(details);
  }

  /**
   * Prints a communication.
   *
   * @param details
   * contains details to print the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.printCommunication(details);
  }

  /**
   * Reads an address record for a concern role.
   *
   * @param key
   * contains the concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAddressDetails
    readAddress(final ReadParticipantAddressKey key)
      throws AppException, InformationalException {

    ReadParticipantAddressDetails readParticipantAddressDetails =
      new ReadParticipantAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressDetails = delegate.readAddress(key);
    return readParticipantAddressDetails;
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * contains the concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantAlternateIDDetails
    readAlternateID(final ReadParticipantAlternateIDKey key)
      throws AppException, InformationalException {

    ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails =
      new ReadParticipantAlternateIDDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDDetails = delegate.readAlternateID(key);
    return readParticipantAlternateIDDetails;
  }

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * contains the bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantBankAccountDetails
    readBankAccount(final ReadParticipantBankAccountKey key)
      throws AppException, InformationalException {

    ReadParticipantBankAccountDetails readParticipantBankAccountDetails =
      new ReadParticipantBankAccountDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountDetails = delegate.readBankAccount(key);
    return readParticipantBankAccountDetails;
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadCommDetails readCommDetails = new ReadCommDetails();

    readCommDetails = delegate.readCommunication(key);
    return readCommDetails;
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * contains the key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails =
      new ReadCommunicationAttachmentDetails();

    readCommunicationAttachmentDetails =
      delegate.readCommunicationAttachment(key);
    return readCommunicationAttachmentDetails;
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * contains the communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantCommunicationExceptionDetails
    readCommunicationException(
      final ReadParticipantCommunicationExceptionKey key)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails =
      new ReadParticipantCommunicationExceptionDetails();

    readParticipantCommunicationExceptionDetails =
      delegate.readCommunicationException(key);
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * contains the concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ConcernRoleTypeDetails
    readConcernRoleType(final ReadParticipantConcernRoleKey key)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails =
      new ConcernRoleTypeDetails();

    concernRoleTypeDetails = delegate.readConcernRoleType(key);
    return concernRoleTypeDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #readConcernContact()}.
   * The
   * return struct of the current method readContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ReadConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  @Deprecated
  @Override
  public ReadContactDetails readContact(final ReadContactKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadContactDetails readContactDetails = new ReadContactDetails();

    readContactDetails = delegate.readContact(key);
    return readContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadConcernContactDetails readConcernContact(
    final ReadContactKey key) throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadConcernContactDetails readConcernContactDetails =
      new ReadConcernContactDetails();

    readConcernContactDetails = delegate.readConcernContact(key);
    return readConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * contains the concern role ID for which the description is
   * retrieved.
   *
   * @return The returned description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantContextDetails
    readContextDescription(final ParticipantContextKey key)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ParticipantContextDetails participantContextDetails =
      new ParticipantContextDetails();

    participantContextDetails = delegate.readContextDescription(key);
    return participantContextDetails;
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * contains the email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantEmailAddressDetails
    readEmailAddress(final ReadParticipantEmailAddressKey key)
      throws AppException, InformationalException {

    ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails =
      new ReadParticipantEmailAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressDetails = delegate.readEmailAddress(key);
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadInteractionDetails readInteraction(final ReadInteractionKey key)
    throws AppException, InformationalException {

    ReadInteractionDetails readInteractionDetails =
      new ReadInteractionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readInteractionDetails = delegate.readInteraction(key);
    return readInteractionDetails;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #premodifyNote1()}
   */
  @Override
  @Deprecated
  public ReadParticipantNoteDetails readNote(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails readParticipantNoteDetails =
      new ReadParticipantNoteDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote(key);
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantNoteDetails1 readNote1(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails1 readParticipantNoteDetails =
      new ReadParticipantNoteDetails1();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote1(key);
    return readParticipantNoteDetails;
  }

  // END, CR00231506

  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * contains the contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ContactContextDescriptionDetails
    readParticipantContactContextDescription(
      final ContactContextDescriptionKey key)
      throws AppException, InformationalException {

    ContactContextDescriptionDetails contactContextDescriptionDetails =
      new ContactContextDescriptionDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    contactContextDescriptionDetails =
      delegate.readParticipantContactContextDescription(key);
    return contactContextDescriptionDetails;
  }

  /**
   * Reads a phone number record for a concern role.
   *
   * @param key contains the concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantPhoneNumberDetails
    readPhoneNumber(final ReadParticipantPhoneNumberKey key)
      throws AppException, InformationalException {

    ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails =
      new ReadParticipantPhoneNumberDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberDetails = delegate.readPhoneNumber(key);
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * contains the web address ID of the record being read.
   *
   * @return The web address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReadParticipantWebAddressDetails
    readWebAddress(final ParticipantWebAddressKey key)
      throws AppException, InformationalException {

    ReadParticipantWebAddressDetails readParticipantWebAddressDetails =
      new ReadParticipantWebAddressDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    readParticipantWebAddressDetails = delegate.readWebAddress(key);
    return readParticipantWebAddressDetails;
  }

  /**
   * Records an existing communication.
   *
   * @param details
   * contains the details of the existing communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Override
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.recordExistingCommunication(details);
  }

  /**
   * Removes an address record for a concern role.
   *
   * @param key contains the concern role address key
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.removeAddress(key);
  }

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key contains the concern Role ID of the record being read.
   *
   * @return The home page name.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ParticipantHomePageName
    resolveProspectHome(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    ParticipantHomePageName participantHomePageName =
      new ParticipantHomePageName();
    final Participant delegate = ParticipantFactory.newInstance();

    participantHomePageName = delegate.resolveProspectHome(key);
    return participantHomePageName;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key Participant search criteria
   *
   * @return Participant details found
   *
   * @throws AppException Application Exception
   *
   * @throws InformationalException Informational Exception
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Employer#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchParticipantDetails(AllParticipantSearchKey)
   * which returns the informational message along with participant details
   * as well. See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public AllParticipantSearchResult
    searchParticipant(final AllParticipantSearchKey key)
      throws AppException, InformationalException {

    // END, CR00290965

    AllParticipantSearchResult allParticipantSearchResult =
      new AllParticipantSearchResult();
    final Participant delegate = ParticipantFactory.newInstance();

    allParticipantSearchResult = delegate.searchParticipant(key);
    return allParticipantSearchResult;
  }

  /**
   * Sends an email communication.
   *
   * @Deprecated
   * @param details
   * contains the details to send the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.sendEmailCommunication(details);
  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * contains the concern role ID and the bank
   * account ID of the bank for which payment will now be made to.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void
    updateBankAccountPaymentDetails(final UpdateBankAccPaymentDtlsKey key)
      throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.updateBankAccountPaymentDetails(key);
  }

  /**
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}.
   * Create a new bank account for a participant.
   */
  @Override
  @Deprecated
  public CreateParticipantBankAccountDetails
    createBankAccount(final MaintainParticipantBankAccountDetails details)
      throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails =
      new CreateParticipantBankAccountDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccount(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CreateParticipantBankAccountDetails
    createBankAccountWithTextSortCode(
      final MaintainParticipantBankAccountWithTextSortCodeDetails details)
      throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails =
      new CreateParticipantBankAccountDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails =
      delegate.createBankAccountWithTextSortCode(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();
    final Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList =
      delegate.modifyBankAccountWithTextSortCode(details);
    return informationMsgDtlsList;
  }

  // END, CR00233791

  // BEGIN, CR00264512, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria. Excludes prospect
   * employers. Does not return names as hyperlinks as this is for popup pages.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Employer#searchEmployerWithoutProspectForPopup(EmployerSearchKey1)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerWithoutProspectForPopup(EmployerSearchKey1) which
   * returns the informational message along with search employer
   * details as well. See release note: CS-09152/CR00282028.
   */
  @Override
  @Deprecated
  public EmployerSearchResult1
    searchWithoutProspectForPopup(final EmployerSearchKey1 key)
      throws AppException, InformationalException {

    // END, CR00282028
    final EmployerSearchRouter employerSearchRouterObj =
      EmployerSearchRouterFactory.newInstance();

    final EmployerSearchResult1 employerSearchResult =
      new EmployerSearchResult1();

    key.key.disableLinkInd = true;

    employerSearchResult.dtls = employerSearchRouterObj.search1(key.key);

    for (int i = 0; i < employerSearchResult.dtls.dtlsList.size(); i++) {
      if (employerSearchResult.dtls.dtlsList.item(i).employerTabDetailsURL
        .substring(CuramConst.gkZero,
          CuramConst.gkProspectEmployerTabDetailsPage.length())
        .equals(CuramConst.gkProspectEmployerTabDetailsPage)) {
        employerSearchResult.dtls.dtlsList.remove(i--);
      }
    }

    // BEGIN, CR00264925, ZV
    // If no search results are found, alert user
    if (employerSearchResult.dtls.dtlsList.isEmpty()) {

      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);

      informationalManager.failOperation();

    }
    // END, CR00264925

    return employerSearchResult;
  }

  // END, CR00264512

  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param employerSearchKey1
   * contains employer search key.
   *
   * @return employer details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EmployerSearchDetailsResult
    searchEmployer(final EmployerSearchKey1 employerSearchKey1)
      throws AppException, InformationalException {

    final EmployerSearchDetailsResult employerSearchResult =
      new EmployerSearchDetailsResult();

    final EmployerSearchRouter employerSearchRouterObj =
      EmployerSearchRouterFactory.newInstance();

    employerSearchResult.dtls =
      employerSearchRouterObj.search1(employerSearchKey1.key);
    collectInformationalMsgs(employerSearchResult.informationalMsgDtls);
    return employerSearchResult;
  }

  /**
   * Searches for an employer by specified search criteria. This is used for
   * popup pages and does not return names as hyperlinks.
   *
   * @param employerSearchKey1
   * contains employer search key.
   *
   * @return employer details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EmployerSearchDetailsResult
    searchEmployerForPopup(final EmployerSearchKey1 employerSearchKey1)
      throws AppException, InformationalException {

    final EmployerSearchRouter employerSearchRouterObj =
      EmployerSearchRouterFactory.newInstance();

    final EmployerSearchDetailsResult employerSearchResult =
      new EmployerSearchDetailsResult();

    employerSearchKey1.key.disableLinkInd = true;

    employerSearchResult.dtls =
      employerSearchRouterObj.search1(employerSearchKey1.key);

    collectInformationalMsgs(employerSearchResult.informationalMsgDtls);

    return employerSearchResult;
  }

  /**
   * Searches for an employer by specified search criteria. Excludes prospect
   * employers. This is used for popup pages and does not return names as
   * hyperlinks.
   *
   * @param employerSearchKey1
   * contains employer search key.
   *
   * @return employer details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public EmployerSearchDetailsResult searchEmployerWithoutProspectForPopup(
    final EmployerSearchKey1 employerSearchKey1)
    throws AppException, InformationalException {

    final EmployerSearchRouter employerSearchRouterObj =
      EmployerSearchRouterFactory.newInstance();

    final EmployerSearchDetailsResult employerSearchResult =
      new EmployerSearchDetailsResult();

    employerSearchKey1.key.disableLinkInd = true;
    // BEGIN, 268814, SH
    employerSearchKey1.key.showProspectEmployersIndOpt = false;
    employerSearchResult.dtls =
      employerSearchRouterObj.search1(employerSearchKey1.key);
    // END, 268814

    if (employerSearchResult.dtls.dtlsList.isEmpty()) {

      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);

      informationalManager.failOperation();
    }

    collectInformationalMsgs(employerSearchResult.informationalMsgDtls);

    return employerSearchResult;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00282028

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey contains all participant search key
   *
   * @return participant search details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  @Override
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey)
    throws AppException, InformationalException {

    AllParticipantSearchDetails allParticipantSearchDetails =
      new AllParticipantSearchDetails();

    final Participant participant = ParticipantFactory.newInstance();

    allParticipantSearchDetails =
      participant.searchParticipantDetails(allParticipantSearchKey);

    return allParticipantSearchDetails;
  }

  // END, CR00290965

  // BEGIN, CR00406231, SS
  /*
   * (non-Javadoc)
   *
   * @see
   * curam.core.facade.intf.Employer#searchAndAssociateToEmployer(curam.core
   * .facade.struct.EmployerSearchAndAssociateKey)
   */
  @Override
  public EmployerSearchDetailsResult searchAndAssociateToEmployer(
    final EmployerSearchAndAssociateKey employerSearchAndAssociateKey)
    throws AppException, InformationalException {

    final EmployerSearchDetailsResult employerSearchResult =
      new EmployerSearchDetailsResult();

    if (CuramConst.kSearchAction
      .equalsIgnoreCase(employerSearchAndAssociateKey.actionString)) {
      final EmployerSearchRouter employerSearchRouterObj =
        EmployerSearchRouterFactory.newInstance();

      // BEGIN, 268814, SH
      employerSearchAndAssociateKey.key.showProspectEmployersIndOpt = true;
      // END, 268814
      employerSearchResult.dtls =
        employerSearchRouterObj.search1(employerSearchAndAssociateKey.key);

      collectInformationalMsgs(employerSearchResult.informationalMsgDtls);

      return employerSearchResult;
    }
    if (CuramConst.kSaveAction
      .equalsIgnoreCase(employerSearchAndAssociateKey.actionString)) {

      final ReadProspectEmployerHomeDetails employerAndProspectDetails =
        new ReadProspectEmployerHomeDetails();

      employerAndProspectDetails.details.employerConcernRoleID =
        employerSearchAndAssociateKey.userSelectedEmployerConcernRoleID;
      employerAndProspectDetails.details.concernRoleID =
        employerSearchAndAssociateKey.prospectEmployerConcernRoleID;
      final ProspectEmployer prospectEmployerobj =
        ProspectEmployerFactory.newInstance();

      prospectEmployerobj
        .associateProspectWithRegisteredEmployer(employerAndProspectDetails);
      collectInformationalMsgs(employerSearchResult.informationalMsgDtls);

    }
    return employerSearchResult;
  }
  // END, CR00406231
}
