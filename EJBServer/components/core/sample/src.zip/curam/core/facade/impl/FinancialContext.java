/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2005-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.FINANCIALINSTRUCTION;
import curam.core.facade.struct.FinancialContextDescription;
import curam.core.facade.struct.FinancialContextDescriptionKey;
import curam.core.impl.CuramConst;
import curam.core.struct.AccountInstructionIdentifier;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.FinancialInstructionCaseDetails;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.ViewAdjustmentInstructionDetailResult;
import curam.core.struct.ViewLiabilityInstructionDetailResult1;
import curam.core.struct.ViewPaymentInstructionDetailResult;
import curam.core.struct.ViewPaymentReceivedInstructionDetailResult;
import curam.core.struct.ViewReversalInstructionDetailResult1;
import curam.core.struct.ViewWriteOffInstructionDetailResult1;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality to retrieve context
 * descriptions for a financial.
 *
 */
public abstract class FinancialContext extends curam.core.facade.base.FinancialContext {

  protected static final char kSlash = '/';

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.
   * getProgramLocale())}.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note CR00219408.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00023323
  // END, CR00222190

  // ___________________________________________________________________________
  /**
   * Generates the context description for the Product Delivery.
   *
   * @param financialContextDescriptionKey Context description identifier.
   *
   * @return A context description for a Product Delivery.
   */
  @Override
  public FinancialContextDescription readContextDescription(
    FinancialContextDescriptionKey financialContextDescriptionKey)
    throws AppException, InformationalException {

    // Create return object
    final FinancialContextDescription financialContextDescription = new FinancialContextDescription();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // Create and initialize StringBuffer
    final int kBufSize = 256;
    final StringBuffer contextDescription = new StringBuffer(kBufSize);

    // Assign key details to read Payment Instruction details
    accountInstructionIdentifier.finInstructionID = financialContextDescriptionKey.finInstructionID;

    // BEGIN, CR00160310, MC
    // Concern Role object and key. Used to read nominee primary alternate ID
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Financial instruction entity, key and details
    final curam.core.intf.FinancialInstruction financialInstructionObj = curam.core.fact.FinancialInstructionFactory.newInstance();

    final FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();
    FinancialInstructionCaseDetails financialInstructionCaseDetails;

    financialInstructionKey.finInstructionID = financialContextDescriptionKey.finInstructionID;

    financialInstructionCaseDetails = financialInstructionObj.readFinInstructIDEffDateTypeAmt(
      financialInstructionKey);

    String contextName = "";

    // Read the details for the correct type of instruction
    if (financialInstructionCaseDetails.typeCode.equals(
      FINANCIALINSTRUCTION.PAYMENT)) {

      // Call ViewConcernAccount BPO to search for the Payment Instruction
      // details
      final ViewPaymentInstructionDetailResult viewPaymentInstructionDetailResult = viewConcernAccountObj.viewPaymentInstructionDetail(
        accountInstructionIdentifier);

      if (viewPaymentInstructionDetailResult.paymentHeader.concernRoleType.equals(
        curam.codetable.CONCERNROLETYPE.PERSON)
          && viewPaymentInstructionDetailResult.paymentHeader.nomineeName.length()
            > 0) {
        contextName = viewPaymentInstructionDetailResult.paymentHeader.nomineeName;
        // Now get the reference number for the nominee
        concernRoleKey.concernRoleID = viewPaymentInstructionDetailResult.paymentHeader.concernRoleID;

      } else {
        contextName = viewPaymentInstructionDetailResult.paymentHeader.concernRoleName;
        concernRoleKey.concernRoleID = viewPaymentInstructionDetailResult.paymentHeader.concernRoleID;
      }
    } else if (financialInstructionCaseDetails.typeCode.equals(
      FINANCIALINSTRUCTION.ADJUSTMENT)) {

      final ViewAdjustmentInstructionDetailResult viewAdjustmentInstructionDetailResult = viewConcernAccountObj.viewAdjustmentInstructionDetail(
        accountInstructionIdentifier);

      contextName = viewAdjustmentInstructionDetailResult.adjustmentHeader.concernRoleName;
      concernRoleKey.concernRoleID = viewAdjustmentInstructionDetailResult.adjustmentHeader.concernRoleID;
    } else if (financialInstructionCaseDetails.typeCode.equals(
      FINANCIALINSTRUCTION.REVERSAL)) {
      // BEGIN, CR00232757, GD
      final ViewReversalInstructionDetailResult1 viewReversalInstructionDetailResult = viewConcernAccountObj.viewReversalInstructionDetail1(
        accountInstructionIdentifier);

      contextName = viewReversalInstructionDetailResult.reversalHeader.concernRoleName;
      concernRoleKey.concernRoleID = viewReversalInstructionDetailResult.reversalHeader.concernRoleID;
      // END, CR00232757
    } else if (financialInstructionCaseDetails.typeCode.equals(
      FINANCIALINSTRUCTION.LIABILITY)) {
      // BEGIN, CR00232757, GD
      final ViewLiabilityInstructionDetailResult1 viewLiabilityInstructionDetailResult = viewConcernAccountObj.viewLiabilityInstructionDetail1(
        accountInstructionIdentifier);

      contextName = viewLiabilityInstructionDetailResult.liabilityHeader.concernRoleName;
      concernRoleKey.concernRoleID = viewLiabilityInstructionDetailResult.liabilityHeader.concernRoleID;
      // END, CR00232757
    } else if (financialInstructionCaseDetails.typeCode.equals(
      FINANCIALINSTRUCTION.PAYMENTRECEIVED)) {
      final ViewPaymentReceivedInstructionDetailResult viewPaymentReceivedInstructionDetailResult = viewConcernAccountObj.viewPaymentReceivedInstructionDetail(
        accountInstructionIdentifier);

      contextName = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.concernRoleName;
      concernRoleKey.concernRoleID = viewPaymentReceivedInstructionDetailResult.pmtReceivedHeader.concernRoleID;
    } else if (financialInstructionCaseDetails.typeCode.equals(
      FINANCIALINSTRUCTION.WRITEOFF)) {
      final ViewWriteOffInstructionDetailResult1 viewWriteOffInstructionDetailResult = viewConcernAccountObj.viewWriteOffInstructionDetail1(
        accountInstructionIdentifier);

      contextName = viewWriteOffInstructionDetailResult.writeOffHeader.concernRoleName;
      concernRoleKey.concernRoleID = viewWriteOffInstructionDetailResult.writeOffHeader.concernRoleID;
    }

    // Append the description details
    contextDescription.append(contextName);
    // BEGIN, CR00222190, ELG
    contextDescription.append(CuramConst.gkSpace).append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())).append(
      concernRoleObj.readNameAlternateIDRegDate(concernRoleKey).primaryAlternateID);
    // END, CR00222190
    // END, CR00160310

    // BEGIN, CR00098942, SAI
    contextDescription.append(CuramConst.gkSpace);
    // END, CR00098942

    financialContextDescription.contextDescription = contextDescription.toString();

    return financialContextDescription;

  }

}
