/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2004, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2013 Curam Software Ltd.
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.ACCEPTANCESTATUS;
import curam.codetable.ACTIVITYATTENDEETYPE;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CALENDARVIEWTYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKSTATUS;
import curam.codetable.USERTYPE;
import curam.codetable.impl.ACTIVITYTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.struct.ActivityAttendeeDetails;
import curam.core.facade.struct.ActivityAttendeeList;
import curam.core.facade.struct.ActivityContextDescriptionDetails;
import curam.core.facade.struct.ActivityContextDescriptionKey;
import curam.core.facade.struct.ActivityContextDetails;
import curam.core.facade.struct.ActivityContextKey;
import curam.core.facade.struct.ActivityIdKey;
import curam.core.facade.struct.ActivityInvitationDetails;
import curam.core.facade.struct.ActivityInvitationKey;
import curam.core.facade.struct.ActivityListViewDetails;
import curam.core.facade.struct.CalendarDataDetails;
import curam.core.facade.struct.CancelRecurringOrganizationActivityKey;
import curam.core.facade.struct.CancelRecurringUserActivityKey;
import curam.core.facade.struct.CancelStandardOrganizationActivityKey;
import curam.core.facade.struct.CancelStandardUserActivityKey;
import curam.core.facade.struct.CreateRecurringOrganizationActivityDetails;
import curam.core.facade.struct.CreateRecurringUserActivityDetails;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.IsCurrentUserActivityOwner;
import curam.core.facade.struct.ListLocationHolidayDetails;
import curam.core.facade.struct.ListLocationHolidayKey;
import curam.core.facade.struct.MaintainAcceptanceStatusKey;
import curam.core.facade.struct.MaintainStandardActivityUserDetails;
import curam.core.facade.struct.MaintainStandardOrganizationActivityDetails;
import curam.core.facade.struct.MaintainUserActivityWithDefaultsDetails;
import curam.core.facade.struct.ModifyRecurringOrganizationActivityDetails;
import curam.core.facade.struct.ModifyRecurringUserActivityDetails;
import curam.core.facade.struct.NewActivityDetails;
import curam.core.facade.struct.OrganizationCalendarData;
import curam.core.facade.struct.OrganizationCalendarDataKey;
import curam.core.facade.struct.OrganizationContextDescriptionDetails;
import curam.core.facade.struct.OrganizationContextDescriptionKey;
import curam.core.facade.struct.OrganizationUserContextDescriptionKey;
import curam.core.facade.struct.ReadRecurringOrganizationActivityDetails;
import curam.core.facade.struct.ReadRecurringOrganizationActivityKey;
import curam.core.facade.struct.ReadStandardOrganizationActivityDetails;
import curam.core.facade.struct.ReadStandardOrganizationActivityKey;
import curam.core.facade.struct.ReadUserActivityKey;
import curam.core.facade.struct.SearchActivityKey;
import curam.core.facade.struct.SearchUserActivityKey;
import curam.core.facade.struct.UserCalendarData;
import curam.core.facade.struct.UserCalendarDataKey;
import curam.core.facade.struct.UserContextDescriptionDetails;
import curam.core.facade.struct.ViewReadOnlyRecurringActivityKey;
import curam.core.facade.struct.ViewReadOnlyStandardActivityKey;
import curam.core.facade.struct.ViewRecurringUserActivityDetails;
import curam.core.facade.struct.ViewRecurringUserActivityKey;
import curam.core.facade.struct.ViewSelectedUserActivityKey;
import curam.core.facade.struct.ViewStandardActivityUserDetails;
import curam.core.facade.struct.ViewStandardUserActivityDetails;
import curam.core.facade.struct.ViewStandardUserActivityKey;
import curam.core.fact.ActivityAttendeeFactory;
import curam.core.fact.ActivityFactory;
import curam.core.fact.ActivityRecurrenceFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.MaintainOrganisationActivityFactory;
import curam.core.fact.MaintainUserActivityFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UserActivityConflictFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.MaintainUserActivity;
import curam.core.intf.ActivityAttendee;
import curam.core.intf.ActivityRecurrence;
import curam.core.intf.CaseHeader;
import curam.core.intf.MaintainOrganisationActivity;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.ExternalUserFactory;
import curam.core.sl.entity.struct.ActiveICClientDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ReadActiveICClientDtlsList;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.ActivityElementDetails;
import curam.core.sl.struct.CalendarElementData;
import curam.core.sl.struct.DateRangeKey;
import curam.core.sl.struct.DateTimeRangeDetails;
import curam.core.sl.struct.EventElementDetails;
import curam.core.sl.struct.TaskAssigneeDetails;
import curam.core.sl.struct.TaskAssigneeDetailsList;
import curam.core.sl.struct.TaskManagementTaskKey;
import curam.core.struct.ActivityAttendeeByUserDtls;
import curam.core.struct.ActivityAttendeeByUserDtlsList;
import curam.core.struct.ActivityAttendeeDtls;
import curam.core.struct.ActivityAttendeeDtlsList;
import curam.core.struct.ActivityAttendeeNotificationDetails;
import curam.core.struct.ActivityAttendeeStatusDetails;
import curam.core.struct.ActivityAttendeeUserName;
import curam.core.struct.ActivityConflictDetails;
import curam.core.struct.ActivityDetails;
import curam.core.struct.ActivityDetailsKey;
import curam.core.struct.ActivityDtls;
import curam.core.struct.ActivityIntervalDetailsList;
import curam.core.struct.ActivityKey;
import curam.core.struct.ActivityListDetails;
import curam.core.struct.ActivityListDetailsList;
import curam.core.struct.ActivityNameDetails;
import curam.core.struct.ActivityOwnerDetails;
import curam.core.struct.ActivityOwnerDetailsKey;
import curam.core.struct.ActivityRecurrenceDtls;
import curam.core.struct.ActivityRecurrenceKey;
import curam.core.struct.AttendeeAcceptanceDetails;
import curam.core.struct.AttendeeNameIDDetails;
import curam.core.struct.AttendeeRecurrenceKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CheckForConflictResult;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CreateOrganisationActivityWarnConflictResult;
import curam.core.struct.CreateUserActivityIgnoreReturnDetails;
import curam.core.struct.CreateUserActivityWarnConflictResult;
import curam.core.struct.CuramInd;
import curam.core.struct.DefaultActivityDetails;
import curam.core.struct.IndicatorStruct;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.LocationHolidaySearchDetails;
import curam.core.struct.MaintainActivityDetails;
import curam.core.struct.MaintainActivityKey;
import curam.core.struct.MaintainAttendeeActivityKey;
import curam.core.struct.ModifyOrganisationActivityWarnConflictResult;
import curam.core.struct.ModifyUserActivityWarnConflictResult;
import curam.core.struct.OrganisationActivityKey;
import curam.core.struct.OrganisationActivitySearchKey;
import curam.core.struct.OrganisationKey;
import curam.core.struct.ReadByActivityAttendeeKey;
import curam.core.struct.ReadRecurringActivitiesKey;
import curam.core.struct.RecurringActivities;
import curam.core.struct.RecurringActivitiesList;
import curam.core.struct.RecurringActivityKey;
import curam.core.struct.SearchOrganisationByDateRangeResult;
import curam.core.struct.SearchUserByDateRangeResult;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserActivityDetails;
import curam.core.struct.UserActivityDetailsList;
import curam.core.struct.UserActivityKey;
import curam.core.struct.UserActivityOwnerDetails;
import curam.core.struct.UserActivityOwnerDetailsKey;
import curam.core.struct.UserActivitySearchKey;
import curam.core.struct.UserDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.core.struct.ViewUserActivityResult;
import curam.events.ACTIVITY;
import curam.events.TASK;
import curam.message.BPOACTIVITY;
import curam.message.BPOMAINTAINACTIVITY;
import curam.message.impl.BPOMAINTAINACTIVITYExceptionCreator;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;
import curam.util.type.NotFoundIndicator;
import curam.util.workflow.supervisor.impl.BusinessObjectAssociationWorkspace;
import curam.util.workflow.supervisor.struct.BusinessObjectAssociationTasksDetails;
import curam.util.workflow.supervisor.struct.BusinessObjectAssociationTasksDetailsList;
import curam.util.workflow.supervisor.struct.BusinessObjectAssociationTasksKey;


/**
 * This process class provides the functionality for the Participant
 * presentation layer.
 *
 */
public abstract class Activity extends curam.core.facade.base.Activity {

  // BEGIN, CR00023323, SK
  protected static final String kFrequencyPattern = FrequencyPattern.kZeroFrequencyPattern.toString();

  // END, CR00023323
  // (Entries are in triplets - unique id, full name and type)
  protected static final int kListEntriesToConstituteAMeeting = 3;

  // Estimated length of an EVENT element
  protected static final int kBufferSize = 1024;

  // ___________________________________________________________________________
  /**
   * Reads the description of the Activity.
   *
   * @param key
   * The activity context key.
   *
   * @return details The activity subject description.
   */
  @Override
  protected ActivityContextDescriptionDetails readActivityContextDescription(
    final ActivityContextDescriptionKey key) throws AppException,
      InformationalException {

    // Activity object and key.
    final curam.core.intf.Activity activityObj = ActivityFactory.newInstance();
    final ActivityKey activityKey = new ActivityKey();
    // Activity details
    ActivityDtls activityDtls;

    // Details to be returned.
    final ActivityContextDescriptionDetails activityContextDescriptionDetails = new ActivityContextDescriptionDetails();

    // Read the activity ID
    activityKey.activityID = key.activityID;
    activityDtls = activityObj.read(activityKey);

    // Set the context description.
    activityContextDescriptionDetails.description = activityDtls.subject;

    // Return the details
    return activityContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancels the specified recurring activity.
   *
   * @param key
   * The Recurring User Activity key.
   */
  @Override
  public void cancelRecurringUserActivity(
    final CancelRecurringUserActivityKey key) throws AppException,
      InformationalException {

    // Create a MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Create a maintainActivityKey object and
    // Read the read the cancelRecurringUserActivity activityID into it
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // BEGIN, CR00001117, CM

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // BEGIN, CR00002484, CM
    maintainActivityKey.activityID = key.cancelRecurringUserActivity.activityID;
    // END, CR00002484

    // set case key
    caseKey.caseID = maintainUserActivityObj.readCaseID(maintainActivityKey).details.caseID;

    // BEGIN, CR00078653, RPM
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }
    // END, CR00078653
    // END, CR00001117

    // BEGIN, CR00227859, PM
    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = key.cancelRecurringUserActivity.activityID;
    activityDtls = activityObj.read(activityKey);
    if (systemUserDtls.userName.equals(activityDtls.userName)) {
      // END, CR00227859

      // Cancel recurring user activity
      maintainUserActivityObj.cancelUserActivity(maintainActivityKey,
        key.indicatorStruct);

      // BEGIN, CR00227859
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00227859

    // BEGIN, CR00314368, MV
    if (EnvVars.ENV_VALUE_YES.equalsIgnoreCase(
      readSendNotificationAlertsProperty())) {
      // END, CR00314368
      // BEGIN, CR00273787, PB
      final Event event = new Event();

      event.eventKey = ACTIVITY.CANCELED;
      event.primaryEventData = maintainActivityKey.activityID;
      EventService.raiseEvent(event);
      // END, CR00273787
      // BEGIN, CR00314368, MV
    } else {

      final ViewRecurringUserActivityDetails viewRecurringUserActivityDetails = new ViewRecurringUserActivityDetails();

      activityKey.activityID = activityKey.activityID;

      activityDtls = activityObj.read(activityKey);

      final BusinessObjectAssociationTasksKey businessObjectAssociationTasksKey = new BusinessObjectAssociationTasksKey();

      if (activityDtls.recurrenceID != 0) {
        businessObjectAssociationTasksKey.bizObjectID = activityDtls.recurrenceID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITYRECURRENCE;
      } else {
        businessObjectAssociationTasksKey.bizObjectID = activityKey.activityID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITY;
      }
      businessObjectAssociationTasksKey.taskReservationStatus = TASKSTATUS.NOTSTARTED;

      final BusinessObjectAssociationTasksDetailsList businessObjectAssociationTasksDetailsList = BusinessObjectAssociationWorkspace.getBusinessObjectAssociationTasks(
        businessObjectAssociationTasksKey);
      final UsersKey usersKey = new UsersKey();

      if (!businessObjectAssociationTasksDetailsList.dtls.isEmpty()) {
        for (final BusinessObjectAssociationTasksDetails businessObjectAssociationTasksDetails : businessObjectAssociationTasksDetailsList.dtls.items()) {

          usersKey.userName = activityDtls.userName;

          if (activityDtls.recurrenceID != 0) {

            final ActivityRecurrence activityRecurrenceObj = ActivityRecurrenceFactory.newInstance();

            final ActivityRecurrenceKey activityRecurrenceKey = new ActivityRecurrenceKey();
            final NotFoundIndicator nfIndicator = new NotFoundIndicator();

            activityRecurrenceKey.recurrenceID = activityDtls.recurrenceID;
            final ActivityRecurrenceDtls activityRecurrenceDtls = activityRecurrenceObj.read(
              nfIndicator, activityRecurrenceKey);

            if (!nfIndicator.isNotFound()) {
              if (RECORDSTATUS.CANCELLED.equals(
                activityRecurrenceDtls.recordStatusCode)) {
                viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd = true;
              }
            }

            final ReadRecurringActivitiesKey readRecurringActivitiesKey = new ReadRecurringActivitiesKey();

            readRecurringActivitiesKey.recurrenceID = activityDtls.recurrenceID;

            final RecurringActivitiesList recurringActivitiesList = activityObj.searchRecurringActivities(
              readRecurringActivitiesKey);
            final ActivityDetailsKey activityDetailsKey = new ActivityDetailsKey();

            if (!recurringActivitiesList.dtls.isEmpty()) {
              for (final RecurringActivities recurringActivities : recurringActivitiesList.dtls.items()) {

                activityDetailsKey.activityID = recurringActivities.activityID;

                final ActivityDetails activityDetails = activityObj.readActivityDetails(
                  activityDetailsKey);

                viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd = false;
                if (RECORDSTATUS.DEFAULTCODE.equals(
                  activityDetails.recordStatusCode)) {
                  break;
                } else {
                  viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd = true;
                }
              }

            }

            if (viewRecurringUserActivityDetails.recActivityTaskDetails.cancelAllOcurrenceInd
              || viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd) {

              final Event event = new Event();

              event.eventKey = TASK.CLOSED;
              event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
              EventService.raiseEvent(event);
            }
          } else {

            final Event event = new Event();

            event.eventKey = TASK.CLOSED;
            event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
            EventService.raiseEvent(event);

          }
        }
      }
    }
    // END, CR00314368
  }

  /**
   * Cancels the specified activity.
   *
   * @param key
   * The User Activity to be canceled.
   */
  @Override
  public void cancelStandardUserActivity(
    final CancelStandardUserActivityKey key) throws AppException,
      InformationalException {

    // User Activity Maintenance Object and key
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final IndicatorStruct removeAllInd = new IndicatorStruct();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // Get activityID from the key
    maintainActivityKey.activityID = key.cancelStandardUserActivityKey.activityID;

    // set case key
    caseKey.caseID = maintainUserActivityObj.readCaseID(maintainActivityKey).details.caseID;

    // BEGIN, CR00078653, RPM
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }
    // END, CR00078653
    // END, CR00001117

    // // Get activityID from the key
    // maintainActivityKey.activityID =
    // key.cancelStandardUserActivityKey.activityID;

    // Set changeAllIndicator to false
    removeAllInd.changeAllIndicator = false;

    // BEGIN, CR00227859, PM
    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = key.cancelStandardUserActivityKey.activityID;
    activityDtls = activityObj.read(activityKey);

    // BEGIN, CR00312526, IBM
    if (EnvVars.ENV_VALUE_YES.equalsIgnoreCase(
      readSendNotificationAlertsProperty())) {

      // BEGIN, CR00260210, PB
      final Event event = new Event();

      event.eventKey = ACTIVITY.CANCELED;
      event.primaryEventData = maintainActivityKey.activityID;
      EventService.raiseEvent(event);
      // END, CR00260210

      // BEGIN, CR00314368, MV
    } else {
      final BusinessObjectAssociationTasksKey businessObjectAssociationTasksKey = new BusinessObjectAssociationTasksKey();

      if (activityDtls.recurrenceID != 0) {
        businessObjectAssociationTasksKey.bizObjectID = activityDtls.recurrenceID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITYRECURRENCE;
      } else {
        businessObjectAssociationTasksKey.bizObjectID = maintainActivityKey.activityID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITY;
      }
      businessObjectAssociationTasksKey.taskReservationStatus = TASKSTATUS.NOTSTARTED;

      final BusinessObjectAssociationTasksDetailsList businessObjectAssociationTasksDetailsList = BusinessObjectAssociationWorkspace.getBusinessObjectAssociationTasks(
        businessObjectAssociationTasksKey);

      if (!businessObjectAssociationTasksDetailsList.dtls.isEmpty()) {
        for (final BusinessObjectAssociationTasksDetails businessObjectAssociationTasksDetails : businessObjectAssociationTasksDetailsList.dtls.items()) {
          final Event event = new Event();

          event.eventKey = TASK.CLOSED;
          event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
          EventService.raiseEvent(event);
        }
      }
    }
    // END, CR00314368

    if (systemUserDtls.userName.equals(activityDtls.userName)) {
      // END, CR00227859

      // Cancel the User Activity
      maintainUserActivityObj.cancelUserActivity(maintainActivityKey,
        removeAllInd);
      // BEGIN, CR00227859
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 8);
    }
    // END, CR00227859
  }

  // ___________________________________________________________________________
  /**
   * Creates a new recurring activity for the specified user.
   *
   * @param details
   * The details of a recurring activity to be created.
   *
   * @return Details of the new activity.
   */
  @Override
  public NewActivityDetails createRecurringUserActivity(
    final CreateRecurringUserActivityDetails details) throws AppException,
      InformationalException {

    // Activity maintenance object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Return objects
    final NewActivityDetails newActivityDetails = new NewActivityDetails();
    CreateUserActivityIgnoreReturnDetails createUserActivityIgnoreReturnDetails;
    CreateUserActivityWarnConflictResult createUserActivityWarnConflictResult;

    // System user maintenance object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Create MaintainActivityDetails from
    // MaintainRecurringUserActivityDetails
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.maintainRecurringUserActivityDetails.caseID;

    // BEGIN, CR00002560, CM
    if (caseKey.caseID != 0) {

      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = details.maintainRecurringUserActivityDetails.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kCreateSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    }// END, CR00002560

    maintainActivityDetails.assign(details.maintainRecurringUserActivityDetails);

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // Create and setup user activity key
    final UserActivityKey userActivityKey = new UserActivityKey();

    userActivityKey.userName = systemUserDtls.userName;

    // Create empty AttendeeNameIDDetails instance
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();

    if (details.maintainRecurringUserActivityDetails.frequencyPattern.length()
      == 0) {
      throw new AppException(
        curam.message.BPOACTIVITY.ERR_ACTIVITY_FV_FREQUENCY_PATTERN);
    }

    // Set recurrence start date
    maintainActivityDetails.recurrenceStartDate = new curam.util.type.Date(
      details.maintainRecurringUserActivityDetails.startDateTime);

    // Create the user activity by calling the relevant method according to
    // the value for ignoreConflictInd
    if (details.maintainRecurringUserActivityDetails.ignoreConflictInd) {

      createUserActivityIgnoreReturnDetails = maintainUserActivityObj.createUserActivityIgnoreConflict(
        userActivityKey, maintainActivityDetails, attendeeNameIDDetails);
      newActivityDetails.activityID = createUserActivityIgnoreReturnDetails.activityKey.activityID;

    } else {

      createUserActivityWarnConflictResult = maintainUserActivityObj.createUserActivityWarnConflict(
        userActivityKey, maintainActivityDetails, attendeeNameIDDetails);
      newActivityDetails.activityID = createUserActivityWarnConflictResult.activityKey.activityID;

      // if there are conflicts throw an error to report them to the user
      if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

        e.arg(
          createUserActivityWarnConflictResult.activityConflictDetails.conflictString);

        throw e;
      }
    }

    // Return details
    return newActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates a new activity for the specified user.
   *
   * @param details
   * The details of a user activity to be created.
   *
   * @return A list of messages returned.
   */
  @Override
  public NewActivityDetails createStandardUserActivity(
    final MaintainStandardActivityUserDetails details) throws AppException,
      InformationalException {

    // User Activity Maintenance Object and key
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final UserActivityKey userActivityKey = new UserActivityKey();

    // Create an instance of MaintainActivityDetails
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // Create an instance of AttendeeNameIDDetails
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();

    // Activity details returned
    CreateUserActivityIgnoreReturnDetails createUserActivityIgnoreReturnDetails;
    CreateUserActivityWarnConflictResult createUserActivityWarnConflictResult;

    final NewActivityDetails newActivityDetails = new NewActivityDetails();

    // System User Details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.viewStandardActivityUserDetails.caseID;

    // BEGIN, CR00002560, CM
    if (caseKey.caseID != 0) {

      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = details.viewStandardActivityUserDetails.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kCreateSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
      // END, CR00001117

    }// END, CR00002560

    // Assign system user details to key
    userActivityKey.userName = systemUserDtls.userName;

    // Get Activity details from key
    maintainActivityDetails.assign(details.viewStandardActivityUserDetails);

    // Set frequency pattern to blank
    maintainActivityDetails.frequencyPattern = kFrequencyPattern;

    // Assign system user details to maintainActivityDetails
    maintainActivityDetails.userName = systemUserDtls.userName;

    // Call relevant create method depending on ignoreConflictInd value
    if (details.viewStandardActivityUserDetails.ignoreConflictInd) {
      createUserActivityIgnoreReturnDetails = maintainUserActivityObj.createUserActivityIgnoreConflict(
        userActivityKey, maintainActivityDetails, attendeeNameIDDetails);

      newActivityDetails.activityID = createUserActivityIgnoreReturnDetails.activityKey.activityID;

    } else {

      createUserActivityWarnConflictResult = maintainUserActivityObj.createUserActivityWarnConflict(
        userActivityKey, maintainActivityDetails, attendeeNameIDDetails);

      newActivityDetails.activityID = createUserActivityWarnConflictResult.activityKey.activityID;

      // if there are conflicts throw an error to report them to the user
      if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

        e.arg(
          createUserActivityWarnConflictResult.activityConflictDetails.conflictString);

        throw e;
      }

    }

    return newActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates a new user activity with default values, with a minimal amount of
   * values specified.
   *
   * @param details
   * Maintain User Activity With Defaults Details Facade Object.
   */
  @Override
  public void createUserActivityWithDefaults(
    final MaintainUserActivityWithDefaultsDetails details)
    throws AppException, InformationalException {

    // Get instance of MaintainUserActivity.
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Get instance of SystemUser.
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Create instance of DefaultActivityDetails.
    final DefaultActivityDetails defaultActivityDetails = new DefaultActivityDetails();

    // Assign maintainUserActivityWithDefaultsDetails to it.
    defaultActivityDetails.assign(
      details.maintainUserActivityWithDefaultsDetails);

    // Set its userName.
    defaultActivityDetails.userName = systemUserObj.getUserDetails().userName;

    // Create a new User Activity With Defaults with the
    // MaintainUserActivity Object previously created.
    maintainUserActivityObj.createUserActivityWithDefaults(
      defaultActivityDetails);
  }

  // ___________________________________________________________________________
  /**
   * Allows a user to accept or decline an invitation to an activity, or to
   * change the status to provisional.
   *
   * @param key
   * The acceptance status.
   */
  public void maintainAcceptanceStatus(final MaintainAcceptanceStatusKey key)
    throws AppException, InformationalException {

    // User activity maintenance object and key
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final UserActivityKey userActivityKey = new UserActivityKey();

    // System user details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // Assign system user details to key
    userActivityKey.userName = systemUserDtls.userName;

    // Maintain acceptance status
    maintainUserActivityObj.maintainAcceptanceStatus(key.maintainActivityKey,
      userActivityKey, key.attendeeAcceptanceDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing recurring user activity.
   *
   * @param details
   * The details of user activity to be modified.
   */
  @Override
  public void modifyRecurringUserActivity(
    final ModifyRecurringUserActivityDetails details) throws AppException,
      InformationalException {

    // Activity recurrence object and key
    final ActivityRecurrenceKey activityRecurrenceKey = new ActivityRecurrenceKey();
    ActivityRecurrenceDtls activityRecurrenceDtls;
    final ActivityRecurrence activityRecurrenceObj = ActivityRecurrenceFactory.newInstance();

    // Read old recurrence details
    activityRecurrenceKey.recurrenceID = details.maintainRecurringUserActivityDetails.recurrenceID;
    activityRecurrenceDtls = activityRecurrenceObj.read(activityRecurrenceKey);

    // Check if frequencyPattern OR numberOfOccurrences has been modified
    final boolean recurrenceChanged = activityRecurrenceDtls.frequencyPattern
      != null
        && !activityRecurrenceDtls.frequencyPattern.equals(
          details.maintainRecurringUserActivityDetails.frequencyPattern)
            || activityRecurrenceDtls.numberOfOccurrences
              != details.maintainRecurringUserActivityDetails.numberOfOccurrences;

    // If some recurrence parameter has been changed the changeAllIndicator
    // flag is implicitly true since this modification influences all the
    // activity occurrences
    if (recurrenceChanged) {
      details.indicatorStruct.changeAllIndicator = true;
    }

    // BEGIN, CR00078653, RPM
    if (details.maintainRecurringUserActivityDetails.caseID != 0) {
      // BEGIN, CR00001117, CM
      // Case Header manipulation variables
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      // set case key
      caseKey.caseID = details.maintainRecurringUserActivityDetails.caseID;

      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = details.maintainRecurringUserActivityDetails.caseID;
        servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }
    // END, CR00078653
    // END, CR00001117

    // Activity maintenance object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // System user maintenance object
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    // Create MaintainActivityDetails from MaintainRecurringUserActivityDetails
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // Attendee details
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();
    final AttendeeNameIDDetails oldAttendeeNameIDDetails = new AttendeeNameIDDetails();

    // Create an instance of ModifyUserActivityWarnConflictResult
    ModifyUserActivityWarnConflictResult modifyUserActivityWarnConflictResult;

    if (details.maintainRecurringUserActivityDetails.frequencyPattern.length()
      == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOACTIVITY.ERR_ACTIVITY_FV_FREQUENCY_PATTERN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // Set recurrenceStartDate (validated and inserted) to
    // startDateTime (retrieved from the client interface)
    maintainActivityDetails.recurrenceStartDate = new Date(
      details.maintainRecurringUserActivityDetails.startDateTime);

    maintainActivityDetails.assign(details.maintainRecurringUserActivityDetails);

    // BEGIN, CR00219331, MC
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = details.maintainRecurringUserActivityDetails.caseParticipantRoleID;

    if (caseParticipantRoleKey.caseParticipantRoleID != 0) {

      final CaseParticipantRole_eoFullDetails caseParticipantDetails = CaseParticipantRoleFactory.newInstance().readFullDetails(
        caseParticipantRoleKey);

      maintainActivityDetails.concernRoleID = caseParticipantDetails.participantRoleID;
      maintainActivityDetails.concernRoleName = caseParticipantDetails.name;
    }
    // END, CR00219331

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // Create and setup user activity key
    final UserActivityKey userActivityKey = new UserActivityKey();

    userActivityKey.userName = systemUserDtls.userName;

    // Assign attendee details
    attendeeNameIDDetails.attendeeNameDetails = details.maintainRecurringUserActivityDetails.attendeeNameDetails;

    oldAttendeeNameIDDetails.attendeeNameDetails = details.maintainRecurringUserActivityDetails.attendeeNameDetails;

    // BEGIN, CR00225987, GSP
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = details.maintainRecurringUserActivityDetails.activityID;
    activityDtls = activityObj.read(activityKey);

    if (systemUserDtls.userName.equals(activityDtls.userName)) {
      // END, CR00225987

      // Modify the user activity by calling the relevant method according to
      // the
      // value for ignoreConflictInd
      if (details.maintainRecurringUserActivityDetails.ignoreConflictInd) {

        maintainUserActivityObj.modifyUserActivityIgnoreConflict(
          userActivityKey, maintainActivityDetails, details.indicatorStruct,
          attendeeNameIDDetails, oldAttendeeNameIDDetails);
      } else {

        modifyUserActivityWarnConflictResult = maintainUserActivityObj.modifyUserActivityWarnConflict(
          userActivityKey, maintainActivityDetails, attendeeNameIDDetails,
          oldAttendeeNameIDDetails, details.indicatorStruct);

        // If there are conflicts throw an error to report them to the user
        if (modifyUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

          final AppException e = new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

          e.arg(
            modifyUserActivityWarnConflictResult.activityConflictDetails.conflictString);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            5);
        }

      }
    } // BEGIN, CR00225987, GSP
    else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);
    }
    // END, CR00225987
  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing user activity.
   *
   * @param details
   * The details of the user activity being modified.
   */
  @Override
  public void modifyStandardUserActivity(
    final MaintainStandardActivityUserDetails details) throws AppException,
      InformationalException {

    // User Activity Maintenance Object and key
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final UserActivityKey userActivityKey = new UserActivityKey();

    // Create an instance of MaintainActivityDetails
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // Create an instance of ModifyUserActivityWarnConflictResult
    ModifyUserActivityWarnConflictResult modifyUserActivityWarnConflictResult;

    // Create two instances of AttendeeNameIDDetails for new and
    // old Attendee details
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();
    final AttendeeNameIDDetails oldAttendeeNameIDDetails = new AttendeeNameIDDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.viewStandardActivityUserDetails.caseID;

    // BEGIN, CR00078653, RPM
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = details.viewStandardActivityUserDetails.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }
    // END, CR00078653
    // END, CR00001117

    // Create an instance of IndicatorStruct
    final IndicatorStruct modifyAll = new IndicatorStruct();

    // System User Details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // Assign system user details to key
    userActivityKey.userName = systemUserDtls.userName;

    // Set frequency pattern to blank
    maintainActivityDetails.frequencyPattern = kFrequencyPattern;

    // Get Activity details from key
    maintainActivityDetails.assign(details.viewStandardActivityUserDetails);

    // BEGIN, CR00219331, MC
    final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = details.viewStandardActivityUserDetails.caseParticipantRoleID;

    if (caseParticipantRoleKey.caseParticipantRoleID != 0) {
      final CaseParticipantRole_eoFullDetails caseParticipantDetails = CaseParticipantRoleFactory.newInstance().readFullDetails(
        caseParticipantRoleKey);

      maintainActivityDetails.concernRoleID = caseParticipantDetails.participantRoleID;
      maintainActivityDetails.concernRoleName = caseParticipantDetails.name;
    }
    // END, CR00219331

    // Assign attendee details
    attendeeNameIDDetails.attendeeNameDetails = details.viewStandardActivityUserDetails.attendeeNameDetails;

    oldAttendeeNameIDDetails.attendeeNameDetails = details.viewStandardActivityUserDetails.attendeeNameDetails;

    // BEGIN, CR00225987, GSP
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = details.viewStandardActivityUserDetails.activityID;
    activityDtls = activityObj.read(activityKey);

    if (systemUserDtls.userName.equals(activityDtls.userName)) {
      // END, CR00225987

      // Call relevant modify method depending on ignoreConflictInd value
      if (details.viewStandardActivityUserDetails.ignoreConflictInd) {

        maintainUserActivityObj.modifyUserActivityIgnoreConflict(
          userActivityKey, maintainActivityDetails, modifyAll,
          attendeeNameIDDetails, oldAttendeeNameIDDetails);
      } else {

        modifyUserActivityWarnConflictResult = maintainUserActivityObj.modifyUserActivityWarnConflict(
          userActivityKey, maintainActivityDetails, attendeeNameIDDetails,
          oldAttendeeNameIDDetails, modifyAll);

        // if there are conflicts throw an error to report them to the user
        if (modifyUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

          final AppException e = new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

          e.arg(
            modifyUserActivityWarnConflictResult.activityConflictDetails.conflictString);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            4);
        }

      }
    } // BEGIN, CR00225987, GSP
    else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }
    // END, CR00225987
  }

  // ___________________________________________________________________________
  /**
   * Modifies some details of a user activity, but allows most details to remain
   * the same.
   *
   * @param details
   * The details of user activity with default details to be modified.
   */
  @Override
  public void modifyUserActivityWithDefaults(
    final MaintainUserActivityWithDefaultsDetails details)
    throws AppException, InformationalException {

    // User activity maintenance object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // System user details
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // Default activity details
    final DefaultActivityDetails defaultActivityDetailsObj = new DefaultActivityDetails();

    defaultActivityDetailsObj.userName = systemUserDtls.userName;
    defaultActivityDetailsObj.assign(
      details.maintainUserActivityWithDefaultsDetails);

    // Modify the user activity details
    maintainUserActivityObj.modifyUserActivityWithDefaults(
      defaultActivityDetailsObj);
  }

  // ___________________________________________________________________________
  /**
   * Reads the description of the Activity
   *
   * @param key
   * Activity ID for which the description is retrieved.
   *
   * @return Activity context details.
   */
  @Override
  public ActivityContextDetails readContextDescription(
    final ActivityContextKey key) throws AppException, InformationalException {

    // Details to be returned.
    final ActivityContextDetails activityContextDetails = new ActivityContextDetails();

    // Get the description.
    activityContextDetails.activityContextDescriptionDetails = readActivityContextDescription(
      key.activityContextDescriptionKey);

    // Return details
    return activityContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the calendar events starting from a specified start date.
   *
   * @boread UserActivity
   *
   * @boread CalendarData
   * @param key
   * The key contains the calendar date, type and view type.
   *
   * @return The activity data for the calendar view.
   */
  @Override
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public CalendarDataDetails getUserActivityData(final UserCalendarDataKey key) throws AppException,
      InformationalException {

    // Get instance of MaintainUserActivity object and key.
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final UserActivitySearchKey userActivitySearchKey = new UserActivitySearchKey();

    // CalendarDataDetails object
    final CalendarDataDetails calendarDataDetails = new CalendarDataDetails();

    // CalendarData object
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory.newInstance();

    CalendarElementData calendarElementData;

    // Get instance of SystemUser and SystemUserDetails..
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // Use current date if the start date is not set
    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Use default view if view type is not set
    if (key.calendarViewType.length() == 0) {
      key.calendarViewType = CALENDARVIEWTYPE.DEFAULTCODE;
    }

    // Get date range
    final DateRangeKey dateRangeKey = new DateRangeKey();

    dateRangeKey.startDate = key.startDate;
    dateRangeKey.calendarViewType = key.calendarViewType;

    final DateTimeRangeDetails dateTimeRangeDetails = calendarDataObj.getDateTimeRange(
      dateRangeKey);

    // Populate userActivitySearchKey
    userActivitySearchKey.userName = key.userName;
    userActivitySearchKey.viewingUserName = systemUserDtls.userName;
    userActivitySearchKey.startDateTime = dateTimeRangeDetails.startDateTime;
    userActivitySearchKey.endDateTime = dateTimeRangeDetails.endDateTime;

    // Create empty SearchUserByDateRangeResult instance.
    SearchUserByDateRangeResult searchUserByDateRangeResult;

    // Search for user activity by date range.
    searchUserByDateRangeResult = maintainUserActivityObj.searchUserByDateRange(
      userActivitySearchKey);

    // Create empty ActivityIntervalDetailsList instance.
    ActivityIntervalDetailsList activityIntervalDetailsList;

    // Obtain list of activities
    activityIntervalDetailsList = searchUserByDateRangeResult.detailsList;

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * activityIntervalDetailsList.dtls.size());

    // BEGIN, CR00023323, SK
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataHeader);
    xmlString.append(key.calendarType);
    xmlString.append(CuramCalendarHeaderConst.kCloseBracket);
    xmlString.append(CuramCalendarHeaderConst.kNewLine);
    // END, CR00023323
    // Loop through list of activities
    for (int i = 0; i < activityIntervalDetailsList.dtls.size(); i++) {

      // ActivityElementDetails instance
      final ActivityElementDetails activityElementDetails = new ActivityElementDetails();

      final EventElementDetails eventElementDetails = new EventElementDetails();

      activityElementDetails.assign(activityIntervalDetailsList.dtls.item(i));

      eventElementDetails.eventType = activityElementDetails.activityTypeCode;
      eventElementDetails.eventID = activityElementDetails.activityID;
      eventElementDetails.eventDescription = activityElementDetails.subject;

      if (eventElementDetails.eventType.equals(ACTIVITYTYPE.HOLIDAY)) {
        final curam.util.type.Date eventDate = new curam.util.type.Date(
          activityElementDetails.startDateTime);
        final curam.util.type.DateTime eventStartDate = new curam.util.type.DateTime(
          activityElementDetails.startDateTime);
        final curam.util.type.DateTime eventEndDate = new curam.util.type.DateTime(
          activityElementDetails.endDateTime);

        eventElementDetails.eventDate = eventDate;
        eventElementDetails.eventStartDate = eventStartDate;
        eventElementDetails.eventEndDate = eventEndDate;
        calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
          dateTimeRangeDetails);
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        calendarElementData = calendarDataObj.parseActivity(
          activityElementDetails, dateTimeRangeDetails);
        xmlString.append(calendarElementData.calendarXMLString);

      }
    }

    // Create CURAM_CALENDAR_DATA node footer.
    // BEGIN, CR00023323, SK
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);
    xmlString.append(CuramCalendarHeaderConst.kNewLine);
    // END, CR00023323
    calendarDataDetails.calendarXMLString = xmlString.toString();

    // Return details.
    return calendarDataDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves calendar events from a particular start date for user
   * calendar.
   *
   * @param key
   * Calendar date and calendar view type.
   *
   * @return The activity data.
   */
  @Override
  public CalendarDataDetails searchCurrentUserActivity(
    final SearchActivityKey key) throws AppException, InformationalException {

    // Create empty CalendarDataDetails and UserCalendarDataKey objects.
    CalendarDataDetails calendarDataDetails;
    final UserCalendarDataKey userCalendarDataKey = new UserCalendarDataKey();

    // Get instance of SystemUser and SystemUserDetails..
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Get the current user
    systemUserDtls = systemUserObj.getUserDetails();
    // BEGIN, CR00023323, SK
    // Populate key
    // BEGIN, CR00163098, JC
    userCalendarDataKey.calendarType = CuramCalendarHeaderConst.kQuote
      + curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
      CALENDARTYPE.USER, TransactionInfo.getProgramLocale())
      + CuramCalendarHeaderConst.kQuote;
    // END, CR00163098, JC
    // END, CR00023323
    userCalendarDataKey.startDate = key.startDate;
    userCalendarDataKey.calendarViewType = key.calendarViewType;
    userCalendarDataKey.userName = systemUserDtls.userName;

    // Get data for the user activities
    calendarDataDetails = getUserActivityData(userCalendarDataKey);
    return calendarDataDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a recurring activity for the current user.
   *
   * @param key
   * Recurring Activity ID for which details are retrieved.
   *
   * @return The activity details returned from the database.
   */
  @Override
  public ViewRecurringUserActivityDetails viewRecurringUserActivity(
    final ViewRecurringUserActivityKey key) throws AppException,
      InformationalException {

    // SystemUser objects
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    // Get the current user
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();
    ViewRecurringUserActivityDetails viewRecurringUserActivityDetails = null;

    // BEGIN, CR00303229, MV
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = key.maintainActivityKey.activityID;
    final ActivityDtls activityDtls = ActivityFactory.newInstance().read(
      activityKey);
    final ViewSelectedUserActivityKey viewSelectedUserActivityKey = new ViewSelectedUserActivityKey();

    viewSelectedUserActivityKey.activityID = key.maintainActivityKey.activityID;
    viewSelectedUserActivityKey.userName = systemUserDtls.userName;
    // END, CR00303229

    // User activity key
    final ReadUserActivityKey readUserActivityKey = new ReadUserActivityKey();

    // Set the key
    readUserActivityKey.activityID = key.maintainActivityKey.activityID;
    readUserActivityKey.userName = systemUserDtls.userName;
    // BEGIN, CR00001117, CM
    // Return the details
    viewRecurringUserActivityDetails = readRecurringUserActivity(
      readUserActivityKey);
    // BEGIN, CR00314092, MV
    if (systemUserDtls.userName.equals(activityDtls.userName)
      || isUserInvited(viewSelectedUserActivityKey)
      || 0
        != viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseID) {
      // END, CR00314092
      // Case Header manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      // set case key
      caseKey.caseID = viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseID;

      // BEGIN, CR00078653, RPM
      if (caseKey.caseID != 0) {
        // read case type code
        final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(
          caseKey);

        // if case type is service plan, check service plan security
        if (caseTypeCode.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.SERVICEPLAN)) {

          // ServicePlanDelivery facade
          final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
          final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

          // register the service plan security implementation
          curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

          // set the key
          servicePlanSecurityKey.caseID = viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseID;
          servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kReadSecurityCheck;

          // check security
          servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
        }
      }
      // END, CR00078653

      // BEGIN, CR00219331, MC
      final CaseParticipantRole_eoCaseIDKey caseParticipantKey = new CaseParticipantRole_eoCaseIDKey();

      caseParticipantKey.caseID = caseKey.caseID;

      final ReadActiveICClientDtlsList readActiveICClientDtlsList = CaseParticipantRoleFactory.newInstance().readActiveICCaseParticipantRole(
        caseParticipantKey);

      for (int i = 0; i < readActiveICClientDtlsList.dtls.size(); i++) {
        final ActiveICClientDetails activeICClientDetails = readActiveICClientDtlsList.dtls.item(i).dtls;

        if (activeICClientDetails.participantRoleID
          == viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.concernRoleID) {

          viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseParticipantRoleID = activeICClientDetails.caseParticipantRoleID;
        }
      }
      // BEGIN, CR00303229, MV
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_VIEW_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00303229
    return viewRecurringUserActivityDetails;
    // END, CR00001117

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a standard activity for the current user.
   *
   * @param key
   * Activity ID for which details are retrieved.
   *
   * @return The activity details returned from the database.
   */
  @Override
  public ViewStandardUserActivityDetails viewStandardUserActivity(
    final ViewStandardUserActivityKey key) throws AppException,
      InformationalException {

    // SystemUser objects
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    // Get the current user
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();
    ViewStandardUserActivityDetails viewStandardUserActivityDetails = null;

    // BEGIN, CR00303229, MV
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = key.maintainActivityKey.activityID;
    final ActivityDtls activityDtls = ActivityFactory.newInstance().read(
      activityKey);
    final ViewSelectedUserActivityKey viewSelectedUserActivityKey = new ViewSelectedUserActivityKey();

    viewSelectedUserActivityKey.activityID = key.maintainActivityKey.activityID;
    viewSelectedUserActivityKey.userName = systemUserDtls.userName;
    // END, CR00303229

    // User activity key
    final ReadUserActivityKey readUserActivityKey = new ReadUserActivityKey();

    // Set the key
    readUserActivityKey.activityID = key.maintainActivityKey.activityID;
    readUserActivityKey.userName = systemUserDtls.userName;

    // BEGIN, CR00001117, CM
    // Return the details
    viewStandardUserActivityDetails = readStandardUserActivity(
      readUserActivityKey);
    // BEGIN, CR00314092, MV
    if (systemUserDtls.userName.equals(activityDtls.userName)
      || isUserInvited(viewSelectedUserActivityKey)
      || 0
        != viewStandardUserActivityDetails.viewStandardActivityUserDetails.caseID) {
      // END, CR00314092
      // Case Header manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      // set case key
      caseKey.caseID = viewStandardUserActivityDetails.viewStandardActivityUserDetails.caseID;

      // BEGIN CR00053419
      if (caseKey.caseID != 0) {

        // read case type code
        final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(
          caseKey);

        // if case type is service plan, check service plan security
        if (caseTypeCode.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.SERVICEPLAN)) {

          // ServicePlanDelivery facade
          final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
          final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

          // register the service plan security implementation
          curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

          // set the key
          servicePlanSecurityKey.caseID = viewStandardUserActivityDetails.viewStandardActivityUserDetails.caseID;
          servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kReadSecurityCheck;

          // check security
          servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
        }
      }
      // END CR00053419

      // BEGIN, CR00219331, MC
      final CaseParticipantRole_eoCaseIDKey caseParticipantKey = new CaseParticipantRole_eoCaseIDKey();

      caseParticipantKey.caseID = caseKey.caseID;

      final ReadActiveICClientDtlsList readActiveICClientDtlsList = CaseParticipantRoleFactory.newInstance().readActiveICCaseParticipantRole(
        caseParticipantKey);

      for (int i = 0; i < readActiveICClientDtlsList.dtls.size(); i++) {
        final ActiveICClientDetails activeICClientDetails = readActiveICClientDtlsList.dtls.item(i).dtls;

        if (activeICClientDetails.participantRoleID
          == viewStandardUserActivityDetails.viewStandardActivityUserDetails.concernRoleID) {

          viewStandardUserActivityDetails.viewStandardActivityUserDetails.caseParticipantRoleID = activeICClientDetails.caseParticipantRoleID;
        }
      }
      // BEGIN, CR00303229, MV
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_VIEW_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00303229
    // END, CR00219331
    return viewStandardUserActivityDetails;
    // END, CR00001117
  }

  // ___________________________________________________________________________
  /**
   * Accepts an invitation for the current user to the specified activity.
   *
   * @param key
   * Activity invitation ID.
   */
  @Override
  public void acceptInvitation(final ActivityInvitationKey key)
    throws AppException, InformationalException {

    // Create a MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Get instance of SystemUser.
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Create instance of ActivityKey
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // Create instance of AttendeeAcceptanceDetails
    final AttendeeAcceptanceDetails attendeeAcceptanceDetails = new AttendeeAcceptanceDetails();

    // Create instance of UserActivityKey.
    final UserActivityKey userActivityKey = new UserActivityKey();
    // BEGIN, CR00273787, PB
    ActivityAttendeeDtls activityAttendeeDtls = new ActivityAttendeeDtls();
    final ReadByActivityAttendeeKey readByActivityAttendeeKey = new ReadByActivityAttendeeKey();
    final ActivityAttendee activityAttendeeObj = ActivityAttendeeFactory.newInstance();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();

    // END, CR00273787
    // Assign its userName.
    userActivityKey.userName = systemUserObj.getUserDetails().userName;

    // Get the activityID from the key
    maintainActivityKey.activityID = key.activityID;

    // Set the acceptance status to accepted
    attendeeAcceptanceDetails.acceptanceStatusCode = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;
    // BEGIN, CR00273787, PB
    readByActivityAttendeeKey.activityID = maintainActivityKey.activityID;
    readByActivityAttendeeKey.recordStatusCode = RECORDSTATUS.NORMAL;
    readByActivityAttendeeKey.userName = userActivityKey.userName;
    activityAttendeeDtls = activityAttendeeObj.readByActivityAttendee(
      nfIndicator, readByActivityAttendeeKey);
    // BEGIN, CR00314368, MV
    if (!nfIndicator.isNotFound()) {
      if (EnvVars.ENV_VALUE_YES.equalsIgnoreCase(
        readSendNotificationAlertsProperty())) {
        final Event event = new Event();

        event.eventKey = ACTIVITY.INVITEE_ACCEPTED;
        event.primaryEventData = activityAttendeeDtls.attendeeID;
        event.secondaryEventData = maintainActivityKey.activityID;
        EventService.raiseEvent(event);
      } else {

        final ActivityKey activityKey = new ActivityKey();

        activityKey.activityID = key.activityID;
        final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
        final ActivityDtls activityDtls = activityObj.read(activityKey);

        final BusinessObjectAssociationTasksKey businessObjectAssociationTasksKey = new BusinessObjectAssociationTasksKey();

        if (activityDtls.recurrenceID != 0) {
          businessObjectAssociationTasksKey.bizObjectID = activityDtls.recurrenceID;
          businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITYRECURRENCE;
        } else {
          businessObjectAssociationTasksKey.bizObjectID = key.activityID;
          businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITY;
        }
        businessObjectAssociationTasksKey.taskReservationStatus = TASKSTATUS.NOTSTARTED;

        final BusinessObjectAssociationTasksDetailsList businessObjectAssociationTasksDetailsList = BusinessObjectAssociationWorkspace.getBusinessObjectAssociationTasks(
          businessObjectAssociationTasksKey);
        final UsersKey usersKey = new UsersKey();

        if (!businessObjectAssociationTasksDetailsList.dtls.isEmpty()) {
          for (final BusinessObjectAssociationTasksDetails businessObjectAssociationTasksDetails : businessObjectAssociationTasksDetailsList.dtls.items()) {
            final curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();
            final TaskManagementTaskKey taskKey = new curam.core.sl.struct.TaskManagementTaskKey();

            taskKey.taskID = businessObjectAssociationTasksDetails.taskID;
            final TaskAssigneeDetailsList taskAssigneeDetailsList = taskManagementObj.viewAssignmentsForTask(
              taskKey);

            for (final TaskAssigneeDetails taskAssigneeDetails : taskAssigneeDetailsList.dtls.items()) {

              usersKey.userName = readByActivityAttendeeKey.userName;

              final UserAccess userAccessObj = UserAccessFactory.newInstance();
              final UserDetails userDetails = userAccessObj.getUserDetails(
                usersKey);

              if (userDetails.fullName.equalsIgnoreCase(
                taskAssigneeDetails.assignedTo)) {

                final Event event = new Event();

                event.eventKey = TASK.CLOSED;
                event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
                EventService.raiseEvent(event);
              }

            }
          }
        }

      }
      // END, CR00314368
    }
    // END, CR00273787
    // Accept Invitation
    maintainUserActivityObj.maintainAcceptanceStatus(maintainActivityKey,
      userActivityKey, attendeeAcceptanceDetails);
  }

  // ___________________________________________________________________________
  /**
   * Sets the status of a meeting invitation for the current user to the
   * specified activity to provisional.
   *
   * @param key
   * Activity invitation ID.
   */
  @Override
  public void setProvisionalInvitation(final ActivityInvitationKey key)
    throws AppException, InformationalException {

    // Create a MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Get instance of SystemUser.
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Create instance of ActivityKey
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // Create instance of AttendeeAcceptanceDetails
    final AttendeeAcceptanceDetails attendeeAcceptanceDetails = new AttendeeAcceptanceDetails();

    // Create instance of UserActivityKey.
    final UserActivityKey userActivityKey = new UserActivityKey();

    // Assign its userName.
    userActivityKey.userName = systemUserObj.getUserDetails().userName;

    // Get the activityID from the key
    maintainActivityKey.activityID = key.activityID;

    // Set the acceptance status to provisional
    attendeeAcceptanceDetails.acceptanceStatusCode = curam.codetable.ACCEPTANCESTATUS.PROVISIONAL;

    // Accept provisional invitation
    maintainUserActivityObj.maintainAcceptanceStatus(maintainActivityKey,
      userActivityKey, attendeeAcceptanceDetails);
  }

  // ___________________________________________________________________________
  /**
   * Rejects an invitation for the current user to the specified activity.
   *
   * @param key
   * Activity invitation ID.
   */
  @Override
  public void rejectInvitation(final ActivityInvitationKey key)
    throws AppException, InformationalException {

    // Create a MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Get instance of SystemUser.
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Create instance of ActivityKey
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // Create instance of AttendeeAcceptanceDetails
    final AttendeeAcceptanceDetails attendeeAcceptanceDetails = new AttendeeAcceptanceDetails();

    // Create instance of UserActivityKey.
    final UserActivityKey userActivityKey = new UserActivityKey();
    // BEGIN, CR00273787, PB
    ActivityAttendeeDtls activityAttendeeDtls = new ActivityAttendeeDtls();
    final ReadByActivityAttendeeKey readByActivityAttendeeKey = new ReadByActivityAttendeeKey();
    final ActivityAttendee activityAttendeeObj = ActivityAttendeeFactory.newInstance();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();

    // END, CR00273787
    // Assign its userName.
    userActivityKey.userName = systemUserObj.getUserDetails().userName;

    // Get the activityID from the key
    maintainActivityKey.activityID = key.activityID;

    // Set the acceptance status to rejected
    attendeeAcceptanceDetails.acceptanceStatusCode = curam.codetable.ACCEPTANCESTATUS.REJECTED;
    // BEGIN, CR00273787, PB
    readByActivityAttendeeKey.activityID = maintainActivityKey.activityID;
    readByActivityAttendeeKey.recordStatusCode = RECORDSTATUS.NORMAL;
    readByActivityAttendeeKey.userName = userActivityKey.userName;
    activityAttendeeDtls = activityAttendeeObj.readByActivityAttendee(
      nfIndicator, readByActivityAttendeeKey);

    // BEGIN, CR00314368, MV
    if (!nfIndicator.isNotFound()) {
      if (EnvVars.ENV_VALUE_YES.equalsIgnoreCase(
        readSendNotificationAlertsProperty())) {
        // END, CR00314368

        final Event event = new curam.util.events.struct.Event();

        event.eventKey = ACTIVITY.INVITEE_REJECTED;
        event.primaryEventData = activityAttendeeDtls.attendeeID;
        event.secondaryEventData = maintainActivityKey.activityID;

        EventService.raiseEvent(event);
        // BEGIN, CR00314368, MV
      } else {

        final ActivityKey activityKey = new ActivityKey();

        activityKey.activityID = key.activityID;
        final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
        final ActivityDtls activityDtls = activityObj.read(activityKey);

        final BusinessObjectAssociationTasksKey businessObjectAssociationTasksKey = new BusinessObjectAssociationTasksKey();

        if (activityDtls.recurrenceID != 0) {
          businessObjectAssociationTasksKey.bizObjectID = activityDtls.recurrenceID;
          businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITYRECURRENCE;
        } else {
          businessObjectAssociationTasksKey.bizObjectID = key.activityID;
          businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITY;
        }
        businessObjectAssociationTasksKey.taskReservationStatus = TASKSTATUS.NOTSTARTED;

        final BusinessObjectAssociationTasksDetailsList businessObjectAssociationTasksDetailsList = BusinessObjectAssociationWorkspace.getBusinessObjectAssociationTasks(
          businessObjectAssociationTasksKey);
        final UsersKey usersKey = new UsersKey();

        if (!businessObjectAssociationTasksDetailsList.dtls.isEmpty()) {
          for (final BusinessObjectAssociationTasksDetails businessObjectAssociationTasksDetails : businessObjectAssociationTasksDetailsList.dtls.items()) {
            final curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();
            final curam.core.sl.struct.TaskManagementTaskKey taskKey = new curam.core.sl.struct.TaskManagementTaskKey();

            taskKey.taskID = businessObjectAssociationTasksDetails.taskID;
            final TaskAssigneeDetailsList taskAssigneeDetailsList = taskManagementObj.viewAssignmentsForTask(
              taskKey);

            for (final TaskAssigneeDetails taskAssigneeDetails : taskAssigneeDetailsList.dtls.items()) {

              usersKey.userName = readByActivityAttendeeKey.userName;

              final UserAccess userAccessObj = UserAccessFactory.newInstance();
              final UserDetails userDetails = userAccessObj.getUserDetails(
                usersKey);

              if (userDetails.fullName.equalsIgnoreCase(
                taskAssigneeDetails.assignedTo)) {

                final Event event = new Event();

                event.eventKey = TASK.CLOSED;
                event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
                EventService.raiseEvent(event);
              }

            }
          }
        }

      }
    }
    // END, CR00314368
    // Reject Invitation
    maintainUserActivityObj.maintainAcceptanceStatus(maintainActivityKey,
      userActivityKey, attendeeAcceptanceDetails);
  }

  // ___________________________________________________________________________
  /**
   * Invites an attendee to the specified standard activity.
   *
   * @param details
   * Activity invitation details.
   */

  @Override
  public void inviteAttendeeToStandardActivity(
    final ActivityInvitationDetails details) throws AppException,
      InformationalException {

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00049218, GM
    if (details.activityAttendeeID.trim().equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_FV_SELECT_ATTENDEE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // BEGIN, CR00099710, PMD
    if (details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.PERSON)) {

      // Client merge manipulation variables
      final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

      // Set the concern role key
      concernRoleKey.concernRoleID = Long.parseLong(details.activityAttendeeID);

      // Check if the concern role has been marked as a duplicate
      final CuramInd curamInd = clientMergeObj.isConcernRoleDuplicate(
        concernRoleKey);

      // If the concern role is a duplicate, throw an exception
      if (curamInd.statusInd) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_DUPLICATE_CLIENT_INVITE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00099710

    // Users entity object, key and details
    final UsersKey usersKey = new UsersKey();

    // ConcernRole key and details
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;

    // MaintainActivity object
    final curam.core.intf.MaintainActivity maintainActivityObj = curam.core.fact.MaintainActivityFactory.newInstance();

    // MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Key objects
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final UserActivityKey userActivityKey = new UserActivityKey();

    // SystemUser object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // BEGIN, CR00227859, PM
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = details.activityID;
    activityDtls = activityObj.read(activityKey);

    if (!systemUserDtls.userName.equals(activityDtls.userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 6);
    }
    // END, CR00227859

    // Attendee details
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();

    curam.util.type.StringList attendeeList;

    // Assign keys
    maintainActivityKey.activityID = details.activityID;
    userActivityKey.userName = systemUserObj.getUserDetails().userName;

    // Read the user activity
    final ViewUserActivityResult viewUserActivityResult = maintainUserActivityObj.viewUserActivity(
      maintainActivityKey, userActivityKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = viewUserActivityResult.details.caseID;

    // BEGIN, CR00078653, RPM
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = viewUserActivityResult.details.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }
    // END, CR00078653
    // END, CR00001117

    // Get list of attendees
    attendeeList = curam.util.resources.StringUtil.tabText2StringList(
      viewUserActivityResult.attendeeDetails.attendeeNameDetails);

    // Add a trailing tab to the attendee string, if necessary
    if (viewUserActivityResult.attendeeDetails.attendeeNameDetails.length() > 0) {
      attendeeNameIDDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails
        + CuramConst.gkTabDelimiter;
    }

    // BEGIN, CR00068919, VM
    // Add new attendee to existing attendee details
    if (details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.USER)
      || details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.EXTERNALUSER)) {

      // Add a user attendee
      usersKey.userName = details.activityAttendeeID;

      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UserDetails userDetails = userAccessObj.getUserDetails(usersKey);

      // BEGIN, CR00273787, PB
      if (attendeeList.contains(userDetails.userName)) {
        // END, CR00273787

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_ALREADY_INVITED);

        e.arg(userDetails.firstname + CuramConst.gkSpace + userDetails.surname);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }

      attendeeNameIDDetails.attendeeNameDetails = attendeeNameIDDetails.attendeeNameDetails
        + userDetails.userName + CuramConst.gkTabDelimiter
        + userDetails.firstname + CuramConst.gkSpace + userDetails.surname
        + CuramConst.gkTabDelimiter + curam.codetable.ATTENDEETYPE.USER;
      // END, CR00068919

    } else if (!details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.OTHER)) {

      // Add a concern role attendee
      concernRoleKey.concernRoleID = java.lang.Long.parseLong(
        details.activityAttendeeID);

      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      if (attendeeNameIDDetails.attendeeNameDetails.indexOf(
        String.valueOf(concernRoleDtls.concernRoleID))
          != -1) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_ALREADY_INVITED);

        e.arg(concernRoleDtls.concernRoleName);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

      attendeeNameIDDetails.attendeeNameDetails = attendeeNameIDDetails.attendeeNameDetails
        + String.valueOf(concernRoleDtls.concernRoleID)
        + CuramConst.gkTabDelimiter + concernRoleDtls.concernRoleName
        + CuramConst.gkTabDelimiter + curam.codetable.ATTENDEETYPE.CONCERNROLE;

    }

    // Set frequency pattern to blank
    viewUserActivityResult.details.frequencyPattern = kFrequencyPattern;

    // Add all attendees from the new attendee details
    maintainActivityObj.maintainAttendeesForActivity(
      viewUserActivityResult.details, viewUserActivityResult.attendeeDetails,
      attendeeNameIDDetails);

    maintainActivityObj.informAttendeesAboutActivity(
      viewUserActivityResult.details, viewUserActivityResult.attendeeDetails,
      attendeeNameIDDetails);
    // BEGIN, CR00357198, AC
    final ViewStandardActivityUserDetails viewStandardActivityUserDetails = new ViewStandardActivityUserDetails();
    final AttendeeNameIDDetails oldAttendeeNameIDDetails = new AttendeeNameIDDetails();

    viewStandardActivityUserDetails.assign(activityDtls);
    viewStandardActivityUserDetails.assign(viewUserActivityResult);
    viewStandardActivityUserDetails.ignoreConflictInd = details.ignoreConflictsIndOpt;
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    oldAttendeeNameIDDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails;

    final IndicatorStruct modifyAll = new IndicatorStruct();

    maintainActivityDetails.assign(viewUserActivityResult.details);
    usersKey.userName = details.activityAttendeeID;
    final MaintainActivityDetails maintainActivityDtls = new MaintainActivityDetails();

    maintainActivityDtls.startDateTime = activityDtls.startDateTime;
    maintainActivityDtls.endDateTime = activityDtls.endDateTime;
    maintainActivityDtls.userName = usersKey.userName;
    final ActivityNameDetails activityNameDetails = new ActivityNameDetails();
    final ActivityConflictDetails activityConflictDetails = new ActivityConflictDetails();

    activityNameDetails.nameInd = true;
    if (systemUserDtls.userName.equals(activityDtls.userName)) {
      if (!viewStandardActivityUserDetails.ignoreConflictInd) {
        final CheckForConflictResult checkForConflictResult = UserActivityConflictFactory.newInstance().checkForConflict(
          maintainActivityDtls);
        final ActivityConflictDetails activityConflictDetailsParse = UserActivityConflictFactory.newInstance().parseConflictList(
          checkForConflictResult.activityConflictList, activityNameDetails);

        activityConflictDetails.conflictString += activityConflictDetailsParse.conflictString;
        activityConflictDetails.conflictInd = true;
        if (checkForConflictResult.activityConflictDetails.conflictInd) {
          final AppException e = new AppException(
            BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

          e.arg(activityConflictDetails.conflictString);

          ValidationManagerFactory.getManager().throwWithLookup(e,
            ValidationManagerConst.kSetOne, 4);
        }
      }
    }// END, CR00357198
  }

  // ___________________________________________________________________________
  /**
   * Cancels a recurring activity for an organization.
   *
   * @param key
   * The ID of the activity to be canceled.
   */
  @Override
  public void cancelRecurringOrganizationActivity(
    final CancelRecurringOrganizationActivityKey key) throws AppException,
      InformationalException {

    // Organization Activity Maintenance Object and key
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivity = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();

    // Create the object for the cancel operation and assign it its values
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // Get activityID from the key
    maintainActivityKey.activityID = key.cancelActivity.activityID;

    // Cancel the Organization Activity
    maintainOrganisationActivity.cancelOrganisationActivity(maintainActivityKey,
      key.indicatorStruct);

  }

  // ___________________________________________________________________________
  /**
   * Cancels a standard activity for an organization.
   *
   * @param key
   * The ID of the activity to be canceled.
   */
  @Override
  public void cancelStandardOrganizationActivity(
    final CancelStandardOrganizationActivityKey key) throws AppException,
      InformationalException {

    // Organization Activity Maintenance Object and key
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivity = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();

    // Create the objects for the cancel operation and assign them their values
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // Get activityID from the key
    maintainActivityKey.activityID = key.cancelActivity.activityID;
    // changeAllIndicator is automatically set to false for standard activities.
    final IndicatorStruct removeAllInd = new IndicatorStruct();

    removeAllInd.changeAllIndicator = false;

    // Cancel the Organization Activity
    maintainOrganisationActivity.cancelOrganisationActivity(maintainActivityKey,
      removeAllInd);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new recurring activity for an organization.
   *
   * @param details
   * The details of the new activity.
   */
  @Override
  public void createRecurringOrganizationActivity(
    final CreateRecurringOrganizationActivityDetails details)
    throws AppException, InformationalException {

    // Organization Activity Maintenance Object
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivityObj = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();

    // Create an instance of OrganisationActivityKey and assign organization ID
    final OrganisationActivityKey organisationActivityKey = new OrganisationActivityKey();

    // Use default organization ID
    // BEGIN, CR00168663, LD
    organisationActivityKey.organisationID = getOrganizationID();
    // END, CR00168663

    // Create an instance of MaintainActivityDetails and assign details
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    maintainActivityDetails.assign(
      details.maintainRecurringOrganizationActivityDetails);

    // BEGIN, CR00168663, LD
    // Set organization id
    maintainActivityDetails.organisationID = getOrganizationID();
    // END, CR00168663

    if (details.maintainRecurringOrganizationActivityDetails.frequencyPattern.length()
      == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOACTIVITY.ERR_ACTIVITY_FV_FREQUENCY_PATTERN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    // Set recurrence start date
    maintainActivityDetails.recurrenceStartDate = new curam.util.type.Date(
      details.maintainRecurringOrganizationActivityDetails.startDateTime);

    // Call relevant create method depending on ignoreConflicts value
    if (details.maintainRecurringOrganizationActivityDetails.ignoreConflicts) {

      maintainOrganisationActivityObj.createOrganisationActivityIgnoreConflict(
        organisationActivityKey, maintainActivityDetails);

    } else {

      final CreateOrganisationActivityWarnConflictResult createOrganisationActivityWarnConflictResult = maintainOrganisationActivityObj.createOrganisationActivityWarnConflict(
        organisationActivityKey, maintainActivityDetails);

      // Throw an error if there is a conflict, since the user has selected
      // not to ignore conflicts.
      if (createOrganisationActivityWarnConflictResult.activityConflictDetails.conflictInd) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

        e.arg(
          createOrganisationActivityWarnConflictResult.activityConflictDetails.conflictString);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a new standard activity for an organization.
   *
   * @param details
   * The details of the new activity.
   */
  @Override
  public void createStandardOrganizationActivity(
    final MaintainStandardOrganizationActivityDetails details)
    throws AppException, InformationalException {

    // Organization Activity Maintenance Object
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivityObj = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();

    // Create an instance of OrganisationActivityKey and assign organization ID
    final OrganisationActivityKey organisationActivityKey = new OrganisationActivityKey();

    // BEGIN, CR00168663, LD
    // Use default organizationID
    organisationActivityKey.organisationID = getOrganizationID();
    // END, CR00168663

    // Create an instance of MaintainActivityDetails and assign details
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    maintainActivityDetails.assign(details.organizationStandardActivityDetails);

    // BEGIN, CR00168663, LD
    // Set organization id
    maintainActivityDetails.organisationID = getOrganizationID();
    // END, CR00168663

    // Set frequency pattern to blank
    maintainActivityDetails.frequencyPattern = kFrequencyPattern;

    // Call relevant create method depending on ignoreConflicts value
    if (details.organizationStandardActivityDetails.ignoreConflicts) {

      maintainOrganisationActivityObj.createOrganisationActivityIgnoreConflict(
        organisationActivityKey, maintainActivityDetails);

    } else {

      final CreateOrganisationActivityWarnConflictResult createOrganisationActivityWarnConflictResult = maintainOrganisationActivityObj.createOrganisationActivityWarnConflict(
        organisationActivityKey, maintainActivityDetails);

      // Throw an error if there is a conflict, since the user has selected
      // not to ignore conflicts.
      if (createOrganisationActivityWarnConflictResult.activityConflictDetails.conflictInd) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

        e.arg(
          createOrganisationActivityWarnConflictResult.activityConflictDetails.conflictString);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          7);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing recurring activity for an organization.
   *
   * @param details
   * The details of the activity to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyRecurringOrganizationActivity(
    final ModifyRecurringOrganizationActivityDetails details)
    throws AppException, InformationalException {

    final MaintainOrganisationActivity maintainOrganisationActivityObj = MaintainOrganisationActivityFactory.newInstance();
    final OrganisationActivityKey organisationActivityKey = new OrganisationActivityKey();

    organisationActivityKey.organisationID = getOrganizationID();
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    maintainActivityDetails.assign(
      details.maintainRecurringOrganizationActivityDetails);
    maintainActivityDetails.organisationID = getOrganizationID();

    if (details.maintainRecurringOrganizationActivityDetails.frequencyPattern.length()
      == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_FREQUENCY_PATTERN),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    maintainActivityDetails.recurrenceStartDate = new Date(
      details.maintainRecurringOrganizationActivityDetails.startDateTime);

    // BEGIN, CR00225987, GSP
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = details.maintainRecurringOrganizationActivityDetails.activityID;
    activityDtls = activityObj.read(activityKey);

    if (activityDtls.organisationID != 0) {
      // END, CR00225987

      // Call relevant modify method depending on ignoreConflictInd value.
      if (details.maintainRecurringOrganizationActivityDetails.ignoreConflicts) {

        maintainOrganisationActivityObj.modifyOrganisationActivityIgnoreConflict(
          organisationActivityKey, maintainActivityDetails,
          details.indicatorStruct);

      } else {

        final ModifyOrganisationActivityWarnConflictResult modifyOrganisationActivityWarnConflictResult = maintainOrganisationActivityObj.modifyOrganisationActivityWarnConflict(
          organisationActivityKey, maintainActivityDetails,
          details.indicatorStruct);

        // Throw an error if there is a conflict, since the user has selected
        // not to ignore conflicts.
        if (modifyOrganisationActivityWarnConflictResult.activityConflictDetails.conflictInd) {

          final AppException e = new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

          e.arg(
            modifyOrganisationActivityWarnConflictResult.activityConflictDetails.conflictString);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            2);

        }

      }
    } // BEGIN, CR00225987, GSP
    else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }
    // END, CR00225987
  }

  // ___________________________________________________________________________
  /**
   * Modifies an existing standard activity for an organization.
   *
   * @param details
   * Contains the details of the activity to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modifyStandardOrganizationActivity(
    final MaintainStandardOrganizationActivityDetails details)
    throws AppException, InformationalException {

    final MaintainOrganisationActivity maintainOrganisationActivityObj = MaintainOrganisationActivityFactory.newInstance();
    final OrganisationActivityKey organisationActivityKey = new OrganisationActivityKey();
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    organisationActivityKey.organisationID = getOrganizationID();
    maintainActivityDetails.assign(details.organizationStandardActivityDetails);
    maintainActivityDetails.organisationID = getOrganizationID();
    maintainActivityDetails.frequencyPattern = kFrequencyPattern;

    // Create an instance of IndicatorStruct and assign false as default
    final IndicatorStruct indicatorStruct = new IndicatorStruct();

    indicatorStruct.changeAllIndicator = false;

    // BEGIN, CR00225987, GSP
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = details.organizationStandardActivityDetails.activityID;
    activityDtls = activityObj.read(activityKey);

    if (activityDtls.organisationID != 0) {

      // END, CR00225987

      // Call relevant modify method depending on ignoreConflictInd value.
      if (details.organizationStandardActivityDetails.ignoreConflicts) {

        maintainOrganisationActivityObj.modifyOrganisationActivityIgnoreConflict(
          organisationActivityKey, maintainActivityDetails, indicatorStruct);

      } else {

        final ModifyOrganisationActivityWarnConflictResult modifyOrganisationActivityWarnConflictResult = maintainOrganisationActivityObj.modifyOrganisationActivityWarnConflict(
          organisationActivityKey, maintainActivityDetails, indicatorStruct);

        // Throw an error if there is a conflict, since the user has selected
        // not to ignore conflicts.
        if (modifyOrganisationActivityWarnConflictResult.activityConflictDetails.conflictInd) {
          final AppException e = new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

          e.arg(
            modifyOrganisationActivityWarnConflictResult.activityConflictDetails.conflictString);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            3);

        }

      }
    } // BEGIN, CR00225987, GSP
    else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
    }
    // END, CR00225987
  }

  // ___________________________________________________________________________
  /**
   * Reads an existing recurring activity for an organization.
   *
   * @param key
   * The details of the activity to be read.
   *
   * @return Details of the recurring activity for the organization.
   */
  @Override
  public ReadRecurringOrganizationActivityDetails readRecurringOrganizationActivity(
    final ReadRecurringOrganizationActivityKey key) throws AppException,
      InformationalException {

    // Organization Activity Maintenance Object
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivityObj = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();

    // Create the object to be returned
    final ReadRecurringOrganizationActivityDetails readRecurringOrganizationActivityDetails = new ReadRecurringOrganizationActivityDetails();

    // Perform the read
    final MaintainActivityDetails maintainActivityDetails = maintainOrganisationActivityObj.viewOrganisationActivity(
      key.maintainActivityKey);

    // Assign the results to the return object
    readRecurringOrganizationActivityDetails.maintainRecurringOrganizationActivityDetails.assign(
      maintainActivityDetails);

    // Read the context description details and assign to the return object
    final ActivityContextDescriptionKey activityContextDescriptionKey = new ActivityContextDescriptionKey();

    activityContextDescriptionKey.activityID = key.maintainActivityKey.activityID;

    readRecurringOrganizationActivityDetails.activityContextDescriptionDetails = readActivityContextDescription(
      activityContextDescriptionKey);

    // Return a string value for occurrences
    if (maintainActivityDetails.numberOfOccurrences != 0) {

      // Set string value of occurrences
      readRecurringOrganizationActivityDetails.maintainRecurringOrganizationActivityDetails.occurrencesStr = String.valueOf(
        maintainActivityDetails.numberOfOccurrences);

    } else {

      // Integer value is zero, so return a blank string
      // BEGIN, CR00049218, GM
      readRecurringOrganizationActivityDetails.maintainRecurringOrganizationActivityDetails.occurrencesStr = CuramConst.gkEmpty;
      // END, CR00049218

    }

    return readRecurringOrganizationActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads an existing standard activity for an organization.
   *
   * @param key
   * The details of the activity to be read.
   *
   * @return Details of the standard activity for the organization.
   */
  @Override
  public ReadStandardOrganizationActivityDetails readStandardOrganizationActivity(
    final ReadStandardOrganizationActivityKey key) throws AppException,
      InformationalException {

    // Organization Activity Maintenance Object
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivityObj = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();

    // Create the object to be returned
    final ReadStandardOrganizationActivityDetails readStandardOrganizationActivityDetails = new ReadStandardOrganizationActivityDetails();

    // Perform the read
    final MaintainActivityDetails maintainActivityDetails = maintainOrganisationActivityObj.viewOrganisationActivity(
      key.maintainActivityKey);

    // Assign the results to the return object
    readStandardOrganizationActivityDetails.organizationStandardActivityDetails.assign(
      maintainActivityDetails);

    // Read the context description details and assign to the return object
    final ActivityContextDescriptionKey activityContextDescriptionKey = new ActivityContextDescriptionKey();

    activityContextDescriptionKey.activityID = key.maintainActivityKey.activityID;
    readStandardOrganizationActivityDetails.activityContextDescriptionDetails = readActivityContextDescription(
      activityContextDescriptionKey);

    return readStandardOrganizationActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * Invites an attendee to the recurring activity.
   *
   * @param details
   * Activity invitation details.
   */
  @Override
  public void inviteAttendeeToRecurringActivity(
    final ActivityInvitationDetails details) throws AppException,
      InformationalException {

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00049218, GM
    if (details.activityAttendeeID.trim().equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_FV_SELECT_ATTENDEE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00099710, PMD
    if (details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.PERSON)) {

      // Client merge manipulation variables
      final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

      // Set the concern role key
      concernRoleKey.concernRoleID = Long.parseLong(details.activityAttendeeID);

      // Check if the concern role has been marked as a duplicate
      final CuramInd curamInd = clientMergeObj.isConcernRoleDuplicate(
        concernRoleKey);

      // If the concern role is a duplicate, throw an exception
      if (curamInd.statusInd) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_DUPLICATE_CLIENT_INVITE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }
    // END, CR00099710

    // Users key
    final UsersKey usersKey = new UsersKey();

    // MaintainActivity Details
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();

    final ReadRecurringActivitiesKey readRecurringActivitiesKey = new ReadRecurringActivitiesKey();

    RecurringActivitiesList recurringActivitiesList;

    ActivityDtls activityDtls;

    final ActivityKey activityKey = new ActivityKey();

    // ConcernRole key and details
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;

    // MaintainActivity object
    final curam.core.intf.MaintainActivity maintainActivityObj = curam.core.fact.MaintainActivityFactory.newInstance();

    // MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Key objects
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final UserActivityKey userActivityKey = new UserActivityKey();
    final RecurringActivityKey recurringActivityKey = new RecurringActivityKey();

    // SystemUser object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Attendee details
    final AttendeeNameIDDetails attendeeNameIDDetails = new AttendeeNameIDDetails();

    curam.util.type.StringList attendeeList;

    // Assign keys
    maintainActivityKey.activityID = details.activityID;
    userActivityKey.userName = systemUserObj.getUserDetails().userName;

    // Read the activity record
    activityKey.activityID = details.activityID;
    activityDtls = activityObj.read(activityKey);

    // BEGIN, CR00227859, PM
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    if (!systemUserDtls.userName.equals(activityDtls.userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }
    // END, CR00227859

    // Read the user activity
    final ViewUserActivityResult viewUserActivityResult = maintainUserActivityObj.viewUserActivity(
      maintainActivityKey, userActivityKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = viewUserActivityResult.details.caseID;

    // BEGIN, CR00078653, RPM
    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
        final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

        // register the service plan security implementation
        curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = viewUserActivityResult.details.caseID;
        servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }
    // END, CR00078653
    // END, CR00001117

    // Get list of attendees
    attendeeList = curam.util.resources.StringUtil.tabText2StringList(
      viewUserActivityResult.attendeeDetails.attendeeNameDetails);

    // Remove any existing attendees
    if (attendeeList.size() > kListEntriesToConstituteAMeeting) {

      recurringActivityKey.recurrenceID = activityDtls.recurrenceID;
      recurringActivityKey.activityID = details.activityID;
      // Remove all existing attendees
      maintainActivityObj.removeAttendeesForActivity(recurringActivityKey);
    }

    // Add a trailing tab to the attendee string, if necessary
    if (viewUserActivityResult.attendeeDetails.attendeeNameDetails.length() > 0) {
      attendeeNameIDDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails
        + CuramConst.gkTabDelimiter;
    }

    // Add new attendee to existing attendee details
    // BEGIN, CR00099177, NP
    if (details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.USER)
      || details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.EXTERNALUSER)) {

      // Add a user attendee
      usersKey.userName = details.activityAttendeeID;

      // read the full name via the UserAccess class as this will consider both
      // internal and external users.
      final UserAccess UserAccessObj = curam.core.sl.fact.UserAccessFactory.newInstance();
      final UserFullname fullName = UserAccessObj.getFullName(usersKey);

      if (attendeeNameIDDetails.attendeeNameDetails.indexOf(usersKey.userName)
        != -1) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_ALREADY_INVITED);

        e.arg(fullName.fullname);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
      }

      attendeeNameIDDetails.attendeeNameDetails = attendeeNameIDDetails.attendeeNameDetails
        + usersKey.userName + CuramConst.gkTabDelimiter + fullName
        + CuramConst.gkTabDelimiter + curam.codetable.ATTENDEETYPE.USER;
      // END, CR00099177

    } else if (!details.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.OTHER)) {

      // Add a concern role attendee
      concernRoleKey.concernRoleID = java.lang.Long.parseLong(
        details.activityAttendeeID);

      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      if (attendeeNameIDDetails.attendeeNameDetails.indexOf(
        String.valueOf(concernRoleDtls.concernRoleID))
          != -1) {

        final AppException e = new AppException(
          curam.message.BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_ALREADY_INVITED);

        e.arg(concernRoleDtls.concernRoleName);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
      }

      attendeeNameIDDetails.attendeeNameDetails = attendeeNameIDDetails.attendeeNameDetails
        + String.valueOf(concernRoleDtls.concernRoleID)
        + CuramConst.gkTabDelimiter + concernRoleDtls.concernRoleName
        + CuramConst.gkTabDelimiter + curam.codetable.ATTENDEETYPE.CONCERNROLE;

    }

    readRecurringActivitiesKey.recurrenceID = activityDtls.recurrenceID;

    recurringActivitiesList = activityObj.searchRecurringActivities(
      readRecurringActivitiesKey);

    for (int i = 0; i < recurringActivitiesList.dtls.size(); i++) {
      viewUserActivityResult.details.activityID = recurringActivitiesList.dtls.item(i).activityID;
      // Add all attendees from the new attendee details
      maintainActivityObj.maintainAttendeesForActivity(
        viewUserActivityResult.details, viewUserActivityResult.attendeeDetails,
        attendeeNameIDDetails);
    }

    maintainActivityObj.informAttendeesAboutActivity(
      viewUserActivityResult.details, viewUserActivityResult.attendeeDetails,
      attendeeNameIDDetails);
    // BEGIN, CR00357198, AC
    final ViewStandardActivityUserDetails viewStandardActivityUserDetails = new ViewStandardActivityUserDetails();
    final AttendeeNameIDDetails oldAttendeeNameIDDetails = new AttendeeNameIDDetails();

    viewStandardActivityUserDetails.assign(activityDtls);
    viewStandardActivityUserDetails.assign(viewUserActivityResult);
    viewStandardActivityUserDetails.ignoreConflictInd = details.ignoreConflictsIndOpt;
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    oldAttendeeNameIDDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails;

    final IndicatorStruct modifyAll = new IndicatorStruct();

    maintainActivityDetails.assign(viewUserActivityResult.details);
    usersKey.userName = details.activityAttendeeID;
    final MaintainActivityDetails maintainActivityDtls = new MaintainActivityDetails();

    maintainActivityDtls.startDateTime = activityDtls.startDateTime;
    maintainActivityDtls.endDateTime = activityDtls.endDateTime;
    maintainActivityDtls.userName = usersKey.userName;
    final ActivityNameDetails activityNameDetails = new ActivityNameDetails();
    final ActivityConflictDetails activityConflictDetails = new ActivityConflictDetails();

    activityNameDetails.nameInd = true;
    if (systemUserDtls.userName.equals(activityDtls.userName)) {
      if (!viewStandardActivityUserDetails.ignoreConflictInd) {

        final CheckForConflictResult checkForConflictResult = UserActivityConflictFactory.newInstance().checkForConflict(
          maintainActivityDtls);
        final ActivityConflictDetails activityConflictDetailsParse = UserActivityConflictFactory.newInstance().parseConflictList(
          checkForConflictResult.activityConflictList, activityNameDetails);

        activityConflictDetails.conflictString += activityConflictDetailsParse.conflictString;
        activityConflictDetails.conflictInd = true;
        if (checkForConflictResult.activityConflictDetails.conflictInd) {
          final AppException e = new AppException(
            BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_CONFLICTS_FOUND);

          e.arg(activityConflictDetails.conflictString);

          ValidationManagerFactory.getManager().throwWithLookup(e,
            ValidationManagerConst.kSetOne, 4);
        }
      }
    }// END, CR00357198
  }

  // ___________________________________________________________________________
  /**
   * Retrieves data for a calendar view for the specified organization.
   *
   * @param key
   * The calendar date, type and view type and organization ID.
   *
   * @return Calendar data for the organization.
   */
  @Override
  protected CalendarDataDetails getOrganizationActivityData(
    final OrganizationCalendarDataKey key) throws AppException,
      InformationalException {

    // Get instance of MaintainOrganisationActivity object and key.
    final curam.core.intf.MaintainOrganisationActivity maintainOrganisationActivityObj = curam.core.fact.MaintainOrganisationActivityFactory.newInstance();
    final OrganisationActivitySearchKey organisationActivitySearchKey = new OrganisationActivitySearchKey();

    // CalendarDataDetails object
    final CalendarDataDetails calendarDataDetails = new CalendarDataDetails();

    // CalendarData object
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory.newInstance();

    CalendarElementData calendarElementData;

    // Use current date if the start date is not set
    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Use default view if view type is not set
    if (key.calendarViewType.length() == 0) {
      key.calendarViewType = CALENDARVIEWTYPE.DEFAULTCODE;
    }

    // Get date range
    final DateRangeKey dateRangeKey = new DateRangeKey();

    dateRangeKey.startDate = key.startDate;
    dateRangeKey.calendarViewType = key.calendarViewType;

    final DateTimeRangeDetails dateTimeRangeDetails = calendarDataObj.getDateTimeRange(
      dateRangeKey);

    // Populate organisationActivitySearchKey
    organisationActivitySearchKey.organisationID = key.organizationID;
    organisationActivitySearchKey.startDateTime = dateTimeRangeDetails.startDateTime;
    organisationActivitySearchKey.endDateTime = dateTimeRangeDetails.endDateTime;

    // Create empty SearchOrganisationByDateRangeResult instance.
    SearchOrganisationByDateRangeResult searchOrganisationByDateRangeResult;

    // Search for organization activity by date range.
    searchOrganisationByDateRangeResult = maintainOrganisationActivityObj.searchOrganisationByDateRange(
      organisationActivitySearchKey);

    // Create empty ActivityIntervalDetailsList instance.
    ActivityIntervalDetailsList activityIntervalDetailsList;

    // Obtain list of activities
    activityIntervalDetailsList = searchOrganisationByDateRangeResult.activityIntervalDetailsList;

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * activityIntervalDetailsList.dtls.size());

    // BEGIN, CR00023323, SK
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataHeader);
    xmlString.append(key.calendarType);
    xmlString.append(CuramCalendarHeaderConst.kCloseBracket);
    xmlString.append(CuramCalendarHeaderConst.kNewLine);
    // END, CR00023323
    // Loop through list of activities
    for (int i = 0; i < activityIntervalDetailsList.dtls.size(); i++) {

      // ActivityElementDetails instance
      final ActivityElementDetails activityElementDetails = new ActivityElementDetails();

      activityElementDetails.assign(activityIntervalDetailsList.dtls.item(i));

      calendarElementData = calendarDataObj.parseActivity(
        activityElementDetails, dateTimeRangeDetails);
      xmlString.append(calendarElementData.calendarXMLString);

    }

    // Create CURAM_CALENDAR_DATA node footer.
    // BEGIN, CR00023323, SK
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    xmlString.append(CuramCalendarHeaderConst.kNewLine);
    // END, CR00023323
    calendarDataDetails.calendarXMLString = xmlString.toString();

    // Return details.
    return calendarDataDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves data for a calendar view for the default organization.
   *
   * @param key
   * The calendar date and view type.
   *
   * @return Calendar data for the organization.
   */
  // Method signature change as the method now also returns organization
  // context description.
  @Override
  public OrganizationCalendarData searchOrganizationActivity(
    final SearchActivityKey key) throws AppException, InformationalException {

    // Create empty CalendarDataDetails and OrganizationCalendarDataKey objects.
    final OrganizationCalendarData organizationCalendarData = new OrganizationCalendarData();

    // Context Description key.
    final OrganizationContextDescriptionKey organizationContextDescriptionKey = new OrganizationContextDescriptionKey();

    // BEGIN, CR00168663, LD
    // set the key for operation.
    organizationContextDescriptionKey.organizationID = getOrganizationID();
    // END, CR00168663

    final OrganizationCalendarDataKey organizationCalendarDataKey = new OrganizationCalendarDataKey();

    // Populate key
    // BEGIN, CR00023323, SK
    // BEGIN, CR00163098, JC
    organizationCalendarDataKey.calendarType = CuramCalendarHeaderConst.kQuote
      + curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
      CALENDARTYPE.ORGANISATION, TransactionInfo.getProgramLocale())
      + CuramCalendarHeaderConst.kQuote;
    // END, CR00163098, JC
    // END, CR00023323
    organizationCalendarDataKey.startDate = key.startDate;
    organizationCalendarDataKey.calendarViewType = key.calendarViewType;

    // BEGIN, CR00168663, LD
    // Set organization id
    organizationCalendarDataKey.organizationID = getOrganizationID();
    // END, CR00168663

    // Get data for the organization activities
    organizationCalendarData.calendarDataDetails = getOrganizationActivityData(
      organizationCalendarDataKey);

    // read the organization context description
    organizationCalendarData.organizationContextDescriptionDetails = readOrganizationContextDescription(
      organizationContextDescriptionKey);

    return organizationCalendarData;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves data for a calendar view for the specified user.
   *
   * @param key
   * The calendar date and view type and the user name.
   *
   * @return Calendar data for the user.
   */
  @Override
  public UserCalendarData searchUserActivity(final SearchUserActivityKey key)
    throws AppException, InformationalException {

    // Create empty CalendarDataDetails and UserCalendarDataKey objects.
    CalendarDataDetails calendarDataDetails;
    final UserCalendarDataKey userCalendarDataKey = new UserCalendarDataKey();

    final OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    final UserCalendarData userCalendarData = new UserCalendarData();
    UserContextDescriptionDetails userContextDescriptionDetails;

    // Populate key
    // BEGIN, CR00023323, SK
    // BEGIN, CR00163098, JC
    userCalendarDataKey.calendarType = CuramCalendarHeaderConst.kQuote
      + curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
      CALENDARTYPE.USER, TransactionInfo.getProgramLocale())
      + CuramCalendarHeaderConst.kQuote;
    // END, CR00163098, JC
    // END, CR00023323
    userCalendarDataKey.startDate = key.startDate;
    userCalendarDataKey.calendarViewType = key.calendarViewType;
    userCalendarDataKey.userName = key.userName;

    // Get data for the user activities
    calendarDataDetails = getUserActivityData(userCalendarDataKey);

    organizationUserContextDescriptionKey.userName = key.userName;

    userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);
    userCalendarData.userContextDescriptionDetails.description = userContextDescriptionDetails.description;
    userCalendarData.calendarDataDetails = calendarDataDetails;

    return userCalendarData;

  }

  // ___________________________________________________________________________
  /**
   * Reads the description of the Organization.
   *
   * @param key
   * Key for the organization
   *
   * @return Organization context description details
   */
  @Override
  protected OrganizationContextDescriptionDetails readOrganizationContextDescription(
    final OrganizationContextDescriptionKey key) throws AppException,
      InformationalException {

    // Organization maintenance business process object
    final curam.core.intf.Organisation organisationObj = curam.core.fact.OrganisationFactory.newInstance();

    // Details to be returned
    final OrganizationContextDescriptionDetails organizationContextDescriptionDetails = new OrganizationContextDescriptionDetails();

    // Read the organization details
    final OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = key.organizationID;

    curam.core.struct.OrganisationDtls organisationDtls;

    organisationDtls = organisationObj.read(organisationKey);

    // Prepare the context description details
    organizationContextDescriptionDetails.description = organisationDtls.name;

    // Return the details
    return organizationContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a specified recurring activity for a user.
   *
   * @param key
   * Activity key and user name.
   *
   * @return The activity details returned from the database.
   */
  @Override
  protected ViewRecurringUserActivityDetails readRecurringUserActivity(
    final ReadUserActivityKey key) throws AppException,
      InformationalException {

    // Create instance of ViewRecurringUserActivityDetails.
    final ViewRecurringUserActivityDetails viewRecurringUserActivityDetails = new ViewRecurringUserActivityDetails();

    // Get instance of MaintainUserActivity.
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Attendee details
    ActivityAttendeeDetails activityAttendeeDetails;

    // Get instance of SystemUser.
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Create instance of UserActivityKey.
    final UserActivityKey userActivityKey = new UserActivityKey();

    // MaintainActivity key
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // Attendee details objects
    final curam.core.intf.ActivityAttendee activityAttendeeObj = curam.core.fact.ActivityAttendeeFactory.newInstance();

    ActivityAttendeeDtlsList activityAttendeeDtlsList;
    final MaintainAttendeeActivityKey maintainAttendeeActivityKey = new MaintainAttendeeActivityKey();

    // User Key
    final UsersKey usersKey = new UsersKey();

    // ConcernRole objects
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    if (key.userName.length() == 0) {
      // Get current user name
      userActivityKey.userName = systemUserObj.getUserDetails().userName;

    } else {
      userActivityKey.userName = key.userName;
    }

    // Set activity key
    maintainActivityKey.activityID = key.activityID;

    // Read a ViewUserActivityResult from the
    // MaintainUserActivity instance.
    final ViewUserActivityResult viewUserActivityResult = maintainUserActivityObj.viewUserActivity(
      maintainActivityKey, userActivityKey);

    // Get a reference to the MaintainActivityDetails attribute of
    // ViewUserActivityResult.
    final MaintainActivityDetails maintainActivityDetails = viewUserActivityResult.details;

    // Assign the returned MaintainActivityDetails Object to the
    // maintainRecurringUserActivityDetails attribute.
    viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.assign(
      maintainActivityDetails);

    viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails;

    // Create instance of ActivityContextDescriptionKey.
    final ActivityContextDescriptionKey activityContextDescriptionKey = new ActivityContextDescriptionKey();

    // Assign maintainActivityDetails to activityContextDescriptionKey
    activityContextDescriptionKey.assign(maintainActivityDetails);

    // Read ActivityContextDescriptionDetails and assign to
    // viewRecurringUserActivityDetails.
    viewRecurringUserActivityDetails.activityContextDescriptionDetails = readActivityContextDescription(
      activityContextDescriptionKey);

    // Get list of attendees
    maintainAttendeeActivityKey.activityID = viewUserActivityResult.details.activityID;
    activityAttendeeDtlsList = activityAttendeeObj.searchByActivity(
      maintainAttendeeActivityKey);

    // Get the owner details for current activity.
    final UserActivityOwnerDetailsKey userActivityOwnerDetailsKey = new UserActivityOwnerDetailsKey();
    UserActivityOwnerDetails userActivityOwnerDetails;

    userActivityOwnerDetailsKey.activityID = key.activityID;

    // read the activity owners details
    userActivityOwnerDetails = maintainUserActivityObj.readActivityOwnerDetails(
      userActivityOwnerDetailsKey);

    activityAttendeeDetails = new ActivityAttendeeDetails();

    // add the user to the attendee list
    activityAttendeeDetails.attendeeName = userActivityOwnerDetails.fullname;
    activityAttendeeDetails.activityAttendeeID = userActivityOwnerDetails.username;
    activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.USER;
    activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;
    viewRecurringUserActivityDetails.activityAttendeeList.activityAttendeeDetails.addRef(
      activityAttendeeDetails);

    // Add attendee names to output list
    for (int i = 0; i < activityAttendeeDtlsList.dtls.size(); i++) {

      activityAttendeeDetails = new ActivityAttendeeDetails();

      // If the attendee is active
      if (!activityAttendeeDtlsList.dtls.item(i).recordStatusCode.equals(
        curam.codetable.RECORDSTATUS.CANCELLED)) {

        // If the attendee is a user
        if (activityAttendeeDtlsList.dtls.item(i).userName.length() > 0) {

          // Read user details
          usersKey.userName = activityAttendeeDtlsList.dtls.item(i).userName;
          // BEGIN, CR00099177, NP
          // read the full name via the UserAccess class as this will consider
          // both internal and external users.
          final UserAccess UserAccessObj = curam.core.sl.fact.UserAccessFactory.newInstance();
          final UserFullname fullName = UserAccessObj.getFullName(usersKey);

          activityAttendeeDetails.attendeeName = fullName.fullname;
          activityAttendeeDetails.activityAttendeeID = usersKey.userName;

          // BEGIN, CR00105425, ZV
          if (UserAccessObj.getUserType(usersKey).equals(
            CuramConst.gkInternalUser)) {
            activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.USER;
          } else {
            activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.EXTERNALUSER;
          }
          // END, CR00105425
          // END, CR00099177
        }

        // If the attendee is a participant
        if (activityAttendeeDtlsList.dtls.item(i).concernRoleID != 0) {

          // Read concern role details
          concernRoleKey.concernRoleID = activityAttendeeDtlsList.dtls.item(i).concernRoleID;

          concernRoleDtls = concernRoleObj.read(concernRoleKey);

          activityAttendeeDetails.attendeeName = concernRoleDtls.concernRoleName;
          activityAttendeeDetails.activityAttendeeID = String.valueOf(
            concernRoleDtls.concernRoleID);
          activityAttendeeDetails.activityAttendeeType = concernRoleDtls.concernRoleType;
        }

        // Set invitation status
        if (activityAttendeeDtlsList.dtls.item(i).acceptedInd == true) {
          activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;

        } else {

          activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.PROVISIONAL;
        }

        viewRecurringUserActivityDetails.activityAttendeeList.activityAttendeeDetails.addRef(
          activityAttendeeDetails);

      }

    }

    // Set the caseID Reference to the appropriate value so that the home page
    // will not display a link if the caseID is 0
    if (viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseID
      == 0) {
      // BEGIN, CR00049218, GM
      viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseReference = CuramConst.gkEmpty;
      // END, CR00049218
    }

    // Return a string value for occurrences
    if (maintainActivityDetails.numberOfOccurrences != 0) {

      // Set string value of occurrences
      viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.occurrencesStr = String.valueOf(
        maintainActivityDetails.numberOfOccurrences);

    } else {

      // Integer value is zero, so return a blank string
      // BEGIN, CR00049218, GM
      viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.occurrencesStr = CuramConst.gkEmpty;
      // END, CR00049218
    }

    viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.concernRoleType = viewUserActivityResult.concernRoleType;

    return viewRecurringUserActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a specified standard activity for a user.
   *
   * @param key
   * Activity key and user name.
   *
   * @return The activity details returned from the database.
   */
  @Override
  protected ViewStandardUserActivityDetails readStandardUserActivity(
    final ReadUserActivityKey key) throws AppException,
      InformationalException {

    // MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // ViewStandardUserActivityDetails object to return the details
    final ViewStandardUserActivityDetails viewStandardUserActivityDetails = new ViewStandardUserActivityDetails();

    // View user activity result
    ViewUserActivityResult viewUserActivityResult;

    // User activity key (for current user)
    final UserActivityKey userActivityKey = new UserActivityKey();

    // Activity key
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    // SystemUser object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Attendee details objects
    final curam.core.intf.ActivityAttendee activityAttendeeObj = curam.core.fact.ActivityAttendeeFactory.newInstance();

    ActivityAttendeeDetails activityAttendeeDetails;
    ActivityAttendeeDtlsList activityAttendeeDtlsList;
    final MaintainAttendeeActivityKey maintainAttendeeActivityKey = new MaintainAttendeeActivityKey();

    // User Key
    final UsersKey usersKey = new UsersKey();

    // ConcernRole objects
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    if (key.userName.length() == 0) {
      // Get current user name
      userActivityKey.userName = systemUserObj.getUserDetails().userName;

    } else {

      userActivityKey.userName = key.userName;
    }

    // Set activity key
    maintainActivityKey.activityID = key.activityID;

    // Read the activity
    viewUserActivityResult = maintainUserActivityObj.viewUserActivity(
      maintainActivityKey, userActivityKey);

    // Read in the details to the ViewStandardUserActivityDetails object
    viewStandardUserActivityDetails.viewStandardActivityUserDetails.assign(
      viewUserActivityResult.details);

    viewStandardUserActivityDetails.viewStandardActivityUserDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails;

    // Get list of attendees
    maintainAttendeeActivityKey.activityID = viewUserActivityResult.details.activityID;
    activityAttendeeDtlsList = activityAttendeeObj.searchByActivity(
      maintainAttendeeActivityKey);

    // Get the owner details for current activity.
    final UserActivityOwnerDetailsKey userActivityOwnerDetailsKey = new UserActivityOwnerDetailsKey();
    UserActivityOwnerDetails userActivityOwnerDetails;

    userActivityOwnerDetailsKey.activityID = key.activityID;

    // read the activity owners details
    userActivityOwnerDetails = maintainUserActivityObj.readActivityOwnerDetails(
      userActivityOwnerDetailsKey);

    activityAttendeeDetails = new ActivityAttendeeDetails();

    // add the user to the attendee list
    activityAttendeeDetails.attendeeName = userActivityOwnerDetails.fullname;
    activityAttendeeDetails.activityAttendeeID = userActivityOwnerDetails.username;
    activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.USER;
    activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;
    viewStandardUserActivityDetails.activityAttendeeList.activityAttendeeDetails.addRef(
      activityAttendeeDetails);

    // Add attendee names to output list
    for (int i = 0; i < activityAttendeeDtlsList.dtls.size(); i++) {

      activityAttendeeDetails = new ActivityAttendeeDetails();

      // If the attendee is active
      if (!activityAttendeeDtlsList.dtls.item(i).recordStatusCode.equals(
        curam.codetable.RECORDSTATUS.CANCELLED)) {

        // If the attendee is a user
        if (activityAttendeeDtlsList.dtls.item(i).userName.length() > 0) {

          // Read user details
          usersKey.userName = activityAttendeeDtlsList.dtls.item(i).userName;

          // BEGIN, CR00099177, NP
          // BEGIN, CR00105424, SAI
          NotFoundIndicator notFoundInd = new NotFoundIndicator();
          final UsersDtls userDtls = UsersFactory.newInstance().read(
            notFoundInd, usersKey);

          final UserFullname fullName = new UserFullname();

          if (notFoundInd.isNotFound()) {

            notFoundInd = new NotFoundIndicator();

            final ExternalUserKey externalUserKey = new ExternalUserKey();

            externalUserKey.userName = usersKey.userName;

            final ExternalUserDtls externalUserDtls = ExternalUserFactory.newInstance().read(
              notFoundInd, externalUserKey);

            if (!notFoundInd.isNotFound()) {
              fullName.fullname = externalUserDtls.fullName;
              activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.EXTERNALUSER;
            }

          } else {
            fullName.fullname = userDtls.fullName;
            activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.USER;
          }

          activityAttendeeDetails.attendeeName = fullName.fullname;
          activityAttendeeDetails.activityAttendeeID = usersKey.userName;
          // END, CR00105424
          // END, CR00099177

        }
        // If the attendee is a participant
        if (activityAttendeeDtlsList.dtls.item(i).concernRoleID != 0) {

          // Read concern role details
          concernRoleKey.concernRoleID = activityAttendeeDtlsList.dtls.item(i).concernRoleID;

          concernRoleDtls = concernRoleObj.read(concernRoleKey);

          activityAttendeeDetails.attendeeName = concernRoleDtls.concernRoleName;
          activityAttendeeDetails.activityAttendeeID = String.valueOf(
            concernRoleDtls.concernRoleID);
          activityAttendeeDetails.activityAttendeeType = concernRoleDtls.concernRoleType;
        }

        // Set invitation status
        if (activityAttendeeDtlsList.dtls.item(i).acceptedInd == true) {
          activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;

        } else {
          activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.PROVISIONAL;
        }

        viewStandardUserActivityDetails.activityAttendeeList.activityAttendeeDetails.addRef(
          activityAttendeeDetails);

      }

    }

    // Set the caseID Reference to the appropriate value so that the home page
    // will not display a link if the caseID is 0
    if (viewStandardUserActivityDetails.viewStandardActivityUserDetails.caseID
      == 0) {
      // BEGIN, CR00049218, GM
      viewStandardUserActivityDetails.viewStandardActivityUserDetails.caseReference = CuramConst.gkEmpty;
      // END, CR00049218
    }

    viewStandardUserActivityDetails.viewStandardActivityUserDetails.concernRoleType = viewUserActivityResult.concernRoleType;

    viewStandardUserActivityDetails.viewStandardActivityUserDetails.concernRoleName = viewUserActivityResult.details.concernRoleName;
    viewStandardUserActivityDetails.viewStandardActivityUserDetails.concernRoleID = viewUserActivityResult.details.concernRoleID;

    // Return the details
    return viewStandardUserActivityDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details of a specified recurring activity for a specified user.
   *
   * @param key
   * Activity key and user name.
   *
   * @return The activity details returned from the database.
   */
  @Override
  public ViewRecurringUserActivityDetails viewSelectedUserRecurringActivity(
    final ViewSelectedUserActivityKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00303229, MV
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = key.activityID;
    final ActivityDtls activityDtls = ActivityFactory.newInstance().read(
      activityKey);

    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    if (0 == key.userName.length()) {
      key.userName = systemUserObj.getUserDetails().userName;
    }

    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    if (systemUserDtls.userName.equals(activityDtls.userName)
      || isUserInvited(key)) {
      // END, CR00303229

      // User activity key
      final ReadUserActivityKey readUserActivityKey = new ReadUserActivityKey();

      // Set the key
      readUserActivityKey.activityID = key.activityID;
      readUserActivityKey.userName = key.userName;
      return readRecurringUserActivity(readUserActivityKey);
      // BEGIN, CR00303229, MV
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_VIEW_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
      // Should not reach this point without throwing a validation
      return null;
    }
    // END, CR00303229
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details of a standard activity for a specified user.
   *
   * @param key
   * Activity key and user name.
   *
   * @return The activity details returned from the database.
   */
  @Override
  public ViewStandardUserActivityDetails viewSelectedUserStandardActivity(
    final ViewSelectedUserActivityKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00303229, MV
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    if (0 == key.userName.length()) {
      key.userName = systemUserObj.getUserDetails().userName;
    }
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = key.activityID;
    final ActivityDtls activityDtls = ActivityFactory.newInstance().read(
      activityKey);

    // Return the details

    // BEGIN, CR00303229, MV
    if (systemUserDtls.userName.equals(activityDtls.userName)
      || isUserInvited(key)) {

      // END, CR00303229

      // User activity key
      final ReadUserActivityKey readUserActivityKey = new ReadUserActivityKey();

      readUserActivityKey.activityID = key.activityID;
      readUserActivityKey.userName = key.userName;

      // Return the details
      return readStandardUserActivity(readUserActivityKey);
      // BEGIN, CR00303229, MV
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_VIEW_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
      // Should not reach this point without throwing a validation
      return null;
    }
    // END, CR00303229
  }

  // ___________________________________________________________________________
  /**
   * Cancels an invitation to an activity for a specified attendee.
   *
   * @param details
   * Activity ID, attendee ID and attendee type.
   */
  @Override
  public void cancelInvitation(final ActivityInvitationDetails details)
    throws AppException, InformationalException {

    // MaintainUserActivity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    // Attendee status object
    final ActivityAttendeeStatusDetails activityAttendeeStatusDetails = new ActivityAttendeeStatusDetails();

    // Set canceled record status
    activityAttendeeStatusDetails.recordStatusCode = curam.codetable.RECORDSTATUS.CANCELLED;

    // BEGIN, CR00227859, PM
    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    ActivityDtls activityDtls = new ActivityDtls();
    final ActivityKey activityKey = new ActivityKey();
    // BEGIN, CR00273787, PB
    ActivityAttendeeDtls activityAttendeeDtls = new ActivityAttendeeDtls();
    final ReadByActivityAttendeeKey readByActivityAttendeeKey = new ReadByActivityAttendeeKey();
    final ActivityAttendee activityAttendeeObj = ActivityAttendeeFactory.newInstance();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();

    // END, CR00273787
    activityKey.activityID = details.activityID;
    activityDtls = activityObj.read(activityKey);

    if (!systemUserDtls.userName.equals(activityDtls.userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_MAINTAIN_RIGHTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 7);
    }
    // END, CR00227859

    // Set activity and attendee
    activityAttendeeStatusDetails.activityAttendeeID = details.activityAttendeeID;
    activityAttendeeStatusDetails.activityAttendeeType = details.activityAttendeeType;
    activityAttendeeStatusDetails.activityID = details.activityID;
    // BEGIN, CR00273787, PB
    readByActivityAttendeeKey.activityID = details.activityID;
    readByActivityAttendeeKey.recordStatusCode = RECORDSTATUS.NORMAL;
    readByActivityAttendeeKey.userName = details.activityAttendeeID;
    activityAttendeeDtls = activityAttendeeObj.readByActivityAttendee(
      nfIndicator, readByActivityAttendeeKey);
    // BEGIN, CR00312526, IBM
    // BEGIN, CR00314368, MV
    final ActivityAttendeeNotificationDetails activityAttendeeNotificationDetails = new ActivityAttendeeNotificationDetails();

    maintainUserActivityObj.modifyActivityAttendeeStatus(
      activityAttendeeStatusDetails);
    if (!nfIndicator.isNotFound()
      && EnvVars.ENV_VALUE_YES.equalsIgnoreCase(
        readSendNotificationAlertsProperty())) {
      // END, CR00312526

      final Event event = new Event();

      event.eventKey = ACTIVITY.ATTENDEE_REMOVED;
      event.primaryEventData = activityAttendeeDtls.attendeeID;
      event.secondaryEventData = activityAttendeeDtls.activityID;
      EventService.raiseEvent(event);
    } // BEGIN, CR00314368, MV
    else {

      activityKey.activityID = details.activityID;

      activityDtls = activityObj.read(activityKey);

      final BusinessObjectAssociationTasksKey businessObjectAssociationTasksKey = new BusinessObjectAssociationTasksKey();

      if (activityDtls.recurrenceID != 0) {
        businessObjectAssociationTasksKey.bizObjectID = activityDtls.recurrenceID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITYRECURRENCE;
      } else {
        businessObjectAssociationTasksKey.bizObjectID = details.activityID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITY;
      }
      businessObjectAssociationTasksKey.taskReservationStatus = TASKSTATUS.NOTSTARTED;

      final BusinessObjectAssociationTasksDetailsList businessObjectAssociationTasksDetailsList = BusinessObjectAssociationWorkspace.getBusinessObjectAssociationTasks(
        businessObjectAssociationTasksKey);
      final UsersKey usersKey = new UsersKey();

      if (!businessObjectAssociationTasksDetailsList.dtls.isEmpty()) {
        for (final BusinessObjectAssociationTasksDetails businessObjectAssociationTasksDetails : businessObjectAssociationTasksDetailsList.dtls.items()) {
          final curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();
          final curam.core.sl.struct.TaskManagementTaskKey taskKey = new curam.core.sl.struct.TaskManagementTaskKey();

          taskKey.taskID = businessObjectAssociationTasksDetails.taskID;
          final TaskAssigneeDetailsList taskAssigneeDetailsList = taskManagementObj.viewAssignmentsForTask(
            taskKey);

          for (final TaskAssigneeDetails taskAssigneeDetails : taskAssigneeDetailsList.dtls.items()) {

            usersKey.userName = readByActivityAttendeeKey.userName;

            final UserAccess userAccessObj = UserAccessFactory.newInstance();
            final UserDetails userDetails = userAccessObj.getUserDetails(
              usersKey);

            if (activityDtls.recurrenceID != 0) {

              final AttendeeRecurrenceKey attendeeRecurrenceKey = new AttendeeRecurrenceKey();

              attendeeRecurrenceKey.recurrenceID = activityDtls.recurrenceID;
              final ActivityAttendeeDtlsList activityAttendeeDtlsList = activityAttendeeObj.searchByRecurrence(
                attendeeRecurrenceKey);

              for (final ActivityAttendeeDtls activityAttendeeDtls1 : activityAttendeeDtlsList.dtls.items()) {

                if (activityAttendeeDtls1.userName.equals(
                  details.activityAttendeeID)) {
                  activityAttendeeNotificationDetails.removeFromAllOccurrencesInd = false;
                  if (RECORDSTATUS.DEFAULTCODE.equals(
                    activityAttendeeDtls1.recordStatusCode)) {
                    break;
                  } else {
                    activityAttendeeNotificationDetails.removeFromAllOccurrencesInd = true;
                  }
                }
              }

              if (userDetails.fullName.equalsIgnoreCase(
                taskAssigneeDetails.assignedTo)
                  && activityAttendeeNotificationDetails.removeFromAllOccurrencesInd) {

                final Event event = new Event();

                event.eventKey = TASK.CLOSED;
                event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
                EventService.raiseEvent(event);
              }
            } else {
              if (userDetails.fullName.equalsIgnoreCase(
                taskAssigneeDetails.assignedTo)) {

                final Event event = new Event();

                event.eventKey = TASK.CLOSED;
                event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
                EventService.raiseEvent(event);
              }
            }
          }
        }
      }
    }
    // END, CR00314368
    // END, CR00273787
    // Cancel the invitation
  }

  // ___________________________________________________________________________
  /**
   * Reads the description of the User.
   *
   * @param key
   * Identifier for user whose description is to be returned
   *
   * @return Context description for a user
   */
  @Override
  protected UserContextDescriptionDetails readUserContextDescription(
    final OrganizationUserContextDescriptionKey key) throws AppException,
      InformationalException {

    // User maintenance business process object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Details to be returned
    final UserContextDescriptionDetails userContextDescriptionDetails = new UserContextDescriptionDetails();

    // Read the user details
    final UsersKey usersKey = new UsersKey();
    UserFullname userFullName;

    usersKey.userName = key.userName;
    userFullName = userAccessObj.getFullName(usersKey);

    // Prepare the context description details
    userContextDescriptionDetails.description = userFullName.fullname;

    return userContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Read a list of an activities attendees including the the activity owner.
   *
   * @param key
   * Contains the activityID.
   *
   * @return list of activity attendees.
   */
  @Override
  public ActivityAttendeeList readActivityAttendeeList(
    final MaintainAttendeeActivityKey key) throws AppException,
      InformationalException {

    // return details
    final ActivityAttendeeList activityAttendeeList = new ActivityAttendeeList();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final UsersKey usersKey = new UsersKey();

    ActivityAttendeeDetails activityAttendeeDetails;
    ActivityAttendeeDtlsList activityAttendeeDtlsList;
    ConcernRoleDtls concernRoleDtls;

    // ConcernRole objects
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Attendee details objects
    final curam.core.intf.ActivityAttendee activityAttendeeObj = curam.core.fact.ActivityAttendeeFactory.newInstance();

    // Get list of attendees
    activityAttendeeDtlsList = activityAttendeeObj.searchByActivity(key);

    // Get the owner details for current activity.
    // maintainUserActivity entity object
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();

    final UserActivityOwnerDetailsKey userActivityOwnerDetailsKey = new UserActivityOwnerDetailsKey();
    UserActivityOwnerDetails userActivityOwnerDetails;

    userActivityOwnerDetailsKey.activityID = key.activityID;

    // read the activity owners details and add to the attendee list
    userActivityOwnerDetails = maintainUserActivityObj.readActivityOwnerDetails(
      userActivityOwnerDetailsKey);

    activityAttendeeDetails = new ActivityAttendeeDetails();

    // add the user to the attendee list
    activityAttendeeDetails.attendeeName = userActivityOwnerDetails.fullname;
    activityAttendeeDetails.activityAttendeeID = userActivityOwnerDetails.username;
    activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.USER;
    activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;
    activityAttendeeList.activityAttendeeDetails.addRef(activityAttendeeDetails);

    // Add attendee names to output list
    for (int i = 0; i < activityAttendeeDtlsList.dtls.size(); i++) {

      activityAttendeeDetails = new ActivityAttendeeDetails();

      // If the attendee is active
      if (!activityAttendeeDtlsList.dtls.item(i).recordStatusCode.equals(
        curam.codetable.RECORDSTATUS.CANCELLED)) {

        // If the attendee is a user
        if (activityAttendeeDtlsList.dtls.item(i).userName.length() > 0) {

          // Read user details
          usersKey.userName = activityAttendeeDtlsList.dtls.item(i).userName;
          // BEGIN, CR00099177, NP
          // BEGIN, CR00105424, SAI
          NotFoundIndicator notFoundInd = new NotFoundIndicator();
          final UsersDtls userDtls = UsersFactory.newInstance().read(
            notFoundInd, usersKey);

          final UserFullname fullName = new UserFullname();

          if (notFoundInd.isNotFound()) {

            notFoundInd = new NotFoundIndicator();

            final ExternalUserKey externalUserKey = new ExternalUserKey();

            externalUserKey.userName = usersKey.userName;

            final ExternalUserDtls externalUserDtls = ExternalUserFactory.newInstance().read(
              notFoundInd, externalUserKey);

            if (!notFoundInd.isNotFound()) {
              fullName.fullname = externalUserDtls.fullName;
              activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.EXTERNALUSER;
            }

          } else {
            fullName.fullname = userDtls.fullName;
            activityAttendeeDetails.activityAttendeeType = curam.codetable.ACTIVITYATTENDEETYPE.USER;
          }

          activityAttendeeDetails.attendeeName = fullName.fullname;
          activityAttendeeDetails.activityAttendeeID = usersKey.userName;
          // END, CR00099177
          // END, CR00105424
        }

        // If the attendee is a participant
        if (activityAttendeeDtlsList.dtls.item(i).concernRoleID != 0) {

          // Read concern role details
          concernRoleKey.concernRoleID = activityAttendeeDtlsList.dtls.item(i).concernRoleID;

          concernRoleDtls = concernRoleObj.read(concernRoleKey);

          activityAttendeeDetails.attendeeName = concernRoleDtls.concernRoleName;
          activityAttendeeDetails.activityAttendeeID = String.valueOf(
            concernRoleDtls.concernRoleID);
          activityAttendeeDetails.activityAttendeeType = concernRoleDtls.concernRoleType;
        }

        // Set invitation status
        if (activityAttendeeDtlsList.dtls.item(i).acceptedInd == true) {
          activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.ACCEPTED;

        } else {
          activityAttendeeDetails.invitationStatus = curam.codetable.ACCEPTANCESTATUS.PROVISIONAL;
        }

        activityAttendeeList.activityAttendeeDetails.addRef(
          activityAttendeeDetails);

      }

    }

    return activityAttendeeList;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves read-only details of a standard activity for the owner of the
   * activity
   *
   * @param key
   * Activity key and user name.
   *
   * @return The activity details returned from the database.
   */
  @Override
  public ViewStandardUserActivityDetails viewReadOnlyActivityDetails(
    final ViewReadOnlyStandardActivityKey key) throws AppException,
      InformationalException {

    final ActivityOwnerDetailsKey activityOwnerDetailsKey = new ActivityOwnerDetailsKey();

    ActivityOwnerDetails activityOwnerDetails;

    activityOwnerDetailsKey.activityID = key.activityID;

    // read the owner of the activity
    // BEGIN, CR00074010, VM
    activityOwnerDetails = UserAccessFactory.newInstance().readActivityOwnerDetails(
      activityOwnerDetailsKey);

    // User activity key
    final ReadUserActivityKey readUserActivityKey = new ReadUserActivityKey();

    if (activityOwnerDetails != null) {
      readUserActivityKey.userName = activityOwnerDetails.username;
    }
    // END, CR00074010

    // Set the key
    readUserActivityKey.activityID = key.activityID;

    return readStandardUserActivity(readUserActivityKey);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves read-only details of a recurring activity for owner of the
   * activity
   *
   * @param key
   * Activity key and owner name.
   *
   * @return The activity details returned from the database.
   */
  @Override
  public ViewRecurringUserActivityDetails viewReadOnlyRecurringActivityDetails(
    final ViewReadOnlyRecurringActivityKey key) throws AppException,
      InformationalException {

    final ActivityOwnerDetailsKey activityOwnerDetailsKey = new ActivityOwnerDetailsKey();

    ActivityOwnerDetails activityOwnerDetails;

    activityOwnerDetailsKey.activityID = key.activityID;

    // read the owner of the activity
    // BEGIN, CR00074010, VM
    activityOwnerDetails = UserAccessFactory.newInstance().readActivityOwnerDetails(
      activityOwnerDetailsKey);

    // User activity key
    final ReadUserActivityKey readUserActivityKey = new ReadUserActivityKey();

    if (activityOwnerDetails != null) {
      readUserActivityKey.userName = activityOwnerDetails.username;
    }
    // END, CR00074010

    // Set the key
    readUserActivityKey.activityID = key.activityID;

    // Return the details
    return readRecurringUserActivity(readUserActivityKey);

  }

  // BEGIN, CR00168663, LD
  // ________________________________________________________________________________
  /**
   * Gets Organization ID
   *
   * @return Organization ID
   */
  protected long getOrganizationID() throws AppException,
      InformationalException {

    // Object to read organization details
    final curam.core.intf.Organisation organizationObj = curam.core.fact.OrganisationFactory.newInstance();
    // Read organization details
    final curam.core.struct.OrganisationDtls organizationDtlsObj = organizationObj.readOne();

    return organizationDtlsObj.organisationID;
  }

  // END, CR00168663

  // BEGIN, CR00243551, ELG
  // ________________________________________________________________________________
  /**
   * Retrieves a list of the activities for current user.
   *
   * @return Structure containing a list of activities for current user.
   */
  @Override
  public ActivityListViewDetails listActivityForCurrentUser()
    throws AppException, InformationalException {

    // Return structure
    final ActivityListViewDetails activityListViewDetails = new ActivityListViewDetails();

    // Get instance of SystemUser and SystemUserDetails..
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Get the current user
    systemUserDtls = systemUserObj.getUserDetails();

    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final UserActivityKey userActivityKey = new UserActivityKey();

    userActivityKey.userName = systemUserDtls.userName;

    activityListViewDetails.activityList = maintainUserActivityObj.listUserActivity(
      userActivityKey);

    return activityListViewDetails;

  }

  // END, CR00243551

  // ___________________________________________________________________________
  /**
   * List all of the activities for the current user including the activities
   * where the user is an invited attendee.
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public UserActivityDetailsList listActivityAndAttendanceForCurrentUser()
    throws AppException, InformationalException {

    final UserActivityDetailsList userActivityDetailsList = new UserActivityDetailsList();
    final UserActivityKey userActivityKey = new UserActivityKey();

    userActivityKey.userName = SystemUserFactory.newInstance().getUserDetails().userName;

    final ActivityListDetailsList activityListDetailsList = MaintainUserActivityFactory.newInstance().listUserActivity(
      userActivityKey);

    ActivityListDetails activityListDetails;
    UserActivityDetails userActivityDetails;
    ActivityDtls activityDtls = new ActivityDtls();

    // Assign the values from this list to the return struct
    for (int i = 0; i < activityListDetailsList.dtls.size(); i++) {
      // BEGIN, CR00406384, AC
      activityListDetails = new ActivityListDetails();
      userActivityDetails = new UserActivityDetails();
      // END, CR00406384
      // Set the attendance specific indicators
      userActivityDetails.userIndicatorDetails.invitedAttendeeInd = false;
      userActivityDetails.userIndicatorDetails.acceptInviteInd = false;
      userActivityDetails.userIndicatorDetails.rejectInviteInd = false;

      userActivityDetails.assign(activityListDetailsList.dtls.item(i));
      userActivityDetailsList.dtls.addRef(userActivityDetails);
    }

    // Now add the activities where the current user is an attendee on an
    // activity
    final ActivityAttendeeUserName activityAttendeeUserName = new ActivityAttendeeUserName();

    activityAttendeeUserName.userName = SystemUserFactory.newInstance().getUserDetails().userName;

    final ActivityAttendeeByUserDtlsList activityAttendeeByUserDtlsList = ActivityAttendeeFactory.newInstance().searchByUserName(
      activityAttendeeUserName);

    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    for (int i = 0; i < activityAttendeeByUserDtlsList.dtls.size(); i++) {
      final ActivityAttendeeByUserDtls activityAttendeeByUserDtls = activityAttendeeByUserDtlsList.dtls.item(
        i);

      if (!activityAttendeeByUserDtls.recordStatusCode.equals(
        RECORDSTATUS.CANCELLED)) {

        activityListDetails = new ActivityListDetails();
        final ActivityKey activityKey = new ActivityKey();

        userActivityDetails = new UserActivityDetails();

        activityKey.activityID = activityAttendeeByUserDtls.activityID;
        activityDtls = ActivityFactory.newInstance().read(activityKey);

        activityListDetails.activityID = activityDtls.activityID;
        activityListDetails.activityTypeCode = activityDtls.activityTypeCode;
        activityListDetails.caseID = activityDtls.caseID;
        activityListDetails.endDate = new Date(activityDtls.endDateTime);
        activityListDetails.startDate = new Date(activityDtls.startDateTime);
        activityListDetails.subject = activityDtls.subject;

        // Set the attendance specific indicators
        userActivityDetails.userIndicatorDetails.invitedAttendeeInd = true;
        if (activityAttendeeByUserDtls.acceptedInd) {
          // invite is already accepted but can still be rejected
          userActivityDetails.userIndicatorDetails.acceptInviteInd = false;
          userActivityDetails.userIndicatorDetails.rejectInviteInd = true;
        } else {
          // Invite is neither accepted or rejected or has been rejected but
          // could be accepted at a later date
          userActivityDetails.userIndicatorDetails.acceptInviteInd = true;
          userActivityDetails.userIndicatorDetails.rejectInviteInd = true;
        }

        // Set the other display indicators
        maintainActivityDetails.assign(activityDtls);
        MaintainUserActivityFactory.newInstance().setActivityDisplayIndicators(
          activityListDetails, maintainActivityDetails);

        userActivityDetails.assign(activityListDetails);
        userActivityDetailsList.dtls.addRef(userActivityDetails);
      }
    }

    // BEGIN, CR00314805, MV
    // Users details, key and entity object
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = SystemUserFactory.newInstance().getUserDetails().userName;
    final String userType = UserAccessFactory.newInstance().getUserType(
      usersKey);

    // BEGIN, CR00370544, AC
    if (USERTYPE.INTERNAL.equals(userType)) {
      final UsersDtls usersDtls = UsersFactory.newInstance().read(usersKey);

      final ListLocationHolidayKey listLocationHolidayKey = new ListLocationHolidayKey();

      listLocationHolidayKey.searchHolidayByLocationKey.locationID = usersDtls.locationID;
      listLocationHolidayKey.searchHolidayByLocationKey.statusCode = RECORDSTATUSEntry.NORMAL.getCode();
      // BEGIN, CR00342927, SS
      listLocationHolidayKey.userNameOpt = usersDtls.userName;
      // END, CR00342927
      final ListLocationHolidayDetails listLocationHolidayDetails = OrganizationFactory.newInstance().listLocationHoliday(
        listLocationHolidayKey);

      for (final LocationHolidaySearchDetails locationHolidaySearchDetails : listLocationHolidayDetails.locationHolidaySearchDetailsList.dtls) {
        userActivityDetails = new UserActivityDetails();
        userActivityDetails.activityID = locationHolidaySearchDetails.locationHolidayID;
        userActivityDetails.subject = locationHolidaySearchDetails.holidayName;
        userActivityDetails.activityTypeCode = ACTIVITYTYPEEntry.HOLIDAY.getCode();
        userActivityDetails.startDate = locationHolidaySearchDetails.holidayDate;
        userActivityDetails.endDate = locationHolidaySearchDetails.holidayDate;
        userActivityDetailsList.dtls.addRef(userActivityDetails);
      }
    }
    // END, CR00314805
    // END, CR00370544
    return userActivityDetailsList;
  }

  // BEGIN, CR00270108, MC
  // __________________________________________________________________________
  /**
   * Used to identify if the current user is the activity owner. This can be
   * used to display the appropriate actions in the list row menus for the
   * events lists.
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public IsCurrentUserActivityOwner isCurrentUserActivityOwner(
    final ActivityOwnerDetailsKey activityKey) throws AppException,
      InformationalException {

    final IsCurrentUserActivityOwner result = new IsCurrentUserActivityOwner();
    // Get the owner details for current activity.
    // read the activity owner details
    final ActivityOwnerDetails activityOwnerDetails = UserAccessFactory.newInstance().readActivityOwnerDetails(
      activityKey);

    // Test if they are the owner of the current activity
    // Get the username of the current user.
    final String userName = TransactionInfo.getProgramUser();

    if (activityOwnerDetails.username.equals(userName)) {
      result.currentUserIsActivityOwnerInd = true;
    } else {
      result.currentUserIsActivityOwnerInd = false;
    }
    return result;
  }

  // END, CR00270108

  // BEGIN, CR00273787, PB
  /**
   * Returns Activity details and Invitees list
   *
   * @param Key
   * Contains Activity ID.
   *
   * @return Activity details and Invitees list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ViewRecurringUserActivityDetails readActivityDetailsAndInviteesList(
    final ActivityIdKey key) throws AppException, InformationalException {

    final ViewRecurringUserActivityDetails viewRecurringUserActivityDetails = new ViewRecurringUserActivityDetails();

    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = MaintainUserActivityFactory.newInstance();

    ActivityAttendeeDetails activityAttendeeDetails;

    final UserActivityKey userActivityKey = new UserActivityKey();

    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final UserAccess UserAccessObj = UserAccessFactory.newInstance();

    final ActivityAttendee activityAttendeeObj = ActivityAttendeeFactory.newInstance();

    ActivityAttendeeDtlsList activityAttendeeDtlsList = null;
    final MaintainAttendeeActivityKey maintainAttendeeActivityKey = new MaintainAttendeeActivityKey();

    final UsersKey usersKey = new UsersKey();

    // BEGIN, CR00282025, PB
    userActivityKey.userName = TransactionInfo.getProgramUser();
    // END, CR00282025
    maintainActivityKey.activityID = key.activityID;

    final ViewUserActivityResult viewUserActivityResult = maintainUserActivityObj.viewUserActivity(
      maintainActivityKey, userActivityKey);

    if (!StringUtil.isNullOrEmpty(
      viewUserActivityResult.details.frequencyPattern)) {

      final FrequencyPattern frequencyPattern = new FrequencyPattern(
        viewUserActivityResult.details.frequencyPattern);

      viewUserActivityResult.details.frequencyPattern = frequencyPattern.toHumanReadableString();
    }

    final MaintainActivityDetails maintainActivityDetails = viewUserActivityResult.details;

    usersKey.userName = userActivityKey.userName;
    maintainActivityDetails.userName = UserAccessObj.getFullName(usersKey).fullname;

    viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.assign(
      maintainActivityDetails);

    viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.attendeeNameDetails = viewUserActivityResult.attendeeDetails.attendeeNameDetails;

    final ActivityContextDescriptionKey activityContextDescriptionKey = new ActivityContextDescriptionKey();

    activityContextDescriptionKey.assign(maintainActivityDetails);

    viewRecurringUserActivityDetails.activityContextDescriptionDetails = readActivityContextDescription(
      activityContextDescriptionKey);

    maintainAttendeeActivityKey.activityID = viewUserActivityResult.details.activityID;

    activityAttendeeDtlsList = activityAttendeeObj.searchByActivity(
      maintainAttendeeActivityKey);

    final UserActivityOwnerDetailsKey userActivityOwnerDetailsKey = new UserActivityOwnerDetailsKey();

    userActivityOwnerDetailsKey.activityID = key.activityID;

    for (final ActivityAttendeeDtls activityAttendeeDtls : activityAttendeeDtlsList.dtls.items()) {

      activityAttendeeDetails = new ActivityAttendeeDetails();

      if (!RECORDSTATUS.CANCELLED.equals(activityAttendeeDtls.recordStatusCode)) {
        if (activityAttendeeDtls.userName.length() > 0) {

          usersKey.userName = activityAttendeeDtls.userName;
          final UserFullname fullName = UserAccessObj.getFullName(usersKey);

          activityAttendeeDetails.attendeeName = fullName.fullname;
          activityAttendeeDetails.activityAttendeeID = usersKey.userName;

          if (CuramConst.gkInternalUser.equals(
            UserAccessObj.getUserType(usersKey))) {
            activityAttendeeDetails.activityAttendeeType = ACTIVITYATTENDEETYPE.USER;
          } else {
            activityAttendeeDetails.activityAttendeeType = ACTIVITYATTENDEETYPE.EXTERNALUSER;
          }
        }

        if (activityAttendeeDtls.acceptedInd) {
          activityAttendeeDetails.invitationStatus = ACCEPTANCESTATUS.ACCEPTED;
        } else {
          activityAttendeeDetails.invitationStatus = ACCEPTANCESTATUS.PROVISIONAL;
        }

        viewRecurringUserActivityDetails.activityAttendeeList.activityAttendeeDetails.addRef(
          activityAttendeeDetails);
      }
    }
    if (0
      == viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseID) {
      viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.caseReference = CuramConst.gkEmpty;
    }

    if (0 != maintainActivityDetails.numberOfOccurrences) {

      viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.occurrencesStr = String.valueOf(
        maintainActivityDetails.numberOfOccurrences);
    } else {

      viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.occurrencesStr = CuramConst.gkEmpty;
    }
    // BEGIN, CR00279834, PB
    if (0
      != viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.recurrenceID) {
      final ActivityRecurrence activityRecurrenceObj = ActivityRecurrenceFactory.newInstance();

      final ActivityRecurrenceKey activityRecurrenceKey = new ActivityRecurrenceKey();
      final NotFoundIndicator nfIndicator = new NotFoundIndicator();

      activityRecurrenceKey.recurrenceID = viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.recurrenceID;
      final ActivityRecurrenceDtls activityRecurrenceDtls = activityRecurrenceObj.read(
        nfIndicator, activityRecurrenceKey);

      if (!nfIndicator.isNotFound()) {
        if (RECORDSTATUS.CANCELLED.equals(
          activityRecurrenceDtls.recordStatusCode)) {
          viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd = true;
        }
      }
      final curam.core.intf.Activity activityObj = ActivityFactory.newInstance();

      final ReadRecurringActivitiesKey readRecurringActivitiesKey = new ReadRecurringActivitiesKey();

      readRecurringActivitiesKey.recurrenceID = viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.recurrenceID;

      final RecurringActivitiesList recurringActivitiesList = activityObj.searchRecurringActivities(
        readRecurringActivitiesKey);
      final curam.core.struct.ActivityDetailsKey activityDetailsKey = new ActivityDetailsKey();

      if (!recurringActivitiesList.dtls.isEmpty()) {
        for (final RecurringActivities recurringActivities : recurringActivitiesList.dtls.items()) {

          activityDetailsKey.activityID = recurringActivities.activityID;

          final ActivityDetails activityDetails = activityObj.readActivityDetails(
            activityDetailsKey);

          viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd = false;
          if (RECORDSTATUS.DEFAULTCODE.equals(activityDetails.recordStatusCode)) {
            break;
          } else {
            viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd = true;
          }
        }
      }

      final BusinessObjectAssociationTasksKey businessObjectAssociationTasksKey = new BusinessObjectAssociationTasksKey();

      // BEGIN, CR00314368, MV
      if (0
        != viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.recurrenceID) {
        // END, CR00314368
        businessObjectAssociationTasksKey.bizObjectID = viewRecurringUserActivityDetails.maintainRecurringUserActivityDetails.recurrenceID;
        businessObjectAssociationTasksKey.bizObjectType = BUSINESSOBJECTTYPE.ACTIVITYRECURRENCE;
        businessObjectAssociationTasksKey.taskReservationStatus = TASKSTATUS.NOTSTARTED;

        final BusinessObjectAssociationTasksDetailsList businessObjectAssociationTasksDetailsList = BusinessObjectAssociationWorkspace.getBusinessObjectAssociationTasks(
          businessObjectAssociationTasksKey);

        if (!businessObjectAssociationTasksDetailsList.dtls.isEmpty()) {
          for (final BusinessObjectAssociationTasksDetails businessObjectAssociationTasksDetails : businessObjectAssociationTasksDetailsList.dtls.items()) {
            viewRecurringUserActivityDetails.recActivityTaskDetails.taskID = businessObjectAssociationTasksDetails.taskID;
            if (viewRecurringUserActivityDetails.recActivityTaskDetails.cancelAllOcurrenceInd
              || viewRecurringUserActivityDetails.recActivityTaskDetails.cancelLastOcurrenceInd) {
              final Event event = new Event();

              event.eventKey = TASK.CLOSED;
              event.primaryEventData = businessObjectAssociationTasksDetails.taskID;
              EventService.raiseEvent(event);
            }
          }
        }
      }
    }
    // END, CR00279834
    return viewRecurringUserActivityDetails;
  }

  // END, CR00273787

  // BEGIN, CR00357198, AC
  /**
   * Checks the users activity conflicts with other activity.
   *
   * @param Activity key
   * @return Informational message text.
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public InformationMsgDtlsList checkForUserConflicts(
    ActivityIdKey activityIdKey) throws AppException, InformationalException {

    final UserActivityDetails userActivityDetails = new UserActivityDetails();
    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = activityIdKey.activityID;
    final ActivityDtls activityDtls = ActivityFactory.newInstance().read(
      activityKey);
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final ActivityConflictDetails activityConflictDetails = new ActivityConflictDetails();
    final UserActivityKey userActivityKey = new UserActivityKey();

    userActivityKey.userName = SystemUserFactory.newInstance().getUserDetails().userName;
    maintainActivityKey.activityID = activityKey.activityID;
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final AppException e;
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    maintainActivityDetails.startDateTime = activityDtls.startDateTime;
    maintainActivityDetails.endDateTime = activityDtls.endDateTime;
    maintainActivityDetails.userName = SystemUserFactory.newInstance().getUserDetails().userName;
    final ActivityNameDetails activityNameDetails = new ActivityNameDetails();

    activityNameDetails.nameInd = true;
    final CheckForConflictResult checkForConflictResult = UserActivityConflictFactory.newInstance().checkForConflict(
      maintainActivityDetails);
    final ActivityConflictDetails activityConflictDetailsParse = UserActivityConflictFactory.newInstance().parseConflictList(
      checkForConflictResult.activityConflictList, activityNameDetails);

    activityConflictDetails.conflictString += activityConflictDetailsParse.conflictString;
    activityConflictDetails.conflictInd = true;
    if (checkForConflictResult.activityConflictDetails.conflictInd) {
      e = new AppException(
        BPOMAINTAINACTIVITY.ERR_ACTIVITY_XRV_INVITEUSERATTENDEE_ACCEPTANCE);

      e.arg(activityConflictDetails.conflictString);
      informationalManager.addInformationalMsg(e, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);
    } else {
      activityConflictDetails.conflictString = CuramConst.gkEmpty;
      activityConflictDetails.conflictInd = false;
      e = new AppException(
        BPOMAINTAINACTIVITYExceptionCreator.ERR_ACTIVITY_XRV_INVITEATTENDEE().getCatEntry());
      e.arg(activityConflictDetails.conflictString);
      informationalManager.addInformationalMsg(e, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);
    }
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00357198
  // BEGIN, CR00303229, MV
  /**
   * Used to identify if the current user is invited for the occurring activity.
   *
   * @param viewSelectedUserActivityKey
   * Activity ID and owner name
   *
   * @return true if the current user is invited for the occurring activity else
   * false.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected boolean isUserInvited(
    final ViewSelectedUserActivityKey viewSelectedUserActivityKey)
    throws AppException, InformationalException {

    boolean isUserInvited = false;
    final MaintainAttendeeActivityKey maintainAttendeeActivityKey = new MaintainAttendeeActivityKey();
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final UserActivityKey userActivityKey = new UserActivityKey();

    maintainActivityKey.activityID = viewSelectedUserActivityKey.activityID;
    userActivityKey.userName = viewSelectedUserActivityKey.userName;
    final ViewUserActivityResult viewUserActivityResult = MaintainUserActivityFactory.newInstance().viewUserActivity(
      maintainActivityKey, userActivityKey);

    maintainAttendeeActivityKey.activityID = viewUserActivityResult.details.activityID;
    final ActivityAttendeeDtlsList activityAttendeeDtlsList = ActivityAttendeeFactory.newInstance().searchByActivity(
      maintainAttendeeActivityKey);

    for (final ActivityAttendeeDtls activityAttendeeDtls : activityAttendeeDtlsList.dtls) {
      if (activityAttendeeDtls.activityID
        == viewSelectedUserActivityKey.activityID
          && activityAttendeeDtls.userName.equals(
            viewSelectedUserActivityKey.userName)) {
        isUserInvited = true;
        break;
      }
    }
    return isUserInvited;
  }

  // END, CR00303229

  // BEGIN, CR00312526, IBM
  /**
   * Reads the send notification alerts property value.
   *
   * @return the send notification alerts property value.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String readSendNotificationAlertsProperty() throws AppException,
      InformationalException {

    return MaintainUserActivity.getProperty(EnvVars.ENV_SENDNOTIFICATIONALERTS,
      EnvVars.ENV_SENDNOTIFICATIONALERTS_DEFAULT);
  }

  // END, CR00312526

  // BEGIN, CR00351811, SG
  /**
   * Updates an activity record which is an event scheduled for a date and
   * time, pertaining to a specific subject and location.
   *
   * @param activityIdKey Contains Activity ID.
   * @param activityDetails Details of the activity to be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void modifyActivity(final ActivityIdKey activityIdKey,
    final curam.core.facade.struct.ActivityDetails activityDetails)
    throws AppException, InformationalException {

    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = activityIdKey.activityID;

    final ActivityDtls activityDtls = new ActivityDtls();

    activityDtls.activityID = activityDetails.activityID;
    activityDtls.activityTypeCode = activityDetails.activityTypeCode;
    activityDtls.allDayInd = activityDetails.allDayInd;
    activityDtls.caseID = activityDetails.caseID;
    activityDtls.concernRoleID = activityDetails.concernRoleID;
    activityDtls.endDateTime = activityDetails.endDateTime;
    activityDtls.locationID = activityDetails.locationID;
    activityDtls.locationName = activityDetails.locationName;
    activityDtls.notes = activityDetails.notes;
    activityDtls.organisationID = activityDetails.organisationID;
    activityDtls.priorityCode = activityDetails.priorityCode;
    activityDtls.recordStatusCode = activityDetails.recordStatusCode;
    activityDtls.recurrenceID = activityDetails.recurrenceID;
    activityDtls.slotAllocationID = activityDetails.slotAllocationID;
    activityDtls.startDateTime = activityDetails.startDateTime;
    activityDtls.subject = activityDetails.subject;
    activityDtls.timeStatusCode = activityDetails.timeStatusCode;
    activityDtls.userName = activityDetails.userName;
    activityDtls.versionNo = activityDetails.versionNo;

    ActivityFactory.newInstance().modifyActivity(activityKey, activityDtls);

  }

  /**
   * Removes an activity record which is an event scheduled for a date and
   * time, pertaining to a specific subject and location.
   *
   * @param activityIdKey Contains Activity ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void removeActivity(final ActivityIdKey activityIdKey)
    throws AppException, InformationalException {

    final ActivityKey activityKey = new ActivityKey();

    activityKey.activityID = activityIdKey.activityID;

    ActivityFactory.newInstance().remove(activityKey);

  }
  // END, CR00351811
}
