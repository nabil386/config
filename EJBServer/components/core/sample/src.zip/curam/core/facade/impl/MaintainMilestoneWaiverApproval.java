/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.MWAPPROVALSTATUS;
import curam.core.facade.struct.MWAppCheckOrgUnitListDetails;
import curam.core.facade.struct.MWAppCheckUserListDetails;
import curam.core.facade.struct.MilestoneWaiverAppOrgUnitID;
import curam.core.facade.struct.MilestoneWaiverAppUserName;
import curam.core.facade.struct.MilestoneWaiverApprovalCheckDetails;
import curam.core.facade.struct.MilestoneWaiverApprovalCheckKey;
import curam.core.facade.struct.MilestoneWaiverApprovalChecks;
import curam.core.facade.struct.OrganisationUnitContextDescriptionDetails;
import curam.core.facade.struct.OrganisationUnitKey;
import curam.core.facade.struct.OrganizationUserContextDescriptionKey;
import curam.core.facade.struct.UserContextDescriptionDetails;
import curam.core.sl.entity.struct.MilestoneConfigurationID;
import curam.core.sl.entity.struct.MilestoneWaiverApprovalCheckDtls;
import curam.core.sl.entity.struct.MilestoneWaiverApprovalCheckDtlsList;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.fact.MilestoneWaiverApprovalFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.MilestoneWaiverApproval;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.MilestoneApprovalCheckPercentageDescDtls;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This facade layer class manages all operations related to the maintenance of
 * Milestone
 * Waiver Approval Check.
 *
 */

public abstract class MaintainMilestoneWaiverApproval extends curam.core.facade.base.MaintainMilestoneWaiverApproval {

  /**
   * Creates organizational unit milestone waiver approval check
   *
   * @param details of the milestone waiver approval check record which
   * is to be created
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void createOrgUnitMWApproval(
    MilestoneWaiverApprovalCheckDetails details) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.createApproval(details.dtls);

  }

  /**
   * Returns a list of milestone waiver approval check records based on the
   * organizational
   * unit id.
   *
   * @param key containing the id of the organization unit, based on which
   * the milestone waiver approval check records are retrieved.
   *
   * @return MWAppCheckOrgUnitListDetails containing a list of milestone waiver
   * approval check
   * records
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public MWAppCheckOrgUnitListDetails listOrgUnitMWApprovals(
    MilestoneWaiverAppOrgUnitID key) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    final MWAppCheckOrgUnitListDetails milestoneWaiverApprovalDetailsList = new MWAppCheckOrgUnitListDetails();

    milestoneWaiverApprovalDetailsList.dtls = milestoneWaiverApprovalObj.listOrgApprovals(
      key.dtls);

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.dtls.dtls.organisationUnitID;

    milestoneWaiverApprovalDetailsList.orgUnitContextDesc = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return milestoneWaiverApprovalDetailsList;
  }

  /**
   * This method assists the user in modifying the milestone waiver approval
   * details for
   * an organizational unit.
   *
   * @param details containing the information to be updated.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void modifyOrgUnitMWApproval(
    MilestoneWaiverApprovalCheckDetails details) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.modifyApproval(details.dtls);

  }

  /**
   * Returns milestone waiver approval check details based on the milestone
   * waiver approval check
   * id for an organizational unit.
   *
   * @param key containing the milestone waiver approval check id.
   *
   * @return MilestoneWaiverApprovalCheckDetails containing the milestone waiver
   * approval check details.
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public MilestoneWaiverApprovalCheckDetails viewOrgUnitMWApproval(
    MilestoneWaiverApprovalCheckKey key) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    final MilestoneWaiverApprovalCheckDetails milestoneWaiverApprovalCheckDetails = new MilestoneWaiverApprovalCheckDetails();

    milestoneWaiverApprovalCheckDetails.dtls = milestoneWaiverApprovalObj.viewApproval(
      key.dtls);

    return milestoneWaiverApprovalCheckDetails;
  }

  /**
   * Cancels milestone waiver approval check details based on the milestone
   * waiver approval check
   * id. It sets the status of the record to Cancelled.
   *
   * @param key containing the milestone waiver approval check id.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void cancelOrgUnitMWApproval(
    curam.core.facade.struct.MilestoneWaiverApprovalCheckKey key)
    throws AppException, InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.cancelMilestoneApproval(key.dtls);

  }

  /**
   * Creates a milestone waiver approval check for a user.
   *
   * @param details of the milestone waiver approval check record which
   * is to be created
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void createUserMWApproval(MilestoneWaiverApprovalCheckDetails details)
    throws AppException, InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.createApproval(details.dtls);

  }

  /**
   * This method assists the user in modifying the milestone waiver approval
   * details for a user
   *
   * @param details containing the information to be updated.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void modifyUserMWApproval(MilestoneWaiverApprovalCheckDetails details)
    throws AppException, InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.modifyApproval(details.dtls);

  }

  /**
   * Returns milestone waiver approval check details based on the milestone
   * waiver approval check
   * id.
   *
   * @param key containing the milestone waiver approval check id.
   *
   * @return MilestoneWaiverApprovalCheckDetails containing the milestone waiver
   * approval check details.
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public MilestoneWaiverApprovalCheckDetails viewUserMWApproval(
    MilestoneWaiverApprovalCheckKey key) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    final MilestoneWaiverApprovalCheckDetails milestoneWaiverApprovalCheckDetails = new MilestoneWaiverApprovalCheckDetails();

    milestoneWaiverApprovalCheckDetails.dtls = milestoneWaiverApprovalObj.viewApproval(
      key.dtls);

    return milestoneWaiverApprovalCheckDetails;
  }

  /**
   * Returns a list of milestone waiver approval check records based on the
   * organizational
   * unit id.
   *
   * @param key containing a user name, based on which the milestone waiver
   * approval check
   * records are retrieved.
   *
   * @return MWAppCheckOrgUnitListDetails containing a list of milestone waiver
   * approval check
   * records
   *
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public MWAppCheckUserListDetails listUserMWApprovals(
    MilestoneWaiverAppUserName key) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    final MWAppCheckUserListDetails milestoneWaiverApprovalDetailsList = new MWAppCheckUserListDetails();

    milestoneWaiverApprovalDetailsList.dtls = milestoneWaiverApprovalObj.listUserApprovals(
      key.dtls);

    final OrganizationUserContextDescriptionKey organizationUserContextKey = new OrganizationUserContextDescriptionKey();

    organizationUserContextKey.userName = key.dtls.dtls.userName;

    milestoneWaiverApprovalDetailsList.userContextDescription = readUserContextDescription(
      organizationUserContextKey);

    return milestoneWaiverApprovalDetailsList;
  }

  /**
   * Cancels milestone waiver approval check details based on the milestone
   * waiver approval check
   * id. It sets the status of the record to Cancelled.
   *
   * @param key containing the milestone waiver approval check id.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void cancelUserMWApproval(
    curam.core.facade.struct.MilestoneWaiverApprovalCheckKey key)
    throws AppException, InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.cancelMilestoneApproval(key.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads the description of the organization unit.
   *
   * @param key organization unit identifier
   *
   * @return organization unit context description
   */
  protected OrganisationUnitContextDescriptionDetails readOrganisationUnitContextDescription(OrganisationUnitKey key)
    throws AppException, InformationalException {

    // Details to be returned
    final OrganisationUnitContextDescriptionDetails organisationUnitContextDescriptionDetails = new OrganisationUnitContextDescriptionDetails();

    final OrganisationUnitName organisationUnitName = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance().readOrgUnitName(
      key.organisationUnitKey.organisationUnitKey);

    // Set the context description
    organisationUnitContextDescriptionDetails.description = organisationUnitName.name;

    // Return the details
    return organisationUnitContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the description of the User.
   *
   * @param key Identifier for user whose description is to be returned
   *
   * @return Context description for a user
   */
  protected UserContextDescriptionDetails readUserContextDescription(
    OrganizationUserContextDescriptionKey key) throws AppException,
      InformationalException {

    // User maintenance business process object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Details to be returned
    final UserContextDescriptionDetails userContextDescriptionDetails = new UserContextDescriptionDetails();

    // Read the user details
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    final UserFullname userFullName = userAccessObj.getFullName(usersKey);

    // Prepare the context description details
    userContextDescriptionDetails.description = userFullName.fullname;

    // Return details
    return userContextDescriptionDetails;
  }

  // BEGIN, CR00145379, MC

  /**
   * Modifies the percentage details for a milestone waiver approval check
   *
   * @param details MilestoneApprovalCheckPercentageDtls containing the
   * milestone waiver
   * approval check id and the modified percentage value
   *
   * @throws AppException, InformationalException
   */
  @Override
  public void modifyMilestoneApprovalPercentage(
    MilestoneApprovalCheckPercentageDescDtls details) throws AppException,
      InformationalException {

    final MilestoneWaiverApproval milestoneWaiverApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalObj.modifyApprovalCheckPercentage(details);

  }

  /**
   * This method lists the milestone approval checks for a particular milestone
   * configuration.
   * It also determines whether a new milestone approval can be created or not.
   *
   * @param key MilestoneConfigurationID containing the milestone configuration
   * for
   * which the approval checks are to be returned
   *
   * @return MilestoneWaiverApprovalCheckDtlsList containing a list of milestone
   * waiver approval
   * checks.
   *
   * @throws AppException, InformationalException
   */

  @Override
  public MilestoneWaiverApprovalChecks listMilestoneApprovals(
    MilestoneConfigurationID key) throws AppException, InformationalException {

    final MilestoneWaiverApprovalChecks milestoneWaiverApprovalChecks = new MilestoneWaiverApprovalChecks();

    final MilestoneWaiverApproval mwApprovalObj = MilestoneWaiverApprovalFactory.newInstance();

    milestoneWaiverApprovalChecks.approvalList.dtls = mwApprovalObj.listMilestoneApprovals(
      key);
    final MilestoneWaiverApprovalCheckDtlsList mwAppCheckUserListDetailsList = milestoneWaiverApprovalChecks.approvalList.dtls;

    milestoneWaiverApprovalChecks.isNewAllowed = true;

    // Check if the user is allowed to create new approval checks.
    final int noOfApprovalChecks = mwAppCheckUserListDetailsList.dtls.size();

    if (noOfApprovalChecks > 0) {

      for (int i = 0; i < noOfApprovalChecks; i++) {
        final MilestoneWaiverApprovalCheckDtls milestoneWaiverApprovalCheckDtls = mwAppCheckUserListDetailsList.dtls.item(
          i);

        if (milestoneWaiverApprovalCheckDtls.status.equals(
          MWAPPROVALSTATUS.ACTIVE)) {
          milestoneWaiverApprovalChecks.isNewAllowed = false;
          break;
        }
      }
    }

    return milestoneWaiverApprovalChecks;

  }

  // END, CR00145379

}
