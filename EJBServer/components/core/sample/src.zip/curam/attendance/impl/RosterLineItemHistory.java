/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.attendance.impl;


import com.google.inject.ImplementedBy;


/**
 * A wrapper object for {@linkplain curam.core.intf.RosterLineItemHistory}.
 */
@ImplementedBy(RosterLineItemHistoryImpl.class)
public interface RosterLineItemHistory extends RosterLineItemHistoryAccessor {

  /**
   * Gets the roster line item history.
   *
   * @return Roster line item history details.
   */
  @Override
  public RosterLineItemHistory getRosterLineItemHistory();

}
