/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attendance.impl;


import com.google.inject.Inject;
import curam.attendance.entity.struct.AbsenceReasonConfigurationDtls;
import curam.codetable.impl.ABSENCEREASONASSOCIATETYPEEntry;
import curam.codetable.impl.ATTENDANCEABSENCEREASONEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.message.impl.ABSENCEREASONExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;


/**
 * Standard implementation of {@linkplain AbsenceReasonConfiguration}.
 */
public class AbsenceReasonConfigurationImpl extends SingleTableLogicallyDeleteableEntityImpl<AbsenceReasonConfigurationDtls>
  implements AbsenceReasonConfiguration {

  /**
   * Absence Reason Configuration DAO.
   */
  @Inject
  protected AbsenceReasonConfigurationDAO absenceReasonConfigurationDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  public long getAssociateID() {

    return getDtls().associateID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean isAbsenceReasonDeductibleEnabled() {

    return getDtls().absenceReasonDeductibleInd;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean isAbsenceReasonPayableEnabled() {

    return getDtls().absenceReasonPayableInd;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setAbsenceReasonDeductible(boolean absenceReasonDeductible) {

    getDtls().absenceReasonDeductibleInd = absenceReasonDeductible;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setAbsenceReasonPayable(boolean absenceReasonPayable) {

    getDtls().absenceReasonPayableInd = absenceReasonPayable;
  }

  /**
   * {@inheritDoc}
   */

  @Override
  public void setAssociateType(String associateType) {

    getDtls().associateType = associateType;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public long getAbsenceReasonID() {

    return getDtls().absenceReasonID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setAssociateID(final long associateID) {

    getDtls().associateID = associateID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setIsAcceptable(boolean isAcceptable) {

    getDtls().isAcceptable = isAcceptable;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean isAcceptable() {

    return getDtls().isAcceptable;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ABSENCEREASONASSOCIATETYPEEntry getAssociateType() {

    return ABSENCEREASONASSOCIATETYPEEntry.get(getDtls().associateType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// No implementation now
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// No implementation now
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// No implementation now
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ATTENDANCEABSENCEREASONEntry getAbsenceReasoncode() {

    return ATTENDANCEABSENCEREASONEntry.get(getDtls().absenceReasonCode);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setAbsenceReasonCode(final String attendanceabsencereasonEntry) {

    getDtls().absenceReasonCode = attendanceabsencereasonEntry;
  }

  /**
   * Inserts an absence reason configuration record. An absence reason
   * configuration can be created at service offering and agency level.
   *
   * @throws InformationalException
   * {@link ABSENCEREASON#ERR_ABSENCEREASON_XRV_ACTIVE_CONFIGURATION_ALREADY_EXISTS}
   * -
   * If the active configuration already exists.
   */
  @Override
  public void insert() throws InformationalException {

    final String type = getAssociateType().getCode();

    for (final AbsenceReasonConfiguration absenceReason : absenceReasonConfigurationDAO.searchByAbsenceReasonType(
      type)) {
      if (!RECORDSTATUSEntry.CANCELLED.equals(absenceReason.getLifecycleState())
        && absenceReason.getAbsenceReasoncode().equals(getAbsenceReasoncode())
        && absenceReason.getAssociateID() == getAssociateID()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ABSENCEREASONExceptionCreator.ERR_ABSENCEREASON_XRV_ACTIVE_CONFIGURATION_ALREADY_EXISTS(
            getAbsenceReasoncode().toUserLocaleString()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    super.insert();

  }

  /**
   * Set the default instance
   */
  @Override
  public void setNewInstanceDefaults() {

    super.setNewInstanceDefaults();
  }

}
