/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attendance.impl;


import curam.util.persistence.StandardEntity;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * Accessor interface for {@linkplain RosterLineItemHistory}.
 */
public interface RosterLineItemHistoryAccessor extends StandardEntity {

  /**
   * Gets the number of units expected for the roster line item.
   *
   * @return Number of units expected.
   */
  public short getExpectedUnits();

  /**
   * Gets the accessor for roster line item history.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Roster line item history details.
   */
  public RosterLineItemHistoryAccessor getRosterLineItemHistory();

  /**
   * Gets the number of units delivered to the client.
   *
   * @return Number of units delivered.
   */
  public short getUnitsDelivered();

  /**
   * Gets the unique ID of the roster line item.
   *
   * @return Unique ID of the roster line item.
   */
  public Long getRosterLineItemID();

  /**
   * Gets the start date of the period of service delivery for which attendance
   * has been recorded.
   *
   * @return Service from date.
   */
  public Date getServiceDateFrom();

  /**
   * Gets the end date of the period of the service delivery for which
   * attendance has been recorded.
   *
   * @return Service to date.
   */
  public Date getServiceDateTo();

  /**
   * Gets the user name.
   *
   * @return User name.
   */
  public String getUser();

  /**
   * Gets the date and time of the modification of a roster line item.
   *
   * @return Date time of modification of roster line item.
   */
  public DateTime getDateTimeChanged();

  /**
   * Gets the reference number of the roster line item.
   *
   * @return Reference number of the roster line item.
   */
  public String getReferenceNumber();

}
