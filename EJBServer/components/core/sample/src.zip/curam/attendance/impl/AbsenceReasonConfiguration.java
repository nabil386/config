/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attendance.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;


/**
 * The Configuration for the agency or service offering to identify the absence
 * reason can be payable or deductible. An absence reason configuration applies
 * to all service offerings unless a configuration for an individual service
 * offering is created to override it.
 */
@ImplementedBy(AbsenceReasonConfigurationImpl.class)
public interface AbsenceReasonConfiguration extends
    AbsenceReasonConfigurationAccessor, Insertable, OptimisticLockModifiable,
    LogicallyDeleteable {

  /**
   * Sets the absence reason for which client was absent and did not receive the
   * service.
   *
   * @param absenceReasonCode
   * Absence reason code.
   */
  void setAbsenceReasonCode(final String absenceReasonCode);

  /**
   * Sets an indicator which is used to identify whether or not the absence
   * reason is payable at agency or service offering level.
   *
   * @param absenceReasonPayable
   * Absence reason payable indicator.
   */
  void setAbsenceReasonPayable(final boolean absenceReasonPayable);

  /**
   * Sets an indicator which indicates whether the units against a particular
   * absence reason should be deducted from the total units authorized.
   *
   * @param absenceReasonDeductible
   * Absence reason deductible indicator.
   */
  void setAbsenceReasonDeductible(final boolean absenceReasonDeductible);

  /**
   * Sets associate ID.
   *
   * @param associateID
   * The associate ID.
   */
  void setAssociateID(final long associateID);

  /**
   * Sets an indicator which indicates whether the absence reason
   * is acceptable or not.
   *
   * @param isAcceptable
   * Absence reason Acceptance indicator.
   */
  void setIsAcceptable(final boolean isAcceptable);

  /**
   * This method sets the associate type for the absence reason.
   *
   * @param associateType
   * Associate Type.
   * @return Absence reason associate type.
   */
  void setAssociateType(final String associateType);

  /**
   * Interface to the absence reason configuration events functionality
   * surrounding the insert method.
   *
   * @deprecated Since Curam 6.0,
   * PI infrastructure would take care of the events.
   */
  @Deprecated
  public interface AbsenceReasonConfigurationInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration#insert}
     *
     * @param absenceReasonConfiguration
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(
      AbsenceReasonConfigurationAccessor absenceReasonConfiguration)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration#insert}
     *
     * @param absenceReasonConfiguration
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(
      AbsenceReasonConfigurationAccessor absenceReasonConfiguration)
      throws InformationalException;
  }


  /**
   * Interface to the absence reason configuration events functionality
   * surrounding the modify method.
   *
   * @deprecated Since Curam 6.0,
   * PI infrastructure would take care of the events.
   */
  @Deprecated
  public interface AbsenceReasonConfigurationModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration#modify}
     *
     * @param absenceReasonConfiguration
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(
      AbsenceReasonConfigurationAccessor absenceReasonConfiguration,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration#modify}
     *
     * @param absenceReasonConfiguration
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(
      AbsenceReasonConfigurationAccessor absenceReasonConfiguration,
      Integer versionNo) throws InformationalException;
  }


  /**
   * Interface to the absence reason configuration events functionality
   * surrounding the cancel method.
   *
   * @deprecated Since Curam 6.0,
   * PI infrastructure would take care of the events.
   */
  @Deprecated
  public interface AbsenceReasonConfigurationCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration#cancel}
     *
     * @param absenceReasonConfiguration
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(
      AbsenceReasonConfigurationAccessor absenceReasonConfiguration,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration#cancel}
     *
     * @param absenceReasonConfiguration
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(
      AbsenceReasonConfigurationAccessor absenceReasonConfiguration,
      int versionNo) throws InformationalException;
  }

}
