/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attendance.impl;


import com.google.inject.Singleton;
import curam.attendance.entity.impl.AbsenceReasonConfigurationAdapter;
import curam.attendance.entity.struct.AbsenceReasonConfigurationDtls;
import curam.codetable.impl.ABSENCEREASONASSOCIATETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;
import java.util.Set;


/**
 * Standard implementation of {@linkplain AbsenceReasonConfigurationDAO}.
 */
@Singleton
public class AbsenceReasonConfigurationDAOImpl extends StandardDAOImpl<AbsenceReasonConfiguration, AbsenceReasonConfigurationDtls>
  implements AbsenceReasonConfigurationDAO {

  /**
   * Creating the Adapter object
   */
  protected static final AbsenceReasonConfigurationAdapter adapter = new AbsenceReasonConfigurationAdapter();

  /**
   * Constructor for the class.
   */
  protected AbsenceReasonConfigurationDAOImpl() {

    super(adapter, AbsenceReasonConfiguration.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Set<AbsenceReasonConfiguration> searchByAbsenceReasonType(
    String absenceReasonType) {

    return LifecycleHelper.filter(
      newSet(adapter.searchByAssociateType(absenceReasonType)),
      RECORDSTATUSEntry.NORMAL);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Set<AbsenceReasonConfiguration> searchByAssociateID(long associateID) {

    return LifecycleHelper.filter(
      newSet(adapter.searchByAssociateID(associateID)),
      RECORDSTATUSEntry.NORMAL);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Set<AbsenceReasonConfiguration> searchByAbsenceReasonAndAssociateID(
    final String absenceReason, final long associateID) {

    return LifecycleHelper.filter(
      newSet(
        adapter.searchByAbsenceReasonAndAssociateID(absenceReason, associateID)),
        RECORDSTATUSEntry.NORMAL);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Set<AbsenceReasonConfiguration> searchByAbsenceReasonAndType(
    final String absenceReason,
    final ABSENCEREASONASSOCIATETYPEEntry absenceReasonType) {

    return LifecycleHelper.filter(
      newSet(
        adapter.searchByAbsenceReasonAndAssociateType(absenceReason,
        absenceReasonType.getCode())),
        RECORDSTATUSEntry.NORMAL);
  }

  // BEGIN, CR00261800, SK
  /**
   * {@inheritDoc}
   */
  @Override
  public Set<AbsenceReasonConfiguration> readAll() {

    return LifecycleHelper.filter(newSet(adapter.readAll()),
      RECORDSTATUSEntry.NORMAL);
  }
  // END, CR00261800
}
