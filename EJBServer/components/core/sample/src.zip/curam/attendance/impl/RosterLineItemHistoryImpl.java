/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008,2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.attendance.impl;


import com.google.inject.Inject;
import curam.core.sl.entity.struct.RosterLineItemHistoryDtls;
import curam.util.persistence.helper.ReadOnlyEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * Standard implementation of
 * {@linkplain curam.attendence.impl.RosterLineItemHistory}.
 */
// BEGIN, CR00183334, PS
public class RosterLineItemHistoryImpl extends ReadOnlyEntityImpl<Long, RosterLineItemHistoryDtls> implements
  RosterLineItemHistory {

  // END, CR00183334
  /**
   * Reference to RosterLineItemHistoryDAO.
   */
  @Inject
  protected RosterLineItemHistoryDAO rosterLineItemHistoryDAO;

  /**
   * Default constructor
   */
  // BEGIN, CR00183334, PS
  protected RosterLineItemHistoryImpl() {// no-arg constructor for use only by
    // Guice.
    // END, CR00183334
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public short getExpectedUnits() {

    return getDtls().expectedUnits;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RosterLineItemHistory getRosterLineItemHistory() {

    return getDtls().rosterLineItemHistoryID == 0
      ? null
      : rosterLineItemHistoryDAO.get(getDtls().rosterLineItemHistoryID);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public short getUnitsDelivered() {

    return getDtls().totalUnitsDelivered;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getRosterLineItemID() {

    return getDtls().rosterLineItemID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Date getServiceDateFrom() {

    return getDtls().serviceFrom;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Date getServiceDateTo() {

    return getDtls().serviceTo;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getUser() {

    return getDtls().userName;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DateTime getDateTimeChanged() {

    return getDtls().dateTimeChanged;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getReferenceNumber() {

    return getDtls().referenceNo;
  }

}
