/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.bihelper.sl.impl;


import com.google.inject.ImplementedBy;
import curam.cefwidgets.docbuilder.impl.WidgetDocumentBuilder;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.Map;
import org.w3c.dom.Document;


/**
 * This interface provides functionality for BI report configuration retrieval
 * in XML form suitable for report renderer.
 */
@ImplementedBy(BIHelperImpl.class)
public interface BIHelper {

  // ___________________________________________________________________________
  /**
   * Formats a date object for inclusion on a BIRT URL HTTP end point.
   *
   * @param inDate
   * the date for format
   * @return String a date formatted for use as a parameter on a BIRT report.
   */
  public String formatDateForBIRT(java.util.Date inDate);

  // ___________________________________________________________________________
  /**
   * Formats a date object for inclusion on a BIRT URL HTTP end point.
   *
   * @param inDate
   * the date for format
   * @return String a date formatted for use as a parameter on a BIRT report.
   */
  public String formatDateForBIRT(java.util.Calendar inDate);

  // ___________________________________________________________________________
  /**
   * Formats a date object for inclusion on a URL HTTP end point.
   *
   * @param inDate
   * the date for format
   * @param defaultDate
   * a default date already in the specified format
   * @param dateFormat
   * the format for the date, e.g. yyyy-MM-dd, yyyy-MM-dd hh:mm:ss.SSS
   * @return String a date formatted for use as a parameter on a BIRT report
   */
  public String formatDateForBIRT(final java.util.Date inDate, final String defaultDate, final String dateFormat);

  // ___________________________________________________________________________
  /**
   * Retrieves report data XML based on the report name.
   *
   * @param reportName
   * Contains name of the report
   * @return String containing report data XML
   */
  public String getReportDataXML(final String reportName)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves report data as DOM object based on the report name.
   *
   * @param reportName
   * Contains name of the report
   * @return DOM object of chart data
   */
  public Document getReportData(final String reportName) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves fully set-up Document Builder that contains BI report data.
   *
   * @param reportName
   * Contains name of the report
   * @return Widget document Builder
   */
  public WidgetDocumentBuilder getDocumentBuilder(final String reportName)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves report data XML based on the report name, and parameter map.
   *
   * @param reportName
   * Contains name of the report
   * @param parameters
   * Contains map of name-value parameter details
   * @return String containing report data XML
   */
  public String getReportDataXML(final String reportName,
    final Map<String, String> parameters) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves report data as DOM object based on the report name, and parameter
   * map.
   *
   * @param reportName
   * Contains name of the report
   * @param parameters
   * Contains map of name-value parameter details
   * @return DOM object of chart data
   */
  public Document getReportData(final String reportName,
    final Map<String, String> parameters) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves fully set-up Document Builder that contains BI report data.
   *
   * @param reportName
   * Contains name of the report
   * @param parameters
   * Contains map of name-value parameter details
   * @return Widget document Builder
   */
  public WidgetDocumentBuilder getDocumentBuilder(final String reportName,
    final Map<String, String> parameters) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves report data XML based on the report name, parameter map and
   * report servlet name.
   *
   * @param reportName
   * Contains name of the report
   * @param parameters
   * Contains map of name-value parameter details
   * @param servletName
   * Contains BI report viewer engine servlet name
   * @return String containing report data XML
   */
  public String getReportDataXML(final String reportName,
    final Map<String, String> parameters, final String servletName)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves report data as DOM object based on the report name, parameter map
   * and report servlet name.
   *
   * @param reportName
   * Contains name of the report
   * @param parameters
   * Contains map of name-value parameter details
   * @param servletName
   * Contains BI report viewer engine servlet name
   * @return DOM object of chart data
   */
  public Document getReportData(final String reportName,
    final Map<String, String> parameters, final String servletName)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves fully set-up Document Builder that contains BI report data.
   *
   * @param reportName
   * Contains name of the report
   * @param parameters
   * Contains map of name-value parameter details
   * @param servletName
   * Contains BI report viewer engine servlet name
   * @return Widget document Builder
   */
  public WidgetDocumentBuilder getDocumentBuilder(final String reportName,
    final Map<String, String> parameters, final String servletName)
    throws AppException, InformationalException;

}
