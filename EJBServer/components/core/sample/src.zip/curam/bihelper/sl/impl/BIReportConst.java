/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.bihelper.sl.impl;


/**
 * This class assigns values to the Curam constants used in BI reports
 */
public abstract class BIReportConst {

  public static final String gkReportTag = "bi_report";

  public static final String gkName = "name";

  public static final String gkPath = "path";

  public static final String gkDescription = "description";

  public static final String gkScrolling = "scrolling";

  public static final String gkWidth = "width";

  public static final String gkHeight = "height";

  public static final String gkFrameborder = "frameborder";

  public static final char gkAndChar = '&';

  public static final String gkOne = "1";

  public static final String gkZero = "0";

  public static final String gkInvalidParameterChars = "=&;:?";

  public static final String gkInvalidParameterCharRegExp = ".*[=&;:?]+.*";

  public static final String gkInvalidParameterCharsForRoot = "=&;?";

  public static final String gkInvalidParameterCharRegExpForRoot = ".*[=&;?]+.*";

  public static final String gkValidReportDimensionRegExp = "[0-9]{1,4}";

  public static final String gkValidReportDimensionPercentageRegExp = "[0-9]{1,3}[%]";

  public static final int gkMaxReportDimensionPercentage = 100;

  // BEGIN, CR00223475, ELG
  public static final String gkLocaleParameter = "__locale";
  // END, CR00223475

}
