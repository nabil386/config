/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2015 - 2016. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import curam.core.impl.CuramConst;
import curam.message.RMILOGINCLIENT;
import curam.util.security.Authentication;
import curam.util.security.EncryptionAdmin;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.Principal;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

/*
 * Modification History
 * --------------------
 * 1/5/15 DK buttons for HCR
 */
public class RMILoginClient {

  protected JTextField username;

  protected javax.swing.JCheckBox external;

  protected JTextField password;

  protected JLabel label;

  protected JLabel counterLabel;

  protected JButton button;

  protected Authentication authentication;

  protected int loginsOK;

  protected int loginsFailed;

  /**
   * Connect in the constructor
   */
  public RMILoginClient() {

    final Properties ctxProps = new Properties();

    // Setup the properties
    ctxProps.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
      CuramConst.kInitialContextFactory);
    ctxProps.put(javax.naming.Context.PROVIDER_URL, CuramConst.kProviderURL);

    // get the initial context
    Object authenicationObj = null;

    try {
      final Context ctx = new InitialContext(ctxProps);

      // Look up for authentication object
      authenicationObj = ctx.lookup(CuramConst.kAuthenticationObject);
    } catch (final Exception e) {
      System.out.println(e);
      e.printStackTrace();

      return;
    }

    // Cast home object obtained through EJB
    authentication =
      (Authentication) javax.rmi.PortableRemoteObject.narrow(
        authenicationObj, curam.util.security.Authentication.class);
  }

  // BEGIN, WI154546, YF
  /**
   * create the various UI elements
   * 
   * @return
   */
  protected Component createComponents() {

    final JPanel panel = new JPanel();

    panel.setBorder(BorderFactory.createEmptyBorder(0, // top
      0, // left
      0, // bottom
      0)// right
      );
    panel.setLayout(new BorderLayout());
    counterLabel = new JLabel(CuramConst.gkEmpty);

    final Font existingFont = counterLabel.getFont();
    final Font newFont =
      new Font(existingFont.getName(), existingFont.getStyle(),
        (int) (existingFont.getSize() * 0.75));

    counterLabel.setFont(newFont);

    label = new JLabel("Enter Username and Password");
    username = new JTextField();
    password = new JPasswordField();
    password.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(final ActionEvent e) {

        login(username.getText(), password.getText(), external.isSelected());
      }
    });

    button = new JButton(RMILOGINCLIENT.INF_LOGIN_BUTTON.getMessageText());
    button.setMnemonic(KeyEvent.VK_L);
    button.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(final ActionEvent e) {

        login(username.getText(), password.getText(), external.isSelected());
      }
    });

    label.setLabelFor(button);

    // sysadmin
    final JButton uatestLogin = new JButton("Sysadmin");

    uatestLogin.setMnemonic(KeyEvent.VK_L);
    uatestLogin.addActionListener(new ActionListener() {

      @Override
      @SuppressWarnings("unused")
      public void actionPerformed(final ActionEvent e) {

        login("sysadmin", "password", false);
      }
    });

    final JPanel loginPanel = new JPanel();

    loginPanel.add(uatestLogin);

    // caseworker
    final JButton cwuserLogin = new JButton("Caseworker");

    cwuserLogin.setMnemonic(KeyEvent.VK_L);
    cwuserLogin.addActionListener(new ActionListener() {

      @Override
      @SuppressWarnings("unused")
      public void actionPerformed(final ActionEvent e) {

        login("caseworker", "password", false);
      }
    });

    final JPanel loginPanel3 = new JPanel();

    loginPanel3.add(cwuserLogin);

    // admin
    final JButton adminLogin = new JButton("Admin");

    adminLogin.setMnemonic(KeyEvent.VK_L);
    adminLogin.addActionListener(new ActionListener() {

      @Override
      @SuppressWarnings("unused")
      public void actionPerformed(final ActionEvent e) {

        login("admin", "password", false);
      }
    });

    final JPanel loginPanel2 = new JPanel();

    loginPanel2.add(adminLogin);

    // superuser
    final JButton superuserLogin = new JButton("Superuser");

    superuserLogin.setMnemonic(KeyEvent.VK_L);
    superuserLogin.addActionListener(new ActionListener() {

      @Override
      @SuppressWarnings("unused")
      public void actionPerformed(final ActionEvent e) {

        login("superuser", "password", false);
      }
    });

    final JPanel loginPanel4 = new JPanel();

    loginPanel4.add(superuserLogin);

    // label.setLabelFor(button);
    /**
     * Use a panel for spacing
     */
    final JPanel pane = new JPanel();
    final JPanel buttonsPanel = new JPanel();

    pane.setBorder(BorderFactory.createEmptyBorder(0, // top
      30, // left
      40, // bottom
      30)// right
      );
    pane.setLayout(new GridLayout(0, 1));
    pane.add(counterLabel);
    pane.add(label);
    pane.add(username);
    pane.add(password);

    // Add the external check box
    final JPanel externalPanel = new JPanel();

    external = new javax.swing.JCheckBox();
    final JLabel externalLabel = new JLabel("External Logon: ");

    externalPanel.add(externalLabel, 0);
    externalPanel.add(external);
    pane.add(externalPanel);
    pane.add(button);

    buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.Y_AXIS));
    buttonsPanel.add(loginPanel);
    buttonsPanel.add(loginPanel2);
    buttonsPanel.add(loginPanel3);
    buttonsPanel.add(loginPanel4);
    panel.add(buttonsPanel, BorderLayout.NORTH);
    panel.add(pane, BorderLayout.SOUTH);

    return panel;
  }

  // END, WI154546, YF
  /**
   * Try to login
   * 
   * @param name
   * @param pass
   */
  protected void login(final String name, final String pass,
    final boolean externalUser) {

    // Encrypt Password
    String encrypted;

    // BEGIN, CR00352206, SS
    Principal user;
    // BEGIN, CR00073147, GM
    String userType = CuramConst.gkInternalUser;

    // END, CR00073147

    try {
      if (externalUser) {
        userType = CuramConst.gkExternalUser;
        encrypted = pass;
      } else {
        encrypted = EncryptionAdmin.encryptPassword(pass);
      }
      // END, CR00352206
    } catch (final Exception e) {
      // BEGIN, CR00073147, GM
      label.setText(RMILOGINCLIENT.INF_ENCRYPTION_FAILED.getMessageText());
      // END, CR00073147

      return;
    }

    try {
      user = authentication.login(name, encrypted, userType);
    } catch (final Exception e) {
      user = null;
      e.printStackTrace();
    }

    if (user == null) {
      // BEGIN, CR00073147, GM
      label.setText(RMILOGINCLIENT.INF_LOG_IN_FAILED.getMessageText());

      loginsFailed++;
    } else {
      label.setText(RMILOGINCLIENT.INF_LOGGED_IN_AS.getMessageText() + name);
      // END, CR00073147
      loginsOK++;
    }

    counterLabel.setText(
    // BEGIN, CR00073147, GM
      RMILOGINCLIENT.INF_LOGINS.getMessageText() + loginsOK
        + RMILOGINCLIENT.INF_FAILURES.getMessageText() + loginsFailed);
    // END, CR00073147
  }

  /**
   * create the LoginWindow and wait for events
   * 
   * @param args List of args
   */
  public static void main(final String[] args) {

    try {
      UIManager.setLookAndFeel(UIManager
        .getCrossPlatformLookAndFeelClassName());
    } catch (final Exception e) {// Ignore exception
    }

    // Create the top-level container and add contents to it.
    final JFrame frame = new JFrame("Login");
    final RMILoginClient app = new RMILoginClient();
    final Component contents = app.createComponents();

    frame.getContentPane().add(contents, BorderLayout.CENTER);

    // Finish setting up the frame, and show it.
    frame.addWindowListener(new WindowAdapter() {

      @Override
      @SuppressWarnings("unused")
      public void windowClosing(final WindowEvent e) {

        System.exit(0);
      }
    });
    frame.pack();

    // Set the location of the window to open
    final Point point = new Point(500, 300);

    frame.setLocation(point);

    frame.setVisible(true);
  }
}
