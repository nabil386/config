/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CancelThirdPartyDetails;
import curam.appeal.facade.struct.CreateThirdPartyDetails;
import curam.appeal.facade.struct.ListThirdPartyDetailsList;
import curam.appeal.facade.struct.ModifyThirdPartyDetails;
import curam.appeal.facade.struct.ThirdPartyKey;
import curam.appeal.facade.struct.ViewThirdPartyDetails;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.fact.ThirdPartyFactory;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.core.facade.pdt.struct.InformationalMessageList;
import curam.core.facade.struct.ParticipantTypeDescList;
import curam.core.facade.struct.ParticipantTypeDescription;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeSet;

/**
 * This process class provides the functionality for the Third Party
 * facade.
 * 
 */
public abstract class ThirdParty extends curam.appeal.facade.base.ThirdParty {

  // ___________________________________________________________________________
  /**
   * Method to create a Third Party
   * 
   * @param details The details of the Third Party being created
   * 
   * @return List of Informational messages.
   */
  @Override
  public InformationalMessageList addThirdParty(
    final CreateThirdPartyDetails details) throws AppException,
    InformationalException {

    // Variable for access to Third Party service layer
    final curam.appeal.sl.intf.ThirdParty thirdParty =
      ThirdPartyFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    return thirdParty.createThirdParty(details.createDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method to modify a Third Party
   * 
   * @param details The details of the Third Party being modified
   */
  @Override
  public void modifyThirdParty(final ModifyThirdPartyDetails details)
    throws AppException, InformationalException {

    // Variable for access to Third Party service layer
    final curam.appeal.sl.intf.ThirdParty thirdParty =
      ThirdPartyFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    thirdParty.updateThirdParty(details.updateDtls);
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel a Third Party
   * 
   * @param details The details of the Third Party
   */
  @Override
  public void removeThirdParty(final CancelThirdPartyDetails details)
    throws AppException, InformationalException {

    // Variable for access to Third Party service layer
    final curam.appeal.sl.intf.ThirdParty thirdParty =
      ThirdPartyFactory.newInstance();

    // Use the service layer
    thirdParty.cancelThirdParty(details.cancelDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method to display the list of Third Parties
   * 
   * @param key The appeal key
   * 
   * @return The list of third parties
   */
  @Override
  public ListThirdPartyDetailsList
    listThirdParties(final AppealCaseIDKey key) throws AppException,
      InformationalException {

    // Return object
    final ListThirdPartyDetailsList listThirdPartyDetailsList =
      new ListThirdPartyDetailsList();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Variable for access to Third Party service layer
    final curam.appeal.sl.intf.ThirdParty thirdParty =
      ThirdPartyFactory.newInstance();

    // appeal entity variables

    final Appeal appeal = AppealFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    final AppealKey appealKey = new AppealKey();

    appealKey.appealID = appeal.readAppealIDByCase(key).appealID;

    // Use the service layer
    listThirdPartyDetailsList.listDtls =
      thirdParty.listThirdParties(appealKey);

    // Get the menu data
    appealCaseDetails.caseID = key.caseID;
    listThirdPartyDetailsList.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    return listThirdPartyDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to display the Third Party details
   * 
   * @param key The details of the Third Party
   * 
   * @return The third party details
   */
  @Override
  public ViewThirdPartyDetails viewThirdParty(final ThirdPartyKey key)
    throws AppException, InformationalException {

    // Variable for access to Third Party service layer
    final curam.appeal.sl.intf.ThirdParty thirdParty =
      ThirdPartyFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    final ViewThirdPartyDetails viewThirdPartyDetails =
      new ViewThirdPartyDetails();

    curam.appeal.sl.entity.struct.ThirdPartyKey thirdPartyKey =
      new curam.appeal.sl.entity.struct.ThirdPartyKey();

    thirdPartyKey = key.key;

    viewThirdPartyDetails.viewDtls = thirdParty.readThirdParty(thirdPartyKey);

    return viewThirdPartyDetails;
  }

  // BEGIN, CR00266910, MC
  // ___________________________________________________________________________
  /**
   * Returns the list of participant types that can be selected as third parties
   * for a hearing case.
   * 
   * @return List of participants to display in participant search list.
   * Reads a list of participants.
   */
  @Override
  public ParticipantTypeDescList populateParticipantList()
    throws AppException, InformationalException {

    //
    // Read the configured list of third party types for the search
    //
    final String participantsString =
      Configuration.getProperty(EnvVars.ENV_APPEAL_THIRD_PARTY_PARTICIPANTS);

    final String[] participantArray =
      participantsString.split(CuramConst.gkComma);

    final LinkedHashMap<String, String> concernRoleHashMap =
      CodeTable.getAllItems(curam.codetable.CONCERNROLETYPE.TABLENAME,
        TransactionInfo.getProgramLocale());

    Set<String> concernRoleKeys = new TreeSet<String>();

    if (!concernRoleHashMap.isEmpty()) {

      concernRoleKeys = concernRoleHashMap.keySet();
    }

    final ParticipantTypeDescList participantTypeDescList =
      new ParticipantTypeDescList();
    ParticipantTypeDescription participantTypeDescription;

    for (int i = 0; i < participantArray.length; i++) {

      if (!concernRoleKeys.isEmpty()) {

        final Iterator<String> itr = concernRoleKeys.iterator();

        while (itr.hasNext()) {
          final String concernRoleKey = itr.next().toString();

          if (participantArray[i].trim().equals(concernRoleKey)) {

            participantTypeDescription = new ParticipantTypeDescription();
            participantTypeDescription.participantType = concernRoleKey;
            participantTypeDescription.participantDescription =
              concernRoleHashMap.get(concernRoleKey).toString();

            participantTypeDescList.participantTypeDescription
              .addRef(participantTypeDescription);
          }
        }
      }
    }

    return participantTypeDescList;
  }

  // END, CR00266910
}
