/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AdjournHearingDetails;
import curam.appeal.facade.struct.AdjournHearingReviewDetails;
import curam.appeal.facade.struct.AttendeeTabList;
import curam.appeal.facade.struct.CompleteDeskHearingDetails;
import curam.appeal.facade.struct.CompleteHearingDetails;
import curam.appeal.facade.struct.CompleteHearingReviewDetails;
import curam.appeal.facade.struct.DeskHearingSummaryDetails;
import curam.appeal.facade.struct.DeskHearingSummaryDetailsOnIC;
import curam.appeal.facade.struct.DisplayLocationScheduleDetails;
import curam.appeal.facade.struct.DisplayLocationScheduleKey;
import curam.appeal.facade.struct.DisplayUserScheduleDtls;
import curam.appeal.facade.struct.DisplayUserScheduleKey;
import curam.appeal.facade.struct.HearingAttendance;
import curam.appeal.facade.struct.HearingAttendanceForIC;
import curam.appeal.facade.struct.HearingCaseHearingDetailsList;
import curam.appeal.facade.struct.HearingKey;
import curam.appeal.facade.struct.HearingModifyDetails;
import curam.appeal.facade.struct.HearingOfficialDetails;
import curam.appeal.facade.struct.HearingParticipantDetailsList;
import curam.appeal.facade.struct.HearingParticipantDetailsListForIC;
import curam.appeal.facade.struct.HearingParticipantKey;
import curam.appeal.facade.struct.HearingParticipantPhoneNumberList;
import curam.appeal.facade.struct.HearingParticipantPhoneNumberListNonIC;
import curam.appeal.facade.struct.HearingReadModifyDetails;
import curam.appeal.facade.struct.HearingReviewSummaryDetails;
import curam.appeal.facade.struct.HearingReviewSummaryDetailsOnIC;
import curam.appeal.facade.struct.HearingReviewerDetails;
import curam.appeal.facade.struct.HearingReviewerFullDetailsList;
import curam.appeal.facade.struct.HearingReviewerFullDetailsListOnIC;
import curam.appeal.facade.struct.HearingSummaryDetails;
import curam.appeal.facade.struct.HearingSummaryDetailsOnIC;
import curam.appeal.facade.struct.HearingUserAttendeeTypeDetails;
import curam.appeal.facade.struct.HearingUserAttendeeTypeDetailsList;
import curam.appeal.facade.struct.HearingUserDetails;
import curam.appeal.facade.struct.HearingUserFullDetailsList;
import curam.appeal.facade.struct.HearingUserFullDetailsListOnIC;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.HearingAttendanceParserFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.HearingAttendanceParser;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.HearingAppealTypeCode;
import curam.appeal.sl.struct.HearingAttendanceDetails;
import curam.appeal.sl.struct.HearingAttendanceDetailsList;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingUserTypeKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.intf.IntegratedCase;
import curam.core.facade.struct.ListMemberDetails;
import curam.core.facade.struct.ListMemberDetailsKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.LocationFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.Location;
import curam.core.sl.fact.SlotAllocationFactory;
import curam.core.sl.intf.SlotAllocation;
import curam.core.sl.struct.DetermineAvailableSlotsKey;
import curam.core.sl.struct.DisplayUserDailyScheduleKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.LocationKey;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeSet;

/**
 * This process class provides the functionality for the Hearing facade.
 * 
 */
public abstract class Hearing extends curam.appeal.facade.base.Hearing {

  protected static final String kScheduleConfigType =
    GeneralAppealConstants.kScheduleConfigType;

  // ___________________________________________________________________________
  /**
   * Invites a user of type official to the hearing
   * 
   * @param dtls The details of the user to be invited
   */
  @Override
  public void inviteOfficial(final HearingOfficialDetails dtls)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set user type
    dtls.dtls.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

    // Add the official
    hearingObj.inviteUser(dtls.dtls);
  }

  // ___________________________________________________________________________
  /**
   * Invites a user of type reviewer to the hearing
   * 
   * @param dtls The details of the user to be invited
   */
  @Override
  public void inviteReviewer(final HearingReviewerDetails dtls)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set user type
    dtls.dtls.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;

    // Add the reviewer
    hearingObj.inviteUser(dtls.dtls);
  }

  // BEGIN, CR00290455, MC
  // ___________________________________________________________________________
  /**
   * Invites a user to the hearing
   * 
   * @param dtls The details of the user to be invited
   * 
   * @deprecated Since Curam 6.0 SP2, replaced by {@link #inviteUserAttendee()}
   * The type code user on the new method is directly from the case user role
   * codetable.
   */
  @Override
  @Deprecated
  public void inviteUser(final HearingUserDetails dtls) throws AppException,
    InformationalException {

    // Hearing objects
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingUserDetails hearingUserDetails =
      new curam.appeal.sl.struct.HearingUserDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Add the user
    hearingUserDetails.hearingID = dtls.hearingID;
    hearingUserDetails.typeCode = dtls.typeCode;
    hearingUserDetails.userName = dtls.userName;
    hearingObj.inviteUser(hearingUserDetails);
  }

  // ___________________________________________________________________________
  /**
   * Invites a user to the hearing and specifies the type of the user from the
   * case user role codetable.
   * 
   * @param dtls The details of the user to be invited
   */
  @Override
  public void inviteUserAttendee(
    final curam.appeal.sl.struct.HearingUserDetails dtls)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingObj.inviteUser(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of user hearing attendee types that can be added as user
   * attendees to a Hearing.
   * 
   * @return List of user hearing attendee types.
   */
  @Override
  public HearingUserAttendeeTypeDetailsList readHearingUserAttendeeTypeList()
    throws AppException, InformationalException {

    //
    // Read the configured list of user hearing attendee types
    //
    final String hearingUserAttedeeTypeString =
      Configuration.getProperty(EnvVars.ENV_HEARING_USER_ATTENDEE_TYPES);

    final String[] hearingUserAttedeeTypeArray =
      hearingUserAttedeeTypeString.split(CuramConst.gkComma);

    final LinkedHashMap<String, String> codetableHashMap =
      CodeTable.getAllItems(curam.codetable.CASEUSERROLETYPE.TABLENAME,
        TransactionInfo.getProgramLocale());

    Set<String> codetableKeys = new TreeSet<String>();

    if (!codetableHashMap.isEmpty()) {

      codetableKeys = codetableHashMap.keySet();
    }

    final HearingUserAttendeeTypeDetailsList hearingUserAttendeeTypeDetailsList =
      new HearingUserAttendeeTypeDetailsList();

    HearingUserAttendeeTypeDetails hearingUserAttendeeTypeDetails;

    for (int i = 0; i < hearingUserAttedeeTypeArray.length; i++) {

      if (!codetableKeys.isEmpty()) {

        final Iterator<String> itr = codetableKeys.iterator();

        while (itr.hasNext()) {
          final String codetableKey = itr.next().toString();
          final String codetableDescription =
            codetableHashMap.get(codetableKey).toString();

          if (hearingUserAttedeeTypeArray[i].trim().equals(codetableKey)) {

            hearingUserAttendeeTypeDetails =
              new HearingUserAttendeeTypeDetails();
            hearingUserAttendeeTypeDetails.typeCode = codetableKey;
            hearingUserAttendeeTypeDetails.typeCodeDescription =
              codetableDescription;

            hearingUserAttendeeTypeDetailsList.dtls
              .addRef(hearingUserAttendeeTypeDetails);
          }
        }
      }
    }

    return hearingUserAttendeeTypeDetailsList;
  }

  // END, CR00290455

  // ___________________________________________________________________________
  /**
   * Reads details about all reviewers for the hearing.
   * 
   * @param key The hearing ID
   * 
   * @return the list of reviewer details associated with the hearing
   */
  @Override
  public HearingReviewerFullDetailsList listReviewers(final HearingKey key)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final HearingUserTypeKey hearingUserTypeKey = new HearingUserTypeKey();
    HearingCaseID hearingCaseID;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final HearingReviewerFullDetailsList hearingReviewerFullDetailsList =
      new HearingReviewerFullDetailsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the reviewer list
    hearingUserTypeKey.hearingID = key.hearingKey_bo.hearingKey.hearingID;
    hearingUserTypeKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;
    hearingReviewerFullDetailsList.hearingOfficialList =
      hearingObj.listUsers(hearingUserTypeKey);

    // Read hearing case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    hearingReviewerFullDetailsList.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Return the list
    return hearingReviewerFullDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads details about all reviewers for the hearing.
   * 
   * @param key The hearing ID
   * 
   * @return the list of reviewer details associated with the hearing
   */
  @Override
  public HearingReviewerFullDetailsListOnIC listReviewersOnIC(
    final HearingKey key) throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final HearingUserTypeKey hearingUserTypeKey = new HearingUserTypeKey();
    HearingCaseID hearingCaseID;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final HearingReviewerFullDetailsListOnIC hearingReviewerFullDetailsListOnIC =
      new HearingReviewerFullDetailsListOnIC();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the reviewer list
    hearingUserTypeKey.hearingID = key.hearingKey_bo.hearingKey.hearingID;
    hearingUserTypeKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;
    hearingReviewerFullDetailsListOnIC.hearingOfficialList =
      hearingObj.listUsers(hearingUserTypeKey);

    // Read hearing case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    hearingReviewerFullDetailsListOnIC.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Get the menu data
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    hearingReviewerFullDetailsListOnIC.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    // Return the list
    return hearingReviewerFullDetailsListOnIC;
  }

  // ___________________________________________________________________________
  /**
   * Lists details about all users for a hearing.
   * 
   * @param key The hearing ID
   * 
   * @return the list of user details associated with the hearing
   */
  @Override
  public HearingUserFullDetailsList listUsers(final HearingKey key)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final HearingUserTypeKey hearingUserTypeKey = new HearingUserTypeKey();
    HearingCaseID hearingCaseID;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final HearingUserFullDetailsList hearingUserFullDetailsList =
      new HearingUserFullDetailsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the user list
    hearingUserTypeKey.hearingID = key.hearingKey_bo.hearingKey.hearingID;
    hearingUserFullDetailsList.hearingUserList =
      hearingObj.listUsers(hearingUserTypeKey);

    // Read hearing case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    hearingUserFullDetailsList.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Return the list
    return hearingUserFullDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists details about all users for a hearing on an integrated case.
   * 
   * @param key The hearing ID
   * 
   * @return the list of user details associated with the hearing
   */
  @Override
  public HearingUserFullDetailsListOnIC listUsersOnIC(final HearingKey key)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final HearingUserTypeKey hearingUserTypeKey = new HearingUserTypeKey();
    HearingCaseID hearingCaseID;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final HearingUserFullDetailsListOnIC hearingUserFullDetailsListOnIC =
      new HearingUserFullDetailsListOnIC();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the user list
    hearingUserTypeKey.hearingID = key.hearingKey_bo.hearingKey.hearingID;
    hearingUserFullDetailsListOnIC.hearingUserList =
      hearingObj.listUsers(hearingUserTypeKey);

    // Read hearing case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // assign the page description to the return object
      hearingUserFullDetailsListOnIC.appealContextDescription.description =
        appealContextDescription.description;

      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo);

      hearingUserFullDetailsListOnIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else { // END, CR00115728
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      hearingUserFullDetailsListOnIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      hearingUserFullDetailsListOnIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }

    // Return the list
    return hearingUserFullDetailsListOnIC;
  }

  // ___________________________________________________________________________
  /*
   * Lists the hearing home page details for a hearing review hearing.
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return the home page details
   */
  @Override
  public HearingReviewSummaryDetails getReviewSummaryDetails(
    final HearingKey key) throws AppException, InformationalException {

    // Return details
    final HearingReviewSummaryDetails hearingReviewSummaryDetails =
      new HearingReviewSummaryDetails();

    // Context Description
    AppealContextDescription appealContextDescription;

    // HearingCaseID object
    HearingCaseID hearingCaseID;

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Get the hearing review case ID
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Assign the details
    hearingReviewSummaryDetails.hearingSummaryReviewDetails =
      hearingObj.getReviewSummaryDetails(key.hearingKey_bo);

    hearingReviewSummaryDetails.appealContextDescription =
      appealContextDescription;

    // Return the details
    return hearingReviewSummaryDetails;
  }

  // ___________________________________________________________________________
  /*
   * Lists the hearing home page details for an integrated case hearing review
   * hearing.
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return the home page details
   */
  @Override
  public HearingReviewSummaryDetailsOnIC getReviewSummaryDetailsOnIC(
    final HearingKey key) throws AppException, InformationalException {

    // Return details
    final HearingReviewSummaryDetailsOnIC hearingReviewSummaryDetailsOnIC =
      new HearingReviewSummaryDetailsOnIC();

    // Context Description
    AppealContextDescription appealContextDescription;

    // HearingCaseID object
    HearingCaseID hearingCaseID;

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Get the hearing review case ID
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Assign the details
    hearingReviewSummaryDetailsOnIC.hearingSummaryReviewDetails =
      hearingObj.getReviewSummaryDetails(key.hearingKey_bo);

    hearingReviewSummaryDetailsOnIC.appealContextDescription =
      appealContextDescription;

    // Get the menu data
    hearingReviewSummaryDetailsOnIC.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    // Return the details
    return hearingReviewSummaryDetailsOnIC;
  }

  // ___________________________________________________________________________
  /*
   * Lists the hearing home page details for a hearing of a standalone case
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return the home page details
   */
  @Override
  public HearingSummaryDetails getSummaryDetails(final HearingKey key)
    throws AppException, InformationalException {

    // Return details
    final HearingSummaryDetails hearingSummaryDetails =
      new HearingSummaryDetails();

    // Context Description
    AppealContextDescription appealContextDescription;

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    final HearingCaseID hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Assign the details
    hearingSummaryDetails.hearingSummaryDetails =
      hearingObj.getSummaryDetails(key.hearingKey_bo);

    hearingSummaryDetails.appealContectDescription = appealContextDescription;

    // Return the details
    return hearingSummaryDetails;

  }

  // ___________________________________________________________________________
  /*
   * Lists the hearing home page details for a hearing of an integrated case
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return the home page details
   */
  @Override
  public HearingSummaryDetailsOnIC
    getSummaryDetailsOnIC(final HearingKey key) throws AppException,
      InformationalException {

    // Return details
    final HearingSummaryDetailsOnIC hearingSummaryDetailsOnIC =
      new HearingSummaryDetailsOnIC();

    // Context Description
    AppealContextDescription appealContextDescription;

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    final HearingCaseID hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription contextDescription =
        legalActionObj.getContextDescription(caseID);

      // Get the context description for legal action
      hearingSummaryDetailsOnIC.appealContextDescription.description =
        contextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo);

      hearingSummaryDetailsOnIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else {
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      hearingSummaryDetailsOnIC.appealContextDescription =
        appealContextDescription;

      // Get the menu data
      hearingSummaryDetailsOnIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }
    // END, CR0011572

    // Assign the details
    hearingSummaryDetailsOnIC.hearingSummaryDetails =
      hearingObj.getSummaryDetails(key.hearingKey_bo);

    // Return the details
    return hearingSummaryDetailsOnIC;

  }

  // ___________________________________________________________________________
  /*
   * This method modifies a hearing
   * 
   * @param details Identifies the hearing
   */
  @Override
  public void modify(final HearingModifyDetails details) throws AppException,
    InformationalException {

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Modify the details
    hearingObj.modify(details.hearingModifyDetails);

  }

  // ___________________________________________________________________________
  /**
   * Returns the list of attendees and their recorded participation for a
   * hearing.
   * 
   * @param key Hearing unique identifier
   * 
   * @return hearingAttendance list of hearing attendees
   */
  @Override
  public HearingAttendance listAttendance(final HearingKey key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;

    // Hearing Attendance variables
    final HearingAttendance hearingAttendance = new HearingAttendance();

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Get the case id

    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // assign the context description for legal action
      hearingAttendance.appealContextDescription.description =
        appealContextDescription.description;
      // END, CR00116551
    } else {
      // Get the context description
      hearingAttendance.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
    }
    // END, CR00115728

    hearingAttendance.hearingAttendance =
      hearingObj.listAttendance(key.hearingKey_bo);

    // BEGIN, CR00258352, PM
    final HearingAttendance hearingAttendanceTemp = new HearingAttendance();

    hearingAttendanceTemp.hearingAttendance =
      hearingObj.listParticipantAttendance(key.hearingKey_bo);

    for (final HearingAttendanceDetails hearingAttendanceDetails : hearingAttendanceTemp.hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
      .items()) {

      // Add to the list.
      hearingAttendance.hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);
    }
    // END, CR00258352

    return hearingAttendance;

  }

  // ___________________________________________________________________________
  /**
   * Returns the list of user attendees and their recorded participation for a
   * hearing for Integrated Cases.
   * 
   * @param key Hearing unique identifier
   * 
   * @return hearingAttendanceForIC list of hearing attendees
   */
  @Override
  public HearingAttendanceForIC listAttendanceForIC(final HearingKey key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;

    // Hearing Attendance variables
    final HearingAttendanceForIC hearingAttendanceForIC =
      new HearingAttendanceForIC();

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Get the case id

    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      hearingAttendanceForIC.appealContextDescription.description =
        appealContextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo);

      // assign menu data
      hearingAttendanceForIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else {
      // Get the context description
      hearingAttendanceForIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      hearingAttendanceForIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }
    // END, CR00115728

    hearingAttendanceForIC.hearingAttendance =
      hearingObj.listAttendance(key.hearingKey_bo);

    return hearingAttendanceForIC;

  }

  // BEGIN, CR00246931, GP
  /**
   * Returns the list of Participant attendees and their recorded participation
   * for a hearing for Integrated Cases.
   * 
   * @param key contains the Hearing key.
   * @return hearingAttendanceForIC list of hearing attendees.
   * 
   * @throws InformationalException Generic exception signature.
   * @throws AppException Generic exception signature.
   */
  @Override
  public HearingAttendanceForIC listParticipantAttendanceForIC(
    final HearingKey key) throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID = new HearingCaseID();

    final HearingAttendanceForIC hearingAttendanceForIC =
      new HearingAttendanceForIC();

    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {

      final LegalAction legalActionObj = LegalActionFactory.newInstance();

      final CaseID caseID = new CaseID();

      caseID.caseID = hearingCaseID.hearingCaseID.caseID;

      // Get the context description for legal action.
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      hearingAttendanceForIC.appealContextDescription.description =
        appealContextDescription.description;

      // Get the menu data for legal action.
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo);

      hearingAttendanceForIC.appealMenuData.menuData =
        appealMenuData.menuData;

    } else {

      // Get the context description
      hearingAttendanceForIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      hearingAttendanceForIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }

    hearingAttendanceForIC.hearingAttendance =
      hearingObj.listParticipantAttendance(key.hearingKey_bo);
    return hearingAttendanceForIC;
  }

  // END, CR00246931

  // ___________________________________________________________________________
  /**
   * Completes a hearing.
   * 
   * @param details Complete hearing details
   */
  @Override
  public void complete(final CompleteHearingDetails details)
    throws AppException, InformationalException {

    // Hearing business object variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.CompleteHearingDetails completeHearingDetails =
      new curam.appeal.sl.struct.CompleteHearingDetails();

    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Hearing attendance parser
    final curam.appeal.sl.intf.HearingAttendanceParser hearingAttendanceParserObj =
      curam.appeal.sl.fact.HearingAttendanceParserFactory.newInstance();
    final AttendeeTabList attendeeTabList = new AttendeeTabList();

    // register the security implementation
    SecurityImplementationFactory.register();

    attendeeTabList.caseUserRoleTabList = details.attendeeList;

    completeHearingDetails.hearingAttendanceDetailsList =
      hearingAttendanceParserObj.parse(attendeeTabList);

    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;

    // assign hearing details
    completeHearingDetails.completeHearing.assign(details.completeHearing);

    // complete hearing
    hearingObj.complete(completeHearingDetails, hearingAppealTypeCode);

  }

  // ___________________________________________________________________________
  /**
   * Completes a hearing review.
   * 
   * @param details Complete hearing review details
   */

  @Override
  public void completeReview(final CompleteHearingReviewDetails details)
    throws AppException, InformationalException {

    // Hearing business object variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.CompleteHearingDetails completeHearingDetails =
      new curam.appeal.sl.struct.CompleteHearingDetails();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // HearingAttendanceParser object
    final HearingAttendanceParser hearingAttendanceParserObj =
      HearingAttendanceParserFactory.newInstance();
    final AttendeeTabList attendeeTabList = new AttendeeTabList();
    HearingAttendanceDetailsList hearingAttendanceDetailsList;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Parse hearing attendance list
    attendeeTabList.caseUserRoleTabList = details.attendeeList;
    hearingAttendanceDetailsList =
      hearingAttendanceParserObj.parse(attendeeTabList);

    // BEGIN, CR00088944, RKi
    // Add parsed list to service layer struct param
    for (int i = 0; i < hearingAttendanceDetailsList.hearingAttendanceDetails
      .size(); i++) {

      completeHearingDetails.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetailsList.hearingAttendanceDetails.item(i));
    }
    // END, CR00088944

    // Add hearing details to service layer struct param
    completeHearingDetails.completeHearing.assign(details.completeHearing);

    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARINGREVIEW;

    // complete hearing
    hearingObj.complete(completeHearingDetails, hearingAppealTypeCode);
  }

  // ___________________________________________________________________________
  /*
   * This method gets the details of the hearing that are to be modified
   * 
   * @param key Identifies the hearing
   */
  @Override
  public HearingReadModifyDetails getDetailsForModify(final HearingKey key)
    throws AppException, InformationalException {

    // Return details
    final HearingReadModifyDetails hearingReadModifyDetails =
      new HearingReadModifyDetails();

    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    hearingReadModifyDetails.hearingModifyDetails.hearingModifyDetails =
      hearingObj.readDetailsForModify(key.hearingKey_bo.hearingKey);

    // Return the details
    return hearingReadModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Adjourns a hearing for a hearing case.
   * 
   * @param dtls Adjourn hearing details
   */
  @Override
  public void adjourn(final AdjournHearingDetails dtls) throws AppException,
    InformationalException {

    // Hearing business object variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.AdjournHearingDetails adjournHearingDetails =
      new curam.appeal.sl.struct.AdjournHearingDetails();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Hearing attendance parser
    final HearingAttendanceParser hearingAttendanceParserObj =
      HearingAttendanceParserFactory.newInstance();
    final AttendeeTabList attendeeTabList = new AttendeeTabList();

    // register the security implementation
    SecurityImplementationFactory.register();

    attendeeTabList.caseUserRoleTabList = dtls.attendeeList;

    adjournHearingDetails.hearingAttendanceDetailsList =
      hearingAttendanceParserObj.parse(attendeeTabList);

    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;

    adjournHearingDetails.adjournHearingDetails.assign(dtls.adjournHearing);

    // adjourn hearing
    hearingObj.adjourn(adjournHearingDetails, hearingAppealTypeCode);

  }

  // ___________________________________________________________________________
  /**
   * Adjourns a hearing review
   * 
   * @param dtls Adjourn hearing review details
   */
  @Override
  public void adjournReview(final AdjournHearingReviewDetails dtls)
    throws AppException, InformationalException {

    // Hearing business object variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.AdjournHearingDetails adjournHearingDetails =
      new curam.appeal.sl.struct.AdjournHearingDetails();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set the type code to hearing review
    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARINGREVIEW;

    adjournHearingDetails.adjournHearingDetails.assign(dtls.adjournHearing);

    // adjourn hearing
    hearingObj.adjourn(adjournHearingDetails, hearingAppealTypeCode);

  }

  // __________________________________________________________________________
  /**
   * Method to return a list of case participants for a given hearing
   * 
   * @param key The hearing id for the hearing.
   * 
   * @return listMemberDetails the list of participants
   */
  @Override
  public curam.core.facade.struct.ListMemberDetails
    listCaseParticipantsDetails(final HearingKey key) throws AppException,
      InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID_bo;

    // IntegratedCase variables
    final IntegratedCase integratedCase_foObj =
      IntegratedCaseFactory.newInstance();
    final ListMemberDetailsKey listMemberDetailsKey_fo =
      new ListMemberDetailsKey();
    ListMemberDetails listMemberDetails_fo;

    // Read Appeal hearing case id
    hearingCaseID_bo = hearing_boObj.getCase(key.hearingKey_bo);

    listMemberDetailsKey_fo.caseID = hearingCaseID_bo.hearingCaseID.caseID;
    listMemberDetails_fo =
      integratedCase_foObj
        .listCaseParticipantsDetails(listMemberDetailsKey_fo);

    return listMemberDetails_fo;

  }

  // __________________________________________________________________________
  /**
   * Displays a location schedule of users
   * 
   * @param key contains the information needed to display the location
   * schedule
   */
  @Override
  public DisplayLocationScheduleDetails displayLocationSchedule(
    final DisplayLocationScheduleKey key) throws AppException,
    InformationalException {

    // Location object and manipulation variables
    final Location locationObj = LocationFactory.newInstance();
    final LocationKey locationKey = new LocationKey();

    // hearing variables
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    // slot determination variables
    final SlotAllocation slotAllocationObj =
      SlotAllocationFactory.newInstance();

    // return details
    final DisplayLocationScheduleDetails displayLocationScheduleDetails =
      new DisplayLocationScheduleDetails();

    final DetermineAvailableSlotsKey determineAvailableSlotsKey =
      new DetermineAvailableSlotsKey();

    determineAvailableSlotsKey.effectiveDate = key.date;
    determineAvailableSlotsKey.jobID = key.jobID;
    determineAvailableSlotsKey.locationID = key.locationID;

    // if were given only a hearing ID, use it to set the caseID
    if (key.caseID == 0 && key.hearingID != 0) {
      hearingKey.hearingID = key.hearingID;
      key.caseID = hearingObj.readCase(hearingKey).caseID;
    }

    determineAvailableSlotsKey.relatedID = key.caseID;

    displayLocationScheduleDetails.determineAvailableSlotsDetailsList =
      slotAllocationObj.determineAvailableSlots(determineAvailableSlotsKey);

    // set the location name
    locationKey.locationID = key.locationID;
    displayLocationScheduleDetails.locationName =
      locationObj.readLocationName(locationKey).name;

    return displayLocationScheduleDetails;

  }

  // __________________________________________________________________________
  /**
   * Displays the user schedule
   * 
   * @param key contains the information needed to display the user
   * schedule
   */
  @Override
  public DisplayUserScheduleDtls displayUserSchedule(
    final DisplayUserScheduleKey key) throws AppException,
    InformationalException {

    final DisplayUserScheduleDtls displayUserScheduleDtls =
      new DisplayUserScheduleDtls();

    final SlotAllocation slotAllocationObj =
      SlotAllocationFactory.newInstance();

    final DisplayUserDailyScheduleKey displayUserDailyScheduleKey =
      new DisplayUserDailyScheduleKey();

    displayUserDailyScheduleKey.effectiveDate = key.date;
    displayUserDailyScheduleKey.jobID = key.jobID;
    displayUserDailyScheduleKey.scheduleConfigMode = key.scheduleConfigMode;
    displayUserDailyScheduleKey.scheduleConfigType = kScheduleConfigType;

    displayUserScheduleDtls.userSchedule =
      slotAllocationObj.displayUserDailySchedule(displayUserDailyScheduleKey).userScheduleData;

    return displayUserScheduleDtls;
  }

  // ___________________________________________________________________________
  /**
   * Displays the active participants for a hearing
   * 
   * @param key Unique internal reference number of the hearing
   * @return The list of active hearing participants and their participant type
   */
  @Override
  public HearingParticipantDetailsList listActiveParticipants(
    final HearingKey key) throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    final HearingParticipantDetailsList hearingParticipantDetailsList =
      new HearingParticipantDetailsList();

    // Get the case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // Get the context description
    hearingParticipantDetailsList.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    hearingParticipantDetailsList.hearingParticipantDetailsList =
      hearingObj.listActiveHearingParticipants(key.hearingKey_bo);

    return hearingParticipantDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Displays the active participants for an IC hearing
   * 
   * @param key Unique internal reference number of the hearing
   * @return The list of active hearing participants and their participant type
   */
  @Override
  public HearingParticipantDetailsListForIC listActiveParticipantsIC(
    final HearingKey key) throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    final HearingParticipantDetailsListForIC hearingParticipantDetailsListForIC =
      new HearingParticipantDetailsListForIC();

    // Get the case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      hearingParticipantDetailsListForIC.appealContextDescription.description =
        appealContextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo);

      // assign menu data
      hearingParticipantDetailsListForIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else {
      // Get the context description
      hearingParticipantDetailsListForIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      hearingParticipantDetailsListForIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }
    // END, CR00115728

    hearingParticipantDetailsListForIC.hearingParticipantDetailsListForIC =
      hearingObj.listActiveHearingParticipants(key.hearingKey_bo);

    return hearingParticipantDetailsListForIC;
  }

  // ___________________________________________________________________________
  /**
   * Displays the list of phone numbers for a hearing participant for IC
   * 
   * @param key Unique internal reference number of the hearing and participant
   * @return The list of phone numbers for the hearing participant
   */
  @Override
  public HearingParticipantPhoneNumberList listPhoneNumbersForParticipant(
    final HearingParticipantKey key) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Details to be returned
    final HearingParticipantPhoneNumberList hearingParticipantPhoneNumberListResult =
      new HearingParticipantPhoneNumberList();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey = new HearingKey();

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Get the case id
    hearingKey.hearingKey_bo.hearingKey.hearingID =
      key.hearingParticipantKey.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00124931, LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      hearingParticipantPhoneNumberListResult.appealContextDescription =
        legalActionObj.getContextDescription(caseID);
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey.hearingKey_bo);

      // assign menu data
      hearingParticipantPhoneNumberListResult.appealMenuData = appealMenuData;
    } else {
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      hearingParticipantPhoneNumberListResult.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      hearingParticipantPhoneNumberListResult.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }
    // End CR00124931 LP
    hearingParticipantPhoneNumberListResult.hearingParticipantPhoneNumberList =
      hearingObj.listParticipantPhoneNumbers(key.hearingParticipantKey);

    return hearingParticipantPhoneNumberListResult;
  }

  // ___________________________________________________________________________
  /**
   * Displays the list of phone numbers for a hearing participant
   * 
   * @param key Unique internal reference number of the hearing and participant
   * @return The list of phone numbers for the hearing participant
   */
  @Override
  public HearingParticipantPhoneNumberListNonIC
    listPhoneNumbersForParticipantNonIC(final HearingParticipantKey key)
      throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Details to be returned
    final HearingParticipantPhoneNumberListNonIC hearingParticipantPhoneNumberListNonICResult =
      new HearingParticipantPhoneNumberListNonIC();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey = new HearingKey();

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Register security
    SecurityImplementationFactory.register();

    // Get the case id
    hearingKey.hearingKey_bo.hearingKey.hearingID =
      key.hearingParticipantKey.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // Get the context description
    hearingParticipantPhoneNumberListNonICResult.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    hearingParticipantPhoneNumberListNonICResult.hearingParticipantPhoneNumberListNonIC =
      hearingObj.listParticipantPhoneNumbers(key.hearingParticipantKey);

    return hearingParticipantPhoneNumberListNonICResult;

  }

  // __________________________________________________________________________

  /**
   * Completes a desk based hearing.
   * 
   * @param key Unique internal reference number of the hearing
   */
  @Override
  public void completeDeskHearing(final CompleteDeskHearingDetails key)
    throws AppException, InformationalException {

    // Hearing business object variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.CompleteHearingDetails completeHearingDetails =
      new curam.appeal.sl.struct.CompleteHearingDetails();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;

    // assign hearing details
    completeHearingDetails.completeHearing.assign(key);

    // complete hearing
    hearingObj.complete(completeHearingDetails, hearingAppealTypeCode);

    // END, HARP, 43061

  }

  // ___________________________________________________________________________

  /**
   * Gets the summary details for a Desk-Based hearing.
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return Desk Hearing summary details.
   */
  @Override
  public DeskHearingSummaryDetails getDeskHearingSummaryDetails(
    final HearingKey key) throws AppException, InformationalException {

    // Return details
    final DeskHearingSummaryDetails deskHearingSummaryDetailsReturn =
      new DeskHearingSummaryDetails();

    // HearingCaseID object
    HearingCaseID hearingCaseID;

    // Context Description
    AppealContextDescription appealContextDescription;

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Desk Hearing Summary Details Object
    curam.appeal.sl.struct.DeskHearingSummaryDetails deskHearingSummaryDetails =
      new curam.appeal.sl.struct.DeskHearingSummaryDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    deskHearingSummaryDetails =
      hearingObj.getDeskHearingSummaryDetails(key.hearingKey_bo);

    // Assign the desk hearing details
    deskHearingSummaryDetailsReturn.assign(deskHearingSummaryDetails);

    // Format DateTime to Date
    deskHearingSummaryDetailsReturn.expectedDate =
      new Date(
        deskHearingSummaryDetails.deskHearingSummaryDetails.scheduledDateTime);

    // Get the case ID
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // Get the context description
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);
    deskHearingSummaryDetailsReturn.appealContextDescription =
      appealContextDescription;

    // Get the menu data
    deskHearingSummaryDetailsReturn.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    // Return the details
    return deskHearingSummaryDetailsReturn;
  }

  // ___________________________________________________________________________

  /**
   * Gets the summary details for a Desk-Based hearing on an integrated case.
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return Desk Hearing summary details for an integrated case.
   */
  @Override
  public DeskHearingSummaryDetailsOnIC getDeskHearingSummaryDetailsOnIC(
    final HearingKey key) throws AppException, InformationalException {

    // Return details
    final DeskHearingSummaryDetailsOnIC deskHearingSummaryDetailsOnIC =
      new DeskHearingSummaryDetailsOnIC();

    // Context Description
    AppealContextDescription appealContextDescription;

    // HearingCaseID object
    HearingCaseID hearingCaseID;

    // Hearing object
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Desk Hearing Summary Details Object
    curam.appeal.sl.struct.DeskHearingSummaryDetails deskHearingSummaryDetails =
      new curam.appeal.sl.struct.DeskHearingSummaryDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    deskHearingSummaryDetails =
      hearingObj.getDeskHearingSummaryDetails(key.hearingKey_bo);

    // BEGIN, CR00285747, MC
    // Assign the hearing details
    deskHearingSummaryDetailsOnIC.deskHearingSummaryDetails
      .assign(deskHearingSummaryDetails.deskHearingSummaryDetails);
    deskHearingSummaryDetailsOnIC.deskHearingSummaryDetails.expectedDate =
      new Date(
        deskHearingSummaryDetails.deskHearingSummaryDetails.scheduledDateTime);
    // END, CR00285747

    // Get the case ID
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription contextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      deskHearingSummaryDetailsOnIC.deskHearingSummaryDetails.appealContextDescription.description =
        contextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo);

      // assign menu data
      deskHearingSummaryDetailsOnIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else {
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
      deskHearingSummaryDetailsOnIC.deskHearingSummaryDetails.appealContextDescription =
        appealContextDescription;

      // Get the menu data
      deskHearingSummaryDetailsOnIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }
    // END, CR00115728

    // Return the details
    return deskHearingSummaryDetailsOnIC;
  }

  // Start CR00117296 LP
  /**
   * Lists the active participants in the hearing, for which there
   * can be representatives or witness.
   * 
   * @param key Hearing Key
   * @return List of HearingParticipantDetails
   */
  @Override
  public HearingCaseHearingDetailsList listForHearingCase(
    final curam.appeal.facade.struct.HearingCaseID hearingCaseID)
    throws AppException, InformationalException {

    final HearingCaseHearingDetailsList caseHearingDetailsList =
      new HearingCaseHearingDetailsList();

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.dtls.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.dtls.hearingCaseID.caseID;

      // Get the context description for legal action
      caseHearingDetailsList.pageDescription =
        legalActionObj.getContextDescription(caseID).description;
    } else {
      // Appeal object
      final curam.appeal.sl.intf.Appeal appealObj =
        curam.appeal.sl.fact.AppealFactory.newInstance();
      final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.dtls.hearingCaseID.caseID;
      caseHearingDetailsList.pageDescription =
        appealObj.getContextDescription(appealCaseDetails).description;

    }
    caseHearingDetailsList.dtls =
      HearingFactory.newInstance().listForHearingCase(hearingCaseID.dtls);
    return caseHearingDetailsList;
  }

  /**
   * The method list the all the participants of which a witness or a
   * representative can be added.
   * 
   * @param key Contains the Hearing ID.
   * 
   * @return HearingParticipantDetailsListForIC contains the participant list.
   * 
   * @throws InformationalException and AppException
   */
  @Override
  public HearingParticipantDetailsListForIC listActiveOnBehalfOfParticipants(
    final HearingKey key) throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    final HearingParticipantDetailsListForIC hearingParticipantDetailsListForIC =
      new HearingParticipantDetailsListForIC();

    // Get the case id
    hearingCaseID = hearingObj.getCase(key.hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      hearingParticipantDetailsListForIC.appealContextDescription.description =
        legalActionObj.getContextDescription(caseID).description;
      // Get the menu data for legal action
      hearingParticipantDetailsListForIC.appealMenuData.menuData =
        legalActionObj.readDynamicMenu(key.hearingKey_bo).menuData;
      // END, CR00116551
    } else {
      // Get the context description
      hearingParticipantDetailsListForIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      hearingParticipantDetailsListForIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }
    // END, CR00115728

    hearingParticipantDetailsListForIC.hearingParticipantDetailsListForIC =
      hearingObj.listActiveOnBehalfOfParticipants(key.hearingKey_bo);

    return hearingParticipantDetailsListForIC;
  }
  // End CR00117296 LP
}
