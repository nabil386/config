/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealCaseKey;
import curam.appeal.facade.struct.AppellantKey;
import curam.appeal.facade.struct.CancelAppellantDetails;
import curam.appeal.facade.struct.CreateAppellantDetails;
import curam.appeal.facade.struct.ListAppellantDetailsList;
import curam.appeal.facade.struct.ModifyAppellantDetails;
import curam.appeal.facade.struct.ViewAppellantDetails;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.fact.AppellantFactory;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.core.facade.pdt.struct.InformationalMessageList;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.struct.InformationalMsgDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Appellants
 * facade.
 * 
 */
public abstract class Appellant extends curam.appeal.facade.base.Appellant {

  // BEGIN, CR00021348, RK
  // _________________________________________________________________________
  /**
   * This method acknowledges of the appeal case created to all the appellants
   * who have not received the receipt previously.
   * 
   * @param key identifies appeal case
   */
  @Override
  public void acknowledgeReceipts(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    final curam.appeal.sl.struct.AppealCaseKey appealCaseKey =
      new curam.appeal.sl.struct.AppealCaseKey();

    appealCaseKey.caseID = key.appealCaseKey.caseID;

    // Use the service layer
    appellant.acknowledgeReceipts(appealCaseKey);

  }

  // END, CR00021348

  // BEGIN, CR00267659, MC
  // ___________________________________________________________________________
  /**
   * Method to create an Appellant
   * 
   * @param details The details of the Appellant being created
   * 
   * @return List of Informational messages.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #addAppellantWithInformationalMsgDtlsList()} This method returns an
   * InformationalMessageList informational list. It should
   * return any informationals in an InformationMsgDtlsList. This method is no
   * longer
   * called in the Curam application.
   */
  @Override
  @Deprecated
  public InformationalMessageList addAppellant(
    final CreateAppellantDetails details) throws AppException,
    InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    return appellant.createAppellant(details.addAppDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to create an Appellant
   * 
   * @param details The details of the Appellant being created
   * 
   * @return List of Informational messages.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #addAppellantWithInformationalMsgDtlsList()} This method returns an
   * InformationalMessageList informational list. It should
   * return any informationals in an InformationMsgDtlsList. This method is no
   * longer
   * used in the Curam application.
   */
  @Override
  @Deprecated
  public InformationMsgDtlsList addAppellantWithInformationMsgDtlsList(
    final CreateAppellantDetails details) throws AppException,
    InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Create the appellant and return the messages
    final InformationalMessageList informationalMessageList =
      appellant.createAppellant(details.addAppDetails);

    final InformationalMsgDtls informationalMessage =
      new InformationalMsgDtls();

    // Add each message from the pdt.informationalMessageList to a core
    // informationMsgDtlsList
    for (int i = 0; i < informationalMessageList.dtls.size(); i++) {

      informationalMessage.informationMsgTxt =
        informationalMessageList.dtls.item(i).message;
      informationMsgDtlsList.informationalMsgDtlsList.dtls
        .addRef(informationalMessage);
    }

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to create an Appellant
   * 
   * @param details The details of the Appellant being created
   * 
   * @return List of Informational messages.
   */
  @Override
  public InformationMsgDtlsList addAppellantWithInformationalMsgDtlsList(
    final CreateAppellantDetails details) throws AppException,
    InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Create the appellant and return the messages
    final InformationalMessageList informationalMessageList =
      appellant.createAppellant(details.addAppDetails);

    final InformationalMsgDtls informationalMessage =
      new InformationalMsgDtls();

    // Add each message from the pdt.informationalMessageList to a core
    // informationMsgDtlsList
    for (int i = 0; i < informationalMessageList.dtls.size(); i++) {

      informationalMessage.informationMsgTxt =
        informationalMessageList.dtls.item(i).message;
      informationMsgDtlsList.informationalMsgDtlsList.dtls
        .addRef(informationalMessage);
    }

    return informationMsgDtlsList;
  }

  // END, CR00267659

  // ___________________________________________________________________________
  /**
   * Method to modify an Appellant
   * 
   * @param details The details of the Appellant being modified
   */

  @Override
  public void modifyAppellant(final ModifyAppellantDetails details)
    throws AppException, InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    appellant.updateAppellant(details.updateAppDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to display the list of Appellants
   * 
   * @param key The appeal key
   * 
   * @return The list of appellants
   */
  @Override
  public ListAppellantDetailsList listAppellants(final AppealCaseIDKey key)
    throws AppException, InformationalException {

    // Return object
    final ListAppellantDetailsList listAppellantDetails =
      new ListAppellantDetailsList();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Variable for access to Appellant service layer
    final curam.appeal.sl.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // appeal entity variables
    final Appeal appeal = AppealFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    final AppealKey appealKey = new AppealKey();

    appealKey.appealID = appeal.readAppealIDByCase(key).appealID;

    // Use the service layer
    listAppellantDetails.listAppDtls = appellantObj.listAppellants(appealKey);

    // Get the menu data
    appealCaseDetails.caseID = key.caseID;
    listAppellantDetails.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    return listAppellantDetails;
  }

  // BEGIN, CR00021712, RKi
  // ___________________________________________________________________________
  /**
   * Method to display the list of Appellants
   * 
   * @param key The appeal key
   * 
   * @return The list of appellants
   */
  @Override
  public ListAppellantDetailsList listAppellantsForBS(
    final AppealCaseIDKey key) throws AppException, InformationalException {

    // Return object
    final ListAppellantDetailsList listAppellantDetails =
      new ListAppellantDetailsList();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Variable for access to Appellant service layer
    final curam.appeal.sl.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // appeal entity variables

    final Appeal appeal = AppealFactory.newInstance();

    final AppealKey appealKey = new AppealKey();

    appealKey.appealID = appeal.readAppealIDByCase(key).appealID;

    // Use the service layer
    listAppellantDetails.listAppDtls = appellantObj.listAppellants(appealKey);

    return listAppellantDetails;
  }

  // END, CR00021712

  // ___________________________________________________________________________
  /**
   * Retrieves the appellant details for the specified appellant
   * 
   * @param key Appellant key
   * 
   * @return The appellant details
   */

  @Override
  public ViewAppellantDetails viewAppellant(final AppellantKey key)
    throws AppException, InformationalException {

    // Return object
    final ViewAppellantDetails viewAppellantDetails =
      new ViewAppellantDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // Use the service layer
    viewAppellantDetails.readAppDetails = appellantObj.readAppellant(key.key);

    return viewAppellantDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel an Appellant
   * 
   * @param details The details of the Appellant
   */
  @Override
  public void removeAppellant(final CancelAppellantDetails details)
    throws AppException, InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    appellant.cancelAppellant(details.cancelDtls);

  }

  // ___________________________________________________________________________
  /**
   * This method gets Appeal ID for an appeal case ID
   * 
   * @param key contains details of an Appellant
   * 
   * @return appeal case ID
   */
  @Override
  public AppealKey readAppealIDByAppealCaseID(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Return object
    AppealKey appealKey;

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    appealKey = appellant.readAppealIDByCaseID(key.appealCaseKey);

    return appealKey;
  }

}
