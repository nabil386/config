/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CancelHearingCaseDetails;
import curam.appeal.facade.struct.CancelHearingCaseKey_fo;
import curam.appeal.facade.struct.CancelHearingReviewDetails_fo;
import curam.appeal.facade.struct.CancelHearingReviewKey;
import curam.appeal.facade.struct.CancelJudicialReviewDetails;
import curam.appeal.facade.struct.ModifyCancelCaseDetails;
import curam.appeal.facade.struct.ModifyCancelCaseKey_fo;
import curam.appeal.facade.struct.ReadCancelledCaseDetails;
import curam.appeal.facade.struct.ReadCancelledCaseKey_fo;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Facade object containing methods related to appeal cancellations.
 * 
 */
public abstract class AppealCancellation extends
  curam.appeal.facade.base.AppealCancellation {

  // ___________________________________________________________________________
  /**
   * Presentation layer method to modify appeal cancellation details.
   * 
   * @param details The details of the appeal cancellation
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  public void modify(final ModifyCancelCaseDetails details,
    final ModifyCancelCaseKey_fo key) throws AppException,
    InformationalException {

    // AppealCancellation object
    final curam.appeal.sl.intf.AppealCancellation appealCancellationObj =
      curam.appeal.sl.fact.AppealCancellationFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Modify an appeal cancellation
    appealCancellationObj.modify(key.modifyCancelCaseKey_bo,
      details.modifyCancelCaseDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation Layer method to read the details of a canceled hearing case.
   * 
   * @param key The case cancellation id.
   */
  @Override
  public ReadCancelledCaseDetails read(final ReadCancelledCaseKey_fo key)
    throws AppException, InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // AppealCancellation object
    final curam.appeal.sl.intf.AppealCancellation appealCancellation =
      curam.appeal.sl.fact.AppealCancellationFactory.newInstance();

    // Create return structure
    final ReadCancelledCaseDetails readCancelledCaseDetails =
      new ReadCancelledCaseDetails();

    // Retrieve the hearing representative
    readCancelledCaseDetails.readCancelledCaseDetails =
      appealCancellation.read(key.readCancelledCaseKey_bo);

    // Return the details
    return readCancelledCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to cancel a hearing case.
   * 
   * @param key The key of the appeal cancellation
   * @param details The details of the appeal cancellation
   */
  @Override
  public void cancelHearingCase(final CancelHearingCaseKey_fo key,
    final CancelHearingCaseDetails details) throws AppException,
    InformationalException {

    // AppealCancellation object
    final curam.appeal.sl.intf.AppealCancellation appealCancellationObj =
      curam.appeal.sl.fact.AppealCancellationFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Modify a Hearing Representative
    appealCancellationObj.cancelHearingCase(key.cancelHearingCaseKey_bo,
      details.cancelHearingCaseDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to cancel a hearing review for an appeal.
   * 
   * @param key The key of the appeal cancellation
   * 
   * @param details The details of the appeal cancellation
   */
  @Override
  public void cancelHearingReview(final CancelHearingReviewKey key,
    final CancelHearingReviewDetails_fo details) throws AppException,
    InformationalException {

    // AppealCancellation object
    final curam.appeal.sl.intf.AppealCancellation appealCancellationObj =
      curam.appeal.sl.fact.AppealCancellationFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Modify a Hearing Representative
    appealCancellationObj.cancelHearingReview(key.cancelHearingReviewKey,
      details.cancelHearingReviewDetails);

  }

  // ___________________________________________________________________________
  /**
   * Cancels a Judicial Review appeal case.
   * 
   * @param dtls The judicial review appeal case cancellation details
   */
  @Override
  public void cancelJudicialReview(final CancelJudicialReviewDetails dtls)
    throws AppException, InformationalException {

    // Variables for AppealCancellation
    final curam.appeal.sl.intf.AppealCancellation appealCancellationObj =
      curam.appeal.sl.fact.AppealCancellationFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Use the service layer to cancel the judicial review
    appealCancellationObj.cancelJudicialReview(dtls.cancelAppealDetails);

    // END, HARP, 38654
  }

}
