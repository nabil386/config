/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CancelTranscriptionDetails;
import curam.appeal.facade.struct.CreateTranscriptionDetails;
import curam.appeal.facade.struct.ModifyTranscriptionDetails;
import curam.appeal.facade.struct.ReadTranscriptionDetails;
import curam.appeal.facade.struct.TranscriptionDetailsICList;
import curam.appeal.facade.struct.TranscriptionDetailsList;
import curam.appeal.facade.struct.TranscriptionHearingKey;
import curam.appeal.facade.struct.TranscriptionRequestKey;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.HearingCaseID;
import curam.codetable.CASETYPECODE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Hearing Transcription
 * facade layer.
 * 
 */
public abstract class HearingTranscription extends
  curam.appeal.facade.base.HearingTranscription {

  // __________________________________________________________________________
  /**
   * Method to cancel a hearing transcription request
   * 
   * @param details The details of the transcription request to cancel
   */
  @Override
  public void cancelRequest(final CancelTranscriptionDetails details)
    throws AppException, InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing transcription variables
    final curam.appeal.sl.intf.HearingTranscription hearingTranscriptionObj =
      curam.appeal.sl.fact.HearingTranscriptionFactory.newInstance();

    // cancel hearing transcription
    hearingTranscriptionObj.cancel(details.cancelTranscriptionDetails);

  }

  // __________________________________________________________________________
  /**
   * Method to create a hearing transcription request
   * 
   * @param details The details of the transcription request to create
   */
  @Override
  public void createRequest(final CreateTranscriptionDetails details)
    throws AppException, InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing transcription variables
    final curam.appeal.sl.intf.HearingTranscription hearingTranscriptionObj =
      curam.appeal.sl.fact.HearingTranscriptionFactory.newInstance();

    // create hearing transcription
    hearingTranscriptionObj.create(details.createTranscriptionDetails);

  }

  // __________________________________________________________________________
  /**
   * Method to create a hearing transcription requests for standalone cases
   * 
   * @param key The hearing transcription id of the hearing transcription
   * requests to list
   * 
   * @return list of all hearing transcription requests for a given hearing
   * transcription id
   */
  @Override
  public TranscriptionDetailsList listRequest(
    final TranscriptionHearingKey key) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing transcription variables
    final curam.appeal.sl.intf.HearingTranscription hearingTranscriptionObj =
      curam.appeal.sl.fact.HearingTranscriptionFactory.newInstance();
    final TranscriptionDetailsList transcriptionDetailsList =
      new TranscriptionDetailsList();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingKey hearingKey =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Get the case id
    hearingKey.hearingKey.hearingID = key.transcriptionHearingKey.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // Get the context description
    transcriptionDetailsList.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // BEGIN, CR00088944, RKi
    // list hearing transcription
    for (int i = 0; i < hearingTranscriptionObj
      .list(key.transcriptionHearingKey).listTranscriptionDetails.size(); i++) {

      transcriptionDetailsList.listTranscriptionDetailsList.listTranscriptionDetails
        .addRef(hearingTranscriptionObj.list(key.transcriptionHearingKey).listTranscriptionDetails
          .item(i));
    }
    // END, CR00088944

    // Return the transcription request list
    return transcriptionDetailsList;

  }

  // __________________________________________________________________________
  /**
   * Method to create a hearing transcription requests for integrated cases
   * 
   * @param key The hearing transcription id of the hearing transcription
   * requests to list
   * 
   * @return list of all hearing transcription requests for a given hearing
   * transcription id
   */
  @Override
  public TranscriptionDetailsICList listRequestForIC(
    final TranscriptionHearingKey key) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing transcription variables
    final curam.appeal.sl.intf.HearingTranscription hearingTranscriptionObj =
      curam.appeal.sl.fact.HearingTranscriptionFactory.newInstance();
    final TranscriptionDetailsICList transcriptionDetailsICList =
      new TranscriptionDetailsICList();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingKey hearingKey =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    ;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // BEGIN, CR00088944, RKi
    // list hearing transcription
    for (int i = 0; i < hearingTranscriptionObj
      .list(key.transcriptionHearingKey).listTranscriptionDetails.size(); i++) {

      transcriptionDetailsICList.listTranscriptionDetailsList.listTranscriptionDetails
        .addRef(hearingTranscriptionObj.list(key.transcriptionHearingKey).listTranscriptionDetails
          .item(i));
    }
    // END, CR00088944

    // Get the case id
    hearingKey.hearingKey.hearingID = key.transcriptionHearingKey.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      transcriptionDetailsICList.appealContextDescription.description =
        appealContextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey);

      // assign menu data
      transcriptionDetailsICList.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else { // END, CR00115728
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      transcriptionDetailsICList.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      transcriptionDetailsICList.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }

    // Return the transcription request list
    return transcriptionDetailsICList;

  }

  // __________________________________________________________________________
  /**
   * Method to modify a hearing transcription request
   * 
   * @param details The details of the transcription request to modify
   */
  @Override
  public void modifyRequest(final ModifyTranscriptionDetails details)
    throws AppException, InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing transcription variables
    final curam.appeal.sl.intf.HearingTranscription hearingTranscriptionObj =
      curam.appeal.sl.fact.HearingTranscriptionFactory.newInstance();

    // modify hearing transcription
    hearingTranscriptionObj.modify(details.modifyTranscriptionDetails);

  }

  // __________________________________________________________________________
  /**
   * Method to view a hearing transcription request
   * 
   * @param key The hearing transcription request id of the request we
   * wish to view.
   * 
   * @return readTranscriptionDetails the requested hearing transcription
   * request
   */
  @Override
  public ReadTranscriptionDetails readRequest(
    final TranscriptionRequestKey key) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing transcription variables
    final curam.appeal.sl.intf.HearingTranscription hearingTranscriptionObj =
      curam.appeal.sl.fact.HearingTranscriptionFactory.newInstance();
    final ReadTranscriptionDetails readTranscriptionDetails =
      new ReadTranscriptionDetails();

    // modify hearing transcription
    readTranscriptionDetails.readTranscriptionDetails =
      hearingTranscriptionObj.read(key.transcriptionRequestKey);

    return readTranscriptionDetails;

  }

}
