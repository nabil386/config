/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2008-2009 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.fact.AppealIntegratedCaseFactory;
import curam.appeal.facade.intf.AppealIntegratedCase;
import curam.core.facade.struct.ICProductDeliveryMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

// BEGIN, CR00178052, SK
/**
 * This process class provides the functionality to get the menu data for an
 * Appeal cases.
 * 
 */
public abstract class AppealsMenuData extends
  curam.appeal.facade.base.AppealsMenuData {

  // END, CR00178052

  // ___________________________________________________________________________
  /**
   * Returns the menu data for a case on an integrated case.
   * 
   * @param key
   * Contains the case identifier.
   * 
   * @return Menu data for the case.
   */
  @Override
  public ICProductDeliveryMenuDataDetails getICProductDeliveryMenuData(
    final ICProductDeliveryMenuDataKey key) throws AppException,
    InformationalException {

    // return object
    ICProductDeliveryMenuDataDetails icProductDeliveryMenuDataDetails =
      new ICProductDeliveryMenuDataDetails();

    // appealIntegratedCase object
    final AppealIntegratedCase appealIntegratedCase =
      AppealIntegratedCaseFactory.newInstance();

    // call to get the menu data from appealIntegratedCase.
    icProductDeliveryMenuDataDetails =
      appealIntegratedCase.getICProductDeliveryMenuData(key);

    return icProductDeliveryMenuDataDetails;

  }

}
