/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.appeal.facade.impl;

import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;
import curam.core.facade.fact.IntegratedCaseContextFactory;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.intf.IntegratedCase;
import curam.core.facade.intf.IntegratedCaseContext;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.ICProductDeliveryContextDescription;
import curam.core.facade.struct.ICProductDeliveryContextDescriptionKey;
import curam.core.facade.struct.ICProductDeliveryMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.CodeTableItemIdentifier;

/**
 * This process class is an extension of the facade layer for integrated cases.
 *
 */
public abstract class AppealIntegratedCase
  extends curam.appeal.facade.base.AppealIntegratedCase {

  protected static final String kNavigationMenu =
    GeneralAppealConstants.kDynamicMenu;

  protected static final String kItem = GeneralAppealConstants.kLink;

  protected static final String kDesc = GeneralAppealConstants.kDescription;

  protected static final String kType = GeneralAppealConstants.kType;

  protected static final String kPageID = GeneralAppealConstants.kPageID;

  protected static final String kParamCaseID =
    GeneralAppealConstants.kParamCaseID;

  protected static final String kParamCaseParticipantRoleID =
    GeneralAppealConstants.kParamCaseParticipantRoleID;

  protected static final String kTypePerson =
    GeneralAppealConstants.kTypePerson;

  protected static final String kTypeCase = GeneralAppealConstants.kTypeCase;

  protected static final String kTypeProduct =
    GeneralAppealConstants.kTypeProduct;

  protected static final String kParam = GeneralAppealConstants.kParameter;

  protected static final String kName = GeneralAppealConstants.kName;

  protected static final String kValue = GeneralAppealConstants.kValue;

  /**
   * Generates the context description for a case on an integrated case.
   *
   * @param key Contains the case identifier.
   *
   * @return A context description for the case.
   */
  @Override
  public ICProductDeliveryContextDescription
    getICProductDeliveryContextDescription(
      final ICProductDeliveryContextDescriptionKey key)
      throws AppException, InformationalException {

    // Create the return object
    ICProductDeliveryContextDescription icProductDeliveryContextDescription =
      new ICProductDeliveryContextDescription();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    AppealContextDescription appealContextDescription;

    // register the security implementation
    SecurityImplementationFactory.register();

    caseKey.caseID = key.caseID;

    // BEGIN, CR00303986, SG
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // Call appeal context description method for appeal cases
    if (caseTypeCode.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.APPEAL)) {
      // END, CR00303986

      appealCaseDetails.caseID = key.caseID;
      appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
      icProductDeliveryContextDescription.description =
        appealContextDescription.description;

    } else {

      // Otherwise use the core integrated case context description
      final IntegratedCaseContext integratedCaseContextObj =
        IntegratedCaseContextFactory.newInstance();

      icProductDeliveryContextDescription =
        integratedCaseContextObj.readICProductDeliveryContextDescription(key);

    }

    return icProductDeliveryContextDescription;

  }

  /**
   * Returns the menu data for a case on an integrated case.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu data for the case.
   */
  @Override
  public ICProductDeliveryMenuDataDetails
    getICProductDeliveryMenuData(final ICProductDeliveryMenuDataKey key)
      throws AppException, InformationalException {

    // Create return object
    final ICProductDeliveryMenuDataDetails icProductDeliveryMenuDataDetails =
      new ICProductDeliveryMenuDataDetails();

    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();

    final IntegratedCase integratedCaseObj =
      IntegratedCaseFactory.newInstance();

    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey =
      new CaseIDParticipantRoleKey();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey =
      new CaseParticipantRoleIDKey();

    ParticipantHomePageName participantHomePageName;

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode;
    CaseHomePageNameAndType caseHomePageNameAndType;

    // ProductDelivery manipulation variables
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    AppealMenuData appealMenuData;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Read case type
    caseKey.caseID = key.caseID;
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // Call appeal menu data method for appeal cases
    if (caseTypeCode.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.APPEAL)) {

      appealCaseDetails.caseID = key.caseID;
      appealMenuData = appealObj.getMenuData(appealCaseDetails);
      icProductDeliveryMenuDataDetails.menuData = appealMenuData.menuData;

    } else {

      // Set key to read ProductDelivery
      productDeliveryKey.caseID = key.caseID;

      // Read ProductDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // Set key to read concernRoleName
      concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

      // Read concernRoleName
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // Read productDelivery to retrieve the case home page name and
      // product type
      caseHomePageNameAndType =
        productDeliveryObj.readCaseHomePageNameAndType(caseKey);

      // Read integratedCaseID from caseHeader
      integratedCaseReferenceKey =
        caseHeaderObj.readIntegratedCaseReferenceByCaseID(caseKey);

      // Re-set key with integratedCaseID to read caseHeader
      caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

      // Read caseHeader
      icPageNamesICTypeAndConcernDetails =
        caseHeaderObj.readICPageNamesICTypeAndConcernDetails(caseKey);

      LocalisableString description = new LocalisableString(
        curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

      description.arg(
        new CodeTableItemIdentifier(curam.codetable.PRODUCTCATEGORY.TABLENAME,
          icPageNamesICTypeAndConcernDetails.integratedCaseType));

      description.arg(integratedCaseReferenceKey.caseReference);

      // Create Root Node
      final Element navigationMenuElement = new Element(kNavigationMenu);

      // Create Child Node
      Element linkElement = new Element(kItem);

      linkElement.setAttribute(kPageID,
        icPageNamesICTypeAndConcernDetails.homePageName);
      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      linkElement.setAttribute(kType, kTypeCase);

      navigationMenuElement.addContent(linkElement);

      Element paramElement = new Element(kParam);

      paramElement.setAttribute(kName, kParamCaseID);
      paramElement.setAttribute(kValue,
        String.valueOf(integratedCaseReferenceKey.integratedCaseID));

      linkElement.addContent(paramElement);

      // Create person item child element and add it to the root
      // Populate the caseIDParticipantRoleKey
      caseIDParticipantRoleKey.caseID =
        integratedCaseReferenceKey.integratedCaseID;
      caseIDParticipantRoleKey.participantRoleID =
        productDeliveryDtls.recipConcernRoleID;

      // Read the caseParticipantRoleID
      caseParticipantRoleCaseParticipantRoleID = caseParticipantRole
        .readCaseParticipantRoleID(caseIDParticipantRoleKey);

      caseParticipantRoleIDKey.caseParticipantRoleID =
        caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

      // Get participant home page

      participantHomePageName =
        integratedCaseObj.resolveParticipantHome(caseParticipantRoleIDKey);

      // create link to the participant home page.
      linkElement = new Element(kItem);

      linkElement.setAttribute(kPageID,
        participantHomePageName.participantHomePageName);

      description = new LocalisableString(
        curam.message.BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

      description.arg(concernRoleNameDetails.concernRoleName);

      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      linkElement.setAttribute(kType, kTypePerson);

      navigationMenuElement.addContent(linkElement);

      paramElement = new Element(kParam);

      paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
      paramElement.setAttribute(kValue, Long.toString(
        caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID));

      linkElement.addContent(paramElement);

      paramElement = new Element(kParam);

      paramElement.setAttribute(kName, kParamCaseID);
      paramElement.setAttribute(kValue,
        String.valueOf(integratedCaseReferenceKey.integratedCaseID));

      linkElement.addContent(paramElement);

      // Create product item child element and add it to the root
      linkElement = new Element(kItem);

      linkElement.setAttribute(kPageID,
        caseHomePageNameAndType.caseHomePageName);

      description = new LocalisableString(
        curam.message.BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

      description.arg(
        new CodeTableItemIdentifier(curam.codetable.PRODUCTTYPE.TABLENAME,
          caseHomePageNameAndType.typeCode));

      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      linkElement.setAttribute(kType, kTypeProduct);

      navigationMenuElement.addContent(linkElement);

      paramElement = new Element(kParam);

      paramElement.setAttribute(kName, kParamCaseID);

      paramElement.setAttribute(kValue, Long.toString(key.caseID));

      linkElement.addContent(paramElement);

      // Output the XML as a string and assign it to the return object
      final XMLOutputter outputter = new XMLOutputter();

      icProductDeliveryMenuDataDetails.menuData =
        outputter.outputString(navigationMenuElement);

    }

    return icProductDeliveryMenuDataDetails;

  }

}
