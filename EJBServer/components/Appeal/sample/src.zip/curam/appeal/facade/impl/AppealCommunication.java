/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.sl.fact.AppealCommunicationFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.codetable.CASETYPECODE;
import curam.core.facade.struct.ListProFormaTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListProFormaTemplateByTypeAndParticpant;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.struct.PreviewProFormaKey;
import curam.core.sl.struct.ProFormaCommKey;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.SearchTemplatesKey;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This facade class provides the functionality for the appeal communication.
 */
public abstract class AppealCommunication extends
  curam.appeal.facade.base.AppealCommunication {

  /**
   * Retrieves the list of templates for the specified template type.
   * 
   * @param listProFormaTemplateByTypeAndParticipantKey The type of the template
   * 
   * @return The list of templates for the specified appeal case.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public
    ListProFormaTemplateByTypeAndParticpant
    listTemplatesByCaseTypeAndParticipant(
      final ListProFormaTemplateByTypeAndParticipantKey listProFormaTemplateByTypeAndParticipantKey)
      throws AppException, InformationalException {

    final ListProFormaTemplateByTypeAndParticpant listProFormaTemplateByTypeAndParticpant =
      new ListProFormaTemplateByTypeAndParticpant();

    final SearchTemplatesKey searchTemplatesKey = new SearchTemplatesKey();

    if (CuramConst.gkZero == listProFormaTemplateByTypeAndParticipantKey.participantRoleID
      && CuramConst.gkZero != listProFormaTemplateByTypeAndParticipantKey.caseID) {

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // Set key to read caseHeader to retrieve the concernRoleID
      caseHeaderKey.caseID =
        listProFormaTemplateByTypeAndParticipantKey.caseID;

      listProFormaTemplateByTypeAndParticipantKey.participantRoleID =
        caseHeaderObj.read(caseHeaderKey).concernRoleID;
    }

    // Set key details to retrieve the list of templates
    searchTemplatesKey.concernRoleID =
      listProFormaTemplateByTypeAndParticipantKey.participantRoleID;
    searchTemplatesKey.templateType =
      listProFormaTemplateByTypeAndParticipantKey.templateType;
    searchTemplatesKey.caseID =
      listProFormaTemplateByTypeAndParticipantKey.caseID;

    listProFormaTemplateByTypeAndParticpant.searchTemplatesByConcernAndTypeResult =
      AppealCommunicationFactory.newInstance().listTemplatesByConcernAndType(
        searchTemplatesKey);

    return listProFormaTemplateByTypeAndParticpant;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00390321, JAF
  /**
   * Generates an XML document from the specified XSL template and previews
   * that document for the Appeals component.
   * 
   * @returns ProFormaReturnDocDetails The document details to be previewed.
   * Contains the file and date (Blob fileDate) and the filename (String
   * filename).
   * 
   * @param details This struct contains the information needed to generate a
   * ProForma (creationDate, dataSetType, dataSetPrimaryKey, documentIDCode,
   * and documentVersion).
   * 
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ProFormaReturnDocDetails previewProForma(
    final PreviewProFormaKey previewProFormaKey) throws AppException,
    InformationalException {

    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();
    final curam.core.sl.intf.Communication communicationObj =
      curam.core.sl.fact.CommunicationFactory.newInstance();

    ProFormaReturnDocDetails proFormaReturnDocDetails =
      new ProFormaReturnDocDetails();

    final ProFormaCommKey proFormaCommKey = new ProFormaCommKey();

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    proFormaCommKey.communicationID = previewProFormaKey.communicationID;

    final curam.core.sl.struct.ProFormaCommDetails1 proFormaCommDetails =
      communicationObj.readProForma1(proFormaCommKey);

    caseKey.caseID = proFormaCommDetails.caseID;
    previewProFormaKey.localeIdentifier =
      proFormaCommDetails.localeIdentifier;

    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj =
          curam.serviceplans.facade.fact.ServicePlanDeliveryFactory
            .newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey =
          new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType =
          ServicePlanSecurity.kMaintainSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    }

    // Call service layer method to print a pro forma communication
    proFormaReturnDocDetails =
      appealProFormaDocumentGenerationObj.previewProForma(previewProFormaKey);

    return proFormaReturnDocDetails;
  }
  // END, CR00390321, JAF

}
