/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2006, 2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.core.facade.fact.ProductDeliveryContextFactory;
import curam.core.facade.intf.ProductDeliveryContext;
import curam.core.facade.struct.ProductDeliveryContextDescription;
import curam.core.facade.struct.ProductDeliveryContextDescriptionKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class is an extension of the facade for product deliveries.
 * 
 */
public abstract class AppealProductDelivery extends
  curam.appeal.facade.base.AppealProductDelivery {

  /**
   * Generates the context description for the case.
   * 
   * @param key Context description identifier.
   * 
   * @return A context description for the case.
   */
  @Override
  public ProductDeliveryContextDescription
    getProductDeliveryContextDescription(
      final ProductDeliveryContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create return object
    ProductDeliveryContextDescription productDeliveryContextDescription =
      new ProductDeliveryContextDescription();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    AppealContextDescription appealContextDescription;

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // Call appeal context description method for appeal cases
    if (caseTypeCode.caseTypeCode.equals(curam.codetable.CASETYPECODE.APPEAL)) {
      // END, CR00303986

      appealCaseDetails.caseID = key.caseID;
      appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
      productDeliveryContextDescription.description =
        appealContextDescription.description;

    } else {

      // Variables for getting product delivery context description
      final ProductDeliveryContext productDeliveryContextObj =
        ProductDeliveryContextFactory.newInstance();

      // Delegate to the core facade for non-appeal cases
      productDeliveryContextDescription =
        productDeliveryContextObj.readContextDescription(key);
    }

    return productDeliveryContextDescription;

  }

}
