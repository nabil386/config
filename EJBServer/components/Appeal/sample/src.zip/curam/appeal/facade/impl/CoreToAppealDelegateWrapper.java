/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.fact.AppealCaseFactory;
import curam.appeal.facade.fact.AppealIntegratedCaseFactory;
import curam.appeal.facade.fact.AppealProductDeliveryFactory;
import curam.appeal.facade.intf.AppealCase;
import curam.appeal.facade.intf.AppealIntegratedCase;
import curam.appeal.facade.intf.AppealProductDelivery;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.struct.CaseIDStatusKey;
import curam.appeal.sl.entity.struct.CountActiveAppealsByRoleParticipantIDKey;
import curam.appeal.sl.entity.struct.CountRelatedCasesActiveAppealsByCaseIDKey;
import curam.appeal.sl.fact.AppealConcernRoleDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealMaintainActivityFactory;
import curam.appeal.sl.fact.AppealMaintainUserActivityFactory;
import curam.appeal.sl.fact.AppealSlotAllocationFactory;
import curam.appeal.sl.intf.AppealConcernRoleDocumentGeneration;
import curam.appeal.sl.intf.AppealMaintainActivity;
import curam.appeal.sl.intf.AppealMaintainUserActivity;
import curam.appeal.sl.intf.AppealSlotAllocation;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.facade.struct.ICProductDeliveryContextDescription;
import curam.core.facade.struct.ICProductDeliveryContextDescriptionKey;
import curam.core.facade.struct.ProductDeliveryContextDescription;
import curam.core.facade.struct.ProductDeliveryContextDescriptionKey;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.sl.struct.DetermineWorkItemKey;
import curam.core.sl.struct.UserWorkItemDetails;
import curam.core.struct.ActivityAttendeeStatusDetails;
import curam.core.struct.GetCaseClosureSupplierKey;
import curam.core.struct.GetCaseEventData;
import curam.core.struct.MaintainActivityDetails;
import curam.core.struct.MaintainActivityKey;
import curam.core.struct.ProFormaDocumentData;
import curam.legalaction.entity.fact.LegalActionFactory;
import curam.legalaction.entity.struct.CaseIDAndStatusKey;
import curam.legalaction.entity.struct.CountActiveLegalActionsByParticipantIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * A delegator class responsible for delegating the calls to the corresponding
 * facade operations of the Appeals component.
 */
public class CoreToAppealDelegateWrapper {

  /**
   * Creates an instance of this class.
   * 
   * @return Returns an instance of this class.
   */
  public static CoreToAppealDelegateWrapper newInstance() {

    return new CoreToAppealDelegateWrapper();

  }

  /**
   * Cancels specified user activity.
   * 
   * @param key
   * Identifier for an activity to be canceled.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelUserActivity(final MaintainActivityKey key)
    throws AppException, InformationalException {

    final AppealMaintainUserActivity appealMaintainUserActivityObj =
      AppealMaintainUserActivityFactory.newInstance();

    appealMaintainUserActivityObj.cancelUserActivity(key);
  }

  /**
   * Method to calculate work item duration and number of work units for
   * particular user.
   * 
   * @param determineWorkItemKey
   * Contains work item key to to calculate work item duration and
   * number of work units.
   * 
   * @return Work item duration and number of work units.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public UserWorkItemDetails determineNumberOfUnitsAndDurationForUser(
    final DetermineWorkItemKey determineWorkItemKey) throws AppException,
    InformationalException {

    final AppealSlotAllocation appealSlotAllocationObj =
      AppealSlotAllocationFactory.newInstance();
    final UserWorkItemDetails userWorkItemDetails =
      appealSlotAllocationObj
        .determineNumberOfUnitsAndDurationForUser(determineWorkItemKey);

    return userWorkItemDetails;
  }

  /**
   * Get product type, reason and client data.
   * 
   * @param key
   * Contains the caseID.
   * @param documentData
   * Contains the pro forma document data for printing the
   * communications.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void getCaseClosureClientData(final GetCaseClosureSupplierKey key,
    final ProFormaDocumentData documentData) throws AppException,
    InformationalException {

    final AppealConcernRoleDocumentGeneration appealConcernRoleDocumentGenerationObj =
      AppealConcernRoleDocumentGenerationFactory.newInstance();

    appealConcernRoleDocumentGenerationObj.getCaseClosureClientData(key,
      documentData);
  }

  /**
   * Retrieve the case event data needed to print a communication.
   * 
   * @param key
   * Contains the concernRoleID & caseID.
   * @param documentData
   * Contains the pro forma document data for printing the
   * communications.
   */
  public void getCaseEventData(final GetCaseEventData key,
    final ProFormaDocumentData documentData) throws AppException,
    InformationalException {

    final AppealConcernRoleDocumentGeneration appealConcernRoleDocumentGenerationObj =
      AppealConcernRoleDocumentGenerationFactory.newInstance();

    appealConcernRoleDocumentGenerationObj
      .getCaseEventData(key, documentData);
  }

  /**
   * Generates the context description for a product delivery on an Integrated
   * Case.
   * 
   * @param key
   * Contains the case identifier.
   * 
   * @return A context description for a product delivery.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ICProductDeliveryContextDescription
    getICProductDeliveryContextDescription(
      final ICProductDeliveryContextDescriptionKey key) throws AppException,
      InformationalException {

    final AppealIntegratedCase appealIntegratedCaseObj =
      AppealIntegratedCaseFactory.newInstance();

    final ICProductDeliveryContextDescription icProductDeliveryContextDescription =
      appealIntegratedCaseObj.getICProductDeliveryContextDescription(key);

    return icProductDeliveryContextDescription;

  }

  /**
   * Generates the context description for the Product Delivery.
   * 
   * @param key
   * Contains the case identifier.
   * 
   * @return A context description for a Product Delivery.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProductDeliveryContextDescription
    getProductDeliveryContextDescription(
      final ProductDeliveryContextDescriptionKey key) throws AppException,
      InformationalException {

    final AppealProductDelivery appealProductDeliveryObj =
      AppealProductDeliveryFactory.newInstance();

    final ProductDeliveryContextDescription productDeliveryContextDescription =
      appealProductDeliveryObj.getProductDeliveryContextDescription(key);

    return productDeliveryContextDescription;

  }

  /**
   * Maintains the list of attendees for a specified activity.
   * 
   * @param maintainActivityDetails
   * Contains the activity details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void maintainAttendeesForActivity(
    final MaintainActivityDetails maintainActivityDetails)
    throws AppException, InformationalException {

    final AppealMaintainActivity appealMaintainActivityObj =
      AppealMaintainActivityFactory.newInstance();

    appealMaintainActivityObj
      .maintainAttendeesForActivity(maintainActivityDetails);
  }

  /**
   * Modifies the record status of an attendee record.
   * 
   * @param details
   * Contains the activity details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyActivityAttendeeStatus(
    final ActivityAttendeeStatusDetails details) throws AppException,
    InformationalException {

    final AppealMaintainUserActivity appealMaintainUserActivityObj =
      AppealMaintainUserActivityFactory.newInstance();

    appealMaintainUserActivityObj.modifyActivityAttendeeStatus(details);

  }

  /**
   * Modifies user activity. Ignores activity modification conflicts.
   * 
   * @param details
   * Contains the activity details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyUserActivityIgnoreConflict(
    final MaintainActivityDetails details) throws AppException,
    InformationalException {

    final AppealMaintainUserActivity appealMaintainUserActivityObj =
      AppealMaintainUserActivityFactory.newInstance();

    appealMaintainUserActivityObj.modifyUserActivityIgnoreConflict(details);
  }

  /**
   * Modifies the specified user activity and warns of any conflicts with other
   * activities.
   * 
   * @param details
   * Contains the activity details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyUserActivityWarnConflict(
    final MaintainActivityDetails details) throws AppException,
    InformationalException {

    final AppealMaintainUserActivity appealMaintainUserActivityObj =
      AppealMaintainUserActivityFactory.newInstance();

    appealMaintainUserActivityObj.modifyUserActivityWarnConflict(details);
  }

  /**
   * Method to read the Case context information.
   * 
   * @param caseContextDescriptionKey
   * Contains the caseID.
   * 
   * @return The context description for a case.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseContextDescription readCaseContextDescription(
    final CaseContextDescriptionKey caseContextDescriptionKey)
    throws AppException, InformationalException {

    final AppealCase appealCaseObj = AppealCaseFactory.newInstance();
    final CaseContextDescription caseContextDescription =
      appealCaseObj.readCaseContextDescription(caseContextDescriptionKey);

    return caseContextDescription;

  }

  /**
   * Creates an instance of AppealsMenuData class.
   * 
   * @return Returns an instance of AppealsMenuData class.
   */

  public static curam.appeal.facade.intf.AppealsMenuData newAppealInstance() {

    final curam.appeal.facade.intf.AppealsMenuData result =
      curam.appeal.facade.fact.AppealsMenuDataFactory.newInstance();

    return result;
  }

  // BEGIN, CR00195128, MC
  // __________________________________________________________________________
  /**
   * Gets the Issues and Product Delivery cases associated with the Integrated
   * Case and sees if any of them have active Appeals on them. If active Appeals
   * are found add them to the count that is returned.
   * 
   * @param CountRelatedCasesActiveAppealsByCaseIDKey
   * 
   * @return The number of appeals associated with the Integrated case.
   */
  public static long countRelatedCasesActiveAppealsByCaseID(
    final CaseIDKey caseIDKey) throws AppException, InformationalException {

    final CountRelatedCasesActiveAppealsByCaseIDKey key =
      new CountRelatedCasesActiveAppealsByCaseIDKey();

    key.caseID = caseIDKey.caseID;

    return AppealFactory.newInstance()
      .countRelatedCasesActiveAppealsByCaseID(key).numOfRecords;
  }

  // __________________________________________________________________________
  /**
   * Counts the number of active Appeal cases where the participant has a role
   * of Appellant or Respondent.
   * 
   * @param CountActiveAppealsByRoleParticipantIDKey
   * 
   * @return The number of appeals the participant has a role of "Appellant" or
   * "Respondent".
   */
  public static long countActiveAppealsByRoleParticipantID(
    final ConcernRoleIDKey concernRoleIDKey) throws AppException,
    InformationalException {

    final CountActiveAppealsByRoleParticipantIDKey key =
      new CountActiveAppealsByRoleParticipantIDKey();

    key.participantRoleID = concernRoleIDKey.concernRoleID;

    return AppealFactory.newInstance().countActiveAppealsByRoleParticipantID(
      key).numOfRecords;
  }

  // __________________________________________________________________________
  /**
   * Count the number of active Legal Actions where the participant has a role.
   * 
   * @param CountActiveAppealsByRoleParticipantIDKey
   * 
   * @return The number of active Legal Actions where the participant has a
   * role.
   */
  public static long countActiveLegalActionsByParticipantID(
    final ConcernRoleIDKey concernRoleIDKey) throws AppException,
    InformationalException {

    final CountActiveLegalActionsByParticipantIDKey key =
      new CountActiveLegalActionsByParticipantIDKey();

    key.concernRoleID = concernRoleIDKey.concernRoleID;

    return LegalActionFactory.newInstance()
      .countActiveLegalActionsByParticipantID(key).numberOfRecords;
  }

  // __________________________________________________________________________
  /**
   * Counts the active Legal Actions associated with a case.
   * 
   * @param CaseIDAndStatusKey
   * 
   * @return The number of active Legal Actions where the participant has a
   * role.
   */
  public static long
    countActiveLegalActionsByCaseID(final CaseIDKey caseIDKey)
      throws AppException, InformationalException {

    final CaseIDAndStatusKey key = new CaseIDAndStatusKey();

    key.caseID = caseIDKey.caseID;

    return LegalActionFactory.newInstance().countActiveLegalActionsByCaseID(
      key).numberOfRecords;
  }

  // __________________________________________________________________________
  /**
   * Counts the number of active Appeal cases associated with this case.
   * 
   * @param CaseIDKey The case ID to read the related Appeals for.
   * @return The number of appeals associated with this case.
   */
  public static long countActiveAppealsByCaseID(final CaseIDKey caseIDKey)
    throws AppException, InformationalException {

    final CaseIDStatusKey key = new CaseIDStatusKey();

    key.caseID = caseIDKey.caseID;
    key.recordStatus = RECORDSTATUS.NORMAL;

    return AppealFactory.newInstance().countActiveAppealsByCaseID(key).numOfRecords;

  }
  // END, CR00195128

}
