/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2003-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.appeal.facade.struct.ActiveHearingCaseDetailsList;
import curam.appeal.facade.struct.AddAppealedCaseDetails;
import curam.appeal.facade.struct.AddHearingCaseStatementDetails;
import curam.appeal.facade.struct.AppellantAndRespondentDetails;
import curam.appeal.facade.struct.AppellantAndRespondentReturnDetails;
import curam.appeal.facade.struct.CaseAppealLevelDetails;
import curam.appeal.facade.struct.CaseIDDetails;
import curam.appeal.facade.struct.CaseType;
import curam.appeal.facade.struct.CreateNewHearingCaseDetails;
import curam.appeal.facade.struct.DecisionsForCaseDetailsList;
import curam.appeal.facade.struct.DecisionsForCaseKey;
import curam.appeal.facade.struct.EnterAppellantDetails;
import curam.appeal.facade.struct.EnterAppellantKey;
import curam.appeal.facade.struct.HearingCaseCaseIDKey;
import curam.appeal.facade.struct.HearingCaseDetailsList;
import curam.appeal.facade.struct.HearingCaseDetailsListForIC;
import curam.appeal.facade.struct.HearingCaseModifyDetails;
import curam.appeal.facade.struct.HearingCaseModifyKey;
import curam.appeal.facade.struct.HearingCaseSummaryDetails;
import curam.appeal.facade.struct.HearingCaseSummaryDetailsIC;
import curam.appeal.facade.struct.HearingCaseSummaryDetailsICAndCancelledInd;
import curam.appeal.facade.struct.HearingCaseSummaryKey;
import curam.appeal.facade.struct.ModifyHearingCaseDetails;
import curam.appeal.facade.struct.ParticipantRoleKey;
import curam.appeal.facade.struct.ReadForCreateHearingCaseDetails;
import curam.appeal.facade.struct.ReadForCreateKey;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.CaseIDAppealTypeCode;
import curam.appeal.sl.struct.CreateHearingAndAppealObjectsDetails;
import curam.appeal.sl.struct.DecisionsForImplCaseKey;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.ReadForCreateDetails;
import curam.appeal.sl.struct.ValidateAppealedCaseLevelDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;

/**
 * This process class provides the functionality for the Hearing Case facade.
 * 
 */
public abstract class HearingCase extends
  curam.appeal.facade.base.HearingCase {

  // BEGIN, CR00396484, JAF
  public HearingCase() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00396484, JAF

  // ___________________________________________________________________________
  /**
   * Returns the details of the hearing case home page
   * 
   * @param key
   * The key of the hearing case
   * 
   * @return The details of the hearing case home page
   */
  @Override
  public HearingCaseSummaryDetails readHearingCaseSummary(
    final HearingCaseSummaryKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingCaseSummaryDetails hearingCaseSummaryDetails =
      new HearingCaseSummaryDetails();

    // Context Description
    AppealContextDescription appealContextDescription;

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Get the context description
    appealCaseDetails.caseID = key.hearingCaseSummaryKey.hearingCaseID;
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Assign the details
    hearingCaseSummaryDetails.hearingCaseSummaryDetails =
      hearingCaseObj.readSummary(key.hearingCaseSummaryKey);
    hearingCaseSummaryDetails.appealContextDescription =
      appealContextDescription;

    // Return the details
    return hearingCaseSummaryDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to modify a hearing case
   * 
   * @param details
   * The details of the hearing case being modified
   */
  @Override
  public void modifyHearingCase(final ModifyHearingCaseDetails details)
    throws AppException, InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Update the hearing case
    hearingCaseObj.modifyHearingCase(details.appealModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to read hearing case details for modification
   * 
   * @param key
   * The key of the hearing case being modified
   * 
   * @return The hearing case details
   */
  @Override
  public HearingCaseModifyDetails readHearingCaseForModify(
    final HearingCaseModifyKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingCaseModifyDetails hearingCaseModifyDetails =
      new HearingCaseModifyDetails();

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Read the hearing case
    hearingCaseModifyDetails.hearingCaseModifyDetails =
      hearingCaseObj.readForModify(key.hearingCaseModifyKey);

    return hearingCaseModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Adds a statement to a hearing case
   * 
   * @param details
   * The details of the statement being added
   */
  @Override
  public InformationMsgDtlsList addStatement(
    final AddHearingCaseStatementDetails details) throws AppException,
    InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Add the statement
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingCaseObj.addStatement(details.appealStatementDetails);

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list the hearings for a hearing case
   * 
   * @param key
   * The hearing case ID
   * 
   * @return the list of hearing details
   */

  @Override
  public HearingCaseDetailsList listHearings(final HearingCaseCaseIDKey key)
    throws AppException, InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final HearingCaseDetailsList hearingCaseDetailsList =
      new HearingCaseDetailsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // BEGIN, CR00088944, RKi
    // Retrieve the hearing list
    for (int i = 0; i < hearingCaseObj.listHearings(key.hearingCaseID).HearingCaseHearingDetails
      .size(); i++) {
      hearingCaseDetailsList.hearingCaseHearingDetailsList.HearingCaseHearingDetails
        .addRef(hearingCaseObj.listHearings(key.hearingCaseID).HearingCaseHearingDetails
          .item(i));
    }
    // END, CR00088944

    // Get the context description
    appealCaseDetails.caseID = key.hearingCaseID.caseID;
    hearingCaseDetailsList.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Return the list
    return hearingCaseDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list the hearings for a hearing case
   * 
   * @param key
   * The hearing case ID
   * 
   * @return the list of hearing details
   */
  @Override
  public HearingCaseDetailsListForIC listHearingsForIC(
    final HearingCaseCaseIDKey key) throws AppException,
    InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final HearingCaseDetailsListForIC hearingCaseDetailsListForIC =
      new HearingCaseDetailsListForIC();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the hearing list
    hearingCaseDetailsListForIC.hearingCaseHearingDetailsList =
      hearingCaseObj.listHearings(key.hearingCaseID);

    // Get the context description
    appealCaseDetails.caseID = key.hearingCaseID.caseID;
    hearingCaseDetailsListForIC.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Get the menu data
    appealCaseDetails.caseID = key.hearingCaseID.caseID;
    hearingCaseDetailsListForIC.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    // Return the list
    return hearingCaseDetailsListForIC;
  }

  // ___________________________________________________________________________
  /**
   * This method displays the home page details of a hearing case
   * 
   * @param key
   * Contains the ID of the hearing case
   * 
   * @return The home page details
   */
  @Override
  public HearingCaseSummaryDetailsIC readHearingCaseSummaryForIC(
    final HearingCaseSummaryKey key) throws AppException,
    InformationalException {

    final HearingCaseSummaryDetailsIC hearingCaseSummaryDetailsIC =
      new HearingCaseSummaryDetailsIC();

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();
    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    AppealMenuData appealMenuData = new AppealMenuData();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Get the context description

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.hearingCaseSummaryKey.hearingCaseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = key.hearingCaseSummaryKey.hearingCaseID;
      // Get the context description for legal action
      hearingCaseSummaryDetailsIC.appealContextDescription.description =
        legalActionObj.getContextDescription(caseID).description;
      final HearingKey hearingKey = new HearingKey();

      hearingKey.hearingKey.hearingID =
        key.hearingCaseSummaryKey.hearingCaseID;
      // Get the menu data for legal action
      hearingCaseSummaryDetailsIC.appealMenuData.menuData =
        legalActionObj.readDynamicMenu(hearingKey).menuData;
      // END, CR00116551
    } else {
      // Get the context description
      appealCaseDetails.caseID = key.hearingCaseSummaryKey.hearingCaseID;
      hearingCaseSummaryDetailsIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
      // Get the menu data
      appealMenuData = appealObj.getMenuData(appealCaseDetails);
    }
    // END, CR00115728

    // Assign the details
    hearingCaseSummaryDetailsIC.hearingCaseSummaryDetails =
      hearingCaseObj.readSummary(key.hearingCaseSummaryKey);

    hearingCaseSummaryDetailsIC.appealContextDescription =
      hearingCaseSummaryDetailsIC.appealContextDescription;
    hearingCaseSummaryDetailsIC.appealMenuData = appealMenuData;

    return hearingCaseSummaryDetailsIC;

  }

  // BEGIN, CR00396484, JAF
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END, CR00396484, JAF

  // ___________________________________________________________________________
  /**
   * This method displays the home page details of a hearing case
   * 
   * @param key
   * Contains the ID of the hearing case
   * 
   * @return The home page details
   */
  @Override
  public
    HearingCaseSummaryDetailsICAndCancelledInd
    readHearingCaseSummaryForICAndCancelledInd(final HearingCaseSummaryKey key)
      throws AppException, InformationalException {

    final HearingCaseSummaryDetailsICAndCancelledInd hearingCaseSummaryDetailsICAndCancelledInd =
      new HearingCaseSummaryDetailsICAndCancelledInd();

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    hearingCaseSummaryDetailsICAndCancelledInd
      .assign(readHearingCaseSummaryForIC(key));

    // BEGIN, CR00283115, JAF
    if (hearingCaseObj.readSummary(key.hearingCaseSummaryKey).hearingCaseDetails.hearingCaseStatus
      .equals(CASESTATUS.CANCELED)) {
      hearingCaseSummaryDetailsICAndCancelledInd.hearingCaseSummaryDetails.hearingCaseDetails.isCancelledIndOpt =
        true;
    }
    // END, CR00283115, JAF

    // BEGIN, CR00396484, JAF
    // Populate "Recent Changes" list
    final curam.core.sl.struct.CaseIDKey caseIDKey =
      new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.hearingCaseSummaryKey.hearingCaseID;

    hearingCaseSummaryDetailsICAndCancelledInd.hearingCaseSummaryDetails.transactionLogDetailsList
      .assign(caseTransactionLogProvider.get().readNumberOfTransactions(
        caseIDKey));
    // END, CR00396484, JAF

    return hearingCaseSummaryDetailsICAndCancelledInd;

  }

  // ___________________________________________________________________________
  /**
   * Method to create a hearing case
   * 
   * @param details
   * The details of the hearing case being created
   * 
   * @return Contains the ID of the hearing case
   */
  @Override
  public HearingCaseSummaryKey create(
    final CreateNewHearingCaseDetails details) throws AppException,
    InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // return struct
    final HearingCaseSummaryKey hearingCaseSummaryKey =
      new HearingCaseSummaryKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // When only specifying an appellant for a hearing case then default
    // the appellant type as the claimant.
    if (details.createNewHearingCaseDetails.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode
      .equals("")) {
      details.createNewHearingCaseDetails.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.CLAIMANT;
    }

    hearingCaseSummaryKey.hearingCaseSummaryKey =
      hearingCaseObj.create(details.createNewHearingCaseDetails);

    return hearingCaseSummaryKey;

  }

  // BEGIN, CR00284371, DK
  // ___________________________________________________________________________
  /**
   * Create a hearing case with a delimited list of objects.
   * 
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "1001,AOT1|2001,AOT2|2002,AOT2" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the appeal object interface class.
   * 
   * @param details
   * The details of the hearing case being created including a
   * delimited list of objects.
   * 
   * @return Contains the ID of the hearing case
   */
  @Override
  public HearingCaseSummaryKey createWithAppealObjects(
    final CreateHearingAndAppealObjectsDetails details) throws AppException,
    InformationalException {

    // return struct
    final HearingCaseSummaryKey hearingCaseSummaryKey =
      new HearingCaseSummaryKey();
    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // When only specifying an appellant for a hearing case then default
    // the appellant type as the claimant.
    if (details.dtls.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode
      .isEmpty()) {
      details.dtls.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.CLAIMANT;
    }

    hearingCaseSummaryKey.hearingCaseSummaryKey =
      hearingCaseObj.createWithAppealObjects(details);
    return hearingCaseSummaryKey;

  }

  // END, CR00284371

  // ___________________________________________________________________________
  /**
   * Method to add a hearing case to an appeal
   * 
   * @param details
   * The details of the hearing case being added
   */
  @Override
  public void addAppealedCase(final AddAppealedCaseDetails details)
    throws AppException, InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingCaseObj.addCase(details.addCaseDetails);

  }

  // ___________________________________________________________________________
  /**
   * Takes in appellant details
   * 
   * @param key
   * Contains implCaseID and caseParticipantRole
   * 
   * @return The participantRoleID and indicator of any active appeals
   */
  @Override
  public EnterAppellantDetails enterAppellantDetails(
    final EnterAppellantKey key) throws AppException, InformationalException {

    // HearingCase object
    final curam.appeal.sl.intf.HearingCase hearingCaseObj =
      curam.appeal.sl.fact.HearingCaseFactory.newInstance();

    final EnterAppellantDetails enterAppellantDetails =
      new EnterAppellantDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // call service layer
    enterAppellantDetails.enterAppellantDetails =
      hearingCaseObj.enterAppellantDetails(key.enterAppellantKey);

    return enterAppellantDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists hearing for a hearing case on an integrated case.
   * 
   * @param key
   * The search key for active hearing cases
   * 
   * @return List of hearing case details
   */
  @Override
  public ActiveHearingCaseDetailsList listActiveHearingCases(
    final ParticipantRoleKey key) throws AppException, InformationalException {

    // Variables for getting the active hearing cases for case
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final ActiveHearingCaseDetailsList activeHearingCaseDetailsList =
      new ActiveHearingCaseDetailsList();

    final curam.appeal.sl.struct.ParticipantRoleKey participantRoleKey =
      new curam.appeal.sl.struct.ParticipantRoleKey();

    participantRoleKey.assign(key);

    participantRoleKey.appellantTypeCode = key.appellantTypeCode;
    participantRoleKey.participantRoleID = key.participantRoleID;
    participantRoleKey.appealTypeCode = APPEALTYPE.HEARING;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Delegate to the business logic layer
    activeHearingCaseDetailsList.activeAppealsDetailsList =
      appealObj.listActiveAppealsForParticipantRole(participantRoleKey);

    return activeHearingCaseDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Reads details needed for creating a hearing case.
   * 
   * @param key
   * Contains case id and participantRoleID
   * 
   * @return The Case Reference and the participant's display name
   */
  @Override
  public ReadForCreateHearingCaseDetails readForCreate(
    final ReadForCreateKey key) throws AppException, InformationalException {

    // Variables for reading the details for creating a hearing case
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    ReadForCreateDetails readForCreateDetails;
    final OrganisationKey organisationKey = new OrganisationKey();

    // The return details for creating a hearing case
    final ReadForCreateHearingCaseDetails readForCreateHearingCaseDetails =
      new ReadForCreateHearingCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    readForCreateDetails = appealObj.readForCreate(key.readForCreateKey);
    readForCreateHearingCaseDetails.assign(readForCreateDetails);

    // If the organization is the appellant then the participant details
    // are for the hearing case respondent. Otherwise the participant
    // details
    // for the hearing case appellant.
    if (key.readForCreateKey.appellantTypeCode
      .equals(curam.codetable.APPELLANTTYPE.ORGANIZATION)) {

      // BEGIN, CR00288724, MC
      organisationKey.organisationID = GeneralAppealConstants.kOrganisationID;
      final OrganisationNameAndAddressDetails organisationNameAndAddressDetails =
        OrganisationFactory.newInstance().readNameAndAddress(organisationKey);

      readForCreateHearingCaseDetails.respondentDisplayName =
        readForCreateDetails.displayName;
      readForCreateHearingCaseDetails.appellantDisplayName =
        organisationNameAndAddressDetails.name;
      readForCreateHearingCaseDetails.respondentParticipantRoleID =
        key.readForCreateKey.participantRoleID;
      // END, CR00288724
    } else {

      readForCreateHearingCaseDetails.appellantDisplayName =
        readForCreateDetails.displayName;
      readForCreateHearingCaseDetails.respondentDisplayName =
        GeneralConstants.kEmpty;
      readForCreateHearingCaseDetails.appellantParticipantRoleID =
        key.readForCreateKey.participantRoleID;

    }

    return readForCreateHearingCaseDetails;

  }

  // ___________________________________________________________________________
  /**
   * This method returns the case type for the case selected to add to an
   * existing hearing case. This method also validates if a request for appeal
   * related to the selected case can be appealed to a hearing case; the level
   * validation which can be performed depends on the type of the selected case.
   * 
   * The selected case can be a previously decided appeal case or an original
   * case within the system. Therefore the level of validation which can be
   * performed depends on the type of the selected case. If a prior appeal case
   * is selected then limited validation can be performed as the decision from
   * that appeal case is unknown at this stage. If an implementation case is
   * selected then it must be valid to directly appeal the case to a hearing
   * case.
   * 
   * @param details
   * The caseID of the case selected to add to a hearing case.
   * @return The case type of the selected case.
   */
  @Override
  public CaseType resolveAddCaseSelection(final CaseIDDetails details)
    throws AppException, InformationalException {

    // Variables for resolving the case selection
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseIDAppealTypeCode caseIDAppealTypeCode =
      new CaseIDAppealTypeCode();
    final CaseType caseType = new CaseType();

    // Register the security implementation factory
    SecurityImplementationFactory.register();

    // Resolve the case selected to add to an existing hearing case.
    caseIDAppealTypeCode.caseID = details.caseIDDetails.caseID;
    caseIDAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;
    caseType.caseType =
      appealObj.resolveAddCaseSelection(caseIDAppealTypeCode).caseType;

    return caseType;

  }

  // ___________________________________________________________________________
  /**
   * Gets the appellant and respondent details for the creation of a hearing
   * case.
   * 
   * @param details
   * The appellant and respondent details
   */
  @Override
  public AppellantAndRespondentReturnDetails enterAppellantAndRespondent(
    final AppellantAndRespondentDetails details) throws AppException,
    InformationalException {

    // Appeal Object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final ValidateAppealedCaseLevelDetails validateAppealedCaseLevelDetails =
      new ValidateAppealedCaseLevelDetails();

    // Return details
    final AppellantAndRespondentReturnDetails appellantAndRespondentReturnDetails =
      new AppellantAndRespondentReturnDetails();

    // appellantAndRespondent Details
    final curam.appeal.sl.struct.AppellantAndRespondentDetails appellantAndRespondentDetails =
      new curam.appeal.sl.struct.AppellantAndRespondentDetails();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Validate the level and type of appeal
    validateAppealedCaseLevelDetails.appealTypeCode = APPEALTYPE.HEARING;
    validateAppealedCaseLevelDetails.implCaseID = details.implCaseID;
    validateAppealedCaseLevelDetails.priorAppealCaseID =
      details.priorAppealCaseID;
    appealObj.validateAppealedCaseLevel(validateAppealedCaseLevelDetails);

    appellantAndRespondentDetails.assign(details);
    appellantAndRespondentDetails.appealTypeCode = APPEALTYPE.HEARING;

    appellantAndRespondentReturnDetails.appellantAndRespondentReturnDetails =
      appealObj.enterAppellantAndRespondent(appellantAndRespondentDetails);

    // The facade provides the information for whether or not the appellant
    // and/or
    // respondent is the organization as an indicator. The combination of
    // indicator
    // selections is used to determine the appellant type for an appeal
    // case;
    // therefore convert the selection combination to the appropriate
    // appellant
    // for use by the subsequent appeal case creation steps.
    if (details.appellantOrganizationInd) {
      appellantAndRespondentReturnDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.ORGANIZATION;
    } else {
      appellantAndRespondentReturnDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.CLAIMANT;
    }

    return appellantAndRespondentReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of prior appeal case decisions where the specified case was
   * being appealed.
   * 
   * @param key
   * The case for which to retrieve prior appeal case decisions
   * @return The list of prior appeal case decisions to appeal to a hearing
   * case.
   */
  @Override
  public DecisionsForCaseDetailsList listAppealDecisionsForCase(
    final DecisionsForCaseKey key) throws AppException,
    InformationalException {

    // Variables for getting the list of prior appeal decisions related to
    // the
    // case.
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final DecisionsForImplCaseKey decisionsForImplCaseKey =
      new DecisionsForImplCaseKey();
    final DecisionsForCaseDetailsList decisionsForCaseDetailsList =
      new DecisionsForCaseDetailsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    decisionsForImplCaseKey.caseID = key.caseID;
    decisionsForCaseDetailsList.decisionForImplCaseDetailsList =
      appealObj.listDecisionsForImplementationCase(decisionsForImplCaseKey);

    return decisionsForCaseDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * This method returns whether or not the specified case can be appealed to a
   * hearing case; it also returns whether the appeal can only be the first
   * level of appeal or whether the appeal can be at other levels of appeal.
   * 
   * @param details
   * The case selected for appeal to a hearing case.
   * @return Indicator if case can only be appealed at the first appeal level.
   * Note that a negative value here implies that the case can be
   * appealed at other levels of appeal. Indicator if the case be
   * appealed at the first level at all.
   */
  @Override
  public CaseAppealLevelDetails resolveAppealLevelForCase(
    final CaseIDDetails details) throws AppException, InformationalException {

    // Variables for resolving the appeal level for the case
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseAppealLevelDetails caseAppealLevelDetails =
      new CaseAppealLevelDetails();
    final CaseIDAppealTypeCode caseIDAppealTypeCode =
      new CaseIDAppealTypeCode();

    // Register the security implementation factory
    SecurityImplementationFactory.register();

    // Resolve the appeal level details for appealing the case to a hearing
    // case
    caseIDAppealTypeCode.caseID = details.caseIDDetails.caseID;
    caseIDAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;
    caseAppealLevelDetails.caseAppealLevelDetails =
      appealObj.resolveAppealLevelForCase(caseIDAppealTypeCode);

    return caseAppealLevelDetails;
  }

}
