/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CreateHearingWitnessDetails;
import curam.appeal.facade.struct.HearingIDKeyHW;
import curam.appeal.facade.struct.HearingWitnessIDKey;
import curam.appeal.facade.struct.ModifyHearingWitnessDetails;
import curam.appeal.facade.struct.ModifyHearingWitnessStatus;
import curam.appeal.facade.struct.ReadHearingWitnessDetails;
import curam.appeal.facade.struct.ReadHearingWitnessDetailsList;
import curam.appeal.facade.struct.ReadHearingWitnessDetailsListForIC;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.HearingCaseID;
import curam.codetable.CASETYPECODE;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Hearing Witness
 * facade.
 * 
 */
public abstract class HearingWitness extends
  curam.appeal.facade.base.HearingWitness {

  // ___________________________________________________________________________
  /**
   * Method to create a hearing witness
   * 
   * @param dtls The details of the hearing witness being created
   * @return Any informational messages
   */
  @Override
  public InformationMsgDtlsList createHearingWitness(
    final CreateHearingWitnessDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning informational messages
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing witness variables
    final curam.appeal.sl.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.fact.HearingWitnessFactory.newInstance();

    // create hearing witness object
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingWitnessObj.create(dtls.createHearingWitnessDetails);

    return informationMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Method to modify a hearing witness
   * 
   * @param dtls The details of the hearing witness to modify
   */
  @Override
  public InformationMsgDtlsList modifyHearingWitness(
    final ModifyHearingWitnessDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning informational messages
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing witness variables
    final curam.appeal.sl.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.fact.HearingWitnessFactory.newInstance();

    // Modify hearing witness
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingWitnessObj.modify(dtls.modifyHearingWitnessDetails);

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to view a hearing witness
   * 
   * @param key The details of the hearing witness to view
   */
  @Override
  public ReadHearingWitnessDetails viewHearingWitness(
    final HearingWitnessIDKey key) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing witness variables
    final curam.appeal.sl.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.fact.HearingWitnessFactory.newInstance();
    final ReadHearingWitnessDetails readHearingWitnessDetails =
      new ReadHearingWitnessDetails();

    // Read hearing witness details
    readHearingWitnessDetails.readHearingWitnessDetails =
      hearingWitnessObj.read(key.hearingWitnessIDKey);

    return readHearingWitnessDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to view a hearing witness list
   * 
   * @param key The hearing ID of the hearing witnesses we wish to view
   * 
   * @return readHearingWitnessDetailsListForIC List of hearing witness
   * for a hearing ID for integrated cases
   */
  @Override
  public ReadHearingWitnessDetailsListForIC
    viewHearingWitnessListForICByHearingID(final HearingIDKeyHW key)
      throws AppException, InformationalException {

    // Hearing witness variables
    final curam.appeal.sl.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.fact.HearingWitnessFactory.newInstance();
    ReadHearingWitnessDetailsListForIC readHearingWitnessDetailsListForIC;

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    curam.appeal.sl.struct.HearingKey hearingKey_bo =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      key.hearingIDKeyHW.hearingIDKeyHW.hearingID;

    readHearingWitnessDetailsListForIC =
      new ReadHearingWitnessDetailsListForIC();

    // Get the case id
    hearingKey_bo = new curam.appeal.sl.struct.HearingKey();
    hearingKey_bo.hearingKey.hearingID =
      key.hearingIDKeyHW.hearingIDKeyHW.hearingID;

    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      readHearingWitnessDetailsListForIC.appealContextDescription.description =
        appealContextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey_bo);

      // assign menu data
      readHearingWitnessDetailsListForIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else { // END, CR00115728
      // Get the context description
      readHearingWitnessDetailsListForIC.appealContextDescription =
        appeal_boObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      readHearingWitnessDetailsListForIC.appealMenuData =
        appeal_boObj.getMenuData(appealCaseDetails);
    }

    // Get a listing of hearing witnesses
    readHearingWitnessDetailsListForIC.readHearingWitnessDetailsList =
      hearingWitnessObj.list(key.hearingIDKeyHW);

    return readHearingWitnessDetailsListForIC;

  }

  // ___________________________________________________________________________
  /**
   * Method to view a hearing witness list
   * 
   * @param key The hearing ID of the hearing witnesses we wish to view
   * 
   * @return readHearingWitnessDetailsList List of hearing witness
   * for a hearing ID
   */
  @Override
  public ReadHearingWitnessDetailsList viewHearingWitnessListByHearingID(
    final HearingIDKeyHW key) throws AppException, InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing witness variables
    final curam.appeal.sl.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.fact.HearingWitnessFactory.newInstance();
    ReadHearingWitnessDetailsList readHearingWitnessDetailsList;

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    curam.appeal.sl.struct.HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    AppealCaseDetails appealCaseDetails;

    readHearingWitnessDetailsList = new ReadHearingWitnessDetailsList();

    // Get the case id
    hearingKey_bo = new curam.appeal.sl.struct.HearingKey();
    hearingKey_bo.hearingKey.hearingID =
      key.hearingIDKeyHW.hearingIDKeyHW.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);
    appealCaseDetails = new AppealCaseDetails();
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // Get the context description
    readHearingWitnessDetailsList.appealContextDescription =
      appeal_boObj.getContextDescription(appealCaseDetails);

    // Get the list of hearing witnesses
    readHearingWitnessDetailsList.readHearingWitnessDetailsList =
      hearingWitnessObj.list(key.hearingIDKeyHW);

    return readHearingWitnessDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Method to cancel a hearing witness
   * 
   * @param dtls The details of the hearing witness we wish to cancel
   */
  @Override
  public void cancelHearingWitness(final ModifyHearingWitnessStatus dtls)
    throws AppException, InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing witness variables
    final curam.appeal.sl.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.fact.HearingWitnessFactory.newInstance();

    // Cancel the hearing witness
    hearingWitnessObj.cancel(dtls.modifyHearingWitnessStatus);
  }
}
