/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.ClauseContextDescription;
import curam.appeal.facade.struct.ClauseKey;
import curam.appeal.facade.struct.ClauseListByCategoryDetailsList;
import curam.appeal.facade.struct.ClauseListByCategoryKey;
import curam.appeal.facade.struct.CreateClauseKey;
import curam.appeal.facade.struct.ListClauseDetails;
import curam.appeal.facade.struct.ModifyClauseDetails;
import curam.appeal.facade.struct.ReadForModifyClauseDetails;
import curam.appeal.facade.struct.ReadForViewClauseDetails;
import curam.appeal.facade.struct.RemoveClauseKey;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This business process class provides the facade layer for administration of
 * standard clauses used in decision texts
 */
public abstract class Clause extends curam.appeal.facade.base.Clause {

  /**
   * Create a new Clause
   * 
   * @param key The details of the new Clause
   */
  @Override
  public void create(final CreateClauseKey key) throws AppException,
    InformationalException {

    // Business Process Object for Clause Service Layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use Service Layer to create the Clause
    clauseObj.create(key.createClauseDetails);
  }

  /**
   * Gets the context description for clause administration pages
   * 
   * @param key The unique identifier for the clause
   * 
   * @return The context description of the clause
   */
  @Override
  public ClauseContextDescription getContextDescription(final ClauseKey key)
    throws AppException, InformationalException {

    // Return variable
    final ClauseContextDescription clauseContextDescription =
      new ClauseContextDescription();

    // Business process object for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the clause name as the context description for the clause
    clauseContextDescription.contextDescription =
      clauseObj.getName(key.clauseKey).clauseContractTextName.clauseName;

    return clauseContextDescription;
  }

  /**
   * List all clauses
   * 
   * @return The list of all clauses
   */
  @Override
  public ListClauseDetails list() throws AppException, InformationalException {

    // Return variable
    final ListClauseDetails listClauseDetails = new ListClauseDetails();

    // Business process object for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use service layer to get list of all clauses
    listClauseDetails.listClauseDetails = clauseObj.list();

    return listClauseDetails;
  }

  /**
   * List all clauses within one category
   * 
   * @param key The category for which to search
   * 
   * @return The list of clauses in this category
   */
  @Override
  public ClauseListByCategoryDetailsList listByCategory(
    final ClauseListByCategoryKey key) throws AppException,
    InformationalException {

    // Return Variable
    final ClauseListByCategoryDetailsList clauseListByCategoryDetailsList =
      new ClauseListByCategoryDetailsList();

    // Business process object for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use service layer to get list of clauses in this category
    clauseListByCategoryDetailsList.clauseListByCategoryDetailsList =
      clauseObj.listByCategory(key.clauseListByCategoryKey);

    return clauseListByCategoryDetailsList;
  }

  /**
   * Modifies the details of a clause
   * 
   * @param details The modified details for the clause
   */
  @Override
  public void modify(final ModifyClauseDetails details) throws AppException,
    InformationalException {

    // Business process object for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use service layer to modify the clause
    clauseObj.modify(details.modifyClauseDetails);
  }

  /**
   * Reads the details of a clause; facade for the viewClause page
   * 
   * @param key The unique identifier for the clause
   * 
   * @return The details of the clause
   */
  @Override
  public ReadForViewClauseDetails readForView(final ClauseKey key)
    throws AppException, InformationalException {

    // Return variable
    final ReadForViewClauseDetails readForViewClauseDetails =
      new ReadForViewClauseDetails();

    // Variables for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use service layer to read the clause details
    readForViewClauseDetails.readForViewClauseDetails =
      clauseObj.readForView(key.clauseKey);

    // Use facade to get context description
    readForViewClauseDetails.clauseContextDescription
      .assign(getContextDescription(key));

    return readForViewClauseDetails;
  }

  /**
   * Reads the details of a clause before modification
   * 
   * @param key The unique identifier for the clause
   * 
   * @return The details of the clause before modification
   */
  @Override
  public ReadForModifyClauseDetails readForModify(final ClauseKey key)
    throws AppException, InformationalException {

    // Return Variable
    final ReadForModifyClauseDetails readForModifyClauseDetails =
      new ReadForModifyClauseDetails();

    // Variables for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer to read the clause details
    readForModifyClauseDetails.readClauseDetails =
      clauseObj.read(key.clauseKey);

    return readForModifyClauseDetails;
  }

  /**
   * Removes the clause from active status
   * 
   * @param key The unique identifier for the clause
   */
  @Override
  public void remove(final RemoveClauseKey key) throws AppException,
    InformationalException {

    // Business process object for Clause service layer
    final curam.appeal.sl.intf.Clause clauseObj =
      curam.appeal.sl.fact.ClauseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer to remove the clause
    clauseObj.remove(key.removeClauseDetails);
  }

}
