/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.fact.AppealsMenuDataFactory;
import curam.codetable.CASETYPECODE;
import curam.core.impl.ProductHookManager;
import curam.core.impl.ProductHookRegistrar;

/**
 * This class registers the Appeals hooks for various functionalities which
 * are defined in the ProductHookRegistrar.
 */
public abstract class AppealsProductRegistrar extends
  curam.appeal.facade.base.AppealsProductRegistrar implements
  ProductHookRegistrar {

  // ___________________________________________________________________________
  /**
   * This method adds details of the Appeals menu hook to use
   * for creating menu data.
   */
  @Override
  public void registerMenuDataHooks() {

    final ProductHookRegistrar.HookMap hookMap =
      ProductHookManager.getMenuDataHookMap();

    hookMap.addMapping(CASETYPECODE.APPEAL, AppealsMenuDataFactory.class);

  }

  // ___________________________________________________________________________
  /**
   * This method adds details of the case rules attribution hook to use
   * for creating case rules.
   */
  @Override
  public void registerCaseRulesAttributionHooks() {// TODO Auto-generated method
                                                   // stub

  }

  // ___________________________________________________________________________
  /**
   * This method adds details of the case start date validation menu hook to use
   * for creating case start date.
   */
  @Override
  public void registerCaseStartDateValidationHooks() {// TODO Auto-generated
                                                      // method stub

  }

  // ___________________________________________________________________________
  /**
   * This method adds details of the decision review hook to use
   * for creating decision review.
   */
  @Override
  public void registerDecisionReviewHooks() {// TODO Auto-generated method stub

  }

  // BEGIN, CR00225596, SK
  @Override
  public void registerApplyChangesHooks() {// TODO Auto-generated method stub

  }
  // END, CR00225596
}
