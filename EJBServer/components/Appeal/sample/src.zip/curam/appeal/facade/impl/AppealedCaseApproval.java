/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealedCaseApproveDetails;
import curam.appeal.facade.struct.AppealedCaseRejectionDetails;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the AppealedCaseApproval
 * facade layer.
 * 
 */
public abstract class AppealedCaseApproval extends
  curam.appeal.facade.base.AppealedCaseApproval {

  // ___________________________________________________________________________
  /*
   * Approves the inclusion of an appealed case for an appeal case.
   * 
   * @param dtls The details of the appealed case approval.
   */
  @Override
  public void approve(final AppealedCaseApproveDetails dtls)
    throws AppException, InformationalException {

    // Appealed Case Approval variables
    final curam.appeal.sl.intf.AppealedCaseApproval appealedCaseApprovalObj =
      curam.appeal.sl.fact.AppealedCaseApprovalFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    appealedCaseApprovalObj.approve(dtls.appealedCaseApproveDetails);

  }

  // ____________________________________________________________________________
  /*
   * Rejects the inclusion of an appealed case for an appeal case.
   * 
   * A rejection can be selected as final which results in the appealed case not
   * being considered as part of the appeal case.
   * 
   * @param dtls The detail of the appealed case rejection including whether or
   * the finality of the rejection.
   */
  @Override
  public void reject(final AppealedCaseRejectionDetails dtls)
    throws AppException, InformationalException {

    // Appealed Case Approval variables
    final curam.appeal.sl.intf.AppealedCaseApproval appealedCaseApprovalObj =
      curam.appeal.sl.fact.AppealedCaseApprovalFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    appealedCaseApprovalObj.reject(dtls.appealedCaseRejectionDetails);

  }

}
