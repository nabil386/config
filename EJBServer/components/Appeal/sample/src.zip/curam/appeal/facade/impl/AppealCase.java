/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007, 2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.codetable.CASETYPECODE;
import curam.core.facade.fact.CaseContextFactory;
import curam.core.facade.intf.CaseContext;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class is an extension of the case process from the facade layer.
 * 
 */
public abstract class AppealCase extends curam.appeal.facade.base.AppealCase {

  // ___________________________________________________________________________
  /**
   * Generates the context description for a case .
   * 
   * @param caseContextDescriptionKey Contains the case identifier.
   * 
   * @return A context description for the case.
   */
  @Override
  public CaseContextDescription readCaseContextDescription(
    final CaseContextDescriptionKey caseContextDescriptionKey)
    throws AppException, InformationalException {

    // Create the return object
    CaseContextDescription caseContextDescription =
      new CaseContextDescription();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    AppealContextDescription appealContextDescription;

    // register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseContextDescriptionKey.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // Call appeal context description method for appeal cases
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
      // END, CR00303986

      appealCaseDetails.caseID = caseContextDescriptionKey.caseID;
      appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
      caseContextDescription.description =
        appealContextDescription.description;

    } else {

      // Otherwise use the core case context description object
      final CaseContext caseContextObj = CaseContextFactory.newInstance();

      caseContextDescription =
        caseContextObj.readContextDescription(caseContextDescriptionKey);
    }

    return caseContextDescription;

  }
}
