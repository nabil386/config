/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CancelDecisionAttachmentDetails;
import curam.appeal.facade.struct.CreateDecisionAttachmentDetails;
import curam.appeal.facade.struct.CreateInternalAttachmentDetails;
import curam.appeal.facade.struct.DecisionAttachmentForModifyDetails;
import curam.appeal.facade.struct.DecisionAttachmentKey;
import curam.appeal.facade.struct.DecisionAttachmentSummaryDetails;
import curam.appeal.facade.struct.MSWordAttachmentDetails;
import curam.appeal.facade.struct.MSWordTemplateAndDocumentDetails;
import curam.appeal.facade.struct.ModifyDecisionAttachmentDetails;
import curam.appeal.facade.struct.ReadForDownloadDetails;
import curam.appeal.sl.fact.AppealCommunicationFactory;
import curam.appeal.sl.fact.DecisionAttachmentFactory;
import curam.appeal.sl.intf.AppealCommunication;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This business process class manages the attachments for an appeal decision.
 */
public abstract class DecisionAttachment extends
  curam.appeal.facade.base.DecisionAttachment {

  // ___________________________________________________________________________
  /**
   * Creates an external decision attachment.
   * 
   * @param details The decision attachment creation details.
   */
  @Override
  public void createExternal(final CreateDecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // Service layer process object
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Delegate to service layer process
    decisionAttachmentObj
      .createExternal(details.createDecisionAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Creates an internal decision attachment.
   * 
   * @param details The decision attachment creation details.
   * @return The identifier for the hearing decision attachment.
   */
  @Override
  public DecisionAttachmentKey createMSWord(
    final CreateInternalAttachmentDetails details) throws AppException,
    InformationalException {

    // Return variable
    final DecisionAttachmentKey decisionAttachmentKey =
      new DecisionAttachmentKey();

    // Service layer process object
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Create the Microsoft Word attachment
    decisionAttachmentKey.decisionAttachmentKey =
      decisionAttachmentObj
        .createMSWord(details.createInternalAttachmentDetails);

    return decisionAttachmentKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an appeal decision attachment where an external document has been
   * attached.
   * 
   * @param details The decision attachment details for modification
   */
  @Override
  public void modifyExternal(final ModifyDecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // Business Process Object for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Ask the Decision Attachment service layer to modify
    // the external attachment
    decisionAttachmentObj
      .modifyExternal(details.modifyDecisionAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of an internally created decision attachment
   * Microsoft Word document.
   * 
   * @param details The Microsoft Word document details.
   */
  @Override
  public void modifyMSWord(final MSWordAttachmentDetails details)
    throws AppException, InformationalException {

    // Business Process Object for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Ask the Decision Attachment service layer to modify
    // the internal attachment
    decisionAttachmentObj.modifyMSWord(details.internalAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a decision attachment where an external
   * document was attached.
   * 
   * @param key The identifier for the decision attachment to read.
   * @return The details of the externally generated attachment
   */
  @Override
  public DecisionAttachmentSummaryDetails readExternal(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return Variable
    final DecisionAttachmentSummaryDetails decisionAttachmentSummaryDetails =
      new DecisionAttachmentSummaryDetails();

    // Business Process Object for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Ask the Decision Attachment service layer to read the decision attachment
    decisionAttachmentSummaryDetails.decisionAttachmentSummaryDetails =
      decisionAttachmentObj.readExternal(key.decisionAttachmentKey);

    return decisionAttachmentSummaryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details, required for modification, for a decision attachment
   * where an external document has been attached.
   * 
   * @param key The identifier for the decision attachment to read.
   * @return The details of the external attachment to be modified
   */
  @Override
  public DecisionAttachmentForModifyDetails readForModifyExternal(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return Variable
    final DecisionAttachmentForModifyDetails decisionAttachmentForModifyDetails =
      new DecisionAttachmentForModifyDetails();

    // Business Process Object for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Ask the Decision Attachment service layer to read the decision attachment
    // for modification
    decisionAttachmentForModifyDetails.decisionAttachmentForModifyDetails =
      decisionAttachmentObj.readForModifyExternal(key.decisionAttachmentKey);

    return decisionAttachmentForModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details of for an internally created word document. Returns
   * the template data for the word document and the current contents of the
   * word document.
   * 
   * @param key The decision attachment identifier for which to read the
   * document template and data details.
   * 
   * @return The details for the internally created attachment.
   * 
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public curam.appeal.facade.struct.MSWordTemplateAndDocumentDetails
    readMSWordTemplateAndDocument(final DecisionAttachmentKey key)
      throws AppException, InformationalException {

    // Variable for return object
    final MSWordTemplateAndDocumentDetails msWordTemplateAndDocumentDetails =
      new MSWordTemplateAndDocumentDetails();

    // Variable for Appeal Communication service layer
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();

    // Variables for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use Appeal Communication service layer to get the details
    msWordTemplateAndDocumentDetails.wordTemplateDocumentAndDataDetails =
      appealCommunicationObj
        .getWordTemplateDocumentAndData(key.decisionAttachmentKey.hearingDecisionAttachmentLinkKey);

    // Use Decision Attachment service layer to get the date and status
    msWordTemplateAndDocumentDetails.attachmentDateStatusAndTemplate =
      decisionAttachmentObj
        .readDateStatusAndTemplate(key.decisionAttachmentKey);

    return msWordTemplateAndDocumentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a decision attachment.
   * 
   * @param details The details for canceling a decision attachment
   */
  @Override
  public void cancel(final CancelDecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // Business Process Object for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Ask the Decision Attachment service layer to cancel the attachment
    decisionAttachmentObj.cancel(details.cancelDecisionAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of an attachment to be downloaded.
   * 
   * @param key The identifier for the decision attachment to download.
   * 
   * @return The details of the decision attachment.
   */
  @Override
  public ReadForDownloadDetails readForDownload(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return variable
    final ReadForDownloadDetails readForDownloadDetails =
      new ReadForDownloadDetails();

    // Business Process Object for Decision Attachment service layer
    final curam.appeal.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Delegate to the service layer
    readForDownloadDetails.readForDownloadDetails =
      decisionAttachmentObj.readForDownload(key.decisionAttachmentKey);

    return readForDownloadDetails;
  }
}
