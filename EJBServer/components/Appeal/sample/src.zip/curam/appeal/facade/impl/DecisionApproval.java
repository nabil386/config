/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.DecisionRejectionCaseKey_fo;
import curam.appeal.facade.struct.DecisionRejectionDetails;
import curam.appeal.facade.struct.DecisionRejectionICListDetails;
import curam.appeal.facade.struct.DecisionRejectionKey;
import curam.appeal.facade.struct.DecisionRejectionListDetails;
import curam.appeal.facade.struct.DecisionRejectionReasonDetails;
import curam.appeal.facade.struct.HearingDecisionVersionKey;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Decision Approval
 * facade.
 * 
 */
public abstract class DecisionApproval extends
  curam.appeal.facade.base.DecisionApproval {

  // ___________________________________________________________________________
  /**
   * This method retrieves a list of decision rejections
   * 
   * @param key Identifies the case
   */
  @Override
  public DecisionRejectionListDetails listRejectionReason(
    final DecisionRejectionCaseKey_fo key) throws AppException,
    InformationalException {

    // Return details
    final DecisionRejectionListDetails decisionRejectionListDetails =
      new DecisionRejectionListDetails();

    // AppealContextDescription manipulation variables
    AppealContextDescription appealContextDescription;
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // DecisionApproval object
    final curam.appeal.sl.intf.DecisionApproval decisionApprovalObj =
      curam.appeal.sl.fact.DecisionApprovalFactory.newInstance();
    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    decisionRejectionListDetails.decisionRejectionListDetails =
      decisionApprovalObj
        .listRejectionReason(key.decisionRejectionCaseKey_bo);

    appealCaseDetails.caseID =
      key.decisionRejectionCaseKey_bo.decisionRejectionCaseKey.caseID;

    // Get the context description
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    decisionRejectionListDetails.appealContextDescription =
      appealContextDescription;

    return decisionRejectionListDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method returns decision rejections details
   * 
   * @param key Identifies the decision rejection
   */
  @Override
  public DecisionRejectionReasonDetails readRejectionReason(
    final DecisionRejectionKey key) throws AppException,
    InformationalException {

    // Return details
    final DecisionRejectionReasonDetails decisionRejectionReasonDetails =
      new DecisionRejectionReasonDetails();

    // DecisionApproval object
    final curam.appeal.sl.intf.DecisionApproval decisionApprovalObj =
      curam.appeal.sl.fact.DecisionApprovalFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Get the rejection details
    decisionRejectionReasonDetails.decisionRejectionReasonDetails =
      decisionApprovalObj.readRejectionReason(key.decisionRejectionKey);

    // Return the details
    return decisionRejectionReasonDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method enables the user to reject a decision
   * 
   * @param details The details of the decision to be rejected
   */
  @Override
  public void rejectDecision(final DecisionRejectionDetails details)
    throws AppException, InformationalException {

    // DecisionApproval object
    final curam.appeal.sl.intf.DecisionApproval decisionApprovalObj =
      curam.appeal.sl.fact.DecisionApprovalFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Reject the decision
    decisionApprovalObj.reject(details.decisionRejectionDetails);
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of rejection reasons
   * 
   * @param key Contains the caseID
   */
  @Override
  public DecisionRejectionICListDetails listRejectionReasonForIC(
    final DecisionRejectionCaseKey_fo key) throws AppException,
    InformationalException {

    final DecisionRejectionICListDetails decisionRejectionICListDetails =
      new DecisionRejectionICListDetails();

    // DecisionApproval object
    final curam.appeal.sl.intf.DecisionApproval decisionApprovalObj =
      curam.appeal.sl.fact.DecisionApprovalFactory.newInstance();
    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // AppealContextDescription manipulation variables
    AppealContextDescription appealContextDescription;
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Menu data
    AppealMenuData appealMenuData;

    // register the security implementation
    SecurityImplementationFactory.register();

    decisionRejectionICListDetails.decisionRejectionListDetails =
      decisionApprovalObj
        .listRejectionReason(key.decisionRejectionCaseKey_bo);

    appealCaseDetails.caseID =
      key.decisionRejectionCaseKey_bo.decisionRejectionCaseKey.caseID;

    // Get the context description
    appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Get the menu data
    appealMenuData = appealObj.getMenuData(appealCaseDetails);

    // Assign the details to the return struct
    decisionRejectionICListDetails.appealMenuData = appealMenuData;
    decisionRejectionICListDetails.appealContextDescription =
      appealContextDescription;

    // Return the details
    return decisionRejectionICListDetails;
  }

  // ___________________________________________________________________________
  /**
   * Approves a hearing decision.
   * 
   * @param details The decision approval details.
   */
  @Override
  public void approve(final HearingDecisionVersionKey details)
    throws AppException, InformationalException {

    // DecisionApproval object
    final curam.appeal.sl.intf.DecisionApproval decisionApprovalObj =
      curam.appeal.sl.fact.DecisionApprovalFactory.newInstance();
    final curam.appeal.sl.struct.AppealDecisionVersionDetails appealDecisionVersionDetails =
      new curam.appeal.sl.struct.AppealDecisionVersionDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Set the key
    appealDecisionVersionDetails.hearingDecisionVersionKey =
      details.hearingDecisionVersionKey;

    // Approve the decision
    decisionApprovalObj.approve(appealDecisionVersionDetails);
  }

  // ___________________________________________________________________________
  /**
   * Submits a decision for approval. If the user has sufficient privileges
   * then the decision is automatically approved; otherwise the decision must
   * be manually approved by a user with the appropriate approval privileges.
   * 
   * @param details The decision submission details.
   */
  @Override
  public void submit(final HearingDecisionVersionKey details)
    throws AppException, InformationalException {

    // DecisionApproval object
    final curam.appeal.sl.intf.DecisionApproval decisionApprovalObj =
      curam.appeal.sl.fact.DecisionApprovalFactory.newInstance();
    final curam.appeal.sl.struct.AppealDecisionVersionDetails appealDecisionVersionDetails =
      new curam.appeal.sl.struct.AppealDecisionVersionDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Set the key
    appealDecisionVersionDetails.hearingDecisionVersionKey =
      details.hearingDecisionVersionKey;

    // Submit the decision for approval
    decisionApprovalObj.submit(appealDecisionVersionDetails);
  }

}
