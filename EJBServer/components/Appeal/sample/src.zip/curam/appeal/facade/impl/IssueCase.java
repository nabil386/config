/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006-2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CaseRefIssueRefConcernRoleID;
import curam.appeal.facade.struct.IssueCaseRelatedCaseConcernDtlsList;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Appeals Issue Case
 * facade layer.
 * 
 */
public class IssueCase extends curam.appeal.facade.base.IssueCase {

  // BEGIN, CR00022056, DK

  // ___________________________________________________________________________
  /**
   * Performs a search for issue cases using the search criteria provided.
   * 
   * @param key
   * Search criteria for the issue case search
   * @return List of issue cases for the search criteria specified.
   */
  @Override
  public IssueCaseRelatedCaseConcernDtlsList searchIssueCases(
    final CaseRefIssueRefConcernRoleID key) throws AppException,
    InformationalException {

    // Register the security implementation
    SecurityImplementationFactory.register();

    final IssueCaseRelatedCaseConcernDtlsList issueCaseRelatedCaseConcernDtlsList =
      new IssueCaseRelatedCaseConcernDtlsList();
    final curam.appeal.sl.intf.IssueCase issueCaseObj =
      curam.appeal.sl.fact.IssueCaseFactory.newInstance();

    // Invoke the service layer method to search issue cases.
    issueCaseRelatedCaseConcernDtlsList.dtlsList =
      issueCaseObj.searchIssueCases(key.key);

    return issueCaseRelatedCaseConcernDtlsList;
  }
  // END, CR00022056

}
