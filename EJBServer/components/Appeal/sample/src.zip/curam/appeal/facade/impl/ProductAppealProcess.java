/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealStageAndProduct;
import curam.appeal.facade.struct.AppealStageDetails;
import curam.appeal.facade.struct.AppealStageIDVersionNo;
import curam.appeal.facade.struct.CreateStageDetails;
import curam.appeal.facade.struct.ModifyAppealStage;
import curam.appeal.facade.struct.ProcessAndStageDetails;
import curam.appeal.facade.struct.ProcessDetailsList;
import curam.appeal.facade.struct.ProcessIDAndVersionNo;
import curam.appeal.facade.struct.ProductAppealProcessAndProduct;
import curam.appeal.facade.struct.ProductID;
import curam.appeal.facade.struct.ProductIDStartDate;
import curam.core.fact.ProductFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.Product;
import curam.core.struct.ProductKey;
import curam.core.struct.ProductNameStructRef;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Provides the facade functionality for maintaining and accessing product
 * appeal process definitions for a Product.
 */

public abstract class ProductAppealProcess extends
  curam.appeal.facade.base.ProductAppealProcess {

  // ___________________________________________________________________________
  /**
   * Cancels a product appeal process
   * 
   * @param details The details to cancel a product appeal process.
   */
  @Override
  public void cancel(final ProcessIDAndVersionNo details)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Service Layer to cancel the Product Appeal Process.
    productAppealProcessObj.cancel(details.processIDAndVersionNo);

  }

  // ___________________________________________________________________________
  /**
   * Cancels an appeal stage.
   * 
   * @param details The details for canceling an appeal stage.
   */
  @Override
  public void cancelStage(final AppealStageIDVersionNo details)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Service Layer to cancel the Appeal Stage.
    productAppealProcessObj.cancelStage(details.appealStageIDVersionNo);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new product appeal process definition for a product. A new
   * product appeal process is created with no appeal stages.
   * 
   * @param details The product and start date for which to create the new
   * product appeal process.
   */
  @Override
  public void create(final ProductIDStartDate details) throws AppException,
    InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the Service Layer to create the Product Appeal Process.
    productAppealProcessObj.create(details.processIDStartDate);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new appeal stage for an existing product appeal process
   * definition.
   * 
   * @param details The details for creating a new appeal stage.
   */
  @Override
  public void createStage(final CreateStageDetails details)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the Service Layer to create the Appeal Stage.
    productAppealProcessObj.createStage(details.createStageDetails);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all product appeal processes for a product. This list
   * includes the first appeal stage, if any, defined for each process.
   * 
   * @param key The product to obtain the list of product appeal processes
   * @return The list of product appeal processes
   */
  @Override
  public ProcessDetailsList list(final ProductID key) throws AppException,
    InformationalException {

    // Variable for list of Product Appeal Processes
    final ProcessDetailsList processDetailsList = new ProcessDetailsList();

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Variables for Product Name
    final Product productObj = ProductFactory.newInstance();
    ProductNameStructRef productNameStructRef;

    final ProductKey productKey = new ProductKey();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Get the list of Product Appeal Processes
    processDetailsList.processDetailsList =
      productAppealProcessObj.list(key.productID);

    // Get the Product name for this Product ID

    productKey.productID = key.productID.productID.productID;

    productNameStructRef = productObj.readProductName(productKey);

    processDetailsList.productNameDetails.productName =
      productNameStructRef.name;

    return processDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns the product appeal process details together with an ordered list,
   * including a numerical order value, of the active appeal stages for the
   * process.
   * 
   * @param details The product appeal process
   * @return The product appeal process details and ordered list of appeal
   * stages.
   */
  @Override
  public ProcessAndStageDetails readProcessDetails(
    final ProductAppealProcessAndProduct details) throws AppException,
    InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Variables for details of Product Appeal Process
    final ProcessAndStageDetails processAndStageDetails =
      new ProcessAndStageDetails();

    // Variables for Product Name
    final Product productObj = ProductFactory.newInstance();

    ProductNameStructRef productNameStructRef;

    final ProductKey productKey = new ProductKey();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the Service Layer to read the Process details
    processAndStageDetails.processAndStageDetails =
      productAppealProcessObj
        .readProcessDetails(details.productAppealProcessID);

    // Get the Product name for this Product ID

    productKey.productID = details.productID.productID.productID;
    productNameStructRef = productObj.readProductName(productKey);

    processAndStageDetails.productNameDetails.productName =
      productNameStructRef.name;

    return processAndStageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates the type of appeal for an appeal stage.
   * 
   * @param details The details for modifying the appeal stage.
   */
  @Override
  public void modifyAppealStageType(final ModifyAppealStage details)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the Service Layer to modify the Appeal Stage type
    productAppealProcessObj.modifyAppealStageType(details.modifyAppealStage);

  }

  // ___________________________________________________________________________
  /**
   * Returns the details of an appeal stage including the its sequence within
   * the overall product appeal process.
   * 
   * @param key The appeal stage to read for.
   * @return The appeal stage details.
   */
  @Override
  public AppealStageDetails readAppealStage(final AppealStageAndProduct key)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();

    // Variable for Appeal Stage Details
    final AppealStageDetails appealStageDetails = new AppealStageDetails();

    // Variables for Product Name
    final Product productObj = ProductFactory.newInstance();

    ProductNameStructRef productNameStructRef;

    final ProductKey productKey = new ProductKey();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the Service Layer to read the Appeal Stage details
    appealStageDetails.appealStageDetails =
      productAppealProcessObj.readAppealStage(key.appealStageID);

    // Get the Product name for this Product ID

    productKey.productID = key.productID.productID.productID;

    productNameStructRef = productObj.readProductName(productKey);

    appealStageDetails.productNameDetails.productName =
      productNameStructRef.name;

    return appealStageDetails;
  }
}
