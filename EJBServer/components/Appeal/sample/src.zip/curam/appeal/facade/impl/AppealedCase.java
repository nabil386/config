/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2004-2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AddResolutionDetails;
import curam.appeal.facade.struct.AppealCaseKey_fo;
import curam.appeal.facade.struct.AppealRelationshipKey;
import curam.appeal.facade.struct.AppealedCaseRejectionComment;
import curam.appeal.facade.struct.AppealedCaseRejectionKey;
import curam.appeal.facade.struct.AppealedCaseRejectionReasonsForIC;
import curam.appeal.facade.struct.AppealedCaseRemoveDetails;
import curam.appeal.facade.struct.AppealedCaseSummaryDetails;
import curam.appeal.facade.struct.ModifyAppealedCaseDetails;
import curam.appeal.facade.struct.ModifyResolutionDetails;
import curam.appeal.facade.struct.ReadForModifyAppealedCaseDetails;
import curam.appeal.facade.struct.ReadResolutionDetails;
import curam.appeal.facade.struct.ReadResolutionForModifyDetails;
import curam.appeal.facade.struct.ReadResolutionPriorAppealDetails;
import curam.appeal.facade.struct.ReadResolutionPriorAppealForModifyDetails;
import curam.appeal.sl.fact.AppealedCaseFactory;
import curam.appeal.sl.struct.AppealCaseID;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.intf.Case;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.facade.struct.CaseMenuData;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.struct.CaseHeaderKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Appeal
 * facade layer.
 */
public class AppealedCase extends curam.appeal.facade.base.AppealedCase {

  // ___________________________________________________________________________
  /**
   * Returns the details of a particular appealed case
   * 
   * @param key Contains the appealRelationshipID
   * 
   * @return The summary details of a particular appealed case
   */
  @Override
  public AppealedCaseSummaryDetails read(final AppealRelationshipKey key)
    throws AppException, InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Variable to contain appealed case details and context description
    final AppealedCaseSummaryDetails appealedCaseSummaryDetails =
      new AppealedCaseSummaryDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the appealed case details
    appealedCaseSummaryDetails.appealedCaseSummaryDetails =
      appealedCaseObj.read(key.appealRelationshipKey);

    return appealedCaseSummaryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Removes the selected appealed case from the appeal by updating the record
   * status to canceled
   * 
   * @param details Contains the appealRelationshipID and versionNo
   */
  @Override
  public void remove(final AppealedCaseRemoveDetails details)
    throws AppException, InformationalException {

    // Variables for AppealedCase service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      AppealedCaseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer to remove the appealed case
    appealedCaseObj.remove(details.appealedCaseRemoveDetails);

  }

  // ___________________________________________________________________________
  /**
   * Returns the details needed for display on the modify Appealed case page
   * 
   * @param key Contains the appealRelationshipID
   * 
   * @return The details to be displayed on the modify Appealed case page
   */
  @Override
  public ReadForModifyAppealedCaseDetails readForModify(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Variable to contain appealed case details
    final ReadForModifyAppealedCaseDetails readForModifyAppealedCaseDetails =
      new ReadForModifyAppealedCaseDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the appealed case details
    readForModifyAppealedCaseDetails.readForModifyAppealedCaseDetails =
      appealedCaseObj.readForModify(key.appealRelationshipKey);

    return readForModifyAppealedCaseDetails;
  }

  // _________________________________________________________________________
  /**
   * Modifies the resolution details for an appealed case.
   * 
   * @param dtls The appealed case resolution details to modify
   */
  @Override
  public void modifyResolution(final ModifyResolutionDetails dtls)
    throws AppException, InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Modify the resolution details
    appealedCaseObj.modifyResolution(dtls.modifyResolutionDetails);
  }

  // _________________________________________________________________________
  /**
   * Reads the resolution details for an appealed case where a case is being
   * directly appealed. That is where a decision from a prior appeal case is
   * not being appealed.
   * 
   * @param key The appealRelationshipID of the appealed case being read.
   * @return The resolution details for the appealed case.
   */
  @Override
  public ReadResolutionDetails
    readResolution(final AppealRelationshipKey key) throws AppException,
      InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Return struct
    final ReadResolutionDetails readResolutionDetails =
      new ReadResolutionDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the resolution details
    readResolutionDetails.readResolutionDetails =
      appealedCaseObj.readResolution(key.appealRelationshipKey);

    return readResolutionDetails;
  }

  // _________________________________________________________________________
  /**
   * Reads the details required for modifying the resolution of an appealed
   * case where a case is being appealed directly. That is where a decision
   * from a prior appeal case is not being appealed.
   * 
   * @param key The appealRelationshipID of the appealed case being read.
   * @return The details required for modifying the appealed case resolution.
   */
  @Override
  public ReadResolutionForModifyDetails readResolutionForModify(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Return struct
    final ReadResolutionForModifyDetails readResolutionForModifyDetails =
      new ReadResolutionForModifyDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the resolution details
    readResolutionForModifyDetails.readResolutionForModifyDetails =
      appealedCaseObj.readResolutionForModify(key.appealRelationshipKey);

    return readResolutionForModifyDetails;
  }

  // _________________________________________________________________________
  /**
   * Reads the resolution details for an appealed case where a decision from
   * a prior appeal case is being appealed.
   * 
   * @param key The appealRelationshipID of the appealed case being read.
   * @return The resolution details for the appealed case.
   */
  @Override
  public ReadResolutionPriorAppealDetails readResolutionPriorAppeal(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Return struct
    final ReadResolutionPriorAppealDetails readResolutionPriorAppealDetails =
      new ReadResolutionPriorAppealDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the resolution details
    readResolutionPriorAppealDetails.readResolutionPriorAppealDetails =
      appealedCaseObj.readResolutionPriorAppeal(key.appealRelationshipKey);

    return readResolutionPriorAppealDetails;
  }

  // _________________________________________________________________________
  /**
   * Reads the details required for modifying the resolution of an appealed
   * case where a decision from a prior appeal case is being appealed.
   * 
   * @param key The appealRelationshipID of the appealed case being read.
   * @return The details required for modifying the appealed case resolution.
   */
  @Override
  public ReadResolutionPriorAppealForModifyDetails
    readResolutionPriorAppealForModify(final AppealRelationshipKey key)
      throws AppException, InformationalException {

    // Variables for service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Return struct
    final ReadResolutionPriorAppealForModifyDetails readResolutionPriorAppealForModifyDetails =
      new ReadResolutionPriorAppealForModifyDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the resolution details
    readResolutionPriorAppealForModifyDetails.readResolutionPriorAppealForModifyDetails =
      appealedCaseObj
        .readResolutionPriorAppealForModify(key.appealRelationshipKey);

    return readResolutionPriorAppealForModifyDetails;
  }

  // _________________________________________________________________________
  /**
   * Validates and modifies the details for an appealed case
   * 
   * @param details Contains the appealed case details for modification
   */
  @Override
  public void modify(final ModifyAppealedCaseDetails details)
    throws AppException, InformationalException {

    // Variable for AppealedCase service layer
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Validate and modify the appealed case details
    appealedCaseObj.modify(details.modifyAppealedCaseDetails);

  }

  // _________________________________________________________________________
  /**
   * Lists rejection reasons for an appealed case
   * 
   * @param key Unique identifier for the appealed case
   * @return List of rejection reasons for the appealed case
   */
  @Override
  public curam.appeal.facade.struct.AppealedCaseRejectionReasons
    listRejectionReasons(final AppealRelationshipKey key)
      throws AppException, InformationalException {

    // Return variable
    final curam.appeal.facade.struct.AppealedCaseRejectionReasons appealedCaseRejectionReasons =
      new curam.appeal.facade.struct.AppealedCaseRejectionReasons();

    // Appealed case service layer object
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();
    AppealCaseID appealCaseID;

    // Appeal Case facade object
    final curam.core.facade.intf.Case caseObj = CaseFactory.newInstance();
    final AppealCaseKey_fo appealCaseKey = new AppealCaseKey_fo();
    final CaseContextDescriptionKey caseContextDescriptionKey =
      new CaseContextDescriptionKey();
    CaseContextDescription caseContextDescription;

    // Get the list of rejection reasons for this appealed case
    appealedCaseRejectionReasons.appealedCaseRejectionReasons =
      appealedCaseObj.listRejectionReasons(key.appealRelationshipKey);

    // Get appeal case ID for the appealed case
    appealCaseID =
      appealedCaseObj.readAppealCaseID(key.appealRelationshipKey);
    appealCaseKey.appealCaseKey.caseID = appealCaseID.caseID;
    caseContextDescriptionKey.caseID = appealCaseID.caseID;

    // Get the context description for the client page
    caseContextDescription =
      caseObj.readCaseContextDescription(caseContextDescriptionKey);
    appealedCaseRejectionReasons.contextDescription =
      caseContextDescription.description;

    return appealedCaseRejectionReasons;
  }

  // _________________________________________________________________________
  /**
   * Modifies the comment text of an appealed case rejection reason
   * 
   * @param details Modified comment for the rejection reason
   */
  @Override
  public void modifyRejectionComment(
    final AppealedCaseRejectionComment details) throws AppException,
    InformationalException {

    // Appealed case service layer object
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Modify the rejection reason comment
    appealedCaseObj.modifyRejectionComment(details.dtls);
  }

  // _________________________________________________________________________
  /**
   * Lists rejection reasons for an integrated case appealed case
   * 
   * @param key Unique identifier for the appealed case
   * @return List of rejection reasons for the appealed case
   */
  @Override
  public AppealedCaseRejectionReasonsForIC listRejectionReasonsForIC(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Return variable
    final AppealedCaseRejectionReasonsForIC appealedCaseRejectionReasonsForIC =
      new AppealedCaseRejectionReasonsForIC();

    // Appealed case service layer object
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();
    AppealCaseID appealCaseID;

    // Case facade object
    // BEGIN HARP 60786, KJ
    final Case caseObj = CaseFactory.newInstance();
    // END HARP 60786

    final AppealCaseKey_fo appealCaseKey = new AppealCaseKey_fo();
    final CaseContextDescriptionKey caseContextDescriptionKey =
      new CaseContextDescriptionKey();
    CaseContextDescription caseContextDescription;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseMenuData caseMenuData;

    // Get the list of rejection reasons for this appealed case
    appealedCaseRejectionReasonsForIC.appealedCaseRejectionReasons =
      appealedCaseObj.listRejectionReasons(key.appealRelationshipKey);

    // Get appeal case ID for the appealed case
    appealCaseID =
      appealedCaseObj.readAppealCaseID(key.appealRelationshipKey);
    appealCaseKey.appealCaseKey.caseID = appealCaseID.caseID;
    caseContextDescriptionKey.caseID = appealCaseID.caseID;

    // Get the context description for the client page
    caseContextDescription =
      caseObj.readCaseContextDescription(caseContextDescriptionKey);
    appealedCaseRejectionReasonsForIC.contextDescription =
      caseContextDescription.description;

    // Get the integrated case menu data
    caseHeaderKey.caseID = appealCaseID.caseID;
    caseMenuData = caseObj.getCaseMenuDataDetails(caseHeaderKey);
    appealedCaseRejectionReasonsForIC.menuData = caseMenuData.menuData;

    return appealedCaseRejectionReasonsForIC;
  }

  // _________________________________________________________________________
  /**
   * Reads details of an appealed case rejection comment for modification
   * 
   * @param key Unique identifier for the appealed case rejection
   * 
   * @return Details of the appealed case rejection comment
   */
  @Override
  public AppealedCaseRejectionComment readForModifyRejectionComment(
    final AppealedCaseRejectionKey key) throws AppException,
    InformationalException {

    // Return variable
    final AppealedCaseRejectionComment appealedCaseRejectionComment =
      new AppealedCaseRejectionComment();

    // Appealed case service layer object
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // Read the appealed case rejection comment details for modification
    appealedCaseRejectionComment.dtls =
      appealedCaseObj.readForModifyRejectionComment(key.dtls);

    return appealedCaseRejectionComment;
  }

  // BEGIN , CR00289874 , DK
  // _________________________________________________________________________
  /**
   * Add resolutions to items under appeal
   * 
   * @param details of the appealed items
   */
  @Override
  public void
    addResolutionToAppealedItems(final AddResolutionDetails details)
      throws AppException, InformationalException {

    // Appealed case service layer object
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      AppealedCaseFactory.newInstance();
    final curam.appeal.sl.struct.AddResolutionDetails resolutionDetails =
      new curam.appeal.sl.struct.AddResolutionDetails();

    resolutionDetails.assign(details);
    appealedCaseObj.addResolutionToAppealedItems(resolutionDetails);

  }
  // END , CR00289874 , DK

}
