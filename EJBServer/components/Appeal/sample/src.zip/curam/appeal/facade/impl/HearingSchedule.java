/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.ContinueHearingDetails;
import curam.appeal.facade.struct.ContinueHearingReviewDetails;
import curam.appeal.facade.struct.HearingCaseParticipantAddressData;
import curam.appeal.facade.struct.HearingKey;
import curam.appeal.facade.struct.HearingScheduleReturnDtls;
import curam.appeal.facade.struct.RescheduleDeskHearingDetails;
import curam.appeal.facade.struct.RescheduleHearingReviewDetails_fo;
import curam.appeal.facade.struct.RescheduleHomeHearingDetails;
import curam.appeal.facade.struct.RescheduleLocationHearingDetails;
import curam.appeal.facade.struct.ReschedulePhoneHearingDetails;
import curam.appeal.facade.struct.ScheduleDeskHearingDetails;
import curam.appeal.facade.struct.ScheduleExternalLocationHearingDetails;
import curam.appeal.facade.struct.ScheduleHearingCaseIDKey;
import curam.appeal.facade.struct.ScheduleHearingReviewDetails_fo;
import curam.appeal.facade.struct.ScheduleHomeHearingDetails;
import curam.appeal.facade.struct.ScheduleLocationHearingDetails;
import curam.appeal.facade.struct.SchedulePhoneHearingDetails;
import curam.appeal.facade.struct.ScheduleUserListString;
import curam.appeal.sl.struct.RescheduleExternalLocationHearingDetails;
import curam.appeal.sl.struct.RescheduleHearingReviewDetails_bo;
import curam.appeal.sl.struct.ScheduleHearingReviewDetails_bo;
import curam.appeal.sl.struct.ScheduleUserName;
import curam.appeal.sl.struct.ScheduleUserNameList;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.impl.TimeZoneUtility;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;

/**
 * Schedule a Hearing for an Appeal case.
 */
public abstract class HearingSchedule extends
  curam.appeal.facade.base.HearingSchedule {

  // ___________________________________________________________________________
  /**
   * Schedules a home based hearing.
   * 
   * @param details Hearing details
   * @return Hearing unique identifier and informational messages
   */
  @Override
  public HearingScheduleReturnDtls scheduleHomeHearing(
    final ScheduleHomeHearingDetails details) throws AppException,
    InformationalException {

    // returned value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // schedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .scheduleHomeHearing(details.scheduleHomeHearingDetails);

    return hearingScheduleReturnDtls;

  }

  // ___________________________________________________________________________
  /**
   * Schedules a location based hearing.
   * 
   * @param details Hearing details
   * @return Hearing unique identifier and informational messages
   */
  @Override
  public HearingScheduleReturnDtls scheduleLocationHearing(
    final ScheduleLocationHearingDetails details) throws AppException,
    InformationalException {

    // returned value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // schedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .scheduleLocationHearing(details.scheduleLocationHearingDetails);

    return hearingScheduleReturnDtls;

  }

  /*
   * //___________________________________________________________________________
   * /**
   * Schedules a phone based hearing.
   * 
   * @param dtls Hearing details
   * 
   * @return Hearing unique identifier and informational messages
   */
  @Override
  public HearingScheduleReturnDtls schedulePhoneHearing(
    final SchedulePhoneHearingDetails details) throws AppException,
    InformationalException {

    // returned value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // schedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .schedulePhoneHearing(details.schedulePhoneHearingDetails);

    return hearingScheduleReturnDtls;

  }

  // ___________________________________________________________________________
  /**
   * Parses a delimited string of user names into a list
   * 
   * @param details Tab delimited string containing user names
   * 
   * @return scheduleUserNameList list of user names
   */
  @Override
  protected ScheduleUserNameList createUserNameListFromString(
    final ScheduleUserListString details) throws AppException,
    InformationalException {

    // Scheduled user name list variable
    final ScheduleUserNameList scheduleUserNameList =
      new ScheduleUserNameList();
    ScheduleUserName scheduleUserName;

    // vector of user names
    StringList userNameStr;

    userNameStr = StringUtil.tabText2StringList(details.userNameListString);

    // convert tab delimited string to vector of type codes
    for (int i = 0; i < userNameStr.size(); i++) {

      scheduleUserName = new ScheduleUserName();
      scheduleUserName.userName = userNameStr.item(i);
      scheduleUserNameList.scheduleUserName.addRef(scheduleUserName);

    }

    return scheduleUserNameList;

  }

  // ___________________________________________________________________________
  /**
   * Continues a hearing for all appeal types.
   * 
   * @param details Hearing continue details
   * @return Informational messages
   */
  @Override
  public InformationMsgDtlsList continueHearing(
    final ContinueHearingDetails details) throws AppException,
    InformationalException {

    // returned value
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Hearing Schedule business object manipulation variables
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();
    final curam.appeal.sl.struct.ContinueHearingDetails continueHearingDetails =
      new curam.appeal.sl.struct.ContinueHearingDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // assign details
    continueHearingDetails.assign(details.continueHearingDetails);

    // continue hearing
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingScheduleObj.continueHearing(continueHearingDetails);

    return informationMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Continues a hearing for all appeal types.
   * 
   * @param details Hearing continue details
   * 
   * @return unique identifier of the hearing being continued
   */
  @Override
  public InformationMsgDtlsList continueHearingReview(
    final ContinueHearingReviewDetails details) throws AppException,
    InformationalException {

    // to be returned
    // HearingKey hearingKey = new HearingKey();
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // Hearing Schedule business object manipulation variables
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();
    final curam.appeal.sl.struct.ContinueHearingDetails continueHearingDetails =
      new curam.appeal.sl.struct.ContinueHearingDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // assign details
    continueHearingDetails.assign(details.continueHearingDetails);

    // continue hearing
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingScheduleObj.continueHearingReview(continueHearingDetails);

    return informationMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Reschedules a hearing for a hearing review case.
   * 
   * @param details Details of the Hearing Review hearing to be rescheduled
   * @return Unique identifier for the newly created hearing.
   */
  @Override
  public HearingScheduleReturnDtls rescheduleHearingReview(
    final RescheduleHearingReviewDetails_fo details) throws AppException,
    InformationalException {

    // Variables for rescheduling a hearing review hearing
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();
    final RescheduleHearingReviewDetails_bo rescheduleHearingReviewDetails =
      new RescheduleHearingReviewDetails_bo();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN, CR00295808, MC
    rescheduleHearingReviewDetails.rescheduleHearingReviewDetails
      .assign(details);

    // If the date is not set and the time is
    if (details.scheduledDate.equals(Date.kZeroDate)
      && !details.scheduledTime.equals(DateTime.kZeroDateTime)) {
      rescheduleHearingReviewDetails.rescheduleHearingReviewDetails.scheduledDateTime =
        details.scheduledTime;
    } else {
      // Format the input for the call to the server. This includes combining
      // the
      // separate Date and Time input values into a single DateTime input for
      // the
      // server.
      rescheduleHearingReviewDetails.rescheduleHearingReviewDetails.scheduledDateTime =
        TimeZoneUtility.getTimeZoneAdjustedDateTime(new DateTime(
          details.scheduledDate.asLong() + details.scheduledTime.asLong()),
          TransactionInfo.getUserTimeZone());
    }
    // END, CR00295808

    // Create the user name list from the input delimited string of user names
    rescheduleHearingReviewDetails.scheduleUserNameList =
      createUserNameListFromString(details.scheduleUserListString);

    // Reschedule the hearing review hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .rescheduleHearingReview(rescheduleHearingReviewDetails);

    return hearingScheduleReturnDtls;

  }

  // ___________________________________________________________________________
  /**
   * Reschedules a home based hearing for a hearing case.
   * 
   * @param details Reschedule home hearing details
   * @return Unique identification of the rescheduled hearing and
   * informational messages.
   */
  @Override
  public HearingScheduleReturnDtls rescheduleHomeHearing(
    final RescheduleHomeHearingDetails details) throws AppException,
    InformationalException {

    // Return variable
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // reschedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .rescheduleHomeHearing(details.rescheduleHomeHearingDetails);

    return hearingScheduleReturnDtls;

  }

  // ___________________________________________________________________________
  /**
   * Reschedules a location based hearing for a hearing case.
   * 
   * @param details Reschedule home hearing details
   * @return Unique identification of the rescheduled hearing and
   * informational messages.
   */
  @Override
  public HearingScheduleReturnDtls rescheduleLocationHearing(
    final RescheduleLocationHearingDetails details) throws AppException,
    InformationalException {

    // Return variable
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // reschedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .rescheduleLocationHearing(details.rescheduleLocationHearingDetails);

    return hearingScheduleReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Reschedules a phone based hearing for a hearing case.
   * 
   * @param details Reschedule home hearing details
   * @return Unique identification of the rescheduled hearing and
   * informational messages.
   */
  @Override
  public HearingScheduleReturnDtls reschedulePhoneHearing(
    final ReschedulePhoneHearingDetails details) throws AppException,
    InformationalException {

    // Return variable
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // reschedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .reschedulePhoneHearing(details.reschedulePhoneHearingDetails);

    return hearingScheduleReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Schedules a hearing review.
   * 
   * @param details Hearing review details
   * @return HearingKey unique identifier of the new created hearing
   */
  @Override
  public HearingScheduleReturnDtls scheduleHearingReview(
    final ScheduleHearingReviewDetails_fo details) throws AppException,
    InformationalException {

    // Variables for scheduling a hearing review
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();
    final ScheduleHearingReviewDetails_bo scheduleHearingReviewDetails =
      new ScheduleHearingReviewDetails_bo();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Format the input for the call to the server. This includes combining the
    // separate Date and Time input values into a single DateTime input for the
    // server.
    scheduleHearingReviewDetails.scheduleHearingReviewDetails.assign(details);
    scheduleHearingReviewDetails.scheduleHearingReviewDetails.scheduledDateTime =
      TimeZoneUtility.getTimeZoneAdjustedDateTime(new DateTime(
        details.scheduledDate.asLong() + details.scheduledTime.asLong()),
        TransactionInfo.getUserTimeZone());

    // Create the user name list from the delimited string input list.
    scheduleHearingReviewDetails.scheduleUserNameList =
      createUserNameListFromString(details.scheduleUserListString);

    // Schedule the hearing review hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj.scheduleHearingReview(scheduleHearingReviewDetails);

    return hearingScheduleReturnDtls;

  }

  // ___________________________________________________________________________
  /**
   * This method retrieves a list of address details for the specified case
   * participant role.
   * 
   * @param key Case Participant Role unique identification
   * @return Hearing case participant address list
   */
  @Override
  public HearingCaseParticipantAddressData listCaseParticipantAddress(
    final ScheduleHearingCaseIDKey key) throws AppException,
    InformationalException {

    // list to be returned
    final HearingCaseParticipantAddressData hearingCaseParticipantAddressData =
      new HearingCaseParticipantAddressData();

    // HearingSchedule business object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingCaseParticipantAddressData.hearingCaseParticipantAddressData =
      hearingScheduleObj.listAppellantAddressByCase(key.hearingCaseID);

    return hearingCaseParticipantAddressData;

  }

  // ___________________________________________________________________________
  /**
   * This method retrieves a list of address details for the appellant
   * of the specified hearing.
   * 
   * @param key Hearing unique identification
   * @return list of address details
   */
  @Override
  public HearingCaseParticipantAddressData listAppellantAddress(
    final HearingKey key) throws AppException, InformationalException {

    // HearingSchedule business object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // list to be returned
    final HearingCaseParticipantAddressData hearingCaseParticipantAddressData =
      new HearingCaseParticipantAddressData();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingCaseParticipantAddressData.hearingCaseParticipantAddressData =
      hearingScheduleObj.listAppellantAddressByHearing(key.hearingKey_bo);

    return hearingCaseParticipantAddressData;

  }

  // ___________________________________________________________________________
  /**
   * Schedules a desk based hearing.
   * 
   * @param details Desk Based Hearing details
   * @return Hearing unique identifier and informational messages
   */
  @Override
  public HearingScheduleReturnDtls scheduleDeskHearing(
    final ScheduleDeskHearingDetails details) throws AppException,
    InformationalException {

    // Return variable
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();
    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();
    // Hearing schedule details
    final curam.appeal.sl.struct.ScheduleDeskHearingDetails scheduleDeskHearingDetails =
      new curam.appeal.sl.struct.ScheduleDeskHearingDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN, CR00285747, MC
    // assign hearing schedule details
    scheduleDeskHearingDetails.scheduleHearingDetailsCommon.assign(details);
    scheduleDeskHearingDetails.scheduleHearingDetailsCommon.scheduledDateTime =
      details.expectedDate.getDateTime();
    // END, CR00285747

    // schedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj.scheduleDeskHearing(scheduleDeskHearingDetails);

    return hearingScheduleReturnDtls;
  }

  // ___________________________________________________________________________

  /**
   * Reschedules a desk based hearing for a hearing case.
   * 
   * @param details Reschedule desk hearing details
   * @return Unique identification of the rescheduled hearing and informational
   * messages.
   */
  @Override
  public HearingScheduleReturnDtls rescheduleDeskHearing(
    final RescheduleDeskHearingDetails details) throws AppException,
    InformationalException {

    // Return variable
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();
    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();
    // Hearing reschedule details
    final curam.appeal.sl.struct.RescheduleDeskHearingDetails rescheduleDeskHearingDetails =
      new curam.appeal.sl.struct.RescheduleDeskHearingDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN, CR00285747, MC
    // assign hearing reschedule details
    rescheduleDeskHearingDetails.rescheduleHearingDetailsCommon
      .assign(details);
    rescheduleDeskHearingDetails.rescheduleHearingDetailsCommon.scheduledDateTime =
      details.expectedDate.getDateTime();
    // END, CR00285747

    // reschedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj.rescheduleDeskHearing(rescheduleDeskHearingDetails);

    return hearingScheduleReturnDtls;
  }

  // BEGIN, CR00290455, MC
  // BEGIN, CR00118193, RKi
  // ___________________________________________________________________________
  /**
   * Schedules a location based hearing.
   * 
   * @param details Hearing details
   * @return Hearing unique identifier and informational messages
   * 
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link #scheduleExternalLocationHearingOfficialMandatory()} This method
   * returns the same details as the method it replaces but the hearing official
   * field is now
   * mandatory.
   */
  @Override
  @Deprecated
  public HearingScheduleReturnDtls scheduleExternalLocationHearing(
    final ScheduleExternalLocationHearingDetails details)
    throws AppException, InformationalException {

    // returned value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // schedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .scheduleExternalLocationHearing(details.externalLocationHearingDetails);

    return hearingScheduleReturnDtls;
  }

  // END, CR00118193
  // ___________________________________________________________________________
  /**
   * Schedules a location based hearing.
   * 
   * @param details Hearing details
   * @return Hearing unique identifier and informational messages
   */
  @Override
  public HearingScheduleReturnDtls
    scheduleExternalLocationHearingOfficialMandatory(
      final ScheduleExternalLocationHearingDetails details)
      throws AppException, InformationalException {

    // returned value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // schedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj
        .scheduleExternalLocationHearing(details.externalLocationHearingDetails);

    return hearingScheduleReturnDtls;
  }

  // END, CR00290455

  // BEGIN, CR00123228, RKi
  // ___________________________________________________________________________
  /**
   * Reschedules a location based hearing for a hearing case.
   * 
   * @param details Reschedule location hearing details
   * @return Unique identification of the rescheduled hearing and
   * informational messages.
   */
  @Override
  public HearingScheduleReturnDtls rescheduleExternalLocationHearing(
    final RescheduleExternalLocationHearingDetails details)
    throws AppException, InformationalException {

    // Return variable
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Hearing Schedule object
    final curam.appeal.sl.intf.HearingSchedule hearingScheduleObj =
      curam.appeal.sl.fact.HearingScheduleFactory.newInstance();

    // reschedule hearing
    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      hearingScheduleObj.rescheduleExternalLocationHearing(details);

    return hearingScheduleReturnDtls;
  }
  // END, CR00123228

}
