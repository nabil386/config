/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.appeal.facade.impl;

import com.google.inject.Inject;
import curam.appeal.facade.struct.AppealAllRelatedDetailsList;
import curam.appeal.facade.struct.AppealAppellantAndRespondentDetails;
import curam.appeal.facade.struct.AppealCaseAllDetailsList;
import curam.appeal.facade.struct.AppealCaseIDPriorCaseID;
import curam.appeal.facade.struct.AppealCaseKey;
import curam.appeal.facade.struct.AppealCaseKey_fo;
import curam.appeal.facade.struct.AppealCaseParticipantRoleKey;
import curam.appeal.facade.struct.AppealCaseSearchKey;
import curam.appeal.facade.struct.AppealCreateWizardProperties;
import curam.appeal.facade.struct.AppealLeadCaseContextDescription;
import curam.appeal.facade.struct.AppealLeadICMenuData;
import curam.appeal.facade.struct.AppealListClosedCaseDetails;
import curam.appeal.facade.struct.AppealListCombinedDetails;
import curam.appeal.facade.struct.AppealListDetails;
import curam.appeal.facade.struct.AppealListDetailsForIC;
import curam.appeal.facade.struct.AppealListMemberDetails;
import curam.appeal.facade.struct.AppealObjectTabList;
import curam.appeal.facade.struct.AppealParticipantRoleDetails;
import curam.appeal.facade.struct.AppealSearchKey;
import curam.appeal.facade.struct.AppealSearchResultList;
import curam.appeal.facade.struct.AppealTypeDetails;
import curam.appeal.facade.struct.AppealTypes;
import curam.appeal.facade.struct.AppealedCaseDetailsListForIC;
import curam.appeal.facade.struct.AppealedDetailsList;
import curam.appeal.facade.struct.AppealedDetailsListForIC;
import curam.appeal.facade.struct.AppealsForConcernRoleDetailsList;
import curam.appeal.facade.struct.CaseAppealLevelDetails;
import curam.appeal.facade.struct.CaseID;
import curam.appeal.facade.struct.CaseIDAppealTypeCode;
import curam.appeal.facade.struct.CaseIDDetails;
import curam.appeal.facade.struct.CaseIDPriorAppealID;
import curam.appeal.facade.struct.CreateAppealDetails;
import curam.appeal.facade.struct.DecisionAndAttachmentListDetails;
import curam.appeal.facade.struct.DecisionAndAttachmentListDetailsForIC;
import curam.appeal.facade.struct.DecisionDetails;
import curam.appeal.facade.struct.DecisionDetailsForIC;
import curam.appeal.facade.struct.DeterminationObjectDetails;
import curam.appeal.facade.struct.HomePageName;
import curam.appeal.facade.struct.MultipleAppellantsOnCaseInd;
import curam.appeal.facade.struct.ReadForCreateAppealDetails;
import curam.appeal.facade.struct.WizardPageName;
import curam.appeal.impl.AppealableCaseType;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSearchRouterFactory;
import curam.appeal.sl.fact.IssueAppealProcessFactory;
import curam.appeal.sl.intf.AppealSearchRouter;
import curam.appeal.sl.struct.AddAppealObjectsDetails;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.AppealListByTypeStatusKey;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.AppealParticipantHomePageKey;
import curam.appeal.sl.struct.AppealParticipantHomePageName;
import curam.appeal.sl.struct.AppealParticipantRoleTypeCode;
import curam.appeal.sl.struct.ListIssueProcessDtls;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALOBJECTTYPE;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RESOLUTIONSTATUSCODE;
import curam.codetable.SEARCHAPPELLANTTYPE;
import curam.codetable.impl.APPEALTYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;
import curam.core.facade.fact.BookmarkFactory;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.fact.ProductFactory;
import curam.core.facade.intf.Case;
import curam.core.facade.struct.BookmarkDetailsStructList;
import curam.core.facade.struct.CaseHomePageDetails;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.ListCaseByCurrentUserDetails;
import curam.core.facade.struct.ListCaseByCurrentUserKey;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ReadAttachmentDetails;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCaseHomePageKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.fact.IssueDeliveryFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.intf.IssueDelivery;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.HomePageIDIssueTypeCaseRef;
import curam.core.sl.entity.struct.IssueDeliveryDtls;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.ResolutionStatus;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.infrastructure.assessment.impl.CREOLECaseDeterminationAccessor;
import curam.core.sl.infrastructure.assessment.impl.CREOLECaseDeterminationAccessorDAO;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.struct.ListBookmarkKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CaseTypeConcernRoleAndConcernRoleType;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ConcernRoleNameTypeAndAlternateID;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.RelatedCaseID;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.message.BPOISSUECASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.UnimplementedException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import java.util.Map;

/**
 * This process class provides the functionality for the Appeal facade layer.
 *
 */
public abstract class Appeal extends curam.appeal.facade.base.Appeal {

  protected static final String kDesc = GeneralAppealConstants.kDescription;

  protected static final String kItem = GeneralAppealConstants.kLink;

  protected static final String kName = GeneralAppealConstants.kName;

  protected static final String kNavigationMenu =
    GeneralAppealConstants.kDynamicMenu;

  protected static final String kPageID = GeneralAppealConstants.kPageID;

  protected static final String kParam = GeneralAppealConstants.kParameter;

  protected static final String kParamCaseID =
    GeneralAppealConstants.kParamCaseID;

  protected static final String kParamCaseParticipantRoleID =
    GeneralAppealConstants.kParamCaseParticipantRoleID;

  protected static final String kTypePerson =
    GeneralAppealConstants.kTypePerson;

  protected static final String kTypeProduct =
    GeneralAppealConstants.kTypeProduct;

  protected static final String kSeparator =
    GeneralAppealConstants.kSeparator;

  protected static final String kSpace = GeneralAppealConstants.kSpace;

  protected static final String kType = GeneralAppealConstants.kType;

  protected static final String kTypeCase = GeneralAppealConstants.kTypeCase;

  protected static final String kValue = GeneralAppealConstants.kValue;

  protected static final int kBufSize = GeneralAppealConstants.kBufferSize;

  // BEGIN, CR00096787, RKi
  protected static final String kParamConcernRoleID =
    XmlMetaDataConst.kParamConcernRoleID;

  // END, CR00096787

  @Inject
  private Map<CASETYPECODEEntry, AppealableCaseType> appealableCaseTypeMap;

  @Inject
  private CREOLECaseDeterminationAccessorDAO creoleCaseDeterminationAccessorDAO;

  public Appeal() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the concern role details for the specified case participant role.
   *
   * @param key
   * Case Participant Role key
   *
   * @return The concern role ID and type
   */
  @Override
  public AppealParticipantRoleDetails
    readConcernRoleDetails(final AppealCaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Return value
    final AppealParticipantRoleDetails appealParticipantRoleDetails =
      new AppealParticipantRoleDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Retrieve concern role details
    appealParticipantRoleDetails.appealParticipantRoleDetails =
      appealObj.readConcernRoleDetails(key.appealCaseParticipantRoleKey);

    // Return details
    return appealParticipantRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of appeal cases for a specified case.
   *
   * @param key
   * The case identifier.
   *
   * @return The list of related appeal cases
   */
  @Override
  public AppealListDetails listAppealByCase(final AppealCaseKey_fo key)
    throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    final AppealCaseID appealCaseID = new AppealCaseID();

    // Return object
    final AppealListDetails appealListDetails = new AppealListDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get list of related appeals
    appealCaseID.caseID = key.appealCaseKey.caseID;
    appealListDetails.listAppealCaseDetails =
      appealObj.listAppealByCase(appealCaseID);

    // BEGIN ,CR00284371, DK
    // Get context description
    // appealCaseDetails.caseID = key.appealCaseKey.caseID;
    // appealListDetails.contextDescription =
    // getLeadCaseContextDescription(key);
    // END ,CR00284371, DK

    // Return output
    return appealListDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of appeals related to the specified case, with Appeals with
   * multiple Appellants included in it.
   *
   * @param key
   * The case identifier.
   *
   * @return The list of related appeal cases
   */
  @Override
  public AppealListCombinedDetails listAppealCombinedByCase(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    final AppealCaseID appealCaseID = new AppealCaseID();

    // Return object
    final AppealListCombinedDetails appealListDetails =
      new AppealListCombinedDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get list of related appeals
    appealCaseID.caseID = key.appealCaseKey.caseID;
    appealListDetails.listAppealCaseDetails =
      appealObj.listAppealByCaseCombined(appealCaseID);

    // Get context description
    appealCaseDetails.caseID = key.appealCaseKey.caseID;

    // Return output
    return appealListDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of closed hearing cases that are related to a specified
   * case.
   *
   * @param key
   * The case identifier.
   *
   * @return The list of closed hearing review cases
   */
  @Override
  public AppealListClosedCaseDetails listClosedHearingCaseByCase(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealListByTypeStatusKey appealListByTypeStatusKey =
      new AppealListByTypeStatusKey();

    // Return object
    final AppealListClosedCaseDetails appealListClosedCaseDetails =
      new AppealListClosedCaseDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Set key to retrieve hearing cases for the case
    appealListByTypeStatusKey.caseID = key.appealCaseKey.caseID;
    appealListByTypeStatusKey.appealTypeCode = APPEALTYPE.HEARING;

    // Get list of hearing reviews
    appealListClosedCaseDetails.relatedAppealByStatusDetailsList =
      appealObj.listAppealByCaseTypeStatus(appealListByTypeStatusKey);

    // Return details
    return appealListClosedCaseDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of closed hearing review cases that are related to a
   * specified case.
   *
   * @param key
   * The case identifier.
   *
   * @return The list of closed hearing review cases
   */
  @Override
  public AppealListClosedCaseDetails listClosedHearingReviewByCase(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealListByTypeStatusKey appealListByTypeStatusKey =
      new AppealListByTypeStatusKey();

    // Return object
    final AppealListClosedCaseDetails appealListClosedCaseDetails =
      new AppealListClosedCaseDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Set key to retrieve hearing reviews for the case
    appealListByTypeStatusKey.caseID = key.appealCaseKey.caseID;
    appealListByTypeStatusKey.appealTypeCode = APPEALTYPE.HEARINGREVIEW;

    // Get list of hearing reviews
    appealListClosedCaseDetails.relatedAppealByStatusDetailsList =
      appealObj.listAppealByCaseTypeStatus(appealListByTypeStatusKey);

    // Return details
    return appealListClosedCaseDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of closed hearing cases that are related to a specified case
   * on an integrated case.
   *
   * @param key
   * The case identifier.
   *
   * @return The list of closed hearing review cases
   */
  @Override
  public AppealListDetailsForIC listAppealByCaseForIC(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    final AppealCaseID appealCaseID = new AppealCaseID();

    // Return object
    final AppealListDetailsForIC appealListDetailsForIC =
      new AppealListDetailsForIC();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get list of related appeals
    appealCaseID.caseID = key.appealCaseKey.caseID;
    appealListDetailsForIC.listAppealCaseDetails =
      appealObj.listAppealByCase(appealCaseID);

    // Get context description
    appealCaseDetails.caseID = key.appealCaseKey.caseID;
    appealListDetailsForIC.contextDescription =
      getLeadICCaseContextDescription(key);

    // Get menu data
    appealListDetailsForIC.appealLeadICMenuData = getLeadICMenuData(key);

    // BEGIN, CR00293141, PS
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = appealCaseDetails.caseID;

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ResolutionStatus resolutionStatus = new ResolutionStatus();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = appealCaseDetails.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      // END, CR00303986
      final IssueDelivery issueDeliveryObj =
        IssueDeliveryFactory.newInstance();

      resolutionStatus =
        issueDeliveryObj.readResolutionStatus(issueDeliveryKey);

      appealListDetailsForIC.isIssueCaseApprovedIndOpt = true;

      if (!resolutionStatus.resolutionStatus
        .equals(RESOLUTIONSTATUSCODE.APPROVED)) {
        appealListDetailsForIC.isIssueCaseApprovedIndOpt = false;
      }
    }
    // END, CR00293141

    // Return output
    return appealListDetailsForIC;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the context description for a lead case.
   *
   * @param key
   * Unique internal reference number of the lead case.
   *
   * @return The context description of the lead case.
   */
  @Override
  protected AppealLeadCaseContextDescription getLeadCaseContextDescription(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // ProductDelivery manipulation variable
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // CaseHomePageNameAndType object
    CaseHomePageNameAndType caseHomePageNameAndType;

    // Return object
    final AppealLeadCaseContextDescription appealLeadCaseContextDescription =
      new AppealLeadCaseContextDescription();

    ConcernRoleNameTypeAndAlternateID concernRoleNameTypeAndAlternateID;

    // Set key to read CaseHeader
    caseHeaderKey.caseID = key.appealCaseKey.caseID;

    caseKey.caseID = key.appealCaseKey.caseID;

    // BEGIN, CR00303986, SG
    final CaseTypeConcernRoleAndConcernRoleType caseTypeConcernRoleAndConcernRoleType =
      caseHeaderObj.readCaseTypeConcernRoleAndConcernRoleType(caseHeaderKey);

    concernRoleKey.concernRoleID =
      caseTypeConcernRoleAndConcernRoleType.concernRoleID;
    // END, CR00303986

    // Read the concern role details.
    concernRoleNameTypeAndAlternateID =
      concernRoleObj.readConcernRoleNameTypeAndAlternateID(concernRoleKey);

    // Read productDelivery
    caseHomePageNameAndType =
      productDeliveryObj.readCaseHomePageNameAndType(caseKey);

    // Create the context description

    final StringBuffer buffer = new StringBuffer();

    buffer.append(curam.util.type.CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode));
    buffer.append(kSpace);

    buffer.append(caseHomePageNameAndType.caseReference);
    buffer.append(kSeparator);
    buffer.append(concernRoleNameTypeAndAlternateID.concernRoleName);
    buffer.append(kSpace);
    buffer.append(concernRoleNameTypeAndAlternateID.primaryAlternateID);

    // Assign it to the return object
    appealLeadCaseContextDescription.contextDescription = buffer.toString();

    return appealLeadCaseContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Gets the context description for a lead case on an integrated case.
   *
   * @param key
   * Unique internal reference number of the lead case.
   *
   * @return The context description of the lead case.
   */
  @Override
  protected AppealLeadCaseContextDescription getLeadICCaseContextDescription(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ProductDelivery manipulation variables
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Return object
    final AppealLeadCaseContextDescription appealLeadCaseContextDescription =
      new AppealLeadCaseContextDescription();

    ConcernRoleNameTypeAndAlternateID concernRoleNameTypeAndAlternateID;

    // Set key to read CaseHeader
    caseHeaderKey.caseID = key.appealCaseKey.caseID;

    caseKey.caseID = key.appealCaseKey.caseID;

    // BEGIN, CR00303986, SG
    final CaseTypeConcernRoleAndConcernRoleType caseTypeConcernRoleAndConcernRoleType =
      caseHeaderObj.readCaseTypeConcernRoleAndConcernRoleType(caseHeaderKey);

    concernRoleKey.concernRoleID =
      caseTypeConcernRoleAndConcernRoleType.concernRoleID;
    // END, CR00303986

    // Read the concern role details.
    concernRoleNameTypeAndAlternateID =
      concernRoleObj.readConcernRoleNameTypeAndAlternateID(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType =
      new CaseHomePageNameAndType();

    // Create the context description
    final StringBuffer buffer = new StringBuffer(kBufSize);

    // Read productDelivery
    // BEGIN, CR00021939, RKi

    // BEGIN, CR00303986, SG
    if (caseTypeConcernRoleAndConcernRoleType.caseTypeCode
      .equals(CASETYPECODE.ISSUE)) {
      // END, CR00303986
      final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
      HomePageIDIssueTypeCaseRef homePageIDIssueTypeCaseRef =
        new HomePageIDIssueTypeCaseRef();

      issueDeliveryKey.caseID = key.appealCaseKey.caseID;
      final IssueDelivery issueDelivery = IssueDeliveryFactory.newInstance();

      homePageIDIssueTypeCaseRef =
        issueDelivery.readHomePageIDIssueTypeCaseRef(issueDeliveryKey);
      caseHomePageNameAndType.caseHomePageName =
        homePageIDIssueTypeCaseRef.homePageIdentifier;
      caseHomePageNameAndType.caseReference =
        homePageIDIssueTypeCaseRef.caseReference;
      caseHomePageNameAndType.typeCode = homePageIDIssueTypeCaseRef.issueType;
      buffer.append(CodeTable.getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME,
        caseHomePageNameAndType.typeCode));
    } else {
      caseHomePageNameAndType =
        productDeliveryObj.readCaseHomePageNameAndType(caseKey);
      buffer.append(CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        caseHomePageNameAndType.typeCode));
    }
    // END, CR00021939

    buffer.append(kSpace);

    buffer.append(caseHomePageNameAndType.caseReference);
    buffer.append(kSeparator);
    buffer.append(concernRoleNameTypeAndAlternateID.concernRoleName);
    buffer.append(kSpace);
    buffer.append(concernRoleNameTypeAndAlternateID.primaryAlternateID);

    // Assign it to the return object
    appealLeadCaseContextDescription.contextDescription = buffer.toString();

    return appealLeadCaseContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the menu data for the specified case on an integrated case.
   *
   * @param key
   * Unique internal reference number of the case.
   *
   * @return The menu data for the specified case.
   */
  @Override
  protected AppealLeadICMenuData getLeadICMenuData(final AppealCaseKey_fo key)
    throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealParticipantHomePageKey appealParticipantHomePageKey =
      new AppealParticipantHomePageKey();
    AppealParticipantHomePageName appealParticipantHomePageName;

    // Return object
    final AppealLeadICMenuData appealLeadICMenuData =
      new AppealLeadICMenuData();

    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();

    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey =
      new CaseIDParticipantRoleKey();

    final CaseParticipantRoleIDKey caseParticipantRoleIDKey =
      new CaseParticipantRoleIDKey();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    final CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls = new ProductDeliveryDtls();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.appealCaseKey.caseID;

    // BEGIN, CR00021939, RKi
    CaseHeaderDtls caseHeaderDtls;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeaderKey caseHeaderKey1 = new CaseHeaderKey();

    caseHeaderKey.caseID = key.appealCaseKey.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
    RelatedCaseID relatedCaseID;

    // if the issue is created on the Integrated case assign the concern role id
    // from the case header table instead of product delivery table
    // BEGIN, CR00083300, RKi
    caseHeaderKey1.caseID = caseHeaderDtls.integratedCaseID;

    // BEGIN, CR00303986, SG
    final CaseTypeConcernRoleAndConcernRoleType caseTypeConcernRoleAndConcernRoleType =
      caseHeaderObj.readCaseTypeConcernRoleAndConcernRoleType(caseHeaderKey1);

    // END, CR00303986

    // END, CR00083300
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      final IssueDelivery issueDelivery = IssueDeliveryFactory.newInstance();
      final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

      issueDeliveryKey.caseID = key.appealCaseKey.caseID;
      relatedCaseID = issueDelivery.readRelatedCaseID(issueDeliveryKey);
      productDeliveryKey.caseID = relatedCaseID.relatedCaseID;

      // BEGIN, CR00083300, RKi
      // BEGIN, CR00303986, SG
      if (caseTypeConcernRoleAndConcernRoleType.caseTypeCode
        .equals(CASETYPECODE.INTEGRATEDCASE)) {
        productDeliveryDtls.recipConcernRoleID =
          caseTypeConcernRoleAndConcernRoleType.concernRoleID;
        // END, CR00303986
        // END, CR00083300
      } else {
        productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);
      }

    } else {
      // Read ProductDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);
    }
    // END, CR00021939

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType =
      new CaseHomePageNameAndType();

    // Set key to read productDelivery
    caseKey.caseID = key.appealCaseKey.caseID;

    // Read productDelivery to retrieve the case home page name and
    // product type

    // BEGIN, CR00021939, RKi
    // Read CaseHeader
    // Set key to read CaseHeader
    caseHeaderKey.caseID = key.appealCaseKey.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
      HomePageIDIssueTypeCaseRef homePageIDIssueTypeCaseRef =
        new HomePageIDIssueTypeCaseRef();

      issueDeliveryKey.caseID = key.appealCaseKey.caseID;
      final IssueDelivery issueDelivery = IssueDeliveryFactory.newInstance();

      homePageIDIssueTypeCaseRef =
        issueDelivery.readHomePageIDIssueTypeCaseRef(issueDeliveryKey);
      caseHomePageNameAndType.caseHomePageName =
        homePageIDIssueTypeCaseRef.homePageIdentifier;
      caseHomePageNameAndType.caseReference =
        homePageIDIssueTypeCaseRef.caseReference;
      caseHomePageNameAndType.typeCode = homePageIDIssueTypeCaseRef.issueType;
    } else {
      caseHomePageNameAndType =
        productDeliveryObj.readCaseHomePageNameAndType(caseKey);
    }
    // END, CR00021939

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey =
      caseHeaderObj.readIntegratedCaseReferenceByCaseID(caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails =
      caseHeaderObj.readICPageNamesICTypeAndConcernDetails(caseKey);

    // Convert IC Case Type Code to its description
    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    caseIDParticipantRoleKey.caseID =
      integratedCaseReferenceKey.integratedCaseID;
    caseIDParticipantRoleKey.participantRoleID =
      productDeliveryDtls.recipConcernRoleID;

    // Read the caseParticipantRoleID
    caseParticipantRoleCaseParticipantRoleID =
      caseParticipantRole.readCaseParticipantRoleID(caseIDParticipantRoleKey);

    caseParticipantRoleIDKey.caseParticipantRoleID =
      caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    // Get participant home page
    appealParticipantHomePageKey.icParticipantHomePageKey.caseParticipantRoleID =
      caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;
    appealParticipantHomePageName =
      appealObj.resolveParticipantHome(appealParticipantHomePageKey);

    // create link to the participant home page.
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName);

    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    paramElement.setAttribute(kValue, Long.toString(
      caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID));

    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    // paramElement.setAttribute(kName, kParamCaseID);
    // paramElement.setAttribute(kValue,
    // String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      caseHomePageNameAndType.caseHomePageName);

    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    // BEGIN, CR CR00065956, NSP

    final StringBuffer buffer = new StringBuffer(kBufSize);

    // Get case Issue type and reference number
    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      buffer.append(CodeTable.getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME,
        caseHomePageNameAndType.typeCode));
    } else {
      buffer.append(CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        caseHomePageNameAndType.typeCode));
    }

    buffer.append(kSeparator);
    buffer.append(caseHomePageNameAndType.caseReference);

    description.arg(buffer.toString());

    // END, CR CR00065956

    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);

    paramElement.setAttribute(kValue,
      Long.toString(key.appealCaseKey.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    appealLeadICMenuData.menuData =
      outputter.outputString(navigationMenuElement);

    return appealLeadICMenuData;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the case home page name.
   *
   * @param key
   * Key to read the case home page name.
   *
   * @return the case home page name.
   */
  @Override
  public HomePageName resolveCaseHomePageName(final AppealCaseKey_fo key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Variable for core Case business process facade
    final Case caseObj = CaseFactory.newInstance();

    // Variables for core Case Header business process
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHomePageDetails caseHomePageDetails;
    final ReadCaseHomePageKey readCaseHomePageKey = new ReadCaseHomePageKey();

    // Variable for Appeal business process service layer
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Return variable
    final HomePageName homePageName = new HomePageName();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.appealCaseKey.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If the case is an appeal case then use the Appeal service layer
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
      // END, CR00303986

      homePageName.homePageName =
        appealObj.resolveCaseHomePageName(key.appealCaseKey);
    } // Otherwise use the core Case facade to resolve the home page name
    else {
      readCaseHomePageKey.caseID = key.appealCaseKey.caseID;
      caseHomePageDetails =
        caseObj.resolveCaseHomePageName(readCaseHomePageKey);
      homePageName.homePageName.homePageName =
        caseHomePageDetails.homePageName;
    }

    return homePageName;
  }

  // BEGIN, CR00295047, MC
  // _____________________________________________________________________________
  /**
   * Resolves the case home page name for all types of appeal case. Note that
   * this method does not resolve the home page for non-appeal case types; this
   * is controlled by the invoking method. This method returns the versions of
   * the Appeals home pages to be displayed as a view
   *
   * @param key
   * Key to read the case home page name.
   * @return the case home page name.
   */
  @Override
  public HomePageName resolveCaseHomePageNameForCalendarEvent(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    final HomePageName homePageName = new HomePageName();
    final HomePageName returnHomePageName = new HomePageName();

    homePageName.homePageName =
      AppealFactory.newInstance().resolveCaseHomePageName(key.appealCaseKey);

    final String appealHomePage = homePageName.homePageName.homePageName;

    if (appealHomePage
      .equals(EnvVars.ENV_APPEAL_HEARINGCASEHOMEFORIC_DEFAULT)) {
      returnHomePageName.homePageName.homePageName =
        GeneralAppealConstants.gkHearingCaseCalendarEventHomePage;
    } else if (appealHomePage
      .equals(EnvVars.ENV_APPEAL_HEARINGREVIEWHOMEFORIC_DEFAULT)) {
      returnHomePageName.homePageName.homePageName =
        GeneralAppealConstants.gkHearingReviewCalendarEventHomePage;
    } else if (appealHomePage
      .equals(EnvVars.ENV_APPEAL_JUDICIALREVIEWHOMEFORIC_DEFAULT)) {
      returnHomePageName.homePageName.homePageName =
        GeneralAppealConstants.gkJudicialReviewCalendarEventHomePage;
    }

    return returnHomePageName;
  }

  // END, CR00295047

  // ___________________________________________________________________________
  /**
   * Retrieve list of cases by owner ID
   *
   * @param key
   * contains the user to list cases by
   *
   * @return the list of the user's cases
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  /**
   * The key in the method parameter is unused. The method has
   * no implementation but yet provided, for the customer to
   * override it and customize the functionality.
   */
  public ListCaseByCurrentUserDetails
    listCaseByCurrentUser(final ListCaseByCurrentUserKey key)
      throws AppException, InformationalException {

    return new ListCaseByCurrentUserDetails();

  }

  // ___________________________________________________________________________
  /**
   * Reads details of a case attachment.
   *
   * @param key
   * Key to read the case attachment details.
   *
   * @return Details of the case attachment.
   */
  @Override
  public ReadAttachmentDetails readAttachment(final ReadAttachmentKey key)
    throws AppException, InformationalException {

    // Details to be returned
    final ReadAttachmentDetails readAttachmentDetails =
      new ReadAttachmentDetails();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Call service layer to read the attachment details
    readAttachmentDetails.readAttachmentOut =
      appealObj.readAttachment(key.readAttachmentIn);

    return readAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the appeal type of an appeal case.
   *
   * @param key
   * Key to read the appeal type.
   *
   * @return Details of the appeal type.
   */
  @Override
  public AppealTypeDetails readAppealType(final AppealCaseKey_fo key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    final AppealTypeDetails appealTypeDetails = new AppealTypeDetails();

    appealTypeDetails.appealTypeDetails =
      appealObj.readAppealType(key.appealCaseKey);

    return appealTypeDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns all the appealed cases for the given appeal caseID
   *
   * @param key
   * Contains the appealCaseID
   *
   * @return The list of all the appealed cases for the given appeal caseID
   */
  @Override
  public AppealedDetailsList listAppealedCases(final AppealCaseKey_fo key)
    throws AppException, InformationalException {

    // Variables for list maintenance
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealedDetailsList appealedDetailsList = new AppealedDetailsList();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Search for all appealed cases and context for the current appeal case
    appealedDetailsList.appealedDetailsList =
      appealObj.listAppealedCases(key.appealCaseKey);
    appealCaseDetails.caseID = key.appealCaseKey.caseID;
    appealedDetailsList.contextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    return appealedDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Creates receipt notices for any outstanding appealed cases on the appeal
   * and sets the receipt notice indicator
   *
   * @param key
   * Contains the appealCaseID
   */
  @Override
  public void createOutstandingReceiptNotices(final AppealCaseKey_fo key)
    throws AppException, InformationalException {

    // Variable for access to Appeal service layer
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the service layer
    appealObj.createOutstandingReceiptNotices(key.appealCaseKey);
  }

  // BEGIN, CR00267114, ZV
  // ___________________________________________________________________________
  /**
   * Returns the overall decision for an appeal case in addition to the list of
   * appealed cases and their resolutions being considered as part of the appeal
   * case.
   *
   * @param key
   * The appeal case to return the decision.
   *
   * @return The overall appeal case decision and the list of appealed cases and
   * their resolutions.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #readDecisionAndAttachmentList()}
   */
  @Override
  @Deprecated
  public DecisionDetails readDecision(final AppealCaseKey key)
    throws AppException, InformationalException {

    final DecisionDetails decisionDetails = new DecisionDetails();

    decisionDetails.assign(readDecisionAndAttachmentList(key));

    return decisionDetails;
  }

  // END, CR00267114

  // BEGIN, CR00267114, ZV
  // ___________________________________________________________________________
  /**
   * Returns the overall decision for an appeal case in addition to the list of
   * appealed cases and their resolutions being considered as part of the appeal
   * case.
   *
   * @param key
   * The appeal case to return the decision.
   *
   * @return The overall appeal case decision and the list of appealed cases and
   * their resolutions.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #readDecisionAndAttachmentListForIC()}
   */
  @Override
  @Deprecated
  public DecisionDetailsForIC readDecisionForIC(final AppealCaseKey key)
    throws AppException, InformationalException {

    final DecisionDetailsForIC decisionDetailsForIC =
      new DecisionDetailsForIC();

    decisionDetailsForIC.assign(readDecisionAndAttachmentListForIC(key));

    return decisionDetailsForIC;
  }

  // END, CR00267114

  /**
   * Returns the list of appealed cases for a given appeal case ID
   *
   * @param key
   * The appeal case ID for which to find the list of appealed cases
   *
   * @return The list of appealed cases for a given appeal case
   */
  @Override
  public AppealedDetailsListForIC listAppealedCasesForIC(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    // Variables for list maintenance
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealedDetailsListForIC appealedDetailsListForIC =
      new AppealedDetailsListForIC();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Search for all appealed cases for the current appeal case
    appealedDetailsListForIC.appealedDetailsList =
      appealObj.listAppealedCases(key.appealCaseKey);

    // Get context and menu data for the current appeal case
    appealCaseDetails.caseID = key.appealCaseKey.caseID;
    appealedDetailsListForIC.contextDescription =
      appealObj.getContextDescription(appealCaseDetails);
    appealedDetailsListForIC.menuData =
      appealObj.getMenuData(appealCaseDetails);

    return appealedDetailsListForIC;

  }

  // BEGIN, CR00247651, GP
  /**
   * Lists appealed cases for a given appeal case ID.
   *
   * @param key contains the appeal case ID for which to find the list of
   * appealed cases.
   *
   * @return The list of appealed cases for a given appeal case.
   */
  @Override
  public AppealedCaseDetailsListForIC listAllAppealedCases(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();
    final AppealedCaseDetailsListForIC appealedDetailsListForIC =
      new AppealedCaseDetailsListForIC();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    SecurityImplementationFactory.register();

    // Search for all appealed cases for the current appeal case.
    appealedDetailsListForIC.appealedCaseDetailsList =
      appealObj.listAppealedCasesForIC(key.appealCaseKey);

    // Get context and menu data for the current appeal case.
    appealCaseDetails.caseID = key.appealCaseKey.caseID;
    appealedDetailsListForIC.contextDescription =
      appealObj.getContextDescription(appealCaseDetails);
    appealedDetailsListForIC.menuData =
      appealObj.getMenuData(appealCaseDetails);
    return appealedDetailsListForIC;
  }

  // END, CR00247651

  /**
   * Returns the list of appealed issues for a given appeal case ID
   *
   * @param key
   * The appeal case ID for which to find the list of appealed cases
   *
   * @return The list of appealed issues for a given appeal case
   */
  @Override
  public AppealedDetailsListForIC listAppealedIssuesForIC(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    //
    // Variables for list maintenance
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealedDetailsListForIC appealedDetailsListForIC =
      new AppealedDetailsListForIC();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Search for all appealed issues for the current appeal case
    appealedDetailsListForIC.appealedDetailsList =
      appealObj.listAppealedIssues(key.appealCaseKey);

    // Get context and menu data for the current appeal case
    appealCaseDetails.caseID = key.appealCaseKey.caseID;
    appealedDetailsListForIC.contextDescription =
      appealObj.getContextDescription(appealCaseDetails);
    appealedDetailsListForIC.menuData =
      appealObj.getMenuData(appealCaseDetails);

    return appealedDetailsListForIC;
  }

  // ___________________________________________________________________________
  /**
   * This method determines whether or not the underlying product appeal process
   * configuration for the case stipulate that the case can only be appealed at
   * the first level of appeal or whether the case can be appealed at other
   * levels of appeal.
   *
   * @param details
   * The case selected for appeal and the type of appeal to appeal it
   * to.
   * @return Indicator if case can only be appealed at the first appeal level.
   * Note that a negative value here implies that the case can be
   * appealed at other levels of appeal. Indicator if the case be
   * appealed at the first level at all.
   */
  @Override
  public CaseAppealLevelDetails
    resolveAppealCaseLevelForCase(final CaseIDAppealTypeCode details)
      throws AppException, InformationalException {

    // Variables for resolving the appeal level for the case
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseAppealLevelDetails caseAppealLevelDetails =
      new CaseAppealLevelDetails();

    // Register the security implementation factory
    SecurityImplementationFactory.register();

    // Resolve the appeal level for the case.
    caseAppealLevelDetails.caseAppealLevelDetails =
      appealObj.resolveAppealLevelForCase(details.caseIDAppealTypeCode);

    return caseAppealLevelDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of valid participants from the specified case which are
   * eligible to be an appellant on an appeal regarding a decision made for the
   * specified case
   *
   * <BR>
   * <BR>
   * Valid Appellant Participant Types:
   * <UL>
   * <LI>Primary Client</LI>
   * <LI>Nominee</LI>
   * <LI>Joint Owner</LI>
   * <LI>Father of Unborn</LI>
   * <LI>Carer</LI>
   * <LI>Child Support Payment Recipient</LI>
   * <LI>Dependent Care Payment Recipient</LI>
   * <LI>Appellant</LI>
   * <LI>Respondent</LI>
   * </UL>
   * <BR>
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return List of valid appellants participants
   */
  @Override
  public AppealListMemberDetails
    listCaseParticipantsForAppellant(final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing participant details list
    final AppealListMemberDetails appealListMemberDetails =
      new AppealListMemberDetails();

    // Participant Role Type Code Object
    final AppealParticipantRoleTypeCode appealParticipantRoleTypeCode =
      new AppealParticipantRoleTypeCode();

    // Appeal CaseID Object
    final curam.appeal.sl.struct.CaseIDDetails caseIDDetails =
      new curam.appeal.sl.struct.CaseIDDetails();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appeal =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Set Participant type code to APPELLANT
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use PriorCaseID if supplied
    if (key.priorCaseID != 0) {
      caseIDDetails.caseID = key.priorCaseID;
    } else {
      caseIDDetails.caseID = key.caseID;
    }

    // Invoke service layer search for a list of valid appellants
    appealListMemberDetails.appealParticipantDetailsList =
      appeal.listCaseParticipantsByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    return appealListMemberDetails;

  }

  /**
   * Returns a list of valid participants from the specified case which are
   * eligible to be an appellant on an appeal regarding a decision made for the
   * specified case. In addition to the roles that were considered before,
   * an additional one had been added to allow any member of the case
   * to be an appellant on an appeal regarding a decision made for the
   * specified case.
   *
   * <BR>
   * <BR>
   * Valid Appellant Participant Types:
   * <UL>
   * <LI>Primary Client</LI>
   * <LI>Nominee</LI>
   * <LI>Joint Owner</LI>
   * <LI>Father of Unborn</LI>
   * <LI>Carer</LI>
   * <LI>Child Support Payment Recipient</LI>
   * <LI>Dependent Care Payment Recipient</LI>
   * <LI>Appellant</LI>
   * <LI>Respondent</LI>
   * </UL>
   * <BR>
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return List of valid appellants participants
   */
  // START, CR00424038, DM
  @Override
  public AppealListMemberDetails
    listCaseMembersForAppellant(final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing participant details list
    final AppealListMemberDetails appealListMemberDetails =
      new AppealListMemberDetails();

    // Participant Role Type Code Object
    final AppealParticipantRoleTypeCode appealParticipantRoleTypeCode =
      new AppealParticipantRoleTypeCode();

    // Appeal CaseID Object
    final curam.appeal.sl.struct.CaseIDDetails caseIDDetails =
      new curam.appeal.sl.struct.CaseIDDetails();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appeal =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Set Participant type code to APPELLANT
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use PriorCaseID if supplied
    if (key.priorCaseID != 0) {
      caseIDDetails.caseID = key.priorCaseID;
    } else {
      caseIDDetails.caseID = key.caseID;
    }

    // Invoke service layer search for a list of valid appellants
    appealListMemberDetails.appealParticipantDetailsList =
      appeal.listCaseMembersByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    return appealListMemberDetails;
  }

  // END, CR00424038

  // ___________________________________________________________________
  /**
   * Returns a list of valid participants from the specified case which are
   * eligible to be a respondent on an appeal regarding a decision made for the
   * specified case.
   *
   * <BR>
   * <BR>
   * Valid Respondent Participant Types:
   * <UL>
   * <LI>Primary Client</LI>
   * <LI>Nominee</LI>
   * <LI>Joint Owner</LI>
   * <LI>Father of Unborn</LI>
   * <LI>Carer</LI>
   * <LI>Child Support Payment Recipient</LI>
   * <LI>Dependent Care Payment Recipient</LI>
   * <LI>Appellant</LI>
   * <LI>Respondent</LI>
   * </UL>
   * <BR>
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return List of valid respondent participants
   */
  @Override
  public AppealListMemberDetails
    listCaseParticipantsForRespondent(final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing participant details list
    final AppealListMemberDetails appealListMemberDetails =
      new AppealListMemberDetails();

    // Participant Role Type Code Object
    final AppealParticipantRoleTypeCode appealParticipantRoleTypeCode =
      new AppealParticipantRoleTypeCode();

    // Appeal CaseID Object
    final curam.appeal.sl.struct.CaseIDDetails caseIDDetails =
      new curam.appeal.sl.struct.CaseIDDetails();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Set Participant type code to RESPONDENT
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use PriorCaseID if supplied
    if (key.priorCaseID != 0) {
      caseIDDetails.caseID = key.priorCaseID;
    } else {
      caseIDDetails.caseID = key.caseID;
    }
    // Invoke service layer search for a list of valid respondents
    appealListMemberDetails.appealParticipantDetailsList =
      appealObj.listCaseParticipantsByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    return appealListMemberDetails;

  }

  // START, CR00424038, DM
  // ___________________________________________________________________
  /**
   * Returns a list of valid participants from the specified case which are
   * eligible to be a respondent on an appeal regarding a decision made for the
   * specified case. In addition to the roles that were considered before,
   * an additional one had been added to allow any member of the case
   * to be a respondent on an appeal regarding a decision made for the
   * specified case. <BR>
   * <BR>
   * Valid Respondent Participant Types:
   * <UL>
   * <LI>Primary Client</LI>
   * <LI>Nominee</LI>
   * <LI>Joint Owner</LI>
   * <LI>Father of Unborn</LI>
   * <LI>Carer</LI>
   * <LI>Child Support Payment Recipient</LI>
   * <LI>Dependent Care Payment Recipient</LI>
   * <LI>Appellant</LI>
   * <LI>Respondent</LI>
   * </UL>
   * <BR>
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return List of valid respondent participants
   */
  @Override
  public AppealListMemberDetails
    listCaseMembersForRespondent(final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing participant details list
    final AppealListMemberDetails appealListMemberDetails =
      new AppealListMemberDetails();

    // Participant Role Type Code Object
    final AppealParticipantRoleTypeCode appealParticipantRoleTypeCode =
      new AppealParticipantRoleTypeCode();

    // Appeal CaseID Object
    final curam.appeal.sl.struct.CaseIDDetails caseIDDetails =
      new curam.appeal.sl.struct.CaseIDDetails();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Set Participant type code to RESPONDENT
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use PriorCaseID if supplied
    if (key.priorCaseID != 0) {
      caseIDDetails.caseID = key.priorCaseID;
    } else {
      caseIDDetails.caseID = key.caseID;
    }
    // Invoke service layer search for a list of valid appellants
    appealListMemberDetails.appealParticipantDetailsList =
      appealObj.listCaseMembersByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    return appealListMemberDetails;
  }

  // END, CR00424038

  // ___________________________________________________________________________
  /**
   * Checks if the resolution status for the issue case is approved.
   *
   * @param key
   * Contains the CaseID
   * @return CaseIDDetails Contains the CaseID
   */
  @Override
  public CaseIDDetails isIssueCaseApproved(final CaseIDDetails key)
    throws AppException, InformationalException {

    // BEGIN, CR00022111, RKi

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Object to create informational messages
    final InformationalManager informationalManager =
      new InformationalManager();
    // Required Objects
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = key.caseIDDetails.caseID;

    // BEGIN, CR00022302, RKi
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ResolutionStatus resolutionStatus = new ResolutionStatus();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseIDDetails.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      // END, CR00303986
      // END, CR00022302
      // BEGIN, CR00022238, DK
      final IssueDelivery issueDeliveryObj =
        IssueDeliveryFactory.newInstance();

      resolutionStatus =
        issueDeliveryObj.readResolutionStatus(issueDeliveryKey);

      // BEGIN, CR00023124, RR
      // An appeal cannot be created if an appeal process has not been defined

      // IssueAppealProcess Service Layer object
      final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcess =
        IssueAppealProcessFactory.newInstance();

      final IssueDeliveryDtls issueDeliveryDtls =
        issueDeliveryObj.read(issueDeliveryKey);

      final ListIssueProcessDtls listIssueProcessDtls =
        new ListIssueProcessDtls();

      // BEGIN, CR00303986, SG
      listIssueProcessDtls.listIssueProcessDtls.caseType =
        caseTypeCode.caseTypeCode;
      // END, CR00303986

      listIssueProcessDtls.listIssueProcessDtls.caseTypeID =
        issueDeliveryDtls.issueConfigurationID;

      // No appeal processes defined for the issue case
      if (issueAppealProcess
        .listIssueProcess(listIssueProcessDtls).issueProcessList.dtls
          .size() == 0) {
        informationalManager.addInformationalMsg(
          new AppException(
            BPOISSUECASE.ERR_ISSUECASE_NO_APPEAL_PROCESS_CANNOT_APPEAL_ISSUE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
        informationalManager.failOperation();
      }
      // END, CR00023124

      // Checks if the resolution status of the issue case has been approved.
      // An appealed case can be created only.
      // if the issue case if approved.
      if (!resolutionStatus.resolutionStatus
        .equals(RESOLUTIONSTATUSCODE.APPROVED)) {
        informationalManager.addInformationalMsg(
          new AppException(
            BPOISSUECASE.ERR_ISSUECASE_NOT_APPROVED_CANNOT_APPEAL_ISSUE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
        informationalManager.failOperation();
      }
    }
    // END, CR00022238

    return key;
    // END, CR00022111
  }

  // ___________________________________________________________________________

  /**
   * Returns two independent lists, one list of valid participants from the
   * specified case which are eligible to be an appellant and another list of
   * valid respondents for an appeal regarding a decision made for the specified
   * case.
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return Struct which contains two separate lists, one list of valid
   * appellants & another containing valid respondents
   */
  @Override
  public AppealAppellantAndRespondentDetails
    listCaseParticipantsForAppellantAndRespondent(
      final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing participant details list for
    // appellant & respondent
    final AppealAppellantAndRespondentDetails appealAppellantAndRespondentDetails =
      new AppealAppellantAndRespondentDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN, CR00022302, RKi
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      // END, CR00303986
      // END, CR00022302

      // BEGIN, CR00022111, RKi
      final CaseIDDetails caseIDDetails = new CaseIDDetails();

      caseIDDetails.caseIDDetails.caseID = key.caseID;
      isIssueCaseApproved(caseIDDetails);
      // END, CR00022111
    }

    // Invoke facade method to obtain a list of valid APPELLANTS
    appealAppellantAndRespondentDetails.appellantList =
      listCaseParticipantsForAppellant(key).appealParticipantDetailsList;

    // Invoke facade method to obtain a list of valid RESPONDENTS
    appealAppellantAndRespondentDetails.respondentList =
      listCaseParticipantsForRespondent(key).appealParticipantDetailsList;

    return appealAppellantAndRespondentDetails;

  }

  // BEGIN, CR00424038, DM
  /**
   * Returns two independent lists, one list of valid m from the
   * specified case which are eligible to be an appellant and another list of
   * valid respondents for an appeal regarding a decision made for the specified
   * case.
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return Struct which contains two separate lists, one list of valid
   * appellants & another containing valid respondents
   */
  public AppealAppellantAndRespondentDetails
    listCaseMembersForAppellantAndRespondent(
      final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing member details list for
    // appellant & respondent
    final AppealAppellantAndRespondentDetails appealAppellantAndRespondentDetails =
      new AppealAppellantAndRespondentDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN, CR00022302, RKi
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // no need worry about appeals for Issue cases, as this CR is only for
    // product delivery cases
    // if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
    // END, CR00303986
    // END, CR00022302
    // BEGIN, CR00022111, RKi
    // CaseIDDetails caseIDDetails = new CaseIDDetails();
    // caseIDDetails.caseIDDetails.caseID = key.caseID;
    // isIssueCaseApproved(caseIDDetails);
    // END, CR00022111
    // }

    // Invoke facade method to obtain a list of valid APPELLANTS
    appealAppellantAndRespondentDetails.appellantList =
      listCaseMembersForAppellant(key).appealParticipantDetailsList;

    // Invoke facade method to obtain a list of valid RESPONDENTS
    appealAppellantAndRespondentDetails.respondentList =
      listCaseMembersForRespondent(key).appealParticipantDetailsList;

    return appealAppellantAndRespondentDetails;
  }

  // END, CR00424038, DM

  // _______________________________________________________________________
  /**
   * Returns a list of valid participants from the specified case which are
   * eligible to be a requester on an appeal regarding a decision made for the
   * specified case.
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return List of valid requester participants
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  /**
   * The key in the method parameter is unused. The method has
   * no implementation but yet provided,so that the customer can
   * override it and customize the functionality.
   */
  public AppealListMemberDetails
    listCaseParticipantsForRequester(final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // This method will not be implemented as part of work item 39880
    final UnimplementedException e = new UnimplementedException();

    throw e;

  }

  // ________________________________________________________________________
  /**
   * Returns a list of valid participants from the specified case which are
   * eligible to be a third party on an appeal regarding a decision made for the
   * specified case.
   *
   * <BR>
   * <BR>
   * Valid Third Party Participant Types:
   * <UL>
   * <LI>Primary Client</LI>
   * <LI>Employer</LI>
   * <LI>Third Party</LI>
   * </UL>
   * <BR>
   *
   * @param key
   * Contains the CaseID & PriorCaseID
   * @return List of valid third party participants
   */
  @Override
  public AppealListMemberDetails
    listCaseParticipantsForThirdParty(final AppealCaseIDPriorCaseID key)
      throws AppException, InformationalException {

    // Return object containing participant details list
    final AppealListMemberDetails appealListMemberDetails =
      new AppealListMemberDetails();

    // Participant Role Type Code Object
    final AppealParticipantRoleTypeCode appealParticipantRoleTypeCode =
      new AppealParticipantRoleTypeCode();

    // Appeal CaseID Object
    final curam.appeal.sl.struct.CaseIDDetails caseIDDetails =
      new curam.appeal.sl.struct.CaseIDDetails();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Set Participant type code to THIRD PARTY
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use PriorCaseID if supplied
    if (key.priorCaseID != 0) {
      caseIDDetails.caseID = key.priorCaseID;
    } else {
      caseIDDetails.caseID = key.caseID;
    }

    // Invoke service layer search for a list of valid third parties
    appealListMemberDetails.appealParticipantDetailsList =
      appealObj.listCaseParticipantsByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    return appealListMemberDetails;
  }

  /**
   * Performs a search for appeal cases using the search criteria provided.
   *
   * @param key
   * Search criteria for the appeal search
   * @return List of appeal cases for the search criteria specified.
   *
   * BEGIN, CR00397927, VT
   * @deprecated Since Curam 6.0.5.3,
   * replaced with {@link Appeal#searchAppeals(AppealCaseSearchKey key)} This
   * method is deprecated as the appealType attribute of input struct is
   * referring to incorrect domain definition.
   *
   * See release notes CR00397927/SPMP-11174.
   *
   * END, CR00397927
   */
  @Override
  @Deprecated
  public AppealSearchResultList search(final AppealSearchKey key)
    throws AppException, InformationalException {

    // Return Object
    final AppealSearchResultList appealSearchResultList =
      new AppealSearchResultList();

    // Appeal Search Object & Key Struct
    final AppealSearchRouter appealSearchRouterObj =
      AppealSearchRouterFactory.newInstance();
    final curam.appeal.sl.struct.AppealSearchKey appealSearchKey =
      new curam.appeal.sl.struct.AppealSearchKey();

    // Register the security implementation
    SecurityImplementationFactory.register();

    appealSearchKey.assign(key);

    // The facade appellant & respondent appellant types use the
    // SEARCHAPPELLANTTYPE domain definition in order to display only two types
    // i.e. ORGANIZATION & PARTICIPANT. These types are mapped the corresponding
    // values as defined in the APPELLANTTYPE domain definition in
    // the service layer.
    if (SEARCHAPPELLANTTYPE.ORGANIZATION.equals(key.appellantType)) {
      appealSearchKey.appellantType = APPELLANTTYPE.ORGANIZATION;
    } else if (SEARCHAPPELLANTTYPE.PARTICIPANT.equals(key.appellantType)) {
      appealSearchKey.appellantType = APPELLANTTYPE.CLAIMANT;
    }
    if (SEARCHAPPELLANTTYPE.ORGANIZATION.equals(key.respondentType)) {
      appealSearchKey.respondentType = APPELLANTTYPE.ORGANIZATION;
    } else if (SEARCHAPPELLANTTYPE.PARTICIPANT.equals(key.respondentType)) {
      appealSearchKey.respondentType = APPELLANTTYPE.CLAIMANT;
    }

    // Search for appeal cases using the criteria specified
    appealSearchResultList.appealSearchResultList =
      appealSearchRouterObj.search(appealSearchKey);

    return appealSearchResultList;

  }

  // BEGIN, CR00021313, RKi
  // ___________________________________________________________________________
  /**
   * This method checks if multiple appellants exists on a particular case.
   *
   * @param key
   * Contains the AppealCaseID
   *
   * @return The boolean value indicating multiple appellants on a particular
   * case.
   */
  @Override
  public MultipleAppellantsOnCaseInd multipleAppellantsIndicator(
    final AppealCaseKey_fo key) throws AppException, InformationalException {

    final MultipleAppellantsOnCaseInd multipleAppellantsOnCaseInd =
      new MultipleAppellantsOnCaseInd();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    final curam.appeal.sl.struct.AppealCaseKey appealCaseKey =
      new curam.appeal.sl.struct.AppealCaseKey();

    appealCaseKey.caseID = key.appealCaseKey.caseID;

    multipleAppellantsOnCaseInd.multipleAppellants = appealObj
      .multipleAppellantsIndicatorOnCase(appealCaseKey).multipleAppellants;

    return multipleAppellantsOnCaseInd;
  }

  // END, CR00021313

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * concern role.
   *
   * @param key The unique id for the concern role.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForConcernRole(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Get the context description for the concern role
    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // Search for appeal cases
    appealsForConcernRoleDetailsList.dtlsList =
      appealObj.listAppealForConcernRole(key);

    // BEGIN, CR00124305, RKi
    // Set menu data for displaying any duplicate client issues
    concernRoleKey.concernRoleID = key.concernRoleID;

    // BEGIN, CR00223852, JF
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00124305, RKi
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj =
        curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00124305

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      dupPageIdentifier.pageIdentifier =
        GeneralAppealConstants.kPerson_listAppealForDuplicate;
      origPageIdentifier.pageIdentifier =
        GeneralAppealConstants.kPerson_listAppeal;
      concernRoleKey.concernRoleID = key.concernRoleID;

      appealsForConcernRoleDetailsList.menuData =
        clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
          origPageIdentifier);

      // Set an indicator if this concern has duplicates
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
        new ConcernRoleIDStatusCodeKey();

      // Set the concern role id and status
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Check for duplicates
      appealsForConcernRoleDetailsList.ind = clientMergeSLObj
        .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
      // END, CR00124305
    }
    // END, CR00223852

    return appealsForConcernRoleDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all Appeals Cases for a specified
   * duplicate concern role.
   *
   * @param key The unique id for the duplicate concern role.
   *
   * @return The list of issue delivery details for the duplicate concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForDuplicateConcernRole(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // Search for appeal delivery cases
    appealsForConcernRoleDetailsList.dtlsList =
      appealObj.listAppealForConcernRole(key);

    // BEGIN, CR00266910, MC
    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // ConcernRoleDuplicate manipulation variables
      final ConcernRoleDuplicate concernRoleDuplicateObj =
        ConcernRoleDuplicateFactory.newInstance();
      ConcernRoleDuplicateDtlsList dupList =
        new ConcernRoleDuplicateDtlsList();
      final SearchByDuplicateConcernRoleIDKey dupKey =
        new SearchByDuplicateConcernRoleIDKey();

      // Get original person concern role ID by searching on the duplicate ID
      dupKey.duplicateConcernRoleID = key.concernRoleID;
      dupList =
        concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

      // Set the context description key to be the original concern role ID
      participantContextKey.participantContextDescriptionKey.concernRoleID =
        dupList.dtls.item(0).originalConcernRoleID;

      // Set the key for appeal delivery case search
      final RelationshipConcernRoleIDKey relConcernRoleIDKey =
        new RelationshipConcernRoleIDKey();

      relConcernRoleIDKey.concernRoleID = key.concernRoleID;

      // BEGIN, CR00124305, RKi
      // ClientMerge manipulation variable
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();

      // Set menu data for displaying any duplicate client issues
      key.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      dupPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listIssueForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssue;
      concernRoleKey.concernRoleID = key.concernRoleID;

      appealsForConcernRoleDetailsList.menuData =
        clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
          origPageIdentifier);
      // END, CR00124305
    }

    // Get the context description for the original concern role
    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // END, CR00266910

    return appealsForConcernRoleDetailsList;
  }

  // END, CR00096787

  // BEGIN, CR00083140, RKi
  // ___________________________________________________________________________
  /**
   * Method to list all appeal types
   *
   * @return a list of all appeal types
   */
  @Override
  public AppealTypes listAllAppealTypes()
    throws AppException, InformationalException {

    // Return struct
    final AppealTypes appealTypes = new AppealTypes();

    // service layer object
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Get the list of all appeal types
    appealTypes.appealTypes = appealObj.listAllAppealTypes();

    return appealTypes;
  }

  // END, CR00083140

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * Employer.
   *
   * @param key The unique id for the Employer.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForDuplicateEmployer(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // BEGIN, CR00266910, MC
    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // Concern RoleDuplicate manipulation variables
      final ConcernRoleDuplicate concernRoleDuplicateObj =
        ConcernRoleDuplicateFactory.newInstance();
      ConcernRoleDuplicateDtlsList dupList =
        new ConcernRoleDuplicateDtlsList();
      final SearchByDuplicateConcernRoleIDKey dupKey =
        new SearchByDuplicateConcernRoleIDKey();

      // Get original Employer concern role ID by searching on the
      // duplicate ID
      dupKey.duplicateConcernRoleID = key.concernRoleID;
      dupList =
        concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

      // Set the context description key to be the original concern role ID
      participantContextKey.participantContextDescriptionKey.concernRoleID =
        dupList.dtls.item(0).originalConcernRoleID;

      // Set the key for appeal delivery case search
      final RelationshipConcernRoleIDKey relConcernRoleIDKey =
        new RelationshipConcernRoleIDKey();

      relConcernRoleIDKey.concernRoleID = key.concernRoleID;

      // Search for appeal delivery cases
      appealsForConcernRoleDetailsList.dtlsList =
        appealObj.listAppealForConcernRole(key);

      // BEGIN, CR00124305, RKi
      // ClientMerge manipulation variable
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();

      // Set menu data for displaying any duplicate client issues
      key.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      dupPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listIssueForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssue;
      concernRoleKey.concernRoleID = key.concernRoleID;

      appealsForConcernRoleDetailsList.menuData =
        clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
          origPageIdentifier);
      // END, CR00124305
    }

    // Get the context description for the original Employer
    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // END, CR00266910
    return appealsForConcernRoleDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * Prospect Employer.
   *
   * @param key The unique id for the Prospect Employer.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForDuplicateProspectEmployer(
      final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // BEGIN, CR00266910, MC
    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // Concern Role Duplicate manipulation variables
      final ConcernRoleDuplicate concernRoleDuplicateObj =
        ConcernRoleDuplicateFactory.newInstance();
      ConcernRoleDuplicateDtlsList dupList =
        new ConcernRoleDuplicateDtlsList();
      final SearchByDuplicateConcernRoleIDKey dupKey =
        new SearchByDuplicateConcernRoleIDKey();

      // Get original Prospect Employer concern role ID by searching
      // on the duplicate ID
      dupKey.duplicateConcernRoleID = key.concernRoleID;
      dupList =
        concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

      // Set the context description key to be the original Prospect Employer ID
      participantContextKey.participantContextDescriptionKey.concernRoleID =
        dupList.dtls.item(0).originalConcernRoleID;

      // Get the context description for the original Prospect Employer
      appealsForConcernRoleDetailsList.description.description =
        participantObj.readContextDescription(
          participantContextKey).participantContextDescriptionDetails.description;

      // Set the key for appeal delivery case search
      final RelationshipConcernRoleIDKey relConcernRoleIDKey =
        new RelationshipConcernRoleIDKey();

      relConcernRoleIDKey.concernRoleID = key.concernRoleID;

      // Search for appeal delivery cases
      appealsForConcernRoleDetailsList.dtlsList =
        appealObj.listAppealForConcernRole(key);

      // BEGIN, CR00124305, RKi
      // ClientMerge manipulation variable
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();

      // Set menu data for displaying any duplicate client issues
      key.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      dupPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listIssueForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssue;
      concernRoleKey.concernRoleID = key.concernRoleID;

      appealsForConcernRoleDetailsList.menuData =
        clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
          origPageIdentifier);
      // END, CR00124305
    }

    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;
    // END, CR00266910

    return appealsForConcernRoleDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * Employer.
   *
   * @param key The unique id for the Prospect Employer.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForEmployer(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    // BEGIN, CR00124305, RKi
    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj =
      curam.core.sl.fact.ClientMergeFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // END, CR00124305

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Get the context description for the concern role
    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // Search for appeal cases
    appealsForConcernRoleDetailsList.dtlsList =
      appealObj.listAppealForConcernRole(key);

    // BEGIN, CR00124305, RKi
    // Set menu data for displaying any duplicate client issues
    concernRoleKey.concernRoleID = key.concernRoleID;

    // set the pages to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    dupPageIdentifier.pageIdentifier =
      GeneralAppealConstants.kPerson_listAppealForDuplicate;
    origPageIdentifier.pageIdentifier =
      GeneralAppealConstants.kPerson_listAppeal;
    concernRoleKey.concernRoleID = key.concernRoleID;

    appealsForConcernRoleDetailsList.menuData =
      clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
        origPageIdentifier);

    // Set an indicator if this concern has duplicates
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
      new ConcernRoleIDStatusCodeKey();

    // Set the concern role id and status
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Check for duplicates
    appealsForConcernRoleDetailsList.ind = clientMergeSLObj
      .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    // END, CR00124305

    return appealsForConcernRoleDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * Prospect Person.
   *
   * @param key The unique id for the Prospect Employer.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForDuplicateProspectPerson(
      final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // BEGIN, CR00266910, MC
    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // ConcernRoleDuplicate manipulation variables
      final ConcernRoleDuplicate concernRoleDuplicateObj =
        ConcernRoleDuplicateFactory.newInstance();
      ConcernRoleDuplicateDtlsList dupList =
        new ConcernRoleDuplicateDtlsList();
      final SearchByDuplicateConcernRoleIDKey dupKey =
        new SearchByDuplicateConcernRoleIDKey();

      // Get original Prospect Person concern role ID by searching on the
      // duplicate ID
      dupKey.duplicateConcernRoleID = key.concernRoleID;
      dupList =
        concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

      // Set the context description key to be the original concern role ID
      participantContextKey.participantContextDescriptionKey.concernRoleID =
        dupList.dtls.item(0).originalConcernRoleID;

      // Get the context description for the original concern role
      appealsForConcernRoleDetailsList.description.description =
        participantObj.readContextDescription(
          participantContextKey).participantContextDescriptionDetails.description;

      // Set the key for appeal delivery case search
      final RelationshipConcernRoleIDKey relConcernRoleIDKey =
        new RelationshipConcernRoleIDKey();

      relConcernRoleIDKey.concernRoleID = key.concernRoleID;

      // Search for appeal delivery cases
      appealsForConcernRoleDetailsList.dtlsList =
        appealObj.listAppealForConcernRole(key);

      // BEGIN, CR00124305, RKi
      // ClientMerge manipulation variable
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();

      // Set menu data for displaying any duplicate client issues
      key.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      dupPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listIssueForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listIssue;
      concernRoleKey.concernRoleID = key.concernRoleID;

      appealsForConcernRoleDetailsList.menuData =
        clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
          origPageIdentifier);
      // END, CR00124305
    }

    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // END, CR00266910

    return appealsForConcernRoleDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * Prospect Employer.
   *
   * @param key The unique id for the Prospect Employer.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForProspectEmployer(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    // BEGIN, CR00124305, RKi
    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj =
      curam.core.sl.fact.ClientMergeFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // END, CR00124305

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // Get the context description for the concern role
    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // Search for appeal cases
    appealsForConcernRoleDetailsList.dtlsList =
      appealObj.listAppealForConcernRole(key);

    // BEGIN, CR00124305, RKi
    // Set menu data for displaying any duplicate client issues
    concernRoleKey.concernRoleID = key.concernRoleID;

    // set the pages to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    dupPageIdentifier.pageIdentifier =
      GeneralAppealConstants.kPerson_listAppealForDuplicate;
    origPageIdentifier.pageIdentifier =
      GeneralAppealConstants.kPerson_listAppeal;
    concernRoleKey.concernRoleID = key.concernRoleID;

    appealsForConcernRoleDetailsList.menuData =
      clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
        origPageIdentifier);

    // Set an indicator if this concern has duplicates
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
      new ConcernRoleIDStatusCodeKey();

    // Set the concern role id and status
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Check for duplicates
    appealsForConcernRoleDetailsList.ind = clientMergeSLObj
      .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    // END, CR00124305

    return appealsForConcernRoleDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to retrieve all appeal cases for a specified
   * Prospect person.
   *
   * @param key The unique id for the concern role.
   *
   * @return The list of appeal case details for the concern.
   */
  @Override
  public AppealsForConcernRoleDetailsList
    listAppealsForProspectPerson(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Appeal manipulation variable
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();

    // Participant manipulation variable
    final curam.core.facade.intf.Participant participantObj =
      curam.core.facade.fact.ParticipantFactory.newInstance();

    // Return struct
    final AppealsForConcernRoleDetailsList appealsForConcernRoleDetailsList =
      new AppealsForConcernRoleDetailsList();

    // Set the Context key
    final ParticipantContextKey participantContextKey =
      new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // BEGIN, CR00124305, RKi
    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj =
      curam.core.sl.fact.ClientMergeFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // END, CR00124305

    // Get the context description for the concern role
    appealsForConcernRoleDetailsList.description.description =
      participantObj.readContextDescription(
        participantContextKey).participantContextDescriptionDetails.description;

    // Search for appeal cases
    appealsForConcernRoleDetailsList.dtlsList =
      appealObj.listAppealForConcernRole(key);

    // BEGIN, CR00124305, RKi
    // Set menu data for displaying any duplicate client issues
    concernRoleKey.concernRoleID = key.concernRoleID;

    // set the pages to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    dupPageIdentifier.pageIdentifier =
      GeneralAppealConstants.kPerson_listAppealForDuplicate;
    origPageIdentifier.pageIdentifier =
      GeneralAppealConstants.kPerson_listAppeal;
    concernRoleKey.concernRoleID = key.concernRoleID;

    appealsForConcernRoleDetailsList.menuData =
      clientMergeObj.getDuplicateMenuData(concernRoleKey, dupPageIdentifier,
        origPageIdentifier);

    // Set an indicator if this concern has duplicates
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
      new ConcernRoleIDStatusCodeKey();

    // Set the concern role id and status
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Check for duplicates
    appealsForConcernRoleDetailsList.ind = clientMergeSLObj
      .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    // END, CR00124305

    return appealsForConcernRoleDetailsList;
  }

  // BEGIN, CR00124809, RKi
  // __________________________________________________________________________
  /**
   * Resolves the home page for third party and witness and external party
   * member.
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key The concern Role ID of the record being read.
   * @return The home page name.
   */
  @Override
  public ParticipantHomePageName
    resolveMemberHome(final ConcernRoleKeyStruct key)
      throws AppException, InformationalException {

    // Return struct
    ParticipantHomePageName participantHomePageName =
      new ParticipantHomePageName();

    // Concern Role object
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read the concern role details
    concernRoleTypeDetails =
      concernRoleObj.readConcernRoleType(concernRoleKey);

    // If the concern role is of type representative
    if (concernRoleTypeDetails.concernRoleType
      .equals(CONCERNROLETYPE.REPRESENTATIVE)) {
      // Set home page name to representative home
      participantHomePageName.participantHomePageName =
        GeneralAppealConstants.krepresentativeHomePageName;
    } else {
      final curam.core.facade.intf.Product product =
        ProductFactory.newInstance();

      // check for other types
      participantHomePageName = product.resolveMemberHome(key);
    }

    return participantHomePageName;
  }

  // END, CR00124809

  // BEGIN, CR00267114, ZV
  // ___________________________________________________________________________
  /**
   * Returns the overall decision for an appeal case in addition to the list of
   * appealed cases and their resolutions being considered as part of the appeal
   * case. Returns attachment details list associated to decision.
   *
   * @param key
   * The appeal case to return the decision.
   *
   * @return The overall appeal case decision and the list of appealed cases and
   * their resolutions.
   */
  @Override
  public DecisionAndAttachmentListDetails readDecisionAndAttachmentList(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Appeal object and structs
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final DecisionAndAttachmentListDetails decisionDetails =
      new DecisionAndAttachmentListDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Assign the details
    decisionDetails.decisionDetails =
      appealObj.readDecisionAndAttachmentList(key.appealCaseKey);

    return decisionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the overall decision for an appeal case in addition to the list of
   * appealed cases and their resolutions being considered as part of the appeal
   * case. Returns attachment details list associated to decision.
   *
   * @param key
   * The appeal case to return the decision.
   *
   * @return The overall appeal case decision and the list of appealed cases and
   * their resolutions.
   */
  @Override
  public DecisionAndAttachmentListDetailsForIC
    readDecisionAndAttachmentListForIC(final AppealCaseKey key)
      throws AppException, InformationalException {

    // Appeal object and return struct
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final DecisionAndAttachmentListDetailsForIC decisionDetailsForIC =
      new DecisionAndAttachmentListDetailsForIC();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    AppealMenuData appealMenuData;

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Get the menu data
    appealCaseDetails.caseID = key.appealCaseKey.caseID;
    appealMenuData = appealObj.getMenuData(appealCaseDetails);

    // Assign the details
    decisionDetailsForIC.appealMenuData = appealMenuData;
    decisionDetailsForIC.decisionDetails =
      appealObj.readDecisionAndAttachmentList(key.appealCaseKey);
    decisionDetailsForIC.contextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    return decisionDetailsForIC;
  }

  // END, CR00267114
  /**
   * Returns all the appealed cases for a given appealCaseID and all of it
   * related cases.
   *
   * @param caseKey
   * The appeal case to return the details
   *
   * @return the struct containing all the appeal case details
   */
  @Override
  public AppealCaseAllDetailsList listAppealCaseDetailsForIC(
    final AppealCaseKey caseKey) throws AppException, InformationalException {

    // return struct
    final AppealCaseAllDetailsList appealCaseAllDetailsList =
      new AppealCaseAllDetailsList();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    appealCaseAllDetailsList.dtls =
      appealObj.listAppealCaseDetailsForIC(caseKey.appealCaseKey);

    return appealCaseAllDetailsList;
  }

  // BEGIN ,CR00284371 , DK
  /**
   * Returns a List of everything related to an appeal case.
   *
   * @param caseKey
   * The appeal case to return the details
   *
   * @return the struct containing all the appeal related details
   */
  @Override
  public AppealAllRelatedDetailsList listAllRelatedByAppealCase(
    final AppealCaseKey key) throws AppException, InformationalException {

    // return struct
    final AppealAllRelatedDetailsList appealAllRelatedDetailsList =
      new AppealAllRelatedDetailsList();
    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // populate the return list
    appealAllRelatedDetailsList.relatedDetails =
      appealObj.listAllRelatedByAppealCase(key.appealCaseKey);
    // BEGIN , CR00289874 , DK
    appealAllRelatedDetailsList.defaultResolutionCode =
      HEARINGDECISIONRESOLUTION.getDefaultCode();
    // END , CR00289874 , DK
    return appealAllRelatedDetailsList;
  }

  // END , CR00284371 , DK

  /**
   * Calls the list Bookmark method from CEF and then does some appeals specific
   * processing
   * to get the description and reference for the appeal
   *
   * @param key
   * The bookmark key
   *
   * @return the struct containing all the bookmarks
   */
  @Override
  public BookmarkDetailsStructList listBookmark(final ListBookmarkKey key)
    throws AppException, InformationalException {

    // return struct
    BookmarkDetailsStructList bookmarkDetailsStructList =
      new BookmarkDetailsStructList();

    // Call list bookmark from CEF to get all case book marks
    bookmarkDetailsStructList =
      BookmarkFactory.newInstance().listBookmark(key);

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey;

    // loop through all bookmarks
    for (int i = 0; i < bookmarkDetailsStructList.dtls.dtlsList.size(); i++) {

      caseHeaderKey = new CaseHeaderKey();
      caseHeaderKey.caseID =
        bookmarkDetailsStructList.dtls.dtlsList.item(i).referenceNo;
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // if the bookmark is of type appeal, then set appeal specific info
      if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
        // set the details panel for an appeal
        bookmarkDetailsStructList.dtls.dtlsList
          .item(i).caseContextDetailsURL =
            curam.appeal.impl.CuramConst.kAppealPreviewPage;
        bookmarkDetailsStructList.dtls.dtlsList
          .item(i).caseContextDetailsURL +=
            CuramConst.kQuestion + CuramConst.gkPageParameterCaseID
              + CuramConst.gkEqualsNoSpaces + caseHeaderKey.caseID;
        // appeal object
        final curam.appeal.sl.entity.intf.Appeal appeal =
          curam.appeal.sl.entity.fact.AppealFactory.newInstance();
        final AppealKey appealKey = new AppealKey();
        final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

        appealCaseIDKey.caseID = caseHeaderKey.caseID;
        appealKey.appealID =
          appeal.readAppealIDByCase(appealCaseIDKey).appealID;
        // concern role object
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
        final ConcernRoleDtls concernRoleDtls =
          concernRoleObj.read(concernRoleKey);
        // set the reference for the appeal
        final String appealTypeDescription =
          curam.util.type.CodeTable.getOneItem(APPEALTYPEEntry.TABLENAME,
            appeal.read(appealKey).appealTypeCode);

        bookmarkDetailsStructList.dtls.dtlsList.item(i).reference =
          appealTypeDescription + CuramConst.gkSpace
            + caseHeaderDtls.caseReference + CuramConst.kSeparator
            + concernRoleDtls.concernRoleName + CuramConst.gkSpace
            + concernRoleDtls.primaryAlternateID;
      }
    }
    // return list
    return bookmarkDetailsStructList;
  }

  /**
   * Add a list of appeal objects to an existing appeals case.
   *
   * The string of objects should be in the form: ObjectID,ObjectTypeCode|
   * E.g. "1001,AOT1|2001,AOT2|2002,AOT2" represents three objects passed in.
   * Each object type code must have a corresponding entry in the
   * AppealObjectType
   * codetable and an implementation of the appeal object interface class.
   *
   * @param details Details of the appeal objects to add to an appeals case.
   */
  @Override
  public void addAppealObjectsToCase(final AddAppealObjectsDetails details)
    throws AppException, InformationalException {

    AppealFactory.newInstance().addAppealObjectsToCase(details);
  }

  // BEGIN , ,DK
  @Deprecated
  @Override
  public ReadForCreateAppealDetails
    readForCreateAppeal(final CaseIDPriorAppealID caseIDPriorAppealID)
      throws AppException, InformationalException {

    // Return struct
    final ReadForCreateAppealDetails readForCreateAppealDetails =
      new ReadForCreateAppealDetails();
    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseIDPriorCaseID key = new AppealCaseIDPriorCaseID();

    key.caseID = caseIDPriorAppealID.caseIDpriorAppealID.caseID;
    // Get list of appellants and respondents
    readForCreateAppealDetails.AppAndResDtls =
      listCaseParticipantsForAppellantAndRespondent(key);
    // Get the details for the create screen
    readForCreateAppealDetails.dtls =
      appealObj.readForCreateAppeal(caseIDPriorAppealID.caseIDpriorAppealID);
    return readForCreateAppealDetails;
  }

  // START, CR00424038, DM
  @Override
  /**
   * Gets the details that are necessary
   * to populate the fields for creating a new appeal.
   *
   * @param caseIDPriorAppealID
   * The case id key
   *
   * @return the struct containing all the details
   */
  public ReadForCreateAppealDetails
    readForCreateNewAppeal(final CaseIDPriorAppealID caseIDPriorAppealID)
      throws AppException, InformationalException {

    // Return struct
    final ReadForCreateAppealDetails readForCreateAppealDetails =
      new ReadForCreateAppealDetails();
    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseIDPriorCaseID key = new AppealCaseIDPriorCaseID();

    key.caseID = caseIDPriorAppealID.caseIDpriorAppealID.caseID;
    // Get list of appellants and respondents
    readForCreateAppealDetails.AppAndResDtls =
      listCaseMembersForAppellantAndRespondent(key);
    // Get the details for the create screen
    readForCreateAppealDetails.dtls =
      appealObj.readForCreateAppeal(caseIDPriorAppealID.caseIDpriorAppealID);
    return readForCreateAppealDetails;
  }

  // END, CR00424038

  /**
   * {@inheritDoc}
   */
  @Override
  public AppealCaseKey createAppeal(final CreateAppealDetails details)
    throws AppException, InformationalException {

    // Return key
    final AppealCaseKey key = new AppealCaseKey();
    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Create the appeal
    key.appealCaseKey = appealObj.createAppeal(details.dtls);
    return key;
  }

  // END , ,DK

  /**
   * Get the properties for the create wizard.
   *
   * @param key The case identifier.
   * @return The properties for the create wizard.
   */
  @Override
  public AppealCreateWizardProperties getCreateWizardProperties(
    final CaseID key) throws AppException, InformationalException {

    final AppealCreateWizardProperties appealCreateWizardProperties =
      new AppealCreateWizardProperties();

    // Read the case type
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseType =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    // Get the AppealableCaseType implementation for the case type.
    final AppealableCaseType appealableCaseType =
      appealableCaseTypeMap.get(CASETYPECODEEntry.get(caseType.caseTypeCode));

    if (appealableCaseType != null) {
      appealCreateWizardProperties.wizardMenu =
        appealableCaseType.getCreateWizardProperties();
    }

    // Return the wizard properties
    return appealCreateWizardProperties;
  }

  /**
   * Get the start page URI for the first page in the create wizard.
   *
   * @param key The case identifier.
   * @return The URI of the first page in the wizard.
   */
  @Override
  public WizardPageName getCreateWizardStartPage(final CaseID key)
    throws AppException, InformationalException {

    final WizardPageName wizardPageName = new WizardPageName();

    // Read the case type
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseType =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    // Get the AppealableCaseType implementation for the case type.
    final AppealableCaseType appealableCaseType =
      appealableCaseTypeMap.get(CASETYPECODEEntry.get(caseType.caseTypeCode));

    final curam.core.struct.CaseID caseID = new curam.core.struct.CaseID();

    caseID.caseID = key.caseID;
    // Return the page name
    if (appealableCaseType != null) {
      wizardPageName.pageURI =
        appealableCaseType.getCreateWizardURI(caseID).getURI();
    }
    return wizardPageName;
  }

  // BEGIN, CR00397927, VT
  /**
   * Performs a search for appeal cases using the search criteria provided.
   *
   * @param key
   * Contains search criteria for the appeal search
   * @return return list of appeal cases for the search criteria specified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AppealSearchResultList searchAppeals(final AppealCaseSearchKey key)
    throws AppException, InformationalException {

    final AppealSearchResultList appealSearchResultList =
      new AppealSearchResultList();
    final AppealSearchRouter appealSearchRouterObj =
      AppealSearchRouterFactory.newInstance();

    final curam.appeal.sl.struct.AppealSearchKey appealSearchKey =
      new curam.appeal.sl.struct.AppealSearchKey();

    // Register the security implementation
    SecurityImplementationFactory.register();

    appealSearchKey.assign(key);

    // The facade appellant & respondent appellant types use the
    // SEARCHAPPELLANTTYPE domain definition in order to display only two types
    // i.e. ORGANIZATION & PARTICIPANT. These types are mapped the corresponding
    // values as defined in the APPELLANTTYPE domain definition in
    // the service layer.
    if (SEARCHAPPELLANTTYPE.ORGANIZATION.equals(key.appellantType)) {
      appealSearchKey.appellantType = APPELLANTTYPE.ORGANIZATION;
    } else if (SEARCHAPPELLANTTYPE.PARTICIPANT.equals(key.appellantType)) {
      appealSearchKey.appellantType = APPELLANTTYPE.CLAIMANT;
    }
    if (SEARCHAPPELLANTTYPE.ORGANIZATION.equals(key.respondentType)) {
      appealSearchKey.respondentType = APPELLANTTYPE.ORGANIZATION;
    } else if (SEARCHAPPELLANTTYPE.PARTICIPANT.equals(key.respondentType)) {
      appealSearchKey.respondentType = APPELLANTTYPE.CLAIMANT;
    }

    appealSearchResultList.appealSearchResultList =
      appealSearchRouterObj.search(appealSearchKey);

    return appealSearchResultList;
  }

  // END, CR00397927

  // BEGIN, CR00434821, SPD
  /**
   * This method is used to firstly parse the determination history tab list
   * which
   * represents the user selected entries which are to be appealed. The returned
   * string is in the agreed format for appeals functionality processing. This
   * method also determines the effective date for the determination appeal.
   * This
   * date is represented by the determination with the oldest creation date.
   *
   * @param determinationTabList Tab separated list of entries.
   *
   * @return Formatted string of appeal objects and the effective date of the
   * determination appeal
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public DeterminationObjectDetails getAppealableObjectsFromTabList(
    final AppealObjectTabList determinationTabList)
    throws AppException, InformationalException {

    final DeterminationObjectDetails determinationObjectDetails =
      new DeterminationObjectDetails();

    DateTime earliestdate = Date.getCurrentDate().getDateTime();

    // 1. Parse tab delimited list of determinations into list
    final StringList determinationDetailsStringList =
      StringUtil.tabText2StringListWithTrim(determinationTabList.tabList);

    // 2. Parse list to find determination details
    for (int i = 0; i < determinationDetailsStringList.size(); i++) {

      // Get the determination
      final Long determinationID =
        new Long(determinationDetailsStringList.get(i));
      final CREOLECaseDeterminationAccessor creoleCaseDeterminationAccessor =
        creoleCaseDeterminationAccessorDAO.get(determinationID);

      // Get the creation date for the determination
      final DateTime determinationDateTime = new DateTime(
        creoleCaseDeterminationAccessor.getDeterminationDateTime());

      // Determine the effective date for the determination appeal
      if (i == 0) {
        earliestdate = determinationDateTime;
      } else {
        if (determinationDateTime.before(earliestdate)) {
          ;
        }
        earliestdate = determinationDateTime;
      }

      // Build up string against agreed format for appeals processing
      determinationObjectDetails.objectIDListString +=
        determinationDetailsStringList.item(i)
          + CuramConst.gkCommaDelimiterChar + APPEALOBJECTTYPE.DETERMINATION;

      if (i < determinationDetailsStringList.size() - 1) {
        determinationObjectDetails.objectIDListString +=
          CuramConst.gkPipeDelimiterChar;
      }
    }

    // at this point, the effective date will represent the earliest creation
    // date from the selected list of determinations
    determinationObjectDetails.effectiveDate = new Date(earliestdate);

    return determinationObjectDetails;
  }
  // END, CR00434821
}
