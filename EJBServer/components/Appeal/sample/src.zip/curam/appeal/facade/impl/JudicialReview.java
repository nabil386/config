/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2003-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.ActiveJudicialReviewDetailsList;
import curam.appeal.facade.struct.CaseAppealLevelDetails;
import curam.appeal.facade.struct.CaseIDDetails;
import curam.appeal.facade.struct.CaseType;
import curam.appeal.facade.struct.CloseJudicialReviewDetails;
import curam.appeal.facade.struct.CreateJudicialDecisionDetails;
import curam.appeal.facade.struct.DecisionsForCaseDetailsList;
import curam.appeal.facade.struct.DecisionsForCaseKey;
import curam.appeal.facade.struct.JudicialReviewAddCaseDetails;
import curam.appeal.facade.struct.JudicialReviewAppellantAndRespondentReturnDetails;
import curam.appeal.facade.struct.JudicialReviewCaseKey_fo;
import curam.appeal.facade.struct.JudicialReviewCaseSummaryDetails;
import curam.appeal.facade.struct.JudicialReviewCaseSummaryDetailsIC;
import curam.appeal.facade.struct.JudicialReviewCreateDetails;
import curam.appeal.facade.struct.JudicialReviewReadModifyDetails;
import curam.appeal.facade.struct.ModifyJudicialReviewDetails;
import curam.appeal.facade.struct.ParticipantRoleKey;
import curam.appeal.facade.struct.ReadForCreateJudicialReviewDetails;
import curam.appeal.facade.struct.ReadForCreateJudicialReviewKey;
import curam.appeal.sl.fact.JudicialReviewFactory;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppellantAndRespondentDetails;
import curam.appeal.sl.struct.CaseIDAppealTypeCode;
import curam.appeal.sl.struct.CreateJudicialReviewAndAppealObjectsDetails;
import curam.appeal.sl.struct.DecisionsForImplCaseKey;
import curam.appeal.sl.struct.JudicialReviewCaseKey;
import curam.appeal.sl.struct.ReadForCreateDetails;
import curam.appeal.sl.struct.ValidateAppealedCaseLevelDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.core.fact.OrganisationFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.GeneralConstants;

/**
 * This process class provides the functionality for the Judicial Review facade.
 * 
 */
public abstract class JudicialReview extends
  curam.appeal.facade.base.JudicialReview {

  // ___________________________________________________________________________
  /**
   * Creates an judicial review decision
   * 
   * @param key
   * The details of the decision
   */
  @Override
  public void createDecision(final CreateJudicialDecisionDetails key)
    throws AppException, InformationalException {

    // JudicialReview object
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Create the decision
    judicialReviewObj.createDecision(key.createJudicialDecisionDetails);
  }

  // ___________________________________________________________________________
  /*
   * This method retrieves a summary of a judicial review case.
   * 
   * @param key Unique internal reference number of the judicial review case
   * 
   * @return The details of the judicial review
   */
  @Override
  public JudicialReviewCaseSummaryDetails readJudicialReviewSummary(
    final JudicialReviewCaseKey_fo key) throws AppException,
    InformationalException {

    // Judicial review objects
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return object
    final JudicialReviewCaseSummaryDetails judicialReviewCaseSummaryDetails =
      new JudicialReviewCaseSummaryDetails();

    // Security registration
    SecurityImplementationFactory.register();

    // Retrieve the summary details
    judicialReviewCaseSummaryDetails.judicialReviewCaseSummaryDetails
      .assign(judicialReviewObj.readSummary(key.judicialReviewCaseKey));

    // Retrieve the context description
    appealCaseDetails.caseID = key.judicialReviewCaseKey.caseID;
    judicialReviewCaseSummaryDetails.appealContextDescription =
      appeal_boObj.getContextDescription(appealCaseDetails);

    // Return the summary details
    return judicialReviewCaseSummaryDetails;

  }

  // ___________________________________________________________________________
  /*
   * This method retrieves a summary of a judicial review case as part of an
   * integrated case
   * 
   * @param key Unique internal reference number of the judicial review case
   * 
   * @return The details of the judicial review
   */
  @Override
  public JudicialReviewCaseSummaryDetailsIC readJudicialReviewSummaryIC(
    final JudicialReviewCaseKey_fo key) throws AppException,
    InformationalException {

    // Judicial review objects
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return object
    final JudicialReviewCaseSummaryDetailsIC judicialReviewCaseSummaryDetailsIC =
      new JudicialReviewCaseSummaryDetailsIC();

    // Security registration
    SecurityImplementationFactory.register();

    // Retrieve the summary details
    judicialReviewCaseSummaryDetailsIC.judicialReviewCaseSummaryDetails
      .assign(judicialReviewObj.readSummary(key.judicialReviewCaseKey));

    // Retrieve the context description
    appealCaseDetails.caseID = key.judicialReviewCaseKey.caseID;
    judicialReviewCaseSummaryDetailsIC.appealContextDescription =
      appeal_boObj.getContextDescription(appealCaseDetails);

    // Retrieve the menu data
    judicialReviewCaseSummaryDetailsIC.appealMenuData =
      appeal_boObj.getMenuData(appealCaseDetails);

    // Return the summary details
    return judicialReviewCaseSummaryDetailsIC;

  }

  // ___________________________________________________________________________
  /**
   * Modifies the judicial review.
   * 
   * @param details
   * The details of the judicial review case being modified
   */
  @Override
  public void modifyJudicialReview(final ModifyJudicialReviewDetails details)
    throws AppException, InformationalException {

    // HearingReview object
    final curam.appeal.sl.intf.JudicialReview judicialReview =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Update the hearing review
    judicialReview.modify(details.judicialReviewModifyWithoutDeadlineDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to read judicial review details for modification.
   * 
   * @param key
   * The key of the judicial review being modified
   * 
   * @return The judicial review details
   */
  @Override
  public JudicialReviewReadModifyDetails readDetailsForModify(
    final JudicialReviewCaseKey_fo key) throws AppException,
    InformationalException {

    // Return details
    final JudicialReviewReadModifyDetails judicialReviewReadModifyDetails =
      new JudicialReviewReadModifyDetails();

    // JudicialReview objects
    final curam.appeal.sl.intf.JudicialReview judicialReview =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();
    JudicialReviewCaseKey judicialReviewCaseKey;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Read the judicial review
    judicialReviewCaseKey = key.judicialReviewCaseKey;
    judicialReviewReadModifyDetails.judicialReviewWithoutDeadlineDetails =
      judicialReview.readForModify(judicialReviewCaseKey);

    return judicialReviewReadModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to close the judicial review case.
   * 
   * @param details
   * The key of the judicial review case being closed.
   */
  @Override
  public void close(final CloseJudicialReviewDetails details)
    throws AppException, InformationalException {

    // JudicialReview objects
    final curam.appeal.sl.intf.JudicialReview judicialReview_bo =
      JudicialReviewFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Close the judicial review
    judicialReview_bo.close(details.closeJudicialReviewDetails);

  }

  // ___________________________________________________________________________
  /**
   * Allows the user to insert the participants for the appeal case and
   * indicates if there are active appeal cases of the specified type with the
   * same appellant and respondent
   * 
   * @param details
   * The appellant and respondent details
   * 
   * @return The participantRoleID and active appeal indicator
   */
  @Override
  public JudicialReviewAppellantAndRespondentReturnDetails
    enterAppellantAndRespondent(
      final curam.appeal.facade.struct.AppellantAndRespondentDetails details)
      throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final ValidateAppealedCaseLevelDetails validateAppealedCaseLevelDetails =
      new ValidateAppealedCaseLevelDetails();

    // AppellantAndRespondent variables
    final AppellantAndRespondentDetails appellantAndRespondentDetails =
      new AppellantAndRespondentDetails();
    final JudicialReviewAppellantAndRespondentReturnDetails judicialReviewReturnDetails =
      new JudicialReviewAppellantAndRespondentReturnDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    appellantAndRespondentDetails.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;

    // Validate the level and type of appeal
    validateAppealedCaseLevelDetails.appealTypeCode =
      APPEALTYPE.JUDICIALREVIEW;
    validateAppealedCaseLevelDetails.implCaseID = details.implCaseID;
    validateAppealedCaseLevelDetails.priorAppealCaseID =
      details.priorAppealCaseID;
    appealObj.validateAppealedCaseLevel(validateAppealedCaseLevelDetails);

    appellantAndRespondentDetails.assign(details);

    judicialReviewReturnDetails.appellantAndRespondentReturnDetails =
      appealObj.enterAppellantAndRespondent(appellantAndRespondentDetails);

    if (details.appellantOrganizationInd) {

      judicialReviewReturnDetails.appellantTypeCode =
        APPELLANTTYPE.ORGANIZATION;

    } else {

      judicialReviewReturnDetails.appellantTypeCode = APPELLANTTYPE.CLAIMANT;
    }

    return judicialReviewReturnDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to read the details required for creating a judicial review
   * 
   * @param key
   * Contains the details needed to perform the read
   * 
   * @return The details required for hearing review creation
   */
  @Override
  public ReadForCreateJudicialReviewDetails readForCreate(
    final ReadForCreateJudicialReviewKey key) throws AppException,
    InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // ReadForCreate details
    ReadForCreateDetails readForCreateDetails;
    final OrganisationKey organisationKey = new OrganisationKey();

    // Return variable
    final ReadForCreateJudicialReviewDetails readForCreateJudicialReviewDetails =
      new ReadForCreateJudicialReviewDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    readForCreateDetails = appealObj.readForCreate(key.readForCreateKey);

    if (key.readForCreateKey.appellantTypeCode
      .equals(APPELLANTTYPE.ORGANIZATION)) {

      // BEGIN, CR00288724, MC
      organisationKey.organisationID = GeneralAppealConstants.kOrganisationID;
      final OrganisationNameAndAddressDetails organisationNameAndAddressDetails =
        OrganisationFactory.newInstance().readNameAndAddress(organisationKey);

      readForCreateJudicialReviewDetails.respondentParticipantRoleID =
        key.readForCreateKey.participantRoleID;
      readForCreateJudicialReviewDetails.respondentDisplayName =
        readForCreateDetails.displayName;
      readForCreateJudicialReviewDetails.appellantDisplayName =
        organisationNameAndAddressDetails.name;
      // END, CR00288724
    } else {

      readForCreateJudicialReviewDetails.appellantParticipantRoleID =
        key.readForCreateKey.participantRoleID;
      readForCreateJudicialReviewDetails.appellantDisplayName =
        readForCreateDetails.displayName;
      readForCreateJudicialReviewDetails.respondentDisplayName =
        GeneralConstants.kEmpty;

    }

    readForCreateJudicialReviewDetails.caseReference =
      readForCreateDetails.caseReference;
    readForCreateJudicialReviewDetails.appealedCaseID =
      readForCreateDetails.appealedCaseID;
    readForCreateJudicialReviewDetails.participantRoleType =
      readForCreateDetails.participantRoleType;

    return readForCreateJudicialReviewDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of active judicial reviews for the appellant/respondent.
   * 
   * @param key
   * Contains the participantRoleID and appellantTypeCode
   * 
   * @return The list of active judicial reviews
   */
  @Override
  public ActiveJudicialReviewDetailsList listActiveJudicialReviews(
    final ParticipantRoleKey key) throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Return variable
    final ActiveJudicialReviewDetailsList activeJudicialReviewDetailsList =
      new ActiveJudicialReviewDetailsList();

    // ParticipantRoleKey
    final curam.appeal.sl.struct.ParticipantRoleKey participantRoleKey =
      new curam.appeal.sl.struct.ParticipantRoleKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    participantRoleKey.participantRoleID = key.participantRoleID;
    participantRoleKey.appellantTypeCode = key.appellantTypeCode;
    participantRoleKey.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;
    participantRoleKey.caseID = key.caseID;

    activeJudicialReviewDetailsList.activeAppealsDetailsList =
      appealObj.listActiveAppealsForParticipantRole(participantRoleKey);

    return activeJudicialReviewDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of hearing cases for a specified appealed case
   * 
   * @param key
   * The key containing the caseID
   * 
   * @return The list of hearing cases for the case being appealed
   */
  @Override
  public DecisionsForCaseDetailsList listAppealDecisionsForCase(
    final DecisionsForCaseKey key) throws AppException,
    InformationalException {

    // Variables for getting list of prior appeal decisions
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final DecisionsForImplCaseKey decisionsForImplCaseKey =
      new DecisionsForImplCaseKey();
    final DecisionsForCaseDetailsList decisionsForCaseDetailsList =
      new DecisionsForCaseDetailsList();

    // register the security implementation
    SecurityImplementationFactory.register();

    decisionsForImplCaseKey.caseID = key.caseID;
    decisionsForCaseDetailsList.decisionForImplCaseDetailsList =
      appealObj.listDecisionsForImplementationCase(decisionsForImplCaseKey);

    return decisionsForCaseDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Creates a new judicial review case
   * 
   * @param details
   * The details required to create the new judicial review
   */
  @Override
  public JudicialReviewCaseKey_fo create(
    final JudicialReviewCreateDetails details) throws AppException,
    InformationalException {

    // JudicialReview variables
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();
    final JudicialReviewCaseKey_fo judicialReviewCaseKey_fo =
      new JudicialReviewCaseKey_fo();

    // register the security implementation
    SecurityImplementationFactory.register();

    judicialReviewCaseKey_fo.judicialReviewCaseKey =
      judicialReviewObj.create(details.judicialReviewCreateDetails);

    return judicialReviewCaseKey_fo;

  }

  // ___________________________________________________________________________
  /**
   * Adds an appealed case to an existing judicial review case.
   * 
   * @param details
   * The details for the appealed case to add
   */
  @Override
  public void addAppealedCase(final JudicialReviewAddCaseDetails details)
    throws AppException, InformationalException {

    // JudicialReview object
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    judicialReviewObj.addCase(details.judicialReviewAddCaseDetails);

  }

  // ___________________________________________________________________________
  /**
   * This method returns the case type for the case selected to add to an
   * existing judicial review case. This method also validates if a request for
   * appeal related to the selected case can be appealed to a judicial review
   * case; the level validation which can be performed depends on the type of
   * the selected case.
   * 
   * The selected case can be a previously decided appeal case or an original
   * case within the system. Therefore the level of validation which can be
   * performed depends on the type of the selected case. If a prior appeal case
   * is selected then limited validation can be performed as the decision from
   * that appeal case is unknown at this stage. If an implementation case is
   * selected then it must be valid to directly appeal the case to a hearing
   * review case.
   * 
   * @param details
   * The caseID of the case selected to add to a judicial review case.
   * @return The case type of the selected case.
   */
  @Override
  public CaseType resolveAddCaseSelection(final CaseIDDetails details)
    throws AppException, InformationalException {

    // Variables for resolving the case selection
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseIDAppealTypeCode caseIDAppealTypeCode =
      new CaseIDAppealTypeCode();
    final CaseType caseType = new CaseType();

    // Resolve the case selected to add to an existing hearing case.
    caseIDAppealTypeCode.caseID = details.caseIDDetails.caseID;
    caseIDAppealTypeCode.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;
    caseType.caseType =
      appealObj.resolveAddCaseSelection(caseIDAppealTypeCode).caseType;

    return caseType;

  }

  // ___________________________________________________________________________
  /**
   * This method determines whether or not the underlying product appeal process
   * configuration for the case stipulate that the case can only be appealed at
   * the first level of appeal or whether the case can be appealed at other
   * levels of appeal. This method returns whether or not the specified case can
   * be appealed to a judicial review case; it also returns whether the appeal
   * can only be the first level of appeal or whether the appeal can be at other
   * levels of appeal.
   * 
   * @param details
   * The case selected to appeal to a judicial review.
   * @return Indicator if case can only be appealed at the first appeal level.
   * Note that a negative value here implies that the case can be
   * appealed at other levels of appeal. Indicator if the case be
   * appealed at the first level at all.
   */
  @Override
  public CaseAppealLevelDetails resolveAppealLevelForCase(
    final CaseIDDetails details) throws AppException, InformationalException {

    // Variables for resolving the appeal level for the case
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseAppealLevelDetails caseAppealLevelDetails =
      new CaseAppealLevelDetails();
    final CaseIDAppealTypeCode caseIDAppealTypeCode =
      new CaseIDAppealTypeCode();

    // Register the security implementation factory
    SecurityImplementationFactory.register();

    // Resolve the appeal level details for appealing the case to a hearing case
    caseIDAppealTypeCode.caseID = details.caseIDDetails.caseID;
    caseIDAppealTypeCode.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;
    caseAppealLevelDetails.caseAppealLevelDetails =
      appealObj.resolveAppealLevelForCase(caseIDAppealTypeCode);

    return caseAppealLevelDetails;
  }

  /**
   * Create a judicial review case with a delimited list of objects.
   * 
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "AOT1,1001|AOT2,2001|AOT2,2002" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the Appeal Object interface class.
   * 
   * @param details
   * The details of the judicial review case being created including a
   * delimited list of objects.
   * 
   * @return Contains the ID of the judicial review case
   */
  @Override
  public JudicialReviewCaseKey_fo createWithObjects(
    final CreateJudicialReviewAndAppealObjectsDetails details)
    throws AppException, InformationalException {

    // JudicialReview variables
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();
    final JudicialReviewCaseKey_fo judicialReviewCaseKey_fo =
      new JudicialReviewCaseKey_fo();

    // register the security implementation
    SecurityImplementationFactory.register();

    // If no objects have been supplied then call standard create method
    judicialReviewCaseKey_fo.judicialReviewCaseKey =
      judicialReviewObj.createWithAppealObjects(details);

    return judicialReviewCaseKey_fo;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void createPetition(final JudicialReviewCaseKey_fo key)
    throws AppException, InformationalException {

    // JudicialReview object
    final curam.appeal.sl.intf.JudicialReview judicialReviewObj =
      curam.appeal.sl.fact.JudicialReviewFactory.newInstance();

    judicialReviewObj.createPetition(key.judicialReviewCaseKey);

  }

}
