/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealSecurityDetails;
import curam.appeal.facade.struct.AppealSecurityIDList;
import curam.appeal.facade.struct.AppealSecurityModifyDetails;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Appeal Security
 * facade.
 * 
 */
public abstract class AppealSecurity extends
  curam.appeal.facade.base.AppealSecurity {

  // ___________________________________________________________________________
  /**
   * This method retrieves the appeal security details
   * 
   */
  @Override
  public AppealSecurityDetails readSecurity() throws AppException,
    InformationalException {

    // Return struct
    final AppealSecurityDetails appealSecurityDetails =
      new AppealSecurityDetails();

    // Appeal security object
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      curam.appeal.sl.fact.AppealSecurityFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Read the data from the service layer
    appealSecurityDetails.appealSecurityDetails =
      appealSecurityObj.readSecurity();

    return appealSecurityDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the appeal security details
   * 
   */
  @Override
  public AppealSecurityModifyDetails readForModify() throws AppException,
    InformationalException {

    // Return struct
    final AppealSecurityModifyDetails appealSecurityModifyDetails =
      new AppealSecurityModifyDetails();

    // Appeal security object
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      curam.appeal.sl.fact.AppealSecurityFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Read the data from the service layer
    appealSecurityModifyDetails.appealSecurityModifyDetails =
      appealSecurityObj.readForModify();

    return appealSecurityModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the appeal security details
   * 
   * @param details the appeal security details
   */
  @Override
  public void modify(final AppealSecurityModifyDetails details)
    throws AppException, InformationalException {

    // Appeal security object and structs
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      curam.appeal.sl.fact.AppealSecurityFactory.newInstance();
    curam.appeal.sl.struct.AppealSecurityModifyDetails appealSecurityModifyDetails =
      new curam.appeal.sl.struct.AppealSecurityModifyDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Call the service layer modify
    appealSecurityModifyDetails = details.appealSecurityModifyDetails;
    appealSecurityObj.modify(appealSecurityModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * This method returns the list of appeal security identifiers
   * 
   * @return appealSecurityIDList
   * The list of appeal security identifiers
   */
  @Override
  public AppealSecurityIDList listAppealSIDs() throws AppException,
    InformationalException {

    // Return variable
    final AppealSecurityIDList appealSecurityIDList =
      new AppealSecurityIDList();

    // Appeal Security business object
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Delegate to business logic layer
    appealSecurityIDList.appealSecurityIDList =
      appealSecurityObj.listAppealSIDs();

    return appealSecurityIDList;
  }

}
