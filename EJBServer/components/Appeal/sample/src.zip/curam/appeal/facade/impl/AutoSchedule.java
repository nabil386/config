/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.LocationScheduleDetails;
import curam.appeal.facade.struct.LocationScheduleKey;
import curam.appeal.facade.struct.UserScheduleDetails;
import curam.appeal.facade.struct.UserScheduleKey;
import curam.appeal.sl.fact.AutoScheduleFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for Automatic Scheduling
 * of Users within Appeal Hearings.
 * 
 */
// BEGIN, CR00095110, RKi
public abstract class AutoSchedule extends
  curam.appeal.facade.base.AutoSchedule {

  // END, CR00095110

  // ___________________________________________________________________________
  /**
   * This operation displays a location based schedule for an appeal hearing.
   * 
   * @param key The criteria for scheduling of the appeal hearing.
   * @return The details of the location based schedule.
   */
  @Override
  public LocationScheduleDetails displayLocationSchedule(
    final LocationScheduleKey key) throws AppException,
    InformationalException {

    // Return Variable
    final LocationScheduleDetails locationScheduleDetails =
      new LocationScheduleDetails();

    // Appeal Auto Schedule Service Layer Variables
    final curam.appeal.sl.intf.AutoSchedule autoScheduleObj =
      AutoScheduleFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Appeal Auto Schedule Service Layer
    locationScheduleDetails.locationScheduleDetails =
      autoScheduleObj.displayLocationSchedule(key.locationScheduleKey);

    return locationScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation displays a schedule for an appeal hearing other than a
   * location based hearing.
   * 
   * @param key The criteria for scheduling of the appeal hearing.
   * @return The details of the schedule for the appeal hearing.
   */
  @Override
  public UserScheduleDetails displayUserSchedule(final UserScheduleKey key)
    throws AppException, InformationalException {

    // Return Variable
    final UserScheduleDetails userScheduleDetails = new UserScheduleDetails();

    // Appeal Auto Schedule Service Layer Variables
    final curam.appeal.sl.intf.AutoSchedule autoScheduleObj =
      AutoScheduleFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Appeal Auto Schedule Service Layer
    userScheduleDetails.userScheduleDetails =
      autoScheduleObj.displayUserSchedule(key.userScheduleKey);

    return userScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation confirms the search parameters for a location based
   * schedule.
   * 
   * @param key The search parameters for a location based schedule.
   */
  @Override
  public LocationScheduleKey enterLocationSearchCriteria(
    final LocationScheduleKey key) throws AppException,
    InformationalException {

    // Return Variable
    final LocationScheduleKey locationScheduleKey = new LocationScheduleKey();

    // Appeal Auto Schedule Service Layer Variables
    final curam.appeal.sl.intf.AutoSchedule autoScheduleObj =
      AutoScheduleFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Appeal Auto Schedule Service Layer
    locationScheduleKey.locationScheduleKey =
      autoScheduleObj.enterLocationSearchCriteria(key.locationScheduleKey);

    return locationScheduleKey;
  }

  // ___________________________________________________________________________
  /**
   * This operation confirms the search parameters for a user based schedule.
   * 
   * @param key The search parameters for a user based schedule.
   */
  @Override
  public UserScheduleKey enterUserSearchCriteria(final UserScheduleKey key)
    throws AppException, InformationalException {

    // Return Variable
    final UserScheduleKey userScheduleKey = new UserScheduleKey();

    // Appeal Auto Schedule Service Layer Variables
    final curam.appeal.sl.intf.AutoSchedule autoScheduleObj =
      AutoScheduleFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Appeal Auto Schedule Service Layer
    userScheduleKey.userScheduleKey =
      autoScheduleObj.enterUserSearchCriteria(key.userScheduleKey);

    return userScheduleKey;
  }

}
