/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealStageConfID;
import curam.appeal.facade.struct.CreateIssueProcessDetails;
import curam.appeal.facade.struct.CreateIssueStageDetails;
import curam.appeal.facade.struct.IssueAppealProcessKey;
import curam.appeal.facade.struct.IssueProcessDetailsList;
import curam.appeal.facade.struct.ListIssueProcessDtls;
import curam.appeal.facade.struct.ModifyIssueStageDetails;
import curam.appeal.facade.struct.ProcessAndStageDetails;
import curam.appeal.facade.struct.ReadIssueStageDetails;
import curam.appeal.sl.entity.struct.AppealProcessKey;
import curam.appeal.sl.entity.struct.AppealStageConfigurationID;
import curam.appeal.sl.fact.IssueAppealProcessFactory;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealStageConfigID;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.IssueConfigurationKey;
import curam.core.sl.fact.IssueConfigurationFactory;
import curam.core.sl.intf.IssueConfiguration;
import curam.core.sl.struct.IssueConfigurationDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.intf.CodeTable;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.transaction.TransactionInfo;

/**
 * Provides the facade functionality for maintaining and accessing issue appeal
 * process definitions for a Product.
 */
public abstract class IssueAppealProcess extends
  curam.appeal.facade.base.IssueAppealProcess {

  // ___________________________________________________________________________
  /**
   * Creates a new issue appeal process definition for a issue. A new issue
   * appeal process is created with no appeal stages.
   * 
   * @param details
   * The issue and start date for which to create the new issue appeal
   * process.
   */
  @Override
  public void createIssueProcess(final CreateIssueProcessDetails details)
    throws AppException, InformationalException {

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Variable for Service Layer
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcessObj =
      curam.appeal.sl.fact.IssueAppealProcessFactory.newInstance();

    // Use the Service Layer to create the Issue Appeal Process.
    issueAppealProcessObj.createIssueProcess(details.createIssueProcess);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all issue appeal processes for a issue. This list
   * includes the first appeal stage, if any, defined for each process.
   * 
   * @param details
   * The case type id and case type to obtain the list of issue appeal
   * processes
   * @return The list of issue appeal processes
   */
  @Override
  public IssueProcessDetailsList listIssueProcess(
    final ListIssueProcessDtls details) throws AppException,
    InformationalException {

    // Variable for list of issue Appeal Processes
    final IssueProcessDetailsList issueProcessDetailsList =
      new IssueProcessDetailsList();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Variable for Service Layer
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcess =
      curam.appeal.sl.fact.IssueAppealProcessFactory.newInstance();

    // Get the list of issue Appeal Processes
    issueProcessDetailsList.issueProcessList =
      issueAppealProcess.listIssueProcess(details.listIssueProcessDtls);

    final IssueConfigurationKey configurationKey =
      new IssueConfigurationKey();

    configurationKey.issueConfigurationID =
      details.listIssueProcessDtls.listIssueProcessDtls.caseTypeID;

    issueProcessDetailsList.issueProcessList.contextDescription =
      getIssueDeliveryContextDescription(configurationKey);

    return issueProcessDetailsList;
  }

  // ____________________________________________________________________________
  /**
   * Generates the context description for the Issue Delivery
   * 
   * 
   * @param key Context description identifier.
   * 
   * @return A context description for a Issue Delivery.
   */
  protected AppealContextDescription getIssueDeliveryContextDescription(
    final IssueConfigurationKey key) throws AppException,
    InformationalException {

    final IssueConfiguration issueConfiguration =
      IssueConfigurationFactory.newInstance();

    IssueConfigurationDtls configurationDtls = new IssueConfigurationDtls();

    configurationDtls = issueConfiguration.read(key);

    final AppealContextDescription appealContextDescription =
      new AppealContextDescription();

    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    final CodeTable codeTableInterface = CodeTableFactory.newInstance();

    ctitemKey.code = configurationDtls.dtls.type;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = ISSUECONFIGURATIONTYPE.TABLENAME;

    ctitem = codeTableInterface.getOneItem(ctitemKey);

    appealContextDescription.description = new String(ctitem.description);

    return appealContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Returns the issue appeal process details together with an ordered list,
   * including a numerical order value, of the active appeal stages for the
   * process.
   * 
   * @param key
   * The issue appeal process key
   * @return The issue appeal process details and ordered list of appeal stages.
   */
  @Override
  public ProcessAndStageDetails readProcessDetails(
    final IssueAppealProcessKey key) throws AppException,
    InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcessObj =
      curam.appeal.sl.fact.IssueAppealProcessFactory.newInstance();

    // Variables for details of Issue Appeal Process
    final ProcessAndStageDetails processAndStageDetails =
      new ProcessAndStageDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Use the Service Layer to read the Process details
    processAndStageDetails.processAndStageDetails =
      issueAppealProcessObj.readIssueProcessDetails(key.issueProcessKey);

    return processAndStageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates an Issue Stage
   * 
   * @param dtls The Issue Stage details.
   */
  @Override
  public void createIssueStage(final CreateIssueStageDetails dtls)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcessObj =
      curam.appeal.sl.fact.IssueAppealProcessFactory.newInstance();

    final curam.appeal.sl.struct.CreateIssueStageDetails createIssueStageDetails =
      new curam.appeal.sl.struct.CreateIssueStageDetails();

    createIssueStageDetails.appealProcessID =
      dtls.createIssueDtls.appealProcessID;
    createIssueStageDetails.appealTypeCode =
      dtls.createIssueDtls.appealTypeCode;

    issueAppealProcessObj.createIssueStage(createIssueStageDetails);

  }

  // ___________________________________________________________________________
  /**
   * Modify an Issue Stage
   * 
   * @param dtls The Issue Stage details.
   */

  @Override
  public void modifyIssueStageDetails(final ModifyIssueStageDetails dtls)
    throws AppException, InformationalException {

    final curam.appeal.sl.intf.IssueAppealProcess appealProcess =
      IssueAppealProcessFactory.newInstance();

    final curam.appeal.sl.struct.ModifyIssueStageDetails details =
      new curam.appeal.sl.struct.ModifyIssueStageDetails();

    details.appeaStageConfigurationID =
      dtls.modifyIssueStage.appeaStageConfigurationID;
    details.appealTypeCode = dtls.modifyIssueStage.appealTypeCode;

    appealProcess.modifyIssueStageDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Read an Issue Stage
   * 
   * @param key The key to identify Issue Stage.
   */

  @Override
  public ReadIssueStageDetails readIssueStage(final AppealStageConfID key)
    throws AppException, InformationalException {

    final curam.appeal.sl.intf.IssueAppealProcess process =
      IssueAppealProcessFactory.newInstance();

    final ReadIssueStageDetails details = new ReadIssueStageDetails();

    final AppealStageConfigID appealStageConfigID = new AppealStageConfigID();

    appealStageConfigID.StageConfigID.appealStageConfID =
      key.stageConfID.StageConfigID.appealStageConfID;

    details.readIssueStage = process.readIssueStage(appealStageConfigID);

    return details;

  }

  // ___________________________________________________________________________
  /**
   * Cancels an appeal process
   * 
   * @param key
   * The key to cancel an appeal process.
   */
  @Override
  public void cancelProcess(final AppealProcessKey key) throws AppException,
    InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcess =
      curam.appeal.sl.fact.IssueAppealProcessFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Service Layer to cancel the Appeal Process.
    issueAppealProcess.cancelProcess(key);
  }

  // ___________________________________________________________________________
  /**
   * Cancels an appeal stage
   * 
   * @param key
   * The key to cancel an appeal stage.
   */
  @Override
  public void cancelStage(final AppealStageConfigurationID key)
    throws AppException, InformationalException {

    // Variable for Service Layer
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcess =
      curam.appeal.sl.fact.IssueAppealProcessFactory.newInstance();

    // Register the security implementation.
    SecurityImplementationFactory.register();

    // Use the Service Layer to cancel the Appeal Stage.
    issueAppealProcess.cancelStage(key);
  }

}
