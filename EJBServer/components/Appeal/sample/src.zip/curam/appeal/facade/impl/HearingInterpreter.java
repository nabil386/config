/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CancelInterpreterKey;
import curam.appeal.facade.struct.CreateHearingInterpreterDetails;
import curam.appeal.facade.struct.ListInterpreterDetails;
import curam.appeal.facade.struct.ListInterpreterDetailsForIC;
import curam.appeal.facade.struct.ListInterpreterKey;
import curam.appeal.facade.struct.ModifyInterpreterDetails;
import curam.appeal.facade.struct.ReadHearingInterpreterDetails;
import curam.appeal.facade.struct.ReadHearingInterpreterKey;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingKey;
import curam.codetable.CASETYPECODE;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Hearing Interpreter
 * facade.
 * 
 */

public abstract class HearingInterpreter extends
  curam.appeal.facade.base.HearingInterpreter {

  // ___________________________________________________________________________
  /**
   * Method to cancel a hearing interpreter
   * 
   * @param key The key of the interpreter to cancel
   */
  @Override
  public void cancel(final CancelInterpreterKey key) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing Interpreter variables
    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();

    // Cancel the interpreter
    hearingInterpreterObj.cancel(key.cancelInterpreterKey);

  }

  // ___________________________________________________________________________
  /**
   * Method to insert a hearing interpreter
   * 
   * @param details The details of the interpreter to insert
   * @return Any informational messages
   */
  @Override
  public InformationMsgDtlsList insert(
    final CreateHearingInterpreterDetails details) throws AppException,
    InformationalException {

    // Return variable
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    SecurityImplementationFactory.register();

    // Hearing Interpreter variables
    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();

    // Insert the interpreter
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingInterpreterObj.insert(details.createHearingInterpreterDetails);

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list interpreters for standalone cases
   * 
   * @param key The details of the interpreter to list
   * 
   * @return listInterpreterDetails The list of all interpreters for a
   * given key.
   */
  @Override
  public ListInterpreterDetails list(final ListInterpreterKey key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingKey hearingKey_bo =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Interpreter variables
    final ListInterpreterDetails listInterpreterDetails =
      new ListInterpreterDetails();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = key.listInterpreterKey.hearingID;

    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // Get the context description
    listInterpreterDetails.appealContextDescription =
      appeal_boObj.getContextDescription(appealCaseDetails);

    // Interpreter variables
    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();

    // get listing of interpreters for stand alone cases
    listInterpreterDetails.listInterpreterDetails =
      hearingInterpreterObj.list(key.listInterpreterKey);

    return listInterpreterDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to list interpreters for Integrated cases.
   * 
   * @param key The key to return a list of interpreters
   * 
   * @return listInterpreterDetailsForIC The list of all interpreters
   * for a given key.
   */
  @Override
  public ListInterpreterDetailsForIC listForIC(final ListInterpreterKey key)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingKey hearingKey_bo =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    // Appeal variables
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Interpreter variables
    final ListInterpreterDetailsForIC listInterpreterDetailsForIC =
      new ListInterpreterDetailsForIC();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = key.listInterpreterKey.hearingID;

    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription contextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      listInterpreterDetailsForIC.appealContextDescription.description =
        contextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey_bo);

      // assign menu data
      listInterpreterDetailsForIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else { // END, CR00115728
      // Get the context description
      listInterpreterDetailsForIC.appealContextDescription =
        appeal_boObj.getContextDescription(appealCaseDetails);

      // Get the menu description
      listInterpreterDetailsForIC.appealMenuData =
        appeal_boObj.getMenuData(appealCaseDetails);
    }

    // Interpreter variables
    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();

    // get listing of interpreters for stand alone cases
    listInterpreterDetailsForIC.listInterpreterDetails =
      hearingInterpreterObj.list(key.listInterpreterKey);

    return listInterpreterDetailsForIC;

  }

  // BEGIN, CR00246931, GP
  /**
   * Method to list participants interpreters for Integrated cases.
   * 
   * @param key contains the hearingID.
   * @return the list of all interpreters.
   * @throws InformationalException Generic exception signature.
   * @throws AppException Generic exception signature.
   */
  @Override
  public ListInterpreterDetailsForIC listParticipantForIC(
    final ListInterpreterKey key) throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();

    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();
    HearingCaseID hearingCaseID = new HearingCaseID();

    final Appeal appeal_boObj = AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    final ListInterpreterDetailsForIC listInterpreterDetailsForIC =
      new ListInterpreterDetailsForIC();

    // Read hearing case id.
    hearingKey_bo.hearingKey.hearingID = key.listInterpreterKey.hearingID;

    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {

      final LegalAction legalActionObj = LegalActionFactory.newInstance();

      final CaseID caseID = new CaseID();

      caseID.caseID = hearingCaseID.hearingCaseID.caseID;

      // Get the context description for legal action.
      final AppealContextDescription contextDescription =
        legalActionObj.getContextDescription(caseID);

      listInterpreterDetailsForIC.appealContextDescription.description =
        contextDescription.description;

      // Get the menu data for legal action.
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey_bo);

      listInterpreterDetailsForIC.appealMenuData.menuData =
        appealMenuData.menuData;

    } else {

      // Get the context description.
      listInterpreterDetailsForIC.appealContextDescription =
        appeal_boObj.getContextDescription(appealCaseDetails);

      // Get the menu description.
      listInterpreterDetailsForIC.appealMenuData =
        appeal_boObj.getMenuData(appealCaseDetails);
    }

    // get listing of interpreters for stand alone cases
    listInterpreterDetailsForIC.listInterpreterDetails =
      hearingInterpreterObj.listParticipants(key.listInterpreterKey);

    return listInterpreterDetailsForIC;
  }

  // END, CR00246931

  /**
   * Method to modify interpreters for Integrated cases.
   * 
   * @param details details of the interpreter to modify
   */
  @Override
  public void modify(final ModifyInterpreterDetails details)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing Interpreter variables
    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();

    // Modify the interpreter
    hearingInterpreterObj.modify(details.modifyInterpreterDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to read a hearing interpreter.
   * 
   * @param key The hearing interpreter to view
   * 
   * @return readHearingInterpreterDetails the hearing interpreter details
   */
  @Override
  public ReadHearingInterpreterDetails read(
    final ReadHearingInterpreterKey key) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing Interpreter details
    final curam.appeal.sl.intf.HearingInterpreter hearingInterpreterObj =
      curam.appeal.sl.fact.HearingInterpreterFactory.newInstance();
    ReadHearingInterpreterDetails readHearingInterpreterDetails;

    readHearingInterpreterDetails = new ReadHearingInterpreterDetails();

    // Get the hearing interpreter details
    readHearingInterpreterDetails.readHearingInterpreterDetails =
      hearingInterpreterObj.read(key.readHearingInterpreterKey);

    return readHearingInterpreterDetails;

  }

}
