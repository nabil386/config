/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.IssueTimeConstraintDetailsList;
import curam.appeal.facade.struct.IssueTimeConstraintDtls;
import curam.appeal.facade.struct.IssueTimeConstraintKey;
import curam.core.sl.entity.struct.IssueConfigurationKey;
import curam.core.sl.fact.IssueTimeConstraintFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality to apply time limits to issues.
 * 
 */
public class IssueTimeConstraint extends
  curam.appeal.facade.base.IssueTimeConstraint {

  // ___________________________________________________________________________
  /**
   * Retrieves list of time constraints which are configured for an Issue type.
   * 
   * @param key
   * Issue Configuration Key
   * 
   * @return
   * Issue TimeConstraint Details List
   */
  @Override
  public IssueTimeConstraintDetailsList listIssueTimeConstraint(
    final IssueConfigurationKey key) throws AppException,
    InformationalException {

    // IssueTimeConstraint manipulation variable
    final curam.core.sl.intf.IssueTimeConstraint issueTimeConstraint =
      IssueTimeConstraintFactory.newInstance();

    final IssueTimeConstraintDetailsList issueTimeConstraintDetailsList =
      new IssueTimeConstraintDetailsList();

    // set key to get list of time constraints
    issueTimeConstraintDetailsList.issueTimeConstraintDtlsList =
      issueTimeConstraint.listTimeConstraint(key);

    return issueTimeConstraintDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Creates/inserts a time constraint for an issue type.
   * 
   * @param dtls
   * Issue TimeConstraint Dtls
   */
  @Override
  public void createIssueTimeConstraint(final IssueTimeConstraintDtls dtls)
    throws AppException, InformationalException {

    // IssueTimeConstraint manipulation variable
    final curam.core.sl.intf.IssueTimeConstraint issueTimeConstraint =
      IssueTimeConstraintFactory.newInstance();

    final curam.core.sl.entity.struct.IssueTimeConstraintDtls issueTimeConstraintDtls =
      new curam.core.sl.entity.struct.IssueTimeConstraintDtls();

    // set dtls to add a time constraint
    issueTimeConstraintDtls.assign(dtls.issueTimeConstraintDtls);

    issueTimeConstraint.createTimeConstraint(issueTimeConstraintDtls);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a time constraint for an issue type.
   * 
   * @param key
   * Issue TimeConstraint Key
   * 
   * @return
   * Issue TimeConstraint Dtls
   */
  @Override
  public IssueTimeConstraintDtls readIssueTimeConstraint(
    final IssueTimeConstraintKey key) throws AppException,
    InformationalException {

    // IssueTimeConstraint manipulation variable
    final curam.core.sl.intf.IssueTimeConstraint issueTimeConstraint =
      IssueTimeConstraintFactory.newInstance();

    final IssueTimeConstraintDtls issueTimeConstraintDtls =
      new IssueTimeConstraintDtls();

    // set dtls to read a specific time constraint
    issueTimeConstraintDtls.issueTimeConstraintDtls =
      issueTimeConstraint.readTimeConstraint(key.issueTimeConstraintKey);

    return issueTimeConstraintDtls;
  }

  // ___________________________________________________________________________
  /**
   * Updates/modify a time constraint for an issue type.
   * 
   * @param dtls
   * Issue TimeConstraint Dtls
   */
  @Override
  public void modifyIssueTimeConstraint(final IssueTimeConstraintDtls dtls)
    throws AppException, InformationalException {

    // IssueTimeConstraint manipulation variable
    final curam.core.sl.intf.IssueTimeConstraint issueTimeConstraint =
      IssueTimeConstraintFactory.newInstance();

    final curam.core.sl.entity.struct.IssueTimeConstraintDtls issueTimeConstraintDtls =
      new curam.core.sl.entity.struct.IssueTimeConstraintDtls();

    // set dtls to modify time constraint
    issueTimeConstraintDtls.assign(dtls.issueTimeConstraintDtls);

    issueTimeConstraint.modifyTimeConstraint(issueTimeConstraintDtls);
  }

  // ___________________________________________________________________________
  /**
   * Deletes/cancels a time constraint for an issue type.
   * 
   * @param key
   * Issue TimeConstraint Key
   */
  @Override
  public void cancelIssueTimeConstraint(final IssueTimeConstraintKey key)
    throws AppException, InformationalException {

    // IssueTimeConstraint manipulation variable
    final curam.core.sl.intf.IssueTimeConstraint issueTimeConstraint =
      IssueTimeConstraintFactory.newInstance();

    final curam.core.sl.entity.struct.IssueTimeConstraintKey issueTimeConstraintKey =
      new curam.core.sl.entity.struct.IssueTimeConstraintKey();

    // set key to delete a specific time constraint
    issueTimeConstraintKey.assign(key.issueTimeConstraintKey);

    issueTimeConstraint.cancelTimeConstraint(issueTimeConstraintKey);
  }

}
