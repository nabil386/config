/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AddToHearingPhoneContactDetails;
import curam.appeal.facade.struct.HearingPhoneContactDetails;
import curam.appeal.facade.struct.HearingPhoneContactDetailsList;
import curam.appeal.facade.struct.HearingPhoneContactDetailsListOnIC;
import curam.appeal.facade.struct.HearingPhoneContactIDKey;
import curam.appeal.facade.struct.HearingPhoneContactKey;
import curam.appeal.facade.struct.ModifyHearingPhoneContactDetails;
import curam.appeal.facade.struct.ModifyHearingPhoneContactStatusDetails;
import curam.appeal.facade.struct.ReadForModifyDetails;
import curam.appeal.facade.struct.ReadHearingPhoneContactDetails;
import curam.appeal.sl.fact.HearingPhoneContactFactory;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.HearingCaseID;
import curam.codetable.CASETYPECODE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Hearing Phone Number
 * facade.
 */
public abstract class HearingPhoneContact extends
  curam.appeal.facade.base.HearingPhoneContact {

  // ___________________________________________________________________________
  /**
   * Returns list of participants and their phone contact numbers. This is
   * facade method used by standalone client page.
   * 
   * @param key The Hearing ID associated with the Hearing phone contact
   * 
   * @return hearingPhoneContactDetailsList list of all hearing
   * phone contacts
   */
  @Override
  public HearingPhoneContactDetailsList listHearingPhoneContact(
    final HearingPhoneContactKey key) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing phone contact variables
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.fact.HearingPhoneContactFactory.newInstance();
    HearingPhoneContactDetailsList hearingPhoneContactDetailsList;

    // Appeals variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    AppealCaseDetails appealCaseDetails;

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    curam.appeal.sl.struct.HearingKey hearingKey;
    HearingCaseID hearingCaseID;

    // Get the case id
    hearingKey = new curam.appeal.sl.struct.HearingKey();
    hearingKey.hearingKey.hearingID = key.key.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);

    appealCaseDetails = new AppealCaseDetails();
    appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;

    hearingPhoneContactDetailsList = new HearingPhoneContactDetailsList();

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      hearingPhoneContactDetailsList.appealContextDescription.description =
        appealContextDescription.description;
      // END, CR00116551
    } else { // END, CR00115728
      hearingPhoneContactDetailsList.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);
    }

    hearingPhoneContactDetailsList.list =
      hearingPhoneContactObj.list(key.key);

    return hearingPhoneContactDetailsList;

  }

  // __________________________________________________________________________
  /**
   * Returns list of participants and their phone contact numbers. This is
   * facade method used by IC client page.
   * 
   * @param key The Hearing ID associated with the Hearing phone contact
   * 
   * @return hearingPhoneContactDetailsListOnIC list of all
   * hearing phone contacts
   */
  @Override
  public HearingPhoneContactDetailsListOnIC listHearingPhoneContactOnIC(
    final HearingPhoneContactKey key) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing phone contact variables
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.fact.HearingPhoneContactFactory.newInstance();
    HearingPhoneContactDetailsListOnIC hearingPhoneContactDetailsListOnIC;

    // Appeals variables
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    AppealCaseDetails appealCaseDetails;

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearingObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    curam.appeal.sl.struct.HearingKey hearingKey;

    hearingKey = new curam.appeal.sl.struct.HearingKey();
    hearingKey.hearingKey.hearingID = key.key.hearingID;

    // Get the list of phone contacts
    hearingPhoneContactDetailsListOnIC =
      new HearingPhoneContactDetailsListOnIC();
    hearingPhoneContactDetailsListOnIC.list =
      hearingPhoneContactObj.list(key.key);

    // Get the case ID and context description
    hearingPhoneContactDetailsListOnIC.hearingCaseID =
      hearingObj.getCase(hearingKey);
    appealCaseDetails = new AppealCaseDetails();
    appealCaseDetails.caseID =
      hearingPhoneContactDetailsListOnIC.hearingCaseID.hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID =
      hearingPhoneContactDetailsListOnIC.hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID =
        hearingPhoneContactDetailsListOnIC.hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      hearingPhoneContactDetailsListOnIC.appealContextDescription.description =
        appealContextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey);

      // assign menu data
      hearingPhoneContactDetailsListOnIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else { // END, CR00115728
      // Get context description
      hearingPhoneContactDetailsListOnIC.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

      // Get menu data
      hearingPhoneContactDetailsListOnIC.appealMenuData =
        appealObj.getMenuData(appealCaseDetails);
    }

    return hearingPhoneContactDetailsListOnIC;

  }

  // ___________________________________________________________________________
  /**
   * Creates new phone contact.
   * 
   * @param details Details of the hearing phone contact
   */
  @Override
  public void createHearingPhoneContact(
    final HearingPhoneContactDetails details) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing phone contact variables
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.fact.HearingPhoneContactFactory.newInstance();

    // Create the hearing phone contact variable
    hearingPhoneContactObj.create(details.details);

  }

  // ___________________________________________________________________________
  /**
   * Adds an existing phone number to the list of hearing phone contacts
   * 
   * @param details The details of the phone number to be added
   */
  @Override
  public void addToHearingPhoneContact(
    final AddToHearingPhoneContactDetails details) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing phone contact variables
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.fact.HearingPhoneContactFactory.newInstance();

    hearingPhoneContactObj
      .addPhoneNumber(details.addToHearingPhoneContactDetails);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the hearing phone contact details
   * 
   * @param key Unique reference number of the hearing phone contact
   * @return The details of the hearing phone contact
   */
  @Override
  public ReadHearingPhoneContactDetails readHearingPhoneContact(
    final HearingPhoneContactIDKey key) throws AppException,
    InformationalException {

    SecurityImplementationFactory.register();

    // Hearing Phone Contact details
    final ReadHearingPhoneContactDetails readHearingPhoneContactDetails =
      new ReadHearingPhoneContactDetails();
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      HearingPhoneContactFactory.newInstance();

    // Get the hearing phone contact details
    readHearingPhoneContactDetails.readHearingPhoneContactDetails =
      hearingPhoneContactObj.read(key.hearingPhoneContactIDKey);

    return readHearingPhoneContactDetails;

  }

  // ___________________________________________________________________________
  /**
   * Cancels a hearing phone contact.
   * 
   * @param details The details to be canceled
   */
  @Override
  public void cancelHearingPhoneContact(
    final ModifyHearingPhoneContactStatusDetails details)
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // Hearing Phone contact variables
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.fact.HearingPhoneContactFactory.newInstance();

    // Cancel the hearing phone contact
    hearingPhoneContactObj
      .cancel(details.modifyHearingPhoneContactStatusDetails);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a hearing phone contact
   * 
   * @param key Unique reference number of the hearing phone contact
   * @return The details of the hearing phone contact
   */
  @Override
  public ReadForModifyDetails
    readForModify(final HearingPhoneContactIDKey key) throws AppException,
      InformationalException {

    SecurityImplementationFactory.register();

    // Hearing Phone Contact details
    final ReadForModifyDetails readForModifyDetails =
      new ReadForModifyDetails();
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      HearingPhoneContactFactory.newInstance();

    // Get the hearing phone contact details
    readForModifyDetails.readForModifyDetails =
      hearingPhoneContactObj.readForModify(key.hearingPhoneContactIDKey);

    return readForModifyDetails;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a hearing phone contact
   * 
   * @param details The details to be modified
   */
  @Override
  public void modifyPhoneContact(
    final ModifyHearingPhoneContactDetails details) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing phone contact variables
    final curam.appeal.sl.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.fact.HearingPhoneContactFactory.newInstance();

    // Modify hearing phone contact
    hearingPhoneContactObj.modify(details.modifyHearingPhoneContactDetails);
  }

}
