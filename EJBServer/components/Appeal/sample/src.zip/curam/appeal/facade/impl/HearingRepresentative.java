/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CreateHearingRepresentativeDetails;
import curam.appeal.facade.struct.HearingIDKeyHR;
import curam.appeal.facade.struct.HearingRepresentativeIDKey;
import curam.appeal.facade.struct.ModifyHearingRepFeeDetails;
import curam.appeal.facade.struct.ModifyHearingRepresentativeDetails;
import curam.appeal.facade.struct.ModifyHearingRepresentativeStatus;
import curam.appeal.facade.struct.ReadHearingRepresentativeDetails;
import curam.appeal.facade.struct.ReadHearingRepresentativeDetailsList;
import curam.appeal.facade.struct.ReadHearingRepresentativeDetailsListForIC;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealContextDescription;
import curam.appeal.sl.struct.AppealMenuData;
import curam.appeal.sl.struct.HearingCaseID;
import curam.codetable.CASETYPECODE;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.intf.LegalAction;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Hearing
 * Representative presentation layer.
 * 
 */
public abstract class HearingRepresentative extends
  curam.appeal.facade.base.HearingRepresentative {

  // ___________________________________________________________________________
  /**
   * Presentation layer method to create a hearing representative.
   * 
   * @param dtls The details of the hearing representative
   * @return Any informational messages
   */
  @Override
  public InformationMsgDtlsList createHearingRepresentative(
    final CreateHearingRepresentativeDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning the informational messages
    final InformationMsgDtlsList informationMsgDtlsList =
      new InformationMsgDtlsList();

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Create a Hearing Representative
    informationMsgDtlsList.informationalMsgDtlsList =
      hearingRepresentativeObj.create(dtls.createDetails);

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to modify a hearing representative.
   * 
   * @param dtls The details of the hearing representative
   */
  @Override
  public void modifyHearingRepresentative(
    final ModifyHearingRepresentativeDetails dtls) throws AppException,
    InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Modify a Hearing Representative
    hearingRepresentativeObj.modify(dtls.modifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to view a hearing representative.
   * 
   * @param key The ID of the hearing representative
   * 
   * @return The hearing representative details
   */
  @Override
  public ReadHearingRepresentativeDetails viewHearingRepresentative(
    final HearingRepresentativeIDKey key) throws AppException,
    InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // Return structure
    final ReadHearingRepresentativeDetails readHearingRepresentativeDetails =
      new ReadHearingRepresentativeDetails();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the Hearing Representative
    readHearingRepresentativeDetails.readDetails =
      hearingRepresentativeObj.read(key.hearingRepresentativeIDKey);

    // Return the Hearing Representative
    return readHearingRepresentativeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to view a hearing representative list.
   * 
   * @param key The ID of the hearing
   * 
   * @return The hearing representative details list
   */
  @Override
  public ReadHearingRepresentativeDetailsList
    viewHearingRepresentativeListByHearingID(final HearingIDKeyHR key)
      throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // HearingObj objects
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingKey hearingKey_bo =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    // Appeal object
    // Start CR00117296 LP
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      key.hearingIDKeyHR.hearingIDKeyHR.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Return structure
    final ReadHearingRepresentativeDetailsList readHearingRepresentativeDetailsList =
      new ReadHearingRepresentativeDetailsList();

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      readHearingRepresentativeDetailsList.appealContextDescription.description =
        legalActionObj.getContextDescription(caseID).description;
    } else {
      // Appeal object
      final curam.appeal.sl.intf.Appeal appealObj =
        curam.appeal.sl.fact.AppealFactory.newInstance();

      // Register a security implementation for the transaction
      SecurityImplementationFactory.register();
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      readHearingRepresentativeDetailsList.appealContextDescription =
        appealObj.getContextDescription(appealCaseDetails);

    }

    // Retrieve the Hearing Representative List
    readHearingRepresentativeDetailsList.readDetailsList =
      hearingRepresentativeObj.list(key.hearingIDKeyHR);
    // End CR00117296 LP
    // Return the list
    return readHearingRepresentativeDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to view a hearing representative list within
   * an IC.
   * 
   * @param key The ID of the hearing
   * 
   * @return The hearing representative details list
   */
  @Override
  public ReadHearingRepresentativeDetailsListForIC
    viewHearingRepresentativeListForICByHearingID(final HearingIDKeyHR key)
      throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // HearingObj objects
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    final curam.appeal.sl.struct.HearingKey hearingKey_bo =
      new curam.appeal.sl.struct.HearingKey();
    HearingCaseID hearingCaseID;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Return structure
    final ReadHearingRepresentativeDetailsListForIC readHearingRepresentativeDetailsListForIC =
      new ReadHearingRepresentativeDetailsListForIC();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the Hearing Representative List
    readHearingRepresentativeDetailsListForIC.readDetailsList =
      hearingRepresentativeObj.list(key.hearingIDKeyHR);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      key.hearingIDKeyHR.hearingIDKeyHR.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Begin CR00117296 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // BEGIN, CR00116551, RKi
      // Legal Action Object
      final LegalAction legalActionObj = LegalActionFactory.newInstance();
      // instance to get context description
      final CaseID caseID = new CaseID();

      // assign the value of caseID to get context description
      caseID.caseID = hearingCaseID.hearingCaseID.caseID;
      // Get the context description for legal action
      final AppealContextDescription appealContextDescription =
        legalActionObj.getContextDescription(caseID);

      // Assign the context description for legal action
      readHearingRepresentativeDetailsListForIC.appealContextDescription.description =
        appealContextDescription.description;
      // Get the menu data for legal action
      final AppealMenuData appealMenuData =
        legalActionObj.readDynamicMenu(hearingKey_bo);

      // assign menu data
      readHearingRepresentativeDetailsListForIC.appealMenuData.menuData =
        appealMenuData.menuData;
      // END, CR00116551
    } else { // END, CR00115728
      // Get the context description
      appealCaseDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      readHearingRepresentativeDetailsListForIC.appealContextDescription =
        appeal_boObj.getContextDescription(appealCaseDetails);

      // Get the menu data
      readHearingRepresentativeDetailsListForIC.appealMenuData =
        appeal_boObj.getMenuData(appealCaseDetails);
    }
    // END CR00117296 LP
    // Return the list
    return readHearingRepresentativeDetailsListForIC;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to cancel a hearing representative.
   * 
   * @param dtls The details of the hearing representative
   */
  @Override
  public void cancelHearingRepresentative(
    final ModifyHearingRepresentativeStatus dtls) throws AppException,
    InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Cancel a Hearing Representative
    hearingRepresentativeObj.cancel(dtls.modifyStatus);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to modify a hearing representative fee.
   * 
   * @param dtls The details of the hearing representative
   */
  @Override
  public void modifyHearingFee(final ModifyHearingRepFeeDetails dtls)
    throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Modify a Hearing Representative Fee
    hearingRepresentativeObj.modifyHearingFee(dtls.modifyFeeDetails);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to read hearing representative details used
   * when modifying representative fee.
   * 
   * @param key The ID of the hearing representative
   * 
   * @return The hearing representative fee details
   */
  @Override
  public ModifyHearingRepFeeDetails readForModifyFee(
    final HearingRepresentativeIDKey key) throws AppException,
    InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.fact.HearingRepresentativeFactory.newInstance();

    // Return structure
    final ModifyHearingRepFeeDetails modifyHearingRepFeeDetails =
      new ModifyHearingRepFeeDetails();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Retrieve the Hearing Representative
    modifyHearingRepFeeDetails.modifyFeeDetails =
      hearingRepresentativeObj
        .readForModifyFee(key.hearingRepresentativeIDKey);

    // Return the Hearing Representative
    return modifyHearingRepFeeDetails;
  }

}
