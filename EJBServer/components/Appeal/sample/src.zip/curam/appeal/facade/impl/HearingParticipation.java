/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.CaseParticipantRoleLinkKey;
import curam.appeal.facade.struct.CreateCaseParticipantRoleLinkDetails;
import curam.appeal.facade.struct.RelatedID;
import curam.appeal.facade.struct.UnlinkedCaseParticipantRoleList;
import curam.appeal.sl.fact.HearingParticipationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

// Begin CR00117296 LP
/**
 * Maintains business process functionality Hearing Participation -
 * CaseParticipantRoleLink entity
 */
public abstract class HearingParticipation extends
  curam.appeal.facade.base.HearingParticipation {

  /**
   * Terminates the CaseParticipantionRoleLink based on the
   * CaseParticipantRoleLinkKey.
   * 
   * @param key - contains the CaseParticipantRoleLinkID
   * 
   * @throws InformationalException, AppException
   */
  @Override
  public void removeCaseParticipantRoleLink(
    final CaseParticipantRoleLinkKey key) throws AppException,
    InformationalException {

    HearingParticipationFactory.newInstance().removeCaseParticipantRoleLink(
      key.key);
  }

  /**
   * Creates multiple CaseParticipantRoleLink entries with the given
   * CreateCaseParticipantRoleLinkDetails, for each CaseparticipantRoleID in
   * the string CaseparticipantRoleIDs.
   * 
   * @param dtls - CreateCaseParticipantRoleLinkDetails contains the String of
   * CaseparticipantRoleIDs and other details.
   * 
   * @throws InformationalException, AppException
   */
  @Override
  public void addCaseParticipantRoleLink(
    final CreateCaseParticipantRoleLinkDetails details) throws AppException,
    InformationalException {

    HearingParticipationFactory.newInstance()
      .createWitnessCaseParticipantRoleLinks(details.dtls);

  }

  /**
   * List the CaseParticipants who are yet to be linked with the witness
   * 
   * @param relatedID relatedID contains the CaseParticipantRoleID.
   * @throws InformationalException, AppException
   */
  @Override
  public UnlinkedCaseParticipantRoleList listUnlinkedParticipants(
    final RelatedID relatedID) throws AppException, InformationalException {

    final UnlinkedCaseParticipantRoleList unlinkedCaseParticipantRoleList =
      new UnlinkedCaseParticipantRoleList();

    unlinkedCaseParticipantRoleList.viewCaseParticipantRoleDetailsList =
      HearingParticipationFactory.newInstance().listUnlinkedParticipants(
        relatedID.relatedID);
    return unlinkedCaseParticipantRoleList;
  }

}

// End CR00117296 LP
