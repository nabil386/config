/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.ListAppealReopenHistoryDetails;
import curam.appeal.facade.struct.ListAppealReopenHistoryDetailsForIC;
import curam.appeal.facade.struct.ListAppealReopenHistoryKey;
import curam.appeal.facade.struct.ReadReopenDetails;
import curam.appeal.facade.struct.ReadReopenKey;
import curam.appeal.facade.struct.ReopenHearingCaseDetails;
import curam.appeal.facade.struct.ReopenHearingCaseKey_fo;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Cancel Hearing Case
 * presentation layer.
 * 
 */
public abstract class AppealReopenHistory extends
  curam.appeal.facade.base.AppealReopenHistory {

  // ___________________________________________________________________________
  /**
   * Presentation layer method to list re-open history of an appeal case.
   * 
   * @param key The case id for the reopen history list items.
   * 
   * @return The list of hearing case reopen details
   */
  @Override
  public ListAppealReopenHistoryDetails list(
    final ListAppealReopenHistoryKey key) throws AppException,
    InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // AppealReopenHistory object
    final curam.appeal.sl.intf.AppealReopenHistory appealReopenHistoryObj =
      curam.appeal.sl.fact.AppealReopenHistoryFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Create return structure
    final ListAppealReopenHistoryDetails listAppealReopenHistoryDetails =
      new ListAppealReopenHistoryDetails();

    // Retrieve the hearing case reopen list
    listAppealReopenHistoryDetails.listAppealReopenHistoryDetails =
      appealReopenHistoryObj.list(key.ListAppealReopenHistoryKey);

    // Get the context description
    appealCaseDetails.caseID =
      key.ListAppealReopenHistoryKey.reopenHistoryCaseIDKey.caseID;
    listAppealReopenHistoryDetails.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Return the details
    return listAppealReopenHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to list re-open history of an appeal case within
   * an IC.
   * 
   * @param key The case id for the reopen history list items.
   * 
   * @return The list of hearing case reopen details
   */
  @Override
  public ListAppealReopenHistoryDetailsForIC listForIC(
    final ListAppealReopenHistoryKey key) throws AppException,
    InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // AppealReopenHistory object
    final curam.appeal.sl.intf.AppealReopenHistory appealReopenHistoryObj =
      curam.appeal.sl.fact.AppealReopenHistoryFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Create return structure
    final ListAppealReopenHistoryDetailsForIC listAppealReopenHistoryDetailsForIC =
      new ListAppealReopenHistoryDetailsForIC();

    // Retrieve the hearing case reopen list
    listAppealReopenHistoryDetailsForIC.listAppealReopenHistoryDetails =
      appealReopenHistoryObj.list(key.ListAppealReopenHistoryKey);

    // Get the context description
    appealCaseDetails.caseID =
      key.ListAppealReopenHistoryKey.reopenHistoryCaseIDKey.caseID;
    listAppealReopenHistoryDetailsForIC.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Get the menu data
    appealCaseDetails.caseID =
      key.ListAppealReopenHistoryKey.reopenHistoryCaseIDKey.caseID;
    listAppealReopenHistoryDetailsForIC.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    // Return the details
    return listAppealReopenHistoryDetailsForIC;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to retrieve details of an appeal re-opening.
   * 
   * @param key The reopen case history item id.
   * 
   * @return The hearing case reopen details
   */
  @Override
  public ReadReopenDetails read(final ReadReopenKey key) throws AppException,
    InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // AppealReopenHistory object
    final curam.appeal.sl.intf.AppealReopenHistory appealReopenHistoryObj =
      curam.appeal.sl.fact.AppealReopenHistoryFactory.newInstance();

    // Create return structure
    final ReadReopenDetails readReopenDetails = new ReadReopenDetails();

    // Retrieve the reopen details
    readReopenDetails.readReopenDetails =
      appealReopenHistoryObj.read(key.readReopenKey);

    // Return the details
    return readReopenDetails;
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to re-open a hearing case.
   * 
   * @param key The ID of the hearing case being reopened.
   * @param details The details of the hearing case being reopened.
   */
  @Override
  public void reopenCase(final ReopenHearingCaseKey_fo key,
    final ReopenHearingCaseDetails details) throws AppException,
    InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // AppealReopenHistory object
    final curam.appeal.sl.intf.AppealReopenHistory appealReopenHistory =
      curam.appeal.sl.fact.AppealReopenHistoryFactory.newInstance();

    // Reopen the Hearing Case
    appealReopenHistory.reopenCase(key.reopenHearingCaseKey,
      details.reopenHearingCaseDetails);
  }
}
