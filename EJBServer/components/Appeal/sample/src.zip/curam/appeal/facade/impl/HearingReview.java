/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2003-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.ActiveHearingReviewDetailsList;
import curam.appeal.facade.struct.AppellantAndRespondentDetails;
import curam.appeal.facade.struct.AppellantAndRespondentReturnDetails;
import curam.appeal.facade.struct.CaseAppealLevelDetails;
import curam.appeal.facade.struct.CaseIDDetails;
import curam.appeal.facade.struct.CaseType;
import curam.appeal.facade.struct.DecisionsForCaseDetailsList;
import curam.appeal.facade.struct.DecisionsForCaseKey;
import curam.appeal.facade.struct.HearingReviewAddCaseDetails;
import curam.appeal.facade.struct.HearingReviewCaseIDKey;
import curam.appeal.facade.struct.HearingReviewCaseSummaryDetails;
import curam.appeal.facade.struct.HearingReviewCaseSummaryDetailsForIC;
import curam.appeal.facade.struct.HearingReviewCreateDetails;
import curam.appeal.facade.struct.HearingReviewHearingDetailsList;
import curam.appeal.facade.struct.HearingReviewHearingDetailsListForIC;
import curam.appeal.facade.struct.HearingReviewReadModifyDetails;
import curam.appeal.facade.struct.ModifyHearingReviewDetails;
import curam.appeal.facade.struct.ParticipantRoleKey;
import curam.appeal.facade.struct.ReadForCreateHearingReviewDetails;
import curam.appeal.facade.struct.ReadForCreateHearingReviewKey;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.CaseIDAppealTypeCode;
import curam.appeal.sl.struct.CreateHearingReviewAndAppealObjectsDetails;
import curam.appeal.sl.struct.DecisionsForImplCaseKey;
import curam.appeal.sl.struct.ReadForCreateDetails;
import curam.appeal.sl.struct.ValidateAppealedCaseLevelDetails;
import curam.codetable.APPEALTYPE;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.GeneralConstants;

/**
 * This process class provides the functionality for the Hearing Review facade
 * layer.
 * 
 */
public abstract class HearingReview extends
  curam.appeal.facade.base.HearingReview {

  // ___________________________________________________________________________
  /**
   * Modifies the hearing review.
   * 
   * @param details
   * The details of the hearing review case being modified
   */
  @Override
  public void modifyHearingReview(final ModifyHearingReviewDetails details)
    throws AppException, InformationalException {

    // HearingReview object
    final curam.appeal.sl.intf.HearingReview hearingReviewObj =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Update the hearing review
    hearingReviewObj.modify(details.appealModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Lists all hearings for the specified Hearing Review case for integrated
   * cases
   * 
   * @param key
   * hearing review case key
   * 
   * @return list of all hearing reviews
   */
  @Override
  public HearingReviewHearingDetailsListForIC listHearingsForIC(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing review variables
    final curam.appeal.sl.intf.HearingReview hearingReviewObj =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();
    HearingReviewHearingDetailsListForIC hearingReviewDetailsListForIC;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    hearingReviewDetailsListForIC =
      new HearingReviewHearingDetailsListForIC();

    // Get the list of hearings from the service layer
    hearingReviewDetailsListForIC.list =
      hearingReviewObj.listHearings(key.key);

    // Get the context description
    appealCaseDetails.caseID = key.key.caseID;
    hearingReviewDetailsListForIC.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Get the menu data
    appealCaseDetails.caseID = key.key.caseID;
    hearingReviewDetailsListForIC.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    return hearingReviewDetailsListForIC;

  }

  // ___________________________________________________________________________
  /**
   * Lists all hearings for standalone cases for the specified Hearing Review
   * case.
   * 
   * @param key
   * hearing review case key
   * 
   * @return list of all hearing reviews
   */
  @Override
  public HearingReviewHearingDetailsList listHearings(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Hearing review variables
    final curam.appeal.sl.intf.HearingReview hearingReviewObj =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();
    HearingReviewHearingDetailsList hearingReviewDetailsList;

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    hearingReviewDetailsList = new HearingReviewHearingDetailsList();

    // Get the list of hearings from the service later
    hearingReviewDetailsList.list = hearingReviewObj.listHearings(key.key);

    // Get the context description
    appealCaseDetails.caseID = key.key.caseID;
    hearingReviewDetailsList.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    return hearingReviewDetailsList;

  }

  // ___________________________________________________________________________
  /*
   * This method retrieves the details of hearing review
   * 
   * @param key Identifies the hearing review
   * 
   * @return The details of the hearing review case
   */
  @Override
  public HearingReviewCaseSummaryDetails readHearingReviewSummary(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingReviewCaseSummaryDetails hearingReviewCaseSummaryDetails =
      new HearingReviewCaseSummaryDetails();

    // HearingReview object
    final curam.appeal.sl.intf.HearingReview hearingReviewObj =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingReviewCaseSummaryDetails.hearingReviewCaseSummaryDetails =
      hearingReviewObj.readSummary(key.key);

    // Get the context description
    appealCaseDetails.caseID = key.key.caseID;
    hearingReviewCaseSummaryDetails.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Return the details
    return hearingReviewCaseSummaryDetails;
  }

  // ___________________________________________________________________________
  /*
   * This method returns the details of a hearing review
   * 
   * @param key Identifies the hearing review
   * 
   * @return The details of the hearing review case
   */
  @Override
  public HearingReviewCaseSummaryDetailsForIC readHearingReviewSummaryForIC(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingReviewCaseSummaryDetailsForIC hearingReviewCaseSummaryDetailsForIC =
      new HearingReviewCaseSummaryDetailsForIC();

    // HearingReview object
    final curam.appeal.sl.intf.HearingReview hearingReviewObj =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingReviewCaseSummaryDetailsForIC.hearingReviewCaseSummaryDetails =
      hearingReviewObj.readSummary(key.key);

    appealCaseDetails.caseID = key.key.caseID;
    // Get the menu data
    hearingReviewCaseSummaryDetailsForIC.appealMenuData =
      appealObj.getMenuData(appealCaseDetails);

    appealCaseDetails.caseID = key.key.caseID;
    // Get the context description
    appealCaseDetails.caseID = key.key.caseID;
    hearingReviewCaseSummaryDetailsForIC.appealContextDescription =
      appealObj.getContextDescription(appealCaseDetails);

    // Return the details
    return hearingReviewCaseSummaryDetailsForIC;
  }

  // ___________________________________________________________________________
  /**
   * Method to read hearing review details for modification.
   * 
   * @param key
   * The key of the hearing review being modified
   * 
   * @return The hearing review details
   */
  @Override
  public HearingReviewReadModifyDetails readDetailsForModify(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingReviewReadModifyDetails hearingReviewReadModifyDetails =
      new HearingReviewReadModifyDetails();

    // HearingCase objects
    final curam.appeal.sl.intf.HearingReview hearingReview =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingReviewReadModifyDetails.appealModifyDetails =
      hearingReview.readForModify(key.key);

    return hearingReviewReadModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to create a new hearing review
   * 
   * @param details
   * Contains the details of the hearing review
   */
  @Override
  public HearingReviewCaseIDKey create(
    final HearingReviewCreateDetails details) throws AppException,
    InformationalException {

    // Hearing Review object
    final curam.appeal.sl.intf.HearingReview hearingReview =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();

    // Return details
    final HearingReviewCaseIDKey HearingReviewCaseIDKey =
      new HearingReviewCaseIDKey();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    HearingReviewCaseIDKey.key.caseID =
      hearingReview.create(details.appealCaseCreateDetails).caseID;

    return HearingReviewCaseIDKey;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of active hearing reviews for the appellant/respondent.
   * 
   * @param key
   * Contains the participantRoleID and appellantTypeCode
   * 
   * @return The list of active hearing reviews
   */
  @Override
  public ActiveHearingReviewDetailsList listActiveHearingReviews(
    final ParticipantRoleKey key) throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // ParticipantRoleKey details
    final curam.appeal.sl.struct.ParticipantRoleKey participantRoleKey =
      new curam.appeal.sl.struct.ParticipantRoleKey();

    // Return details
    final ActiveHearingReviewDetailsList activeHearingReviewDetailsList =
      new ActiveHearingReviewDetailsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    participantRoleKey.caseID = key.caseID;
    participantRoleKey.appellantTypeCode = key.appellantTypeCode;
    participantRoleKey.participantRoleID = key.participantRoleID;
    participantRoleKey.appealTypeCode =
      curam.codetable.APPEALTYPE.HEARINGREVIEW;

    activeHearingReviewDetailsList.activeAppealsDetailsList =
      appealObj.listActiveAppealsForParticipantRole(participantRoleKey);

    return activeHearingReviewDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Returns the list of decisions for closed hearing cases which appealed the
   * implementation case specified
   * 
   * @param key
   * The key containing the caseID
   * 
   * @return The list of prior appeal decisions
   */
  @Override
  public DecisionsForCaseDetailsList listAppealDecisionsForCase(
    final DecisionsForCaseKey key) throws AppException,
    InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Decision case details objects
    final DecisionsForImplCaseKey decisionsForImplCaseKey =
      new curam.appeal.sl.struct.DecisionsForImplCaseKey();
    final DecisionsForCaseDetailsList decisionsForCaseDetailsList =
      new DecisionsForCaseDetailsList();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    decisionsForImplCaseKey.caseID = key.caseID;
    decisionsForCaseDetailsList.decisionForImplCaseDetailsList =
      appealObj.listDecisionsForImplementationCase(decisionsForImplCaseKey);

    return decisionsForCaseDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Allows the user to insert the participants for the appeal case and
   * indicates if there are active appeal cases of the specified type with the
   * same appellant and respondent
   * 
   * @param details
   * The appellant and respondent details
   * 
   * @return The participantRoleID and active appeal indicator
   */
  @Override
  public AppellantAndRespondentReturnDetails enterAppellantAndRespondent(
    final AppellantAndRespondentDetails details) throws AppException,
    InformationalException {

    // Appeal Object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final ValidateAppealedCaseLevelDetails validateAppealedCaseLevelDetails =
      new ValidateAppealedCaseLevelDetails();

    // Return details
    final AppellantAndRespondentReturnDetails appellantAndRespondentReturnDetails =
      new AppellantAndRespondentReturnDetails();

    // appellantAndRespondent Details
    final curam.appeal.sl.struct.AppellantAndRespondentDetails appellantAndRespondentDetails =
      new curam.appeal.sl.struct.AppellantAndRespondentDetails();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    // Validate the level and type of appeal
    validateAppealedCaseLevelDetails.appealTypeCode =
      APPEALTYPE.HEARINGREVIEW;
    validateAppealedCaseLevelDetails.implCaseID = details.implCaseID;
    validateAppealedCaseLevelDetails.priorAppealCaseID =
      details.priorAppealCaseID;
    appealObj.validateAppealedCaseLevel(validateAppealedCaseLevelDetails);

    appellantAndRespondentDetails.assign(details);
    appellantAndRespondentDetails.appealTypeCode =
      curam.codetable.APPEALTYPE.HEARINGREVIEW;

    appellantAndRespondentReturnDetails.appellantAndRespondentReturnDetails =
      appealObj.enterAppellantAndRespondent(appellantAndRespondentDetails);

    if (details.appellantOrganizationInd) {
      appellantAndRespondentReturnDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.ORGANIZATION;
    } else {
      appellantAndRespondentReturnDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.CLAIMANT;
    }

    return appellantAndRespondentReturnDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to read the details required for creating a hearing review
   * 
   * @param key
   * Contains the details needed to perform the read
   * 
   * @return The details required for hearing review creation
   */
  @Override
  public ReadForCreateHearingReviewDetails readForCreate(
    final ReadForCreateHearingReviewKey key) throws AppException,
    InformationalException {

    // Appeal Object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    // Return details
    final ReadForCreateHearingReviewDetails readForCreateHearingReviewDetails =
      new ReadForCreateHearingReviewDetails();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    final ReadForCreateDetails readForCreateDetails =
      appealObj.readForCreate(key.readForCreateKey);

    if (key.readForCreateKey.appellantTypeCode
      .equals(curam.codetable.APPELLANTTYPE.ORGANIZATION)) {

      readForCreateHearingReviewDetails.appealedCaseID =
        readForCreateDetails.appealedCaseID;
      readForCreateHearingReviewDetails.caseReference =
        readForCreateDetails.caseReference;
      readForCreateHearingReviewDetails.respondentDisplayName =
        readForCreateDetails.displayName;
      readForCreateHearingReviewDetails.appellantDisplayName =
        GeneralConstants.kEmpty;
      readForCreateHearingReviewDetails.respondentParticipantRoleID =
        key.readForCreateKey.participantRoleID;

    } else {

      readForCreateHearingReviewDetails.appealedCaseID =
        readForCreateDetails.appealedCaseID;
      readForCreateHearingReviewDetails.caseReference =
        readForCreateDetails.caseReference;
      readForCreateHearingReviewDetails.appellantDisplayName =
        readForCreateDetails.displayName;
      readForCreateHearingReviewDetails.respondentDisplayName =
        GeneralConstants.kEmpty;
      readForCreateHearingReviewDetails.respondentParticipantRoleID =
        key.readForCreateKey.participantRoleID;

    }

    readForCreateHearingReviewDetails.participantRoleType =
      readForCreateDetails.participantRoleType;

    return readForCreateHearingReviewDetails;

  }

  // ___________________________________________________________________________
  /**
   * Adds an appealed case to an existing hearing review case.
   * 
   * @param details
   * The details for the appealed case to add
   */
  @Override
  public void addAppealedCase(final HearingReviewAddCaseDetails details)
    throws AppException, InformationalException {

    // HearingReview object
    final curam.appeal.sl.intf.HearingReview hearingReviewObj =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    hearingReviewObj.addCase(details.hearingReviewAddCaseDetails);

  }

  // ___________________________________________________________________________
  /**
   * This method returns the case type for the case selected to add to an
   * existing hearing review case. This method also validates if a request for
   * appeal related to the selected case can be appealed to a hearing review
   * case; the level validation which can be performed depends on the type of
   * the selected case.
   * 
   * The selected case can be a previously decided appeal case or an original
   * case within the system. Therefore the level of validation which can be
   * performed depends on the type of the selected case. If a prior appeal case
   * is selected then limited validation can be performed as the decision from
   * that appeal case is unknown at this stage. If an implementation case is
   * selected then it must be valid to directly appeal the case to a hearing
   * review case.
   * 
   * @param details
   * The caseID of the case selected to add to a hearing review case.
   * @return The case type of the selected case.
   */
  @Override
  public CaseType resolveAddCaseSelection(final CaseIDDetails details)
    throws AppException, InformationalException {

    // Variables for resolving the case selection
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseIDAppealTypeCode caseIDAppealTypeCode =
      new CaseIDAppealTypeCode();
    final CaseType caseType = new CaseType();

    // Resolve the case selected to add to an existing hearing case.
    caseIDAppealTypeCode.caseID = details.caseIDDetails.caseID;
    caseIDAppealTypeCode.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    caseType.caseType =
      appealObj.resolveAddCaseSelection(caseIDAppealTypeCode).caseType;

    return caseType;

  }

  // ___________________________________________________________________________
  /**
   * This method returns whether or not the specified case can be appealed to a
   * hearing review case; it also returns whether the appeal can only be the
   * first level of appeal or whether the appeal can be at other levels of
   * appeal.
   * 
   * @param details
   * The case selected to appeal to a hearing review.
   * @return Indicator if case can only be appealed at the first appeal level.
   * Note that a negative value here implies that the case can be
   * appealed at other levels of appeal. Indicator if the case be
   * appealed at the first level at all.
   */
  @Override
  public CaseAppealLevelDetails resolveAppealLevelForCase(
    final CaseIDDetails details) throws AppException, InformationalException {

    // Variables for resolving the appeal level for the case
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseAppealLevelDetails caseAppealLevelDetails =
      new CaseAppealLevelDetails();
    final CaseIDAppealTypeCode caseIDAppealTypeCode =
      new CaseIDAppealTypeCode();

    // Register the security implementation factory
    SecurityImplementationFactory.register();

    // Resolve the appeal level details for appealing the case to a hearing case
    caseIDAppealTypeCode.caseID = details.caseIDDetails.caseID;
    caseIDAppealTypeCode.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    caseAppealLevelDetails.caseAppealLevelDetails =
      appealObj.resolveAppealLevelForCase(caseIDAppealTypeCode);

    return caseAppealLevelDetails;
  }

  /**
   * Create a hearing review case with a delimited list of objects.
   * 
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "AOT1,1001|AOT2,2001|AOT2,2002" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the Appeal Object interface class.
   * 
   * @param details
   * The details of the hearing review case being created including a
   * delimited list of objects.
   * 
   * @return Contains the ID of the hearing review case
   */
  @Override
  public HearingReviewCaseIDKey createWithAppealObjects(
    final CreateHearingReviewAndAppealObjectsDetails details)
    throws AppException, InformationalException {

    // Hearing Review object
    final curam.appeal.sl.intf.HearingReview hearingReview =
      curam.appeal.sl.fact.HearingReviewFactory.newInstance();

    // Return details
    final HearingReviewCaseIDKey HearingReviewCaseIDKey =
      new HearingReviewCaseIDKey();

    // Register a security implementation for the transaction
    SecurityImplementationFactory.register();

    HearingReviewCaseIDKey.key.caseID =
      hearingReview.createWithAppealObjects(details).caseID;

    return HearingReviewCaseIDKey;
  }

}
