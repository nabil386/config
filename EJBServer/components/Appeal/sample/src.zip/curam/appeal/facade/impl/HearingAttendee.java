/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.HearingAttendeeDetails;
import curam.appeal.facade.struct.HearingAttendeeModifyDetails;
import curam.appeal.facade.struct.HearingAttendeeRemoveDetails;
import curam.appeal.facade.struct.HearingUserRoleIDKey;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the HearingAttendee facade.
 * 
 */
public abstract class HearingAttendee extends
  curam.appeal.facade.base.HearingAttendee {

  // ___________________________________________________________________________
  /*
   * Displays the hearing user role details for a hearing attendee.
   * 
   * @param key contains the ID of the hearingUserRole to display
   * 
   * @return the home page details
   */
  @Override
  public HearingAttendeeDetails view(final HearingUserRoleIDKey key)
    throws AppException, InformationalException {

    // Return details
    final HearingAttendeeDetails hearingAttendeeDetails =
      new HearingAttendeeDetails();

    // HearingAttendee object
    final curam.appeal.sl.intf.HearingAttendee hearingAttendeeObj =
      curam.appeal.sl.fact.HearingAttendeeFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign the details
    hearingAttendeeDetails.hearingAttendeeDetails =
      hearingAttendeeObj.view(key.hearingUserRoleIDKey);

    // Return the details
    return hearingAttendeeDetails;
  }

  // ___________________________________________________________________________
  /*
   * This method modifies a hearing user attendee
   * 
   * @param details identifies the hearing attendee
   */
  @Override
  public void modify(final HearingAttendeeModifyDetails details)
    throws AppException, InformationalException {

    // HearingAttendee object
    final curam.appeal.sl.intf.HearingAttendee hearingAttendeeObj =
      curam.appeal.sl.fact.HearingAttendeeFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Modify the details
    hearingAttendeeObj.modify(details.hearingAttendeeModifyDetails);
  }

  // ___________________________________________________________________________
  /*
   * This method removes a hearing user attendee
   * 
   * @param details identifies the hearing attendee
   */
  @Override
  public void remove(final HearingAttendeeRemoveDetails details)
    throws AppException, InformationalException {

    // HearingAttendee object
    final curam.appeal.sl.intf.HearingAttendee hearingAttendeeObj =
      curam.appeal.sl.fact.HearingAttendeeFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Modify the details
    hearingAttendeeObj.remove(details.hearingAttendeeRemoveDetails);
  }

}
