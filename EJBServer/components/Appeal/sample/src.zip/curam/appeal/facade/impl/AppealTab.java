/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealCaseTabDetail;
import curam.appeal.sl.entity.struct.AppealCaseTabDetailKey;
import curam.appeal.sl.fact.AppealTabFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Provides methods to access the details required for the Appeals Tab panels.
 */
public class AppealTab extends curam.appeal.facade.base.AppealTab {

  // __________________________________________________________________________
  /**
   * Reads the details of the appeal case including the case owner, hearing
   * official, case status and resolution information.
   * 
   * @param AppealCaseTabDetailKey
   * @return The case details for the Appeal tab panel.
   * 
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public AppealCaseTabDetail readAppealCaseTabDetail(
    final AppealCaseTabDetailKey appealCaseTabDetailKey) throws AppException,
    InformationalException {

    final AppealCaseTabDetail appealCaseTabDetail = new AppealCaseTabDetail();

    appealCaseTabDetail.dtls =
      AppealTabFactory.newInstance().readAppealCaseTabDetail(
        appealCaseTabDetailKey);

    return appealCaseTabDetail;
  }

}
