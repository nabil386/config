/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.facade.impl;

import curam.appeal.facade.struct.AppealDecisionCreateDetails;
import curam.appeal.facade.struct.AppealDecisionKey;
import curam.appeal.facade.struct.AppealDecisionModifyCommentsDetails;
import curam.appeal.facade.struct.AppealDecisionModifyDetails;
import curam.appeal.facade.struct.AppealDecisionSummaryDetails;
import curam.core.impl.SecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Appeal Decision
 * facade layer.
 * 
 */
public abstract class AppealDecision extends
  curam.appeal.facade.base.AppealDecision {

  // ___________________________________________________________________________
  /**
   * Creates an appeal decision for the appeal case. Note that this does not
   * include any decision attachment or overall resolution details.
   * 
   * @param details The appeal decision creation details.
   * @return The appeal decision identifier
   */
  @Override
  public AppealDecisionKey create(final AppealDecisionCreateDetails details)
    throws AppException, InformationalException {

    // AppealDecision object and struct
    final curam.appeal.sl.intf.AppealDecision appealDecisionObj =
      curam.appeal.sl.fact.AppealDecisionFactory.newInstance();
    final curam.appeal.sl.struct.AppealDecisionCreateDetails appealDecisionCreateDetails =
      new curam.appeal.sl.struct.AppealDecisionCreateDetails();

    // Return details
    final AppealDecisionKey appealDecisionKey = new AppealDecisionKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign values to sl struct
    appealDecisionCreateDetails.appealCaseID =
      details.createAppealDecisionDetails.appealCaseID;
    appealDecisionCreateDetails.comments =
      details.createAppealDecisionDetails.comments;
    appealDecisionCreateDetails.decisionDate =
      details.createAppealDecisionDetails.decisionDate;

    // Create the decision
    appealDecisionKey.appealDecisionKey =
      appealDecisionObj.create(appealDecisionCreateDetails);

    return appealDecisionKey;
  }

  // ___________________________________________________________________________
  /**
   * Updates the details for an appeal decision. Note that this excludes
   * attachment details.
   * 
   * @param details The appeal decision details to modify.
   */
  @Override
  public void modify(final AppealDecisionModifyDetails details)
    throws AppException, InformationalException {

    // AppealDecision object
    final curam.appeal.sl.intf.AppealDecision appealDecisionObj =
      curam.appeal.sl.fact.AppealDecisionFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Modify the decision details
    appealDecisionObj.modify(details.appealDecisionModifyDetails);
  }

  // BEGIN, CR00289874 , DK
  // ___________________________________________________________________________
  /**
   * Updates the details for an appeal decision's comments. Note that this
   * excludes
   * attachment details.
   * 
   * @param details The appeal decision details to modify.
   */
  @Override
  public void
    modifyComments(final AppealDecisionModifyCommentsDetails details)
      throws AppException, InformationalException {

    // AppealDecision object
    final curam.appeal.sl.intf.AppealDecision appealDecisionObj =
      curam.appeal.sl.fact.AppealDecisionFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Modify the decision details
    appealDecisionObj.modifyComments(details.dtls);

  }

  // END, CR00289874 , DK
  // ___________________________________________________________________________
  /**
   * Reads the details for an appeal decision. Note that this does not include
   * and decision attachment details.
   * 
   * @param key The identifier of the decision to read
   * @return The appeal decision details.
   */
  @Override
  public AppealDecisionSummaryDetails read(final AppealDecisionKey key)
    throws AppException, InformationalException {

    // AppealDecision object
    final curam.appeal.sl.intf.AppealDecision appealDecisionObj =
      curam.appeal.sl.fact.AppealDecisionFactory.newInstance();

    // Return details
    final AppealDecisionSummaryDetails appealDecisionSummaryDetails =
      new AppealDecisionSummaryDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Read the decision details
    appealDecisionSummaryDetails.appealDecisionSummaryDetails =
      appealDecisionObj.readSummary(key.appealDecisionKey);

    return appealDecisionSummaryDetails;
  }

}
