/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.impl;

import curam.appeal.sl.entity.fact.AppealObjectFactory;
import curam.appeal.sl.entity.struct.AppealObjectKey;
import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.message.APPEALOBJECT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.CodeTableItemIdentifier;

/**
 * Implementation of the {@linkplain Appeals} interface for Integrated
 * cases.
 */
public class IntegratedCaseAppeal implements Appealable {

  /**
   * {@inheritDoc}
   */
  @Override
  public String getHomePageURI(final APPEALOBJECTTYPEEntry appealObjectType,
    final long appealObjectID) throws AppException, InformationalException {

    final AppealObjectKey key = new AppealObjectKey();

    key.appealObjectID = appealObjectID;
    return CuramConst.kCaseHomePageURI
      + AppealObjectFactory.newInstance().read(key).objectID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LocalisableString getAppealObjectDescription(
    final APPEALOBJECTTYPEEntry appealObjectType, final long appealObjectID)
    throws AppException, InformationalException {

    // Read the case header for the case
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    final AppealObjectKey key = new AppealObjectKey();

    key.appealObjectID = appealObjectID;
    caseHeaderKey.caseID =
      AppealObjectFactory.newInstance().read(key).objectID;

    // Create the description string
    final LocalisableString localisableString =
      new LocalisableString(APPEALOBJECT.INF_APPEAL_OBJECT_DESCRIPTION);

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = AppealObjectFactory.newInstance().read(key).objectID;
    localisableString
      .arg(new CodeTableItemIdentifier(
        curam.codetable.CASECATTYPECODE.TABLENAME,
        CaseHeaderFactory.newInstance().readICHomePageNameAndType(caseKey).integratedCaseType));

    localisableString
      .arg(CaseHeaderFactory.newInstance().read(caseHeaderKey).caseReference);

    return localisableString;
  }

}
